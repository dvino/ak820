                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _process_record_quantum
                                     53 	.globl _action_for_keycode
                                     54 	.globl _mDelaymS
                                     55 	.globl _host_consumer_send
                                     56 	.globl _host_system_send
                                     57 	.globl _host_keyboard_leds
                                     58 	.globl _led_set
                                     59 	.globl _clear_keys_from_report
                                     60 	.globl ___memcpy
                                     61 	.globl _ADC_START
                                     62 	.globl _S0_R_FIFO
                                     63 	.globl _S0_T_FIFO
                                     64 	.globl _S0_FREE
                                     65 	.globl _S0_IF_BYTE
                                     66 	.globl _S0_IF_FIRST
                                     67 	.globl _S0_IF_OV
                                     68 	.globl _S0_FST_ACT
                                     69 	.globl _CP_RL2
                                     70 	.globl _C_T2
                                     71 	.globl _TR2
                                     72 	.globl _EXEN2
                                     73 	.globl _TCLK
                                     74 	.globl _RCLK
                                     75 	.globl _EXF2
                                     76 	.globl _CAP1F
                                     77 	.globl _TF2
                                     78 	.globl _RI
                                     79 	.globl _TI
                                     80 	.globl _RB8
                                     81 	.globl _TB8
                                     82 	.globl _REN
                                     83 	.globl _SM2
                                     84 	.globl _SM1
                                     85 	.globl _SM0
                                     86 	.globl _IT0
                                     87 	.globl _IE0
                                     88 	.globl _IT1
                                     89 	.globl _IE1
                                     90 	.globl _TR0
                                     91 	.globl _TF0
                                     92 	.globl _TR1
                                     93 	.globl _TF1
                                     94 	.globl _P4_0
                                     95 	.globl _P4_1
                                     96 	.globl _P4_2
                                     97 	.globl _P4_3
                                     98 	.globl _P4_4
                                     99 	.globl _P4_5
                                    100 	.globl _P4_6
                                    101 	.globl _RXD
                                    102 	.globl _TXD
                                    103 	.globl _INT0
                                    104 	.globl _INT1
                                    105 	.globl _T0
                                    106 	.globl _T1
                                    107 	.globl _MOSI1
                                    108 	.globl _MISO1
                                    109 	.globl _SCK1
                                    110 	.globl _P3_0
                                    111 	.globl _P3_1
                                    112 	.globl _P3_2
                                    113 	.globl _P3_3
                                    114 	.globl _P3_4
                                    115 	.globl _P3_5
                                    116 	.globl _P3_6
                                    117 	.globl _P3_7
                                    118 	.globl _CAP1_
                                    119 	.globl _T2_
                                    120 	.globl _CAP2_
                                    121 	.globl _T2EX_
                                    122 	.globl _RXD1
                                    123 	.globl _TXD1
                                    124 	.globl _P2_0
                                    125 	.globl _P2_1
                                    126 	.globl _P2_2
                                    127 	.globl _P2_3
                                    128 	.globl _P2_4
                                    129 	.globl _P2_5
                                    130 	.globl _P2_6
                                    131 	.globl _P2_7
                                    132 	.globl _AIN0
                                    133 	.globl _AIN1
                                    134 	.globl _AIN2
                                    135 	.globl _AIN3
                                    136 	.globl _AIN4
                                    137 	.globl _AIN5
                                    138 	.globl _AIN6
                                    139 	.globl _AIN7
                                    140 	.globl _CAP1
                                    141 	.globl _T2
                                    142 	.globl _CAP2
                                    143 	.globl _T2EX
                                    144 	.globl _INT0_
                                    145 	.globl _SCS
                                    146 	.globl _MOSI
                                    147 	.globl _MISO
                                    148 	.globl _SCK
                                    149 	.globl _RXD1_
                                    150 	.globl _TXD1_
                                    151 	.globl _P1_0
                                    152 	.globl _P1_1
                                    153 	.globl _P1_2
                                    154 	.globl _P1_3
                                    155 	.globl _P1_4
                                    156 	.globl _P1_5
                                    157 	.globl _P1_6
                                    158 	.globl _P1_7
                                    159 	.globl _AIN8
                                    160 	.globl _AIN9
                                    161 	.globl _AIN10
                                    162 	.globl _AIN11
                                    163 	.globl _AIN12
                                    164 	.globl _AIN13
                                    165 	.globl _RXD_
                                    166 	.globl _TXD_
                                    167 	.globl _SCL0
                                    168 	.globl _SDA0
                                    169 	.globl _P0_0
                                    170 	.globl _P0_1
                                    171 	.globl _P0_2
                                    172 	.globl _P0_3
                                    173 	.globl _P0_4
                                    174 	.globl _P0_5
                                    175 	.globl _P0_6
                                    176 	.globl _P0_7
                                    177 	.globl _IE_SPI0
                                    178 	.globl _IE_USB
                                    179 	.globl _IE_ADC
                                    180 	.globl _IE_UART1
                                    181 	.globl _IE_PWM_I2C
                                    182 	.globl _IE_GPIO
                                    183 	.globl _IE_WDOG
                                    184 	.globl _PX0
                                    185 	.globl _PT0
                                    186 	.globl _PX1
                                    187 	.globl _PT1
                                    188 	.globl _PS
                                    189 	.globl _PT2
                                    190 	.globl _PL_FLAG
                                    191 	.globl _PH_FLAG
                                    192 	.globl _EX0
                                    193 	.globl _ET0
                                    194 	.globl _EX1
                                    195 	.globl _ET1
                                    196 	.globl _ES
                                    197 	.globl _ET2
                                    198 	.globl _E_DIS
                                    199 	.globl _EA
                                    200 	.globl _P
                                    201 	.globl _F1
                                    202 	.globl _OV
                                    203 	.globl _RS0
                                    204 	.globl _RS1
                                    205 	.globl _F0
                                    206 	.globl _AC
                                    207 	.globl _CY
                                    208 	.globl _I2CS_INT_ST
                                    209 	.globl _I2CX_INT
                                    210 	.globl _LED_STATUS
                                    211 	.globl _LED_DMA_H
                                    212 	.globl _LED_DMA_L
                                    213 	.globl _LED_DMA
                                    214 	.globl _LED_PWM_OE
                                    215 	.globl _LED_COMMON
                                    216 	.globl _ADC_CHAN
                                    217 	.globl _ADC_DAT_H
                                    218 	.globl _ADC_DAT_L
                                    219 	.globl _ADC_DAT
                                    220 	.globl _ADC_CTRL
                                    221 	.globl _SPI1_CK_SE
                                    222 	.globl _SPI1_CTRL
                                    223 	.globl _SPI1_DATA
                                    224 	.globl _SPI1_STAT
                                    225 	.globl _SIF1
                                    226 	.globl _SBAUD1
                                    227 	.globl _SBUF1
                                    228 	.globl _SCON1
                                    229 	.globl _SPI0_SETUP
                                    230 	.globl _SPI0_CK_SE
                                    231 	.globl _SPI0_CTRL
                                    232 	.globl _SPI0_DATA
                                    233 	.globl _SPI0_STAT
                                    234 	.globl _T2CAP1H
                                    235 	.globl _T2CAP1L
                                    236 	.globl _T2CAP1
                                    237 	.globl _TH2
                                    238 	.globl _TL2
                                    239 	.globl _T2COUNT
                                    240 	.globl _RCAP2H
                                    241 	.globl _RCAP2L
                                    242 	.globl _RCAP2
                                    243 	.globl _T2MOD
                                    244 	.globl _T2CON
                                    245 	.globl _SBUF
                                    246 	.globl _SCON
                                    247 	.globl _TH1
                                    248 	.globl _TH0
                                    249 	.globl _TL1
                                    250 	.globl _TL0
                                    251 	.globl _TMOD
                                    252 	.globl _TCON
                                    253 	.globl _XBUS_AUX
                                    254 	.globl _P7
                                    255 	.globl _P6_DIR
                                    256 	.globl _P6_OUT_PU
                                    257 	.globl _P6_IN
                                    258 	.globl _P5_DIR
                                    259 	.globl _P5_OUT_PU
                                    260 	.globl _P5_IN
                                    261 	.globl _P4_LED_KEY
                                    262 	.globl _P4_DIR_PU
                                    263 	.globl _P4_MOD_OC
                                    264 	.globl _P4
                                    265 	.globl _P3_DIR_PU
                                    266 	.globl _P3_MOD_OC
                                    267 	.globl _P3
                                    268 	.globl _P2_DIR_PU
                                    269 	.globl _P2_MOD_OC
                                    270 	.globl _P2
                                    271 	.globl _P1_DIR_PU
                                    272 	.globl _P1_MOD_OC
                                    273 	.globl _P1
                                    274 	.globl _P0_DIR_PU
                                    275 	.globl _P0_MOD_OC
                                    276 	.globl _P0
                                    277 	.globl _ROM_CTRL
                                    278 	.globl _ROM_DATA_HH
                                    279 	.globl _ROM_DATA_HL
                                    280 	.globl _ROM_DATA_HI
                                    281 	.globl _ROM_ADDR_H
                                    282 	.globl _ROM_ADDR_L
                                    283 	.globl _ROM_ADDR
                                    284 	.globl _GPIO_IE
                                    285 	.globl _IP_EX
                                    286 	.globl _IE_EX
                                    287 	.globl _IP
                                    288 	.globl _IE
                                    289 	.globl _WDOG_COUNT
                                    290 	.globl _RESET_KEEP
                                    291 	.globl _WAKE_CTRL
                                    292 	.globl _CLOCK_CFG
                                    293 	.globl _POWER_CFG
                                    294 	.globl _PCON
                                    295 	.globl _GLOBAL_CFG
                                    296 	.globl _SAFE_MOD
                                    297 	.globl _DPH
                                    298 	.globl _DPL
                                    299 	.globl _SP
                                    300 	.globl _A_INV
                                    301 	.globl _B
                                    302 	.globl _ACC
                                    303 	.globl _PSW
                                    304 	.globl _disable_action_cache
                                    305 	.globl _tap_code_delay_PARM_2
                                    306 	.globl _process_action_PARM_2
                                    307 	.globl _action_exec_PARM_1
                                    308 	.globl _tp_buttons
                                    309 	.globl _action_exec
                                    310 	.globl _ak820_action_exec
                                    311 	.globl _process_record
                                    312 	.globl _process_record_handler
                                    313 	.globl _process_action
                                    314 	.globl _register_code
                                    315 	.globl _unregister_code
                                    316 	.globl _tap_code_delay
                                    317 	.globl _tap_code
                                    318 	.globl _register_mods
                                    319 	.globl _unregister_mods
                                    320 	.globl _register_weak_mods
                                    321 	.globl _unregister_weak_mods
                                    322 	.globl _clear_keyboard
                                    323 	.globl _clear_keyboard_but_mods
                                    324 	.globl _clear_keyboard_but_mods_and_keys
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000018                        587 _process_action_sloc0_1_0:
      000018                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; overlayable items in internal ram
                                    591 ;--------------------------------------------------------
                                    592 ;--------------------------------------------------------
                                    593 ; indirectly addressable internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area ISEG    (DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; absolute internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area IABS    (ABS,DATA)
                                    600 	.area IABS    (ABS,DATA)
                                    601 ;--------------------------------------------------------
                                    602 ; bit data
                                    603 ;--------------------------------------------------------
                                    604 	.area BSEG    (BIT)
      00001D                        605 _process_action_sloc1_1_0:
      00001D                        606 	.ds 1
                                    607 ;--------------------------------------------------------
                                    608 ; paged external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area PSEG    (PAG,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; uninitialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XSEG    (XDATA)
      000807                        615 _tp_buttons::
      000807                        616 	.ds 2
      000809                        617 _action_exec_PARM_1:
      000809                        618 	.ds 6
      00080F                        619 _action_exec_record_10001_624:
      00080F                        620 	.ds 9
      000818                        621 _ak820_action_exec_event_10000_628:
      000818                        622 	.ds 2
      00081A                        623 _ak820_action_exec_snapshot_10000_629:
      00081A                        624 	.ds 6
      000820                        625 _process_record_record_argument_10000_632:
      000820                        626 	.ds 2
      000822                        627 _process_record_handler_record_argument_10000_640:
      000822                        628 	.ds 2
      000824                        629 _process_record_handler_action_10000_641:
      000824                        630 	.ds 2
      000826                        631 _process_action_PARM_2:
      000826                        632 	.ds 2
      000828                        633 _process_action_record_argument_10000_652:
      000828                        634 	.ds 2
      00082A                        635 _process_action_on_40000_675:
      00082A                        636 	.ds 1
      00082B                        637 _register_code_code_10000_709:
      00082B                        638 	.ds 1
      00082C                        639 _unregister_code_code_10000_723:
      00082C                        640 	.ds 1
      00082D                        641 _tap_code_delay_PARM_2:
      00082D                        642 	.ds 2
      00082F                        643 _tap_code_delay_code_10000_736:
      00082F                        644 	.ds 1
      000830                        645 _tap_code_code_10000_743:
      000830                        646 	.ds 1
      000831                        647 _register_mods_mods_10000_745:
      000831                        648 	.ds 1
      000832                        649 _unregister_mods_mods_10000_749:
      000832                        650 	.ds 1
      000833                        651 _register_weak_mods_mods_10000_753:
      000833                        652 	.ds 1
      000834                        653 _unregister_weak_mods_mods_10000_757:
      000834                        654 	.ds 1
                                    655 ;--------------------------------------------------------
                                    656 ; absolute external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XABS    (ABS,XDATA)
                                    659 ;--------------------------------------------------------
                                    660 ; initialized external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XISEG   (XDATA)
      000D8D                        663 _disable_action_cache::
      000D8D                        664 	.ds 1
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT0 (CODE)
                                    667 	.area GSINIT1 (CODE)
                                    668 	.area GSINIT2 (CODE)
                                    669 	.area GSINIT3 (CODE)
                                    670 	.area GSINIT4 (CODE)
                                    671 	.area GSINIT5 (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area CSEG    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; global & static initialisations
                                    677 ;--------------------------------------------------------
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; Home
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area HOME    (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; code
                                    689 ;--------------------------------------------------------
                                    690 	.area CSEG    (CODE)
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    693 ;------------------------------------------------------------
                                    694 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    695 ;------------------------------------------------------------
                                    696 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    697 ;	-----------------------------------------
                           000007   698 	ar7 = 0x07
                           000006   699 	ar6 = 0x06
                           000005   700 	ar5 = 0x05
                           000004   701 	ar4 = 0x04
                           000003   702 	ar3 = 0x03
                           000002   703 	ar2 = 0x02
                           000001   704 	ar1 = 0x01
                           000000   705 	ar0 = 0x00
                                    706 ;	 function action_exec
                                    707 ;	-----------------------------------------
      006F10                        708 _action_exec:
                                    709 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      006F10 90 08 0B         [24]  710 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006F13 12 37 A2         [24]  711 	lcall	_ak820_outline_0004
      006F16 12 35 B9         [24]  712 	lcall	_ak820_combo_tick
                                    713 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      006F19 90 08 09         [24]  714 	mov	dptr,#_action_exec_PARM_1
      006F1C 12 44 20         [24]  715 	lcall	_ak820_tapping_before
      006F1F E5 82            [12]  716 	mov	a, dpl
      006F21 70 01            [24]  717 	jnz	00102$
      006F23 22               [24]  718 	ret
      006F24                        719 00102$:
                                    720 ;	quantum/action.c:126: if (event.pressed) {
      006F24 90 08 0E         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006F27 E0               [24]  722 	movx	a,@dptr
      006F28 60 03            [24]  723 	jz	00104$
                                    724 ;	quantum/action.c:128: clear_weak_mods();
      006F2A 12 7F 17         [24]  725 	lcall	_clear_weak_mods
      006F2D                        726 00104$:
                                    727 ;	quantum/action.c:140: record.event = event;
      006F2D 90 0D 6D         [24]  728 	mov	dptr,#___memcpy_PARM_2
      006F30 74 09            [12]  729 	mov	a,#_action_exec_PARM_1
      006F32 F0               [24]  730 	movx	@dptr,a
      006F33 74 08            [12]  731 	mov	a,#(_action_exec_PARM_1 >> 8)
      006F35 12 75 8E         [24]  732 	lcall	_ak820_outline_0048
      006F38 12 75 AE         [24]  733 	lcall	_ak820_outline_0106
      006F3B 90 08 0F         [24]  734 	mov	dptr,#_action_exec_record_10001_624
      006F3E F5 F0            [12]  735 	mov	b,a
      006F40 12 B5 58         [24]  736 	lcall	___memcpy
                                    737 ;	quantum/action.c:142: record.tap.count = 0;
      006F43 90 08 15         [24]  738 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      006F46 E0               [24]  739 	movx	a,@dptr
      006F47 54 0F            [12]  740 	anl	a,#0x0f
      006F49 F0               [24]  741 	movx	@dptr,a
                                    742 ;	quantum/action.c:147: record.keycode = 0;
      006F4A 90 08 16         [24]  743 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      006F4D 12 4E 64         [24]  744 	lcall	_ak820_outline_0164
                                    745 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006F50 90 08 13         [24]  746 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      006F53 E0               [24]  747 	movx	a,@dptr
      006F54 60 0A            [24]  748 	jz	00107$
      006F56 90 08 0F         [24]  749 	mov	dptr,#_action_exec_record_10001_624
      006F59 12 9C 7F         [24]  750 	lcall	_pre_process_record_quantum
      006F5C E5 82            [12]  751 	mov	a, dpl
      006F5E 60 11            [24]  752 	jz	00110$
      006F60                        753 00107$:
                                    754 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      006F60 90 08 0F         [24]  755 	mov	dptr,#_action_exec_record_10001_624
      006F63 12 45 0C         [24]  756 	lcall	_ak820_tapping_process
      006F66 E5 82            [12]  757 	mov	a, dpl
      006F68 70 01            [24]  758 	jnz	00106$
      006F6A 22               [24]  759 	ret
      006F6B                        760 00106$:
                                    761 ;	quantum/action.c:185: process_record(&record);
      006F6B 90 08 0F         [24]  762 	mov	dptr,#_action_exec_record_10001_624
                                    763 ;	quantum/action.c:200: }
      006F6E 02 6F AF         [24]  764 	ljmp	_process_record
      006F71                        765 00110$:
      006F71 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_action_exec'
                                    769 ;------------------------------------------------------------
                                    770 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    771 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    772 ;------------------------------------------------------------
                                    773 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    774 ;	-----------------------------------------
                                    775 ;	 function ak820_action_exec
                                    776 ;	-----------------------------------------
      006F72                        777 _ak820_action_exec:
      006F72 12 38 47         [24]  778 	lcall	_ak820_outline_0103
      006F75 90 08 18         [24]  779 	mov	dptr,#_ak820_action_exec_event_10000_628
      006F78 12 38 42         [24]  780 	lcall	_ak820_outline_0102
                                    781 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      006F7B 90 08 18         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      006F7E 12 38 10         [24]  783 	lcall	_ak820_outline_0055
      006F81 90 0D 6D         [24]  784 	mov	dptr,#___memcpy_PARM_2
      006F84 ED               [12]  785 	mov	a,r5
      006F85 12 37 E1         [24]  786 	lcall	_ak820_outline_0014
      006F88 90 0D 70         [24]  787 	mov	dptr,#___memcpy_PARM_3
      006F8B 12 75 AE         [24]  788 	lcall	_ak820_outline_0106
      006F8E 90 08 1A         [24]  789 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      006F91 F5 F0            [12]  790 	mov	b,a
      006F93 12 B5 58         [24]  791 	lcall	___memcpy
                                    792 ;	quantum/action.c:207: action_exec(snapshot);
      006F96 90 0D 6D         [24]  793 	mov	dptr,#___memcpy_PARM_2
      006F99 74 1A            [12]  794 	mov	a,#_ak820_action_exec_snapshot_10000_629
      006F9B F0               [24]  795 	movx	@dptr,a
      006F9C 74 08            [12]  796 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      006F9E 12 75 8E         [24]  797 	lcall	_ak820_outline_0048
      006FA1 12 75 AE         [24]  798 	lcall	_ak820_outline_0106
      006FA4 90 08 09         [24]  799 	mov	dptr,#_action_exec_PARM_1
      006FA7 F5 F0            [12]  800 	mov	b,a
      006FA9 12 B5 58         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:208: }
      006FAC 02 6F 10         [24]  803 	ljmp	_action_exec
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'process_record_nocache'
                                    806 ;------------------------------------------------------------
                                    807 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function process_record
                                    812 ;	-----------------------------------------
      006FAF                        813 _process_record:
      006FAF 12 38 47         [24]  814 	lcall	_ak820_outline_0103
      006FB2 90 08 20         [24]  815 	mov	dptr,#_process_record_record_argument_10000_632
      006FB5 12 38 42         [24]  816 	lcall	_ak820_outline_0102
                                    817 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006FB8 90 08 20         [24]  818 	mov	dptr,#_process_record_record_argument_10000_632
      006FBB 12 37 F9         [24]  819 	lcall	_ak820_outline_0049
                                    820 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      006FBE 74 04            [12]  821 	mov	a,#0x04
      006FC0 12 47 6D         [24]  822 	lcall	_ak820_outline_0011
      006FC3 70 01            [24]  823 	jnz	00102$
                                    824 ;	quantum/action.c:354: return;
      006FC5 22               [24]  825 	ret
      006FC6                        826 00102$:
                                    827 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      006FC6 8E 04            [24]  828 	mov	ar4,r6
      006FC8 8F 05            [24]  829 	mov	ar5,r7
      006FCA 90 0D 6D         [24]  830 	mov	dptr,#___memcpy_PARM_2
      006FCD EC               [12]  831 	mov	a,r4
      006FCE F0               [24]  832 	movx	@dptr,a
      006FCF ED               [12]  833 	mov	a,r5
      006FD0 12 75 8E         [24]  834 	lcall	_ak820_outline_0048
      006FD3 12 4E 56         [24]  835 	lcall	_ak820_outline_0105
      006FD6 90 06 20         [24]  836 	mov	dptr,#_ak820_tapping_source_PARM_1
      006FD9 F5 F0            [12]  837 	mov	b,a
      006FDB C0 07            [24]  838 	push	ar7
      006FDD C0 06            [24]  839 	push	ar6
      006FDF 12 B5 58         [24]  840 	lcall	___memcpy
      006FE2 12 43 5A         [24]  841 	lcall	_ak820_tapping_source
      006FE5 AD 82            [24]  842 	mov	r5, dpl
      006FE7 D0 06            [24]  843 	pop	ar6
      006FE9 D0 07            [24]  844 	pop	ar7
                                    845 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      006FEB 12 42 BE         [24]  846 	lcall	_ak820_outline_0010
      006FEE E0               [24]  847 	movx	a,@dptr
      006FEF FC               [12]  848 	mov	r4,a
                                    849 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      006FF0 74 07            [12]  850 	mov	a,#0x07
      006FF2 2E               [12]  851 	add	a, r6
      006FF3 FA               [12]  852 	mov	r2,a
      006FF4 E4               [12]  853 	clr	a
      006FF5 3F               [12]  854 	addc	a, r7
      006FF6 FB               [12]  855 	mov	r3,a
      006FF7 90 0B CF         [24]  856 	mov	dptr,#_get_record_keycode_PARM_2
      006FFA 74 01            [12]  857 	mov	a,#0x01
      006FFC 12 42 F4         [24]  858 	lcall	_ak820_outline_0058
      006FFF C0 07            [24]  859 	push	ar7
      007001 C0 06            [24]  860 	push	ar6
      007003 C0 05            [24]  861 	push	ar5
      007005 C0 04            [24]  862 	push	ar4
      007007 C0 03            [24]  863 	push	ar3
      007009 C0 02            [24]  864 	push	ar2
      00700B 12 9C 41         [24]  865 	lcall	_get_record_keycode
      00700E A8 82            [24]  866 	mov	r0, dpl
      007010 A9 83            [24]  867 	mov	r1, dph
      007012 D0 02            [24]  868 	pop	ar2
      007014 D0 03            [24]  869 	pop	ar3
      007016 D0 04            [24]  870 	pop	ar4
      007018 D0 05            [24]  871 	pop	ar5
      00701A D0 06            [24]  872 	pop	ar6
      00701C D0 07            [24]  873 	pop	ar7
      00701E 12 43 35         [24]  874 	lcall	_ak820_outline_0139
      007021 E8               [12]  875 	mov	a,r0
      007022 F0               [24]  876 	movx	@dptr,a
      007023 E9               [12]  877 	mov	a,r1
      007024 A3               [24]  878 	inc	dptr
      007025 F0               [24]  879 	movx	@dptr,a
                                    880 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007026 74 07            [12]  881 	mov	a,#0x07
      007028 12 37 E9         [24]  882 	lcall	_ak820_outline_0019
      00702B 12 43 01         [24]  883 	lcall	_ak820_outline_0080
      00702E 90 06 2D         [24]  884 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007031 ED               [12]  885 	mov	a,r5
      007032 F0               [24]  886 	movx	@dptr,a
      007033 90 06 2E         [24]  887 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007036 EC               [12]  888 	mov	a,r4
      007037 F0               [24]  889 	movx	@dptr,a
      007038 12 43 35         [24]  890 	lcall	_ak820_outline_0139
      00703B C0 07            [24]  891 	push	ar7
      00703D C0 06            [24]  892 	push	ar6
      00703F C0 05            [24]  893 	push	ar5
      007041 C0 04            [24]  894 	push	ar4
      007043 12 46 37         [24]  895 	lcall	_ak820_oneshot_process
      007046 E5 82            [12]  896 	mov	a, dpl
      007048 D0 04            [24]  897 	pop	ar4
      00704A D0 05            [24]  898 	pop	ar5
      00704C D0 06            [24]  899 	pop	ar6
      00704E D0 07            [24]  900 	pop	ar7
      007050 70 01            [24]  901 	jnz	00104$
      007052 22               [24]  902 	ret
      007053                        903 00104$:
                                    904 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      007053 12 43 1F         [24]  905 	lcall	_ak820_outline_0116
      007056 C0 07            [24]  906 	push	ar7
      007058 C0 06            [24]  907 	push	ar6
      00705A C0 05            [24]  908 	push	ar5
      00705C C0 04            [24]  909 	push	ar4
      00705E 12 9C C3         [24]  910 	lcall	_process_record_quantum
      007061 E5 82            [12]  911 	mov	a, dpl
      007063 D0 04            [24]  912 	pop	ar4
      007065 D0 05            [24]  913 	pop	ar5
      007067 D0 06            [24]  914 	pop	ar6
      007069 D0 07            [24]  915 	pop	ar7
      00706B 70 0A            [24]  916 	jnz	00106$
                                    917 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00706D 90 05 98         [24]  918 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007070 EC               [12]  919 	mov	a,r4
      007071 F0               [24]  920 	movx	@dptr,a
      007072 8D 82            [24]  921 	mov	dpl, r5
                                    922 ;	quantum/action.c:376: return;
      007074 02 2E BB         [24]  923 	ljmp	_ak820_oneshot_post
      007077                        924 00106$:
                                    925 ;	quantum/action.c:382: process_record_handler(record);
      007077 12 43 1F         [24]  926 	lcall	_ak820_outline_0116
      00707A C0 05            [24]  927 	push	ar5
      00707C C0 04            [24]  928 	push	ar4
      00707E 12 70 8F         [24]  929 	lcall	_process_record_handler
      007081 D0 04            [24]  930 	pop	ar4
      007083 D0 05            [24]  931 	pop	ar5
                                    932 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007085 90 05 98         [24]  933 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007088 EC               [12]  934 	mov	a,r4
      007089 F0               [24]  935 	movx	@dptr,a
      00708A 8D 82            [24]  936 	mov	dpl, r5
                                    937 ;	quantum/action.c:392: }
      00708C 02 2E BB         [24]  938 	ljmp	_ak820_oneshot_post
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'process_record_handler'
                                    941 ;------------------------------------------------------------
                                    942 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    943 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    944 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function process_record_handler
                                    949 ;	-----------------------------------------
      00708F                        950 _process_record_handler:
      00708F 12 38 47         [24]  951 	lcall	_ak820_outline_0103
      007092 90 08 22         [24]  952 	mov	dptr,#_process_record_handler_record_argument_10000_640
      007095 12 38 42         [24]  953 	lcall	_ak820_outline_0102
                                    954 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007098 90 08 22         [24]  955 	mov	dptr,#_process_record_handler_record_argument_10000_640
      00709B 12 37 B9         [24]  956 	lcall	_ak820_outline_0008
                                    957 ;	quantum/action.c:405: if (record->keycode) {
      00709E 4C               [12]  958 	orl	a,r4
      00709F 60 19            [24]  959 	jz	00102$
                                    960 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      0070A1 12 38 53         [24]  961 	lcall	_ak820_outline_0117
      0070A4 C0 07            [24]  962 	push	ar7
      0070A6 C0 06            [24]  963 	push	ar6
      0070A8 12 93 13         [24]  964 	lcall	_action_for_keycode
      0070AB 12 43 3A         [24]  965 	lcall	_ak820_outline_0143
      0070AE D0 06            [24]  966 	pop	ar6
      0070B0 D0 07            [24]  967 	pop	ar7
      0070B2 90 08 24         [24]  968 	mov	dptr,#_process_record_handler_action_10000_641
      0070B5 12 38 1E         [24]  969 	lcall	_ak820_outline_0068
      0070B8 80 2B            [24]  970 	sjmp	00104$
      0070BA                        971 00102$:
                                    972 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0070BA 12 75 76         [24]  973 	lcall	_ak820_outline_0018
      0070BD 7A 00            [12]  974 	mov	r2,#0x00
      0070BF 12 43 2F         [24]  975 	lcall	_ak820_outline_0138
      0070C2 12 42 BE         [24]  976 	lcall	_ak820_outline_0010
      0070C5 E0               [24]  977 	movx	a,@dptr
      0070C6 90 09 5F         [24]  978 	mov	dptr,#_ak820_resolve_key_PARM_2
      0070C9 F0               [24]  979 	movx	@dptr,a
      0070CA 8D 82            [24]  980 	mov	dpl, r5
      0070CC 8C 83            [24]  981 	mov	dph, r4
      0070CE C0 07            [24]  982 	push	ar7
      0070D0 C0 06            [24]  983 	push	ar6
      0070D2 12 79 13         [24]  984 	lcall	_ak820_resolve_key
      0070D5 12 93 13         [24]  985 	lcall	_action_for_keycode
      0070D8 12 43 3A         [24]  986 	lcall	_ak820_outline_0143
      0070DB D0 06            [24]  987 	pop	ar6
      0070DD D0 07            [24]  988 	pop	ar7
      0070DF 90 08 24         [24]  989 	mov	dptr,#_process_record_handler_action_10000_641
      0070E2 12 38 1E         [24]  990 	lcall	_ak820_outline_0068
                                    991 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0070E5                        992 00104$:
                                    993 ;	quantum/action.c:429: process_action(record, action);
      0070E5 90 0D 6D         [24]  994 	mov	dptr,#___memcpy_PARM_2
      0070E8 74 24            [12]  995 	mov	a,#_process_record_handler_action_10000_641
      0070EA F0               [24]  996 	movx	@dptr,a
      0070EB 74 08            [12]  997 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      0070ED 12 75 8E         [24]  998 	lcall	_ak820_outline_0048
      0070F0 12 4E 56         [24]  999 	lcall	_ak820_outline_0105
      0070F3 90 08 26         [24] 1000 	mov	dptr,#_process_action_PARM_2
      0070F6 F5 F0            [12] 1001 	mov	b,a
      0070F8 C0 07            [24] 1002 	push	ar7
      0070FA C0 06            [24] 1003 	push	ar6
      0070FC 12 B5 58         [24] 1004 	lcall	___memcpy
      0070FF D0 06            [24] 1005 	pop	ar6
      007101 D0 07            [24] 1006 	pop	ar7
      007103 12 43 1F         [24] 1007 	lcall	_ak820_outline_0116
                                   1008 ;	quantum/action.c:430: }
      007106 02 71 09         [24] 1009 	ljmp	_process_action
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'register_mouse'
                                   1012 ;------------------------------------------------------------
                                   1013 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1014 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1015 ;------------------------------------------------------------
                                   1016 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1017 ;	-----------------------------------------
                                   1018 ;	 function process_action
                                   1019 ;	-----------------------------------------
      007109                       1020 _process_action:
      007109 12 38 47         [24] 1021 	lcall	_ak820_outline_0103
      00710C 90 08 28         [24] 1022 	mov	dptr,#_process_action_record_argument_10000_652
      00710F 12 38 42         [24] 1023 	lcall	_ak820_outline_0102
                                   1024 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007112 90 08 28         [24] 1025 	mov	dptr,#_process_action_record_argument_10000_652
      007115 12 37 A2         [24] 1026 	lcall	_ak820_outline_0004
                                   1027 ;	quantum/action.c:501: pressed = record->event.pressed;
      007118 A3               [24] 1028 	inc	dptr
      007119 A3               [24] 1029 	inc	dptr
      00711A A3               [24] 1030 	inc	dptr
      00711B A3               [24] 1031 	inc	dptr
      00711C A3               [24] 1032 	inc	dptr
      00711D E0               [24] 1033 	movx	a,@dptr
      00711E F5 18            [12] 1034 	mov	_process_action_sloc0_1_0,a
                                   1035 ;	quantum/action.c:525: switch (action.kind.id) {
      007120 90 08 27         [24] 1036 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007123 E0               [24] 1037 	movx	a,@dptr
      007124 C4               [12] 1038 	swap	a
      007125 54 0F            [12] 1039 	anl	a,#0x0f
      007127 FD               [12] 1040 	mov  r5,a
      007128 24 F4            [12] 1041 	add	a,#0xff - 0x0b
      00712A 50 03            [24] 1042 	jnc	00434$
      00712C 02 73 AA         [24] 1043 	ljmp	00181$
      00712F                       1044 00434$:
                                   1045 ;	free result
      00712F ED               [12] 1046 	mov	a,r5
      007130 24 0A            [12] 1047 	add	a,#(00435$-3-.)
      007132 83               [24] 1048 	movc	a,@a+pc
      007133 F5 82            [12] 1049 	mov	dpl,a
      007135 ED               [12] 1050 	mov	a,r5
      007136 24 10            [12] 1051 	add	a,#(00436$-3-.)
      007138 83               [24] 1052 	movc	a,@a+pc
      007139 F5 83            [12] 1053 	mov	dph,a
      00713B E4               [12] 1054 	clr	a
      00713C 73               [24] 1055 	jmp	@a+dptr
      00713D                       1056 00435$:
      00713D 55                    1057 	.db	00102$
      00713E 55                    1058 	.db	00102$
      00713F AA                    1059 	.db	00181$
      007140 AA                    1060 	.db	00181$
      007141 DF                    1061 	.db	00123$
      007142 AA                    1062 	.db	00181$
      007143 AA                    1063 	.db	00181$
      007144 AA                    1064 	.db	00181$
      007145 3F                    1065 	.db	00131$
      007146 11                    1066 	.db	00147$
      007147 37                    1067 	.db	00152$
      007148 37                    1068 	.db	00152$
      007149                       1069 00436$:
      007149 71                    1070 	.db	00102$>>8
      00714A 71                    1071 	.db	00102$>>8
      00714B 73                    1072 	.db	00181$>>8
      00714C 73                    1073 	.db	00181$>>8
      00714D 71                    1074 	.db	00123$>>8
      00714E 73                    1075 	.db	00181$>>8
      00714F 73                    1076 	.db	00181$>>8
      007150 73                    1077 	.db	00181$>>8
      007151 72                    1078 	.db	00131$>>8
      007152 73                    1079 	.db	00147$>>8
      007153 73                    1080 	.db	00152$>>8
      007154 73                    1081 	.db	00152$>>8
                                   1082 ;	quantum/action.c:528: case ACT_RMODS: {
      007155                       1083 00102$:
                                   1084 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007155 90 08 27         [24] 1085 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007158 E0               [24] 1086 	movx	a,@dptr
      007159 54 F0            [12] 1087 	anl	a,#0xf0
      00715B 70 06            [24] 1088 	jnz	00194$
      00715D 12 75 B5         [24] 1089 	lcall	_ak820_outline_0108
      007160 FD               [12] 1090 	mov	r5,a
      007161 80 07            [24] 1091 	sjmp	00195$
      007163                       1092 00194$:
      007163 12 75 B5         [24] 1093 	lcall	_ak820_outline_0108
      007166 C4               [12] 1094 	swap	a
      007167 54 F0            [12] 1095 	anl	a,#0xf0
      007169 FD               [12] 1096 	mov	r5,a
      00716A                       1097 00195$:
                                   1098 ;	quantum/action.c:531: if (pressed) {
      00716A E5 18            [12] 1099 	mov	a,_process_action_sloc0_1_0
      00716C 60 35            [24] 1100 	jz	00119$
                                   1101 ;	quantum/action.c:532: if (mods) {
      00716E ED               [12] 1102 	mov	a,r5
      00716F 60 29            [24] 1103 	jz	00110$
                                   1104 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007171 12 75 C7         [24] 1105 	lcall	_ak820_outline_0153
      007174 FC               [12] 1106 	mov	r4,a
      007175 BC E0 00         [24] 1107 	cjne	r4,#0xe0,00440$
      007178                       1108 00440$:
      007178 40 07            [24] 1109 	jc	00108$
      00717A 12 75 C7         [24] 1110 	lcall	_ak820_outline_0153
      00717D 24 18            [12] 1111 	add	a,#0xff - 0xe7
      00717F 50 0A            [24] 1112 	jnc	00104$
                                   1113 ;	free result
      007181                       1114 00108$:
      007181 7B 26            [12] 1115 	mov	r3,#_process_action_PARM_2
      007183 7C 08            [12] 1116 	mov	r4,#(_process_action_PARM_2 >> 8)
      007185 12 33 FC         [24] 1117 	lcall	_ak820_outline_0120
      007188 E0               [24] 1118 	movx	a,@dptr
      007189 70 07            [24] 1119 	jnz	00105$
      00718B                       1120 00104$:
                                   1121 ;	quantum/action.c:537: add_owned_mods(mods);
      00718B 8D 82            [24] 1122 	mov	dpl, r5
      00718D 12 7B 2D         [24] 1123 	lcall	_add_owned_mods
      007190 80 05            [24] 1124 	sjmp	00106$
      007192                       1125 00105$:
                                   1126 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007192 8D 82            [24] 1127 	mov	dpl, r5
      007194 12 7B 4C         [24] 1128 	lcall	_add_owned_weak_mods
      007197                       1129 00106$:
                                   1130 ;	quantum/action.c:541: send_keyboard_report();
      007197 12 7E 67         [24] 1131 	lcall	_send_keyboard_report
      00719A                       1132 00110$:
                                   1133 ;	quantum/action.c:543: register_code(action.key.code);
      00719A 12 75 9E         [24] 1134 	lcall	_ak820_outline_0073
      00719D 12 73 C1         [24] 1135 	lcall	_register_code
      0071A0 02 73 AA         [24] 1136 	ljmp	00181$
      0071A3                       1137 00119$:
                                   1138 ;	quantum/action.c:545: unregister_code(action.key.code);
      0071A3 12 75 9E         [24] 1139 	lcall	_ak820_outline_0073
      0071A6 C0 05            [24] 1140 	push	ar5
      0071A8 12 74 2E         [24] 1141 	lcall	_unregister_code
      0071AB D0 05            [24] 1142 	pop	ar5
                                   1143 ;	quantum/action.c:546: if (mods) {
      0071AD ED               [12] 1144 	mov	a,r5
      0071AE 70 03            [24] 1145 	jnz	00444$
      0071B0 02 73 AA         [24] 1146 	ljmp	00181$
      0071B3                       1147 00444$:
                                   1148 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0071B3 12 75 C7         [24] 1149 	lcall	_ak820_outline_0153
      0071B6 FC               [12] 1150 	mov	r4,a
      0071B7 BC E0 00         [24] 1151 	cjne	r4,#0xe0,00445$
      0071BA                       1152 00445$:
      0071BA 40 07            [24] 1153 	jc	00115$
      0071BC 12 75 C7         [24] 1154 	lcall	_ak820_outline_0153
      0071BF 24 18            [12] 1155 	add	a,#0xff - 0xe7
      0071C1 50 0A            [24] 1156 	jnc	00111$
                                   1157 ;	free result
      0071C3                       1158 00115$:
      0071C3 7B 26            [12] 1159 	mov	r3,#_process_action_PARM_2
      0071C5 7C 08            [12] 1160 	mov	r4,#(_process_action_PARM_2 >> 8)
      0071C7 12 33 FC         [24] 1161 	lcall	_ak820_outline_0120
      0071CA E0               [24] 1162 	movx	a,@dptr
      0071CB 70 07            [24] 1163 	jnz	00112$
      0071CD                       1164 00111$:
                                   1165 ;	quantum/action.c:548: del_owned_mods(mods);
      0071CD 8D 82            [24] 1166 	mov	dpl, r5
      0071CF 12 7B 3D         [24] 1167 	lcall	_del_owned_mods
      0071D2 80 05            [24] 1168 	sjmp	00113$
      0071D4                       1169 00112$:
                                   1170 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      0071D4 8D 82            [24] 1171 	mov	dpl, r5
      0071D6 12 7B 5C         [24] 1172 	lcall	_del_owned_weak_mods
      0071D9                       1173 00113$:
                                   1174 ;	quantum/action.c:552: send_keyboard_report();
      0071D9 12 7E 67         [24] 1175 	lcall	_send_keyboard_report
                                   1176 ;	quantum/action.c:555: } break;
      0071DC 02 73 AA         [24] 1177 	ljmp	00181$
                                   1178 ;	quantum/action.c:632: case ACT_USAGE:
      0071DF                       1179 00123$:
                                   1180 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0071DF 74 07            [12] 1181 	mov	a,#0x07
      0071E1 12 37 E9         [24] 1182 	lcall	_ak820_outline_0019
      0071E4 12 37 CD         [24] 1183 	lcall	_ak820_outline_0009
      0071E7 C3               [12] 1184 	clr	c
      0071E8 EC               [12] 1185 	mov	a,r4
      0071E9 94 A5            [12] 1186 	subb	a,#0xa5
      0071EB ED               [12] 1187 	mov	a,r5
      0071EC 94 00            [12] 1188 	subb	a,#0x00
      0071EE 40 15            [24] 1189 	jc	00125$
      0071F0 74 C2            [12] 1190 	mov	a,#0xc2
      0071F2 9C               [12] 1191 	subb	a,r4
      0071F3 E4               [12] 1192 	clr	a
      0071F4 9D               [12] 1193 	subb	a,r5
      0071F5 40 0E            [24] 1194 	jc	00125$
                                   1195 ;	free result
                                   1196 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0071F7 90 0A 86         [24] 1197 	mov	dptr,#_owned_usage_key_PARM_2
      0071FA E5 18            [12] 1198 	mov	a,_process_action_sloc0_1_0
      0071FC F0               [24] 1199 	movx	@dptr,a
      0071FD 8E 82            [24] 1200 	mov	dpl, r6
      0071FF 12 7D 12         [24] 1201 	lcall	_owned_usage_key
                                   1202 ;	quantum/action.c:640: break;
      007202 02 73 AA         [24] 1203 	ljmp	00181$
      007205                       1204 00125$:
                                   1205 ;	quantum/action.c:643: switch (action.usage.page) {
      007205 12 75 A5         [24] 1206 	lcall	_ak820_outline_0084
      007208 FF               [12] 1207 	mov	r7,a
      007209 60 08            [24] 1208 	jz	00127$
      00720B BF 01 02         [24] 1209 	cjne	r7,#0x01,00452$
      00720E 80 19            [24] 1210 	sjmp	00128$
      007210                       1211 00452$:
      007210 02 73 AA         [24] 1212 	ljmp	00181$
                                   1213 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007213                       1214 00127$:
                                   1215 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007213 E5 18            [12] 1216 	mov	a,_process_action_sloc0_1_0
      007215 60 05            [24] 1217 	jz	00196$
      007217 12 75 BC         [24] 1218 	lcall	_ak820_outline_0127
      00721A 80 04            [24] 1219 	sjmp	00197$
      00721C                       1220 00196$:
      00721C 7E 00            [12] 1221 	mov	r6,#0x00
      00721E 7F 00            [12] 1222 	mov	r7,#0x00
      007220                       1223 00197$:
      007220 12 43 1F         [24] 1224 	lcall	_ak820_outline_0116
      007223 12 6C 0C         [24] 1225 	lcall	_host_system_send
                                   1226 ;	quantum/action.c:646: break;
      007226 02 73 AA         [24] 1227 	ljmp	00181$
                                   1228 ;	quantum/action.c:647: case PAGE_CONSUMER:
      007229                       1229 00128$:
                                   1230 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      007229 E5 18            [12] 1231 	mov	a,_process_action_sloc0_1_0
      00722B 60 05            [24] 1232 	jz	00198$
      00722D 12 75 BC         [24] 1233 	lcall	_ak820_outline_0127
      007230 80 04            [24] 1234 	sjmp	00199$
      007232                       1235 00198$:
      007232 7E 00            [12] 1236 	mov	r6,#0x00
      007234 7F 00            [12] 1237 	mov	r7,#0x00
      007236                       1238 00199$:
      007236 12 43 1F         [24] 1239 	lcall	_ak820_outline_0116
      007239 12 6C 3C         [24] 1240 	lcall	_host_consumer_send
                                   1241 ;	quantum/action.c:651: break;
      00723C 02 73 AA         [24] 1242 	ljmp	00181$
                                   1243 ;	quantum/action.c:658: case ACT_LAYER: {
      00723F                       1244 00131$:
                                   1245 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      00723F 90 08 27         [24] 1246 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007242 E0               [24] 1247 	movx	a,@dptr
      007243 54 03            [12] 1248 	anl	a,#0x03
      007245 90 08 2A         [24] 1249 	mov	dptr,#_process_action_on_40000_675
      007248 F0               [24] 1250 	movx	@dptr,a
                                   1251 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007249 E0               [24] 1252 	movx	a,@dptr
      00724A FF               [12] 1253 	mov	r7,a
      00724B 60 11            [24] 1254 	jz	00200$
      00724D E5 18            [12] 1255 	mov	a,_process_action_sloc0_1_0
      00724F 60 07            [24] 1256 	jz	00202$
      007251 8F 06            [24] 1257 	mov	ar6,r7
      007253 53 06 01         [24] 1258 	anl	ar6,#0x01
      007256 80 10            [24] 1259 	sjmp	00201$
      007258                       1260 00202$:
      007258 74 02            [12] 1261 	mov	a,#0x02
      00725A 5F               [12] 1262 	anl	a,r7
      00725B FE               [12] 1263 	mov	r6,a
      00725C 80 0A            [24] 1264 	sjmp	00201$
      00725E                       1265 00200$:
      00725E E5 18            [12] 1266 	mov	a,_process_action_sloc0_1_0
      007260 B4 01 00         [24] 1267 	cjne	a,#0x01,00457$
      007263                       1268 00457$:
      007263 92 1D            [24] 1269 	mov  _process_action_sloc1_1_0,c
      007265 E4               [12] 1270 	clr	a
      007266 33               [12] 1271 	rlc	a
      007267 FE               [12] 1272 	mov	r6,a
      007268                       1273 00201$:
      007268 EE               [12] 1274 	mov	a,r6
      007269 70 03            [24] 1275 	jnz	00458$
      00726B 02 73 AA         [24] 1276 	ljmp	00181$
      00726E                       1277 00458$:
                                   1278 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      00726E 12 75 C7         [24] 1279 	lcall	_ak820_outline_0153
      007271 C4               [12] 1280 	swap	a
      007272 03               [12] 1281 	rr	a
      007273 54 07            [12] 1282 	anl	a,#0x07
      007275 25 E0            [12] 1283 	add	a,acc
      007277 25 E0            [12] 1284 	add	a,acc
      007279 FF               [12] 1285 	mov	r7,a
                                   1286 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00727A 12 75 C7         [24] 1287 	lcall	_ak820_outline_0153
      00727D 54 0F            [12] 1288 	anl	a,#0x0f
      00727F FE               [12] 1289 	mov	r6,a
      007280 8F F0            [24] 1290 	mov	b,r7
      007282 05 F0            [12] 1291 	inc	b
      007284 EE               [12] 1292 	mov	a,r6
      007285 80 02            [24] 1293 	sjmp	00460$
      007287                       1294 00459$:
      007287 25 E0            [12] 1295 	add	a,acc
      007289                       1296 00460$:
      007289 D5 F0 FB         [24] 1297 	djnz	b,00459$
      00728C FE               [12] 1298 	mov	r6,a
                                   1299 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00728D 12 75 C7         [24] 1300 	lcall	_ak820_outline_0153
      007290 30 E4 11         [24] 1301 	jnb	acc.4,00204$
      007293 8F F0            [24] 1302 	mov	b,r7
      007295 05 F0            [12] 1303 	inc	b
      007297 74 0F            [12] 1304 	mov	a,#0x0f
      007299 80 02            [24] 1305 	sjmp	00463$
      00729B                       1306 00462$:
      00729B 25 E0            [12] 1307 	add	a,acc
      00729D                       1308 00463$:
      00729D D5 F0 FB         [24] 1309 	djnz	b,00462$
      0072A0 F4               [12] 1310 	cpl	a
      0072A1 FF               [12] 1311 	mov	r7,a
      0072A2 80 02            [24] 1312 	sjmp	00205$
      0072A4                       1313 00204$:
      0072A4 7F 00            [12] 1314 	mov	r7,#0x00
      0072A6                       1315 00205$:
                                   1316 ;	quantum/action.c:666: bits |= mask;
      0072A6 EE               [12] 1317 	mov	a,r6
      0072A7 42 07            [12] 1318 	orl	ar7,a
                                   1319 ;	quantum/action.c:667: if (!on) {
      0072A9 90 08 2A         [24] 1320 	mov	dptr,#_process_action_on_40000_675
      0072AC E0               [24] 1321 	movx	a,@dptr
      0072AD 70 31            [24] 1322 	jnz	00143$
                                   1323 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      0072AF 12 75 A5         [24] 1324 	lcall	_ak820_outline_0084
      0072B2 FE               [12] 1325 	mov	r6,a
      0072B3 2E               [12] 1326 	add	a,r6
                                   1327 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      0072B4 90 72 B8         [24] 1328 	mov	dptr,#00465$
      0072B7 73               [24] 1329 	jmp	@a+dptr
      0072B8                       1330 00465$:
      0072B8 80 06            [24] 1331 	sjmp	00132$
      0072BA 80 0C            [24] 1332 	sjmp	00133$
      0072BC 80 12            [24] 1333 	sjmp	00134$
      0072BE 80 18            [24] 1334 	sjmp	00135$
      0072C0                       1335 00132$:
      0072C0 8F 82            [24] 1336 	mov	dpl, r7
      0072C2 12 76 22         [24] 1337 	lcall	_default_layer_and
      0072C5 02 73 AA         [24] 1338 	ljmp	00181$
                                   1339 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      0072C8                       1340 00133$:
      0072C8 8F 82            [24] 1341 	mov	dpl, r7
      0072CA 12 76 11         [24] 1342 	lcall	_default_layer_or
      0072CD 02 73 AA         [24] 1343 	ljmp	00181$
                                   1344 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      0072D0                       1345 00134$:
      0072D0 8F 82            [24] 1346 	mov	dpl, r7
      0072D2 12 76 38         [24] 1347 	lcall	_default_layer_xor
      0072D5 02 73 AA         [24] 1348 	ljmp	00181$
                                   1349 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0072D8                       1350 00135$:
      0072D8 8F 82            [24] 1351 	mov	dpl, r7
      0072DA 12 76 06         [24] 1352 	lcall	_default_layer_set
                                   1353 ;	quantum/action.c:673: }
      0072DD 02 73 AA         [24] 1354 	ljmp	00181$
      0072E0                       1355 00143$:
                                   1356 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      0072E0 12 75 A5         [24] 1357 	lcall	_ak820_outline_0084
      0072E3 FE               [12] 1358 	mov	r6,a
      0072E4 2E               [12] 1359 	add	a,r6
                                   1360 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0072E5 90 72 E9         [24] 1361 	mov	dptr,#00466$
      0072E8 73               [24] 1362 	jmp	@a+dptr
      0072E9                       1363 00466$:
      0072E9 80 06            [24] 1364 	sjmp	00137$
      0072EB 80 0C            [24] 1365 	sjmp	00138$
      0072ED 80 12            [24] 1366 	sjmp	00139$
      0072EF 80 18            [24] 1367 	sjmp	00140$
      0072F1                       1368 00137$:
      0072F1 8F 82            [24] 1369 	mov	dpl, r7
      0072F3 12 77 BB         [24] 1370 	lcall	_layer_and
      0072F6 02 73 AA         [24] 1371 	ljmp	00181$
                                   1372 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0072F9                       1373 00138$:
      0072F9 8F 82            [24] 1374 	mov	dpl, r7
      0072FB 12 77 AA         [24] 1375 	lcall	_layer_or
      0072FE 02 73 AA         [24] 1376 	ljmp	00181$
                                   1377 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007301                       1378 00139$:
      007301 8F 82            [24] 1379 	mov	dpl, r7
      007303 12 77 D1         [24] 1380 	lcall	_layer_xor
      007306 02 73 AA         [24] 1381 	ljmp	00181$
                                   1382 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      007309                       1383 00140$:
      007309 8F 82            [24] 1384 	mov	dpl, r7
      00730B 12 77 47         [24] 1385 	lcall	_layer_state_set
                                   1386 ;	quantum/action.c:683: break;
      00730E 02 73 AA         [24] 1387 	ljmp	00181$
                                   1388 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007311                       1389 00147$:
                                   1390 ;	quantum/action.c:686: if (pressed) {
      007311 E5 18            [12] 1391 	mov	a,_process_action_sloc0_1_0
      007313 60 11            [24] 1392 	jz	00149$
                                   1393 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      007315 12 75 B5         [24] 1394 	lcall	_ak820_outline_0108
      007318 F5 82            [12] 1395 	mov	dpl,a
      00731A 12 76 A8         [24] 1396 	lcall	_layer_hold_on
                                   1397 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      00731D 12 75 9E         [24] 1398 	lcall	_ak820_outline_0073
      007320 12 74 E4         [24] 1399 	lcall	_register_mods
      007323 02 73 AA         [24] 1400 	ljmp	00181$
      007326                       1401 00149$:
                                   1402 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      007326 12 75 9E         [24] 1403 	lcall	_ak820_outline_0073
      007329 12 74 F8         [24] 1404 	lcall	_unregister_mods
                                   1405 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      00732C 12 75 B5         [24] 1406 	lcall	_ak820_outline_0108
      00732F F5 82            [12] 1407 	mov	dpl,a
      007331 12 76 E0         [24] 1408 	lcall	_layer_hold_off
                                   1409 ;	quantum/action.c:693: break;
      007334 02 73 AA         [24] 1410 	ljmp	00181$
                                   1411 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      007337                       1412 00152$:
                                   1413 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      007337 12 75 C7         [24] 1414 	lcall	_ak820_outline_0153
      00733A FF               [12] 1415 	mov	r7,a
      00733B BF F1 02         [24] 1416 	cjne	r7,#0xf1,00468$
      00733E 80 0A            [24] 1417 	sjmp	00154$
      007340                       1418 00468$:
      007340 BF F2 02         [24] 1419 	cjne	r7,#0xf2,00469$
      007343 80 19            [24] 1420 	sjmp	00155$
      007345                       1421 00469$:
                                   1422 ;	quantum/action.c:712: momentary_layer_action:
      007345 BF F3 3B         [24] 1423 	cjne	r7,#0xf3,00160$
      007348 80 28            [24] 1424 	sjmp	00156$
      00734A                       1425 00154$:
                                   1426 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00734A E5 18            [12] 1427 	mov	a,_process_action_sloc0_1_0
      00734C 60 08            [24] 1428 	jz	00206$
      00734E 12 75 85         [24] 1429 	lcall	_ak820_outline_0037
      007351 12 76 A8         [24] 1430 	lcall	_layer_hold_on
      007354 80 54            [24] 1431 	sjmp	00181$
      007356                       1432 00206$:
      007356 12 75 85         [24] 1433 	lcall	_ak820_outline_0037
      007359 12 76 E0         [24] 1434 	lcall	_layer_hold_off
                                   1435 ;	quantum/action.c:714: break;
                                   1436 ;	quantum/action.c:715: case OP_OFF_ON:
      00735C 80 4C            [24] 1437 	sjmp	00181$
      00735E                       1438 00155$:
                                   1439 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00735E E5 18            [12] 1440 	mov	a,_process_action_sloc0_1_0
      007360 60 08            [24] 1441 	jz	00208$
      007362 12 75 85         [24] 1442 	lcall	_ak820_outline_0037
      007365 12 77 8C         [24] 1443 	lcall	_layer_off
      007368 80 40            [24] 1444 	sjmp	00181$
      00736A                       1445 00208$:
      00736A 12 75 85         [24] 1446 	lcall	_ak820_outline_0037
      00736D 12 77 71         [24] 1447 	lcall	_layer_on
                                   1448 ;	quantum/action.c:717: break;
                                   1449 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007370 80 38            [24] 1450 	sjmp	00181$
      007372                       1451 00156$:
                                   1452 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007372 E5 18            [12] 1453 	mov	a,_process_action_sloc0_1_0
      007374 60 08            [24] 1454 	jz	00210$
      007376 12 75 85         [24] 1455 	lcall	_ak820_outline_0037
      007379 12 77 5B         [24] 1456 	lcall	_layer_move
      00737C 80 2C            [24] 1457 	sjmp	00181$
      00737E                       1458 00210$:
      00737E 12 77 55         [24] 1459 	lcall	_layer_clear
                                   1460 ;	quantum/action.c:720: break;
                                   1461 ;	quantum/action.c:766: default:
      007381 80 27            [24] 1462 	sjmp	00181$
      007383                       1463 00160$:
                                   1464 ;	quantum/action.c:773: if (pressed) {
      007383 E5 18            [12] 1465 	mov	a,_process_action_sloc0_1_0
      007385 60 08            [24] 1466 	jz	00163$
                                   1467 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007387 12 75 9E         [24] 1468 	lcall	_ak820_outline_0073
      00738A 12 73 C1         [24] 1469 	lcall	_register_code
                                   1470 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00738D 80 1B            [24] 1471 	sjmp	00181$
      00738F                       1472 00163$:
                                   1473 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      00738F 12 75 C7         [24] 1474 	lcall	_ak820_outline_0153
      007392 FF               [12] 1475 	mov	r7,a
      007393 BF 39 0E         [24] 1476 	cjne	r7,#0x39,00175$
                                   1477 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007396 7F 50            [12] 1478 	mov	r7,#0x50
      007398                       1479 00187$:
      007398 EF               [12] 1480 	mov	a,r7
      007399 60 09            [24] 1481 	jz	00175$
      00739B 90 00 01         [24] 1482 	mov	dptr,#0x0001
      00739E 12 57 E6         [24] 1483 	lcall	_mDelaymS
      0073A1 1F               [12] 1484 	dec	r7
                                   1485 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      0073A2 80 F4            [24] 1486 	sjmp	00187$
      0073A4                       1487 00175$:
                                   1488 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      0073A4 12 75 9E         [24] 1489 	lcall	_ak820_outline_0073
      0073A7 12 74 2E         [24] 1490 	lcall	_unregister_code
                                   1491 ;	quantum/action.c:866: }
      0073AA                       1492 00181$:
                                   1493 ;	quantum/action.c:887: switch (action.kind.id) {
      0073AA 90 08 27         [24] 1494 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073AD E0               [24] 1495 	movx	a,@dptr
      0073AE C4               [12] 1496 	swap	a
      0073AF 54 0F            [12] 1497 	anl	a,#0x0f
      0073B1 FF               [12] 1498 	mov	r7,a
      0073B2 BF 08 02         [24] 1499 	cjne	r7,#0x08,00478$
      0073B5 80 03            [24] 1500 	sjmp	00183$
      0073B7                       1501 00478$:
      0073B7 BF 09 06         [24] 1502 	cjne	r7,#0x09,00192$
                                   1503 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      0073BA                       1504 00183$:
                                   1505 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      0073BA 12 6B 71         [24] 1506 	lcall	_host_keyboard_leds
                                   1507 ;	quantum/action.c:898: }
                                   1508 ;	quantum/action.c:951: }
      0073BD 02 95 C8         [24] 1509 	ljmp	_led_set
      0073C0                       1510 00192$:
      0073C0 22               [24] 1511 	ret
                                   1512 ;------------------------------------------------------------
                                   1513 ;Allocation info for local variables in function 'register_code'
                                   1514 ;------------------------------------------------------------
                                   1515 ;code          Allocated with name '_register_code_code_10000_709'
                                   1516 ;------------------------------------------------------------
                                   1517 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1518 ;	-----------------------------------------
                                   1519 ;	 function register_code
                                   1520 ;	-----------------------------------------
      0073C1                       1521 _register_code:
      0073C1 E5 82            [12] 1522 	mov	a,dpl
      0073C3 90 08 2B         [24] 1523 	mov	dptr,#_register_code_code_10000_709
      0073C6 F0               [24] 1524 	movx	@dptr,a
                                   1525 ;	quantum/action.c:958: if (code == KC_NO) {
      0073C7 E0               [24] 1526 	movx	a,@dptr
      0073C8 FF               [12] 1527 	mov	r7,a
      0073C9 70 01            [24] 1528 	jnz	00123$
                                   1529 ;	quantum/action.c:959: return;
      0073CB 22               [24] 1530 	ret
      0073CC                       1531 00123$:
                                   1532 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      0073CC BF 04 00         [24] 1533 	cjne	r7,#0x04,00186$
      0073CF                       1534 00186$:
      0073CF 40 12            [24] 1535 	jc	00119$
      0073D1 EF               [12] 1536 	mov	a,r7
      0073D2 24 5B            [12] 1537 	add	a,#0xff - 0xa4
      0073D4 40 0D            [24] 1538 	jc	00119$
                                   1539 ;	free result
                                   1540 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      0073D6 8F 82            [24] 1541 	mov	dpl, r7
      0073D8 12 7B D1         [24] 1542 	lcall	_add_owned_key
      0073DB E5 82            [12] 1543 	mov	a, dpl
      0073DD 70 01            [24] 1544 	jnz	00104$
      0073DF 22               [24] 1545 	ret
      0073E0                       1546 00104$:
                                   1547 ;	quantum/action.c:1013: send_keyboard_report();
      0073E0 02 7E 67         [24] 1548 	ljmp	_send_keyboard_report
      0073E3                       1549 00119$:
                                   1550 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      0073E3 12 75 CC         [24] 1551 	lcall	_ak820_outline_0161
      0073E6 BF E0 00         [24] 1552 	cjne	r7,#0xe0,00190$
      0073E9                       1553 00190$:
      0073E9 40 1A            [24] 1554 	jc	00115$
      0073EB EF               [12] 1555 	mov	a,r7
      0073EC 24 18            [12] 1556 	add	a,#0xff - 0xe7
      0073EE 40 15            [24] 1557 	jc	00115$
                                   1558 ;	free result
                                   1559 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0073F0 74 07            [12] 1560 	mov	a,#0x07
      0073F2 5F               [12] 1561 	anl	a,r7
      0073F3 12 75 97         [24] 1562 	lcall	_ak820_outline_0060
      0073F6 80 02            [24] 1563 	sjmp	00194$
      0073F8                       1564 00193$:
      0073F8 25 E0            [12] 1565 	add	a,acc
      0073FA                       1566 00194$:
      0073FA D5 F0 FB         [24] 1567 	djnz	b,00193$
      0073FD F5 82            [12] 1568 	mov	dpl,a
      0073FF 12 7B 2D         [24] 1569 	lcall	_add_owned_mods
                                   1570 ;	quantum/action.c:1016: send_keyboard_report();
      007402 02 7E 67         [24] 1571 	ljmp	_send_keyboard_report
      007405                       1572 00115$:
                                   1573 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007405 12 75 CC         [24] 1574 	lcall	_ak820_outline_0161
      007408 BF A5 00         [24] 1575 	cjne	r7,#0xa5,00195$
      00740B                       1576 00195$:
      00740B 40 05            [24] 1577 	jc	00113$
      00740D EF               [12] 1578 	mov	a,r7
      00740E 24 58            [12] 1579 	add	a,#0xff - 0xa7
      007410 50 0D            [24] 1580 	jnc	00108$
                                   1581 ;	free result
      007412                       1582 00113$:
      007412 12 75 CC         [24] 1583 	lcall	_ak820_outline_0161
      007415 BF A8 00         [24] 1584 	cjne	r7,#0xa8,00198$
      007418                       1585 00198$:
      007418 40 13            [24] 1586 	jc	00125$
      00741A EF               [12] 1587 	mov	a,r7
      00741B 24 3D            [12] 1588 	add	a,#0xff - 0xc2
      00741D 40 0E            [24] 1589 	jc	00125$
                                   1590 ;	free result
      00741F                       1591 00108$:
                                   1592 ;	quantum/action.c:1021: owned_usage_key(code, true);
      00741F 12 75 CC         [24] 1593 	lcall	_ak820_outline_0161
      007422 90 0A 86         [24] 1594 	mov	dptr,#_owned_usage_key_PARM_2
      007425 74 01            [12] 1595 	mov	a,#0x01
      007427 F0               [24] 1596 	movx	@dptr,a
      007428 8F 82            [24] 1597 	mov	dpl, r7
                                   1598 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1599 ;	quantum/action.c:1031: }
      00742A 02 7D 12         [24] 1600 	ljmp	_owned_usage_key
      00742D                       1601 00125$:
      00742D 22               [24] 1602 	ret
                                   1603 ;------------------------------------------------------------
                                   1604 ;Allocation info for local variables in function 'unregister_code'
                                   1605 ;------------------------------------------------------------
                                   1606 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1607 ;------------------------------------------------------------
                                   1608 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1609 ;	-----------------------------------------
                                   1610 ;	 function unregister_code
                                   1611 ;	-----------------------------------------
      00742E                       1612 _unregister_code:
      00742E E5 82            [12] 1613 	mov	a,dpl
      007430 90 08 2C         [24] 1614 	mov	dptr,#_unregister_code_code_10000_723
      007433 F0               [24] 1615 	movx	@dptr,a
                                   1616 ;	quantum/action.c:1038: if (code == KC_NO) {
      007434 E0               [24] 1617 	movx	a,@dptr
      007435 FF               [12] 1618 	mov	r7,a
      007436 70 01            [24] 1619 	jnz	00121$
                                   1620 ;	quantum/action.c:1039: return;
      007438 22               [24] 1621 	ret
      007439                       1622 00121$:
                                   1623 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007439 BF 04 00         [24] 1624 	cjne	r7,#0x04,00184$
      00743C                       1625 00184$:
      00743C 40 12            [24] 1626 	jc	00117$
      00743E EF               [12] 1627 	mov	a,r7
      00743F 24 5B            [12] 1628 	add	a,#0xff - 0xa4
      007441 40 0D            [24] 1629 	jc	00117$
                                   1630 ;	free result
                                   1631 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007443 8F 82            [24] 1632 	mov	dpl, r7
      007445 12 7C 4B         [24] 1633 	lcall	_del_owned_key
      007448 E5 82            [12] 1634 	mov	a, dpl
      00744A 70 01            [24] 1635 	jnz	00102$
      00744C 22               [24] 1636 	ret
      00744D                       1637 00102$:
                                   1638 ;	quantum/action.c:1080: send_keyboard_report();
      00744D 02 7E 67         [24] 1639 	ljmp	_send_keyboard_report
      007450                       1640 00117$:
                                   1641 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007450 12 75 D2         [24] 1642 	lcall	_ak820_outline_0162
      007453 BF E0 00         [24] 1643 	cjne	r7,#0xe0,00188$
      007456                       1644 00188$:
      007456 40 1A            [24] 1645 	jc	00113$
      007458 EF               [12] 1646 	mov	a,r7
      007459 24 18            [12] 1647 	add	a,#0xff - 0xe7
      00745B 40 15            [24] 1648 	jc	00113$
                                   1649 ;	free result
                                   1650 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      00745D 74 07            [12] 1651 	mov	a,#0x07
      00745F 5F               [12] 1652 	anl	a,r7
      007460 12 75 97         [24] 1653 	lcall	_ak820_outline_0060
      007463 80 02            [24] 1654 	sjmp	00192$
      007465                       1655 00191$:
      007465 25 E0            [12] 1656 	add	a,acc
      007467                       1657 00192$:
      007467 D5 F0 FB         [24] 1658 	djnz	b,00191$
      00746A F5 82            [12] 1659 	mov	dpl,a
      00746C 12 7B 3D         [24] 1660 	lcall	_del_owned_mods
                                   1661 ;	quantum/action.c:1083: send_keyboard_report();
      00746F 02 7E 67         [24] 1662 	ljmp	_send_keyboard_report
      007472                       1663 00113$:
                                   1664 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007472 12 75 D2         [24] 1665 	lcall	_ak820_outline_0162
      007475 BF A5 00         [24] 1666 	cjne	r7,#0xa5,00193$
      007478                       1667 00193$:
      007478 40 05            [24] 1668 	jc	00111$
      00747A EF               [12] 1669 	mov	a,r7
      00747B 24 58            [12] 1670 	add	a,#0xff - 0xa7
      00747D 50 0D            [24] 1671 	jnc	00106$
                                   1672 ;	free result
      00747F                       1673 00111$:
      00747F 12 75 D2         [24] 1674 	lcall	_ak820_outline_0162
      007482 BF A8 00         [24] 1675 	cjne	r7,#0xa8,00196$
      007485                       1676 00196$:
      007485 40 12            [24] 1677 	jc	00123$
      007487 EF               [12] 1678 	mov	a,r7
      007488 24 3D            [12] 1679 	add	a,#0xff - 0xc2
      00748A 40 0D            [24] 1680 	jc	00123$
                                   1681 ;	free result
      00748C                       1682 00106$:
                                   1683 ;	quantum/action.c:1088: owned_usage_key(code, false);
      00748C 12 75 D2         [24] 1684 	lcall	_ak820_outline_0162
      00748F 90 0A 86         [24] 1685 	mov	dptr,#_owned_usage_key_PARM_2
      007492 E4               [12] 1686 	clr	a
      007493 F0               [24] 1687 	movx	@dptr,a
      007494 8F 82            [24] 1688 	mov	dpl, r7
                                   1689 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1690 ;	quantum/action.c:1098: }
      007496 02 7D 12         [24] 1691 	ljmp	_owned_usage_key
      007499                       1692 00123$:
      007499 22               [24] 1693 	ret
                                   1694 ;------------------------------------------------------------
                                   1695 ;Allocation info for local variables in function 'tap_code_delay'
                                   1696 ;------------------------------------------------------------
                                   1697 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1698 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1699 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1700 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1701 ;------------------------------------------------------------
                                   1702 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1703 ;	-----------------------------------------
                                   1704 ;	 function tap_code_delay
                                   1705 ;	-----------------------------------------
      00749A                       1706 _tap_code_delay:
      00749A E5 82            [12] 1707 	mov	a,dpl
      00749C 90 08 2F         [24] 1708 	mov	dptr,#_tap_code_delay_code_10000_736
      00749F F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	quantum/action.c:1106: register_code(code);
      0074A0 E0               [24] 1711 	movx	a,@dptr
      0074A1 FF               [12] 1712 	mov	r7,a
      0074A2 F5 82            [12] 1713 	mov	dpl,a
      0074A4 C0 07            [24] 1714 	push	ar7
      0074A6 12 73 C1         [24] 1715 	lcall	_register_code
      0074A9 D0 07            [24] 1716 	pop	ar7
                                   1717 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0074AB 90 08 2D         [24] 1718 	mov	dptr,#_tap_code_delay_PARM_2
      0074AE 12 43 0D         [24] 1719 	lcall	_ak820_outline_0090
      0074B1                       1720 00110$:
      0074B1 ED               [12] 1721 	mov	a,r5
      0074B2 4E               [12] 1722 	orl	a,r6
      0074B3 60 0D            [24] 1723 	jz	00105$
                                   1724 ;	quantum/action.c:1108: wait_ms(1);
      0074B5 90 00 01         [24] 1725 	mov	dptr,#0x0001
      0074B8 12 57 E6         [24] 1726 	lcall	_mDelaymS
                                   1727 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0074BB 1D               [12] 1728 	dec	r5
      0074BC BD FF 01         [24] 1729 	cjne	r5,#0xff,00141$
      0074BF 1E               [12] 1730 	dec	r6
      0074C0                       1731 00141$:
      0074C0 80 EF            [24] 1732 	sjmp	00110$
      0074C2                       1733 00105$:
                                   1734 ;	quantum/action.c:1110: unregister_code(code);
      0074C2 8F 82            [24] 1735 	mov	dpl, r7
                                   1736 ;	quantum/action.c:1111: }
      0074C4 02 74 2E         [24] 1737 	ljmp	_unregister_code
                                   1738 ;------------------------------------------------------------
                                   1739 ;Allocation info for local variables in function 'tap_code'
                                   1740 ;------------------------------------------------------------
                                   1741 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1742 ;------------------------------------------------------------
                                   1743 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1744 ;	-----------------------------------------
                                   1745 ;	 function tap_code
                                   1746 ;	-----------------------------------------
      0074C7                       1747 _tap_code:
      0074C7 E5 82            [12] 1748 	mov	a,dpl
      0074C9 90 08 30         [24] 1749 	mov	dptr,#_tap_code_code_10000_743
      0074CC F0               [24] 1750 	movx	@dptr,a
                                   1751 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0074CD E0               [24] 1752 	movx	a,@dptr
      0074CE FF               [12] 1753 	mov	r7,a
      0074CF BF 39 04         [24] 1754 	cjne	r7,#0x39,00103$
      0074D2 7E 50            [12] 1755 	mov	r6,#0x50
      0074D4 80 02            [24] 1756 	sjmp	00104$
      0074D6                       1757 00103$:
      0074D6 7E 00            [12] 1758 	mov	r6,#0x00
      0074D8                       1759 00104$:
      0074D8 90 08 2D         [24] 1760 	mov	dptr,#_tap_code_delay_PARM_2
      0074DB EE               [12] 1761 	mov	a,r6
      0074DC 12 38 58         [24] 1762 	lcall	_ak820_outline_0121
      0074DF 8F 82            [24] 1763 	mov	dpl, r7
                                   1764 ;	quantum/action.c:1119: }
      0074E1 02 74 9A         [24] 1765 	ljmp	_tap_code_delay
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'register_mods'
                                   1768 ;------------------------------------------------------------
                                   1769 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1770 ;------------------------------------------------------------
                                   1771 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1772 ;	-----------------------------------------
                                   1773 ;	 function register_mods
                                   1774 ;	-----------------------------------------
      0074E4                       1775 _register_mods:
      0074E4 E5 82            [12] 1776 	mov	a,dpl
      0074E6 90 08 31         [24] 1777 	mov	dptr,#_register_mods_mods_10000_745
      0074E9 F0               [24] 1778 	movx	@dptr,a
                                   1779 ;	quantum/action.c:1126: if (mods) {
      0074EA E0               [24] 1780 	movx	a,@dptr
      0074EB FF               [12] 1781 	mov	r7,a
      0074EC E0               [24] 1782 	movx	a,@dptr
      0074ED 60 08            [24] 1783 	jz	00103$
                                   1784 ;	quantum/action.c:1127: add_owned_mods(mods);
      0074EF 8F 82            [24] 1785 	mov	dpl, r7
      0074F1 12 7B 2D         [24] 1786 	lcall	_add_owned_mods
                                   1787 ;	quantum/action.c:1128: send_keyboard_report();
                                   1788 ;	quantum/action.c:1130: }
      0074F4 02 7E 67         [24] 1789 	ljmp	_send_keyboard_report
      0074F7                       1790 00103$:
      0074F7 22               [24] 1791 	ret
                                   1792 ;------------------------------------------------------------
                                   1793 ;Allocation info for local variables in function 'unregister_mods'
                                   1794 ;------------------------------------------------------------
                                   1795 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1796 ;------------------------------------------------------------
                                   1797 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1798 ;	-----------------------------------------
                                   1799 ;	 function unregister_mods
                                   1800 ;	-----------------------------------------
      0074F8                       1801 _unregister_mods:
      0074F8 E5 82            [12] 1802 	mov	a,dpl
      0074FA 90 08 32         [24] 1803 	mov	dptr,#_unregister_mods_mods_10000_749
      0074FD F0               [24] 1804 	movx	@dptr,a
                                   1805 ;	quantum/action.c:1137: if (mods) {
      0074FE E0               [24] 1806 	movx	a,@dptr
      0074FF FF               [12] 1807 	mov	r7,a
      007500 E0               [24] 1808 	movx	a,@dptr
      007501 60 08            [24] 1809 	jz	00103$
                                   1810 ;	quantum/action.c:1138: del_owned_mods(mods);
      007503 8F 82            [24] 1811 	mov	dpl, r7
      007505 12 7B 3D         [24] 1812 	lcall	_del_owned_mods
                                   1813 ;	quantum/action.c:1139: send_keyboard_report();
                                   1814 ;	quantum/action.c:1141: }
      007508 02 7E 67         [24] 1815 	ljmp	_send_keyboard_report
      00750B                       1816 00103$:
      00750B 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'register_weak_mods'
                                   1820 ;------------------------------------------------------------
                                   1821 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1822 ;------------------------------------------------------------
                                   1823 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1824 ;	-----------------------------------------
                                   1825 ;	 function register_weak_mods
                                   1826 ;	-----------------------------------------
      00750C                       1827 _register_weak_mods:
      00750C E5 82            [12] 1828 	mov	a,dpl
      00750E 90 08 33         [24] 1829 	mov	dptr,#_register_weak_mods_mods_10000_753
      007511 F0               [24] 1830 	movx	@dptr,a
                                   1831 ;	quantum/action.c:1148: if (mods) {
      007512 E0               [24] 1832 	movx	a,@dptr
      007513 FF               [12] 1833 	mov	r7,a
      007514 E0               [24] 1834 	movx	a,@dptr
      007515 60 08            [24] 1835 	jz	00103$
                                   1836 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007517 8F 82            [24] 1837 	mov	dpl, r7
      007519 12 7B 4C         [24] 1838 	lcall	_add_owned_weak_mods
                                   1839 ;	quantum/action.c:1150: send_keyboard_report();
                                   1840 ;	quantum/action.c:1152: }
      00751C 02 7E 67         [24] 1841 	ljmp	_send_keyboard_report
      00751F                       1842 00103$:
      00751F 22               [24] 1843 	ret
                                   1844 ;------------------------------------------------------------
                                   1845 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1846 ;------------------------------------------------------------
                                   1847 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1848 ;------------------------------------------------------------
                                   1849 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1850 ;	-----------------------------------------
                                   1851 ;	 function unregister_weak_mods
                                   1852 ;	-----------------------------------------
      007520                       1853 _unregister_weak_mods:
      007520 E5 82            [12] 1854 	mov	a,dpl
      007522 90 08 34         [24] 1855 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      007525 F0               [24] 1856 	movx	@dptr,a
                                   1857 ;	quantum/action.c:1159: if (mods) {
      007526 E0               [24] 1858 	movx	a,@dptr
      007527 FF               [12] 1859 	mov	r7,a
      007528 E0               [24] 1860 	movx	a,@dptr
      007529 60 08            [24] 1861 	jz	00103$
                                   1862 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      00752B 8F 82            [24] 1863 	mov	dpl, r7
      00752D 12 7B 5C         [24] 1864 	lcall	_del_owned_weak_mods
                                   1865 ;	quantum/action.c:1161: send_keyboard_report();
                                   1866 ;	quantum/action.c:1163: }
      007530 02 7E 67         [24] 1867 	ljmp	_send_keyboard_report
      007533                       1868 00103$:
      007533 22               [24] 1869 	ret
                                   1870 ;------------------------------------------------------------
                                   1871 ;Allocation info for local variables in function 'clear_keyboard'
                                   1872 ;------------------------------------------------------------
                                   1873 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1874 ;	-----------------------------------------
                                   1875 ;	 function clear_keyboard
                                   1876 ;	-----------------------------------------
      007534                       1877 _clear_keyboard:
                                   1878 ;	quantum/action.c:1170: clear_mods();
      007534 12 7E E2         [24] 1879 	lcall	_clear_mods
                                   1880 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1881 ;	quantum/action.c:1172: }
      007537 02 75 3A         [24] 1882 	ljmp	_clear_keyboard_but_mods
                                   1883 ;------------------------------------------------------------
                                   1884 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1885 ;------------------------------------------------------------
                                   1886 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1887 ;	-----------------------------------------
                                   1888 ;	 function clear_keyboard_but_mods
                                   1889 ;	-----------------------------------------
      00753A                       1890 _clear_keyboard_but_mods:
                                   1891 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00753A 90 0D 92         [24] 1892 	mov	dptr,#_actual_keyboard_report
      00753D 12 6E 2F         [24] 1893 	lcall	_clear_keys_from_report
                                   1894 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1895 ;	quantum/action.c:1181: }
      007540 02 75 43         [24] 1896 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function clear_keyboard_but_mods_and_keys
                                   1903 ;	-----------------------------------------
      007543                       1904 _clear_keyboard_but_mods_and_keys:
                                   1905 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007543 12 46 16         [24] 1906 	lcall	_ak820_tapping_cancel
                                   1907 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007546 12 2E F0         [24] 1908 	lcall	_ak820_oneshot_cancel
                                   1909 ;	quantum/action.c:1209: ak820_combo_cancel();
      007549 12 35 28         [24] 1910 	lcall	_ak820_combo_cancel
                                   1911 ;	quantum/action.c:1212: repeat_key_cancel();
      00754C 12 9E B7         [24] 1912 	lcall	_repeat_key_cancel
                                   1913 ;	quantum/action.c:1214: clear_owned_mods();
      00754F 12 7B 6C         [24] 1914 	lcall	_clear_owned_mods
                                   1915 ;	quantum/action.c:1215: clear_owned_keys();
      007552 12 7B A4         [24] 1916 	lcall	_clear_owned_keys
                                   1917 ;	quantum/action.c:1216: clear_owned_usages();
      007555 12 7C DA         [24] 1918 	lcall	_clear_owned_usages
                                   1919 ;	quantum/action.c:1217: layer_hold_clear();
      007558 12 77 18         [24] 1920 	lcall	_layer_hold_clear
                                   1921 ;	quantum/action.c:1219: clear_macro_tri_layer();
      00755B 12 9A 56         [24] 1922 	lcall	_clear_macro_tri_layer
                                   1923 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00755E 90 0D 92         [24] 1924 	mov	dptr,#_actual_keyboard_report
      007561 12 6E 2F         [24] 1925 	lcall	_clear_keys_from_report
                                   1926 ;	quantum/action.c:1224: host_system_send(0);
      007564 90 00 00         [24] 1927 	mov	dptr,#0x0000
      007567 12 6C 0C         [24] 1928 	lcall	_host_system_send
                                   1929 ;	quantum/action.c:1225: host_consumer_send(0);
      00756A 90 00 00         [24] 1930 	mov	dptr,#0x0000
      00756D 12 6C 3C         [24] 1931 	lcall	_host_consumer_send
                                   1932 ;	quantum/action.c:1227: clear_weak_mods();
      007570 12 7F 17         [24] 1933 	lcall	_clear_weak_mods
                                   1934 ;	quantum/action.c:1228: send_keyboard_report();
                                   1935 ;	quantum/action.c:1236: }
      007573 02 7E 67         [24] 1936 	ljmp	_send_keyboard_report
                                   1937 ;------------------------------------------------------------
                                   1938 ;Allocation info for local variables in function 'is_tap_record'
                                   1939 ;------------------------------------------------------------
                                   1940 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1941 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1942 ;------------------------------------------------------------
                                   1943 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1944 ;	-----------------------------------------
                                   1945 	.area CSEG    (CODE)
                                   1946 	.area CONST   (CODE)
                                   1947 	.area XINIT   (CODE)
      00BE28                       1948 __xinit__disable_action_cache:
      00BE28 00                    1949 	.db #0x00	;  0
                                   1950 	.area CABS    (ABS,CODE)
                                   1951 
                                   1952 ; Experimental exact instruction outlining.
                                   1953 	.globl _ak820_outline_0004
                                   1954 	.globl _ak820_outline_0008
                                   1955 	.globl _ak820_outline_0009
                                   1956 	.globl _ak820_outline_0010
                                   1957 	.globl _ak820_outline_0011
                                   1958 	.globl _ak820_outline_0014
                                   1959 	.globl _ak820_outline_0018
                                   1960 	.globl _ak820_outline_0019
                                   1961 	.globl _ak820_outline_0037
                                   1962 	.globl _ak820_outline_0048
                                   1963 	.globl _ak820_outline_0049
                                   1964 	.globl _ak820_outline_0055
                                   1965 	.globl _ak820_outline_0058
                                   1966 	.globl _ak820_outline_0060
                                   1967 	.globl _ak820_outline_0068
                                   1968 	.globl _ak820_outline_0073
                                   1969 	.globl _ak820_outline_0080
                                   1970 	.globl _ak820_outline_0084
                                   1971 	.globl _ak820_outline_0090
                                   1972 	.globl _ak820_outline_0102
                                   1973 	.globl _ak820_outline_0103
                                   1974 	.globl _ak820_outline_0105
                                   1975 	.globl _ak820_outline_0106
                                   1976 	.globl _ak820_outline_0108
                                   1977 	.globl _ak820_outline_0116
                                   1978 	.globl _ak820_outline_0117
                                   1979 	.globl _ak820_outline_0120
                                   1980 	.globl _ak820_outline_0121
                                   1981 	.globl _ak820_outline_0127
                                   1982 	.globl _ak820_outline_0138
                                   1983 	.globl _ak820_outline_0139
                                   1984 	.globl _ak820_outline_0143
                                   1985 	.globl _ak820_outline_0153
                                   1986 	.globl _ak820_outline_0161
                                   1987 	.globl _ak820_outline_0162
                                   1988 	.globl _ak820_outline_0164
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0018
      007576                       1992 _ak820_outline_0018:
      007576 8E 82            [24] 1993 	mov	dpl,r6
      007578 8F 83            [24] 1994 	mov	dph,r7
      00757A A3               [24] 1995 	inc	dptr
      00757B E0               [24] 1996 	movx	a,@dptr
      00757C FC               [12] 1997 	mov	r4,a
      00757D 7D 00            [12] 1998 	mov	r5,#0x00
      00757F 8E 82            [24] 1999 	mov	dpl,r6
      007581 8F 83            [24] 2000 	mov	dph,r7
      007583 E0               [24] 2001 	movx	a,@dptr
      007584 22               [24] 2002 	ret
                                   2003 
                                   2004 	.area CSEG (CODE)
                                   2005 ; function ak820_outline_0037
      007585                       2006 _ak820_outline_0037:
      007585 90 08 27         [24] 2007 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007588 E0               [24] 2008 	movx	a,@dptr
      007589 54 1F            [12] 2009 	anl	a,#0x1f
      00758B F5 82            [12] 2010 	mov	dpl,a
      00758D 22               [24] 2011 	ret
                                   2012 
                                   2013 	.area CSEG (CODE)
                                   2014 ; function ak820_outline_0048
      00758E                       2015 _ak820_outline_0048:
      00758E A3               [24] 2016 	inc	dptr
      00758F F0               [24] 2017 	movx	@dptr,a
      007590 E4               [12] 2018 	clr	a
      007591 A3               [24] 2019 	inc	dptr
      007592 F0               [24] 2020 	movx	@dptr,a
      007593 90 0D 70         [24] 2021 	mov	dptr,#___memcpy_PARM_3
      007596 22               [24] 2022 	ret
                                   2023 
                                   2024 	.area CSEG (CODE)
                                   2025 ; function ak820_outline_0060
      007597                       2026 _ak820_outline_0060:
      007597 F5 F0            [12] 2027 	mov	b,a
      007599 05 F0            [12] 2028 	inc	b
      00759B 74 01            [12] 2029 	mov	a,#0x01
      00759D 22               [24] 2030 	ret
                                   2031 
                                   2032 	.area CSEG (CODE)
                                   2033 ; function ak820_outline_0073
      00759E                       2034 _ak820_outline_0073:
      00759E 90 08 26         [24] 2035 	mov	dptr,#_process_action_PARM_2
      0075A1 E0               [24] 2036 	movx	a,@dptr
      0075A2 F5 82            [12] 2037 	mov	dpl,a
      0075A4 22               [24] 2038 	ret
                                   2039 
                                   2040 	.area CSEG (CODE)
                                   2041 ; function ak820_outline_0084
      0075A5                       2042 _ak820_outline_0084:
      0075A5 90 08 27         [24] 2043 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0075A8 E0               [24] 2044 	movx	a,@dptr
      0075A9 03               [12] 2045 	rr	a
      0075AA 03               [12] 2046 	rr	a
      0075AB 54 03            [12] 2047 	anl	a,#0x03
      0075AD 22               [24] 2048 	ret
                                   2049 
                                   2050 	.area CSEG (CODE)
                                   2051 ; function ak820_outline_0106
      0075AE                       2052 _ak820_outline_0106:
      0075AE 74 06            [12] 2053 	mov	a,#0x06
      0075B0 F0               [24] 2054 	movx	@dptr,a
      0075B1 E4               [12] 2055 	clr	a
      0075B2 A3               [24] 2056 	inc	dptr
      0075B3 F0               [24] 2057 	movx	@dptr,a
      0075B4 22               [24] 2058 	ret
                                   2059 
                                   2060 	.area CSEG (CODE)
                                   2061 ; function ak820_outline_0108
      0075B5                       2062 _ak820_outline_0108:
      0075B5 90 08 27         [24] 2063 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0075B8 E0               [24] 2064 	movx	a,@dptr
      0075B9 54 0F            [12] 2065 	anl	a,#0x0f
      0075BB 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0127
      0075BC                       2070 _ak820_outline_0127:
      0075BC 90 08 26         [24] 2071 	mov	dptr,#_process_action_PARM_2
      0075BF E0               [24] 2072 	movx	a,@dptr
      0075C0 FE               [12] 2073 	mov	r6,a
      0075C1 A3               [24] 2074 	inc	dptr
      0075C2 E0               [24] 2075 	movx	a,@dptr
      0075C3 54 03            [12] 2076 	anl	a,#0x03
      0075C5 FF               [12] 2077 	mov	r7,a
      0075C6 22               [24] 2078 	ret
                                   2079 
                                   2080 	.area CSEG (CODE)
                                   2081 ; function ak820_outline_0153
      0075C7                       2082 _ak820_outline_0153:
      0075C7 90 08 26         [24] 2083 	mov	dptr,#_process_action_PARM_2
      0075CA E0               [24] 2084 	movx	a,@dptr
      0075CB 22               [24] 2085 	ret
                                   2086 
                                   2087 	.area CSEG (CODE)
                                   2088 ; function ak820_outline_0161
      0075CC                       2089 _ak820_outline_0161:
      0075CC 90 08 2B         [24] 2090 	mov	dptr,#_register_code_code_10000_709
      0075CF E0               [24] 2091 	movx	a,@dptr
      0075D0 FF               [12] 2092 	mov	r7,a
      0075D1 22               [24] 2093 	ret
                                   2094 
                                   2095 	.area CSEG (CODE)
                                   2096 ; function ak820_outline_0162
      0075D2                       2097 _ak820_outline_0162:
      0075D2 90 08 2C         [24] 2098 	mov	dptr,#_unregister_code_code_10000_723
      0075D5 E0               [24] 2099 	movx	a,@dptr
      0075D6 FF               [12] 2100 	mov	r7,a
      0075D7 22               [24] 2101 	ret
