                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000678                         85 _eeprom_read_word_addr_10000_91:
      000678                         86 	.ds 3
      00067B                         87 _eeprom_read_word_ret_10000_92:
      00067B                         88 	.ds 2
      00067D                         89 _eeprom_read_dword_addr_10000_93:
      00067D                         90 	.ds 3
      000680                         91 _eeprom_read_dword_ret_10000_94:
      000680                         92 	.ds 4
      000684                         93 _eeprom_write_byte_PARM_2:
      000684                         94 	.ds 1
      000685                         95 _eeprom_write_byte_addr_10000_95:
      000685                         96 	.ds 3
      000688                         97 _eeprom_write_word_PARM_2:
      000688                         98 	.ds 2
      00068A                         99 _eeprom_write_word_addr_10000_97:
      00068A                        100 	.ds 3
      00068D                        101 _eeprom_write_dword_PARM_2:
      00068D                        102 	.ds 4
      000691                        103 _eeprom_write_dword_addr_10000_99:
      000691                        104 	.ds 3
      000694                        105 _eeprom_update_byte_PARM_2:
      000694                        106 	.ds 1
      000695                        107 _eeprom_update_byte_addr_10000_107:
      000695                        108 	.ds 3
      000698                        109 _eeprom_update_word_PARM_2:
      000698                        110 	.ds 2
      00069A                        111 _eeprom_update_word_addr_10000_111:
      00069A                        112 	.ds 3
      00069D                        113 _eeprom_update_dword_PARM_2:
      00069D                        114 	.ds 4
      0006A1                        115 _eeprom_update_dword_addr_10000_115:
      0006A1                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004C60                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004C60 12 42 D0         [24]  170 	lcall	_ak820_outline_0035
      004C63 90 06 78         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004C66 12 37 E1         [24]  172 	lcall	_ak820_outline_0014
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004C69 90 06 7B         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004C6C 12 4E 64         [24]  175 	lcall	_ak820_outline_0164
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004C6F 90 06 78         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004C72 12 4E 1B         [24]  178 	lcall	_ak820_outline_0021
      004C75 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004C78 ED               [12]  180 	mov	a,r5
      004C79 12 37 E1         [24]  181 	lcall	_ak820_outline_0014
      004C7C 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004C7F 12 4E 56         [24]  183 	lcall	_ak820_outline_0105
      004C82 90 06 7B         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004C85 12 40 6C         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004C88 90 06 7B         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004C8B 12 4E 4D         [24]  188 	lcall	_ak820_outline_0086
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004C8E 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004C8F                        201 _eeprom_read_dword:
      004C8F 12 42 D0         [24]  202 	lcall	_ak820_outline_0035
      004C92 90 06 7D         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004C95 12 37 E1         [24]  204 	lcall	_ak820_outline_0014
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004C98 90 06 80         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004C9B 12 4E 2B         [24]  207 	lcall	_ak820_outline_0047
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004C9E 90 06 7D         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004CA1 12 4E 1B         [24]  210 	lcall	_ak820_outline_0021
      004CA4 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004CA7 ED               [12]  212 	mov	a,r5
      004CA8 12 37 E1         [24]  213 	lcall	_ak820_outline_0014
      004CAB 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004CAE 74 04            [12]  215 	mov	a,#0x04
      004CB0 12 38 58         [24]  216 	lcall	_ak820_outline_0121
      004CB3 90 06 80         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004CB6 12 40 6C         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004CB9 90 06 80         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004CBC 12 4E 34         [24]  221 	lcall	_ak820_outline_0052
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004CBF 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004CC0                        234 _eeprom_write_byte:
      004CC0 12 42 D0         [24]  235 	lcall	_ak820_outline_0035
      004CC3 90 06 85         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004CC6 12 37 E1         [24]  237 	lcall	_ak820_outline_0014
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004CC9 90 06 85         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004CCC 12 4D F5         [24]  240 	lcall	_ak820_outline_0002
      004CCF 74 01            [12]  241 	mov	a,#0x01
      004CD1 12 38 58         [24]  242 	lcall	_ak820_outline_0121
      004CD4 90 06 84         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004CD7 02 40 F8         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004CDA                        256 _eeprom_write_word:
      004CDA 12 42 D0         [24]  257 	lcall	_ak820_outline_0035
      004CDD 90 06 8A         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004CE0 12 37 E1         [24]  259 	lcall	_ak820_outline_0014
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004CE3 90 06 8A         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004CE6 12 4D F5         [24]  262 	lcall	_ak820_outline_0002
      004CE9 12 4E 56         [24]  263 	lcall	_ak820_outline_0105
      004CEC 90 06 88         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004CEF 02 40 F8         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004CF2                        277 _eeprom_write_dword:
      004CF2 12 42 D0         [24]  278 	lcall	_ak820_outline_0035
      004CF5 90 06 91         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004CF8 12 37 E1         [24]  280 	lcall	_ak820_outline_0014
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004CFB 90 06 91         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004CFE 12 4D F5         [24]  283 	lcall	_ak820_outline_0002
      004D01 74 04            [12]  284 	mov	a,#0x04
      004D03 12 38 58         [24]  285 	lcall	_ak820_outline_0121
      004D06 90 06 8D         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004D09 02 40 F8         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004D0C                        307 _eeprom_update_byte:
      004D0C C0 07            [24]  308 	push	ar7
      004D0E C0 06            [24]  309 	push	ar6
      004D10 C0 05            [24]  310 	push	ar5
      004D12 C0 04            [24]  311 	push	ar4
      004D14 12 42 D0         [24]  312 	lcall	_ak820_outline_0035
      004D17 90 06 95         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D1A 12 37 E1         [24]  314 	lcall	_ak820_outline_0014
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004D1D 90 06 95         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D20 12 4E 0C         [24]  317 	lcall	_ak820_outline_0003
      004D23 12 40 31         [24]  318 	lcall	_eeprom_read_byte
      004D26 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004D28 90 06 94         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004D2B E0               [24]  322 	movx	a,@dptr
      004D2C FE               [12]  323 	mov	r6,a
      004D2D EF               [12]  324 	mov	a,r7
      004D2E B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004D31 80 36            [24]  326 	sjmp	00103$
      004D33                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004D33 90 06 95         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D36 12 38 18         [24]  330 	lcall	_ak820_outline_0057
      004D39 A3               [24]  331 	inc	dptr
      004D3A E0               [24]  332 	movx	a,@dptr
      004D3B FF               [12]  333 	mov	r7,a
      004D3C 90 06 84         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004D3F EE               [12]  335 	mov	a,r6
      004D40 F0               [24]  336 	movx	@dptr,a
      004D41 12 38 53         [24]  337 	lcall	_ak820_outline_0117
      004D44 8F F0            [24]  338 	mov	b, r7
      004D46 C0 07            [24]  339 	push	ar7
      004D48 C0 06            [24]  340 	push	ar6
      004D4A C0 05            [24]  341 	push	ar5
      004D4C C0 04            [24]  342 	push	ar4
      004D4E C0 03            [24]  343 	push	ar3
      004D50 C0 02            [24]  344 	push	ar2
      004D52 C0 01            [24]  345 	push	ar1
      004D54 C0 00            [24]  346 	push	ar0
      004D56 12 4C C0         [24]  347 	lcall	_eeprom_write_byte
      004D59 D0 00            [24]  348 	pop	ar0
      004D5B D0 01            [24]  349 	pop	ar1
      004D5D D0 02            [24]  350 	pop	ar2
      004D5F D0 03            [24]  351 	pop	ar3
      004D61 D0 04            [24]  352 	pop	ar4
      004D63 D0 05            [24]  353 	pop	ar5
      004D65 D0 06            [24]  354 	pop	ar6
      004D67 D0 07            [24]  355 	pop	ar7
      004D69                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      004D69 D0 04            [24]  358 	pop	ar4
      004D6B D0 05            [24]  359 	pop	ar5
      004D6D D0 06            [24]  360 	pop	ar6
      004D6F D0 07            [24]  361 	pop	ar7
      004D71 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      004D72                        374 _eeprom_update_word:
      004D72 12 42 D0         [24]  375 	lcall	_ak820_outline_0035
      004D75 90 06 9A         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004D78 12 37 E1         [24]  377 	lcall	_ak820_outline_0014
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004D7B 90 06 9A         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004D7E 12 4E 0C         [24]  380 	lcall	_ak820_outline_0003
      004D81 12 4C 60         [24]  381 	lcall	_eeprom_read_word
      004D84 12 43 24         [24]  382 	lcall	_ak820_outline_0129
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004D87 90 06 98         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      004D8A 12 38 18         [24]  385 	lcall	_ak820_outline_0057
      004D8D EE               [12]  386 	mov	a,r6
      004D8E B5 04 05         [24]  387 	cjne	a,ar4,00112$
      004D91 EF               [12]  388 	mov	a,r7
      004D92 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      004D95 22               [24]  390 	ret
      004D96                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004D96 90 06 9A         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004D99 E0               [24]  394 	movx	a,@dptr
      004D9A FB               [12]  395 	mov	r3,a
      004D9B A3               [24]  396 	inc	dptr
      004D9C 12 37 F9         [24]  397 	lcall	_ak820_outline_0049
      004D9F 90 06 88         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      004DA2 12 38 1E         [24]  399 	lcall	_ak820_outline_0068
      004DA5 8B 82            [24]  400 	mov	dpl, r3
      004DA7 8E 83            [24]  401 	mov	dph, r6
      004DA9 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      004DAB 02 4C DA         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      004DAE                        416 _eeprom_update_dword:
      004DAE 12 42 D0         [24]  417 	lcall	_ak820_outline_0035
      004DB1 90 06 A1         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004DB4 12 37 E1         [24]  419 	lcall	_ak820_outline_0014
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004DB7 90 06 A1         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004DBA 12 4E 0C         [24]  422 	lcall	_ak820_outline_0003
      004DBD 12 4C 8F         [24]  423 	lcall	_eeprom_read_dword
      004DC0 12 4E 45         [24]  424 	lcall	_ak820_outline_0054
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004DC3 90 06 9D         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      004DC6 12 38 2A         [24]  427 	lcall	_ak820_outline_0094
      004DC9 A3               [24]  428 	inc	dptr
      004DCA 12 43 01         [24]  429 	lcall	_ak820_outline_0080
      004DCD EC               [12]  430 	mov	a,r4
      004DCE B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004DD1 ED               [12]  432 	mov	a,r5
      004DD2 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004DD5 EE               [12]  434 	mov	a,r6
      004DD6 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004DD9 EF               [12]  436 	mov	a,r7
      004DDA B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004DDD 22               [24]  438 	ret
      004DDE                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004DDE 90 06 A1         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004DE1 12 4E 1B         [24]  442 	lcall	_ak820_outline_0021
      004DE4 90 06 8D         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004DE7 E8               [12]  444 	mov	a,r0
      004DE8 F0               [24]  445 	movx	@dptr,a
      004DE9 E9               [12]  446 	mov	a,r1
      004DEA A3               [24]  447 	inc	dptr
      004DEB 12 4E 5D         [24]  448 	lcall	_ak820_outline_0149
      004DEE F0               [24]  449 	movx	@dptr,a
      004DEF 12 4E 24         [24]  450 	lcall	_ak820_outline_0042
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      004DF2 02 4C F2         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0014
                                    462 	.globl _ak820_outline_0021
                                    463 	.globl _ak820_outline_0035
                                    464 	.globl _ak820_outline_0042
                                    465 	.globl _ak820_outline_0047
                                    466 	.globl _ak820_outline_0049
                                    467 	.globl _ak820_outline_0052
                                    468 	.globl _ak820_outline_0054
                                    469 	.globl _ak820_outline_0057
                                    470 	.globl _ak820_outline_0068
                                    471 	.globl _ak820_outline_0080
                                    472 	.globl _ak820_outline_0086
                                    473 	.globl _ak820_outline_0094
                                    474 	.globl _ak820_outline_0105
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0121
                                    477 	.globl _ak820_outline_0129
                                    478 	.globl _ak820_outline_0149
                                    479 	.globl _ak820_outline_0164
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      004DF5                        483 _ak820_outline_0002:
      004DF5 E0               [24]  484 	movx	a,@dptr
      004DF6 FD               [12]  485 	mov	r5,a
      004DF7 A3               [24]  486 	inc	dptr
      004DF8 E0               [24]  487 	movx	a,@dptr
      004DF9 FE               [12]  488 	mov	r6,a
      004DFA A3               [24]  489 	inc	dptr
      004DFB E0               [24]  490 	movx	a,@dptr
      004DFC FF               [12]  491 	mov	r7,a
      004DFD 90 05 8A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004E00 ED               [12]  493 	mov	a,r5
      004E01 F0               [24]  494 	movx	@dptr,a
      004E02 EE               [12]  495 	mov	a,r6
      004E03 A3               [24]  496 	inc	dptr
      004E04 F0               [24]  497 	movx	@dptr,a
      004E05 EF               [12]  498 	mov	a,r7
      004E06 A3               [24]  499 	inc	dptr
      004E07 F0               [24]  500 	movx	@dptr,a
      004E08 90 05 8D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004E0B 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      004E0C                        506 _ak820_outline_0003:
      004E0C E0               [24]  507 	movx	a,@dptr
      004E0D FD               [12]  508 	mov	r5,a
      004E0E A3               [24]  509 	inc	dptr
      004E0F E0               [24]  510 	movx	a,@dptr
      004E10 FE               [12]  511 	mov	r6,a
      004E11 A3               [24]  512 	inc	dptr
      004E12 E0               [24]  513 	movx	a,@dptr
      004E13 FF               [12]  514 	mov	r7,a
      004E14 8D 82            [24]  515 	mov	dpl,r5
      004E16 8E 83            [24]  516 	mov	dph,r6
      004E18 8F F0            [24]  517 	mov	b,r7
      004E1A 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0021
      004E1B                        522 _ak820_outline_0021:
      004E1B E0               [24]  523 	movx	a,@dptr
      004E1C FD               [12]  524 	mov	r5,a
      004E1D A3               [24]  525 	inc	dptr
      004E1E E0               [24]  526 	movx	a,@dptr
      004E1F FE               [12]  527 	mov	r6,a
      004E20 A3               [24]  528 	inc	dptr
      004E21 E0               [24]  529 	movx	a,@dptr
      004E22 FF               [12]  530 	mov	r7,a
      004E23 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0042
      004E24                        535 _ak820_outline_0042:
      004E24 8D 82            [24]  536 	mov	dpl,r5
      004E26 8E 83            [24]  537 	mov	dph,r6
      004E28 8F F0            [24]  538 	mov	b,r7
      004E2A 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0047
      004E2B                        543 _ak820_outline_0047:
      004E2B E4               [12]  544 	clr	a
      004E2C F0               [24]  545 	movx	@dptr,a
      004E2D A3               [24]  546 	inc	dptr
      004E2E F0               [24]  547 	movx	@dptr,a
      004E2F A3               [24]  548 	inc	dptr
      004E30 F0               [24]  549 	movx	@dptr,a
      004E31 A3               [24]  550 	inc	dptr
      004E32 F0               [24]  551 	movx	@dptr,a
      004E33 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0052
      004E34                        556 _ak820_outline_0052:
      004E34 E0               [24]  557 	movx	a,@dptr
      004E35 FC               [12]  558 	mov	r4,a
      004E36 A3               [24]  559 	inc	dptr
      004E37 E0               [24]  560 	movx	a,@dptr
      004E38 FD               [12]  561 	mov	r5,a
      004E39 A3               [24]  562 	inc	dptr
      004E3A E0               [24]  563 	movx	a,@dptr
      004E3B FE               [12]  564 	mov	r6,a
      004E3C A3               [24]  565 	inc	dptr
      004E3D E0               [24]  566 	movx	a,@dptr
      004E3E 8C 82            [24]  567 	mov	dpl,r4
      004E40 8D 83            [24]  568 	mov	dph,r5
      004E42 8E F0            [24]  569 	mov	b,r6
      004E44 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0054
      004E45                        574 _ak820_outline_0054:
      004E45 AC 82            [24]  575 	mov	r4,dpl
      004E47 AD 83            [24]  576 	mov	r5,dph
      004E49 AE F0            [24]  577 	mov	r6,b
      004E4B FF               [12]  578 	mov	r7,a
      004E4C 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0086
      004E4D                        583 _ak820_outline_0086:
      004E4D E0               [24]  584 	movx	a,@dptr
      004E4E FE               [12]  585 	mov	r6,a
      004E4F A3               [24]  586 	inc	dptr
      004E50 E0               [24]  587 	movx	a,@dptr
      004E51 8E 82            [24]  588 	mov	dpl,r6
      004E53 F5 83            [12]  589 	mov	dph,a
      004E55 22               [24]  590 	ret
                                    591 
                                    592 	.area CSEG (CODE)
                                    593 ; function ak820_outline_0105
      004E56                        594 _ak820_outline_0105:
      004E56 74 02            [12]  595 	mov	a,#0x02
      004E58 F0               [24]  596 	movx	@dptr,a
      004E59 E4               [12]  597 	clr	a
      004E5A A3               [24]  598 	inc	dptr
      004E5B F0               [24]  599 	movx	@dptr,a
      004E5C 22               [24]  600 	ret
                                    601 
                                    602 	.area CSEG (CODE)
                                    603 ; function ak820_outline_0149
      004E5D                        604 _ak820_outline_0149:
      004E5D F0               [24]  605 	movx	@dptr,a
      004E5E EA               [12]  606 	mov	a,r2
      004E5F A3               [24]  607 	inc	dptr
      004E60 F0               [24]  608 	movx	@dptr,a
      004E61 EB               [12]  609 	mov	a,r3
      004E62 A3               [24]  610 	inc	dptr
      004E63 22               [24]  611 	ret
                                    612 
                                    613 	.area CSEG (CODE)
                                    614 ; function ak820_outline_0164
      004E64                        615 _ak820_outline_0164:
      004E64 E4               [12]  616 	clr	a
      004E65 F0               [24]  617 	movx	@dptr,a
      004E66 A3               [24]  618 	inc	dptr
      004E67 F0               [24]  619 	movx	@dptr,a
      004E68 22               [24]  620 	ret
