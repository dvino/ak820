                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _add_owned_mods
                                     13 	.globl _layer_hold_off
                                     14 	.globl _layer_hold_on
                                     15 	.globl _unregister_mods
                                     16 	.globl _register_mods
                                     17 	.globl _process_record
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _ak820_oneshot_target
                                    262 	.globl _ak820_oneshot_process_PARM_3
                                    263 	.globl _ak820_oneshot_process_PARM_2
                                    264 	.globl _ak820_oneshot_consumed
                                    265 	.globl _ak820_oneshot_mods
                                    266 	.globl _ak820_tapping_source_PARM_1
                                    267 	.globl _ak820_tapping_source
                                    268 	.globl _ak820_tapping_before
                                    269 	.globl _ak820_tapping_process
                                    270 	.globl _ak820_tapping_cancel
                                    271 	.globl _ak820_oneshot_process
                                    272 ;--------------------------------------------------------
                                    273 ; special function registers
                                    274 ;--------------------------------------------------------
                                    275 	.area RSEG    (ABS,DATA)
      000000                        276 	.org 0x0000
                           0000D0   277 _PSW	=	0x00d0
                           0000E0   278 _ACC	=	0x00e0
                           0000F0   279 _B	=	0x00f0
                           0000FD   280 _A_INV	=	0x00fd
                           000081   281 _SP	=	0x0081
                           000082   282 _DPL	=	0x0082
                           000083   283 _DPH	=	0x0083
                           0000A1   284 _SAFE_MOD	=	0x00a1
                           0000B1   285 _GLOBAL_CFG	=	0x00b1
                           000087   286 _PCON	=	0x0087
                           0000BA   287 _POWER_CFG	=	0x00ba
                           0000B9   288 _CLOCK_CFG	=	0x00b9
                           0000A9   289 _WAKE_CTRL	=	0x00a9
                           0000FE   290 _RESET_KEEP	=	0x00fe
                           0000FF   291 _WDOG_COUNT	=	0x00ff
                           0000A8   292 _IE	=	0x00a8
                           0000B8   293 _IP	=	0x00b8
                           0000E8   294 _IE_EX	=	0x00e8
                           0000E9   295 _IP_EX	=	0x00e9
                           0000B2   296 _GPIO_IE	=	0x00b2
                           008584   297 _ROM_ADDR	=	0x8584
                           000084   298 _ROM_ADDR_L	=	0x0084
                           000085   299 _ROM_ADDR_H	=	0x0085
                           008F8E   300 _ROM_DATA_HI	=	0x8f8e
                           00008E   301 _ROM_DATA_HL	=	0x008e
                           00008F   302 _ROM_DATA_HH	=	0x008f
                           000086   303 _ROM_CTRL	=	0x0086
                           000080   304 _P0	=	0x0080
                           0000C4   305 _P0_MOD_OC	=	0x00c4
                           0000C5   306 _P0_DIR_PU	=	0x00c5
                           000090   307 _P1	=	0x0090
                           000092   308 _P1_MOD_OC	=	0x0092
                           000093   309 _P1_DIR_PU	=	0x0093
                           0000A0   310 _P2	=	0x00a0
                           000094   311 _P2_MOD_OC	=	0x0094
                           000095   312 _P2_DIR_PU	=	0x0095
                           0000B0   313 _P3	=	0x00b0
                           000096   314 _P3_MOD_OC	=	0x0096
                           000097   315 _P3_DIR_PU	=	0x0097
                           0000C0   316 _P4	=	0x00c0
                           0000C2   317 _P4_MOD_OC	=	0x00c2
                           0000C3   318 _P4_DIR_PU	=	0x00c3
                           0000C1   319 _P4_LED_KEY	=	0x00c1
                           0000AA   320 _P5_IN	=	0x00aa
                           0000AB   321 _P5_OUT_PU	=	0x00ab
                           0000AC   322 _P5_DIR	=	0x00ac
                           0000AD   323 _P6_IN	=	0x00ad
                           0000AE   324 _P6_OUT_PU	=	0x00ae
                           0000AF   325 _P6_DIR	=	0x00af
                           0000F1   326 _P7	=	0x00f1
                           0000A2   327 _XBUS_AUX	=	0x00a2
                           000088   328 _TCON	=	0x0088
                           000089   329 _TMOD	=	0x0089
                           00008A   330 _TL0	=	0x008a
                           00008B   331 _TL1	=	0x008b
                           00008C   332 _TH0	=	0x008c
                           00008D   333 _TH1	=	0x008d
                           000098   334 _SCON	=	0x0098
                           000099   335 _SBUF	=	0x0099
                           0000C8   336 _T2CON	=	0x00c8
                           0000C9   337 _T2MOD	=	0x00c9
                           00CBCA   338 _RCAP2	=	0xcbca
                           0000CA   339 _RCAP2L	=	0x00ca
                           0000CB   340 _RCAP2H	=	0x00cb
                           00CDCC   341 _T2COUNT	=	0xcdcc
                           0000CC   342 _TL2	=	0x00cc
                           0000CD   343 _TH2	=	0x00cd
                           00CFCE   344 _T2CAP1	=	0xcfce
                           0000CE   345 _T2CAP1L	=	0x00ce
                           0000CF   346 _T2CAP1H	=	0x00cf
                           0000F8   347 _SPI0_STAT	=	0x00f8
                           0000F9   348 _SPI0_DATA	=	0x00f9
                           0000FA   349 _SPI0_CTRL	=	0x00fa
                           0000FB   350 _SPI0_CK_SE	=	0x00fb
                           0000FC   351 _SPI0_SETUP	=	0x00fc
                           0000BC   352 _SCON1	=	0x00bc
                           0000BD   353 _SBUF1	=	0x00bd
                           0000BE   354 _SBAUD1	=	0x00be
                           0000BF   355 _SIF1	=	0x00bf
                           0000B4   356 _SPI1_STAT	=	0x00b4
                           0000B5   357 _SPI1_DATA	=	0x00b5
                           0000B6   358 _SPI1_CTRL	=	0x00b6
                           0000B7   359 _SPI1_CK_SE	=	0x00b7
                           0000F3   360 _ADC_CTRL	=	0x00f3
                           00F5F4   361 _ADC_DAT	=	0xf5f4
                           0000F4   362 _ADC_DAT_L	=	0x00f4
                           0000F5   363 _ADC_DAT_H	=	0x00f5
                           0000F6   364 _ADC_CHAN	=	0x00f6
                           0000A6   365 _LED_COMMON	=	0x00a6
                           0000A7   366 _LED_PWM_OE	=	0x00a7
                           00C7C6   367 _LED_DMA	=	0xc7c6
                           0000C6   368 _LED_DMA_L	=	0x00c6
                           0000C7   369 _LED_DMA_H	=	0x00c7
                           0000F7   370 _LED_STATUS	=	0x00f7
                           0000B3   371 _I2CX_INT	=	0x00b3
                           0000BB   372 _I2CS_INT_ST	=	0x00bb
                                    373 ;--------------------------------------------------------
                                    374 ; special function bits
                                    375 ;--------------------------------------------------------
                                    376 	.area RSEG    (ABS,DATA)
      000000                        377 	.org 0x0000
                           0000D7   378 _CY	=	0x00d7
                           0000D6   379 _AC	=	0x00d6
                           0000D5   380 _F0	=	0x00d5
                           0000D4   381 _RS1	=	0x00d4
                           0000D3   382 _RS0	=	0x00d3
                           0000D2   383 _OV	=	0x00d2
                           0000D1   384 _F1	=	0x00d1
                           0000D0   385 _P	=	0x00d0
                           0000AF   386 _EA	=	0x00af
                           0000AE   387 _E_DIS	=	0x00ae
                           0000AD   388 _ET2	=	0x00ad
                           0000AC   389 _ES	=	0x00ac
                           0000AB   390 _ET1	=	0x00ab
                           0000AA   391 _EX1	=	0x00aa
                           0000A9   392 _ET0	=	0x00a9
                           0000A8   393 _EX0	=	0x00a8
                           0000BF   394 _PH_FLAG	=	0x00bf
                           0000BE   395 _PL_FLAG	=	0x00be
                           0000BD   396 _PT2	=	0x00bd
                           0000BC   397 _PS	=	0x00bc
                           0000BB   398 _PT1	=	0x00bb
                           0000BA   399 _PX1	=	0x00ba
                           0000B9   400 _PT0	=	0x00b9
                           0000B8   401 _PX0	=	0x00b8
                           0000EF   402 _IE_WDOG	=	0x00ef
                           0000EE   403 _IE_GPIO	=	0x00ee
                           0000ED   404 _IE_PWM_I2C	=	0x00ed
                           0000EC   405 _IE_UART1	=	0x00ec
                           0000EB   406 _IE_ADC	=	0x00eb
                           0000E9   407 _IE_USB	=	0x00e9
                           0000E8   408 _IE_SPI0	=	0x00e8
                           000087   409 _P0_7	=	0x0087
                           000086   410 _P0_6	=	0x0086
                           000085   411 _P0_5	=	0x0085
                           000084   412 _P0_4	=	0x0084
                           000083   413 _P0_3	=	0x0083
                           000082   414 _P0_2	=	0x0082
                           000081   415 _P0_1	=	0x0081
                           000080   416 _P0_0	=	0x0080
                           000081   417 _SDA0	=	0x0081
                           000080   418 _SCL0	=	0x0080
                           000083   419 _TXD_	=	0x0083
                           000082   420 _RXD_	=	0x0082
                           000085   421 _AIN13	=	0x0085
                           000084   422 _AIN12	=	0x0084
                           000083   423 _AIN11	=	0x0083
                           000082   424 _AIN10	=	0x0082
                           000081   425 _AIN9	=	0x0081
                           000080   426 _AIN8	=	0x0080
                           000097   427 _P1_7	=	0x0097
                           000096   428 _P1_6	=	0x0096
                           000095   429 _P1_5	=	0x0095
                           000094   430 _P1_4	=	0x0094
                           000093   431 _P1_3	=	0x0093
                           000092   432 _P1_2	=	0x0092
                           000091   433 _P1_1	=	0x0091
                           000090   434 _P1_0	=	0x0090
                           000097   435 _TXD1_	=	0x0097
                           000096   436 _RXD1_	=	0x0096
                           000097   437 _SCK	=	0x0097
                           000096   438 _MISO	=	0x0096
                           000095   439 _MOSI	=	0x0095
                           000094   440 _SCS	=	0x0094
                           000092   441 _INT0_	=	0x0092
                           000091   442 _T2EX	=	0x0091
                           000091   443 _CAP2	=	0x0091
                           000090   444 _T2	=	0x0090
                           000090   445 _CAP1	=	0x0090
                           000097   446 _AIN7	=	0x0097
                           000096   447 _AIN6	=	0x0096
                           000095   448 _AIN5	=	0x0095
                           000094   449 _AIN4	=	0x0094
                           000093   450 _AIN3	=	0x0093
                           000092   451 _AIN2	=	0x0092
                           000091   452 _AIN1	=	0x0091
                           000090   453 _AIN0	=	0x0090
                           0000A7   454 _P2_7	=	0x00a7
                           0000A6   455 _P2_6	=	0x00a6
                           0000A5   456 _P2_5	=	0x00a5
                           0000A4   457 _P2_4	=	0x00a4
                           0000A3   458 _P2_3	=	0x00a3
                           0000A2   459 _P2_2	=	0x00a2
                           0000A1   460 _P2_1	=	0x00a1
                           0000A0   461 _P2_0	=	0x00a0
                           0000A7   462 _TXD1	=	0x00a7
                           0000A6   463 _RXD1	=	0x00a6
                           0000A5   464 _T2EX_	=	0x00a5
                           0000A5   465 _CAP2_	=	0x00a5
                           0000A4   466 _T2_	=	0x00a4
                           0000A4   467 _CAP1_	=	0x00a4
                           0000B7   468 _P3_7	=	0x00b7
                           0000B6   469 _P3_6	=	0x00b6
                           0000B5   470 _P3_5	=	0x00b5
                           0000B4   471 _P3_4	=	0x00b4
                           0000B3   472 _P3_3	=	0x00b3
                           0000B2   473 _P3_2	=	0x00b2
                           0000B1   474 _P3_1	=	0x00b1
                           0000B0   475 _P3_0	=	0x00b0
                           0000B7   476 _SCK1	=	0x00b7
                           0000B6   477 _MISO1	=	0x00b6
                           0000B5   478 _MOSI1	=	0x00b5
                           0000B5   479 _T1	=	0x00b5
                           0000B4   480 _T0	=	0x00b4
                           0000B3   481 _INT1	=	0x00b3
                           0000B2   482 _INT0	=	0x00b2
                           0000B1   483 _TXD	=	0x00b1
                           0000B0   484 _RXD	=	0x00b0
                           0000C6   485 _P4_6	=	0x00c6
                           0000C5   486 _P4_5	=	0x00c5
                           0000C4   487 _P4_4	=	0x00c4
                           0000C3   488 _P4_3	=	0x00c3
                           0000C2   489 _P4_2	=	0x00c2
                           0000C1   490 _P4_1	=	0x00c1
                           0000C0   491 _P4_0	=	0x00c0
                           00008F   492 _TF1	=	0x008f
                           00008E   493 _TR1	=	0x008e
                           00008D   494 _TF0	=	0x008d
                           00008C   495 _TR0	=	0x008c
                           00008B   496 _IE1	=	0x008b
                           00008A   497 _IT1	=	0x008a
                           000089   498 _IE0	=	0x0089
                           000088   499 _IT0	=	0x0088
                           00009F   500 _SM0	=	0x009f
                           00009E   501 _SM1	=	0x009e
                           00009D   502 _SM2	=	0x009d
                           00009C   503 _REN	=	0x009c
                           00009B   504 _TB8	=	0x009b
                           00009A   505 _RB8	=	0x009a
                           000099   506 _TI	=	0x0099
                           000098   507 _RI	=	0x0098
                           0000CF   508 _TF2	=	0x00cf
                           0000CF   509 _CAP1F	=	0x00cf
                           0000CE   510 _EXF2	=	0x00ce
                           0000CD   511 _RCLK	=	0x00cd
                           0000CC   512 _TCLK	=	0x00cc
                           0000CB   513 _EXEN2	=	0x00cb
                           0000CA   514 _TR2	=	0x00ca
                           0000C9   515 _C_T2	=	0x00c9
                           0000C8   516 _CP_RL2	=	0x00c8
                           0000FF   517 _S0_FST_ACT	=	0x00ff
                           0000FE   518 _S0_IF_OV	=	0x00fe
                           0000FD   519 _S0_IF_FIRST	=	0x00fd
                           0000FC   520 _S0_IF_BYTE	=	0x00fc
                           0000FB   521 _S0_FREE	=	0x00fb
                           0000FA   522 _S0_T_FIFO	=	0x00fa
                           0000F8   523 _S0_R_FIFO	=	0x00f8
                           0000F7   524 _ADC_START	=	0x00f7
                                    525 ;--------------------------------------------------------
                                    526 ; overlayable register banks
                                    527 ;--------------------------------------------------------
                                    528 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        529 	.ds 8
                                    530 ;--------------------------------------------------------
                                    531 ; internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area DSEG    (DATA)
      000015                        534 _ak820_tapping_process_sloc0_1_0:
      000015                        535 	.ds 2
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00059A                        562 _source_state:
      00059A                        563 	.ds 130
      00061C                        564 _pending_time:
      00061C                        565 	.ds 2
      00061E                        566 _pending_code:
      00061E                        567 	.ds 2
      000620                        568 _ak820_tapping_source_PARM_1:
      000620                        569 	.ds 2
      000622                        570 _hold_PARM_2:
      000622                        571 	.ds 1
      000623                        572 _hold_code_10000_601:
      000623                        573 	.ds 2
      000625                        574 _hold_mods_30000_604:
      000625                        575 	.ds 1
      000626                        576 _commit_pending_id_10000_610:
      000626                        577 	.ds 1
      000627                        578 _ak820_tapping_before_event_10000_611:
      000627                        579 	.ds 2
      000629                        580 _ak820_tapping_process_record_10000_622:
      000629                        581 	.ds 2
      00062B                        582 _ak820_oneshot_mods::
      00062B                        583 	.ds 1
      00062C                        584 _ak820_oneshot_consumed::
      00062C                        585 	.ds 1
      00062D                        586 _ak820_oneshot_process_PARM_2:
      00062D                        587 	.ds 1
      00062E                        588 _ak820_oneshot_process_PARM_3:
      00062E                        589 	.ds 1
      00062F                        590 _ak820_oneshot_process_code_10000_640:
      00062F                        591 	.ds 2
      000631                        592 _ak820_oneshot_process_mods_10000_641:
      000631                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000D7D                        602 _pending:
      000D7D                        603 	.ds 1
      000D7E                        604 _ak820_oneshot_target::
      000D7E                        605 	.ds 1
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT0 (CODE)
                                    608 	.area GSINIT1 (CODE)
                                    609 	.area GSINIT2 (CODE)
                                    610 	.area GSINIT3 (CODE)
                                    611 	.area GSINIT4 (CODE)
                                    612 	.area GSINIT5 (CODE)
                                    613 	.area GSINIT  (CODE)
                                    614 	.area GSFINAL (CODE)
                                    615 	.area CSEG    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; global & static initialisations
                                    618 ;--------------------------------------------------------
                                    619 	.area HOME    (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; Home
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area HOME    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; code
                                    630 ;--------------------------------------------------------
                                    631 	.area CSEG    (CODE)
                                    632 ;------------------------------------------------------------
                                    633 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    634 ;------------------------------------------------------------
                                    635 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    638 ;	-----------------------------------------
                           000007   639 	ar7 = 0x07
                           000006   640 	ar6 = 0x06
                           000005   641 	ar5 = 0x05
                           000004   642 	ar4 = 0x04
                           000003   643 	ar3 = 0x03
                           000002   644 	ar2 = 0x02
                           000001   645 	ar1 = 0x01
                           000000   646 	ar0 = 0x00
                                    647 ;	 function ak820_tapping_source
                                    648 ;	-----------------------------------------
      00435A                        649 _ak820_tapping_source:
                                    650 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      00435A 90 06 21         [24]  651 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00435D E0               [24]  652 	movx	a,@dptr
      00435E FF               [12]  653 	mov	r7,a
      00435F BF 10 00         [24]  654 	cjne	r7,#0x10,00147$
      004362                        655 00147$:
      004362 50 14            [24]  656 	jnc	00102$
      004364 90 06 20         [24]  657 	mov	dptr,#_ak820_tapping_source_PARM_1
      004367 E0               [24]  658 	movx	a,@dptr
      004368 FE               [12]  659 	mov	r6,a
      004369 BE 08 00         [24]  660 	cjne	r6,#0x08,00149$
      00436C                        661 00149$:
      00436C 50 0A            [24]  662 	jnc	00102$
      00436E 8F 05            [24]  663 	mov	ar5,r7
      004370 ED               [12]  664 	mov	a,r5
      004371 12 38 83         [24]  665 	lcall	_ak820_outline_0183
      004374 2E               [12]  666 	add	a,r6
      004375 F5 82            [12]  667 	mov	dpl,a
      004377 22               [24]  668 	ret
      004378                        669 00102$:
                                    670 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004378 90 06 20         [24]  671 	mov	dptr,#_ak820_tapping_source_PARM_1
      00437B E0               [24]  672 	movx	a,@dptr
      00437C FE               [12]  673 	mov	r6,a
      00437D BE 01 00         [24]  674 	cjne	r6,#0x01,00151$
      004380                        675 00151$:
      004380 50 0E            [24]  676 	jnc	00109$
                                    677 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004382 BF FD 04         [24]  678 	cjne	r7,#0xfd,00105$
      004385 75 82 80         [24]  679 	mov	dpl, #0x80
      004388 22               [24]  680 	ret
      004389                        681 00105$:
                                    682 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004389 BF FC 04         [24]  683 	cjne	r7,#0xfc,00109$
      00438C 75 82 81         [24]  684 	mov	dpl, #0x81
      00438F 22               [24]  685 	ret
      004390                        686 00109$:
                                    687 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004390 75 82 FF         [24]  688 	mov	dpl, #0xff
                                    689 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004393 22               [24]  690 	ret
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'hold'
                                    693 ;------------------------------------------------------------
                                    694 ;pressed       Allocated with name '_hold_PARM_2'
                                    695 ;code          Allocated with name '_hold_code_10000_601'
                                    696 ;mods          Allocated with name '_hold_mods_30000_604'
                                    697 ;layer         Allocated with name '_hold_layer_30000_607'
                                    698 ;------------------------------------------------------------
                                    699 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    700 ;	-----------------------------------------
                                    701 ;	 function hold
                                    702 ;	-----------------------------------------
      004394                        703 _hold:
      004394 12 38 47         [24]  704 	lcall	_ak820_outline_0103
      004397 90 06 23         [24]  705 	mov	dptr,#_hold_code_10000_601
      00439A 12 38 42         [24]  706 	lcall	_ak820_outline_0102
                                    707 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      00439D 90 06 23         [24]  708 	mov	dptr,#_hold_code_10000_601
      0043A0 12 37 CD         [24]  709 	lcall	_ak820_outline_0009
      0043A3 74 C0            [12]  710 	mov	a,#0x100 - 0x40
      0043A5 2D               [12]  711 	add	a,r5
      0043A6 40 2E            [24]  712 	jc	00110$
                                    713 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0043A8 8F 05            [24]  714 	mov	ar5,r7
      0043AA 53 05 1F         [24]  715 	anl	ar5,#0x1f
      0043AD 90 06 25         [24]  716 	mov	dptr,#_hold_mods_30000_604
      0043B0 ED               [12]  717 	mov	a,r5
      0043B1 F0               [24]  718 	movx	@dptr,a
                                    719 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0043B2 ED               [12]  720 	mov	a,r5
      0043B3 30 E4 08         [24]  721 	jnb	acc.4,00102$
      0043B6 ED               [12]  722 	mov	a,r5
      0043B7 C4               [12]  723 	swap	a
      0043B8 54 F0            [12]  724 	anl	a,#0xf0
      0043BA 90 06 25         [24]  725 	mov	dptr,#_hold_mods_30000_604
      0043BD F0               [24]  726 	movx	@dptr,a
      0043BE                        727 00102$:
                                    728 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0043BE 90 06 22         [24]  729 	mov	dptr,#_hold_PARM_2
      0043C1 E0               [24]  730 	movx	a,@dptr
      0043C2 60 09            [24]  731 	jz	00104$
      0043C4 90 06 25         [24]  732 	mov	dptr,#_hold_mods_30000_604
      0043C7 E0               [24]  733 	movx	a,@dptr
      0043C8 F5 82            [12]  734 	mov	dpl,a
      0043CA 02 74 E4         [24]  735 	ljmp	_register_mods
      0043CD                        736 00104$:
                                    737 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0043CD 90 06 25         [24]  738 	mov	dptr,#_hold_mods_30000_604
      0043D0 E0               [24]  739 	movx	a,@dptr
      0043D1 F5 82            [12]  740 	mov	dpl,a
      0043D3 02 74 F8         [24]  741 	ljmp	_unregister_mods
      0043D6                        742 00110$:
                                    743 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      0043D6 8F 06            [24]  744 	mov	ar6,r7
      0043D8 74 0F            [12]  745 	mov	a,#0x0f
      0043DA 5E               [12]  746 	anl	a,r6
      0043DB FF               [12]  747 	mov	r7,a
                                    748 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      0043DC 90 06 22         [24]  749 	mov	dptr,#_hold_PARM_2
      0043DF E0               [24]  750 	movx	a,@dptr
      0043E0 60 05            [24]  751 	jz	00107$
      0043E2 8F 82            [24]  752 	mov	dpl, r7
      0043E4 02 76 A8         [24]  753 	ljmp	_layer_hold_on
      0043E7                        754 00107$:
                                    755 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0043E7 8F 82            [24]  756 	mov	dpl, r7
                                    757 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0043E9 02 76 E0         [24]  758 	ljmp	_layer_hold_off
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'commit_pending'
                                    761 ;------------------------------------------------------------
                                    762 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    763 ;------------------------------------------------------------
                                    764 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function commit_pending
                                    767 ;	-----------------------------------------
      0043EC                        768 _commit_pending:
                                    769 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0043EC 90 0D 7D         [24]  770 	mov	dptr,#_pending
      0043EF E0               [24]  771 	movx	a,@dptr
      0043F0 90 06 26         [24]  772 	mov	dptr,#_commit_pending_id_10000_610
      0043F3 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0043F4 12 47 E8         [24]  775 	lcall	_ak820_outline_0148
                                    776 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0043F7 90 06 26         [24]  777 	mov	dptr,#_commit_pending_id_10000_610
      0043FA E0               [24]  778 	movx	a,@dptr
      0043FB 24 9A            [12]  779 	add	a,#_source_state
      0043FD FF               [12]  780 	mov	r7,a
      0043FE E4               [12]  781 	clr	a
      0043FF 34 05            [12]  782 	addc	a, #(_source_state >> 8)
      004401 FE               [12]  783 	mov	r6,a
      004402 12 43 44         [24]  784 	lcall	_ak820_outline_0152
      004405 E0               [24]  785 	movx	a,@dptr
      004406 FD               [12]  786 	mov	r5,a
      004407 43 05 04         [24]  787 	orl	ar5,#0x04
      00440A 12 43 44         [24]  788 	lcall	_ak820_outline_0152
      00440D ED               [12]  789 	mov	a,r5
      00440E F0               [24]  790 	movx	@dptr,a
                                    791 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00440F 90 06 1E         [24]  792 	mov	dptr,#_pending_code
      004412 12 37 F9         [24]  793 	lcall	_ak820_outline_0049
      004415 90 06 22         [24]  794 	mov	dptr,#_hold_PARM_2
      004418 74 01            [12]  795 	mov	a,#0x01
      00441A 12 42 F4         [24]  796 	lcall	_ak820_outline_0058
                                    797 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      00441D 02 43 94         [24]  798 	ljmp	_hold
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    801 ;------------------------------------------------------------
                                    802 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    803 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    804 ;------------------------------------------------------------
                                    805 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function ak820_tapping_before
                                    808 ;	-----------------------------------------
      004420                        809 _ak820_tapping_before:
      004420 12 38 47         [24]  810 	lcall	_ak820_outline_0103
      004423 90 06 27         [24]  811 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004426 12 38 42         [24]  812 	lcall	_ak820_outline_0102
                                    813 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004429 90 06 27         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_611
      00442C 12 37 CD         [24]  815 	lcall	_ak820_outline_0009
      00442F 12 47 92         [24]  816 	lcall	_ak820_outline_0022
      004432 C0 07            [24]  817 	push	ar7
      004434 C0 06            [24]  818 	push	ar6
      004436 12 B5 58         [24]  819 	lcall	___memcpy
      004439 12 43 5A         [24]  820 	lcall	_ak820_tapping_source
      00443C AD 82            [24]  821 	mov	r5, dpl
      00443E D0 06            [24]  822 	pop	ar6
      004440 D0 07            [24]  823 	pop	ar7
                                    824 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004442 90 0D EE         [24]  825 	mov	dptr,#_vial_unlock_in_progress
      004445 E0               [24]  826 	movx	a,@dptr
      004446 60 29            [24]  827 	jz	00106$
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004448 74 04            [12]  829 	mov	a,#0x04
      00444A 12 47 78         [24]  830 	lcall	_ak820_outline_0015
      00444D 60 1E            [24]  831 	jz	00102$
      00444F BD FF 02         [24]  832 	cjne	r5,#0xff,00218$
      004452 80 19            [24]  833 	sjmp	00102$
      004454                        834 00218$:
      004454 74 05            [12]  835 	mov	a,#0x05
      004456 12 47 78         [24]  836 	lcall	_ak820_outline_0015
      004459 70 12            [24]  837 	jnz	00102$
      00445B ED               [12]  838 	mov	a,r5
      00445C 24 9A            [12]  839 	add	a, #_source_state
      00445E FB               [12]  840 	mov	r3,a
      00445F E4               [12]  841 	clr	a
      004460 34 05            [12]  842 	addc	a, #(_source_state >> 8)
      004462 12 47 B7         [24]  843 	lcall	_ak820_outline_0053
      004465 53 02 FD         [24]  844 	anl	ar2,#0xfd
      004468 12 33 FC         [24]  845 	lcall	_ak820_outline_0120
      00446B EA               [12]  846 	mov	a,r2
      00446C F0               [24]  847 	movx	@dptr,a
      00446D                        848 00102$:
                                    849 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      00446D 75 82 00         [24]  850 	mov	dpl, #0x00
      004470 22               [24]  851 	ret
      004471                        852 00106$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004471 90 0D 7D         [24]  854 	mov	dptr,#_pending
      004474 E0               [24]  855 	movx	a,@dptr
      004475 FC               [12]  856 	mov	r4,a
      004476 BC FF 02         [24]  857 	cjne	r4,#0xff,00220$
      004479 80 3B            [24]  858 	sjmp	00108$
      00447B                        859 00220$:
      00447B 12 37 F1         [24]  860 	lcall	_ak820_outline_0032
      00447E FA               [12]  861 	mov	r2,a
      00447F A3               [24]  862 	inc	dptr
      004480 E0               [24]  863 	movx	a,@dptr
      004481 FB               [12]  864 	mov	r3,a
      004482 90 06 1C         [24]  865 	mov	dptr,#_pending_time
      004485 12 38 2A         [24]  866 	lcall	_ak820_outline_0094
      004488 EA               [12]  867 	mov	a,r2
      004489 C3               [12]  868 	clr	c
      00448A 98               [12]  869 	subb	a,r0
      00448B FA               [12]  870 	mov	r2,a
      00448C EB               [12]  871 	mov	a,r3
      00448D 99               [12]  872 	subb	a,r1
      00448E FB               [12]  873 	mov	r3,a
      00448F C3               [12]  874 	clr	c
      004490 EA               [12]  875 	mov	a,r2
      004491 94 C8            [12]  876 	subb	a,#0xc8
      004493 EB               [12]  877 	mov	a,r3
      004494 94 00            [12]  878 	subb	a,#0x00
      004496 50 17            [24]  879 	jnc	00107$
                                    880 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004498 74 04            [12]  881 	mov	a,#0x04
      00449A 12 47 AC         [24]  882 	lcall	_ak820_outline_0044
      00449D 60 17            [24]  883 	jz	00108$
      00449F 12 37 AC         [24]  884 	lcall	_ak820_outline_0005
      0044A2 60 12            [24]  885 	jz	00108$
      0044A4 BD FF 02         [24]  886 	cjne	r5,#0xff,00224$
      0044A7 80 06            [24]  887 	sjmp	00107$
      0044A9                        888 00224$:
      0044A9 ED               [12]  889 	mov	a,r5
      0044AA B5 04 02         [24]  890 	cjne	a,ar4,00225$
      0044AD 80 07            [24]  891 	sjmp	00108$
      0044AF                        892 00225$:
      0044AF                        893 00107$:
      0044AF C0 05            [24]  894 	push	ar5
      0044B1 12 43 EC         [24]  895 	lcall	_commit_pending
      0044B4 D0 05            [24]  896 	pop	ar5
      0044B6                        897 00108$:
                                    898 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044B6 90 06 27         [24]  899 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0044B9 12 37 F9         [24]  900 	lcall	_ak820_outline_0049
      0044BC 74 04            [12]  901 	mov	a,#0x04
      0044BE 12 47 78         [24]  902 	lcall	_ak820_outline_0015
      0044C1 60 03            [24]  903 	jz	00114$
      0044C3 BD FF 04         [24]  904 	cjne	r5,#0xff,00115$
      0044C6                        905 00114$:
      0044C6 75 82 01         [24]  906 	mov	dpl, #0x01
      0044C9 22               [24]  907 	ret
      0044CA                        908 00115$:
                                    909 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044CA ED               [12]  910 	mov	a,r5
      0044CB 12 47 CC         [24]  911 	lcall	_ak820_outline_0075
      0044CE 30 E1 13         [24]  912 	jnb	acc.1,00120$
                                    913 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044D1 74 05            [12]  914 	mov	a,#0x05
      0044D3 2E               [12]  915 	add	a, r6
      0044D4 12 37 D7         [24]  916 	lcall	_ak820_outline_0012
      0044D7 70 07            [24]  917 	jnz	00118$
      0044D9 74 FD            [12]  918 	mov	a,#0xfd
      0044DB 5B               [12]  919 	anl	a,r3
      0044DC 12 38 53         [24]  920 	lcall	_ak820_outline_0117
      0044DF F0               [24]  921 	movx	@dptr,a
      0044E0                        922 00118$:
                                    923 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      0044E0 75 82 00         [24]  924 	mov	dpl, #0x00
      0044E3 22               [24]  925 	ret
      0044E4                        926 00120$:
                                    927 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      0044E4 12 42 BE         [24]  928 	lcall	_ak820_outline_0010
      0044E7 E0               [24]  929 	movx	a,@dptr
      0044E8 FF               [12]  930 	mov	r7,a
      0044E9 8B 06            [24]  931 	mov	ar6,r3
      0044EB 53 06 01         [24]  932 	anl	ar6,#0x01
      0044EE EE               [12]  933 	mov	a,r6
      0044EF B4 01 00         [24]  934 	cjne	a,#0x01,00231$
      0044F2                        935 00231$:
      0044F2 B3               [12]  936 	cpl	c
      0044F3 92 0C            [24]  937 	mov	_ak820_tapping_before_sloc0_1_0,c
      0044F5 8F F0            [24]  938 	mov	b,r7
      0044F7 E4               [12]  939 	clr	a
      0044F8 33               [12]  940 	rlc	a
      0044F9 B5 F0 04         [24]  941 	cjne	a,b,00122$
      0044FC 75 82 00         [24]  942 	mov	dpl, #0x00
      0044FF 22               [24]  943 	ret
      004500                        944 00122$:
                                    945 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004500 63 03 01         [24]  946 	xrl	ar3,#0x01
      004503 12 38 53         [24]  947 	lcall	_ak820_outline_0117
      004506 EB               [12]  948 	mov	a,r3
      004507 F0               [24]  949 	movx	@dptr,a
                                    950 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004508 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      00450B 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    956 ;------------------------------------------------------------
                                    957 ;sloc0         Allocated with name '_ak820_tapping_process_sloc0_1_0'
                                    958 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    959 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    960 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    961 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    962 ;------------------------------------------------------------
                                    963 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    964 ;	-----------------------------------------
                                    965 ;	 function ak820_tapping_process
                                    966 ;	-----------------------------------------
      00450C                        967 _ak820_tapping_process:
      00450C 12 38 47         [24]  968 	lcall	_ak820_outline_0103
      00450F 90 06 29         [24]  969 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004512 12 38 42         [24]  970 	lcall	_ak820_outline_0102
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004515 90 06 29         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004518 12 37 F9         [24]  973 	lcall	_ak820_outline_0049
      00451B 74 04            [12]  974 	mov	a,#0x04
      00451D 12 47 6D         [24]  975 	lcall	_ak820_outline_0011
      004520 70 04            [24]  976 	jnz	00102$
      004522 75 82 01         [24]  977 	mov	dpl, #0x01
      004525 22               [24]  978 	ret
      004526                        979 00102$:
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004526 8E 04            [24]  981 	mov	ar4,r6
      004528 8F 05            [24]  982 	mov	ar5,r7
      00452A 12 47 92         [24]  983 	lcall	_ak820_outline_0022
      00452D C0 07            [24]  984 	push	ar7
      00452F C0 06            [24]  985 	push	ar6
      004531 12 B5 58         [24]  986 	lcall	___memcpy
      004534 12 43 5A         [24]  987 	lcall	_ak820_tapping_source
      004537 AD 82            [24]  988 	mov	r5, dpl
      004539 D0 06            [24]  989 	pop	ar6
      00453B D0 07            [24]  990 	pop	ar7
                                    991 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      00453D BD FF 04         [24]  992 	cjne	r5,#0xff,00104$
      004540 75 82 01         [24]  993 	mov	dpl, #0x01
      004543 22               [24]  994 	ret
      004544                        995 00104$:
                                    996 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004544 74 07            [12]  997 	mov	a,#0x07
      004546 12 37 E9         [24]  998 	lcall	_ak820_outline_0019
      004549 E0               [24]  999 	movx	a,@dptr
      00454A F5 15            [12] 1000 	mov	_ak820_tapping_process_sloc0_1_0,a
      00454C A3               [24] 1001 	inc	dptr
      00454D E0               [24] 1002 	movx	a,@dptr
      00454E F5 16            [12] 1003 	mov	(_ak820_tapping_process_sloc0_1_0 + 1),a
                                   1004 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004550 AC 16            [24] 1005 	mov	r4,(_ak820_tapping_process_sloc0_1_0 + 1)
                                   1006 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004552 BC 20 00         [24] 1007 	cjne	r4,#0x20,00189$
      004555                       1008 00189$:
      004555 40 05            [24] 1009 	jc	00105$
      004557 BC 50 00         [24] 1010 	cjne	r4,#0x50,00191$
      00455A                       1011 00191$:
      00455A 40 04            [24] 1012 	jc	00106$
      00455C                       1013 00105$:
      00455C 75 82 01         [24] 1014 	mov	dpl, #0x01
      00455F 22               [24] 1015 	ret
      004560                       1016 00106$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004560 BC 40 00         [24] 1018 	cjne	r4,#0x40,00193$
      004563                       1019 00193$:
      004563 40 0C            [24] 1020 	jc	00109$
      004565 53 04 0F         [24] 1021 	anl	ar4,#0x0f
      004568 BC 06 00         [24] 1022 	cjne	r4,#0x06,00195$
      00456B                       1023 00195$:
      00456B 40 04            [24] 1024 	jc	00109$
      00456D 75 82 00         [24] 1025 	mov	dpl, #0x00
      004570 22               [24] 1026 	ret
      004571                       1027 00109$:
                                   1028 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004571 90 06 29         [24] 1029 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004574 12 38 3C         [24] 1030 	lcall	_ak820_outline_0098
      004577 74 05            [12] 1031 	mov	a,#0x05
      004579 2B               [12] 1032 	add	a, r3
      00457A F9               [12] 1033 	mov	r1,a
      00457B E4               [12] 1034 	clr	a
      00457C 3C               [12] 1035 	addc	a, r4
      00457D FA               [12] 1036 	mov	r2,a
      00457E 12 43 3F         [24] 1037 	lcall	_ak820_outline_0151
      004581 E0               [24] 1038 	movx	a,@dptr
      004582 60 22            [24] 1039 	jz	00119$
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004584 90 0D 7D         [24] 1041 	mov	dptr,#_pending
      004587 ED               [12] 1042 	mov	a,r5
      004588 12 47 E2         [24] 1043 	lcall	_ak820_outline_0119
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00458B A3               [24] 1045 	inc	dptr
      00458C A3               [24] 1046 	inc	dptr
      00458D E0               [24] 1047 	movx	a,@dptr
      00458E F8               [12] 1048 	mov	r0,a
      00458F A3               [24] 1049 	inc	dptr
      004590 E0               [24] 1050 	movx	a,@dptr
      004591 FF               [12] 1051 	mov	r7,a
      004592 90 06 1C         [24] 1052 	mov	dptr,#_pending_time
      004595 E8               [12] 1053 	mov	a,r0
      004596 12 38 42         [24] 1054 	lcall	_ak820_outline_0102
                                   1055 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004599 90 06 1E         [24] 1056 	mov	dptr,#_pending_code
      00459C E5 15            [12] 1057 	mov	a,_ak820_tapping_process_sloc0_1_0
      00459E F0               [24] 1058 	movx	@dptr,a
      00459F E5 16            [12] 1059 	mov	a,(_ak820_tapping_process_sloc0_1_0 + 1)
      0045A1 A3               [24] 1060 	inc	dptr
      0045A2 F0               [24] 1061 	movx	@dptr,a
      0045A3 02 46 12         [24] 1062 	ljmp	00120$
      0045A6                       1063 00119$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      0045A6 90 0D 7D         [24] 1065 	mov	dptr,#_pending
      0045A9 E0               [24] 1066 	movx	a,@dptr
      0045AA FF               [12] 1067 	mov	r7,a
      0045AB ED               [12] 1068 	mov	a,r5
      0045AC B5 07 3E         [24] 1069 	cjne	a,ar7,00116$
                                   1070 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      0045AF 12 47 E8         [24] 1071 	lcall	_ak820_outline_0148
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      0045B2 74 07            [12] 1073 	mov	a,#0x07
      0045B4 12 47 DA         [24] 1074 	lcall	_ak820_outline_0113
      0045B7 AE 15            [24] 1075 	mov	r6,_ak820_tapping_process_sloc0_1_0
      0045B9 7F 00            [12] 1076 	mov	r7,#0x00
      0045BB 12 47 BF         [24] 1077 	lcall	_ak820_outline_0056
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      0045BE C3               [12] 1079 	clr	c
      0045BF 04               [12] 1080 	inc	a
      0045C0 9E               [12] 1081 	subb	a,r6
      0045C1 50 4F            [24] 1082 	jnc	00120$
                                   1083 ;	free result
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      0045C3 74 06            [12] 1085 	mov	a,#0x06
      0045C5 12 47 DA         [24] 1086 	lcall	_ak820_outline_0113
      0045C8 E0               [24] 1087 	movx	a,@dptr
      0045C9 54 0F            [12] 1088 	anl	a,#0x0f
      0045CB 44 10            [12] 1089 	orl	a,#0x10
      0045CD F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      0045CE 12 43 3F         [24] 1092 	lcall	_ak820_outline_0151
      0045D1 74 01            [12] 1093 	mov	a,#0x01
      0045D3 12 47 E2         [24] 1094 	lcall	_ak820_outline_0119
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      0045D6 12 6F AF         [24] 1096 	lcall	_process_record
                                   1097 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      0045D9 90 06 29         [24] 1098 	mov	dptr,#_ak820_tapping_process_record_10000_622
      0045DC 12 37 A2         [24] 1099 	lcall	_ak820_outline_0004
      0045DF A3               [24] 1100 	inc	dptr
      0045E0 A3               [24] 1101 	inc	dptr
      0045E1 A3               [24] 1102 	inc	dptr
      0045E2 A3               [24] 1103 	inc	dptr
      0045E3 A3               [24] 1104 	inc	dptr
      0045E4 E4               [12] 1105 	clr	a
      0045E5 12 42 F4         [24] 1106 	lcall	_ak820_outline_0058
                                   1107 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      0045E8 12 6F AF         [24] 1108 	lcall	_process_record
      0045EB 80 25            [24] 1109 	sjmp	00120$
      0045ED                       1110 00116$:
                                   1111 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      0045ED ED               [12] 1112 	mov	a,r5
      0045EE 24 9A            [12] 1113 	add	a, #_source_state
      0045F0 FE               [12] 1114 	mov	r6,a
      0045F1 E4               [12] 1115 	clr	a
      0045F2 34 05            [12] 1116 	addc	a, #(_source_state >> 8)
      0045F4 FF               [12] 1117 	mov	r7,a
      0045F5 12 38 36         [24] 1118 	lcall	_ak820_outline_0096
      0045F8 FD               [12] 1119 	mov	r5,a
      0045F9 30 E2 16         [24] 1120 	jnb	acc.2,00120$
                                   1121 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0045FC 53 05 FB         [24] 1122 	anl	ar5,#0xfb
      0045FF 12 43 1F         [24] 1123 	lcall	_ak820_outline_0116
      004602 ED               [12] 1124 	mov	a,r5
      004603 F0               [24] 1125 	movx	@dptr,a
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004604 90 06 22         [24] 1127 	mov	dptr,#_hold_PARM_2
      004607 E4               [12] 1128 	clr	a
      004608 F0               [24] 1129 	movx	@dptr,a
      004609 85 15 82         [24] 1130 	mov	dpl, _ak820_tapping_process_sloc0_1_0
      00460C 85 16 83         [24] 1131 	mov	dph, (_ak820_tapping_process_sloc0_1_0 + 1)
      00460F 12 43 94         [24] 1132 	lcall	_hold
      004612                       1133 00120$:
                                   1134 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004612 75 82 00         [24] 1135 	mov	dpl, #0x00
                                   1136 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004615 22               [24] 1137 	ret
                                   1138 ;------------------------------------------------------------
                                   1139 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1140 ;------------------------------------------------------------
                                   1141 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_638'
                                   1142 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_639'
                                   1143 ;------------------------------------------------------------
                                   1144 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1145 ;	-----------------------------------------
                                   1146 ;	 function ak820_tapping_cancel
                                   1147 ;	-----------------------------------------
      004616                       1148 _ak820_tapping_cancel:
                                   1149 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004616 12 47 E8         [24] 1150 	lcall	_ak820_outline_0148
                                   1151 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004619 7F 00            [12] 1152 	mov	r7,#0x00
      00461B                       1153 00103$:
      00461B BF 82 00         [24] 1154 	cjne	r7,#0x82,00122$
      00461E                       1155 00122$:
      00461E 50 16            [24] 1156 	jnc	00105$
                                   1157 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004620 12 47 83         [24] 1158 	lcall	_ak820_outline_0017
                                   1159 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004623 74 02            [12] 1160 	mov	a,#0x02
      004625 5C               [12] 1161 	anl	a,r4
      004626 FB               [12] 1162 	mov	r3,a
      004627 53 04 01         [24] 1163 	anl	ar4,#0x01
      00462A EC               [12] 1164 	mov	a,r4
      00462B 2C               [12] 1165 	add	a,r4
      00462C 42 03            [12] 1166 	orl	ar3,a
      00462E 12 38 5D         [24] 1167 	lcall	_ak820_outline_0130
      004631 EB               [12] 1168 	mov	a,r3
      004632 F0               [24] 1169 	movx	@dptr,a
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004633 0F               [12] 1171 	inc	r7
      004634 80 E5            [24] 1172 	sjmp	00103$
      004636                       1173 00105$:
                                   1174 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004636 22               [24] 1175 	ret
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1178 ;------------------------------------------------------------
                                   1179 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1180 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1181 ;code          Allocated with name '_ak820_oneshot_process_code_10000_640'
                                   1182 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_641'
                                   1183 ;i             Allocated with name '_ak820_oneshot_process_i_40000_655'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function ak820_oneshot_process
                                   1188 ;	-----------------------------------------
      004637                       1189 _ak820_oneshot_process:
      004637 12 38 47         [24] 1190 	lcall	_ak820_outline_0103
      00463A 90 06 2F         [24] 1191 	mov	dptr,#_ak820_oneshot_process_code_10000_640
      00463D 12 38 42         [24] 1192 	lcall	_ak820_outline_0102
                                   1193 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004640 90 06 2D         [24] 1194 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004643 E0               [24] 1195 	movx	a,@dptr
      004644 FF               [12] 1196 	mov	r7,a
      004645 BF FF 02         [24] 1197 	cjne	r7,#0xff,00248$
      004648 80 07            [24] 1198 	sjmp	00101$
      00464A                       1199 00248$:
      00464A 12 9F 4B         [24] 1200 	lcall	_get_repeat_key_count
      00464D E5 82            [12] 1201 	mov	a, dpl
      00464F 60 04            [24] 1202 	jz	00102$
      004651                       1203 00101$:
      004651 75 82 01         [24] 1204 	mov	dpl, #0x01
      004654 22               [24] 1205 	ret
      004655                       1206 00102$:
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004655 90 06 2F         [24] 1208 	mov	dptr,#_ak820_oneshot_process_code_10000_640
      004658 E0               [24] 1209 	movx	a,@dptr
      004659 FD               [12] 1210 	mov	r5,a
      00465A A3               [24] 1211 	inc	dptr
      00465B E0               [24] 1212 	movx	a,@dptr
      00465C FB               [12] 1213 	mov	r3,a
      00465D BB 52 02         [24] 1214 	cjne	r3,#0x52,00250$
      004660 80 03            [24] 1215 	sjmp	00251$
      004662                       1216 00250$:
      004662 02 47 07         [24] 1217 	ljmp	00116$
      004665                       1218 00251$:
      004665 8D 04            [24] 1219 	mov	ar4,r5
      004667 53 04 E0         [24] 1220 	anl	ar4,#0xe0
      00466A BC A0 02         [24] 1221 	cjne	r4,#0xa0,00252$
      00466D 80 03            [24] 1222 	sjmp	00253$
      00466F                       1223 00252$:
      00466F 02 47 07         [24] 1224 	ljmp	00116$
      004672                       1225 00253$:
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004672 8D 04            [24] 1227 	mov	ar4,r5
      004674 53 04 0F         [24] 1228 	anl	ar4,#0x0f
      004677 90 06 31         [24] 1229 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      00467A EC               [12] 1230 	mov	a,r4
      00467B F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      00467C ED               [12] 1233 	mov	a,r5
      00467D 30 E4 08         [24] 1234 	jnb	acc.4,00105$
      004680 EC               [12] 1235 	mov	a,r4
      004681 C4               [12] 1236 	swap	a
      004682 54 F0            [12] 1237 	anl	a,#0xf0
      004684 90 06 31         [24] 1238 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      004687 F0               [24] 1239 	movx	@dptr,a
      004688                       1240 00105$:
                                   1241 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004688 90 06 2E         [24] 1242 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00468B E0               [24] 1243 	movx	a,@dptr
      00468C 60 2D            [24] 1244 	jz	00113$
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      00468E 12 47 83         [24] 1246 	lcall	_ak820_outline_0017
      004691 43 04 08         [24] 1247 	orl	ar4,#0x08
      004694 12 42 FA         [24] 1248 	lcall	_ak820_outline_0062
                                   1249 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004697 53 04 EF         [24] 1250 	anl	ar4,#0xef
      00469A 12 42 FA         [24] 1251 	lcall	_ak820_outline_0062
                                   1252 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      00469D 90 0D 7E         [24] 1253 	mov	dptr,#_ak820_oneshot_target
      0046A0 E0               [24] 1254 	movx	a,@dptr
      0046A1 FC               [12] 1255 	mov	r4,a
      0046A2 BC FF 02         [24] 1256 	cjne	r4,#0xff,00256$
      0046A5 80 09            [24] 1257 	sjmp	00107$
      0046A7                       1258 00256$:
      0046A7 12 47 C5         [24] 1259 	lcall	_ak820_outline_0072
      0046AA 43 04 10         [24] 1260 	orl	ar4,#0x10
      0046AD 12 42 FA         [24] 1261 	lcall	_ak820_outline_0062
      0046B0                       1262 00107$:
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      0046B0 90 06 31         [24] 1264 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      0046B3 E0               [24] 1265 	movx	a,@dptr
      0046B4 F5 82            [12] 1266 	mov	dpl,a
      0046B6 12 74 E4         [24] 1267 	lcall	_register_mods
      0046B9 80 48            [24] 1268 	sjmp	00114$
      0046BB                       1269 00113$:
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      0046BB 12 47 83         [24] 1271 	lcall	_ak820_outline_0017
      0046BE 30 E3 42         [24] 1272 	jnb	acc.3,00114$
                                   1273 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0046C1 EC               [12] 1274 	mov	a,r4
      0046C2 20 E4 24         [24] 1275 	jb	acc.4,00109$
                                   1276 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      0046C5 90 06 2B         [24] 1277 	mov	dptr,#_ak820_oneshot_mods
      0046C8 E0               [24] 1278 	movx	a,@dptr
      0046C9 F4               [12] 1279 	cpl	a
      0046CA FC               [12] 1280 	mov	r4,a
      0046CB 90 06 31         [24] 1281 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      0046CE E0               [24] 1282 	movx	a,@dptr
      0046CF FB               [12] 1283 	mov	r3,a
      0046D0 52 04            [12] 1284 	anl	ar4,a
      0046D2 8C 82            [24] 1285 	mov	dpl, r4
      0046D4 C0 06            [24] 1286 	push	ar6
      0046D6 C0 05            [24] 1287 	push	ar5
      0046D8 C0 03            [24] 1288 	push	ar3
      0046DA 12 7B 2D         [24] 1289 	lcall	_add_owned_mods
      0046DD D0 03            [24] 1290 	pop	ar3
      0046DF D0 05            [24] 1291 	pop	ar5
      0046E1 D0 06            [24] 1292 	pop	ar6
                                   1293 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      0046E3 90 06 2B         [24] 1294 	mov	dptr,#_ak820_oneshot_mods
      0046E6 E0               [24] 1295 	movx	a,@dptr
      0046E7 4B               [12] 1296 	orl	a,r3
      0046E8 F0               [24] 1297 	movx	@dptr,a
      0046E9                       1298 00109$:
                                   1299 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      0046E9 90 06 31         [24] 1300 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      0046EC E0               [24] 1301 	movx	a,@dptr
      0046ED F5 82            [12] 1302 	mov	dpl,a
      0046EF C0 06            [24] 1303 	push	ar6
      0046F1 C0 05            [24] 1304 	push	ar5
      0046F3 12 74 F8         [24] 1305 	lcall	_unregister_mods
      0046F6 D0 05            [24] 1306 	pop	ar5
      0046F8 D0 06            [24] 1307 	pop	ar6
                                   1308 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0046FA 12 47 C5         [24] 1309 	lcall	_ak820_outline_0072
      0046FD 53 04 E7         [24] 1310 	anl	ar4,#0xe7
      004700 12 42 FA         [24] 1311 	lcall	_ak820_outline_0062
      004703                       1312 00114$:
                                   1313 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004703 75 82 00         [24] 1314 	mov	dpl, #0x00
      004706 22               [24] 1315 	ret
      004707                       1316 00116$:
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004707 90 06 2E         [24] 1318 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00470A E0               [24] 1319 	movx	a,@dptr
      00470B 60 5C            [24] 1320 	jz	00124$
      00470D 90 06 2F         [24] 1321 	mov	dptr,#_ak820_oneshot_process_code_10000_640
      004710 12 43 0D         [24] 1322 	lcall	_ak820_outline_0090
      004713 C3               [12] 1323 	clr	c
      004714 74 01            [12] 1324 	mov	a,#0x01
      004716 9D               [12] 1325 	subb	a,r5
      004717 E4               [12] 1326 	clr	a
      004718 9E               [12] 1327 	subb	a,r6
      004719 50 4E            [24] 1328 	jnc	00124$
                                   1329 ;	free result
                                   1330 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      00471B C3               [12] 1331 	clr	c
      00471C ED               [12] 1332 	mov	a,r5
      00471D 94 E0            [12] 1333 	subb	a,#0xe0
      00471F EE               [12] 1334 	mov	a,r6
      004720 94 00            [12] 1335 	subb	a,#0x00
      004722 40 07            [24] 1336 	jc	00129$
      004724 74 E7            [12] 1337 	mov	a,#0xe7
      004726 9D               [12] 1338 	subb	a,r5
      004727 E4               [12] 1339 	clr	a
      004728 9E               [12] 1340 	subb	a,r6
      004729 50 3E            [24] 1341 	jnc	00124$
                                   1342 ;	free result
      00472B                       1343 00129$:
                                   1344 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      00472B 74 AE            [12] 1345 	mov	a,#0x100 - 0x52
      00472D 2E               [12] 1346 	add	a,r6
      00472E 50 09            [24] 1347 	jnc	00165$
      004730 C3               [12] 1348 	clr	c
      004731 74 DF            [12] 1349 	mov	a,#0xdf
      004733 9D               [12] 1350 	subb	a,r5
      004734 74 52            [12] 1351 	mov	a,#0x52
      004736 9E               [12] 1352 	subb	a,r6
      004737 50 30            [24] 1353 	jnc	00124$
                                   1354 ;	free result
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004739                       1356 00165$:
      004739 7E 00            [12] 1357 	mov	r6,#0x00
      00473B                       1358 00131$:
      00473B BE 82 00         [24] 1359 	cjne	r6,#0x82,00265$
      00473E                       1360 00265$:
      00473E 50 12            [24] 1361 	jnc	00120$
                                   1362 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004740 EE               [12] 1363 	mov	a,r6
      004741 12 47 CC         [24] 1364 	lcall	_ak820_outline_0075
      004744 30 E3 08         [24] 1365 	jnb	acc.3,00132$
      004747 43 03 10         [24] 1366 	orl	ar3,#0x10
      00474A 12 38 53         [24] 1367 	lcall	_ak820_outline_0117
      00474D EB               [12] 1368 	mov	a,r3
      00474E F0               [24] 1369 	movx	@dptr,a
      00474F                       1370 00132$:
                                   1371 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      00474F 0E               [12] 1372 	inc	r6
      004750 80 E9            [24] 1373 	sjmp	00131$
      004752                       1374 00120$:
                                   1375 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004752 90 06 2B         [24] 1376 	mov	dptr,#_ak820_oneshot_mods
      004755 E0               [24] 1377 	movx	a,@dptr
      004756 FE               [12] 1378 	mov	r6,a
      004757 E0               [24] 1379 	movx	a,@dptr
      004758 60 0F            [24] 1380 	jz	00124$
                                   1381 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      00475A 90 06 2C         [24] 1382 	mov	dptr,#_ak820_oneshot_consumed
      00475D EE               [12] 1383 	mov	a,r6
      00475E F0               [24] 1384 	movx	@dptr,a
                                   1385 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      00475F 90 0D 7E         [24] 1386 	mov	dptr,#_ak820_oneshot_target
      004762 EF               [12] 1387 	mov	a,r7
      004763 F0               [24] 1388 	movx	@dptr,a
                                   1389 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004764 90 06 2B         [24] 1390 	mov	dptr,#_ak820_oneshot_mods
      004767 E4               [12] 1391 	clr	a
      004768 F0               [24] 1392 	movx	@dptr,a
      004769                       1393 00124$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004769 75 82 01         [24] 1395 	mov	dpl, #0x01
                                   1396 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      00476C 22               [24] 1397 	ret
                                   1398 	.area CSEG    (CODE)
                                   1399 	.area CONST   (CODE)
                                   1400 	.area XINIT   (CODE)
      00BE18                       1401 __xinit__pending:
      00BE18 FF                    1402 	.db #0xff	; 255
      00BE19                       1403 __xinit__ak820_oneshot_target:
      00BE19 FF                    1404 	.db #0xff	; 255
                                   1405 	.area CABS    (ABS,CODE)
                                   1406 
                                   1407 ; Experimental exact instruction outlining.
                                   1408 	.globl _ak820_outline_0004
                                   1409 	.globl _ak820_outline_0005
                                   1410 	.globl _ak820_outline_0009
                                   1411 	.globl _ak820_outline_0010
                                   1412 	.globl _ak820_outline_0011
                                   1413 	.globl _ak820_outline_0012
                                   1414 	.globl _ak820_outline_0015
                                   1415 	.globl _ak820_outline_0017
                                   1416 	.globl _ak820_outline_0019
                                   1417 	.globl _ak820_outline_0022
                                   1418 	.globl _ak820_outline_0032
                                   1419 	.globl _ak820_outline_0044
                                   1420 	.globl _ak820_outline_0049
                                   1421 	.globl _ak820_outline_0053
                                   1422 	.globl _ak820_outline_0056
                                   1423 	.globl _ak820_outline_0058
                                   1424 	.globl _ak820_outline_0062
                                   1425 	.globl _ak820_outline_0072
                                   1426 	.globl _ak820_outline_0075
                                   1427 	.globl _ak820_outline_0090
                                   1428 	.globl _ak820_outline_0094
                                   1429 	.globl _ak820_outline_0096
                                   1430 	.globl _ak820_outline_0098
                                   1431 	.globl _ak820_outline_0102
                                   1432 	.globl _ak820_outline_0103
                                   1433 	.globl _ak820_outline_0113
                                   1434 	.globl _ak820_outline_0116
                                   1435 	.globl _ak820_outline_0117
                                   1436 	.globl _ak820_outline_0119
                                   1437 	.globl _ak820_outline_0120
                                   1438 	.globl _ak820_outline_0130
                                   1439 	.globl _ak820_outline_0148
                                   1440 	.globl _ak820_outline_0151
                                   1441 	.globl _ak820_outline_0152
                                   1442 	.globl _ak820_outline_0183
                                   1443 
                                   1444 	.area CSEG (CODE)
                                   1445 ; function ak820_outline_0011
      00476D                       1446 _ak820_outline_0011:
      00476D 2E               [12] 1447 	add	a,r6
      00476E FC               [12] 1448 	mov	r4,a
      00476F E4               [12] 1449 	clr	a
      004770 3F               [12] 1450 	addc	a,r7
      004771 FD               [12] 1451 	mov	r5,a
      004772 8C 82            [24] 1452 	mov	dpl,r4
      004774 8D 83            [24] 1453 	mov	dph,r5
      004776 E0               [24] 1454 	movx	a,@dptr
      004777 22               [24] 1455 	ret
                                   1456 
                                   1457 	.area CSEG (CODE)
                                   1458 ; function ak820_outline_0015
      004778                       1459 _ak820_outline_0015:
      004778 2E               [12] 1460 	add	a,r6
      004779 FB               [12] 1461 	mov	r3,a
      00477A E4               [12] 1462 	clr	a
      00477B 3F               [12] 1463 	addc	a,r7
      00477C FC               [12] 1464 	mov	r4,a
      00477D 8B 82            [24] 1465 	mov	dpl,r3
      00477F 8C 83            [24] 1466 	mov	dph,r4
      004781 E0               [24] 1467 	movx	a,@dptr
      004782 22               [24] 1468 	ret
                                   1469 
                                   1470 	.area CSEG (CODE)
                                   1471 ; function ak820_outline_0017
      004783                       1472 _ak820_outline_0017:
      004783 EF               [12] 1473 	mov	a,r7
      004784 24 9A            [12] 1474 	add	a,#_source_state
      004786 FD               [12] 1475 	mov	r5,a
      004787 E4               [12] 1476 	clr	a
      004788 34 05            [12] 1477 	addc	a,#(_source_state>>8)
      00478A FE               [12] 1478 	mov	r6,a
      00478B 8D 82            [24] 1479 	mov	dpl,r5
      00478D 8E 83            [24] 1480 	mov	dph,r6
      00478F E0               [24] 1481 	movx	a,@dptr
      004790 FC               [12] 1482 	mov	r4,a
      004791 22               [24] 1483 	ret
                                   1484 
                                   1485 	.area CSEG (CODE)
                                   1486 ; function ak820_outline_0022
      004792                       1487 _ak820_outline_0022:
      004792 90 0D 6D         [24] 1488 	mov	dptr,#___memcpy_PARM_2
      004795 EC               [12] 1489 	mov	a,r4
      004796 F0               [24] 1490 	movx	@dptr,a
      004797 ED               [12] 1491 	mov	a,r5
      004798 A3               [24] 1492 	inc	dptr
      004799 F0               [24] 1493 	movx	@dptr,a
      00479A E4               [12] 1494 	clr	a
      00479B A3               [24] 1495 	inc	dptr
      00479C F0               [24] 1496 	movx	@dptr,a
      00479D 90 0D 70         [24] 1497 	mov	dptr,#___memcpy_PARM_3
      0047A0 74 02            [12] 1498 	mov	a,#0x02
      0047A2 F0               [24] 1499 	movx	@dptr,a
      0047A3 E4               [12] 1500 	clr	a
      0047A4 A3               [24] 1501 	inc	dptr
      0047A5 F0               [24] 1502 	movx	@dptr,a
      0047A6 90 06 20         [24] 1503 	mov	dptr,#_ak820_tapping_source_PARM_1
      0047A9 F5 F0            [12] 1504 	mov	b,a
      0047AB 22               [24] 1505 	ret
                                   1506 
                                   1507 	.area CSEG (CODE)
                                   1508 ; function ak820_outline_0044
      0047AC                       1509 _ak820_outline_0044:
      0047AC 2E               [12] 1510 	add	a,r6
      0047AD FA               [12] 1511 	mov	r2,a
      0047AE E4               [12] 1512 	clr	a
      0047AF 3F               [12] 1513 	addc	a,r7
      0047B0 FB               [12] 1514 	mov	r3,a
      0047B1 8A 82            [24] 1515 	mov	dpl,r2
      0047B3 8B 83            [24] 1516 	mov	dph,r3
      0047B5 E0               [24] 1517 	movx	a,@dptr
      0047B6 22               [24] 1518 	ret
                                   1519 
                                   1520 	.area CSEG (CODE)
                                   1521 ; function ak820_outline_0053
      0047B7                       1522 _ak820_outline_0053:
      0047B7 FC               [12] 1523 	mov	r4,a
      0047B8 8B 82            [24] 1524 	mov	dpl,r3
      0047BA 8C 83            [24] 1525 	mov	dph,r4
      0047BC E0               [24] 1526 	movx	a,@dptr
      0047BD FA               [12] 1527 	mov	r2,a
      0047BE 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0056
      0047BF                       1532 _ak820_outline_0056:
      0047BF EE               [12] 1533 	mov	a,r6
      0047C0 F0               [24] 1534 	movx	@dptr,a
      0047C1 EF               [12] 1535 	mov	a,r7
      0047C2 A3               [24] 1536 	inc	dptr
      0047C3 F0               [24] 1537 	movx	@dptr,a
      0047C4 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0072
      0047C5                       1542 _ak820_outline_0072:
      0047C5 8D 82            [24] 1543 	mov	dpl,r5
      0047C7 8E 83            [24] 1544 	mov	dph,r6
      0047C9 E0               [24] 1545 	movx	a,@dptr
      0047CA FC               [12] 1546 	mov	r4,a
      0047CB 22               [24] 1547 	ret
                                   1548 
                                   1549 	.area CSEG (CODE)
                                   1550 ; function ak820_outline_0075
      0047CC                       1551 _ak820_outline_0075:
      0047CC 24 9A            [12] 1552 	add	a,#_source_state
      0047CE FC               [12] 1553 	mov	r4,a
      0047CF E4               [12] 1554 	clr	a
      0047D0 34 05            [12] 1555 	addc	a,#(_source_state>>8)
      0047D2 FD               [12] 1556 	mov	r5,a
      0047D3 8C 82            [24] 1557 	mov	dpl,r4
      0047D5 8D 83            [24] 1558 	mov	dph,r5
      0047D7 E0               [24] 1559 	movx	a,@dptr
      0047D8 FB               [12] 1560 	mov	r3,a
      0047D9 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0113
      0047DA                       1565 _ak820_outline_0113:
      0047DA 2B               [12] 1566 	add	a,r3
      0047DB F5 82            [12] 1567 	mov	dpl,a
      0047DD E4               [12] 1568 	clr	a
      0047DE 3C               [12] 1569 	addc	a,r4
      0047DF F5 83            [12] 1570 	mov	dph,a
      0047E1 22               [24] 1571 	ret
                                   1572 
                                   1573 	.area CSEG (CODE)
                                   1574 ; function ak820_outline_0119
      0047E2                       1575 _ak820_outline_0119:
      0047E2 F0               [24] 1576 	movx	@dptr,a
      0047E3 8B 82            [24] 1577 	mov	dpl,r3
      0047E5 8C 83            [24] 1578 	mov	dph,r4
      0047E7 22               [24] 1579 	ret
                                   1580 
                                   1581 	.area CSEG (CODE)
                                   1582 ; function ak820_outline_0148
      0047E8                       1583 _ak820_outline_0148:
      0047E8 90 0D 7D         [24] 1584 	mov	dptr,#_pending
      0047EB 74 FF            [12] 1585 	mov	a,#0xff
      0047ED F0               [24] 1586 	movx	@dptr,a
      0047EE 22               [24] 1587 	ret
