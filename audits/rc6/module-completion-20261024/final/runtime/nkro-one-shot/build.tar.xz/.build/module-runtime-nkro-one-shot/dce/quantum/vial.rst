                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000045                        541 _vial_handle_cmd_sloc0_1_0:
      000045                        542 	.ds 2
      000047                        543 _vial_handle_cmd_sloc1_1_0:
      000047                        544 	.ds 2
      000049                        545 _vial_handle_cmd_sloc2_1_0:
      000049                        546 	.ds 2
      00004B                        547 _vial_handle_cmd_sloc3_1_0:
      00004B                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C23                        573 _vial_unlock_timer:
      000C23                        574 	.ds 4
      000C27                        575 _vial_unlock_holding:
      000C27                        576 	.ds 1
      000C28                        577 _vial_keycode_firewall_in_10000_609:
      000C28                        578 	.ds 2
      000C2A                        579 _vial_fill_packet_PARM_2:
      000C2A                        580 	.ds 1
      000C2B                        581 _vial_fill_packet_msg_10000_612:
      000C2B                        582 	.ds 2
      000C2D                        583 _vial_handle_cmd_PARM_2:
      000C2D                        584 	.ds 1
      000C2E                        585 _vial_handle_cmd_data_10000_617:
      000C2E                        586 	.ds 3
      000C31                        587 _vial_handle_cmd_entry_70000_645:
      000C31                        588 	.ds 10
      000C3B                        589 _vial_handle_cmd_entry_70000_646:
      000C3B                        590 	.ds 10
      000C45                        591 _g_vial_magic_keycode_override::
      000C45                        592 	.ds 2
      000C47                        593 _vial_keycode_down_keycode_10000_648:
      000C47                        594 	.ds 2
      000C49                        595 _vial_keycode_down_dummy_event_30000_655:
      000C49                        596 	.ds 6
      000C4F                        597 _vial_keycode_up_keycode_10000_656:
      000C4F                        598 	.ds 2
      000C51                        599 _vial_keycode_up_dummy_event_30000_663:
      000C51                        600 	.ds 6
      000C57                        601 _vial_keycode_tap_keycode_10000_664:
      000C57                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000DED                        611 _vial_unlocked::
      000DED                        612 	.ds 1
      000DEE                        613 _vial_unlock_in_progress::
      000DEE                        614 	.ds 1
      000DEF                        615 _vial_unlock_counter:
      000DEF                        616 	.ds 1
      000DF0                        617 _vial_unlock_combo_rows:
      000DF0                        618 	.ds 2
      000DF2                        619 _vial_unlock_combo_cols:
      000DF2                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00A9E2                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00A9E2 90 0D EE         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00A9E5 E0               [24]  667 	movx	a,@dptr
      00A9E6 70 01            [24]  668 	jnz	00131$
      00A9E8 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00A9E9                        671 00131$:
      00A9E9 7F 00            [12]  672 	mov	r7,#0x00
      00A9EB                        673 00115$:
      00A9EB BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00A9EE                        675 00184$:
      00A9EE 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00A9F0 EF               [12]  678 	mov	a,r7
      00A9F1 12 AF A9         [24]  679 	lcall	_ak820_outline_0124
      00A9F4 FE               [12]  680 	mov	r6,a
      00A9F5 EF               [12]  681 	mov	a,r7
      00A9F6 12 AF 9E         [24]  682 	lcall	_ak820_outline_0123
      00A9F9 90 07 58         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00A9FC F0               [24]  684 	movx	@dptr,a
      00A9FD 8E 82            [24]  685 	mov	dpl, r6
      00A9FF C0 07            [24]  686 	push	ar7
      00AA01 12 58 58         [24]  687 	lcall	_matrix_is_on
      00AA04 E5 82            [12]  688 	mov	a, dpl
      00AA06 D0 07            [24]  689 	pop	ar7
      00AA08 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00AA0A 90 0C 27         [24]  692 	mov	dptr,#_vial_unlock_holding
      00AA0D E4               [12]  693 	clr	a
      00AA0E F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AA0F 90 0D EF         [24]  696 	mov	dptr,#_vial_unlock_counter
      00AA12 74 1E            [12]  697 	mov	a,#0x1e
      00AA14 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00AA15 22               [24]  700 	ret
      00AA16                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AA16 0F               [12]  703 	inc	r7
      00AA17 80 D2            [24]  704 	sjmp	00115$
      00AA19                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00AA19 90 0C 27         [24]  707 	mov	dptr,#_vial_unlock_holding
      00AA1C E0               [24]  708 	movx	a,@dptr
      00AA1D 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00AA1F 90 0C 27         [24]  711 	mov	dptr,#_vial_unlock_holding
      00AA22 74 01            [12]  712 	mov	a,#0x01
      00AA24 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00AA25 12 48 34         [24]  715 	lcall	_timer_read32
      00AA28 12 4E 45         [24]  716 	lcall	_ak820_outline_0054
      00AA2B 90 0C 23         [24]  717 	mov	dptr,#_vial_unlock_timer
      00AA2E 12 8E 8B         [24]  718 	lcall	_ak820_outline_0007
      00AA31                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00AA31 90 0C 23         [24]  721 	mov	dptr,#_vial_unlock_timer
      00AA34 12 4E 34         [24]  722 	lcall	_ak820_outline_0052
      00AA37 12 48 8D         [24]  723 	lcall	_timer_elapsed32
      00AA3A 12 4E 45         [24]  724 	lcall	_ak820_outline_0054
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00AA3D 7B 1E            [12]  726 	mov	r3,#0x1e
      00AA3F                        727 00109$:
      00AA3F EB               [12]  728 	mov	a,r3
      00AA40 60 22            [24]  729 	jz	00111$
      00AA42 C3               [12]  730 	clr	c
      00AA43 EC               [12]  731 	mov	a,r4
      00AA44 94 64            [12]  732 	subb	a,#0x64
      00AA46 ED               [12]  733 	mov	a,r5
      00AA47 94 00            [12]  734 	subb	a,#0x00
      00AA49 EE               [12]  735 	mov	a,r6
      00AA4A 94 00            [12]  736 	subb	a,#0x00
      00AA4C EF               [12]  737 	mov	a,r7
      00AA4D 94 00            [12]  738 	subb	a,#0x00
      00AA4F 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00AA51 EC               [12]  741 	mov	a,r4
      00AA52 24 9C            [12]  742 	add	a,#0x9c
      00AA54 FC               [12]  743 	mov	r4,a
      00AA55 ED               [12]  744 	mov	a,r5
      00AA56 34 FF            [12]  745 	addc	a,#0xff
      00AA58 FD               [12]  746 	mov	r5,a
      00AA59 EE               [12]  747 	mov	a,r6
      00AA5A 34 FF            [12]  748 	addc	a,#0xff
      00AA5C FE               [12]  749 	mov	r6,a
      00AA5D EF               [12]  750 	mov	a,r7
      00AA5E 34 FF            [12]  751 	addc	a,#0xff
      00AA60 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00AA61 1B               [12]  754 	dec	r3
      00AA62 80 DB            [24]  755 	sjmp	00109$
      00AA64                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AA64 90 0D EF         [24]  758 	mov	dptr,#_vial_unlock_counter
      00AA67 EB               [12]  759 	mov	a,r3
      00AA68 F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00AA69 EB               [12]  762 	mov	a,r3
      00AA6A 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AA6C 90 0D EE         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00AA6F E4               [12]  766 	clr	a
      00AA70 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AA71 90 0D ED         [24]  769 	mov	dptr,#_vial_unlocked
      00AA74 04               [12]  770 	inc	a
      00AA75 F0               [24]  771 	movx	@dptr,a
      00AA76                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00AA76 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00AA77                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00AA77 02 35 38         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_609'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00AA7A                        795 _vial_keycode_firewall:
      00AA7A 12 38 47         [24]  796 	lcall	_ak820_outline_0103
      00AA7D 90 0C 28         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AA80 12 38 42         [24]  798 	lcall	_ak820_outline_0102
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00AA83 90 0C 28         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AA86 12 37 CD         [24]  801 	lcall	_ak820_outline_0009
      00AA89 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AA8C BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00AA8F 90 0D ED         [24]  804 	mov	dptr,#_vial_unlocked
      00AA92 E0               [24]  805 	movx	a,@dptr
      00AA93 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00AA95 90 00 00         [24]  808 	mov	dptr,#0x0000
      00AA98 22               [24]  809 	ret
      00AA99                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00AA99 12 43 1F         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00AA9C 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_612'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_614'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00AA9D                        826 _vial_fill_packet:
      00AA9D 12 38 47         [24]  827 	lcall	_ak820_outline_0103
      00AAA0 90 0C 2B         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AAA3 12 38 42         [24]  829 	lcall	_ak820_outline_0102
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AAA6 90 0C 2B         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AAA9 12 37 F9         [24]  832 	lcall	_ak820_outline_0049
      00AAAC 90 0C 2A         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00AAAF E0               [24]  834 	movx	a,@dptr
      00AAB0 FD               [12]  835 	mov	r5,a
      00AAB1 7C 00            [12]  836 	mov	r4,#0x00
      00AAB3                        837 00103$:
      00AAB3 BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00AAB6                        839 00122$:
      00AAB6 50 09            [24]  840 	jnc	00105$
      00AAB8 EC               [12]  841 	mov	a,r4
      00AAB9 12 37 E9         [24]  842 	lcall	_ak820_outline_0019
      00AABC ED               [12]  843 	mov	a,r5
      00AABD F0               [24]  844 	movx	@dptr,a
      00AABE 0C               [12]  845 	inc	r4
      00AABF 80 F2            [24]  846 	sjmp	00103$
      00AAC1                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00AAC1 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AAC2                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00AAC2 12 9E B7         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00AAC5 02 75 34         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_617'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_618'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_623'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_624'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_627'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_629'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_629'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_629'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_630'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_631'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_631'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_631'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_634'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_645'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_645'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AAC8                        893 _vial_handle_cmd:
      00AAC8 12 42 D0         [24]  894 	lcall	_ak820_outline_0035
      00AACB 90 0C 2E         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AACE 12 37 E1         [24]  896 	lcall	_ak820_outline_0014
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AAD1 90 0C 2E         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AAD4 12 37 F9         [24]  899 	lcall	_ak820_outline_0049
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00AAD7 90 0C 2D         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AADA E0               [24]  902 	movx	a,@dptr
      00AADB FD               [12]  903 	mov	r5,a
      00AADC BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AADF 80 01            [24]  905 	sjmp	00102$
      00AAE1                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00AAE1 22               [24]  908 	ret
      00AAE2                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00AAE2 74 01            [12]  911 	mov	a,#0x01
      00AAE4 12 47 6D         [24]  912 	lcall	_ak820_outline_0011
      00AAE7 FB               [12]  913 	mov  r3,a
      00AAE8 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AAEA 50 01            [24]  915 	jnc	00259$
      00AAEC 22               [24]  916 	ret
      00AAED                        917 00259$:
                                    918 ;	free result
      00AAED EB               [12]  919 	mov	a,r3
      00AAEE 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AAF0 83               [24]  921 	movc	a,@a+pc
      00AAF1 F5 82            [12]  922 	mov	dpl,a
      00AAF3 EB               [12]  923 	mov	a,r3
      00AAF4 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AAF6 83               [24]  925 	movc	a,@a+pc
      00AAF7 F5 83            [12]  926 	mov	dph,a
      00AAF9 E4               [12]  927 	clr	a
      00AAFA 73               [24]  928 	jmp	@a+dptr
      00AAFB                        929 00260$:
      00AAFB 17                     930 	.db	00103$
      00AAFC 5F                     931 	.db	00105$
      00AAFD 74                     932 	.db	00106$
      00AAFE 00                     933 	.db	00112$
      00AAFF 86                     934 	.db	00113$
      00AB00 D2                     935 	.db	00114$
      00AB01 41                     936 	.db	00116$
      00AB02 5C                     937 	.db	00119$
      00AB03 7C                     938 	.db	00120$
      00AB04 8A                     939 	.db	00121$
      00AB05 8A                     940 	.db	00139$
      00AB06 8A                     941 	.db	00139$
      00AB07 8A                     942 	.db	00139$
      00AB08 95                     943 	.db	00122$
      00AB09                        944 00261$:
      00AB09 AB                     945 	.db	00103$>>8
      00AB0A AB                     946 	.db	00105$>>8
      00AB0B AB                     947 	.db	00106$>>8
      00AB0C AC                     948 	.db	00112$>>8
      00AB0D AC                     949 	.db	00113$>>8
      00AB0E AC                     950 	.db	00114$>>8
      00AB0F AD                     951 	.db	00116$>>8
      00AB10 AD                     952 	.db	00119$>>8
      00AB11 AD                     953 	.db	00120$>>8
      00AB12 AD                     954 	.db	00121$>>8
      00AB13 AE                     955 	.db	00139$>>8
      00AB14 AE                     956 	.db	00139$>>8
      00AB15 AE                     957 	.db	00139$>>8
      00AB16 AD                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00AB17                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00AB17 90 0C 2A         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00AB1A E4               [12]  963 	clr	a
      00AB1B 12 42 F4         [24]  964 	lcall	_ak820_outline_0058
      00AB1E C0 07            [24]  965 	push	ar7
      00AB20 C0 06            [24]  966 	push	ar6
      00AB22 12 AA 9D         [24]  967 	lcall	_vial_fill_packet
      00AB25 D0 06            [24]  968 	pop	ar6
      00AB27 D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00AB29 12 43 1F         [24]  971 	lcall	_ak820_outline_0116
      00AB2C 74 06            [12]  972 	mov	a,#0x06
      00AB2E 12 42 F4         [24]  973 	lcall	_ak820_outline_0058
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00AB31 A3               [24]  975 	inc	dptr
      00AB32 E4               [12]  976 	clr	a
      00AB33 12 42 C8         [24]  977 	lcall	_ak820_outline_0029
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00AB36 12 42 C8         [24]  979 	lcall	_ak820_outline_0029
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00AB39 A3               [24]  981 	inc	dptr
      00AB3A F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00AB3B FB               [12]  984 	mov	r3,a
      00AB3C                        985 00131$:
      00AB3C BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00AB3F                        987 00262$:
      00AB3F 50 15            [24]  988 	jnc	00104$
      00AB41 8B 02            [24]  989 	mov	ar2,r3
      00AB43 74 04            [12]  990 	mov	a,#0x04
      00AB45 2A               [12]  991 	add	a, r2
      00AB46 2E               [12]  992 	add	a, r6
      00AB47 F9               [12]  993 	mov	r1,a
      00AB48 E4               [12]  994 	clr	a
      00AB49 3F               [12]  995 	addc	a,r7
      00AB4A FA               [12]  996 	mov	r2,a
      00AB4B EB               [12]  997 	mov	a,r3
      00AB4C 90 BC 52         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_622
      00AB4F 93               [24]  999 	movc	a,@a+dptr
      00AB50 12 6B 49         [24] 1000 	lcall	_ak820_outline_0134
      00AB53 0B               [12] 1001 	inc	r3
      00AB54 80 E6            [24] 1002 	sjmp	00131$
      00AB56                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00AB56 74 0C            [12] 1005 	mov	a,#0x0c
      00AB58 12 37 E9         [24] 1006 	lcall	_ak820_outline_0019
      00AB5B 74 01            [12] 1007 	mov	a,#0x01
      00AB5D F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00AB5E 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00AB5F                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00AB5F 12 43 1F         [24] 1014 	lcall	_ak820_outline_0116
      00AB62 74 7C            [12] 1015 	mov	a,#0x7c
      00AB64 F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00AB65 12 38 53         [24] 1018 	lcall	_ak820_outline_0117
      00AB68 74 01            [12] 1019 	mov	a,#0x01
      00AB6A 12 42 C8         [24] 1020 	lcall	_ak820_outline_0029
                                   1021 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00AB6D E4               [12] 1022 	clr	a
      00AB6E 12 42 C8         [24] 1023 	lcall	_ak820_outline_0029
                                   1024 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00AB71 A3               [24] 1025 	inc	dptr
      00AB72 F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:216: break;
      00AB73 22               [24] 1028 	ret
                                   1029 ;	quantum/vial.c:219: case vial_get_def: {
      00AB74                       1030 00106$:
                                   1031 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00AB74 12 A9 A6         [24] 1032 	lcall	_ak820_outline_0020
      00AB77 E0               [24] 1033 	movx	a,@dptr
      00AB78 FB               [12] 1034 	mov	r3,a
      00AB79 12 42 BE         [24] 1035 	lcall	_ak820_outline_0010
      00AB7C E0               [24] 1036 	movx	a,@dptr
      00AB7D 4B               [12] 1037 	orl	a,r3
      00AB7E 60 01            [24] 1038 	jz	00108$
      00AB80 22               [24] 1039 	ret
      00AB81                       1040 00108$:
                                   1041 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00AB81 12 37 F1         [24] 1042 	lcall	_ak820_outline_0032
      00AB84 FB               [12] 1043 	mov	r3,a
      00AB85 7A 00            [12] 1044 	mov	r2,#0x00
      00AB87 12 A9 9D         [24] 1045 	lcall	_ak820_outline_0013
      00AB8A F9               [12] 1046 	mov	r1,a
      00AB8B E4               [12] 1047 	clr	a
      00AB8C 42 03            [12] 1048 	orl	ar3,a
      00AB8E E9               [12] 1049 	mov	a,r1
      00AB8F 42 02            [12] 1050 	orl	ar2,a
                                   1051 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00AB91 C3               [12] 1052 	clr	c
      00AB92 EB               [12] 1053 	mov	a,r3
      00AB93 94 0C            [12] 1054 	subb	a,#0x0c
      00AB95 EA               [12] 1055 	mov	a,r2
      00AB96 94 00            [12] 1056 	subb	a,#0x00
      00AB98 40 01            [24] 1057 	jc	00110$
      00AB9A 22               [24] 1058 	ret
      00AB9B                       1059 00110$:
                                   1060 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00AB9B EA               [12] 1061 	mov	a,r2
      00AB9C C4               [12] 1062 	swap	a
      00AB9D 23               [12] 1063 	rl	a
      00AB9E 54 E0            [12] 1064 	anl	a,#0xe0
      00ABA0 CB               [12] 1065 	xch	a,r3
      00ABA1 C4               [12] 1066 	swap	a
      00ABA2 23               [12] 1067 	rl	a
      00ABA3 CB               [12] 1068 	xch	a,r3
      00ABA4 6B               [12] 1069 	xrl	a,r3
      00ABA5 CB               [12] 1070 	xch	a,r3
      00ABA6 54 E0            [12] 1071 	anl	a,#0xe0
      00ABA8 CB               [12] 1072 	xch	a,r3
      00ABA9 6B               [12] 1073 	xrl	a,r3
      00ABAA FA               [12] 1074 	mov	r2,a
      00ABAB 8B 45            [24] 1075 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00ABAD 8A 46            [24] 1076 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1077 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00ABAF 74 7C            [12] 1078 	mov	a,#0x7c
      00ABB1 C3               [12] 1079 	clr	c
      00ABB2 95 45            [12] 1080 	subb	a,_vial_handle_cmd_sloc0_1_0
      00ABB4 F8               [12] 1081 	mov	r0,a
      00ABB5 74 01            [12] 1082 	mov	a,#0x01
      00ABB7 95 46            [12] 1083 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00ABB9 F9               [12] 1084 	mov	r1,a
                                   1085 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00ABBA C3               [12] 1086 	clr	c
      00ABBB E8               [12] 1087 	mov	a,r0
      00ABBC 94 20            [12] 1088 	subb	a,#0x20
      00ABBE E9               [12] 1089 	mov	a,r1
      00ABBF 94 00            [12] 1090 	subb	a,#0x00
      00ABC1 40 02            [24] 1091 	jc	00142$
      00ABC3 78 20            [12] 1092 	mov	r0,#0x20
      00ABC5                       1093 00142$:
                                   1094 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00ABC5 79 00            [12] 1095 	mov	r1,#0x00
      00ABC7                       1096 00134$:
      00ABC7 C3               [12] 1097 	clr	c
      00ABC8 E9               [12] 1098 	mov	a,r1
      00ABC9 98               [12] 1099 	subb	a,r0
      00ABCA 40 01            [24] 1100 	jc	00267$
      00ABCC 22               [24] 1101 	ret
      00ABCD                       1102 00267$:
      00ABCD C0 00            [24] 1103 	push	ar0
      00ABCF E9               [12] 1104 	mov	a,r1
      00ABD0 2E               [12] 1105 	add	a, r6
      00ABD1 F5 47            [12] 1106 	mov	_vial_handle_cmd_sloc1_1_0,a
      00ABD3 E4               [12] 1107 	clr	a
      00ABD4 3F               [12] 1108 	addc	a, r7
      00ABD5 F5 48            [12] 1109 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00ABD7 89 49            [24] 1110 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00ABD9 75 4A 00         [24] 1111 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00ABDC A8 45            [24] 1112 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00ABDE AB 46            [24] 1113 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00ABE0 E5 49            [12] 1114 	mov	a,_vial_handle_cmd_sloc2_1_0
      00ABE2 28               [12] 1115 	add	a, r0
      00ABE3 F8               [12] 1116 	mov	r0,a
      00ABE4 E5 4A            [12] 1117 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00ABE6 3B               [12] 1118 	addc	a, r3
      00ABE7 FB               [12] 1119 	mov	r3,a
      00ABE8 E8               [12] 1120 	mov	a,r0
      00ABE9 24 D6            [12] 1121 	add	a, #_keyboard_definition
      00ABEB F5 82            [12] 1122 	mov	dpl,a
      00ABED EB               [12] 1123 	mov	a,r3
      00ABEE 34 BA            [12] 1124 	addc	a, #(_keyboard_definition >> 8)
      00ABF0 F5 83            [12] 1125 	mov	dph,a
      00ABF2 E4               [12] 1126 	clr	a
      00ABF3 93               [24] 1127 	movc	a,@a+dptr
      00ABF4 85 47 82         [24] 1128 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00ABF7 85 48 83         [24] 1129 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00ABFA F0               [24] 1130 	movx	@dptr,a
      00ABFB 09               [12] 1131 	inc	r1
      00ABFC D0 00            [24] 1132 	pop	ar0
                                   1133 ;	quantum/vial.c:246: case vial_get_encoder: {
      00ABFE 80 C7            [24] 1134 	sjmp	00134$
      00AC00                       1135 00112$:
                                   1136 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00AC00 74 02            [12] 1137 	mov	a,#0x02
      00AC02 12 47 AC         [24] 1138 	lcall	_ak820_outline_0044
      00AC05 F5 49            [12] 1139 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1140 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00AC07 74 03            [12] 1141 	mov	a,#0x03
      00AC09 2E               [12] 1142 	add	a, r6
      00AC0A F5 47            [12] 1143 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AC0C E4               [12] 1144 	clr	a
      00AC0D 3F               [12] 1145 	addc	a, r7
      00AC0E F5 48            [12] 1146 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AC10 85 47 82         [24] 1147 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AC13 85 48 83         [24] 1148 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AC16 E0               [24] 1149 	movx	a,@dptr
                                   1150 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00AC17 F5 45            [12] 1151 	mov	_vial_handle_cmd_sloc0_1_0,a
      00AC19 90 0A D8         [24] 1152 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AC1C F0               [24] 1153 	movx	@dptr,a
      00AC1D 90 0A D9         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AC20 E4               [12] 1155 	clr	a
      00AC21 F0               [24] 1156 	movx	@dptr,a
      00AC22 85 49 82         [24] 1157 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AC25 C0 07            [24] 1158 	push	ar7
      00AC27 C0 06            [24] 1159 	push	ar6
      00AC29 C0 05            [24] 1160 	push	ar5
      00AC2B C0 04            [24] 1161 	push	ar4
      00AC2D C0 03            [24] 1162 	push	ar3
      00AC2F C0 02            [24] 1163 	push	ar2
      00AC31 12 83 08         [24] 1164 	lcall	_dynamic_keymap_get_encoder
      00AC34 85 82 4B         [24] 1165 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AC37 85 83 4C         [24] 1166 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AC3A D0 02            [24] 1167 	pop	ar2
      00AC3C D0 03            [24] 1168 	pop	ar3
      00AC3E D0 04            [24] 1169 	pop	ar4
      00AC40 D0 05            [24] 1170 	pop	ar5
      00AC42 D0 06            [24] 1171 	pop	ar6
      00AC44 D0 07            [24] 1172 	pop	ar7
                                   1173 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00AC46 A9 4C            [24] 1174 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AC48 12 43 1F         [24] 1175 	lcall	_ak820_outline_0116
      00AC4B E9               [12] 1176 	mov	a,r1
      00AC4C F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00AC4D A8 4B            [24] 1179 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AC4F 12 38 53         [24] 1180 	lcall	_ak820_outline_0117
      00AC52 E8               [12] 1181 	mov	a,r0
      00AC53 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00AC54 90 0A D8         [24] 1184 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AC57 E5 45            [12] 1185 	mov	a,_vial_handle_cmd_sloc0_1_0
      00AC59 F0               [24] 1186 	movx	@dptr,a
      00AC5A 90 0A D9         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AC5D 74 01            [12] 1188 	mov	a,#0x01
      00AC5F F0               [24] 1189 	movx	@dptr,a
      00AC60 85 49 82         [24] 1190 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AC63 C0 03            [24] 1191 	push	ar3
      00AC65 C0 02            [24] 1192 	push	ar2
      00AC67 12 83 08         [24] 1193 	lcall	_dynamic_keymap_get_encoder
      00AC6A 85 82 4B         [24] 1194 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AC6D 85 83 4C         [24] 1195 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AC70 D0 02            [24] 1196 	pop	ar2
      00AC72 D0 03            [24] 1197 	pop	ar3
                                   1198 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00AC74 A9 4C            [24] 1199 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AC76 12 43 35         [24] 1200 	lcall	_ak820_outline_0139
      00AC79 E9               [12] 1201 	mov	a,r1
      00AC7A F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00AC7B A8 4B            [24] 1204 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AC7D 85 47 82         [24] 1205 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AC80 85 48 83         [24] 1206 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AC83 E8               [12] 1207 	mov	a,r0
      00AC84 F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/vial.c:255: break;
      00AC85 22               [24] 1210 	ret
                                   1211 ;	quantum/vial.c:257: case vial_set_encoder: {
      00AC86                       1212 00113$:
                                   1213 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AC86 12 37 F1         [24] 1214 	lcall	_ak820_outline_0032
      00AC89 F5 47            [12] 1215 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AC8B 12 A9 9D         [24] 1216 	lcall	_ak820_outline_0013
      00AC8E F5 49            [12] 1217 	mov	_vial_handle_cmd_sloc2_1_0,a
      00AC90 12 A9 A6         [24] 1218 	lcall	_ak820_outline_0020
      00AC93 E0               [24] 1219 	movx	a,@dptr
                                   1220 ;	assignBit
      00AC94 24 FF            [12] 1221 	add	a,#0xff
      00AC96 E4               [12] 1222 	clr	a
      00AC97 33               [12] 1223 	rlc	a
      00AC98 F5 4B            [12] 1224 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AC9A 12 42 BE         [24] 1225 	lcall	_ak820_outline_0010
      00AC9D E0               [24] 1226 	movx	a,@dptr
      00AC9E F9               [12] 1227 	mov	r1,a
      00AC9F 78 00            [12] 1228 	mov	r0,#0x00
      00ACA1 74 06            [12] 1229 	mov	a,#0x06
      00ACA3 12 37 E9         [24] 1230 	lcall	_ak820_outline_0019
      00ACA6 E0               [24] 1231 	movx	a,@dptr
      00ACA7 7B 00            [12] 1232 	mov	r3,#0x00
      00ACA9 42 00            [12] 1233 	orl	ar0,a
      00ACAB EB               [12] 1234 	mov	a,r3
      00ACAC 42 01            [12] 1235 	orl	ar1,a
      00ACAE 12 38 6E         [24] 1236 	lcall	_ak820_outline_0150
      00ACB1 12 AA 7A         [24] 1237 	lcall	_vial_keycode_firewall
      00ACB4 AA 82            [24] 1238 	mov	r2, dpl
      00ACB6 AB 83            [24] 1239 	mov	r3, dph
      00ACB8 90 0A DB         [24] 1240 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00ACBB E5 49            [12] 1241 	mov	a,_vial_handle_cmd_sloc2_1_0
      00ACBD F0               [24] 1242 	movx	@dptr,a
      00ACBE 90 0A DC         [24] 1243 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00ACC1 E5 4B            [12] 1244 	mov	a,_vial_handle_cmd_sloc3_1_0
      00ACC3 F0               [24] 1245 	movx	@dptr,a
      00ACC4 90 0A DD         [24] 1246 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00ACC7 EA               [12] 1247 	mov	a,r2
      00ACC8 F0               [24] 1248 	movx	@dptr,a
      00ACC9 EB               [12] 1249 	mov	a,r3
      00ACCA A3               [24] 1250 	inc	dptr
      00ACCB F0               [24] 1251 	movx	@dptr,a
      00ACCC 85 47 82         [24] 1252 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1253 ;	quantum/vial.c:259: break;
      00ACCF 02 83 70         [24] 1254 	ljmp	_dynamic_keymap_set_encoder
                                   1255 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00ACD2                       1256 00114$:
                                   1257 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00ACD2 90 0C 2A         [24] 1258 	mov	dptr,#_vial_fill_packet_PARM_2
      00ACD5 74 FF            [12] 1259 	mov	a,#0xff
      00ACD7 12 42 F4         [24] 1260 	lcall	_ak820_outline_0058
      00ACDA C0 07            [24] 1261 	push	ar7
      00ACDC C0 06            [24] 1262 	push	ar6
      00ACDE 12 AA 9D         [24] 1263 	lcall	_vial_fill_packet
      00ACE1 D0 06            [24] 1264 	pop	ar6
      00ACE3 D0 07            [24] 1265 	pop	ar7
                                   1266 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00ACE5 90 0D ED         [24] 1267 	mov	dptr,#_vial_unlocked
      00ACE8 E0               [24] 1268 	movx	a,@dptr
      00ACE9 12 43 1F         [24] 1269 	lcall	_ak820_outline_0116
      00ACEC F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00ACED 74 01            [12] 1272 	mov	a,#0x01
      00ACEF 2E               [12] 1273 	add	a, r6
      00ACF0 FA               [12] 1274 	mov	r2,a
      00ACF1 E4               [12] 1275 	clr	a
      00ACF2 3F               [12] 1276 	addc	a, r7
      00ACF3 FB               [12] 1277 	mov	r3,a
      00ACF4 90 0D EE         [24] 1278 	mov	dptr,#_vial_unlock_in_progress
      00ACF7 E0               [24] 1279 	movx	a,@dptr
      00ACF8 12 43 35         [24] 1280 	lcall	_ak820_outline_0139
      00ACFB F0               [24] 1281 	movx	@dptr,a
                                   1282 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00ACFC 7B 00            [12] 1283 	mov	r3,#0x00
      00ACFE                       1284 00137$:
      00ACFE BB 02 00         [24] 1285 	cjne	r3,#0x02,00268$
      00AD01                       1286 00268$:
      00AD01 40 01            [24] 1287 	jc	00269$
      00AD03 22               [24] 1288 	ret
      00AD04                       1289 00269$:
                                   1290 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00AD04 8B 01            [24] 1291 	mov	ar1,r3
      00AD06 7A 00            [12] 1292 	mov	r2,#0x00
      00AD08 E9               [12] 1293 	mov	a,r1
      00AD09 29               [12] 1294 	add	a,r1
      00AD0A F5 4B            [12] 1295 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AD0C EA               [12] 1296 	mov	a,r2
      00AD0D 33               [12] 1297 	rlc	a
      00AD0E F5 4C            [12] 1298 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00AD10 74 02            [12] 1299 	mov	a,#0x02
      00AD12 25 4B            [12] 1300 	add	a, _vial_handle_cmd_sloc3_1_0
      00AD14 F8               [12] 1301 	mov	r0,a
      00AD15 E4               [12] 1302 	clr	a
      00AD16 35 4C            [12] 1303 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AD18 FA               [12] 1304 	mov	r2,a
      00AD19 E8               [12] 1305 	mov	a,r0
      00AD1A 2E               [12] 1306 	add	a, r6
      00AD1B F8               [12] 1307 	mov	r0,a
      00AD1C EA               [12] 1308 	mov	a,r2
      00AD1D 3F               [12] 1309 	addc	a, r7
      00AD1E FA               [12] 1310 	mov	r2,a
      00AD1F EB               [12] 1311 	mov	a,r3
      00AD20 12 AF A9         [24] 1312 	lcall	_ak820_outline_0124
      00AD23 88 82            [24] 1313 	mov	dpl,r0
      00AD25 8A 83            [24] 1314 	mov	dph,r2
      00AD27 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00AD28 74 03            [12] 1317 	mov	a,#0x03
      00AD2A 25 4B            [12] 1318 	add	a, _vial_handle_cmd_sloc3_1_0
      00AD2C F9               [12] 1319 	mov	r1,a
      00AD2D E4               [12] 1320 	clr	a
      00AD2E 35 4C            [12] 1321 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AD30 FA               [12] 1322 	mov	r2,a
      00AD31 E9               [12] 1323 	mov	a,r1
      00AD32 2E               [12] 1324 	add	a, r6
      00AD33 F9               [12] 1325 	mov	r1,a
      00AD34 EA               [12] 1326 	mov	a,r2
      00AD35 3F               [12] 1327 	addc	a, r7
      00AD36 FA               [12] 1328 	mov	r2,a
      00AD37 EB               [12] 1329 	mov	a,r3
      00AD38 12 AF 9E         [24] 1330 	lcall	_ak820_outline_0123
      00AD3B 12 6B 49         [24] 1331 	lcall	_ak820_outline_0134
                                   1332 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AD3E 0B               [12] 1333 	inc	r3
                                   1334 ;	quantum/vial.c:278: case vial_unlock_start: {
      00AD3F 80 BD            [24] 1335 	sjmp	00137$
      00AD41                       1336 00116$:
                                   1337 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00AD41 90 0D EE         [24] 1338 	mov	dptr,#_vial_unlock_in_progress
      00AD44 E0               [24] 1339 	movx	a,@dptr
      00AD45 70 03            [24] 1340 	jnz	00118$
      00AD47 12 AA C2         [24] 1341 	lcall	_vial_release_held_state
      00AD4A                       1342 00118$:
                                   1343 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00AD4A 90 0D EE         [24] 1344 	mov	dptr,#_vial_unlock_in_progress
      00AD4D 74 01            [12] 1345 	mov	a,#0x01
      00AD4F F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AD50 90 0D EF         [24] 1348 	mov	dptr,#_vial_unlock_counter
      00AD53 74 1E            [12] 1349 	mov	a,#0x1e
      00AD55 F0               [24] 1350 	movx	@dptr,a
                                   1351 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00AD56 90 0C 27         [24] 1352 	mov	dptr,#_vial_unlock_holding
      00AD59 E4               [12] 1353 	clr	a
      00AD5A F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/vial.c:287: break;
      00AD5B 22               [24] 1356 	ret
                                   1357 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00AD5C                       1358 00119$:
                                   1359 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00AD5C 90 0D ED         [24] 1360 	mov	dptr,#_vial_unlocked
      00AD5F E0               [24] 1361 	movx	a,@dptr
      00AD60 12 43 1F         [24] 1362 	lcall	_ak820_outline_0116
      00AD63 F0               [24] 1363 	movx	@dptr,a
                                   1364 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00AD64 90 0D EE         [24] 1365 	mov	dptr,#_vial_unlock_in_progress
      00AD67 E0               [24] 1366 	movx	a,@dptr
      00AD68 12 38 53         [24] 1367 	lcall	_ak820_outline_0117
      00AD6B F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00AD6C 74 02            [12] 1370 	mov	a,#0x02
      00AD6E 2E               [12] 1371 	add	a, r6
      00AD6F FA               [12] 1372 	mov	r2,a
      00AD70 E4               [12] 1373 	clr	a
      00AD71 3F               [12] 1374 	addc	a, r7
      00AD72 FB               [12] 1375 	mov	r3,a
      00AD73 90 0D EF         [24] 1376 	mov	dptr,#_vial_unlock_counter
      00AD76 E0               [24] 1377 	movx	a,@dptr
      00AD77 12 43 35         [24] 1378 	lcall	_ak820_outline_0139
      00AD7A F0               [24] 1379 	movx	@dptr,a
                                   1380 ;	quantum/vial.c:293: break;
      00AD7B 22               [24] 1381 	ret
                                   1382 ;	quantum/vial.c:295: case vial_lock: {
      00AD7C                       1383 00120$:
                                   1384 ;	quantum/vial.c:297: vial_unlocked = 0;
      00AD7C 90 0D ED         [24] 1385 	mov	dptr,#_vial_unlocked
      00AD7F E4               [12] 1386 	clr	a
      00AD80 F0               [24] 1387 	movx	@dptr,a
                                   1388 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00AD81 90 0D EE         [24] 1389 	mov	dptr,#_vial_unlock_in_progress
      00AD84 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00AD85 90 0C 27         [24] 1392 	mov	dptr,#_vial_unlock_holding
      00AD88 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:301: break;
      00AD89 22               [24] 1395 	ret
                                   1396 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00AD8A                       1397 00121$:
                                   1398 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00AD8A 90 0C 2A         [24] 1399 	mov	dptr,#_vial_fill_packet_PARM_2
      00AD8D 74 FF            [12] 1400 	mov	a,#0xff
      00AD8F 12 42 F4         [24] 1401 	lcall	_ak820_outline_0058
                                   1402 ;	quantum/vial.c:314: break;
      00AD92 02 AA 9D         [24] 1403 	ljmp	_vial_fill_packet
                                   1404 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00AD95                       1405 00122$:
                                   1406 ;	quantum/vial.c:347: switch (msg[2]) {
      00AD95 12 37 F1         [24] 1407 	lcall	_ak820_outline_0032
      00AD98 FB               [12] 1408 	mov	r3,a
      00AD99 60 0C            [24] 1409 	jz	00123$
      00AD9B BB 03 02         [24] 1410 	cjne	r3,#0x03,00272$
      00AD9E 80 31            [24] 1411 	sjmp	00124$
      00ADA0                       1412 00272$:
      00ADA0 BB 04 03         [24] 1413 	cjne	r3,#0x04,00273$
      00ADA3 02 AE 2F         [24] 1414 	ljmp	00125$
      00ADA6                       1415 00273$:
      00ADA6 22               [24] 1416 	ret
                                   1417 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00ADA7                       1418 00123$:
                                   1419 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00ADA7 90 0C 2A         [24] 1420 	mov	dptr,#_vial_fill_packet_PARM_2
      00ADAA E4               [12] 1421 	clr	a
      00ADAB 12 42 F4         [24] 1422 	lcall	_ak820_outline_0058
      00ADAE C0 07            [24] 1423 	push	ar7
      00ADB0 C0 06            [24] 1424 	push	ar6
      00ADB2 12 AA 9D         [24] 1425 	lcall	_vial_fill_packet
      00ADB5 D0 06            [24] 1426 	pop	ar6
      00ADB7 D0 07            [24] 1427 	pop	ar7
                                   1428 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00ADB9 12 43 1F         [24] 1429 	lcall	_ak820_outline_0116
      00ADBC E4               [12] 1430 	clr	a
      00ADBD 12 42 F4         [24] 1431 	lcall	_ak820_outline_0058
                                   1432 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00ADC0 A3               [24] 1433 	inc	dptr
      00ADC1 74 08            [12] 1434 	mov	a,#0x08
      00ADC3 12 42 C8         [24] 1435 	lcall	_ak820_outline_0029
                                   1436 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00ADC6 E4               [12] 1437 	clr	a
      00ADC7 F0               [24] 1438 	movx	@dptr,a
                                   1439 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00ADC8 74 1F            [12] 1440 	mov	a,#0x1f
      00ADCA 12 37 E9         [24] 1441 	lcall	_ak820_outline_0019
      00ADCD 74 01            [12] 1442 	mov	a,#0x01
      00ADCF F0               [24] 1443 	movx	@dptr,a
                                   1444 ;	quantum/vial.c:356: break;
      00ADD0 22               [24] 1445 	ret
                                   1446 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00ADD1                       1447 00124$:
                                   1448 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00ADD1 12 A9 9D         [24] 1449 	lcall	_ak820_outline_0013
      00ADD4 FB               [12] 1450 	mov	r3,a
                                   1451 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00ADD5 90 0C 31         [24] 1452 	mov	dptr,#_vial_handle_cmd_entry_70000_645
      00ADD8 12 4E 64         [24] 1453 	lcall	_ak820_outline_0164
      00ADDB 90 0C 33         [24] 1454 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0002)
      00ADDE F0               [24] 1455 	movx	@dptr,a
      00ADDF A3               [24] 1456 	inc	dptr
      00ADE0 F0               [24] 1457 	movx	@dptr,a
      00ADE1 90 0C 35         [24] 1458 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0004)
      00ADE4 F0               [24] 1459 	movx	@dptr,a
      00ADE5 A3               [24] 1460 	inc	dptr
      00ADE6 F0               [24] 1461 	movx	@dptr,a
      00ADE7 90 0C 37         [24] 1462 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0006)
      00ADEA F0               [24] 1463 	movx	@dptr,a
      00ADEB A3               [24] 1464 	inc	dptr
      00ADEC F0               [24] 1465 	movx	@dptr,a
      00ADED 90 0C 39         [24] 1466 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0008)
      00ADF0 F0               [24] 1467 	movx	@dptr,a
      00ADF1 A3               [24] 1468 	inc	dptr
      00ADF2 F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00ADF3 90 0A E0         [24] 1471 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00ADF6 74 31            [12] 1472 	mov	a,#_vial_handle_cmd_entry_70000_645
      00ADF8 F0               [24] 1473 	movx	@dptr,a
      00ADF9 74 0C            [12] 1474 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00ADFB 12 38 30         [24] 1475 	lcall	_ak820_outline_0095
      00ADFE 8B 82            [24] 1476 	mov	dpl, r3
      00AE00 C0 07            [24] 1477 	push	ar7
      00AE02 C0 06            [24] 1478 	push	ar6
      00AE04 C0 05            [24] 1479 	push	ar5
      00AE06 C0 04            [24] 1480 	push	ar4
      00AE08 12 83 DD         [24] 1481 	lcall	_dynamic_keymap_get_combo
      00AE0B AA 82            [24] 1482 	mov	r2, dpl
      00AE0D D0 04            [24] 1483 	pop	ar4
      00AE0F D0 05            [24] 1484 	pop	ar5
      00AE11 D0 06            [24] 1485 	pop	ar6
      00AE13 D0 07            [24] 1486 	pop	ar7
      00AE15 12 43 1F         [24] 1487 	lcall	_ak820_outline_0116
      00AE18 EA               [12] 1488 	mov	a,r2
      00AE19 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00AE1A 7B 00            [12] 1491 	mov	r3,#0x00
      00AE1C 90 0D 6D         [24] 1492 	mov	dptr,#___memcpy_PARM_2
      00AE1F 74 31            [12] 1493 	mov	a,#_vial_handle_cmd_entry_70000_645
      00AE21 F0               [24] 1494 	movx	@dptr,a
      00AE22 74 0C            [12] 1495 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00AE24 12 AF 8F         [24] 1496 	lcall	_ak820_outline_0070
      00AE27 12 38 53         [24] 1497 	lcall	_ak820_outline_0117
      00AE2A 8B F0            [24] 1498 	mov	b, r3
                                   1499 ;	quantum/vial.c:387: break;
      00AE2C 02 B5 58         [24] 1500 	ljmp	___memcpy
                                   1501 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00AE2F                       1502 00125$:
                                   1503 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00AE2F 12 A9 9D         [24] 1504 	lcall	_ak820_outline_0013
      00AE32 FD               [12] 1505 	mov	r5,a
                                   1506 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00AE33 74 04            [12] 1507 	mov	a,#0x04
      00AE35 2E               [12] 1508 	add	a, r6
      00AE36 FB               [12] 1509 	mov	r3,a
      00AE37 E4               [12] 1510 	clr	a
      00AE38 3F               [12] 1511 	addc	a, r7
      00AE39 FC               [12] 1512 	mov	r4,a
      00AE3A 90 0D 6D         [24] 1513 	mov	dptr,#___memcpy_PARM_2
      00AE3D EB               [12] 1514 	mov	a,r3
      00AE3E F0               [24] 1515 	movx	@dptr,a
      00AE3F EC               [12] 1516 	mov	a,r4
      00AE40 12 AF 8F         [24] 1517 	lcall	_ak820_outline_0070
      00AE43 90 0C 3B         [24] 1518 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00AE46 F5 F0            [12] 1519 	mov	b,a
      00AE48 C0 07            [24] 1520 	push	ar7
      00AE4A C0 06            [24] 1521 	push	ar6
      00AE4C C0 05            [24] 1522 	push	ar5
      00AE4E 12 B5 58         [24] 1523 	lcall	___memcpy
                                   1524 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00AE51 90 0C 43         [24] 1525 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AE54 12 38 3C         [24] 1526 	lcall	_ak820_outline_0098
      00AE57 12 33 FC         [24] 1527 	lcall	_ak820_outline_0120
      00AE5A 12 AA 7A         [24] 1528 	lcall	_vial_keycode_firewall
      00AE5D AB 82            [24] 1529 	mov	r3, dpl
      00AE5F AC 83            [24] 1530 	mov	r4, dph
      00AE61 D0 05            [24] 1531 	pop	ar5
      00AE63 90 0C 43         [24] 1532 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AE66 12 38 24         [24] 1533 	lcall	_ak820_outline_0074
                                   1534 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00AE69 90 0A E4         [24] 1535 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00AE6C 74 3B            [12] 1536 	mov	a,#_vial_handle_cmd_entry_70000_646
      00AE6E F0               [24] 1537 	movx	@dptr,a
      00AE6F 74 0C            [12] 1538 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00AE71 12 38 30         [24] 1539 	lcall	_ak820_outline_0095
      00AE74 8D 82            [24] 1540 	mov	dpl, r5
      00AE76 12 84 83         [24] 1541 	lcall	_dynamic_keymap_set_combo
      00AE79 AC 82            [24] 1542 	mov	r4, dpl
      00AE7B D0 06            [24] 1543 	pop	ar6
      00AE7D D0 07            [24] 1544 	pop	ar7
      00AE7F 12 43 1F         [24] 1545 	lcall	_ak820_outline_0116
      00AE82 EC               [12] 1546 	mov	a,r4
      00AE83 F0               [24] 1547 	movx	@dptr,a
                                   1548 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00AE84 EC               [12] 1549 	mov	a,r4
      00AE85 70 03            [24] 1550 	jnz	00139$
                                   1551 ;	quantum/vial.c:423: }
                                   1552 ;	quantum/vial.c:424: }
      00AE87 02 35 38         [24] 1553 	ljmp	_ak820_combo_reload
      00AE8A                       1554 00139$:
      00AE8A 22               [24] 1555 	ret
                                   1556 ;------------------------------------------------------------
                                   1557 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1558 ;------------------------------------------------------------
                                   1559 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_648'
                                   1560 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_655'
                                   1561 ;------------------------------------------------------------
                                   1562 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1563 ;	-----------------------------------------
                                   1564 ;	 function vial_keycode_down
                                   1565 ;	-----------------------------------------
      00AE8B                       1566 _vial_keycode_down:
      00AE8B 12 38 47         [24] 1567 	lcall	_ak820_outline_0103
      00AE8E 90 0C 47         [24] 1568 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AE91 12 38 42         [24] 1569 	lcall	_ak820_outline_0102
                                   1570 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AE94 90 0C 47         [24] 1571 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AE97 12 37 CD         [24] 1572 	lcall	_ak820_outline_0009
      00AE9A 74 E0            [12] 1573 	mov	a,#0x100 - 0x20
      00AE9C 2D               [12] 1574 	add	a,r5
      00AE9D 50 19            [24] 1575 	jnc	00104$
      00AE9F C3               [12] 1576 	clr	c
      00AEA0 74 FF            [12] 1577 	mov	a,#0xff
      00AEA2 9C               [12] 1578 	subb	a,r4
      00AEA3 74 4F            [12] 1579 	mov	a,#0x4f
      00AEA5 9D               [12] 1580 	subb	a,r5
      00AEA6 40 10            [24] 1581 	jc	00104$
                                   1582 ;	free result
                                   1583 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00AEA8 90 0C 47         [24] 1584 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AEAB EE               [12] 1585 	mov	a,r6
      00AEAC 12 38 58         [24] 1586 	lcall	_ak820_outline_0121
                                   1587 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00AEAF 90 0C 47         [24] 1588 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AEB2 E0               [24] 1589 	movx	a,@dptr
      00AEB3 24 FE            [12] 1590 	add	a,#0xff - 0x01
      00AEB5 40 01            [24] 1591 	jc	00104$
                                   1592 ;	free result
      00AEB7 22               [24] 1593 	ret
      00AEB8                       1594 00104$:
                                   1595 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00AEB8 90 0C 47         [24] 1596 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AEBB 12 AF 76         [24] 1597 	lcall	_ak820_outline_0023
                                   1598 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00AEBE 40 06            [24] 1599 	jc	00107$
                                   1600 ;	free result
                                   1601 ;	quantum/vial.c:440: register_code16(keycode);
      00AEC0 12 43 1F         [24] 1602 	lcall	_ak820_outline_0116
      00AEC3 02 9B 92         [24] 1603 	ljmp	_register_code16
      00AEC6                       1604 00107$:
                                   1605 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00AEC6 90 0C 4D         [24] 1606 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0004)
      00AEC9 74 01            [12] 1607 	mov	a,#0x01
      00AECB F0               [24] 1608 	movx	@dptr,a
      00AECC 90 0C 4A         [24] 1609 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0001)
      00AECF 74 F0            [12] 1610 	mov	a,#0xf0
      00AED1 F0               [24] 1611 	movx	@dptr,a
      00AED2 90 0C 49         [24] 1612 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
      00AED5 F0               [24] 1613 	movx	@dptr,a
      00AED6 90 0C 4E         [24] 1614 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0005)
      00AED9 74 01            [12] 1615 	mov	a,#0x01
      00AEDB F0               [24] 1616 	movx	@dptr,a
      00AEDC 12 48 65         [24] 1617 	lcall	_timer_read
      00AEDF 12 43 24         [24] 1618 	lcall	_ak820_outline_0129
      00AEE2 43 06 01         [24] 1619 	orl	ar6,#0x01
      00AEE5 90 0C 4B         [24] 1620 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0002)
      00AEE8 12 47 BF         [24] 1621 	lcall	_ak820_outline_0056
                                   1622 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00AEEB 90 0C 49         [24] 1623 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
                                   1624 ;	quantum/vial.c:448: }
      00AEEE 02 6F 72         [24] 1625 	ljmp	_ak820_action_exec
                                   1626 ;------------------------------------------------------------
                                   1627 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1628 ;------------------------------------------------------------
                                   1629 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_656'
                                   1630 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_663'
                                   1631 ;------------------------------------------------------------
                                   1632 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1633 ;	-----------------------------------------
                                   1634 ;	 function vial_keycode_up
                                   1635 ;	-----------------------------------------
      00AEF1                       1636 _vial_keycode_up:
      00AEF1 12 38 47         [24] 1637 	lcall	_ak820_outline_0103
      00AEF4 90 0C 4F         [24] 1638 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AEF7 12 38 42         [24] 1639 	lcall	_ak820_outline_0102
                                   1640 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AEFA 90 0C 4F         [24] 1641 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AEFD 12 37 CD         [24] 1642 	lcall	_ak820_outline_0009
      00AF00 74 E0            [12] 1643 	mov	a,#0x100 - 0x20
      00AF02 2D               [12] 1644 	add	a,r5
      00AF03 50 19            [24] 1645 	jnc	00104$
      00AF05 C3               [12] 1646 	clr	c
      00AF06 74 FF            [12] 1647 	mov	a,#0xff
      00AF08 9C               [12] 1648 	subb	a,r4
      00AF09 74 4F            [12] 1649 	mov	a,#0x4f
      00AF0B 9D               [12] 1650 	subb	a,r5
      00AF0C 40 10            [24] 1651 	jc	00104$
                                   1652 ;	free result
                                   1653 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00AF0E 90 0C 4F         [24] 1654 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AF11 EE               [12] 1655 	mov	a,r6
      00AF12 12 38 58         [24] 1656 	lcall	_ak820_outline_0121
                                   1657 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00AF15 90 0C 4F         [24] 1658 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AF18 E0               [24] 1659 	movx	a,@dptr
      00AF19 24 FE            [12] 1660 	add	a,#0xff - 0x01
      00AF1B 40 01            [24] 1661 	jc	00104$
                                   1662 ;	free result
      00AF1D 22               [24] 1663 	ret
      00AF1E                       1664 00104$:
                                   1665 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00AF1E 90 0C 4F         [24] 1666 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AF21 12 AF 76         [24] 1667 	lcall	_ak820_outline_0023
                                   1668 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00AF24 40 06            [24] 1669 	jc	00107$
                                   1670 ;	free result
                                   1671 ;	quantum/vial.c:462: unregister_code16(keycode);
      00AF26 12 43 1F         [24] 1672 	lcall	_ak820_outline_0116
      00AF29 02 9B D7         [24] 1673 	ljmp	_unregister_code16
      00AF2C                       1674 00107$:
                                   1675 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00AF2C 90 0C 55         [24] 1676 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0004)
      00AF2F 74 01            [12] 1677 	mov	a,#0x01
      00AF31 F0               [24] 1678 	movx	@dptr,a
      00AF32 90 0C 52         [24] 1679 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0001)
      00AF35 74 F0            [12] 1680 	mov	a,#0xf0
      00AF37 F0               [24] 1681 	movx	@dptr,a
      00AF38 90 0C 51         [24] 1682 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
      00AF3B F0               [24] 1683 	movx	@dptr,a
      00AF3C 90 0C 56         [24] 1684 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0005)
      00AF3F E4               [12] 1685 	clr	a
      00AF40 F0               [24] 1686 	movx	@dptr,a
      00AF41 12 48 65         [24] 1687 	lcall	_timer_read
      00AF44 12 43 24         [24] 1688 	lcall	_ak820_outline_0129
      00AF47 43 06 01         [24] 1689 	orl	ar6,#0x01
      00AF4A 90 0C 53         [24] 1690 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0002)
      00AF4D 12 47 BF         [24] 1691 	lcall	_ak820_outline_0056
                                   1692 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00AF50 90 0C 51         [24] 1693 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
                                   1694 ;	quantum/vial.c:470: }
      00AF53 02 6F 72         [24] 1695 	ljmp	_ak820_action_exec
                                   1696 ;------------------------------------------------------------
                                   1697 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1698 ;------------------------------------------------------------
                                   1699 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_664'
                                   1700 ;i             Allocated with name '_vial_keycode_tap_i_30000_667'
                                   1701 ;------------------------------------------------------------
                                   1702 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1703 ;	-----------------------------------------
                                   1704 ;	 function vial_keycode_tap
                                   1705 ;	-----------------------------------------
      00AF56                       1706 _vial_keycode_tap:
      00AF56 12 38 47         [24] 1707 	lcall	_ak820_outline_0103
      00AF59 90 0C 57         [24] 1708 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00AF5C 12 38 42         [24] 1709 	lcall	_ak820_outline_0102
                                   1710 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00AF5F 90 0C 57         [24] 1711 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00AF62 12 37 A2         [24] 1712 	lcall	_ak820_outline_0004
      00AF65 C0 07            [24] 1713 	push	ar7
      00AF67 C0 06            [24] 1714 	push	ar6
      00AF69 12 AE 8B         [24] 1715 	lcall	_vial_keycode_down
      00AF6C D0 06            [24] 1716 	pop	ar6
      00AF6E D0 07            [24] 1717 	pop	ar7
                                   1718 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00AF70 12 43 1F         [24] 1719 	lcall	_ak820_outline_0116
                                   1720 ;	quantum/vial.c:476: }
      00AF73 02 AE F1         [24] 1721 	ljmp	_vial_keycode_up
                                   1722 ;------------------------------------------------------------
                                   1723 ;Allocation info for local variables in function 'process_record_vial'
                                   1724 ;------------------------------------------------------------
                                   1725 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1726 ;keycode       Allocated with name '_process_record_vial_keycode_10000_669'
                                   1727 ;------------------------------------------------------------
                                   1728 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1729 ;	-----------------------------------------
                                   1730 	.area CSEG    (CODE)
                                   1731 	.area CONST   (CODE)
                                   1732 	.area CONST   (CODE)
      00BAD6                       1733 _keyboard_definition:
      00BAD6 FD                    1734 	.db #0xfd	; 253
      00BAD7 37                    1735 	.db #0x37	; 55	'7'
      00BAD8 7A                    1736 	.db #0x7a	; 122	'z'
      00BAD9 58                    1737 	.db #0x58	; 88	'X'
      00BADA 5A                    1738 	.db #0x5a	; 90	'Z'
      00BADB 00                    1739 	.db #0x00	; 0
      00BADC 00                    1740 	.db #0x00	; 0
      00BADD 04                    1741 	.db #0x04	; 4
      00BADE E6                    1742 	.db #0xe6	; 230
      00BADF D6                    1743 	.db #0xd6	; 214
      00BAE0 B4                    1744 	.db #0xb4	; 180
      00BAE1 46                    1745 	.db #0x46	; 70	'F'
      00BAE2 02                    1746 	.db #0x02	; 2
      00BAE3 00                    1747 	.db #0x00	; 0
      00BAE4 21                    1748 	.db #0x21	; 33
      00BAE5 01                    1749 	.db #0x01	; 1
      00BAE6 00                    1750 	.db #0x00	; 0
      00BAE7 00                    1751 	.db #0x00	; 0
      00BAE8 00                    1752 	.db #0x00	; 0
      00BAE9 00                    1753 	.db #0x00	; 0
      00BAEA 37                    1754 	.db #0x37	; 55	'7'
      00BAEB 27                    1755 	.db #0x27	; 39
      00BAEC 97                    1756 	.db #0x97	; 151
      00BAED D6                    1757 	.db #0xd6	; 214
      00BAEE E0                    1758 	.db #0xe0	; 224
      00BAEF 03                    1759 	.db #0x03	; 3
      00BAF0 CB                    1760 	.db #0xcb	; 203
      00BAF1 01                    1761 	.db #0x01	; 1
      00BAF2 3C                    1762 	.db #0x3c	; 60
      00BAF3 00                    1763 	.db #0x00	; 0
      00BAF4 00                    1764 	.db #0x00	; 0
      00BAF5 3D                    1765 	.db #0x3d	; 61
      00BAF6 88                    1766 	.db #0x88	; 136
      00BAF7 CD                    1767 	.db #0xcd	; 205
      00BAF8 A5                    1768 	.db #0xa5	; 165
      00BAF9 AA                    1769 	.db #0xaa	; 170
      00BAFA E5                    1770 	.db #0xe5	; 229
      00BAFB A8                    1771 	.db #0xa8	; 168
      00BAFC 76                    1772 	.db #0x76	; 118	'v'
      00BAFD F6                    1773 	.db #0xf6	; 246
      00BAFE 43                    1774 	.db #0x43	; 67	'C'
      00BAFF 0E                    1775 	.db #0x0e	; 14
      00BB00 D2                    1776 	.db #0xd2	; 210
      00BB01 90                    1777 	.db #0x90	; 144
      00BB02 7D                    1778 	.db #0x7d	; 125
      00BB03 94                    1779 	.db #0x94	; 148
      00BB04 79                    1780 	.db #0x79	; 121	'y'
      00BB05 78                    1781 	.db #0x78	; 120	'x'
      00BB06 EF                    1782 	.db #0xef	; 239
      00BB07 49                    1783 	.db #0x49	; 73	'I'
      00BB08 3E                    1784 	.db #0x3e	; 62
      00BB09 EF                    1785 	.db #0xef	; 239
      00BB0A FD                    1786 	.db #0xfd	; 253
      00BB0B 8F                    1787 	.db #0x8f	; 143
      00BB0C EF                    1788 	.db #0xef	; 239
      00BB0D 00                    1789 	.db #0x00	; 0
      00BB0E C6                    1790 	.db #0xc6	; 198
      00BB0F D1                    1791 	.db #0xd1	; 209
      00BB10 DB                    1792 	.db #0xdb	; 219
      00BB11 FB                    1793 	.db #0xfb	; 251
      00BB12 EB                    1794 	.db #0xeb	; 235
      00BB13 DE                    1795 	.db #0xde	; 222
      00BB14 66                    1796 	.db #0x66	; 102	'f'
      00BB15 63                    1797 	.db #0x63	; 99	'c'
      00BB16 0C                    1798 	.db #0x0c	; 12
      00BB17 92                    1799 	.db #0x92	; 146
      00BB18 7B                    1800 	.db #0x7b	; 123
      00BB19 F9                    1801 	.db #0xf9	; 249
      00BB1A D4                    1802 	.db #0xd4	; 212
      00BB1B 7A                    1803 	.db #0x7a	; 122	'z'
      00BB1C 4F                    1804 	.db #0x4f	; 79	'O'
      00BB1D 83                    1805 	.db #0x83	; 131
      00BB1E 4B                    1806 	.db #0x4b	; 75	'K'
      00BB1F 86                    1807 	.db #0x86	; 134
      00BB20 0E                    1808 	.db #0x0e	; 14
      00BB21 6A                    1809 	.db #0x6a	; 106	'j'
      00BB22 F2                    1810 	.db #0xf2	; 242
      00BB23 22                    1811 	.db #0x22	; 34
      00BB24 22                    1812 	.db #0x22	; 34
      00BB25 0B                    1813 	.db #0x0b	; 11
      00BB26 03                    1814 	.db #0x03	; 3
      00BB27 BA                    1815 	.db #0xba	; 186
      00BB28 67                    1816 	.db #0x67	; 103	'g'
      00BB29 9B                    1817 	.db #0x9b	; 155
      00BB2A 7A                    1818 	.db #0x7a	; 122	'z'
      00BB2B E1                    1819 	.db #0xe1	; 225
      00BB2C BC                    1820 	.db #0xbc	; 188
      00BB2D 37                    1821 	.db #0x37	; 55	'7'
      00BB2E 26                    1822 	.db #0x26	; 38
      00BB2F 46                    1823 	.db #0x46	; 70	'F'
      00BB30 78                    1824 	.db #0x78	; 120	'x'
      00BB31 05                    1825 	.db #0x05	; 5
      00BB32 0D                    1826 	.db #0x0d	; 13
      00BB33 95                    1827 	.db #0x95	; 149
      00BB34 02                    1828 	.db #0x02	; 2
      00BB35 E4                    1829 	.db #0xe4	; 228
      00BB36 18                    1830 	.db #0x18	; 24
      00BB37 CA                    1831 	.db #0xca	; 202
      00BB38 33                    1832 	.db #0x33	; 51	'3'
      00BB39 EA                    1833 	.db #0xea	; 234
      00BB3A 24                    1834 	.db #0x24	; 36
      00BB3B C8                    1835 	.db #0xc8	; 200
      00BB3C 81                    1836 	.db #0x81	; 129
      00BB3D 4E                    1837 	.db #0x4e	; 78	'N'
      00BB3E 47                    1838 	.db #0x47	; 71	'G'
      00BB3F A8                    1839 	.db #0xa8	; 168
      00BB40 44                    1840 	.db #0x44	; 68	'D'
      00BB41 DD                    1841 	.db #0xdd	; 221
      00BB42 91                    1842 	.db #0x91	; 145
      00BB43 6D                    1843 	.db #0x6d	; 109	'm'
      00BB44 69                    1844 	.db #0x69	; 105	'i'
      00BB45 DB                    1845 	.db #0xdb	; 219
      00BB46 4F                    1846 	.db #0x4f	; 79	'O'
      00BB47 3A                    1847 	.db #0x3a	; 58
      00BB48 43                    1848 	.db #0x43	; 67	'C'
      00BB49 9D                    1849 	.db #0x9d	; 157
      00BB4A 26                    1850 	.db #0x26	; 38
      00BB4B 49                    1851 	.db #0x49	; 73	'I'
      00BB4C 4C                    1852 	.db #0x4c	; 76	'L'
      00BB4D EF                    1853 	.db #0xef	; 239
      00BB4E 2B                    1854 	.db #0x2b	; 43
      00BB4F D8                    1855 	.db #0xd8	; 216
      00BB50 55                    1856 	.db #0x55	; 85	'U'
      00BB51 95                    1857 	.db #0x95	; 149
      00BB52 70                    1858 	.db #0x70	; 112	'p'
      00BB53 B1                    1859 	.db #0xb1	; 177
      00BB54 CC                    1860 	.db #0xcc	; 204
      00BB55 CF                    1861 	.db #0xcf	; 207
      00BB56 13                    1862 	.db #0x13	; 19
      00BB57 32                    1863 	.db #0x32	; 50	'2'
      00BB58 6A                    1864 	.db #0x6a	; 106	'j'
      00BB59 A1                    1865 	.db #0xa1	; 161
      00BB5A FF                    1866 	.db #0xff	; 255
      00BB5B 99                    1867 	.db #0x99	; 153
      00BB5C 61                    1868 	.db #0x61	; 97	'a'
      00BB5D 95                    1869 	.db #0x95	; 149
      00BB5E B1                    1870 	.db #0xb1	; 177
      00BB5F 89                    1871 	.db #0x89	; 137
      00BB60 9B                    1872 	.db #0x9b	; 155
      00BB61 11                    1873 	.db #0x11	; 17
      00BB62 D9                    1874 	.db #0xd9	; 217
      00BB63 35                    1875 	.db #0x35	; 53	'5'
      00BB64 78                    1876 	.db #0x78	; 120	'x'
      00BB65 ED                    1877 	.db #0xed	; 237
      00BB66 CD                    1878 	.db #0xcd	; 205
      00BB67 94                    1879 	.db #0x94	; 148
      00BB68 6E                    1880 	.db #0x6e	; 110	'n'
      00BB69 60                    1881 	.db #0x60	; 96
      00BB6A 8E                    1882 	.db #0x8e	; 142
      00BB6B 63                    1883 	.db #0x63	; 99	'c'
      00BB6C 8B                    1884 	.db #0x8b	; 139
      00BB6D FF                    1885 	.db #0xff	; 255
      00BB6E 4E                    1886 	.db #0x4e	; 78	'N'
      00BB6F 20                    1887 	.db #0x20	; 32
      00BB70 7A                    1888 	.db #0x7a	; 122	'z'
      00BB71 B5                    1889 	.db #0xb5	; 181
      00BB72 87                    1890 	.db #0x87	; 135
      00BB73 C2                    1891 	.db #0xc2	; 194
      00BB74 35                    1892 	.db #0x35	; 53	'5'
      00BB75 A4                    1893 	.db #0xa4	; 164
      00BB76 6D                    1894 	.db #0x6d	; 109	'm'
      00BB77 18                    1895 	.db #0x18	; 24
      00BB78 C1                    1896 	.db #0xc1	; 193
      00BB79 A3                    1897 	.db #0xa3	; 163
      00BB7A DB                    1898 	.db #0xdb	; 219
      00BB7B 53                    1899 	.db #0x53	; 83	'S'
      00BB7C 1D                    1900 	.db #0x1d	; 29
      00BB7D EC                    1901 	.db #0xec	; 236
      00BB7E F0                    1902 	.db #0xf0	; 240
      00BB7F BF                    1903 	.db #0xbf	; 191
      00BB80 4A                    1904 	.db #0x4a	; 74	'J'
      00BB81 4C                    1905 	.db #0x4c	; 76	'L'
      00BB82 4A                    1906 	.db #0x4a	; 74	'J'
      00BB83 C4                    1907 	.db #0xc4	; 196
      00BB84 AA                    1908 	.db #0xaa	; 170
      00BB85 37                    1909 	.db #0x37	; 55	'7'
      00BB86 19                    1910 	.db #0x19	; 25
      00BB87 34                    1911 	.db #0x34	; 52	'4'
      00BB88 3F                    1912 	.db #0x3f	; 63
      00BB89 A1                    1913 	.db #0xa1	; 161
      00BB8A D3                    1914 	.db #0xd3	; 211
      00BB8B 1A                    1915 	.db #0x1a	; 26
      00BB8C 5C                    1916 	.db #0x5c	; 92
      00BB8D 03                    1917 	.db #0x03	; 3
      00BB8E 4D                    1918 	.db #0x4d	; 77	'M'
      00BB8F BC                    1919 	.db #0xbc	; 188
      00BB90 10                    1920 	.db #0x10	; 16
      00BB91 2E                    1921 	.db #0x2e	; 46
      00BB92 80                    1922 	.db #0x80	; 128
      00BB93 F7                    1923 	.db #0xf7	; 247
      00BB94 D6                    1924 	.db #0xd6	; 214
      00BB95 82                    1925 	.db #0x82	; 130
      00BB96 24                    1926 	.db #0x24	; 36
      00BB97 4C                    1927 	.db #0x4c	; 76	'L'
      00BB98 87                    1928 	.db #0x87	; 135
      00BB99 B9                    1929 	.db #0xb9	; 185
      00BB9A F8                    1930 	.db #0xf8	; 248
      00BB9B BE                    1931 	.db #0xbe	; 190
      00BB9C 67                    1932 	.db #0x67	; 103	'g'
      00BB9D 96                    1933 	.db #0x96	; 150
      00BB9E 89                    1934 	.db #0x89	; 137
      00BB9F 30                    1935 	.db #0x30	; 48	'0'
      00BBA0 C8                    1936 	.db #0xc8	; 200
      00BBA1 8D                    1937 	.db #0x8d	; 141
      00BBA2 2C                    1938 	.db #0x2c	; 44
      00BBA3 F5                    1939 	.db #0xf5	; 245
      00BBA4 06                    1940 	.db #0x06	; 6
      00BBA5 05                    1941 	.db #0x05	; 5
      00BBA6 7C                    1942 	.db #0x7c	; 124
      00BBA7 48                    1943 	.db #0x48	; 72	'H'
      00BBA8 1B                    1944 	.db #0x1b	; 27
      00BBA9 76                    1945 	.db #0x76	; 118	'v'
      00BBAA AA                    1946 	.db #0xaa	; 170
      00BBAB 3D                    1947 	.db #0x3d	; 61
      00BBAC 28                    1948 	.db #0x28	; 40
      00BBAD FC                    1949 	.db #0xfc	; 252
      00BBAE 80                    1950 	.db #0x80	; 128
      00BBAF 75                    1951 	.db #0x75	; 117	'u'
      00BBB0 EB                    1952 	.db #0xeb	; 235
      00BBB1 78                    1953 	.db #0x78	; 120	'x'
      00BBB2 D0                    1954 	.db #0xd0	; 208
      00BBB3 8A                    1955 	.db #0x8a	; 138
      00BBB4 8F                    1956 	.db #0x8f	; 143
      00BBB5 27                    1957 	.db #0x27	; 39
      00BBB6 F7                    1958 	.db #0xf7	; 247
      00BBB7 F2                    1959 	.db #0xf2	; 242
      00BBB8 EB                    1960 	.db #0xeb	; 235
      00BBB9 58                    1961 	.db #0x58	; 88	'X'
      00BBBA 37                    1962 	.db #0x37	; 55	'7'
      00BBBB 3C                    1963 	.db #0x3c	; 60
      00BBBC 2B                    1964 	.db #0x2b	; 43
      00BBBD 6F                    1965 	.db #0x6f	; 111	'o'
      00BBBE 0E                    1966 	.db #0x0e	; 14
      00BBBF C7                    1967 	.db #0xc7	; 199
      00BBC0 E2                    1968 	.db #0xe2	; 226
      00BBC1 A0                    1969 	.db #0xa0	; 160
      00BBC2 97                    1970 	.db #0x97	; 151
      00BBC3 EE                    1971 	.db #0xee	; 238
      00BBC4 FD                    1972 	.db #0xfd	; 253
      00BBC5 9F                    1973 	.db #0x9f	; 159
      00BBC6 45                    1974 	.db #0x45	; 69	'E'
      00BBC7 17                    1975 	.db #0x17	; 23
      00BBC8 94                    1976 	.db #0x94	; 148
      00BBC9 E6                    1977 	.db #0xe6	; 230
      00BBCA E7                    1978 	.db #0xe7	; 231
      00BBCB FA                    1979 	.db #0xfa	; 250
      00BBCC 4C                    1980 	.db #0x4c	; 76	'L'
      00BBCD 7A                    1981 	.db #0x7a	; 122	'z'
      00BBCE D6                    1982 	.db #0xd6	; 214
      00BBCF 7A                    1983 	.db #0x7a	; 122	'z'
      00BBD0 7B                    1984 	.db #0x7b	; 123
      00BBD1 ED                    1985 	.db #0xed	; 237
      00BBD2 10                    1986 	.db #0x10	; 16
      00BBD3 C5                    1987 	.db #0xc5	; 197
      00BBD4 BC                    1988 	.db #0xbc	; 188
      00BBD5 E3                    1989 	.db #0xe3	; 227
      00BBD6 A9                    1990 	.db #0xa9	; 169
      00BBD7 1F                    1991 	.db #0x1f	; 31
      00BBD8 CF                    1992 	.db #0xcf	; 207
      00BBD9 C4                    1993 	.db #0xc4	; 196
      00BBDA 9D                    1994 	.db #0x9d	; 157
      00BBDB DC                    1995 	.db #0xdc	; 220
      00BBDC 45                    1996 	.db #0x45	; 69	'E'
      00BBDD 2A                    1997 	.db #0x2a	; 42
      00BBDE 69                    1998 	.db #0x69	; 105	'i'
      00BBDF 57                    1999 	.db #0x57	; 87	'W'
      00BBE0 8F                    2000 	.db #0x8f	; 143
      00BBE1 EC                    2001 	.db #0xec	; 236
      00BBE2 85                    2002 	.db #0x85	; 133
      00BBE3 6C                    2003 	.db #0x6c	; 108	'l'
      00BBE4 43                    2004 	.db #0x43	; 67	'C'
      00BBE5 1C                    2005 	.db #0x1c	; 28
      00BBE6 BA                    2006 	.db #0xba	; 186
      00BBE7 89                    2007 	.db #0x89	; 137
      00BBE8 68                    2008 	.db #0x68	; 104	'h'
      00BBE9 4A                    2009 	.db #0x4a	; 74	'J'
      00BBEA 1C                    2010 	.db #0x1c	; 28
      00BBEB 91                    2011 	.db #0x91	; 145
      00BBEC 3F                    2012 	.db #0x3f	; 63
      00BBED D1                    2013 	.db #0xd1	; 209
      00BBEE B3                    2014 	.db #0xb3	; 179
      00BBEF 96                    2015 	.db #0x96	; 150
      00BBF0 1D                    2016 	.db #0x1d	; 29
      00BBF1 7C                    2017 	.db #0x7c	; 124
      00BBF2 14                    2018 	.db #0x14	; 20
      00BBF3 77                    2019 	.db #0x77	; 119	'w'
      00BBF4 9C                    2020 	.db #0x9c	; 156
      00BBF5 74                    2021 	.db #0x74	; 116	't'
      00BBF6 36                    2022 	.db #0x36	; 54	'6'
      00BBF7 FF                    2023 	.db #0xff	; 255
      00BBF8 2C                    2024 	.db #0x2c	; 44
      00BBF9 66                    2025 	.db #0x66	; 102	'f'
      00BBFA AF                    2026 	.db #0xaf	; 175
      00BBFB 0F                    2027 	.db #0x0f	; 15
      00BBFC 3C                    2028 	.db #0x3c	; 60
      00BBFD A2                    2029 	.db #0xa2	; 162
      00BBFE 23                    2030 	.db #0x23	; 35
      00BBFF 85                    2031 	.db #0x85	; 133
      00BC00 05                    2032 	.db #0x05	; 5
      00BC01 87                    2033 	.db #0x87	; 135
      00BC02 DA                    2034 	.db #0xda	; 218
      00BC03 61                    2035 	.db #0x61	; 97	'a'
      00BC04 5E                    2036 	.db #0x5e	; 94
      00BC05 42                    2037 	.db #0x42	; 66	'B'
      00BC06 54                    2038 	.db #0x54	; 84	'T'
      00BC07 60                    2039 	.db #0x60	; 96
      00BC08 23                    2040 	.db #0x23	; 35
      00BC09 CA                    2041 	.db #0xca	; 202
      00BC0A BC                    2042 	.db #0xbc	; 188
      00BC0B B3                    2043 	.db #0xb3	; 179
      00BC0C 18                    2044 	.db #0x18	; 24
      00BC0D 1D                    2045 	.db #0x1d	; 29
      00BC0E F8                    2046 	.db #0xf8	; 248
      00BC0F 0A                    2047 	.db #0x0a	; 10
      00BC10 55                    2048 	.db #0x55	; 85	'U'
      00BC11 CD                    2049 	.db #0xcd	; 205
      00BC12 A3                    2050 	.db #0xa3	; 163
      00BC13 DE                    2051 	.db #0xde	; 222
      00BC14 FF                    2052 	.db #0xff	; 255
      00BC15 B2                    2053 	.db #0xb2	; 178
      00BC16 2A                    2054 	.db #0x2a	; 42
      00BC17 35                    2055 	.db #0x35	; 53	'5'
      00BC18 00                    2056 	.db #0x00	; 0
      00BC19 D6                    2057 	.db #0xd6	; 214
      00BC1A 7B                    2058 	.db #0x7b	; 123
      00BC1B E8                    2059 	.db #0xe8	; 232
      00BC1C F2                    2060 	.db #0xf2	; 242
      00BC1D 1A                    2061 	.db #0x1a	; 26
      00BC1E BC                    2062 	.db #0xbc	; 188
      00BC1F F5                    2063 	.db #0xf5	; 245
      00BC20 7E                    2064 	.db #0x7e	; 126
      00BC21 48                    2065 	.db #0x48	; 72	'H'
      00BC22 72                    2066 	.db #0x72	; 114	'r'
      00BC23 E0                    2067 	.db #0xe0	; 224
      00BC24 E4                    2068 	.db #0xe4	; 228
      00BC25 E0                    2069 	.db #0xe0	; 224
      00BC26 27                    2070 	.db #0x27	; 39
      00BC27 87                    2071 	.db #0x87	; 135
      00BC28 9A                    2072 	.db #0x9a	; 154
      00BC29 51                    2073 	.db #0x51	; 81	'Q'
      00BC2A D4                    2074 	.db #0xd4	; 212
      00BC2B DD                    2075 	.db #0xdd	; 221
      00BC2C C3                    2076 	.db #0xc3	; 195
      00BC2D AA                    2077 	.db #0xaa	; 170
      00BC2E 49                    2078 	.db #0x49	; 73	'I'
      00BC2F 5A                    2079 	.db #0x5a	; 90	'Z'
      00BC30 2A                    2080 	.db #0x2a	; 42
      00BC31 00                    2081 	.db #0x00	; 0
      00BC32 A0                    2082 	.db #0xa0	; 160
      00BC33 8C                    2083 	.db #0x8c	; 140
      00BC34 FF                    2084 	.db #0xff	; 255
      00BC35 74                    2085 	.db #0x74	; 116	't'
      00BC36 BF                    2086 	.db #0xbf	; 191
      00BC37 EC                    2087 	.db #0xec	; 236
      00BC38 1D                    2088 	.db #0x1d	; 29
      00BC39 F1                    2089 	.db #0xf1	; 241
      00BC3A 00                    2090 	.db #0x00	; 0
      00BC3B 01                    2091 	.db #0x01	; 1
      00BC3C D8                    2092 	.db #0xd8	; 216
      00BC3D 02                    2093 	.db #0x02	; 2
      00BC3E CC                    2094 	.db #0xcc	; 204
      00BC3F 07                    2095 	.db #0x07	; 7
      00BC40 00                    2096 	.db #0x00	; 0
      00BC41 00                    2097 	.db #0x00	; 0
      00BC42 C4                    2098 	.db #0xc4	; 196
      00BC43 5E                    2099 	.db #0x5e	; 94
      00BC44 2C                    2100 	.db #0x2c	; 44
      00BC45 7E                    2101 	.db #0x7e	; 126
      00BC46 B1                    2102 	.db #0xb1	; 177
      00BC47 C4                    2103 	.db #0xc4	; 196
      00BC48 67                    2104 	.db #0x67	; 103	'g'
      00BC49 FB                    2105 	.db #0xfb	; 251
      00BC4A 02                    2106 	.db #0x02	; 2
      00BC4B 00                    2107 	.db #0x00	; 0
      00BC4C 00                    2108 	.db #0x00	; 0
      00BC4D 00                    2109 	.db #0x00	; 0
      00BC4E 00                    2110 	.db #0x00	; 0
      00BC4F 04                    2111 	.db #0x04	; 4
      00BC50 59                    2112 	.db #0x59	; 89	'Y'
      00BC51 5A                    2113 	.db #0x5a	; 90	'Z'
                                   2114 	.area CSEG    (CODE)
                                   2115 	.area CONST   (CODE)
      00BC52                       2116 _vial_handle_cmd_keyboard_uid_40000_622:
      00BC52 04                    2117 	.db #0x04	; 4
      00BC53 70                    2118 	.db #0x70	; 112	'p'
      00BC54 FF                    2119 	.db #0xff	; 255
      00BC55 90                    2120 	.db #0x90	; 144
      00BC56 01                    2121 	.db #0x01	; 1
      00BC57 B9                    2122 	.db #0xb9	; 185
      00BC58 15                    2123 	.db #0x15	; 21
      00BC59 D3                    2124 	.db #0xd3	; 211
                                   2125 	.area CSEG    (CODE)
                                   2126 	.area XINIT   (CODE)
      00BE88                       2127 __xinit__vial_unlocked:
      00BE88 00                    2128 	.db #0x00	;  0
      00BE89                       2129 __xinit__vial_unlock_in_progress:
      00BE89 00                    2130 	.db #0x00	;  0
      00BE8A                       2131 __xinit__vial_unlock_counter:
      00BE8A 00                    2132 	.db #0x00	; 0
      00BE8B                       2133 __xinit__vial_unlock_combo_rows:
      00BE8B 00                    2134 	.db #0x00	; 0
      00BE8C 00                    2135 	.db #0x00	; 0
      00BE8D                       2136 __xinit__vial_unlock_combo_cols:
      00BE8D 00                    2137 	.db #0x00	; 0
      00BE8E 05                    2138 	.db #0x05	; 5
                                   2139 	.area CABS    (ABS,CODE)
                                   2140 
                                   2141 ; Experimental exact instruction outlining.
                                   2142 	.globl _ak820_outline_0004
                                   2143 	.globl _ak820_outline_0007
                                   2144 	.globl _ak820_outline_0009
                                   2145 	.globl _ak820_outline_0010
                                   2146 	.globl _ak820_outline_0011
                                   2147 	.globl _ak820_outline_0013
                                   2148 	.globl _ak820_outline_0014
                                   2149 	.globl _ak820_outline_0019
                                   2150 	.globl _ak820_outline_0020
                                   2151 	.globl _ak820_outline_0023
                                   2152 	.globl _ak820_outline_0029
                                   2153 	.globl _ak820_outline_0032
                                   2154 	.globl _ak820_outline_0035
                                   2155 	.globl _ak820_outline_0044
                                   2156 	.globl _ak820_outline_0049
                                   2157 	.globl _ak820_outline_0052
                                   2158 	.globl _ak820_outline_0054
                                   2159 	.globl _ak820_outline_0056
                                   2160 	.globl _ak820_outline_0058
                                   2161 	.globl _ak820_outline_0070
                                   2162 	.globl _ak820_outline_0074
                                   2163 	.globl _ak820_outline_0095
                                   2164 	.globl _ak820_outline_0098
                                   2165 	.globl _ak820_outline_0102
                                   2166 	.globl _ak820_outline_0103
                                   2167 	.globl _ak820_outline_0116
                                   2168 	.globl _ak820_outline_0117
                                   2169 	.globl _ak820_outline_0120
                                   2170 	.globl _ak820_outline_0121
                                   2171 	.globl _ak820_outline_0123
                                   2172 	.globl _ak820_outline_0124
                                   2173 	.globl _ak820_outline_0129
                                   2174 	.globl _ak820_outline_0134
                                   2175 	.globl _ak820_outline_0139
                                   2176 	.globl _ak820_outline_0150
                                   2177 	.globl _ak820_outline_0164
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0023
      00AF76                       2181 _ak820_outline_0023:
      00AF76 E0               [24] 2182 	movx	a,@dptr
      00AF77 FE               [12] 2183 	mov	r6,a
      00AF78 A3               [24] 2184 	inc	dptr
      00AF79 E0               [24] 2185 	movx	a,@dptr
      00AF7A FF               [12] 2186 	mov	r7,a
      00AF7B 90 0C 45         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00AF7E EE               [12] 2188 	mov	a,r6
      00AF7F F0               [24] 2189 	movx	@dptr,a
      00AF80 EF               [12] 2190 	mov	a,r7
      00AF81 A3               [24] 2191 	inc	dptr
      00AF82 F0               [24] 2192 	movx	@dptr,a
      00AF83 8E 04            [24] 2193 	mov	ar4,r6
      00AF85 8F 05            [24] 2194 	mov	ar5,r7
      00AF87 C3               [12] 2195 	clr	c
      00AF88 74 FF            [12] 2196 	mov	a,#0xff
      00AF8A 9C               [12] 2197 	subb	a,r4
      00AF8B 74 1F            [12] 2198 	mov	a,#0x1f
      00AF8D 9D               [12] 2199 	subb	a,r5
      00AF8E 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0070
      00AF8F                       2204 _ak820_outline_0070:
      00AF8F A3               [24] 2205 	inc	dptr
      00AF90 F0               [24] 2206 	movx	@dptr,a
      00AF91 E4               [12] 2207 	clr	a
      00AF92 A3               [24] 2208 	inc	dptr
      00AF93 F0               [24] 2209 	movx	@dptr,a
      00AF94 90 0D 70         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00AF97 74 0A            [12] 2211 	mov	a,#0x0a
      00AF99 F0               [24] 2212 	movx	@dptr,a
      00AF9A E4               [12] 2213 	clr	a
      00AF9B A3               [24] 2214 	inc	dptr
      00AF9C F0               [24] 2215 	movx	@dptr,a
      00AF9D 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0123
      00AF9E                       2220 _ak820_outline_0123:
      00AF9E 24 F2            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00AFA0 F5 82            [12] 2222 	mov	dpl,a
      00AFA2 E4               [12] 2223 	clr	a
      00AFA3 34 0D            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00AFA5 F5 83            [12] 2225 	mov	dph,a
      00AFA7 E0               [24] 2226 	movx	a,@dptr
      00AFA8 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0124
      00AFA9                       2231 _ak820_outline_0124:
      00AFA9 24 F0            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00AFAB F5 82            [12] 2233 	mov	dpl,a
      00AFAD E4               [12] 2234 	clr	a
      00AFAE 34 0D            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00AFB0 F5 83            [12] 2236 	mov	dph,a
      00AFB2 E0               [24] 2237 	movx	a,@dptr
      00AFB3 22               [24] 2238 	ret
