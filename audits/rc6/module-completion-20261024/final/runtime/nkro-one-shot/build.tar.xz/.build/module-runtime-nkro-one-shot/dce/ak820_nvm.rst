                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         53 bits:
      000025                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B40                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B40 E5 82            [12]  215 	mov	a,dpl
      003B42 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B45 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B46 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B49 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B4C E0               [24]  221 	movx	a,@dptr
      003B4D 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B50 F0               [24]  223 	movx	@dptr,a
      003B51                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B51 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B53 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B54                        239 _ak820_nvm_diagnostic:
      003B54 12 38 47         [24]  240 	lcall	_ak820_outline_0103
      003B57 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B5A 12 38 42         [24]  242 	lcall	_ak820_outline_0102
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B5D 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B60 12 37 F9         [24]  245 	lcall	_ak820_outline_0049
      003B63 A2 09            [12]  246 	mov	c,_storage_failed
      003B65 E4               [12]  247 	clr	a
      003B66 33               [12]  248 	rlc	a
      003B67 12 43 1F         [24]  249 	lcall	_ak820_outline_0116
      003B6A 12 42 F4         [24]  250 	lcall	_ak820_outline_0058
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B6D A3               [24]  252 	inc	dptr
      003B6E A2 07            [12]  253 	mov	c,_page_valid
      003B70 E4               [12]  254 	clr	a
      003B71 33               [12]  255 	rlc	a
      003B72 12 42 C8         [24]  256 	lcall	_ak820_outline_0029
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B75 A2 08            [12]  258 	mov	c,_page_dirty
      003B77 E4               [12]  259 	clr	a
      003B78 33               [12]  260 	rlc	a
      003B79 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B7A 74 03            [12]  263 	mov	a,#0x03
      003B7C 12 43 49         [24]  264 	lcall	_ak820_outline_0155
      003B7F 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B82 E0               [24]  266 	movx	a,@dptr
      003B83 12 38 53         [24]  267 	lcall	_ak820_outline_0117
      003B86 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B87 74 04            [12]  270 	mov	a,#0x04
      003B89 12 43 49         [24]  271 	lcall	_ak820_outline_0155
      003B8C 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003B8F E0               [24]  273 	movx	a,@dptr
      003B90 12 38 53         [24]  274 	lcall	_ak820_outline_0117
      003B93 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003B94 12 42 BE         [24]  277 	lcall	_ak820_outline_0010
      003B97 E4               [12]  278 	clr	a
      003B98 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003B99 74 06            [12]  281 	mov	a,#0x06
      003B9B 12 43 29         [24]  282 	lcall	_ak820_outline_0132
      003B9E 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003BA1 E0               [24]  284 	movx	a,@dptr
      003BA2 12 43 1F         [24]  285 	lcall	_ak820_outline_0116
      003BA5 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BA6 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003BA7                        300 _crc_byte:
      003BA7 12 38 47         [24]  301 	lcall	_ak820_outline_0103
      003BAA 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003BAD 12 38 42         [24]  303 	lcall	_ak820_outline_0102
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BB0 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003BB3 E0               [24]  306 	movx	a,@dptr
      003BB4 FF               [12]  307 	mov	r7,a
      003BB5 7E 00            [12]  308 	mov	r6,#0x00
      003BB7 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003BBA E0               [24]  310 	movx	a,@dptr
      003BBB 6E               [12]  311 	xrl	a,r6
      003BBC F0               [24]  312 	movx	@dptr,a
      003BBD A3               [24]  313 	inc	dptr
      003BBE E0               [24]  314 	movx	a,@dptr
      003BBF 6F               [12]  315 	xrl	a,r7
      003BC0 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BC1 7F 00            [12]  318 	mov	r7,#0x00
      003BC3                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BC3 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003BC6 12 43 0D         [24]  322 	lcall	_ak820_outline_0090
      003BC9 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003BCC ED               [12]  324 	mov	a,r5
      003BCD 2D               [12]  325 	add	a,r5
      003BCE FB               [12]  326 	mov	r3,a
      003BCF EE               [12]  327 	mov	a,r6
      003BD0 33               [12]  328 	rlc	a
      003BD1 FC               [12]  329 	mov	r4,a
      003BD2 63 03 21         [24]  330 	xrl	ar3,#0x21
      003BD5 63 04 10         [24]  331 	xrl	ar4,#0x10
      003BD8 80 06            [24]  332 	sjmp	00107$
      003BDA                        333 00106$:
      003BDA ED               [12]  334 	mov	a,r5
      003BDB 2D               [12]  335 	add	a,r5
      003BDC FB               [12]  336 	mov	r3,a
      003BDD EE               [12]  337 	mov	a,r6
      003BDE 33               [12]  338 	rlc	a
      003BDF FC               [12]  339 	mov	r4,a
      003BE0                        340 00107$:
      003BE0 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003BE3 12 38 24         [24]  342 	lcall	_ak820_outline_0074
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BE6 0F               [12]  344 	inc	r7
      003BE7 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BEA 12 33 FC         [24]  347 	lcall	_ak820_outline_0120
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BED 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003BEE                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BEE 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003BF1 74 FF            [12]  363 	mov	a,#0xff
      003BF3 F0               [24]  364 	movx	@dptr,a
      003BF4 A3               [24]  365 	inc	dptr
      003BF5 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003BF6 7F 00            [12]  368 	mov	r7,#0x00
      003BF8                        369 00102$:
      003BF8 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003BFB 12 43 0D         [24]  371 	lcall	_ak820_outline_0090
      003BFE 12 43 13         [24]  372 	lcall	_ak820_outline_0100
      003C01 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C04 F0               [24]  374 	movx	@dptr,a
      003C05 12 38 5D         [24]  375 	lcall	_ak820_outline_0130
      003C08 C0 07            [24]  376 	push	ar7
      003C0A 12 3B A7         [24]  377 	lcall	_crc_byte
      003C0D AD 82            [24]  378 	mov	r5, dpl
      003C0F AE 83            [24]  379 	mov	r6, dph
      003C11 D0 07            [24]  380 	pop	ar7
      003C13 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C16 12 43 4F         [24]  382 	lcall	_ak820_outline_0156
      003C19 0F               [12]  383 	inc	r7
      003C1A BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C1D 12 38 5D         [24]  386 	lcall	_ak820_outline_0130
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C20 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C21                        399 _write_page:
      003C21 12 38 47         [24]  400 	lcall	_ak820_outline_0103
      003C24 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C27 12 38 42         [24]  402 	lcall	_ak820_outline_0102
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C2A 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C2D 12 37 A2         [24]  405 	lcall	_ak820_outline_0004
      003C30 C0 07            [24]  406 	push	ar7
      003C32 C0 06            [24]  407 	push	ar6
      003C34 12 39 B9         [24]  408 	lcall	_ak820_flash_erase
      003C37 E5 82            [12]  409 	mov	a, dpl
      003C39 D0 06            [24]  410 	pop	ar6
      003C3B D0 07            [24]  411 	pop	ar7
      003C3D 70 03            [24]  412 	jnz	00102$
      003C3F F5 82            [12]  413 	mov	dpl,a
      003C41 22               [24]  414 	ret
      003C42                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C42 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C45 74 19            [12]  418 	mov	a,#_page_data
      003C47 F0               [24]  419 	movx	@dptr,a
      003C48 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003C4A A3               [24]  421 	inc	dptr
      003C4B 12 42 F4         [24]  422 	lcall	_ak820_outline_0058
      003C4E 12 3A CD         [24]  423 	lcall	_ak820_flash_program_page
      003C51 E5 82            [12]  424 	mov	a, dpl
      003C53 70 03            [24]  425 	jnz	00120$
      003C55 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C57 22               [24]  428 	ret
      003C58                        429 00120$:
      003C58 7F 00            [12]  430 	mov	r7,#0x00
      003C5A                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C5A 8F 05            [24]  433 	mov	ar5,r7
      003C5C 7E 00            [12]  434 	mov	r6,#0x00
      003C5E 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003C61 12 38 3C         [24]  436 	lcall	_ak820_outline_0098
      003C64 ED               [12]  437 	mov	a,r5
      003C65 2B               [12]  438 	add	a, r3
      003C66 FB               [12]  439 	mov	r3,a
      003C67 EE               [12]  440 	mov	a,r6
      003C68 3C               [12]  441 	addc	a, r4
      003C69 FC               [12]  442 	mov	r4,a
      003C6A 12 33 FC         [24]  443 	lcall	_ak820_outline_0120
      003C6D 12 38 AC         [24]  444 	lcall	_ak820_flash_read
      003C70 AE 82            [24]  445 	mov	r6, dpl
      003C72 12 43 13         [24]  446 	lcall	_ak820_outline_0100
      003C75 FD               [12]  447 	mov	r5,a
      003C76 EE               [12]  448 	mov	a,r6
      003C77 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003C7A 80 04            [24]  450 	sjmp	00109$
      003C7C                        451 00149$:
      003C7C 75 82 00         [24]  452 	mov	dpl, #0x00
      003C7F 22               [24]  453 	ret
      003C80                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C80 0F               [12]  456 	inc	r7
      003C81 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C84 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C87 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003C88                        472 _journal_header_valid:
      003C88 12 38 47         [24]  473 	lcall	_ak820_outline_0103
      003C8B 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003C8E 12 38 42         [24]  475 	lcall	_ak820_outline_0102
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C91 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003C94 12 37 A2         [24]  478 	lcall	_ak820_outline_0004
      003C97 E0               [24]  479 	movx	a,@dptr
      003C98 FD               [12]  480 	mov	r5,a
      003C99 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003C9C 80 04            [24]  482 	sjmp	00116$
      003C9E                        483 00138$:
      003C9E 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CA1 22               [24]  486 	ret
      003CA2                        487 00116$:
      003CA2 7D 01            [12]  488 	mov	r5,#0x01
      003CA4                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CA4 ED               [12]  491 	mov	a,r5
      003CA5 12 37 E9         [24]  492 	lcall	_ak820_outline_0019
      003CA8 E0               [24]  493 	movx	a,@dptr
      003CA9 FC               [12]  494 	mov	r4,a
      003CAA 8D 02            [24]  495 	mov	ar2,r5
      003CAC 7B 00            [12]  496 	mov	r3,#0x00
      003CAE 74 04            [12]  497 	mov	a,#0x04
      003CB0 2A               [12]  498 	add	a, r2
      003CB1 FA               [12]  499 	mov	r2,a
      003CB2 E4               [12]  500 	clr	a
      003CB3 3B               [12]  501 	addc	a, r3
      003CB4 FB               [12]  502 	mov	r3,a
      003CB5 EA               [12]  503 	mov	a,r2
      003CB6 2E               [12]  504 	add	a, r6
      003CB7 F5 82            [12]  505 	mov	dpl,a
      003CB9 EB               [12]  506 	mov	a,r3
      003CBA 3F               [12]  507 	addc	a, r7
      003CBB F5 83            [12]  508 	mov	dph,a
      003CBD E0               [24]  509 	movx	a,@dptr
      003CBE 62 04            [12]  510 	xrl	ar4,a
      003CC0 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003CC3 80 04            [24]  512 	sjmp	00107$
      003CC5                        513 00139$:
      003CC5 75 82 00         [24]  514 	mov	dpl, #0x00
      003CC8 22               [24]  515 	ret
      003CC9                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CC9 0D               [12]  518 	inc	r5
      003CCA BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CCD 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CD0 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003CD1                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CD1 7F 00            [12]  538 	mov	r7,#0x00
      003CD3                        539 00115$:
      003CD3 EF               [12]  540 	mov	a,r7
      003CD4 24 68            [12]  541 	add	a, #_recover_journal_header_10000_46
      003CD6 FD               [12]  542 	mov	r5,a
      003CD7 E4               [12]  543 	clr	a
      003CD8 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CDA FE               [12]  545 	mov	r6,a
      003CDB 8F 04            [24]  546 	mov	ar4,r7
      003CDD 7B 00            [12]  547 	mov	r3,#0x00
      003CDF 74 40            [12]  548 	mov	a,#0x40
      003CE1 2C               [12]  549 	add	a, r4
      003CE2 FC               [12]  550 	mov	r4,a
      003CE3 74 EF            [12]  551 	mov	a,#0xef
      003CE5 3B               [12]  552 	addc	a, r3
      003CE6 FB               [12]  553 	mov	r3,a
      003CE7 12 43 55         [24]  554 	lcall	_ak820_outline_0178
      003CEA 12 38 AC         [24]  555 	lcall	_ak820_flash_read
      003CED AC 82            [24]  556 	mov	r4, dpl
      003CEF 12 42 FA         [24]  557 	lcall	_ak820_outline_0062
      003CF2 0F               [12]  558 	inc	r7
      003CF3 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003CF6 90 05 68         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003CF9 12 3C 88         [24]  562 	lcall	_journal_header_valid
      003CFC E5 82            [12]  563 	mov	a, dpl
      003CFE 70 01            [24]  564 	jnz	00103$
      003D00 22               [24]  565 	ret
      003D01                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D01 90 05 69         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D04 E0               [24]  569 	movx	a,@dptr
      003D05 FF               [12]  570 	mov	r7,a
      003D06 7E 00            [12]  571 	mov	r6,#0x00
      003D08 90 05 6A         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D0B E0               [24]  573 	movx	a,@dptr
      003D0C FC               [12]  574 	mov	r4,a
      003D0D E4               [12]  575 	clr	a
      003D0E 42 07            [12]  576 	orl	ar7,a
      003D10 EC               [12]  577 	mov	a,r4
      003D11 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D13 90 05 6B         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D16 E0               [24]  581 	movx	a,@dptr
      003D17 FD               [12]  582 	mov	r5,a
      003D18 7C 00            [12]  583 	mov	r4,#0x00
      003D1A 90 05 6C         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D1D E0               [24]  585 	movx	a,@dptr
      003D1E FA               [12]  586 	mov	r2,a
      003D1F E4               [12]  587 	clr	a
      003D20 12 43 2F         [24]  588 	lcall	_ak820_outline_0138
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D23 C3               [12]  590 	clr	c
      003D24 EF               [12]  591 	mov	a,r7
      003D25 94 A0            [12]  592 	subb	a,#0xa0
      003D27 EE               [12]  593 	mov	a,r6
      003D28 94 00            [12]  594 	subb	a,#0x00
      003D2A 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D2C 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D2F 02 3B 40         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D32                        601 00134$:
      003D32 7B 00            [12]  602 	mov	r3,#0x00
      003D34                        603 00117$:
      003D34 C0 05            [24]  604 	push	ar5
      003D36 C0 04            [24]  605 	push	ar4
      003D38 EB               [12]  606 	mov	a,r3
      003D39 24 19            [12]  607 	add	a, #_page_data
      003D3B F9               [12]  608 	mov	r1,a
      003D3C E4               [12]  609 	clr	a
      003D3D 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003D3F FA               [12]  611 	mov	r2,a
      003D40 8B 00            [24]  612 	mov	ar0,r3
      003D42 7D 00            [12]  613 	mov	r5,#0x00
      003D44 74 EF            [12]  614 	mov	a,#0xef
      003D46 2D               [12]  615 	add	a, r5
      003D47 FD               [12]  616 	mov	r5,a
      003D48 88 82            [24]  617 	mov	dpl, r0
      003D4A 8D 83            [24]  618 	mov	dph, r5
      003D4C 12 38 AC         [24]  619 	lcall	_ak820_flash_read
      003D4F AD 82            [24]  620 	mov	r5, dpl
      003D51 12 43 3F         [24]  621 	lcall	_ak820_outline_0151
      003D54 ED               [12]  622 	mov	a,r5
      003D55 F0               [24]  623 	movx	@dptr,a
      003D56 0B               [12]  624 	inc	r3
      003D57 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003D5A 80 06            [24]  626 	sjmp	00191$
      003D5C                        627 00190$:
      003D5C D0 04            [24]  628 	pop	ar4
      003D5E D0 05            [24]  629 	pop	ar5
      003D60 80 D2            [24]  630 	sjmp	00117$
      003D62                        631 00191$:
      003D62 D0 04            [24]  632 	pop	ar4
      003D64 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D66 C0 07            [24]  635 	push	ar7
      003D68 C0 06            [24]  636 	push	ar6
      003D6A C0 05            [24]  637 	push	ar5
      003D6C C0 04            [24]  638 	push	ar4
      003D6E 12 3B EE         [24]  639 	lcall	_page_crc
      003D71 AA 82            [24]  640 	mov	r2, dpl
      003D73 AB 83            [24]  641 	mov	r3, dph
      003D75 D0 04            [24]  642 	pop	ar4
      003D77 D0 05            [24]  643 	pop	ar5
      003D79 D0 06            [24]  644 	pop	ar6
      003D7B D0 07            [24]  645 	pop	ar7
      003D7D EA               [12]  646 	mov	a,r2
      003D7E B5 05 06         [24]  647 	cjne	a,ar5,00192$
      003D81 EB               [12]  648 	mov	a,r3
      003D82 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      003D85 80 06            [24]  650 	sjmp	00113$
      003D87                        651 00192$:
      003D87 75 82 02         [24]  652 	mov	dpl, #0x02
      003D8A 02 3B 40         [24]  653 	ljmp	_nvm_fail
      003D8D                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D8D EE               [12]  656 	mov	a,r6
      003D8E 54 03            [12]  657 	anl	a,#0x03
      003D90 A2 E0            [12]  658 	mov	c,acc.0
      003D92 CF               [12]  659 	xch	a,r7
      003D93 13               [12]  660 	rrc	a
      003D94 CF               [12]  661 	xch	a,r7
      003D95 13               [12]  662 	rrc	a
      003D96 A2 E0            [12]  663 	mov	c,acc.0
      003D98 CF               [12]  664 	xch	a,r7
      003D99 13               [12]  665 	rrc	a
      003D9A CF               [12]  666 	xch	a,r7
      003D9B 13               [12]  667 	rrc	a
      003D9C CF               [12]  668 	xch	a,r7
      003D9D 24 C7            [12]  669 	add	a,#0xc7
      003D9F FE               [12]  670 	mov	r6,a
      003DA0 12 43 44         [24]  671 	lcall	_ak820_outline_0152
      003DA3 12 3C 21         [24]  672 	lcall	_write_page
      003DA6 E5 82            [12]  673 	mov	a, dpl
      003DA8 70 06            [24]  674 	jnz	00110$
      003DAA 75 82 03         [24]  675 	mov	dpl, #0x03
      003DAD 02 3B 40         [24]  676 	ljmp	_nvm_fail
      003DB0                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DB0 90 EF 40         [24]  679 	mov	dptr,#0xef40
      003DB3 12 39 B9         [24]  680 	lcall	_ak820_flash_erase
      003DB6 E5 82            [12]  681 	mov	a, dpl
      003DB8 70 06            [24]  682 	jnz	00119$
      003DBA 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DBD 02 3B 40         [24]  685 	ljmp	_nvm_fail
      003DC0                        686 00119$:
      003DC0 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      003DC1                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      003DC1 C2 09            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DC3 90 05 5B         [24]  700 	mov	dptr,#_first_failure_stage
      003DC6 E4               [12]  701 	clr	a
      003DC7 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      003DC8 C2 08            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      003DCA C2 07            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DCC 90 05 5A         [24]  709 	mov	dptr,#_batch_depth
      003DCF E4               [12]  710 	clr	a
      003DD0 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DD1 12 3C D1         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DD4 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      003DD7                        724 _ak820_nvm_ok:
      003DD7 A2 09            [12]  725 	mov	c,_storage_failed
      003DD9 B3               [12]  726 	cpl	c
      003DDA 92 0A            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DDC 12 38 79         [24]  728 	lcall	_ak820_outline_0165
      003DDF 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      003DE0                        737 _ak820_nvm_schema_fault:
      003DE0 75 82 10         [24]  738 	mov	dpl, #0x10
      003DE3 02 3B 40         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      003DE6                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DE6 30 08 03         [24]  754 	jnb	_page_dirty,00101$
      003DE9 30 09 01         [24]  755 	jnb	_storage_failed,00102$
      003DEC                        756 00101$:
      003DEC 22               [24]  757 	ret
      003DED                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DED 12 3B EE         [24]  760 	lcall	_page_crc
      003DF0 12 43 24         [24]  761 	lcall	_ak820_outline_0129
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003DF3 90 05 71         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003DF6 74 A5            [12]  764 	mov	a,#0xa5
      003DF8 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003DF9 90 05 59         [24]  767 	mov	dptr,#_cached_page
      003DFC E0               [24]  768 	movx	a,@dptr
      003DFD 90 05 72         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E00 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E01 90 05 73         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E04 E4               [12]  773 	clr	a
      003E05 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E06 8E 05            [24]  776 	mov	ar5,r6
      003E08 90 05 74         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E0B ED               [12]  778 	mov	a,r5
      003E0C F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E0D 8F 06            [24]  781 	mov	ar6,r7
      003E0F 90 05 75         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E12 EE               [12]  783 	mov	a,r6
      003E13 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E14 7F 01            [12]  786 	mov	r7,#0x01
      003E16                        787 00128$:
      003E16 8F 06            [24]  788 	mov	ar6,r7
      003E18 EE               [12]  789 	mov	a,r6
      003E19 24 04            [12]  790 	add	a,#0x04
      003E1B FE               [12]  791 	mov	r6,a
      003E1C 33               [12]  792 	rlc	a
      003E1D 95 E0            [12]  793 	subb	a,acc
      003E1F FD               [12]  794 	mov	r5,a
      003E20 EE               [12]  795 	mov	a,r6
      003E21 24 71            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      003E23 FE               [12]  797 	mov	r6,a
      003E24 ED               [12]  798 	mov	a,r5
      003E25 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E27 FD               [12]  800 	mov	r5,a
      003E28 12 42 D7         [24]  801 	lcall	_ak820_outline_0038
      003E2B FC               [12]  802 	mov	r4,a
      003E2C 63 04 FF         [24]  803 	xrl	ar4,#0xff
      003E2F 8E 82            [24]  804 	mov	dpl,r6
      003E31 8D 83            [24]  805 	mov	dph,r5
      003E33 EC               [12]  806 	mov	a,r4
      003E34 F0               [24]  807 	movx	@dptr,a
      003E35 0F               [12]  808 	inc	r7
      003E36 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E39 90 05 7A         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E3C 74 05            [12]  812 	mov	a,#0x05
      003E3E F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E3F 90 EF 40         [24]  815 	mov	dptr,#0xef40
      003E42 12 39 B9         [24]  816 	lcall	_ak820_flash_erase
      003E45 E5 82            [12]  817 	mov	a, dpl
      003E47 70 03            [24]  818 	jnz	00269$
      003E49 02 3F 30         [24]  819 	ljmp	00127$
      003E4C                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E4C 90 05 7A         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E4F 74 06            [12]  823 	mov	a,#0x06
      003E51 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E52 7F 00            [12]  826 	mov	r7,#0x00
      003E54                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E54 12 42 E3         [24]  829 	lcall	_ak820_outline_0050
      003E57 12 38 AC         [24]  830 	lcall	_ak820_flash_read
      003E5A E5 82            [12]  831 	mov	a, dpl
      003E5C 60 03            [24]  832 	jz	00270$
      003E5E 02 3F 30         [24]  833 	ljmp	00127$
      003E61                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E61 0F               [12]  836 	inc	r7
      003E62 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E65 90 05 7A         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E68 74 07            [12]  840 	mov	a,#0x07
      003E6A F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E6B 90 EF 00         [24]  843 	mov	dptr,#0xef00
      003E6E 12 3C 21         [24]  844 	lcall	_write_page
      003E71 E5 82            [12]  845 	mov	a, dpl
      003E73 70 03            [24]  846 	jnz	00273$
      003E75 02 3F 30         [24]  847 	ljmp	00127$
      003E78                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E78 90 05 7A         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E7B 74 08            [12]  851 	mov	a,#0x08
      003E7D F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E7E 7F 01            [12]  854 	mov	r7,#0x01
      003E80                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E80 12 42 D7         [24]  857 	lcall	_ak820_outline_0038
      003E83 FE               [12]  858 	mov	r6,a
      003E84 60 23            [24]  859 	jz	00133$
      003E86 8F 05            [24]  860 	mov	ar5,r7
      003E88 7C 00            [12]  861 	mov	r4,#0x00
      003E8A 74 40            [12]  862 	mov	a,#0x40
      003E8C 2D               [12]  863 	add	a, r5
      003E8D FD               [12]  864 	mov	r5,a
      003E8E 74 EF            [12]  865 	mov	a,#0xef
      003E90 3C               [12]  866 	addc	a, r4
      003E91 FC               [12]  867 	mov	r4,a
      003E92 90 04 F2         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      003E95 EE               [12]  869 	mov	a,r6
      003E96 F0               [24]  870 	movx	@dptr,a
      003E97 8D 82            [24]  871 	mov	dpl, r5
      003E99 8C 83            [24]  872 	mov	dph, r4
      003E9B C0 07            [24]  873 	push	ar7
      003E9D 12 3A 19         [24]  874 	lcall	_ak820_flash_program
      003EA0 E5 82            [12]  875 	mov	a, dpl
      003EA2 D0 07            [24]  876 	pop	ar7
      003EA4 70 03            [24]  877 	jnz	00275$
      003EA6 02 3F 30         [24]  878 	ljmp	00127$
      003EA9                        879 00275$:
      003EA9                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EA9 0F               [12]  882 	inc	r7
      003EAA BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EAD 90 05 7A         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB0 74 09            [12]  886 	mov	a,#0x09
      003EB2 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EB3 7F 01            [12]  889 	mov	r7,#0x01
      003EB5                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EB5 12 42 E3         [24]  892 	lcall	_ak820_outline_0050
      003EB8 12 38 AC         [24]  893 	lcall	_ak820_flash_read
      003EBB AE 82            [24]  894 	mov	r6, dpl
      003EBD 12 42 D7         [24]  895 	lcall	_ak820_outline_0038
      003EC0 FD               [12]  896 	mov	r5,a
      003EC1 EE               [12]  897 	mov	a,r6
      003EC2 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EC5 0F               [12]  900 	inc	r7
      003EC6 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003EC9 90 05 7A         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ECC 74 0A            [12]  904 	mov	a,#0x0a
      003ECE F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003ECF 90 05 71         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003ED2 E0               [24]  908 	movx	a,@dptr
      003ED3 90 04 F2         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      003ED6 F0               [24]  910 	movx	@dptr,a
      003ED7 90 EF 40         [24]  911 	mov	dptr,#0xef40
      003EDA 12 3A 19         [24]  912 	lcall	_ak820_flash_program
      003EDD E5 82            [12]  913 	mov	a, dpl
      003EDF 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EE1 90 05 7A         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE4 74 0B            [12]  917 	mov	a,#0x0b
      003EE6 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EE7 90 EF 40         [24]  920 	mov	dptr,#0xef40
      003EEA 12 38 AC         [24]  921 	lcall	_ak820_flash_read
      003EED AF 82            [24]  922 	mov	r7, dpl
      003EEF 90 05 71         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EF2 E0               [24]  924 	movx	a,@dptr
      003EF3 FE               [12]  925 	mov	r6,a
      003EF4 EF               [12]  926 	mov	a,r7
      003EF5 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003EF8 90 05 7A         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EFB 74 0C            [12]  930 	mov	a,#0x0c
      003EFD F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003EFE 90 05 59         [24]  933 	mov	dptr,#_cached_page
      003F01 E0               [24]  934 	movx	a,@dptr
      003F02 FE               [12]  935 	mov	r6,a
      003F03 E4               [12]  936 	clr	a
      003F04 C3               [12]  937 	clr	c
      003F05 CE               [12]  938 	xch	a,r6
      003F06 13               [12]  939 	rrc	a
      003F07 CE               [12]  940 	xch	a,r6
      003F08 13               [12]  941 	rrc	a
      003F09 A2 E0            [12]  942 	mov	c,acc.0
      003F0B CE               [12]  943 	xch	a,r6
      003F0C 13               [12]  944 	rrc	a
      003F0D CE               [12]  945 	xch	a,r6
      003F0E 13               [12]  946 	rrc	a
      003F0F CE               [12]  947 	xch	a,r6
      003F10 24 C7            [12]  948 	add	a,#0xc7
      003F12 FF               [12]  949 	mov	r7,a
      003F13 12 43 1F         [24]  950 	lcall	_ak820_outline_0116
      003F16 12 3C 21         [24]  951 	lcall	_write_page
      003F19 E5 82            [12]  952 	mov	a, dpl
      003F1B 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F1D 90 05 7A         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F20 74 0D            [12]  956 	mov	a,#0x0d
      003F22 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F23 90 EF 40         [24]  959 	mov	dptr,#0xef40
      003F26 12 39 B9         [24]  960 	lcall	_ak820_flash_erase
      003F29 E5 82            [12]  961 	mov	a, dpl
      003F2B 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      003F2D C2 08            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F2F 22               [24]  968 	ret
      003F30                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F30 90 05 7A         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F33 E0               [24]  972 	movx	a,@dptr
      003F34 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F36 02 3B 40         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      003F39                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F39 90 05 5A         [24]  985 	mov	dptr,#_batch_depth
      003F3C E0               [24]  986 	movx	a,@dptr
      003F3D FF               [12]  987 	mov	r7,a
      003F3E BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      003F41 75 82 0F         [24]  989 	mov	dpl, #0x0f
      003F44 02 3B 40         [24]  990 	ljmp	_nvm_fail
      003F47                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F47 90 05 5A         [24]  993 	mov	dptr,#_batch_depth
      003F4A EF               [12]  994 	mov	a,r7
      003F4B 04               [12]  995 	inc	a
      003F4C F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F4D 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      003F4E                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F4E 90 05 5A         [24] 1008 	mov	dptr,#_batch_depth
      003F51 E0               [24] 1009 	movx	a,@dptr
      003F52 FF               [12] 1010 	mov	r7,a
      003F53 E0               [24] 1011 	movx	a,@dptr
      003F54 60 06            [24] 1012 	jz	00102$
      003F56 EF               [12] 1013 	mov	a,r7
      003F57 14               [12] 1014 	dec	a
      003F58 90 05 5A         [24] 1015 	mov	dptr,#_batch_depth
      003F5B F0               [24] 1016 	movx	@dptr,a
      003F5C                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F5C 90 05 5A         [24] 1019 	mov	dptr,#_batch_depth
      003F5F E0               [24] 1020 	movx	a,@dptr
      003F60 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F62 02 3D E6         [24] 1023 	ljmp	_ak820_nvm_flush
      003F65                       1024 00105$:
      003F65 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      003F66                       1036 _load_page:
      003F66 E5 82            [12] 1037 	mov	a,dpl
      003F68 90 05 7B         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      003F6B F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F6C 30 07 17         [24] 1041 	jnb	_page_valid,00102$
      003F6F 90 05 59         [24] 1042 	mov	dptr,#_cached_page
      003F72 E0               [24] 1043 	movx	a,@dptr
      003F73 FF               [12] 1044 	mov	r7,a
      003F74 90 05 7B         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      003F77 E0               [24] 1046 	movx	a,@dptr
      003F78 FE               [12] 1047 	mov	r6,a
      003F79 EF               [12] 1048 	mov	a,r7
      003F7A B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      003F7D A2 09            [12] 1050 	mov	c,_storage_failed
      003F7F B3               [12] 1051 	cpl	c
      003F80 92 0B            [24] 1052 	mov  _load_page_sloc0_1_0,c
      003F82 12 38 79         [24] 1053 	lcall	_ak820_outline_0165
      003F85 22               [24] 1054 	ret
      003F86                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F86 12 3D E6         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F89 30 09 04         [24] 1059 	jnb	_storage_failed,00119$
      003F8C 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F8F 22               [24] 1062 	ret
      003F90                       1063 00119$:
      003F90 7F 00            [12] 1064 	mov	r7,#0x00
      003F92                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003F92 EF               [12] 1067 	mov	a,r7
      003F93 24 19            [12] 1068 	add	a, #_page_data
      003F95 FD               [12] 1069 	mov	r5,a
      003F96 E4               [12] 1070 	clr	a
      003F97 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      003F99 FE               [12] 1072 	mov	r6,a
      003F9A 90 05 7B         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      003F9D E0               [24] 1074 	movx	a,@dptr
      003F9E FC               [12] 1075 	mov	r4,a
      003F9F FA               [12] 1076 	mov	r2,a
      003FA0 E4               [12] 1077 	clr	a
      003FA1 C3               [12] 1078 	clr	c
      003FA2 CA               [12] 1079 	xch	a,r2
      003FA3 13               [12] 1080 	rrc	a
      003FA4 CA               [12] 1081 	xch	a,r2
      003FA5 13               [12] 1082 	rrc	a
      003FA6 A2 E0            [12] 1083 	mov	c,acc.0
      003FA8 CA               [12] 1084 	xch	a,r2
      003FA9 13               [12] 1085 	rrc	a
      003FAA CA               [12] 1086 	xch	a,r2
      003FAB 13               [12] 1087 	rrc	a
      003FAC CA               [12] 1088 	xch	a,r2
      003FAD 24 C7            [12] 1089 	add	a,#0xc7
      003FAF FB               [12] 1090 	mov	r3,a
      003FB0 8F 01            [24] 1091 	mov	ar1,r7
      003FB2 89 00            [24] 1092 	mov	ar0,r1
      003FB4 79 00            [12] 1093 	mov	r1,#0x00
      003FB6 E8               [12] 1094 	mov	a,r0
      003FB7 2A               [12] 1095 	add	a, r2
      003FB8 FA               [12] 1096 	mov	r2,a
      003FB9 E9               [12] 1097 	mov	a,r1
      003FBA 3B               [12] 1098 	addc	a, r3
      003FBB FB               [12] 1099 	mov	r3,a
      003FBC 12 43 35         [24] 1100 	lcall	_ak820_outline_0139
      003FBF 12 38 AC         [24] 1101 	lcall	_ak820_flash_read
      003FC2 AB 82            [24] 1102 	mov	r3, dpl
      003FC4 12 38 5D         [24] 1103 	lcall	_ak820_outline_0130
      003FC7 EB               [12] 1104 	mov	a,r3
      003FC8 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FC9 0F               [12] 1107 	inc	r7
      003FCA BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FCD 90 05 59         [24] 1110 	mov	dptr,#_cached_page
      003FD0 EC               [12] 1111 	mov	a,r4
      003FD1 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      003FD2 D2 07            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FD4 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FD7 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      003FD8                       1129 _read_offset:
      003FD8 12 38 47         [24] 1130 	lcall	_ak820_outline_0103
      003FDB 90 05 7C         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      003FDE 12 38 42         [24] 1132 	lcall	_ak820_outline_0102
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FE1 90 05 7C         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      003FE4 12 37 F9         [24] 1135 	lcall	_ak820_outline_0049
      003FE7 C3               [12] 1136 	clr	c
      003FE8 94 28            [12] 1137 	subb	a,#0x28
      003FEA 40 04            [24] 1138 	jc	00102$
      003FEC 75 82 00         [24] 1139 	mov	dpl, #0x00
      003FEF 22               [24] 1140 	ret
      003FF0                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FF0 30 07 34         [24] 1143 	jnb	_page_valid,00104$
      003FF3 8E 04            [24] 1144 	mov	ar4,r6
      003FF5 EF               [12] 1145 	mov	a,r7
      003FF6 A2 E7            [12] 1146 	mov	c,acc.7
      003FF8 CC               [12] 1147 	xch	a,r4
      003FF9 33               [12] 1148 	rlc	a
      003FFA CC               [12] 1149 	xch	a,r4
      003FFB 33               [12] 1150 	rlc	a
      003FFC A2 E7            [12] 1151 	mov	c,acc.7
      003FFE CC               [12] 1152 	xch	a,r4
      003FFF 33               [12] 1153 	rlc	a
      004000 CC               [12] 1154 	xch	a,r4
      004001 33               [12] 1155 	rlc	a
      004002 CC               [12] 1156 	xch	a,r4
      004003 54 03            [12] 1157 	anl	a,#0x03
      004005 FD               [12] 1158 	mov	r5,a
      004006 90 05 59         [24] 1159 	mov	dptr,#_cached_page
      004009 E0               [24] 1160 	movx	a,@dptr
      00400A FA               [12] 1161 	mov	r2,a
      00400B 7B 00            [12] 1162 	mov	r3,#0x00
      00400D EC               [12] 1163 	mov	a,r4
      00400E B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      004011 ED               [12] 1165 	mov	a,r5
      004012 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004015 74 3F            [12] 1168 	mov	a,#0x3f
      004017 5E               [12] 1169 	anl	a,r6
      004018 7D 00            [12] 1170 	mov	r5,#0x00
      00401A 24 19            [12] 1171 	add	a, #_page_data
      00401C F5 82            [12] 1172 	mov	dpl,a
      00401E ED               [12] 1173 	mov	a,r5
      00401F 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      004021 F5 83            [12] 1175 	mov	dph,a
      004023 E0               [24] 1176 	movx	a,@dptr
      004024 F5 82            [12] 1177 	mov	dpl,a
      004026 22               [24] 1178 	ret
      004027                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004027 74 C7            [12] 1181 	mov	a,#0xc7
      004029 2F               [12] 1182 	add	a, r7
      00402A FF               [12] 1183 	mov	r7,a
      00402B 12 43 1F         [24] 1184 	lcall	_ak820_outline_0116
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00402E 02 38 AC         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      004031                       1196 _eeprom_read_byte:
      004031 C0 07            [24] 1197 	push	ar7
      004033 C0 06            [24] 1198 	push	ar6
      004035 12 42 D0         [24] 1199 	lcall	_ak820_outline_0035
      004038 90 05 7E         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00403B 12 37 E1         [24] 1201 	lcall	_ak820_outline_0014
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00403E 90 05 7E         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004041 12 37 A2         [24] 1204 	lcall	_ak820_outline_0004
      004044 C0 06            [24] 1205 	push	ar6
      004046 C0 05            [24] 1206 	push	ar5
      004048 C0 04            [24] 1207 	push	ar4
      00404A C0 03            [24] 1208 	push	ar3
      00404C C0 02            [24] 1209 	push	ar2
      00404E C0 01            [24] 1210 	push	ar1
      004050 C0 00            [24] 1211 	push	ar0
      004052 12 3F D8         [24] 1212 	lcall	_read_offset
      004055 AF 82            [24] 1213 	mov	r7, dpl
      004057 D0 00            [24] 1214 	pop	ar0
      004059 D0 01            [24] 1215 	pop	ar1
      00405B D0 02            [24] 1216 	pop	ar2
      00405D D0 03            [24] 1217 	pop	ar3
      00405F D0 04            [24] 1218 	pop	ar4
      004061 D0 05            [24] 1219 	pop	ar5
      004063 D0 06            [24] 1220 	pop	ar6
      004065 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004067 D0 06            [24] 1223 	pop	ar6
      004069 D0 07            [24] 1224 	pop	ar7
      00406B 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      00406C                       1239 _ak820_eeprom_read_block_xdata:
      00406C 12 38 47         [24] 1240 	lcall	_ak820_outline_0103
      00406F 90 05 86         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004072 12 38 42         [24] 1242 	lcall	_ak820_outline_0102
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004075 90 05 81         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004078 12 37 F9         [24] 1245 	lcall	_ak820_outline_0049
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00407B 90 05 86         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00407E 12 38 18         [24] 1248 	lcall	_ak820_outline_0057
      004081 90 05 88         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004084 12 38 1E         [24] 1250 	lcall	_ak820_outline_0068
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004087 90 05 84         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00408A 12 38 18         [24] 1253 	lcall	_ak820_outline_0057
      00408D                       1254 00103$:
      00408D 8C 02            [24] 1255 	mov	ar2,r4
      00408F 8D 03            [24] 1256 	mov	ar3,r5
      004091 1C               [12] 1257 	dec	r4
      004092 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004095 1D               [12] 1259 	dec	r5
      004096                       1260 00130$:
      004096 EA               [12] 1261 	mov	a,r2
      004097 4B               [12] 1262 	orl	a,r3
      004098 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00409A 8E 02            [24] 1265 	mov	ar2,r6
      00409C 8F 03            [24] 1266 	mov	ar3,r7
      00409E 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      0040A0 2B               [12] 1268 	add	a,r3
      0040A1 50 17            [24] 1269 	jnc	00102$
      0040A3 90 05 88         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040A6 12 43 01         [24] 1271 	lcall	_ak820_outline_0080
      0040A9 12 43 35         [24] 1272 	lcall	_ak820_outline_0139
      0040AC E4               [12] 1273 	clr	a
      0040AD F0               [24] 1274 	movx	@dptr,a
      0040AE 90 05 88         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040B1 04               [12] 1276 	inc	a
      0040B2 2A               [12] 1277 	add	a, r2
      0040B3 F0               [24] 1278 	movx	@dptr,a
      0040B4 E4               [12] 1279 	clr	a
      0040B5 3B               [12] 1280 	addc	a, r3
      0040B6 A3               [24] 1281 	inc	dptr
      0040B7 F0               [24] 1282 	movx	@dptr,a
      0040B8 80 D3            [24] 1283 	sjmp	00103$
      0040BA                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040BA 90 05 88         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040BD 12 43 01         [24] 1287 	lcall	_ak820_outline_0080
      0040C0 12 43 1F         [24] 1288 	lcall	_ak820_outline_0116
      0040C3 C0 07            [24] 1289 	push	ar7
      0040C5 C0 06            [24] 1290 	push	ar6
      0040C7 C0 05            [24] 1291 	push	ar5
      0040C9 C0 04            [24] 1292 	push	ar4
      0040CB C0 03            [24] 1293 	push	ar3
      0040CD C0 02            [24] 1294 	push	ar2
      0040CF 12 3F D8         [24] 1295 	lcall	_read_offset
      0040D2 A9 82            [24] 1296 	mov	r1, dpl
      0040D4 D0 02            [24] 1297 	pop	ar2
      0040D6 D0 03            [24] 1298 	pop	ar3
      0040D8 D0 04            [24] 1299 	pop	ar4
      0040DA D0 05            [24] 1300 	pop	ar5
      0040DC D0 06            [24] 1301 	pop	ar6
      0040DE D0 07            [24] 1302 	pop	ar7
      0040E0 12 43 35         [24] 1303 	lcall	_ak820_outline_0139
      0040E3 E9               [12] 1304 	mov	a,r1
      0040E4 F0               [24] 1305 	movx	@dptr,a
      0040E5 90 05 88         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040E8 74 01            [12] 1307 	mov	a,#0x01
      0040EA 2A               [12] 1308 	add	a, r2
      0040EB F0               [24] 1309 	movx	@dptr,a
      0040EC E4               [12] 1310 	clr	a
      0040ED 3B               [12] 1311 	addc	a, r3
      0040EE A3               [24] 1312 	inc	dptr
      0040EF F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040F0 0E               [12] 1315 	inc	r6
      0040F1 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      0040F4 0F               [12] 1317 	inc	r7
      0040F5 80 96            [24] 1318 	sjmp	00103$
      0040F7                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0040F7 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      0040F8                       1337 _ak820_eeprom_write_block_xdata:
      0040F8 12 38 47         [24] 1338 	lcall	_ak820_outline_0103
      0040FB 90 05 8F         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0040FE 12 38 42         [24] 1340 	lcall	_ak820_outline_0102
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004101 90 05 8A         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004104 12 37 F9         [24] 1343 	lcall	_ak820_outline_0049
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004107 90 05 8F         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00410A 12 38 18         [24] 1346 	lcall	_ak820_outline_0057
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00410D 8E 02            [24] 1348 	mov	ar2,r6
      00410F 8F 03            [24] 1349 	mov	ar3,r7
      004111 C3               [12] 1350 	clr	c
      004112 E4               [12] 1351 	clr	a
      004113 9A               [12] 1352 	subb	a,r2
      004114 74 28            [12] 1353 	mov	a,#0x28
      004116 9B               [12] 1354 	subb	a,r3
      004117 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      004119 E4               [12] 1357 	clr	a
      00411A C3               [12] 1358 	clr	c
      00411B 9E               [12] 1359 	subb	a,r6
      00411C FA               [12] 1360 	mov	r2,a
      00411D 74 28            [12] 1361 	mov	a,#0x28
      00411F 9F               [12] 1362 	subb	a,r7
      004120 FB               [12] 1363 	mov	r3,a
      004121 90 05 8D         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004124 12 38 2A         [24] 1365 	lcall	_ak820_outline_0094
      004127 C3               [12] 1366 	clr	c
      004128 EA               [12] 1367 	mov	a,r2
      004129 98               [12] 1368 	subb	a,r0
      00412A EB               [12] 1369 	mov	a,r3
      00412B 99               [12] 1370 	subb	a,r1
      00412C 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      00412E                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00412E 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004131 02 3B 40         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004134                       1379 00125$:
      004134 90 05 8D         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004137 12 43 01         [24] 1381 	lcall	_ak820_outline_0080
      00413A                       1382 00108$:
      00413A 8A 00            [24] 1383 	mov	ar0,r2
      00413C 8B 01            [24] 1384 	mov	ar1,r3
      00413E 1A               [12] 1385 	dec	r2
      00413F BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      004142 1B               [12] 1387 	dec	r3
      004143                       1388 00159$:
      004143 E8               [12] 1389 	mov	a,r0
      004144 49               [12] 1390 	orl	a,r1
      004145 70 03            [24] 1391 	jnz	00160$
      004147 02 41 D1         [24] 1392 	ljmp	00110$
      00414A                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00414A C0 02            [24] 1395 	push	ar2
      00414C C0 03            [24] 1396 	push	ar3
      00414E 12 43 07         [24] 1397 	lcall	_ak820_outline_0089
      004151 F9               [12] 1398 	mov	r1,a
      004152 A3               [24] 1399 	inc	dptr
      004153 12 43 3A         [24] 1400 	lcall	_ak820_outline_0143
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004156 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004158 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00415A A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00415C E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00415E A2 E7            [12] 1406 	mov	c,acc.7
      004160 C8               [12] 1407 	xch	a,r0
      004161 33               [12] 1408 	rlc	a
      004162 C8               [12] 1409 	xch	a,r0
      004163 33               [12] 1410 	rlc	a
      004164 A2 E7            [12] 1411 	mov	c,acc.7
      004166 C8               [12] 1412 	xch	a,r0
      004167 33               [12] 1413 	rlc	a
      004168 C8               [12] 1414 	xch	a,r0
      004169 33               [12] 1415 	rlc	a
      00416A C8               [12] 1416 	xch	a,r0
      00416B 54 03            [12] 1417 	anl	a,#0x03
      00416D FB               [12] 1418 	mov	r3,a
      00416E 88 82            [24] 1419 	mov	dpl, r0
      004170 C0 07            [24] 1420 	push	ar7
      004172 C0 06            [24] 1421 	push	ar6
      004174 C0 05            [24] 1422 	push	ar5
      004176 C0 04            [24] 1423 	push	ar4
      004178 C0 03            [24] 1424 	push	ar3
      00417A C0 02            [24] 1425 	push	ar2
      00417C C0 01            [24] 1426 	push	ar1
      00417E 12 3F 66         [24] 1427 	lcall	_load_page
      004181 E5 82            [12] 1428 	mov	a, dpl
      004183 D0 01            [24] 1429 	pop	ar1
      004185 D0 02            [24] 1430 	pop	ar2
      004187 D0 03            [24] 1431 	pop	ar3
      004189 D0 04            [24] 1432 	pop	ar4
      00418B D0 05            [24] 1433 	pop	ar5
      00418D D0 06            [24] 1434 	pop	ar6
      00418F D0 07            [24] 1435 	pop	ar7
      004191 D0 03            [24] 1436 	pop	ar3
      004193 D0 02            [24] 1437 	pop	ar2
      004195 70 01            [24] 1438 	jnz	00105$
      004197 22               [24] 1439 	ret
      004198                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004198 C0 06            [24] 1442 	push	ar6
      00419A C0 07            [24] 1443 	push	ar7
      00419C 74 3F            [12] 1444 	mov	a,#0x3f
      00419E 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041A0 7F 00            [12] 1446 	mov	r7,#0x00
      0041A2 24 19            [12] 1447 	add	a, #_page_data
      0041A4 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041A6 EF               [12] 1449 	mov	a,r7
      0041A7 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      0041A9 F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041AB 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041AE 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041B1 E0               [24] 1454 	movx	a,@dptr
      0041B2 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      0041B5 D0 07            [24] 1456 	pop	ar7
      0041B7 D0 06            [24] 1457 	pop	ar6
      0041B9 80 0E            [24] 1458 	sjmp	00107$
      0041BB                       1459 00162$:
      0041BB D0 07            [24] 1460 	pop	ar7
      0041BD D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041BF 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041C2 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041C5 E9               [12] 1465 	mov	a,r1
      0041C6 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      0041C7 D2 08            [12] 1469 	setb	_page_dirty
      0041C9                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041C9 0E               [12] 1472 	inc	r6
      0041CA BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      0041CD 0F               [12] 1474 	inc	r7
      0041CE                       1475 00163$:
      0041CE 02 41 3A         [24] 1476 	ljmp	00108$
      0041D1                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041D1 90 05 5A         [24] 1479 	mov	dptr,#_batch_depth
      0041D4 E0               [24] 1480 	movx	a,@dptr
      0041D5 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041D7 02 3D E6         [24] 1483 	ljmp	_ak820_nvm_flush
      0041DA                       1484 00113$:
      0041DA 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      0041DB                       1503 _ak820_eeprom_update_block_xdata:
      0041DB 12 38 47         [24] 1504 	lcall	_ak820_outline_0103
      0041DE 90 05 96         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E1 12 38 42         [24] 1506 	lcall	_ak820_outline_0102
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041E4 90 05 96         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E7 12 37 F9         [24] 1509 	lcall	_ak820_outline_0049
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041EA 90 05 91         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041ED E0               [24] 1512 	movx	a,@dptr
      0041EE F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041F0 A3               [24] 1514 	inc	dptr
      0041F1 E0               [24] 1515 	movx	a,@dptr
      0041F2 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0041F4 A3               [24] 1517 	inc	dptr
      0041F5 E0               [24] 1518 	movx	a,@dptr
      0041F6 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0041F8 A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0041FA AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0041FC E4               [12] 1523 	clr	a
      0041FD F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0041FF F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004201                       1526 00105$:
      004201 90 05 94         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004204 E0               [24] 1528 	movx	a,@dptr
      004205 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004207 A3               [24] 1530 	inc	dptr
      004208 E0               [24] 1531 	movx	a,@dptr
      004209 F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00420B C3               [12] 1533 	clr	c
      00420C E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00420E 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004210 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004212 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004214 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004216 89 00            [24] 1540 	mov	ar0,r1
      004218 8A 05            [24] 1541 	mov	ar5,r2
      00421A E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00421C 28               [12] 1543 	add	a, r0
      00421D F8               [12] 1544 	mov	r0,a
      00421E E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004220 3D               [12] 1546 	addc	a, r5
      004221 FD               [12] 1547 	mov	r5,a
      004222 88 82            [24] 1548 	mov	dpl, r0
      004224 8D 83            [24] 1549 	mov	dph, r5
      004226 C0 07            [24] 1550 	push	ar7
      004228 C0 06            [24] 1551 	push	ar6
      00422A C0 02            [24] 1552 	push	ar2
      00422C C0 01            [24] 1553 	push	ar1
      00422E 12 3F D8         [24] 1554 	lcall	_read_offset
      004231 AD 82            [24] 1555 	mov	r5, dpl
      004233 D0 01            [24] 1556 	pop	ar1
      004235 D0 02            [24] 1557 	pop	ar2
      004237 D0 06            [24] 1558 	pop	ar6
      004239 D0 07            [24] 1559 	pop	ar7
      00423B E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00423D 2E               [12] 1561 	add	a, r6
      00423E F5 82            [12] 1562 	mov	dpl,a
      004240 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004242 3F               [12] 1564 	addc	a, r7
      004243 F5 83            [12] 1565 	mov	dph,a
      004245 E0               [24] 1566 	movx	a,@dptr
      004246 FC               [12] 1567 	mov	r4,a
      004247 ED               [12] 1568 	mov	a,r5
      004248 B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      00424B 80 27            [24] 1570 	sjmp	00106$
      00424D                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00424D 90 05 96         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004250 E0               [24] 1574 	movx	a,@dptr
      004251 F8               [12] 1575 	mov	r0,a
      004252 A3               [24] 1576 	inc	dptr
      004253 E0               [24] 1577 	movx	a,@dptr
      004254 FD               [12] 1578 	mov	r5,a
      004255 90 05 8A         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004258 E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00425A F0               [24] 1581 	movx	@dptr,a
      00425B E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00425D A3               [24] 1583 	inc	dptr
      00425E F0               [24] 1584 	movx	@dptr,a
      00425F E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004261 A3               [24] 1586 	inc	dptr
      004262 F0               [24] 1587 	movx	@dptr,a
      004263 90 05 8D         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004266 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004268 F0               [24] 1590 	movx	@dptr,a
      004269 E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00426B A3               [24] 1592 	inc	dptr
      00426C F0               [24] 1593 	movx	@dptr,a
      00426D 88 82            [24] 1594 	mov	dpl, r0
      00426F 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004271 02 40 F8         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      004274                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004274 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004276 E4               [12] 1601 	clr	a
      004277 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00427A 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00427C 80 83            [24] 1604 	sjmp	00105$
      00427E                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00427E 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      00427F                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00427F 12 3D E6         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004282 7F 00            [12] 1622 	mov	r7,#0x00
      004284                       1623 00111$:
      004284 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      004287 22               [24] 1625 	ret
      004288                       1626 00165$:
      004288 20 09 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00428B 8F 82            [24] 1629 	mov	dpl, r7
      00428D C0 07            [24] 1630 	push	ar7
      00428F 12 3F 66         [24] 1631 	lcall	_load_page
      004292 E5 82            [12] 1632 	mov	a, dpl
      004294 D0 07            [24] 1633 	pop	ar7
      004296 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004298 22               [24] 1636 	ret
      004299                       1637 00126$:
      004299 7E 00            [12] 1638 	mov	r6,#0x00
      00429B                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00429B EE               [12] 1641 	mov	a,r6
      00429C 24 19            [12] 1642 	add	a, #_page_data
      00429E FC               [12] 1643 	mov	r4,a
      00429F E4               [12] 1644 	clr	a
      0042A0 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      0042A2 FD               [12] 1646 	mov	r5,a
      0042A3 12 43 07         [24] 1647 	lcall	_ak820_outline_0089
      0042A6 60 07            [24] 1648 	jz	00108$
      0042A8 12 38 53         [24] 1649 	lcall	_ak820_outline_0117
      0042AB E4               [12] 1650 	clr	a
      0042AC F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      0042AD D2 08            [12] 1653 	setb	_page_dirty
      0042AF                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042AF 0E               [12] 1656 	inc	r6
      0042B0 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042B3 C0 07            [24] 1659 	push	ar7
      0042B5 12 3D E6         [24] 1660 	lcall	_ak820_nvm_flush
      0042B8 D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042BA 0F               [12] 1663 	inc	r7
      0042BB 80 C7            [24] 1664 	sjmp	00111$
      0042BD                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042BD 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0004
                                   1675 	.globl _ak820_outline_0010
                                   1676 	.globl _ak820_outline_0014
                                   1677 	.globl _ak820_outline_0019
                                   1678 	.globl _ak820_outline_0029
                                   1679 	.globl _ak820_outline_0035
                                   1680 	.globl _ak820_outline_0038
                                   1681 	.globl _ak820_outline_0049
                                   1682 	.globl _ak820_outline_0050
                                   1683 	.globl _ak820_outline_0057
                                   1684 	.globl _ak820_outline_0058
                                   1685 	.globl _ak820_outline_0062
                                   1686 	.globl _ak820_outline_0068
                                   1687 	.globl _ak820_outline_0074
                                   1688 	.globl _ak820_outline_0080
                                   1689 	.globl _ak820_outline_0089
                                   1690 	.globl _ak820_outline_0090
                                   1691 	.globl _ak820_outline_0094
                                   1692 	.globl _ak820_outline_0098
                                   1693 	.globl _ak820_outline_0100
                                   1694 	.globl _ak820_outline_0102
                                   1695 	.globl _ak820_outline_0103
                                   1696 	.globl _ak820_outline_0116
                                   1697 	.globl _ak820_outline_0117
                                   1698 	.globl _ak820_outline_0120
                                   1699 	.globl _ak820_outline_0129
                                   1700 	.globl _ak820_outline_0130
                                   1701 	.globl _ak820_outline_0132
                                   1702 	.globl _ak820_outline_0138
                                   1703 	.globl _ak820_outline_0139
                                   1704 	.globl _ak820_outline_0143
                                   1705 	.globl _ak820_outline_0151
                                   1706 	.globl _ak820_outline_0152
                                   1707 	.globl _ak820_outline_0155
                                   1708 	.globl _ak820_outline_0156
                                   1709 	.globl _ak820_outline_0165
                                   1710 	.globl _ak820_outline_0178
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0010
      0042BE                       1714 _ak820_outline_0010:
      0042BE 8E 82            [24] 1715 	mov	dpl,r6
      0042C0 8F 83            [24] 1716 	mov	dph,r7
      0042C2 A3               [24] 1717 	inc	dptr
      0042C3 A3               [24] 1718 	inc	dptr
      0042C4 A3               [24] 1719 	inc	dptr
      0042C5 A3               [24] 1720 	inc	dptr
      0042C6 A3               [24] 1721 	inc	dptr
      0042C7 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0029
      0042C8                       1726 _ak820_outline_0029:
      0042C8 F0               [24] 1727 	movx	@dptr,a
      0042C9 8E 82            [24] 1728 	mov	dpl,r6
      0042CB 8F 83            [24] 1729 	mov	dph,r7
      0042CD A3               [24] 1730 	inc	dptr
      0042CE A3               [24] 1731 	inc	dptr
      0042CF 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0035
      0042D0                       1736 _ak820_outline_0035:
      0042D0 AF F0            [24] 1737 	mov	r7,b
      0042D2 AE 83            [24] 1738 	mov	r6,dph
      0042D4 E5 82            [12] 1739 	mov	a,dpl
      0042D6 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0038
      0042D7                       1744 _ak820_outline_0038:
      0042D7 EF               [12] 1745 	mov	a,r7
      0042D8 24 71            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      0042DA F5 82            [12] 1747 	mov	dpl,a
      0042DC E4               [12] 1748 	clr	a
      0042DD 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042DF F5 83            [12] 1750 	mov	dph,a
      0042E1 E0               [24] 1751 	movx	a,@dptr
      0042E2 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0050
      0042E3                       1756 _ak820_outline_0050:
      0042E3 8F 06            [24] 1757 	mov	ar6,r7
      0042E5 7D 00            [12] 1758 	mov	r5,#0x00
      0042E7 74 40            [12] 1759 	mov	a,#0x40
      0042E9 2E               [12] 1760 	add	a,r6
      0042EA FE               [12] 1761 	mov	r6,a
      0042EB 74 EF            [12] 1762 	mov	a,#0xef
      0042ED 3D               [12] 1763 	addc	a,r5
      0042EE FD               [12] 1764 	mov	r5,a
      0042EF 8E 82            [24] 1765 	mov	dpl,r6
      0042F1 8D 83            [24] 1766 	mov	dph,r5
      0042F3 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0058
      0042F4                       1771 _ak820_outline_0058:
      0042F4 F0               [24] 1772 	movx	@dptr,a
      0042F5 8E 82            [24] 1773 	mov	dpl,r6
      0042F7 8F 83            [24] 1774 	mov	dph,r7
      0042F9 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0062
      0042FA                       1779 _ak820_outline_0062:
      0042FA 8D 82            [24] 1780 	mov	dpl,r5
      0042FC 8E 83            [24] 1781 	mov	dph,r6
      0042FE EC               [12] 1782 	mov	a,r4
      0042FF F0               [24] 1783 	movx	@dptr,a
      004300 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0080
      004301                       1788 _ak820_outline_0080:
      004301 E0               [24] 1789 	movx	a,@dptr
      004302 FA               [12] 1790 	mov	r2,a
      004303 A3               [24] 1791 	inc	dptr
      004304 E0               [24] 1792 	movx	a,@dptr
      004305 FB               [12] 1793 	mov	r3,a
      004306 22               [24] 1794 	ret
                                   1795 
                                   1796 	.area CSEG (CODE)
                                   1797 ; function ak820_outline_0089
      004307                       1798 _ak820_outline_0089:
      004307 8C 82            [24] 1799 	mov	dpl,r4
      004309 8D 83            [24] 1800 	mov	dph,r5
      00430B E0               [24] 1801 	movx	a,@dptr
      00430C 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0090
      00430D                       1806 _ak820_outline_0090:
      00430D E0               [24] 1807 	movx	a,@dptr
      00430E FD               [12] 1808 	mov	r5,a
      00430F A3               [24] 1809 	inc	dptr
      004310 E0               [24] 1810 	movx	a,@dptr
      004311 FE               [12] 1811 	mov	r6,a
      004312 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0100
      004313                       1816 _ak820_outline_0100:
      004313 EF               [12] 1817 	mov	a,r7
      004314 24 19            [12] 1818 	add	a,#_page_data
      004316 F5 82            [12] 1819 	mov	dpl,a
      004318 E4               [12] 1820 	clr	a
      004319 34 05            [12] 1821 	addc	a,#(_page_data>>8)
      00431B F5 83            [12] 1822 	mov	dph,a
      00431D E0               [24] 1823 	movx	a,@dptr
      00431E 22               [24] 1824 	ret
                                   1825 
                                   1826 	.area CSEG (CODE)
                                   1827 ; function ak820_outline_0116
      00431F                       1828 _ak820_outline_0116:
      00431F 8E 82            [24] 1829 	mov	dpl,r6
      004321 8F 83            [24] 1830 	mov	dph,r7
      004323 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0129
      004324                       1835 _ak820_outline_0129:
      004324 AE 82            [24] 1836 	mov	r6,dpl
      004326 AF 83            [24] 1837 	mov	r7,dph
      004328 22               [24] 1838 	ret
                                   1839 
                                   1840 	.area CSEG (CODE)
                                   1841 ; function ak820_outline_0132
      004329                       1842 _ak820_outline_0132:
      004329 2E               [12] 1843 	add	a,r6
      00432A FE               [12] 1844 	mov	r6,a
      00432B E4               [12] 1845 	clr	a
      00432C 3F               [12] 1846 	addc	a,r7
      00432D FF               [12] 1847 	mov	r7,a
      00432E 22               [24] 1848 	ret
                                   1849 
                                   1850 	.area CSEG (CODE)
                                   1851 ; function ak820_outline_0138
      00432F                       1852 _ak820_outline_0138:
      00432F 42 05            [12] 1853 	orl	ar5,a
      004331 EA               [12] 1854 	mov	a,r2
      004332 42 04            [12] 1855 	orl	ar4,a
      004334 22               [24] 1856 	ret
                                   1857 
                                   1858 	.area CSEG (CODE)
                                   1859 ; function ak820_outline_0139
      004335                       1860 _ak820_outline_0139:
      004335 8A 82            [24] 1861 	mov	dpl,r2
      004337 8B 83            [24] 1862 	mov	dph,r3
      004339 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0143
      00433A                       1867 _ak820_outline_0143:
      00433A AC 82            [24] 1868 	mov	r4,dpl
      00433C AD 83            [24] 1869 	mov	r5,dph
      00433E 22               [24] 1870 	ret
                                   1871 
                                   1872 	.area CSEG (CODE)
                                   1873 ; function ak820_outline_0151
      00433F                       1874 _ak820_outline_0151:
      00433F 89 82            [24] 1875 	mov	dpl,r1
      004341 8A 83            [24] 1876 	mov	dph,r2
      004343 22               [24] 1877 	ret
                                   1878 
                                   1879 	.area CSEG (CODE)
                                   1880 ; function ak820_outline_0152
      004344                       1881 _ak820_outline_0152:
      004344 8F 82            [24] 1882 	mov	dpl,r7
      004346 8E 83            [24] 1883 	mov	dph,r6
      004348 22               [24] 1884 	ret
                                   1885 
                                   1886 	.area CSEG (CODE)
                                   1887 ; function ak820_outline_0155
      004349                       1888 _ak820_outline_0155:
      004349 2E               [12] 1889 	add	a,r6
      00434A FC               [12] 1890 	mov	r4,a
      00434B E4               [12] 1891 	clr	a
      00434C 3F               [12] 1892 	addc	a,r7
      00434D FD               [12] 1893 	mov	r5,a
      00434E 22               [24] 1894 	ret
                                   1895 
                                   1896 	.area CSEG (CODE)
                                   1897 ; function ak820_outline_0156
      00434F                       1898 _ak820_outline_0156:
      00434F ED               [12] 1899 	mov	a,r5
      004350 F0               [24] 1900 	movx	@dptr,a
      004351 EE               [12] 1901 	mov	a,r6
      004352 A3               [24] 1902 	inc	dptr
      004353 F0               [24] 1903 	movx	@dptr,a
      004354 22               [24] 1904 	ret
                                   1905 
                                   1906 	.area CSEG (CODE)
                                   1907 ; function ak820_outline_0178
      004355                       1908 _ak820_outline_0178:
      004355 8C 82            [24] 1909 	mov	dpl,r4
      004357 8B 83            [24] 1910 	mov	dph,r3
      004359 22               [24] 1911 	ret
