                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004D                        535 _fast_set_leds_sloc0_1_0:
      00004D                        536 	.ds 2
      00004F                        537 _fast_set_leds_sloc1_1_0:
      00004F                        538 	.ds 2
      000051                        539 _vialrgb_get_value_sloc0_1_0:
      000051                        540 	.ds 2
      000053                        541 _vialrgb_get_value_sloc1_1_0:
      000053                        542 	.ds 2
      000055                        543 _vialrgb_set_value_sloc0_1_0:
      000055                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C59                        569 _g_direct_mode_colors::
      000C59                        570 	.ds 246
      000D4F                        571 _get_supported_PARM_2:
      000D4F                        572 	.ds 1
      000D50                        573 _get_supported_args_10000_255:
      000D50                        574 	.ds 2
      000D52                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D52                        576 	.ds 2
      000D54                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D54                        578 	.ds 2
      000D56                        579 _set_mode_mode_10000_275:
      000D56                        580 	.ds 2
      000D58                        581 _get_matrix_pos_for_led_PARM_2:
      000D58                        582 	.ds 2
      000D5A                        583 _get_matrix_pos_for_led_led_10000_280:
      000D5A                        584 	.ds 2
      000D5C                        585 _fast_set_leds_PARM_2:
      000D5C                        586 	.ds 1
      000D5D                        587 _fast_set_leds_args_10000_282:
      000D5D                        588 	.ds 2
      000D5F                        589 _fast_set_leds_first_index_10001_285:
      000D5F                        590 	.ds 2
      000D61                        591 _fast_set_leds_num_leds_10001_285:
      000D61                        592 	.ds 1
      000D62                        593 _vialrgb_get_value_PARM_2:
      000D62                        594 	.ds 1
      000D63                        595 _vialrgb_get_value_data_10000_291:
      000D63                        596 	.ds 3
      000D66                        597 _vialrgb_set_value_PARM_2:
      000D66                        598 	.ds 1
      000D67                        599 _vialrgb_set_value_data_10000_302:
      000D67                        600 	.ds 3
      000D6A                        601 _vialrgb_save_PARM_2:
      000D6A                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00AFB4                        654 _get_supported:
      00AFB4 12 38 47         [24]  655 	lcall	_ak820_outline_0103
      00AFB7 90 0D 50         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00AFBA 12 38 42         [24]  657 	lcall	_ak820_outline_0102
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00AFBD 90 0D 50         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00AFC0 12 37 A2         [24]  660 	lcall	_ak820_outline_0004
      00AFC3 E0               [24]  661 	movx	a,@dptr
      00AFC4 FD               [12]  662 	mov	r5,a
      00AFC5 7C 00            [12]  663 	mov	r4,#0x00
      00AFC7 12 38 4C         [24]  664 	lcall	_ak820_outline_0107
      00AFCA FA               [12]  665 	mov	r2,a
      00AFCB E4               [12]  666 	clr	a
      00AFCC 12 43 2F         [24]  667 	lcall	_ak820_outline_0138
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00AFCF 90 0D 4F         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00AFD2 E0               [24]  670 	movx	a,@dptr
      00AFD3 FB               [12]  671 	mov	r3,a
      00AFD4 7A 00            [12]  672 	mov	r2,#0x00
      00AFD6                        673 00107$:
      00AFD6 C3               [12]  674 	clr	c
      00AFD7 EA               [12]  675 	mov	a,r2
      00AFD8 9B               [12]  676 	subb	a,r3
      00AFD9 50 0A            [24]  677 	jnc	00101$
      00AFDB EA               [12]  678 	mov	a,r2
      00AFDC 12 37 E9         [24]  679 	lcall	_ak820_outline_0019
      00AFDF 74 FF            [12]  680 	mov	a,#0xff
      00AFE1 F0               [24]  681 	movx	@dptr,a
      00AFE2 0A               [12]  682 	inc	r2
      00AFE3 80 F1            [24]  683 	sjmp	00107$
      00AFE5                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AFE5 8D 06            [24]  686 	mov	ar6,r5
      00AFE7 8C 07            [24]  687 	mov	ar7,r4
      00AFE9 8B 05            [24]  688 	mov	ar5,r3
      00AFEB 90 0D 50         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00AFEE 12 38 3C         [24]  690 	lcall	_ak820_outline_0098
      00AFF1 7A 00            [12]  691 	mov	r2,#0x00
      00AFF3                        692 00110$:
      00AFF3 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00AFF6                        694 00159$:
      00AFF6 50 45            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AFF8 EA               [12]  697 	mov	a,r2
      00AFF9 75 F0 02         [24]  698 	mov	b,#0x02
      00AFFC A4               [48]  699 	mul	ab
      00AFFD 24 5A            [12]  700 	add	a, #_supported_modes
      00AFFF F5 82            [12]  701 	mov	dpl,a
      00B001 74 BC            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B003 12 56 29         [24]  703 	lcall	_ak820_outline_0104
      00B006 F8               [12]  704 	mov	r0,a
      00B007 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B009 C3               [12]  707 	clr	c
      00B00A EE               [12]  708 	mov	a,r6
      00B00B 98               [12]  709 	subb	a,r0
      00B00C EF               [12]  710 	mov	a,r7
      00B00D 99               [12]  711 	subb	a,r1
      00B00E 50 2A            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B010 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B013                        715 00162$:
      00B013 40 25            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B015 C0 06            [24]  718 	push	ar6
      00B017 C0 07            [24]  719 	push	ar7
      00B019 88 07            [24]  720 	mov	ar7,r0
      00B01B 12 33 FC         [24]  721 	lcall	_ak820_outline_0120
      00B01E EF               [12]  722 	mov	a,r7
      00B01F 12 47 E2         [24]  723 	lcall	_ak820_outline_0119
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B022 A3               [24]  725 	inc	dptr
      00B023 89 00            [24]  726 	mov	ar0,r1
      00B025 E8               [12]  727 	mov	a,r0
      00B026 F0               [24]  728 	movx	@dptr,a
                                    729 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B027 1D               [12]  730 	dec	r5
      00B028 1D               [12]  731 	dec	r5
                                    732 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B029 74 02            [12]  733 	mov	a,#0x02
      00B02B 2B               [12]  734 	add	a, r3
      00B02C FB               [12]  735 	mov	r3,a
      00B02D E4               [12]  736 	clr	a
      00B02E 3C               [12]  737 	addc	a, r4
      00B02F FC               [12]  738 	mov	r4,a
      00B030 90 0D 50         [24]  739 	mov	dptr,#_get_supported_args_10000_255
      00B033 12 38 24         [24]  740 	lcall	_ak820_outline_0074
                                    741 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B036 D0 07            [24]  742 	pop	ar7
      00B038 D0 06            [24]  743 	pop	ar6
                                    744 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B03A                        745 00111$:
                                    746 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B03A 0A               [12]  747 	inc	r2
      00B03B 80 B6            [24]  748 	sjmp	00110$
      00B03D                        749 00127$:
      00B03D 90 0D 50         [24]  750 	mov	dptr,#_get_supported_args_10000_255
      00B040 12 38 24         [24]  751 	lcall	_ak820_outline_0074
                                    752 ;	quantum/vialrgb.c:55: }
      00B043 22               [24]  753 	ret
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    756 ;------------------------------------------------------------
                                    757 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    758 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    759 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    760 ;------------------------------------------------------------
                                    761 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    762 ;	-----------------------------------------
                                    763 ;	 function qmk_id_to_vialrgb_id
                                    764 ;	-----------------------------------------
      00B044                        765 _qmk_id_to_vialrgb_id:
      00B044 12 38 47         [24]  766 	lcall	_ak820_outline_0103
      00B047 90 0D 52         [24]  767 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B04A 12 38 42         [24]  768 	lcall	_ak820_outline_0102
                                    769 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B04D 90 0D 52         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B050 12 37 F9         [24]  771 	lcall	_ak820_outline_0049
      00B053 7D 00            [12]  772 	mov	r5,#0x00
      00B055                        773 00105$:
      00B055 BD 07 00         [24]  774 	cjne	r5,#0x07,00130$
      00B058                        775 00130$:
      00B058 50 19            [24]  776 	jnc	00103$
                                    777 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B05A 12 B4 79         [24]  778 	lcall	_ak820_outline_0043
      00B05D A3               [24]  779 	inc	dptr
      00B05E E4               [12]  780 	clr	a
      00B05F 93               [24]  781 	movc	a,@a+dptr
                                    782 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B060 7A 00            [12]  783 	mov	r2,#0x00
      00B062 B5 06 0B         [24]  784 	cjne	a,ar6,00106$
      00B065 EA               [12]  785 	mov	a,r2
      00B066 B5 07 07         [24]  786 	cjne	a,ar7,00106$
                                    787 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B069 12 33 FC         [24]  788 	lcall	_ak820_outline_0120
      00B06C 12 B4 A5         [24]  789 	lcall	_ak820_outline_0140
      00B06F 22               [24]  790 	ret
      00B070                        791 00106$:
                                    792 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B070 0D               [12]  793 	inc	r5
      00B071 80 E2            [24]  794 	sjmp	00105$
      00B073                        795 00103$:
                                    796 ;	quantum/vialrgb.c:63: return 0;
      00B073 90 00 00         [24]  797 	mov	dptr,#0x0000
                                    798 ;	quantum/vialrgb.c:64: }
      00B076 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    802 ;------------------------------------------------------------
                                    803 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    804 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    805 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function vialrgb_id_to_qmk_id
                                    810 ;	-----------------------------------------
      00B077                        811 _vialrgb_id_to_qmk_id:
      00B077 12 38 47         [24]  812 	lcall	_ak820_outline_0103
      00B07A 90 0D 54         [24]  813 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B07D 12 38 42         [24]  814 	lcall	_ak820_outline_0102
                                    815 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B080 90 0D 54         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B083 12 37 F9         [24]  817 	lcall	_ak820_outline_0049
      00B086 7D 00            [12]  818 	mov	r5,#0x00
      00B088                        819 00105$:
      00B088 BD 07 00         [24]  820 	cjne	r5,#0x07,00130$
      00B08B                        821 00130$:
      00B08B 50 19            [24]  822 	jnc	00103$
                                    823 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B08D 12 B4 79         [24]  824 	lcall	_ak820_outline_0043
      00B090 E4               [12]  825 	clr	a
      00B091 93               [24]  826 	movc	a,@a+dptr
                                    827 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B092 7A 00            [12]  828 	mov	r2,#0x00
      00B094 B5 06 0C         [24]  829 	cjne	a,ar6,00106$
      00B097 EA               [12]  830 	mov	a,r2
      00B098 B5 07 08         [24]  831 	cjne	a,ar7,00106$
                                    832 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B09B 12 33 FC         [24]  833 	lcall	_ak820_outline_0120
      00B09E A3               [24]  834 	inc	dptr
      00B09F 12 B4 A5         [24]  835 	lcall	_ak820_outline_0140
      00B0A2 22               [24]  836 	ret
      00B0A3                        837 00106$:
                                    838 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B0A3 0D               [12]  839 	inc	r5
      00B0A4 80 E2            [24]  840 	sjmp	00105$
      00B0A6                        841 00103$:
                                    842 ;	quantum/vialrgb.c:72: return 0;
      00B0A6 90 00 00         [24]  843 	mov	dptr,#0x0000
                                    844 ;	quantum/vialrgb.c:73: }
      00B0A9 22               [24]  845 	ret
                                    846 ;------------------------------------------------------------
                                    847 ;Allocation info for local variables in function 'get_mode'
                                    848 ;------------------------------------------------------------
                                    849 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    850 ;	-----------------------------------------
                                    851 ;	 function get_mode
                                    852 ;	-----------------------------------------
      00B0AA                        853 _get_mode:
                                    854 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B0AA 12 54 0F         [24]  855 	lcall	_rgb_matrix_is_enabled
      00B0AD E5 82            [12]  856 	mov	a, dpl
      00B0AF 70 04            [24]  857 	jnz	00102$
                                    858 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B0B1 90 00 00         [24]  859 	mov	dptr,#0x0000
      00B0B4 22               [24]  860 	ret
      00B0B5                        861 00102$:
                                    862 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B0B5 12 54 15         [24]  863 	lcall	_rgb_matrix_get_mode
      00B0B8 7E 00            [12]  864 	mov	r6,#0x00
      00B0BA 8E 83            [24]  865 	mov	dph, r6
                                    866 ;	quantum/vialrgb.c:80: }
      00B0BC 02 B0 44         [24]  867 	ljmp	_qmk_id_to_vialrgb_id
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'set_mode'
                                    870 ;------------------------------------------------------------
                                    871 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function set_mode
                                    876 ;	-----------------------------------------
      00B0BF                        877 _set_mode:
      00B0BF 12 38 47         [24]  878 	lcall	_ak820_outline_0103
      00B0C2 90 0D 56         [24]  879 	mov	dptr,#_set_mode_mode_10000_275
      00B0C5 12 38 42         [24]  880 	lcall	_ak820_outline_0102
                                    881 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B0C8 90 0D 56         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00B0CB 12 37 F9         [24]  883 	lcall	_ak820_outline_0049
      00B0CE 90 0D 56         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B0D1 12 6C 7A         [24]  885 	lcall	_ak820_outline_0034
      00B0D4 70 03            [24]  886 	jnz	00102$
                                    887 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B0D6 02 54 62         [24]  888 	ljmp	_rgb_matrix_disable_noeeprom
      00B0D9                        889 00102$:
                                    890 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B0D9 C0 07            [24]  891 	push	ar7
      00B0DB C0 06            [24]  892 	push	ar6
      00B0DD 12 54 51         [24]  893 	lcall	_rgb_matrix_enable_noeeprom
      00B0E0 D0 06            [24]  894 	pop	ar6
      00B0E2 D0 07            [24]  895 	pop	ar7
                                    896 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B0E4 12 43 1F         [24]  897 	lcall	_ak820_outline_0116
      00B0E7 12 B0 77         [24]  898 	lcall	_vialrgb_id_to_qmk_id
                                    899 ;	quantum/vialrgb.c:90: }
      00B0EA 02 54 6B         [24]  900 	ljmp	_rgb_matrix_mode_noeeprom
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    903 ;------------------------------------------------------------
                                    904 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    905 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    906 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function get_matrix_pos_for_led
                                    911 ;	-----------------------------------------
      00B0ED                        912 _get_matrix_pos_for_led:
      00B0ED 12 38 47         [24]  913 	lcall	_ak820_outline_0103
      00B0F0 90 0D 5A         [24]  914 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B0F3 12 38 42         [24]  915 	lcall	_ak820_outline_0102
                                    916 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B0F6 90 0D 5A         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B0F9 12 37 F9         [24]  918 	lcall	_ak820_outline_0049
      00B0FC EE               [12]  919 	mov	a,r6
      00B0FD 24 61            [12]  920 	add	a, #_ak820_rgb_slots
      00B0FF F5 82            [12]  921 	mov	dpl,a
      00B101 EF               [12]  922 	mov	a,r7
      00B102 34 B6            [12]  923 	addc	a, #(_ak820_rgb_slots >> 8)
      00B104 F5 83            [12]  924 	mov	dph,a
      00B106 E4               [12]  925 	clr	a
      00B107 93               [24]  926 	movc	a,@a+dptr
      00B108 FF               [12]  927 	mov	r7,a
                                    928 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B109 90 0D 58         [24]  929 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B10C 12 43 0D         [24]  930 	lcall	_ak820_outline_0090
      00B10F EF               [12]  931 	mov	a,r7
      00B110 12 56 5F         [24]  932 	lcall	_ak820_outline_0181
      00B113 12 7F 52         [24]  933 	lcall	_ak820_outline_0118
                                    934 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B116 12 38 5D         [24]  935 	lcall	_ak820_outline_0130
      00B119 A3               [24]  936 	inc	dptr
      00B11A 53 07 07         [24]  937 	anl	ar7,#0x07
      00B11D EF               [12]  938 	mov	a,r7
      00B11E F0               [24]  939 	movx	@dptr,a
                                    940 ;	quantum/vialrgb.c:110: }
      00B11F 22               [24]  941 	ret
                                    942 ;------------------------------------------------------------
                                    943 ;Allocation info for local variables in function 'fast_set_leds'
                                    944 ;------------------------------------------------------------
                                    945 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    946 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    947 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    948 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    949 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    950 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    951 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    952 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    953 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    954 ;------------------------------------------------------------
                                    955 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    956 ;	-----------------------------------------
                                    957 ;	 function fast_set_leds
                                    958 ;	-----------------------------------------
      00B120                        959 _fast_set_leds:
      00B120 12 38 47         [24]  960 	lcall	_ak820_outline_0103
      00B123 90 0D 5D         [24]  961 	mov	dptr,#_fast_set_leds_args_10000_282
      00B126 12 38 42         [24]  962 	lcall	_ak820_outline_0102
                                    963 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B129 90 0D 5C         [24]  964 	mov	dptr,#_fast_set_leds_PARM_2
      00B12C E0               [24]  965 	movx	a,@dptr
      00B12D FF               [12]  966 	mov	r7,a
      00B12E BF 03 00         [24]  967 	cjne	r7,#0x03,00159$
      00B131                        968 00159$:
      00B131 50 01            [24]  969 	jnc	00102$
      00B133 22               [24]  970 	ret
      00B134                        971 00102$:
                                    972 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B134 90 0D 5D         [24]  973 	mov	dptr,#_fast_set_leds_args_10000_282
      00B137 12 43 0D         [24]  974 	lcall	_ak820_outline_0090
      00B13A 12 47 C5         [24]  975 	lcall	_ak820_outline_0072
      00B13D 7B 00            [12]  976 	mov	r3,#0x00
      00B13F 12 38 5D         [24]  977 	lcall	_ak820_outline_0130
      00B142 A3               [24]  978 	inc	dptr
      00B143 E0               [24]  979 	movx	a,@dptr
      00B144 FA               [12]  980 	mov	r2,a
      00B145 79 00            [12]  981 	mov	r1,#0x00
      00B147 90 0D 5F         [24]  982 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B14A E9               [12]  983 	mov	a,r1
      00B14B 4C               [12]  984 	orl	a,r4
      00B14C F0               [24]  985 	movx	@dptr,a
      00B14D EA               [12]  986 	mov	a,r2
      00B14E 4B               [12]  987 	orl	a,r3
      00B14F A3               [24]  988 	inc	dptr
      00B150 F0               [24]  989 	movx	@dptr,a
                                    990 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B151 12 38 5D         [24]  991 	lcall	_ak820_outline_0130
      00B154 A3               [24]  992 	inc	dptr
      00B155 A3               [24]  993 	inc	dptr
      00B156 E0               [24]  994 	movx	a,@dptr
      00B157 90 0D 61         [24]  995 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B15A F0               [24]  996 	movx	@dptr,a
                                    997 ;	quantum/vialrgb.c:119: length -= 3;
      00B15B EF               [12]  998 	mov	a,r7
      00B15C 24 FD            [12]  999 	add	a,#0xfd
      00B15E 90 0D 5C         [24] 1000 	mov	dptr,#_fast_set_leds_PARM_2
      00B161 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/vialrgb.c:120: args += 3;
      00B162 90 0D 5D         [24] 1003 	mov	dptr,#_fast_set_leds_args_10000_282
      00B165 74 03            [12] 1004 	mov	a,#0x03
      00B167 2D               [12] 1005 	add	a, r5
      00B168 F0               [24] 1006 	movx	@dptr,a
      00B169 E4               [12] 1007 	clr	a
      00B16A 3E               [12] 1008 	addc	a, r6
      00B16B A3               [24] 1009 	inc	dptr
      00B16C F0               [24] 1010 	movx	@dptr,a
                                   1011 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B16D 90 0D 61         [24] 1012 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B170 E0               [24] 1013 	movx	a,@dptr
      00B171 FF               [12] 1014 	mov	r7,a
      00B172 75 F0 03         [24] 1015 	mov	b,#0x03
      00B175 A4               [48] 1016 	mul	ab
      00B176 FE               [12] 1017 	mov	r6,a
      00B177 AD F0            [24] 1018 	mov	r5,b
      00B179 90 0D 5C         [24] 1019 	mov	dptr,#_fast_set_leds_PARM_2
      00B17C E0               [24] 1020 	movx	a,@dptr
      00B17D FB               [12] 1021 	mov	r3,a
      00B17E 7C 00            [12] 1022 	mov	r4,#0x00
      00B180 C3               [12] 1023 	clr	c
      00B181 EB               [12] 1024 	mov	a,r3
      00B182 9E               [12] 1025 	subb	a,r6
      00B183 EC               [12] 1026 	mov	a,r4
      00B184 9D               [12] 1027 	subb	a,r5
      00B185 40 13            [24] 1028 	jc	00103$
                                   1029 ;	free result
      00B187 90 0D 5F         [24] 1030 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B18A 12 43 0D         [24] 1031 	lcall	_ak820_outline_0090
      00B18D 8D 03            [24] 1032 	mov	ar3,r5
      00B18F 8E 04            [24] 1033 	mov	ar4,r6
      00B191 C3               [12] 1034 	clr	c
      00B192 EB               [12] 1035 	mov	a,r3
      00B193 94 52            [12] 1036 	subb	a,#0x52
      00B195 EC               [12] 1037 	mov	a,r4
      00B196 94 00            [12] 1038 	subb	a,#0x00
      00B198 40 01            [24] 1039 	jc	00104$
      00B19A                       1040 00103$:
      00B19A 22               [24] 1041 	ret
      00B19B                       1042 00104$:
                                   1043 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B19B 74 52            [12] 1044 	mov	a,#0x52
      00B19D C3               [12] 1045 	clr	c
      00B19E 9D               [12] 1046 	subb	a,r5
      00B19F FB               [12] 1047 	mov	r3,a
      00B1A0 E4               [12] 1048 	clr	a
      00B1A1 9E               [12] 1049 	subb	a,r6
      00B1A2 FC               [12] 1050 	mov	r4,a
      00B1A3 7A 00            [12] 1051 	mov	r2,#0x00
      00B1A5 C3               [12] 1052 	clr	c
      00B1A6 EB               [12] 1053 	mov	a,r3
      00B1A7 9F               [12] 1054 	subb	a,r7
      00B1A8 EC               [12] 1055 	mov	a,r4
      00B1A9 9A               [12] 1056 	subb	a,r2
      00B1AA 50 08            [24] 1057 	jnc	00127$
                                   1058 ;	free result
      00B1AC 90 0D 61         [24] 1059 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B1AF 74 52            [12] 1060 	mov	a,#0x52
      00B1B1 C3               [12] 1061 	clr	c
      00B1B2 9D               [12] 1062 	subb	a,r5
      00B1B3 F0               [24] 1063 	movx	@dptr,a
                                   1064 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B1B4                       1065 00127$:
      00B1B4 90 0D 61         [24] 1066 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B1B7 E0               [24] 1067 	movx	a,@dptr
      00B1B8 FF               [12] 1068 	mov	r7,a
      00B1B9 90 0D 5F         [24] 1069 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B1BC 12 43 0D         [24] 1070 	lcall	_ak820_outline_0090
      00B1BF 7C 00            [12] 1071 	mov	r4,#0x00
      00B1C1                       1072 00110$:
      00B1C1 C3               [12] 1073 	clr	c
      00B1C2 EC               [12] 1074 	mov	a,r4
      00B1C3 9F               [12] 1075 	subb	a,r7
      00B1C4 40 01            [24] 1076 	jc	00164$
      00B1C6 22               [24] 1077 	ret
      00B1C7                       1078 00164$:
                                   1079 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B1C7 C0 07            [24] 1080 	push	ar7
      00B1C9 90 0D 79         [24] 1081 	mov	dptr,#__mulint_PARM_2
      00B1CC 12 43 4F         [24] 1082 	lcall	_ak820_outline_0156
      00B1CF 90 00 03         [24] 1083 	mov	dptr,#0x0003
      00B1D2 C0 07            [24] 1084 	push	ar7
      00B1D4 C0 06            [24] 1085 	push	ar6
      00B1D6 C0 05            [24] 1086 	push	ar5
      00B1D8 C0 04            [24] 1087 	push	ar4
      00B1DA 12 B6 11         [24] 1088 	lcall	__mulint
      00B1DD AA 82            [24] 1089 	mov	r2, dpl
      00B1DF AB 83            [24] 1090 	mov	r3, dph
      00B1E1 D0 04            [24] 1091 	pop	ar4
      00B1E3 D0 05            [24] 1092 	pop	ar5
      00B1E5 D0 06            [24] 1093 	pop	ar6
      00B1E7 D0 07            [24] 1094 	pop	ar7
      00B1E9 0D               [12] 1095 	inc	r5
      00B1EA BD 00 01         [24] 1096 	cjne	r5,#0x00,00165$
      00B1ED 0E               [12] 1097 	inc	r6
      00B1EE                       1098 00165$:
      00B1EE EA               [12] 1099 	mov	a,r2
      00B1EF 24 59            [12] 1100 	add	a, #_g_direct_mode_colors
      00B1F1 FA               [12] 1101 	mov	r2,a
      00B1F2 EB               [12] 1102 	mov	a,r3
      00B1F3 34 0C            [12] 1103 	addc	a, #(_g_direct_mode_colors >> 8)
      00B1F5 FB               [12] 1104 	mov	r3,a
                                   1105 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B1F6 8A 4D            [24] 1106 	mov	_fast_set_leds_sloc0_1_0,r2
      00B1F8 8B 4E            [24] 1107 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B1FA 12 B4 8B         [24] 1108 	lcall	_ak820_outline_0079
      00B1FD F8               [12] 1109 	mov	r0,a
      00B1FE 12 B4 99         [24] 1110 	lcall	_ak820_outline_0101
      00B201 85 4D 82         [24] 1111 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B204 85 4E 83         [24] 1112 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B207 E8               [12] 1113 	mov	a,r0
      00B208 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B209 74 01            [12] 1116 	mov	a,#0x01
      00B20B 2A               [12] 1117 	add	a, r2
      00B20C F5 4D            [12] 1118 	mov	_fast_set_leds_sloc0_1_0,a
      00B20E E4               [12] 1119 	clr	a
      00B20F 3B               [12] 1120 	addc	a, r3
      00B210 F5 4E            [12] 1121 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B212 90 0D 5D         [24] 1122 	mov	dptr,#_fast_set_leds_args_10000_282
      00B215 E0               [24] 1123 	movx	a,@dptr
      00B216 F8               [12] 1124 	mov	r0,a
      00B217 A3               [24] 1125 	inc	dptr
      00B218 E0               [24] 1126 	movx	a,@dptr
      00B219 FF               [12] 1127 	mov	r7,a
      00B21A 88 82            [24] 1128 	mov	dpl,r0
      00B21C 8F 83            [24] 1129 	mov	dph,r7
      00B21E E0               [24] 1130 	movx	a,@dptr
      00B21F F9               [12] 1131 	mov	r1,a
      00B220 90 0D 5D         [24] 1132 	mov	dptr,#_fast_set_leds_args_10000_282
      00B223 74 01            [12] 1133 	mov	a,#0x01
      00B225 28               [12] 1134 	add	a, r0
      00B226 F0               [24] 1135 	movx	@dptr,a
      00B227 E4               [12] 1136 	clr	a
      00B228 3F               [12] 1137 	addc	a, r7
      00B229 A3               [24] 1138 	inc	dptr
      00B22A F0               [24] 1139 	movx	@dptr,a
      00B22B 85 4D 82         [24] 1140 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B22E 85 4E 83         [24] 1141 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B231 E9               [12] 1142 	mov	a,r1
      00B232 F0               [24] 1143 	movx	@dptr,a
                                   1144 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B233 12 B4 8B         [24] 1145 	lcall	_ak820_outline_0079
      00B236 F5 4D            [12] 1146 	mov	_fast_set_leds_sloc0_1_0,a
      00B238 12 B4 99         [24] 1147 	lcall	_ak820_outline_0101
                                   1148 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B23B 74 02            [12] 1149 	mov	a,#0x02
      00B23D 2A               [12] 1150 	add	a, r2
      00B23E F5 4F            [12] 1151 	mov	_fast_set_leds_sloc1_1_0,a
      00B240 E4               [12] 1152 	clr	a
      00B241 3B               [12] 1153 	addc	a, r3
      00B242 F5 50            [12] 1154 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B244 C3               [12] 1155 	clr	c
      00B245 74 A0            [12] 1156 	mov	a,#0xa0
      00B247 95 4D            [12] 1157 	subb	a,_fast_set_leds_sloc0_1_0
      00B249 D0 07            [24] 1158 	pop	ar7
      00B24B 50 04            [24] 1159 	jnc	00114$
                                   1160 ;	free result
      00B24D 7B A0            [12] 1161 	mov	r3,#0xa0
      00B24F 80 04            [24] 1162 	sjmp	00115$
      00B251                       1163 00114$:
      00B251 AA 4D            [24] 1164 	mov	r2,_fast_set_leds_sloc0_1_0
      00B253 8A 03            [24] 1165 	mov	ar3,r2
      00B255                       1166 00115$:
      00B255 85 4F 82         [24] 1167 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B258 85 50 83         [24] 1168 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B25B EB               [12] 1169 	mov	a,r3
      00B25C F0               [24] 1170 	movx	@dptr,a
                                   1171 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B25D 0C               [12] 1172 	inc	r4
                                   1173 ;	quantum/vialrgb.c:133: }
      00B25E 02 B1 C1         [24] 1174 	ljmp	00110$
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1179 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1180 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1181 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1182 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1183 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1184 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1185 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1186 ;------------------------------------------------------------
                                   1187 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1188 ;	-----------------------------------------
                                   1189 ;	 function vialrgb_get_value
                                   1190 ;	-----------------------------------------
      00B261                       1191 _vialrgb_get_value:
      00B261 12 42 D0         [24] 1192 	lcall	_ak820_outline_0035
      00B264 90 0D 63         [24] 1193 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B267 12 37 E1         [24] 1194 	lcall	_ak820_outline_0014
                                   1195 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B26A 90 0D 62         [24] 1196 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B26D E0               [24] 1197 	movx	a,@dptr
      00B26E FF               [12] 1198 	mov	r7,a
      00B26F BF 20 02         [24] 1199 	cjne	r7,#0x20,00162$
      00B272 80 01            [24] 1200 	sjmp	00102$
      00B274                       1201 00162$:
      00B274 22               [24] 1202 	ret
      00B275                       1203 00102$:
                                   1204 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B275 90 0D 63         [24] 1205 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B278 12 B4 65         [24] 1206 	lcall	_ak820_outline_0041
                                   1207 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1208 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B27B BA 40 02         [24] 1209 	cjne	r2,#0x40,00163$
      00B27E 80 18            [24] 1210 	sjmp	00103$
      00B280                       1211 00163$:
      00B280 BA 41 02         [24] 1212 	cjne	r2,#0x41,00164$
      00B283 80 26            [24] 1213 	sjmp	00104$
      00B285                       1214 00164$:
      00B285 BA 42 03         [24] 1215 	cjne	r2,#0x42,00165$
      00B288 02 B3 3D         [24] 1216 	ljmp	00105$
      00B28B                       1217 00165$:
      00B28B BA 43 03         [24] 1218 	cjne	r2,#0x43,00166$
      00B28E 02 B3 49         [24] 1219 	ljmp	00106$
      00B291                       1220 00166$:
      00B291 BA 44 03         [24] 1221 	cjne	r2,#0x44,00167$
      00B294 02 B3 55         [24] 1222 	ljmp	00107$
      00B297                       1223 00167$:
      00B297 22               [24] 1224 	ret
                                   1225 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B298                       1226 00103$:
                                   1227 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B298 12 33 FC         [24] 1228 	lcall	_ak820_outline_0120
      00B29B 74 01            [12] 1229 	mov	a,#0x01
      00B29D F0               [24] 1230 	movx	@dptr,a
                                   1231 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B29E 12 B4 5D         [24] 1232 	lcall	_ak820_outline_0033
      00B2A1 E4               [12] 1233 	clr	a
      00B2A2 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B2A3 12 B4 5D         [24] 1236 	lcall	_ak820_outline_0033
      00B2A6 A3               [24] 1237 	inc	dptr
      00B2A7 74 A0            [12] 1238 	mov	a,#0xa0
      00B2A9 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	quantum/vialrgb.c:147: break;
      00B2AA 22               [24] 1241 	ret
                                   1242 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B2AB                       1243 00104$:
                                   1244 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B2AB C0 06            [24] 1245 	push	ar6
      00B2AD C0 05            [24] 1246 	push	ar5
      00B2AF C0 04            [24] 1247 	push	ar4
      00B2B1 C0 03            [24] 1248 	push	ar3
      00B2B3 12 B0 AA         [24] 1249 	lcall	_get_mode
      00B2B6 A9 82            [24] 1250 	mov	r1, dpl
      00B2B8 AA 83            [24] 1251 	mov	r2, dph
      00B2BA D0 03            [24] 1252 	pop	ar3
      00B2BC D0 04            [24] 1253 	pop	ar4
      00B2BE D0 05            [24] 1254 	pop	ar5
      00B2C0 D0 06            [24] 1255 	pop	ar6
                                   1256 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B2C2 89 00            [24] 1257 	mov	ar0,r1
      00B2C4 12 33 FC         [24] 1258 	lcall	_ak820_outline_0120
      00B2C7 E8               [12] 1259 	mov	a,r0
      00B2C8 F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B2C9 12 B4 5D         [24] 1262 	lcall	_ak820_outline_0033
      00B2CC 8A 01            [24] 1263 	mov	ar1,r2
      00B2CE E9               [12] 1264 	mov	a,r1
      00B2CF F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B2D0 74 04            [12] 1267 	mov	a,#0x04
      00B2D2 12 8C E3         [24] 1268 	lcall	_ak820_outline_0131
      00B2D5 C0 06            [24] 1269 	push	ar6
      00B2D7 C0 05            [24] 1270 	push	ar5
      00B2D9 C0 02            [24] 1271 	push	ar2
      00B2DB C0 01            [24] 1272 	push	ar1
      00B2DD 12 54 30         [24] 1273 	lcall	_rgb_matrix_get_speed
      00B2E0 A8 82            [24] 1274 	mov	r0, dpl
      00B2E2 D0 01            [24] 1275 	pop	ar1
      00B2E4 D0 02            [24] 1276 	pop	ar2
      00B2E6 D0 05            [24] 1277 	pop	ar5
      00B2E8 D0 06            [24] 1278 	pop	ar6
      00B2EA 12 7F 2B         [24] 1279 	lcall	_ak820_outline_0061
                                   1280 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B2ED 74 05            [12] 1281 	mov	a,#0x05
      00B2EF 12 8C E3         [24] 1282 	lcall	_ak820_outline_0131
      00B2F2 C0 06            [24] 1283 	push	ar6
      00B2F4 C0 05            [24] 1284 	push	ar5
      00B2F6 C0 02            [24] 1285 	push	ar2
      00B2F8 C0 01            [24] 1286 	push	ar1
      00B2FA 12 54 1B         [24] 1287 	lcall	_rgb_matrix_get_hue
      00B2FD A8 82            [24] 1288 	mov	r0, dpl
      00B2FF D0 01            [24] 1289 	pop	ar1
      00B301 D0 02            [24] 1290 	pop	ar2
      00B303 D0 05            [24] 1291 	pop	ar5
      00B305 D0 06            [24] 1292 	pop	ar6
      00B307 12 7F 2B         [24] 1293 	lcall	_ak820_outline_0061
                                   1294 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B30A 74 06            [12] 1295 	mov	a,#0x06
      00B30C 12 8C E3         [24] 1296 	lcall	_ak820_outline_0131
      00B30F C0 06            [24] 1297 	push	ar6
      00B311 C0 05            [24] 1298 	push	ar5
      00B313 C0 02            [24] 1299 	push	ar2
      00B315 C0 01            [24] 1300 	push	ar1
      00B317 12 54 22         [24] 1301 	lcall	_rgb_matrix_get_sat
      00B31A A8 82            [24] 1302 	mov	r0, dpl
      00B31C D0 01            [24] 1303 	pop	ar1
      00B31E D0 02            [24] 1304 	pop	ar2
      00B320 D0 05            [24] 1305 	pop	ar5
      00B322 D0 06            [24] 1306 	pop	ar6
      00B324 12 7F 2B         [24] 1307 	lcall	_ak820_outline_0061
                                   1308 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B327 74 07            [12] 1309 	mov	a,#0x07
      00B329 12 8C E3         [24] 1310 	lcall	_ak820_outline_0131
      00B32C C0 02            [24] 1311 	push	ar2
      00B32E C0 01            [24] 1312 	push	ar1
      00B330 12 54 29         [24] 1313 	lcall	_rgb_matrix_get_val
      00B333 A8 82            [24] 1314 	mov	r0, dpl
      00B335 D0 01            [24] 1315 	pop	ar1
      00B337 D0 02            [24] 1316 	pop	ar2
      00B339 12 7F 2B         [24] 1317 	lcall	_ak820_outline_0061
                                   1318 ;	quantum/vialrgb.c:156: break;
      00B33C 22               [24] 1319 	ret
                                   1320 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B33D                       1321 00105$:
                                   1322 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B33D EF               [12] 1323 	mov	a,r7
      00B33E 24 FE            [12] 1324 	add	a,#0xfe
      00B340 90 0D 4F         [24] 1325 	mov	dptr,#_get_supported_PARM_2
      00B343 12 47 E2         [24] 1326 	lcall	_ak820_outline_0119
                                   1327 ;	quantum/vialrgb.c:160: break;
      00B346 02 AF B4         [24] 1328 	ljmp	_get_supported
                                   1329 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B349                       1330 00106$:
                                   1331 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B349 12 33 FC         [24] 1332 	lcall	_ak820_outline_0120
      00B34C 74 52            [12] 1333 	mov	a,#0x52
      00B34E F0               [24] 1334 	movx	@dptr,a
                                   1335 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B34F 12 B4 5D         [24] 1336 	lcall	_ak820_outline_0033
      00B352 E4               [12] 1337 	clr	a
      00B353 F0               [24] 1338 	movx	@dptr,a
                                   1339 ;	quantum/vialrgb.c:166: break;
      00B354 22               [24] 1340 	ret
                                   1341 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B355                       1342 00107$:
                                   1343 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B355 12 33 FC         [24] 1344 	lcall	_ak820_outline_0120
      00B358 E0               [24] 1345 	movx	a,@dptr
      00B359 FF               [12] 1346 	mov	r7,a
      00B35A 7A 00            [12] 1347 	mov	r2,#0x00
      00B35C 74 03            [12] 1348 	mov	a,#0x03
      00B35E 2D               [12] 1349 	add	a, r5
      00B35F F8               [12] 1350 	mov	r0,a
      00B360 E4               [12] 1351 	clr	a
      00B361 3E               [12] 1352 	addc	a, r6
      00B362 F9               [12] 1353 	mov	r1,a
      00B363 C0 03            [24] 1354 	push	ar3
      00B365 C0 04            [24] 1355 	push	ar4
      00B367 12 38 6E         [24] 1356 	lcall	_ak820_outline_0150
      00B36A E0               [24] 1357 	movx	a,@dptr
      00B36B FB               [12] 1358 	mov	r3,a
      00B36C E4               [12] 1359 	clr	a
      00B36D 4F               [12] 1360 	orl	a,r7
      00B36E F5 51            [12] 1361 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B370 EB               [12] 1362 	mov	a,r3
      00B371 4A               [12] 1363 	orl	a,r2
      00B372 F5 52            [12] 1364 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1365 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B374 AC 51            [24] 1366 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B376 AF 52            [24] 1367 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B378 C3               [12] 1368 	clr	c
      00B379 EC               [12] 1369 	mov	a,r4
      00B37A 94 52            [12] 1370 	subb	a,#0x52
      00B37C EF               [12] 1371 	mov	a,r7
      00B37D 94 00            [12] 1372 	subb	a,#0x00
      00B37F D0 04            [24] 1373 	pop	ar4
      00B381 D0 03            [24] 1374 	pop	ar3
      00B383 40 01            [24] 1375 	jc	00109$
      00B385 22               [24] 1376 	ret
      00B386                       1377 00109$:
                                   1378 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B386 E5 51            [12] 1379 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B388 25 51            [12] 1380 	add	a,_vialrgb_get_value_sloc0_1_0
      00B38A FA               [12] 1381 	mov	r2,a
      00B38B E5 52            [12] 1382 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B38D 33               [12] 1383 	rlc	a
      00B38E FF               [12] 1384 	mov	r7,a
      00B38F EA               [12] 1385 	mov	a,r2
      00B390 24 1B            [12] 1386 	add	a, #_ak820_led_points
      00B392 F5 53            [12] 1387 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B394 EF               [12] 1388 	mov	a,r7
      00B395 34 B9            [12] 1389 	addc	a, #(_ak820_led_points >> 8)
      00B397 F5 54            [12] 1390 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B399 85 53 82         [24] 1391 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B39C 85 54 83         [24] 1392 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B39F E4               [12] 1393 	clr	a
      00B3A0 93               [24] 1394 	movc	a,@a+dptr
      00B3A1 12 33 FC         [24] 1395 	lcall	_ak820_outline_0120
      00B3A4 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B3A5 85 53 82         [24] 1398 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B3A8 85 54 83         [24] 1399 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B3AB A3               [24] 1400 	inc	dptr
      00B3AC E4               [12] 1401 	clr	a
      00B3AD 93               [24] 1402 	movc	a,@a+dptr
      00B3AE 12 38 6E         [24] 1403 	lcall	_ak820_outline_0150
      00B3B1 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B3B2 12 B4 5D         [24] 1406 	lcall	_ak820_outline_0033
      00B3B5 A3               [24] 1407 	inc	dptr
      00B3B6 74 04            [12] 1408 	mov	a,#0x04
      00B3B8 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B3B9 90 0D 58         [24] 1411 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B3BC 04               [12] 1412 	inc	a
      00B3BD 2D               [12] 1413 	add	a, r5
      00B3BE F0               [24] 1414 	movx	@dptr,a
      00B3BF E4               [12] 1415 	clr	a
      00B3C0 3E               [12] 1416 	addc	a, r6
      00B3C1 A3               [24] 1417 	inc	dptr
      00B3C2 F0               [24] 1418 	movx	@dptr,a
      00B3C3 85 51 82         [24] 1419 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B3C6 85 52 83         [24] 1420 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1421 ;	quantum/vialrgb.c:187: }
                                   1422 ;	quantum/vialrgb.c:188: }
      00B3C9 02 B0 ED         [24] 1423 	ljmp	_get_matrix_pos_for_led
                                   1424 ;------------------------------------------------------------
                                   1425 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1426 ;------------------------------------------------------------
                                   1427 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1428 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1429 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1430 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1431 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1432 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1433 ;------------------------------------------------------------
                                   1434 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1435 ;	-----------------------------------------
                                   1436 ;	 function vialrgb_set_value
                                   1437 ;	-----------------------------------------
      00B3CC                       1438 _vialrgb_set_value:
      00B3CC 12 42 D0         [24] 1439 	lcall	_ak820_outline_0035
      00B3CF 90 0D 67         [24] 1440 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B3D2 12 37 E1         [24] 1441 	lcall	_ak820_outline_0014
                                   1442 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B3D5 90 0D 66         [24] 1443 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B3D8 E0               [24] 1444 	movx	a,@dptr
      00B3D9 FF               [12] 1445 	mov	r7,a
      00B3DA BF 20 02         [24] 1446 	cjne	r7,#0x20,00129$
      00B3DD 80 01            [24] 1447 	sjmp	00102$
      00B3DF                       1448 00129$:
      00B3DF 22               [24] 1449 	ret
      00B3E0                       1450 00102$:
                                   1451 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B3E0 90 0D 67         [24] 1452 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B3E3 12 B4 65         [24] 1453 	lcall	_ak820_outline_0041
                                   1454 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1455 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B3E6 BA 41 02         [24] 1456 	cjne	r2,#0x41,00130$
      00B3E9 80 06            [24] 1457 	sjmp	00103$
      00B3EB                       1458 00130$:
      00B3EB BA 42 02         [24] 1459 	cjne	r2,#0x42,00131$
      00B3EE 80 5E            [24] 1460 	sjmp	00104$
      00B3F0                       1461 00131$:
      00B3F0 22               [24] 1462 	ret
                                   1463 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B3F1                       1464 00103$:
                                   1465 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B3F1 12 33 FC         [24] 1466 	lcall	_ak820_outline_0120
      00B3F4 E0               [24] 1467 	movx	a,@dptr
      00B3F5 FA               [12] 1468 	mov	r2,a
      00B3F6 12 B4 5D         [24] 1469 	lcall	_ak820_outline_0033
      00B3F9 E0               [24] 1470 	movx	a,@dptr
      00B3FA F8               [12] 1471 	mov	r0,a
      00B3FB 79 00            [12] 1472 	mov	r1,#0x00
      00B3FD 88 56            [24] 1473 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B3FF 89 55            [24] 1474 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B401 8A 01            [24] 1475 	mov	ar1,r2
      00B403 7A 00            [12] 1476 	mov	r2,#0x00
      00B405 E5 56            [12] 1477 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B407 42 02            [12] 1478 	orl	ar2,a
                                   1479 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B409 12 43 3F         [24] 1480 	lcall	_ak820_outline_0151
      00B40C C0 06            [24] 1481 	push	ar6
      00B40E C0 05            [24] 1482 	push	ar5
      00B410 12 B0 BF         [24] 1483 	lcall	_set_mode
      00B413 D0 05            [24] 1484 	pop	ar5
      00B415 D0 06            [24] 1485 	pop	ar6
                                   1486 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B417 12 B4 5D         [24] 1487 	lcall	_ak820_outline_0033
      00B41A A3               [24] 1488 	inc	dptr
      00B41B E0               [24] 1489 	movx	a,@dptr
      00B41C F5 82            [12] 1490 	mov	dpl,a
      00B41E C0 06            [24] 1491 	push	ar6
      00B420 C0 05            [24] 1492 	push	ar5
      00B422 12 54 FE         [24] 1493 	lcall	_rgb_matrix_set_speed_noeeprom
      00B425 D0 05            [24] 1494 	pop	ar5
      00B427 D0 06            [24] 1495 	pop	ar6
                                   1496 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B429 12 B4 5D         [24] 1497 	lcall	_ak820_outline_0033
      00B42C A3               [24] 1498 	inc	dptr
      00B42D A3               [24] 1499 	inc	dptr
      00B42E E0               [24] 1500 	movx	a,@dptr
      00B42F F9               [12] 1501 	mov	r1,a
      00B430 7A 00            [12] 1502 	mov	r2,#0x00
      00B432 74 06            [12] 1503 	mov	a,#0x06
      00B434 12 B4 AF         [24] 1504 	lcall	_ak820_outline_0167
      00B437 F8               [12] 1505 	mov	r0,a
      00B438 74 07            [12] 1506 	mov	a,#0x07
      00B43A 12 B4 AF         [24] 1507 	lcall	_ak820_outline_0167
      00B43D FE               [12] 1508 	mov	r6,a
      00B43E 90 07 29         [24] 1509 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B441 E8               [12] 1510 	mov	a,r0
      00B442 F0               [24] 1511 	movx	@dptr,a
      00B443 90 07 2A         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B446 EE               [12] 1513 	mov	a,r6
      00B447 F0               [24] 1514 	movx	@dptr,a
      00B448 12 43 3F         [24] 1515 	lcall	_ak820_outline_0151
                                   1516 ;	quantum/vialrgb.c:202: break;
                                   1517 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B44B 02 54 CF         [24] 1518 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B44E                       1519 00104$:
                                   1520 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B44E EF               [12] 1521 	mov	a,r7
      00B44F 24 FE            [12] 1522 	add	a,#0xfe
      00B451 90 0D 5C         [24] 1523 	mov	dptr,#_fast_set_leds_PARM_2
      00B454 12 47 E2         [24] 1524 	lcall	_ak820_outline_0119
                                   1525 ;	quantum/vialrgb.c:210: }
                                   1526 ;	quantum/vialrgb.c:211: }
      00B457 02 B1 20         [24] 1527 	ljmp	_fast_set_leds
                                   1528 ;------------------------------------------------------------
                                   1529 ;Allocation info for local variables in function 'vialrgb_save'
                                   1530 ;------------------------------------------------------------
                                   1531 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1532 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1533 ;------------------------------------------------------------
                                   1534 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1535 ;	-----------------------------------------
                                   1536 ;	 function vialrgb_save
                                   1537 ;	-----------------------------------------
      00B45A                       1538 _vialrgb_save:
                                   1539 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1540 ;	quantum/vialrgb.c:218: }
      00B45A 02 4F 55         [24] 1541 	ljmp	_eeconfig_update_rgb_matrix
                                   1542 	.area CSEG    (CODE)
                                   1543 	.area CONST   (CODE)
                                   1544 	.area CONST   (CODE)
      00BC5A                       1545 _supported_modes:
      00BC5A 00                    1546 	.db #0x00	; 0
      00BC5B 00                    1547 	.db #0x00	; 0
      00BC5C 01                    1548 	.db #0x01	; 1
      00BC5D 05                    1549 	.db #0x05	; 5
      00BC5E 02                    1550 	.db #0x02	; 2
      00BC5F 01                    1551 	.db #0x01	; 1
      00BC60 06                    1552 	.db #0x06	; 6
      00BC61 02                    1553 	.db #0x02	; 2
      00BC62 0D                    1554 	.db #0x0d	; 13
      00BC63 03                    1555 	.db #0x03	; 3
      00BC64 0E                    1556 	.db #0x0e	; 14
      00BC65 04                    1557 	.db #0x04	; 4
      00BC66 1F                    1558 	.db #0x1f	; 31
      00BC67 06                    1559 	.db #0x06	; 6
                                   1560 	.area CSEG    (CODE)
                                   1561 	.area XINIT   (CODE)
                                   1562 	.area CABS    (ABS,CODE)
                                   1563 
                                   1564 ; Experimental exact instruction outlining.
                                   1565 	.globl _ak820_outline_0004
                                   1566 	.globl _ak820_outline_0014
                                   1567 	.globl _ak820_outline_0019
                                   1568 	.globl _ak820_outline_0033
                                   1569 	.globl _ak820_outline_0034
                                   1570 	.globl _ak820_outline_0035
                                   1571 	.globl _ak820_outline_0041
                                   1572 	.globl _ak820_outline_0043
                                   1573 	.globl _ak820_outline_0049
                                   1574 	.globl _ak820_outline_0061
                                   1575 	.globl _ak820_outline_0072
                                   1576 	.globl _ak820_outline_0074
                                   1577 	.globl _ak820_outline_0079
                                   1578 	.globl _ak820_outline_0090
                                   1579 	.globl _ak820_outline_0098
                                   1580 	.globl _ak820_outline_0101
                                   1581 	.globl _ak820_outline_0102
                                   1582 	.globl _ak820_outline_0103
                                   1583 	.globl _ak820_outline_0104
                                   1584 	.globl _ak820_outline_0107
                                   1585 	.globl _ak820_outline_0116
                                   1586 	.globl _ak820_outline_0118
                                   1587 	.globl _ak820_outline_0119
                                   1588 	.globl _ak820_outline_0120
                                   1589 	.globl _ak820_outline_0130
                                   1590 	.globl _ak820_outline_0131
                                   1591 	.globl _ak820_outline_0138
                                   1592 	.globl _ak820_outline_0140
                                   1593 	.globl _ak820_outline_0150
                                   1594 	.globl _ak820_outline_0151
                                   1595 	.globl _ak820_outline_0156
                                   1596 	.globl _ak820_outline_0167
                                   1597 	.globl _ak820_outline_0181
                                   1598 
                                   1599 	.area CSEG (CODE)
                                   1600 ; function ak820_outline_0033
      00B45D                       1601 _ak820_outline_0033:
      00B45D 8D 82            [24] 1602 	mov	dpl,r5
      00B45F 8E 83            [24] 1603 	mov	dph,r6
      00B461 A3               [24] 1604 	inc	dptr
      00B462 A3               [24] 1605 	inc	dptr
      00B463 A3               [24] 1606 	inc	dptr
      00B464 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0041
      00B465                       1611 _ak820_outline_0041:
      00B465 E0               [24] 1612 	movx	a,@dptr
      00B466 FD               [12] 1613 	mov	r5,a
      00B467 A3               [24] 1614 	inc	dptr
      00B468 E0               [24] 1615 	movx	a,@dptr
      00B469 FE               [12] 1616 	mov	r6,a
      00B46A 74 02            [12] 1617 	mov	a,#0x02
      00B46C 2D               [12] 1618 	add	a,r5
      00B46D FB               [12] 1619 	mov	r3,a
      00B46E E4               [12] 1620 	clr	a
      00B46F 3E               [12] 1621 	addc	a,r6
      00B470 FC               [12] 1622 	mov	r4,a
      00B471 8D 82            [24] 1623 	mov	dpl,r5
      00B473 8E 83            [24] 1624 	mov	dph,r6
      00B475 A3               [24] 1625 	inc	dptr
      00B476 E0               [24] 1626 	movx	a,@dptr
      00B477 FA               [12] 1627 	mov	r2,a
      00B478 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0043
      00B479                       1632 _ak820_outline_0043:
      00B479 ED               [12] 1633 	mov	a,r5
      00B47A 75 F0 02         [24] 1634 	mov	b,#0x02
      00B47D A4               [48] 1635 	mul	ab
      00B47E 24 5A            [12] 1636 	add	a,#_supported_modes
      00B480 FB               [12] 1637 	mov	r3,a
      00B481 74 BC            [12] 1638 	mov	a,#(_supported_modes>>8)
      00B483 35 F0            [12] 1639 	addc	a,b
      00B485 FC               [12] 1640 	mov	r4,a
      00B486 8B 82            [24] 1641 	mov	dpl,r3
      00B488 8C 83            [24] 1642 	mov	dph,r4
      00B48A 22               [24] 1643 	ret
                                   1644 
                                   1645 	.area CSEG (CODE)
                                   1646 ; function ak820_outline_0079
      00B48B                       1647 _ak820_outline_0079:
      00B48B 90 0D 5D         [24] 1648 	mov	dptr,#_fast_set_leds_args_10000_282
      00B48E E0               [24] 1649 	movx	a,@dptr
      00B48F F9               [12] 1650 	mov	r1,a
      00B490 A3               [24] 1651 	inc	dptr
      00B491 E0               [24] 1652 	movx	a,@dptr
      00B492 FF               [12] 1653 	mov	r7,a
      00B493 89 82            [24] 1654 	mov	dpl,r1
      00B495 8F 83            [24] 1655 	mov	dph,r7
      00B497 E0               [24] 1656 	movx	a,@dptr
      00B498 22               [24] 1657 	ret
                                   1658 
                                   1659 	.area CSEG (CODE)
                                   1660 ; function ak820_outline_0101
      00B499                       1661 _ak820_outline_0101:
      00B499 90 0D 5D         [24] 1662 	mov	dptr,#_fast_set_leds_args_10000_282
      00B49C 74 01            [12] 1663 	mov	a,#0x01
      00B49E 29               [12] 1664 	add	a,r1
      00B49F F0               [24] 1665 	movx	@dptr,a
      00B4A0 E4               [12] 1666 	clr	a
      00B4A1 3F               [12] 1667 	addc	a,r7
      00B4A2 A3               [24] 1668 	inc	dptr
      00B4A3 F0               [24] 1669 	movx	@dptr,a
      00B4A4 22               [24] 1670 	ret
                                   1671 
                                   1672 	.area CSEG (CODE)
                                   1673 ; function ak820_outline_0140
      00B4A5                       1674 _ak820_outline_0140:
      00B4A5 E4               [12] 1675 	clr	a
      00B4A6 93               [24] 1676 	movc	a,@a+dptr
      00B4A7 FC               [12] 1677 	mov	r4,a
      00B4A8 7B 00            [12] 1678 	mov	r3,#0x00
      00B4AA 8C 82            [24] 1679 	mov	dpl,r4
      00B4AC 8B 83            [24] 1680 	mov	dph,r3
      00B4AE 22               [24] 1681 	ret
                                   1682 
                                   1683 	.area CSEG (CODE)
                                   1684 ; function ak820_outline_0167
      00B4AF                       1685 _ak820_outline_0167:
      00B4AF 2D               [12] 1686 	add	a,r5
      00B4B0 F5 82            [12] 1687 	mov	dpl,a
      00B4B2 E4               [12] 1688 	clr	a
      00B4B3 3E               [12] 1689 	addc	a,r6
      00B4B4 F5 83            [12] 1690 	mov	dph,a
      00B4B6 E0               [24] 1691 	movx	a,@dptr
      00B4B7 22               [24] 1692 	ret
