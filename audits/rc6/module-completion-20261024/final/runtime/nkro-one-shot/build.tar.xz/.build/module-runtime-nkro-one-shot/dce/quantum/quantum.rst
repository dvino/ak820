                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _register_code16
                                    282 	.globl _unregister_code16
                                    283 	.globl _reset_keyboard
                                    284 	.globl _soft_reset_keyboard
                                    285 	.globl _get_record_keycode
                                    286 	.globl _pre_process_record_quantum
                                    287 	.globl _process_record_quantum
                                    288 	.globl _process_record_quantum_helper
                                    289 	.globl _shutdown_user
                                    290 ;--------------------------------------------------------
                                    291 ; special function registers
                                    292 ;--------------------------------------------------------
                                    293 	.area RSEG    (ABS,DATA)
      000000                        294 	.org 0x0000
                           0000D0   295 _PSW	=	0x00d0
                           0000E0   296 _ACC	=	0x00e0
                           0000F0   297 _B	=	0x00f0
                           0000FD   298 _A_INV	=	0x00fd
                           000081   299 _SP	=	0x0081
                           000082   300 _DPL	=	0x0082
                           000083   301 _DPH	=	0x0083
                           0000A1   302 _SAFE_MOD	=	0x00a1
                           0000B1   303 _GLOBAL_CFG	=	0x00b1
                           000087   304 _PCON	=	0x0087
                           0000BA   305 _POWER_CFG	=	0x00ba
                           0000B9   306 _CLOCK_CFG	=	0x00b9
                           0000A9   307 _WAKE_CTRL	=	0x00a9
                           0000FE   308 _RESET_KEEP	=	0x00fe
                           0000FF   309 _WDOG_COUNT	=	0x00ff
                           0000A8   310 _IE	=	0x00a8
                           0000B8   311 _IP	=	0x00b8
                           0000E8   312 _IE_EX	=	0x00e8
                           0000E9   313 _IP_EX	=	0x00e9
                           0000B2   314 _GPIO_IE	=	0x00b2
                           008584   315 _ROM_ADDR	=	0x8584
                           000084   316 _ROM_ADDR_L	=	0x0084
                           000085   317 _ROM_ADDR_H	=	0x0085
                           008F8E   318 _ROM_DATA_HI	=	0x8f8e
                           00008E   319 _ROM_DATA_HL	=	0x008e
                           00008F   320 _ROM_DATA_HH	=	0x008f
                           000086   321 _ROM_CTRL	=	0x0086
                           000080   322 _P0	=	0x0080
                           0000C4   323 _P0_MOD_OC	=	0x00c4
                           0000C5   324 _P0_DIR_PU	=	0x00c5
                           000090   325 _P1	=	0x0090
                           000092   326 _P1_MOD_OC	=	0x0092
                           000093   327 _P1_DIR_PU	=	0x0093
                           0000A0   328 _P2	=	0x00a0
                           000094   329 _P2_MOD_OC	=	0x0094
                           000095   330 _P2_DIR_PU	=	0x0095
                           0000B0   331 _P3	=	0x00b0
                           000096   332 _P3_MOD_OC	=	0x0096
                           000097   333 _P3_DIR_PU	=	0x0097
                           0000C0   334 _P4	=	0x00c0
                           0000C2   335 _P4_MOD_OC	=	0x00c2
                           0000C3   336 _P4_DIR_PU	=	0x00c3
                           0000C1   337 _P4_LED_KEY	=	0x00c1
                           0000AA   338 _P5_IN	=	0x00aa
                           0000AB   339 _P5_OUT_PU	=	0x00ab
                           0000AC   340 _P5_DIR	=	0x00ac
                           0000AD   341 _P6_IN	=	0x00ad
                           0000AE   342 _P6_OUT_PU	=	0x00ae
                           0000AF   343 _P6_DIR	=	0x00af
                           0000F1   344 _P7	=	0x00f1
                           0000A2   345 _XBUS_AUX	=	0x00a2
                           000088   346 _TCON	=	0x0088
                           000089   347 _TMOD	=	0x0089
                           00008A   348 _TL0	=	0x008a
                           00008B   349 _TL1	=	0x008b
                           00008C   350 _TH0	=	0x008c
                           00008D   351 _TH1	=	0x008d
                           000098   352 _SCON	=	0x0098
                           000099   353 _SBUF	=	0x0099
                           0000C8   354 _T2CON	=	0x00c8
                           0000C9   355 _T2MOD	=	0x00c9
                           00CBCA   356 _RCAP2	=	0xcbca
                           0000CA   357 _RCAP2L	=	0x00ca
                           0000CB   358 _RCAP2H	=	0x00cb
                           00CDCC   359 _T2COUNT	=	0xcdcc
                           0000CC   360 _TL2	=	0x00cc
                           0000CD   361 _TH2	=	0x00cd
                           00CFCE   362 _T2CAP1	=	0xcfce
                           0000CE   363 _T2CAP1L	=	0x00ce
                           0000CF   364 _T2CAP1H	=	0x00cf
                           0000F8   365 _SPI0_STAT	=	0x00f8
                           0000F9   366 _SPI0_DATA	=	0x00f9
                           0000FA   367 _SPI0_CTRL	=	0x00fa
                           0000FB   368 _SPI0_CK_SE	=	0x00fb
                           0000FC   369 _SPI0_SETUP	=	0x00fc
                           0000BC   370 _SCON1	=	0x00bc
                           0000BD   371 _SBUF1	=	0x00bd
                           0000BE   372 _SBAUD1	=	0x00be
                           0000BF   373 _SIF1	=	0x00bf
                           0000B4   374 _SPI1_STAT	=	0x00b4
                           0000B5   375 _SPI1_DATA	=	0x00b5
                           0000B6   376 _SPI1_CTRL	=	0x00b6
                           0000B7   377 _SPI1_CK_SE	=	0x00b7
                           0000F3   378 _ADC_CTRL	=	0x00f3
                           00F5F4   379 _ADC_DAT	=	0xf5f4
                           0000F4   380 _ADC_DAT_L	=	0x00f4
                           0000F5   381 _ADC_DAT_H	=	0x00f5
                           0000F6   382 _ADC_CHAN	=	0x00f6
                           0000A6   383 _LED_COMMON	=	0x00a6
                           0000A7   384 _LED_PWM_OE	=	0x00a7
                           00C7C6   385 _LED_DMA	=	0xc7c6
                           0000C6   386 _LED_DMA_L	=	0x00c6
                           0000C7   387 _LED_DMA_H	=	0x00c7
                           0000F7   388 _LED_STATUS	=	0x00f7
                           0000B3   389 _I2CX_INT	=	0x00b3
                           0000BB   390 _I2CS_INT_ST	=	0x00bb
                                    391 ;--------------------------------------------------------
                                    392 ; special function bits
                                    393 ;--------------------------------------------------------
                                    394 	.area RSEG    (ABS,DATA)
      000000                        395 	.org 0x0000
                           0000D7   396 _CY	=	0x00d7
                           0000D6   397 _AC	=	0x00d6
                           0000D5   398 _F0	=	0x00d5
                           0000D4   399 _RS1	=	0x00d4
                           0000D3   400 _RS0	=	0x00d3
                           0000D2   401 _OV	=	0x00d2
                           0000D1   402 _F1	=	0x00d1
                           0000D0   403 _P	=	0x00d0
                           0000AF   404 _EA	=	0x00af
                           0000AE   405 _E_DIS	=	0x00ae
                           0000AD   406 _ET2	=	0x00ad
                           0000AC   407 _ES	=	0x00ac
                           0000AB   408 _ET1	=	0x00ab
                           0000AA   409 _EX1	=	0x00aa
                           0000A9   410 _ET0	=	0x00a9
                           0000A8   411 _EX0	=	0x00a8
                           0000BF   412 _PH_FLAG	=	0x00bf
                           0000BE   413 _PL_FLAG	=	0x00be
                           0000BD   414 _PT2	=	0x00bd
                           0000BC   415 _PS	=	0x00bc
                           0000BB   416 _PT1	=	0x00bb
                           0000BA   417 _PX1	=	0x00ba
                           0000B9   418 _PT0	=	0x00b9
                           0000B8   419 _PX0	=	0x00b8
                           0000EF   420 _IE_WDOG	=	0x00ef
                           0000EE   421 _IE_GPIO	=	0x00ee
                           0000ED   422 _IE_PWM_I2C	=	0x00ed
                           0000EC   423 _IE_UART1	=	0x00ec
                           0000EB   424 _IE_ADC	=	0x00eb
                           0000E9   425 _IE_USB	=	0x00e9
                           0000E8   426 _IE_SPI0	=	0x00e8
                           000087   427 _P0_7	=	0x0087
                           000086   428 _P0_6	=	0x0086
                           000085   429 _P0_5	=	0x0085
                           000084   430 _P0_4	=	0x0084
                           000083   431 _P0_3	=	0x0083
                           000082   432 _P0_2	=	0x0082
                           000081   433 _P0_1	=	0x0081
                           000080   434 _P0_0	=	0x0080
                           000081   435 _SDA0	=	0x0081
                           000080   436 _SCL0	=	0x0080
                           000083   437 _TXD_	=	0x0083
                           000082   438 _RXD_	=	0x0082
                           000085   439 _AIN13	=	0x0085
                           000084   440 _AIN12	=	0x0084
                           000083   441 _AIN11	=	0x0083
                           000082   442 _AIN10	=	0x0082
                           000081   443 _AIN9	=	0x0081
                           000080   444 _AIN8	=	0x0080
                           000097   445 _P1_7	=	0x0097
                           000096   446 _P1_6	=	0x0096
                           000095   447 _P1_5	=	0x0095
                           000094   448 _P1_4	=	0x0094
                           000093   449 _P1_3	=	0x0093
                           000092   450 _P1_2	=	0x0092
                           000091   451 _P1_1	=	0x0091
                           000090   452 _P1_0	=	0x0090
                           000097   453 _TXD1_	=	0x0097
                           000096   454 _RXD1_	=	0x0096
                           000097   455 _SCK	=	0x0097
                           000096   456 _MISO	=	0x0096
                           000095   457 _MOSI	=	0x0095
                           000094   458 _SCS	=	0x0094
                           000092   459 _INT0_	=	0x0092
                           000091   460 _T2EX	=	0x0091
                           000091   461 _CAP2	=	0x0091
                           000090   462 _T2	=	0x0090
                           000090   463 _CAP1	=	0x0090
                           000097   464 _AIN7	=	0x0097
                           000096   465 _AIN6	=	0x0096
                           000095   466 _AIN5	=	0x0095
                           000094   467 _AIN4	=	0x0094
                           000093   468 _AIN3	=	0x0093
                           000092   469 _AIN2	=	0x0092
                           000091   470 _AIN1	=	0x0091
                           000090   471 _AIN0	=	0x0090
                           0000A7   472 _P2_7	=	0x00a7
                           0000A6   473 _P2_6	=	0x00a6
                           0000A5   474 _P2_5	=	0x00a5
                           0000A4   475 _P2_4	=	0x00a4
                           0000A3   476 _P2_3	=	0x00a3
                           0000A2   477 _P2_2	=	0x00a2
                           0000A1   478 _P2_1	=	0x00a1
                           0000A0   479 _P2_0	=	0x00a0
                           0000A7   480 _TXD1	=	0x00a7
                           0000A6   481 _RXD1	=	0x00a6
                           0000A5   482 _T2EX_	=	0x00a5
                           0000A5   483 _CAP2_	=	0x00a5
                           0000A4   484 _T2_	=	0x00a4
                           0000A4   485 _CAP1_	=	0x00a4
                           0000B7   486 _P3_7	=	0x00b7
                           0000B6   487 _P3_6	=	0x00b6
                           0000B5   488 _P3_5	=	0x00b5
                           0000B4   489 _P3_4	=	0x00b4
                           0000B3   490 _P3_3	=	0x00b3
                           0000B2   491 _P3_2	=	0x00b2
                           0000B1   492 _P3_1	=	0x00b1
                           0000B0   493 _P3_0	=	0x00b0
                           0000B7   494 _SCK1	=	0x00b7
                           0000B6   495 _MISO1	=	0x00b6
                           0000B5   496 _MOSI1	=	0x00b5
                           0000B5   497 _T1	=	0x00b5
                           0000B4   498 _T0	=	0x00b4
                           0000B3   499 _INT1	=	0x00b3
                           0000B2   500 _INT0	=	0x00b2
                           0000B1   501 _TXD	=	0x00b1
                           0000B0   502 _RXD	=	0x00b0
                           0000C6   503 _P4_6	=	0x00c6
                           0000C5   504 _P4_5	=	0x00c5
                           0000C4   505 _P4_4	=	0x00c4
                           0000C3   506 _P4_3	=	0x00c3
                           0000C2   507 _P4_2	=	0x00c2
                           0000C1   508 _P4_1	=	0x00c1
                           0000C0   509 _P4_0	=	0x00c0
                           00008F   510 _TF1	=	0x008f
                           00008E   511 _TR1	=	0x008e
                           00008D   512 _TF0	=	0x008d
                           00008C   513 _TR0	=	0x008c
                           00008B   514 _IE1	=	0x008b
                           00008A   515 _IT1	=	0x008a
                           000089   516 _IE0	=	0x0089
                           000088   517 _IT0	=	0x0088
                           00009F   518 _SM0	=	0x009f
                           00009E   519 _SM1	=	0x009e
                           00009D   520 _SM2	=	0x009d
                           00009C   521 _REN	=	0x009c
                           00009B   522 _TB8	=	0x009b
                           00009A   523 _RB8	=	0x009a
                           000099   524 _TI	=	0x0099
                           000098   525 _RI	=	0x0098
                           0000CF   526 _TF2	=	0x00cf
                           0000CF   527 _CAP1F	=	0x00cf
                           0000CE   528 _EXF2	=	0x00ce
                           0000CD   529 _RCLK	=	0x00cd
                           0000CC   530 _TCLK	=	0x00cc
                           0000CB   531 _EXEN2	=	0x00cb
                           0000CA   532 _TR2	=	0x00ca
                           0000C9   533 _C_T2	=	0x00c9
                           0000C8   534 _CP_RL2	=	0x00c8
                           0000FF   535 _S0_FST_ACT	=	0x00ff
                           0000FE   536 _S0_IF_OV	=	0x00fe
                           0000FD   537 _S0_IF_FIRST	=	0x00fd
                           0000FC   538 _S0_IF_BYTE	=	0x00fc
                           0000FB   539 _S0_FREE	=	0x00fb
                           0000FA   540 _S0_T_FIFO	=	0x00fa
                           0000F8   541 _S0_R_FIFO	=	0x00f8
                           0000F7   542 _ADC_START	=	0x00f7
                                    543 ;--------------------------------------------------------
                                    544 ; overlayable register banks
                                    545 ;--------------------------------------------------------
                                    546 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        547 	.ds 8
                                    548 ;--------------------------------------------------------
                                    549 ; internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area DSEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000023                        568 _get_record_keycode_sloc0_1_0:
      000023                        569 	.ds 1
      000024                        570 _pre_process_record_quantum_sloc0_1_0:
      000024                        571 	.ds 1
      000025                        572 _process_ak820_nkro_sloc0_1_0:
      000025                        573 	.ds 1
                                    574 ;--------------------------------------------------------
                                    575 ; paged external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area PSEG    (PAG,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; uninitialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XSEG    (XDATA)
      000BC9                        582 _extract_mod_bits_code_10000_599:
      000BC9                        583 	.ds 2
      000BCB                        584 _register_code16_code_10000_605:
      000BCB                        585 	.ds 2
      000BCD                        586 _unregister_code16_code_10000_610:
      000BCD                        587 	.ds 2
      000BCF                        588 _get_record_keycode_PARM_2:
      000BCF                        589 	.ds 1
      000BD0                        590 _get_record_keycode_record_argument_10000_648:
      000BD0                        591 	.ds 2
      000BD2                        592 _pre_process_record_quantum_record_argument_10000_654:
      000BD2                        593 	.ds 2
      000BD4                        594 _process_record_quantum_record_10000_658:
      000BD4                        595 	.ds 2
      000BD6                        596 _process_ak820_nkro_PARM_2:
      000BD6                        597 	.ds 3
      000BD9                        598 _process_ak820_nkro_keycode_10000_660:
      000BD9                        599 	.ds 2
      000BDB                        600 _process_record_quantum_helper_PARM_2:
      000BDB                        601 	.ds 2
      000BDD                        602 _process_record_quantum_helper_keycode_10000_665:
      000BDD                        603 	.ds 2
      000BDF                        604 _get_u8_str_last_num_10000_691:
      000BDF                        605 	.ds 1
      000BE0                        606 _get_u16_str_last_num_10000_695:
      000BE0                        607 	.ds 2
                                    608 ;--------------------------------------------------------
                                    609 ; absolute external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area XABS    (ABS,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; initialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XISEG   (XDATA)
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT0 (CODE)
                                    618 	.area GSINIT1 (CODE)
                                    619 	.area GSINIT2 (CODE)
                                    620 	.area GSINIT3 (CODE)
                                    621 	.area GSINIT4 (CODE)
                                    622 	.area GSINIT5 (CODE)
                                    623 	.area GSINIT  (CODE)
                                    624 	.area GSFINAL (CODE)
                                    625 	.area CSEG    (CODE)
                                    626 ;--------------------------------------------------------
                                    627 ; global & static initialisations
                                    628 ;--------------------------------------------------------
                                    629 	.area HOME    (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area GSINIT  (CODE)
                                    633 ;------------------------------------------------------------
                                    634 ;Allocation info for local variables in function 'get_u8_str'
                                    635 ;------------------------------------------------------------
                                    636 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    637 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_690'
                                    638 ;buf           Allocated with name '_get_u8_str_buf_10000_691'
                                    639 ;last_num      Allocated with name '_get_u8_str_last_num_10000_691'
                                    640 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_691'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0B DF         [24]  643 	mov	dptr,#_get_u8_str_last_num_10000_691
      0030F6 74 FF            [12]  644 	mov	a,#0xff
      0030F8 F0               [24]  645 	movx	@dptr,a
                                    646 ;------------------------------------------------------------
                                    647 ;Allocation info for local variables in function 'get_u16_str'
                                    648 ;------------------------------------------------------------
                                    649 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    650 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_694'
                                    651 ;buf           Allocated with name '_get_u16_str_buf_10000_695'
                                    652 ;last_num      Allocated with name '_get_u16_str_last_num_10000_695'
                                    653 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_695'
                                    654 ;------------------------------------------------------------
                                    655 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0B E0         [24]  656 	mov	dptr,#_get_u16_str_last_num_10000_695
      0030FC 74 FF            [12]  657 	mov	a,#0xff
      0030FE F0               [24]  658 	movx	@dptr,a
      0030FF E4               [12]  659 	clr	a
      003100 A3               [24]  660 	inc	dptr
      003101 F0               [24]  661 	movx	@dptr,a
                                    662 ;--------------------------------------------------------
                                    663 ; Home
                                    664 ;--------------------------------------------------------
                                    665 	.area HOME    (CODE)
                                    666 	.area HOME    (CODE)
                                    667 ;--------------------------------------------------------
                                    668 ; code
                                    669 ;--------------------------------------------------------
                                    670 	.area CSEG    (CODE)
                                    671 ;------------------------------------------------------------
                                    672 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    673 ;------------------------------------------------------------
                                    674 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    677 ;	-----------------------------------------
                           000007   678 	ar7 = 0x07
                           000006   679 	ar6 = 0x06
                           000005   680 	ar5 = 0x05
                           000004   681 	ar4 = 0x04
                           000003   682 	ar3 = 0x03
                           000002   683 	ar2 = 0x02
                           000001   684 	ar1 = 0x01
                           000000   685 	ar0 = 0x00
                                    686 ;	 function extract_mod_bits
                                    687 ;	-----------------------------------------
      009B67                        688 _extract_mod_bits:
      009B67 12 38 47         [24]  689 	lcall	_ak820_outline_0103
      009B6A 90 0B C9         [24]  690 	mov	dptr,#_extract_mod_bits_code_10000_599
      009B6D 12 38 42         [24]  691 	lcall	_ak820_outline_0102
                                    692 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      009B70 90 0B C9         [24]  693 	mov	dptr,#_extract_mod_bits_code_10000_599
      009B73 E0               [24]  694 	movx	a,@dptr
      009B74 A3               [24]  695 	inc	dptr
      009B75 E0               [24]  696 	movx	a,@dptr
                                    697 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009B76 FF               [12]  698 	mov	r7,a
      009B77 60 05            [24]  699 	jz	00101$
      009B79 EF               [12]  700 	mov	a,r7
      009B7A 24 E0            [12]  701 	add	a,#0xff - 0x1f
      009B7C 50 04            [24]  702 	jnc	00102$
                                    703 ;	free result
      009B7E                        704 00101$:
      009B7E 75 82 00         [24]  705 	mov	dpl, #0x00
      009B81 22               [24]  706 	ret
      009B82                        707 00102$:
                                    708 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009B82 EF               [12]  709 	mov	a,r7
      009B83 30 E4 07         [24]  710 	jnb	acc.4,00106$
      009B86 EF               [12]  711 	mov	a,r7
      009B87 C4               [12]  712 	swap	a
      009B88 54 F0            [12]  713 	anl	a,#0xf0
      009B8A FE               [12]  714 	mov	r6,a
      009B8B 80 02            [24]  715 	sjmp	00107$
      009B8D                        716 00106$:
      009B8D 8F 06            [24]  717 	mov	ar6,r7
      009B8F                        718 00107$:
      009B8F 8E 82            [24]  719 	mov	dpl, r6
                                    720 ;	quantum/quantum.c:143: }
      009B91 22               [24]  721 	ret
                                    722 ;------------------------------------------------------------
                                    723 ;Allocation info for local variables in function 'do_code16'
                                    724 ;------------------------------------------------------------
                                    725 ;f             Allocated with name '_do_code16_PARM_2'
                                    726 ;code          Allocated with name '_do_code16_code_10000_602'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function register_code16
                                    731 ;	-----------------------------------------
      009B92                        732 _register_code16:
      009B92 12 38 47         [24]  733 	lcall	_ak820_outline_0103
      009B95 90 0B CB         [24]  734 	mov	dptr,#_register_code16_code_10000_605
      009B98 12 38 42         [24]  735 	lcall	_ak820_outline_0102
                                    736 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      009B9B 90 0B CB         [24]  737 	mov	dptr,#_register_code16_code_10000_605
      009B9E 12 37 A2         [24]  738 	lcall	_ak820_outline_0004
      009BA1 C0 07            [24]  739 	push	ar7
      009BA3 C0 06            [24]  740 	push	ar6
      009BA5 12 9B 67         [24]  741 	lcall	_extract_mod_bits
      009BA8 AD 82            [24]  742 	mov	r5, dpl
      009BAA D0 06            [24]  743 	pop	ar6
      009BAC D0 07            [24]  744 	pop	ar7
                                    745 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009BAE 12 99 A8         [24]  746 	lcall	_ak820_outline_0114
      009BB1 40 07            [24]  747 	jc	00105$
      009BB3 74 E7            [12]  748 	mov	a,#0xe7
      009BB5 9E               [12]  749 	subb	a,r6
      009BB6 E4               [12]  750 	clr	a
      009BB7 9F               [12]  751 	subb	a,r7
      009BB8 50 08            [24]  752 	jnc	00101$
                                    753 ;	free result
      009BBA                        754 00105$:
      009BBA 90 0B CB         [24]  755 	mov	dptr,#_register_code16_code_10000_605
      009BBD 12 6C 7A         [24]  756 	lcall	_ak820_outline_0034
      009BC0 70 07            [24]  757 	jnz	00102$
      009BC2                        758 00101$:
                                    759 ;	quantum/quantum.c:153: register_mods(mods);
      009BC2 8D 82            [24]  760 	mov	dpl, r5
      009BC4 12 74 E4         [24]  761 	lcall	_register_mods
      009BC7 80 05            [24]  762 	sjmp	00103$
      009BC9                        763 00102$:
                                    764 ;	quantum/quantum.c:155: register_weak_mods(mods);
      009BC9 8D 82            [24]  765 	mov	dpl, r5
      009BCB 12 75 0C         [24]  766 	lcall	_register_weak_mods
      009BCE                        767 00103$:
                                    768 ;	quantum/quantum.c:157: register_code(code);
      009BCE 90 0B CB         [24]  769 	mov	dptr,#_register_code16_code_10000_605
      009BD1 E0               [24]  770 	movx	a,@dptr
      009BD2 F5 82            [12]  771 	mov	dpl,a
                                    772 ;	quantum/quantum.c:167: }
      009BD4 02 73 C1         [24]  773 	ljmp	_register_code
                                    774 ;------------------------------------------------------------
                                    775 ;Allocation info for local variables in function 'unregister_code16'
                                    776 ;------------------------------------------------------------
                                    777 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    778 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    779 ;------------------------------------------------------------
                                    780 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function unregister_code16
                                    783 ;	-----------------------------------------
      009BD7                        784 _unregister_code16:
      009BD7 12 38 47         [24]  785 	lcall	_ak820_outline_0103
      009BDA 90 0B CD         [24]  786 	mov	dptr,#_unregister_code16_code_10000_610
      009BDD 12 38 42         [24]  787 	lcall	_ak820_outline_0102
                                    788 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      009BE0 90 0B CD         [24]  789 	mov	dptr,#_unregister_code16_code_10000_610
      009BE3 12 37 A2         [24]  790 	lcall	_ak820_outline_0004
      009BE6 C0 07            [24]  791 	push	ar7
      009BE8 C0 06            [24]  792 	push	ar6
      009BEA 12 9B 67         [24]  793 	lcall	_extract_mod_bits
      009BED AD 82            [24]  794 	mov	r5, dpl
      009BEF D0 06            [24]  795 	pop	ar6
                                    796 ;	quantum/quantum.c:172: unregister_code(code);
      009BF1 8E 04            [24]  797 	mov	ar4,r6
      009BF3 8C 82            [24]  798 	mov	dpl, r4
      009BF5 C0 06            [24]  799 	push	ar6
      009BF7 C0 05            [24]  800 	push	ar5
      009BF9 12 74 2E         [24]  801 	lcall	_unregister_code
      009BFC D0 05            [24]  802 	pop	ar5
      009BFE D0 06            [24]  803 	pop	ar6
      009C00 D0 07            [24]  804 	pop	ar7
                                    805 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009C02 12 99 A8         [24]  806 	lcall	_ak820_outline_0114
      009C05 40 07            [24]  807 	jc	00105$
      009C07 74 E7            [12]  808 	mov	a,#0xe7
      009C09 9E               [12]  809 	subb	a,r6
      009C0A E4               [12]  810 	clr	a
      009C0B 9F               [12]  811 	subb	a,r7
      009C0C 50 08            [24]  812 	jnc	00101$
                                    813 ;	free result
      009C0E                        814 00105$:
      009C0E 90 0B CD         [24]  815 	mov	dptr,#_unregister_code16_code_10000_610
      009C11 12 6C 7A         [24]  816 	lcall	_ak820_outline_0034
      009C14 70 05            [24]  817 	jnz	00102$
      009C16                        818 00101$:
                                    819 ;	quantum/quantum.c:174: unregister_mods(mods);
      009C16 8D 82            [24]  820 	mov	dpl, r5
      009C18 02 74 F8         [24]  821 	ljmp	_unregister_mods
      009C1B                        822 00102$:
                                    823 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      009C1B 8D 82            [24]  824 	mov	dpl, r5
                                    825 ;	quantum/quantum.c:187: }
      009C1D 02 75 20         [24]  826 	ljmp	_unregister_weak_mods
                                    827 ;------------------------------------------------------------
                                    828 ;Allocation info for local variables in function 'tap_code16_delay'
                                    829 ;------------------------------------------------------------
                                    830 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    831 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    832 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    833 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    834 ;------------------------------------------------------------
                                    835 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    836 ;	-----------------------------------------
                                    837 ;	 function shutdown_quantum
                                    838 ;	-----------------------------------------
      009C20                        839 _shutdown_quantum:
                                    840 ;	quantum/quantum.c:237: clear_keyboard();
      009C20 12 75 34         [24]  841 	lcall	_clear_keyboard
                                    842 ;	quantum/quantum.c:252: shutdown_user();
      009C23 12 9E A9         [24]  843 	lcall	_shutdown_user
                                    844 ;	quantum/quantum.c:253: wait_ms(250);
      009C26 7F FA            [12]  845 	mov	r7,#0xfa
      009C28                        846 00106$:
      009C28 EF               [12]  847 	mov	a,r7
      009C29 60 09            [24]  848 	jz	00108$
      009C2B 90 00 01         [24]  849 	mov	dptr,#0x0001
      009C2E 12 57 E6         [24]  850 	lcall	_mDelaymS
      009C31 1F               [12]  851 	dec	r7
      009C32 80 F4            [24]  852 	sjmp	00106$
      009C34                        853 00108$:
                                    854 ;	quantum/quantum.c:258: }
      009C34 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'reset_keyboard'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function reset_keyboard
                                    862 ;	-----------------------------------------
      009C35                        863 _reset_keyboard:
                                    864 ;	quantum/quantum.c:261: shutdown_quantum();
      009C35 12 9C 20         [24]  865 	lcall	_shutdown_quantum
                                    866 ;	quantum/quantum.c:262: bootloader_jump();
                                    867 ;	quantum/quantum.c:263: }
      009C38 02 34 0E         [24]  868 	ljmp	_bootloader_jump
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    871 ;------------------------------------------------------------
                                    872 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function soft_reset_keyboard
                                    875 ;	-----------------------------------------
      009C3B                        876 _soft_reset_keyboard:
                                    877 ;	quantum/quantum.c:266: shutdown_quantum();
      009C3B 12 9C 20         [24]  878 	lcall	_shutdown_quantum
                                    879 ;	quantum/quantum.c:267: mcu_reset();
                                    880 ;	quantum/quantum.c:268: }
      009C3E 02 34 01         [24]  881 	ljmp	_mcu_reset
                                    882 ;------------------------------------------------------------
                                    883 ;Allocation info for local variables in function 'get_record_keycode'
                                    884 ;------------------------------------------------------------
                                    885 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    886 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                    887 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function get_record_keycode
                                    892 ;	-----------------------------------------
      009C41                        893 _get_record_keycode:
      009C41 12 38 47         [24]  894 	lcall	_ak820_outline_0103
      009C44 90 0B D0         [24]  895 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009C47 12 38 42         [24]  896 	lcall	_ak820_outline_0102
                                    897 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C4A 90 0B D0         [24]  898 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009C4D 12 37 B9         [24]  899 	lcall	_ak820_outline_0008
                                    900 ;	quantum/quantum.c:278: if (record->keycode) {
      009C50 4C               [12]  901 	orl	a,r4
      009C51 60 04            [24]  902 	jz	00102$
                                    903 ;	quantum/quantum.c:279: return record->keycode;
      009C53 12 38 53         [24]  904 	lcall	_ak820_outline_0117
      009C56 22               [24]  905 	ret
      009C57                        906 00102$:
                                    907 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009C57 12 75 76         [24]  908 	lcall	_ak820_outline_0018
      009C5A 7A 00            [12]  909 	mov	r2,#0x00
      009C5C 12 43 2F         [24]  910 	lcall	_ak820_outline_0138
      009C5F 12 37 AC         [24]  911 	lcall	_ak820_outline_0005
      009C62 60 06            [24]  912 	jz	00105$
      009C64 90 0B CF         [24]  913 	mov	dptr,#_get_record_keycode_PARM_2
      009C67 E0               [24]  914 	movx	a,@dptr
      009C68 70 04            [24]  915 	jnz	00106$
      009C6A                        916 00105$:
                                    917 ;	assignBit
      009C6A C2 23            [12]  918 	clr	_get_record_keycode_sloc0_1_0
      009C6C 80 02            [24]  919 	sjmp	00107$
      009C6E                        920 00106$:
                                    921 ;	assignBit
      009C6E D2 23            [12]  922 	setb	_get_record_keycode_sloc0_1_0
      009C70                        923 00107$:
      009C70 90 09 5F         [24]  924 	mov	dptr,#_ak820_resolve_key_PARM_2
      009C73 A2 23            [12]  925 	mov	c,_get_record_keycode_sloc0_1_0
      009C75 E4               [12]  926 	clr	a
      009C76 33               [12]  927 	rlc	a
      009C77 F0               [24]  928 	movx	@dptr,a
      009C78 8D 82            [24]  929 	mov	dpl, r5
      009C7A 8C 83            [24]  930 	mov	dph, r4
                                    931 ;	quantum/quantum.c:287: }
      009C7C 02 79 13         [24]  932 	ljmp	_ak820_resolve_key
                                    933 ;------------------------------------------------------------
                                    934 ;Allocation info for local variables in function 'get_event_keycode'
                                    935 ;------------------------------------------------------------
                                    936 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    937 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                    938 ;------------------------------------------------------------
                                    939 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    940 ;	-----------------------------------------
                                    941 ;	 function pre_process_record_quantum
                                    942 ;	-----------------------------------------
      009C7F                        943 _pre_process_record_quantum:
      009C7F 12 38 47         [24]  944 	lcall	_ak820_outline_0103
      009C82 90 0B D2         [24]  945 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C85 12 38 42         [24]  946 	lcall	_ak820_outline_0102
                                    947 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C88 90 0B D2         [24]  948 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C8B 12 37 F9         [24]  949 	lcall	_ak820_outline_0049
                                    950 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      009C8E 90 0B CF         [24]  951 	mov	dptr,#_get_record_keycode_PARM_2
      009C91 74 01            [12]  952 	mov	a,#0x01
      009C93 12 42 F4         [24]  953 	lcall	_ak820_outline_0058
      009C96 C0 07            [24]  954 	push	ar7
      009C98 C0 06            [24]  955 	push	ar6
      009C9A 12 9C 41         [24]  956 	lcall	_get_record_keycode
      009C9D 12 43 3A         [24]  957 	lcall	_ak820_outline_0143
      009CA0 D0 06            [24]  958 	pop	ar6
      009CA2 D0 07            [24]  959 	pop	ar7
                                    960 ;	quantum/quantum.c:334: record->keycode = keycode;
      009CA4 74 07            [12]  961 	mov	a,#0x07
      009CA6 12 37 E9         [24]  962 	lcall	_ak820_outline_0019
      009CA9 EC               [12]  963 	mov	a,r4
      009CAA F0               [24]  964 	movx	@dptr,a
      009CAB ED               [12]  965 	mov	a,r5
      009CAC A3               [24]  966 	inc	dptr
      009CAD 12 42 F4         [24]  967 	lcall	_ak820_outline_0058
                                    968 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009CB0 12 35 F0         [24]  969 	lcall	_ak820_combo_process
      009CB3 E5 82            [12]  970 	mov	a, dpl
      009CB5 70 04            [24]  971 	jnz	00104$
                                    972 ;	quantum/quantum.c:366: true;
                                    973 ;	assignBit
      009CB7 C2 24            [12]  974 	clr	_pre_process_record_quantum_sloc0_1_0
      009CB9 80 02            [24]  975 	sjmp	00105$
      009CBB                        976 00104$:
                                    977 ;	assignBit
      009CBB D2 24            [12]  978 	setb	_pre_process_record_quantum_sloc0_1_0
      009CBD                        979 00105$:
      009CBD A2 24            [12]  980 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009CBF 12 38 79         [24]  981 	lcall	_ak820_outline_0165
                                    982 ;	quantum/quantum.c:367: }
      009CC2 22               [24]  983 	ret
                                    984 ;------------------------------------------------------------
                                    985 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    986 ;------------------------------------------------------------
                                    987 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                    988 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                    989 ;------------------------------------------------------------
                                    990 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    991 ;	-----------------------------------------
                                    992 ;	 function process_record_quantum
                                    993 ;	-----------------------------------------
      009CC3                        994 _process_record_quantum:
      009CC3 12 38 47         [24]  995 	lcall	_ak820_outline_0103
      009CC6 90 0B D4         [24]  996 	mov	dptr,#_process_record_quantum_record_10000_658
      009CC9 12 38 42         [24]  997 	lcall	_ak820_outline_0102
                                    998 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      009CCC 90 0B D4         [24]  999 	mov	dptr,#_process_record_quantum_record_10000_658
      009CCF 12 37 F9         [24] 1000 	lcall	_ak820_outline_0049
      009CD2 90 0B CF         [24] 1001 	mov	dptr,#_get_record_keycode_PARM_2
      009CD5 E4               [12] 1002 	clr	a
      009CD6 12 42 F4         [24] 1003 	lcall	_ak820_outline_0058
      009CD9 12 9C 41         [24] 1004 	lcall	_get_record_keycode
      009CDC 12 43 24         [24] 1005 	lcall	_ak820_outline_0129
                                   1006 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      009CDF 90 0B D4         [24] 1007 	mov	dptr,#_process_record_quantum_record_10000_658
      009CE2 12 38 18         [24] 1008 	lcall	_ak820_outline_0057
      009CE5 90 0B DB         [24] 1009 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009CE8 EC               [12] 1010 	mov	a,r4
      009CE9 F0               [24] 1011 	movx	@dptr,a
      009CEA ED               [12] 1012 	mov	a,r5
      009CEB A3               [24] 1013 	inc	dptr
      009CEC 12 42 F4         [24] 1014 	lcall	_ak820_outline_0058
                                   1015 ;	quantum/quantum.c:382: }
      009CEF 02 9D 5D         [24] 1016 	ljmp	_process_record_quantum_helper
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1019 ;------------------------------------------------------------
                                   1020 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1021 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_660'
                                   1022 ;record        Allocated with name '_process_ak820_nkro_record_10000_661'
                                   1023 ;------------------------------------------------------------
                                   1024 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1025 ;	-----------------------------------------
                                   1026 ;	 function process_ak820_nkro
                                   1027 ;	-----------------------------------------
      009CF2                       1028 _process_ak820_nkro:
      009CF2 12 38 47         [24] 1029 	lcall	_ak820_outline_0103
      009CF5 90 0B D9         [24] 1030 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009CF8 12 38 42         [24] 1031 	lcall	_ak820_outline_0102
                                   1032 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009CFB 90 0B D6         [24] 1033 	mov	dptr,#_process_ak820_nkro_PARM_2
      009CFE 12 37 F9         [24] 1034 	lcall	_ak820_outline_0049
                                   1035 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      009D01 90 0B D9         [24] 1036 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009D04 12 38 18         [24] 1037 	lcall	_ak820_outline_0057
      009D07 C3               [12] 1038 	clr	c
      009D08 EC               [12] 1039 	mov	a,r4
      009D09 94 11            [12] 1040 	subb	a,#0x11
      009D0B ED               [12] 1041 	mov	a,r5
      009D0C 94 70            [12] 1042 	subb	a,#0x70
      009D0E 40 08            [24] 1043 	jc	00101$
      009D10 74 13            [12] 1044 	mov	a,#0x13
      009D12 9C               [12] 1045 	subb	a,r4
      009D13 74 70            [12] 1046 	mov	a,#0x70
      009D15 9D               [12] 1047 	subb	a,r5
      009D16 50 04            [24] 1048 	jnc	00102$
                                   1049 ;	free result
      009D18                       1050 00101$:
      009D18 75 82 01         [24] 1051 	mov	dpl, #0x01
      009D1B 22               [24] 1052 	ret
      009D1C                       1053 00102$:
                                   1054 ;	quantum/quantum.c:406: if (record->event.pressed) {
      009D1C 12 37 AC         [24] 1055 	lcall	_ak820_outline_0005
      009D1F 60 38            [24] 1056 	jz	00105$
                                   1057 ;	quantum/quantum.c:407: clear_keyboard();
      009D21 C0 05            [24] 1058 	push	ar5
      009D23 C0 04            [24] 1059 	push	ar4
      009D25 12 75 34         [24] 1060 	lcall	_clear_keyboard
      009D28 D0 04            [24] 1061 	pop	ar4
      009D2A D0 05            [24] 1062 	pop	ar5
                                   1063 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      009D2C BC 13 14         [24] 1064 	cjne	r4,#0x13,00108$
      009D2F BD 70 11         [24] 1065 	cjne	r5,#0x70,00108$
      009D32 90 0A B1         [24] 1066 	mov	dptr,#_keymap_config
      009D35 E0               [24] 1067 	movx	a,@dptr
      009D36 23               [12] 1068 	rl	a
      009D37 54 01            [12] 1069 	anl	a,#0x01
      009D39 B4 01 00         [24] 1070 	cjne	a,#0x01,00136$
      009D3C                       1071 00136$:
      009D3C 92 25            [24] 1072 	mov  _process_ak820_nkro_sloc0_1_0,c
      009D3E E4               [12] 1073 	clr	a
      009D3F 33               [12] 1074 	rlc	a
      009D40 FF               [12] 1075 	mov	r7,a
      009D41 80 09            [24] 1076 	sjmp	00109$
      009D43                       1077 00108$:
      009D43 E4               [12] 1078 	clr	a
      009D44 BC 11 04         [24] 1079 	cjne	r4,#0x11,00137$
      009D47 BD 70 01         [24] 1080 	cjne	r5,#0x70,00137$
      009D4A 04               [12] 1081 	inc	a
      009D4B                       1082 00137$:
      009D4B FF               [12] 1083 	mov	r7,a
      009D4C                       1084 00109$:
                                   1085 ;	assignBit
      009D4C EF               [12] 1086 	mov	a,r7
      009D4D 24 FF            [12] 1087 	add	a,#0xff
      009D4F E4               [12] 1088 	clr	a
      009D50 33               [12] 1089 	rlc	a
      009D51 90 0A B1         [24] 1090 	mov	dptr,#_keymap_config
      009D54 13               [12] 1091 	rrc	a
      009D55 E0               [24] 1092 	movx	a,@dptr
      009D56 92 E7            [24] 1093 	mov	acc.7,c
      009D58 F0               [24] 1094 	movx	@dptr,a
      009D59                       1095 00105$:
                                   1096 ;	quantum/quantum.c:410: return false;
      009D59 75 82 00         [24] 1097 	mov	dpl, #0x00
                                   1098 ;	quantum/quantum.c:411: }
      009D5C 22               [24] 1099 	ret
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1102 ;------------------------------------------------------------
                                   1103 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1104 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_665'
                                   1105 ;record        Allocated with name '_process_record_quantum_helper_record_10000_666'
                                   1106 ;------------------------------------------------------------
                                   1107 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1108 ;	-----------------------------------------
                                   1109 ;	 function process_record_quantum_helper
                                   1110 ;	-----------------------------------------
      009D5D                       1111 _process_record_quantum_helper:
      009D5D 12 38 47         [24] 1112 	lcall	_ak820_outline_0103
      009D60 90 0B DD         [24] 1113 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009D63 12 38 42         [24] 1114 	lcall	_ak820_outline_0102
                                   1115 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009D66 90 0B DB         [24] 1116 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009D69 12 37 F9         [24] 1117 	lcall	_ak820_outline_0049
                                   1118 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      009D6C 90 0B DD         [24] 1119 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009D6F 12 38 18         [24] 1120 	lcall	_ak820_outline_0057
      009D72 90 0B D6         [24] 1121 	mov	dptr,#_process_ak820_nkro_PARM_2
      009D75 12 9E AA         [24] 1122 	lcall	_ak820_outline_0006
      009D78 C0 07            [24] 1123 	push	ar7
      009D7A C0 06            [24] 1124 	push	ar6
      009D7C C0 05            [24] 1125 	push	ar5
      009D7E C0 04            [24] 1126 	push	ar4
      009D80 12 9C F2         [24] 1127 	lcall	_process_ak820_nkro
      009D83 E5 82            [12] 1128 	mov	a, dpl
      009D85 D0 04            [24] 1129 	pop	ar4
      009D87 D0 05            [24] 1130 	pop	ar5
      009D89 D0 06            [24] 1131 	pop	ar6
      009D8B D0 07            [24] 1132 	pop	ar7
      009D8D 70 03            [24] 1133 	jnz	00196$
      009D8F 02 9E 6C         [24] 1134 	ljmp	00101$
      009D92                       1135 00196$:
                                   1136 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      009D92 90 0B B4         [24] 1137 	mov	dptr,#_process_last_key_PARM_2
      009D95 12 47 BF         [24] 1138 	lcall	_ak820_outline_0056
      009D98 12 38 53         [24] 1139 	lcall	_ak820_outline_0117
      009D9B C0 07            [24] 1140 	push	ar7
      009D9D C0 06            [24] 1141 	push	ar6
      009D9F C0 05            [24] 1142 	push	ar5
      009DA1 C0 04            [24] 1143 	push	ar4
      009DA3 12 98 E8         [24] 1144 	lcall	_process_last_key
      009DA6 E5 82            [12] 1145 	mov	a, dpl
      009DA8 D0 04            [24] 1146 	pop	ar4
      009DAA D0 05            [24] 1147 	pop	ar5
      009DAC D0 06            [24] 1148 	pop	ar6
      009DAE D0 07            [24] 1149 	pop	ar7
      009DB0 70 03            [24] 1150 	jnz	00197$
      009DB2 02 9E 6C         [24] 1151 	ljmp	00101$
      009DB5                       1152 00197$:
      009DB5 90 0B B9         [24] 1153 	mov	dptr,#_process_repeat_key_PARM_2
      009DB8 12 47 BF         [24] 1154 	lcall	_ak820_outline_0056
      009DBB 12 38 53         [24] 1155 	lcall	_ak820_outline_0117
      009DBE C0 07            [24] 1156 	push	ar7
      009DC0 C0 06            [24] 1157 	push	ar6
      009DC2 C0 05            [24] 1158 	push	ar5
      009DC4 C0 04            [24] 1159 	push	ar4
      009DC6 12 99 61         [24] 1160 	lcall	_process_repeat_key
      009DC9 E5 82            [12] 1161 	mov	a, dpl
      009DCB D0 04            [24] 1162 	pop	ar4
      009DCD D0 05            [24] 1163 	pop	ar5
      009DCF D0 06            [24] 1164 	pop	ar6
      009DD1 D0 07            [24] 1165 	pop	ar7
      009DD3 70 03            [24] 1166 	jnz	00198$
      009DD5 02 9E 6C         [24] 1167 	ljmp	00101$
      009DD8                       1168 00198$:
                                   1169 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      009DD8 90 0C 16         [24] 1170 	mov	dptr,#_process_record_via_PARM_2
      009DDB 12 9E AA         [24] 1171 	lcall	_ak820_outline_0006
      009DDE C0 07            [24] 1172 	push	ar7
      009DE0 C0 06            [24] 1173 	push	ar6
      009DE2 C0 05            [24] 1174 	push	ar5
      009DE4 C0 04            [24] 1175 	push	ar4
      009DE6 12 A3 99         [24] 1176 	lcall	_process_record_via
      009DE9 E5 82            [12] 1177 	mov	a, dpl
      009DEB D0 04            [24] 1178 	pop	ar4
      009DED D0 05            [24] 1179 	pop	ar5
      009DEF D0 06            [24] 1180 	pop	ar6
      009DF1 D0 07            [24] 1181 	pop	ar7
      009DF3 70 03            [24] 1182 	jnz	00199$
      009DF5 02 9E 6C         [24] 1183 	ljmp	00101$
      009DF8                       1184 00199$:
                                   1185 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      009DF8 90 0B 9D         [24] 1186 	mov	dptr,#_process_caps_word_PARM_2
      009DFB 12 9E AA         [24] 1187 	lcall	_ak820_outline_0006
      009DFE C0 07            [24] 1188 	push	ar7
      009E00 C0 06            [24] 1189 	push	ar6
      009E02 C0 05            [24] 1190 	push	ar5
      009E04 C0 04            [24] 1191 	push	ar4
      009E06 12 96 87         [24] 1192 	lcall	_process_caps_word
      009E09 E5 82            [12] 1193 	mov	a, dpl
      009E0B D0 04            [24] 1194 	pop	ar4
      009E0D D0 05            [24] 1195 	pop	ar5
      009E0F D0 06            [24] 1196 	pop	ar6
      009E11 D0 07            [24] 1197 	pop	ar7
      009E13 60 57            [24] 1198 	jz	00101$
                                   1199 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      009E15 90 0B A2         [24] 1200 	mov	dptr,#_process_grave_esc_PARM_2
      009E18 12 9E AA         [24] 1201 	lcall	_ak820_outline_0006
      009E1B C0 07            [24] 1202 	push	ar7
      009E1D C0 06            [24] 1203 	push	ar6
      009E1F C0 05            [24] 1204 	push	ar5
      009E21 C0 04            [24] 1205 	push	ar4
      009E23 12 97 9A         [24] 1206 	lcall	_process_grave_esc
      009E26 E5 82            [12] 1207 	mov	a, dpl
      009E28 D0 04            [24] 1208 	pop	ar4
      009E2A D0 05            [24] 1209 	pop	ar5
      009E2C D0 06            [24] 1210 	pop	ar6
      009E2E D0 07            [24] 1211 	pop	ar7
      009E30 60 3A            [24] 1212 	jz	00101$
                                   1213 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      009E32 90 0B BD         [24] 1214 	mov	dptr,#_process_rgb_PARM_2
      009E35 12 9E AA         [24] 1215 	lcall	_ak820_outline_0006
      009E38 C0 07            [24] 1216 	push	ar7
      009E3A C0 06            [24] 1217 	push	ar6
      009E3C C0 05            [24] 1218 	push	ar5
      009E3E C0 04            [24] 1219 	push	ar4
      009E40 12 99 B0         [24] 1220 	lcall	_process_rgb
      009E43 E5 82            [12] 1221 	mov	a, dpl
      009E45 D0 04            [24] 1222 	pop	ar4
      009E47 D0 05            [24] 1223 	pop	ar5
      009E49 D0 06            [24] 1224 	pop	ar6
      009E4B D0 07            [24] 1225 	pop	ar7
      009E4D 60 1D            [24] 1226 	jz	00101$
                                   1227 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      009E4F 90 0B C3         [24] 1228 	mov	dptr,#_process_tri_layer_PARM_2
      009E52 12 9E AA         [24] 1229 	lcall	_ak820_outline_0006
      009E55 C0 07            [24] 1230 	push	ar7
      009E57 C0 06            [24] 1231 	push	ar6
      009E59 C0 05            [24] 1232 	push	ar5
      009E5B C0 04            [24] 1233 	push	ar4
      009E5D 12 9A 61         [24] 1234 	lcall	_process_tri_layer
      009E60 E5 82            [12] 1235 	mov	a, dpl
      009E62 D0 04            [24] 1236 	pop	ar4
      009E64 D0 05            [24] 1237 	pop	ar5
      009E66 D0 06            [24] 1238 	pop	ar6
      009E68 D0 07            [24] 1239 	pop	ar7
      009E6A 70 04            [24] 1240 	jnz	00102$
                                   1241 ;	quantum/quantum.c:561: true)) {
      009E6C                       1242 00101$:
                                   1243 ;	quantum/quantum.c:562: return false;
      009E6C 75 82 00         [24] 1244 	mov	dpl, #0x00
      009E6F 22               [24] 1245 	ret
      009E70                       1246 00102$:
                                   1247 ;	quantum/quantum.c:565: if (record->event.pressed) {
      009E70 12 37 AC         [24] 1248 	lcall	_ak820_outline_0005
      009E73 60 30            [24] 1249 	jz	00116$
                                   1250 ;	quantum/quantum.c:566: switch (keycode) {
      009E75 BC 00 05         [24] 1251 	cjne	r4,#0x00,00205$
      009E78 BD 7C 02         [24] 1252 	cjne	r5,#0x7c,00205$
      009E7B 80 10            [24] 1253 	sjmp	00111$
      009E7D                       1254 00205$:
      009E7D BC 01 05         [24] 1255 	cjne	r4,#0x01,00206$
      009E80 BD 7C 02         [24] 1256 	cjne	r5,#0x7c,00206$
      009E83 80 0F            [24] 1257 	sjmp	00112$
      009E85                       1258 00206$:
                                   1259 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      009E85 BC 03 1D         [24] 1260 	cjne	r4,#0x03,00116$
      009E88 BD 7C 1A         [24] 1261 	cjne	r5,#0x7c,00116$
      009E8B 80 0E            [24] 1262 	sjmp	00113$
      009E8D                       1263 00111$:
                                   1264 ;	quantum/quantum.c:569: reset_keyboard();
      009E8D 12 9C 35         [24] 1265 	lcall	_reset_keyboard
                                   1266 ;	quantum/quantum.c:570: return false;
      009E90 75 82 00         [24] 1267 	mov	dpl, #0x00
                                   1268 ;	quantum/quantum.c:571: case QK_REBOOT:
      009E93 22               [24] 1269 	ret
      009E94                       1270 00112$:
                                   1271 ;	quantum/quantum.c:572: soft_reset_keyboard();
      009E94 12 9C 3B         [24] 1272 	lcall	_soft_reset_keyboard
                                   1273 ;	quantum/quantum.c:573: return false;
      009E97 75 82 00         [24] 1274 	mov	dpl, #0x00
                                   1275 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      009E9A 22               [24] 1276 	ret
      009E9B                       1277 00113$:
                                   1278 ;	quantum/quantum.c:592: eeconfig_disable();
      009E9B 12 8D F2         [24] 1279 	lcall	_eeconfig_disable
                                   1280 ;	quantum/quantum.c:593: soft_reset_keyboard();
      009E9E 12 9C 3B         [24] 1281 	lcall	_soft_reset_keyboard
                                   1282 ;	quantum/quantum.c:595: return false;
      009EA1 75 82 00         [24] 1283 	mov	dpl, #0x00
                                   1284 ;	quantum/quantum.c:650: }
      009EA4 22               [24] 1285 	ret
      009EA5                       1286 00116$:
                                   1287 ;	quantum/quantum.c:654: return true;
      009EA5 75 82 01         [24] 1288 	mov	dpl, #0x01
                                   1289 ;	quantum/quantum.c:658: }
      009EA8 22               [24] 1290 	ret
                                   1291 ;------------------------------------------------------------
                                   1292 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1293 ;------------------------------------------------------------
                                   1294 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_673'
                                   1295 ;------------------------------------------------------------
                                   1296 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1297 ;	-----------------------------------------
                                   1298 ;	 function shutdown_user
                                   1299 ;	-----------------------------------------
      009EA9                       1300 _shutdown_user:
      009EA9 22               [24] 1301 	ret
                                   1302 ;------------------------------------------------------------
                                   1303 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1304 ;------------------------------------------------------------
                                   1305 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1306 ;	-----------------------------------------
                                   1307 	.area CSEG    (CODE)
                                   1308 	.area CONST   (CODE)
                                   1309 	.area XINIT   (CODE)
                                   1310 	.area CABS    (ABS,CODE)
                                   1311 
                                   1312 ; Experimental exact instruction outlining.
                                   1313 	.globl _ak820_outline_0004
                                   1314 	.globl _ak820_outline_0005
                                   1315 	.globl _ak820_outline_0006
                                   1316 	.globl _ak820_outline_0008
                                   1317 	.globl _ak820_outline_0018
                                   1318 	.globl _ak820_outline_0019
                                   1319 	.globl _ak820_outline_0034
                                   1320 	.globl _ak820_outline_0049
                                   1321 	.globl _ak820_outline_0056
                                   1322 	.globl _ak820_outline_0057
                                   1323 	.globl _ak820_outline_0058
                                   1324 	.globl _ak820_outline_0102
                                   1325 	.globl _ak820_outline_0103
                                   1326 	.globl _ak820_outline_0114
                                   1327 	.globl _ak820_outline_0117
                                   1328 	.globl _ak820_outline_0129
                                   1329 	.globl _ak820_outline_0138
                                   1330 	.globl _ak820_outline_0143
                                   1331 	.globl _ak820_outline_0165
                                   1332 
                                   1333 	.area CSEG (CODE)
                                   1334 ; function ak820_outline_0006
      009EAA                       1335 _ak820_outline_0006:
      009EAA EE               [12] 1336 	mov	a,r6
      009EAB F0               [24] 1337 	movx	@dptr,a
      009EAC EF               [12] 1338 	mov	a,r7
      009EAD A3               [24] 1339 	inc	dptr
      009EAE F0               [24] 1340 	movx	@dptr,a
      009EAF E4               [12] 1341 	clr	a
      009EB0 A3               [24] 1342 	inc	dptr
      009EB1 F0               [24] 1343 	movx	@dptr,a
      009EB2 8C 82            [24] 1344 	mov	dpl,r4
      009EB4 8D 83            [24] 1345 	mov	dph,r5
      009EB6 22               [24] 1346 	ret
