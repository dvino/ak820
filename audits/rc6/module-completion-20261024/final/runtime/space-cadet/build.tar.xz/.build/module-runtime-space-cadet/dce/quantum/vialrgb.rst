                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      000049                        535 _fast_set_leds_sloc0_1_0:
      000049                        536 	.ds 2
      00004B                        537 _fast_set_leds_sloc1_1_0:
      00004B                        538 	.ds 2
      00004D                        539 _vialrgb_get_value_sloc0_1_0:
      00004D                        540 	.ds 2
      00004F                        541 _vialrgb_get_value_sloc1_1_0:
      00004F                        542 	.ds 2
      000051                        543 _vialrgb_set_value_sloc0_1_0:
      000051                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C4E                        569 _g_direct_mode_colors::
      000C4E                        570 	.ds 246
      000D44                        571 _get_supported_PARM_2:
      000D44                        572 	.ds 1
      000D45                        573 _get_supported_args_10000_255:
      000D45                        574 	.ds 2
      000D47                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D47                        576 	.ds 2
      000D49                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D49                        578 	.ds 2
      000D4B                        579 _set_mode_mode_10000_275:
      000D4B                        580 	.ds 2
      000D4D                        581 _get_matrix_pos_for_led_PARM_2:
      000D4D                        582 	.ds 2
      000D4F                        583 _get_matrix_pos_for_led_led_10000_280:
      000D4F                        584 	.ds 2
      000D51                        585 _fast_set_leds_PARM_2:
      000D51                        586 	.ds 1
      000D52                        587 _fast_set_leds_args_10000_282:
      000D52                        588 	.ds 2
      000D54                        589 _fast_set_leds_first_index_10001_285:
      000D54                        590 	.ds 2
      000D56                        591 _fast_set_leds_num_leds_10001_285:
      000D56                        592 	.ds 1
      000D57                        593 _vialrgb_get_value_PARM_2:
      000D57                        594 	.ds 1
      000D58                        595 _vialrgb_get_value_data_10000_291:
      000D58                        596 	.ds 3
      000D5B                        597 _vialrgb_set_value_PARM_2:
      000D5B                        598 	.ds 1
      000D5C                        599 _vialrgb_set_value_data_10000_302:
      000D5C                        600 	.ds 3
      000D5F                        601 _vialrgb_save_PARM_2:
      000D5F                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00ADA9                        654 _get_supported:
      00ADA9 12 38 3C         [24]  655 	lcall	_ak820_outline_0098
      00ADAC 90 0D 45         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00ADAF 12 38 41         [24]  657 	lcall	_ak820_outline_0099
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00ADB2 90 0D 45         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00ADB5 12 37 A2         [24]  660 	lcall	_ak820_outline_0004
      00ADB8 E0               [24]  661 	movx	a,@dptr
      00ADB9 FD               [12]  662 	mov	r5,a
      00ADBA 7C 00            [12]  663 	mov	r4,#0x00
      00ADBC 12 38 46         [24]  664 	lcall	_ak820_outline_0101
      00ADBF FA               [12]  665 	mov	r2,a
      00ADC0 E4               [12]  666 	clr	a
      00ADC1 12 43 2A         [24]  667 	lcall	_ak820_outline_0131
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00ADC4 90 0D 44         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00ADC7 E0               [24]  670 	movx	a,@dptr
      00ADC8 FB               [12]  671 	mov	r3,a
      00ADC9 7A 00            [12]  672 	mov	r2,#0x00
      00ADCB                        673 00107$:
      00ADCB C3               [12]  674 	clr	c
      00ADCC EA               [12]  675 	mov	a,r2
      00ADCD 9B               [12]  676 	subb	a,r3
      00ADCE 50 0A            [24]  677 	jnc	00101$
      00ADD0 EA               [12]  678 	mov	a,r2
      00ADD1 12 37 E9         [24]  679 	lcall	_ak820_outline_0018
      00ADD4 74 FF            [12]  680 	mov	a,#0xff
      00ADD6 F0               [24]  681 	movx	@dptr,a
      00ADD7 0A               [12]  682 	inc	r2
      00ADD8 80 F1            [24]  683 	sjmp	00107$
      00ADDA                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00ADDA 8D 06            [24]  686 	mov	ar6,r5
      00ADDC 8C 07            [24]  687 	mov	ar7,r4
      00ADDE 8B 05            [24]  688 	mov	ar5,r3
      00ADE0 90 0D 45         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00ADE3 12 38 52         [24]  690 	lcall	_ak820_outline_0112
      00ADE6 7A 00            [12]  691 	mov	r2,#0x00
      00ADE8                        692 00110$:
      00ADE8 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00ADEB                        694 00159$:
      00ADEB 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00ADED EA               [12]  697 	mov	a,r2
      00ADEE 75 F0 02         [24]  698 	mov	b,#0x02
      00ADF1 A4               [48]  699 	mul	ab
      00ADF2 24 53            [12]  700 	add	a, #_supported_modes
      00ADF4 F5 82            [12]  701 	mov	dpl,a
      00ADF6 74 BA            [12]  702 	mov	a,#(_supported_modes >> 8)
      00ADF8 12 55 50         [24]  703 	lcall	_ak820_outline_0100
      00ADFB F8               [12]  704 	mov	r0,a
      00ADFC 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00ADFE C3               [12]  707 	clr	c
      00ADFF EE               [12]  708 	mov	a,r6
      00AE00 98               [12]  709 	subb	a,r0
      00AE01 EF               [12]  710 	mov	a,r7
      00AE02 99               [12]  711 	subb	a,r1
      00AE03 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00AE05 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00AE08                        715 00162$:
      00AE08 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00AE0A C0 06            [24]  718 	push	ar6
      00AE0C C0 07            [24]  719 	push	ar7
      00AE0E 88 07            [24]  720 	mov	ar7,r0
      00AE10 12 33 FC         [24]  721 	lcall	_ak820_outline_0113
      00AE13 EF               [12]  722 	mov	a,r7
      00AE14 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00AE15 12 33 FC         [24]  725 	lcall	_ak820_outline_0113
      00AE18 A3               [24]  726 	inc	dptr
      00AE19 89 00            [24]  727 	mov	ar0,r1
      00AE1B E8               [12]  728 	mov	a,r0
      00AE1C F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00AE1D 1D               [12]  731 	dec	r5
      00AE1E 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00AE1F 74 02            [12]  734 	mov	a,#0x02
      00AE21 2B               [12]  735 	add	a, r3
      00AE22 FB               [12]  736 	mov	r3,a
      00AE23 E4               [12]  737 	clr	a
      00AE24 3C               [12]  738 	addc	a, r4
      00AE25 FC               [12]  739 	mov	r4,a
      00AE26 90 0D 45         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00AE29 12 38 2A         [24]  741 	lcall	_ak820_outline_0071
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE2C D0 07            [24]  743 	pop	ar7
      00AE2E D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00AE30                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE30 0A               [12]  748 	inc	r2
      00AE31 80 B5            [24]  749 	sjmp	00110$
      00AE33                        750 00127$:
      00AE33 90 0D 45         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00AE36 12 38 2A         [24]  752 	lcall	_ak820_outline_0071
                                    753 ;	quantum/vialrgb.c:55: }
      00AE39 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00AE3A                        766 _qmk_id_to_vialrgb_id:
      00AE3A 12 38 3C         [24]  767 	lcall	_ak820_outline_0098
      00AE3D 90 0D 47         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00AE40 12 38 41         [24]  769 	lcall	_ak820_outline_0099
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE43 90 0D 47         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00AE46 12 37 F9         [24]  772 	lcall	_ak820_outline_0047
      00AE49 7D 00            [12]  773 	mov	r5,#0x00
      00AE4B                        774 00105$:
      00AE4B BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00AE4E                        776 00130$:
      00AE4E 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00AE50 12 B2 72         [24]  779 	lcall	_ak820_outline_0042
      00AE53 A3               [24]  780 	inc	dptr
      00AE54 E4               [12]  781 	clr	a
      00AE55 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00AE56 7A 00            [12]  784 	mov	r2,#0x00
      00AE58 B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00AE5B EA               [12]  786 	mov	a,r2
      00AE5C B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AE5F 12 33 FC         [24]  789 	lcall	_ak820_outline_0113
      00AE62 12 B2 9E         [24]  790 	lcall	_ak820_outline_0133
      00AE65 22               [24]  791 	ret
      00AE66                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE66 0D               [12]  794 	inc	r5
      00AE67 80 E2            [24]  795 	sjmp	00105$
      00AE69                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00AE69 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00AE6C 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00AE6D                        812 _vialrgb_id_to_qmk_id:
      00AE6D 12 38 3C         [24]  813 	lcall	_ak820_outline_0098
      00AE70 90 0D 49         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00AE73 12 38 41         [24]  815 	lcall	_ak820_outline_0099
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE76 90 0D 49         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00AE79 12 37 F9         [24]  818 	lcall	_ak820_outline_0047
      00AE7C 7D 00            [12]  819 	mov	r5,#0x00
      00AE7E                        820 00105$:
      00AE7E BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00AE81                        822 00130$:
      00AE81 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AE83 12 B2 72         [24]  825 	lcall	_ak820_outline_0042
      00AE86 E4               [12]  826 	clr	a
      00AE87 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00AE88 7A 00            [12]  829 	mov	r2,#0x00
      00AE8A B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00AE8D EA               [12]  831 	mov	a,r2
      00AE8E B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00AE91 12 33 FC         [24]  834 	lcall	_ak820_outline_0113
      00AE94 A3               [24]  835 	inc	dptr
      00AE95 12 B2 9E         [24]  836 	lcall	_ak820_outline_0133
      00AE98 22               [24]  837 	ret
      00AE99                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AE99 0D               [12]  840 	inc	r5
      00AE9A 80 E2            [24]  841 	sjmp	00105$
      00AE9C                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00AE9C 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00AE9F 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00AEA0                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00AEA0 12 53 45         [24]  856 	lcall	_rgb_matrix_is_enabled
      00AEA3 E5 82            [12]  857 	mov	a, dpl
      00AEA5 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00AEA7 90 00 00         [24]  860 	mov	dptr,#0x0000
      00AEAA 22               [24]  861 	ret
      00AEAB                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00AEAB 12 53 4B         [24]  864 	lcall	_rgb_matrix_get_mode
      00AEAE 7E 00            [12]  865 	mov	r6,#0x00
      00AEB0 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00AEB2 02 AE 3A         [24]  868 	ljmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00AEB5                        878 _set_mode:
      00AEB5 12 38 3C         [24]  879 	lcall	_ak820_outline_0098
      00AEB8 90 0D 4B         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00AEBB 12 38 41         [24]  881 	lcall	_ak820_outline_0099
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00AEBE 90 0D 4B         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00AEC1 12 37 F9         [24]  884 	lcall	_ak820_outline_0047
      00AEC4 90 0D 4B         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00AEC7 12 6B A1         [24]  886 	lcall	_ak820_outline_0033
      00AECA 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00AECC 02 53 98         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00AECF                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00AECF C0 07            [24]  892 	push	ar7
      00AED1 C0 06            [24]  893 	push	ar6
      00AED3 12 53 87         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00AED6 D0 06            [24]  895 	pop	ar6
      00AED8 D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00AEDA 12 43 1A         [24]  898 	lcall	_ak820_outline_0109
      00AEDD 12 AE 6D         [24]  899 	lcall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00AEE0 02 53 A1         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00AEE3                        913 _get_matrix_pos_for_led:
      00AEE3 12 38 3C         [24]  914 	lcall	_ak820_outline_0098
      00AEE6 90 0D 4F         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00AEE9 12 38 41         [24]  916 	lcall	_ak820_outline_0099
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00AEEC 90 0D 4F         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00AEEF 12 37 F9         [24]  919 	lcall	_ak820_outline_0047
      00AEF2 EE               [12]  920 	mov	a,r6
      00AEF3 24 5A            [12]  921 	add	a, #_ak820_rgb_slots
      00AEF5 F5 82            [12]  922 	mov	dpl,a
      00AEF7 EF               [12]  923 	mov	a,r7
      00AEF8 34 B4            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00AEFA F5 83            [12]  925 	mov	dph,a
      00AEFC E4               [12]  926 	clr	a
      00AEFD 93               [24]  927 	movc	a,@a+dptr
      00AEFE FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00AEFF 90 0D 4D         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00AF02 12 43 08         [24]  931 	lcall	_ak820_outline_0094
      00AF05 EF               [12]  932 	mov	a,r7
      00AF06 12 55 86         [24]  933 	lcall	_ak820_outline_0174
      00AF09 12 7D C6         [24]  934 	lcall	_ak820_outline_0111
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00AF0C 12 38 5D         [24]  936 	lcall	_ak820_outline_0122
      00AF0F A3               [24]  937 	inc	dptr
      00AF10 53 07 07         [24]  938 	anl	ar7,#0x07
      00AF13 EF               [12]  939 	mov	a,r7
      00AF14 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00AF15 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00AF16                        960 _fast_set_leds:
      00AF16 12 38 3C         [24]  961 	lcall	_ak820_outline_0098
      00AF19 90 0D 52         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00AF1C 12 38 41         [24]  963 	lcall	_ak820_outline_0099
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00AF1F 90 0D 51         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00AF22 E0               [24]  966 	movx	a,@dptr
      00AF23 FF               [12]  967 	mov	r7,a
      00AF24 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00AF27                        969 00159$:
      00AF27 50 01            [24]  970 	jnc	00102$
      00AF29 22               [24]  971 	ret
      00AF2A                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00AF2A 90 0D 52         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00AF2D E0               [24]  975 	movx	a,@dptr
      00AF2E FD               [12]  976 	mov	r5,a
      00AF2F A3               [24]  977 	inc	dptr
      00AF30 E0               [24]  978 	movx	a,@dptr
      00AF31 12 46 FB         [24]  979 	lcall	_ak820_outline_0053
      00AF34 7B 00            [12]  980 	mov	r3,#0x00
      00AF36 12 38 5D         [24]  981 	lcall	_ak820_outline_0122
      00AF39 A3               [24]  982 	inc	dptr
      00AF3A E0               [24]  983 	movx	a,@dptr
      00AF3B FA               [12]  984 	mov	r2,a
      00AF3C 79 00            [12]  985 	mov	r1,#0x00
      00AF3E 90 0D 54         [24]  986 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00AF41 E9               [12]  987 	mov	a,r1
      00AF42 4C               [12]  988 	orl	a,r4
      00AF43 F0               [24]  989 	movx	@dptr,a
      00AF44 EA               [12]  990 	mov	a,r2
      00AF45 4B               [12]  991 	orl	a,r3
      00AF46 A3               [24]  992 	inc	dptr
      00AF47 F0               [24]  993 	movx	@dptr,a
                                    994 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00AF48 12 38 5D         [24]  995 	lcall	_ak820_outline_0122
      00AF4B A3               [24]  996 	inc	dptr
      00AF4C A3               [24]  997 	inc	dptr
      00AF4D E0               [24]  998 	movx	a,@dptr
      00AF4E 90 0D 56         [24]  999 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AF51 F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	quantum/vialrgb.c:119: length -= 3;
      00AF52 EF               [12] 1002 	mov	a,r7
      00AF53 24 FD            [12] 1003 	add	a,#0xfd
      00AF55 90 0D 51         [24] 1004 	mov	dptr,#_fast_set_leds_PARM_2
      00AF58 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	quantum/vialrgb.c:120: args += 3;
      00AF59 90 0D 52         [24] 1007 	mov	dptr,#_fast_set_leds_args_10000_282
      00AF5C 74 03            [12] 1008 	mov	a,#0x03
      00AF5E 2D               [12] 1009 	add	a, r5
      00AF5F F0               [24] 1010 	movx	@dptr,a
      00AF60 E4               [12] 1011 	clr	a
      00AF61 3E               [12] 1012 	addc	a, r6
      00AF62 A3               [24] 1013 	inc	dptr
      00AF63 F0               [24] 1014 	movx	@dptr,a
                                   1015 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00AF64 90 0D 56         [24] 1016 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AF67 E0               [24] 1017 	movx	a,@dptr
      00AF68 FF               [12] 1018 	mov	r7,a
      00AF69 75 F0 03         [24] 1019 	mov	b,#0x03
      00AF6C A4               [48] 1020 	mul	ab
      00AF6D FE               [12] 1021 	mov	r6,a
      00AF6E AD F0            [24] 1022 	mov	r5,b
      00AF70 90 0D 51         [24] 1023 	mov	dptr,#_fast_set_leds_PARM_2
      00AF73 E0               [24] 1024 	movx	a,@dptr
      00AF74 FB               [12] 1025 	mov	r3,a
      00AF75 7C 00            [12] 1026 	mov	r4,#0x00
      00AF77 C3               [12] 1027 	clr	c
      00AF78 EB               [12] 1028 	mov	a,r3
      00AF79 9E               [12] 1029 	subb	a,r6
      00AF7A EC               [12] 1030 	mov	a,r4
      00AF7B 9D               [12] 1031 	subb	a,r5
      00AF7C 40 13            [24] 1032 	jc	00103$
                                   1033 ;	free result
      00AF7E 90 0D 54         [24] 1034 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00AF81 12 43 08         [24] 1035 	lcall	_ak820_outline_0094
      00AF84 8D 03            [24] 1036 	mov	ar3,r5
      00AF86 8E 04            [24] 1037 	mov	ar4,r6
      00AF88 C3               [12] 1038 	clr	c
      00AF89 EB               [12] 1039 	mov	a,r3
      00AF8A 94 52            [12] 1040 	subb	a,#0x52
      00AF8C EC               [12] 1041 	mov	a,r4
      00AF8D 94 00            [12] 1042 	subb	a,#0x00
      00AF8F 40 01            [24] 1043 	jc	00104$
      00AF91                       1044 00103$:
      00AF91 22               [24] 1045 	ret
      00AF92                       1046 00104$:
                                   1047 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00AF92 74 52            [12] 1048 	mov	a,#0x52
      00AF94 C3               [12] 1049 	clr	c
      00AF95 9D               [12] 1050 	subb	a,r5
      00AF96 FB               [12] 1051 	mov	r3,a
      00AF97 E4               [12] 1052 	clr	a
      00AF98 9E               [12] 1053 	subb	a,r6
      00AF99 FC               [12] 1054 	mov	r4,a
      00AF9A 7A 00            [12] 1055 	mov	r2,#0x00
      00AF9C C3               [12] 1056 	clr	c
      00AF9D EB               [12] 1057 	mov	a,r3
      00AF9E 9F               [12] 1058 	subb	a,r7
      00AF9F EC               [12] 1059 	mov	a,r4
      00AFA0 9A               [12] 1060 	subb	a,r2
      00AFA1 50 08            [24] 1061 	jnc	00127$
                                   1062 ;	free result
      00AFA3 90 0D 56         [24] 1063 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AFA6 74 52            [12] 1064 	mov	a,#0x52
      00AFA8 C3               [12] 1065 	clr	c
      00AFA9 9D               [12] 1066 	subb	a,r5
      00AFAA F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00AFAB                       1069 00127$:
      00AFAB 90 0D 56         [24] 1070 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00AFAE E0               [24] 1071 	movx	a,@dptr
      00AFAF FF               [12] 1072 	mov	r7,a
      00AFB0 90 0D 54         [24] 1073 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00AFB3 12 43 08         [24] 1074 	lcall	_ak820_outline_0094
      00AFB6 7C 00            [12] 1075 	mov	r4,#0x00
      00AFB8                       1076 00110$:
      00AFB8 C3               [12] 1077 	clr	c
      00AFB9 EC               [12] 1078 	mov	a,r4
      00AFBA 9F               [12] 1079 	subb	a,r7
      00AFBB 40 01            [24] 1080 	jc	00164$
      00AFBD 22               [24] 1081 	ret
      00AFBE                       1082 00164$:
                                   1083 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00AFBE C0 07            [24] 1084 	push	ar7
      00AFC0 90 0D 6E         [24] 1085 	mov	dptr,#__mulint_PARM_2
      00AFC3 12 43 45         [24] 1086 	lcall	_ak820_outline_0149
      00AFC6 90 00 03         [24] 1087 	mov	dptr,#0x0003
      00AFC9 C0 07            [24] 1088 	push	ar7
      00AFCB C0 06            [24] 1089 	push	ar6
      00AFCD C0 05            [24] 1090 	push	ar5
      00AFCF C0 04            [24] 1091 	push	ar4
      00AFD1 12 B4 0A         [24] 1092 	lcall	__mulint
      00AFD4 AA 82            [24] 1093 	mov	r2, dpl
      00AFD6 AB 83            [24] 1094 	mov	r3, dph
      00AFD8 D0 04            [24] 1095 	pop	ar4
      00AFDA D0 05            [24] 1096 	pop	ar5
      00AFDC D0 06            [24] 1097 	pop	ar6
      00AFDE D0 07            [24] 1098 	pop	ar7
      00AFE0 0D               [12] 1099 	inc	r5
      00AFE1 BD 00 01         [24] 1100 	cjne	r5,#0x00,00165$
      00AFE4 0E               [12] 1101 	inc	r6
      00AFE5                       1102 00165$:
      00AFE5 EA               [12] 1103 	mov	a,r2
      00AFE6 24 4E            [12] 1104 	add	a, #_g_direct_mode_colors
      00AFE8 FA               [12] 1105 	mov	r2,a
      00AFE9 EB               [12] 1106 	mov	a,r3
      00AFEA 34 0C            [12] 1107 	addc	a, #(_g_direct_mode_colors >> 8)
      00AFEC FB               [12] 1108 	mov	r3,a
                                   1109 ;	quantum/vialrgb.c:128: color->h = *args++;
      00AFED 8A 49            [24] 1110 	mov	_fast_set_leds_sloc0_1_0,r2
      00AFEF 8B 4A            [24] 1111 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00AFF1 12 B2 84         [24] 1112 	lcall	_ak820_outline_0075
      00AFF4 F8               [12] 1113 	mov	r0,a
      00AFF5 12 B2 92         [24] 1114 	lcall	_ak820_outline_0097
      00AFF8 85 49 82         [24] 1115 	mov	dpl,_fast_set_leds_sloc0_1_0
      00AFFB 85 4A 83         [24] 1116 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00AFFE E8               [12] 1117 	mov	a,r0
      00AFFF F0               [24] 1118 	movx	@dptr,a
                                   1119 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B000 74 01            [12] 1120 	mov	a,#0x01
      00B002 2A               [12] 1121 	add	a, r2
      00B003 F5 49            [12] 1122 	mov	_fast_set_leds_sloc0_1_0,a
      00B005 E4               [12] 1123 	clr	a
      00B006 3B               [12] 1124 	addc	a, r3
      00B007 F5 4A            [12] 1125 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B009 90 0D 52         [24] 1126 	mov	dptr,#_fast_set_leds_args_10000_282
      00B00C E0               [24] 1127 	movx	a,@dptr
      00B00D F8               [12] 1128 	mov	r0,a
      00B00E A3               [24] 1129 	inc	dptr
      00B00F E0               [24] 1130 	movx	a,@dptr
      00B010 FF               [12] 1131 	mov	r7,a
      00B011 88 82            [24] 1132 	mov	dpl,r0
      00B013 8F 83            [24] 1133 	mov	dph,r7
      00B015 E0               [24] 1134 	movx	a,@dptr
      00B016 F9               [12] 1135 	mov	r1,a
      00B017 90 0D 52         [24] 1136 	mov	dptr,#_fast_set_leds_args_10000_282
      00B01A 74 01            [12] 1137 	mov	a,#0x01
      00B01C 28               [12] 1138 	add	a, r0
      00B01D F0               [24] 1139 	movx	@dptr,a
      00B01E E4               [12] 1140 	clr	a
      00B01F 3F               [12] 1141 	addc	a, r7
      00B020 A3               [24] 1142 	inc	dptr
      00B021 F0               [24] 1143 	movx	@dptr,a
      00B022 85 49 82         [24] 1144 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B025 85 4A 83         [24] 1145 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B028 E9               [12] 1146 	mov	a,r1
      00B029 F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B02A 12 B2 84         [24] 1149 	lcall	_ak820_outline_0075
      00B02D F5 49            [12] 1150 	mov	_fast_set_leds_sloc0_1_0,a
      00B02F 12 B2 92         [24] 1151 	lcall	_ak820_outline_0097
                                   1152 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B032 74 02            [12] 1153 	mov	a,#0x02
      00B034 2A               [12] 1154 	add	a, r2
      00B035 F5 4B            [12] 1155 	mov	_fast_set_leds_sloc1_1_0,a
      00B037 E4               [12] 1156 	clr	a
      00B038 3B               [12] 1157 	addc	a, r3
      00B039 F5 4C            [12] 1158 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B03B C3               [12] 1159 	clr	c
      00B03C 74 A0            [12] 1160 	mov	a,#0xa0
      00B03E 95 49            [12] 1161 	subb	a,_fast_set_leds_sloc0_1_0
      00B040 D0 07            [24] 1162 	pop	ar7
      00B042 50 04            [24] 1163 	jnc	00114$
                                   1164 ;	free result
      00B044 7B A0            [12] 1165 	mov	r3,#0xa0
      00B046 80 04            [24] 1166 	sjmp	00115$
      00B048                       1167 00114$:
      00B048 AA 49            [24] 1168 	mov	r2,_fast_set_leds_sloc0_1_0
      00B04A 8A 03            [24] 1169 	mov	ar3,r2
      00B04C                       1170 00115$:
      00B04C 85 4B 82         [24] 1171 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B04F 85 4C 83         [24] 1172 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B052 EB               [12] 1173 	mov	a,r3
      00B053 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B054 0C               [12] 1176 	inc	r4
                                   1177 ;	quantum/vialrgb.c:133: }
      00B055 02 AF B8         [24] 1178 	ljmp	00110$
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1183 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1184 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1185 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1186 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1187 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1188 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1189 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function vialrgb_get_value
                                   1194 ;	-----------------------------------------
      00B058                       1195 _vialrgb_get_value:
      00B058 12 42 D2         [24] 1196 	lcall	_ak820_outline_0034
      00B05B 90 0D 58         [24] 1197 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B05E 12 37 E1         [24] 1198 	lcall	_ak820_outline_0015
                                   1199 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B061 90 0D 57         [24] 1200 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B064 E0               [24] 1201 	movx	a,@dptr
      00B065 FF               [12] 1202 	mov	r7,a
      00B066 BF 20 02         [24] 1203 	cjne	r7,#0x20,00162$
      00B069 80 01            [24] 1204 	sjmp	00102$
      00B06B                       1205 00162$:
      00B06B 22               [24] 1206 	ret
      00B06C                       1207 00102$:
                                   1208 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B06C 90 0D 58         [24] 1209 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B06F 12 B2 5E         [24] 1210 	lcall	_ak820_outline_0040
                                   1211 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1212 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B072 BA 40 02         [24] 1213 	cjne	r2,#0x40,00163$
      00B075 80 18            [24] 1214 	sjmp	00103$
      00B077                       1215 00163$:
      00B077 BA 41 02         [24] 1216 	cjne	r2,#0x41,00164$
      00B07A 80 26            [24] 1217 	sjmp	00104$
      00B07C                       1218 00164$:
      00B07C BA 42 03         [24] 1219 	cjne	r2,#0x42,00165$
      00B07F 02 B1 34         [24] 1220 	ljmp	00105$
      00B082                       1221 00165$:
      00B082 BA 43 03         [24] 1222 	cjne	r2,#0x43,00166$
      00B085 02 B1 41         [24] 1223 	ljmp	00106$
      00B088                       1224 00166$:
      00B088 BA 44 03         [24] 1225 	cjne	r2,#0x44,00167$
      00B08B 02 B1 4D         [24] 1226 	ljmp	00107$
      00B08E                       1227 00167$:
      00B08E 22               [24] 1228 	ret
                                   1229 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B08F                       1230 00103$:
                                   1231 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B08F 12 33 FC         [24] 1232 	lcall	_ak820_outline_0113
      00B092 74 01            [12] 1233 	mov	a,#0x01
      00B094 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B095 12 B2 56         [24] 1236 	lcall	_ak820_outline_0032
      00B098 E4               [12] 1237 	clr	a
      00B099 F0               [24] 1238 	movx	@dptr,a
                                   1239 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B09A 12 B2 56         [24] 1240 	lcall	_ak820_outline_0032
      00B09D A3               [24] 1241 	inc	dptr
      00B09E 74 A0            [12] 1242 	mov	a,#0xa0
      00B0A0 F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	quantum/vialrgb.c:147: break;
      00B0A1 22               [24] 1245 	ret
                                   1246 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B0A2                       1247 00104$:
                                   1248 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B0A2 C0 06            [24] 1249 	push	ar6
      00B0A4 C0 05            [24] 1250 	push	ar5
      00B0A6 C0 04            [24] 1251 	push	ar4
      00B0A8 C0 03            [24] 1252 	push	ar3
      00B0AA 12 AE A0         [24] 1253 	lcall	_get_mode
      00B0AD A9 82            [24] 1254 	mov	r1, dpl
      00B0AF AA 83            [24] 1255 	mov	r2, dph
      00B0B1 D0 03            [24] 1256 	pop	ar3
      00B0B3 D0 04            [24] 1257 	pop	ar4
      00B0B5 D0 05            [24] 1258 	pop	ar5
      00B0B7 D0 06            [24] 1259 	pop	ar6
                                   1260 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B0B9 89 00            [24] 1261 	mov	ar0,r1
      00B0BB 12 33 FC         [24] 1262 	lcall	_ak820_outline_0113
      00B0BE E8               [12] 1263 	mov	a,r0
      00B0BF F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B0C0 12 B2 56         [24] 1266 	lcall	_ak820_outline_0032
      00B0C3 8A 01            [24] 1267 	mov	ar1,r2
      00B0C5 E9               [12] 1268 	mov	a,r1
      00B0C6 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B0C7 74 04            [12] 1271 	mov	a,#0x04
      00B0C9 12 8B 51         [24] 1272 	lcall	_ak820_outline_0124
      00B0CC C0 06            [24] 1273 	push	ar6
      00B0CE C0 05            [24] 1274 	push	ar5
      00B0D0 C0 02            [24] 1275 	push	ar2
      00B0D2 C0 01            [24] 1276 	push	ar1
      00B0D4 12 53 66         [24] 1277 	lcall	_rgb_matrix_get_speed
      00B0D7 A8 82            [24] 1278 	mov	r0, dpl
      00B0D9 D0 01            [24] 1279 	pop	ar1
      00B0DB D0 02            [24] 1280 	pop	ar2
      00B0DD D0 05            [24] 1281 	pop	ar5
      00B0DF D0 06            [24] 1282 	pop	ar6
      00B0E1 12 7D 9F         [24] 1283 	lcall	_ak820_outline_0060
                                   1284 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B0E4 74 05            [12] 1285 	mov	a,#0x05
      00B0E6 12 8B 51         [24] 1286 	lcall	_ak820_outline_0124
      00B0E9 C0 06            [24] 1287 	push	ar6
      00B0EB C0 05            [24] 1288 	push	ar5
      00B0ED C0 02            [24] 1289 	push	ar2
      00B0EF C0 01            [24] 1290 	push	ar1
      00B0F1 12 53 51         [24] 1291 	lcall	_rgb_matrix_get_hue
      00B0F4 A8 82            [24] 1292 	mov	r0, dpl
      00B0F6 D0 01            [24] 1293 	pop	ar1
      00B0F8 D0 02            [24] 1294 	pop	ar2
      00B0FA D0 05            [24] 1295 	pop	ar5
      00B0FC D0 06            [24] 1296 	pop	ar6
      00B0FE 12 7D 9F         [24] 1297 	lcall	_ak820_outline_0060
                                   1298 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B101 74 06            [12] 1299 	mov	a,#0x06
      00B103 12 8B 51         [24] 1300 	lcall	_ak820_outline_0124
      00B106 C0 06            [24] 1301 	push	ar6
      00B108 C0 05            [24] 1302 	push	ar5
      00B10A C0 02            [24] 1303 	push	ar2
      00B10C C0 01            [24] 1304 	push	ar1
      00B10E 12 53 58         [24] 1305 	lcall	_rgb_matrix_get_sat
      00B111 A8 82            [24] 1306 	mov	r0, dpl
      00B113 D0 01            [24] 1307 	pop	ar1
      00B115 D0 02            [24] 1308 	pop	ar2
      00B117 D0 05            [24] 1309 	pop	ar5
      00B119 D0 06            [24] 1310 	pop	ar6
      00B11B 12 7D 9F         [24] 1311 	lcall	_ak820_outline_0060
                                   1312 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B11E 74 07            [12] 1313 	mov	a,#0x07
      00B120 12 8B 51         [24] 1314 	lcall	_ak820_outline_0124
      00B123 C0 02            [24] 1315 	push	ar2
      00B125 C0 01            [24] 1316 	push	ar1
      00B127 12 53 5F         [24] 1317 	lcall	_rgb_matrix_get_val
      00B12A A8 82            [24] 1318 	mov	r0, dpl
      00B12C D0 01            [24] 1319 	pop	ar1
      00B12E D0 02            [24] 1320 	pop	ar2
      00B130 12 7D 9F         [24] 1321 	lcall	_ak820_outline_0060
                                   1322 ;	quantum/vialrgb.c:156: break;
      00B133 22               [24] 1323 	ret
                                   1324 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B134                       1325 00105$:
                                   1326 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B134 EF               [12] 1327 	mov	a,r7
      00B135 24 FE            [12] 1328 	add	a,#0xfe
      00B137 90 0D 44         [24] 1329 	mov	dptr,#_get_supported_PARM_2
      00B13A F0               [24] 1330 	movx	@dptr,a
      00B13B 12 33 FC         [24] 1331 	lcall	_ak820_outline_0113
                                   1332 ;	quantum/vialrgb.c:160: break;
      00B13E 02 AD A9         [24] 1333 	ljmp	_get_supported
                                   1334 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B141                       1335 00106$:
                                   1336 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B141 12 33 FC         [24] 1337 	lcall	_ak820_outline_0113
      00B144 74 52            [12] 1338 	mov	a,#0x52
      00B146 F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B147 12 B2 56         [24] 1341 	lcall	_ak820_outline_0032
      00B14A E4               [12] 1342 	clr	a
      00B14B F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vialrgb.c:166: break;
      00B14C 22               [24] 1345 	ret
                                   1346 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B14D                       1347 00107$:
                                   1348 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B14D 12 33 FC         [24] 1349 	lcall	_ak820_outline_0113
      00B150 E0               [24] 1350 	movx	a,@dptr
      00B151 FF               [12] 1351 	mov	r7,a
      00B152 7A 00            [12] 1352 	mov	r2,#0x00
      00B154 74 03            [12] 1353 	mov	a,#0x03
      00B156 2D               [12] 1354 	add	a, r5
      00B157 F8               [12] 1355 	mov	r0,a
      00B158 E4               [12] 1356 	clr	a
      00B159 3E               [12] 1357 	addc	a, r6
      00B15A F9               [12] 1358 	mov	r1,a
      00B15B C0 03            [24] 1359 	push	ar3
      00B15D C0 04            [24] 1360 	push	ar4
      00B15F 12 38 6E         [24] 1361 	lcall	_ak820_outline_0144
      00B162 E0               [24] 1362 	movx	a,@dptr
      00B163 FB               [12] 1363 	mov	r3,a
      00B164 E4               [12] 1364 	clr	a
      00B165 4F               [12] 1365 	orl	a,r7
      00B166 F5 4D            [12] 1366 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B168 EB               [12] 1367 	mov	a,r3
      00B169 4A               [12] 1368 	orl	a,r2
      00B16A F5 4E            [12] 1369 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1370 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B16C AC 4D            [24] 1371 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B16E AF 4E            [24] 1372 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B170 C3               [12] 1373 	clr	c
      00B171 EC               [12] 1374 	mov	a,r4
      00B172 94 52            [12] 1375 	subb	a,#0x52
      00B174 EF               [12] 1376 	mov	a,r7
      00B175 94 00            [12] 1377 	subb	a,#0x00
      00B177 D0 04            [24] 1378 	pop	ar4
      00B179 D0 03            [24] 1379 	pop	ar3
      00B17B 40 01            [24] 1380 	jc	00109$
      00B17D 22               [24] 1381 	ret
      00B17E                       1382 00109$:
                                   1383 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B17E E5 4D            [12] 1384 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B180 25 4D            [12] 1385 	add	a,_vialrgb_get_value_sloc0_1_0
      00B182 FA               [12] 1386 	mov	r2,a
      00B183 E5 4E            [12] 1387 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B185 33               [12] 1388 	rlc	a
      00B186 FF               [12] 1389 	mov	r7,a
      00B187 EA               [12] 1390 	mov	a,r2
      00B188 24 14            [12] 1391 	add	a, #_ak820_led_points
      00B18A F5 4F            [12] 1392 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B18C EF               [12] 1393 	mov	a,r7
      00B18D 34 B7            [12] 1394 	addc	a, #(_ak820_led_points >> 8)
      00B18F F5 50            [12] 1395 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B191 85 4F 82         [24] 1396 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B194 85 50 83         [24] 1397 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B197 E4               [12] 1398 	clr	a
      00B198 93               [24] 1399 	movc	a,@a+dptr
      00B199 12 33 FC         [24] 1400 	lcall	_ak820_outline_0113
      00B19C F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B19D 85 4F 82         [24] 1403 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B1A0 85 50 83         [24] 1404 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B1A3 A3               [24] 1405 	inc	dptr
      00B1A4 E4               [12] 1406 	clr	a
      00B1A5 93               [24] 1407 	movc	a,@a+dptr
      00B1A6 12 38 6E         [24] 1408 	lcall	_ak820_outline_0144
      00B1A9 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B1AA 12 B2 56         [24] 1411 	lcall	_ak820_outline_0032
      00B1AD A3               [24] 1412 	inc	dptr
      00B1AE 74 04            [12] 1413 	mov	a,#0x04
      00B1B0 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B1B1 90 0D 4D         [24] 1416 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B1B4 04               [12] 1417 	inc	a
      00B1B5 2D               [12] 1418 	add	a, r5
      00B1B6 F0               [24] 1419 	movx	@dptr,a
      00B1B7 E4               [12] 1420 	clr	a
      00B1B8 3E               [12] 1421 	addc	a, r6
      00B1B9 A3               [24] 1422 	inc	dptr
      00B1BA F0               [24] 1423 	movx	@dptr,a
      00B1BB 85 4D 82         [24] 1424 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B1BE 85 4E 83         [24] 1425 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1426 ;	quantum/vialrgb.c:187: }
                                   1427 ;	quantum/vialrgb.c:188: }
      00B1C1 02 AE E3         [24] 1428 	ljmp	_get_matrix_pos_for_led
                                   1429 ;------------------------------------------------------------
                                   1430 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1431 ;------------------------------------------------------------
                                   1432 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1433 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1434 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1435 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1436 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1437 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1438 ;------------------------------------------------------------
                                   1439 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1440 ;	-----------------------------------------
                                   1441 ;	 function vialrgb_set_value
                                   1442 ;	-----------------------------------------
      00B1C4                       1443 _vialrgb_set_value:
      00B1C4 12 42 D2         [24] 1444 	lcall	_ak820_outline_0034
      00B1C7 90 0D 5C         [24] 1445 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B1CA 12 37 E1         [24] 1446 	lcall	_ak820_outline_0015
                                   1447 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B1CD 90 0D 5B         [24] 1448 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B1D0 E0               [24] 1449 	movx	a,@dptr
      00B1D1 FF               [12] 1450 	mov	r7,a
      00B1D2 BF 20 02         [24] 1451 	cjne	r7,#0x20,00129$
      00B1D5 80 01            [24] 1452 	sjmp	00102$
      00B1D7                       1453 00129$:
      00B1D7 22               [24] 1454 	ret
      00B1D8                       1455 00102$:
                                   1456 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B1D8 90 0D 5C         [24] 1457 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B1DB 12 B2 5E         [24] 1458 	lcall	_ak820_outline_0040
                                   1459 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1460 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B1DE BA 41 02         [24] 1461 	cjne	r2,#0x41,00130$
      00B1E1 80 06            [24] 1462 	sjmp	00103$
      00B1E3                       1463 00130$:
      00B1E3 BA 42 02         [24] 1464 	cjne	r2,#0x42,00131$
      00B1E6 80 5E            [24] 1465 	sjmp	00104$
      00B1E8                       1466 00131$:
      00B1E8 22               [24] 1467 	ret
                                   1468 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B1E9                       1469 00103$:
                                   1470 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B1E9 12 33 FC         [24] 1471 	lcall	_ak820_outline_0113
      00B1EC E0               [24] 1472 	movx	a,@dptr
      00B1ED FA               [12] 1473 	mov	r2,a
      00B1EE 12 B2 56         [24] 1474 	lcall	_ak820_outline_0032
      00B1F1 E0               [24] 1475 	movx	a,@dptr
      00B1F2 F8               [12] 1476 	mov	r0,a
      00B1F3 79 00            [12] 1477 	mov	r1,#0x00
      00B1F5 88 52            [24] 1478 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B1F7 89 51            [24] 1479 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B1F9 8A 01            [24] 1480 	mov	ar1,r2
      00B1FB 7A 00            [12] 1481 	mov	r2,#0x00
      00B1FD E5 52            [12] 1482 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B1FF 42 02            [12] 1483 	orl	ar2,a
                                   1484 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B201 12 43 4B         [24] 1485 	lcall	_ak820_outline_0170
      00B204 C0 06            [24] 1486 	push	ar6
      00B206 C0 05            [24] 1487 	push	ar5
      00B208 12 AE B5         [24] 1488 	lcall	_set_mode
      00B20B D0 05            [24] 1489 	pop	ar5
      00B20D D0 06            [24] 1490 	pop	ar6
                                   1491 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B20F 12 B2 56         [24] 1492 	lcall	_ak820_outline_0032
      00B212 A3               [24] 1493 	inc	dptr
      00B213 E0               [24] 1494 	movx	a,@dptr
      00B214 F5 82            [12] 1495 	mov	dpl,a
      00B216 C0 06            [24] 1496 	push	ar6
      00B218 C0 05            [24] 1497 	push	ar5
      00B21A 12 54 34         [24] 1498 	lcall	_rgb_matrix_set_speed_noeeprom
      00B21D D0 05            [24] 1499 	pop	ar5
      00B21F D0 06            [24] 1500 	pop	ar6
                                   1501 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B221 12 B2 56         [24] 1502 	lcall	_ak820_outline_0032
      00B224 A3               [24] 1503 	inc	dptr
      00B225 A3               [24] 1504 	inc	dptr
      00B226 E0               [24] 1505 	movx	a,@dptr
      00B227 F9               [12] 1506 	mov	r1,a
      00B228 7A 00            [12] 1507 	mov	r2,#0x00
      00B22A 74 06            [12] 1508 	mov	a,#0x06
      00B22C 12 B2 A8         [24] 1509 	lcall	_ak820_outline_0160
      00B22F F8               [12] 1510 	mov	r0,a
      00B230 74 07            [12] 1511 	mov	a,#0x07
      00B232 12 B2 A8         [24] 1512 	lcall	_ak820_outline_0160
      00B235 FE               [12] 1513 	mov	r6,a
      00B236 90 07 23         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B239 E8               [12] 1515 	mov	a,r0
      00B23A F0               [24] 1516 	movx	@dptr,a
      00B23B 90 07 24         [24] 1517 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B23E EE               [12] 1518 	mov	a,r6
      00B23F F0               [24] 1519 	movx	@dptr,a
      00B240 12 43 4B         [24] 1520 	lcall	_ak820_outline_0170
                                   1521 ;	quantum/vialrgb.c:202: break;
                                   1522 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B243 02 54 05         [24] 1523 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B246                       1524 00104$:
                                   1525 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B246 EF               [12] 1526 	mov	a,r7
      00B247 24 FE            [12] 1527 	add	a,#0xfe
      00B249 90 0D 51         [24] 1528 	mov	dptr,#_fast_set_leds_PARM_2
      00B24C F0               [24] 1529 	movx	@dptr,a
      00B24D 12 33 FC         [24] 1530 	lcall	_ak820_outline_0113
                                   1531 ;	quantum/vialrgb.c:210: }
                                   1532 ;	quantum/vialrgb.c:211: }
      00B250 02 AF 16         [24] 1533 	ljmp	_fast_set_leds
                                   1534 ;------------------------------------------------------------
                                   1535 ;Allocation info for local variables in function 'vialrgb_save'
                                   1536 ;------------------------------------------------------------
                                   1537 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1538 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1539 ;------------------------------------------------------------
                                   1540 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1541 ;	-----------------------------------------
                                   1542 ;	 function vialrgb_save
                                   1543 ;	-----------------------------------------
      00B253                       1544 _vialrgb_save:
                                   1545 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1546 ;	quantum/vialrgb.c:218: }
      00B253 02 4E 7B         [24] 1547 	ljmp	_eeconfig_update_rgb_matrix
                                   1548 	.area CSEG    (CODE)
                                   1549 	.area CONST   (CODE)
                                   1550 	.area CONST   (CODE)
      00BA53                       1551 _supported_modes:
      00BA53 00                    1552 	.db #0x00	; 0
      00BA54 00                    1553 	.db #0x00	; 0
      00BA55 01                    1554 	.db #0x01	; 1
      00BA56 05                    1555 	.db #0x05	; 5
      00BA57 02                    1556 	.db #0x02	; 2
      00BA58 01                    1557 	.db #0x01	; 1
      00BA59 06                    1558 	.db #0x06	; 6
      00BA5A 02                    1559 	.db #0x02	; 2
      00BA5B 0D                    1560 	.db #0x0d	; 13
      00BA5C 03                    1561 	.db #0x03	; 3
      00BA5D 0E                    1562 	.db #0x0e	; 14
      00BA5E 04                    1563 	.db #0x04	; 4
      00BA5F 1F                    1564 	.db #0x1f	; 31
      00BA60 06                    1565 	.db #0x06	; 6
                                   1566 	.area CSEG    (CODE)
                                   1567 	.area XINIT   (CODE)
                                   1568 	.area CABS    (ABS,CODE)
                                   1569 
                                   1570 ; Experimental exact instruction outlining.
                                   1571 	.globl _ak820_outline_0004
                                   1572 	.globl _ak820_outline_0015
                                   1573 	.globl _ak820_outline_0018
                                   1574 	.globl _ak820_outline_0032
                                   1575 	.globl _ak820_outline_0033
                                   1576 	.globl _ak820_outline_0034
                                   1577 	.globl _ak820_outline_0040
                                   1578 	.globl _ak820_outline_0042
                                   1579 	.globl _ak820_outline_0047
                                   1580 	.globl _ak820_outline_0053
                                   1581 	.globl _ak820_outline_0060
                                   1582 	.globl _ak820_outline_0071
                                   1583 	.globl _ak820_outline_0075
                                   1584 	.globl _ak820_outline_0094
                                   1585 	.globl _ak820_outline_0097
                                   1586 	.globl _ak820_outline_0098
                                   1587 	.globl _ak820_outline_0099
                                   1588 	.globl _ak820_outline_0100
                                   1589 	.globl _ak820_outline_0101
                                   1590 	.globl _ak820_outline_0109
                                   1591 	.globl _ak820_outline_0111
                                   1592 	.globl _ak820_outline_0112
                                   1593 	.globl _ak820_outline_0113
                                   1594 	.globl _ak820_outline_0122
                                   1595 	.globl _ak820_outline_0124
                                   1596 	.globl _ak820_outline_0131
                                   1597 	.globl _ak820_outline_0133
                                   1598 	.globl _ak820_outline_0144
                                   1599 	.globl _ak820_outline_0149
                                   1600 	.globl _ak820_outline_0160
                                   1601 	.globl _ak820_outline_0170
                                   1602 	.globl _ak820_outline_0174
                                   1603 
                                   1604 	.area CSEG (CODE)
                                   1605 ; function ak820_outline_0032
      00B256                       1606 _ak820_outline_0032:
      00B256 8D 82            [24] 1607 	mov	dpl,r5
      00B258 8E 83            [24] 1608 	mov	dph,r6
      00B25A A3               [24] 1609 	inc	dptr
      00B25B A3               [24] 1610 	inc	dptr
      00B25C A3               [24] 1611 	inc	dptr
      00B25D 22               [24] 1612 	ret
                                   1613 
                                   1614 	.area CSEG (CODE)
                                   1615 ; function ak820_outline_0040
      00B25E                       1616 _ak820_outline_0040:
      00B25E E0               [24] 1617 	movx	a,@dptr
      00B25F FD               [12] 1618 	mov	r5,a
      00B260 A3               [24] 1619 	inc	dptr
      00B261 E0               [24] 1620 	movx	a,@dptr
      00B262 FE               [12] 1621 	mov	r6,a
      00B263 74 02            [12] 1622 	mov	a,#0x02
      00B265 2D               [12] 1623 	add	a,r5
      00B266 FB               [12] 1624 	mov	r3,a
      00B267 E4               [12] 1625 	clr	a
      00B268 3E               [12] 1626 	addc	a,r6
      00B269 FC               [12] 1627 	mov	r4,a
      00B26A 8D 82            [24] 1628 	mov	dpl,r5
      00B26C 8E 83            [24] 1629 	mov	dph,r6
      00B26E A3               [24] 1630 	inc	dptr
      00B26F E0               [24] 1631 	movx	a,@dptr
      00B270 FA               [12] 1632 	mov	r2,a
      00B271 22               [24] 1633 	ret
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0042
      00B272                       1637 _ak820_outline_0042:
      00B272 ED               [12] 1638 	mov	a,r5
      00B273 75 F0 02         [24] 1639 	mov	b,#0x02
      00B276 A4               [48] 1640 	mul	ab
      00B277 24 53            [12] 1641 	add	a,#_supported_modes
      00B279 FB               [12] 1642 	mov	r3,a
      00B27A 74 BA            [12] 1643 	mov	a,#(_supported_modes>>8)
      00B27C 35 F0            [12] 1644 	addc	a,b
      00B27E FC               [12] 1645 	mov	r4,a
      00B27F 8B 82            [24] 1646 	mov	dpl,r3
      00B281 8C 83            [24] 1647 	mov	dph,r4
      00B283 22               [24] 1648 	ret
                                   1649 
                                   1650 	.area CSEG (CODE)
                                   1651 ; function ak820_outline_0075
      00B284                       1652 _ak820_outline_0075:
      00B284 90 0D 52         [24] 1653 	mov	dptr,#_fast_set_leds_args_10000_282
      00B287 E0               [24] 1654 	movx	a,@dptr
      00B288 F9               [12] 1655 	mov	r1,a
      00B289 A3               [24] 1656 	inc	dptr
      00B28A E0               [24] 1657 	movx	a,@dptr
      00B28B FF               [12] 1658 	mov	r7,a
      00B28C 89 82            [24] 1659 	mov	dpl,r1
      00B28E 8F 83            [24] 1660 	mov	dph,r7
      00B290 E0               [24] 1661 	movx	a,@dptr
      00B291 22               [24] 1662 	ret
                                   1663 
                                   1664 	.area CSEG (CODE)
                                   1665 ; function ak820_outline_0097
      00B292                       1666 _ak820_outline_0097:
      00B292 90 0D 52         [24] 1667 	mov	dptr,#_fast_set_leds_args_10000_282
      00B295 74 01            [12] 1668 	mov	a,#0x01
      00B297 29               [12] 1669 	add	a,r1
      00B298 F0               [24] 1670 	movx	@dptr,a
      00B299 E4               [12] 1671 	clr	a
      00B29A 3F               [12] 1672 	addc	a,r7
      00B29B A3               [24] 1673 	inc	dptr
      00B29C F0               [24] 1674 	movx	@dptr,a
      00B29D 22               [24] 1675 	ret
                                   1676 
                                   1677 	.area CSEG (CODE)
                                   1678 ; function ak820_outline_0133
      00B29E                       1679 _ak820_outline_0133:
      00B29E E4               [12] 1680 	clr	a
      00B29F 93               [24] 1681 	movc	a,@a+dptr
      00B2A0 FC               [12] 1682 	mov	r4,a
      00B2A1 7B 00            [12] 1683 	mov	r3,#0x00
      00B2A3 8C 82            [24] 1684 	mov	dpl,r4
      00B2A5 8B 83            [24] 1685 	mov	dph,r3
      00B2A7 22               [24] 1686 	ret
                                   1687 
                                   1688 	.area CSEG (CODE)
                                   1689 ; function ak820_outline_0160
      00B2A8                       1690 _ak820_outline_0160:
      00B2A8 2D               [12] 1691 	add	a,r5
      00B2A9 F5 82            [12] 1692 	mov	dpl,a
      00B2AB E4               [12] 1693 	clr	a
      00B2AC 3E               [12] 1694 	addc	a,r6
      00B2AD F5 83            [12] 1695 	mov	dph,a
      00B2AF E0               [24] 1696 	movx	a,@dptr
      00B2B0 22               [24] 1697 	ret
