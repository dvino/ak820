                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _ak820_combo_valid_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _ak820_combo_process_sloc0_1_0:
      000001                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000422                        551 _combos:
      000422                        552 	.ds 32
      000442                        553 _saved:
      000442                        554 	.ds 9
      00044B                        555 _active:
      00044B                        556 	.ds 1
      00044C                        557 _ak820_combo_valid_entry_10000_592:
      00044C                        558 	.ds 2
      00044E                        559 _ak820_combo_reload_entry_30000_604:
      00044E                        560 	.ds 10
      000458                        561 _ak820_combo_tick_now_10000_609:
      000458                        562 	.ds 2
      00045A                        563 _ak820_combo_process_record_10000_612:
      00045A                        564 	.ds 2
      00045C                        565 _ak820_combo_process_eligible_10001_627:
      00045C                        566 	.ds 1
      00045D                        567 _ak820_combo_process_i_40001_630:
      00045D                        568 	.ds 1
      00045E                        569 _ak820_combo_process_a_50001_631:
      00045E                        570 	.ds 1
      00045F                        571 _ak820_combo_process_b_50001_631:
      00045F                        572 	.ds 1
                                    573 ;--------------------------------------------------------
                                    574 ; absolute external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area XABS    (ABS,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; initialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XISEG   (XDATA)
      000D70                        581 _first:
      000D70                        582 	.ds 1
      000D71                        583 _second:
      000D71                        584 	.ds 1
                                    585 	.area HOME    (CODE)
                                    586 	.area GSINIT0 (CODE)
                                    587 	.area GSINIT1 (CODE)
                                    588 	.area GSINIT2 (CODE)
                                    589 	.area GSINIT3 (CODE)
                                    590 	.area GSINIT4 (CODE)
                                    591 	.area GSINIT5 (CODE)
                                    592 	.area GSINIT  (CODE)
                                    593 	.area GSFINAL (CODE)
                                    594 	.area CSEG    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; global & static initialisations
                                    597 ;--------------------------------------------------------
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; Home
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area HOME    (CODE)
                                    607 ;--------------------------------------------------------
                                    608 ; code
                                    609 ;--------------------------------------------------------
                                    610 	.area CSEG    (CODE)
                                    611 ;------------------------------------------------------------
                                    612 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    613 ;------------------------------------------------------------
                                    614 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    615 ;------------------------------------------------------------
                                    616 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    617 ;	-----------------------------------------
                           000007   618 	ar7 = 0x07
                           000006   619 	ar6 = 0x06
                           000005   620 	ar5 = 0x05
                           000004   621 	ar4 = 0x04
                           000003   622 	ar3 = 0x03
                           000002   623 	ar2 = 0x02
                           000001   624 	ar1 = 0x01
                           000000   625 	ar0 = 0x00
                                    626 ;	 function ak820_combo_valid
                                    627 ;	-----------------------------------------
      003468                        628 _ak820_combo_valid:
      003468 12 38 3C         [24]  629 	lcall	_ak820_outline_0098
      00346B 90 04 4C         [24]  630 	mov	dptr,#_ak820_combo_valid_entry_10000_592
      00346E 12 38 41         [24]  631 	lcall	_ak820_outline_0099
                                    632 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (entry->input[2] || entry->input[3]) return false;
      003471 90 04 4C         [24]  633 	mov	dptr,#_ak820_combo_valid_entry_10000_592
      003474 12 37 A2         [24]  634 	lcall	_ak820_outline_0004
      003477 A3               [24]  635 	inc	dptr
      003478 A3               [24]  636 	inc	dptr
      003479 A3               [24]  637 	inc	dptr
      00347A A3               [24]  638 	inc	dptr
      00347B 12 38 68         [24]  639 	lcall	_ak820_outline_0129
      00347E 70 0A            [24]  640 	jnz	00101$
      003480 74 06            [12]  641 	mov	a,#0x06
      003482 12 37 E9         [24]  642 	lcall	_ak820_outline_0018
      003485 12 38 68         [24]  643 	lcall	_ak820_outline_0129
      003488 60 04            [24]  644 	jz	00102$
      00348A                        645 00101$:
      00348A 75 82 00         [24]  646 	mov	dpl, #0x00
      00348D 22               [24]  647 	ret
      00348E                        648 00102$:
                                    649 ;	keyboards/ajazz/ak820/ak820_combo.c:25: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      00348E 8E 04            [24]  650 	mov	ar4,r6
      003490 8F 05            [24]  651 	mov	ar5,r7
      003492 12 37 F1         [24]  652 	lcall	_ak820_outline_0031
      003495 FA               [12]  653 	mov	r2,a
      003496 A3               [24]  654 	inc	dptr
      003497 E0               [24]  655 	movx	a,@dptr
      003498 FB               [12]  656 	mov	r3,a
      003499 12 38 4D         [24]  657 	lcall	_ak820_outline_0110
      00349C 12 38 18         [24]  658 	lcall	_ak820_outline_0057
      00349F EA               [12]  659 	mov	a,r2
      0034A0 4C               [12]  660 	orl	a,r4
      0034A1 F8               [12]  661 	mov	r0,a
      0034A2 EB               [12]  662 	mov	a,r3
      0034A3 4D               [12]  663 	orl	a,r5
      0034A4 48               [12]  664 	orl	a,r0
      0034A5 70 13            [24]  665 	jnz	00105$
      0034A7 74 08            [12]  666 	mov	a,#0x08
      0034A9 12 37 E9         [24]  667 	lcall	_ak820_outline_0018
      0034AC E0               [24]  668 	movx	a,@dptr
      0034AD F8               [12]  669 	mov	r0,a
      0034AE A3               [24]  670 	inc	dptr
      0034AF E0               [24]  671 	movx	a,@dptr
      0034B0 48               [12]  672 	orl	a,r0
      0034B1 B4 01 00         [24]  673 	cjne	a,#0x01,00187$
      0034B4                        674 00187$:
      0034B4 92 00            [24]  675 	mov  _ak820_combo_valid_sloc0_1_0,c
      0034B6 12 38 79         [24]  676 	lcall	_ak820_outline_0158
      0034B9 22               [24]  677 	ret
      0034BA                        678 00105$:
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[0] == entry->input[1]) return false;
      0034BA EC               [12]  680 	mov	a,r4
      0034BB B5 02 08         [24]  681 	cjne	a,ar2,00107$
      0034BE ED               [12]  682 	mov	a,r5
      0034BF B5 03 04         [24]  683 	cjne	a,ar3,00107$
      0034C2 75 82 00         [24]  684 	mov	dpl, #0x00
      0034C5 22               [24]  685 	ret
      0034C6                        686 00107$:
                                    687 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!COMBO_INPUT(entry->input[0])) return false;
      0034C6 C3               [12]  688 	clr	c
      0034C7 EC               [12]  689 	mov	a,r4
      0034C8 94 04            [12]  690 	subb	a,#0x04
      0034CA ED               [12]  691 	mov	a,r5
      0034CB 94 00            [12]  692 	subb	a,#0x00
      0034CD 40 07            [24]  693 	jc	00108$
      0034CF 74 A4            [12]  694 	mov	a,#0xa4
      0034D1 9C               [12]  695 	subb	a,r4
      0034D2 E4               [12]  696 	clr	a
      0034D3 9D               [12]  697 	subb	a,r5
      0034D4 50 04            [24]  698 	jnc	00109$
                                    699 ;	free result
      0034D6                        700 00108$:
      0034D6 75 82 00         [24]  701 	mov	dpl, #0x00
      0034D9 22               [24]  702 	ret
      0034DA                        703 00109$:
                                    704 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (!COMBO_INPUT(entry->input[1])) return false;
      0034DA C3               [12]  705 	clr	c
      0034DB EA               [12]  706 	mov	a,r2
      0034DC 94 04            [12]  707 	subb	a,#0x04
      0034DE EB               [12]  708 	mov	a,r3
      0034DF 94 00            [12]  709 	subb	a,#0x00
      0034E1 40 07            [24]  710 	jc	00111$
      0034E3 74 A4            [12]  711 	mov	a,#0xa4
      0034E5 9A               [12]  712 	subb	a,r2
      0034E6 E4               [12]  713 	clr	a
      0034E7 9B               [12]  714 	subb	a,r3
      0034E8 50 04            [24]  715 	jnc	00112$
                                    716 ;	free result
      0034EA                        717 00111$:
      0034EA 75 82 00         [24]  718 	mov	dpl, #0x00
      0034ED 22               [24]  719 	ret
      0034EE                        720 00112$:
                                    721 ;	keyboards/ajazz/ak820/ak820_combo.c:29: return COMBO_OUTPUT(entry->output);
      0034EE 74 08            [12]  722 	mov	a,#0x08
      0034F0 12 37 E9         [24]  723 	lcall	_ak820_outline_0018
      0034F3 12 37 C0         [24]  724 	lcall	_ak820_outline_0007
      0034F6 74 E0            [12]  725 	mov	a,#0x100 - 0x20
      0034F8 2D               [12]  726 	add	a,r5
      0034F9 40 21            [24]  727 	jc	00116$
      0034FB BE 04 00         [24]  728 	cjne	r6,#0x04,00195$
      0034FE                        729 00195$:
      0034FE 40 05            [24]  730 	jc	00124$
      003500 EE               [12]  731 	mov	a,r6
      003501 24 5B            [12]  732 	add	a,#0xff - 0xa4
      003503 50 1B            [24]  733 	jnc	00117$
                                    734 ;	free result
      003505                        735 00124$:
      003505 90 04 4C         [24]  736 	mov	dptr,#_ak820_combo_valid_entry_10000_592
      003508 12 37 F9         [24]  737 	lcall	_ak820_outline_0047
      00350B 74 08            [12]  738 	mov	a,#0x08
      00350D 12 37 E9         [24]  739 	lcall	_ak820_outline_0018
      003510 E0               [24]  740 	movx	a,@dptr
      003511 FF               [12]  741 	mov	r7,a
      003512 BF E0 00         [24]  742 	cjne	r7,#0xe0,00198$
      003515                        743 00198$:
      003515 40 05            [24]  744 	jc	00116$
      003517 EF               [12]  745 	mov	a,r7
      003518 24 18            [12]  746 	add	a,#0xff - 0xe7
      00351A 50 04            [24]  747 	jnc	00117$
                                    748 ;	free result
      00351C                        749 00116$:
                                    750 ;	assignBit
      00351C C2 00            [12]  751 	clr	_ak820_combo_valid_sloc0_1_0
      00351E 80 02            [24]  752 	sjmp	00118$
      003520                        753 00117$:
                                    754 ;	assignBit
      003520 D2 00            [12]  755 	setb	_ak820_combo_valid_sloc0_1_0
      003522                        756 00118$:
      003522 A2 00            [12]  757 	mov	c,_ak820_combo_valid_sloc0_1_0
      003524 12 38 79         [24]  758 	lcall	_ak820_outline_0158
                                    759 ;	keyboards/ajazz/ak820/ak820_combo.c:30: }
      003527 22               [24]  760 	ret
                                    761 ;------------------------------------------------------------
                                    762 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    763 ;------------------------------------------------------------
                                    764 ;	keyboards/ajazz/ak820/ak820_combo.c:33: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    765 ;	-----------------------------------------
                                    766 ;	 function ak820_combo_cancel
                                    767 ;	-----------------------------------------
      003528                        768 _ak820_combo_cancel:
      003528 90 0D 71         [24]  769 	mov	dptr,#_second
      00352B 74 FF            [12]  770 	mov	a,#0xff
      00352D F0               [24]  771 	movx	@dptr,a
      00352E 90 0D 70         [24]  772 	mov	dptr,#_first
      003531 F0               [24]  773 	movx	@dptr,a
      003532 90 04 4B         [24]  774 	mov	dptr,#_active
      003535 E4               [12]  775 	clr	a
      003536 F0               [24]  776 	movx	@dptr,a
      003537 22               [24]  777 	ret
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    780 ;------------------------------------------------------------
                                    781 ;i             Allocated with name '_ak820_combo_reload_i_20000_603'
                                    782 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_604'
                                    783 ;------------------------------------------------------------
                                    784 ;	keyboards/ajazz/ak820/ak820_combo.c:34: void ak820_combo_reload(void) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function ak820_combo_reload
                                    787 ;	-----------------------------------------
      003538                        788 _ak820_combo_reload:
                                    789 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003538 7F 00            [12]  790 	mov	r7,#0x00
      00353A                        791 00105$:
      00353A BF 08 00         [24]  792 	cjne	r7,#0x08,00131$
      00353D                        793 00131$:
      00353D 40 01            [24]  794 	jc	00132$
      00353F 22               [24]  795 	ret
      003540                        796 00132$:
                                    797 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].a = 0;
      003540 EF               [12]  798 	mov	a,r7
      003541 75 F0 04         [24]  799 	mov	b,#0x04
      003544 A4               [48]  800 	mul	ab
      003545 24 22            [12]  801 	add	a, #_combos
      003547 FD               [12]  802 	mov	r5,a
      003548 74 04            [12]  803 	mov	a,#(_combos >> 8)
      00354A 35 F0            [12]  804 	addc	a, b
      00354C FE               [12]  805 	mov	r6,a
      00354D 8D 03            [24]  806 	mov	ar3,r5
      00354F 8E 04            [24]  807 	mov	ar4,r6
      003551 12 33 FC         [24]  808 	lcall	_ak820_outline_0113
      003554 E4               [12]  809 	clr	a
      003555 F0               [24]  810 	movx	@dptr,a
                                    811 ;	keyboards/ajazz/ak820/ak820_combo.c:38: if (!dynamic_keymap_get_combo(i, &entry)) {
      003556 90 0A DA         [24]  812 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003559 74 4E            [12]  813 	mov	a,#_ak820_combo_reload_entry_30000_604
      00355B F0               [24]  814 	movx	@dptr,a
      00355C 74 04            [12]  815 	mov	a,#(_ak820_combo_reload_entry_30000_604 >> 8)
      00355E 12 38 1E         [24]  816 	lcall	_ak820_outline_0067
      003561 8F 82            [24]  817 	mov	dpl, r7
      003563 C0 07            [24]  818 	push	ar7
      003565 C0 06            [24]  819 	push	ar6
      003567 C0 05            [24]  820 	push	ar5
      003569 C0 04            [24]  821 	push	ar4
      00356B C0 03            [24]  822 	push	ar3
      00356D 12 82 51         [24]  823 	lcall	_dynamic_keymap_get_combo
      003570 12 38 62         [24]  824 	lcall	_ak820_outline_0126
      003573 D0 03            [24]  825 	pop	ar3
      003575 D0 04            [24]  826 	pop	ar4
      003577 D0 05            [24]  827 	pop	ar5
      003579 D0 06            [24]  828 	pop	ar6
      00357B D0 07            [24]  829 	pop	ar7
      00357D 45 F0            [12]  830 	orl	a,b
      00357F 70 28            [24]  831 	jnz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = entry.input[0];
      003581 90 04 4E         [24]  833 	mov	dptr,#_ak820_combo_reload_entry_30000_604
      003584 E0               [24]  834 	movx	a,@dptr
      003585 12 33 FC         [24]  835 	lcall	_ak820_outline_0113
      003588 F0               [24]  836 	movx	@dptr,a
                                    837 ;	keyboards/ajazz/ak820/ak820_combo.c:40: combos[i].b = entry.input[1];
      003589 74 01            [12]  838 	mov	a,#0x01
      00358B 2D               [12]  839 	add	a, r5
      00358C FB               [12]  840 	mov	r3,a
      00358D E4               [12]  841 	clr	a
      00358E 3E               [12]  842 	addc	a, r6
      00358F FC               [12]  843 	mov	r4,a
      003590 90 04 50         [24]  844 	mov	dptr,#(_ak820_combo_reload_entry_30000_604 + 0x0002)
      003593 E0               [24]  845 	movx	a,@dptr
      003594 12 33 FC         [24]  846 	lcall	_ak820_outline_0113
      003597 F0               [24]  847 	movx	@dptr,a
                                    848 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].output = entry.output;
      003598 74 02            [12]  849 	mov	a,#0x02
      00359A 12 38 73         [24]  850 	lcall	_ak820_outline_0147
      00359D 90 04 56         [24]  851 	mov	dptr,#(_ak820_combo_reload_entry_30000_604 + 0x0008)
      0035A0 12 38 52         [24]  852 	lcall	_ak820_outline_0112
      0035A3 12 38 5D         [24]  853 	lcall	_ak820_outline_0122
      0035A6 12 38 2A         [24]  854 	lcall	_ak820_outline_0071
      0035A9                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035A9 0F               [12]  857 	inc	r7
                                    858 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0035AA 02 35 3A         [24]  859 	ljmp	00105$
                                    860 ;------------------------------------------------------------
                                    861 ;Allocation info for local variables in function 'flush'
                                    862 ;------------------------------------------------------------
                                    863 ;	keyboards/ajazz/ak820/ak820_combo.c:45: static void flush(void) {
                                    864 ;	-----------------------------------------
                                    865 ;	 function flush
                                    866 ;	-----------------------------------------
      0035AD                        867 _flush:
                                    868 ;	keyboards/ajazz/ak820/ak820_combo.c:46: first = NONE;
      0035AD 90 0D 70         [24]  869 	mov	dptr,#_first
      0035B0 74 FF            [12]  870 	mov	a,#0xff
      0035B2 F0               [24]  871 	movx	@dptr,a
                                    872 ;	keyboards/ajazz/ak820/ak820_combo.c:47: process_record(&saved);
      0035B3 90 04 42         [24]  873 	mov	dptr,#_saved
                                    874 ;	keyboards/ajazz/ak820/ak820_combo.c:48: }
      0035B6 02 6E D6         [24]  875 	ljmp	_process_record
                                    876 ;------------------------------------------------------------
                                    877 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    878 ;------------------------------------------------------------
                                    879 ;now           Allocated with name '_ak820_combo_tick_now_10000_609'
                                    880 ;------------------------------------------------------------
                                    881 ;	keyboards/ajazz/ak820/ak820_combo.c:49: void ak820_combo_tick(uint16_t now) {
                                    882 ;	-----------------------------------------
                                    883 ;	 function ak820_combo_tick
                                    884 ;	-----------------------------------------
      0035B9                        885 _ak820_combo_tick:
      0035B9 12 38 3C         [24]  886 	lcall	_ak820_outline_0098
      0035BC 90 04 58         [24]  887 	mov	dptr,#_ak820_combo_tick_now_10000_609
      0035BF 12 38 41         [24]  888 	lcall	_ak820_outline_0099
                                    889 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      0035C2 12 38 7E         [24]  890 	lcall	_ak820_outline_0172
      0035C5 FF               [12]  891 	mov	r7,a
      0035C6 BF FF 01         [24]  892 	cjne	r7,#0xff,00128$
      0035C9 22               [24]  893 	ret
      0035CA                        894 00128$:
      0035CA 90 04 4B         [24]  895 	mov	dptr,#_active
      0035CD E0               [24]  896 	movx	a,@dptr
      0035CE 70 1F            [24]  897 	jnz	00105$
      0035D0 90 04 44         [24]  898 	mov	dptr,#(_saved + 0x0002)
      0035D3 12 37 F9         [24]  899 	lcall	_ak820_outline_0047
      0035D6 90 04 58         [24]  900 	mov	dptr,#_ak820_combo_tick_now_10000_609
      0035D9 12 38 18         [24]  901 	lcall	_ak820_outline_0057
      0035DC EC               [12]  902 	mov	a,r4
      0035DD C3               [12]  903 	clr	c
      0035DE 9E               [12]  904 	subb	a,r6
      0035DF FE               [12]  905 	mov	r6,a
      0035E0 ED               [12]  906 	mov	a,r5
      0035E1 9F               [12]  907 	subb	a,r7
      0035E2 FF               [12]  908 	mov	r7,a
      0035E3 C3               [12]  909 	clr	c
      0035E4 EE               [12]  910 	mov	a,r6
      0035E5 94 28            [12]  911 	subb	a,#0x28
      0035E7 EF               [12]  912 	mov	a,r7
      0035E8 94 00            [12]  913 	subb	a,#0x00
      0035EA 40 03            [24]  914 	jc	00105$
                                    915 ;	keyboards/ajazz/ak820/ak820_combo.c:51: }
      0035EC 02 35 AD         [24]  916 	ljmp	_flush
      0035EF                        917 00105$:
      0035EF 22               [24]  918 	ret
                                    919 ;------------------------------------------------------------
                                    920 ;Allocation info for local variables in function 'ak820_combo_process'
                                    921 ;------------------------------------------------------------
                                    922 ;record        Allocated with name '_ak820_combo_process_record_10000_612'
                                    923 ;id            Allocated with name '_ak820_combo_process_id_10000_613'
                                    924 ;code          Allocated with name '_ak820_combo_process_code_10000_613'
                                    925 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_627'
                                    926 ;previous      Allocated with name '_ak820_combo_process_previous_30001_629'
                                    927 ;i             Allocated with name '_ak820_combo_process_i_40001_630'
                                    928 ;a             Allocated with name '_ak820_combo_process_a_50001_631'
                                    929 ;b             Allocated with name '_ak820_combo_process_b_50001_631'
                                    930 ;------------------------------------------------------------
                                    931 ;	keyboards/ajazz/ak820/ak820_combo.c:52: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    932 ;	-----------------------------------------
                                    933 ;	 function ak820_combo_process
                                    934 ;	-----------------------------------------
      0035F0                        935 _ak820_combo_process:
      0035F0 12 38 3C         [24]  936 	lcall	_ak820_outline_0098
      0035F3 90 04 5A         [24]  937 	mov	dptr,#_ak820_combo_process_record_10000_612
      0035F6 12 38 41         [24]  938 	lcall	_ak820_outline_0099
                                    939 ;	keyboards/ajazz/ak820/ak820_combo.c:53: uint8_t id, code = record->keycode;
      0035F9 90 04 5A         [24]  940 	mov	dptr,#_ak820_combo_process_record_10000_612
      0035FC 12 37 AC         [24]  941 	lcall	_ak820_outline_0006
      0035FF 8C 03            [24]  942 	mov	ar3,r4
                                    943 ;	keyboards/ajazz/ak820/ak820_combo.c:54: if (IS_NOEVENT(record->event)) return true;
      003601 74 04            [12]  944 	mov	a,#0x04
      003603 2E               [12]  945 	add	a, r6
      003604 12 37 D7         [24]  946 	lcall	_ak820_outline_0013
      003607 70 04            [24]  947 	jnz	00102$
      003609 75 82 01         [24]  948 	mov	dpl, #0x01
      00360C 22               [24]  949 	ret
      00360D                        950 00102$:
                                    951 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00360D 12 38 46         [24]  952 	lcall	_ak820_outline_0101
      003610 FA               [12]  953 	mov	r2,a
      003611 BA 10 00         [24]  954 	cjne	r2,#0x10,00308$
      003614                        955 00308$:
      003614 50 09            [24]  956 	jnc	00106$
      003616 12 38 30         [24]  957 	lcall	_ak820_outline_0090
      003619 F9               [12]  958 	mov	r1,a
      00361A B9 08 00         [24]  959 	cjne	r1,#0x08,00310$
      00361D                        960 00310$:
      00361D 40 16            [24]  961 	jc	00107$
      00361F                        962 00106$:
                                    963 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (first != NONE && !active) flush();
      00361F 12 38 7E         [24]  964 	lcall	_ak820_outline_0172
      003622 F8               [12]  965 	mov	r0,a
      003623 B8 FF 02         [24]  966 	cjne	r0,#0xff,00312$
      003626 80 09            [24]  967 	sjmp	00104$
      003628                        968 00312$:
      003628 90 04 4B         [24]  969 	mov	dptr,#_active
      00362B E0               [24]  970 	movx	a,@dptr
      00362C 70 03            [24]  971 	jnz	00104$
      00362E 12 35 AD         [24]  972 	lcall	_flush
      003631                        973 00104$:
                                    974 ;	keyboards/ajazz/ak820/ak820_combo.c:58: return true;
      003631 75 82 01         [24]  975 	mov	dpl, #0x01
      003634 22               [24]  976 	ret
      003635                        977 00107$:
                                    978 ;	keyboards/ajazz/ak820/ak820_combo.c:60: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003635 EA               [12]  979 	mov	a,r2
      003636 12 38 83         [24]  980 	lcall	_ak820_outline_0176
      003639 29               [12]  981 	add	a,r1
      00363A FA               [12]  982 	mov	r2,a
                                    983 ;	keyboards/ajazz/ak820/ak820_combo.c:61: if (active) {
      00363B 90 04 4B         [24]  984 	mov	dptr,#_active
      00363E E0               [24]  985 	movx	a,@dptr
      00363F 60 6F            [24]  986 	jz	00123$
                                    987 ;	keyboards/ajazz/ak820/ak820_combo.c:62: if (id != first && id != second) return true;
      003641 12 38 7E         [24]  988 	lcall	_ak820_outline_0172
      003644 F9               [12]  989 	mov	r1,a
      003645 EA               [12]  990 	mov	a,r2
      003646 B5 01 02         [24]  991 	cjne	a,ar1,00315$
      003649 80 0F            [24]  992 	sjmp	00110$
      00364B                        993 00315$:
      00364B 90 0D 71         [24]  994 	mov	dptr,#_second
      00364E E0               [24]  995 	movx	a,@dptr
      00364F F9               [12]  996 	mov	r1,a
      003650 EA               [12]  997 	mov	a,r2
      003651 B5 01 02         [24]  998 	cjne	a,ar1,00316$
      003654 80 04            [24]  999 	sjmp	00110$
      003656                       1000 00316$:
      003656 75 82 01         [24] 1001 	mov	dpl, #0x01
      003659 22               [24] 1002 	ret
      00365A                       1003 00110$:
                                   1004 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (!record->event.pressed) {
      00365A 90 04 5A         [24] 1005 	mov	dptr,#_ak820_combo_process_record_10000_612
      00365D 12 38 36         [24] 1006 	lcall	_ak820_outline_0092
      003660 74 05            [12] 1007 	mov	a,#0x05
      003662 28               [12] 1008 	add	a, r0
      003663 F8               [12] 1009 	mov	r0,a
      003664 E4               [12] 1010 	clr	a
      003665 39               [12] 1011 	addc	a, r1
      003666 F9               [12] 1012 	mov	r1,a
      003667 12 38 6E         [24] 1013 	lcall	_ak820_outline_0144
      00366A E0               [24] 1014 	movx	a,@dptr
      00366B 70 3F            [24] 1015 	jnz	00121$
                                   1016 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (saved.event.pressed) {
      00366D 90 04 47         [24] 1017 	mov	dptr,#(_saved + 0x0005)
      003670 E0               [24] 1018 	movx	a,@dptr
      003671 60 0F            [24] 1019 	jz	00113$
                                   1020 ;	keyboards/ajazz/ak820/ak820_combo.c:65: saved.event.pressed = false;
      003673 90 04 47         [24] 1021 	mov	dptr,#(_saved + 0x0005)
      003676 E4               [12] 1022 	clr	a
      003677 F0               [24] 1023 	movx	@dptr,a
                                   1024 ;	keyboards/ajazz/ak820/ak820_combo.c:66: process_record(&saved);
      003678 90 04 42         [24] 1025 	mov	dptr,#_saved
      00367B C0 02            [24] 1026 	push	ar2
      00367D 12 6E D6         [24] 1027 	lcall	_process_record
      003680 D0 02            [24] 1028 	pop	ar2
      003682                       1029 00113$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_combo.c:68: if (id == first) first = NONE;
      003682 12 38 7E         [24] 1031 	lcall	_ak820_outline_0172
      003685 F9               [12] 1032 	mov	r1,a
      003686 EA               [12] 1033 	mov	a,r2
      003687 B5 01 08         [24] 1034 	cjne	a,ar1,00115$
      00368A 90 0D 70         [24] 1035 	mov	dptr,#_first
      00368D 74 FF            [12] 1036 	mov	a,#0xff
      00368F F0               [24] 1037 	movx	@dptr,a
      003690 80 06            [24] 1038 	sjmp	00116$
      003692                       1039 00115$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_combo.c:69: else second = NONE;
      003692 90 0D 71         [24] 1041 	mov	dptr,#_second
      003695 74 FF            [12] 1042 	mov	a,#0xff
      003697 F0               [24] 1043 	movx	@dptr,a
      003698                       1044 00116$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (first == NONE && second == NONE) active = false;
      003698 12 38 7E         [24] 1046 	lcall	_ak820_outline_0172
      00369B F9               [12] 1047 	mov	r1,a
      00369C B9 FF 0D         [24] 1048 	cjne	r1,#0xff,00121$
      00369F 90 0D 71         [24] 1049 	mov	dptr,#_second
      0036A2 E0               [24] 1050 	movx	a,@dptr
      0036A3 F9               [12] 1051 	mov	r1,a
      0036A4 B9 FF 05         [24] 1052 	cjne	r1,#0xff,00121$
      0036A7 90 04 4B         [24] 1053 	mov	dptr,#_active
      0036AA E4               [12] 1054 	clr	a
      0036AB F0               [24] 1055 	movx	@dptr,a
      0036AC                       1056 00121$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_combo.c:72: return false;
      0036AC 75 82 00         [24] 1058 	mov	dpl, #0x00
      0036AF 22               [24] 1059 	ret
      0036B0                       1060 00123$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_combo.c:74: bool eligible = false;
      0036B0 90 04 5C         [24] 1062 	mov	dptr,#_ak820_combo_process_eligible_10001_627
      0036B3 E4               [12] 1063 	clr	a
      0036B4 F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (record->event.pressed && COMBO_INPUT(record->keycode)) {
      0036B5 12 37 CA         [24] 1066 	lcall	_ak820_outline_0008
      0036B8 70 03            [24] 1067 	jnz	00325$
      0036BA 02 37 62         [24] 1068 	ljmp	00134$
      0036BD                       1069 00325$:
      0036BD C3               [12] 1070 	clr	c
      0036BE EC               [12] 1071 	mov	a,r4
      0036BF 94 04            [12] 1072 	subb	a,#0x04
      0036C1 ED               [12] 1073 	mov	a,r5
      0036C2 94 00            [12] 1074 	subb	a,#0x00
      0036C4 50 03            [24] 1075 	jnc	00326$
      0036C6 02 37 62         [24] 1076 	ljmp	00134$
      0036C9                       1077 00326$:
      0036C9 C3               [12] 1078 	clr	c
      0036CA 74 A4            [12] 1079 	mov	a,#0xa4
      0036CC 9C               [12] 1080 	subb	a,r4
      0036CD E4               [12] 1081 	clr	a
      0036CE 9D               [12] 1082 	subb	a,r5
      0036CF 50 03            [24] 1083 	jnc	00327$
      0036D1 02 37 62         [24] 1084 	ljmp	00134$
      0036D4                       1085 00327$:
                                   1086 ;	free result
                                   1087 ;	keyboards/ajazz/ak820/ak820_combo.c:76: uint8_t previous = saved.keycode;
      0036D4 90 04 49         [24] 1088 	mov	dptr,#(_saved + 0x0007)
      0036D7 E0               [24] 1089 	movx	a,@dptr
      0036D8 FF               [12] 1090 	mov	r7,a
                                   1091 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0036D9 90 04 5D         [24] 1092 	mov	dptr,#_ak820_combo_process_i_40001_630
      0036DC E4               [12] 1093 	clr	a
      0036DD F0               [24] 1094 	movx	@dptr,a
      0036DE EB               [12] 1095 	mov	a,r3
      0036DF B5 07 03         [24] 1096 	cjne	a,ar7,00328$
      0036E2 D3               [12] 1097 	setb	c
      0036E3 80 01            [24] 1098 	sjmp	00329$
      0036E5                       1099 00328$:
      0036E5 C3               [12] 1100 	clr	c
      0036E6                       1101 00329$:
      0036E6 92 01            [24] 1102 	mov	_ak820_combo_process_sloc0_1_0,c
      0036E8 7E 00            [12] 1103 	mov	r6,#0x00
      0036EA                       1104 00142$:
      0036EA BE 08 00         [24] 1105 	cjne	r6,#0x08,00330$
      0036ED                       1106 00330$:
      0036ED 40 03            [24] 1107 	jc	00331$
      0036EF 02 37 62         [24] 1108 	ljmp	00134$
      0036F2                       1109 00331$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t a = combos[i].a, b = combos[i].b;
      0036F2 EE               [12] 1111 	mov	a,r6
      0036F3 12 37 FF         [24] 1112 	lcall	_ak820_outline_0049
      0036F6 E0               [24] 1113 	movx	a,@dptr
      0036F7 F9               [12] 1114 	mov	r1,a
      0036F8 90 04 5E         [24] 1115 	mov	dptr,#_ak820_combo_process_a_50001_631
      0036FB F0               [24] 1116 	movx	@dptr,a
      0036FC 12 38 4D         [24] 1117 	lcall	_ak820_outline_0110
      0036FF A3               [24] 1118 	inc	dptr
      003700 E0               [24] 1119 	movx	a,@dptr
      003701 FD               [12] 1120 	mov	r5,a
      003702 90 04 5F         [24] 1121 	mov	dptr,#_ak820_combo_process_b_50001_631
      003705 F0               [24] 1122 	movx	@dptr,a
                                   1123 ;	keyboards/ajazz/ak820/ak820_combo.c:79: if (a == code || b == code) {
      003706 E9               [12] 1124 	mov	a,r1
      003707 B5 03 02         [24] 1125 	cjne	a,ar3,00332$
      00370A 80 04            [24] 1126 	sjmp	00129$
      00370C                       1127 00332$:
      00370C ED               [12] 1128 	mov	a,r5
      00370D B5 03 49         [24] 1129 	cjne	a,ar3,00143$
      003710                       1130 00129$:
                                   1131 ;	keyboards/ajazz/ak820/ak820_combo.c:80: eligible = true;
      003710 90 04 5C         [24] 1132 	mov	dptr,#_ak820_combo_process_eligible_10001_627
      003713 74 01            [12] 1133 	mov	a,#0x01
      003715 F0               [24] 1134 	movx	@dptr,a
                                   1135 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003716 12 38 7E         [24] 1136 	lcall	_ak820_outline_0172
      003719 FD               [12] 1137 	mov	r5,a
      00371A BD FF 02         [24] 1138 	cjne	r5,#0xff,00335$
      00371D 80 3A            [24] 1139 	sjmp	00143$
      00371F                       1140 00335$:
      00371F 20 01 37         [24] 1141 	jb	_ak820_combo_process_sloc0_1_0,00143$
      003722 90 04 5E         [24] 1142 	mov	dptr,#_ak820_combo_process_a_50001_631
      003725 E0               [24] 1143 	movx	a,@dptr
      003726 B5 07 02         [24] 1144 	cjne	a,ar7,00337$
      003729 80 07            [24] 1145 	sjmp	00124$
      00372B                       1146 00337$:
      00372B 90 04 5F         [24] 1147 	mov	dptr,#_ak820_combo_process_b_50001_631
      00372E E0               [24] 1148 	movx	a,@dptr
      00372F B5 07 27         [24] 1149 	cjne	a,ar7,00143$
      003732                       1150 00124$:
                                   1151 ;	keyboards/ajazz/ak820/ak820_combo.c:82: second = id;
      003732 90 0D 71         [24] 1152 	mov	dptr,#_second
      003735 EA               [12] 1153 	mov	a,r2
      003736 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	keyboards/ajazz/ak820/ak820_combo.c:83: active = true;
      003737 90 04 4B         [24] 1156 	mov	dptr,#_active
      00373A 74 01            [12] 1157 	mov	a,#0x01
      00373C F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	keyboards/ajazz/ak820/ak820_combo.c:84: saved.keycode = combos[i].output;
      00373D 90 04 5D         [24] 1160 	mov	dptr,#_ak820_combo_process_i_40001_630
      003740 E0               [24] 1161 	movx	a,@dptr
      003741 12 37 FF         [24] 1162 	lcall	_ak820_outline_0049
      003744 A3               [24] 1163 	inc	dptr
      003745 A3               [24] 1164 	inc	dptr
      003746 12 38 18         [24] 1165 	lcall	_ak820_outline_0057
      003749 90 04 49         [24] 1166 	mov	dptr,#(_saved + 0x0007)
      00374C 12 38 24         [24] 1167 	lcall	_ak820_outline_0070
                                   1168 ;	keyboards/ajazz/ak820/ak820_combo.c:85: process_record(&saved);
      00374F 90 04 42         [24] 1169 	mov	dptr,#_saved
      003752 12 6E D6         [24] 1170 	lcall	_process_record
                                   1171 ;	keyboards/ajazz/ak820/ak820_combo.c:86: return false;
      003755 75 82 00         [24] 1172 	mov	dpl, #0x00
      003758 22               [24] 1173 	ret
      003759                       1174 00143$:
                                   1175 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003759 0E               [12] 1176 	inc	r6
      00375A 90 04 5D         [24] 1177 	mov	dptr,#_ak820_combo_process_i_40001_630
      00375D EE               [12] 1178 	mov	a,r6
      00375E F0               [24] 1179 	movx	@dptr,a
      00375F 02 36 EA         [24] 1180 	ljmp	00142$
      003762                       1181 00134$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_combo.c:91: if (first != NONE) flush();
      003762 12 38 7E         [24] 1183 	lcall	_ak820_outline_0172
      003765 FF               [12] 1184 	mov	r7,a
      003766 BF FF 02         [24] 1185 	cjne	r7,#0xff,00340$
      003769 80 07            [24] 1186 	sjmp	00138$
      00376B                       1187 00340$:
      00376B C0 02            [24] 1188 	push	ar2
      00376D 12 35 AD         [24] 1189 	lcall	_flush
      003770 D0 02            [24] 1190 	pop	ar2
      003772                       1191 00138$:
                                   1192 ;	keyboards/ajazz/ak820/ak820_combo.c:92: if (eligible) {
      003772 90 04 5C         [24] 1193 	mov	dptr,#_ak820_combo_process_eligible_10001_627
      003775 E0               [24] 1194 	movx	a,@dptr
      003776 60 26            [24] 1195 	jz	00140$
                                   1196 ;	keyboards/ajazz/ak820/ak820_combo.c:93: first = id;
      003778 90 0D 70         [24] 1197 	mov	dptr,#_first
      00377B EA               [12] 1198 	mov	a,r2
      00377C F0               [24] 1199 	movx	@dptr,a
                                   1200 ;	keyboards/ajazz/ak820/ak820_combo.c:94: saved = *record;
      00377D 90 04 5A         [24] 1201 	mov	dptr,#_ak820_combo_process_record_10000_612
      003780 12 38 10         [24] 1202 	lcall	_ak820_outline_0054
      003783 90 0D 62         [24] 1203 	mov	dptr,#___memcpy_PARM_2
      003786 ED               [12] 1204 	mov	a,r5
      003787 12 37 E1         [24] 1205 	lcall	_ak820_outline_0015
      00378A 90 0D 65         [24] 1206 	mov	dptr,#___memcpy_PARM_3
      00378D 74 09            [12] 1207 	mov	a,#0x09
      00378F 12 38 58         [24] 1208 	lcall	_ak820_outline_0114
      003792 90 04 42         [24] 1209 	mov	dptr,#_saved
      003795 F5 F0            [12] 1210 	mov	b,a
      003797 12 B3 51         [24] 1211 	lcall	___memcpy
                                   1212 ;	keyboards/ajazz/ak820/ak820_combo.c:95: return false;
      00379A 75 82 00         [24] 1213 	mov	dpl, #0x00
      00379D 22               [24] 1214 	ret
      00379E                       1215 00140$:
                                   1216 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return true;
      00379E 75 82 01         [24] 1217 	mov	dpl, #0x01
                                   1218 ;	keyboards/ajazz/ak820/ak820_combo.c:98: }
      0037A1 22               [24] 1219 	ret
                                   1220 	.area CSEG    (CODE)
                                   1221 	.area CONST   (CODE)
                                   1222 	.area XINIT   (CODE)
      00BC0F                       1223 __xinit__first:
      00BC0F FF                    1224 	.db #0xff	; 255
      00BC10                       1225 __xinit__second:
      00BC10 FF                    1226 	.db #0xff	; 255
                                   1227 	.area CABS    (ABS,CODE)
                                   1228 
                                   1229 ; Experimental exact instruction outlining.
                                   1230 	.globl _ak820_outline_0004
                                   1231 	.globl _ak820_outline_0006
                                   1232 	.globl _ak820_outline_0007
                                   1233 	.globl _ak820_outline_0008
                                   1234 	.globl _ak820_outline_0013
                                   1235 	.globl _ak820_outline_0015
                                   1236 	.globl _ak820_outline_0018
                                   1237 	.globl _ak820_outline_0031
                                   1238 	.globl _ak820_outline_0047
                                   1239 	.globl _ak820_outline_0049
                                   1240 	.globl _ak820_outline_0054
                                   1241 	.globl _ak820_outline_0057
                                   1242 	.globl _ak820_outline_0067
                                   1243 	.globl _ak820_outline_0070
                                   1244 	.globl _ak820_outline_0071
                                   1245 	.globl _ak820_outline_0090
                                   1246 	.globl _ak820_outline_0092
                                   1247 	.globl _ak820_outline_0098
                                   1248 	.globl _ak820_outline_0099
                                   1249 	.globl _ak820_outline_0101
                                   1250 	.globl _ak820_outline_0110
                                   1251 	.globl _ak820_outline_0112
                                   1252 	.globl _ak820_outline_0113
                                   1253 	.globl _ak820_outline_0114
                                   1254 	.globl _ak820_outline_0122
                                   1255 	.globl _ak820_outline_0126
                                   1256 	.globl _ak820_outline_0129
                                   1257 	.globl _ak820_outline_0144
                                   1258 	.globl _ak820_outline_0147
                                   1259 	.globl _ak820_outline_0158
                                   1260 	.globl _ak820_outline_0172
                                   1261 	.globl _ak820_outline_0176
                                   1262 
                                   1263 	.area CSEG (CODE)
                                   1264 ; function ak820_outline_0004
      0037A2                       1265 _ak820_outline_0004:
      0037A2 E0               [24] 1266 	movx	a,@dptr
      0037A3 FE               [12] 1267 	mov	r6,a
      0037A4 A3               [24] 1268 	inc	dptr
      0037A5 E0               [24] 1269 	movx	a,@dptr
      0037A6 FF               [12] 1270 	mov	r7,a
      0037A7 8E 82            [24] 1271 	mov	dpl,r6
      0037A9 8F 83            [24] 1272 	mov	dph,r7
      0037AB 22               [24] 1273 	ret
                                   1274 
                                   1275 	.area CSEG (CODE)
                                   1276 ; function ak820_outline_0006
      0037AC                       1277 _ak820_outline_0006:
      0037AC E0               [24] 1278 	movx	a,@dptr
      0037AD FE               [12] 1279 	mov	r6,a
      0037AE A3               [24] 1280 	inc	dptr
      0037AF E0               [24] 1281 	movx	a,@dptr
      0037B0 FF               [12] 1282 	mov	r7,a
      0037B1 74 07            [12] 1283 	mov	a,#0x07
      0037B3 2E               [12] 1284 	add	a,r6
      0037B4 F5 82            [12] 1285 	mov	dpl,a
      0037B6 E4               [12] 1286 	clr	a
      0037B7 3F               [12] 1287 	addc	a,r7
      0037B8 F5 83            [12] 1288 	mov	dph,a
      0037BA E0               [24] 1289 	movx	a,@dptr
      0037BB FC               [12] 1290 	mov	r4,a
      0037BC A3               [24] 1291 	inc	dptr
      0037BD E0               [24] 1292 	movx	a,@dptr
      0037BE FD               [12] 1293 	mov	r5,a
      0037BF 22               [24] 1294 	ret
                                   1295 
                                   1296 	.area CSEG (CODE)
                                   1297 ; function ak820_outline_0007
      0037C0                       1298 _ak820_outline_0007:
      0037C0 E0               [24] 1299 	movx	a,@dptr
      0037C1 FE               [12] 1300 	mov	r6,a
      0037C2 A3               [24] 1301 	inc	dptr
      0037C3 E0               [24] 1302 	movx	a,@dptr
      0037C4 FF               [12] 1303 	mov	r7,a
      0037C5 8E 04            [24] 1304 	mov	ar4,r6
      0037C7 8F 05            [24] 1305 	mov	ar5,r7
      0037C9 22               [24] 1306 	ret
                                   1307 
                                   1308 	.area CSEG (CODE)
                                   1309 ; function ak820_outline_0008
      0037CA                       1310 _ak820_outline_0008:
      0037CA 74 05            [12] 1311 	mov	a,#0x05
      0037CC 2E               [12] 1312 	add	a,r6
      0037CD FE               [12] 1313 	mov	r6,a
      0037CE E4               [12] 1314 	clr	a
      0037CF 3F               [12] 1315 	addc	a,r7
      0037D0 FF               [12] 1316 	mov	r7,a
      0037D1 8E 82            [24] 1317 	mov	dpl,r6
      0037D3 8F 83            [24] 1318 	mov	dph,r7
      0037D5 E0               [24] 1319 	movx	a,@dptr
      0037D6 22               [24] 1320 	ret
                                   1321 
                                   1322 	.area CSEG (CODE)
                                   1323 ; function ak820_outline_0013
      0037D7                       1324 _ak820_outline_0013:
      0037D7 F9               [12] 1325 	mov	r1,a
      0037D8 E4               [12] 1326 	clr	a
      0037D9 3F               [12] 1327 	addc	a,r7
      0037DA FA               [12] 1328 	mov	r2,a
      0037DB 89 82            [24] 1329 	mov	dpl,r1
      0037DD 8A 83            [24] 1330 	mov	dph,r2
      0037DF E0               [24] 1331 	movx	a,@dptr
      0037E0 22               [24] 1332 	ret
                                   1333 
                                   1334 	.area CSEG (CODE)
                                   1335 ; function ak820_outline_0015
      0037E1                       1336 _ak820_outline_0015:
      0037E1 F0               [24] 1337 	movx	@dptr,a
      0037E2 EE               [12] 1338 	mov	a,r6
      0037E3 A3               [24] 1339 	inc	dptr
      0037E4 F0               [24] 1340 	movx	@dptr,a
      0037E5 EF               [12] 1341 	mov	a,r7
      0037E6 A3               [24] 1342 	inc	dptr
      0037E7 F0               [24] 1343 	movx	@dptr,a
      0037E8 22               [24] 1344 	ret
                                   1345 
                                   1346 	.area CSEG (CODE)
                                   1347 ; function ak820_outline_0018
      0037E9                       1348 _ak820_outline_0018:
      0037E9 2E               [12] 1349 	add	a,r6
      0037EA F5 82            [12] 1350 	mov	dpl,a
      0037EC E4               [12] 1351 	clr	a
      0037ED 3F               [12] 1352 	addc	a,r7
      0037EE F5 83            [12] 1353 	mov	dph,a
      0037F0 22               [24] 1354 	ret
                                   1355 
                                   1356 	.area CSEG (CODE)
                                   1357 ; function ak820_outline_0031
      0037F1                       1358 _ak820_outline_0031:
      0037F1 8E 82            [24] 1359 	mov	dpl,r6
      0037F3 8F 83            [24] 1360 	mov	dph,r7
      0037F5 A3               [24] 1361 	inc	dptr
      0037F6 A3               [24] 1362 	inc	dptr
      0037F7 E0               [24] 1363 	movx	a,@dptr
      0037F8 22               [24] 1364 	ret
                                   1365 
                                   1366 	.area CSEG (CODE)
                                   1367 ; function ak820_outline_0047
      0037F9                       1368 _ak820_outline_0047:
      0037F9 E0               [24] 1369 	movx	a,@dptr
      0037FA FE               [12] 1370 	mov	r6,a
      0037FB A3               [24] 1371 	inc	dptr
      0037FC E0               [24] 1372 	movx	a,@dptr
      0037FD FF               [12] 1373 	mov	r7,a
      0037FE 22               [24] 1374 	ret
                                   1375 
                                   1376 	.area CSEG (CODE)
                                   1377 ; function ak820_outline_0049
      0037FF                       1378 _ak820_outline_0049:
      0037FF 75 F0 04         [24] 1379 	mov	b,#0x04
      003802 A4               [48] 1380 	mul	ab
      003803 24 22            [12] 1381 	add	a,#_combos
      003805 FC               [12] 1382 	mov	r4,a
      003806 74 04            [12] 1383 	mov	a,#(_combos>>8)
      003808 35 F0            [12] 1384 	addc	a,b
      00380A FD               [12] 1385 	mov	r5,a
      00380B 8C 82            [24] 1386 	mov	dpl,r4
      00380D 8D 83            [24] 1387 	mov	dph,r5
      00380F 22               [24] 1388 	ret
                                   1389 
                                   1390 	.area CSEG (CODE)
                                   1391 ; function ak820_outline_0054
      003810                       1392 _ak820_outline_0054:
      003810 E0               [24] 1393 	movx	a,@dptr
      003811 FD               [12] 1394 	mov	r5,a
      003812 A3               [24] 1395 	inc	dptr
      003813 E0               [24] 1396 	movx	a,@dptr
      003814 FE               [12] 1397 	mov	r6,a
      003815 7F 00            [12] 1398 	mov	r7,#0x00
      003817 22               [24] 1399 	ret
                                   1400 
                                   1401 	.area CSEG (CODE)
                                   1402 ; function ak820_outline_0057
      003818                       1403 _ak820_outline_0057:
      003818 E0               [24] 1404 	movx	a,@dptr
      003819 FC               [12] 1405 	mov	r4,a
      00381A A3               [24] 1406 	inc	dptr
      00381B E0               [24] 1407 	movx	a,@dptr
      00381C FD               [12] 1408 	mov	r5,a
      00381D 22               [24] 1409 	ret
                                   1410 
                                   1411 	.area CSEG (CODE)
                                   1412 ; function ak820_outline_0067
      00381E                       1413 _ak820_outline_0067:
      00381E A3               [24] 1414 	inc	dptr
      00381F F0               [24] 1415 	movx	@dptr,a
      003820 E4               [12] 1416 	clr	a
      003821 A3               [24] 1417 	inc	dptr
      003822 F0               [24] 1418 	movx	@dptr,a
      003823 22               [24] 1419 	ret
                                   1420 
                                   1421 	.area CSEG (CODE)
                                   1422 ; function ak820_outline_0070
      003824                       1423 _ak820_outline_0070:
      003824 EC               [12] 1424 	mov	a,r4
      003825 F0               [24] 1425 	movx	@dptr,a
      003826 ED               [12] 1426 	mov	a,r5
      003827 A3               [24] 1427 	inc	dptr
      003828 F0               [24] 1428 	movx	@dptr,a
      003829 22               [24] 1429 	ret
                                   1430 
                                   1431 	.area CSEG (CODE)
                                   1432 ; function ak820_outline_0071
      00382A                       1433 _ak820_outline_0071:
      00382A EB               [12] 1434 	mov	a,r3
      00382B F0               [24] 1435 	movx	@dptr,a
      00382C EC               [12] 1436 	mov	a,r4
      00382D A3               [24] 1437 	inc	dptr
      00382E F0               [24] 1438 	movx	@dptr,a
      00382F 22               [24] 1439 	ret
                                   1440 
                                   1441 	.area CSEG (CODE)
                                   1442 ; function ak820_outline_0090
      003830                       1443 _ak820_outline_0090:
      003830 8E 82            [24] 1444 	mov	dpl,r6
      003832 8F 83            [24] 1445 	mov	dph,r7
      003834 E0               [24] 1446 	movx	a,@dptr
      003835 22               [24] 1447 	ret
                                   1448 
                                   1449 	.area CSEG (CODE)
                                   1450 ; function ak820_outline_0092
      003836                       1451 _ak820_outline_0092:
      003836 E0               [24] 1452 	movx	a,@dptr
      003837 F8               [12] 1453 	mov	r0,a
      003838 A3               [24] 1454 	inc	dptr
      003839 E0               [24] 1455 	movx	a,@dptr
      00383A F9               [12] 1456 	mov	r1,a
      00383B 22               [24] 1457 	ret
                                   1458 
                                   1459 	.area CSEG (CODE)
                                   1460 ; function ak820_outline_0098
      00383C                       1461 _ak820_outline_0098:
      00383C AF 83            [24] 1462 	mov	r7,dph
      00383E E5 82            [12] 1463 	mov	a,dpl
      003840 22               [24] 1464 	ret
                                   1465 
                                   1466 	.area CSEG (CODE)
                                   1467 ; function ak820_outline_0099
      003841                       1468 _ak820_outline_0099:
      003841 F0               [24] 1469 	movx	@dptr,a
      003842 EF               [12] 1470 	mov	a,r7
      003843 A3               [24] 1471 	inc	dptr
      003844 F0               [24] 1472 	movx	@dptr,a
      003845 22               [24] 1473 	ret
                                   1474 
                                   1475 	.area CSEG (CODE)
                                   1476 ; function ak820_outline_0101
      003846                       1477 _ak820_outline_0101:
      003846 8E 82            [24] 1478 	mov	dpl,r6
      003848 8F 83            [24] 1479 	mov	dph,r7
      00384A A3               [24] 1480 	inc	dptr
      00384B E0               [24] 1481 	movx	a,@dptr
      00384C 22               [24] 1482 	ret
                                   1483 
                                   1484 	.area CSEG (CODE)
                                   1485 ; function ak820_outline_0110
      00384D                       1486 _ak820_outline_0110:
      00384D 8C 82            [24] 1487 	mov	dpl,r4
      00384F 8D 83            [24] 1488 	mov	dph,r5
      003851 22               [24] 1489 	ret
                                   1490 
                                   1491 	.area CSEG (CODE)
                                   1492 ; function ak820_outline_0112
      003852                       1493 _ak820_outline_0112:
      003852 E0               [24] 1494 	movx	a,@dptr
      003853 FB               [12] 1495 	mov	r3,a
      003854 A3               [24] 1496 	inc	dptr
      003855 E0               [24] 1497 	movx	a,@dptr
      003856 FC               [12] 1498 	mov	r4,a
      003857 22               [24] 1499 	ret
                                   1500 
                                   1501 	.area CSEG (CODE)
                                   1502 ; function ak820_outline_0114
      003858                       1503 _ak820_outline_0114:
      003858 F0               [24] 1504 	movx	@dptr,a
      003859 E4               [12] 1505 	clr	a
      00385A A3               [24] 1506 	inc	dptr
      00385B F0               [24] 1507 	movx	@dptr,a
      00385C 22               [24] 1508 	ret
                                   1509 
                                   1510 	.area CSEG (CODE)
                                   1511 ; function ak820_outline_0122
      00385D                       1512 _ak820_outline_0122:
      00385D 8D 82            [24] 1513 	mov	dpl,r5
      00385F 8E 83            [24] 1514 	mov	dph,r6
      003861 22               [24] 1515 	ret
                                   1516 
                                   1517 	.area CSEG (CODE)
                                   1518 ; function ak820_outline_0126
      003862                       1519 _ak820_outline_0126:
      003862 E5 82            [12] 1520 	mov	a,dpl
      003864 85 83 F0         [24] 1521 	mov	b,dph
      003867 22               [24] 1522 	ret
                                   1523 
                                   1524 	.area CSEG (CODE)
                                   1525 ; function ak820_outline_0129
      003868                       1526 _ak820_outline_0129:
      003868 E0               [24] 1527 	movx	a,@dptr
      003869 FC               [12] 1528 	mov	r4,a
      00386A A3               [24] 1529 	inc	dptr
      00386B E0               [24] 1530 	movx	a,@dptr
      00386C 4C               [12] 1531 	orl	a,r4
      00386D 22               [24] 1532 	ret
                                   1533 
                                   1534 	.area CSEG (CODE)
                                   1535 ; function ak820_outline_0144
      00386E                       1536 _ak820_outline_0144:
      00386E 88 82            [24] 1537 	mov	dpl,r0
      003870 89 83            [24] 1538 	mov	dph,r1
      003872 22               [24] 1539 	ret
                                   1540 
                                   1541 	.area CSEG (CODE)
                                   1542 ; function ak820_outline_0147
      003873                       1543 _ak820_outline_0147:
      003873 2D               [12] 1544 	add	a,r5
      003874 FD               [12] 1545 	mov	r5,a
      003875 E4               [12] 1546 	clr	a
      003876 3E               [12] 1547 	addc	a,r6
      003877 FE               [12] 1548 	mov	r6,a
      003878 22               [24] 1549 	ret
                                   1550 
                                   1551 	.area CSEG (CODE)
                                   1552 ; function ak820_outline_0158
      003879                       1553 _ak820_outline_0158:
      003879 E4               [12] 1554 	clr	a
      00387A 33               [12] 1555 	rlc	a
      00387B F5 82            [12] 1556 	mov	dpl,a
      00387D 22               [24] 1557 	ret
                                   1558 
                                   1559 	.area CSEG (CODE)
                                   1560 ; function ak820_outline_0172
      00387E                       1561 _ak820_outline_0172:
      00387E 90 0D 70         [24] 1562 	mov	dptr,#_first
      003881 E0               [24] 1563 	movx	a,@dptr
      003882 22               [24] 1564 	ret
                                   1565 
                                   1566 	.area CSEG (CODE)
                                   1567 ; function ak820_outline_0176
      003883                       1568 _ak820_outline_0176:
      003883 C4               [12] 1569 	swap	a
      003884 03               [12] 1570 	rr	a
      003885 54 F8            [12] 1571 	anl	a,#0xf8
      003887 22               [24] 1572 	ret
