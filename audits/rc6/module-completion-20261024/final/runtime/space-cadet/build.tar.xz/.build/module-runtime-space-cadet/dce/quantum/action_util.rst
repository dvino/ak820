                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000053                        551 _change_owned_sloc1_1_0:
      000053                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      00001E                        566 _ak820_macro_change_sloc0_1_0:
      00001E                        567 	.ds 1
      00001F                        568 _change_owned_sloc0_1_0:
      00001F                        569 	.ds 1
      000020                        570 _owned_usage_key_sloc0_1_0:
      000020                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      00095F                        580 _owned_mod_refs:
      00095F                        581 	.ds 8
      000967                        582 _owned_weak_refs:
      000967                        583 	.ds 8
      00096F                        584 _owned_mods:
      00096F                        585 	.ds 1
      000970                        586 _owned_weak_mods:
      000970                        587 	.ds 1
      000971                        588 _macro_mods:
      000971                        589 	.ds 2
      000973                        590 _ak820_macro_primitive::
      000973                        591 	.ds 1
      000974                        592 _ak820_macro_cancelled::
      000974                        593 	.ds 1
      000975                        594 _ak820_macro_change_PARM_2:
      000975                        595 	.ds 1
      000976                        596 _ak820_macro_change_PARM_3:
      000976                        597 	.ds 1
      000977                        598 _ak820_macro_change_bits_10000_293:
      000977                        599 	.ds 2
      000979                        600 _change_owned_PARM_2:
      000979                        601 	.ds 1
      00097A                        602 _change_owned_mods_10000_298:
      00097A                        603 	.ds 1
      00097B                        604 _change_owned_result_10001_302:
      00097B                        605 	.ds 1
      00097C                        606 _change_owned_bit_20001_303:
      00097C                        607 	.ds 1
      00097D                        608 _add_owned_mods_mods_10000_311:
      00097D                        609 	.ds 1
      00097E                        610 _del_owned_mods_mods_10000_313:
      00097E                        611 	.ds 1
      00097F                        612 _add_owned_weak_mods_mods_10000_315:
      00097F                        613 	.ds 1
      000980                        614 _del_owned_weak_mods_mods_10000_317:
      000980                        615 	.ds 1
      000981                        616 _key_refs:
      000981                        617 	.ds 165
      000A26                        618 _distinct_keys:
      000A26                        619 	.ds 1
      000A27                        620 _macro_keys:
      000A27                        621 	.ds 21
      000A3C                        622 _add_owned_key_code_10000_326:
      000A3C                        623 	.ds 1
      000A3D                        624 _del_owned_key_code_10000_341:
      000A3D                        625 	.ds 1
      000A3E                        626 _usage_refs:
      000A3E                        627 	.ds 30
      000A5C                        628 _usage_order:
      000A5C                        629 	.ds 30
      000A7A                        630 _usage_lengths:
      000A7A                        631 	.ds 2
      000A7C                        632 _macro_usages:
      000A7C                        633 	.ds 4
      000A80                        634 _owned_usage_key_PARM_2:
      000A80                        635 	.ds 1
      000A81                        636 _owned_usage_key_code_10000_368:
      000A81                        637 	.ds 1
      000A82                        638 _owned_usage_key___200000085_20000_369:
      000A82                        639 	.ds 2
      000A84                        640 _owned_usage_key_which_10000_369:
      000A84                        641 	.ds 1
      000A85                        642 _owned_usage_key_count_10000_369:
      000A85                        643 	.ds 1
      000A86                        644 _owned_usage_key_pos_30001_376:
      000A86                        645 	.ds 1
      000A87                        646 _owned_usage_key_key_40000_381:
      000A87                        647 	.ds 1
      000A88                        648 _send_keyboard_report_last_report_10001_388:
      000A88                        649 	.ds 32
      000AA8                        650 _send_keyboard_report_changed_10001_388:
      000AA8                        651 	.ds 1
      000AA9                        652 _add_weak_mods_mods_10000_406:
      000AA9                        653 	.ds 1
      000AAA                        654 _del_weak_mods_mods_10000_408:
      000AAA                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000D84                        664 _real_mods:
      000D84                        665 	.ds 1
      000D85                        666 _weak_mods:
      000D85                        667 	.ds 1
      000D86                        668 _actual_keyboard_report::
      000D86                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007865                        713 _ak820_macro_change:
      007865 12 38 3C         [24]  714 	lcall	_ak820_outline_0098
      007868 90 09 77         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      00786B 12 38 41         [24]  716 	lcall	_ak820_outline_0099
                                    717 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      00786E 90 09 73         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007871 E0               [24]  719 	movx	a,@dptr
      007872 70 04            [24]  720 	jnz	00102$
      007874 75 82 01         [24]  721 	mov	dpl, #0x01
      007877 22               [24]  722 	ret
      007878                        723 00102$:
                                    724 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007878 90 09 75         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      00787B E0               [24]  726 	movx	a,@dptr
      00787C FF               [12]  727 	mov	r7,a
      00787D 74 07            [12]  728 	mov	a,#0x07
      00787F 5F               [12]  729 	anl	a,r7
      007880 12 74 07         [24]  730 	lcall	_ak820_outline_0059
      007883 80 02            [24]  731 	sjmp	00123$
      007885                        732 00122$:
      007885 25 E0            [12]  733 	add	a,acc
      007887                        734 00123$:
      007887 D5 F0 FB         [24]  735 	djnz	b,00122$
      00788A FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:101: bits += index >> 3;
      00788B EF               [12]  738 	mov	a,r7
      00788C 12 55 86         [24]  739 	lcall	_ak820_outline_0174
      00788F FF               [12]  740 	mov	r7,a
      007890 90 09 77         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007893 12 38 18         [24]  742 	lcall	_ak820_outline_0057
      007896 90 09 77         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007899 EF               [12]  744 	mov	a,r7
      00789A 2C               [12]  745 	add	a, r4
      00789B F0               [24]  746 	movx	@dptr,a
      00789C E4               [12]  747 	clr	a
      00789D 3D               [12]  748 	addc	a, r5
      00789E A3               [24]  749 	inc	dptr
      00789F F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      0078A0 90 09 77         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078A3 E0               [24]  753 	movx	a,@dptr
      0078A4 FD               [12]  754 	mov	r5,a
      0078A5 A3               [24]  755 	inc	dptr
      0078A6 E0               [24]  756 	movx	a,@dptr
      0078A7 FF               [12]  757 	mov	r7,a
      0078A8 12 7D EB         [24]  758 	lcall	_ak820_outline_0175
      0078AB E0               [24]  759 	movx	a,@dptr
      0078AC FC               [12]  760 	mov	r4,a
      0078AD EE               [12]  761 	mov	a,r6
      0078AE 5C               [12]  762 	anl	a,r4
      0078AF B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      0078B2                        764 00124$:
      0078B2 B3               [12]  765 	cpl	c
      0078B3 92 1E            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      0078B5 90 09 76         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      0078B8 E0               [24]  768 	movx	a,@dptr
      0078B9 FB               [12]  769 	mov	r3,a
      0078BA A2 1E            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      0078BC E4               [12]  771 	clr	a
      0078BD 33               [12]  772 	rlc	a
      0078BE B5 03 04         [24]  773 	cjne	a,ar3,00104$
      0078C1 75 82 00         [24]  774 	mov	dpl, #0x00
      0078C4 22               [24]  775 	ret
      0078C5                        776 00104$:
                                    777 ;	quantum/action_util.c:103: *bits ^= mask;
      0078C5 EC               [12]  778 	mov	a,r4
      0078C6 62 06            [12]  779 	xrl	ar6,a
      0078C8 12 7D EB         [24]  780 	lcall	_ak820_outline_0175
      0078CB EE               [12]  781 	mov	a,r6
      0078CC F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:104: return true;
      0078CD 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:105: }
      0078D0 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      0078D1                        805 _change_owned:
      0078D1 E5 82            [12]  806 	mov	a,dpl
      0078D3 90 09 7A         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      0078D6 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      0078D7 90 09 79         [24]  810 	mov	dptr,#_change_owned_PARM_2
      0078DA E0               [24]  811 	movx	a,@dptr
      0078DB FF               [12]  812 	mov	r7,a
      0078DC C3               [12]  813 	clr	c
      0078DD 13               [12]  814 	rrc	a
      0078DE FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      0078DF 53 07 01         [24]  817 	anl	ar7,#0x01
      0078E2 EF               [12]  818 	mov	a,r7
      0078E3 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      0078E6                        820 00205$:
      0078E6 92 1F            [24]  821 	mov  _change_owned_sloc0_1_0,c
      0078E8 B3               [12]  822 	cpl	c
      0078E9 E4               [12]  823 	clr	a
      0078EA 33               [12]  824 	rlc	a
      0078EB F5 53            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      0078ED EE               [12]  827 	mov	a,r6
      0078EE 60 06            [24]  828 	jz	00121$
      0078F0 7D 67            [12]  829 	mov	r5,#_owned_weak_refs
      0078F2 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      0078F4 80 04            [24]  831 	sjmp	00122$
      0078F6                        832 00121$:
      0078F6 7D 5F            [12]  833 	mov	r5,#_owned_mod_refs
      0078F8 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      0078FA                        835 00122$:
                                    836 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      0078FA 90 09 73         [24]  837 	mov	dptr,#_ak820_macro_primitive
      0078FD E0               [24]  838 	movx	a,@dptr
      0078FE 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007900 EE               [12]  841 	mov	a,r6
      007901 24 71            [12]  842 	add	a, #_macro_mods
      007903 FB               [12]  843 	mov	r3,a
      007904 E4               [12]  844 	clr	a
      007905 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007907 12 46 F3         [24]  846 	lcall	_ak820_outline_0051
                                    847 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      00790A E5 53            [12]  848 	mov	a,_change_owned_sloc1_1_0
      00790C 60 0A            [24]  849 	jz	00123$
      00790E 90 09 7A         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007911 E0               [24]  851 	movx	a,@dptr
      007912 F9               [12]  852 	mov	r1,a
      007913 EA               [12]  853 	mov	a,r2
      007914 42 01            [12]  854 	orl	ar1,a
      007916 80 07            [24]  855 	sjmp	00124$
      007918                        856 00123$:
      007918 90 09 7A         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      00791B E0               [24]  858 	movx	a,@dptr
      00791C F4               [12]  859 	cpl	a
      00791D 5A               [12]  860 	anl	a,r2
      00791E F9               [12]  861 	mov	r1,a
      00791F                        862 00124$:
      00791F 12 33 FC         [24]  863 	lcall	_ak820_outline_0113
      007922 E9               [12]  864 	mov	a,r1
      007923 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007924 E5 53            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007926 60 06            [24]  868 	jz	00125$
      007928 74 FF            [12]  869 	mov	a,#0xff
      00792A 6A               [12]  870 	xrl	a,r2
      00792B FC               [12]  871 	mov	r4,a
      00792C 80 02            [24]  872 	sjmp	00126$
      00792E                        873 00125$:
      00792E 8A 04            [24]  874 	mov	ar4,r2
      007930                        875 00126$:
      007930 90 09 7A         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007933 E0               [24]  877 	movx	a,@dptr
      007934 5C               [12]  878 	anl	a,r4
      007935 F0               [24]  879 	movx	@dptr,a
      007936                        880 00102$:
                                    881 ;	quantum/action_util.c:115: uint8_t result = 0;
      007936 90 09 7B         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007939 E4               [12]  883 	clr	a
      00793A F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00793B 90 09 7C         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      00793E 04               [12]  887 	inc	a
      00793F F0               [24]  888 	movx	@dptr,a
      007940 90 09 7A         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007943 E0               [24]  890 	movx	a,@dptr
      007944 FC               [12]  891 	mov	r4,a
      007945 7B 00            [12]  892 	mov	r3,#0x00
      007947                        893 00117$:
      007947 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      00794A                        895 00210$:
      00794A 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:117: if (mods & bit) {
      00794C 90 09 7C         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      00794F E0               [24]  899 	movx	a,@dptr
      007950 5C               [12]  900 	anl	a,r4
      007951 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007953 E5 53            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007955 60 0C            [24]  904 	jz	00106$
      007957 EB               [12]  905 	mov	a,r3
      007958 2D               [12]  906 	add	a, r5
      007959 12 37 D7         [24]  907 	lcall	_ak820_outline_0013
      00795C F8               [12]  908 	mov	r0,a
      00795D 08               [12]  909 	inc	r0
      00795E 12 7D 9F         [24]  910 	lcall	_ak820_outline_0060
      007961 80 0C            [24]  911 	sjmp	00109$
      007963                        912 00106$:
                                    913 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007963 EB               [12]  914 	mov	a,r3
      007964 2D               [12]  915 	add	a, r5
      007965 12 37 D7         [24]  916 	lcall	_ak820_outline_0013
      007968 F8               [12]  917 	mov	r0,a
      007969 60 04            [24]  918 	jz	00109$
      00796B 18               [12]  919 	dec	r0
      00796C 12 7D 9F         [24]  920 	lcall	_ak820_outline_0060
      00796F                        921 00109$:
                                    922 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      00796F EB               [12]  923 	mov	a,r3
      007970 2D               [12]  924 	add	a, r5
      007971 12 37 D7         [24]  925 	lcall	_ak820_outline_0013
      007974 60 0B            [24]  926 	jz	00118$
      007976 90 09 7C         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007979 E0               [24]  928 	movx	a,@dptr
      00797A FA               [12]  929 	mov	r2,a
      00797B 90 09 7B         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      00797E E0               [24]  931 	movx	a,@dptr
      00797F 4A               [12]  932 	orl	a,r2
      007980 F0               [24]  933 	movx	@dptr,a
      007981                        934 00118$:
                                    935 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007981 0B               [12]  936 	inc	r3
      007982 90 09 7C         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007985 E0               [24]  938 	movx	a,@dptr
      007986 25 E0            [12]  939 	add	a,acc
      007988 F0               [24]  940 	movx	@dptr,a
      007989 80 BC            [24]  941 	sjmp	00117$
      00798B                        942 00112$:
                                    943 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      00798B EE               [12]  944 	mov	a,r6
      00798C 60 09            [24]  945 	jz	00114$
      00798E 90 09 7B         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007991 E0               [24]  947 	movx	a,@dptr
      007992 90 09 70         [24]  948 	mov	dptr,#_owned_weak_mods
      007995 F0               [24]  949 	movx	@dptr,a
      007996 22               [24]  950 	ret
      007997                        951 00114$:
                                    952 ;	quantum/action_util.c:124: else owned_mods = result;
      007997 90 09 7B         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      00799A E0               [24]  954 	movx	a,@dptr
      00799B 90 09 6F         [24]  955 	mov	dptr,#_owned_mods
      00799E F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:125: }
      00799F 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      0079A0                        968 _add_owned_mods:
      0079A0 E5 82            [12]  969 	mov	a,dpl
      0079A2 90 09 7D         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      0079A5 12 7D BF         [24]  971 	lcall	_ak820_outline_0106
      0079A8 74 01            [12]  972 	mov	a,#0x01
      0079AA F0               [24]  973 	movx	@dptr,a
      0079AB 8F 82            [24]  974 	mov	dpl, r7
      0079AD 02 78 D1         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      0079B0                        985 _del_owned_mods:
      0079B0 E5 82            [12]  986 	mov	a,dpl
      0079B2 90 09 7E         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      0079B5 12 7D BF         [24]  988 	lcall	_ak820_outline_0106
      0079B8 E4               [12]  989 	clr	a
      0079B9 F0               [24]  990 	movx	@dptr,a
      0079BA 8F 82            [24]  991 	mov	dpl, r7
      0079BC 02 78 D1         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      0079BF                       1002 _add_owned_weak_mods:
      0079BF E5 82            [12] 1003 	mov	a,dpl
      0079C1 90 09 7F         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      0079C4 12 7D BF         [24] 1005 	lcall	_ak820_outline_0106
      0079C7 74 03            [12] 1006 	mov	a,#0x03
      0079C9 F0               [24] 1007 	movx	@dptr,a
      0079CA 8F 82            [24] 1008 	mov	dpl, r7
      0079CC 02 78 D1         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      0079CF                       1019 _del_owned_weak_mods:
      0079CF E5 82            [12] 1020 	mov	a,dpl
      0079D1 90 09 80         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      0079D4 12 7D BF         [24] 1022 	lcall	_ak820_outline_0106
      0079D7 74 02            [12] 1023 	mov	a,#0x02
      0079D9 F0               [24] 1024 	movx	@dptr,a
      0079DA 8F 82            [24] 1025 	mov	dpl, r7
      0079DC 02 78 D1         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      0079DF                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      0079DF 7F 00            [12] 1038 	mov	r7,#0x00
      0079E1                       1039 00103$:
      0079E1 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      0079E4                       1041 00122$:
      0079E4 50 1A            [24] 1042 	jnc	00101$
      0079E6 EF               [12] 1043 	mov	a,r7
      0079E7 24 5F            [12] 1044 	add	a, #_owned_mod_refs
      0079E9 FD               [12] 1045 	mov	r5,a
      0079EA E4               [12] 1046 	clr	a
      0079EB 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      0079ED FE               [12] 1048 	mov	r6,a
      0079EE EF               [12] 1049 	mov	a,r7
      0079EF 24 67            [12] 1050 	add	a, #_owned_weak_refs
      0079F1 F5 82            [12] 1051 	mov	dpl,a
      0079F3 E4               [12] 1052 	clr	a
      0079F4 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      0079F6 F5 83            [12] 1054 	mov	dph,a
      0079F8 E4               [12] 1055 	clr	a
      0079F9 F0               [24] 1056 	movx	@dptr,a
      0079FA 12 7D C6         [24] 1057 	lcall	_ak820_outline_0111
      0079FD 0F               [12] 1058 	inc	r7
      0079FE 80 E1            [24] 1059 	sjmp	00103$
      007A00                       1060 00101$:
                                   1061 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007A00 90 09 72         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007A03 E4               [12] 1063 	clr	a
      007A04 F0               [24] 1064 	movx	@dptr,a
      007A05 90 09 71         [24] 1065 	mov	dptr,#_macro_mods
      007A08 F0               [24] 1066 	movx	@dptr,a
      007A09 90 09 70         [24] 1067 	mov	dptr,#_owned_weak_mods
      007A0C F0               [24] 1068 	movx	@dptr,a
      007A0D 90 09 6F         [24] 1069 	mov	dptr,#_owned_mods
      007A10 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      007A11 90 09 74         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007A14 04               [12] 1073 	inc	a
      007A15 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:134: }
      007A16 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007A17                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007A17 7F 00            [12] 1089 	mov	r7,#0x00
      007A19                       1090 00104$:
      007A19 EF               [12] 1091 	mov	a,r7
      007A1A 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007A1C 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007A1E EF               [12] 1095 	mov	a,r7
      007A1F 24 81            [12] 1096 	add	a, #_key_refs
      007A21 F5 82            [12] 1097 	mov	dpl,a
      007A23 E4               [12] 1098 	clr	a
      007A24 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007A26 12 78 56         [24] 1100 	lcall	_ak820_outline_0150
      007A29 80 EE            [24] 1101 	sjmp	00104$
      007A2B                       1102 00101$:
                                   1103 ;	quantum/action_util.c:142: distinct_keys = 0;
      007A2B 90 0A 26         [24] 1104 	mov	dptr,#_distinct_keys
      007A2E E4               [12] 1105 	clr	a
      007A2F F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007A30 FF               [12] 1108 	mov	r7,a
      007A31                       1109 00107$:
      007A31 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007A34                       1111 00142$:
      007A34 50 0D            [24] 1112 	jnc	00109$
      007A36 EF               [12] 1113 	mov	a,r7
      007A37 24 27            [12] 1114 	add	a, #_macro_keys
      007A39 F5 82            [12] 1115 	mov	dpl,a
      007A3B E4               [12] 1116 	clr	a
      007A3C 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007A3E 12 78 56         [24] 1118 	lcall	_ak820_outline_0150
      007A41 80 EE            [24] 1119 	sjmp	00107$
      007A43                       1120 00109$:
                                   1121 ;	quantum/action_util.c:144: }
      007A43 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007A44                       1137 _add_owned_key:
      007A44 E5 82            [12] 1138 	mov	a,dpl
      007A46 90 0A 3C         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007A49 12 7D D7         [24] 1140 	lcall	_ak820_outline_0121
                                   1141 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007A4C 74 01            [12] 1142 	mov	a,#0x01
      007A4E F0               [24] 1143 	movx	@dptr,a
      007A4F 90 0A 27         [24] 1144 	mov	dptr,#_macro_keys
      007A52 C0 07            [24] 1145 	push	ar7
      007A54 12 78 65         [24] 1146 	lcall	_ak820_macro_change
      007A57 E5 82            [12] 1147 	mov	a, dpl
      007A59 D0 07            [24] 1148 	pop	ar7
      007A5B 70 03            [24] 1149 	jnz	00102$
      007A5D F5 82            [12] 1150 	mov	dpl,a
      007A5F 22               [24] 1151 	ret
      007A60                       1152 00102$:
                                   1153 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      007A60 12 7D 91         [24] 1154 	lcall	_ak820_outline_0027
      007A63 FC               [12] 1155 	mov	r4,a
      007A64 04               [12] 1156 	inc	a
      007A65 12 7D C6         [24] 1157 	lcall	_ak820_outline_0111
      007A68 EC               [12] 1158 	mov	a,r4
      007A69 60 04            [24] 1159 	jz	00104$
      007A6B 75 82 00         [24] 1160 	mov	dpl, #0x00
      007A6E 22               [24] 1161 	ret
      007A6F                       1162 00104$:
                                   1163 ;	quantum/action_util.c:148: ++distinct_keys;
      007A6F 90 0A 26         [24] 1164 	mov	dptr,#_distinct_keys
      007A72 E0               [24] 1165 	movx	a,@dptr
      007A73 24 01            [12] 1166 	add	a, #0x01
      007A75 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007A76 90 0D 73         [24] 1169 	mov	dptr,#_keyboard_protocol
      007A79 E0               [24] 1170 	movx	a,@dptr
      007A7A 60 11            [24] 1171 	jz	00106$
      007A7C 90 0A AB         [24] 1172 	mov	dptr,#_keymap_config
      007A7F E0               [24] 1173 	movx	a,@dptr
      007A80 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007A83 12 7D E2         [24] 1176 	lcall	_ak820_outline_0163
      007A86 12 6C EC         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007A89 75 82 01         [24] 1179 	mov	dpl, #0x01
      007A8C 22               [24] 1180 	ret
      007A8D                       1181 00106$:
                                   1182 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007A8D 90 0A 26         [24] 1183 	mov	dptr,#_distinct_keys
      007A90 E0               [24] 1184 	movx	a,@dptr
      007A91 24 F9            [12] 1185 	add	a,#0xff - 0x06
      007A93 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007A95 7F 00            [12] 1189 	mov	r7,#0x00
      007A97                       1190 00115$:
      007A97 BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      007A9A                       1192 00174$:
      007A9A 50 1E            [24] 1193 	jnc	00111$
      007A9C EF               [12] 1194 	mov	a,r7
      007A9D 24 88            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      007A9F F5 82            [12] 1196 	mov	dpl,a
      007AA1 E4               [12] 1197 	clr	a
      007AA2 34 0D            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007AA4 F5 83            [12] 1199 	mov	dph,a
      007AA6 74 01            [12] 1200 	mov	a,#0x01
      007AA8 F0               [24] 1201 	movx	@dptr,a
      007AA9 0F               [12] 1202 	inc	r7
      007AAA 80 EB            [24] 1203 	sjmp	00115$
      007AAC                       1204 00110$:
                                   1205 ;	quantum/action_util.c:154: } else add_key(code);
      007AAC 90 0A 3C         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      007AAF E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007AB0 90 07 F2         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      007AB3 F0               [24] 1210 	movx	@dptr,a
      007AB4 90 0D 86         [24] 1211 	mov	dptr,#_actual_keyboard_report
      007AB7 12 6C EC         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:154: } else add_key(code);
      007ABA                       1214 00111$:
                                   1215 ;	quantum/action_util.c:155: return true;
      007ABA 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:156: }
      007ABD 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      007ABE                       1235 _del_owned_key:
      007ABE E5 82            [12] 1236 	mov	a,dpl
      007AC0 90 0A 3D         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      007AC3 12 7D D7         [24] 1238 	lcall	_ak820_outline_0121
                                   1239 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007AC6 E4               [12] 1240 	clr	a
      007AC7 F0               [24] 1241 	movx	@dptr,a
      007AC8 90 0A 27         [24] 1242 	mov	dptr,#_macro_keys
      007ACB C0 07            [24] 1243 	push	ar7
      007ACD 12 78 65         [24] 1244 	lcall	_ak820_macro_change
      007AD0 E5 82            [12] 1245 	mov	a, dpl
      007AD2 D0 07            [24] 1246 	pop	ar7
      007AD4 70 03            [24] 1247 	jnz	00102$
      007AD6 F5 82            [12] 1248 	mov	dpl,a
      007AD8 22               [24] 1249 	ret
      007AD9                       1250 00102$:
                                   1251 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      007AD9 12 7D 91         [24] 1252 	lcall	_ak820_outline_0027
      007ADC FC               [12] 1253 	mov	r4,a
      007ADD 60 09            [24] 1254 	jz	00103$
      007ADF 1C               [12] 1255 	dec	r4
      007AE0 12 38 5D         [24] 1256 	lcall	_ak820_outline_0122
      007AE3 EC               [12] 1257 	mov	a,r4
      007AE4 F0               [24] 1258 	movx	@dptr,a
      007AE5 EC               [12] 1259 	mov	a,r4
      007AE6 60 04            [24] 1260 	jz	00104$
      007AE8                       1261 00103$:
      007AE8 75 82 00         [24] 1262 	mov	dpl, #0x00
      007AEB 22               [24] 1263 	ret
      007AEC                       1264 00104$:
                                   1265 ;	quantum/action_util.c:160: --distinct_keys;
      007AEC 90 0A 26         [24] 1266 	mov	dptr,#_distinct_keys
      007AEF E0               [24] 1267 	movx	a,@dptr
      007AF0 14               [12] 1268 	dec	a
      007AF1 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007AF2 90 0D 73         [24] 1271 	mov	dptr,#_keyboard_protocol
      007AF5 E0               [24] 1272 	movx	a,@dptr
      007AF6 60 16            [24] 1273 	jz	00107$
      007AF8 90 0A AB         [24] 1274 	mov	dptr,#_keymap_config
      007AFB E0               [24] 1275 	movx	a,@dptr
      007AFC 30 E7 0F         [24] 1276 	jnb	acc.7,00107$
                                   1277 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007AFF 90 07 F5         [24] 1278 	mov	dptr,#_del_key_from_report_PARM_2
      007B02 EF               [12] 1279 	mov	a,r7
      007B03 F0               [24] 1280 	movx	@dptr,a
      007B04 90 0D 86         [24] 1281 	mov	dptr,#_actual_keyboard_report
      007B07 12 6D 22         [24] 1282 	lcall	_del_key_from_report
                                   1283 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007B0A 75 82 01         [24] 1284 	mov	dpl, #0x01
      007B0D 22               [24] 1285 	ret
      007B0E                       1286 00107$:
                                   1287 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007B0E 90 0A 26         [24] 1288 	mov	dptr,#_distinct_keys
      007B11 E0               [24] 1289 	movx	a,@dptr
      007B12 FF               [12] 1290 	mov  r7,a
      007B13 24 F9            [12] 1291 	add	a,#0xff - 0x06
      007B15 50 04            [24] 1292 	jnc	00110$
                                   1293 ;	free result
      007B17 75 82 01         [24] 1294 	mov	dpl, #0x01
      007B1A 22               [24] 1295 	ret
      007B1B                       1296 00110$:
                                   1297 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007B1B BF 06 1F         [24] 1298 	cjne	r7,#0x06,00115$
                                   1299 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B1E 90 0D 86         [24] 1300 	mov	dptr,#_actual_keyboard_report
      007B21 12 6D 58         [24] 1301 	lcall	_clear_keys_from_report
                                   1302 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007B24 7F 04            [12] 1303 	mov	r7,#0x04
      007B26                       1304 00122$:
      007B26 EF               [12] 1305 	mov	a,r7
      007B27 24 5B            [12] 1306 	add	a,#0xff - 0xa4
      007B29 40 20            [24] 1307 	jc	00116$
                                   1308 ;	free result
      007B2B 12 7D 91         [24] 1309 	lcall	_ak820_outline_0027
      007B2E 60 0A            [24] 1310 	jz	00123$
                                   1311 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007B30 12 7D E2         [24] 1312 	lcall	_ak820_outline_0163
      007B33 C0 07            [24] 1313 	push	ar7
      007B35 12 6C EC         [24] 1314 	lcall	_add_key_to_report
      007B38 D0 07            [24] 1315 	pop	ar7
                                   1316 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007B3A                       1317 00123$:
      007B3A 0F               [12] 1318 	inc	r7
      007B3B 80 E9            [24] 1319 	sjmp	00122$
      007B3D                       1320 00115$:
                                   1321 ;	quantum/action_util.c:169: } else del_key(code);
      007B3D 90 0A 3D         [24] 1322 	mov	dptr,#_del_owned_key_code_10000_341
      007B40 E0               [24] 1323 	movx	a,@dptr
                                   1324 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007B41 90 07 F5         [24] 1325 	mov	dptr,#_del_key_from_report_PARM_2
      007B44 F0               [24] 1326 	movx	@dptr,a
      007B45 90 0D 86         [24] 1327 	mov	dptr,#_actual_keyboard_report
      007B48 12 6D 22         [24] 1328 	lcall	_del_key_from_report
                                   1329 ;	quantum/action_util.c:169: } else del_key(code);
      007B4B                       1330 00116$:
                                   1331 ;	quantum/action_util.c:170: return true;
      007B4B 75 82 01         [24] 1332 	mov	dpl, #0x01
                                   1333 ;	quantum/action_util.c:171: }
      007B4E 22               [24] 1334 	ret
                                   1335 ;------------------------------------------------------------
                                   1336 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1337 ;------------------------------------------------------------
                                   1338 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1339 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1340 ;------------------------------------------------------------
                                   1341 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function clear_owned_usages
                                   1344 ;	-----------------------------------------
      007B4F                       1345 _clear_owned_usages:
                                   1346 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007B4F 7F 00            [12] 1347 	mov	r7,#0x00
      007B51                       1348 00104$:
      007B51 BF 1E 00         [24] 1349 	cjne	r7,#0x1e,00141$
      007B54                       1350 00141$:
      007B54 50 14            [24] 1351 	jnc	00101$
      007B56 EF               [12] 1352 	mov	a,r7
      007B57 24 3E            [12] 1353 	add	a, #_usage_refs
      007B59 FD               [12] 1354 	mov	r5,a
      007B5A E4               [12] 1355 	clr	a
      007B5B 34 0A            [12] 1356 	addc	a, #(_usage_refs >> 8)
      007B5D FE               [12] 1357 	mov	r6,a
      007B5E EF               [12] 1358 	mov	a,r7
      007B5F 12 7D A6         [24] 1359 	lcall	_ak820_outline_0063
      007B62 E4               [12] 1360 	clr	a
      007B63 F0               [24] 1361 	movx	@dptr,a
      007B64 12 7D C6         [24] 1362 	lcall	_ak820_outline_0111
      007B67 0F               [12] 1363 	inc	r7
      007B68 80 E7            [24] 1364 	sjmp	00104$
      007B6A                       1365 00101$:
                                   1366 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      007B6A 90 0A 7B         [24] 1367 	mov	dptr,#(_usage_lengths + 0x0001)
      007B6D E4               [12] 1368 	clr	a
      007B6E F0               [24] 1369 	movx	@dptr,a
      007B6F 90 0A 7A         [24] 1370 	mov	dptr,#_usage_lengths
      007B72 F0               [24] 1371 	movx	@dptr,a
                                   1372 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007B73 FF               [12] 1373 	mov	r7,a
      007B74                       1374 00107$:
      007B74 BF 04 00         [24] 1375 	cjne	r7,#0x04,00143$
      007B77                       1376 00143$:
      007B77 50 0D            [24] 1377 	jnc	00109$
      007B79 EF               [12] 1378 	mov	a,r7
      007B7A 24 7C            [12] 1379 	add	a, #_macro_usages
      007B7C F5 82            [12] 1380 	mov	dpl,a
      007B7E E4               [12] 1381 	clr	a
      007B7F 34 0A            [12] 1382 	addc	a, #(_macro_usages >> 8)
      007B81 12 78 56         [24] 1383 	lcall	_ak820_outline_0150
      007B84 80 EE            [24] 1384 	sjmp	00107$
      007B86                       1385 00109$:
                                   1386 ;	quantum/action_util.c:185: }
      007B86 22               [24] 1387 	ret
                                   1388 ;------------------------------------------------------------
                                   1389 ;Allocation info for local variables in function 'owned_usage_key'
                                   1390 ;------------------------------------------------------------
                                   1391 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1392 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1393 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1394 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1395 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1396 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1397 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1398 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1399 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1400 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1401 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1402 ;------------------------------------------------------------
                                   1403 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1404 ;	-----------------------------------------
                                   1405 ;	 function owned_usage_key
                                   1406 ;	-----------------------------------------
      007B87                       1407 _owned_usage_key:
      007B87 E5 82            [12] 1408 	mov	a,dpl
      007B89 90 0A 81         [24] 1409 	mov	dptr,#_owned_usage_key_code_10000_368
      007B8C F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      007B8D E0               [24] 1412 	movx	a,@dptr
      007B8E FF               [12] 1413 	mov	r7,a
      007B8F BF A8 00         [24] 1414 	cjne	r7,#0xa8,00244$
      007B92                       1415 00244$:
      007B92 B3               [12] 1416 	cpl	c
      007B93 92 20            [24] 1417 	mov	_owned_usage_key_sloc0_1_0,c
      007B95 E4               [12] 1418 	clr	a
      007B96 33               [12] 1419 	rlc	a
      007B97 FF               [12] 1420 	mov	r7,a
      007B98 90 0A 84         [24] 1421 	mov	dptr,#_owned_usage_key_which_10000_369
      007B9B F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      007B9C EF               [12] 1424 	mov	a,r7
      007B9D 60 02            [24] 1425 	jz	00129$
      007B9F 74 03            [12] 1426 	mov	a,#0x03
      007BA1                       1427 00129$:
      007BA1 FE               [12] 1428 	mov	r6,a
                                   1429 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      007BA2 EF               [12] 1430 	mov	a,r7
      007BA3 24 7A            [12] 1431 	add	a, #_usage_lengths
      007BA5 FD               [12] 1432 	mov	r5,a
      007BA6 E4               [12] 1433 	clr	a
      007BA7 34 0A            [12] 1434 	addc	a, #(_usage_lengths >> 8)
      007BA9 FF               [12] 1435 	mov	r7,a
      007BAA 12 7D EB         [24] 1436 	lcall	_ak820_outline_0175
      007BAD E0               [24] 1437 	movx	a,@dptr
      007BAE FC               [12] 1438 	mov	r4,a
                                   1439 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      007BAF 90 0A 81         [24] 1440 	mov	dptr,#_owned_usage_key_code_10000_368
      007BB2 E0               [24] 1441 	movx	a,@dptr
      007BB3 24 5B            [12] 1442 	add	a,#0x5b
      007BB5 FB               [12] 1443 	mov	r3,a
                                   1444 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007BB6 90 0A 80         [24] 1445 	mov	dptr,#_owned_usage_key_PARM_2
      007BB9 E0               [24] 1446 	movx	a,@dptr
      007BBA FA               [12] 1447 	mov	r2,a
      007BBB 90 09 75         [24] 1448 	mov	dptr,#_ak820_macro_change_PARM_2
      007BBE EB               [12] 1449 	mov	a,r3
      007BBF F0               [24] 1450 	movx	@dptr,a
      007BC0 90 09 76         [24] 1451 	mov	dptr,#_ak820_macro_change_PARM_3
      007BC3 EA               [12] 1452 	mov	a,r2
      007BC4 F0               [24] 1453 	movx	@dptr,a
      007BC5 90 0A 7C         [24] 1454 	mov	dptr,#_macro_usages
      007BC8 C0 07            [24] 1455 	push	ar7
      007BCA C0 06            [24] 1456 	push	ar6
      007BCC C0 05            [24] 1457 	push	ar5
      007BCE C0 04            [24] 1458 	push	ar4
      007BD0 C0 03            [24] 1459 	push	ar3
      007BD2 C0 02            [24] 1460 	push	ar2
      007BD4 12 78 65         [24] 1461 	lcall	_ak820_macro_change
      007BD7 E5 82            [12] 1462 	mov	a, dpl
      007BD9 D0 02            [24] 1463 	pop	ar2
      007BDB D0 03            [24] 1464 	pop	ar3
      007BDD D0 04            [24] 1465 	pop	ar4
      007BDF D0 05            [24] 1466 	pop	ar5
      007BE1 D0 06            [24] 1467 	pop	ar6
      007BE3 D0 07            [24] 1468 	pop	ar7
      007BE5 70 01            [24] 1469 	jnz	00102$
      007BE7 22               [24] 1470 	ret
      007BE8                       1471 00102$:
                                   1472 ;	quantum/action_util.c:192: if (pressed) {
      007BE8 EA               [12] 1473 	mov	a,r2
      007BE9 60 1B            [24] 1474 	jz	00115$
                                   1475 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      007BEB 12 7D B0         [24] 1476 	lcall	_ak820_outline_0068
      007BEE 04               [12] 1477 	inc	a
      007BEF 12 6A 70         [24] 1478 	lcall	_ak820_outline_0127
      007BF2 E8               [12] 1479 	mov	a,r0
      007BF3 60 01            [24] 1480 	jz	00104$
      007BF5 22               [24] 1481 	ret
      007BF6                       1482 00104$:
                                   1483 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      007BF6 90 0A 85         [24] 1484 	mov	dptr,#_owned_usage_key_count_10000_369
      007BF9 EC               [12] 1485 	mov	a,r4
      007BFA 04               [12] 1486 	inc	a
      007BFB F0               [24] 1487 	movx	@dptr,a
      007BFC EC               [12] 1488 	mov	a,r4
      007BFD 2E               [12] 1489 	add	a, r6
      007BFE 12 7D A6         [24] 1490 	lcall	_ak820_outline_0063
      007C01 EB               [12] 1491 	mov	a,r3
      007C02 F0               [24] 1492 	movx	@dptr,a
      007C03 02 7C 67         [24] 1493 	ljmp	00116$
      007C06                       1494 00115$:
                                   1495 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      007C06 12 7D B0         [24] 1496 	lcall	_ak820_outline_0068
      007C09 60 07            [24] 1497 	jz	00105$
      007C0B 18               [12] 1498 	dec	r0
      007C0C 12 7D 9F         [24] 1499 	lcall	_ak820_outline_0060
      007C0F E8               [12] 1500 	mov	a,r0
      007C10 60 01            [24] 1501 	jz	00106$
      007C12                       1502 00105$:
      007C12 22               [24] 1503 	ret
      007C13                       1504 00106$:
                                   1505 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      007C13 7A 00            [12] 1506 	mov	r2,#0x00
      007C15                       1507 00108$:
      007C15 EA               [12] 1508 	mov	a,r2
      007C16 2E               [12] 1509 	add	a, r6
      007C17 12 7D A6         [24] 1510 	lcall	_ak820_outline_0063
      007C1A E0               [24] 1511 	movx	a,@dptr
      007C1B B5 03 02         [24] 1512 	cjne	a,ar3,00251$
      007C1E 80 03            [24] 1513 	sjmp	00167$
      007C20                       1514 00251$:
      007C20 0A               [12] 1515 	inc	r2
      007C21 80 F2            [24] 1516 	sjmp	00108$
      007C23                       1517 00167$:
      007C23 90 0A 86         [24] 1518 	mov	dptr,#_owned_usage_key_pos_30001_376
      007C26 EA               [12] 1519 	mov	a,r2
      007C27 F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	quantum/action_util.c:199: --count;
      007C28 1C               [12] 1522 	dec	r4
      007C29 90 0A 85         [24] 1523 	mov	dptr,#_owned_usage_key_count_10000_369
      007C2C EC               [12] 1524 	mov	a,r4
      007C2D F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007C2E 8A 03            [24] 1527 	mov	ar3,r2
      007C30                       1528 00125$:
      007C30 C3               [12] 1529 	clr	c
      007C31 EB               [12] 1530 	mov	a,r3
      007C32 9C               [12] 1531 	subb	a,r4
      007C33 50 23            [24] 1532 	jnc	00111$
      007C35 C0 05            [24] 1533 	push	ar5
      007C37 C0 07            [24] 1534 	push	ar7
      007C39 EB               [12] 1535 	mov	a,r3
      007C3A 2E               [12] 1536 	add	a, r6
      007C3B FA               [12] 1537 	mov	r2,a
      007C3C 24 5C            [12] 1538 	add	a, #_usage_order
      007C3E F8               [12] 1539 	mov	r0,a
      007C3F E4               [12] 1540 	clr	a
      007C40 34 0A            [12] 1541 	addc	a, #(_usage_order >> 8)
      007C42 F9               [12] 1542 	mov	r1,a
      007C43 0A               [12] 1543 	inc	r2
      007C44 EA               [12] 1544 	mov	a,r2
      007C45 33               [12] 1545 	rlc	a
      007C46 95 E0            [12] 1546 	subb	a,acc
      007C48 FF               [12] 1547 	mov	r7,a
      007C49 EA               [12] 1548 	mov	a,r2
      007C4A 12 7D CC         [24] 1549 	lcall	_ak820_outline_0115
      007C4D 12 38 6E         [24] 1550 	lcall	_ak820_outline_0144
      007C50 F0               [24] 1551 	movx	@dptr,a
      007C51 0B               [12] 1552 	inc	r3
      007C52 D0 07            [24] 1553 	pop	ar7
      007C54 D0 05            [24] 1554 	pop	ar5
      007C56 80 D8            [24] 1555 	sjmp	00125$
      007C58                       1556 00111$:
                                   1557 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      007C58 12 7D EB         [24] 1558 	lcall	_ak820_outline_0175
      007C5B EC               [12] 1559 	mov	a,r4
      007C5C F0               [24] 1560 	movx	@dptr,a
                                   1561 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      007C5D 90 0A 86         [24] 1562 	mov	dptr,#_owned_usage_key_pos_30001_376
      007C60 E0               [24] 1563 	movx	a,@dptr
      007C61 B5 04 02         [24] 1564 	cjne	a,ar4,00253$
      007C64 80 01            [24] 1565 	sjmp	00116$
      007C66                       1566 00253$:
      007C66 22               [24] 1567 	ret
      007C67                       1568 00116$:
                                   1569 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      007C67 90 0A 85         [24] 1570 	mov	dptr,#_owned_usage_key_count_10000_369
      007C6A E0               [24] 1571 	movx	a,@dptr
      007C6B FC               [12] 1572 	mov	r4,a
      007C6C 12 7D EB         [24] 1573 	lcall	_ak820_outline_0175
      007C6F F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007C70 EC               [12] 1576 	mov	a,r4
      007C71 60 15            [24] 1577 	jz	00131$
      007C73 EC               [12] 1578 	mov	a,r4
      007C74 2E               [12] 1579 	add	a, r6
      007C75 FE               [12] 1580 	mov	r6,a
      007C76 1E               [12] 1581 	dec	r6
      007C77 EE               [12] 1582 	mov	a,r6
      007C78 33               [12] 1583 	rlc	a
      007C79 95 E0            [12] 1584 	subb	a,acc
      007C7B FF               [12] 1585 	mov	r7,a
      007C7C EE               [12] 1586 	mov	a,r6
      007C7D 12 7D CC         [24] 1587 	lcall	_ak820_outline_0115
      007C80 24 A5            [12] 1588 	add	a,#0xa5
      007C82 FE               [12] 1589 	mov	r6,a
      007C83 33               [12] 1590 	rlc	a
      007C84 95 E0            [12] 1591 	subb	a,acc
      007C86 80 02            [24] 1592 	sjmp	00132$
      007C88                       1593 00131$:
      007C88 7E 00            [12] 1594 	mov	r6,#0x00
      007C8A                       1595 00132$:
      007C8A 90 0A 81         [24] 1596 	mov	dptr,#_owned_usage_key_code_10000_368
      007C8D EE               [12] 1597 	mov	a,r6
      007C8E F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007C8F 90 0A 84         [24] 1600 	mov	dptr,#_owned_usage_key_which_10000_369
      007C92 E0               [24] 1601 	movx	a,@dptr
      007C93 60 18            [24] 1602 	jz	00118$
      007C95 EE               [12] 1603 	mov	a,r6
      007C96 60 0B            [24] 1604 	jz	00133$
      007C98 8E 82            [24] 1605 	mov	dpl, r6
      007C9A 12 6B A9         [24] 1606 	lcall	_KEYCODE2CONSUMER
      007C9D AD 82            [24] 1607 	mov	r5, dpl
      007C9F AF 83            [24] 1608 	mov	r7, dph
      007CA1 80 04            [24] 1609 	sjmp	00134$
      007CA3                       1610 00133$:
      007CA3 7D 00            [12] 1611 	mov	r5,#0x00
      007CA5 7F 00            [12] 1612 	mov	r7,#0x00
      007CA7                       1613 00134$:
      007CA7 12 7D EB         [24] 1614 	lcall	_ak820_outline_0175
      007CAA 02 6B 63         [24] 1615 	ljmp	_host_consumer_send
      007CAD                       1616 00118$:
                                   1617 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007CAD EE               [12] 1618 	mov	a,r6
      007CAE 60 22            [24] 1619 	jz	00135$
                                   1620 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007CB0 BE A5 00         [24] 1621 	cjne	r6,#0xa5,00258$
      007CB3                       1622 00258$:
      007CB3 40 05            [24] 1623 	jc	00121$
      007CB5 EE               [12] 1624 	mov	a,r6
      007CB6 24 58            [12] 1625 	add	a,#0xff - 0xa7
      007CB8 50 08            [24] 1626 	jnc	00122$
                                   1627 ;	free result
      007CBA                       1628 00121$:
      007CBA 90 0A 82         [24] 1629 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007CBD 12 4D 8A         [24] 1630 	lcall	_ak820_outline_0157
      007CC0 80 09            [24] 1631 	sjmp	00123$
      007CC2                       1632 00122$:
                                   1633 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007CC2 74 DC            [12] 1634 	mov	a,#0xdc
      007CC4 2E               [12] 1635 	add	a, r6
      007CC5 90 0A 82         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007CC8 12 38 58         [24] 1637 	lcall	_ak820_outline_0114
                                   1638 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007CCB                       1639 00123$:
      007CCB 90 0A 82         [24] 1640 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007CCE E0               [24] 1641 	movx	a,@dptr
      007CCF FF               [12] 1642 	mov	r7,a
      007CD0 80 02            [24] 1643 	sjmp	00136$
      007CD2                       1644 00135$:
      007CD2 7F 00            [12] 1645 	mov	r7,#0x00
      007CD4                       1646 00136$:
      007CD4 7E 00            [12] 1647 	mov	r6,#0x00
      007CD6 12 43 3A         [24] 1648 	lcall	_ak820_outline_0145
                                   1649 ;	quantum/action_util.c:208: }
      007CD9 02 6B 33         [24] 1650 	ljmp	_host_system_send
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1653 ;------------------------------------------------------------
                                   1654 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1655 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1656 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1657 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1658 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1659 ;------------------------------------------------------------
                                   1660 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1661 ;	-----------------------------------------
                                   1662 ;	 function send_keyboard_report
                                   1663 ;	-----------------------------------------
      007CDC                       1664 _send_keyboard_report:
                                   1665 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      007CDC 90 0D 84         [24] 1666 	mov	dptr,#_real_mods
      007CDF E0               [24] 1667 	movx	a,@dptr
      007CE0 FF               [12] 1668 	mov	r7,a
      007CE1 90 0D 86         [24] 1669 	mov	dptr,#_actual_keyboard_report
      007CE4 F0               [24] 1670 	movx	@dptr,a
                                   1671 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      007CE5 90 0D 85         [24] 1672 	mov	dptr,#_weak_mods
      007CE8 E0               [24] 1673 	movx	a,@dptr
      007CE9 42 07            [12] 1674 	orl	ar7,a
      007CEB 90 0D 86         [24] 1675 	mov	dptr,#_actual_keyboard_report
      007CEE EF               [12] 1676 	mov	a,r7
      007CEF F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007CF0 90 09 70         [24] 1679 	mov	dptr,#_owned_weak_mods
      007CF3 E0               [24] 1680 	movx	a,@dptr
      007CF4 FE               [12] 1681 	mov	r6,a
      007CF5 90 09 6F         [24] 1682 	mov	dptr,#_owned_mods
      007CF8 E0               [24] 1683 	movx	a,@dptr
      007CF9 4E               [12] 1684 	orl	a,r6
      007CFA 42 07            [12] 1685 	orl	ar7,a
      007CFC 90 0D 86         [24] 1686 	mov	dptr,#_actual_keyboard_report
      007CFF EF               [12] 1687 	mov	a,r7
      007D00 F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:515: bool changed = false;
      007D01 90 0A A8         [24] 1690 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D04 E4               [12] 1691 	clr	a
      007D05 F0               [24] 1692 	movx	@dptr,a
                                   1693 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1694 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1695 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D06 FF               [12] 1696 	mov	r7,a
      007D07                       1697 00107$:
      007D07 BF 20 00         [24] 1698 	cjne	r7,#0x20,00140$
      007D0A                       1699 00140$:
      007D0A 50 2A            [24] 1700 	jnc	00103$
                                   1701 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      007D0C EF               [12] 1702 	mov	a,r7
      007D0D 24 88            [12] 1703 	add	a, #_send_keyboard_report_last_report_10001_388
      007D0F FD               [12] 1704 	mov	r5,a
      007D10 E4               [12] 1705 	clr	a
      007D11 34 0A            [12] 1706 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007D13 12 46 FB         [24] 1707 	lcall	_ak820_outline_0053
      007D16 EF               [12] 1708 	mov	a,r7
      007D17 24 86            [12] 1709 	add	a, #_actual_keyboard_report
      007D19 F5 82            [12] 1710 	mov	dpl,a
      007D1B E4               [12] 1711 	clr	a
      007D1C 34 0D            [12] 1712 	addc	a, #(_actual_keyboard_report >> 8)
      007D1E F5 83            [12] 1713 	mov	dph,a
      007D20 E0               [24] 1714 	movx	a,@dptr
      007D21 FB               [12] 1715 	mov	r3,a
      007D22 EC               [12] 1716 	mov	a,r4
      007D23 B5 03 02         [24] 1717 	cjne	a,ar3,00142$
      007D26 80 0B            [24] 1718 	sjmp	00108$
      007D28                       1719 00142$:
                                   1720 ;	quantum/action_util.c:525: dest[i] = src[i];
      007D28 12 38 5D         [24] 1721 	lcall	_ak820_outline_0122
      007D2B EB               [12] 1722 	mov	a,r3
      007D2C F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action_util.c:526: changed = true;
      007D2D 90 0A A8         [24] 1725 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D30 74 01            [12] 1726 	mov	a,#0x01
      007D32 F0               [24] 1727 	movx	@dptr,a
      007D33                       1728 00108$:
                                   1729 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D33 0F               [12] 1730 	inc	r7
      007D34 80 D1            [24] 1731 	sjmp	00107$
      007D36                       1732 00103$:
                                   1733 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      007D36 90 0A A8         [24] 1734 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D39 E0               [24] 1735 	movx	a,@dptr
      007D3A 60 09            [24] 1736 	jz	00109$
      007D3C 90 0D 86         [24] 1737 	mov	dptr,#_actual_keyboard_report
      007D3F 75 F0 00         [24] 1738 	mov	b, #0x00
                                   1739 ;	quantum/action_util.c:538: }
      007D42 02 6A A8         [24] 1740 	ljmp	_host_keyboard_send
      007D45                       1741 00109$:
      007D45 22               [24] 1742 	ret
                                   1743 ;------------------------------------------------------------
                                   1744 ;Allocation info for local variables in function 'get_mods'
                                   1745 ;------------------------------------------------------------
                                   1746 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1747 ;	-----------------------------------------
                                   1748 ;	 function get_mods
                                   1749 ;	-----------------------------------------
      007D46                       1750 _get_mods:
      007D46 C0 07            [24] 1751 	push	ar7
                                   1752 ;	quantum/action_util.c:549: ;
      007D48 90 09 6F         [24] 1753 	mov	dptr,#_owned_mods
      007D4B E0               [24] 1754 	movx	a,@dptr
      007D4C FF               [12] 1755 	mov	r7,a
      007D4D 90 0D 84         [24] 1756 	mov	dptr,#_real_mods
      007D50 12 78 50         [24] 1757 	lcall	_ak820_outline_0130
                                   1758 ;	quantum/action_util.c:550: }
      007D53 D0 07            [24] 1759 	pop	ar7
      007D55 22               [24] 1760 	ret
                                   1761 ;------------------------------------------------------------
                                   1762 ;Allocation info for local variables in function 'add_mods'
                                   1763 ;------------------------------------------------------------
                                   1764 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function clear_mods
                                   1769 ;	-----------------------------------------
      007D56                       1770 _clear_mods:
                                   1771 ;	quantum/action_util.c:577: real_mods = 0;
      007D56 90 0D 84         [24] 1772 	mov	dptr,#_real_mods
      007D59 E4               [12] 1773 	clr	a
      007D5A F0               [24] 1774 	movx	@dptr,a
                                   1775 ;	quantum/action_util.c:578: }
      007D5B 22               [24] 1776 	ret
                                   1777 ;------------------------------------------------------------
                                   1778 ;Allocation info for local variables in function 'get_weak_mods'
                                   1779 ;------------------------------------------------------------
                                   1780 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1781 ;	-----------------------------------------
                                   1782 ;	 function get_weak_mods
                                   1783 ;	-----------------------------------------
      007D5C                       1784 _get_weak_mods:
      007D5C C0 07            [24] 1785 	push	ar7
                                   1786 ;	quantum/action_util.c:589: ;
      007D5E 90 09 70         [24] 1787 	mov	dptr,#_owned_weak_mods
      007D61 E0               [24] 1788 	movx	a,@dptr
      007D62 FF               [12] 1789 	mov	r7,a
      007D63 90 0D 85         [24] 1790 	mov	dptr,#_weak_mods
      007D66 12 78 50         [24] 1791 	lcall	_ak820_outline_0130
                                   1792 ;	quantum/action_util.c:590: }
      007D69 D0 07            [24] 1793 	pop	ar7
      007D6B 22               [24] 1794 	ret
                                   1795 ;------------------------------------------------------------
                                   1796 ;Allocation info for local variables in function 'add_weak_mods'
                                   1797 ;------------------------------------------------------------
                                   1798 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1799 ;------------------------------------------------------------
                                   1800 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1801 ;	-----------------------------------------
                                   1802 ;	 function add_weak_mods
                                   1803 ;	-----------------------------------------
      007D6C                       1804 _add_weak_mods:
      007D6C E5 82            [12] 1805 	mov	a,dpl
      007D6E 90 0A A9         [24] 1806 	mov	dptr,#_add_weak_mods_mods_10000_406
      007D71 F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	quantum/action_util.c:596: weak_mods |= mods;
      007D72 E0               [24] 1809 	movx	a,@dptr
      007D73 FF               [12] 1810 	mov	r7,a
      007D74 90 0D 85         [24] 1811 	mov	dptr,#_weak_mods
      007D77 E0               [24] 1812 	movx	a,@dptr
      007D78 4F               [12] 1813 	orl	a,r7
      007D79 F0               [24] 1814 	movx	@dptr,a
                                   1815 ;	quantum/action_util.c:597: }
      007D7A 22               [24] 1816 	ret
                                   1817 ;------------------------------------------------------------
                                   1818 ;Allocation info for local variables in function 'del_weak_mods'
                                   1819 ;------------------------------------------------------------
                                   1820 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1821 ;------------------------------------------------------------
                                   1822 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1823 ;	-----------------------------------------
                                   1824 ;	 function del_weak_mods
                                   1825 ;	-----------------------------------------
      007D7B                       1826 _del_weak_mods:
      007D7B E5 82            [12] 1827 	mov	a,dpl
      007D7D 90 0A AA         [24] 1828 	mov	dptr,#_del_weak_mods_mods_10000_408
      007D80 F0               [24] 1829 	movx	@dptr,a
                                   1830 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      007D81 E0               [24] 1831 	movx	a,@dptr
      007D82 F4               [12] 1832 	cpl	a
      007D83 FF               [12] 1833 	mov	r7,a
      007D84 90 0D 85         [24] 1834 	mov	dptr,#_weak_mods
      007D87 E0               [24] 1835 	movx	a,@dptr
      007D88 5F               [12] 1836 	anl	a,r7
      007D89 F0               [24] 1837 	movx	@dptr,a
                                   1838 ;	quantum/action_util.c:604: }
      007D8A 22               [24] 1839 	ret
                                   1840 ;------------------------------------------------------------
                                   1841 ;Allocation info for local variables in function 'set_weak_mods'
                                   1842 ;------------------------------------------------------------
                                   1843 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1844 ;------------------------------------------------------------
                                   1845 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1846 ;	-----------------------------------------
                                   1847 ;	 function clear_weak_mods
                                   1848 ;	-----------------------------------------
      007D8B                       1849 _clear_weak_mods:
                                   1850 ;	quantum/action_util.c:617: weak_mods = 0;
      007D8B 90 0D 85         [24] 1851 	mov	dptr,#_weak_mods
      007D8E E4               [12] 1852 	clr	a
      007D8F F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/action_util.c:618: }
      007D90 22               [24] 1855 	ret
                                   1856 ;------------------------------------------------------------
                                   1857 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1858 ;------------------------------------------------------------
                                   1859 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1860 ;------------------------------------------------------------
                                   1861 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1862 ;	-----------------------------------------
                                   1863 	.area CSEG    (CODE)
                                   1864 	.area CONST   (CODE)
                                   1865 	.area XINIT   (CODE)
      00BC23                       1866 __xinit__real_mods:
      00BC23 00                    1867 	.db #0x00	; 0
      00BC24                       1868 __xinit__weak_mods:
      00BC24 00                    1869 	.db #0x00	; 0
      00BC25                       1870 __xinit__actual_keyboard_report:
      00BC25 00                    1871 	.db #0x00	; 0
      00BC26 00                    1872 	.db #0x00	; 0
      00BC27 00                    1873 	.db #0x00	; 0
      00BC28 00                    1874 	.db #0x00	; 0
      00BC29 00                    1875 	.db #0x00	; 0
      00BC2A 00                    1876 	.db #0x00	; 0
      00BC2B 00                    1877 	.db #0x00	; 0
      00BC2C 00                    1878 	.db #0x00	; 0
      00BC2D 00                    1879 	.db 0x00
      00BC2E 00                    1880 	.db 0x00
      00BC2F 00                    1881 	.db 0x00
      00BC30 00                    1882 	.db 0x00
      00BC31 00                    1883 	.db 0x00
      00BC32 00                    1884 	.db 0x00
      00BC33 00                    1885 	.db 0x00
      00BC34 00                    1886 	.db 0x00
      00BC35 00                    1887 	.db 0x00
      00BC36 00                    1888 	.db 0x00
      00BC37 00                    1889 	.db 0x00
      00BC38 00                    1890 	.db 0x00
      00BC39 00                    1891 	.db 0x00
      00BC3A 00                    1892 	.db 0x00
      00BC3B 00                    1893 	.db 0x00
      00BC3C 00                    1894 	.db 0x00
      00BC3D 00                    1895 	.db 0x00
      00BC3E 00                    1896 	.db 0x00
      00BC3F 00                    1897 	.db 0x00
      00BC40 00                    1898 	.db 0x00
      00BC41 00                    1899 	.db 0x00
      00BC42 00                    1900 	.db 0x00
      00BC43 00                    1901 	.db 0x00
      00BC44 00                    1902 	.db 0x00
                                   1903 	.area CABS    (ABS,CODE)
                                   1904 
                                   1905 ; Experimental exact instruction outlining.
                                   1906 	.globl _ak820_outline_0013
                                   1907 	.globl _ak820_outline_0027
                                   1908 	.globl _ak820_outline_0051
                                   1909 	.globl _ak820_outline_0053
                                   1910 	.globl _ak820_outline_0057
                                   1911 	.globl _ak820_outline_0059
                                   1912 	.globl _ak820_outline_0060
                                   1913 	.globl _ak820_outline_0063
                                   1914 	.globl _ak820_outline_0068
                                   1915 	.globl _ak820_outline_0098
                                   1916 	.globl _ak820_outline_0099
                                   1917 	.globl _ak820_outline_0106
                                   1918 	.globl _ak820_outline_0111
                                   1919 	.globl _ak820_outline_0113
                                   1920 	.globl _ak820_outline_0114
                                   1921 	.globl _ak820_outline_0115
                                   1922 	.globl _ak820_outline_0121
                                   1923 	.globl _ak820_outline_0122
                                   1924 	.globl _ak820_outline_0127
                                   1925 	.globl _ak820_outline_0130
                                   1926 	.globl _ak820_outline_0144
                                   1927 	.globl _ak820_outline_0145
                                   1928 	.globl _ak820_outline_0150
                                   1929 	.globl _ak820_outline_0157
                                   1930 	.globl _ak820_outline_0163
                                   1931 	.globl _ak820_outline_0174
                                   1932 	.globl _ak820_outline_0175
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0027
      007D91                       1936 _ak820_outline_0027:
      007D91 EF               [12] 1937 	mov	a,r7
      007D92 24 81            [12] 1938 	add	a,#_key_refs
      007D94 FD               [12] 1939 	mov	r5,a
      007D95 E4               [12] 1940 	clr	a
      007D96 34 09            [12] 1941 	addc	a,#(_key_refs>>8)
      007D98 FE               [12] 1942 	mov	r6,a
      007D99 8D 82            [24] 1943 	mov	dpl,r5
      007D9B 8E 83            [24] 1944 	mov	dph,r6
      007D9D E0               [24] 1945 	movx	a,@dptr
      007D9E 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0060
      007D9F                       1950 _ak820_outline_0060:
      007D9F 89 82            [24] 1951 	mov	dpl,r1
      007DA1 8A 83            [24] 1952 	mov	dph,r2
      007DA3 E8               [12] 1953 	mov	a,r0
      007DA4 F0               [24] 1954 	movx	@dptr,a
      007DA5 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0063
      007DA6                       1959 _ak820_outline_0063:
      007DA6 24 5C            [12] 1960 	add	a,#_usage_order
      007DA8 F5 82            [12] 1961 	mov	dpl,a
      007DAA E4               [12] 1962 	clr	a
      007DAB 34 0A            [12] 1963 	addc	a,#(_usage_order>>8)
      007DAD F5 83            [12] 1964 	mov	dph,a
      007DAF 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0068
      007DB0                       1969 _ak820_outline_0068:
      007DB0 EB               [12] 1970 	mov	a,r3
      007DB1 24 3E            [12] 1971 	add	a,#_usage_refs
      007DB3 F9               [12] 1972 	mov	r1,a
      007DB4 E4               [12] 1973 	clr	a
      007DB5 34 0A            [12] 1974 	addc	a,#(_usage_refs>>8)
      007DB7 FA               [12] 1975 	mov	r2,a
      007DB8 89 82            [24] 1976 	mov	dpl,r1
      007DBA 8A 83            [24] 1977 	mov	dph,r2
      007DBC E0               [24] 1978 	movx	a,@dptr
      007DBD F8               [12] 1979 	mov	r0,a
      007DBE 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0106
      007DBF                       1984 _ak820_outline_0106:
      007DBF F0               [24] 1985 	movx	@dptr,a
      007DC0 E0               [24] 1986 	movx	a,@dptr
      007DC1 FF               [12] 1987 	mov	r7,a
      007DC2 90 09 79         [24] 1988 	mov	dptr,#_change_owned_PARM_2
      007DC5 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0111
      007DC6                       1993 _ak820_outline_0111:
      007DC6 8D 82            [24] 1994 	mov	dpl,r5
      007DC8 8E 83            [24] 1995 	mov	dph,r6
      007DCA F0               [24] 1996 	movx	@dptr,a
      007DCB 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0115
      007DCC                       2001 _ak820_outline_0115:
      007DCC 24 5C            [12] 2002 	add	a,#_usage_order
      007DCE F5 82            [12] 2003 	mov	dpl,a
      007DD0 EF               [12] 2004 	mov	a,r7
      007DD1 34 0A            [12] 2005 	addc	a,#(_usage_order>>8)
      007DD3 F5 83            [12] 2006 	mov	dph,a
      007DD5 E0               [24] 2007 	movx	a,@dptr
      007DD6 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0121
      007DD7                       2012 _ak820_outline_0121:
      007DD7 F0               [24] 2013 	movx	@dptr,a
      007DD8 E0               [24] 2014 	movx	a,@dptr
      007DD9 FF               [12] 2015 	mov	r7,a
      007DDA 90 09 75         [24] 2016 	mov	dptr,#_ak820_macro_change_PARM_2
      007DDD F0               [24] 2017 	movx	@dptr,a
      007DDE 90 09 76         [24] 2018 	mov	dptr,#_ak820_macro_change_PARM_3
      007DE1 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0163
      007DE2                       2023 _ak820_outline_0163:
      007DE2 90 07 F2         [24] 2024 	mov	dptr,#_add_key_to_report_PARM_2
      007DE5 EF               [12] 2025 	mov	a,r7
      007DE6 F0               [24] 2026 	movx	@dptr,a
      007DE7 90 0D 86         [24] 2027 	mov	dptr,#_actual_keyboard_report
      007DEA 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0175
      007DEB                       2032 _ak820_outline_0175:
      007DEB 8D 82            [24] 2033 	mov	dpl,r5
      007DED 8F 83            [24] 2034 	mov	dph,r7
      007DEF 22               [24] 2035 	ret
