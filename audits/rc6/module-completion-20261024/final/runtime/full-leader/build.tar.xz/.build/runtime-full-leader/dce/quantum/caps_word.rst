                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module caps_word
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _caps_word_press_user
                                     12 	.globl _del_weak_mods
                                     13 	.globl _add_weak_mods
                                     14 	.globl _clear_mods
                                     15 	.globl _send_keyboard_report
                                     16 	.globl _timer_read
                                     17 	.globl _ADC_START
                                     18 	.globl _S0_R_FIFO
                                     19 	.globl _S0_T_FIFO
                                     20 	.globl _S0_FREE
                                     21 	.globl _S0_IF_BYTE
                                     22 	.globl _S0_IF_FIRST
                                     23 	.globl _S0_IF_OV
                                     24 	.globl _S0_FST_ACT
                                     25 	.globl _CP_RL2
                                     26 	.globl _C_T2
                                     27 	.globl _TR2
                                     28 	.globl _EXEN2
                                     29 	.globl _TCLK
                                     30 	.globl _RCLK
                                     31 	.globl _EXF2
                                     32 	.globl _CAP1F
                                     33 	.globl _TF2
                                     34 	.globl _RI
                                     35 	.globl _TI
                                     36 	.globl _RB8
                                     37 	.globl _TB8
                                     38 	.globl _REN
                                     39 	.globl _SM2
                                     40 	.globl _SM1
                                     41 	.globl _SM0
                                     42 	.globl _IT0
                                     43 	.globl _IE0
                                     44 	.globl _IT1
                                     45 	.globl _IE1
                                     46 	.globl _TR0
                                     47 	.globl _TF0
                                     48 	.globl _TR1
                                     49 	.globl _TF1
                                     50 	.globl _P4_0
                                     51 	.globl _P4_1
                                     52 	.globl _P4_2
                                     53 	.globl _P4_3
                                     54 	.globl _P4_4
                                     55 	.globl _P4_5
                                     56 	.globl _P4_6
                                     57 	.globl _RXD
                                     58 	.globl _TXD
                                     59 	.globl _INT0
                                     60 	.globl _INT1
                                     61 	.globl _T0
                                     62 	.globl _T1
                                     63 	.globl _MOSI1
                                     64 	.globl _MISO1
                                     65 	.globl _SCK1
                                     66 	.globl _P3_0
                                     67 	.globl _P3_1
                                     68 	.globl _P3_2
                                     69 	.globl _P3_3
                                     70 	.globl _P3_4
                                     71 	.globl _P3_5
                                     72 	.globl _P3_6
                                     73 	.globl _P3_7
                                     74 	.globl _CAP1_
                                     75 	.globl _T2_
                                     76 	.globl _CAP2_
                                     77 	.globl _T2EX_
                                     78 	.globl _RXD1
                                     79 	.globl _TXD1
                                     80 	.globl _P2_0
                                     81 	.globl _P2_1
                                     82 	.globl _P2_2
                                     83 	.globl _P2_3
                                     84 	.globl _P2_4
                                     85 	.globl _P2_5
                                     86 	.globl _P2_6
                                     87 	.globl _P2_7
                                     88 	.globl _AIN0
                                     89 	.globl _AIN1
                                     90 	.globl _AIN2
                                     91 	.globl _AIN3
                                     92 	.globl _AIN4
                                     93 	.globl _AIN5
                                     94 	.globl _AIN6
                                     95 	.globl _AIN7
                                     96 	.globl _CAP1
                                     97 	.globl _T2
                                     98 	.globl _CAP2
                                     99 	.globl _T2EX
                                    100 	.globl _INT0_
                                    101 	.globl _SCS
                                    102 	.globl _MOSI
                                    103 	.globl _MISO
                                    104 	.globl _SCK
                                    105 	.globl _RXD1_
                                    106 	.globl _TXD1_
                                    107 	.globl _P1_0
                                    108 	.globl _P1_1
                                    109 	.globl _P1_2
                                    110 	.globl _P1_3
                                    111 	.globl _P1_4
                                    112 	.globl _P1_5
                                    113 	.globl _P1_6
                                    114 	.globl _P1_7
                                    115 	.globl _AIN8
                                    116 	.globl _AIN9
                                    117 	.globl _AIN10
                                    118 	.globl _AIN11
                                    119 	.globl _AIN12
                                    120 	.globl _AIN13
                                    121 	.globl _RXD_
                                    122 	.globl _TXD_
                                    123 	.globl _SCL0
                                    124 	.globl _SDA0
                                    125 	.globl _P0_0
                                    126 	.globl _P0_1
                                    127 	.globl _P0_2
                                    128 	.globl _P0_3
                                    129 	.globl _P0_4
                                    130 	.globl _P0_5
                                    131 	.globl _P0_6
                                    132 	.globl _P0_7
                                    133 	.globl _IE_SPI0
                                    134 	.globl _IE_USB
                                    135 	.globl _IE_ADC
                                    136 	.globl _IE_UART1
                                    137 	.globl _IE_PWM_I2C
                                    138 	.globl _IE_GPIO
                                    139 	.globl _IE_WDOG
                                    140 	.globl _PX0
                                    141 	.globl _PT0
                                    142 	.globl _PX1
                                    143 	.globl _PT1
                                    144 	.globl _PS
                                    145 	.globl _PT2
                                    146 	.globl _PL_FLAG
                                    147 	.globl _PH_FLAG
                                    148 	.globl _EX0
                                    149 	.globl _ET0
                                    150 	.globl _EX1
                                    151 	.globl _ET1
                                    152 	.globl _ES
                                    153 	.globl _ET2
                                    154 	.globl _E_DIS
                                    155 	.globl _EA
                                    156 	.globl _P
                                    157 	.globl _F1
                                    158 	.globl _OV
                                    159 	.globl _RS0
                                    160 	.globl _RS1
                                    161 	.globl _F0
                                    162 	.globl _AC
                                    163 	.globl _CY
                                    164 	.globl _I2CS_INT_ST
                                    165 	.globl _I2CX_INT
                                    166 	.globl _LED_STATUS
                                    167 	.globl _LED_DMA_H
                                    168 	.globl _LED_DMA_L
                                    169 	.globl _LED_DMA
                                    170 	.globl _LED_PWM_OE
                                    171 	.globl _LED_COMMON
                                    172 	.globl _ADC_CHAN
                                    173 	.globl _ADC_DAT_H
                                    174 	.globl _ADC_DAT_L
                                    175 	.globl _ADC_DAT
                                    176 	.globl _ADC_CTRL
                                    177 	.globl _SPI1_CK_SE
                                    178 	.globl _SPI1_CTRL
                                    179 	.globl _SPI1_DATA
                                    180 	.globl _SPI1_STAT
                                    181 	.globl _SIF1
                                    182 	.globl _SBAUD1
                                    183 	.globl _SBUF1
                                    184 	.globl _SCON1
                                    185 	.globl _SPI0_SETUP
                                    186 	.globl _SPI0_CK_SE
                                    187 	.globl _SPI0_CTRL
                                    188 	.globl _SPI0_DATA
                                    189 	.globl _SPI0_STAT
                                    190 	.globl _T2CAP1H
                                    191 	.globl _T2CAP1L
                                    192 	.globl _T2CAP1
                                    193 	.globl _TH2
                                    194 	.globl _TL2
                                    195 	.globl _T2COUNT
                                    196 	.globl _RCAP2H
                                    197 	.globl _RCAP2L
                                    198 	.globl _RCAP2
                                    199 	.globl _T2MOD
                                    200 	.globl _T2CON
                                    201 	.globl _SBUF
                                    202 	.globl _SCON
                                    203 	.globl _TH1
                                    204 	.globl _TH0
                                    205 	.globl _TL1
                                    206 	.globl _TL0
                                    207 	.globl _TMOD
                                    208 	.globl _TCON
                                    209 	.globl _XBUS_AUX
                                    210 	.globl _P7
                                    211 	.globl _P6_DIR
                                    212 	.globl _P6_OUT_PU
                                    213 	.globl _P6_IN
                                    214 	.globl _P5_DIR
                                    215 	.globl _P5_OUT_PU
                                    216 	.globl _P5_IN
                                    217 	.globl _P4_LED_KEY
                                    218 	.globl _P4_DIR_PU
                                    219 	.globl _P4_MOD_OC
                                    220 	.globl _P4
                                    221 	.globl _P3_DIR_PU
                                    222 	.globl _P3_MOD_OC
                                    223 	.globl _P3
                                    224 	.globl _P2_DIR_PU
                                    225 	.globl _P2_MOD_OC
                                    226 	.globl _P2
                                    227 	.globl _P1_DIR_PU
                                    228 	.globl _P1_MOD_OC
                                    229 	.globl _P1
                                    230 	.globl _P0_DIR_PU
                                    231 	.globl _P0_MOD_OC
                                    232 	.globl _P0
                                    233 	.globl _ROM_CTRL
                                    234 	.globl _ROM_DATA_HH
                                    235 	.globl _ROM_DATA_HL
                                    236 	.globl _ROM_DATA_HI
                                    237 	.globl _ROM_ADDR_H
                                    238 	.globl _ROM_ADDR_L
                                    239 	.globl _ROM_ADDR
                                    240 	.globl _GPIO_IE
                                    241 	.globl _IP_EX
                                    242 	.globl _IE_EX
                                    243 	.globl _IP
                                    244 	.globl _IE
                                    245 	.globl _WDOG_COUNT
                                    246 	.globl _RESET_KEEP
                                    247 	.globl _WAKE_CTRL
                                    248 	.globl _CLOCK_CFG
                                    249 	.globl _POWER_CFG
                                    250 	.globl _PCON
                                    251 	.globl _GLOBAL_CFG
                                    252 	.globl _SAFE_MOD
                                    253 	.globl _DPH
                                    254 	.globl _DPL
                                    255 	.globl _SP
                                    256 	.globl _A_INV
                                    257 	.globl _B
                                    258 	.globl _ACC
                                    259 	.globl _PSW
                                    260 	.globl _caps_word_task
                                    261 	.globl _caps_word_reset_idle_timer
                                    262 	.globl _caps_word_on
                                    263 	.globl _caps_word_off
                                    264 	.globl _caps_word_toggle
                                    265 	.globl _is_caps_word_on
                                    266 	.globl _caps_word_set_user
                                    267 ;--------------------------------------------------------
                                    268 ; special function registers
                                    269 ;--------------------------------------------------------
                                    270 	.area RSEG    (ABS,DATA)
      000000                        271 	.org 0x0000
                           0000D0   272 _PSW	=	0x00d0
                           0000E0   273 _ACC	=	0x00e0
                           0000F0   274 _B	=	0x00f0
                           0000FD   275 _A_INV	=	0x00fd
                           000081   276 _SP	=	0x0081
                           000082   277 _DPL	=	0x0082
                           000083   278 _DPH	=	0x0083
                           0000A1   279 _SAFE_MOD	=	0x00a1
                           0000B1   280 _GLOBAL_CFG	=	0x00b1
                           000087   281 _PCON	=	0x0087
                           0000BA   282 _POWER_CFG	=	0x00ba
                           0000B9   283 _CLOCK_CFG	=	0x00b9
                           0000A9   284 _WAKE_CTRL	=	0x00a9
                           0000FE   285 _RESET_KEEP	=	0x00fe
                           0000FF   286 _WDOG_COUNT	=	0x00ff
                           0000A8   287 _IE	=	0x00a8
                           0000B8   288 _IP	=	0x00b8
                           0000E8   289 _IE_EX	=	0x00e8
                           0000E9   290 _IP_EX	=	0x00e9
                           0000B2   291 _GPIO_IE	=	0x00b2
                           008584   292 _ROM_ADDR	=	0x8584
                           000084   293 _ROM_ADDR_L	=	0x0084
                           000085   294 _ROM_ADDR_H	=	0x0085
                           008F8E   295 _ROM_DATA_HI	=	0x8f8e
                           00008E   296 _ROM_DATA_HL	=	0x008e
                           00008F   297 _ROM_DATA_HH	=	0x008f
                           000086   298 _ROM_CTRL	=	0x0086
                           000080   299 _P0	=	0x0080
                           0000C4   300 _P0_MOD_OC	=	0x00c4
                           0000C5   301 _P0_DIR_PU	=	0x00c5
                           000090   302 _P1	=	0x0090
                           000092   303 _P1_MOD_OC	=	0x0092
                           000093   304 _P1_DIR_PU	=	0x0093
                           0000A0   305 _P2	=	0x00a0
                           000094   306 _P2_MOD_OC	=	0x0094
                           000095   307 _P2_DIR_PU	=	0x0095
                           0000B0   308 _P3	=	0x00b0
                           000096   309 _P3_MOD_OC	=	0x0096
                           000097   310 _P3_DIR_PU	=	0x0097
                           0000C0   311 _P4	=	0x00c0
                           0000C2   312 _P4_MOD_OC	=	0x00c2
                           0000C3   313 _P4_DIR_PU	=	0x00c3
                           0000C1   314 _P4_LED_KEY	=	0x00c1
                           0000AA   315 _P5_IN	=	0x00aa
                           0000AB   316 _P5_OUT_PU	=	0x00ab
                           0000AC   317 _P5_DIR	=	0x00ac
                           0000AD   318 _P6_IN	=	0x00ad
                           0000AE   319 _P6_OUT_PU	=	0x00ae
                           0000AF   320 _P6_DIR	=	0x00af
                           0000F1   321 _P7	=	0x00f1
                           0000A2   322 _XBUS_AUX	=	0x00a2
                           000088   323 _TCON	=	0x0088
                           000089   324 _TMOD	=	0x0089
                           00008A   325 _TL0	=	0x008a
                           00008B   326 _TL1	=	0x008b
                           00008C   327 _TH0	=	0x008c
                           00008D   328 _TH1	=	0x008d
                           000098   329 _SCON	=	0x0098
                           000099   330 _SBUF	=	0x0099
                           0000C8   331 _T2CON	=	0x00c8
                           0000C9   332 _T2MOD	=	0x00c9
                           00CBCA   333 _RCAP2	=	0xcbca
                           0000CA   334 _RCAP2L	=	0x00ca
                           0000CB   335 _RCAP2H	=	0x00cb
                           00CDCC   336 _T2COUNT	=	0xcdcc
                           0000CC   337 _TL2	=	0x00cc
                           0000CD   338 _TH2	=	0x00cd
                           00CFCE   339 _T2CAP1	=	0xcfce
                           0000CE   340 _T2CAP1L	=	0x00ce
                           0000CF   341 _T2CAP1H	=	0x00cf
                           0000F8   342 _SPI0_STAT	=	0x00f8
                           0000F9   343 _SPI0_DATA	=	0x00f9
                           0000FA   344 _SPI0_CTRL	=	0x00fa
                           0000FB   345 _SPI0_CK_SE	=	0x00fb
                           0000FC   346 _SPI0_SETUP	=	0x00fc
                           0000BC   347 _SCON1	=	0x00bc
                           0000BD   348 _SBUF1	=	0x00bd
                           0000BE   349 _SBAUD1	=	0x00be
                           0000BF   350 _SIF1	=	0x00bf
                           0000B4   351 _SPI1_STAT	=	0x00b4
                           0000B5   352 _SPI1_DATA	=	0x00b5
                           0000B6   353 _SPI1_CTRL	=	0x00b6
                           0000B7   354 _SPI1_CK_SE	=	0x00b7
                           0000F3   355 _ADC_CTRL	=	0x00f3
                           00F5F4   356 _ADC_DAT	=	0xf5f4
                           0000F4   357 _ADC_DAT_L	=	0x00f4
                           0000F5   358 _ADC_DAT_H	=	0x00f5
                           0000F6   359 _ADC_CHAN	=	0x00f6
                           0000A6   360 _LED_COMMON	=	0x00a6
                           0000A7   361 _LED_PWM_OE	=	0x00a7
                           00C7C6   362 _LED_DMA	=	0xc7c6
                           0000C6   363 _LED_DMA_L	=	0x00c6
                           0000C7   364 _LED_DMA_H	=	0x00c7
                           0000F7   365 _LED_STATUS	=	0x00f7
                           0000B3   366 _I2CX_INT	=	0x00b3
                           0000BB   367 _I2CS_INT_ST	=	0x00bb
                                    368 ;--------------------------------------------------------
                                    369 ; special function bits
                                    370 ;--------------------------------------------------------
                                    371 	.area RSEG    (ABS,DATA)
      000000                        372 	.org 0x0000
                           0000D7   373 _CY	=	0x00d7
                           0000D6   374 _AC	=	0x00d6
                           0000D5   375 _F0	=	0x00d5
                           0000D4   376 _RS1	=	0x00d4
                           0000D3   377 _RS0	=	0x00d3
                           0000D2   378 _OV	=	0x00d2
                           0000D1   379 _F1	=	0x00d1
                           0000D0   380 _P	=	0x00d0
                           0000AF   381 _EA	=	0x00af
                           0000AE   382 _E_DIS	=	0x00ae
                           0000AD   383 _ET2	=	0x00ad
                           0000AC   384 _ES	=	0x00ac
                           0000AB   385 _ET1	=	0x00ab
                           0000AA   386 _EX1	=	0x00aa
                           0000A9   387 _ET0	=	0x00a9
                           0000A8   388 _EX0	=	0x00a8
                           0000BF   389 _PH_FLAG	=	0x00bf
                           0000BE   390 _PL_FLAG	=	0x00be
                           0000BD   391 _PT2	=	0x00bd
                           0000BC   392 _PS	=	0x00bc
                           0000BB   393 _PT1	=	0x00bb
                           0000BA   394 _PX1	=	0x00ba
                           0000B9   395 _PT0	=	0x00b9
                           0000B8   396 _PX0	=	0x00b8
                           0000EF   397 _IE_WDOG	=	0x00ef
                           0000EE   398 _IE_GPIO	=	0x00ee
                           0000ED   399 _IE_PWM_I2C	=	0x00ed
                           0000EC   400 _IE_UART1	=	0x00ec
                           0000EB   401 _IE_ADC	=	0x00eb
                           0000E9   402 _IE_USB	=	0x00e9
                           0000E8   403 _IE_SPI0	=	0x00e8
                           000087   404 _P0_7	=	0x0087
                           000086   405 _P0_6	=	0x0086
                           000085   406 _P0_5	=	0x0085
                           000084   407 _P0_4	=	0x0084
                           000083   408 _P0_3	=	0x0083
                           000082   409 _P0_2	=	0x0082
                           000081   410 _P0_1	=	0x0081
                           000080   411 _P0_0	=	0x0080
                           000081   412 _SDA0	=	0x0081
                           000080   413 _SCL0	=	0x0080
                           000083   414 _TXD_	=	0x0083
                           000082   415 _RXD_	=	0x0082
                           000085   416 _AIN13	=	0x0085
                           000084   417 _AIN12	=	0x0084
                           000083   418 _AIN11	=	0x0083
                           000082   419 _AIN10	=	0x0082
                           000081   420 _AIN9	=	0x0081
                           000080   421 _AIN8	=	0x0080
                           000097   422 _P1_7	=	0x0097
                           000096   423 _P1_6	=	0x0096
                           000095   424 _P1_5	=	0x0095
                           000094   425 _P1_4	=	0x0094
                           000093   426 _P1_3	=	0x0093
                           000092   427 _P1_2	=	0x0092
                           000091   428 _P1_1	=	0x0091
                           000090   429 _P1_0	=	0x0090
                           000097   430 _TXD1_	=	0x0097
                           000096   431 _RXD1_	=	0x0096
                           000097   432 _SCK	=	0x0097
                           000096   433 _MISO	=	0x0096
                           000095   434 _MOSI	=	0x0095
                           000094   435 _SCS	=	0x0094
                           000092   436 _INT0_	=	0x0092
                           000091   437 _T2EX	=	0x0091
                           000091   438 _CAP2	=	0x0091
                           000090   439 _T2	=	0x0090
                           000090   440 _CAP1	=	0x0090
                           000097   441 _AIN7	=	0x0097
                           000096   442 _AIN6	=	0x0096
                           000095   443 _AIN5	=	0x0095
                           000094   444 _AIN4	=	0x0094
                           000093   445 _AIN3	=	0x0093
                           000092   446 _AIN2	=	0x0092
                           000091   447 _AIN1	=	0x0091
                           000090   448 _AIN0	=	0x0090
                           0000A7   449 _P2_7	=	0x00a7
                           0000A6   450 _P2_6	=	0x00a6
                           0000A5   451 _P2_5	=	0x00a5
                           0000A4   452 _P2_4	=	0x00a4
                           0000A3   453 _P2_3	=	0x00a3
                           0000A2   454 _P2_2	=	0x00a2
                           0000A1   455 _P2_1	=	0x00a1
                           0000A0   456 _P2_0	=	0x00a0
                           0000A7   457 _TXD1	=	0x00a7
                           0000A6   458 _RXD1	=	0x00a6
                           0000A5   459 _T2EX_	=	0x00a5
                           0000A5   460 _CAP2_	=	0x00a5
                           0000A4   461 _T2_	=	0x00a4
                           0000A4   462 _CAP1_	=	0x00a4
                           0000B7   463 _P3_7	=	0x00b7
                           0000B6   464 _P3_6	=	0x00b6
                           0000B5   465 _P3_5	=	0x00b5
                           0000B4   466 _P3_4	=	0x00b4
                           0000B3   467 _P3_3	=	0x00b3
                           0000B2   468 _P3_2	=	0x00b2
                           0000B1   469 _P3_1	=	0x00b1
                           0000B0   470 _P3_0	=	0x00b0
                           0000B7   471 _SCK1	=	0x00b7
                           0000B6   472 _MISO1	=	0x00b6
                           0000B5   473 _MOSI1	=	0x00b5
                           0000B5   474 _T1	=	0x00b5
                           0000B4   475 _T0	=	0x00b4
                           0000B3   476 _INT1	=	0x00b3
                           0000B2   477 _INT0	=	0x00b2
                           0000B1   478 _TXD	=	0x00b1
                           0000B0   479 _RXD	=	0x00b0
                           0000C6   480 _P4_6	=	0x00c6
                           0000C5   481 _P4_5	=	0x00c5
                           0000C4   482 _P4_4	=	0x00c4
                           0000C3   483 _P4_3	=	0x00c3
                           0000C2   484 _P4_2	=	0x00c2
                           0000C1   485 _P4_1	=	0x00c1
                           0000C0   486 _P4_0	=	0x00c0
                           00008F   487 _TF1	=	0x008f
                           00008E   488 _TR1	=	0x008e
                           00008D   489 _TF0	=	0x008d
                           00008C   490 _TR0	=	0x008c
                           00008B   491 _IE1	=	0x008b
                           00008A   492 _IT1	=	0x008a
                           000089   493 _IE0	=	0x0089
                           000088   494 _IT0	=	0x0088
                           00009F   495 _SM0	=	0x009f
                           00009E   496 _SM1	=	0x009e
                           00009D   497 _SM2	=	0x009d
                           00009C   498 _REN	=	0x009c
                           00009B   499 _TB8	=	0x009b
                           00009A   500 _RB8	=	0x009a
                           000099   501 _TI	=	0x0099
                           000098   502 _RI	=	0x0098
                           0000CF   503 _TF2	=	0x00cf
                           0000CF   504 _CAP1F	=	0x00cf
                           0000CE   505 _EXF2	=	0x00ce
                           0000CD   506 _RCLK	=	0x00cd
                           0000CC   507 _TCLK	=	0x00cc
                           0000CB   508 _EXEN2	=	0x00cb
                           0000CA   509 _TR2	=	0x00ca
                           0000C9   510 _C_T2	=	0x00c9
                           0000C8   511 _CP_RL2	=	0x00c8
                           0000FF   512 _S0_FST_ACT	=	0x00ff
                           0000FE   513 _S0_IF_OV	=	0x00fe
                           0000FD   514 _S0_IF_FIRST	=	0x00fd
                           0000FC   515 _S0_IF_BYTE	=	0x00fc
                           0000FB   516 _S0_FREE	=	0x00fb
                           0000FA   517 _S0_T_FIFO	=	0x00fa
                           0000F8   518 _S0_R_FIFO	=	0x00f8
                           0000F7   519 _ADC_START	=	0x00f7
                                    520 ;--------------------------------------------------------
                                    521 ; overlayable register banks
                                    522 ;--------------------------------------------------------
                                    523 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        524 	.ds 8
                                    525 ;--------------------------------------------------------
                                    526 ; internal ram data
                                    527 ;--------------------------------------------------------
                                    528 	.area DSEG    (DATA)
                                    529 ;--------------------------------------------------------
                                    530 ; overlayable items in internal ram
                                    531 ;--------------------------------------------------------
                                    532 ;--------------------------------------------------------
                                    533 ; indirectly addressable internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area ISEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; absolute internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area IABS    (ABS,DATA)
                                    540 	.area IABS    (ABS,DATA)
                                    541 ;--------------------------------------------------------
                                    542 ; bit data
                                    543 ;--------------------------------------------------------
                                    544 	.area BSEG    (BIT)
      000021                        545 _caps_word_press_user_sloc0_1_0:
      000021                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000AD0                        555 _caps_word_press_user_keycode_10000_253:
      000AD0                        556 	.ds 2
                                    557 ;--------------------------------------------------------
                                    558 ; absolute external ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area XABS    (ABS,XDATA)
                                    561 ;--------------------------------------------------------
                                    562 ; initialized external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area XISEG   (XDATA)
      000DD0                        565 _caps_word_active:
      000DD0                        566 	.ds 1
      000DD1                        567 _idle_timer:
      000DD1                        568 	.ds 2
                                    569 	.area HOME    (CODE)
                                    570 	.area GSINIT0 (CODE)
                                    571 	.area GSINIT1 (CODE)
                                    572 	.area GSINIT2 (CODE)
                                    573 	.area GSINIT3 (CODE)
                                    574 	.area GSINIT4 (CODE)
                                    575 	.area GSINIT5 (CODE)
                                    576 	.area GSINIT  (CODE)
                                    577 	.area GSFINAL (CODE)
                                    578 	.area CSEG    (CODE)
                                    579 ;--------------------------------------------------------
                                    580 ; global & static initialisations
                                    581 ;--------------------------------------------------------
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT  (CODE)
                                    584 	.area GSFINAL (CODE)
                                    585 	.area GSINIT  (CODE)
                                    586 ;--------------------------------------------------------
                                    587 ; Home
                                    588 ;--------------------------------------------------------
                                    589 	.area HOME    (CODE)
                                    590 	.area HOME    (CODE)
                                    591 ;--------------------------------------------------------
                                    592 ; code
                                    593 ;--------------------------------------------------------
                                    594 	.area AK820LOW(CODE)
                                    595 ;------------------------------------------------------------
                                    596 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    597 ;------------------------------------------------------------
                                    598 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_129'
                                    599 ;------------------------------------------------------------
                                    600 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    601 ;	-----------------------------------------
                           000007   602 	ar7 = 0x07
                           000006   603 	ar6 = 0x06
                           000005   604 	ar5 = 0x05
                           000004   605 	ar4 = 0x04
                           000003   606 	ar3 = 0x03
                           000002   607 	ar2 = 0x02
                           000001   608 	ar1 = 0x01
                           000000   609 	ar0 = 0x00
                                    610 ;	 function caps_word_task
                                    611 ;	-----------------------------------------
      002EFF                        612 _caps_word_task:
                                    613 ;	quantum/caps_word.c:42: if (caps_word_active && timer_expired(timer_read(), idle_timer)) {
      002EFF 90 0D D0         [24]  614 	mov	dptr,#_caps_word_active
      002F02 E0               [24]  615 	movx	a,@dptr
      002F03 60 22            [24]  616 	jz	00104$
      002F05 12 4B 15         [24]  617 	lcall	_timer_read
      002F08 AE 82            [24]  618 	mov	r6, dpl
      002F0A AF 83            [24]  619 	mov	r7, dph
      002F0C 90 0D D1         [24]  620 	mov	dptr,#_idle_timer
      002F0F E0               [24]  621 	movx	a,@dptr
      002F10 FC               [12]  622 	mov	r4,a
      002F11 A3               [24]  623 	inc	dptr
      002F12 E0               [24]  624 	movx	a,@dptr
      002F13 FD               [12]  625 	mov	r5,a
      002F14 EE               [12]  626 	mov	a,r6
      002F15 C3               [12]  627 	clr	c
      002F16 9C               [12]  628 	subb	a,r4
      002F17 FE               [12]  629 	mov	r6,a
      002F18 EF               [12]  630 	mov	a,r7
      002F19 9D               [12]  631 	subb	a,r5
      002F1A FF               [12]  632 	mov	r7,a
      002F1B C3               [12]  633 	clr	c
      002F1C EE               [12]  634 	mov	a,r6
      002F1D 94 FF            [12]  635 	subb	a,#0xff
      002F1F EF               [12]  636 	mov	a,r7
      002F20 94 7F            [12]  637 	subb	a,#0x7f
      002F22 50 03            [24]  638 	jnc	00104$
                                    639 ;	quantum/caps_word.c:43: caps_word_off();
                                    640 ;	quantum/caps_word.c:45: }
      002F24 02 2F 59         [24]  641 	ljmp	_caps_word_off
      002F27                        642 00104$:
      002F27 22               [24]  643 	ret
                                    644 ;------------------------------------------------------------
                                    645 ;Allocation info for local variables in function 'caps_word_reset_idle_timer'
                                    646 ;------------------------------------------------------------
                                    647 ;	quantum/caps_word.c:47: void caps_word_reset_idle_timer(void) {
                                    648 ;	-----------------------------------------
                                    649 ;	 function caps_word_reset_idle_timer
                                    650 ;	-----------------------------------------
      002F28                        651 _caps_word_reset_idle_timer:
                                    652 ;	quantum/caps_word.c:48: idle_timer = timer_read() + CAPS_WORD_IDLE_TIMEOUT;
      002F28 12 4B 15         [24]  653 	lcall	_timer_read
      002F2B AE 82            [24]  654 	mov	r6, dpl
      002F2D AF 83            [24]  655 	mov	r7, dph
      002F2F 74 88            [12]  656 	mov	a,#0x88
      002F31 2E               [12]  657 	add	a, r6
      002F32 FE               [12]  658 	mov	r6,a
      002F33 74 13            [12]  659 	mov	a,#0x13
      002F35 3F               [12]  660 	addc	a, r7
      002F36 FF               [12]  661 	mov	r7,a
      002F37 90 0D D1         [24]  662 	mov	dptr,#_idle_timer
      002F3A EE               [12]  663 	mov	a,r6
      002F3B F0               [24]  664 	movx	@dptr,a
      002F3C EF               [12]  665 	mov	a,r7
      002F3D A3               [24]  666 	inc	dptr
      002F3E F0               [24]  667 	movx	@dptr,a
                                    668 ;	quantum/caps_word.c:49: }
      002F3F 22               [24]  669 	ret
                                    670 ;------------------------------------------------------------
                                    671 ;Allocation info for local variables in function 'caps_word_on'
                                    672 ;------------------------------------------------------------
                                    673 ;	quantum/caps_word.c:54: void caps_word_on(void) {
                                    674 ;	-----------------------------------------
                                    675 ;	 function caps_word_on
                                    676 ;	-----------------------------------------
      002F40                        677 _caps_word_on:
                                    678 ;	quantum/caps_word.c:55: if (caps_word_active) {
      002F40 90 0D D0         [24]  679 	mov	dptr,#_caps_word_active
      002F43 E0               [24]  680 	movx	a,@dptr
      002F44 60 01            [24]  681 	jz	00102$
                                    682 ;	quantum/caps_word.c:56: return;
      002F46 22               [24]  683 	ret
      002F47                        684 00102$:
                                    685 ;	quantum/caps_word.c:59: clear_mods();
      002F47 12 81 AE         [24]  686 	lcall	_clear_mods
                                    687 ;	quantum/caps_word.c:64: caps_word_reset_idle_timer();
      002F4A 12 2F 28         [24]  688 	lcall	_caps_word_reset_idle_timer
                                    689 ;	quantum/caps_word.c:67: caps_word_active = true;
      002F4D 90 0D D0         [24]  690 	mov	dptr,#_caps_word_active
      002F50 74 01            [12]  691 	mov	a,#0x01
      002F52 F0               [24]  692 	movx	@dptr,a
                                    693 ;	quantum/caps_word.c:68: caps_word_set_user(true);
      002F53 75 82 01         [24]  694 	mov	dpl, #0x01
                                    695 ;	quantum/caps_word.c:69: }
      002F56 02 2F 87         [24]  696 	ljmp	_caps_word_set_user
                                    697 ;------------------------------------------------------------
                                    698 ;Allocation info for local variables in function 'caps_word_off'
                                    699 ;------------------------------------------------------------
                                    700 ;	quantum/caps_word.c:71: void caps_word_off(void) {
                                    701 ;	-----------------------------------------
                                    702 ;	 function caps_word_off
                                    703 ;	-----------------------------------------
      002F59                        704 _caps_word_off:
                                    705 ;	quantum/caps_word.c:72: if (!caps_word_active) {
      002F59 90 0D D0         [24]  706 	mov	dptr,#_caps_word_active
      002F5C E0               [24]  707 	movx	a,@dptr
      002F5D 70 01            [24]  708 	jnz	00102$
                                    709 ;	quantum/caps_word.c:73: return;
      002F5F 22               [24]  710 	ret
      002F60                        711 00102$:
                                    712 ;	quantum/caps_word.c:79: del_weak_mods(MOD_MASK_SHIFT);
      002F60 75 82 22         [24]  713 	mov	dpl, #0x22
      002F63 12 81 D3         [24]  714 	lcall	_del_weak_mods
                                    715 ;	quantum/caps_word.c:80: send_keyboard_report();
      002F66 12 81 33         [24]  716 	lcall	_send_keyboard_report
                                    717 ;	quantum/caps_word.c:84: caps_word_active = false;
      002F69 90 0D D0         [24]  718 	mov	dptr,#_caps_word_active
      002F6C E4               [12]  719 	clr	a
      002F6D F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/caps_word.c:85: caps_word_set_user(false);
      002F6E 75 82 00         [24]  722 	mov	dpl, #0x00
                                    723 ;	quantum/caps_word.c:86: }
      002F71 02 2F 87         [24]  724 	ljmp	_caps_word_set_user
                                    725 ;------------------------------------------------------------
                                    726 ;Allocation info for local variables in function 'caps_word_toggle'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/caps_word.c:88: void caps_word_toggle(void) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function caps_word_toggle
                                    731 ;	-----------------------------------------
      002F74                        732 _caps_word_toggle:
                                    733 ;	quantum/caps_word.c:89: if (caps_word_active) {
      002F74 90 0D D0         [24]  734 	mov	dptr,#_caps_word_active
      002F77 E0               [24]  735 	movx	a,@dptr
      002F78 60 03            [24]  736 	jz	00102$
                                    737 ;	quantum/caps_word.c:90: caps_word_off();
      002F7A 02 2F 59         [24]  738 	ljmp	_caps_word_off
      002F7D                        739 00102$:
                                    740 ;	quantum/caps_word.c:92: caps_word_on();
                                    741 ;	quantum/caps_word.c:94: }
      002F7D 02 2F 40         [24]  742 	ljmp	_caps_word_on
                                    743 ;------------------------------------------------------------
                                    744 ;Allocation info for local variables in function 'is_caps_word_on'
                                    745 ;------------------------------------------------------------
                                    746 ;	quantum/caps_word.c:96: bool is_caps_word_on(void) {
                                    747 ;	-----------------------------------------
                                    748 ;	 function is_caps_word_on
                                    749 ;	-----------------------------------------
      002F80                        750 _is_caps_word_on:
                                    751 ;	quantum/caps_word.c:97: return caps_word_active;
      002F80 90 0D D0         [24]  752 	mov	dptr,#_caps_word_active
      002F83 E0               [24]  753 	movx	a,@dptr
                                    754 ;	quantum/caps_word.c:98: }
      002F84 F5 82            [12]  755 	mov	dpl,a
      002F86 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'caps_word_set_user'
                                    759 ;------------------------------------------------------------
                                    760 ;active        Allocated with name '_caps_word_set_user_active_10000_250'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/caps_word.c:100: __attribute__((weak)) void caps_word_set_user(bool active) {}
                                    763 ;	-----------------------------------------
                                    764 ;	 function caps_word_set_user
                                    765 ;	-----------------------------------------
      002F87                        766 _caps_word_set_user:
      002F87 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'caps_word_press_user'
                                    770 ;------------------------------------------------------------
                                    771 ;keycode       Allocated with name '_caps_word_press_user_keycode_10000_253'
                                    772 ;------------------------------------------------------------
                                    773 ;	quantum/caps_word.c:104: __attribute__((weak)) bool caps_word_press_user(uint16_t keycode) {
                                    774 ;	-----------------------------------------
                                    775 ;	 function caps_word_press_user
                                    776 ;	-----------------------------------------
      002F88                        777 _caps_word_press_user:
      002F88 AF 83            [24]  778 	mov	r7,dph
      002F8A E5 82            [12]  779 	mov	a,dpl
      002F8C 90 0A D0         [24]  780 	mov	dptr,#_caps_word_press_user_keycode_10000_253
      002F8F F0               [24]  781 	movx	@dptr,a
      002F90 EF               [12]  782 	mov	a,r7
      002F91 A3               [24]  783 	inc	dptr
      002F92 F0               [24]  784 	movx	@dptr,a
                                    785 ;	quantum/caps_word.c:105: if ((keycode >= KC_A && keycode <= KC_Z) || keycode == KC_MINS) {
      002F93 90 0A D0         [24]  786 	mov	dptr,#_caps_word_press_user_keycode_10000_253
      002F96 E0               [24]  787 	movx	a,@dptr
      002F97 FE               [12]  788 	mov	r6,a
      002F98 A3               [24]  789 	inc	dptr
      002F99 E0               [24]  790 	movx	a,@dptr
      002F9A FF               [12]  791 	mov	r7,a
      002F9B C3               [12]  792 	clr	c
      002F9C EE               [12]  793 	mov	a,r6
      002F9D 94 04            [12]  794 	subb	a,#0x04
      002F9F EF               [12]  795 	mov	a,r7
      002FA0 94 00            [12]  796 	subb	a,#0x00
      002FA2 40 07            [24]  797 	jc	00104$
      002FA4 74 1D            [12]  798 	mov	a,#0x1d
      002FA6 9E               [12]  799 	subb	a,r6
      002FA7 E4               [12]  800 	clr	a
      002FA8 9F               [12]  801 	subb	a,r7
      002FA9 50 06            [24]  802 	jnc	00101$
                                    803 ;	free result
      002FAB                        804 00104$:
      002FAB BE 2D 0D         [24]  805 	cjne	r6,#0x2d,00102$
      002FAE BF 00 0A         [24]  806 	cjne	r7,#0x00,00102$
      002FB1                        807 00101$:
                                    808 ;	quantum/caps_word.c:106: add_weak_mods(MOD_BIT(KC_LSFT));
      002FB1 75 82 02         [24]  809 	mov	dpl, #0x02
      002FB4 12 81 C4         [24]  810 	lcall	_add_weak_mods
                                    811 ;	quantum/caps_word.c:107: return true;
      002FB7 75 82 01         [24]  812 	mov	dpl, #0x01
      002FBA 22               [24]  813 	ret
      002FBB                        814 00102$:
                                    815 ;	quantum/caps_word.c:109: return (keycode >= KC_1 && keycode <= KC_0) || keycode == KC_BSPC ||
      002FBB C3               [12]  816 	clr	c
      002FBC EE               [12]  817 	mov	a,r6
      002FBD 94 1E            [12]  818 	subb	a,#0x1e
      002FBF EF               [12]  819 	mov	a,r7
      002FC0 94 00            [12]  820 	subb	a,#0x00
      002FC2 40 07            [24]  821 	jc	00118$
      002FC4 74 27            [12]  822 	mov	a,#0x27
      002FC6 9E               [12]  823 	subb	a,r6
      002FC7 E4               [12]  824 	clr	a
      002FC8 9F               [12]  825 	subb	a,r7
      002FC9 50 1C            [24]  826 	jnc	00108$
                                    827 ;	free result
      002FCB                        828 00118$:
      002FCB BE 2A 05         [24]  829 	cjne	r6,#0x2a,00160$
      002FCE BF 00 02         [24]  830 	cjne	r7,#0x00,00160$
      002FD1 80 14            [24]  831 	sjmp	00108$
      002FD3                        832 00160$:
                                    833 ;	quantum/caps_word.c:110: keycode == KC_DEL || keycode == KC_UNDS;
      002FD3 BE 4C 05         [24]  834 	cjne	r6,#0x4c,00161$
      002FD6 BF 00 02         [24]  835 	cjne	r7,#0x00,00161$
      002FD9 80 0C            [24]  836 	sjmp	00108$
      002FDB                        837 00161$:
      002FDB BE 2D 05         [24]  838 	cjne	r6,#0x2d,00162$
      002FDE BF 02 02         [24]  839 	cjne	r7,#0x02,00162$
      002FE1 80 04            [24]  840 	sjmp	00108$
      002FE3                        841 00162$:
                                    842 ;	assignBit
      002FE3 C2 21            [12]  843 	clr	_caps_word_press_user_sloc0_1_0
      002FE5 80 02            [24]  844 	sjmp	00109$
      002FE7                        845 00108$:
                                    846 ;	assignBit
      002FE7 D2 21            [12]  847 	setb	_caps_word_press_user_sloc0_1_0
      002FE9                        848 00109$:
      002FE9 A2 21            [12]  849 	mov	c,_caps_word_press_user_sloc0_1_0
      002FEB E4               [12]  850 	clr	a
      002FEC 33               [12]  851 	rlc	a
      002FED F5 82            [12]  852 	mov	dpl, a
                                    853 ;	quantum/caps_word.c:111: }
      002FEF 22               [24]  854 	ret
                                    855 	.area AK820LOW(CODE)
                                    856 	.area CONST   (CODE)
                                    857 	.area XINIT   (CODE)
      00C163                        858 __xinit__caps_word_active:
      00C163 00                     859 	.db #0x00	;  0
      00C164                        860 __xinit__idle_timer:
      00C164 00 00                  861 	.byte #0x00, #0x00	; 0
                                    862 	.area CABS    (ABS,CODE)
