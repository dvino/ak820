                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000026                        548 _control_setup_sloc1_1_0:
      000026                        549 	.ds 1
      000027                        550 _control_setup_sloc3_1_0:
      000027                        551 	.ds 2
      000029                        552 _control_setup_sloc4_1_0:
      000029                        553 	.ds 2
      00002B                        554 _ak820_usb_send_sloc0_1_0:
      00002B                        555 	.ds 2
      00002D                        556 _ak820_usb_send_sloc1_1_0:
      00002D                        557 	.ds 1
      00002E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00002E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000014                        576 _control_setup_valid_interface_10000_286:
      000014                        577 	.ds 1
      000015                        578 _control_setup_zero_index_10000_286:
      000015                        579 	.ds 1
      000016                        580 _control_setup_zero_value_10000_286:
      000016                        581 	.ds 1
      000017                        582 _control_setup_zero_length_10000_286:
      000017                        583 	.ds 1
      000018                        584 _control_setup_sloc0_1_0:
      000018                        585 	.ds 1
      000019                        586 _control_setup_sloc2_1_0:
      000019                        587 	.ds 1
      00001A                        588 _ak820_usb_try_send_sloc0_1_0:
      00001A                        589 	.ds 1
      00001B                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001B                        591 	.ds 1
      00001C                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001C                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      00077B                        602 _D0SetupReqCode::
      00077B                        603 	.ds 1
      00077C                        604 _D0SetupLen::
      00077C                        605 	.ds 2
      00077E                        606 _pD0Descr::
      00077E                        607 	.ds 3
      000781                        608 _D0UsbConfig::
      000781                        609 	.ds 1
      000782                        610 _USB_EnumStatus::
      000782                        611 	.ds 1
      000783                        612 _USB_SleepStatus::
      000783                        613 	.ds 1
      000784                        614 _MCU_Sleep_Operate::
      000784                        615 	.ds 1
      000785                        616 _KB_USB_UpStatus::
      000785                        617 	.ds 1
      000786                        618 _KB_USB_SetReport::
      000786                        619 	.ds 1
      000787                        620 _ak820_boot_stage::
      000787                        621 	.ds 1
      000788                        622 _ak820_main_heartbeat::
      000788                        623 	.ds 1
      000789                        624 _raw_state:
      000789                        625 	.ds 1
      00078A                        626 _raw_buffer:
      00078A                        627 	.ds 32
      0007AA                        628 _raw_reply_without_nvm:
      0007AA                        629 	.ds 1
      0007AB                        630 _keyboard_reset:
      0007AB                        631 	.ds 1
      0007AC                        632 _input_snapshot:
      0007AC                        633 	.ds 46
      0007DA                        634 _control_phase:
      0007DA                        635 	.ds 1
      0007DB                        636 _output_kind:
      0007DB                        637 	.ds 1
      0007DC                        638 _output_report_id:
      0007DC                        639 	.ds 1
      0007DD                        640 _control_zlp:
      0007DD                        641 	.ds 1
      0007DE                        642 _control_pointer:
      0007DE                        643 	.ds 2
      0007E0                        644 _descriptor_select_PARM_2:
      0007E0                        645 	.ds 1
      0007E1                        646 _descriptor_select_PARM_3:
      0007E1                        647 	.ds 2
      0007E3                        648 _descriptor_select_type_10000_268:
      0007E3                        649 	.ds 1
      0007E4                        650 _control_setup_length_10000_286:
      0007E4                        651 	.ds 2
      0007E6                        652 _control_setup_offset_10000_286:
      0007E6                        653 	.ds 1
      0007E7                        654 _ak820_usb_send_PARM_2:
      0007E7                        655 	.ds 2
      0007E9                        656 _ak820_usb_send_PARM_3:
      0007E9                        657 	.ds 1
      0007EA                        658 _ak820_usb_send_endpoint_10000_422:
      0007EA                        659 	.ds 1
      0007EB                        660 _ak820_usb_send_offset_10000_423:
      0007EB                        661 	.ds 1
      0007EC                        662 _ak820_usb_try_send_PARM_2:
      0007EC                        663 	.ds 2
      0007EE                        664 _ak820_usb_try_send_PARM_3:
      0007EE                        665 	.ds 1
      0007EF                        666 _ak820_usb_try_send_endpoint_10000_443:
      0007EF                        667 	.ds 1
      0007F0                        668 _ak820_usb_try_send_sent_10000_444:
      0007F0                        669 	.ds 1
      0007F1                        670 _ak820_usb_raw_send_PARM_2:
      0007F1                        671 	.ds 1
      0007F2                        672 _ak820_usb_raw_send_report_10000_459:
      0007F2                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005C01                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005C01 90 07 89         [24]  727 	mov	dptr,#_raw_state
      005C04 E0               [24]  728 	movx	a,@dptr
      005C05 FF               [12]  729 	mov	r7,a
      005C06 BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005C09 80 1C            [24]  731 	sjmp	00101$
      005C0B                        732 00130$:
      005C0B 90 07 89         [24]  733 	mov	dptr,#_raw_state
      005C0E E0               [24]  734 	movx	a,@dptr
      005C0F FF               [12]  735 	mov	r7,a
      005C10 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005C13 80 12            [24]  737 	sjmp	00101$
      005C15                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005C15 90 07 89         [24]  740 	mov	dptr,#_raw_state
      005C18 E0               [24]  741 	movx	a,@dptr
      005C19 FF               [12]  742 	mov	r7,a
      005C1A BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005C1D 80 08            [24]  744 	sjmp	00101$
      005C1F                        745 00132$:
      005C1F 90 07 89         [24]  746 	mov	dptr,#_raw_state
      005C22 E0               [24]  747 	movx	a,@dptr
      005C23 FF               [12]  748 	mov	r7,a
      005C24 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005C27                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005C27 90 07 89         [24]  752 	mov	dptr,#_raw_state
      005C2A 74 07            [12]  753 	mov	a,#0x07
      005C2C F0               [24]  754 	movx	@dptr,a
      005C2D 80 05            [24]  755 	sjmp	00103$
      005C2F                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005C2F 90 07 89         [24]  758 	mov	dptr,#_raw_state
      005C32 E4               [12]  759 	clr	a
      005C33 F0               [24]  760 	movx	@dptr,a
      005C34                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005C34 90 07 DB         [24]  763 	mov	dptr,#_output_kind
      005C37 E4               [12]  764 	clr	a
      005C38 F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005C39 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005C3A                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005C3A 90 07 89         [24]  777 	mov	dptr,#_raw_state
      005C3D E0               [24]  778 	movx	a,@dptr
      005C3E FF               [12]  779 	mov	r7,a
      005C3F BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005C42 90 07 89         [24]  781 	mov	dptr,#_raw_state
      005C45 74 06            [12]  782 	mov	a,#0x06
      005C47 F0               [24]  783 	movx	@dptr,a
      005C48 22               [24]  784 	ret
      005C49                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005C49 90 07 89         [24]  787 	mov	dptr,#_raw_state
      005C4C E0               [24]  788 	movx	a,@dptr
      005C4D FF               [12]  789 	mov	r7,a
      005C4E BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005C51 90 07 89         [24]  791 	mov	dptr,#_raw_state
      005C54 E4               [12]  792 	clr	a
      005C55 F0               [24]  793 	movx	@dptr,a
      005C56                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005C56 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005C57                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005C57 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005C5A 74 01            [12]  809 	mov	a,#0x01
      005C5C F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005C5D F5 82            [12]  812 	mov	dpl,a
      005C5F 74 12            [12]  813 	mov	a,#0x12
      005C61 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005C62 A3               [24]  816 	inc	dptr
      005C63 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005C64 A3               [24]  819 	inc	dptr
      005C65 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005C66 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005C69 E4               [12]  823 	clr	a
      005C6A F0               [24]  824 	movx	@dptr,a
      005C6B 15 82            [12]  825 	dec	dpl
      005C6D F0               [24]  826 	movx	@dptr,a
      005C6E 15 82            [12]  827 	dec	dpl
      005C70 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005C71 FF               [12]  830 	mov	r7,a
      005C72                        831 00103$:
      005C72 EF               [12]  832 	mov	a,r7
      005C73 24 AC            [12]  833 	add	a, #_input_snapshot
      005C75 F5 82            [12]  834 	mov	dpl,a
      005C77 E4               [12]  835 	clr	a
      005C78 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005C7A F5 83            [12]  837 	mov	dph,a
      005C7C E4               [12]  838 	clr	a
      005C7D F0               [24]  839 	movx	@dptr,a
      005C7E 0F               [12]  840 	inc	r7
      005C7F BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005C82                        842 00139$:
      005C82 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005C84 90 07 B4         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005C87 74 06            [12]  846 	mov	a,#0x06
      005C89 F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005C8A 90 07 D4         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005C8D 03               [12]  850 	rr	a
      005C8E F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005C8F 90 07 D7         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005C92 04               [12]  854 	inc	a
      005C93 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005C94 7F 00            [12]  857 	mov	r7,#0x00
      005C96                        858 00105$:
      005C96 8F 06            [24]  859 	mov	ar6,r7
      005C98 74 C0            [12]  860 	mov	a,#0xc0
      005C9A 2E               [12]  861 	add	a, r6
      005C9B F5 82            [12]  862 	mov	dpl,a
      005C9D 74 10            [12]  863 	mov	a,#0x10
      005C9F 24 00            [12]  864 	add	a, #0x00
      005CA1 F5 83            [12]  865 	mov	dph,a
      005CA3 E4               [12]  866 	clr	a
      005CA4 F0               [24]  867 	movx	@dptr,a
      005CA5 0F               [12]  868 	inc	r7
      005CA6 BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005CA9                        870 00141$:
      005CA9 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005CAB 02 5C 01         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005CAE                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005CAE 90 07 89         [24]  884 	mov	dptr,#_raw_state
      005CB1 E0               [24]  885 	movx	a,@dptr
      005CB2 FF               [12]  886 	mov	r7,a
      005CB3 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005CB6 90 07 89         [24]  888 	mov	dptr,#_raw_state
      005CB9 E4               [12]  889 	clr	a
      005CBA F0               [24]  890 	movx	@dptr,a
      005CBB                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005CBB 90 07 DB         [24]  893 	mov	dptr,#_output_kind
      005CBE E4               [12]  894 	clr	a
      005CBF F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005CC0 90 07 DA         [24]  897 	mov	dptr,#_control_phase
      005CC3 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005CC4 90 07 7B         [24]  900 	mov	dptr,#_D0SetupReqCode
      005CC7 14               [12]  901 	dec	a
      005CC8 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005CC9 90 22 00         [24]  904 	mov	dptr,#0x2200
      005CCC 74 CF            [12]  905 	mov	a,#0xcf
      005CCE F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005CCF 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005CD0                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005CD0 90 07 7C         [24]  921 	mov	dptr,#_D0SetupLen
      005CD3 E0               [24]  922 	movx	a,@dptr
      005CD4 FE               [12]  923 	mov	r6,a
      005CD5 A3               [24]  924 	inc	dptr
      005CD6 E0               [24]  925 	movx	a,@dptr
      005CD7 FF               [12]  926 	mov	r7,a
      005CD8 C3               [12]  927 	clr	c
      005CD9 74 40            [12]  928 	mov	a,#0x40
      005CDB 9E               [12]  929 	subb	a,r6
      005CDC E4               [12]  930 	clr	a
      005CDD 9F               [12]  931 	subb	a,r7
      005CDE 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005CE0 7E 40            [12]  934 	mov	r6,#0x40
      005CE2 80 07            [24]  935 	sjmp	00110$
      005CE4                        936 00109$:
      005CE4 90 07 7C         [24]  937 	mov	dptr,#_D0SetupLen
      005CE7 E0               [24]  938 	movx	a,@dptr
      005CE8 FE               [12]  939 	mov	r6,a
      005CE9 A3               [24]  940 	inc	dptr
      005CEA E0               [24]  941 	movx	a,@dptr
      005CEB                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005CEB 7F 00            [12]  944 	mov	r7,#0x00
      005CED                        945 00105$:
      005CED C3               [12]  946 	clr	c
      005CEE EF               [12]  947 	mov	a,r7
      005CEF 9E               [12]  948 	subb	a,r6
      005CF0 50 2A            [24]  949 	jnc	00101$
      005CF2 8F 04            [24]  950 	mov	ar4,r7
      005CF4 74 10            [12]  951 	mov	a,#0x10
      005CF6 24 00            [12]  952 	add	a, #0x00
      005CF8 FD               [12]  953 	mov	r5,a
      005CF9 90 07 DE         [24]  954 	mov	dptr,#_control_pointer
      005CFC E0               [24]  955 	movx	a,@dptr
      005CFD FA               [12]  956 	mov	r2,a
      005CFE A3               [24]  957 	inc	dptr
      005CFF E0               [24]  958 	movx	a,@dptr
      005D00 FB               [12]  959 	mov	r3,a
      005D01 8A 82            [24]  960 	mov	dpl,r2
      005D03 8B 83            [24]  961 	mov	dph,r3
      005D05 E4               [12]  962 	clr	a
      005D06 93               [24]  963 	movc	a,@a+dptr
      005D07 F9               [12]  964 	mov	r1,a
      005D08 90 07 DE         [24]  965 	mov	dptr,#_control_pointer
      005D0B 74 01            [12]  966 	mov	a,#0x01
      005D0D 2A               [12]  967 	add	a, r2
      005D0E F0               [24]  968 	movx	@dptr,a
      005D0F E4               [12]  969 	clr	a
      005D10 3B               [12]  970 	addc	a, r3
      005D11 A3               [24]  971 	inc	dptr
      005D12 F0               [24]  972 	movx	@dptr,a
      005D13 8C 82            [24]  973 	mov	dpl,r4
      005D15 8D 83            [24]  974 	mov	dph,r5
      005D17 E9               [12]  975 	mov	a,r1
      005D18 F0               [24]  976 	movx	@dptr,a
      005D19 0F               [12]  977 	inc	r7
      005D1A 80 D1            [24]  978 	sjmp	00105$
      005D1C                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005D1C 8E 05            [24]  981 	mov	ar5,r6
      005D1E 7F 00            [12]  982 	mov	r7,#0x00
      005D20 90 07 7C         [24]  983 	mov	dptr,#_D0SetupLen
      005D23 E0               [24]  984 	movx	a,@dptr
      005D24 FB               [12]  985 	mov	r3,a
      005D25 A3               [24]  986 	inc	dptr
      005D26 E0               [24]  987 	movx	a,@dptr
      005D27 FC               [12]  988 	mov	r4,a
      005D28 EB               [12]  989 	mov	a,r3
      005D29 C3               [12]  990 	clr	c
      005D2A 9D               [12]  991 	subb	a,r5
      005D2B FB               [12]  992 	mov	r3,a
      005D2C EC               [12]  993 	mov	a,r4
      005D2D 9F               [12]  994 	subb	a,r7
      005D2E FC               [12]  995 	mov	r4,a
      005D2F 90 07 7C         [24]  996 	mov	dptr,#_D0SetupLen
      005D32 EB               [12]  997 	mov	a,r3
      005D33 F0               [24]  998 	movx	@dptr,a
      005D34 EC               [12]  999 	mov	a,r4
      005D35 A3               [24] 1000 	inc	dptr
      005D36 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005D37 EE               [12] 1003 	mov	a,r6
      005D38 70 05            [24] 1004 	jnz	00103$
      005D3A 90 07 DD         [24] 1005 	mov	dptr,#_control_zlp
      005D3D E4               [12] 1006 	clr	a
      005D3E F0               [24] 1007 	movx	@dptr,a
      005D3F                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005D3F 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005D42 EE               [12] 1011 	mov	a,r6
      005D43 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005D44 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005D47 E0               [24] 1015 	movx	a,@dptr
      005D48 54 C0            [12] 1016 	anl	a,#0xc0
      005D4A F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005D4B 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005D4C                       1032 _descriptor_select:
      005D4C E5 82            [12] 1033 	mov	a,dpl
      005D4E 90 07 E3         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      005D51 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005D52 E0               [24] 1037 	movx	a,@dptr
      005D53 FF               [12] 1038 	mov	r7,a
      005D54 BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005D57 90 07 E0         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005D5A E0               [24] 1041 	movx	a,@dptr
      005D5B 70 1A            [24] 1042 	jnz	00102$
      005D5D 90 07 E1         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005D60 E0               [24] 1044 	movx	a,@dptr
      005D61 F5 F0            [12] 1045 	mov	b,a
      005D63 A3               [24] 1046 	inc	dptr
      005D64 E0               [24] 1047 	movx	a,@dptr
      005D65 45 F0            [12] 1048 	orl	a,b
      005D67 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005D69 90 07 DE         [24] 1051 	mov	dptr,#_control_pointer
      005D6C 74 5D            [12] 1052 	mov	a,#_DeviceDescriptor
      005D6E F0               [24] 1053 	movx	@dptr,a
      005D6F 74 C0            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005D71 A3               [24] 1055 	inc	dptr
      005D72 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      005D73 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005D76 22               [24] 1059 	ret
      005D77                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005D77 90 07 E3         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      005D7A E0               [24] 1063 	movx	a,@dptr
      005D7B FF               [12] 1064 	mov	r7,a
      005D7C BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005D7F 90 07 E0         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005D82 E0               [24] 1067 	movx	a,@dptr
      005D83 70 1A            [24] 1068 	jnz	00106$
      005D85 90 07 E1         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005D88 E0               [24] 1070 	movx	a,@dptr
      005D89 F5 F0            [12] 1071 	mov	b,a
      005D8B A3               [24] 1072 	inc	dptr
      005D8C E0               [24] 1073 	movx	a,@dptr
      005D8D 45 F0            [12] 1074 	orl	a,b
      005D8F 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005D91 90 07 DE         [24] 1077 	mov	dptr,#_control_pointer
      005D94 74 6F            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005D96 F0               [24] 1079 	movx	@dptr,a
      005D97 74 C0            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005D99 A3               [24] 1081 	inc	dptr
      005D9A F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      005D9B 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005D9E 22               [24] 1085 	ret
      005D9F                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      005D9F 90 07 E3         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      005DA2 E0               [24] 1089 	movx	a,@dptr
      005DA3 FF               [12] 1090 	mov	r7,a
      005DA4 BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005DA7 80 03            [24] 1092 	sjmp	00239$
      005DA9                       1093 00238$:
      005DA9 02 5E 43         [24] 1094 	ljmp	00119$
      005DAC                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      005DAC 90 07 E1         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005DAF E0               [24] 1098 	movx	a,@dptr
      005DB0 FD               [12] 1099 	mov	r5,a
      005DB1 A3               [24] 1100 	inc	dptr
      005DB2 E0               [24] 1101 	movx	a,@dptr
      005DB3 FE               [12] 1102 	mov	r6,a
      005DB4 90 07 E1         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005DB7 E0               [24] 1104 	movx	a,@dptr
      005DB8 F5 F0            [12] 1105 	mov	b,a
      005DBA A3               [24] 1106 	inc	dptr
      005DBB E0               [24] 1107 	movx	a,@dptr
      005DBC 45 F0            [12] 1108 	orl	a,b
      005DBE 60 0C            [24] 1109 	jz	00110$
      005DC0 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005DC3 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005DC6 80 04            [24] 1112 	sjmp	00110$
      005DC8                       1113 00241$:
      005DC8 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005DCB 22               [24] 1115 	ret
      005DCC                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      005DCC 90 07 E0         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005DCF E0               [24] 1119 	movx	a,@dptr
      005DD0 FE               [12] 1120 	mov  r6,a
      005DD1 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005DD3 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005DD5 EE               [12] 1124 	mov	a,r6
      005DD6 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005DD7 90 5D DB         [24] 1127 	mov	dptr,#00243$
      005DDA 73               [24] 1128 	jmp	@a+dptr
      005DDB                       1129 00243$:
      005DDB 80 06            [24] 1130 	sjmp	00112$
      005DDD 80 1B            [24] 1131 	sjmp	00113$
      005DDF 80 30            [24] 1132 	sjmp	00114$
      005DE1 80 45            [24] 1133 	sjmp	00115$
      005DE3                       1134 00112$:
      005DE3 90 07 DE         [24] 1135 	mov	dptr,#_control_pointer
      005DE6 74 C3            [12] 1136 	mov	a,#_LanguageString
      005DE8 F0               [24] 1137 	movx	@dptr,a
      005DE9 74 C0            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005DEB A3               [24] 1139 	inc	dptr
      005DEC F0               [24] 1140 	movx	@dptr,a
      005DED 90 C0 C3         [24] 1141 	mov	dptr,#_LanguageString
      005DF0 E4               [12] 1142 	clr	a
      005DF1 93               [24] 1143 	movc	a,@a+dptr
      005DF2 FE               [12] 1144 	mov	r6,a
      005DF3 7D 00            [12] 1145 	mov	r5,#0x00
      005DF5 8E 82            [24] 1146 	mov	dpl, r6
      005DF7 8D 83            [24] 1147 	mov	dph, r5
      005DF9 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005DFA                       1150 00113$:
      005DFA 90 07 DE         [24] 1151 	mov	dptr,#_control_pointer
      005DFD 74 C7            [12] 1152 	mov	a,#_ManufacturerString
      005DFF F0               [24] 1153 	movx	@dptr,a
      005E00 74 C0            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005E02 A3               [24] 1155 	inc	dptr
      005E03 F0               [24] 1156 	movx	@dptr,a
      005E04 90 C0 C7         [24] 1157 	mov	dptr,#_ManufacturerString
      005E07 E4               [12] 1158 	clr	a
      005E08 93               [24] 1159 	movc	a,@a+dptr
      005E09 FE               [12] 1160 	mov	r6,a
      005E0A 7D 00            [12] 1161 	mov	r5,#0x00
      005E0C 8E 82            [24] 1162 	mov	dpl, r6
      005E0E 8D 83            [24] 1163 	mov	dph, r5
      005E10 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005E11                       1166 00114$:
      005E11 90 07 DE         [24] 1167 	mov	dptr,#_control_pointer
      005E14 74 D5            [12] 1168 	mov	a,#_ProductString
      005E16 F0               [24] 1169 	movx	@dptr,a
      005E17 74 C0            [12] 1170 	mov	a,#(_ProductString >> 8)
      005E19 A3               [24] 1171 	inc	dptr
      005E1A F0               [24] 1172 	movx	@dptr,a
      005E1B 90 C0 D5         [24] 1173 	mov	dptr,#_ProductString
      005E1E E4               [12] 1174 	clr	a
      005E1F 93               [24] 1175 	movc	a,@a+dptr
      005E20 FE               [12] 1176 	mov	r6,a
      005E21 7D 00            [12] 1177 	mov	r5,#0x00
      005E23 8E 82            [24] 1178 	mov	dpl, r6
      005E25 8D 83            [24] 1179 	mov	dph, r5
      005E27 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005E28                       1182 00115$:
      005E28 90 07 DE         [24] 1183 	mov	dptr,#_control_pointer
      005E2B 74 0D            [12] 1184 	mov	a,#_SerialNumberString
      005E2D F0               [24] 1185 	movx	@dptr,a
      005E2E 74 C1            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005E30 A3               [24] 1187 	inc	dptr
      005E31 F0               [24] 1188 	movx	@dptr,a
      005E32 90 C1 0D         [24] 1189 	mov	dptr,#_SerialNumberString
      005E35 E4               [12] 1190 	clr	a
      005E36 93               [24] 1191 	movc	a,@a+dptr
      005E37 FE               [12] 1192 	mov	r6,a
      005E38 7D 00            [12] 1193 	mov	r5,#0x00
      005E3A 8E 82            [24] 1194 	mov	dpl, r6
      005E3C 8D 83            [24] 1195 	mov	dph, r5
      005E3E 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      005E3F                       1198 00116$:
      005E3F 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005E42 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      005E43                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      005E43 90 07 E0         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005E46 E0               [24] 1205 	movx	a,@dptr
      005E47 70 11            [24] 1206 	jnz	00120$
      005E49 90 07 E1         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005E4C E0               [24] 1208 	movx	a,@dptr
      005E4D FD               [12] 1209 	mov	r5,a
      005E4E A3               [24] 1210 	inc	dptr
      005E4F E0               [24] 1211 	movx	a,@dptr
      005E50 FE               [12] 1212 	mov	r6,a
      005E51 C3               [12] 1213 	clr	c
      005E52 ED               [12] 1214 	mov	a,r5
      005E53 94 03            [12] 1215 	subb	a,#0x03
      005E55 EE               [12] 1216 	mov	a,r6
      005E56 94 00            [12] 1217 	subb	a,#0x00
      005E58 40 04            [24] 1218 	jc	00121$
      005E5A                       1219 00120$:
      005E5A 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005E5D 22               [24] 1221 	ret
      005E5E                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005E5E BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005E61 80 03            [24] 1225 	sjmp	00127$
      005E63                       1226 00246$:
      005E63 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      005E66                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005E66 ED               [12] 1230 	mov	a,r5
      005E67 75 F0 04         [24] 1231 	mov	b,#0x04
      005E6A A4               [48] 1232 	mul	ab
      005E6B 24 E6            [12] 1233 	add	a, #_interface_descriptors
      005E6D FE               [12] 1234 	mov	r6,a
      005E6E 74 B9            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      005E70 35 F0            [12] 1236 	addc	a, b
      005E72 FF               [12] 1237 	mov	r7,a
      005E73 8E 82            [24] 1238 	mov	dpl,r6
      005E75 8F 83            [24] 1239 	mov	dph,r7
      005E77 A3               [24] 1240 	inc	dptr
      005E78 A3               [24] 1241 	inc	dptr
      005E79 E4               [12] 1242 	clr	a
      005E7A 93               [24] 1243 	movc	a,@a+dptr
      005E7B FC               [12] 1244 	mov	r4,a
      005E7C A3               [24] 1245 	inc	dptr
      005E7D E4               [12] 1246 	clr	a
      005E7E 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      005E7F FD               [12] 1249 	mov	r5,a
      005E80 4C               [12] 1250 	orl	a,r4
      005E81 70 04            [24] 1251 	jnz	00124$
      005E83 90 00 00         [24] 1252 	mov	dptr,#0x0000
      005E86 22               [24] 1253 	ret
      005E87                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      005E87 90 07 E3         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      005E8A E0               [24] 1257 	movx	a,@dptr
      005E8B FB               [12] 1258 	mov	r3,a
      005E8C BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005E8F 8E 82            [24] 1261 	mov	dpl,r6
      005E91 8F 83            [24] 1262 	mov	dph,r7
      005E93 E4               [12] 1263 	clr	a
      005E94 93               [24] 1264 	movc	a,@a+dptr
      005E95 FE               [12] 1265 	mov	r6,a
      005E96 A3               [24] 1266 	inc	dptr
      005E97 E4               [12] 1267 	clr	a
      005E98 93               [24] 1268 	movc	a,@a+dptr
      005E99 FF               [12] 1269 	mov	r7,a
      005E9A 90 07 DE         [24] 1270 	mov	dptr,#_control_pointer
      005E9D EE               [12] 1271 	mov	a,r6
      005E9E F0               [24] 1272 	movx	@dptr,a
      005E9F EF               [12] 1273 	mov	a,r7
      005EA0 A3               [24] 1274 	inc	dptr
      005EA1 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      005EA2 74 07            [12] 1277 	mov	a,#0x07
      005EA4 2C               [12] 1278 	add	a, r4
      005EA5 F5 82            [12] 1279 	mov	dpl,a
      005EA7 E4               [12] 1280 	clr	a
      005EA8 3D               [12] 1281 	addc	a, r5
      005EA9 F5 83            [12] 1282 	mov	dph,a
      005EAB E4               [12] 1283 	clr	a
      005EAC 93               [24] 1284 	movc	a,@a+dptr
      005EAD FE               [12] 1285 	mov	r6,a
      005EAE A3               [24] 1286 	inc	dptr
      005EAF E4               [12] 1287 	clr	a
      005EB0 93               [24] 1288 	movc	a,@a+dptr
      005EB1 FF               [12] 1289 	mov	r7,a
      005EB2 8E 82            [24] 1290 	mov	dpl, r6
      005EB4 8F 83            [24] 1291 	mov	dph, r7
      005EB6 22               [24] 1292 	ret
      005EB7                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      005EB7 90 07 DE         [24] 1295 	mov	dptr,#_control_pointer
      005EBA EC               [12] 1296 	mov	a,r4
      005EBB F0               [24] 1297 	movx	@dptr,a
      005EBC ED               [12] 1298 	mov	a,r5
      005EBD A3               [24] 1299 	inc	dptr
      005EBE F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      005EBF 90 00 09         [24] 1302 	mov	dptr,#0x0009
      005EC2 22               [24] 1303 	ret
      005EC3                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      005EC3 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      005EC6 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      005EC7                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005EC7 90 10 00         [24] 1330 	mov	dptr,#0x1000
      005ECA E0               [24] 1331 	movx	a,@dptr
      005ECB FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005ECC A3               [24] 1334 	inc	dptr
      005ECD A3               [24] 1335 	inc	dptr
      005ECE E0               [24] 1336 	movx	a,@dptr
      005ECF FE               [12] 1337 	mov	r6,a
      005ED0 A3               [24] 1338 	inc	dptr
      005ED1 E0               [24] 1339 	movx	a,@dptr
      005ED2 FC               [12] 1340 	mov	r4,a
      005ED3 7D 00            [12] 1341 	mov	r5,#0x00
      005ED5 8E 03            [24] 1342 	mov	ar3,r6
      005ED7 7E 00            [12] 1343 	mov	r6,#0x00
      005ED9 ED               [12] 1344 	mov	a,r5
      005EDA 4B               [12] 1345 	orl	a,r3
      005EDB FD               [12] 1346 	mov	r5,a
      005EDC EC               [12] 1347 	mov	a,r4
      005EDD 4E               [12] 1348 	orl	a,r6
      005EDE FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005EDF A3               [24] 1351 	inc	dptr
      005EE0 E0               [24] 1352 	movx	a,@dptr
      005EE1 FC               [12] 1353 	mov	r4,a
      005EE2 A3               [24] 1354 	inc	dptr
      005EE3 E0               [24] 1355 	movx	a,@dptr
      005EE4 FA               [12] 1356 	mov	r2,a
      005EE5 7B 00            [12] 1357 	mov	r3,#0x00
      005EE7 8C 01            [24] 1358 	mov	ar1,r4
      005EE9 7C 00            [12] 1359 	mov	r4,#0x00
      005EEB EB               [12] 1360 	mov	a,r3
      005EEC 49               [12] 1361 	orl	a,r1
      005EED FB               [12] 1362 	mov	r3,a
      005EEE EA               [12] 1363 	mov	a,r2
      005EEF 4C               [12] 1364 	orl	a,r4
      005EF0 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      005EF1 C3               [12] 1367 	clr	c
      005EF2 EB               [12] 1368 	mov	a,r3
      005EF3 94 03            [12] 1369 	subb	a,#0x03
      005EF5 EC               [12] 1370 	mov	a,r4
      005EF6 94 00            [12] 1371 	subb	a,#0x00
      005EF8 92 14            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      005EFA EB               [12] 1374 	mov	a,r3
      005EFB 4C               [12] 1375 	orl	a,r4
      005EFC B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      005EFF                       1377 01201$:
      005EFF 92 15            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      005F01 ED               [12] 1380 	mov	a,r5
      005F02 4E               [12] 1381 	orl	a,r6
      005F03 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      005F06                       1383 01202$:
                                   1384 ;	assignBit
      005F06 92 18            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      005F08 92 16            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      005F0A 90 07 E6         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      005F0D E4               [12] 1389 	clr	a
      005F0E F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005F0F 90 07 89         [24] 1392 	mov	dptr,#_raw_state
      005F12 E0               [24] 1393 	movx	a,@dptr
      005F13 FA               [12] 1394 	mov	r2,a
      005F14 BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      005F17 90 07 89         [24] 1396 	mov	dptr,#_raw_state
      005F1A E4               [12] 1397 	clr	a
      005F1B F0               [24] 1398 	movx	@dptr,a
      005F1C                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      005F1C C0 07            [24] 1401 	push	ar7
      005F1E 90 07 DB         [24] 1402 	mov	dptr,#_output_kind
      005F21 E4               [12] 1403 	clr	a
      005F22 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      005F23 90 07 DA         [24] 1406 	mov	dptr,#_control_phase
      005F26 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      005F27 90 07 DD         [24] 1409 	mov	dptr,#_control_zlp
      005F2A F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005F2B 90 10 01         [24] 1412 	mov	dptr,#0x1001
      005F2E E0               [24] 1413 	movx	a,@dptr
      005F2F 90 07 7B         [24] 1414 	mov	dptr,#_D0SetupReqCode
      005F32 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005F33 90 10 06         [24] 1417 	mov	dptr,#0x1006
      005F36 E0               [24] 1418 	movx	a,@dptr
      005F37 FA               [12] 1419 	mov	r2,a
      005F38 A3               [24] 1420 	inc	dptr
      005F39 E0               [24] 1421 	movx	a,@dptr
      005F3A F9               [12] 1422 	mov	r1,a
      005F3B 78 00            [12] 1423 	mov	r0,#0x00
      005F3D 7F 00            [12] 1424 	mov	r7,#0x00
      005F3F 90 07 7C         [24] 1425 	mov	dptr,#_D0SetupLen
      005F42 E8               [12] 1426 	mov	a,r0
      005F43 4A               [12] 1427 	orl	a,r2
      005F44 F0               [24] 1428 	movx	@dptr,a
      005F45 E9               [12] 1429 	mov	a,r1
      005F46 4F               [12] 1430 	orl	a,r7
      005F47 A3               [24] 1431 	inc	dptr
      005F48 F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      005F49 90 07 7C         [24] 1434 	mov	dptr,#_D0SetupLen
      005F4C E0               [24] 1435 	movx	a,@dptr
      005F4D FA               [12] 1436 	mov	r2,a
      005F4E A3               [24] 1437 	inc	dptr
      005F4F E0               [24] 1438 	movx	a,@dptr
      005F50 4A               [12] 1439 	orl	a,r2
      005F51 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      005F54                       1441 01205$:
      005F54 92 17            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005F56 90 22 00         [24] 1444 	mov	dptr,#0x2200
      005F59 74 C2            [12] 1445 	mov	a,#0xc2
      005F5B F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      005F5C 90 22 08         [24] 1448 	mov	dptr,#0x2208
      005F5F E4               [12] 1449 	clr	a
      005F60 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      005F61 90 07 7B         [24] 1452 	mov	dptr,#_D0SetupReqCode
      005F64 E0               [24] 1453 	movx	a,@dptr
      005F65 F5 26            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      005F67 C3               [12] 1455 	clr	c
      005F68 74 0B            [12] 1456 	mov	a,#0x0b
      005F6A 95 26            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      005F6C D0 07            [24] 1458 	pop	ar7
      005F6E 50 03            [24] 1459 	jnc	01206$
      005F70 02 5C AE         [24] 1460 	ljmp	_control_stall
      005F73                       1461 01206$:
                                   1462 ;	free result
      005F73 E5 26            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      005F75 F5 F0            [12] 1464 	mov	b,a
      005F77 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      005F79 83               [24] 1466 	movc	a,@a+pc
      005F7A F5 82            [12] 1467 	mov	dpl,a
      005F7C E5 F0            [12] 1468 	mov	a,b
      005F7E 24 10            [12] 1469 	add	a,#(01208$-3-.)
      005F80 83               [24] 1470 	movc	a,@a+pc
      005F81 F5 83            [12] 1471 	mov	dph,a
      005F83 E4               [12] 1472 	clr	a
      005F84 73               [24] 1473 	jmp	@a+dptr
      005F85                       1474 01207$:
      005F85 2D                    1475 	.db	00188$
      005F86 D3                    1476 	.db	00205$
      005F87 16                    1477 	.db	00282$
      005F88 D3                    1478 	.db	00205$
      005F89 5A                    1479 	.db	00290$
      005F8A 57                    1480 	.db	00116$
      005F8B 9D                    1481 	.db	00103$
      005F8C 5A                    1482 	.db	00290$
      005F8D 5C                    1483 	.db	00150$
      005F8E 80                    1484 	.db	00123$
      005F8F 8C                    1485 	.db	00157$
      005F90 DF                    1486 	.db	00173$
      005F91                       1487 01208$:
      005F91 62                    1488 	.db	00188$>>8
      005F92 62                    1489 	.db	00205$>>8
      005F93 66                    1490 	.db	00282$>>8
      005F94 62                    1491 	.db	00205$>>8
      005F95 66                    1492 	.db	00290$>>8
      005F96 60                    1493 	.db	00116$>>8
      005F97 5F                    1494 	.db	00103$>>8
      005F98 66                    1495 	.db	00290$>>8
      005F99 61                    1496 	.db	00150$>>8
      005F9A 60                    1497 	.db	00123$>>8
      005F9B 61                    1498 	.db	00157$>>8
      005F9C 61                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      005F9D                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      005F9D BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      005FA0 80 08            [24] 1504 	sjmp	00112$
      005FA2                       1505 01209$:
      005FA2 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      005FA5 80 03            [24] 1507 	sjmp	01211$
      005FA7                       1508 01210$:
      005FA7 02 5C AE         [24] 1509 	ljmp	_control_stall
      005FAA                       1510 01211$:
      005FAA                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005FAA 8E 01            [24] 1513 	mov	ar1,r6
      005FAC B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      005FAF 80 09            [24] 1515 	sjmp	00301$
      005FB1                       1516 01212$:
      005FB1 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      005FB4 80 04            [24] 1518 	sjmp	00301$
      005FB6                       1519 01213$:
                                   1520 ;	assignBit
      005FB6 C2 19            [12] 1521 	clr	_control_setup_sloc2_1_0
      005FB8 80 02            [24] 1522 	sjmp	00302$
      005FBA                       1523 00301$:
                                   1524 ;	assignBit
      005FBA D2 19            [12] 1525 	setb	_control_setup_sloc2_1_0
      005FBC                       1526 00302$:
      005FBC E4               [12] 1527 	clr	a
      005FBD BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      005FC0 04               [12] 1529 	inc	a
      005FC1                       1530 01214$:
      005FC1 FA               [12] 1531 	mov	r2,a
      005FC2 A2 19            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      005FC4 E4               [12] 1533 	clr	a
      005FC5 33               [12] 1534 	rlc	a
      005FC6 B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      005FC9 80 03            [24] 1536 	sjmp	00105$
      005FCB                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      005FCB 02 5C AE         [24] 1539 	ljmp	_control_stall
      005FCE                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      005FCE 8E 02            [24] 1542 	mov	ar2,r6
      005FD0 90 07 E0         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      005FD3 ED               [12] 1544 	mov	a,r5
      005FD4 F0               [24] 1545 	movx	@dptr,a
      005FD5 90 07 E1         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      005FD8 EB               [12] 1547 	mov	a,r3
      005FD9 F0               [24] 1548 	movx	@dptr,a
      005FDA EC               [12] 1549 	mov	a,r4
      005FDB A3               [24] 1550 	inc	dptr
      005FDC F0               [24] 1551 	movx	@dptr,a
      005FDD 8A 82            [24] 1552 	mov	dpl, r2
      005FDF 12 5D 4C         [24] 1553 	lcall	_descriptor_select
      005FE2 85 82 27         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      005FE5 85 83 28         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      005FE8 E5 27            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      005FEA 45 28            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005FEC 70 03            [24] 1559 	jnz	00107$
      005FEE 02 5C AE         [24] 1560 	ljmp	_control_stall
      005FF1                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005FF1 90 07 7C         [24] 1563 	mov	dptr,#_D0SetupLen
      005FF4 E0               [24] 1564 	movx	a,@dptr
      005FF5 F8               [12] 1565 	mov	r0,a
      005FF6 A3               [24] 1566 	inc	dptr
      005FF7 E0               [24] 1567 	movx	a,@dptr
      005FF8 FA               [12] 1568 	mov	r2,a
      005FF9 C3               [12] 1569 	clr	c
      005FFA E5 27            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      005FFC 98               [12] 1571 	subb	a,r0
      005FFD E5 28            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005FFF 9A               [12] 1573 	subb	a,r2
      006000 50 06            [24] 1574 	jnc	00303$
      006002 E5 27            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      006004 54 3F            [12] 1576 	anl	a,#0x3f
      006006 60 04            [24] 1577 	jz	00304$
      006008                       1578 00303$:
                                   1579 ;	assignBit
      006008 C2 19            [12] 1580 	clr	_control_setup_sloc2_1_0
      00600A 80 02            [24] 1581 	sjmp	00305$
      00600C                       1582 00304$:
                                   1583 ;	assignBit
      00600C D2 19            [12] 1584 	setb	_control_setup_sloc2_1_0
      00600E                       1585 00305$:
      00600E 90 07 DD         [24] 1586 	mov	dptr,#_control_zlp
      006011 A2 19            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      006013 E4               [12] 1588 	clr	a
      006014 33               [12] 1589 	rlc	a
      006015 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      006016 90 07 7C         [24] 1592 	mov	dptr,#_D0SetupLen
      006019 E0               [24] 1593 	movx	a,@dptr
      00601A F9               [12] 1594 	mov	r1,a
      00601B A3               [24] 1595 	inc	dptr
      00601C E0               [24] 1596 	movx	a,@dptr
      00601D FA               [12] 1597 	mov	r2,a
      00601E C3               [12] 1598 	clr	c
      00601F E5 27            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      006021 99               [12] 1600 	subb	a,r1
      006022 E5 28            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006024 9A               [12] 1602 	subb	a,r2
      006025 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      006027 90 07 7C         [24] 1605 	mov	dptr,#_D0SetupLen
      00602A E5 27            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      00602C F0               [24] 1607 	movx	@dptr,a
      00602D E5 28            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00602F A3               [24] 1609 	inc	dptr
      006030 F0               [24] 1610 	movx	@dptr,a
      006031                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      006031 90 07 7C         [24] 1613 	mov	dptr,#_D0SetupLen
      006034 E0               [24] 1614 	movx	a,@dptr
      006035 F9               [12] 1615 	mov	r1,a
      006036 A3               [24] 1616 	inc	dptr
      006037 E0               [24] 1617 	movx	a,@dptr
      006038 49               [12] 1618 	orl	a,r1
      006039 60 04            [24] 1619 	jz	00306$
      00603B 7A 01            [12] 1620 	mov	r2,#0x01
      00603D 80 02            [24] 1621 	sjmp	00307$
      00603F                       1622 00306$:
      00603F 7A 02            [12] 1623 	mov	r2,#0x02
      006041                       1624 00307$:
      006041 90 07 DA         [24] 1625 	mov	dptr,#_control_phase
      006044 EA               [12] 1626 	mov	a,r2
      006045 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      006046 90 07 7C         [24] 1629 	mov	dptr,#_D0SetupLen
      006049 E0               [24] 1630 	movx	a,@dptr
      00604A F9               [12] 1631 	mov	r1,a
      00604B A3               [24] 1632 	inc	dptr
      00604C E0               [24] 1633 	movx	a,@dptr
      00604D 49               [12] 1634 	orl	a,r1
      00604E 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      006050 02 5C D0         [24] 1637 	ljmp	_control_next
      006053                       1638 00111$:
      006053 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      006054 02 5C AE         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      006057                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006057 EF               [12] 1645 	mov	a,r7
      006058 70 23            [24] 1646 	jnz	00118$
      00605A 30 15 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      00605D 30 17 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      006060 8D 01            [24] 1649 	mov	ar1,r5
      006062 8E 02            [24] 1650 	mov	ar2,r6
      006064 C3               [12] 1651 	clr	c
      006065 74 7F            [12] 1652 	mov	a,#0x7f
      006067 99               [12] 1653 	subb	a,r1
      006068 E4               [12] 1654 	clr	a
      006069 9A               [12] 1655 	subb	a,r2
      00606A 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      00606C 90 07 7C         [24] 1659 	mov	dptr,#_D0SetupLen
      00606F ED               [12] 1660 	mov	a,r5
      006070 F0               [24] 1661 	movx	@dptr,a
      006071 EE               [12] 1662 	mov	a,r6
      006072 A3               [24] 1663 	inc	dptr
      006073 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      006074 90 07 DA         [24] 1666 	mov	dptr,#_control_phase
      006077 74 03            [12] 1667 	mov	a,#0x03
      006079 F0               [24] 1668 	movx	@dptr,a
      00607A 02 66 5D         [24] 1669 	ljmp	00291$
      00607D                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      00607D 02 5C AE         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      006080                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      006080 EF               [12] 1676 	mov	a,r7
      006081 70 3C            [24] 1677 	jnz	00145$
      006083 30 15 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      006086 30 17 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      006089 8D 01            [24] 1680 	mov	ar1,r5
      00608B 8E 02            [24] 1681 	mov	ar2,r6
      00608D C3               [12] 1682 	clr	c
      00608E 74 01            [12] 1683 	mov	a,#0x01
      006090 99               [12] 1684 	subb	a,r1
      006091 E4               [12] 1685 	clr	a
      006092 9A               [12] 1686 	subb	a,r2
      006093 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      006095 C0 06            [24] 1690 	push	ar6
      006097 C0 05            [24] 1691 	push	ar5
      006099 12 5C 57         [24] 1692 	lcall	_endpoints_reset
      00609C D0 05            [24] 1693 	pop	ar5
      00609E D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      0060A0 90 07 81         [24] 1696 	mov	dptr,#_D0UsbConfig
      0060A3 ED               [12] 1697 	mov	a,r5
      0060A4 F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      0060A5 A2 18            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      0060A7 B3               [12] 1701 	cpl	c
      0060A8 92 19            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      0060AA 90 07 82         [24] 1703 	mov	dptr,#_USB_EnumStatus
      0060AD E4               [12] 1704 	clr	a
      0060AE 33               [12] 1705 	rlc	a
      0060AF F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      0060B0 90 07 AB         [24] 1708 	mov	dptr,#_keyboard_reset
      0060B3 74 01            [12] 1709 	mov	a,#0x01
      0060B5 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      0060B6 90 07 DA         [24] 1712 	mov	dptr,#_control_phase
      0060B9 74 03            [12] 1713 	mov	a,#0x03
      0060BB F0               [24] 1714 	movx	@dptr,a
      0060BC 02 66 5D         [24] 1715 	ljmp	00291$
      0060BF                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      0060BF BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      0060C2 80 03            [24] 1719 	sjmp	01232$
      0060C4                       1720 01231$:
      0060C4 02 5C AE         [24] 1721 	ljmp	_control_stall
      0060C7                       1722 01232$:
      0060C7 90 07 81         [24] 1723 	mov	dptr,#_D0UsbConfig
      0060CA E0               [24] 1724 	movx	a,@dptr
      0060CB 70 03            [24] 1725 	jnz	01233$
      0060CD 02 5C AE         [24] 1726 	ljmp	_control_stall
      0060D0                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      0060D0 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      0060D3 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      0060D6 8D 01            [24] 1731 	mov	ar1,r5
      0060D8 8E 02            [24] 1732 	mov	ar2,r6
      0060DA B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      0060DD BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      0060E0 90 07 7C         [24] 1735 	mov	dptr,#_D0SetupLen
      0060E3 E0               [24] 1736 	movx	a,@dptr
      0060E4 F9               [12] 1737 	mov	r1,a
      0060E5 A3               [24] 1738 	inc	dptr
      0060E6 E0               [24] 1739 	movx	a,@dptr
      0060E7 FA               [12] 1740 	mov	r2,a
      0060E8 B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      0060EB BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      0060EE 90 07 89         [24] 1743 	mov	dptr,#_raw_state
      0060F1 E0               [24] 1744 	movx	a,@dptr
      0060F2 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      0060F4 90 07 89         [24] 1747 	mov	dptr,#_raw_state
      0060F7 74 01            [12] 1748 	mov	a,#0x01
      0060F9 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      0060FA 90 07 DB         [24] 1751 	mov	dptr,#_output_kind
      0060FD F0               [24] 1752 	movx	@dptr,a
      0060FE 80 52            [24] 1753 	sjmp	00136$
      006100                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006100 EB               [12] 1756 	mov	a,r3
      006101 4C               [12] 1757 	orl	a,r4
      006102 70 20            [24] 1758 	jnz	00130$
      006104 8D 01            [24] 1759 	mov	ar1,r5
      006106 8E 02            [24] 1760 	mov	ar2,r6
      006108 B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      00610B BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      00610E 90 07 7C         [24] 1763 	mov	dptr,#_D0SetupLen
      006111 E0               [24] 1764 	movx	a,@dptr
      006112 F9               [12] 1765 	mov	r1,a
      006113 A3               [24] 1766 	inc	dptr
      006114 E0               [24] 1767 	movx	a,@dptr
      006115 FA               [12] 1768 	mov	r2,a
      006116 B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      006119 BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      00611C 90 07 DB         [24] 1772 	mov	dptr,#_output_kind
      00611F 74 02            [12] 1773 	mov	a,#0x02
      006121 F0               [24] 1774 	movx	@dptr,a
      006122 80 2E            [24] 1775 	sjmp	00136$
      006124                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006124 BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      006127 BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      00612A 8D 01            [24] 1780 	mov	ar1,r5
      00612C 8E 02            [24] 1781 	mov	ar2,r6
      00612E B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      006131 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      006134 90 07 7C         [24] 1784 	mov	dptr,#_D0SetupLen
      006137 E0               [24] 1785 	movx	a,@dptr
      006138 F9               [12] 1786 	mov	r1,a
      006139 A3               [24] 1787 	inc	dptr
      00613A E0               [24] 1788 	movx	a,@dptr
      00613B FA               [12] 1789 	mov	r2,a
      00613C B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      00613F BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      006142 90 07 DB         [24] 1793 	mov	dptr,#_output_kind
      006145 74 03            [12] 1794 	mov	a,#0x03
      006147 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      006148 90 07 DC         [24] 1797 	mov	dptr,#_output_report_id
      00614B 23               [12] 1798 	rl	a
      00614C F0               [24] 1799 	movx	@dptr,a
      00614D 80 03            [24] 1800 	sjmp	00136$
      00614F                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      00614F 02 5C AE         [24] 1803 	ljmp	_control_stall
      006152                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      006152 90 07 DA         [24] 1806 	mov	dptr,#_control_phase
      006155 74 04            [12] 1807 	mov	a,#0x04
      006157 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      006158 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      006159 02 5C AE         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      00615C                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      00615C BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      00615F 30 15 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      006162 30 16 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      006165 90 07 7C         [24] 1819 	mov	dptr,#_D0SetupLen
      006168 E0               [24] 1820 	movx	a,@dptr
      006169 F9               [12] 1821 	mov	r1,a
      00616A A3               [24] 1822 	inc	dptr
      00616B E0               [24] 1823 	movx	a,@dptr
      00616C FA               [12] 1824 	mov	r2,a
      00616D B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      006170 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      006173 90 07 81         [24] 1828 	mov	dptr,#_D0UsbConfig
      006176 E0               [24] 1829 	movx	a,@dptr
      006177 90 10 00         [24] 1830 	mov	dptr,#0x1000
      00617A F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      00617B 90 22 08         [24] 1833 	mov	dptr,#0x2208
      00617E 74 01            [12] 1834 	mov	a,#0x01
      006180 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      006181 90 07 DA         [24] 1837 	mov	dptr,#_control_phase
      006184 04               [12] 1838 	inc	a
      006185 F0               [24] 1839 	movx	@dptr,a
      006186 02 66 5D         [24] 1840 	ljmp	00291$
      006189                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      006189 02 5C AE         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      00618C                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      00618C BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      00618F 30 14 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      006192 30 16 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      006195 90 07 7C         [24] 1850 	mov	dptr,#_D0SetupLen
      006198 E0               [24] 1851 	movx	a,@dptr
      006199 F9               [12] 1852 	mov	r1,a
      00619A A3               [24] 1853 	inc	dptr
      00619B E0               [24] 1854 	movx	a,@dptr
      00619C FA               [12] 1855 	mov	r2,a
      00619D B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      0061A0 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      0061A3 90 07 81         [24] 1858 	mov	dptr,#_D0UsbConfig
      0061A6 E0               [24] 1859 	movx	a,@dptr
      0061A7 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      0061A9 90 10 00         [24] 1862 	mov	dptr,#0x1000
      0061AC E4               [12] 1863 	clr	a
      0061AD F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      0061AE 90 22 08         [24] 1866 	mov	dptr,#0x2208
      0061B1 04               [12] 1867 	inc	a
      0061B2 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      0061B3 90 07 DA         [24] 1870 	mov	dptr,#_control_phase
      0061B6 04               [12] 1871 	inc	a
      0061B7 F0               [24] 1872 	movx	@dptr,a
      0061B8 02 66 5D         [24] 1873 	ljmp	00291$
      0061BB                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0061BB 30 14 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      0061BE 90 07 81         [24] 1877 	mov	dptr,#_D0UsbConfig
      0061C1 E0               [24] 1878 	movx	a,@dptr
      0061C2 60 18            [24] 1879 	jz	00161$
      0061C4 BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      0061C7 30 17 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      0061CA EB               [12] 1883 	mov	a,r3
      0061CB 4C               [12] 1884 	orl	a,r4
      0061CC 70 05            [24] 1885 	jnz	00159$
      0061CE 90 06 59         [24] 1886 	mov	dptr,#_keyboard_idle
      0061D1 EE               [12] 1887 	mov	a,r6
      0061D2 F0               [24] 1888 	movx	@dptr,a
      0061D3                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      0061D3 90 07 DA         [24] 1891 	mov	dptr,#_control_phase
      0061D6 74 03            [12] 1892 	mov	a,#0x03
      0061D8 F0               [24] 1893 	movx	@dptr,a
      0061D9 02 66 5D         [24] 1894 	ljmp	00291$
      0061DC                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      0061DC 02 5C AE         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0061DF                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0061DF BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      0061E2 30 14 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      0061E5 30 16 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      0061E8 30 17 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      0061EB 90 07 81         [24] 1905 	mov	dptr,#_D0UsbConfig
      0061EE E0               [24] 1906 	movx	a,@dptr
      0061EF 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      0061F1 90 07 DA         [24] 1909 	mov	dptr,#_control_phase
      0061F4 74 03            [12] 1910 	mov	a,#0x03
      0061F6 F0               [24] 1911 	movx	@dptr,a
      0061F7 02 66 5D         [24] 1912 	ljmp	00291$
      0061FA                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0061FA EB               [12] 1915 	mov	a,r3
      0061FB 4C               [12] 1916 	orl	a,r4
      0061FC 70 2C            [24] 1917 	jnz	00175$
      0061FE 90 07 81         [24] 1918 	mov	dptr,#_D0UsbConfig
      006201 E0               [24] 1919 	movx	a,@dptr
      006202 60 26            [24] 1920 	jz	00175$
      006204 BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      006207 30 17 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      00620A 8D 01            [24] 1923 	mov	ar1,r5
      00620C 8E 02            [24] 1924 	mov	ar2,r6
      00620E C3               [12] 1925 	clr	c
      00620F 74 01            [12] 1926 	mov	a,#0x01
      006211 99               [12] 1927 	subb	a,r1
      006212 E4               [12] 1928 	clr	a
      006213 9A               [12] 1929 	subb	a,r2
      006214 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006216 90 0D 9D         [24] 1933 	mov	dptr,#_keyboard_protocol
      006219 ED               [12] 1934 	mov	a,r5
      00621A F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      00621B 90 07 AB         [24] 1937 	mov	dptr,#_keyboard_reset
      00621E 74 01            [12] 1938 	mov	a,#0x01
      006220 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      006221 90 07 DA         [24] 1941 	mov	dptr,#_control_phase
      006224 74 03            [12] 1942 	mov	a,#0x03
      006226 F0               [24] 1943 	movx	@dptr,a
      006227 02 66 5D         [24] 1944 	ljmp	00291$
      00622A                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      00622A 02 5C AE         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      00622D                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      00622D 20 16 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      006230 02 5C AE         [24] 1952 	ljmp	_control_stall
      006233                       1953 01283$:
      006233 90 07 7C         [24] 1954 	mov	dptr,#_D0SetupLen
      006236 E0               [24] 1955 	movx	a,@dptr
      006237 F9               [12] 1956 	mov	r1,a
      006238 A3               [24] 1957 	inc	dptr
      006239 E0               [24] 1958 	movx	a,@dptr
      00623A FA               [12] 1959 	mov	r2,a
      00623B B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      00623E BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      006241 80 03            [24] 1962 	sjmp	01285$
      006243                       1963 01284$:
      006243 02 5C AE         [24] 1964 	ljmp	_control_stall
      006246                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006246 E4               [12] 1967 	clr	a
      006247 BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      00624A 04               [12] 1969 	inc	a
      00624B                       1970 01286$:
      00624B FA               [12] 1971 	mov	r2,a
      00624C 60 03            [24] 1972 	jz	00196$
      00624E 20 15 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      006251                       1974 00196$:
      006251 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      006254 30 14 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      006257 90 07 81         [24] 1977 	mov	dptr,#_D0UsbConfig
      00625A E0               [24] 1978 	movx	a,@dptr
      00625B 70 29            [24] 1979 	jnz	00189$
      00625D                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      00625D BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      006260 90 07 81         [24] 1983 	mov	dptr,#_D0UsbConfig
      006263 E0               [24] 1984 	movx	a,@dptr
      006264 60 6A            [24] 1985 	jz	00190$
      006266 EB               [12] 1986 	mov	a,r3
      006267 4C               [12] 1987 	orl	a,r4
      006268 60 1C            [24] 1988 	jz	00189$
      00626A 8B 00            [24] 1989 	mov	ar0,r3
      00626C 8C 01            [24] 1990 	mov	ar1,r4
      00626E B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      006271 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      006274 80 10            [24] 1993 	sjmp	00189$
      006276                       1994 01298$:
      006276 C3               [12] 1995 	clr	c
      006277 E8               [12] 1996 	mov	a,r0
      006278 94 81            [12] 1997 	subb	a,#0x81
      00627A E9               [12] 1998 	mov	a,r1
      00627B 94 00            [12] 1999 	subb	a,#0x00
      00627D 40 51            [24] 2000 	jc	00190$
      00627F 74 83            [12] 2001 	mov	a,#0x83
      006281 98               [12] 2002 	subb	a,r0
      006282 E4               [12] 2003 	clr	a
      006283 99               [12] 2004 	subb	a,r1
      006284 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      006286                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      006286 8B 01            [24] 2009 	mov	ar1,r3
      006288 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      00628B EA               [12] 2012 	mov	a,r2
      00628C 60 0B            [24] 2013 	jz	00308$
      00628E 90 07 83         [24] 2014 	mov	dptr,#_USB_SleepStatus
      006291 E0               [24] 2015 	movx	a,@dptr
      006292 54 01            [12] 2016 	anl	a,#0x01
      006294 25 E0            [12] 2017 	add	a,acc
      006296 FA               [12] 2018 	mov	r2,a
      006297 80 22            [24] 2019 	sjmp	00309$
      006299                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006299 BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      00629C E9               [12] 2023 	mov	a,r1
      00629D 60 18            [24] 2024 	jz	00310$
      00629F 89 00            [24] 2025 	mov	ar0,r1
      0062A1 79 00            [12] 2026 	mov	r1,#0x00
      0062A3 74 22            [12] 2027 	mov	a,#0x22
      0062A5 29               [12] 2028 	add	a, r1
      0062A6 F9               [12] 2029 	mov	r1,a
      0062A7 88 82            [24] 2030 	mov	dpl,r0
      0062A9 89 83            [24] 2031 	mov	dph,r1
      0062AB E0               [24] 2032 	movx	a,@dptr
      0062AC F9               [12] 2033 	mov	r1,a
      0062AD 53 01 03         [24] 2034 	anl	ar1,#0x03
      0062B0 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      0062B3 79 01            [12] 2036 	mov	r1,#0x01
      0062B5 80 02            [24] 2037 	sjmp	00311$
      0062B7                       2038 00310$:
      0062B7 79 00            [12] 2039 	mov	r1,#0x00
      0062B9                       2040 00311$:
      0062B9 89 02            [24] 2041 	mov	ar2,r1
      0062BB                       2042 00309$:
      0062BB 90 10 00         [24] 2043 	mov	dptr,#0x1000
      0062BE EA               [12] 2044 	mov	a,r2
      0062BF F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      0062C0 A3               [24] 2047 	inc	dptr
      0062C1 E4               [12] 2048 	clr	a
      0062C2 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      0062C3 90 22 08         [24] 2051 	mov	dptr,#0x2208
      0062C6 74 02            [12] 2052 	mov	a,#0x02
      0062C8 F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      0062C9 90 07 DA         [24] 2055 	mov	dptr,#_control_phase
      0062CC F0               [24] 2056 	movx	@dptr,a
      0062CD 02 66 5D         [24] 2057 	ljmp	00291$
      0062D0                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      0062D0 02 5C AE         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0062D3                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      0062D3 20 17 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      0062D6 02 63 66         [24] 2065 	ljmp	00279$
      0062D9                       2066 01307$:
      0062D9 90 07 81         [24] 2067 	mov	dptr,#_D0UsbConfig
      0062DC E0               [24] 2068 	movx	a,@dptr
      0062DD 70 03            [24] 2069 	jnz	01308$
      0062DF 02 63 66         [24] 2070 	ljmp	00279$
      0062E2                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      0062E2 EF               [12] 2073 	mov	a,r7
      0062E3 70 29            [24] 2074 	jnz	00218$
      0062E5 8D 01            [24] 2075 	mov	ar1,r5
      0062E7 8E 02            [24] 2076 	mov	ar2,r6
      0062E9 B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      0062EC BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      0062EF 30 15 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0062F2 90 07 7B         [24] 2081 	mov	dptr,#_D0SetupReqCode
      0062F5 E0               [24] 2082 	movx	a,@dptr
      0062F6 FA               [12] 2083 	mov	r2,a
      0062F7 BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      0062FA 90 07 83         [24] 2085 	mov	dptr,#_USB_SleepStatus
      0062FD E0               [24] 2086 	movx	a,@dptr
      0062FE 43 E0 01         [24] 2087 	orl	acc,#0x01
      006301 F0               [24] 2088 	movx	@dptr,a
      006302 80 59            [24] 2089 	sjmp	00219$
      006304                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006304 90 07 83         [24] 2092 	mov	dptr,#_USB_SleepStatus
      006307 E0               [24] 2093 	movx	a,@dptr
      006308 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      00630B F0               [24] 2095 	movx	@dptr,a
      00630C 80 4F            [24] 2096 	sjmp	00219$
      00630E                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00630E BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      006311 30 16 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      006314 8B 01            [24] 2101 	mov	ar1,r3
      006316 8C 02            [24] 2102 	mov	ar2,r4
      006318 C3               [12] 2103 	clr	c
      006319 E9               [12] 2104 	mov	a,r1
      00631A 94 81            [12] 2105 	subb	a,#0x81
      00631C EA               [12] 2106 	mov	a,r2
      00631D 94 00            [12] 2107 	subb	a,#0x00
      00631F 40 39            [24] 2108 	jc	00212$
      006321 74 83            [12] 2109 	mov	a,#0x83
      006323 99               [12] 2110 	subb	a,r1
      006324 E4               [12] 2111 	clr	a
      006325 9A               [12] 2112 	subb	a,r2
      006326 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006328 8B 02            [24] 2116 	mov	ar2,r3
      00632A 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      00632D 8A 00            [24] 2119 	mov	ar0,r2
      00632F 79 00            [12] 2120 	mov	r1,#0x00
      006331 74 22            [12] 2121 	mov	a,#0x22
      006333 29               [12] 2122 	add	a, r1
      006334 F9               [12] 2123 	mov	r1,a
      006335 88 27            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      006337 89 28            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006339 90 07 7B         [24] 2126 	mov	dptr,#_D0SetupReqCode
      00633C E0               [24] 2127 	movx	a,@dptr
      00633D F9               [12] 2128 	mov	r1,a
      00633E B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006341 79 03            [12] 2130 	mov	r1,#0x03
      006343 80 02            [24] 2131 	sjmp	00319$
      006345                       2132 00318$:
      006345 79 02            [12] 2133 	mov	r1,#0x02
      006347                       2134 00319$:
      006347 43 01 10         [24] 2135 	orl	ar1,#0x10
      00634A 85 27 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      00634D 85 28 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006350 E9               [12] 2138 	mov	a,r1
      006351 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006352 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      006355 12 5C 3A         [24] 2142 	lcall	_raw_complete
      006358 80 03            [24] 2143 	sjmp	00219$
      00635A                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      00635A 02 5C AE         [24] 2146 	ljmp	_control_stall
      00635D                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      00635D 90 07 DA         [24] 2149 	mov	dptr,#_control_phase
      006360 74 03            [12] 2150 	mov	a,#0x03
      006362 F0               [24] 2151 	movx	@dptr,a
      006363 02 66 5D         [24] 2152 	ljmp	00291$
      006366                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006366 E4               [12] 2155 	clr	a
      006367 BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      00636A 04               [12] 2157 	inc	a
      00636B                       2158 01324$:
      00636B FA               [12] 2159 	mov	r2,a
      00636C 70 03            [24] 2160 	jnz	01326$
      00636E 02 65 D8         [24] 2161 	ljmp	00273$
      006371                       2162 01326$:
      006371 90 07 7B         [24] 2163 	mov	dptr,#_D0SetupReqCode
      006374 E0               [24] 2164 	movx	a,@dptr
      006375 F9               [12] 2165 	mov	r1,a
      006376 B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      006379 80 03            [24] 2167 	sjmp	01328$
      00637B                       2168 01327$:
      00637B 02 65 D8         [24] 2169 	ljmp	00273$
      00637E                       2170 01328$:
      00637E 90 07 81         [24] 2171 	mov	dptr,#_D0UsbConfig
      006381 E0               [24] 2172 	movx	a,@dptr
      006382 70 03            [24] 2173 	jnz	01329$
      006384 02 65 D8         [24] 2174 	ljmp	00273$
      006387                       2175 01329$:
      006387 90 07 7C         [24] 2176 	mov	dptr,#_D0SetupLen
      00638A E0               [24] 2177 	movx	a,@dptr
      00638B F8               [12] 2178 	mov	r0,a
      00638C A3               [24] 2179 	inc	dptr
      00638D E0               [24] 2180 	movx	a,@dptr
      00638E 48               [12] 2181 	orl	a,r0
      00638F 70 03            [24] 2182 	jnz	01330$
      006391 02 65 D8         [24] 2183 	ljmp	00273$
      006394                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      006394 C0 03            [24] 2186 	push	ar3
      006396 C0 04            [24] 2187 	push	ar4
      006398 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      00639A 8E 00            [24] 2190 	mov	ar0,r6
      00639C B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      00639F E8               [12] 2192 	mov	a,r0
      0063A0 80 01            [24] 2193 	sjmp	01332$
      0063A2                       2194 01331$:
      0063A2 E4               [12] 2195 	clr	a
      0063A3                       2196 01332$:
      0063A3 F5 27            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      0063A5 D0 04            [24] 2198 	pop	ar4
      0063A7 D0 03            [24] 2199 	pop	ar3
      0063A9 E5 27            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      0063AB 60 17            [24] 2201 	jz	00251$
      0063AD EB               [12] 2202 	mov	a,r3
      0063AE 4C               [12] 2203 	orl	a,r4
      0063AF 70 13            [24] 2204 	jnz	00251$
      0063B1 E9               [12] 2205 	mov	a,r1
      0063B2 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      0063B4 90 07 E4         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      0063B7 74 08            [12] 2209 	mov	a,#0x08
      0063B9 F0               [24] 2210 	movx	@dptr,a
      0063BA E4               [12] 2211 	clr	a
      0063BB A3               [24] 2212 	inc	dptr
      0063BC F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      0063BD 90 07 E6         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      0063C0 F0               [24] 2216 	movx	@dptr,a
      0063C1 02 65 48         [24] 2217 	ljmp	00252$
      0063C4                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0063C4 E5 27            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      0063C6 60 27            [24] 2221 	jz	00245$
      0063C8 BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      0063CB BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0063CE B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      0063D1                       2226 01339$:
      0063D1 50 1C            [24] 2227 	jnc	00245$
      0063D3 E9               [12] 2228 	mov	a,r1
      0063D4 90 B9 DF         [24] 2229 	mov	dptr,#_shared_lengths
      0063D7 93               [24] 2230 	movc	a,@a+dptr
      0063D8 F8               [12] 2231 	mov	r0,a
      0063D9 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      0063DB 90 07 E4         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      0063DE E8               [12] 2235 	mov	a,r0
      0063DF F0               [24] 2236 	movx	@dptr,a
      0063E0 E4               [12] 2237 	clr	a
      0063E1 A3               [24] 2238 	inc	dptr
      0063E2 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      0063E3 E9               [12] 2241 	mov	a,r1
      0063E4 90 B9 D8         [24] 2242 	mov	dptr,#_shared_offsets
      0063E7 93               [24] 2243 	movc	a,@a+dptr
      0063E8 90 07 E6         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      0063EB F0               [24] 2245 	movx	@dptr,a
      0063EC 02 65 48         [24] 2246 	ljmp	00252$
      0063EF                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0063EF E5 27            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      0063F1 60 7A            [24] 2250 	jz	00240$
      0063F3 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      0063F6 BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      0063F9 E9               [12] 2253 	mov	a,r1
      0063FA 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0063FC 90 07 7C         [24] 2256 	mov	dptr,#_D0SetupLen
      0063FF E0               [24] 2257 	movx	a,@dptr
      006400 F8               [12] 2258 	mov	r0,a
      006401 A3               [24] 2259 	inc	dptr
      006402 E0               [24] 2260 	movx	a,@dptr
      006403 F9               [12] 2261 	mov	r1,a
      006404 C3               [12] 2262 	clr	c
      006405 E8               [12] 2263 	mov	a,r0
      006406 94 20            [12] 2264 	subb	a,#0x20
      006408 E9               [12] 2265 	mov	a,r1
      006409 94 00            [12] 2266 	subb	a,#0x00
      00640B 50 0A            [24] 2267 	jnc	00320$
      00640D 90 07 7C         [24] 2268 	mov	dptr,#_D0SetupLen
      006410 E0               [24] 2269 	movx	a,@dptr
      006411 F8               [12] 2270 	mov	r0,a
      006412 A3               [24] 2271 	inc	dptr
      006413 E0               [24] 2272 	movx	a,@dptr
      006414 F9               [12] 2273 	mov	r1,a
      006415 80 04            [24] 2274 	sjmp	00321$
      006417                       2275 00320$:
      006417 78 20            [12] 2276 	mov	r0,#0x20
      006419 79 00            [12] 2277 	mov	r1,#0x00
      00641B                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      00641B 75 27 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      00641E                       2281 00293$:
      00641E C0 03            [24] 2282 	push	ar3
      006420 C0 04            [24] 2283 	push	ar4
      006422 AB 27            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      006424 7C 00            [12] 2285 	mov	r4,#0x00
      006426 C3               [12] 2286 	clr	c
      006427 EB               [12] 2287 	mov	a,r3
      006428 98               [12] 2288 	subb	a,r0
      006429 EC               [12] 2289 	mov	a,r4
      00642A 99               [12] 2290 	subb	a,r1
      00642B D0 04            [24] 2291 	pop	ar4
      00642D D0 03            [24] 2292 	pop	ar3
      00642F 50 32            [24] 2293 	jnc	00222$
      006431 C0 00            [24] 2294 	push	ar0
      006433 C0 01            [24] 2295 	push	ar1
      006435 85 27 29         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006438 74 10            [12] 2297 	mov	a,#0x10
      00643A 24 00            [12] 2298 	add	a, #0x00
      00643C F5 2A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      00643E A8 27            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      006440 79 00            [12] 2301 	mov	r1,#0x00
      006442 74 C0            [12] 2302 	mov	a,#0xc0
      006444 28               [12] 2303 	add	a, r0
      006445 F8               [12] 2304 	mov	r0,a
      006446 E4               [12] 2305 	clr	a
      006447 39               [12] 2306 	addc	a, r1
      006448 F9               [12] 2307 	mov	r1,a
      006449 88 82            [24] 2308 	mov	dpl,r0
      00644B 74 10            [12] 2309 	mov	a,#0x10
      00644D 29               [12] 2310 	add	a, r1
      00644E F5 83            [12] 2311 	mov	dph,a
      006450 E0               [24] 2312 	movx	a,@dptr
      006451 85 29 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      006454 85 2A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006457 F0               [24] 2315 	movx	@dptr,a
      006458 E5 27            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      00645A 04               [12] 2317 	inc	a
      00645B F5 27            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      00645D D0 01            [24] 2319 	pop	ar1
      00645F D0 00            [24] 2320 	pop	ar0
      006461 80 BB            [24] 2321 	sjmp	00293$
      006463                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      006463 90 07 E4         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      006466 E4               [12] 2325 	clr	a
      006467 F0               [24] 2326 	movx	@dptr,a
      006468 A3               [24] 2327 	inc	dptr
      006469 F0               [24] 2328 	movx	@dptr,a
      00646A 02 65 48         [24] 2329 	ljmp	00252$
      00646D                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      00646D 8D 00            [24] 2332 	mov	ar0,r5
      00646F 8E 01            [24] 2333 	mov	ar1,r6
      006471 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      006474 B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      006477 EB               [12] 2336 	mov	a,r3
      006478 4C               [12] 2337 	orl	a,r4
      006479 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      00647B 90 07 86         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      00647E E0               [24] 2341 	movx	a,@dptr
      00647F 90 10 00         [24] 2342 	mov	dptr,#0x1000
      006482 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      006483 90 07 E4         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      006486 E4               [12] 2346 	clr	a
      006487 F0               [24] 2347 	movx	@dptr,a
      006488 A3               [24] 2348 	inc	dptr
      006489 F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      00648A 90 07 7C         [24] 2351 	mov	dptr,#_D0SetupLen
      00648D 04               [12] 2352 	inc	a
      00648E F0               [24] 2353 	movx	@dptr,a
      00648F E4               [12] 2354 	clr	a
      006490 A3               [24] 2355 	inc	dptr
      006491 F0               [24] 2356 	movx	@dptr,a
      006492 02 65 48         [24] 2357 	ljmp	00252$
      006495                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006495 B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      006498 B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      00649B BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      00649E BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0064A1 C0 03            [24] 2365 	push	ar3
      0064A3 C0 04            [24] 2366 	push	ar4
      0064A5 90 10 00         [24] 2367 	mov	dptr,#0x1000
      0064A8 74 06            [12] 2368 	mov	a,#0x06
      0064AA F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0064AB 90 07 86         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      0064AE E0               [24] 2372 	movx	a,@dptr
      0064AF 90 10 01         [24] 2373 	mov	dptr,#0x1001
      0064B2 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      0064B3 90 07 E4         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      0064B6 E4               [12] 2377 	clr	a
      0064B7 F0               [24] 2378 	movx	@dptr,a
      0064B8 A3               [24] 2379 	inc	dptr
      0064B9 F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      0064BA 90 07 7C         [24] 2382 	mov	dptr,#_D0SetupLen
      0064BD E0               [24] 2383 	movx	a,@dptr
      0064BE FB               [12] 2384 	mov	r3,a
      0064BF A3               [24] 2385 	inc	dptr
      0064C0 E0               [24] 2386 	movx	a,@dptr
      0064C1 FC               [12] 2387 	mov	r4,a
      0064C2 C3               [12] 2388 	clr	c
      0064C3 74 02            [12] 2389 	mov	a,#0x02
      0064C5 9B               [12] 2390 	subb	a,r3
      0064C6 E4               [12] 2391 	clr	a
      0064C7 9C               [12] 2392 	subb	a,r4
      0064C8 D0 04            [24] 2393 	pop	ar4
      0064CA D0 03            [24] 2394 	pop	ar3
      0064CC 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      0064CE 90 07 7C         [24] 2397 	mov	dptr,#_D0SetupLen
      0064D1 74 02            [12] 2398 	mov	a,#0x02
      0064D3 F0               [24] 2399 	movx	@dptr,a
      0064D4 E4               [12] 2400 	clr	a
      0064D5 A3               [24] 2401 	inc	dptr
      0064D6 F0               [24] 2402 	movx	@dptr,a
      0064D7 80 6F            [24] 2403 	sjmp	00252$
      0064D9                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0064D9 B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      0064DC B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      0064DF BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      0064E2 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      0064E5 90 10 00         [24] 2411 	mov	dptr,#0x1000
      0064E8 74 41            [12] 2412 	mov	a,#0x41
      0064EA F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      0064EB A3               [24] 2415 	inc	dptr
      0064EC 74 4B            [12] 2416 	mov	a,#0x4b
      0064EE F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      0064EF A3               [24] 2419 	inc	dptr
      0064F0 74 42            [12] 2420 	mov	a,#0x42
      0064F2 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      0064F3 A3               [24] 2423 	inc	dptr
      0064F4 74 54            [12] 2424 	mov	a,#0x54
      0064F6 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      0064F7 A3               [24] 2427 	inc	dptr
      0064F8 74 01            [12] 2428 	mov	a,#0x01
      0064FA F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      0064FB 90 07 87         [24] 2431 	mov	dptr,#_ak820_boot_stage
      0064FE E0               [24] 2432 	movx	a,@dptr
      0064FF 90 10 05         [24] 2433 	mov	dptr,#0x1005
      006502 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006503 90 07 88         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      006506 E0               [24] 2437 	movx	a,@dptr
      006507 90 10 06         [24] 2438 	mov	dptr,#0x1006
      00650A F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00650B 90 07 82         [24] 2441 	mov	dptr,#_USB_EnumStatus
      00650E E0               [24] 2442 	movx	a,@dptr
      00650F 60 02            [24] 2443 	jz	00322$
      006511 74 01            [12] 2444 	mov	a,#0x01
      006513                       2445 00322$:
      006513 F9               [12] 2446 	mov	r1,a
      006514 90 07 83         [24] 2447 	mov	dptr,#_USB_SleepStatus
      006517 E0               [24] 2448 	movx	a,@dptr
      006518 54 02            [12] 2449 	anl	a,#0x02
      00651A F8               [12] 2450 	mov	r0,a
      00651B E9               [12] 2451 	mov	a,r1
      00651C 42 00            [12] 2452 	orl	ar0,a
      00651E 90 10 07         [24] 2453 	mov	dptr,#0x1007
      006521 E8               [12] 2454 	mov	a,r0
      006522 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      006523 90 07 E4         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      006526 E4               [12] 2458 	clr	a
      006527 F0               [24] 2459 	movx	@dptr,a
      006528 A3               [24] 2460 	inc	dptr
      006529 F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      00652A 90 07 7C         [24] 2463 	mov	dptr,#_D0SetupLen
      00652D E0               [24] 2464 	movx	a,@dptr
      00652E F8               [12] 2465 	mov	r0,a
      00652F A3               [24] 2466 	inc	dptr
      006530 E0               [24] 2467 	movx	a,@dptr
      006531 F9               [12] 2468 	mov	r1,a
      006532 C3               [12] 2469 	clr	c
      006533 74 08            [12] 2470 	mov	a,#0x08
      006535 98               [12] 2471 	subb	a,r0
      006536 E4               [12] 2472 	clr	a
      006537 99               [12] 2473 	subb	a,r1
      006538 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      00653A 90 07 7C         [24] 2476 	mov	dptr,#_D0SetupLen
      00653D 74 08            [12] 2477 	mov	a,#0x08
      00653F F0               [24] 2478 	movx	@dptr,a
      006540 E4               [12] 2479 	clr	a
      006541 A3               [24] 2480 	inc	dptr
      006542 F0               [24] 2481 	movx	@dptr,a
      006543 80 03            [24] 2482 	sjmp	00252$
      006545                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006545 02 5C AE         [24] 2485 	ljmp	_control_stall
      006548                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      006548 90 07 E4         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      00654B E0               [24] 2489 	movx	a,@dptr
      00654C F5 29            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      00654E A3               [24] 2491 	inc	dptr
      00654F E0               [24] 2492 	movx	a,@dptr
      006550 F5 2A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      006552 E5 29            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      006554 45 2A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006556 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      006558 90 07 7C         [24] 2498 	mov	dptr,#_D0SetupLen
      00655B E0               [24] 2499 	movx	a,@dptr
      00655C F8               [12] 2500 	mov	r0,a
      00655D A3               [24] 2501 	inc	dptr
      00655E E0               [24] 2502 	movx	a,@dptr
      00655F F9               [12] 2503 	mov	r1,a
      006560 C3               [12] 2504 	clr	c
      006561 E5 29            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      006563 98               [12] 2506 	subb	a,r0
      006564 E5 2A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006566 99               [12] 2508 	subb	a,r1
      006567 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      006569 90 07 7C         [24] 2511 	mov	dptr,#_D0SetupLen
      00656C E5 29            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      00656E F0               [24] 2513 	movx	@dptr,a
      00656F E5 2A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006571 A3               [24] 2515 	inc	dptr
      006572 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006573                       2518 00559$:
      006573 75 29 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      006576                       2520 00296$:
      006576 90 07 7C         [24] 2521 	mov	dptr,#_D0SetupLen
      006579 E0               [24] 2522 	movx	a,@dptr
      00657A F8               [12] 2523 	mov	r0,a
      00657B C3               [12] 2524 	clr	c
      00657C E5 29            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      00657E 98               [12] 2526 	subb	a,r0
      00657F 50 46            [24] 2527 	jnc	00263$
      006581 85 29 27         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006584 74 10            [12] 2529 	mov	a,#0x10
      006586 24 00            [12] 2530 	add	a, #0x00
      006588 F5 28            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      00658A 90 07 E6         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      00658D E0               [24] 2533 	movx	a,@dptr
      00658E 25 29            [12] 2534 	add	a, _control_setup_sloc4_1_0
      006590 24 AC            [12] 2535 	add	a, #_input_snapshot
      006592 F5 82            [12] 2536 	mov	dpl,a
      006594 E4               [12] 2537 	clr	a
      006595 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      006597 F5 83            [12] 2539 	mov	dph,a
      006599 E0               [24] 2540 	movx	a,@dptr
      00659A 85 27 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      00659D 85 28 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0065A0 F0               [24] 2543 	movx	@dptr,a
      0065A1 E5 29            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      0065A3 04               [12] 2545 	inc	a
      0065A4 F5 29            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      0065A6 80 CE            [24] 2547 	sjmp	00296$
      0065A8                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0065A8 BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      0065AB BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      0065AE 90 07 7C         [24] 2552 	mov	dptr,#_D0SetupLen
      0065B1 E0               [24] 2553 	movx	a,@dptr
      0065B2 F8               [12] 2554 	mov	r0,a
      0065B3 A3               [24] 2555 	inc	dptr
      0065B4 E0               [24] 2556 	movx	a,@dptr
      0065B5 F9               [12] 2557 	mov	r1,a
      0065B6 C3               [12] 2558 	clr	c
      0065B7 74 20            [12] 2559 	mov	a,#0x20
      0065B9 98               [12] 2560 	subb	a,r0
      0065BA E4               [12] 2561 	clr	a
      0065BB 99               [12] 2562 	subb	a,r1
      0065BC 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      0065BE 90 07 7C         [24] 2565 	mov	dptr,#_D0SetupLen
      0065C1 74 20            [12] 2566 	mov	a,#0x20
      0065C3 F0               [24] 2567 	movx	@dptr,a
      0065C4 E4               [12] 2568 	clr	a
      0065C5 A3               [24] 2569 	inc	dptr
      0065C6 F0               [24] 2570 	movx	@dptr,a
      0065C7                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      0065C7 90 07 7C         [24] 2573 	mov	dptr,#_D0SetupLen
      0065CA E0               [24] 2574 	movx	a,@dptr
      0065CB 90 22 08         [24] 2575 	mov	dptr,#0x2208
      0065CE F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      0065CF 90 07 DA         [24] 2578 	mov	dptr,#_control_phase
      0065D2 74 02            [12] 2579 	mov	a,#0x02
      0065D4 F0               [24] 2580 	movx	@dptr,a
      0065D5 02 66 5D         [24] 2581 	ljmp	00291$
      0065D8                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0065D8 EB               [12] 2584 	mov	a,r3
      0065D9 4C               [12] 2585 	orl	a,r4
      0065DA 70 37            [24] 2586 	jnz	00265$
      0065DC 90 07 81         [24] 2587 	mov	dptr,#_D0UsbConfig
      0065DF E0               [24] 2588 	movx	a,@dptr
      0065E0 60 31            [24] 2589 	jz	00265$
      0065E2 EA               [12] 2590 	mov	a,r2
      0065E3 60 2E            [24] 2591 	jz	00265$
      0065E5 90 07 7B         [24] 2592 	mov	dptr,#_D0SetupReqCode
      0065E8 E0               [24] 2593 	movx	a,@dptr
      0065E9 FA               [12] 2594 	mov	r2,a
      0065EA BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      0065ED 30 16 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      0065F0 90 07 7C         [24] 2597 	mov	dptr,#_D0SetupLen
      0065F3 E0               [24] 2598 	movx	a,@dptr
      0065F4 F9               [12] 2599 	mov	r1,a
      0065F5 A3               [24] 2600 	inc	dptr
      0065F6 E0               [24] 2601 	movx	a,@dptr
      0065F7 FA               [12] 2602 	mov	r2,a
      0065F8 B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      0065FB BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      0065FE 90 0D 9D         [24] 2606 	mov	dptr,#_keyboard_protocol
      006601 E0               [24] 2607 	movx	a,@dptr
      006602 90 10 00         [24] 2608 	mov	dptr,#0x1000
      006605 F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006606 90 22 08         [24] 2611 	mov	dptr,#0x2208
      006609 74 01            [12] 2612 	mov	a,#0x01
      00660B F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      00660C 90 07 DA         [24] 2615 	mov	dptr,#_control_phase
      00660F 04               [12] 2616 	inc	a
      006610 F0               [24] 2617 	movx	@dptr,a
      006611 80 4A            [24] 2618 	sjmp	00291$
      006613                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      006613 02 5C AE         [24] 2622 	ljmp	_control_stall
      006616                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006616 30 14 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      006619 90 07 81         [24] 2626 	mov	dptr,#_D0UsbConfig
      00661C E0               [24] 2627 	movx	a,@dptr
      00661D 60 38            [24] 2628 	jz	00284$
      00661F BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      006622 8E 05            [24] 2630 	mov	ar5,r6
      006624 7E 00            [12] 2631 	mov	r6,#0x00
      006626 ED               [12] 2632 	mov	a,r5
      006627 4E               [12] 2633 	orl	a,r6
      006628 70 2D            [24] 2634 	jnz	00284$
      00662A 90 07 7C         [24] 2635 	mov	dptr,#_D0SetupLen
      00662D E0               [24] 2636 	movx	a,@dptr
      00662E FE               [12] 2637 	mov	r6,a
      00662F A3               [24] 2638 	inc	dptr
      006630 E0               [24] 2639 	movx	a,@dptr
      006631 FF               [12] 2640 	mov	r7,a
      006632 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      006635 BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006638 EB               [12] 2644 	mov	a,r3
      006639 4C               [12] 2645 	orl	a,r4
      00663A 70 07            [24] 2646 	jnz	00324$
      00663C 90 06 59         [24] 2647 	mov	dptr,#_keyboard_idle
      00663F E0               [24] 2648 	movx	a,@dptr
      006640 FF               [12] 2649 	mov	r7,a
      006641 80 02            [24] 2650 	sjmp	00325$
      006643                       2651 00324$:
      006643 7F 00            [12] 2652 	mov	r7,#0x00
      006645                       2653 00325$:
      006645 90 10 00         [24] 2654 	mov	dptr,#0x1000
      006648 EF               [12] 2655 	mov	a,r7
      006649 F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      00664A 90 22 08         [24] 2658 	mov	dptr,#0x2208
      00664D 74 01            [12] 2659 	mov	a,#0x01
      00664F F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006650 90 07 DA         [24] 2662 	mov	dptr,#_control_phase
      006653 04               [12] 2663 	inc	a
      006654 F0               [24] 2664 	movx	@dptr,a
      006655 80 06            [24] 2665 	sjmp	00291$
      006657                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006657 02 5C AE         [24] 2669 	ljmp	_control_stall
      00665A                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      00665A 02 5C AE         [24] 2672 	ljmp	_control_stall
      00665D                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      00665D 90 22 00         [24] 2675 	mov	dptr,#0x2200
      006660 74 C0            [12] 2676 	mov	a,#0xc0
      006662 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006663 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      006664                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006664 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      006667 E0               [24] 2692 	movx	a,@dptr
      006668 20 E6 01         [24] 2693 	jb	acc.6,00102$
      00666B 22               [24] 2694 	ret
      00666C                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      00666C 90 07 DA         [24] 2697 	mov	dptr,#_control_phase
      00666F E0               [24] 2698 	movx	a,@dptr
      006670 FF               [12] 2699 	mov	r7,a
      006671 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      006674 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      006677 E0               [24] 2702 	movx	a,@dptr
      006678 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      00667A 90 07 DA         [24] 2705 	mov	dptr,#_control_phase
      00667D E4               [12] 2706 	clr	a
      00667E F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00667F 90 22 00         [24] 2709 	mov	dptr,#0x2200
      006682 74 02            [12] 2710 	mov	a,#0x02
      006684 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006685 22               [24] 2713 	ret
      006686                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006686 BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      006689 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      00668C E0               [24] 2718 	movx	a,@dptr
      00668D FF               [12] 2719 	mov	r7,a
      00668E 90 07 7C         [24] 2720 	mov	dptr,#_D0SetupLen
      006691 E0               [24] 2721 	movx	a,@dptr
      006692 FD               [12] 2722 	mov	r5,a
      006693 A3               [24] 2723 	inc	dptr
      006694 E0               [24] 2724 	movx	a,@dptr
      006695 FE               [12] 2725 	mov	r6,a
      006696 7C 00            [12] 2726 	mov	r4,#0x00
      006698 EF               [12] 2727 	mov	a,r7
      006699 B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      00669C EC               [12] 2729 	mov	a,r4
      00669D B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      0066A0 80 03            [24] 2731 	sjmp	00107$
      0066A2                       2732 00209$:
      0066A2                       2733 00106$:
      0066A2 02 5C AE         [24] 2734 	ljmp	_control_stall
      0066A5                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0066A5 90 07 DB         [24] 2737 	mov	dptr,#_output_kind
      0066A8 E0               [24] 2738 	movx	a,@dptr
      0066A9 FF               [12] 2739 	mov	r7,a
      0066AA BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      0066AD 90 07 89         [24] 2741 	mov	dptr,#_raw_state
      0066B0 E0               [24] 2742 	movx	a,@dptr
      0066B1 FE               [12] 2743 	mov	r6,a
      0066B2 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0066B5 7E 00            [12] 2746 	mov	r6,#0x00
      0066B7                       2747 00121$:
      0066B7 EE               [12] 2748 	mov	a,r6
      0066B8 24 8A            [12] 2749 	add	a, #_raw_buffer
      0066BA FC               [12] 2750 	mov	r4,a
      0066BB E4               [12] 2751 	clr	a
      0066BC 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      0066BE FD               [12] 2753 	mov	r5,a
      0066BF 8E 82            [24] 2754 	mov	dpl,r6
      0066C1 74 10            [12] 2755 	mov	a,#0x10
      0066C3 24 00            [12] 2756 	add	a, #0x00
      0066C5 F5 83            [12] 2757 	mov	dph,a
      0066C7 E0               [24] 2758 	movx	a,@dptr
      0066C8 8C 82            [24] 2759 	mov	dpl,r4
      0066CA 8D 83            [24] 2760 	mov	dph,r5
      0066CC F0               [24] 2761 	movx	@dptr,a
      0066CD 0E               [12] 2762 	inc	r6
      0066CE BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      0066D1                       2764 00214$:
      0066D1 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      0066D3 90 07 89         [24] 2767 	mov	dptr,#_raw_state
      0066D6 74 02            [12] 2768 	mov	a,#0x02
      0066D8 F0               [24] 2769 	movx	@dptr,a
      0066D9 80 2B            [24] 2770 	sjmp	00119$
      0066DB                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      0066DB BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      0066DE 90 10 00         [24] 2775 	mov	dptr,#0x1000
      0066E1 E0               [24] 2776 	movx	a,@dptr
      0066E2 90 07 86         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      0066E5 F0               [24] 2778 	movx	@dptr,a
      0066E6 80 1E            [24] 2779 	sjmp	00119$
      0066E8                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0066E8 BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      0066EB 90 10 00         [24] 2783 	mov	dptr,#0x1000
      0066EE E0               [24] 2784 	movx	a,@dptr
      0066EF FF               [12] 2785 	mov	r7,a
      0066F0 90 07 DC         [24] 2786 	mov	dptr,#_output_report_id
      0066F3 E0               [24] 2787 	movx	a,@dptr
      0066F4 FE               [12] 2788 	mov	r6,a
      0066F5 EF               [12] 2789 	mov	a,r7
      0066F6 B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      0066F9 90 10 01         [24] 2792 	mov	dptr,#0x1001
      0066FC E0               [24] 2793 	movx	a,@dptr
      0066FD 90 07 86         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      006700 F0               [24] 2795 	movx	@dptr,a
      006701 80 03            [24] 2796 	sjmp	00119$
      006703                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006703 02 5C AE         [24] 2799 	ljmp	_control_stall
      006706                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006706 90 07 DB         [24] 2802 	mov	dptr,#_output_kind
      006709 E4               [12] 2803 	clr	a
      00670A F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      00670B 90 07 7C         [24] 2806 	mov	dptr,#_D0SetupLen
      00670E F0               [24] 2807 	movx	@dptr,a
      00670F A3               [24] 2808 	inc	dptr
      006710 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006711 90 07 DA         [24] 2811 	mov	dptr,#_control_phase
      006714 74 03            [12] 2812 	mov	a,#0x03
      006716 F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006717 90 22 08         [24] 2815 	mov	dptr,#0x2208
      00671A E4               [12] 2816 	clr	a
      00671B F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      00671C F5 82            [12] 2819 	mov	dpl,a
      00671E 74 48            [12] 2820 	mov	a,#0x48
      006720 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006721 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      006722                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006722 90 07 DA         [24] 2833 	mov	dptr,#_control_phase
      006725 E0               [24] 2834 	movx	a,@dptr
      006726 FF               [12] 2835 	mov	r7,a
      006727 BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      00672A 90 07 7C         [24] 2838 	mov	dptr,#_D0SetupLen
      00672D E0               [24] 2839 	movx	a,@dptr
      00672E FD               [12] 2840 	mov	r5,a
      00672F A3               [24] 2841 	inc	dptr
      006730 E0               [24] 2842 	movx	a,@dptr
      006731 4D               [12] 2843 	orl	a,r5
      006732 70 06            [24] 2844 	jnz	00101$
      006734 90 07 DD         [24] 2845 	mov	dptr,#_control_zlp
      006737 E0               [24] 2846 	movx	a,@dptr
      006738 60 0A            [24] 2847 	jz	00102$
      00673A                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      00673A 90 22 00         [24] 2850 	mov	dptr,#0x2200
      00673D E0               [24] 2851 	movx	a,@dptr
      00673E 64 40            [12] 2852 	xrl	a,#0x40
      006740 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006741 02 5C D0         [24] 2856 	ljmp	_control_next
      006744                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006744 90 07 DA         [24] 2859 	mov	dptr,#_control_phase
      006747 74 02            [12] 2860 	mov	a,#0x02
      006749 F0               [24] 2861 	movx	@dptr,a
      00674A 80 18            [24] 2862 	sjmp	00110$
      00674C                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      00674C BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00674F 90 07 7B         [24] 2867 	mov	dptr,#_D0SetupReqCode
      006752 E0               [24] 2868 	movx	a,@dptr
      006753 FF               [12] 2869 	mov	r7,a
      006754 BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      006757 90 07 7C         [24] 2871 	mov	dptr,#_D0SetupLen
      00675A E0               [24] 2872 	movx	a,@dptr
      00675B 90 22 07         [24] 2873 	mov	dptr,#0x2207
      00675E F0               [24] 2874 	movx	@dptr,a
      00675F                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      00675F 90 07 DA         [24] 2877 	mov	dptr,#_control_phase
      006762 E4               [12] 2878 	clr	a
      006763 F0               [24] 2879 	movx	@dptr,a
      006764                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006764 90 22 00         [24] 2882 	mov	dptr,#0x2200
      006767 74 82            [12] 2883 	mov	a,#0x82
      006769 F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      00676A 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      00676B                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      00676B                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      00676B 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      00676E E0               [24] 2902 	movx	a,@dptr
      00676F 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006772 12 5C 57         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006775 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006778 E4               [12] 2908 	clr	a
      006779 F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      00677A 90 07 83         [24] 2911 	mov	dptr,#_USB_SleepStatus
      00677D F0               [24] 2912 	movx	@dptr,a
      00677E 90 07 82         [24] 2913 	mov	dptr,#_USB_EnumStatus
      006781 F0               [24] 2914 	movx	@dptr,a
      006782 90 07 81         [24] 2915 	mov	dptr,#_D0UsbConfig
      006785 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006786 90 07 86         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      006789 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      00678A 90 0D 9D         [24] 2921 	mov	dptr,#_keyboard_protocol
      00678D 04               [12] 2922 	inc	a
      00678E F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      00678F 90 06 59         [24] 2925 	mov	dptr,#_keyboard_idle
      006792 E4               [12] 2926 	clr	a
      006793 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006794 90 07 AB         [24] 2929 	mov	dptr,#_keyboard_reset
      006797 04               [12] 2930 	inc	a
      006798 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006799 90 07 7B         [24] 2933 	mov	dptr,#_D0SetupReqCode
      00679C 74 FF            [12] 2934 	mov	a,#0xff
      00679E F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      00679F 90 07 7C         [24] 2937 	mov	dptr,#_D0SetupLen
      0067A2 E4               [12] 2938 	clr	a
      0067A3 F0               [24] 2939 	movx	@dptr,a
      0067A4 A3               [24] 2940 	inc	dptr
      0067A5 F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      0067A6 90 07 DA         [24] 2943 	mov	dptr,#_control_phase
      0067A9 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0067AA 90 22 00         [24] 2946 	mov	dptr,#0x2200
      0067AD 74 02            [12] 2947 	mov	a,#0x02
      0067AF F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      0067B0 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      0067B3 E4               [12] 2951 	clr	a
      0067B4 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      0067B5 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      0067B8 04               [12] 2955 	inc	a
      0067B9 F0               [24] 2956 	movx	@dptr,a
      0067BA 02 68 50         [24] 2957 	ljmp	00130$
      0067BD                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      0067BD 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      0067C0 E0               [24] 2961 	movx	a,@dptr
      0067C1 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      0067C4 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      0067C7 E0               [24] 2965 	movx	a,@dptr
      0067C8 FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      0067C9 74 07            [12] 2968 	mov	a,#0x07
      0067CB 5F               [12] 2969 	anl	a,r7
      0067CC FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      0067CD EF               [12] 2972 	mov	a,r7
      0067CE 54 18            [12] 2973 	anl	a,#0x18
      0067D0 70 08            [24] 2974 	jnz	00115$
      0067D2 EE               [12] 2975 	mov	a,r6
      0067D3 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      0067D5 12 66 64         [24] 2978 	lcall	_control_out
      0067D8 80 43            [24] 2979 	sjmp	00116$
      0067DA                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      0067DA 8F 05            [24] 2982 	mov	ar5,r7
      0067DC 74 18            [12] 2983 	mov	a,#0x18
      0067DE 5D               [12] 2984 	anl	a,r5
      0067DF FC               [12] 2985 	mov	r4,a
      0067E0 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      0067E3 EE               [12] 2988 	mov	a,r6
      0067E4 70 05            [24] 2989 	jnz	00106$
      0067E6 12 67 22         [24] 2990 	lcall	_control_in
      0067E9 80 32            [24] 2991 	sjmp	00116$
      0067EB                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      0067EB EE               [12] 2994 	mov	a,r6
      0067EC 24 FC            [12] 2995 	add	a,#0xff - 0x03
      0067EE 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      0067F0 8E 04            [24] 2999 	mov	ar4,r6
      0067F2 7B 00            [12] 3000 	mov	r3,#0x00
      0067F4 74 22            [12] 3001 	mov	a,#0x22
      0067F6 2B               [12] 3002 	add	a, r3
      0067F7 FB               [12] 3003 	mov	r3,a
      0067F8 8C 82            [24] 3004 	mov	dpl,r4
      0067FA 8B 83            [24] 3005 	mov	dph,r3
      0067FC E0               [24] 3006 	movx	a,@dptr
      0067FD FA               [12] 3007 	mov	r2,a
      0067FE 74 FC            [12] 3008 	mov	a,#0xfc
      006800 5A               [12] 3009 	anl	a,r2
      006801 44 02            [12] 3010 	orl	a,#0x02
      006803 8C 82            [24] 3011 	mov	dpl,r4
      006805 8B 83            [24] 3012 	mov	dph,r3
      006807 F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006808 BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      00680B 12 5C 3A         [24] 3016 	lcall	_raw_complete
      00680E 80 0D            [24] 3017 	sjmp	00116$
      006810                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006810 53 05 18         [24] 3020 	anl	ar5,#0x18
      006813 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      006816 EF               [12] 3022 	mov	a,r7
      006817 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      00681A 12 5E C7         [24] 3025 	lcall	_control_setup
      00681D                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      00681D 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      006820 E4               [12] 3029 	clr	a
      006821 F0               [24] 3030 	movx	@dptr,a
      006822 80 2C            [24] 3031 	sjmp	00130$
      006824                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006824 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      006827 E0               [24] 3035 	movx	a,@dptr
      006828 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      00682B 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      00682E E0               [24] 3039 	movx	a,@dptr
      00682F 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006832 90 07 83         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006835 E0               [24] 3042 	movx	a,@dptr
      006836 43 E0 02         [24] 3043 	orl	acc,#0x02
      006839 F0               [24] 3044 	movx	@dptr,a
      00683A 80 0E            [24] 3045 	sjmp	00120$
      00683C                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      00683C 90 07 83         [24] 3048 	mov	dptr,#_USB_SleepStatus
      00683F E0               [24] 3049 	movx	a,@dptr
      006840 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006843 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006844 90 07 AB         [24] 3053 	mov	dptr,#_keyboard_reset
      006847 74 01            [12] 3054 	mov	a,#0x01
      006849 F0               [24] 3055 	movx	@dptr,a
      00684A                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      00684A 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      00684D 74 04            [12] 3059 	mov	a,#0x04
      00684F F0               [24] 3060 	movx	@dptr,a
      006850                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006850 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006853 E0               [24] 3064 	movx	a,@dptr
      006854 54 25            [12] 3065 	anl	a,#0x25
      006856 60 03            [24] 3066 	jz	00242$
      006858 02 67 6B         [24] 3067 	ljmp	00129$
      00685B                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      00685B 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      00685C                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3080 ;	assignBit
      00685C C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      00685E 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006861 E4               [12] 3084 	clr	a
      006862 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006863 90 07 89         [24] 3087 	mov	dptr,#_raw_state
      006866 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006867 12 5C 57         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      00686A 90 07 83         [24] 3092 	mov	dptr,#_USB_SleepStatus
      00686D E4               [12] 3093 	clr	a
      00686E F0               [24] 3094 	movx	@dptr,a
      00686F 90 07 82         [24] 3095 	mov	dptr,#_USB_EnumStatus
      006872 F0               [24] 3096 	movx	@dptr,a
      006873 90 07 81         [24] 3097 	mov	dptr,#_D0UsbConfig
      006876 F0               [24] 3098 	movx	@dptr,a
      006877 90 22 07         [24] 3099 	mov	dptr,#0x2207
      00687A F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      00687B 90 07 84         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      00687E F0               [24] 3103 	movx	@dptr,a
      00687F 90 07 85         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      006882 F0               [24] 3105 	movx	@dptr,a
      006883 90 07 86         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      006886 F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006887 90 0D 9D         [24] 3109 	mov	dptr,#_keyboard_protocol
      00688A 04               [12] 3110 	inc	a
      00688B F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      00688C 90 06 59         [24] 3113 	mov	dptr,#_keyboard_idle
      00688F E4               [12] 3114 	clr	a
      006890 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006891 90 07 AB         [24] 3117 	mov	dptr,#_keyboard_reset
      006894 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006895 90 07 DA         [24] 3120 	mov	dptr,#_control_phase
      006898 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006899 90 07 7B         [24] 3123 	mov	dptr,#_D0SetupReqCode
      00689C 14               [12] 3124 	dec	a
      00689D F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      00689E 90 07 7C         [24] 3127 	mov	dptr,#_D0SetupLen
      0068A1 E4               [12] 3128 	clr	a
      0068A2 F0               [24] 3129 	movx	@dptr,a
      0068A3 A3               [24] 3130 	inc	dptr
      0068A4 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068A5 90 22 00         [24] 3133 	mov	dptr,#0x2200
      0068A8 74 02            [12] 3134 	mov	a,#0x02
      0068AA F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      0068AB 90 22 37         [24] 3137 	mov	dptr,#0x2237
      0068AE 74 7F            [12] 3138 	mov	a,#0x7f
      0068B0 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      0068B1 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      0068B4 74 FF            [12] 3142 	mov	a,#0xff
      0068B6 F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      0068B7 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      0068BA 74 07            [12] 3146 	mov	a,#0x07
      0068BC F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      0068BD A3               [24] 3149 	inc	dptr
      0068BE 74 80            [12] 3150 	mov	a,#0x80
      0068C0 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3153 ;	assignBit
      0068C1 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      0068C3 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      0068C4                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      0068C4 90 07 83         [24] 3169 	mov	dptr,#_USB_SleepStatus
      0068C7 E0               [24] 3170 	movx	a,@dptr
      0068C8 FF               [12] 3171 	mov	r7,a
      0068C9 BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      0068CC 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      0068CF E0               [24] 3175 	movx	a,@dptr
      0068D0 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      0068D1 E0               [24] 3178 	movx	a,@dptr
      0068D2 FE               [12] 3179 	mov	r6,a
      0068D3 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      0068D6 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      0068D9 EE               [12] 3182 	mov	a,r6
      0068DA F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      0068DB 7E 0A            [12] 3185 	mov	r6,#0x0a
      0068DD                       3186 00108$:
      0068DD EE               [12] 3187 	mov	a,r6
      0068DE 60 09            [24] 3188 	jz	00105$
      0068E0 90 00 01         [24] 3189 	mov	dptr,#0x0001
      0068E3 12 5A 9E         [24] 3190 	lcall	_mDelaymS
      0068E6 1E               [12] 3191 	dec	r6
      0068E7 80 F4            [24] 3192 	sjmp	00108$
      0068E9                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      0068E9 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      0068EC EF               [12] 3196 	mov	a,r7
      0068ED F0               [24] 3197 	movx	@dptr,a
      0068EE                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      0068EE 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      0068EF                       3220 _ak820_usb_send:
      0068EF E5 82            [12] 3221 	mov	a,dpl
      0068F1 90 07 EA         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0068F4 F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      0068F5 90 07 EB         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0068F8 74 2E            [12] 3226 	mov	a,#0x2e
      0068FA F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      0068FB 90 07 EA         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0068FE E0               [24] 3230 	movx	a,@dptr
      0068FF FF               [12] 3231 	mov	r7,a
      006900 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      006903                       3233 00306$:
      006903 40 14            [24] 3234 	jc	00101$
      006905 EF               [12] 3235 	mov	a,r7
      006906 24 FC            [12] 3236 	add	a,#0xff - 0x03
      006908 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      00690A 90 07 E9         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      00690D E0               [24] 3240 	movx	a,@dptr
      00690E FE               [12] 3241 	mov  r6,a
      00690F 24 BF            [12] 3242 	add	a,#0xff - 0x40
      006911 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      006913 90 07 82         [24] 3245 	mov	dptr,#_USB_EnumStatus
      006916 E0               [24] 3246 	movx	a,@dptr
      006917 70 04            [24] 3247 	jnz	00102$
      006919                       3248 00101$:
      006919 75 82 00         [24] 3249 	mov	dpl, #0x00
      00691C 22               [24] 3250 	ret
      00691D                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      00691D BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006920 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      006923 80 04            [24] 3256 	sjmp	00107$
      006925                       3257 00313$:
      006925 75 82 00         [24] 3258 	mov	dpl, #0x00
      006928 22               [24] 3259 	ret
      006929                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006929 90 07 EB         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00692C E4               [12] 3263 	clr	a
      00692D F0               [24] 3264 	movx	@dptr,a
      00692E 80 3C            [24] 3265 	sjmp	00119$
      006930                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006930 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006933 90 07 E7         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      006936 E0               [24] 3271 	movx	a,@dptr
      006937 FD               [12] 3272 	mov	r5,a
      006938 A3               [24] 3273 	inc	dptr
      006939 E0               [24] 3274 	movx	a,@dptr
      00693A FF               [12] 3275 	mov	r7,a
      00693B 8D 82            [24] 3276 	mov	dpl,r5
      00693D 8F 83            [24] 3277 	mov	dph,r7
      00693F E0               [24] 3278 	movx	a,@dptr
      006940 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006941 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      006944                       3282 00316$:
      006944 50 0E            [24] 3283 	jnc	00108$
      006946 EF               [12] 3284 	mov	a,r7
      006947 90 B9 DF         [24] 3285 	mov	dptr,#_shared_lengths
      00694A 93               [24] 3286 	movc	a,@a+dptr
      00694B FD               [12] 3287 	mov	r5,a
      00694C 60 06            [24] 3288 	jz	00108$
      00694E EE               [12] 3289 	mov	a,r6
      00694F B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      006952 80 04            [24] 3291 	sjmp	00109$
      006954                       3292 00319$:
      006954                       3293 00108$:
      006954 75 82 00         [24] 3294 	mov	dpl, #0x00
      006957 22               [24] 3295 	ret
      006958                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006958 EF               [12] 3298 	mov	a,r7
      006959 90 B9 D8         [24] 3299 	mov	dptr,#_shared_offsets
      00695C 93               [24] 3300 	movc	a,@a+dptr
      00695D 90 07 EB         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006960 F0               [24] 3302 	movx	@dptr,a
      006961 80 09            [24] 3303 	sjmp	00119$
      006963                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006963 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      006966 80 04            [24] 3307 	sjmp	00119$
      006968                       3308 00320$:
      006968 75 82 00         [24] 3309 	mov	dpl, #0x00
      00696B 22               [24] 3310 	ret
      00696C                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      00696C 90 07 83         [24] 3313 	mov	dptr,#_USB_SleepStatus
      00696F E0               [24] 3314 	movx	a,@dptr
      006970 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      006973 12 68 C4         [24] 3316 	lcall	_USB_WakeUp_PC
      006976 75 82 00         [24] 3317 	mov	dpl, #0x00
      006979 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      00697A                       3320 00184$:
      00697A 7F FA            [12] 3321 	mov	r7,#0xfa
      00697C                       3322 00127$:
      00697C 90 07 EA         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00697F E0               [24] 3324 	movx	a,@dptr
      006980 FC               [12] 3325 	mov	r4,a
      006981 7D 00            [12] 3326 	mov	r5,#0x00
      006983 8C 02            [24] 3327 	mov	ar2,r4
      006985 74 22            [12] 3328 	mov	a,#0x22
      006987 2D               [12] 3329 	add	a, r5
      006988 FB               [12] 3330 	mov	r3,a
      006989 8A 82            [24] 3331 	mov	dpl,r2
      00698B 8B 83            [24] 3332 	mov	dph,r3
      00698D E0               [24] 3333 	movx	a,@dptr
      00698E 54 03            [12] 3334 	anl	a,#0x03
      006990 70 14            [24] 3335 	jnz	00129$
      006992 8F 03            [24] 3336 	mov	ar3,r7
      006994 1F               [12] 3337 	dec	r7
      006995 EB               [12] 3338 	mov	a,r3
      006996 60 0E            [24] 3339 	jz	00129$
      006998 7B 28            [12] 3340 	mov	r3,#0x28
      00699A                       3341 00141$:
      00699A EB               [12] 3342 	mov	a,r3
      00699B 60 DF            [24] 3343 	jz	00127$
      00699D 90 00 01         [24] 3344 	mov	dptr,#0x0001
      0069A0 12 5A 5A         [24] 3345 	lcall	_mDelayuS
      0069A3 1B               [12] 3346 	dec	r3
      0069A4 80 F4            [24] 3347 	sjmp	00141$
      0069A6                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      0069A6 A2 AF            [12] 3350 	mov	c,_EA
      0069A8 E4               [12] 3351 	clr	a
      0069A9 33               [12] 3352 	rlc	a
      0069AA FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3355 ;	assignBit
      0069AB C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      0069AD 90 07 82         [24] 3358 	mov	dptr,#_USB_EnumStatus
      0069B0 E0               [24] 3359 	movx	a,@dptr
      0069B1 60 25            [24] 3360 	jz	00130$
      0069B3 90 07 EA         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0069B6 E0               [24] 3362 	movx	a,@dptr
      0069B7 FB               [12] 3363 	mov	r3,a
      0069B8 F9               [12] 3364 	mov	r1,a
      0069B9 7A 00            [12] 3365 	mov	r2,#0x00
      0069BB 74 22            [12] 3366 	mov	a,#0x22
      0069BD 2A               [12] 3367 	add	a, r2
      0069BE FA               [12] 3368 	mov	r2,a
      0069BF 89 82            [24] 3369 	mov	dpl,r1
      0069C1 8A 83            [24] 3370 	mov	dph,r2
      0069C3 E0               [24] 3371 	movx	a,@dptr
      0069C4 FA               [12] 3372 	mov	r2,a
      0069C5 53 02 03         [24] 3373 	anl	ar2,#0x03
      0069C8 BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      0069CB BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      0069CE 90 07 89         [24] 3377 	mov	dptr,#_raw_state
      0069D1 E0               [24] 3378 	movx	a,@dptr
      0069D2 FB               [12] 3379 	mov	r3,a
      0069D3 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      0069D6 80 09            [24] 3381 	sjmp	00192$
      0069D8                       3382 00331$:
      0069D8                       3383 00130$:
                                   3384 ;	assignBit
      0069D8 EF               [12] 3385 	mov	a,r7
      0069D9 24 FF            [12] 3386 	add	a,#0xff
      0069DB 92 AF            [24] 3387 	mov	_EA,c
      0069DD 75 82 00         [24] 3388 	mov	dpl, #0x00
      0069E0 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      0069E1                       3391 00192$:
      0069E1 7B 00            [12] 3392 	mov	r3,#0x00
      0069E3                       3393 00144$:
      0069E3 C3               [12] 3394 	clr	c
      0069E4 EB               [12] 3395 	mov	a,r3
      0069E5 9E               [12] 3396 	subb	a,r6
      0069E6 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      0069E8 C0 07            [24] 3399 	push	ar7
      0069EA 90 07 EA         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0069ED E0               [24] 3401 	movx	a,@dptr
      0069EE F9               [12] 3402 	mov	r1,a
      0069EF E4               [12] 3403 	clr	a
      0069F0 C3               [12] 3404 	clr	c
      0069F1 C9               [12] 3405 	xch	a,r1
      0069F2 13               [12] 3406 	rrc	a
      0069F3 C9               [12] 3407 	xch	a,r1
      0069F4 13               [12] 3408 	rrc	a
      0069F5 A2 E0            [12] 3409 	mov	c,acc.0
      0069F7 C9               [12] 3410 	xch	a,r1
      0069F8 13               [12] 3411 	rrc	a
      0069F9 C9               [12] 3412 	xch	a,r1
      0069FA 13               [12] 3413 	rrc	a
      0069FB C9               [12] 3414 	xch	a,r1
      0069FC FA               [12] 3415 	mov	r2,a
      0069FD 8B 00            [24] 3416 	mov	ar0,r3
      0069FF 7F 00            [12] 3417 	mov	r7,#0x00
      006A01 E8               [12] 3418 	mov	a,r0
      006A02 29               [12] 3419 	add	a, r1
      006A03 F9               [12] 3420 	mov	r1,a
      006A04 EF               [12] 3421 	mov	a,r7
      006A05 3A               [12] 3422 	addc	a, r2
      006A06 24 10            [12] 3423 	add	a,#0x10
      006A08 FA               [12] 3424 	mov	r2,a
      006A09 90 07 E7         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      006A0C E0               [24] 3426 	movx	a,@dptr
      006A0D F8               [12] 3427 	mov	r0,a
      006A0E A3               [24] 3428 	inc	dptr
      006A0F E0               [24] 3429 	movx	a,@dptr
      006A10 FF               [12] 3430 	mov	r7,a
      006A11 EB               [12] 3431 	mov	a,r3
      006A12 28               [12] 3432 	add	a, r0
      006A13 F5 2B            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      006A15 E4               [12] 3434 	clr	a
      006A16 3F               [12] 3435 	addc	a, r7
      006A17 F5 2C            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006A19 85 2B 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006A1C 85 2C 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006A1F E0               [24] 3439 	movx	a,@dptr
      006A20 89 82            [24] 3440 	mov	dpl,r1
      006A22 8A 83            [24] 3441 	mov	dph,r2
      006A24 F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006A25 90 07 EB         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006A28 E0               [24] 3445 	movx	a,@dptr
      006A29 F5 2D            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      006A2B 74 2E            [12] 3447 	mov	a,#0x2e
      006A2D B5 2D 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006A30 D0 07            [24] 3449 	pop	ar7
      006A32 80 18            [24] 3450 	sjmp	00145$
      006A34                       3451 00333$:
      006A34 D0 07            [24] 3452 	pop	ar7
      006A36 EB               [12] 3453 	mov	a,r3
      006A37 25 2D            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      006A39 24 AC            [12] 3455 	add	a, #_input_snapshot
      006A3B F9               [12] 3456 	mov	r1,a
      006A3C E4               [12] 3457 	clr	a
      006A3D 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      006A3F FA               [12] 3459 	mov	r2,a
      006A40 85 2B 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006A43 85 2C 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006A46 E0               [24] 3462 	movx	a,@dptr
      006A47 89 82            [24] 3463 	mov	dpl,r1
      006A49 8A 83            [24] 3464 	mov	dph,r2
      006A4B F0               [24] 3465 	movx	@dptr,a
      006A4C                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006A4C 0B               [12] 3468 	inc	r3
      006A4D 80 94            [24] 3469 	sjmp	00144$
      006A4F                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006A4F 90 07 EA         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006A52 E0               [24] 3473 	movx	a,@dptr
      006A53 FB               [12] 3474 	mov	r3,a
      006A54 F9               [12] 3475 	mov	r1,a
      006A55 7A 00            [12] 3476 	mov	r2,#0x00
      006A57 74 08            [12] 3477 	mov	a,#0x08
      006A59 29               [12] 3478 	add	a, r1
      006A5A F9               [12] 3479 	mov	r1,a
      006A5B 74 22            [12] 3480 	mov	a,#0x22
      006A5D 3A               [12] 3481 	addc	a, r2
      006A5E FA               [12] 3482 	mov	r2,a
      006A5F 89 82            [24] 3483 	mov	dpl,r1
      006A61 8A 83            [24] 3484 	mov	dph,r2
      006A63 EE               [12] 3485 	mov	a,r6
      006A64 F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006A65 BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      006A68 90 07 89         [24] 3489 	mov	dptr,#_raw_state
      006A6B 74 04            [12] 3490 	mov	a,#0x04
      006A6D F0               [24] 3491 	movx	@dptr,a
      006A6E                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006A6E 74 22            [12] 3494 	mov	a,#0x22
      006A70 2D               [12] 3495 	add	a, r5
      006A71 FD               [12] 3496 	mov	r5,a
      006A72 8C 82            [24] 3497 	mov	dpl,r4
      006A74 8D 83            [24] 3498 	mov	dph,r5
      006A76 E0               [24] 3499 	movx	a,@dptr
      006A77 FE               [12] 3500 	mov	r6,a
      006A78 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      006A7B 8C 82            [24] 3502 	mov	dpl,r4
      006A7D 8D 83            [24] 3503 	mov	dph,r5
      006A7F EE               [12] 3504 	mov	a,r6
      006A80 F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3507 ;	assignBit
      006A81 EF               [12] 3508 	mov	a,r7
      006A82 24 FF            [12] 3509 	add	a,#0xff
      006A84 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006A86 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006A89 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      006A8A                       3528 _ak820_usb_try_send:
      006A8A E5 82            [12] 3529 	mov	a,dpl
      006A8C 90 07 EF         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006A8F F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      006A90 A2 AF            [12] 3534 	mov	c,_EA
      006A92 92 1A            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006A94 90 07 F0         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006A97 E4               [12] 3538 	clr	a
      006A98 F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3541 ;	assignBit
      006A99 C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006A9B 90 07 EF         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006A9E E0               [24] 3545 	movx	a,@dptr
      006A9F FF               [12] 3546 	mov	r7,a
      006AA0 BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      006AA3                       3548 00152$:
      006AA3 40 4E            [24] 3549 	jc	00102$
      006AA5 EF               [12] 3550 	mov	a,r7
      006AA6 24 FD            [12] 3551 	add	a,#0xff - 0x02
      006AA8 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      006AAA 90 07 82         [24] 3554 	mov	dptr,#_USB_EnumStatus
      006AAD E0               [24] 3555 	movx	a,@dptr
      006AAE 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006AB0 90 07 83         [24] 3558 	mov	dptr,#_USB_SleepStatus
      006AB3 E0               [24] 3559 	movx	a,@dptr
      006AB4 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      006AB7 90 07 AB         [24] 3561 	mov	dptr,#_keyboard_reset
      006ABA E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006ABB 70 36            [24] 3564 	jnz	00102$
      006ABD 8F 06            [24] 3565 	mov	ar6,r7
      006ABF 24 22            [12] 3566 	add	a,#0x22
      006AC1 FD               [12] 3567 	mov	r5,a
      006AC2 8E 82            [24] 3568 	mov	dpl,r6
      006AC4 8D 83            [24] 3569 	mov	dph,r5
      006AC6 E0               [24] 3570 	movx	a,@dptr
      006AC7 FE               [12] 3571 	mov	r6,a
      006AC8 53 06 03         [24] 3572 	anl	ar6,#0x03
      006ACB BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006ACE 90 07 EC         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006AD1 E0               [24] 3576 	movx	a,@dptr
      006AD2 FD               [12] 3577 	mov	r5,a
      006AD3 A3               [24] 3578 	inc	dptr
      006AD4 E0               [24] 3579 	movx	a,@dptr
      006AD5 FE               [12] 3580 	mov	r6,a
      006AD6 90 07 EE         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006AD9 E0               [24] 3582 	movx	a,@dptr
      006ADA FC               [12] 3583 	mov	r4,a
      006ADB 90 07 E7         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      006ADE ED               [12] 3585 	mov	a,r5
      006ADF F0               [24] 3586 	movx	@dptr,a
      006AE0 EE               [12] 3587 	mov	a,r6
      006AE1 A3               [24] 3588 	inc	dptr
      006AE2 F0               [24] 3589 	movx	@dptr,a
      006AE3 90 07 E9         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      006AE6 EC               [12] 3591 	mov	a,r4
      006AE7 F0               [24] 3592 	movx	@dptr,a
      006AE8 8F 82            [24] 3593 	mov	dpl, r7
      006AEA 12 68 EF         [24] 3594 	lcall	_ak820_usb_send
      006AED E5 82            [12] 3595 	mov	a, dpl
      006AEF 90 07 F0         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006AF2 F0               [24] 3597 	movx	@dptr,a
      006AF3                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3600 ;	assignBit
      006AF3 A2 1A            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006AF5 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006AF7 90 07 F0         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006AFA E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006AFB F5 82            [12] 3607 	mov	dpl,a
      006AFD 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      006AFE                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006AFE 90 07 8A         [24] 3618 	mov	dptr,#_raw_buffer
      006B01 E0               [24] 3619 	movx	a,@dptr
      006B02 FF               [12] 3620 	mov	r7,a
      006B03 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      006B06 80 35            [24] 3622 	sjmp	00108$
      006B08                       3623 00302$:
      006B08 BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      006B0B 80 34            [24] 3625 	sjmp	00109$
      006B0D                       3626 00303$:
      006B0D BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      006B10 80 2B            [24] 3628 	sjmp	00108$
      006B12                       3629 00304$:
      006B12 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      006B15 80 47            [24] 3631 	sjmp	00116$
      006B17                       3632 00305$:
      006B17 BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      006B1A 80 21            [24] 3634 	sjmp	00108$
      006B1C                       3635 00306$:
      006B1C BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      006B1F 80 1C            [24] 3637 	sjmp	00108$
      006B21                       3638 00307$:
      006B21 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      006B24 80 17            [24] 3640 	sjmp	00108$
      006B26                       3641 00308$:
      006B26 BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      006B29 80 12            [24] 3643 	sjmp	00108$
      006B2B                       3644 00309$:
      006B2B BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      006B2E 80 0D            [24] 3646 	sjmp	00108$
      006B30                       3647 00310$:
      006B30 BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      006B33 80 08            [24] 3649 	sjmp	00108$
      006B35                       3650 00311$:
      006B35 BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      006B38 80 46            [24] 3652 	sjmp	00124$
      006B3A                       3653 00312$:
      006B3A 02 6B D5         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006B3D                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006B3D 75 82 01         [24] 3658 	mov	dpl, #0x01
      006B40 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006B41                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006B41 12 6E 07         [24] 3663 	lcall	_ak820_outline_0158
      006B44 BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      006B47 80 0D            [24] 3665 	sjmp	00113$
      006B49                       3666 00313$:
      006B49 BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      006B4C 80 08            [24] 3668 	sjmp	00113$
      006B4E                       3669 00314$:
      006B4E BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      006B51 80 03            [24] 3671 	sjmp	00113$
      006B53                       3672 00315$:
      006B53 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006B56                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006B56 75 82 01         [24] 3677 	mov	dpl, #0x01
      006B59 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006B5A                       3680 00114$:
      006B5A 75 82 00         [24] 3681 	mov	dpl, #0x00
      006B5D 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006B5E                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006B5E 12 6E 07         [24] 3686 	lcall	_ak820_outline_0158
      006B61 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      006B64 80 12            [24] 3688 	sjmp	00121$
      006B66                       3689 00318$:
      006B66 BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      006B69 80 0D            [24] 3691 	sjmp	00121$
      006B6B                       3692 00319$:
      006B6B BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      006B6E 80 08            [24] 3694 	sjmp	00121$
      006B70                       3695 00320$:
      006B70 BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      006B73 80 03            [24] 3697 	sjmp	00121$
      006B75                       3698 00321$:
      006B75 BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006B78                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006B78 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006B7B 22               [24] 3705 	ret
      006B7C                       3706 00122$:
      006B7C 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006B7F 22               [24] 3709 	ret
      006B80                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006B80 12 6E 07         [24] 3712 	lcall	_ak820_outline_0158
      006B83 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      006B85 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      006B87 EF               [12] 3716 	mov	a,r7
      006B88 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      006B8A 83               [24] 3718 	movc	a,@a+pc
      006B8B F5 82            [12] 3719 	mov	dpl,a
      006B8D EF               [12] 3720 	mov	a,r7
      006B8E 24 12            [12] 3721 	add	a,#(00326$-3-.)
      006B90 83               [24] 3722 	movc	a,@a+pc
      006B91 F5 83            [12] 3723 	mov	dph,a
      006B93 E4               [12] 3724 	clr	a
      006B94 73               [24] 3725 	jmp	@a+dptr
      006B95                       3726 00325$:
      006B95 B1                    3727 	.db	00134$
      006B96 B1                    3728 	.db	00134$
      006B97 B1                    3729 	.db	00134$
      006B98 B1                    3730 	.db	00134$
      006B99 D1                    3731 	.db	00142$
      006B9A B1                    3732 	.db	00134$
      006B9B B1                    3733 	.db	00134$
      006B9C B1                    3734 	.db	00134$
      006B9D B1                    3735 	.db	00134$
      006B9E B1                    3736 	.db	00134$
      006B9F B1                    3737 	.db	00134$
      006BA0 D1                    3738 	.db	00142$
      006BA1 D1                    3739 	.db	00142$
      006BA2 B5                    3740 	.db	00135$
      006BA3                       3741 00326$:
      006BA3 6B                    3742 	.db	00134$>>8
      006BA4 6B                    3743 	.db	00134$>>8
      006BA5 6B                    3744 	.db	00134$>>8
      006BA6 6B                    3745 	.db	00134$>>8
      006BA7 6B                    3746 	.db	00142$>>8
      006BA8 6B                    3747 	.db	00134$>>8
      006BA9 6B                    3748 	.db	00134$>>8
      006BAA 6B                    3749 	.db	00134$>>8
      006BAB 6B                    3750 	.db	00134$>>8
      006BAC 6B                    3751 	.db	00134$>>8
      006BAD 6B                    3752 	.db	00134$>>8
      006BAE 6B                    3753 	.db	00142$>>8
      006BAF 6B                    3754 	.db	00142$>>8
      006BB0 6B                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006BB1                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006BB1 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006BB4 22               [24] 3761 	ret
      006BB5                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006BB5 90 07 8C         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      006BB8 E0               [24] 3765 	movx	a,@dptr
      006BB9 FF               [12] 3766 	mov	r7,a
      006BBA 60 0D            [24] 3767 	jz	00139$
      006BBC BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      006BBF 80 08            [24] 3769 	sjmp	00139$
      006BC1                       3770 00328$:
      006BC1 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      006BC4 80 03            [24] 3772 	sjmp	00139$
      006BC6                       3773 00329$:
      006BC6 BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006BC9                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006BC9 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006BCC 22               [24] 3780 	ret
      006BCD                       3781 00140$:
      006BCD 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006BD0 22               [24] 3784 	ret
      006BD1                       3785 00142$:
      006BD1 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006BD4 22               [24] 3788 	ret
      006BD5                       3789 00144$:
      006BD5 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006BD8 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      006BD9                       3804 _ak820_usb_raw_send:
      006BD9 12 45 11         [24] 3805 	lcall	_ak820_outline_0036
      006BDC 90 07 F2         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006BDF 12 37 E0         [24] 3807 	lcall	_ak820_outline_0015
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006BE2 90 07 F1         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006BE5 E0               [24] 3810 	movx	a,@dptr
      006BE6 FF               [12] 3811 	mov	r7,a
      006BE7 BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006BEA C0 07            [24] 3814 	push	ar7
      006BEC 12 40 27         [24] 3815 	lcall	_ak820_nvm_flush
      006BEF D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006BF1 90 07 AA         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      006BF4 E0               [24] 3819 	movx	a,@dptr
      006BF5 70 07            [24] 3820 	jnz	00103$
      006BF7 12 40 18         [24] 3821 	lcall	_ak820_nvm_ok
      006BFA E5 82            [12] 3822 	mov	a, dpl
      006BFC 60 17            [24] 3823 	jz	00106$
      006BFE                       3824 00103$:
      006BFE 90 07 F2         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006C01 12 45 48         [24] 3826 	lcall	_ak820_outline_0093
      006C04 90 07 E7         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      006C07 12 45 8B         [24] 3828 	lcall	_ak820_outline_0156
      006C0A 90 07 E9         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      006C0D EF               [12] 3830 	mov	a,r7
      006C0E F0               [24] 3831 	movx	@dptr,a
      006C0F 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006C12 02 68 EF         [24] 3834 	ljmp	_ak820_usb_send
      006C15                       3835 00106$:
      006C15 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      006C16                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006C16 A2 AF            [12] 3852 	mov	c,_EA
      006C18 E4               [12] 3853 	clr	a
      006C19 33               [12] 3854 	rlc	a
      006C1A FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3857 ;	assignBit
      006C1B C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006C1D 90 07 82         [24] 3860 	mov	dptr,#_USB_EnumStatus
      006C20 E0               [24] 3861 	movx	a,@dptr
      006C21 60 0A            [24] 3862 	jz	00101$
      006C23 90 07 89         [24] 3863 	mov	dptr,#_raw_state
      006C26 E0               [24] 3864 	movx	a,@dptr
      006C27 FE               [12] 3865 	mov	r6,a
      006C28 BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      006C2B 80 06            [24] 3867 	sjmp	00102$
      006C2D                       3868 00270$:
      006C2D                       3869 00101$:
                                   3870 ;	assignBit
      006C2D EF               [12] 3871 	mov	a,r7
      006C2E 24 FF            [12] 3872 	add	a,#0xff
      006C30 92 AF            [24] 3873 	mov	_EA,c
      006C32 22               [24] 3874 	ret
      006C33                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006C33 90 07 89         [24] 3877 	mov	dptr,#_raw_state
      006C36 74 03            [12] 3878 	mov	a,#0x03
      006C38 F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3881 ;	assignBit
      006C39 EF               [12] 3882 	mov	a,r7
      006C3A 24 FF            [12] 3883 	add	a,#0xff
      006C3C 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006C3E 90 07 8A         [24] 3886 	mov	dptr,#_raw_buffer
      006C41 E0               [24] 3887 	movx	a,@dptr
      006C42 FF               [12] 3888 	mov	r7,a
      006C43 E4               [12] 3889 	clr	a
      006C44 BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      006C47 04               [12] 3891 	inc	a
      006C48                       3892 00271$:
      006C48 FF               [12] 3893 	mov	r7,a
      006C49 70 03            [24] 3894 	jnz	00273$
      006C4B 02 6C EB         [24] 3895 	ljmp	00118$
      006C4E                       3896 00273$:
      006C4E 90 07 8B         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      006C51 E0               [24] 3898 	movx	a,@dptr
      006C52 60 03            [24] 3899 	jz	00274$
      006C54 02 6C EB         [24] 3900 	ljmp	00118$
      006C57                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006C57 90 07 8C         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      006C5A E0               [24] 3904 	movx	a,@dptr
      006C5B FD               [12] 3905 	mov	r5,a
      006C5C 7E 00            [12] 3906 	mov	r6,#0x00
      006C5E 90 07 8D         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      006C61 E0               [24] 3908 	movx	a,@dptr
      006C62 7B 00            [12] 3909 	mov	r3,#0x00
      006C64 42 06            [12] 3910 	orl	ar6,a
      006C66 EB               [12] 3911 	mov	a,r3
      006C67 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006C69 90 07 8E         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      006C6C E0               [24] 3915 	movx	a,@dptr
      006C6D FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006C6E 7B 05            [12] 3918 	mov	r3,#0x05
      006C70                       3919 00128$:
      006C70 EB               [12] 3920 	mov	a,r3
      006C71 12 6D F5         [24] 3921 	lcall	_ak820_outline_0101
      006C74 0B               [12] 3922 	inc	r3
      006C75 BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      006C78                       3924 00275$:
      006C78 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006C7A EC               [12] 3927 	mov	a,r4
      006C7B 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      006C7D 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      006C7F EC               [12] 3931 	mov	a,r4
      006C80 60 26            [24] 3932 	jz	00165$
      006C82 8C 03            [24] 3933 	mov	ar3,r4
      006C84 1B               [12] 3934 	dec	r3
      006C85 7A 00            [12] 3935 	mov	r2,#0x00
      006C87 74 FF            [12] 3936 	mov	a,#0xff
      006C89 C3               [12] 3937 	clr	c
      006C8A 9B               [12] 3938 	subb	a,r3
      006C8B FB               [12] 3939 	mov	r3,a
      006C8C 74 FF            [12] 3940 	mov	a,#0xff
      006C8E 9A               [12] 3941 	subb	a,r2
      006C8F FA               [12] 3942 	mov	r2,a
      006C90 8E 00            [24] 3943 	mov	ar0,r6
      006C92 8D 01            [24] 3944 	mov	ar1,r5
      006C94 C3               [12] 3945 	clr	c
      006C95 EB               [12] 3946 	mov	a,r3
      006C96 98               [12] 3947 	subb	a,r0
      006C97 EA               [12] 3948 	mov	a,r2
      006C98 99               [12] 3949 	subb	a,r1
      006C99 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      006C9B                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006C9B 90 07 8B         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      006C9E 74 FF            [12] 3955 	mov	a,#0xff
      006CA0 F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006CA1 90 07 8E         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      006CA4 E4               [12] 3959 	clr	a
      006CA5 F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006CA6 80 3A            [24] 3962 	sjmp	00108$
      006CA8                       3963 00165$:
      006CA8 7B 00            [12] 3964 	mov	r3,#0x00
      006CAA                       3965 00131$:
      006CAA C3               [12] 3966 	clr	c
      006CAB EB               [12] 3967 	mov	a,r3
      006CAC 9C               [12] 3968 	subb	a,r4
      006CAD 50 33            [24] 3969 	jnc	00108$
      006CAF C0 04            [24] 3970 	push	ar4
      006CB1 8B 02            [24] 3971 	mov	ar2,r3
      006CB3 74 05            [12] 3972 	mov	a,#0x05
      006CB5 2A               [12] 3973 	add	a, r2
      006CB6 F9               [12] 3974 	mov	r1,a
      006CB7 33               [12] 3975 	rlc	a
      006CB8 95 E0            [12] 3976 	subb	a,acc
      006CBA FA               [12] 3977 	mov	r2,a
      006CBB E9               [12] 3978 	mov	a,r1
      006CBC 24 8A            [12] 3979 	add	a, #_raw_buffer
      006CBE F9               [12] 3980 	mov	r1,a
      006CBF EA               [12] 3981 	mov	a,r2
      006CC0 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      006CC2 FA               [12] 3983 	mov	r2,a
      006CC3 8B 2E            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006CC5 75 2F 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006CC8 8E 00            [24] 3986 	mov	ar0,r6
      006CCA 8D 04            [24] 3987 	mov	ar4,r5
      006CCC E5 2E            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006CCE 28               [12] 3989 	add	a, r0
      006CCF F8               [12] 3990 	mov	r0,a
      006CD0 E5 2F            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006CD2 3C               [12] 3992 	addc	a, r4
      006CD3 FC               [12] 3993 	mov	r4,a
      006CD4 88 82            [24] 3994 	mov	dpl,r0
      006CD6 8C 83            [24] 3995 	mov	dph,r4
      006CD8 E4               [12] 3996 	clr	a
      006CD9 93               [24] 3997 	movc	a,@a+dptr
      006CDA 12 6E 01         [24] 3998 	lcall	_ak820_outline_0135
      006CDD 0B               [12] 3999 	inc	r3
      006CDE D0 04            [24] 4000 	pop	ar4
      006CE0 80 C8            [24] 4001 	sjmp	00131$
      006CE2                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006CE2 12 6D E1         [24] 4004 	lcall	_ak820_outline_0041
      006CE5 12 68 EF         [24] 4005 	lcall	_ak820_usb_send
      006CE8 02 6D 91         [24] 4006 	ljmp	00119$
      006CEB                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006CEB EF               [12] 4009 	mov	a,r7
      006CEC 70 03            [24] 4010 	jnz	00281$
      006CEE 02 6D 6E         [24] 4011 	ljmp	00114$
      006CF1                       4012 00281$:
      006CF1 12 6E 07         [24] 4013 	lcall	_ak820_outline_0158
      006CF4 BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      006CF7 80 03            [24] 4015 	sjmp	00283$
      006CF9                       4016 00282$:
      006CF9 02 6D 6E         [24] 4017 	ljmp	00114$
      006CFC                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006CFC 7F 02            [12] 4020 	mov	r7,#0x02
      006CFE                       4021 00133$:
      006CFE EF               [12] 4022 	mov	a,r7
      006CFF 12 6D F5         [24] 4023 	lcall	_ak820_outline_0101
      006D02 0F               [12] 4024 	inc	r7
      006D03 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      006D06                       4026 00284$:
      006D06 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006D08 90 07 8C         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      006D0B 74 01            [12] 4030 	mov	a,#0x01
      006D0D F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006D0E 90 07 8D         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      006D11 74 A8            [12] 4034 	mov	a,#0xa8
      006D13 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006D14 90 07 8E         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      006D17 12 3D 96         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006D1A 7F 00            [12] 4040 	mov	r7,#0x00
      006D1C                       4041 00135$:
      006D1C 8F 06            [24] 4042 	mov	ar6,r7
      006D1E 74 0B            [12] 4043 	mov	a,#0x0b
      006D20 2E               [12] 4044 	add	a, r6
      006D21 24 8A            [12] 4045 	add	a,#_raw_buffer
      006D23 FE               [12] 4046 	mov	r6,a
      006D24 E4               [12] 4047 	clr	a
      006D25 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      006D27 FD               [12] 4049 	mov	r5,a
      006D28 EF               [12] 4050 	mov	a,r7
      006D29 24 60            [12] 4051 	add	a, #_ak820_flash_diagnostic
      006D2B F5 82            [12] 4052 	mov	dpl,a
      006D2D E4               [12] 4053 	clr	a
      006D2E 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006D30 F5 83            [12] 4055 	mov	dph,a
      006D32 E0               [24] 4056 	movx	a,@dptr
      006D33 8E 82            [24] 4057 	mov	dpl,r6
      006D35 8D 83            [24] 4058 	mov	dph,r5
      006D37 F0               [24] 4059 	movx	@dptr,a
      006D38 0F               [12] 4060 	inc	r7
      006D39 BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      006D3C                       4062 00286$:
      006D3C 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006D3E 90 0E 0B         [24] 4065 	mov	dptr,#_vial_unlocked
      006D41 E0               [24] 4066 	movx	a,@dptr
      006D42 90 07 9B         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      006D45 F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006D46 90 0E 0C         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      006D49 E0               [24] 4071 	movx	a,@dptr
      006D4A 90 07 9C         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      006D4D F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006D4E 90 07 82         [24] 4075 	mov	dptr,#_USB_EnumStatus
      006D51 E0               [24] 4076 	movx	a,@dptr
      006D52 90 07 9D         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      006D55 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006D56 90 07 83         [24] 4080 	mov	dptr,#_USB_SleepStatus
      006D59 E0               [24] 4081 	movx	a,@dptr
      006D5A 90 07 9E         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      006D5D F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006D5E 90 07 89         [24] 4085 	mov	dptr,#_raw_state
      006D61 E0               [24] 4086 	movx	a,@dptr
      006D62 90 07 9F         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      006D65 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006D66 12 6D E1         [24] 4090 	lcall	_ak820_outline_0041
      006D69 12 68 EF         [24] 4091 	lcall	_ak820_usb_send
      006D6C 80 23            [24] 4092 	sjmp	00119$
      006D6E                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006D6E 12 6A FE         [24] 4095 	lcall	_raw_request_is_nonpersistent
      006D71 E5 82            [12] 4096 	mov	a, dpl
      006D73 90 07 AA         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      006D76 F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      006D77 12 41 7A         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006D7A 90 0C 3C         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      006D7D 74 20            [12] 4103 	mov	a,#0x20
      006D7F F0               [24] 4104 	movx	@dptr,a
      006D80 90 07 8A         [24] 4105 	mov	dptr,#_raw_buffer
      006D83 75 F0 00         [24] 4106 	mov	b, #0x00
      006D86 12 A6 FD         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      006D89 12 41 8F         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      006D8C 90 07 AA         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      006D8F E4               [12] 4112 	clr	a
      006D90 F0               [24] 4113 	movx	@dptr,a
      006D91                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4116 ;	assignBit
      006D91 A2 AF            [12] 4117 	mov	c,_EA
      006D93 92 1B            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4120 ;	assignBit
      006D95 C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006D97 12 6E 0D         [24] 4123 	lcall	_ak820_outline_0160
      006D9A BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      006D9D 90 07 89         [24] 4125 	mov	dptr,#_raw_state
      006DA0 74 05            [12] 4126 	mov	a,#0x05
      006DA2 F0               [24] 4127 	movx	@dptr,a
      006DA3 80 1B            [24] 4128 	sjmp	00127$
      006DA5                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006DA5 12 6E 0D         [24] 4131 	lcall	_ak820_outline_0160
      006DA8 BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      006DAB 80 0E            [24] 4133 	sjmp	00121$
      006DAD                       4134 00290$:
      006DAD 12 6E 0D         [24] 4135 	lcall	_ak820_outline_0160
      006DB0 BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      006DB3 80 06            [24] 4137 	sjmp	00121$
      006DB5                       4138 00291$:
      006DB5 12 6E 0D         [24] 4139 	lcall	_ak820_outline_0160
      006DB8 BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      006DBB                       4141 00121$:
      006DBB 90 07 89         [24] 4142 	mov	dptr,#_raw_state
      006DBE E4               [12] 4143 	clr	a
      006DBF F0               [24] 4144 	movx	@dptr,a
      006DC0                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4147 ;	assignBit
      006DC0 A2 1B            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006DC2 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      006DC4 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      006DC5                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      006DC5 A2 AF            [12] 4165 	mov	c,_EA
      006DC7 92 1C            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4168 ;	assignBit
      006DC9 C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      006DCB 90 07 AB         [24] 4171 	mov	dptr,#_keyboard_reset
      006DCE E0               [24] 4172 	movx	a,@dptr
      006DCF FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      006DD0 E4               [12] 4175 	clr	a
      006DD1 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4178 ;	assignBit
      006DD2 A2 1C            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006DD4 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      006DD6 EF               [12] 4182 	mov	a,r7
      006DD7 B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      006DDA                       4184 00103$:
      006DDA B3               [12] 4185 	cpl	c
      006DDB 92 1C            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006DDD 12 38 81         [24] 4187 	lcall	_ak820_outline_0166
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      006DE0 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00B9D8                       4193 _shared_offsets:
      00B9D8 00                    4194 	.db #0x00	; 0
      00B9D9 00                    4195 	.db #0x00	; 0
      00B9DA 28                    4196 	.db #0x28	; 40
      00B9DB 28                    4197 	.db #0x28	; 40
      00B9DC 2B                    4198 	.db #0x2b	; 43
      00B9DD 00                    4199 	.db #0x00	; 0
      00B9DE 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00B9DF                       4203 _shared_lengths:
      00B9DF 00                    4204 	.db #0x00	; 0
      00B9E0 00                    4205 	.db #0x00	; 0
      00B9E1 00                    4206 	.db #0x00	; 0
      00B9E2 03                    4207 	.db #0x03	; 3
      00B9E3 03                    4208 	.db #0x03	; 3
      00B9E4 00                    4209 	.db #0x00	; 0
      00B9E5 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00B9E6                       4213 _interface_descriptors:
      00B9E6 81 BF                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00B9E8 81 C0                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00B9EA 34 C0                 4216 	.byte _RawReport, (_RawReport >> 8)
      00B9EC 9A C0                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00B9EE C6 BF                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00B9F0 B3 C0                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0015
                                   4226 	.globl _ak820_outline_0036
                                   4227 	.globl _ak820_outline_0041
                                   4228 	.globl _ak820_outline_0093
                                   4229 	.globl _ak820_outline_0101
                                   4230 	.globl _ak820_outline_0135
                                   4231 	.globl _ak820_outline_0156
                                   4232 	.globl _ak820_outline_0158
                                   4233 	.globl _ak820_outline_0160
                                   4234 	.globl _ak820_outline_0166
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0041
      006DE1                       4238 _ak820_outline_0041:
      006DE1 90 07 E7         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      006DE4 74 8A            [12] 4240 	mov	a,#_raw_buffer
      006DE6 F0               [24] 4241 	movx	@dptr,a
      006DE7 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      006DE9 A3               [24] 4243 	inc	dptr
      006DEA F0               [24] 4244 	movx	@dptr,a
      006DEB 90 07 E9         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      006DEE 74 20            [12] 4246 	mov	a,#0x20
      006DF0 F0               [24] 4247 	movx	@dptr,a
      006DF1 75 82 03         [24] 4248 	mov	dpl,#0x03
      006DF4 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0101
      006DF5                       4253 _ak820_outline_0101:
      006DF5 24 8A            [12] 4254 	add	a,#_raw_buffer
      006DF7 F5 82            [12] 4255 	mov	dpl,a
      006DF9 E4               [12] 4256 	clr	a
      006DFA 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      006DFC F5 83            [12] 4258 	mov	dph,a
      006DFE E4               [12] 4259 	clr	a
      006DFF F0               [24] 4260 	movx	@dptr,a
      006E00 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0135
      006E01                       4265 _ak820_outline_0135:
      006E01 89 82            [24] 4266 	mov	dpl,r1
      006E03 8A 83            [24] 4267 	mov	dph,r2
      006E05 F0               [24] 4268 	movx	@dptr,a
      006E06 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0158
      006E07                       4273 _ak820_outline_0158:
      006E07 90 07 8B         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      006E0A E0               [24] 4275 	movx	a,@dptr
      006E0B FF               [12] 4276 	mov	r7,a
      006E0C 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0160
      006E0D                       4281 _ak820_outline_0160:
      006E0D 90 07 89         [24] 4282 	mov	dptr,#_raw_state
      006E10 E0               [24] 4283 	movx	a,@dptr
      006E11 FF               [12] 4284 	mov	r7,a
      006E12 22               [24] 4285 	ret
