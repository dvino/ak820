                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005B4                        562 _source_state:
      0005B4                        563 	.ds 130
      000636                        564 _pending_time:
      000636                        565 	.ds 2
      000638                        566 _pending_code:
      000638                        567 	.ds 2
      00063A                        568 _ak820_tapping_source_PARM_1:
      00063A                        569 	.ds 2
      00063C                        570 _hold_PARM_2:
      00063C                        571 	.ds 1
      00063D                        572 _hold_code_10000_601:
      00063D                        573 	.ds 2
      00063F                        574 _hold_mods_30000_604:
      00063F                        575 	.ds 1
      000640                        576 _commit_pending_id_10000_610:
      000640                        577 	.ds 1
      000641                        578 _ak820_tapping_before_event_10000_611:
      000641                        579 	.ds 2
      000643                        580 _ak820_tapping_process_record_10000_622:
      000643                        581 	.ds 2
      000645                        582 _ak820_tapping_process_code_10000_623:
      000645                        583 	.ds 2
      000647                        584 _ak820_tapping_process_sc_mods_10000_623:
      000647                        585 	.ds 1
      000648                        586 _ak820_oneshot_mods::
      000648                        587 	.ds 1
      000649                        588 _ak820_oneshot_consumed::
      000649                        589 	.ds 1
      00064A                        590 _ak820_oneshot_process_PARM_2:
      00064A                        591 	.ds 1
      00064B                        592 _ak820_oneshot_process_PARM_3:
      00064B                        593 	.ds 1
      00064C                        594 _ak820_oneshot_process_code_10000_648:
      00064C                        595 	.ds 2
      00064E                        596 _ak820_oneshot_process_mods_10000_649:
      00064E                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000D9B                        606 _pending:
      000D9B                        607 	.ds 1
      000D9C                        608 _ak820_oneshot_target::
      000D9C                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      00459B                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      00459B 90 06 3B         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00459E E0               [24]  656 	movx	a,@dptr
      00459F FF               [12]  657 	mov	r7,a
      0045A0 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0045A3                        659 00147$:
      0045A3 50 14            [24]  660 	jnc	00102$
      0045A5 90 06 3A         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045A8 E0               [24]  662 	movx	a,@dptr
      0045A9 FE               [12]  663 	mov	r6,a
      0045AA BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0045AD                        665 00149$:
      0045AD 50 0A            [24]  666 	jnc	00102$
      0045AF 8F 05            [24]  667 	mov	ar5,r7
      0045B1 ED               [12]  668 	mov	a,r5
      0045B2 12 38 8B         [24]  669 	lcall	_ak820_outline_0184
      0045B5 2E               [12]  670 	add	a,r6
      0045B6 F5 82            [12]  671 	mov	dpl,a
      0045B8 22               [24]  672 	ret
      0045B9                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0045B9 90 06 3A         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045BC E0               [24]  676 	movx	a,@dptr
      0045BD FE               [12]  677 	mov	r6,a
      0045BE BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0045C1                        679 00151$:
      0045C1 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0045C3 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0045C6 75 82 80         [24]  683 	mov	dpl, #0x80
      0045C9 22               [24]  684 	ret
      0045CA                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0045CA BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0045CD 75 82 81         [24]  688 	mov	dpl, #0x81
      0045D0 22               [24]  689 	ret
      0045D1                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0045D1 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0045D4 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_601'
                                    700 ;mods          Allocated with name '_hold_mods_30000_604'
                                    701 ;layer         Allocated with name '_hold_layer_30000_607'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0045D5                        707 _hold:
      0045D5 12 38 4B         [24]  708 	lcall	_ak820_outline_0104
      0045D8 90 06 3D         [24]  709 	mov	dptr,#_hold_code_10000_601
      0045DB 12 38 50         [24]  710 	lcall	_ak820_outline_0105
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0045DE 90 06 3D         [24]  712 	mov	dptr,#_hold_code_10000_601
      0045E1 12 37 CC         [24]  713 	lcall	_ak820_outline_0009
      0045E4 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0045E6 2D               [12]  715 	add	a,r5
      0045E7 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0045E9 8F 05            [24]  718 	mov	ar5,r7
      0045EB 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0045EE 90 06 3F         [24]  720 	mov	dptr,#_hold_mods_30000_604
      0045F1 ED               [12]  721 	mov	a,r5
      0045F2 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0045F3 ED               [12]  724 	mov	a,r5
      0045F4 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0045F7 ED               [12]  726 	mov	a,r5
      0045F8 C4               [12]  727 	swap	a
      0045F9 54 F0            [12]  728 	anl	a,#0xf0
      0045FB 90 06 3F         [24]  729 	mov	dptr,#_hold_mods_30000_604
      0045FE F0               [24]  730 	movx	@dptr,a
      0045FF                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0045FF 90 06 3C         [24]  733 	mov	dptr,#_hold_PARM_2
      004602 E0               [24]  734 	movx	a,@dptr
      004603 60 09            [24]  735 	jz	00104$
      004605 90 06 3F         [24]  736 	mov	dptr,#_hold_mods_30000_604
      004608 E0               [24]  737 	movx	a,@dptr
      004609 F5 82            [12]  738 	mov	dpl,a
      00460B 02 77 AD         [24]  739 	ljmp	_register_mods
      00460E                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      00460E 90 06 3F         [24]  742 	mov	dptr,#_hold_mods_30000_604
      004611 E0               [24]  743 	movx	a,@dptr
      004612 F5 82            [12]  744 	mov	dpl,a
      004614 02 77 C1         [24]  745 	ljmp	_unregister_mods
      004617                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004617 8F 06            [24]  748 	mov	ar6,r7
      004619 74 0F            [12]  749 	mov	a,#0x0f
      00461B 5E               [12]  750 	anl	a,r6
      00461C FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      00461D 90 06 3C         [24]  753 	mov	dptr,#_hold_PARM_2
      004620 E0               [24]  754 	movx	a,@dptr
      004621 60 05            [24]  755 	jz	00107$
      004623 8F 82            [24]  756 	mov	dpl, r7
      004625 02 79 74         [24]  757 	ljmp	_layer_hold_on
      004628                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004628 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00462A 02 79 AC         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00462D                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      00462D 90 0D 9B         [24]  774 	mov	dptr,#_pending
      004630 E0               [24]  775 	movx	a,@dptr
      004631 90 06 40         [24]  776 	mov	dptr,#_commit_pending_id_10000_610
      004634 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004635 12 4A 98         [24]  779 	lcall	_ak820_outline_0149
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004638 90 06 40         [24]  781 	mov	dptr,#_commit_pending_id_10000_610
      00463B E0               [24]  782 	movx	a,@dptr
      00463C 24 B4            [12]  783 	add	a,#_source_state
      00463E FF               [12]  784 	mov	r7,a
      00463F E4               [12]  785 	clr	a
      004640 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004642 FE               [12]  787 	mov	r6,a
      004643 12 45 80         [24]  788 	lcall	_ak820_outline_0152
      004646 E0               [24]  789 	movx	a,@dptr
      004647 FD               [12]  790 	mov	r5,a
      004648 43 05 04         [24]  791 	orl	ar5,#0x04
      00464B 12 45 80         [24]  792 	lcall	_ak820_outline_0152
      00464E ED               [12]  793 	mov	a,r5
      00464F F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004650 90 06 38         [24]  796 	mov	dptr,#_pending_code
      004653 12 38 01         [24]  797 	lcall	_ak820_outline_0050
      004656 90 06 3C         [24]  798 	mov	dptr,#_hold_PARM_2
      004659 12 4A 6D         [24]  799 	lcall	_ak820_outline_0054
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      00465C 02 45 D5         [24]  801 	ljmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      00465F                        812 _ak820_tapping_before:
      00465F 12 38 4B         [24]  813 	lcall	_ak820_outline_0104
      004662 90 06 41         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004665 12 38 50         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004668 90 06 41         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_611
      00466B 12 37 CC         [24]  818 	lcall	_ak820_outline_0009
      00466E 12 4A 48         [24]  819 	lcall	_ak820_outline_0022
      004671 C0 07            [24]  820 	push	ar7
      004673 C0 06            [24]  821 	push	ar6
      004675 12 B8 6D         [24]  822 	lcall	___memcpy
      004678 12 45 9B         [24]  823 	lcall	_ak820_tapping_source
      00467B AD 82            [24]  824 	mov	r5, dpl
      00467D D0 06            [24]  825 	pop	ar6
      00467F D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004681 90 0E 0C         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004684 E0               [24]  829 	movx	a,@dptr
      004685 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004687 74 04            [12]  832 	mov	a,#0x04
      004689 12 4A 2E         [24]  833 	lcall	_ak820_outline_0012
      00468C 60 1E            [24]  834 	jz	00102$
      00468E BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004691 80 19            [24]  836 	sjmp	00102$
      004693                        837 00218$:
      004693 74 05            [12]  838 	mov	a,#0x05
      004695 12 4A 2E         [24]  839 	lcall	_ak820_outline_0012
      004698 70 12            [24]  840 	jnz	00102$
      00469A ED               [12]  841 	mov	a,r5
      00469B 24 B4            [12]  842 	add	a, #_source_state
      00469D FB               [12]  843 	mov	r3,a
      00469E E4               [12]  844 	clr	a
      00469F 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      0046A1 12 4A 75         [24]  846 	lcall	_ak820_outline_0055
      0046A4 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0046A7 12 33 FC         [24]  848 	lcall	_ak820_outline_0121
      0046AA EA               [12]  849 	mov	a,r2
      0046AB F0               [24]  850 	movx	@dptr,a
      0046AC                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0046AC 75 82 00         [24]  853 	mov	dpl, #0x00
      0046AF 22               [24]  854 	ret
      0046B0                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0046B0 90 0D 9B         [24]  857 	mov	dptr,#_pending
      0046B3 E0               [24]  858 	movx	a,@dptr
      0046B4 FC               [12]  859 	mov	r4,a
      0046B5 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      0046B8 80 3B            [24]  861 	sjmp	00108$
      0046BA                        862 00220$:
      0046BA 12 37 F1         [24]  863 	lcall	_ak820_outline_0029
      0046BD FA               [12]  864 	mov	r2,a
      0046BE A3               [24]  865 	inc	dptr
      0046BF E0               [24]  866 	movx	a,@dptr
      0046C0 FB               [12]  867 	mov	r3,a
      0046C1 90 06 36         [24]  868 	mov	dptr,#_pending_time
      0046C4 12 38 45         [24]  869 	lcall	_ak820_outline_0100
      0046C7 EA               [12]  870 	mov	a,r2
      0046C8 C3               [12]  871 	clr	c
      0046C9 98               [12]  872 	subb	a,r0
      0046CA FA               [12]  873 	mov	r2,a
      0046CB EB               [12]  874 	mov	a,r3
      0046CC 99               [12]  875 	subb	a,r1
      0046CD FB               [12]  876 	mov	r3,a
      0046CE C3               [12]  877 	clr	c
      0046CF EA               [12]  878 	mov	a,r2
      0046D0 94 C8            [12]  879 	subb	a,#0xc8
      0046D2 EB               [12]  880 	mov	a,r3
      0046D3 94 00            [12]  881 	subb	a,#0x00
      0046D5 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0046D7 74 04            [12]  884 	mov	a,#0x04
      0046D9 12 4A 62         [24]  885 	lcall	_ak820_outline_0045
      0046DC 60 17            [24]  886 	jz	00108$
      0046DE 12 37 AB         [24]  887 	lcall	_ak820_outline_0005
      0046E1 60 12            [24]  888 	jz	00108$
      0046E3 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      0046E6 80 06            [24]  890 	sjmp	00107$
      0046E8                        891 00224$:
      0046E8 ED               [12]  892 	mov	a,r5
      0046E9 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      0046EC 80 07            [24]  894 	sjmp	00108$
      0046EE                        895 00225$:
      0046EE                        896 00107$:
      0046EE C0 05            [24]  897 	push	ar5
      0046F0 12 46 2D         [24]  898 	lcall	_commit_pending
      0046F3 D0 05            [24]  899 	pop	ar5
      0046F5                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0046F5 90 06 41         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0046F8 12 38 01         [24]  903 	lcall	_ak820_outline_0050
      0046FB 74 04            [12]  904 	mov	a,#0x04
      0046FD 12 4A 2E         [24]  905 	lcall	_ak820_outline_0012
      004700 60 03            [24]  906 	jz	00114$
      004702 BD FF 04         [24]  907 	cjne	r5,#0xff,00115$
      004705                        908 00114$:
      004705 75 82 01         [24]  909 	mov	dpl, #0x01
      004708 22               [24]  910 	ret
      004709                        911 00115$:
                                    912 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004709 ED               [12]  913 	mov	a,r5
      00470A 12 4A 8A         [24]  914 	lcall	_ak820_outline_0077
      00470D 30 E1 13         [24]  915 	jnb	acc.1,00120$
                                    916 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004710 74 05            [12]  917 	mov	a,#0x05
      004712 2E               [12]  918 	add	a, r6
      004713 12 37 D6         [24]  919 	lcall	_ak820_outline_0013
      004716 70 07            [24]  920 	jnz	00118$
      004718 74 FD            [12]  921 	mov	a,#0xfd
      00471A 5B               [12]  922 	anl	a,r3
      00471B 12 38 55         [24]  923 	lcall	_ak820_outline_0117
      00471E F0               [24]  924 	movx	@dptr,a
      00471F                        925 00118$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      00471F 75 82 00         [24]  927 	mov	dpl, #0x00
      004722 22               [24]  928 	ret
      004723                        929 00120$:
                                    930 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004723 12 44 FF         [24]  931 	lcall	_ak820_outline_0011
      004726 E0               [24]  932 	movx	a,@dptr
      004727 FF               [12]  933 	mov	r7,a
      004728 8B 06            [24]  934 	mov	ar6,r3
      00472A 53 06 01         [24]  935 	anl	ar6,#0x01
      00472D EE               [12]  936 	mov	a,r6
      00472E B4 01 00         [24]  937 	cjne	a,#0x01,00231$
      004731                        938 00231$:
      004731 B3               [12]  939 	cpl	c
      004732 92 0C            [24]  940 	mov	_ak820_tapping_before_sloc0_1_0,c
      004734 8F F0            [24]  941 	mov	b,r7
      004736 E4               [12]  942 	clr	a
      004737 33               [12]  943 	rlc	a
      004738 B5 F0 04         [24]  944 	cjne	a,b,00122$
      00473B 75 82 00         [24]  945 	mov	dpl, #0x00
      00473E 22               [24]  946 	ret
      00473F                        947 00122$:
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      00473F 63 03 01         [24]  949 	xrl	ar3,#0x01
      004742 12 38 55         [24]  950 	lcall	_ak820_outline_0117
      004745 EB               [12]  951 	mov	a,r3
      004746 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004747 75 82 01         [24]  954 	mov	dpl, #0x01
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      00474A 22               [24]  956 	ret
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    959 ;------------------------------------------------------------
                                    960 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    961 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    962 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    963 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    964 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_623'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function ak820_tapping_process
                                    969 ;	-----------------------------------------
      00474B                        970 _ak820_tapping_process:
      00474B 12 38 4B         [24]  971 	lcall	_ak820_outline_0104
      00474E 90 06 43         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004751 12 38 50         [24]  973 	lcall	_ak820_outline_0105
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004754 90 06 47         [24]  975 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004757 E4               [12]  976 	clr	a
      004758 F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004759 90 06 43         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00475C 12 38 01         [24]  980 	lcall	_ak820_outline_0050
      00475F 74 04            [12]  981 	mov	a,#0x04
      004761 12 4A 23         [24]  982 	lcall	_ak820_outline_0010
      004764 70 04            [24]  983 	jnz	00102$
      004766 75 82 01         [24]  984 	mov	dpl, #0x01
      004769 22               [24]  985 	ret
      00476A                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      00476A 8E 04            [24]  988 	mov	ar4,r6
      00476C 8F 05            [24]  989 	mov	ar5,r7
      00476E 12 4A 48         [24]  990 	lcall	_ak820_outline_0022
      004771 C0 07            [24]  991 	push	ar7
      004773 C0 06            [24]  992 	push	ar6
      004775 12 B8 6D         [24]  993 	lcall	___memcpy
      004778 12 45 9B         [24]  994 	lcall	_ak820_tapping_source
      00477B AD 82            [24]  995 	mov	r5, dpl
      00477D D0 06            [24]  996 	pop	ar6
      00477F D0 07            [24]  997 	pop	ar7
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004781 BD FF 04         [24]  999 	cjne	r5,#0xff,00104$
      004784 75 82 01         [24] 1000 	mov	dpl, #0x01
      004787 22               [24] 1001 	ret
      004788                       1002 00104$:
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004788 74 07            [12] 1004 	mov	a,#0x07
      00478A 12 37 E8         [24] 1005 	lcall	_ak820_outline_0016
      00478D FE               [12] 1006 	mov	r6,a
      00478E A3               [24] 1007 	inc	dptr
      00478F E0               [24] 1008 	movx	a,@dptr
      004790 FF               [12] 1009 	mov	r7,a
      004791 90 06 45         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004794 12 4A 7D         [24] 1011 	lcall	_ak820_outline_0058
                                   1012 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004797 BE 1A 15         [24] 1013 	cjne	r6,#0x1a,00111$
      00479A BF 7C 12         [24] 1014 	cjne	r7,#0x7c,00111$
      00479D 90 06 45         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047A0 74 26            [12] 1016 	mov	a,#0x26
      0047A2 F0               [24] 1017 	movx	@dptr,a
      0047A3 74 22            [12] 1018 	mov	a,#0x22
      0047A5 A3               [24] 1019 	inc	dptr
      0047A6 F0               [24] 1020 	movx	@dptr,a
      0047A7 90 06 47         [24] 1021 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0047AA 74 02            [12] 1022 	mov	a,#0x02
      0047AC F0               [24] 1023 	movx	@dptr,a
      0047AD 80 28            [24] 1024 	sjmp	00112$
      0047AF                       1025 00111$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0047AF BE 1B 15         [24] 1027 	cjne	r6,#0x1b,00108$
      0047B2 BF 7C 12         [24] 1028 	cjne	r7,#0x7c,00108$
      0047B5 90 06 45         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047B8 74 27            [12] 1030 	mov	a,#0x27
      0047BA F0               [24] 1031 	movx	@dptr,a
      0047BB 74 32            [12] 1032 	mov	a,#0x32
      0047BD A3               [24] 1033 	inc	dptr
      0047BE F0               [24] 1034 	movx	@dptr,a
      0047BF 90 06 47         [24] 1035 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0047C2 74 20            [12] 1036 	mov	a,#0x20
      0047C4 F0               [24] 1037 	movx	@dptr,a
      0047C5 80 10            [24] 1038 	sjmp	00112$
      0047C7                       1039 00108$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0047C7 BE 1E 0D         [24] 1041 	cjne	r6,#0x1e,00112$
      0047CA BF 7C 0A         [24] 1042 	cjne	r7,#0x7c,00112$
      0047CD 90 06 45         [24] 1043 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047D0 74 28            [12] 1044 	mov	a,#0x28
      0047D2 F0               [24] 1045 	movx	@dptr,a
      0047D3 74 32            [12] 1046 	mov	a,#0x32
      0047D5 A3               [24] 1047 	inc	dptr
      0047D6 F0               [24] 1048 	movx	@dptr,a
      0047D7                       1049 00112$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      0047D7 90 06 45         [24] 1051 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047DA E0               [24] 1052 	movx	a,@dptr
      0047DB A3               [24] 1053 	inc	dptr
      0047DC E0               [24] 1054 	movx	a,@dptr
      0047DD FF               [12] 1055 	mov	r7,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      0047DE BF 20 00         [24] 1057 	cjne	r7,#0x20,00242$
      0047E1                       1058 00242$:
      0047E1 40 05            [24] 1059 	jc	00113$
      0047E3 BF 50 00         [24] 1060 	cjne	r7,#0x50,00244$
      0047E6                       1061 00244$:
      0047E6 40 04            [24] 1062 	jc	00114$
      0047E8                       1063 00113$:
      0047E8 75 82 01         [24] 1064 	mov	dpl, #0x01
      0047EB 22               [24] 1065 	ret
      0047EC                       1066 00114$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0047EC BF 40 00         [24] 1068 	cjne	r7,#0x40,00246$
      0047EF                       1069 00246$:
      0047EF 40 0C            [24] 1070 	jc	00117$
      0047F1 53 07 0F         [24] 1071 	anl	ar7,#0x0f
      0047F4 BF 06 00         [24] 1072 	cjne	r7,#0x06,00248$
      0047F7                       1073 00248$:
      0047F7 40 04            [24] 1074 	jc	00117$
      0047F9 75 82 00         [24] 1075 	mov	dpl, #0x00
      0047FC 22               [24] 1076 	ret
      0047FD                       1077 00117$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      0047FD 90 06 43         [24] 1079 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004800 12 38 01         [24] 1080 	lcall	_ak820_outline_0050
      004803 74 05            [12] 1081 	mov	a,#0x05
      004805 12 4A 2E         [24] 1082 	lcall	_ak820_outline_0012
      004808 60 21            [24] 1083 	jz	00131$
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      00480A 90 0D 9B         [24] 1085 	mov	dptr,#_pending
      00480D ED               [12] 1086 	mov	a,r5
      00480E F0               [24] 1087 	movx	@dptr,a
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00480F 12 37 F1         [24] 1089 	lcall	_ak820_outline_0029
      004812 FE               [12] 1090 	mov	r6,a
      004813 A3               [24] 1091 	inc	dptr
      004814 E0               [24] 1092 	movx	a,@dptr
      004815 FF               [12] 1093 	mov	r7,a
      004816 90 06 36         [24] 1094 	mov	dptr,#_pending_time
      004819 12 4A 7D         [24] 1095 	lcall	_ak820_outline_0058
                                   1096 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      00481C 90 06 45         [24] 1097 	mov	dptr,#_ak820_tapping_process_code_10000_623
      00481F 12 38 01         [24] 1098 	lcall	_ak820_outline_0050
      004822 90 06 38         [24] 1099 	mov	dptr,#_pending_code
      004825 12 4A 7D         [24] 1100 	lcall	_ak820_outline_0058
      004828 02 48 C8         [24] 1101 	ljmp	00132$
      00482B                       1102 00131$:
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      00482B 90 0D 9B         [24] 1104 	mov	dptr,#_pending
      00482E E0               [24] 1105 	movx	a,@dptr
      00482F FF               [12] 1106 	mov	r7,a
      004830 ED               [12] 1107 	mov	a,r5
      004831 B5 07 02         [24] 1108 	cjne	a,ar7,00251$
      004834 80 03            [24] 1109 	sjmp	00252$
      004836                       1110 00251$:
      004836 02 48 A1         [24] 1111 	ljmp	00128$
      004839                       1112 00252$:
                                   1113 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004839 12 4A 98         [24] 1114 	lcall	_ak820_outline_0149
                                   1115 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      00483C 90 06 47         [24] 1116 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      00483F E0               [24] 1117 	movx	a,@dptr
      004840 FF               [12] 1118 	mov	r7,a
      004841 E0               [24] 1119 	movx	a,@dptr
      004842 60 05            [24] 1120 	jz	00120$
      004844 8F 82            [24] 1121 	mov	dpl, r7
      004846 12 7D F9         [24] 1122 	lcall	_add_owned_mods
      004849                       1123 00120$:
                                   1124 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004849 90 06 43         [24] 1125 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00484C 12 38 01         [24] 1126 	lcall	_ak820_outline_0050
      00484F 74 07            [12] 1127 	mov	a,#0x07
      004851 2E               [12] 1128 	add	a, r6
      004852 FB               [12] 1129 	mov	r3,a
      004853 E4               [12] 1130 	clr	a
      004854 3F               [12] 1131 	addc	a, r7
      004855 FC               [12] 1132 	mov	r4,a
      004856 90 06 45         [24] 1133 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004859 E0               [24] 1134 	movx	a,@dptr
      00485A F9               [12] 1135 	mov	r1,a
      00485B 7A 00            [12] 1136 	mov	r2,#0x00
      00485D 12 33 FC         [24] 1137 	lcall	_ak820_outline_0121
      004860 E9               [12] 1138 	mov	a,r1
      004861 F0               [24] 1139 	movx	@dptr,a
      004862 EA               [12] 1140 	mov	a,r2
      004863 A3               [24] 1141 	inc	dptr
      004864 F0               [24] 1142 	movx	@dptr,a
                                   1143 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004865 C3               [12] 1144 	clr	c
      004866 04               [12] 1145 	inc	a
      004867 99               [12] 1146 	subb	a,r1
      004868 50 25            [24] 1147 	jnc	00122$
                                   1148 ;	free result
                                   1149 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      00486A 74 06            [12] 1150 	mov	a,#0x06
      00486C 12 37 E8         [24] 1151 	lcall	_ak820_outline_0016
      00486F 54 0F            [12] 1152 	anl	a,#0x0f
      004871 44 10            [12] 1153 	orl	a,#0x10
      004873 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004874 12 44 FF         [24] 1156 	lcall	_ak820_outline_0011
      004877 12 4A 6D         [24] 1157 	lcall	_ak820_outline_0054
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      00487A 12 72 79         [24] 1159 	lcall	_process_record
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      00487D 90 06 43         [24] 1161 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004880 12 37 A1         [24] 1162 	lcall	_ak820_outline_0004
      004883 A3               [24] 1163 	inc	dptr
      004884 A3               [24] 1164 	inc	dptr
      004885 A3               [24] 1165 	inc	dptr
      004886 A3               [24] 1166 	inc	dptr
      004887 A3               [24] 1167 	inc	dptr
      004888 E4               [12] 1168 	clr	a
      004889 12 45 35         [24] 1169 	lcall	_ak820_outline_0061
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      00488C 12 72 79         [24] 1171 	lcall	_process_record
      00488F                       1172 00122$:
                                   1173 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      00488F 90 06 47         [24] 1174 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004892 E0               [24] 1175 	movx	a,@dptr
      004893 FF               [12] 1176 	mov	r7,a
      004894 E0               [24] 1177 	movx	a,@dptr
      004895 60 31            [24] 1178 	jz	00132$
                                   1179 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004897 8F 82            [24] 1180 	mov	dpl, r7
      004899 12 7E 09         [24] 1181 	lcall	_del_owned_mods
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      00489C 12 81 33         [24] 1183 	lcall	_send_keyboard_report
      00489F 80 27            [24] 1184 	sjmp	00132$
      0048A1                       1185 00128$:
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      0048A1 ED               [12] 1187 	mov	a,r5
      0048A2 24 B4            [12] 1188 	add	a, #_source_state
      0048A4 FE               [12] 1189 	mov	r6,a
      0048A5 E4               [12] 1190 	clr	a
      0048A6 34 05            [12] 1191 	addc	a, #(_source_state >> 8)
      0048A8 FF               [12] 1192 	mov	r7,a
      0048A9 12 38 39         [24] 1193 	lcall	_ak820_outline_0097
      0048AC FD               [12] 1194 	mov	r5,a
      0048AD 30 E2 18         [24] 1195 	jnb	acc.2,00132$
                                   1196 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0048B0 53 05 FB         [24] 1197 	anl	ar5,#0xfb
      0048B3 12 45 5A         [24] 1198 	lcall	_ak820_outline_0114
      0048B6 ED               [12] 1199 	mov	a,r5
      0048B7 F0               [24] 1200 	movx	@dptr,a
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0048B8 90 06 45         [24] 1202 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048BB 12 38 01         [24] 1203 	lcall	_ak820_outline_0050
      0048BE 90 06 3C         [24] 1204 	mov	dptr,#_hold_PARM_2
      0048C1 E4               [12] 1205 	clr	a
      0048C2 12 45 35         [24] 1206 	lcall	_ak820_outline_0061
      0048C5 12 45 D5         [24] 1207 	lcall	_hold
      0048C8                       1208 00132$:
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0048C8 75 82 00         [24] 1210 	mov	dpl, #0x00
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0048CB 22               [24] 1212 	ret
                                   1213 ;------------------------------------------------------------
                                   1214 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1215 ;------------------------------------------------------------
                                   1216 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_646'
                                   1217 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_647'
                                   1218 ;------------------------------------------------------------
                                   1219 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1220 ;	-----------------------------------------
                                   1221 ;	 function ak820_tapping_cancel
                                   1222 ;	-----------------------------------------
      0048CC                       1223 _ak820_tapping_cancel:
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0048CC 12 4A 98         [24] 1225 	lcall	_ak820_outline_0149
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0048CF 7F 00            [12] 1227 	mov	r7,#0x00
      0048D1                       1228 00103$:
      0048D1 BF 82 00         [24] 1229 	cjne	r7,#0x82,00122$
      0048D4                       1230 00122$:
      0048D4 50 16            [24] 1231 	jnc	00105$
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0048D6 12 4A 39         [24] 1233 	lcall	_ak820_outline_0018
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0048D9 74 02            [12] 1235 	mov	a,#0x02
      0048DB 5C               [12] 1236 	anl	a,r4
      0048DC FB               [12] 1237 	mov	r3,a
      0048DD 53 04 01         [24] 1238 	anl	ar4,#0x01
      0048E0 EC               [12] 1239 	mov	a,r4
      0048E1 2C               [12] 1240 	add	a,r4
      0048E2 42 03            [12] 1241 	orl	ar3,a
      0048E4 12 38 65         [24] 1242 	lcall	_ak820_outline_0131
      0048E7 EB               [12] 1243 	mov	a,r3
      0048E8 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0048E9 0F               [12] 1246 	inc	r7
      0048EA 80 E5            [24] 1247 	sjmp	00103$
      0048EC                       1248 00105$:
                                   1249 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0048EC 22               [24] 1250 	ret
                                   1251 ;------------------------------------------------------------
                                   1252 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1253 ;------------------------------------------------------------
                                   1254 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1255 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1256 ;code          Allocated with name '_ak820_oneshot_process_code_10000_648'
                                   1257 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_649'
                                   1258 ;i             Allocated with name '_ak820_oneshot_process_i_40000_663'
                                   1259 ;------------------------------------------------------------
                                   1260 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1261 ;	-----------------------------------------
                                   1262 ;	 function ak820_oneshot_process
                                   1263 ;	-----------------------------------------
      0048ED                       1264 _ak820_oneshot_process:
      0048ED 12 38 4B         [24] 1265 	lcall	_ak820_outline_0104
      0048F0 90 06 4C         [24] 1266 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      0048F3 12 38 50         [24] 1267 	lcall	_ak820_outline_0105
                                   1268 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      0048F6 90 06 4A         [24] 1269 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0048F9 E0               [24] 1270 	movx	a,@dptr
      0048FA FF               [12] 1271 	mov	r7,a
      0048FB BF FF 02         [24] 1272 	cjne	r7,#0xff,00248$
      0048FE 80 07            [24] 1273 	sjmp	00101$
      004900                       1274 00248$:
      004900 12 A2 60         [24] 1275 	lcall	_get_repeat_key_count
      004903 E5 82            [12] 1276 	mov	a, dpl
      004905 60 04            [24] 1277 	jz	00102$
      004907                       1278 00101$:
      004907 75 82 01         [24] 1279 	mov	dpl, #0x01
      00490A 22               [24] 1280 	ret
      00490B                       1281 00102$:
                                   1282 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      00490B 90 06 4C         [24] 1283 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      00490E E0               [24] 1284 	movx	a,@dptr
      00490F FD               [12] 1285 	mov	r5,a
      004910 A3               [24] 1286 	inc	dptr
      004911 E0               [24] 1287 	movx	a,@dptr
      004912 FB               [12] 1288 	mov	r3,a
      004913 BB 52 02         [24] 1289 	cjne	r3,#0x52,00250$
      004916 80 03            [24] 1290 	sjmp	00251$
      004918                       1291 00250$:
      004918 02 49 BD         [24] 1292 	ljmp	00116$
      00491B                       1293 00251$:
      00491B 8D 04            [24] 1294 	mov	ar4,r5
      00491D 53 04 E0         [24] 1295 	anl	ar4,#0xe0
      004920 BC A0 02         [24] 1296 	cjne	r4,#0xa0,00252$
      004923 80 03            [24] 1297 	sjmp	00253$
      004925                       1298 00252$:
      004925 02 49 BD         [24] 1299 	ljmp	00116$
      004928                       1300 00253$:
                                   1301 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004928 8D 04            [24] 1302 	mov	ar4,r5
      00492A 53 04 0F         [24] 1303 	anl	ar4,#0x0f
      00492D 90 06 4E         [24] 1304 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004930 EC               [12] 1305 	mov	a,r4
      004931 F0               [24] 1306 	movx	@dptr,a
                                   1307 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004932 ED               [12] 1308 	mov	a,r5
      004933 30 E4 08         [24] 1309 	jnb	acc.4,00105$
      004936 EC               [12] 1310 	mov	a,r4
      004937 C4               [12] 1311 	swap	a
      004938 54 F0            [12] 1312 	anl	a,#0xf0
      00493A 90 06 4E         [24] 1313 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      00493D F0               [24] 1314 	movx	@dptr,a
      00493E                       1315 00105$:
                                   1316 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      00493E 90 06 4B         [24] 1317 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004941 E0               [24] 1318 	movx	a,@dptr
      004942 60 2D            [24] 1319 	jz	00113$
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004944 12 4A 39         [24] 1321 	lcall	_ak820_outline_0018
      004947 43 04 08         [24] 1322 	orl	ar4,#0x08
      00494A 12 45 3B         [24] 1323 	lcall	_ak820_outline_0064
                                   1324 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      00494D 53 04 EF         [24] 1325 	anl	ar4,#0xef
      004950 12 45 3B         [24] 1326 	lcall	_ak820_outline_0064
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004953 90 0D 9C         [24] 1328 	mov	dptr,#_ak820_oneshot_target
      004956 E0               [24] 1329 	movx	a,@dptr
      004957 FC               [12] 1330 	mov	r4,a
      004958 BC FF 02         [24] 1331 	cjne	r4,#0xff,00256$
      00495B 80 09            [24] 1332 	sjmp	00107$
      00495D                       1333 00256$:
      00495D 12 4A 83         [24] 1334 	lcall	_ak820_outline_0074
      004960 43 04 10         [24] 1335 	orl	ar4,#0x10
      004963 12 45 3B         [24] 1336 	lcall	_ak820_outline_0064
      004966                       1337 00107$:
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004966 90 06 4E         [24] 1339 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004969 E0               [24] 1340 	movx	a,@dptr
      00496A F5 82            [12] 1341 	mov	dpl,a
      00496C 12 77 AD         [24] 1342 	lcall	_register_mods
      00496F 80 48            [24] 1343 	sjmp	00114$
      004971                       1344 00113$:
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004971 12 4A 39         [24] 1346 	lcall	_ak820_outline_0018
      004974 30 E3 42         [24] 1347 	jnb	acc.3,00114$
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004977 EC               [12] 1349 	mov	a,r4
      004978 20 E4 24         [24] 1350 	jb	acc.4,00109$
                                   1351 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      00497B 90 06 48         [24] 1352 	mov	dptr,#_ak820_oneshot_mods
      00497E E0               [24] 1353 	movx	a,@dptr
      00497F F4               [12] 1354 	cpl	a
      004980 FC               [12] 1355 	mov	r4,a
      004981 90 06 4E         [24] 1356 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004984 E0               [24] 1357 	movx	a,@dptr
      004985 FB               [12] 1358 	mov	r3,a
      004986 52 04            [12] 1359 	anl	ar4,a
      004988 8C 82            [24] 1360 	mov	dpl, r4
      00498A C0 06            [24] 1361 	push	ar6
      00498C C0 05            [24] 1362 	push	ar5
      00498E C0 03            [24] 1363 	push	ar3
      004990 12 7D F9         [24] 1364 	lcall	_add_owned_mods
      004993 D0 03            [24] 1365 	pop	ar3
      004995 D0 05            [24] 1366 	pop	ar5
      004997 D0 06            [24] 1367 	pop	ar6
                                   1368 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004999 90 06 48         [24] 1369 	mov	dptr,#_ak820_oneshot_mods
      00499C E0               [24] 1370 	movx	a,@dptr
      00499D 4B               [12] 1371 	orl	a,r3
      00499E F0               [24] 1372 	movx	@dptr,a
      00499F                       1373 00109$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      00499F 90 06 4E         [24] 1375 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      0049A2 E0               [24] 1376 	movx	a,@dptr
      0049A3 F5 82            [12] 1377 	mov	dpl,a
      0049A5 C0 06            [24] 1378 	push	ar6
      0049A7 C0 05            [24] 1379 	push	ar5
      0049A9 12 77 C1         [24] 1380 	lcall	_unregister_mods
      0049AC D0 05            [24] 1381 	pop	ar5
      0049AE D0 06            [24] 1382 	pop	ar6
                                   1383 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0049B0 12 4A 83         [24] 1384 	lcall	_ak820_outline_0074
      0049B3 53 04 E7         [24] 1385 	anl	ar4,#0xe7
      0049B6 12 45 3B         [24] 1386 	lcall	_ak820_outline_0064
      0049B9                       1387 00114$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      0049B9 75 82 00         [24] 1389 	mov	dpl, #0x00
      0049BC 22               [24] 1390 	ret
      0049BD                       1391 00116$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      0049BD 90 06 4B         [24] 1393 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0049C0 E0               [24] 1394 	movx	a,@dptr
      0049C1 60 5C            [24] 1395 	jz	00124$
      0049C3 90 06 4C         [24] 1396 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      0049C6 12 45 48         [24] 1397 	lcall	_ak820_outline_0093
      0049C9 C3               [12] 1398 	clr	c
      0049CA 74 01            [12] 1399 	mov	a,#0x01
      0049CC 9D               [12] 1400 	subb	a,r5
      0049CD E4               [12] 1401 	clr	a
      0049CE 9E               [12] 1402 	subb	a,r6
      0049CF 50 4E            [24] 1403 	jnc	00124$
                                   1404 ;	free result
                                   1405 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      0049D1 C3               [12] 1406 	clr	c
      0049D2 ED               [12] 1407 	mov	a,r5
      0049D3 94 E0            [12] 1408 	subb	a,#0xe0
      0049D5 EE               [12] 1409 	mov	a,r6
      0049D6 94 00            [12] 1410 	subb	a,#0x00
      0049D8 40 07            [24] 1411 	jc	00129$
      0049DA 74 E7            [12] 1412 	mov	a,#0xe7
      0049DC 9D               [12] 1413 	subb	a,r5
      0049DD E4               [12] 1414 	clr	a
      0049DE 9E               [12] 1415 	subb	a,r6
      0049DF 50 3E            [24] 1416 	jnc	00124$
                                   1417 ;	free result
      0049E1                       1418 00129$:
                                   1419 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      0049E1 74 AE            [12] 1420 	mov	a,#0x100 - 0x52
      0049E3 2E               [12] 1421 	add	a,r6
      0049E4 50 09            [24] 1422 	jnc	00165$
      0049E6 C3               [12] 1423 	clr	c
      0049E7 74 DF            [12] 1424 	mov	a,#0xdf
      0049E9 9D               [12] 1425 	subb	a,r5
      0049EA 74 52            [12] 1426 	mov	a,#0x52
      0049EC 9E               [12] 1427 	subb	a,r6
      0049ED 50 30            [24] 1428 	jnc	00124$
                                   1429 ;	free result
                                   1430 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      0049EF                       1431 00165$:
      0049EF 7E 00            [12] 1432 	mov	r6,#0x00
      0049F1                       1433 00131$:
      0049F1 BE 82 00         [24] 1434 	cjne	r6,#0x82,00265$
      0049F4                       1435 00265$:
      0049F4 50 12            [24] 1436 	jnc	00120$
                                   1437 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      0049F6 EE               [12] 1438 	mov	a,r6
      0049F7 12 4A 8A         [24] 1439 	lcall	_ak820_outline_0077
      0049FA 30 E3 08         [24] 1440 	jnb	acc.3,00132$
      0049FD 43 03 10         [24] 1441 	orl	ar3,#0x10
      004A00 12 38 55         [24] 1442 	lcall	_ak820_outline_0117
      004A03 EB               [12] 1443 	mov	a,r3
      004A04 F0               [24] 1444 	movx	@dptr,a
      004A05                       1445 00132$:
                                   1446 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004A05 0E               [12] 1447 	inc	r6
      004A06 80 E9            [24] 1448 	sjmp	00131$
      004A08                       1449 00120$:
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004A08 90 06 48         [24] 1451 	mov	dptr,#_ak820_oneshot_mods
      004A0B E0               [24] 1452 	movx	a,@dptr
      004A0C FE               [12] 1453 	mov	r6,a
      004A0D E0               [24] 1454 	movx	a,@dptr
      004A0E 60 0F            [24] 1455 	jz	00124$
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004A10 90 06 49         [24] 1457 	mov	dptr,#_ak820_oneshot_consumed
      004A13 EE               [12] 1458 	mov	a,r6
      004A14 F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004A15 90 0D 9C         [24] 1461 	mov	dptr,#_ak820_oneshot_target
      004A18 EF               [12] 1462 	mov	a,r7
      004A19 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004A1A 90 06 48         [24] 1465 	mov	dptr,#_ak820_oneshot_mods
      004A1D E4               [12] 1466 	clr	a
      004A1E F0               [24] 1467 	movx	@dptr,a
      004A1F                       1468 00124$:
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004A1F 75 82 01         [24] 1470 	mov	dpl, #0x01
                                   1471 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004A22 22               [24] 1472 	ret
                                   1473 	.area CSEG    (CODE)
                                   1474 	.area CONST   (CODE)
                                   1475 	.area XINIT   (CODE)
      00C12E                       1476 __xinit__pending:
      00C12E FF                    1477 	.db #0xff	; 255
      00C12F                       1478 __xinit__ak820_oneshot_target:
      00C12F FF                    1479 	.db #0xff	; 255
                                   1480 	.area CABS    (ABS,CODE)
                                   1481 
                                   1482 ; Experimental exact instruction outlining.
                                   1483 	.globl _ak820_outline_0004
                                   1484 	.globl _ak820_outline_0005
                                   1485 	.globl _ak820_outline_0009
                                   1486 	.globl _ak820_outline_0010
                                   1487 	.globl _ak820_outline_0011
                                   1488 	.globl _ak820_outline_0012
                                   1489 	.globl _ak820_outline_0013
                                   1490 	.globl _ak820_outline_0016
                                   1491 	.globl _ak820_outline_0018
                                   1492 	.globl _ak820_outline_0022
                                   1493 	.globl _ak820_outline_0029
                                   1494 	.globl _ak820_outline_0045
                                   1495 	.globl _ak820_outline_0050
                                   1496 	.globl _ak820_outline_0054
                                   1497 	.globl _ak820_outline_0055
                                   1498 	.globl _ak820_outline_0058
                                   1499 	.globl _ak820_outline_0061
                                   1500 	.globl _ak820_outline_0064
                                   1501 	.globl _ak820_outline_0074
                                   1502 	.globl _ak820_outline_0077
                                   1503 	.globl _ak820_outline_0093
                                   1504 	.globl _ak820_outline_0097
                                   1505 	.globl _ak820_outline_0100
                                   1506 	.globl _ak820_outline_0104
                                   1507 	.globl _ak820_outline_0105
                                   1508 	.globl _ak820_outline_0114
                                   1509 	.globl _ak820_outline_0117
                                   1510 	.globl _ak820_outline_0121
                                   1511 	.globl _ak820_outline_0131
                                   1512 	.globl _ak820_outline_0149
                                   1513 	.globl _ak820_outline_0152
                                   1514 	.globl _ak820_outline_0184
                                   1515 
                                   1516 	.area CSEG (CODE)
                                   1517 ; function ak820_outline_0010
      004A23                       1518 _ak820_outline_0010:
      004A23 2E               [12] 1519 	add	a,r6
      004A24 FC               [12] 1520 	mov	r4,a
      004A25 E4               [12] 1521 	clr	a
      004A26 3F               [12] 1522 	addc	a,r7
      004A27 FD               [12] 1523 	mov	r5,a
      004A28 8C 82            [24] 1524 	mov	dpl,r4
      004A2A 8D 83            [24] 1525 	mov	dph,r5
      004A2C E0               [24] 1526 	movx	a,@dptr
      004A2D 22               [24] 1527 	ret
                                   1528 
                                   1529 	.area CSEG (CODE)
                                   1530 ; function ak820_outline_0012
      004A2E                       1531 _ak820_outline_0012:
      004A2E 2E               [12] 1532 	add	a,r6
      004A2F FB               [12] 1533 	mov	r3,a
      004A30 E4               [12] 1534 	clr	a
      004A31 3F               [12] 1535 	addc	a,r7
      004A32 FC               [12] 1536 	mov	r4,a
      004A33 8B 82            [24] 1537 	mov	dpl,r3
      004A35 8C 83            [24] 1538 	mov	dph,r4
      004A37 E0               [24] 1539 	movx	a,@dptr
      004A38 22               [24] 1540 	ret
                                   1541 
                                   1542 	.area CSEG (CODE)
                                   1543 ; function ak820_outline_0018
      004A39                       1544 _ak820_outline_0018:
      004A39 EF               [12] 1545 	mov	a,r7
      004A3A 24 B4            [12] 1546 	add	a,#_source_state
      004A3C FD               [12] 1547 	mov	r5,a
      004A3D E4               [12] 1548 	clr	a
      004A3E 34 05            [12] 1549 	addc	a,#(_source_state>>8)
      004A40 FE               [12] 1550 	mov	r6,a
      004A41 8D 82            [24] 1551 	mov	dpl,r5
      004A43 8E 83            [24] 1552 	mov	dph,r6
      004A45 E0               [24] 1553 	movx	a,@dptr
      004A46 FC               [12] 1554 	mov	r4,a
      004A47 22               [24] 1555 	ret
                                   1556 
                                   1557 	.area CSEG (CODE)
                                   1558 ; function ak820_outline_0022
      004A48                       1559 _ak820_outline_0022:
      004A48 90 0D 8A         [24] 1560 	mov	dptr,#___memcpy_PARM_2
      004A4B EC               [12] 1561 	mov	a,r4
      004A4C F0               [24] 1562 	movx	@dptr,a
      004A4D ED               [12] 1563 	mov	a,r5
      004A4E A3               [24] 1564 	inc	dptr
      004A4F F0               [24] 1565 	movx	@dptr,a
      004A50 E4               [12] 1566 	clr	a
      004A51 A3               [24] 1567 	inc	dptr
      004A52 F0               [24] 1568 	movx	@dptr,a
      004A53 90 0D 8D         [24] 1569 	mov	dptr,#___memcpy_PARM_3
      004A56 74 02            [12] 1570 	mov	a,#0x02
      004A58 F0               [24] 1571 	movx	@dptr,a
      004A59 E4               [12] 1572 	clr	a
      004A5A A3               [24] 1573 	inc	dptr
      004A5B F0               [24] 1574 	movx	@dptr,a
      004A5C 90 06 3A         [24] 1575 	mov	dptr,#_ak820_tapping_source_PARM_1
      004A5F F5 F0            [12] 1576 	mov	b,a
      004A61 22               [24] 1577 	ret
                                   1578 
                                   1579 	.area CSEG (CODE)
                                   1580 ; function ak820_outline_0045
      004A62                       1581 _ak820_outline_0045:
      004A62 2E               [12] 1582 	add	a,r6
      004A63 FA               [12] 1583 	mov	r2,a
      004A64 E4               [12] 1584 	clr	a
      004A65 3F               [12] 1585 	addc	a,r7
      004A66 FB               [12] 1586 	mov	r3,a
      004A67 8A 82            [24] 1587 	mov	dpl,r2
      004A69 8B 83            [24] 1588 	mov	dph,r3
      004A6B E0               [24] 1589 	movx	a,@dptr
      004A6C 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0054
      004A6D                       1594 _ak820_outline_0054:
      004A6D 74 01            [12] 1595 	mov	a,#0x01
      004A6F F0               [24] 1596 	movx	@dptr,a
      004A70 8E 82            [24] 1597 	mov	dpl,r6
      004A72 8F 83            [24] 1598 	mov	dph,r7
      004A74 22               [24] 1599 	ret
                                   1600 
                                   1601 	.area CSEG (CODE)
                                   1602 ; function ak820_outline_0055
      004A75                       1603 _ak820_outline_0055:
      004A75 FC               [12] 1604 	mov	r4,a
      004A76 8B 82            [24] 1605 	mov	dpl,r3
      004A78 8C 83            [24] 1606 	mov	dph,r4
      004A7A E0               [24] 1607 	movx	a,@dptr
      004A7B FA               [12] 1608 	mov	r2,a
      004A7C 22               [24] 1609 	ret
                                   1610 
                                   1611 	.area CSEG (CODE)
                                   1612 ; function ak820_outline_0058
      004A7D                       1613 _ak820_outline_0058:
      004A7D EE               [12] 1614 	mov	a,r6
      004A7E F0               [24] 1615 	movx	@dptr,a
      004A7F EF               [12] 1616 	mov	a,r7
      004A80 A3               [24] 1617 	inc	dptr
      004A81 F0               [24] 1618 	movx	@dptr,a
      004A82 22               [24] 1619 	ret
                                   1620 
                                   1621 	.area CSEG (CODE)
                                   1622 ; function ak820_outline_0074
      004A83                       1623 _ak820_outline_0074:
      004A83 8D 82            [24] 1624 	mov	dpl,r5
      004A85 8E 83            [24] 1625 	mov	dph,r6
      004A87 E0               [24] 1626 	movx	a,@dptr
      004A88 FC               [12] 1627 	mov	r4,a
      004A89 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0077
      004A8A                       1632 _ak820_outline_0077:
      004A8A 24 B4            [12] 1633 	add	a,#_source_state
      004A8C FC               [12] 1634 	mov	r4,a
      004A8D E4               [12] 1635 	clr	a
      004A8E 34 05            [12] 1636 	addc	a,#(_source_state>>8)
      004A90 FD               [12] 1637 	mov	r5,a
      004A91 8C 82            [24] 1638 	mov	dpl,r4
      004A93 8D 83            [24] 1639 	mov	dph,r5
      004A95 E0               [24] 1640 	movx	a,@dptr
      004A96 FB               [12] 1641 	mov	r3,a
      004A97 22               [24] 1642 	ret
                                   1643 
                                   1644 	.area CSEG (CODE)
                                   1645 ; function ak820_outline_0149
      004A98                       1646 _ak820_outline_0149:
      004A98 90 0D 9B         [24] 1647 	mov	dptr,#_pending
      004A9B 74 FF            [12] 1648 	mov	a,#0xff
      004A9D F0               [24] 1649 	movx	@dptr,a
      004A9E 22               [24] 1650 	ret
