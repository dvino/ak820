                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         53 bits:
      000025                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000E                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000E                         68 	.ds 2
      000010                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      000010                         70 	.ds 2
      000012                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000012                         72 	.ds 2
      000014                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000014                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000533                        109 _page_data:
      000533                        110 	.ds 64
      000573                        111 _cached_page:
      000573                        112 	.ds 1
      000574                        113 _batch_depth:
      000574                        114 	.ds 1
      000575                        115 _first_failure_stage:
      000575                        116 	.ds 1
      000576                        117 _nvm_fail_stage_10000_20:
      000576                        118 	.ds 1
      000577                        119 _ak820_nvm_diagnostic_out_10000_23:
      000577                        120 	.ds 2
      000579                        121 _crc_byte_PARM_2:
      000579                        122 	.ds 1
      00057A                        123 _crc_byte_crc_10000_25:
      00057A                        124 	.ds 2
      00057C                        125 _page_crc_crc_10000_30:
      00057C                        126 	.ds 2
      00057E                        127 _write_page_address_10000_32:
      00057E                        128 	.ds 2
      000580                        129 _journal_header_valid_header_10000_39:
      000580                        130 	.ds 2
      000582                        131 _recover_journal_header_10000_46:
      000582                        132 	.ds 9
      00058B                        133 _ak820_nvm_flush_header_10000_62:
      00058B                        134 	.ds 9
      000594                        135 _ak820_nvm_flush_stage_10000_62:
      000594                        136 	.ds 1
      000595                        137 _load_page_page_10000_87:
      000595                        138 	.ds 1
      000596                        139 _read_offset_offset_10000_93:
      000596                        140 	.ds 2
      000598                        141 _eeprom_read_byte_addr_10000_97:
      000598                        142 	.ds 3
      00059B                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      00059B                        144 	.ds 3
      00059E                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      00059E                        146 	.ds 2
      0005A0                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005A0                        148 	.ds 2
      0005A2                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005A2                        150 	.ds 2
      0005A4                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005A4                        152 	.ds 3
      0005A7                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005A7                        154 	.ds 2
      0005A9                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005A9                        156 	.ds 2
      0005AB                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005AB                        158 	.ds 3
      0005AE                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005AE                        160 	.ds 2
      0005B0                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005B0                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003D82                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003D82 E5 82            [12]  215 	mov	a,dpl
      003D84 90 05 76         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003D87 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003D88 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003D8B 90 05 76         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003D8E E0               [24]  221 	movx	a,@dptr
      003D8F 90 05 75         [24]  222 	mov	dptr,#_first_failure_stage
      003D92 F0               [24]  223 	movx	@dptr,a
      003D93                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003D93 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003D95 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003D96                        239 _ak820_nvm_diagnostic:
      003D96 12 38 4B         [24]  240 	lcall	_ak820_outline_0104
      003D99 90 05 77         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003D9C 12 38 50         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003D9F 90 05 77         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003DA2 12 38 01         [24]  245 	lcall	_ak820_outline_0050
      003DA5 A2 09            [12]  246 	mov	c,_storage_failed
      003DA7 E4               [12]  247 	clr	a
      003DA8 33               [12]  248 	rlc	a
      003DA9 12 45 5A         [24]  249 	lcall	_ak820_outline_0114
      003DAC 12 45 35         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003DAF A3               [24]  252 	inc	dptr
      003DB0 A2 07            [12]  253 	mov	c,_page_valid
      003DB2 E4               [12]  254 	clr	a
      003DB3 33               [12]  255 	rlc	a
      003DB4 12 45 09         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003DB7 A2 08            [12]  258 	mov	c,_page_dirty
      003DB9 E4               [12]  259 	clr	a
      003DBA 33               [12]  260 	rlc	a
      003DBB F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003DBC 74 03            [12]  263 	mov	a,#0x03
      003DBE 12 45 85         [24]  264 	lcall	_ak820_outline_0155
      003DC1 90 05 74         [24]  265 	mov	dptr,#_batch_depth
      003DC4 E0               [24]  266 	movx	a,@dptr
      003DC5 12 38 55         [24]  267 	lcall	_ak820_outline_0117
      003DC8 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003DC9 74 04            [12]  270 	mov	a,#0x04
      003DCB 12 45 85         [24]  271 	lcall	_ak820_outline_0155
      003DCE 90 05 73         [24]  272 	mov	dptr,#_cached_page
      003DD1 E0               [24]  273 	movx	a,@dptr
      003DD2 12 38 55         [24]  274 	lcall	_ak820_outline_0117
      003DD5 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003DD6 12 44 FF         [24]  277 	lcall	_ak820_outline_0011
      003DD9 E4               [12]  278 	clr	a
      003DDA F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003DDB 74 06            [12]  281 	mov	a,#0x06
      003DDD 12 45 6A         [24]  282 	lcall	_ak820_outline_0133
      003DE0 90 05 75         [24]  283 	mov	dptr,#_first_failure_stage
      003DE3 E0               [24]  284 	movx	a,@dptr
      003DE4 12 45 5A         [24]  285 	lcall	_ak820_outline_0114
      003DE7 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003DE8 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003DE9                        300 _crc_byte:
      003DE9 12 38 4B         [24]  301 	lcall	_ak820_outline_0104
      003DEC 90 05 7A         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003DEF 12 38 50         [24]  303 	lcall	_ak820_outline_0105
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003DF2 90 05 79         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003DF5 E0               [24]  306 	movx	a,@dptr
      003DF6 FF               [12]  307 	mov	r7,a
      003DF7 7E 00            [12]  308 	mov	r6,#0x00
      003DF9 90 05 7A         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003DFC E0               [24]  310 	movx	a,@dptr
      003DFD 6E               [12]  311 	xrl	a,r6
      003DFE F0               [24]  312 	movx	@dptr,a
      003DFF A3               [24]  313 	inc	dptr
      003E00 E0               [24]  314 	movx	a,@dptr
      003E01 6F               [12]  315 	xrl	a,r7
      003E02 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E03 7F 00            [12]  318 	mov	r7,#0x00
      003E05                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E05 90 05 7A         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E08 12 45 48         [24]  322 	lcall	_ak820_outline_0093
      003E0B 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E0E ED               [12]  324 	mov	a,r5
      003E0F 2D               [12]  325 	add	a,r5
      003E10 FB               [12]  326 	mov	r3,a
      003E11 EE               [12]  327 	mov	a,r6
      003E12 33               [12]  328 	rlc	a
      003E13 FC               [12]  329 	mov	r4,a
      003E14 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E17 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E1A 80 06            [24]  332 	sjmp	00107$
      003E1C                        333 00106$:
      003E1C ED               [12]  334 	mov	a,r5
      003E1D 2D               [12]  335 	add	a,r5
      003E1E FB               [12]  336 	mov	r3,a
      003E1F EE               [12]  337 	mov	a,r6
      003E20 33               [12]  338 	rlc	a
      003E21 FC               [12]  339 	mov	r4,a
      003E22                        340 00107$:
      003E22 90 05 7A         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E25 12 38 2C         [24]  342 	lcall	_ak820_outline_0076
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E28 0F               [12]  344 	inc	r7
      003E29 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003E2C 12 33 FC         [24]  347 	lcall	_ak820_outline_0121
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003E2F 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003E30                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003E30 90 05 7C         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003E33 74 FF            [12]  363 	mov	a,#0xff
      003E35 F0               [24]  364 	movx	@dptr,a
      003E36 A3               [24]  365 	inc	dptr
      003E37 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003E38 7F 00            [12]  368 	mov	r7,#0x00
      003E3A                        369 00102$:
      003E3A 90 05 7C         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003E3D 12 45 48         [24]  371 	lcall	_ak820_outline_0093
      003E40 12 45 4E         [24]  372 	lcall	_ak820_outline_0102
      003E43 90 05 79         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003E46 F0               [24]  374 	movx	@dptr,a
      003E47 12 38 65         [24]  375 	lcall	_ak820_outline_0131
      003E4A C0 07            [24]  376 	push	ar7
      003E4C 12 3D E9         [24]  377 	lcall	_crc_byte
      003E4F AD 82            [24]  378 	mov	r5, dpl
      003E51 AE 83            [24]  379 	mov	r6, dph
      003E53 D0 07            [24]  380 	pop	ar7
      003E55 90 05 7C         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003E58 12 45 8B         [24]  382 	lcall	_ak820_outline_0156
      003E5B 0F               [12]  383 	inc	r7
      003E5C BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003E5F 12 38 65         [24]  386 	lcall	_ak820_outline_0131
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003E62 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003E63                        399 _write_page:
      003E63 12 38 4B         [24]  400 	lcall	_ak820_outline_0104
      003E66 90 05 7E         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003E69 12 38 50         [24]  402 	lcall	_ak820_outline_0105
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003E6C 90 05 7E         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003E6F 12 37 A1         [24]  405 	lcall	_ak820_outline_0004
      003E72 C0 07            [24]  406 	push	ar7
      003E74 C0 06            [24]  407 	push	ar6
      003E76 12 39 C1         [24]  408 	lcall	_ak820_flash_erase
      003E79 E5 82            [12]  409 	mov	a, dpl
      003E7B D0 06            [24]  410 	pop	ar6
      003E7D D0 07            [24]  411 	pop	ar7
      003E7F 70 03            [24]  412 	jnz	00102$
      003E81 F5 82            [12]  413 	mov	dpl,a
      003E83 22               [24]  414 	ret
      003E84                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003E84 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003E87 74 33            [12]  418 	mov	a,#_page_data
      003E89 F0               [24]  419 	movx	@dptr,a
      003E8A 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003E8C A3               [24]  421 	inc	dptr
      003E8D 12 45 35         [24]  422 	lcall	_ak820_outline_0061
      003E90 12 3A D5         [24]  423 	lcall	_ak820_flash_program_page
      003E93 E5 82            [12]  424 	mov	a, dpl
      003E95 70 03            [24]  425 	jnz	00120$
      003E97 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E99 22               [24]  428 	ret
      003E9A                        429 00120$:
      003E9A 7F 00            [12]  430 	mov	r7,#0x00
      003E9C                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003E9C 8F 05            [24]  433 	mov	ar5,r7
      003E9E 7E 00            [12]  434 	mov	r6,#0x00
      003EA0 90 05 7E         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003EA3 12 38 5A         [24]  436 	lcall	_ak820_outline_0120
      003EA6 ED               [12]  437 	mov	a,r5
      003EA7 2B               [12]  438 	add	a, r3
      003EA8 FB               [12]  439 	mov	r3,a
      003EA9 EE               [12]  440 	mov	a,r6
      003EAA 3C               [12]  441 	addc	a, r4
      003EAB FC               [12]  442 	mov	r4,a
      003EAC 12 33 FC         [24]  443 	lcall	_ak820_outline_0121
      003EAF 12 38 B4         [24]  444 	lcall	_ak820_flash_read
      003EB2 AE 82            [24]  445 	mov	r6, dpl
      003EB4 12 45 4E         [24]  446 	lcall	_ak820_outline_0102
      003EB7 FD               [12]  447 	mov	r5,a
      003EB8 EE               [12]  448 	mov	a,r6
      003EB9 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003EBC 80 04            [24]  450 	sjmp	00109$
      003EBE                        451 00149$:
      003EBE 75 82 00         [24]  452 	mov	dpl, #0x00
      003EC1 22               [24]  453 	ret
      003EC2                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EC2 0F               [12]  456 	inc	r7
      003EC3 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003EC6 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003EC9 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003ECA                        472 _journal_header_valid:
      003ECA 12 38 4B         [24]  473 	lcall	_ak820_outline_0104
      003ECD 90 05 80         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003ED0 12 38 50         [24]  475 	lcall	_ak820_outline_0105
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003ED3 90 05 80         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003ED6 12 37 A1         [24]  478 	lcall	_ak820_outline_0004
      003ED9 E0               [24]  479 	movx	a,@dptr
      003EDA FD               [12]  480 	mov	r5,a
      003EDB BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003EDE 80 04            [24]  482 	sjmp	00116$
      003EE0                        483 00138$:
      003EE0 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003EE3 22               [24]  486 	ret
      003EE4                        487 00116$:
      003EE4 7D 01            [12]  488 	mov	r5,#0x01
      003EE6                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003EE6 ED               [12]  491 	mov	a,r5
      003EE7 12 37 E8         [24]  492 	lcall	_ak820_outline_0016
      003EEA FC               [12]  493 	mov	r4,a
      003EEB 8D 02            [24]  494 	mov	ar2,r5
      003EED 7B 00            [12]  495 	mov	r3,#0x00
      003EEF 74 04            [12]  496 	mov	a,#0x04
      003EF1 2A               [12]  497 	add	a, r2
      003EF2 FA               [12]  498 	mov	r2,a
      003EF3 E4               [12]  499 	clr	a
      003EF4 3B               [12]  500 	addc	a, r3
      003EF5 FB               [12]  501 	mov	r3,a
      003EF6 EA               [12]  502 	mov	a,r2
      003EF7 2E               [12]  503 	add	a, r6
      003EF8 F5 82            [12]  504 	mov	dpl,a
      003EFA EB               [12]  505 	mov	a,r3
      003EFB 3F               [12]  506 	addc	a, r7
      003EFC F5 83            [12]  507 	mov	dph,a
      003EFE E0               [24]  508 	movx	a,@dptr
      003EFF 62 04            [12]  509 	xrl	ar4,a
      003F01 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003F04 80 04            [24]  511 	sjmp	00107$
      003F06                        512 00139$:
      003F06 75 82 00         [24]  513 	mov	dpl, #0x00
      003F09 22               [24]  514 	ret
      003F0A                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F0A 0D               [12]  517 	inc	r5
      003F0B BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F0E 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F11 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003F12                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F12 7F 00            [12]  537 	mov	r7,#0x00
      003F14                        538 00115$:
      003F14 EF               [12]  539 	mov	a,r7
      003F15 24 82            [12]  540 	add	a, #_recover_journal_header_10000_46
      003F17 FD               [12]  541 	mov	r5,a
      003F18 E4               [12]  542 	clr	a
      003F19 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F1B FE               [12]  544 	mov	r6,a
      003F1C 8F 04            [24]  545 	mov	ar4,r7
      003F1E 7B 00            [12]  546 	mov	r3,#0x00
      003F20 74 40            [12]  547 	mov	a,#0x40
      003F22 2C               [12]  548 	add	a, r4
      003F23 FC               [12]  549 	mov	r4,a
      003F24 74 EF            [12]  550 	mov	a,#0xef
      003F26 3B               [12]  551 	addc	a, r3
      003F27 FB               [12]  552 	mov	r3,a
      003F28 12 45 96         [24]  553 	lcall	_ak820_outline_0179
      003F2B 12 38 B4         [24]  554 	lcall	_ak820_flash_read
      003F2E AC 82            [24]  555 	mov	r4, dpl
      003F30 12 45 3B         [24]  556 	lcall	_ak820_outline_0064
      003F33 0F               [12]  557 	inc	r7
      003F34 BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003F37 90 05 82         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      003F3A 12 3E CA         [24]  561 	lcall	_journal_header_valid
      003F3D E5 82            [12]  562 	mov	a, dpl
      003F3F 70 01            [24]  563 	jnz	00103$
      003F41 22               [24]  564 	ret
      003F42                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003F42 90 05 83         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003F45 E0               [24]  568 	movx	a,@dptr
      003F46 FF               [12]  569 	mov	r7,a
      003F47 7E 00            [12]  570 	mov	r6,#0x00
      003F49 90 05 84         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003F4C E0               [24]  572 	movx	a,@dptr
      003F4D FC               [12]  573 	mov	r4,a
      003F4E E4               [12]  574 	clr	a
      003F4F 42 07            [12]  575 	orl	ar7,a
      003F51 EC               [12]  576 	mov	a,r4
      003F52 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003F54 90 05 85         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003F57 E0               [24]  580 	movx	a,@dptr
      003F58 FD               [12]  581 	mov	r5,a
      003F59 7C 00            [12]  582 	mov	r4,#0x00
      003F5B 90 05 86         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003F5E E0               [24]  584 	movx	a,@dptr
      003F5F FA               [12]  585 	mov	r2,a
      003F60 E4               [12]  586 	clr	a
      003F61 12 45 70         [24]  587 	lcall	_ak820_outline_0138
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003F64 C3               [12]  589 	clr	c
      003F65 EF               [12]  590 	mov	a,r7
      003F66 94 A0            [12]  591 	subb	a,#0xa0
      003F68 EE               [12]  592 	mov	a,r6
      003F69 94 00            [12]  593 	subb	a,#0x00
      003F6B 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003F6D 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003F70 02 3D 82         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003F73                        600 00134$:
      003F73 7B 00            [12]  601 	mov	r3,#0x00
      003F75                        602 00117$:
      003F75 C0 05            [24]  603 	push	ar5
      003F77 C0 04            [24]  604 	push	ar4
      003F79 EB               [12]  605 	mov	a,r3
      003F7A 24 33            [12]  606 	add	a, #_page_data
      003F7C F9               [12]  607 	mov	r1,a
      003F7D E4               [12]  608 	clr	a
      003F7E 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      003F80 FA               [12]  610 	mov	r2,a
      003F81 8B 00            [24]  611 	mov	ar0,r3
      003F83 7D 00            [12]  612 	mov	r5,#0x00
      003F85 74 EF            [12]  613 	mov	a,#0xef
      003F87 2D               [12]  614 	add	a, r5
      003F88 FD               [12]  615 	mov	r5,a
      003F89 88 82            [24]  616 	mov	dpl, r0
      003F8B 8D 83            [24]  617 	mov	dph, r5
      003F8D 12 38 B4         [24]  618 	lcall	_ak820_flash_read
      003F90 AD 82            [24]  619 	mov	r5, dpl
      003F92 12 45 91         [24]  620 	lcall	_ak820_outline_0178
      003F95 ED               [12]  621 	mov	a,r5
      003F96 F0               [24]  622 	movx	@dptr,a
      003F97 0B               [12]  623 	inc	r3
      003F98 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      003F9B 80 06            [24]  625 	sjmp	00191$
      003F9D                        626 00190$:
      003F9D D0 04            [24]  627 	pop	ar4
      003F9F D0 05            [24]  628 	pop	ar5
      003FA1 80 D2            [24]  629 	sjmp	00117$
      003FA3                        630 00191$:
      003FA3 D0 04            [24]  631 	pop	ar4
      003FA5 D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003FA7 C0 07            [24]  634 	push	ar7
      003FA9 C0 06            [24]  635 	push	ar6
      003FAB C0 05            [24]  636 	push	ar5
      003FAD C0 04            [24]  637 	push	ar4
      003FAF 12 3E 30         [24]  638 	lcall	_page_crc
      003FB2 AA 82            [24]  639 	mov	r2, dpl
      003FB4 AB 83            [24]  640 	mov	r3, dph
      003FB6 D0 04            [24]  641 	pop	ar4
      003FB8 D0 05            [24]  642 	pop	ar5
      003FBA D0 06            [24]  643 	pop	ar6
      003FBC D0 07            [24]  644 	pop	ar7
      003FBE EA               [12]  645 	mov	a,r2
      003FBF B5 05 06         [24]  646 	cjne	a,ar5,00192$
      003FC2 EB               [12]  647 	mov	a,r3
      003FC3 B5 04 02         [24]  648 	cjne	a,ar4,00192$
      003FC6 80 06            [24]  649 	sjmp	00113$
      003FC8                        650 00192$:
      003FC8 75 82 02         [24]  651 	mov	dpl, #0x02
      003FCB 02 3D 82         [24]  652 	ljmp	_nvm_fail
      003FCE                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003FCE EE               [12]  655 	mov	a,r6
      003FCF 54 03            [12]  656 	anl	a,#0x03
      003FD1 A2 E0            [12]  657 	mov	c,acc.0
      003FD3 CF               [12]  658 	xch	a,r7
      003FD4 13               [12]  659 	rrc	a
      003FD5 CF               [12]  660 	xch	a,r7
      003FD6 13               [12]  661 	rrc	a
      003FD7 A2 E0            [12]  662 	mov	c,acc.0
      003FD9 CF               [12]  663 	xch	a,r7
      003FDA 13               [12]  664 	rrc	a
      003FDB CF               [12]  665 	xch	a,r7
      003FDC 13               [12]  666 	rrc	a
      003FDD CF               [12]  667 	xch	a,r7
      003FDE 24 C7            [12]  668 	add	a,#0xc7
      003FE0 FE               [12]  669 	mov	r6,a
      003FE1 12 45 80         [24]  670 	lcall	_ak820_outline_0152
      003FE4 12 3E 63         [24]  671 	lcall	_write_page
      003FE7 E5 82            [12]  672 	mov	a, dpl
      003FE9 70 06            [24]  673 	jnz	00110$
      003FEB 75 82 03         [24]  674 	mov	dpl, #0x03
      003FEE 02 3D 82         [24]  675 	ljmp	_nvm_fail
      003FF1                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003FF1 90 EF 40         [24]  678 	mov	dptr,#0xef40
      003FF4 12 39 C1         [24]  679 	lcall	_ak820_flash_erase
      003FF7 E5 82            [12]  680 	mov	a, dpl
      003FF9 70 06            [24]  681 	jnz	00119$
      003FFB 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003FFE 02 3D 82         [24]  684 	ljmp	_nvm_fail
      004001                        685 00119$:
      004001 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      004002                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      004002 C2 09            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004004 90 05 75         [24]  699 	mov	dptr,#_first_failure_stage
      004007 E4               [12]  700 	clr	a
      004008 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      004009 C2 08            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      00400B C2 07            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00400D 90 05 74         [24]  708 	mov	dptr,#_batch_depth
      004010 E4               [12]  709 	clr	a
      004011 F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004012 12 3F 12         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004015 02 2A B7         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      004018                        723 _ak820_nvm_ok:
      004018 A2 09            [12]  724 	mov	c,_storage_failed
      00401A B3               [12]  725 	cpl	c
      00401B 92 0A            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      00401D 12 38 81         [24]  727 	lcall	_ak820_outline_0166
      004020 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      004021                        736 _ak820_nvm_schema_fault:
      004021 75 82 10         [24]  737 	mov	dpl, #0x10
      004024 02 3D 82         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      004027                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004027 30 08 03         [24]  753 	jnb	_page_dirty,00101$
      00402A 30 09 01         [24]  754 	jnb	_storage_failed,00102$
      00402D                        755 00101$:
      00402D 22               [24]  756 	ret
      00402E                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      00402E 12 3E 30         [24]  759 	lcall	_page_crc
      004031 12 45 65         [24]  760 	lcall	_ak820_outline_0130
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      004034 90 05 8B         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004037 74 A5            [12]  763 	mov	a,#0xa5
      004039 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      00403A 90 05 73         [24]  766 	mov	dptr,#_cached_page
      00403D E0               [24]  767 	movx	a,@dptr
      00403E 90 05 8C         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      004041 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      004042 90 05 8D         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004045 E4               [12]  772 	clr	a
      004046 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      004047 8E 05            [24]  775 	mov	ar5,r6
      004049 90 05 8E         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      00404C ED               [12]  777 	mov	a,r5
      00404D F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      00404E 8F 06            [24]  780 	mov	ar6,r7
      004050 90 05 8F         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      004053 EE               [12]  782 	mov	a,r6
      004054 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      004055 7F 01            [12]  785 	mov	r7,#0x01
      004057                        786 00128$:
      004057 8F 06            [24]  787 	mov	ar6,r7
      004059 EE               [12]  788 	mov	a,r6
      00405A 24 04            [12]  789 	add	a,#0x04
      00405C FE               [12]  790 	mov	r6,a
      00405D 33               [12]  791 	rlc	a
      00405E 95 E0            [12]  792 	subb	a,acc
      004060 FD               [12]  793 	mov	r5,a
      004061 EE               [12]  794 	mov	a,r6
      004062 24 8B            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      004064 FE               [12]  796 	mov	r6,a
      004065 ED               [12]  797 	mov	a,r5
      004066 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      004068 FD               [12]  799 	mov	r5,a
      004069 12 45 18         [24]  800 	lcall	_ak820_outline_0039
      00406C FC               [12]  801 	mov	r4,a
      00406D 63 04 FF         [24]  802 	xrl	ar4,#0xff
      004070 8E 82            [24]  803 	mov	dpl,r6
      004072 8D 83            [24]  804 	mov	dph,r5
      004074 EC               [12]  805 	mov	a,r4
      004075 F0               [24]  806 	movx	@dptr,a
      004076 0F               [12]  807 	inc	r7
      004077 BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      00407A 90 05 94         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00407D 74 05            [12]  811 	mov	a,#0x05
      00407F F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004080 90 EF 40         [24]  814 	mov	dptr,#0xef40
      004083 12 39 C1         [24]  815 	lcall	_ak820_flash_erase
      004086 E5 82            [12]  816 	mov	a, dpl
      004088 70 03            [24]  817 	jnz	00269$
      00408A 02 41 71         [24]  818 	ljmp	00127$
      00408D                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      00408D 90 05 94         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004090 74 06            [12]  822 	mov	a,#0x06
      004092 F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004093 7F 00            [12]  825 	mov	r7,#0x00
      004095                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004095 12 45 24         [24]  828 	lcall	_ak820_outline_0051
      004098 12 38 B4         [24]  829 	lcall	_ak820_flash_read
      00409B E5 82            [12]  830 	mov	a, dpl
      00409D 60 03            [24]  831 	jz	00270$
      00409F 02 41 71         [24]  832 	ljmp	00127$
      0040A2                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0040A2 0F               [12]  835 	inc	r7
      0040A3 BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0040A6 90 05 94         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040A9 74 07            [12]  839 	mov	a,#0x07
      0040AB F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0040AC 90 EF 00         [24]  842 	mov	dptr,#0xef00
      0040AF 12 3E 63         [24]  843 	lcall	_write_page
      0040B2 E5 82            [12]  844 	mov	a, dpl
      0040B4 70 03            [24]  845 	jnz	00273$
      0040B6 02 41 71         [24]  846 	ljmp	00127$
      0040B9                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      0040B9 90 05 94         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040BC 74 08            [12]  850 	mov	a,#0x08
      0040BE F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0040BF 7F 01            [12]  853 	mov	r7,#0x01
      0040C1                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      0040C1 12 45 18         [24]  856 	lcall	_ak820_outline_0039
      0040C4 FE               [12]  857 	mov	r6,a
      0040C5 60 23            [24]  858 	jz	00133$
      0040C7 8F 05            [24]  859 	mov	ar5,r7
      0040C9 7C 00            [12]  860 	mov	r4,#0x00
      0040CB 74 40            [12]  861 	mov	a,#0x40
      0040CD 2D               [12]  862 	add	a, r5
      0040CE FD               [12]  863 	mov	r5,a
      0040CF 74 EF            [12]  864 	mov	a,#0xef
      0040D1 3C               [12]  865 	addc	a, r4
      0040D2 FC               [12]  866 	mov	r4,a
      0040D3 90 04 F2         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      0040D6 EE               [12]  868 	mov	a,r6
      0040D7 F0               [24]  869 	movx	@dptr,a
      0040D8 8D 82            [24]  870 	mov	dpl, r5
      0040DA 8C 83            [24]  871 	mov	dph, r4
      0040DC C0 07            [24]  872 	push	ar7
      0040DE 12 3A 21         [24]  873 	lcall	_ak820_flash_program
      0040E1 E5 82            [12]  874 	mov	a, dpl
      0040E3 D0 07            [24]  875 	pop	ar7
      0040E5 70 03            [24]  876 	jnz	00275$
      0040E7 02 41 71         [24]  877 	ljmp	00127$
      0040EA                        878 00275$:
      0040EA                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0040EA 0F               [12]  881 	inc	r7
      0040EB BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      0040EE 90 05 94         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040F1 74 09            [12]  885 	mov	a,#0x09
      0040F3 F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      0040F4 7F 01            [12]  888 	mov	r7,#0x01
      0040F6                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      0040F6 12 45 24         [24]  891 	lcall	_ak820_outline_0051
      0040F9 12 38 B4         [24]  892 	lcall	_ak820_flash_read
      0040FC AE 82            [24]  893 	mov	r6, dpl
      0040FE 12 45 18         [24]  894 	lcall	_ak820_outline_0039
      004101 FD               [12]  895 	mov	r5,a
      004102 EE               [12]  896 	mov	a,r6
      004103 B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004106 0F               [12]  899 	inc	r7
      004107 BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      00410A 90 05 94         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00410D 74 0A            [12]  903 	mov	a,#0x0a
      00410F F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004110 90 05 8B         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004113 E0               [24]  907 	movx	a,@dptr
      004114 90 04 F2         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      004117 F0               [24]  909 	movx	@dptr,a
      004118 90 EF 40         [24]  910 	mov	dptr,#0xef40
      00411B 12 3A 21         [24]  911 	lcall	_ak820_flash_program
      00411E E5 82            [12]  912 	mov	a, dpl
      004120 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004122 90 05 94         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004125 74 0B            [12]  916 	mov	a,#0x0b
      004127 F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004128 90 EF 40         [24]  919 	mov	dptr,#0xef40
      00412B 12 38 B4         [24]  920 	lcall	_ak820_flash_read
      00412E AF 82            [24]  921 	mov	r7, dpl
      004130 90 05 8B         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004133 E0               [24]  923 	movx	a,@dptr
      004134 FE               [12]  924 	mov	r6,a
      004135 EF               [12]  925 	mov	a,r7
      004136 B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004139 90 05 94         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00413C 74 0C            [12]  929 	mov	a,#0x0c
      00413E F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      00413F 90 05 73         [24]  932 	mov	dptr,#_cached_page
      004142 E0               [24]  933 	movx	a,@dptr
      004143 FE               [12]  934 	mov	r6,a
      004144 E4               [12]  935 	clr	a
      004145 C3               [12]  936 	clr	c
      004146 CE               [12]  937 	xch	a,r6
      004147 13               [12]  938 	rrc	a
      004148 CE               [12]  939 	xch	a,r6
      004149 13               [12]  940 	rrc	a
      00414A A2 E0            [12]  941 	mov	c,acc.0
      00414C CE               [12]  942 	xch	a,r6
      00414D 13               [12]  943 	rrc	a
      00414E CE               [12]  944 	xch	a,r6
      00414F 13               [12]  945 	rrc	a
      004150 CE               [12]  946 	xch	a,r6
      004151 24 C7            [12]  947 	add	a,#0xc7
      004153 FF               [12]  948 	mov	r7,a
      004154 12 45 5A         [24]  949 	lcall	_ak820_outline_0114
      004157 12 3E 63         [24]  950 	lcall	_write_page
      00415A E5 82            [12]  951 	mov	a, dpl
      00415C 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      00415E 90 05 94         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004161 74 0D            [12]  955 	mov	a,#0x0d
      004163 F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004164 90 EF 40         [24]  958 	mov	dptr,#0xef40
      004167 12 39 C1         [24]  959 	lcall	_ak820_flash_erase
      00416A E5 82            [12]  960 	mov	a, dpl
      00416C 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      00416E C2 08            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      004170 22               [24]  967 	ret
      004171                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      004171 90 05 94         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004174 E0               [24]  971 	movx	a,@dptr
      004175 F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      004177 02 3D 82         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      00417A                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      00417A 90 05 74         [24]  984 	mov	dptr,#_batch_depth
      00417D E0               [24]  985 	movx	a,@dptr
      00417E FF               [12]  986 	mov	r7,a
      00417F BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      004182 75 82 0F         [24]  988 	mov	dpl, #0x0f
      004185 02 3D 82         [24]  989 	ljmp	_nvm_fail
      004188                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004188 90 05 74         [24]  992 	mov	dptr,#_batch_depth
      00418B EF               [12]  993 	mov	a,r7
      00418C 04               [12]  994 	inc	a
      00418D F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      00418E 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      00418F                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      00418F 90 05 74         [24] 1007 	mov	dptr,#_batch_depth
      004192 E0               [24] 1008 	movx	a,@dptr
      004193 FF               [12] 1009 	mov	r7,a
      004194 E0               [24] 1010 	movx	a,@dptr
      004195 60 06            [24] 1011 	jz	00102$
      004197 EF               [12] 1012 	mov	a,r7
      004198 14               [12] 1013 	dec	a
      004199 90 05 74         [24] 1014 	mov	dptr,#_batch_depth
      00419C F0               [24] 1015 	movx	@dptr,a
      00419D                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      00419D 90 05 74         [24] 1018 	mov	dptr,#_batch_depth
      0041A0 E0               [24] 1019 	movx	a,@dptr
      0041A1 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0041A3 02 40 27         [24] 1022 	ljmp	_ak820_nvm_flush
      0041A6                       1023 00105$:
      0041A6 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      0041A7                       1035 _load_page:
      0041A7 E5 82            [12] 1036 	mov	a,dpl
      0041A9 90 05 95         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      0041AC F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0041AD 30 07 17         [24] 1040 	jnb	_page_valid,00102$
      0041B0 90 05 73         [24] 1041 	mov	dptr,#_cached_page
      0041B3 E0               [24] 1042 	movx	a,@dptr
      0041B4 FF               [12] 1043 	mov	r7,a
      0041B5 90 05 95         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      0041B8 E0               [24] 1045 	movx	a,@dptr
      0041B9 FE               [12] 1046 	mov	r6,a
      0041BA EF               [12] 1047 	mov	a,r7
      0041BB B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      0041BE A2 09            [12] 1049 	mov	c,_storage_failed
      0041C0 B3               [12] 1050 	cpl	c
      0041C1 92 0B            [24] 1051 	mov  _load_page_sloc0_1_0,c
      0041C3 12 38 81         [24] 1052 	lcall	_ak820_outline_0166
      0041C6 22               [24] 1053 	ret
      0041C7                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      0041C7 12 40 27         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      0041CA 30 09 04         [24] 1058 	jnb	_storage_failed,00119$
      0041CD 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041D0 22               [24] 1061 	ret
      0041D1                       1062 00119$:
      0041D1 7F 00            [12] 1063 	mov	r7,#0x00
      0041D3                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      0041D3 EF               [12] 1066 	mov	a,r7
      0041D4 24 33            [12] 1067 	add	a, #_page_data
      0041D6 FD               [12] 1068 	mov	r5,a
      0041D7 E4               [12] 1069 	clr	a
      0041D8 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      0041DA FE               [12] 1071 	mov	r6,a
      0041DB 90 05 95         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      0041DE E0               [24] 1073 	movx	a,@dptr
      0041DF FC               [12] 1074 	mov	r4,a
      0041E0 FA               [12] 1075 	mov	r2,a
      0041E1 E4               [12] 1076 	clr	a
      0041E2 C3               [12] 1077 	clr	c
      0041E3 CA               [12] 1078 	xch	a,r2
      0041E4 13               [12] 1079 	rrc	a
      0041E5 CA               [12] 1080 	xch	a,r2
      0041E6 13               [12] 1081 	rrc	a
      0041E7 A2 E0            [12] 1082 	mov	c,acc.0
      0041E9 CA               [12] 1083 	xch	a,r2
      0041EA 13               [12] 1084 	rrc	a
      0041EB CA               [12] 1085 	xch	a,r2
      0041EC 13               [12] 1086 	rrc	a
      0041ED CA               [12] 1087 	xch	a,r2
      0041EE 24 C7            [12] 1088 	add	a,#0xc7
      0041F0 FB               [12] 1089 	mov	r3,a
      0041F1 8F 01            [24] 1090 	mov	ar1,r7
      0041F3 89 00            [24] 1091 	mov	ar0,r1
      0041F5 79 00            [12] 1092 	mov	r1,#0x00
      0041F7 E8               [12] 1093 	mov	a,r0
      0041F8 2A               [12] 1094 	add	a, r2
      0041F9 FA               [12] 1095 	mov	r2,a
      0041FA E9               [12] 1096 	mov	a,r1
      0041FB 3B               [12] 1097 	addc	a, r3
      0041FC FB               [12] 1098 	mov	r3,a
      0041FD 12 45 76         [24] 1099 	lcall	_ak820_outline_0139
      004200 12 38 B4         [24] 1100 	lcall	_ak820_flash_read
      004203 AB 82            [24] 1101 	mov	r3, dpl
      004205 12 38 65         [24] 1102 	lcall	_ak820_outline_0131
      004208 EB               [12] 1103 	mov	a,r3
      004209 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00420A 0F               [12] 1106 	inc	r7
      00420B BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00420E 90 05 73         [24] 1109 	mov	dptr,#_cached_page
      004211 EC               [12] 1110 	mov	a,r4
      004212 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      004213 D2 07            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004215 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004218 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004219                       1128 _read_offset:
      004219 12 38 4B         [24] 1129 	lcall	_ak820_outline_0104
      00421C 90 05 96         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      00421F 12 38 50         [24] 1131 	lcall	_ak820_outline_0105
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004222 90 05 96         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      004225 12 38 01         [24] 1134 	lcall	_ak820_outline_0050
      004228 C3               [12] 1135 	clr	c
      004229 94 28            [12] 1136 	subb	a,#0x28
      00422B 40 04            [24] 1137 	jc	00102$
      00422D 75 82 00         [24] 1138 	mov	dpl, #0x00
      004230 22               [24] 1139 	ret
      004231                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004231 30 07 34         [24] 1142 	jnb	_page_valid,00104$
      004234 8E 04            [24] 1143 	mov	ar4,r6
      004236 EF               [12] 1144 	mov	a,r7
      004237 A2 E7            [12] 1145 	mov	c,acc.7
      004239 CC               [12] 1146 	xch	a,r4
      00423A 33               [12] 1147 	rlc	a
      00423B CC               [12] 1148 	xch	a,r4
      00423C 33               [12] 1149 	rlc	a
      00423D A2 E7            [12] 1150 	mov	c,acc.7
      00423F CC               [12] 1151 	xch	a,r4
      004240 33               [12] 1152 	rlc	a
      004241 CC               [12] 1153 	xch	a,r4
      004242 33               [12] 1154 	rlc	a
      004243 CC               [12] 1155 	xch	a,r4
      004244 54 03            [12] 1156 	anl	a,#0x03
      004246 FD               [12] 1157 	mov	r5,a
      004247 90 05 73         [24] 1158 	mov	dptr,#_cached_page
      00424A E0               [24] 1159 	movx	a,@dptr
      00424B FA               [12] 1160 	mov	r2,a
      00424C 7B 00            [12] 1161 	mov	r3,#0x00
      00424E EC               [12] 1162 	mov	a,r4
      00424F B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      004252 ED               [12] 1164 	mov	a,r5
      004253 B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004256 74 3F            [12] 1167 	mov	a,#0x3f
      004258 5E               [12] 1168 	anl	a,r6
      004259 7D 00            [12] 1169 	mov	r5,#0x00
      00425B 24 33            [12] 1170 	add	a, #_page_data
      00425D F5 82            [12] 1171 	mov	dpl,a
      00425F ED               [12] 1172 	mov	a,r5
      004260 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      004262 F5 83            [12] 1174 	mov	dph,a
      004264 E0               [24] 1175 	movx	a,@dptr
      004265 F5 82            [12] 1176 	mov	dpl,a
      004267 22               [24] 1177 	ret
      004268                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004268 74 C7            [12] 1180 	mov	a,#0xc7
      00426A 2F               [12] 1181 	add	a, r7
      00426B FF               [12] 1182 	mov	r7,a
      00426C 12 45 5A         [24] 1183 	lcall	_ak820_outline_0114
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00426F 02 38 B4         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      004272                       1195 _eeprom_read_byte:
      004272 C0 07            [24] 1196 	push	ar7
      004274 C0 06            [24] 1197 	push	ar6
      004276 12 45 11         [24] 1198 	lcall	_ak820_outline_0036
      004279 90 05 98         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00427C 12 37 E0         [24] 1200 	lcall	_ak820_outline_0015
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00427F 90 05 98         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004282 12 37 A1         [24] 1203 	lcall	_ak820_outline_0004
      004285 C0 06            [24] 1204 	push	ar6
      004287 C0 05            [24] 1205 	push	ar5
      004289 C0 04            [24] 1206 	push	ar4
      00428B C0 03            [24] 1207 	push	ar3
      00428D C0 02            [24] 1208 	push	ar2
      00428F C0 01            [24] 1209 	push	ar1
      004291 C0 00            [24] 1210 	push	ar0
      004293 12 42 19         [24] 1211 	lcall	_read_offset
      004296 AF 82            [24] 1212 	mov	r7, dpl
      004298 D0 00            [24] 1213 	pop	ar0
      00429A D0 01            [24] 1214 	pop	ar1
      00429C D0 02            [24] 1215 	pop	ar2
      00429E D0 03            [24] 1216 	pop	ar3
      0042A0 D0 04            [24] 1217 	pop	ar4
      0042A2 D0 05            [24] 1218 	pop	ar5
      0042A4 D0 06            [24] 1219 	pop	ar6
      0042A6 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0042A8 D0 06            [24] 1222 	pop	ar6
      0042AA D0 07            [24] 1223 	pop	ar7
      0042AC 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      0042AD                       1238 _ak820_eeprom_read_block_xdata:
      0042AD 12 38 4B         [24] 1239 	lcall	_ak820_outline_0104
      0042B0 90 05 A0         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0042B3 12 38 50         [24] 1241 	lcall	_ak820_outline_0105
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0042B6 90 05 9B         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0042B9 12 38 01         [24] 1244 	lcall	_ak820_outline_0050
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0042BC 90 05 A0         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0042BF 12 38 20         [24] 1247 	lcall	_ak820_outline_0059
      0042C2 90 05 A2         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042C5 12 38 26         [24] 1249 	lcall	_ak820_outline_0070
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0042C8 90 05 9E         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0042CB 12 38 20         [24] 1252 	lcall	_ak820_outline_0059
      0042CE                       1253 00103$:
      0042CE 8C 02            [24] 1254 	mov	ar2,r4
      0042D0 8D 03            [24] 1255 	mov	ar3,r5
      0042D2 1C               [12] 1256 	dec	r4
      0042D3 BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      0042D6 1D               [12] 1258 	dec	r5
      0042D7                       1259 00130$:
      0042D7 EA               [12] 1260 	mov	a,r2
      0042D8 4B               [12] 1261 	orl	a,r3
      0042D9 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0042DB 8E 02            [24] 1264 	mov	ar2,r6
      0042DD 8F 03            [24] 1265 	mov	ar3,r7
      0042DF 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      0042E1 2B               [12] 1267 	add	a,r3
      0042E2 50 17            [24] 1268 	jnc	00102$
      0042E4 90 05 A2         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042E7 12 45 5F         [24] 1270 	lcall	_ak820_outline_0119
      0042EA 12 45 76         [24] 1271 	lcall	_ak820_outline_0139
      0042ED E4               [12] 1272 	clr	a
      0042EE F0               [24] 1273 	movx	@dptr,a
      0042EF 90 05 A2         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042F2 04               [12] 1275 	inc	a
      0042F3 2A               [12] 1276 	add	a, r2
      0042F4 F0               [24] 1277 	movx	@dptr,a
      0042F5 E4               [12] 1278 	clr	a
      0042F6 3B               [12] 1279 	addc	a, r3
      0042F7 A3               [24] 1280 	inc	dptr
      0042F8 F0               [24] 1281 	movx	@dptr,a
      0042F9 80 D3            [24] 1282 	sjmp	00103$
      0042FB                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0042FB 90 05 A2         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0042FE 12 45 5F         [24] 1286 	lcall	_ak820_outline_0119
      004301 12 45 5A         [24] 1287 	lcall	_ak820_outline_0114
      004304 C0 07            [24] 1288 	push	ar7
      004306 C0 06            [24] 1289 	push	ar6
      004308 C0 05            [24] 1290 	push	ar5
      00430A C0 04            [24] 1291 	push	ar4
      00430C C0 03            [24] 1292 	push	ar3
      00430E C0 02            [24] 1293 	push	ar2
      004310 12 42 19         [24] 1294 	lcall	_read_offset
      004313 A9 82            [24] 1295 	mov	r1, dpl
      004315 D0 02            [24] 1296 	pop	ar2
      004317 D0 03            [24] 1297 	pop	ar3
      004319 D0 04            [24] 1298 	pop	ar4
      00431B D0 05            [24] 1299 	pop	ar5
      00431D D0 06            [24] 1300 	pop	ar6
      00431F D0 07            [24] 1301 	pop	ar7
      004321 12 45 76         [24] 1302 	lcall	_ak820_outline_0139
      004324 E9               [12] 1303 	mov	a,r1
      004325 F0               [24] 1304 	movx	@dptr,a
      004326 90 05 A2         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004329 74 01            [12] 1306 	mov	a,#0x01
      00432B 2A               [12] 1307 	add	a, r2
      00432C F0               [24] 1308 	movx	@dptr,a
      00432D E4               [12] 1309 	clr	a
      00432E 3B               [12] 1310 	addc	a, r3
      00432F A3               [24] 1311 	inc	dptr
      004330 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004331 0E               [12] 1314 	inc	r6
      004332 BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      004335 0F               [12] 1316 	inc	r7
      004336 80 96            [24] 1317 	sjmp	00103$
      004338                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004338 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      004339                       1336 _ak820_eeprom_write_block_xdata:
      004339 12 38 4B         [24] 1337 	lcall	_ak820_outline_0104
      00433C 90 05 A9         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00433F 12 38 50         [24] 1339 	lcall	_ak820_outline_0105
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004342 90 05 A4         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004345 12 38 01         [24] 1342 	lcall	_ak820_outline_0050
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004348 90 05 A9         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00434B 12 38 20         [24] 1345 	lcall	_ak820_outline_0059
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00434E 8E 02            [24] 1347 	mov	ar2,r6
      004350 8F 03            [24] 1348 	mov	ar3,r7
      004352 C3               [12] 1349 	clr	c
      004353 E4               [12] 1350 	clr	a
      004354 9A               [12] 1351 	subb	a,r2
      004355 74 28            [12] 1352 	mov	a,#0x28
      004357 9B               [12] 1353 	subb	a,r3
      004358 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      00435A E4               [12] 1356 	clr	a
      00435B C3               [12] 1357 	clr	c
      00435C 9E               [12] 1358 	subb	a,r6
      00435D FA               [12] 1359 	mov	r2,a
      00435E 74 28            [12] 1360 	mov	a,#0x28
      004360 9F               [12] 1361 	subb	a,r7
      004361 FB               [12] 1362 	mov	r3,a
      004362 90 05 A7         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004365 12 38 45         [24] 1364 	lcall	_ak820_outline_0100
      004368 C3               [12] 1365 	clr	c
      004369 EA               [12] 1366 	mov	a,r2
      00436A 98               [12] 1367 	subb	a,r0
      00436B EB               [12] 1368 	mov	a,r3
      00436C 99               [12] 1369 	subb	a,r1
      00436D 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      00436F                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00436F 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004372 02 3D 82         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004375                       1378 00125$:
      004375 90 05 A7         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004378 12 45 5F         [24] 1380 	lcall	_ak820_outline_0119
      00437B                       1381 00108$:
      00437B 8A 00            [24] 1382 	mov	ar0,r2
      00437D 8B 01            [24] 1383 	mov	ar1,r3
      00437F 1A               [12] 1384 	dec	r2
      004380 BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      004383 1B               [12] 1386 	dec	r3
      004384                       1387 00159$:
      004384 E8               [12] 1388 	mov	a,r0
      004385 49               [12] 1389 	orl	a,r1
      004386 70 03            [24] 1390 	jnz	00160$
      004388 02 44 12         [24] 1391 	ljmp	00110$
      00438B                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00438B C0 02            [24] 1394 	push	ar2
      00438D C0 03            [24] 1395 	push	ar3
      00438F 12 45 42         [24] 1396 	lcall	_ak820_outline_0092
      004392 F9               [12] 1397 	mov	r1,a
      004393 A3               [24] 1398 	inc	dptr
      004394 12 45 7B         [24] 1399 	lcall	_ak820_outline_0144
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004397 8E 0E            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004399 8F 0F            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00439B A8 0E            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00439D E5 0F            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00439F A2 E7            [12] 1405 	mov	c,acc.7
      0043A1 C8               [12] 1406 	xch	a,r0
      0043A2 33               [12] 1407 	rlc	a
      0043A3 C8               [12] 1408 	xch	a,r0
      0043A4 33               [12] 1409 	rlc	a
      0043A5 A2 E7            [12] 1410 	mov	c,acc.7
      0043A7 C8               [12] 1411 	xch	a,r0
      0043A8 33               [12] 1412 	rlc	a
      0043A9 C8               [12] 1413 	xch	a,r0
      0043AA 33               [12] 1414 	rlc	a
      0043AB C8               [12] 1415 	xch	a,r0
      0043AC 54 03            [12] 1416 	anl	a,#0x03
      0043AE FB               [12] 1417 	mov	r3,a
      0043AF 88 82            [24] 1418 	mov	dpl, r0
      0043B1 C0 07            [24] 1419 	push	ar7
      0043B3 C0 06            [24] 1420 	push	ar6
      0043B5 C0 05            [24] 1421 	push	ar5
      0043B7 C0 04            [24] 1422 	push	ar4
      0043B9 C0 03            [24] 1423 	push	ar3
      0043BB C0 02            [24] 1424 	push	ar2
      0043BD C0 01            [24] 1425 	push	ar1
      0043BF 12 41 A7         [24] 1426 	lcall	_load_page
      0043C2 E5 82            [12] 1427 	mov	a, dpl
      0043C4 D0 01            [24] 1428 	pop	ar1
      0043C6 D0 02            [24] 1429 	pop	ar2
      0043C8 D0 03            [24] 1430 	pop	ar3
      0043CA D0 04            [24] 1431 	pop	ar4
      0043CC D0 05            [24] 1432 	pop	ar5
      0043CE D0 06            [24] 1433 	pop	ar6
      0043D0 D0 07            [24] 1434 	pop	ar7
      0043D2 D0 03            [24] 1435 	pop	ar3
      0043D4 D0 02            [24] 1436 	pop	ar2
      0043D6 70 01            [24] 1437 	jnz	00105$
      0043D8 22               [24] 1438 	ret
      0043D9                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0043D9 C0 06            [24] 1441 	push	ar6
      0043DB C0 07            [24] 1442 	push	ar7
      0043DD 74 3F            [12] 1443 	mov	a,#0x3f
      0043DF 55 0E            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043E1 7F 00            [12] 1445 	mov	r7,#0x00
      0043E3 24 33            [12] 1446 	add	a, #_page_data
      0043E5 F5 0E            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0043E7 EF               [12] 1448 	mov	a,r7
      0043E8 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      0043EA F5 0F            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0043EC 85 0E 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043EF 85 0F 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0043F2 E0               [24] 1453 	movx	a,@dptr
      0043F3 B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      0043F6 D0 07            [24] 1455 	pop	ar7
      0043F8 D0 06            [24] 1456 	pop	ar6
      0043FA 80 0E            [24] 1457 	sjmp	00107$
      0043FC                       1458 00162$:
      0043FC D0 07            [24] 1459 	pop	ar7
      0043FE D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004400 85 0E 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004403 85 0F 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004406 E9               [12] 1464 	mov	a,r1
      004407 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004408 D2 08            [12] 1468 	setb	_page_dirty
      00440A                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00440A 0E               [12] 1471 	inc	r6
      00440B BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      00440E 0F               [12] 1473 	inc	r7
      00440F                       1474 00163$:
      00440F 02 43 7B         [24] 1475 	ljmp	00108$
      004412                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004412 90 05 74         [24] 1478 	mov	dptr,#_batch_depth
      004415 E0               [24] 1479 	movx	a,@dptr
      004416 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004418 02 40 27         [24] 1482 	ljmp	_ak820_nvm_flush
      00441B                       1483 00113$:
      00441B 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      00441C                       1502 _ak820_eeprom_update_block_xdata:
      00441C 12 38 4B         [24] 1503 	lcall	_ak820_outline_0104
      00441F 90 05 B0         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004422 12 38 50         [24] 1505 	lcall	_ak820_outline_0105
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004425 90 05 B0         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004428 12 38 01         [24] 1508 	lcall	_ak820_outline_0050
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00442B 90 05 AB         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00442E E0               [24] 1511 	movx	a,@dptr
      00442F F5 14            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004431 A3               [24] 1513 	inc	dptr
      004432 E0               [24] 1514 	movx	a,@dptr
      004433 F5 15            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004435 A3               [24] 1516 	inc	dptr
      004436 E0               [24] 1517 	movx	a,@dptr
      004437 F5 16            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004439 A9 14            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00443B AA 15            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00443D E4               [12] 1522 	clr	a
      00443E F5 10            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004440 F5 11            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004442                       1525 00105$:
      004442 90 05 AE         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004445 E0               [24] 1527 	movx	a,@dptr
      004446 F5 12            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004448 A3               [24] 1529 	inc	dptr
      004449 E0               [24] 1530 	movx	a,@dptr
      00444A F5 13            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00444C C3               [12] 1532 	clr	c
      00444D E5 10            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00444F 95 12            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004451 E5 11            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004453 95 13            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004455 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004457 89 00            [24] 1539 	mov	ar0,r1
      004459 8A 05            [24] 1540 	mov	ar5,r2
      00445B E5 10            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00445D 28               [12] 1542 	add	a, r0
      00445E F8               [12] 1543 	mov	r0,a
      00445F E5 11            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004461 3D               [12] 1545 	addc	a, r5
      004462 FD               [12] 1546 	mov	r5,a
      004463 88 82            [24] 1547 	mov	dpl, r0
      004465 8D 83            [24] 1548 	mov	dph, r5
      004467 C0 07            [24] 1549 	push	ar7
      004469 C0 06            [24] 1550 	push	ar6
      00446B C0 02            [24] 1551 	push	ar2
      00446D C0 01            [24] 1552 	push	ar1
      00446F 12 42 19         [24] 1553 	lcall	_read_offset
      004472 AD 82            [24] 1554 	mov	r5, dpl
      004474 D0 01            [24] 1555 	pop	ar1
      004476 D0 02            [24] 1556 	pop	ar2
      004478 D0 06            [24] 1557 	pop	ar6
      00447A D0 07            [24] 1558 	pop	ar7
      00447C E5 10            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00447E 2E               [12] 1560 	add	a, r6
      00447F F5 82            [12] 1561 	mov	dpl,a
      004481 E5 11            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004483 3F               [12] 1563 	addc	a, r7
      004484 F5 83            [12] 1564 	mov	dph,a
      004486 E0               [24] 1565 	movx	a,@dptr
      004487 FC               [12] 1566 	mov	r4,a
      004488 ED               [12] 1567 	mov	a,r5
      004489 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      00448C 80 27            [24] 1569 	sjmp	00106$
      00448E                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00448E 90 05 B0         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004491 E0               [24] 1573 	movx	a,@dptr
      004492 F8               [12] 1574 	mov	r0,a
      004493 A3               [24] 1575 	inc	dptr
      004494 E0               [24] 1576 	movx	a,@dptr
      004495 FD               [12] 1577 	mov	r5,a
      004496 90 05 A4         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004499 E5 14            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00449B F0               [24] 1580 	movx	@dptr,a
      00449C E5 15            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00449E A3               [24] 1582 	inc	dptr
      00449F F0               [24] 1583 	movx	@dptr,a
      0044A0 E5 16            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0044A2 A3               [24] 1585 	inc	dptr
      0044A3 F0               [24] 1586 	movx	@dptr,a
      0044A4 90 05 A7         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044A7 E5 12            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044A9 F0               [24] 1589 	movx	@dptr,a
      0044AA E5 13            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044AC A3               [24] 1591 	inc	dptr
      0044AD F0               [24] 1592 	movx	@dptr,a
      0044AE 88 82            [24] 1593 	mov	dpl, r0
      0044B0 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0044B2 02 43 39         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      0044B5                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044B5 05 10            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044B7 E4               [12] 1600 	clr	a
      0044B8 B5 10 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0044BB 05 11            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044BD 80 83            [24] 1603 	sjmp	00105$
      0044BF                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0044BF 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      0044C0                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0044C0 12 40 27         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0044C3 7F 00            [12] 1621 	mov	r7,#0x00
      0044C5                       1622 00111$:
      0044C5 BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      0044C8 22               [24] 1624 	ret
      0044C9                       1625 00165$:
      0044C9 20 09 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0044CC 8F 82            [24] 1628 	mov	dpl, r7
      0044CE C0 07            [24] 1629 	push	ar7
      0044D0 12 41 A7         [24] 1630 	lcall	_load_page
      0044D3 E5 82            [12] 1631 	mov	a, dpl
      0044D5 D0 07            [24] 1632 	pop	ar7
      0044D7 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044D9 22               [24] 1635 	ret
      0044DA                       1636 00126$:
      0044DA 7E 00            [12] 1637 	mov	r6,#0x00
      0044DC                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0044DC EE               [12] 1640 	mov	a,r6
      0044DD 24 33            [12] 1641 	add	a, #_page_data
      0044DF FC               [12] 1642 	mov	r4,a
      0044E0 E4               [12] 1643 	clr	a
      0044E1 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      0044E3 FD               [12] 1645 	mov	r5,a
      0044E4 12 45 42         [24] 1646 	lcall	_ak820_outline_0092
      0044E7 60 07            [24] 1647 	jz	00108$
      0044E9 12 38 55         [24] 1648 	lcall	_ak820_outline_0117
      0044EC E4               [12] 1649 	clr	a
      0044ED F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      0044EE D2 08            [12] 1652 	setb	_page_dirty
      0044F0                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044F0 0E               [12] 1655 	inc	r6
      0044F1 BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0044F4 C0 07            [24] 1658 	push	ar7
      0044F6 12 40 27         [24] 1659 	lcall	_ak820_nvm_flush
      0044F9 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0044FB 0F               [12] 1662 	inc	r7
      0044FC 80 C7            [24] 1663 	sjmp	00111$
      0044FE                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0044FE 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0004
                                   1674 	.globl _ak820_outline_0011
                                   1675 	.globl _ak820_outline_0015
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0031
                                   1678 	.globl _ak820_outline_0036
                                   1679 	.globl _ak820_outline_0039
                                   1680 	.globl _ak820_outline_0050
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0059
                                   1683 	.globl _ak820_outline_0061
                                   1684 	.globl _ak820_outline_0064
                                   1685 	.globl _ak820_outline_0070
                                   1686 	.globl _ak820_outline_0076
                                   1687 	.globl _ak820_outline_0092
                                   1688 	.globl _ak820_outline_0093
                                   1689 	.globl _ak820_outline_0100
                                   1690 	.globl _ak820_outline_0102
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0105
                                   1693 	.globl _ak820_outline_0114
                                   1694 	.globl _ak820_outline_0117
                                   1695 	.globl _ak820_outline_0119
                                   1696 	.globl _ak820_outline_0120
                                   1697 	.globl _ak820_outline_0121
                                   1698 	.globl _ak820_outline_0130
                                   1699 	.globl _ak820_outline_0131
                                   1700 	.globl _ak820_outline_0133
                                   1701 	.globl _ak820_outline_0138
                                   1702 	.globl _ak820_outline_0139
                                   1703 	.globl _ak820_outline_0144
                                   1704 	.globl _ak820_outline_0152
                                   1705 	.globl _ak820_outline_0155
                                   1706 	.globl _ak820_outline_0156
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0178
                                   1709 	.globl _ak820_outline_0179
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0011
      0044FF                       1713 _ak820_outline_0011:
      0044FF 8E 82            [24] 1714 	mov	dpl,r6
      004501 8F 83            [24] 1715 	mov	dph,r7
      004503 A3               [24] 1716 	inc	dptr
      004504 A3               [24] 1717 	inc	dptr
      004505 A3               [24] 1718 	inc	dptr
      004506 A3               [24] 1719 	inc	dptr
      004507 A3               [24] 1720 	inc	dptr
      004508 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0031
      004509                       1725 _ak820_outline_0031:
      004509 F0               [24] 1726 	movx	@dptr,a
      00450A 8E 82            [24] 1727 	mov	dpl,r6
      00450C 8F 83            [24] 1728 	mov	dph,r7
      00450E A3               [24] 1729 	inc	dptr
      00450F A3               [24] 1730 	inc	dptr
      004510 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0036
      004511                       1735 _ak820_outline_0036:
      004511 AF F0            [24] 1736 	mov	r7,b
      004513 AE 83            [24] 1737 	mov	r6,dph
      004515 E5 82            [12] 1738 	mov	a,dpl
      004517 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0039
      004518                       1743 _ak820_outline_0039:
      004518 EF               [12] 1744 	mov	a,r7
      004519 24 8B            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      00451B F5 82            [12] 1746 	mov	dpl,a
      00451D E4               [12] 1747 	clr	a
      00451E 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004520 F5 83            [12] 1749 	mov	dph,a
      004522 E0               [24] 1750 	movx	a,@dptr
      004523 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0051
      004524                       1755 _ak820_outline_0051:
      004524 8F 06            [24] 1756 	mov	ar6,r7
      004526 7D 00            [12] 1757 	mov	r5,#0x00
      004528 74 40            [12] 1758 	mov	a,#0x40
      00452A 2E               [12] 1759 	add	a,r6
      00452B FE               [12] 1760 	mov	r6,a
      00452C 74 EF            [12] 1761 	mov	a,#0xef
      00452E 3D               [12] 1762 	addc	a,r5
      00452F FD               [12] 1763 	mov	r5,a
      004530 8E 82            [24] 1764 	mov	dpl,r6
      004532 8D 83            [24] 1765 	mov	dph,r5
      004534 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0061
      004535                       1770 _ak820_outline_0061:
      004535 F0               [24] 1771 	movx	@dptr,a
      004536 8E 82            [24] 1772 	mov	dpl,r6
      004538 8F 83            [24] 1773 	mov	dph,r7
      00453A 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0064
      00453B                       1778 _ak820_outline_0064:
      00453B 8D 82            [24] 1779 	mov	dpl,r5
      00453D 8E 83            [24] 1780 	mov	dph,r6
      00453F EC               [12] 1781 	mov	a,r4
      004540 F0               [24] 1782 	movx	@dptr,a
      004541 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0092
      004542                       1787 _ak820_outline_0092:
      004542 8C 82            [24] 1788 	mov	dpl,r4
      004544 8D 83            [24] 1789 	mov	dph,r5
      004546 E0               [24] 1790 	movx	a,@dptr
      004547 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0093
      004548                       1795 _ak820_outline_0093:
      004548 E0               [24] 1796 	movx	a,@dptr
      004549 FD               [12] 1797 	mov	r5,a
      00454A A3               [24] 1798 	inc	dptr
      00454B E0               [24] 1799 	movx	a,@dptr
      00454C FE               [12] 1800 	mov	r6,a
      00454D 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0102
      00454E                       1805 _ak820_outline_0102:
      00454E EF               [12] 1806 	mov	a,r7
      00454F 24 33            [12] 1807 	add	a,#_page_data
      004551 F5 82            [12] 1808 	mov	dpl,a
      004553 E4               [12] 1809 	clr	a
      004554 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      004556 F5 83            [12] 1811 	mov	dph,a
      004558 E0               [24] 1812 	movx	a,@dptr
      004559 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0114
      00455A                       1817 _ak820_outline_0114:
      00455A 8E 82            [24] 1818 	mov	dpl,r6
      00455C 8F 83            [24] 1819 	mov	dph,r7
      00455E 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0119
      00455F                       1824 _ak820_outline_0119:
      00455F E0               [24] 1825 	movx	a,@dptr
      004560 FA               [12] 1826 	mov	r2,a
      004561 A3               [24] 1827 	inc	dptr
      004562 E0               [24] 1828 	movx	a,@dptr
      004563 FB               [12] 1829 	mov	r3,a
      004564 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0130
      004565                       1834 _ak820_outline_0130:
      004565 AE 82            [24] 1835 	mov	r6,dpl
      004567 AF 83            [24] 1836 	mov	r7,dph
      004569 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0133
      00456A                       1841 _ak820_outline_0133:
      00456A 2E               [12] 1842 	add	a,r6
      00456B FE               [12] 1843 	mov	r6,a
      00456C E4               [12] 1844 	clr	a
      00456D 3F               [12] 1845 	addc	a,r7
      00456E FF               [12] 1846 	mov	r7,a
      00456F 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0138
      004570                       1851 _ak820_outline_0138:
      004570 42 05            [12] 1852 	orl	ar5,a
      004572 EA               [12] 1853 	mov	a,r2
      004573 42 04            [12] 1854 	orl	ar4,a
      004575 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0139
      004576                       1859 _ak820_outline_0139:
      004576 8A 82            [24] 1860 	mov	dpl,r2
      004578 8B 83            [24] 1861 	mov	dph,r3
      00457A 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0144
      00457B                       1866 _ak820_outline_0144:
      00457B AC 82            [24] 1867 	mov	r4,dpl
      00457D AD 83            [24] 1868 	mov	r5,dph
      00457F 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0152
      004580                       1873 _ak820_outline_0152:
      004580 8F 82            [24] 1874 	mov	dpl,r7
      004582 8E 83            [24] 1875 	mov	dph,r6
      004584 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0155
      004585                       1880 _ak820_outline_0155:
      004585 2E               [12] 1881 	add	a,r6
      004586 FC               [12] 1882 	mov	r4,a
      004587 E4               [12] 1883 	clr	a
      004588 3F               [12] 1884 	addc	a,r7
      004589 FD               [12] 1885 	mov	r5,a
      00458A 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0156
      00458B                       1890 _ak820_outline_0156:
      00458B ED               [12] 1891 	mov	a,r5
      00458C F0               [24] 1892 	movx	@dptr,a
      00458D EE               [12] 1893 	mov	a,r6
      00458E A3               [24] 1894 	inc	dptr
      00458F F0               [24] 1895 	movx	@dptr,a
      004590 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0178
      004591                       1900 _ak820_outline_0178:
      004591 89 82            [24] 1901 	mov	dpl,r1
      004593 8A 83            [24] 1902 	mov	dph,r2
      004595 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0179
      004596                       1907 _ak820_outline_0179:
      004596 8C 82            [24] 1908 	mov	dpl,r4
      004598 8B 83            [24] 1909 	mov	dph,r3
      00459A 22               [24] 1910 	ret
