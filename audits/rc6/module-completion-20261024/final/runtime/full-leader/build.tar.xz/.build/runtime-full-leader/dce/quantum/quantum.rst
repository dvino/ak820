                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_combo_tick
                                     18 	.globl _ak820_leader_process
                                     19 	.globl _process_repeat_key
                                     20 	.globl _process_last_key
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _mcu_reset
                                     24 	.globl _bootloader_jump
                                     25 	.globl _ak820_resolve_key
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _rgb_matrix_set_suspend_state
                                     36 	.globl _rgb_matrix_task
                                     37 	.globl _mDelaymS
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _process_record_quantum_helper_PARM_2
                                    282 	.globl _get_record_keycode_PARM_2
                                    283 	.globl _register_code16
                                    284 	.globl _unregister_code16
                                    285 	.globl _reset_keyboard
                                    286 	.globl _soft_reset_keyboard
                                    287 	.globl _get_record_keycode
                                    288 	.globl _pre_process_record_quantum
                                    289 	.globl _process_record_quantum
                                    290 	.globl _process_record_quantum_helper
                                    291 	.globl _shutdown_user
                                    292 ;--------------------------------------------------------
                                    293 ; special function registers
                                    294 ;--------------------------------------------------------
                                    295 	.area RSEG    (ABS,DATA)
      000000                        296 	.org 0x0000
                           0000D0   297 _PSW	=	0x00d0
                           0000E0   298 _ACC	=	0x00e0
                           0000F0   299 _B	=	0x00f0
                           0000FD   300 _A_INV	=	0x00fd
                           000081   301 _SP	=	0x0081
                           000082   302 _DPL	=	0x0082
                           000083   303 _DPH	=	0x0083
                           0000A1   304 _SAFE_MOD	=	0x00a1
                           0000B1   305 _GLOBAL_CFG	=	0x00b1
                           000087   306 _PCON	=	0x0087
                           0000BA   307 _POWER_CFG	=	0x00ba
                           0000B9   308 _CLOCK_CFG	=	0x00b9
                           0000A9   309 _WAKE_CTRL	=	0x00a9
                           0000FE   310 _RESET_KEEP	=	0x00fe
                           0000FF   311 _WDOG_COUNT	=	0x00ff
                           0000A8   312 _IE	=	0x00a8
                           0000B8   313 _IP	=	0x00b8
                           0000E8   314 _IE_EX	=	0x00e8
                           0000E9   315 _IP_EX	=	0x00e9
                           0000B2   316 _GPIO_IE	=	0x00b2
                           008584   317 _ROM_ADDR	=	0x8584
                           000084   318 _ROM_ADDR_L	=	0x0084
                           000085   319 _ROM_ADDR_H	=	0x0085
                           008F8E   320 _ROM_DATA_HI	=	0x8f8e
                           00008E   321 _ROM_DATA_HL	=	0x008e
                           00008F   322 _ROM_DATA_HH	=	0x008f
                           000086   323 _ROM_CTRL	=	0x0086
                           000080   324 _P0	=	0x0080
                           0000C4   325 _P0_MOD_OC	=	0x00c4
                           0000C5   326 _P0_DIR_PU	=	0x00c5
                           000090   327 _P1	=	0x0090
                           000092   328 _P1_MOD_OC	=	0x0092
                           000093   329 _P1_DIR_PU	=	0x0093
                           0000A0   330 _P2	=	0x00a0
                           000094   331 _P2_MOD_OC	=	0x0094
                           000095   332 _P2_DIR_PU	=	0x0095
                           0000B0   333 _P3	=	0x00b0
                           000096   334 _P3_MOD_OC	=	0x0096
                           000097   335 _P3_DIR_PU	=	0x0097
                           0000C0   336 _P4	=	0x00c0
                           0000C2   337 _P4_MOD_OC	=	0x00c2
                           0000C3   338 _P4_DIR_PU	=	0x00c3
                           0000C1   339 _P4_LED_KEY	=	0x00c1
                           0000AA   340 _P5_IN	=	0x00aa
                           0000AB   341 _P5_OUT_PU	=	0x00ab
                           0000AC   342 _P5_DIR	=	0x00ac
                           0000AD   343 _P6_IN	=	0x00ad
                           0000AE   344 _P6_OUT_PU	=	0x00ae
                           0000AF   345 _P6_DIR	=	0x00af
                           0000F1   346 _P7	=	0x00f1
                           0000A2   347 _XBUS_AUX	=	0x00a2
                           000088   348 _TCON	=	0x0088
                           000089   349 _TMOD	=	0x0089
                           00008A   350 _TL0	=	0x008a
                           00008B   351 _TL1	=	0x008b
                           00008C   352 _TH0	=	0x008c
                           00008D   353 _TH1	=	0x008d
                           000098   354 _SCON	=	0x0098
                           000099   355 _SBUF	=	0x0099
                           0000C8   356 _T2CON	=	0x00c8
                           0000C9   357 _T2MOD	=	0x00c9
                           00CBCA   358 _RCAP2	=	0xcbca
                           0000CA   359 _RCAP2L	=	0x00ca
                           0000CB   360 _RCAP2H	=	0x00cb
                           00CDCC   361 _T2COUNT	=	0xcdcc
                           0000CC   362 _TL2	=	0x00cc
                           0000CD   363 _TH2	=	0x00cd
                           00CFCE   364 _T2CAP1	=	0xcfce
                           0000CE   365 _T2CAP1L	=	0x00ce
                           0000CF   366 _T2CAP1H	=	0x00cf
                           0000F8   367 _SPI0_STAT	=	0x00f8
                           0000F9   368 _SPI0_DATA	=	0x00f9
                           0000FA   369 _SPI0_CTRL	=	0x00fa
                           0000FB   370 _SPI0_CK_SE	=	0x00fb
                           0000FC   371 _SPI0_SETUP	=	0x00fc
                           0000BC   372 _SCON1	=	0x00bc
                           0000BD   373 _SBUF1	=	0x00bd
                           0000BE   374 _SBAUD1	=	0x00be
                           0000BF   375 _SIF1	=	0x00bf
                           0000B4   376 _SPI1_STAT	=	0x00b4
                           0000B5   377 _SPI1_DATA	=	0x00b5
                           0000B6   378 _SPI1_CTRL	=	0x00b6
                           0000B7   379 _SPI1_CK_SE	=	0x00b7
                           0000F3   380 _ADC_CTRL	=	0x00f3
                           00F5F4   381 _ADC_DAT	=	0xf5f4
                           0000F4   382 _ADC_DAT_L	=	0x00f4
                           0000F5   383 _ADC_DAT_H	=	0x00f5
                           0000F6   384 _ADC_CHAN	=	0x00f6
                           0000A6   385 _LED_COMMON	=	0x00a6
                           0000A7   386 _LED_PWM_OE	=	0x00a7
                           00C7C6   387 _LED_DMA	=	0xc7c6
                           0000C6   388 _LED_DMA_L	=	0x00c6
                           0000C7   389 _LED_DMA_H	=	0x00c7
                           0000F7   390 _LED_STATUS	=	0x00f7
                           0000B3   391 _I2CX_INT	=	0x00b3
                           0000BB   392 _I2CS_INT_ST	=	0x00bb
                                    393 ;--------------------------------------------------------
                                    394 ; special function bits
                                    395 ;--------------------------------------------------------
                                    396 	.area RSEG    (ABS,DATA)
      000000                        397 	.org 0x0000
                           0000D7   398 _CY	=	0x00d7
                           0000D6   399 _AC	=	0x00d6
                           0000D5   400 _F0	=	0x00d5
                           0000D4   401 _RS1	=	0x00d4
                           0000D3   402 _RS0	=	0x00d3
                           0000D2   403 _OV	=	0x00d2
                           0000D1   404 _F1	=	0x00d1
                           0000D0   405 _P	=	0x00d0
                           0000AF   406 _EA	=	0x00af
                           0000AE   407 _E_DIS	=	0x00ae
                           0000AD   408 _ET2	=	0x00ad
                           0000AC   409 _ES	=	0x00ac
                           0000AB   410 _ET1	=	0x00ab
                           0000AA   411 _EX1	=	0x00aa
                           0000A9   412 _ET0	=	0x00a9
                           0000A8   413 _EX0	=	0x00a8
                           0000BF   414 _PH_FLAG	=	0x00bf
                           0000BE   415 _PL_FLAG	=	0x00be
                           0000BD   416 _PT2	=	0x00bd
                           0000BC   417 _PS	=	0x00bc
                           0000BB   418 _PT1	=	0x00bb
                           0000BA   419 _PX1	=	0x00ba
                           0000B9   420 _PT0	=	0x00b9
                           0000B8   421 _PX0	=	0x00b8
                           0000EF   422 _IE_WDOG	=	0x00ef
                           0000EE   423 _IE_GPIO	=	0x00ee
                           0000ED   424 _IE_PWM_I2C	=	0x00ed
                           0000EC   425 _IE_UART1	=	0x00ec
                           0000EB   426 _IE_ADC	=	0x00eb
                           0000E9   427 _IE_USB	=	0x00e9
                           0000E8   428 _IE_SPI0	=	0x00e8
                           000087   429 _P0_7	=	0x0087
                           000086   430 _P0_6	=	0x0086
                           000085   431 _P0_5	=	0x0085
                           000084   432 _P0_4	=	0x0084
                           000083   433 _P0_3	=	0x0083
                           000082   434 _P0_2	=	0x0082
                           000081   435 _P0_1	=	0x0081
                           000080   436 _P0_0	=	0x0080
                           000081   437 _SDA0	=	0x0081
                           000080   438 _SCL0	=	0x0080
                           000083   439 _TXD_	=	0x0083
                           000082   440 _RXD_	=	0x0082
                           000085   441 _AIN13	=	0x0085
                           000084   442 _AIN12	=	0x0084
                           000083   443 _AIN11	=	0x0083
                           000082   444 _AIN10	=	0x0082
                           000081   445 _AIN9	=	0x0081
                           000080   446 _AIN8	=	0x0080
                           000097   447 _P1_7	=	0x0097
                           000096   448 _P1_6	=	0x0096
                           000095   449 _P1_5	=	0x0095
                           000094   450 _P1_4	=	0x0094
                           000093   451 _P1_3	=	0x0093
                           000092   452 _P1_2	=	0x0092
                           000091   453 _P1_1	=	0x0091
                           000090   454 _P1_0	=	0x0090
                           000097   455 _TXD1_	=	0x0097
                           000096   456 _RXD1_	=	0x0096
                           000097   457 _SCK	=	0x0097
                           000096   458 _MISO	=	0x0096
                           000095   459 _MOSI	=	0x0095
                           000094   460 _SCS	=	0x0094
                           000092   461 _INT0_	=	0x0092
                           000091   462 _T2EX	=	0x0091
                           000091   463 _CAP2	=	0x0091
                           000090   464 _T2	=	0x0090
                           000090   465 _CAP1	=	0x0090
                           000097   466 _AIN7	=	0x0097
                           000096   467 _AIN6	=	0x0096
                           000095   468 _AIN5	=	0x0095
                           000094   469 _AIN4	=	0x0094
                           000093   470 _AIN3	=	0x0093
                           000092   471 _AIN2	=	0x0092
                           000091   472 _AIN1	=	0x0091
                           000090   473 _AIN0	=	0x0090
                           0000A7   474 _P2_7	=	0x00a7
                           0000A6   475 _P2_6	=	0x00a6
                           0000A5   476 _P2_5	=	0x00a5
                           0000A4   477 _P2_4	=	0x00a4
                           0000A3   478 _P2_3	=	0x00a3
                           0000A2   479 _P2_2	=	0x00a2
                           0000A1   480 _P2_1	=	0x00a1
                           0000A0   481 _P2_0	=	0x00a0
                           0000A7   482 _TXD1	=	0x00a7
                           0000A6   483 _RXD1	=	0x00a6
                           0000A5   484 _T2EX_	=	0x00a5
                           0000A5   485 _CAP2_	=	0x00a5
                           0000A4   486 _T2_	=	0x00a4
                           0000A4   487 _CAP1_	=	0x00a4
                           0000B7   488 _P3_7	=	0x00b7
                           0000B6   489 _P3_6	=	0x00b6
                           0000B5   490 _P3_5	=	0x00b5
                           0000B4   491 _P3_4	=	0x00b4
                           0000B3   492 _P3_3	=	0x00b3
                           0000B2   493 _P3_2	=	0x00b2
                           0000B1   494 _P3_1	=	0x00b1
                           0000B0   495 _P3_0	=	0x00b0
                           0000B7   496 _SCK1	=	0x00b7
                           0000B6   497 _MISO1	=	0x00b6
                           0000B5   498 _MOSI1	=	0x00b5
                           0000B5   499 _T1	=	0x00b5
                           0000B4   500 _T0	=	0x00b4
                           0000B3   501 _INT1	=	0x00b3
                           0000B2   502 _INT0	=	0x00b2
                           0000B1   503 _TXD	=	0x00b1
                           0000B0   504 _RXD	=	0x00b0
                           0000C6   505 _P4_6	=	0x00c6
                           0000C5   506 _P4_5	=	0x00c5
                           0000C4   507 _P4_4	=	0x00c4
                           0000C3   508 _P4_3	=	0x00c3
                           0000C2   509 _P4_2	=	0x00c2
                           0000C1   510 _P4_1	=	0x00c1
                           0000C0   511 _P4_0	=	0x00c0
                           00008F   512 _TF1	=	0x008f
                           00008E   513 _TR1	=	0x008e
                           00008D   514 _TF0	=	0x008d
                           00008C   515 _TR0	=	0x008c
                           00008B   516 _IE1	=	0x008b
                           00008A   517 _IT1	=	0x008a
                           000089   518 _IE0	=	0x0089
                           000088   519 _IT0	=	0x0088
                           00009F   520 _SM0	=	0x009f
                           00009E   521 _SM1	=	0x009e
                           00009D   522 _SM2	=	0x009d
                           00009C   523 _REN	=	0x009c
                           00009B   524 _TB8	=	0x009b
                           00009A   525 _RB8	=	0x009a
                           000099   526 _TI	=	0x0099
                           000098   527 _RI	=	0x0098
                           0000CF   528 _TF2	=	0x00cf
                           0000CF   529 _CAP1F	=	0x00cf
                           0000CE   530 _EXF2	=	0x00ce
                           0000CD   531 _RCLK	=	0x00cd
                           0000CC   532 _TCLK	=	0x00cc
                           0000CB   533 _EXEN2	=	0x00cb
                           0000CA   534 _TR2	=	0x00ca
                           0000C9   535 _C_T2	=	0x00c9
                           0000C8   536 _CP_RL2	=	0x00c8
                           0000FF   537 _S0_FST_ACT	=	0x00ff
                           0000FE   538 _S0_IF_OV	=	0x00fe
                           0000FD   539 _S0_IF_FIRST	=	0x00fd
                           0000FC   540 _S0_IF_BYTE	=	0x00fc
                           0000FB   541 _S0_FREE	=	0x00fb
                           0000FA   542 _S0_T_FIFO	=	0x00fa
                           0000F8   543 _S0_R_FIFO	=	0x00f8
                           0000F7   544 _ADC_START	=	0x00f7
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable register banks
                                    547 ;--------------------------------------------------------
                                    548 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        549 	.ds 8
                                    550 ;--------------------------------------------------------
                                    551 ; internal ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area DSEG    (DATA)
                                    554 ;--------------------------------------------------------
                                    555 ; overlayable items in internal ram
                                    556 ;--------------------------------------------------------
                                    557 ;--------------------------------------------------------
                                    558 ; indirectly addressable internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area ISEG    (DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; absolute internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area IABS    (ABS,DATA)
                                    565 	.area IABS    (ABS,DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; bit data
                                    568 ;--------------------------------------------------------
                                    569 	.area BSEG    (BIT)
      000023                        570 _get_record_keycode_sloc0_1_0:
      000023                        571 	.ds 1
      000024                        572 _pre_process_record_quantum_sloc0_1_0:
      000024                        573 	.ds 1
      000025                        574 _process_ak820_nkro_sloc0_1_0:
      000025                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; paged external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area PSEG    (PAG,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; uninitialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XSEG    (XDATA)
      000BE6                        584 _extract_mod_bits_code_10000_602:
      000BE6                        585 	.ds 2
      000BE8                        586 _register_code16_code_10000_608:
      000BE8                        587 	.ds 2
      000BEA                        588 _unregister_code16_code_10000_613:
      000BEA                        589 	.ds 2
      000BEC                        590 _get_record_keycode_PARM_2:
      000BEC                        591 	.ds 1
      000BED                        592 _get_record_keycode_record_argument_10000_651:
      000BED                        593 	.ds 2
      000BEF                        594 _pre_process_record_quantum_record_argument_10000_657:
      000BEF                        595 	.ds 2
      000BF1                        596 _process_record_quantum_record_10000_663:
      000BF1                        597 	.ds 2
      000BF3                        598 _process_ak820_nkro_PARM_2:
      000BF3                        599 	.ds 3
      000BF6                        600 _process_ak820_nkro_keycode_10000_665:
      000BF6                        601 	.ds 2
      000BF8                        602 _process_record_quantum_helper_PARM_2:
      000BF8                        603 	.ds 2
      000BFA                        604 _process_record_quantum_helper_keycode_10000_670:
      000BFA                        605 	.ds 2
      000BFC                        606 _get_u8_str_last_num_10000_696:
      000BFC                        607 	.ds 1
      000BFD                        608 _get_u16_str_last_num_10000_700:
      000BFD                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
                                    618 	.area HOME    (CODE)
                                    619 	.area GSINIT0 (CODE)
                                    620 	.area GSINIT1 (CODE)
                                    621 	.area GSINIT2 (CODE)
                                    622 	.area GSINIT3 (CODE)
                                    623 	.area GSINIT4 (CODE)
                                    624 	.area GSINIT5 (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area CSEG    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; global & static initialisations
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area GSINIT  (CODE)
                                    633 	.area GSFINAL (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 ;------------------------------------------------------------
                                    636 ;Allocation info for local variables in function 'get_u8_str'
                                    637 ;------------------------------------------------------------
                                    638 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    639 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_695'
                                    640 ;buf           Allocated with name '_get_u8_str_buf_10000_696'
                                    641 ;last_num      Allocated with name '_get_u8_str_last_num_10000_696'
                                    642 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_696'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0B FC         [24]  645 	mov	dptr,#_get_u8_str_last_num_10000_696
      0030F6 74 FF            [12]  646 	mov	a,#0xff
      0030F8 F0               [24]  647 	movx	@dptr,a
                                    648 ;------------------------------------------------------------
                                    649 ;Allocation info for local variables in function 'get_u16_str'
                                    650 ;------------------------------------------------------------
                                    651 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    652 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_699'
                                    653 ;buf           Allocated with name '_get_u16_str_buf_10000_700'
                                    654 ;last_num      Allocated with name '_get_u16_str_last_num_10000_700'
                                    655 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_700'
                                    656 ;------------------------------------------------------------
                                    657 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0B FD         [24]  658 	mov	dptr,#_get_u16_str_last_num_10000_700
      0030FC 74 FF            [12]  659 	mov	a,#0xff
      0030FE F0               [24]  660 	movx	@dptr,a
      0030FF E4               [12]  661 	clr	a
      003100 A3               [24]  662 	inc	dptr
      003101 F0               [24]  663 	movx	@dptr,a
                                    664 ;--------------------------------------------------------
                                    665 ; Home
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area HOME    (CODE)
                                    669 ;--------------------------------------------------------
                                    670 ; code
                                    671 ;--------------------------------------------------------
                                    672 	.area CSEG    (CODE)
                                    673 ;------------------------------------------------------------
                                    674 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    675 ;------------------------------------------------------------
                                    676 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    679 ;	-----------------------------------------
                           000007   680 	ar7 = 0x07
                           000006   681 	ar6 = 0x06
                           000005   682 	ar5 = 0x05
                           000004   683 	ar4 = 0x04
                           000003   684 	ar3 = 0x03
                           000002   685 	ar2 = 0x02
                           000001   686 	ar1 = 0x01
                           000000   687 	ar0 = 0x00
                                    688 ;	 function extract_mod_bits
                                    689 ;	-----------------------------------------
      009E2F                        690 _extract_mod_bits:
      009E2F 12 38 4B         [24]  691 	lcall	_ak820_outline_0104
      009E32 90 0B E6         [24]  692 	mov	dptr,#_extract_mod_bits_code_10000_602
      009E35 12 38 50         [24]  693 	lcall	_ak820_outline_0105
                                    694 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      009E38 90 0B E6         [24]  695 	mov	dptr,#_extract_mod_bits_code_10000_602
      009E3B E0               [24]  696 	movx	a,@dptr
      009E3C A3               [24]  697 	inc	dptr
      009E3D E0               [24]  698 	movx	a,@dptr
                                    699 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009E3E FF               [12]  700 	mov	r7,a
      009E3F 60 05            [24]  701 	jz	00101$
      009E41 EF               [12]  702 	mov	a,r7
      009E42 24 E0            [12]  703 	add	a,#0xff - 0x1f
      009E44 50 04            [24]  704 	jnc	00102$
                                    705 ;	free result
      009E46                        706 00101$:
      009E46 75 82 00         [24]  707 	mov	dpl, #0x00
      009E49 22               [24]  708 	ret
      009E4A                        709 00102$:
                                    710 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009E4A EF               [12]  711 	mov	a,r7
      009E4B 30 E4 07         [24]  712 	jnb	acc.4,00106$
      009E4E EF               [12]  713 	mov	a,r7
      009E4F C4               [12]  714 	swap	a
      009E50 54 F0            [12]  715 	anl	a,#0xf0
      009E52 FE               [12]  716 	mov	r6,a
      009E53 80 02            [24]  717 	sjmp	00107$
      009E55                        718 00106$:
      009E55 8F 06            [24]  719 	mov	ar6,r7
      009E57                        720 00107$:
      009E57 8E 82            [24]  721 	mov	dpl, r6
                                    722 ;	quantum/quantum.c:143: }
      009E59 22               [24]  723 	ret
                                    724 ;------------------------------------------------------------
                                    725 ;Allocation info for local variables in function 'do_code16'
                                    726 ;------------------------------------------------------------
                                    727 ;f             Allocated with name '_do_code16_PARM_2'
                                    728 ;code          Allocated with name '_do_code16_code_10000_605'
                                    729 ;------------------------------------------------------------
                                    730 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    731 ;	-----------------------------------------
                                    732 ;	 function register_code16
                                    733 ;	-----------------------------------------
      009E5A                        734 _register_code16:
      009E5A 12 38 4B         [24]  735 	lcall	_ak820_outline_0104
      009E5D 90 0B E8         [24]  736 	mov	dptr,#_register_code16_code_10000_608
      009E60 12 38 50         [24]  737 	lcall	_ak820_outline_0105
                                    738 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      009E63 90 0B E8         [24]  739 	mov	dptr,#_register_code16_code_10000_608
      009E66 12 37 A1         [24]  740 	lcall	_ak820_outline_0004
      009E69 C0 07            [24]  741 	push	ar7
      009E6B C0 06            [24]  742 	push	ar6
      009E6D 12 9E 2F         [24]  743 	lcall	_extract_mod_bits
      009E70 AD 82            [24]  744 	mov	r5, dpl
      009E72 D0 06            [24]  745 	pop	ar6
      009E74 D0 07            [24]  746 	pop	ar7
                                    747 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009E76 12 9C 6F         [24]  748 	lcall	_ak820_outline_0115
      009E79 40 07            [24]  749 	jc	00105$
      009E7B 74 E7            [12]  750 	mov	a,#0xe7
      009E7D 9E               [12]  751 	subb	a,r6
      009E7E E4               [12]  752 	clr	a
      009E7F 9F               [12]  753 	subb	a,r7
      009E80 50 08            [24]  754 	jnc	00101$
                                    755 ;	free result
      009E82                        756 00105$:
      009E82 90 0B E8         [24]  757 	mov	dptr,#_register_code16_code_10000_608
      009E85 12 6F 32         [24]  758 	lcall	_ak820_outline_0035
      009E88 70 07            [24]  759 	jnz	00102$
      009E8A                        760 00101$:
                                    761 ;	quantum/quantum.c:153: register_mods(mods);
      009E8A 8D 82            [24]  762 	mov	dpl, r5
      009E8C 12 77 AD         [24]  763 	lcall	_register_mods
      009E8F 80 05            [24]  764 	sjmp	00103$
      009E91                        765 00102$:
                                    766 ;	quantum/quantum.c:155: register_weak_mods(mods);
      009E91 8D 82            [24]  767 	mov	dpl, r5
      009E93 12 77 D5         [24]  768 	lcall	_register_weak_mods
      009E96                        769 00103$:
                                    770 ;	quantum/quantum.c:157: register_code(code);
      009E96 90 0B E8         [24]  771 	mov	dptr,#_register_code16_code_10000_608
      009E99 E0               [24]  772 	movx	a,@dptr
      009E9A F5 82            [12]  773 	mov	dpl,a
                                    774 ;	quantum/quantum.c:167: }
      009E9C 02 76 8A         [24]  775 	ljmp	_register_code
                                    776 ;------------------------------------------------------------
                                    777 ;Allocation info for local variables in function 'unregister_code16'
                                    778 ;------------------------------------------------------------
                                    779 ;code          Allocated with name '_unregister_code16_code_10000_613'
                                    780 ;mods          Allocated with name '_unregister_code16_mods_10000_614'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function unregister_code16
                                    785 ;	-----------------------------------------
      009E9F                        786 _unregister_code16:
      009E9F 12 38 4B         [24]  787 	lcall	_ak820_outline_0104
      009EA2 90 0B EA         [24]  788 	mov	dptr,#_unregister_code16_code_10000_613
      009EA5 12 38 50         [24]  789 	lcall	_ak820_outline_0105
                                    790 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      009EA8 90 0B EA         [24]  791 	mov	dptr,#_unregister_code16_code_10000_613
      009EAB 12 37 A1         [24]  792 	lcall	_ak820_outline_0004
      009EAE C0 07            [24]  793 	push	ar7
      009EB0 C0 06            [24]  794 	push	ar6
      009EB2 12 9E 2F         [24]  795 	lcall	_extract_mod_bits
      009EB5 AD 82            [24]  796 	mov	r5, dpl
      009EB7 D0 06            [24]  797 	pop	ar6
                                    798 ;	quantum/quantum.c:172: unregister_code(code);
      009EB9 8E 04            [24]  799 	mov	ar4,r6
      009EBB 8C 82            [24]  800 	mov	dpl, r4
      009EBD C0 06            [24]  801 	push	ar6
      009EBF C0 05            [24]  802 	push	ar5
      009EC1 12 76 F7         [24]  803 	lcall	_unregister_code
      009EC4 D0 05            [24]  804 	pop	ar5
      009EC6 D0 06            [24]  805 	pop	ar6
      009EC8 D0 07            [24]  806 	pop	ar7
                                    807 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009ECA 12 9C 6F         [24]  808 	lcall	_ak820_outline_0115
      009ECD 40 07            [24]  809 	jc	00105$
      009ECF 74 E7            [12]  810 	mov	a,#0xe7
      009ED1 9E               [12]  811 	subb	a,r6
      009ED2 E4               [12]  812 	clr	a
      009ED3 9F               [12]  813 	subb	a,r7
      009ED4 50 08            [24]  814 	jnc	00101$
                                    815 ;	free result
      009ED6                        816 00105$:
      009ED6 90 0B EA         [24]  817 	mov	dptr,#_unregister_code16_code_10000_613
      009ED9 12 6F 32         [24]  818 	lcall	_ak820_outline_0035
      009EDC 70 05            [24]  819 	jnz	00102$
      009EDE                        820 00101$:
                                    821 ;	quantum/quantum.c:174: unregister_mods(mods);
      009EDE 8D 82            [24]  822 	mov	dpl, r5
      009EE0 02 77 C1         [24]  823 	ljmp	_unregister_mods
      009EE3                        824 00102$:
                                    825 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      009EE3 8D 82            [24]  826 	mov	dpl, r5
                                    827 ;	quantum/quantum.c:187: }
      009EE5 02 77 E9         [24]  828 	ljmp	_unregister_weak_mods
                                    829 ;------------------------------------------------------------
                                    830 ;Allocation info for local variables in function 'tap_code16_delay'
                                    831 ;------------------------------------------------------------
                                    832 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    833 ;code          Allocated with name '_tap_code16_delay_code_10000_618'
                                    834 ;i             Allocated with name '_tap_code16_delay_i_20000_620'
                                    835 ;i             Allocated with name '_tap_code16_delay_i_50000_623'
                                    836 ;------------------------------------------------------------
                                    837 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    838 ;	-----------------------------------------
                                    839 ;	 function shutdown_quantum
                                    840 ;	-----------------------------------------
      009EE8                        841 _shutdown_quantum:
                                    842 ;	quantum/quantum.c:237: clear_keyboard();
      009EE8 12 77 FD         [24]  843 	lcall	_clear_keyboard
                                    844 ;	quantum/quantum.c:252: shutdown_user();
      009EEB 12 A1 BE         [24]  845 	lcall	_shutdown_user
                                    846 ;	quantum/quantum.c:253: wait_ms(250);
      009EEE 7F FA            [12]  847 	mov	r7,#0xfa
      009EF0                        848 00106$:
      009EF0 EF               [12]  849 	mov	a,r7
      009EF1 60 09            [24]  850 	jz	00108$
      009EF3 90 00 01         [24]  851 	mov	dptr,#0x0001
      009EF6 12 5A 9E         [24]  852 	lcall	_mDelaymS
      009EF9 1F               [12]  853 	dec	r7
      009EFA 80 F4            [24]  854 	sjmp	00106$
      009EFC                        855 00108$:
                                    856 ;	quantum/quantum.c:258: }
      009EFC 22               [24]  857 	ret
                                    858 ;------------------------------------------------------------
                                    859 ;Allocation info for local variables in function 'reset_keyboard'
                                    860 ;------------------------------------------------------------
                                    861 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    862 ;	-----------------------------------------
                                    863 ;	 function reset_keyboard
                                    864 ;	-----------------------------------------
      009EFD                        865 _reset_keyboard:
                                    866 ;	quantum/quantum.c:261: shutdown_quantum();
      009EFD 12 9E E8         [24]  867 	lcall	_shutdown_quantum
                                    868 ;	quantum/quantum.c:262: bootloader_jump();
                                    869 ;	quantum/quantum.c:263: }
      009F00 02 34 0E         [24]  870 	ljmp	_bootloader_jump
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function soft_reset_keyboard
                                    877 ;	-----------------------------------------
      009F03                        878 _soft_reset_keyboard:
                                    879 ;	quantum/quantum.c:266: shutdown_quantum();
      009F03 12 9E E8         [24]  880 	lcall	_shutdown_quantum
                                    881 ;	quantum/quantum.c:267: mcu_reset();
                                    882 ;	quantum/quantum.c:268: }
      009F06 02 34 01         [24]  883 	ljmp	_mcu_reset
                                    884 ;------------------------------------------------------------
                                    885 ;Allocation info for local variables in function 'get_record_keycode'
                                    886 ;------------------------------------------------------------
                                    887 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    888 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_651'
                                    889 ;record        Allocated with name '_get_record_keycode_record_10000_652'
                                    890 ;------------------------------------------------------------
                                    891 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    892 ;	-----------------------------------------
                                    893 ;	 function get_record_keycode
                                    894 ;	-----------------------------------------
      009F09                        895 _get_record_keycode:
      009F09 12 38 4B         [24]  896 	lcall	_ak820_outline_0104
      009F0C 90 0B ED         [24]  897 	mov	dptr,#_get_record_keycode_record_argument_10000_651
      009F0F 12 38 50         [24]  898 	lcall	_ak820_outline_0105
                                    899 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009F12 90 0B ED         [24]  900 	mov	dptr,#_get_record_keycode_record_argument_10000_651
      009F15 12 37 B8         [24]  901 	lcall	_ak820_outline_0008
                                    902 ;	quantum/quantum.c:278: if (record->keycode) {
      009F18 4C               [12]  903 	orl	a,r4
      009F19 60 04            [24]  904 	jz	00102$
                                    905 ;	quantum/quantum.c:279: return record->keycode;
      009F1B 12 38 55         [24]  906 	lcall	_ak820_outline_0117
      009F1E 22               [24]  907 	ret
      009F1F                        908 00102$:
                                    909 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009F1F 12 78 42         [24]  910 	lcall	_ak820_outline_0019
      009F22 7A 00            [12]  911 	mov	r2,#0x00
      009F24 12 45 70         [24]  912 	lcall	_ak820_outline_0138
      009F27 12 37 AB         [24]  913 	lcall	_ak820_outline_0005
      009F2A 60 06            [24]  914 	jz	00105$
      009F2C 90 0B EC         [24]  915 	mov	dptr,#_get_record_keycode_PARM_2
      009F2F E0               [24]  916 	movx	a,@dptr
      009F30 70 04            [24]  917 	jnz	00106$
      009F32                        918 00105$:
                                    919 ;	assignBit
      009F32 C2 23            [12]  920 	clr	_get_record_keycode_sloc0_1_0
      009F34 80 02            [24]  921 	sjmp	00107$
      009F36                        922 00106$:
                                    923 ;	assignBit
      009F36 D2 23            [12]  924 	setb	_get_record_keycode_sloc0_1_0
      009F38                        925 00107$:
      009F38 90 09 7C         [24]  926 	mov	dptr,#_ak820_resolve_key_PARM_2
      009F3B A2 23            [12]  927 	mov	c,_get_record_keycode_sloc0_1_0
      009F3D E4               [12]  928 	clr	a
      009F3E 33               [12]  929 	rlc	a
      009F3F F0               [24]  930 	movx	@dptr,a
      009F40 8D 82            [24]  931 	mov	dpl, r5
      009F42 8C 83            [24]  932 	mov	dph, r4
                                    933 ;	quantum/quantum.c:287: }
      009F44 02 7B DF         [24]  934 	ljmp	_ak820_resolve_key
                                    935 ;------------------------------------------------------------
                                    936 ;Allocation info for local variables in function 'get_event_keycode'
                                    937 ;------------------------------------------------------------
                                    938 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    939 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_655'
                                    940 ;------------------------------------------------------------
                                    941 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    942 ;	-----------------------------------------
                                    943 ;	 function pre_process_record_quantum
                                    944 ;	-----------------------------------------
      009F47                        945 _pre_process_record_quantum:
      009F47 12 38 4B         [24]  946 	lcall	_ak820_outline_0104
      009F4A 90 0B EF         [24]  947 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
      009F4D 12 38 50         [24]  948 	lcall	_ak820_outline_0105
                                    949 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009F50 90 0B EF         [24]  950 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
      009F53 12 38 01         [24]  951 	lcall	_ak820_outline_0050
                                    952 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      009F56 90 0B EC         [24]  953 	mov	dptr,#_get_record_keycode_PARM_2
      009F59 12 4A 6D         [24]  954 	lcall	_ak820_outline_0054
      009F5C C0 07            [24]  955 	push	ar7
      009F5E C0 06            [24]  956 	push	ar6
      009F60 12 9F 09         [24]  957 	lcall	_get_record_keycode
      009F63 12 45 7B         [24]  958 	lcall	_ak820_outline_0144
      009F66 D0 06            [24]  959 	pop	ar6
      009F68 D0 07            [24]  960 	pop	ar7
                                    961 ;	quantum/quantum.c:334: record->keycode = keycode;
      009F6A 74 07            [12]  962 	mov	a,#0x07
      009F6C 12 37 F9         [24]  963 	lcall	_ak820_outline_0030
      009F6F 12 38 26         [24]  964 	lcall	_ak820_outline_0070
                                    965 ;	quantum/quantum.c:339: if (keycode == QK_LEAD && record->event.pressed && record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS)
      009F72 BC 58 38         [24]  966 	cjne	r4,#0x58,00102$
      009F75 BD 7C 35         [24]  967 	cjne	r5,#0x7c,00102$
      009F78 74 05            [12]  968 	mov	a,#0x05
      009F7A 12 4A 23         [24]  969 	lcall	_ak820_outline_0010
      009F7D 60 2E            [24]  970 	jz	00102$
      009F7F 12 38 32         [24]  971 	lcall	_ak820_outline_0091
      009F82 FD               [12]  972 	mov	r5,a
      009F83 BD 10 00         [24]  973 	cjne	r5,#0x10,00158$
      009F86                        974 00158$:
      009F86 50 25            [24]  975 	jnc	00102$
      009F88 12 38 39         [24]  976 	lcall	_ak820_outline_0097
      009F8B FD               [12]  977 	mov	r5,a
      009F8C BD 08 00         [24]  978 	cjne	r5,#0x08,00160$
      009F8F                        979 00160$:
      009F8F 50 1C            [24]  980 	jnc	00102$
                                    981 ;	quantum/quantum.c:340: ak820_combo_tick(record->event.time +
      009F91 12 37 F1         [24]  982 	lcall	_ak820_outline_0029
      009F94 FC               [12]  983 	mov	r4,a
      009F95 A3               [24]  984 	inc	dptr
      009F96 E0               [24]  985 	movx	a,@dptr
      009F97 FD               [12]  986 	mov	r5,a
      009F98 74 28            [12]  987 	mov	a,#0x28
      009F9A 2C               [12]  988 	add	a, r4
      009F9B FC               [12]  989 	mov	r4,a
      009F9C E4               [12]  990 	clr	a
      009F9D 3D               [12]  991 	addc	a, r5
      009F9E FD               [12]  992 	mov	r5,a
      009F9F 12 38 55         [24]  993 	lcall	_ak820_outline_0117
      009FA2 C0 07            [24]  994 	push	ar7
      009FA4 C0 06            [24]  995 	push	ar6
      009FA6 12 35 B8         [24]  996 	lcall	_ak820_combo_tick
      009FA9 D0 06            [24]  997 	pop	ar6
      009FAB D0 07            [24]  998 	pop	ar7
      009FAD                        999 00102$:
                                   1000 ;	quantum/quantum.c:348: if (!ak820_leader_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      009FAD 12 45 5A         [24] 1001 	lcall	_ak820_outline_0114
      009FB0 C0 07            [24] 1002 	push	ar7
      009FB2 C0 06            [24] 1003 	push	ar6
      009FB4 12 3B D8         [24] 1004 	lcall	_ak820_leader_process
      009FB7 E5 82            [12] 1005 	mov	a, dpl
      009FB9 D0 06            [24] 1006 	pop	ar6
      009FBB D0 07            [24] 1007 	pop	ar7
      009FBD 70 03            [24] 1008 	jnz	00107$
      009FBF F5 82            [12] 1009 	mov	dpl,a
      009FC1 22               [24] 1010 	ret
      009FC2                       1011 00107$:
                                   1012 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009FC2 12 45 5A         [24] 1013 	lcall	_ak820_outline_0114
      009FC5 12 35 EF         [24] 1014 	lcall	_ak820_combo_process
      009FC8 E5 82            [12] 1015 	mov	a, dpl
      009FCA 70 04            [24] 1016 	jnz	00111$
                                   1017 ;	quantum/quantum.c:366: true;
                                   1018 ;	assignBit
      009FCC C2 24            [12] 1019 	clr	_pre_process_record_quantum_sloc0_1_0
      009FCE 80 02            [24] 1020 	sjmp	00112$
      009FD0                       1021 00111$:
                                   1022 ;	assignBit
      009FD0 D2 24            [12] 1023 	setb	_pre_process_record_quantum_sloc0_1_0
      009FD2                       1024 00112$:
      009FD2 A2 24            [12] 1025 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009FD4 12 38 81         [24] 1026 	lcall	_ak820_outline_0166
                                   1027 ;	quantum/quantum.c:367: }
      009FD7 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1031 ;------------------------------------------------------------
                                   1032 ;record        Allocated with name '_post_process_record_quantum_record_10000_661'
                                   1033 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_662'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function process_record_quantum
                                   1038 ;	-----------------------------------------
      009FD8                       1039 _process_record_quantum:
      009FD8 12 38 4B         [24] 1040 	lcall	_ak820_outline_0104
      009FDB 90 0B F1         [24] 1041 	mov	dptr,#_process_record_quantum_record_10000_663
      009FDE 12 38 50         [24] 1042 	lcall	_ak820_outline_0105
                                   1043 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      009FE1 90 0B F1         [24] 1044 	mov	dptr,#_process_record_quantum_record_10000_663
      009FE4 12 38 01         [24] 1045 	lcall	_ak820_outline_0050
      009FE7 90 0B EC         [24] 1046 	mov	dptr,#_get_record_keycode_PARM_2
      009FEA E4               [12] 1047 	clr	a
      009FEB 12 45 35         [24] 1048 	lcall	_ak820_outline_0061
      009FEE 12 9F 09         [24] 1049 	lcall	_get_record_keycode
      009FF1 12 45 65         [24] 1050 	lcall	_ak820_outline_0130
                                   1051 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      009FF4 90 0B F1         [24] 1052 	mov	dptr,#_process_record_quantum_record_10000_663
      009FF7 12 38 20         [24] 1053 	lcall	_ak820_outline_0059
      009FFA 90 0B F8         [24] 1054 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009FFD EC               [12] 1055 	mov	a,r4
      009FFE F0               [24] 1056 	movx	@dptr,a
      009FFF ED               [12] 1057 	mov	a,r5
      00A000 A3               [24] 1058 	inc	dptr
      00A001 12 45 35         [24] 1059 	lcall	_ak820_outline_0061
                                   1060 ;	quantum/quantum.c:382: }
      00A004 02 A0 72         [24] 1061 	ljmp	_process_record_quantum_helper
                                   1062 ;------------------------------------------------------------
                                   1063 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1064 ;------------------------------------------------------------
                                   1065 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1066 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_665'
                                   1067 ;record        Allocated with name '_process_ak820_nkro_record_10000_666'
                                   1068 ;------------------------------------------------------------
                                   1069 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1070 ;	-----------------------------------------
                                   1071 ;	 function process_ak820_nkro
                                   1072 ;	-----------------------------------------
      00A007                       1073 _process_ak820_nkro:
      00A007 12 38 4B         [24] 1074 	lcall	_ak820_outline_0104
      00A00A 90 0B F6         [24] 1075 	mov	dptr,#_process_ak820_nkro_keycode_10000_665
      00A00D 12 38 50         [24] 1076 	lcall	_ak820_outline_0105
                                   1077 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A010 90 0B F3         [24] 1078 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A013 12 38 01         [24] 1079 	lcall	_ak820_outline_0050
                                   1080 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A016 90 0B F6         [24] 1081 	mov	dptr,#_process_ak820_nkro_keycode_10000_665
      00A019 12 38 20         [24] 1082 	lcall	_ak820_outline_0059
      00A01C C3               [12] 1083 	clr	c
      00A01D EC               [12] 1084 	mov	a,r4
      00A01E 94 11            [12] 1085 	subb	a,#0x11
      00A020 ED               [12] 1086 	mov	a,r5
      00A021 94 70            [12] 1087 	subb	a,#0x70
      00A023 40 08            [24] 1088 	jc	00101$
      00A025 74 13            [12] 1089 	mov	a,#0x13
      00A027 9C               [12] 1090 	subb	a,r4
      00A028 74 70            [12] 1091 	mov	a,#0x70
      00A02A 9D               [12] 1092 	subb	a,r5
      00A02B 50 04            [24] 1093 	jnc	00102$
                                   1094 ;	free result
      00A02D                       1095 00101$:
      00A02D 75 82 01         [24] 1096 	mov	dpl, #0x01
      00A030 22               [24] 1097 	ret
      00A031                       1098 00102$:
                                   1099 ;	quantum/quantum.c:406: if (record->event.pressed) {
      00A031 12 37 AB         [24] 1100 	lcall	_ak820_outline_0005
      00A034 60 38            [24] 1101 	jz	00105$
                                   1102 ;	quantum/quantum.c:407: clear_keyboard();
      00A036 C0 05            [24] 1103 	push	ar5
      00A038 C0 04            [24] 1104 	push	ar4
      00A03A 12 77 FD         [24] 1105 	lcall	_clear_keyboard
      00A03D D0 04            [24] 1106 	pop	ar4
      00A03F D0 05            [24] 1107 	pop	ar5
                                   1108 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A041 BC 13 14         [24] 1109 	cjne	r4,#0x13,00108$
      00A044 BD 70 11         [24] 1110 	cjne	r5,#0x70,00108$
      00A047 90 0A CE         [24] 1111 	mov	dptr,#_keymap_config
      00A04A E0               [24] 1112 	movx	a,@dptr
      00A04B 23               [12] 1113 	rl	a
      00A04C 54 01            [12] 1114 	anl	a,#0x01
      00A04E B4 01 00         [24] 1115 	cjne	a,#0x01,00136$
      00A051                       1116 00136$:
      00A051 92 25            [24] 1117 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A053 E4               [12] 1118 	clr	a
      00A054 33               [12] 1119 	rlc	a
      00A055 FF               [12] 1120 	mov	r7,a
      00A056 80 09            [24] 1121 	sjmp	00109$
      00A058                       1122 00108$:
      00A058 E4               [12] 1123 	clr	a
      00A059 BC 11 04         [24] 1124 	cjne	r4,#0x11,00137$
      00A05C BD 70 01         [24] 1125 	cjne	r5,#0x70,00137$
      00A05F 04               [12] 1126 	inc	a
      00A060                       1127 00137$:
      00A060 FF               [12] 1128 	mov	r7,a
      00A061                       1129 00109$:
                                   1130 ;	assignBit
      00A061 EF               [12] 1131 	mov	a,r7
      00A062 24 FF            [12] 1132 	add	a,#0xff
      00A064 E4               [12] 1133 	clr	a
      00A065 33               [12] 1134 	rlc	a
      00A066 90 0A CE         [24] 1135 	mov	dptr,#_keymap_config
      00A069 13               [12] 1136 	rrc	a
      00A06A E0               [24] 1137 	movx	a,@dptr
      00A06B 92 E7            [24] 1138 	mov	acc.7,c
      00A06D F0               [24] 1139 	movx	@dptr,a
      00A06E                       1140 00105$:
                                   1141 ;	quantum/quantum.c:410: return false;
      00A06E 75 82 00         [24] 1142 	mov	dpl, #0x00
                                   1143 ;	quantum/quantum.c:411: }
      00A071 22               [24] 1144 	ret
                                   1145 ;------------------------------------------------------------
                                   1146 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1147 ;------------------------------------------------------------
                                   1148 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1149 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_670'
                                   1150 ;record        Allocated with name '_process_record_quantum_helper_record_10000_671'
                                   1151 ;------------------------------------------------------------
                                   1152 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1153 ;	-----------------------------------------
                                   1154 ;	 function process_record_quantum_helper
                                   1155 ;	-----------------------------------------
      00A072                       1156 _process_record_quantum_helper:
      00A072 12 38 4B         [24] 1157 	lcall	_ak820_outline_0104
      00A075 90 0B FA         [24] 1158 	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
      00A078 12 38 50         [24] 1159 	lcall	_ak820_outline_0105
                                   1160 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A07B 90 0B F8         [24] 1161 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A07E 12 38 01         [24] 1162 	lcall	_ak820_outline_0050
                                   1163 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      00A081 90 0B FA         [24] 1164 	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
      00A084 12 38 20         [24] 1165 	lcall	_ak820_outline_0059
      00A087 90 0B F3         [24] 1166 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A08A 12 A1 BF         [24] 1167 	lcall	_ak820_outline_0006
      00A08D C0 07            [24] 1168 	push	ar7
      00A08F C0 06            [24] 1169 	push	ar6
      00A091 C0 05            [24] 1170 	push	ar5
      00A093 C0 04            [24] 1171 	push	ar4
      00A095 12 A0 07         [24] 1172 	lcall	_process_ak820_nkro
      00A098 E5 82            [12] 1173 	mov	a, dpl
      00A09A D0 04            [24] 1174 	pop	ar4
      00A09C D0 05            [24] 1175 	pop	ar5
      00A09E D0 06            [24] 1176 	pop	ar6
      00A0A0 D0 07            [24] 1177 	pop	ar7
      00A0A2 70 03            [24] 1178 	jnz	00196$
      00A0A4 02 A1 81         [24] 1179 	ljmp	00101$
      00A0A7                       1180 00196$:
                                   1181 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A0A7 90 0B D1         [24] 1182 	mov	dptr,#_process_last_key_PARM_2
      00A0AA 12 4A 7D         [24] 1183 	lcall	_ak820_outline_0058
      00A0AD 12 38 55         [24] 1184 	lcall	_ak820_outline_0117
      00A0B0 C0 07            [24] 1185 	push	ar7
      00A0B2 C0 06            [24] 1186 	push	ar6
      00A0B4 C0 05            [24] 1187 	push	ar5
      00A0B6 C0 04            [24] 1188 	push	ar4
      00A0B8 12 9B AF         [24] 1189 	lcall	_process_last_key
      00A0BB E5 82            [12] 1190 	mov	a, dpl
      00A0BD D0 04            [24] 1191 	pop	ar4
      00A0BF D0 05            [24] 1192 	pop	ar5
      00A0C1 D0 06            [24] 1193 	pop	ar6
      00A0C3 D0 07            [24] 1194 	pop	ar7
      00A0C5 70 03            [24] 1195 	jnz	00197$
      00A0C7 02 A1 81         [24] 1196 	ljmp	00101$
      00A0CA                       1197 00197$:
      00A0CA 90 0B D6         [24] 1198 	mov	dptr,#_process_repeat_key_PARM_2
      00A0CD 12 4A 7D         [24] 1199 	lcall	_ak820_outline_0058
      00A0D0 12 38 55         [24] 1200 	lcall	_ak820_outline_0117
      00A0D3 C0 07            [24] 1201 	push	ar7
      00A0D5 C0 06            [24] 1202 	push	ar6
      00A0D7 C0 05            [24] 1203 	push	ar5
      00A0D9 C0 04            [24] 1204 	push	ar4
      00A0DB 12 9C 28         [24] 1205 	lcall	_process_repeat_key
      00A0DE E5 82            [12] 1206 	mov	a, dpl
      00A0E0 D0 04            [24] 1207 	pop	ar4
      00A0E2 D0 05            [24] 1208 	pop	ar5
      00A0E4 D0 06            [24] 1209 	pop	ar6
      00A0E6 D0 07            [24] 1210 	pop	ar7
      00A0E8 70 03            [24] 1211 	jnz	00198$
      00A0EA 02 A1 81         [24] 1212 	ljmp	00101$
      00A0ED                       1213 00198$:
                                   1214 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A0ED 90 0C 33         [24] 1215 	mov	dptr,#_process_record_via_PARM_2
      00A0F0 12 A1 BF         [24] 1216 	lcall	_ak820_outline_0006
      00A0F3 C0 07            [24] 1217 	push	ar7
      00A0F5 C0 06            [24] 1218 	push	ar6
      00A0F7 C0 05            [24] 1219 	push	ar5
      00A0F9 C0 04            [24] 1220 	push	ar4
      00A0FB 12 A6 AC         [24] 1221 	lcall	_process_record_via
      00A0FE E5 82            [12] 1222 	mov	a, dpl
      00A100 D0 04            [24] 1223 	pop	ar4
      00A102 D0 05            [24] 1224 	pop	ar5
      00A104 D0 06            [24] 1225 	pop	ar6
      00A106 D0 07            [24] 1226 	pop	ar7
      00A108 70 03            [24] 1227 	jnz	00199$
      00A10A 02 A1 81         [24] 1228 	ljmp	00101$
      00A10D                       1229 00199$:
                                   1230 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A10D 90 0B BA         [24] 1231 	mov	dptr,#_process_caps_word_PARM_2
      00A110 12 A1 BF         [24] 1232 	lcall	_ak820_outline_0006
      00A113 C0 07            [24] 1233 	push	ar7
      00A115 C0 06            [24] 1234 	push	ar6
      00A117 C0 05            [24] 1235 	push	ar5
      00A119 C0 04            [24] 1236 	push	ar4
      00A11B 12 99 4E         [24] 1237 	lcall	_process_caps_word
      00A11E E5 82            [12] 1238 	mov	a, dpl
      00A120 D0 04            [24] 1239 	pop	ar4
      00A122 D0 05            [24] 1240 	pop	ar5
      00A124 D0 06            [24] 1241 	pop	ar6
      00A126 D0 07            [24] 1242 	pop	ar7
      00A128 60 57            [24] 1243 	jz	00101$
                                   1244 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A12A 90 0B BF         [24] 1245 	mov	dptr,#_process_grave_esc_PARM_2
      00A12D 12 A1 BF         [24] 1246 	lcall	_ak820_outline_0006
      00A130 C0 07            [24] 1247 	push	ar7
      00A132 C0 06            [24] 1248 	push	ar6
      00A134 C0 05            [24] 1249 	push	ar5
      00A136 C0 04            [24] 1250 	push	ar4
      00A138 12 9A 61         [24] 1251 	lcall	_process_grave_esc
      00A13B E5 82            [12] 1252 	mov	a, dpl
      00A13D D0 04            [24] 1253 	pop	ar4
      00A13F D0 05            [24] 1254 	pop	ar5
      00A141 D0 06            [24] 1255 	pop	ar6
      00A143 D0 07            [24] 1256 	pop	ar7
      00A145 60 3A            [24] 1257 	jz	00101$
                                   1258 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A147 90 0B DA         [24] 1259 	mov	dptr,#_process_rgb_PARM_2
      00A14A 12 A1 BF         [24] 1260 	lcall	_ak820_outline_0006
      00A14D C0 07            [24] 1261 	push	ar7
      00A14F C0 06            [24] 1262 	push	ar6
      00A151 C0 05            [24] 1263 	push	ar5
      00A153 C0 04            [24] 1264 	push	ar4
      00A155 12 9C 77         [24] 1265 	lcall	_process_rgb
      00A158 E5 82            [12] 1266 	mov	a, dpl
      00A15A D0 04            [24] 1267 	pop	ar4
      00A15C D0 05            [24] 1268 	pop	ar5
      00A15E D0 06            [24] 1269 	pop	ar6
      00A160 D0 07            [24] 1270 	pop	ar7
      00A162 60 1D            [24] 1271 	jz	00101$
                                   1272 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A164 90 0B E0         [24] 1273 	mov	dptr,#_process_tri_layer_PARM_2
      00A167 12 A1 BF         [24] 1274 	lcall	_ak820_outline_0006
      00A16A C0 07            [24] 1275 	push	ar7
      00A16C C0 06            [24] 1276 	push	ar6
      00A16E C0 05            [24] 1277 	push	ar5
      00A170 C0 04            [24] 1278 	push	ar4
      00A172 12 9D 28         [24] 1279 	lcall	_process_tri_layer
      00A175 E5 82            [12] 1280 	mov	a, dpl
      00A177 D0 04            [24] 1281 	pop	ar4
      00A179 D0 05            [24] 1282 	pop	ar5
      00A17B D0 06            [24] 1283 	pop	ar6
      00A17D D0 07            [24] 1284 	pop	ar7
      00A17F 70 04            [24] 1285 	jnz	00102$
                                   1286 ;	quantum/quantum.c:561: true)) {
      00A181                       1287 00101$:
                                   1288 ;	quantum/quantum.c:562: return false;
      00A181 75 82 00         [24] 1289 	mov	dpl, #0x00
      00A184 22               [24] 1290 	ret
      00A185                       1291 00102$:
                                   1292 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A185 12 37 AB         [24] 1293 	lcall	_ak820_outline_0005
      00A188 60 30            [24] 1294 	jz	00116$
                                   1295 ;	quantum/quantum.c:566: switch (keycode) {
      00A18A BC 00 05         [24] 1296 	cjne	r4,#0x00,00205$
      00A18D BD 7C 02         [24] 1297 	cjne	r5,#0x7c,00205$
      00A190 80 10            [24] 1298 	sjmp	00111$
      00A192                       1299 00205$:
      00A192 BC 01 05         [24] 1300 	cjne	r4,#0x01,00206$
      00A195 BD 7C 02         [24] 1301 	cjne	r5,#0x7c,00206$
      00A198 80 0F            [24] 1302 	sjmp	00112$
      00A19A                       1303 00206$:
                                   1304 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A19A BC 03 1D         [24] 1305 	cjne	r4,#0x03,00116$
      00A19D BD 7C 1A         [24] 1306 	cjne	r5,#0x7c,00116$
      00A1A0 80 0E            [24] 1307 	sjmp	00113$
      00A1A2                       1308 00111$:
                                   1309 ;	quantum/quantum.c:569: reset_keyboard();
      00A1A2 12 9E FD         [24] 1310 	lcall	_reset_keyboard
                                   1311 ;	quantum/quantum.c:570: return false;
      00A1A5 75 82 00         [24] 1312 	mov	dpl, #0x00
                                   1313 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A1A8 22               [24] 1314 	ret
      00A1A9                       1315 00112$:
                                   1316 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A1A9 12 9F 03         [24] 1317 	lcall	_soft_reset_keyboard
                                   1318 ;	quantum/quantum.c:573: return false;
      00A1AC 75 82 00         [24] 1319 	mov	dpl, #0x00
                                   1320 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A1AF 22               [24] 1321 	ret
      00A1B0                       1322 00113$:
                                   1323 ;	quantum/quantum.c:592: eeconfig_disable();
      00A1B0 12 90 B9         [24] 1324 	lcall	_eeconfig_disable
                                   1325 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A1B3 12 9F 03         [24] 1326 	lcall	_soft_reset_keyboard
                                   1327 ;	quantum/quantum.c:595: return false;
      00A1B6 75 82 00         [24] 1328 	mov	dpl, #0x00
                                   1329 ;	quantum/quantum.c:650: }
      00A1B9 22               [24] 1330 	ret
      00A1BA                       1331 00116$:
                                   1332 ;	quantum/quantum.c:654: return true;
      00A1BA 75 82 01         [24] 1333 	mov	dpl, #0x01
                                   1334 ;	quantum/quantum.c:658: }
      00A1BD 22               [24] 1335 	ret
                                   1336 ;------------------------------------------------------------
                                   1337 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1338 ;------------------------------------------------------------
                                   1339 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_678'
                                   1340 ;------------------------------------------------------------
                                   1341 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function shutdown_user
                                   1344 ;	-----------------------------------------
      00A1BE                       1345 _shutdown_user:
      00A1BE 22               [24] 1346 	ret
                                   1347 ;------------------------------------------------------------
                                   1348 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1349 ;------------------------------------------------------------
                                   1350 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1351 ;	-----------------------------------------
                                   1352 	.area CSEG    (CODE)
                                   1353 	.area CONST   (CODE)
                                   1354 	.area XINIT   (CODE)
                                   1355 	.area CABS    (ABS,CODE)
                                   1356 
                                   1357 ; Experimental exact instruction outlining.
                                   1358 	.globl _ak820_outline_0004
                                   1359 	.globl _ak820_outline_0005
                                   1360 	.globl _ak820_outline_0006
                                   1361 	.globl _ak820_outline_0008
                                   1362 	.globl _ak820_outline_0010
                                   1363 	.globl _ak820_outline_0019
                                   1364 	.globl _ak820_outline_0029
                                   1365 	.globl _ak820_outline_0030
                                   1366 	.globl _ak820_outline_0035
                                   1367 	.globl _ak820_outline_0050
                                   1368 	.globl _ak820_outline_0054
                                   1369 	.globl _ak820_outline_0058
                                   1370 	.globl _ak820_outline_0059
                                   1371 	.globl _ak820_outline_0061
                                   1372 	.globl _ak820_outline_0070
                                   1373 	.globl _ak820_outline_0091
                                   1374 	.globl _ak820_outline_0097
                                   1375 	.globl _ak820_outline_0104
                                   1376 	.globl _ak820_outline_0105
                                   1377 	.globl _ak820_outline_0114
                                   1378 	.globl _ak820_outline_0115
                                   1379 	.globl _ak820_outline_0117
                                   1380 	.globl _ak820_outline_0130
                                   1381 	.globl _ak820_outline_0138
                                   1382 	.globl _ak820_outline_0144
                                   1383 	.globl _ak820_outline_0166
                                   1384 
                                   1385 	.area CSEG (CODE)
                                   1386 ; function ak820_outline_0006
      00A1BF                       1387 _ak820_outline_0006:
      00A1BF EE               [12] 1388 	mov	a,r6
      00A1C0 F0               [24] 1389 	movx	@dptr,a
      00A1C1 EF               [12] 1390 	mov	a,r7
      00A1C2 A3               [24] 1391 	inc	dptr
      00A1C3 F0               [24] 1392 	movx	@dptr,a
      00A1C4 E4               [12] 1393 	clr	a
      00A1C5 A3               [24] 1394 	inc	dptr
      00A1C6 F0               [24] 1395 	movx	@dptr,a
      00A1C7 8C 82            [24] 1396 	mov	dpl,r4
      00A1C9 8D 83            [24] 1397 	mov	dph,r5
      00A1CB 22               [24] 1398 	ret
