                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000017                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000017                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      00000F                        595 _suspended:
      00000F                        596 	.ds 1
      000010                        597 _dirty:
      000010                        598 	.ds 1
      000011                        599 _rendering:
      000011                        600 	.ds 1
      000012                        601 _rgb_matrix_task_sloc0_1_0:
      000012                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006C1                        611 _rgb_matrix_config::
      0006C1                        612 	.ds 8
      0006C9                        613 _changed_at:
      0006C9                        614 	.ds 2
      0006CB                        615 _frame_at:
      0006CB                        616 	.ds 2
      0006CD                        617 _phase:
      0006CD                        618 	.ds 2
      0006CF                        619 _led_index:
      0006CF                        620 	.ds 1
      0006D0                        621 _frame_mode:
      0006D0                        622 	.ds 1
      0006D1                        623 _frame_hue:
      0006D1                        624 	.ds 1
      0006D2                        625 _frame_sat:
      0006D2                        626 	.ds 1
      0006D3                        627 _frame_val:
      0006D3                        628 	.ds 1
      0006D4                        629 _frame_flags:
      0006D4                        630 	.ds 1
      0006D5                        631 _frame_phase:
      0006D5                        632 	.ds 1
      0006D6                        633 _reactive_age:
      0006D6                        634 	.ds 82
      000728                        635 _reactive_at:
      000728                        636 	.ds 2
      00072A                        637 _add_sat_PARM_2:
      00072A                        638 	.ds 1
      00072B                        639 _add_sat_x_10000_266:
      00072B                        640 	.ds 1
      00072C                        641 _sub_sat_PARM_2:
      00072C                        642 	.ds 1
      00072D                        643 _sub_sat_x_10000_268:
      00072D                        644 	.ds 1
      00072E                        645 _rgb_matrix_set_color_PARM_2:
      00072E                        646 	.ds 1
      00072F                        647 _rgb_matrix_set_color_PARM_3:
      00072F                        648 	.ds 1
      000730                        649 _rgb_matrix_set_color_PARM_4:
      000730                        650 	.ds 1
      000731                        651 _rgb_matrix_set_color_index_10000_284:
      000731                        652 	.ds 2
      000733                        653 _rgb_matrix_set_color_all_PARM_2:
      000733                        654 	.ds 1
      000734                        655 _rgb_matrix_set_color_all_PARM_3:
      000734                        656 	.ds 1
      000735                        657 _rgb_matrix_set_color_all_r_10000_287:
      000735                        658 	.ds 1
      000736                        659 _sine8_theta_10000_289:
      000736                        660 	.ds 1
      000737                        661 _sine8_offset_10000_290:
      000737                        662 	.ds 1
      000738                        663 _sine8_fraction_10000_290:
      000738                        664 	.ds 1
      000739                        665 _breathing_cie_value_10000_293:
      000739                        666 	.ds 1
      00073A                        667 _rgb_matrix_task_end_10000_298:
      00073A                        668 	.ds 1
      00073B                        669 _rgb_matrix_task_hsv_10000_298:
      00073B                        670 	.ds 3
      00073E                        671 _rgb_matrix_task_rgb_10000_298:
      00073E                        672 	.ds 3
      000741                        673 _process_rgb_matrix_PARM_2:
      000741                        674 	.ds 1
      000742                        675 _process_rgb_matrix_PARM_3:
      000742                        676 	.ds 1
      000743                        677 _process_rgb_matrix_row_10000_319:
      000743                        678 	.ds 1
      000744                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      000744                        680 	.ds 1
      000745                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000745                        682 	.ds 1
      000746                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000746                        684 	.ds 1
      000747                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000747                        686 	.ds 1
      000748                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000748                        688 	.ds 2
      00074A                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      00074A                        690 	.ds 1
      00074B                        691 _rgb_matrix_mode_mode_10000_411:
      00074B                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      005121                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      005121 12 59 09         [24]  746 	lcall	_ak820_outline_0175
      005124 74 52            [12]  747 	mov	a,#0x52
      005126 12 38 60         [24]  748 	lcall	_ak820_outline_0122
      005129 90 06 D6         [24]  749 	mov	dptr,#_reactive_age
      00512C F5 F0            [12]  750 	mov	b,a
      00512E 12 B8 E3         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      005131 12 4B 15         [24]  753 	lcall	_timer_read
      005134 12 38 6A         [24]  754 	lcall	_ak820_outline_0134
      005137 90 07 28         [24]  755 	mov	dptr,#_reactive_at
      00513A 12 58 F5         [24]  756 	lcall	_ak820_outline_0163
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      00513D 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      00513E                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      00513E 90 07 28         [24]  772 	mov	dptr,#_reactive_at
      005141 12 37 A1         [24]  773 	lcall	_ak820_outline_0004
      005144 12 4B 18         [24]  774 	lcall	_timer_elapsed
      005147 AE 82            [24]  775 	mov	r6, dpl
      005149 E5 83            [12]  776 	mov	a,dph
      00514B C4               [12]  777 	swap	a
      00514C CE               [12]  778 	xch	a,r6
      00514D C4               [12]  779 	swap	a
      00514E 54 0F            [12]  780 	anl	a,#0x0f
      005150 6E               [12]  781 	xrl	a,r6
      005151 CE               [12]  782 	xch	a,r6
      005152 54 0F            [12]  783 	anl	a,#0x0f
      005154 CE               [12]  784 	xch	a,r6
      005155 6E               [12]  785 	xrl	a,r6
      005156 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005157 FF               [12]  788 	mov	r7,a
      005158 4E               [12]  789 	orl	a,r6
      005159 70 01            [24]  790 	jnz	00102$
      00515B 22               [24]  791 	ret
      00515C                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      00515C 8E 04            [24]  794 	mov	ar4,r6
      00515E EF               [12]  795 	mov	a,r7
      00515F C4               [12]  796 	swap	a
      005160 54 F0            [12]  797 	anl	a,#0xf0
      005162 CC               [12]  798 	xch	a,r4
      005163 C4               [12]  799 	swap	a
      005164 CC               [12]  800 	xch	a,r4
      005165 6C               [12]  801 	xrl	a,r4
      005166 CC               [12]  802 	xch	a,r4
      005167 54 F0            [12]  803 	anl	a,#0xf0
      005169 CC               [12]  804 	xch	a,r4
      00516A 6C               [12]  805 	xrl	a,r4
      00516B FD               [12]  806 	mov	r5,a
      00516C 90 07 28         [24]  807 	mov	dptr,#_reactive_at
      00516F 12 45 5F         [24]  808 	lcall	_ak820_outline_0119
      005172 90 07 28         [24]  809 	mov	dptr,#_reactive_at
      005175 EC               [12]  810 	mov	a,r4
      005176 2A               [12]  811 	add	a, r2
      005177 F0               [24]  812 	movx	@dptr,a
      005178 ED               [12]  813 	mov	a,r5
      005179 3B               [12]  814 	addc	a, r3
      00517A A3               [24]  815 	inc	dptr
      00517B F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      00517C 8E 04            [24]  818 	mov	ar4,r6
      00517E 8F 05            [24]  819 	mov	ar5,r7
      005180 C3               [12]  820 	clr	c
      005181 74 FF            [12]  821 	mov	a,#0xff
      005183 9C               [12]  822 	subb	a,r4
      005184 E4               [12]  823 	clr	a
      005185 9D               [12]  824 	subb	a,r5
      005186 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      005188 7D FF            [12]  827 	mov	r5,#0xff
      00518A 80 02            [24]  828 	sjmp	00109$
      00518C                        829 00108$:
      00518C 8E 05            [24]  830 	mov	ar5,r6
      00518E                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00518E 7F 00            [12]  833 	mov	r7,#0x00
      005190                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      005190 EF               [12]  836 	mov	a,r7
      005191 24 D6            [12]  837 	add	a, #_reactive_age
      005193 FC               [12]  838 	mov	r4,a
      005194 E4               [12]  839 	clr	a
      005195 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      005197 FE               [12]  841 	mov	r6,a
      005198 8C 82            [24]  842 	mov	dpl,r4
      00519A 8E 83            [24]  843 	mov	dph,r6
      00519C E0               [24]  844 	movx	a,@dptr
      00519D FB               [12]  845 	mov	r3,a
      00519E C3               [12]  846 	clr	c
      00519F ED               [12]  847 	mov	a,r5
      0051A0 9B               [12]  848 	subb	a,r3
      0051A1 40 04            [24]  849 	jc	00110$
      0051A3 7B 00            [12]  850 	mov	r3,#0x00
      0051A5 80 08            [24]  851 	sjmp	00111$
      0051A7                        852 00110$:
      0051A7 8C 82            [24]  853 	mov	dpl,r4
      0051A9 8E 83            [24]  854 	mov	dph,r6
      0051AB E0               [24]  855 	movx	a,@dptr
      0051AC C3               [12]  856 	clr	c
      0051AD 9D               [12]  857 	subb	a,r5
      0051AE FB               [12]  858 	mov	r3,a
      0051AF                        859 00111$:
      0051AF 8C 82            [24]  860 	mov	dpl,r4
      0051B1 8E 83            [24]  861 	mov	dph,r6
      0051B3 EB               [12]  862 	mov	a,r3
      0051B4 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0051B5 0F               [12]  865 	inc	r7
      0051B6 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      0051B9                        867 00144$:
      0051B9 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      0051BB 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      0051BC                        881 _add_sat:
      0051BC E5 82            [12]  882 	mov	a,dpl
      0051BE 90 07 2B         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      0051C1 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      0051C2 90 07 2A         [24]  886 	mov	dptr,#_add_sat_PARM_2
      0051C5 E0               [24]  887 	movx	a,@dptr
      0051C6 FF               [12]  888 	mov	r7,a
      0051C7 FE               [12]  889 	mov	r6,a
      0051C8 74 FF            [12]  890 	mov	a,#0xff
      0051CA C3               [12]  891 	clr	c
      0051CB 9E               [12]  892 	subb	a,r6
      0051CC FE               [12]  893 	mov	r6,a
      0051CD 90 07 2B         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      0051D0 E0               [24]  895 	movx	a,@dptr
      0051D1 FD               [12]  896 	mov	r5,a
      0051D2 C3               [12]  897 	clr	c
      0051D3 EE               [12]  898 	mov	a,r6
      0051D4 9D               [12]  899 	subb	a,r5
      0051D5 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      0051D7 7E FF            [12]  902 	mov	r6,#0xff
      0051D9 80 03            [24]  903 	sjmp	00104$
      0051DB                        904 00103$:
      0051DB EF               [12]  905 	mov	a,r7
      0051DC 2D               [12]  906 	add	a, r5
      0051DD FE               [12]  907 	mov	r6,a
      0051DE                        908 00104$:
      0051DE 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      0051E0 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      0051E1                        922 _sub_sat:
      0051E1 E5 82            [12]  923 	mov	a,dpl
      0051E3 90 07 2D         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      0051E6 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      0051E7 E0               [24]  927 	movx	a,@dptr
      0051E8 FF               [12]  928 	mov	r7,a
      0051E9 90 07 2C         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      0051EC E0               [24]  930 	movx	a,@dptr
      0051ED FE               [12]  931 	mov	r6,a
      0051EE C3               [12]  932 	clr	c
      0051EF EF               [12]  933 	mov	a,r7
      0051F0 9E               [12]  934 	subb	a,r6
      0051F1 50 04            [24]  935 	jnc	00103$
      0051F3 7D 00            [12]  936 	mov	r5,#0x00
      0051F5 80 04            [24]  937 	sjmp	00104$
      0051F7                        938 00103$:
      0051F7 EF               [12]  939 	mov	a,r7
      0051F8 C3               [12]  940 	clr	c
      0051F9 9E               [12]  941 	subb	a,r6
      0051FA FD               [12]  942 	mov	r5,a
      0051FB                        943 00104$:
      0051FB 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      0051FD 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      0051FE                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      0051FE D2 10            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      005200 12 4B 15         [24]  959 	lcall	_timer_read
      005203 12 38 6A         [24]  960 	lcall	_ak820_outline_0134
      005206 90 06 C9         [24]  961 	mov	dptr,#_changed_at
      005209 12 58 F5         [24]  962 	lcall	_ak820_outline_0163
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      00520C 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      00520D                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      00520D 90 06 C8         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      005210 E4               [12]  978 	clr	a
      005211 F0               [24]  979 	movx	@dptr,a
      005212 90 06 C7         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      005215 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005216 90 05 AB         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      005219 12 58 D8         [24]  984 	lcall	_ak820_outline_0082
      00521C 90 05 AE         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00521F 12 58 BF         [24]  986 	lcall	_ak820_outline_0069
      005222 12 44 1C         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      005225 C2 10            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005227 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005228                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005228 12 59 09         [24] 1002 	lcall	_ak820_outline_0175
      00522B 12 58 BF         [24] 1003 	lcall	_ak820_outline_0069
      00522E F5 F0            [12] 1004 	mov	b,a
      005230 12 B8 E3         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      005233 12 58 E8         [24] 1007 	lcall	_ak820_outline_0111
      005236 44 01            [12] 1008 	orl	a,#0x01
      005238 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005239 12 58 B8         [24] 1011 	lcall	_ak820_outline_0065
      00523C 44 04            [12] 1012 	orl	a,#0x04
      00523E F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      00523F 90 06 C2         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005242 E4               [12] 1016 	clr	a
      005243 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      005244 90 06 C3         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005247 14               [12] 1020 	dec	a
      005248 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005249 90 06 C4         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00524C 74 50            [12] 1024 	mov	a,#0x50
      00524E F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      00524F 90 06 C5         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005252 74 60            [12] 1028 	mov	a,#0x60
      005254 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      005255 90 06 C6         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005258 74 FF            [12] 1032 	mov	a,#0xff
      00525A F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      00525B 02 52 0D         [24] 1036 	ljmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      00525E                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00525E 90 05 9B         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005261 12 58 D8         [24] 1047 	lcall	_ak820_outline_0082
      005264 90 05 9E         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005267 12 58 BF         [24] 1049 	lcall	_ak820_outline_0069
      00526A 12 42 AD         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      00526D 12 58 E8         [24] 1052 	lcall	_ak820_outline_0111
      005270 60 11            [24] 1053 	jz	00101$
      005272 12 58 99         [24] 1054 	lcall	_ak820_outline_0017
      005275 C3               [12] 1055 	clr	c
      005276 64 80            [12] 1056 	xrl	a,#0x80
      005278 94 87            [12] 1057 	subb	a,#0x87
      00527A 50 07            [24] 1058 	jnc	00101$
      00527C 12 58 B8         [24] 1059 	lcall	_ak820_outline_0065
      00527F 24 FE            [12] 1060 	add	a,#0xff - 0x01
      005281 50 03            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      005283                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      005283 12 52 28         [24] 1065 	lcall	_eeconfig_update_rgb_matrix_default
      005286                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005286 90 06 C4         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005289 E0               [24] 1069 	movx	a,@dptr
      00528A 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      00528C 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00528E 90 06 C4         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005291 74 A0            [12] 1075 	mov	a,#0xa0
      005293 F0               [24] 1076 	movx	@dptr,a
      005294                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      005294 C2 10            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      005296 C2 11            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005298 02 51 21         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      00529B                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      00529B 12 52 5E         [24] 1096 	lcall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      00529E 12 4B 15         [24] 1098 	lcall	_timer_read
      0052A1 12 45 65         [24] 1099 	lcall	_ak820_outline_0130
      0052A4 EE               [12] 1100 	mov	a,r6
      0052A5 24 F0            [12] 1101 	add	a,#0xf0
      0052A7 FE               [12] 1102 	mov	r6,a
      0052A8 EF               [12] 1103 	mov	a,r7
      0052A9 34 FF            [12] 1104 	addc	a,#0xff
      0052AB FF               [12] 1105 	mov	r7,a
      0052AC 90 06 CB         [24] 1106 	mov	dptr,#_frame_at
      0052AF 12 4A 7D         [24] 1107 	lcall	_ak820_outline_0058
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      0052B2 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      0052B3                       1122 _rgb_matrix_set_color:
      0052B3 12 38 4B         [24] 1123 	lcall	_ak820_outline_0104
      0052B6 90 07 31         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0052B9 12 38 50         [24] 1125 	lcall	_ak820_outline_0105
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      0052BC 90 07 31         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0052BF 12 38 01         [24] 1128 	lcall	_ak820_outline_0050
      0052C2 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      0052C5 C3               [12] 1130 	clr	c
      0052C6 EE               [12] 1131 	mov	a,r6
      0052C7 94 52            [12] 1132 	subb	a,#0x52
      0052C9 EF               [12] 1133 	mov	a,r7
      0052CA 64 80            [12] 1134 	xrl	a,#0x80
      0052CC 94 80            [12] 1135 	subb	a,#0x80
      0052CE 50 23            [24] 1136 	jnc	00104$
      0052D0 90 07 2E         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0052D3 E0               [24] 1138 	movx	a,@dptr
      0052D4 FF               [12] 1139 	mov	r7,a
      0052D5 90 07 2F         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0052D8 E0               [24] 1141 	movx	a,@dptr
      0052D9 FD               [12] 1142 	mov	r5,a
      0052DA 90 07 30         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0052DD E0               [24] 1144 	movx	a,@dptr
      0052DE FC               [12] 1145 	mov	r4,a
      0052DF 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      0052E2 EF               [12] 1147 	mov	a,r7
      0052E3 F0               [24] 1148 	movx	@dptr,a
      0052E4 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      0052E7 ED               [12] 1150 	mov	a,r5
      0052E8 F0               [24] 1151 	movx	@dptr,a
      0052E9 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0052EC EC               [12] 1153 	mov	a,r4
      0052ED F0               [24] 1154 	movx	@dptr,a
      0052EE 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0052F0 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      0052F3                       1158 00104$:
      0052F3 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0052F4                       1171 _rgb_matrix_set_color_all:
      0052F4 E5 82            [12] 1172 	mov	a,dpl
      0052F6 90 07 35         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      0052F9 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      0052FA E0               [24] 1176 	movx	a,@dptr
      0052FB FF               [12] 1177 	mov	r7,a
      0052FC 90 07 33         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0052FF E0               [24] 1179 	movx	a,@dptr
      005300 FE               [12] 1180 	mov	r6,a
      005301 90 07 34         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005304 E0               [24] 1182 	movx	a,@dptr
      005305 FD               [12] 1183 	mov	r5,a
      005306 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      005309 EE               [12] 1185 	mov	a,r6
      00530A F0               [24] 1186 	movx	@dptr,a
      00530B 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      00530E ED               [12] 1188 	mov	a,r5
      00530F F0               [24] 1189 	movx	@dptr,a
      005310 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005312 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      005315                       1206 _sine8:
      005315 E5 82            [12] 1207 	mov	a,dpl
      005317 90 07 36         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      00531A F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      00531B E0               [24] 1211 	movx	a,@dptr
      00531C FF               [12] 1212 	mov	r7,a
      00531D 90 07 37         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      005320 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005321 EF               [12] 1216 	mov	a,r7
      005322 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      005325 90 07 37         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      005328 74 FF            [12] 1219 	mov	a,#0xff
      00532A C3               [12] 1220 	clr	c
      00532B 9F               [12] 1221 	subb	a,r7
      00532C F0               [24] 1222 	movx	@dptr,a
      00532D                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      00532D 90 07 37         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      005330 E0               [24] 1226 	movx	a,@dptr
      005331 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      005334 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      005335 90 07 37         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      005338 E0               [24] 1231 	movx	a,@dptr
      005339 54 0F            [12] 1232 	anl	a,#0x0f
      00533B FF               [12] 1233 	mov	r7,a
      00533C 90 07 38         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      00533F F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005340 90 07 36         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      005343 E0               [24] 1238 	movx	a,@dptr
      005344 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      005347 90 07 38         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      00534A EF               [12] 1241 	mov	a,r7
      00534B 04               [12] 1242 	inc	a
      00534C F0               [24] 1243 	movx	@dptr,a
      00534D                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      00534D 90 07 37         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      005350 E0               [24] 1247 	movx	a,@dptr
      005351 C4               [12] 1248 	swap	a
      005352 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      005354 25 E0            [12] 1251 	add	a,acc
      005356 FF               [12] 1252 	mov	r7,a
      005357 90 B9 C8         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      00535A 93               [24] 1254 	movc	a,@a+dptr
      00535B FE               [12] 1255 	mov	r6,a
      00535C 0F               [12] 1256 	inc	r7
      00535D EF               [12] 1257 	mov	a,r7
      00535E 90 B9 C8         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      005361 93               [24] 1259 	movc	a,@a+dptr
      005362 FF               [12] 1260 	mov	r7,a
      005363 90 07 38         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      005366 E0               [24] 1262 	movx	a,@dptr
      005367 8F F0            [24] 1263 	mov	b,r7
      005369 A4               [48] 1264 	mul	ab
      00536A FF               [12] 1265 	mov	r7,a
      00536B E5 F0            [12] 1266 	mov	a,b
      00536D C4               [12] 1267 	swap	a
      00536E CF               [12] 1268 	xch	a,r7
      00536F C4               [12] 1269 	swap	a
      005370 54 0F            [12] 1270 	anl	a,#0x0f
      005372 6F               [12] 1271 	xrl	a,r7
      005373 CF               [12] 1272 	xch	a,r7
      005374 54 0F            [12] 1273 	anl	a,#0x0f
      005376 CF               [12] 1274 	xch	a,r7
      005377 6F               [12] 1275 	xrl	a,r7
      005378 CF               [12] 1276 	xch	a,r7
      005379 EF               [12] 1277 	mov	a,r7
      00537A 2E               [12] 1278 	add	a, r6
      00537B FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      00537C 90 07 36         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      00537F E0               [24] 1282 	movx	a,@dptr
      005380 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      005383 8F 06            [24] 1284 	mov	ar6,r7
      005385 74 80            [12] 1285 	mov	a,#0x80
      005387 C3               [12] 1286 	clr	c
      005388 9E               [12] 1287 	subb	a,r6
      005389 FE               [12] 1288 	mov	r6,a
      00538A 80 04            [24] 1289 	sjmp	00108$
      00538C                       1290 00107$:
      00538C 74 80            [12] 1291 	mov	a,#0x80
      00538E 2F               [12] 1292 	add	a, r7
      00538F FE               [12] 1293 	mov	r6,a
      005390                       1294 00108$:
      005390 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005392 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      005393                       1312 _breathing_cie:
      005393 E5 82            [12] 1313 	mov	a,dpl
      005395 90 07 39         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      005398 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      005399 E0               [24] 1317 	movx	a,@dptr
      00539A FF               [12] 1318 	mov	r7,a
      00539B 12 59 17         [24] 1319 	lcall	_ak820_outline_0182
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      00539E FE               [12] 1321 	mov	r6,a
      00539F 90 BC D4         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      0053A2 93               [24] 1323 	movc	a,@a+dptr
      0053A3 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      0053A4 BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      0053A7 8D 82            [24] 1327 	mov	dpl, r5
      0053A9 22               [24] 1328 	ret
      0053AA                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0053AA EE               [12] 1331 	mov	a,r6
      0053AB 04               [12] 1332 	inc	a
      0053AC 90 BC D4         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      0053AF 93               [24] 1334 	movc	a,@a+dptr
      0053B0 C3               [12] 1335 	clr	c
      0053B1 9D               [12] 1336 	subb	a,r5
      0053B2 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      0053B3 74 07            [12] 1339 	mov	a,#0x07
      0053B5 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      0053B6 F5 F0            [12] 1342 	mov	b,a
      0053B8 EE               [12] 1343 	mov	a,r6
      0053B9 A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      0053BA 12 59 17         [24] 1346 	lcall	_ak820_outline_0182
      0053BD 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      0053BE F5 82            [12] 1349 	mov	dpl,a
      0053C0 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      0053C1                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      0053C1 12 51 3E         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      0053C4 30 10 18         [24] 1369 	jnb	_dirty,00102$
      0053C7 90 06 C9         [24] 1370 	mov	dptr,#_changed_at
      0053CA 12 37 A1         [24] 1371 	lcall	_ak820_outline_0004
      0053CD 12 4B 18         [24] 1372 	lcall	_timer_elapsed
      0053D0 12 45 65         [24] 1373 	lcall	_ak820_outline_0130
      0053D3 C3               [12] 1374 	clr	c
      0053D4 EE               [12] 1375 	mov	a,r6
      0053D5 94 E8            [12] 1376 	subb	a,#0xe8
      0053D7 EF               [12] 1377 	mov	a,r7
      0053D8 94 03            [12] 1378 	subb	a,#0x03
      0053DA 40 03            [24] 1379 	jc	00102$
      0053DC 12 52 0D         [24] 1380 	lcall	_eeconfig_update_rgb_matrix
      0053DF                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0053DF 30 11 03         [24] 1383 	jnb	_rendering,00254$
      0053E2 02 54 9A         [24] 1384 	ljmp	00109$
      0053E5                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0053E5 90 06 CB         [24] 1387 	mov	dptr,#_frame_at
      0053E8 12 37 A1         [24] 1388 	lcall	_ak820_outline_0004
      0053EB 12 4B 18         [24] 1389 	lcall	_timer_elapsed
      0053EE 12 45 65         [24] 1390 	lcall	_ak820_outline_0130
      0053F1 C3               [12] 1391 	clr	c
      0053F2 EE               [12] 1392 	mov	a,r6
      0053F3 94 10            [12] 1393 	subb	a,#0x10
      0053F5 EF               [12] 1394 	mov	a,r7
      0053F6 94 00            [12] 1395 	subb	a,#0x00
      0053F8 50 01            [24] 1396 	jnc	00105$
      0053FA 22               [24] 1397 	ret
      0053FB                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0053FB 12 4B 15         [24] 1400 	lcall	_timer_read
      0053FE 12 38 6A         [24] 1401 	lcall	_ak820_outline_0134
      005401 90 06 CB         [24] 1402 	mov	dptr,#_frame_at
      005404 12 58 F5         [24] 1403 	lcall	_ak820_outline_0163
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      005407 90 06 C5         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00540A E0               [24] 1406 	movx	a,@dptr
      00540B FF               [12] 1407 	mov	r7,a
      00540C 7E 00            [12] 1408 	mov	r6,#0x00
      00540E 74 20            [12] 1409 	mov	a,#0x20
      005410 2F               [12] 1410 	add	a, r7
      005411 FF               [12] 1411 	mov	r7,a
      005412 E4               [12] 1412 	clr	a
      005413 3E               [12] 1413 	addc	a, r6
      005414 FE               [12] 1414 	mov	r6,a
      005415 90 06 CD         [24] 1415 	mov	dptr,#_phase
      005418 12 38 20         [24] 1416 	lcall	_ak820_outline_0059
      00541B EF               [12] 1417 	mov	a,r7
      00541C 2C               [12] 1418 	add	a, r4
      00541D FF               [12] 1419 	mov	r7,a
      00541E EE               [12] 1420 	mov	a,r6
      00541F 3D               [12] 1421 	addc	a, r5
      005420 FE               [12] 1422 	mov	r6,a
      005421 90 06 CD         [24] 1423 	mov	dptr,#_phase
      005424 EF               [12] 1424 	mov	a,r7
      005425 F0               [24] 1425 	movx	@dptr,a
      005426 EE               [12] 1426 	mov	a,r6
      005427 A3               [24] 1427 	inc	dptr
      005428 F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      005429 90 06 CD         [24] 1430 	mov	dptr,#_phase
      00542C E0               [24] 1431 	movx	a,@dptr
      00542D A3               [24] 1432 	inc	dptr
      00542E E0               [24] 1433 	movx	a,@dptr
      00542F FF               [12] 1434 	mov	r7,a
      005430 90 06 D5         [24] 1435 	mov	dptr,#_frame_phase
      005433 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005434 20 0F 05         [24] 1438 	jb	_suspended,00135$
      005437 12 58 B8         [24] 1439 	lcall	_ak820_outline_0065
      00543A 70 04            [24] 1440 	jnz	00132$
      00543C                       1441 00135$:
      00543C 7E 00            [12] 1442 	mov	r6,#0x00
      00543E 80 04            [24] 1443 	sjmp	00133$
      005440                       1444 00132$:
      005440 12 58 99         [24] 1445 	lcall	_ak820_outline_0017
      005443 FE               [12] 1446 	mov	r6,a
      005444                       1447 00133$:
      005444 90 06 D0         [24] 1448 	mov	dptr,#_frame_mode
      005447 EE               [12] 1449 	mov	a,r6
      005448 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      005449 90 06 C2         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00544C E0               [24] 1453 	movx	a,@dptr
      00544D 90 06 D1         [24] 1454 	mov	dptr,#_frame_hue
      005450 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005451 90 06 C3         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005454 E0               [24] 1458 	movx	a,@dptr
      005455 90 06 D2         [24] 1459 	mov	dptr,#_frame_sat
      005458 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005459 90 06 C4         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00545C E0               [24] 1463 	movx	a,@dptr
      00545D FD               [12] 1464 	mov	r5,a
      00545E 90 06 D3         [24] 1465 	mov	dptr,#_frame_val
      005461 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005462 90 06 C6         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005465 E0               [24] 1469 	movx	a,@dptr
      005466 90 06 D4         [24] 1470 	mov	dptr,#_frame_flags
      005469 F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      00546A BE 02 26         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      00546D EF               [12] 1475 	mov	a,r7
      00546E 24 C0            [12] 1476 	add	a,#0xc0
      005470 F5 82            [12] 1477 	mov	dpl,a
      005472 C0 05            [24] 1478 	push	ar5
      005474 12 53 15         [24] 1479 	lcall	_sine8
      005477 AF 82            [24] 1480 	mov	r7, dpl
      005479 D0 05            [24] 1481 	pop	ar5
      00547B 8D F0            [24] 1482 	mov	b,r5
      00547D EF               [12] 1483 	mov	a,r7
      00547E A4               [48] 1484 	mul	ab
      00547F AE F0            [24] 1485 	mov	r6,b
      005481 8E 05            [24] 1486 	mov	ar5,r6
      005483 90 06 D3         [24] 1487 	mov	dptr,#_frame_val
      005486 ED               [12] 1488 	mov	a,r5
      005487 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      005488 8D 82            [24] 1491 	mov	dpl, r5
      00548A 12 53 93         [24] 1492 	lcall	_breathing_cie
      00548D E5 82            [12] 1493 	mov	a, dpl
      00548F 90 06 D3         [24] 1494 	mov	dptr,#_frame_val
      005492 F0               [24] 1495 	movx	@dptr,a
      005493                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005493 90 06 CF         [24] 1498 	mov	dptr,#_led_index
      005496 E4               [12] 1499 	clr	a
      005497 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      005498 D2 11            [12] 1503 	setb	_rendering
      00549A                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      00549A 12 59 12         [24] 1506 	lcall	_ak820_outline_0181
      00549D 24 08            [12] 1507 	add	a,#0x08
      00549F FF               [12] 1508 	mov	r7,a
      0054A0 90 07 3A         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0054A3 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      0054A4 EF               [12] 1512 	mov	a,r7
      0054A5 24 AD            [12] 1513 	add	a,#0xff - 0x52
      0054A7 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      0054A9 90 07 3A         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0054AC 74 52            [12] 1517 	mov	a,#0x52
      0054AE F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      0054AF                       1520 00125$:
      0054AF 12 59 12         [24] 1521 	lcall	_ak820_outline_0181
      0054B2 FF               [12] 1522 	mov	r7,a
      0054B3 90 07 3A         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0054B6 E0               [24] 1524 	movx	a,@dptr
      0054B7 FE               [12] 1525 	mov	r6,a
      0054B8 C3               [12] 1526 	clr	c
      0054B9 EF               [12] 1527 	mov	a,r7
      0054BA 9E               [12] 1528 	subb	a,r6
      0054BB 40 03            [24] 1529 	jc	00261$
      0054BD 02 56 21         [24] 1530 	ljmp	00127$
      0054C0                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0054C0 12 58 EF         [24] 1533 	lcall	_ak820_outline_0136
      0054C3 E0               [24] 1534 	movx	a,@dptr
      0054C4 60 07            [24] 1535 	jz	00121$
      0054C6 90 06 D4         [24] 1536 	mov	dptr,#_frame_flags
      0054C9 E0               [24] 1537 	movx	a,@dptr
      0054CA 20 E2 1C         [24] 1538 	jb	acc.2,00122$
      0054CD                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0054CD 12 59 12         [24] 1541 	lcall	_ak820_outline_0181
      0054D0 FC               [12] 1542 	mov	r4,a
      0054D1 7D 00            [12] 1543 	mov	r5,#0x00
      0054D3 90 07 2E         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0054D6 E4               [12] 1545 	clr	a
      0054D7 F0               [24] 1546 	movx	@dptr,a
      0054D8 90 07 2F         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0054DB F0               [24] 1548 	movx	@dptr,a
      0054DC 90 07 30         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0054DF F0               [24] 1550 	movx	@dptr,a
      0054E0 12 38 55         [24] 1551 	lcall	_ak820_outline_0117
      0054E3 12 52 B3         [24] 1552 	lcall	_rgb_matrix_set_color
      0054E6 02 56 18         [24] 1553 	ljmp	00123$
      0054E9                       1554 00122$:
                                   1555 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0054E9 BE 05 21         [24] 1556 	cjne	r6,#0x05,00119$
                                   1557 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      0054EC EF               [12] 1558 	mov	a,r7
      0054ED 75 F0 03         [24] 1559 	mov	b,#0x03
      0054F0 A4               [48] 1560 	mul	ab
      0054F1 24 76            [12] 1561 	add	a, #_g_direct_mode_colors
      0054F3 FD               [12] 1562 	mov	r5,a
      0054F4 74 0C            [12] 1563 	mov	a,#(_g_direct_mode_colors >> 8)
      0054F6 35 F0            [12] 1564 	addc	a, b
      0054F8 FE               [12] 1565 	mov	r6,a
      0054F9 90 0D 8A         [24] 1566 	mov	dptr,#___memcpy_PARM_2
      0054FC ED               [12] 1567 	mov	a,r5
      0054FD F0               [24] 1568 	movx	@dptr,a
      0054FE EE               [12] 1569 	mov	a,r6
      0054FF 12 58 C9         [24] 1570 	lcall	_ak820_outline_0071
      005502 90 07 3B         [24] 1571 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005505 F5 F0            [12] 1572 	mov	b,a
      005507 12 B8 6D         [24] 1573 	lcall	___memcpy
      00550A 02 55 BC         [24] 1574 	ljmp	00120$
      00550D                       1575 00119$:
                                   1576 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      00550D 90 06 D1         [24] 1577 	mov	dptr,#_frame_hue
      005510 E0               [24] 1578 	movx	a,@dptr
      005511 90 07 3B         [24] 1579 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005514 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005515 90 06 D2         [24] 1582 	mov	dptr,#_frame_sat
      005518 E0               [24] 1583 	movx	a,@dptr
      005519 90 07 3C         [24] 1584 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      00551C F0               [24] 1585 	movx	@dptr,a
                                   1586 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      00551D 90 06 D3         [24] 1587 	mov	dptr,#_frame_val
      005520 E0               [24] 1588 	movx	a,@dptr
      005521 90 07 3D         [24] 1589 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005524 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005525 12 58 EF         [24] 1592 	lcall	_ak820_outline_0136
      005528 BE 03 0E         [24] 1593 	cjne	r6,#0x03,00113$
      00552B 90 07 3B         [24] 1594 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00552E E0               [24] 1595 	movx	a,@dptr
      00552F FE               [12] 1596 	mov	r6,a
      005530 90 06 D5         [24] 1597 	mov	dptr,#_frame_phase
      005533 E0               [24] 1598 	movx	a,@dptr
      005534 2E               [12] 1599 	add	a, r6
      005535 90 07 3B         [24] 1600 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005538 F0               [24] 1601 	movx	@dptr,a
      005539                       1602 00113$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005539 12 58 EF         [24] 1604 	lcall	_ak820_outline_0136
      00553C BE 04 23         [24] 1605 	cjne	r6,#0x04,00115$
      00553F 90 07 3B         [24] 1606 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005542 E0               [24] 1607 	movx	a,@dptr
      005543 FE               [12] 1608 	mov	r6,a
      005544 12 59 12         [24] 1609 	lcall	_ak820_outline_0181
      005547 75 F0 02         [24] 1610 	mov	b,#0x02
      00554A A4               [48] 1611 	mul	ab
      00554B 24 30            [12] 1612 	add	a, #_ak820_led_points
      00554D F5 82            [12] 1613 	mov	dpl,a
      00554F 74 BC            [12] 1614 	mov	a,#(_ak820_led_points >> 8)
      005551 12 58 E1         [24] 1615 	lcall	_ak820_outline_0106
      005554 FD               [12] 1616 	mov	r5,a
      005555 90 06 D5         [24] 1617 	mov	dptr,#_frame_phase
      005558 E0               [24] 1618 	movx	a,@dptr
      005559 FC               [12] 1619 	mov	r4,a
      00555A ED               [12] 1620 	mov	a,r5
      00555B C3               [12] 1621 	clr	c
      00555C 9C               [12] 1622 	subb	a,r4
      00555D 2E               [12] 1623 	add	a, r6
      00555E 90 07 3B         [24] 1624 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005561 F0               [24] 1625 	movx	@dptr,a
      005562                       1626 00115$:
                                   1627 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      005562 12 58 EF         [24] 1628 	lcall	_ak820_outline_0136
      005565 BE 06 54         [24] 1629 	cjne	r6,#0x06,00120$
                                   1630 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005568 12 59 00         [24] 1631 	lcall	_ak820_outline_0169
      00556B FE               [12] 1632 	mov	r6,a
      00556C 74 07            [12] 1633 	mov	a,#0x07
      00556E C3               [12] 1634 	clr	c
      00556F 9E               [12] 1635 	subb	a,r6
      005570 FE               [12] 1636 	mov	r6,a
                                   1637 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      005571 8E F0            [24] 1638 	mov	b,r6
      005573 05 F0            [12] 1639 	inc	b
      005575 74 01            [12] 1640 	mov	a,#0x01
      005577 80 02            [24] 1641 	sjmp	00273$
      005579                       1642 00272$:
      005579 25 E0            [12] 1643 	add	a,acc
      00557B                       1644 00273$:
      00557B D5 F0 FB         [24] 1645 	djnz	b,00272$
      00557E FD               [12] 1646 	mov	r5,a
                                   1647 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      00557F 12 59 12         [24] 1648 	lcall	_ak820_outline_0181
      005582 24 D6            [12] 1649 	add	a, #_reactive_age
      005584 F5 82            [12] 1650 	mov	dpl,a
      005586 E4               [12] 1651 	clr	a
      005587 34 06            [12] 1652 	addc	a, #(_reactive_age >> 8)
      005589 F5 83            [12] 1653 	mov	dph,a
      00558B E0               [24] 1654 	movx	a,@dptr
                                   1655 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      00558C FC               [12] 1656 	mov	r4,a
      00558D C3               [12] 1657 	clr	c
      00558E 9D               [12] 1658 	subb	a,r5
      00558F 40 07            [24] 1659 	jc	00137$
      005591 90 06 D3         [24] 1660 	mov	dptr,#_frame_val
      005594 E0               [24] 1661 	movx	a,@dptr
      005595 FB               [12] 1662 	mov	r3,a
      005596 80 1F            [24] 1663 	sjmp	00138$
      005598                       1664 00137$:
      005598 90 06 D3         [24] 1665 	mov	dptr,#_frame_val
      00559B E0               [24] 1666 	movx	a,@dptr
      00559C F5 F0            [12] 1667 	mov	b, a
      00559E EC               [12] 1668 	mov	a,r4
      00559F A4               [48] 1669 	mul	ab
      0055A0 FC               [12] 1670 	mov	r4,a
      0055A1 AA F0            [24] 1671 	mov	r2,b
      0055A3 8E F0            [24] 1672 	mov	b,r6
      0055A5 05 F0            [12] 1673 	inc	b
      0055A7 AB 04            [24] 1674 	mov	r3,ar4
      0055A9 AD 02            [24] 1675 	mov	r5,ar2
      0055AB 80 07            [24] 1676 	sjmp	00276$
      0055AD                       1677 00275$:
      0055AD C3               [12] 1678 	clr	c
      0055AE ED               [12] 1679 	mov	a,r5
      0055AF 13               [12] 1680 	rrc	a
      0055B0 FD               [12] 1681 	mov	r5,a
      0055B1 EB               [12] 1682 	mov	a,r3
      0055B2 13               [12] 1683 	rrc	a
      0055B3 FB               [12] 1684 	mov	r3,a
      0055B4                       1685 00276$:
      0055B4 D5 F0 F6         [24] 1686 	djnz	b,00275$
      0055B7                       1687 00138$:
      0055B7 90 07 3D         [24] 1688 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0055BA EB               [12] 1689 	mov	a,r3
      0055BB F0               [24] 1690 	movx	@dptr,a
      0055BC                       1691 00120$:
                                   1692 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0055BC 12 58 EF         [24] 1693 	lcall	_ak820_outline_0136
      0055BF BE 02 03         [24] 1694 	cjne	r6,#0x02,00277$
      0055C2 D3               [12] 1695 	setb	c
      0055C3 80 01            [24] 1696 	sjmp	00278$
      0055C5                       1697 00277$:
      0055C5 C3               [12] 1698 	clr	c
      0055C6                       1699 00278$:
      0055C6 B3               [12] 1700 	cpl	c
      0055C7 92 12            [24] 1701 	mov	_rgb_matrix_task_sloc0_1_0,c
      0055C9 90 0D 8A         [24] 1702 	mov	dptr,#___memcpy_PARM_2
      0055CC 74 3B            [12] 1703 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0055CE F0               [24] 1704 	movx	@dptr,a
      0055CF 74 07            [12] 1705 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0055D1 12 58 C9         [24] 1706 	lcall	_ak820_outline_0071
      0055D4 90 0A D3         [24] 1707 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0055D7 F5 F0            [12] 1708 	mov	b,a
      0055D9 12 B8 6D         [24] 1709 	lcall	___memcpy
      0055DC 90 0A D6         [24] 1710 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0055DF 74 3E            [12] 1711 	mov	a,#_rgb_matrix_task_rgb_10000_298
      0055E1 F0               [24] 1712 	movx	@dptr,a
      0055E2 74 07            [12] 1713 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      0055E4 A3               [24] 1714 	inc	dptr
      0055E5 F0               [24] 1715 	movx	@dptr,a
      0055E6 A2 12            [12] 1716 	mov	c,_rgb_matrix_task_sloc0_1_0
      0055E8 12 38 81         [24] 1717 	lcall	_ak820_outline_0166
      0055EB 12 82 B2         [24] 1718 	lcall	_hsv_to_rgb_into
                                   1719 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      0055EE 12 59 12         [24] 1720 	lcall	_ak820_outline_0181
      0055F1 FD               [12] 1721 	mov	r5,a
      0055F2 7E 00            [12] 1722 	mov	r6,#0x00
      0055F4 90 07 3F         [24] 1723 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      0055F7 E0               [24] 1724 	movx	a,@dptr
      0055F8 FC               [12] 1725 	mov	r4,a
      0055F9 90 07 3E         [24] 1726 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      0055FC E0               [24] 1727 	movx	a,@dptr
      0055FD FB               [12] 1728 	mov	r3,a
      0055FE 90 07 40         [24] 1729 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      005601 E0               [24] 1730 	movx	a,@dptr
      005602 FA               [12] 1731 	mov	r2,a
      005603 90 07 2E         [24] 1732 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005606 EC               [12] 1733 	mov	a,r4
      005607 F0               [24] 1734 	movx	@dptr,a
      005608 90 07 2F         [24] 1735 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00560B EB               [12] 1736 	mov	a,r3
      00560C F0               [24] 1737 	movx	@dptr,a
      00560D 90 07 30         [24] 1738 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005610 EA               [12] 1739 	mov	a,r2
      005611 F0               [24] 1740 	movx	@dptr,a
      005612 12 38 65         [24] 1741 	lcall	_ak820_outline_0131
      005615 12 52 B3         [24] 1742 	lcall	_rgb_matrix_set_color
      005618                       1743 00123$:
                                   1744 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005618 12 59 12         [24] 1745 	lcall	_ak820_outline_0181
      00561B 24 01            [12] 1746 	add	a, #0x01
      00561D F0               [24] 1747 	movx	@dptr,a
      00561E 02 54 AF         [24] 1748 	ljmp	00125$
      005621                       1749 00127$:
                                   1750 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005621 BF 52 02         [24] 1751 	cjne	r7,#0x52,00130$
                                   1752 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1753 ;	assignBit
      005624 C2 11            [12] 1754 	clr	_rendering
      005626                       1755 00130$:
                                   1756 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005626 22               [24] 1757 	ret
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1760 ;------------------------------------------------------------
                                   1761 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1762 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1763 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1764 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1765 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1766 ;------------------------------------------------------------
                                   1767 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1768 ;	-----------------------------------------
                                   1769 ;	 function process_rgb_matrix
                                   1770 ;	-----------------------------------------
      005627                       1771 _process_rgb_matrix:
      005627 E5 82            [12] 1772 	mov	a,dpl
      005629 90 07 43         [24] 1773 	mov	dptr,#_process_rgb_matrix_row_10000_319
      00562C F0               [24] 1774 	movx	@dptr,a
                                   1775 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      00562D 90 07 42         [24] 1776 	mov	dptr,#_process_rgb_matrix_PARM_3
      005630 E0               [24] 1777 	movx	a,@dptr
      005631 60 23            [24] 1778 	jz	00101$
      005633 20 0F 20         [24] 1779 	jb	_suspended,00101$
      005636 12 58 B8         [24] 1780 	lcall	_ak820_outline_0065
      005639 60 1B            [24] 1781 	jz	00101$
                                   1782 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      00563B 12 58 99         [24] 1783 	lcall	_ak820_outline_0017
      00563E FF               [12] 1784 	mov	r7,a
      00563F BF 06 14         [24] 1785 	cjne	r7,#0x06,00101$
      005642 90 07 43         [24] 1786 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005645 E0               [24] 1787 	movx	a,@dptr
      005646 FF               [12] 1788 	mov	r7,a
      005647 BF 10 00         [24] 1789 	cjne	r7,#0x10,00169$
      00564A                       1790 00169$:
      00564A 50 0A            [24] 1791 	jnc	00101$
      00564C 90 07 41         [24] 1792 	mov	dptr,#_process_rgb_matrix_PARM_2
      00564F E0               [24] 1793 	movx	a,@dptr
      005650 FE               [12] 1794 	mov	r6,a
      005651 BE 08 00         [24] 1795 	cjne	r6,#0x08,00171$
      005654                       1796 00171$:
      005654 40 01            [24] 1797 	jc	00102$
      005656                       1798 00101$:
      005656 22               [24] 1799 	ret
      005657                       1800 00102$:
                                   1801 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005657 C0 07            [24] 1802 	push	ar7
      005659 C0 06            [24] 1803 	push	ar6
      00565B 12 51 3E         [24] 1804 	lcall	_age_reactive
      00565E D0 06            [24] 1805 	pop	ar6
      005660 D0 07            [24] 1806 	pop	ar7
                                   1807 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005662 EF               [12] 1808 	mov	a,r7
      005663 12 38 8B         [24] 1809 	lcall	_ak820_outline_0184
      005666 2E               [12] 1810 	add	a,r6
      005667 FF               [12] 1811 	mov	r7,a
                                   1812 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005668 7E 00            [12] 1813 	mov	r6,#0x00
      00566A                       1814 00111$:
                                   1815 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      00566A EE               [12] 1816 	mov	a,r6
      00566B 90 B9 76         [24] 1817 	mov	dptr,#_ak820_rgb_slots
      00566E 93               [24] 1818 	movc	a,@a+dptr
      00566F B5 07 29         [24] 1819 	cjne	a,ar7,00112$
                                   1820 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005672 EE               [12] 1821 	mov	a,r6
      005673 24 D6            [12] 1822 	add	a, #_reactive_age
      005675 FC               [12] 1823 	mov	r4,a
      005676 E4               [12] 1824 	clr	a
      005677 34 06            [12] 1825 	addc	a, #(_reactive_age >> 8)
      005679 FD               [12] 1826 	mov	r5,a
      00567A 12 59 00         [24] 1827 	lcall	_ak820_outline_0169
      00567D F5 F0            [12] 1828 	mov	b, a
      00567F 05 F0            [12] 1829 	inc	b
      005681 7B 80            [12] 1830 	mov	r3,#0x80
      005683 E4               [12] 1831 	clr	a
      005684 FA               [12] 1832 	mov	r2,a
      005685 33               [12] 1833 	rlc	a
      005686 92 D2            [24] 1834 	mov	ov,c
      005688 80 08            [24] 1835 	sjmp	00176$
      00568A                       1836 00175$:
      00568A A2 D2            [12] 1837 	mov	c,ov
      00568C EA               [12] 1838 	mov	a,r2
      00568D 13               [12] 1839 	rrc	a
      00568E FA               [12] 1840 	mov	r2,a
      00568F EB               [12] 1841 	mov	a,r3
      005690 13               [12] 1842 	rrc	a
      005691 FB               [12] 1843 	mov	r3,a
      005692                       1844 00176$:
      005692 D5 F0 F5         [24] 1845 	djnz	b,00175$
      005695 12 38 55         [24] 1846 	lcall	_ak820_outline_0117
      005698 EB               [12] 1847 	mov	a,r3
      005699 F0               [24] 1848 	movx	@dptr,a
                                   1849 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      00569A 22               [24] 1850 	ret
      00569B                       1851 00112$:
                                   1852 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00569B 0E               [12] 1853 	inc	r6
      00569C BE 52 00         [24] 1854 	cjne	r6,#0x52,00177$
      00569F                       1855 00177$:
      00569F 40 C9            [24] 1856 	jc	00111$
                                   1857 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      0056A1 22               [24] 1858 	ret
                                   1859 ;------------------------------------------------------------
                                   1860 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1861 ;------------------------------------------------------------
                                   1862 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1863 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1864 ;------------------------------------------------------------
                                   1865 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1866 ;	-----------------------------------------
                                   1867 ;	 function rgb_matrix_set_suspend_state
                                   1868 ;	-----------------------------------------
      0056A2                       1869 _rgb_matrix_set_suspend_state:
      0056A2 E5 82            [12] 1870 	mov	a,dpl
      0056A4 90 07 44         [24] 1871 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      0056A7 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      0056A8 E0               [24] 1874 	movx	a,@dptr
                                   1875 ;	assignBit
      0056A9 F5 17            [12] 1876 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      0056AB 13               [12] 1877 	rrc	a
      0056AC 92 0F            [24] 1878 	mov	_suspended,c
                                   1879 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1880 ;	assignBit
      0056AE C2 11            [12] 1881 	clr	_rendering
                                   1882 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      0056B0 12 51 21         [24] 1883 	lcall	_clear_reactive
                                   1884 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      0056B3 E5 17            [12] 1885 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      0056B5 60 0F            [24] 1886 	jz	00103$
                                   1887 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      0056B7 90 07 33         [24] 1888 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0056BA E4               [12] 1889 	clr	a
      0056BB F0               [24] 1890 	movx	@dptr,a
      0056BC 90 07 34         [24] 1891 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0056BF F0               [24] 1892 	movx	@dptr,a
      0056C0 75 82 00         [24] 1893 	mov	dpl, #0x00
                                   1894 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      0056C3 02 52 F4         [24] 1895 	ljmp	_rgb_matrix_set_color_all
      0056C6                       1896 00103$:
      0056C6 22               [24] 1897 	ret
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function rgb_matrix_is_enabled
                                   1904 ;	-----------------------------------------
      0056C7                       1905 _rgb_matrix_is_enabled:
      0056C7 12 58 B8         [24] 1906 	lcall	_ak820_outline_0065
      0056CA F5 82            [12] 1907 	mov	dpl,a
      0056CC 22               [24] 1908 	ret
                                   1909 ;------------------------------------------------------------
                                   1910 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1911 ;------------------------------------------------------------
                                   1912 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1913 ;	-----------------------------------------
                                   1914 ;	 function rgb_matrix_get_mode
                                   1915 ;	-----------------------------------------
      0056CD                       1916 _rgb_matrix_get_mode:
      0056CD 12 58 99         [24] 1917 	lcall	_ak820_outline_0017
      0056D0 F5 82            [12] 1918 	mov	dpl,a
      0056D2 22               [24] 1919 	ret
                                   1920 ;------------------------------------------------------------
                                   1921 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1922 ;------------------------------------------------------------
                                   1923 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1924 ;	-----------------------------------------
                                   1925 ;	 function rgb_matrix_get_hue
                                   1926 ;	-----------------------------------------
      0056D3                       1927 _rgb_matrix_get_hue:
      0056D3 90 06 C2         [24] 1928 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0056D6 E0               [24] 1929 	movx	a,@dptr
      0056D7 F5 82            [12] 1930 	mov	dpl,a
      0056D9 22               [24] 1931 	ret
                                   1932 ;------------------------------------------------------------
                                   1933 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1934 ;------------------------------------------------------------
                                   1935 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1936 ;	-----------------------------------------
                                   1937 ;	 function rgb_matrix_get_sat
                                   1938 ;	-----------------------------------------
      0056DA                       1939 _rgb_matrix_get_sat:
      0056DA 90 06 C3         [24] 1940 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0056DD E0               [24] 1941 	movx	a,@dptr
      0056DE F5 82            [12] 1942 	mov	dpl,a
      0056E0 22               [24] 1943 	ret
                                   1944 ;------------------------------------------------------------
                                   1945 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function rgb_matrix_get_val
                                   1950 ;	-----------------------------------------
      0056E1                       1951 _rgb_matrix_get_val:
      0056E1 90 06 C4         [24] 1952 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0056E4 E0               [24] 1953 	movx	a,@dptr
      0056E5 F5 82            [12] 1954 	mov	dpl,a
      0056E7 22               [24] 1955 	ret
                                   1956 ;------------------------------------------------------------
                                   1957 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1958 ;------------------------------------------------------------
                                   1959 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1960 ;	-----------------------------------------
                                   1961 ;	 function rgb_matrix_get_speed
                                   1962 ;	-----------------------------------------
      0056E8                       1963 _rgb_matrix_get_speed:
      0056E8 90 06 C5         [24] 1964 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0056EB E0               [24] 1965 	movx	a,@dptr
      0056EC F5 82            [12] 1966 	mov	dpl,a
      0056EE 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1970 ;------------------------------------------------------------
                                   1971 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1972 ;	-----------------------------------------
                                   1973 ;	 function rgb_matrix_toggle_noeeprom
                                   1974 ;	-----------------------------------------
      0056EF                       1975 _rgb_matrix_toggle_noeeprom:
      0056EF 12 58 B8         [24] 1976 	lcall	_ak820_outline_0065
      0056F2 FF               [12] 1977 	mov	r7,a
      0056F3 63 07 01         [24] 1978 	xrl	ar7,#0x01
      0056F6 90 06 C1         [24] 1979 	mov	dptr,#_rgb_matrix_config
      0056F9 EF               [12] 1980 	mov	a,r7
      0056FA 54 03            [12] 1981 	anl	a,#0x03
      0056FC F5 F0            [12] 1982 	mov	b,a
      0056FE E0               [24] 1983 	movx	a,@dptr
      0056FF 54 FC            [12] 1984 	anl	a,#0xfc
      005701 45 F0            [12] 1985 	orl	a,b
      005703 F0               [24] 1986 	movx	@dptr,a
                                   1987 ;	assignBit
      005704 C2 11            [12] 1988 	clr	_rendering
      005706 02 51 21         [24] 1989 	ljmp	_clear_reactive
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1992 ;------------------------------------------------------------
                                   1993 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1994 ;	-----------------------------------------
                                   1995 ;	 function rgb_matrix_enable_noeeprom
                                   1996 ;	-----------------------------------------
      005709                       1997 _rgb_matrix_enable_noeeprom:
      005709 12 58 B8         [24] 1998 	lcall	_ak820_outline_0065
      00570C 70 03            [24] 1999 	jnz	00102$
      00570E 12 51 21         [24] 2000 	lcall	_clear_reactive
      005711                       2001 00102$:
      005711 12 58 E8         [24] 2002 	lcall	_ak820_outline_0111
      005714 44 01            [12] 2003 	orl	a,#0x01
      005716 F0               [24] 2004 	movx	@dptr,a
                                   2005 ;	assignBit
      005717 C2 11            [12] 2006 	clr	_rendering
      005719 22               [24] 2007 	ret
                                   2008 ;------------------------------------------------------------
                                   2009 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2010 ;------------------------------------------------------------
                                   2011 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2012 ;	-----------------------------------------
                                   2013 ;	 function rgb_matrix_disable_noeeprom
                                   2014 ;	-----------------------------------------
      00571A                       2015 _rgb_matrix_disable_noeeprom:
      00571A 12 58 E8         [24] 2016 	lcall	_ak820_outline_0111
      00571D F0               [24] 2017 	movx	@dptr,a
                                   2018 ;	assignBit
      00571E C2 11            [12] 2019 	clr	_rendering
      005720 02 51 21         [24] 2020 	ljmp	_clear_reactive
                                   2021 ;------------------------------------------------------------
                                   2022 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2023 ;------------------------------------------------------------
                                   2024 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2025 ;------------------------------------------------------------
                                   2026 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2027 ;	-----------------------------------------
                                   2028 ;	 function rgb_matrix_mode_noeeprom
                                   2029 ;	-----------------------------------------
      005723                       2030 _rgb_matrix_mode_noeeprom:
      005723 E5 82            [12] 2031 	mov	a,dpl
      005725 90 07 45         [24] 2032 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005728 F0               [24] 2033 	movx	@dptr,a
                                   2034 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005729 E0               [24] 2035 	movx	a,@dptr
      00572A FF               [12] 2036 	mov	r7,a
      00572B 60 05            [24] 2037 	jz	00101$
      00572D BF 07 00         [24] 2038 	cjne	r7,#0x07,00123$
      005730                       2039 00123$:
      005730 40 01            [24] 2040 	jc	00102$
      005732                       2041 00101$:
      005732 22               [24] 2042 	ret
      005733                       2043 00102$:
                                   2044 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005733 12 58 99         [24] 2045 	lcall	_ak820_outline_0017
      005736 FE               [12] 2046 	mov	r6,a
      005737 EF               [12] 2047 	mov	a,r7
      005738 B5 06 02         [24] 2048 	cjne	a,ar6,00125$
      00573B 80 03            [24] 2049 	sjmp	00105$
      00573D                       2050 00125$:
      00573D 12 51 21         [24] 2051 	lcall	_clear_reactive
      005740                       2052 00105$:
                                   2053 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005740 90 07 45         [24] 2054 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005743 E0               [24] 2055 	movx	a,@dptr
      005744 90 06 C1         [24] 2056 	mov	dptr,#_rgb_matrix_config
      005747 25 E0            [12] 2057 	add	a,acc
      005749 25 E0            [12] 2058 	add	a,acc
      00574B 54 FC            [12] 2059 	anl	a,#0xfc
      00574D F5 F0            [12] 2060 	mov	b,a
      00574F E0               [24] 2061 	movx	a,@dptr
      005750 54 03            [12] 2062 	anl	a,#0x03
      005752 45 F0            [12] 2063 	orl	a,b
      005754 F0               [24] 2064 	movx	@dptr,a
                                   2065 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2066 ;	assignBit
      005755 C2 11            [12] 2067 	clr	_rendering
                                   2068 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005757 22               [24] 2069 	ret
                                   2070 ;------------------------------------------------------------
                                   2071 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2072 ;------------------------------------------------------------
                                   2073 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2074 ;	-----------------------------------------
                                   2075 ;	 function rgb_matrix_step_noeeprom
                                   2076 ;	-----------------------------------------
      005758                       2077 _rgb_matrix_step_noeeprom:
                                   2078 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005758 12 58 99         [24] 2079 	lcall	_ak820_outline_0017
      00575B FF               [12] 2080 	mov	r7,a
      00575C 0F               [12] 2081 	inc	r7
      00575D BF 07 00         [24] 2082 	cjne	r7,#0x07,00112$
      005760                       2083 00112$:
      005760 40 04            [24] 2084 	jc	00103$
      005762 7F 01            [12] 2085 	mov	r7,#0x01
      005764 80 07            [24] 2086 	sjmp	00104$
      005766                       2087 00103$:
      005766 12 58 99         [24] 2088 	lcall	_ak820_outline_0017
      005769 FE               [12] 2089 	mov	r6,a
      00576A 0E               [12] 2090 	inc	r6
      00576B 8E 07            [24] 2091 	mov	ar7,r6
      00576D                       2092 00104$:
      00576D 8F 82            [24] 2093 	mov	dpl, r7
                                   2094 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      00576F 02 57 23         [24] 2095 	ljmp	_rgb_matrix_mode_noeeprom
                                   2096 ;------------------------------------------------------------
                                   2097 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2098 ;------------------------------------------------------------
                                   2099 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2100 ;	-----------------------------------------
                                   2101 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2102 ;	-----------------------------------------
      005772                       2103 _rgb_matrix_step_reverse_noeeprom:
                                   2104 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005772 12 58 99         [24] 2105 	lcall	_ak820_outline_0017
      005775 24 FE            [12] 2106 	add	a,#0xff - 0x01
      005777 40 04            [24] 2107 	jc	00103$
                                   2108 ;	free result
      005779 7F 06            [12] 2109 	mov	r7,#0x06
      00577B 80 05            [24] 2110 	sjmp	00104$
      00577D                       2111 00103$:
      00577D 12 58 99         [24] 2112 	lcall	_ak820_outline_0017
      005780 14               [12] 2113 	dec	a
      005781 FF               [12] 2114 	mov	r7,a
      005782                       2115 00104$:
      005782 8F 82            [24] 2116 	mov	dpl, r7
                                   2117 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005784 02 57 23         [24] 2118 	ljmp	_rgb_matrix_mode_noeeprom
                                   2119 ;------------------------------------------------------------
                                   2120 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2121 ;------------------------------------------------------------
                                   2122 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2123 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2124 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2125 ;------------------------------------------------------------
                                   2126 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2127 ;	-----------------------------------------
                                   2128 ;	 function rgb_matrix_sethsv_noeeprom
                                   2129 ;	-----------------------------------------
      005787                       2130 _rgb_matrix_sethsv_noeeprom:
      005787 12 38 4B         [24] 2131 	lcall	_ak820_outline_0104
      00578A 90 07 48         [24] 2132 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      00578D 12 38 50         [24] 2133 	lcall	_ak820_outline_0105
                                   2134 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005790 90 07 48         [24] 2135 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005793 E0               [24] 2136 	movx	a,@dptr
      005794 90 06 C2         [24] 2137 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005797 F0               [24] 2138 	movx	@dptr,a
                                   2139 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005798 90 07 46         [24] 2140 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00579B E0               [24] 2141 	movx	a,@dptr
      00579C FF               [12] 2142 	mov	r7,a
      00579D 90 06 C3         [24] 2143 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0057A0 F0               [24] 2144 	movx	@dptr,a
                                   2145 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      0057A1 90 07 47         [24] 2146 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      0057A4 E0               [24] 2147 	movx	a,@dptr
      0057A5 FF               [12] 2148 	mov  r7,a
      0057A6 24 5F            [12] 2149 	add	a,#0xff - 0xa0
      0057A8 50 04            [24] 2150 	jnc	00103$
                                   2151 ;	free result
      0057AA 7E A0            [12] 2152 	mov	r6,#0xa0
      0057AC 80 02            [24] 2153 	sjmp	00104$
      0057AE                       2154 00103$:
      0057AE 8F 06            [24] 2155 	mov	ar6,r7
      0057B0                       2156 00104$:
      0057B0 90 06 C4         [24] 2157 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0057B3 EE               [12] 2158 	mov	a,r6
      0057B4 F0               [24] 2159 	movx	@dptr,a
                                   2160 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      0057B5 22               [24] 2161 	ret
                                   2162 ;------------------------------------------------------------
                                   2163 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2164 ;------------------------------------------------------------
                                   2165 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2166 ;------------------------------------------------------------
                                   2167 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2168 ;	-----------------------------------------
                                   2169 ;	 function rgb_matrix_set_speed_noeeprom
                                   2170 ;	-----------------------------------------
      0057B6                       2171 _rgb_matrix_set_speed_noeeprom:
      0057B6 E5 82            [12] 2172 	mov	a,dpl
      0057B8 90 07 4A         [24] 2173 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      0057BB F0               [24] 2174 	movx	@dptr,a
      0057BC E0               [24] 2175 	movx	a,@dptr
      0057BD 90 06 C5         [24] 2176 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0057C0 F0               [24] 2177 	movx	@dptr,a
      0057C1 22               [24] 2178 	ret
                                   2179 ;------------------------------------------------------------
                                   2180 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2181 ;------------------------------------------------------------
                                   2182 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2183 ;------------------------------------------------------------
                                   2184 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2185 ;	-----------------------------------------
                                   2186 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2187 ;	-----------------------------------------
      0057C2                       2188 _rgb_matrix_increase_hue_noeeprom:
      0057C2 90 06 C2         [24] 2189 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0057C5 E0               [24] 2190 	movx	a,@dptr
      0057C6 24 08            [12] 2191 	add	a,#0x08
      0057C8 90 06 C2         [24] 2192 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0057CB F0               [24] 2193 	movx	@dptr,a
      0057CC 22               [24] 2194 	ret
                                   2195 ;------------------------------------------------------------
                                   2196 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2197 ;------------------------------------------------------------
                                   2198 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2199 ;	-----------------------------------------
                                   2200 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2201 ;	-----------------------------------------
      0057CD                       2202 _rgb_matrix_decrease_hue_noeeprom:
      0057CD 90 06 C2         [24] 2203 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0057D0 E0               [24] 2204 	movx	a,@dptr
      0057D1 24 F8            [12] 2205 	add	a,#0xf8
      0057D3 90 06 C2         [24] 2206 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0057D6 F0               [24] 2207 	movx	@dptr,a
      0057D7 22               [24] 2208 	ret
                                   2209 ;------------------------------------------------------------
                                   2210 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2211 ;------------------------------------------------------------
                                   2212 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2213 ;	-----------------------------------------
                                   2214 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2215 ;	-----------------------------------------
      0057D8                       2216 _rgb_matrix_increase_sat_noeeprom:
      0057D8 90 06 C3         [24] 2217 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0057DB 12 58 A2         [24] 2218 	lcall	_ak820_outline_0046
      0057DE 12 51 BC         [24] 2219 	lcall	_add_sat
      0057E1 AF 82            [24] 2220 	mov	r7, dpl
      0057E3 90 06 C3         [24] 2221 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0057E6 EF               [12] 2222 	mov	a,r7
      0057E7 F0               [24] 2223 	movx	@dptr,a
      0057E8 22               [24] 2224 	ret
                                   2225 ;------------------------------------------------------------
                                   2226 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2227 ;------------------------------------------------------------
                                   2228 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2229 ;	-----------------------------------------
                                   2230 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2231 ;	-----------------------------------------
      0057E9                       2232 _rgb_matrix_decrease_sat_noeeprom:
      0057E9 90 06 C3         [24] 2233 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0057EC 12 58 AD         [24] 2234 	lcall	_ak820_outline_0047
      0057EF 12 51 E1         [24] 2235 	lcall	_sub_sat
      0057F2 AF 82            [24] 2236 	mov	r7, dpl
      0057F4 90 06 C3         [24] 2237 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0057F7 EF               [12] 2238 	mov	a,r7
      0057F8 F0               [24] 2239 	movx	@dptr,a
      0057F9 22               [24] 2240 	ret
                                   2241 ;------------------------------------------------------------
                                   2242 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2243 ;------------------------------------------------------------
                                   2244 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2245 ;------------------------------------------------------------
                                   2246 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2247 ;	-----------------------------------------
                                   2248 ;	 function rgb_matrix_increase_val_noeeprom
                                   2249 ;	-----------------------------------------
      0057FA                       2250 _rgb_matrix_increase_val_noeeprom:
                                   2251 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      0057FA 90 06 C4         [24] 2252 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0057FD 12 58 A2         [24] 2253 	lcall	_ak820_outline_0046
      005800 12 51 BC         [24] 2254 	lcall	_add_sat
                                   2255 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005803 E5 82            [12] 2256 	mov	a,dpl
      005805 FF               [12] 2257 	mov	r7,a
      005806 24 5F            [12] 2258 	add	a,#0xff - 0xa0
      005808 50 04            [24] 2259 	jnc	00103$
                                   2260 ;	free result
      00580A 7E A0            [12] 2261 	mov	r6,#0xa0
      00580C 80 02            [24] 2262 	sjmp	00104$
      00580E                       2263 00103$:
      00580E 8F 06            [24] 2264 	mov	ar6,r7
      005810                       2265 00104$:
      005810 90 06 C4         [24] 2266 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005813 EE               [12] 2267 	mov	a,r6
      005814 F0               [24] 2268 	movx	@dptr,a
                                   2269 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005815 22               [24] 2270 	ret
                                   2271 ;------------------------------------------------------------
                                   2272 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2273 ;------------------------------------------------------------
                                   2274 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2275 ;	-----------------------------------------
                                   2276 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2277 ;	-----------------------------------------
      005816                       2278 _rgb_matrix_decrease_val_noeeprom:
      005816 90 06 C4         [24] 2279 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005819 12 58 AD         [24] 2280 	lcall	_ak820_outline_0047
      00581C 12 51 E1         [24] 2281 	lcall	_sub_sat
      00581F AF 82            [24] 2282 	mov	r7, dpl
      005821 90 06 C4         [24] 2283 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005824 EF               [12] 2284 	mov	a,r7
      005825 F0               [24] 2285 	movx	@dptr,a
      005826 22               [24] 2286 	ret
                                   2287 ;------------------------------------------------------------
                                   2288 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2289 ;------------------------------------------------------------
                                   2290 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2291 ;	-----------------------------------------
                                   2292 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2293 ;	-----------------------------------------
      005827                       2294 _rgb_matrix_increase_speed_noeeprom:
      005827 90 06 C5         [24] 2295 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00582A 12 58 A2         [24] 2296 	lcall	_ak820_outline_0046
      00582D 12 51 BC         [24] 2297 	lcall	_add_sat
      005830 AF 82            [24] 2298 	mov	r7, dpl
      005832 90 06 C5         [24] 2299 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005835 EF               [12] 2300 	mov	a,r7
      005836 F0               [24] 2301 	movx	@dptr,a
      005837 22               [24] 2302 	ret
                                   2303 ;------------------------------------------------------------
                                   2304 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2305 ;------------------------------------------------------------
                                   2306 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2307 ;	-----------------------------------------
                                   2308 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2309 ;	-----------------------------------------
      005838                       2310 _rgb_matrix_decrease_speed_noeeprom:
      005838 90 06 C5         [24] 2311 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00583B 12 58 AD         [24] 2312 	lcall	_ak820_outline_0047
      00583E 12 51 E1         [24] 2313 	lcall	_sub_sat
      005841 AF 82            [24] 2314 	mov	r7, dpl
      005843 90 06 C5         [24] 2315 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005846 EF               [12] 2316 	mov	a,r7
      005847 F0               [24] 2317 	movx	@dptr,a
      005848 22               [24] 2318 	ret
                                   2319 ;------------------------------------------------------------
                                   2320 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2321 ;------------------------------------------------------------
                                   2322 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2323 ;	-----------------------------------------
                                   2324 ;	 function rgb_matrix_toggle
                                   2325 ;	-----------------------------------------
      005849                       2326 _rgb_matrix_toggle:
      005849 12 56 EF         [24] 2327 	lcall	_rgb_matrix_toggle_noeeprom
      00584C 02 51 FE         [24] 2328 	ljmp	_mark_dirty
                                   2329 ;------------------------------------------------------------
                                   2330 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2331 ;------------------------------------------------------------
                                   2332 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2333 ;	-----------------------------------------
                                   2334 ;	 function rgb_matrix_step
                                   2335 ;	-----------------------------------------
      00584F                       2336 _rgb_matrix_step:
      00584F 12 57 58         [24] 2337 	lcall	_rgb_matrix_step_noeeprom
      005852 02 51 FE         [24] 2338 	ljmp	_mark_dirty
                                   2339 ;------------------------------------------------------------
                                   2340 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2341 ;------------------------------------------------------------
                                   2342 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2343 ;	-----------------------------------------
                                   2344 ;	 function rgb_matrix_step_reverse
                                   2345 ;	-----------------------------------------
      005855                       2346 _rgb_matrix_step_reverse:
      005855 12 57 72         [24] 2347 	lcall	_rgb_matrix_step_reverse_noeeprom
      005858 02 51 FE         [24] 2348 	ljmp	_mark_dirty
                                   2349 ;------------------------------------------------------------
                                   2350 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2351 ;------------------------------------------------------------
                                   2352 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2353 ;	-----------------------------------------
                                   2354 ;	 function rgb_matrix_increase_hue
                                   2355 ;	-----------------------------------------
      00585B                       2356 _rgb_matrix_increase_hue:
      00585B 12 57 C2         [24] 2357 	lcall	_rgb_matrix_increase_hue_noeeprom
      00585E 02 51 FE         [24] 2358 	ljmp	_mark_dirty
                                   2359 ;------------------------------------------------------------
                                   2360 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2361 ;------------------------------------------------------------
                                   2362 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2363 ;	-----------------------------------------
                                   2364 ;	 function rgb_matrix_decrease_hue
                                   2365 ;	-----------------------------------------
      005861                       2366 _rgb_matrix_decrease_hue:
      005861 12 57 CD         [24] 2367 	lcall	_rgb_matrix_decrease_hue_noeeprom
      005864 02 51 FE         [24] 2368 	ljmp	_mark_dirty
                                   2369 ;------------------------------------------------------------
                                   2370 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2371 ;------------------------------------------------------------
                                   2372 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2373 ;	-----------------------------------------
                                   2374 ;	 function rgb_matrix_increase_sat
                                   2375 ;	-----------------------------------------
      005867                       2376 _rgb_matrix_increase_sat:
      005867 12 57 D8         [24] 2377 	lcall	_rgb_matrix_increase_sat_noeeprom
      00586A 02 51 FE         [24] 2378 	ljmp	_mark_dirty
                                   2379 ;------------------------------------------------------------
                                   2380 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2381 ;------------------------------------------------------------
                                   2382 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2383 ;	-----------------------------------------
                                   2384 ;	 function rgb_matrix_decrease_sat
                                   2385 ;	-----------------------------------------
      00586D                       2386 _rgb_matrix_decrease_sat:
      00586D 12 57 E9         [24] 2387 	lcall	_rgb_matrix_decrease_sat_noeeprom
      005870 02 51 FE         [24] 2388 	ljmp	_mark_dirty
                                   2389 ;------------------------------------------------------------
                                   2390 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2391 ;------------------------------------------------------------
                                   2392 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2393 ;	-----------------------------------------
                                   2394 ;	 function rgb_matrix_increase_val
                                   2395 ;	-----------------------------------------
      005873                       2396 _rgb_matrix_increase_val:
      005873 12 57 FA         [24] 2397 	lcall	_rgb_matrix_increase_val_noeeprom
      005876 02 51 FE         [24] 2398 	ljmp	_mark_dirty
                                   2399 ;------------------------------------------------------------
                                   2400 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2401 ;------------------------------------------------------------
                                   2402 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2403 ;	-----------------------------------------
                                   2404 ;	 function rgb_matrix_decrease_val
                                   2405 ;	-----------------------------------------
      005879                       2406 _rgb_matrix_decrease_val:
      005879 12 58 16         [24] 2407 	lcall	_rgb_matrix_decrease_val_noeeprom
      00587C 02 51 FE         [24] 2408 	ljmp	_mark_dirty
                                   2409 ;------------------------------------------------------------
                                   2410 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function rgb_matrix_increase_speed
                                   2415 ;	-----------------------------------------
      00587F                       2416 _rgb_matrix_increase_speed:
      00587F 12 58 27         [24] 2417 	lcall	_rgb_matrix_increase_speed_noeeprom
      005882 02 51 FE         [24] 2418 	ljmp	_mark_dirty
                                   2419 ;------------------------------------------------------------
                                   2420 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function rgb_matrix_decrease_speed
                                   2425 ;	-----------------------------------------
      005885                       2426 _rgb_matrix_decrease_speed:
      005885 12 58 38         [24] 2427 	lcall	_rgb_matrix_decrease_speed_noeeprom
      005888 02 51 FE         [24] 2428 	ljmp	_mark_dirty
                                   2429 ;------------------------------------------------------------
                                   2430 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2431 ;------------------------------------------------------------
                                   2432 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2433 ;------------------------------------------------------------
                                   2434 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2435 ;	-----------------------------------------
                                   2436 ;	 function rgb_matrix_mode
                                   2437 ;	-----------------------------------------
      00588B                       2438 _rgb_matrix_mode:
      00588B E5 82            [12] 2439 	mov	a,dpl
      00588D 90 07 4B         [24] 2440 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005890 12 58 FB         [24] 2441 	lcall	_ak820_outline_0167
      005893 12 57 23         [24] 2442 	lcall	_rgb_matrix_mode_noeeprom
      005896 02 51 FE         [24] 2443 	ljmp	_mark_dirty
                                   2444 ;------------------------------------------------------------
                                   2445 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2446 ;------------------------------------------------------------
                                   2447 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2448 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2449 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2450 ;------------------------------------------------------------
                                   2451 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2452 ;	-----------------------------------------
                                   2453 	.area CSEG    (CODE)
                                   2454 	.area CONST   (CODE)
                                   2455 	.area CONST   (CODE)
      00B9C8                       2456 _sine8_coefficients_10000_290:
      00B9C8 00                    2457 	.db #0x00	; 0
      00B9C9 31                    2458 	.db #0x31	; 49	'1'
      00B9CA 31                    2459 	.db #0x31	; 49	'1'
      00B9CB 29                    2460 	.db #0x29	; 41
      00B9CC 5A                    2461 	.db #0x5a	; 90	'Z'
      00B9CD 1B                    2462 	.db #0x1b	; 27
      00B9CE 75                    2463 	.db #0x75	; 117	'u'
      00B9CF 0A                    2464 	.db #0x0a	; 10
                                   2465 	.area CSEG    (CODE)
                                   2466 	.area XINIT   (CODE)
                                   2467 	.area CABS    (ABS,CODE)
                                   2468 
                                   2469 ; Experimental exact instruction outlining.
                                   2470 	.globl _ak820_outline_0004
                                   2471 	.globl _ak820_outline_0017
                                   2472 	.globl _ak820_outline_0046
                                   2473 	.globl _ak820_outline_0047
                                   2474 	.globl _ak820_outline_0050
                                   2475 	.globl _ak820_outline_0058
                                   2476 	.globl _ak820_outline_0059
                                   2477 	.globl _ak820_outline_0065
                                   2478 	.globl _ak820_outline_0069
                                   2479 	.globl _ak820_outline_0071
                                   2480 	.globl _ak820_outline_0082
                                   2481 	.globl _ak820_outline_0104
                                   2482 	.globl _ak820_outline_0105
                                   2483 	.globl _ak820_outline_0106
                                   2484 	.globl _ak820_outline_0111
                                   2485 	.globl _ak820_outline_0117
                                   2486 	.globl _ak820_outline_0119
                                   2487 	.globl _ak820_outline_0122
                                   2488 	.globl _ak820_outline_0130
                                   2489 	.globl _ak820_outline_0131
                                   2490 	.globl _ak820_outline_0134
                                   2491 	.globl _ak820_outline_0136
                                   2492 	.globl _ak820_outline_0163
                                   2493 	.globl _ak820_outline_0166
                                   2494 	.globl _ak820_outline_0167
                                   2495 	.globl _ak820_outline_0169
                                   2496 	.globl _ak820_outline_0175
                                   2497 	.globl _ak820_outline_0181
                                   2498 	.globl _ak820_outline_0182
                                   2499 	.globl _ak820_outline_0184
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0017
      005899                       2503 _ak820_outline_0017:
      005899 90 06 C1         [24] 2504 	mov	dptr,#_rgb_matrix_config
      00589C E0               [24] 2505 	movx	a,@dptr
      00589D 03               [12] 2506 	rr	a
      00589E 03               [12] 2507 	rr	a
      00589F 54 3F            [12] 2508 	anl	a,#0x3f
      0058A1 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0046
      0058A2                       2513 _ak820_outline_0046:
      0058A2 E0               [24] 2514 	movx	a,@dptr
      0058A3 FF               [12] 2515 	mov	r7,a
      0058A4 90 07 2A         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      0058A7 74 10            [12] 2517 	mov	a,#0x10
      0058A9 F0               [24] 2518 	movx	@dptr,a
      0058AA 8F 82            [24] 2519 	mov	dpl,r7
      0058AC 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0047
      0058AD                       2524 _ak820_outline_0047:
      0058AD E0               [24] 2525 	movx	a,@dptr
      0058AE FF               [12] 2526 	mov	r7,a
      0058AF 90 07 2C         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      0058B2 74 10            [12] 2528 	mov	a,#0x10
      0058B4 F0               [24] 2529 	movx	@dptr,a
      0058B5 8F 82            [24] 2530 	mov	dpl,r7
      0058B7 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0065
      0058B8                       2535 _ak820_outline_0065:
      0058B8 90 06 C1         [24] 2536 	mov	dptr,#_rgb_matrix_config
      0058BB E0               [24] 2537 	movx	a,@dptr
      0058BC 54 03            [12] 2538 	anl	a,#0x03
      0058BE 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0069
      0058BF                       2543 _ak820_outline_0069:
      0058BF 74 08            [12] 2544 	mov	a,#0x08
      0058C1 F0               [24] 2545 	movx	@dptr,a
      0058C2 E4               [12] 2546 	clr	a
      0058C3 A3               [24] 2547 	inc	dptr
      0058C4 F0               [24] 2548 	movx	@dptr,a
      0058C5 90 06 C1         [24] 2549 	mov	dptr,#_rgb_matrix_config
      0058C8 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0071
      0058C9                       2554 _ak820_outline_0071:
      0058C9 A3               [24] 2555 	inc	dptr
      0058CA F0               [24] 2556 	movx	@dptr,a
      0058CB E4               [12] 2557 	clr	a
      0058CC A3               [24] 2558 	inc	dptr
      0058CD F0               [24] 2559 	movx	@dptr,a
      0058CE 90 0D 8D         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      0058D1 74 03            [12] 2561 	mov	a,#0x03
      0058D3 F0               [24] 2562 	movx	@dptr,a
      0058D4 E4               [12] 2563 	clr	a
      0058D5 A3               [24] 2564 	inc	dptr
      0058D6 F0               [24] 2565 	movx	@dptr,a
      0058D7 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0082
      0058D8                       2570 _ak820_outline_0082:
      0058D8 74 18            [12] 2571 	mov	a,#0x18
      0058DA F0               [24] 2572 	movx	@dptr,a
      0058DB E4               [12] 2573 	clr	a
      0058DC A3               [24] 2574 	inc	dptr
      0058DD F0               [24] 2575 	movx	@dptr,a
      0058DE A3               [24] 2576 	inc	dptr
      0058DF F0               [24] 2577 	movx	@dptr,a
      0058E0 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0106
      0058E1                       2582 _ak820_outline_0106:
      0058E1 35 F0            [12] 2583 	addc	a,b
      0058E3 F5 83            [12] 2584 	mov	dph,a
      0058E5 E4               [12] 2585 	clr	a
      0058E6 93               [24] 2586 	movc	a,@a+dptr
      0058E7 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0111
      0058E8                       2591 _ak820_outline_0111:
      0058E8 90 06 C1         [24] 2592 	mov	dptr,#_rgb_matrix_config
      0058EB E0               [24] 2593 	movx	a,@dptr
      0058EC 54 FC            [12] 2594 	anl	a,#0xfc
      0058EE 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0136
      0058EF                       2599 _ak820_outline_0136:
      0058EF 90 06 D0         [24] 2600 	mov	dptr,#_frame_mode
      0058F2 E0               [24] 2601 	movx	a,@dptr
      0058F3 FE               [12] 2602 	mov	r6,a
      0058F4 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0163
      0058F5                       2607 _ak820_outline_0163:
      0058F5 F0               [24] 2608 	movx	@dptr,a
      0058F6 E5 F0            [12] 2609 	mov	a,b
      0058F8 A3               [24] 2610 	inc	dptr
      0058F9 F0               [24] 2611 	movx	@dptr,a
      0058FA 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0167
      0058FB                       2616 _ak820_outline_0167:
      0058FB F0               [24] 2617 	movx	@dptr,a
      0058FC E0               [24] 2618 	movx	a,@dptr
      0058FD F5 82            [12] 2619 	mov	dpl,a
      0058FF 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0169
      005900                       2624 _ak820_outline_0169:
      005900 90 06 C5         [24] 2625 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005903 E0               [24] 2626 	movx	a,@dptr
      005904 23               [12] 2627 	rl	a
      005905 23               [12] 2628 	rl	a
      005906 54 03            [12] 2629 	anl	a,#0x03
      005908 22               [24] 2630 	ret
                                   2631 
                                   2632 	.area CSEG (CODE)
                                   2633 ; function ak820_outline_0175
      005909                       2634 _ak820_outline_0175:
      005909 90 0D 92         [24] 2635 	mov	dptr,#_memset_PARM_2
      00590C E4               [12] 2636 	clr	a
      00590D F0               [24] 2637 	movx	@dptr,a
      00590E 90 0D 93         [24] 2638 	mov	dptr,#_memset_PARM_3
      005911 22               [24] 2639 	ret
                                   2640 
                                   2641 	.area CSEG (CODE)
                                   2642 ; function ak820_outline_0181
      005912                       2643 _ak820_outline_0181:
      005912 90 06 CF         [24] 2644 	mov	dptr,#_led_index
      005915 E0               [24] 2645 	movx	a,@dptr
      005916 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0182
      005917                       2650 _ak820_outline_0182:
      005917 C4               [12] 2651 	swap	a
      005918 23               [12] 2652 	rl	a
      005919 54 1F            [12] 2653 	anl	a,#0x1f
      00591B 22               [24] 2654 	ret
