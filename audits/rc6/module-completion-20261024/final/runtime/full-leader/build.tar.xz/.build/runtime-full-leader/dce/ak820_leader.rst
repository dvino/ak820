                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_leader
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_macro_send
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_leader_cancel
                                    257 	.globl _ak820_leader_task
                                    258 	.globl _ak820_leader_process
                                    259 ;--------------------------------------------------------
                                    260 ; special function registers
                                    261 ;--------------------------------------------------------
                                    262 	.area RSEG    (ABS,DATA)
      000000                        263 	.org 0x0000
                           0000D0   264 _PSW	=	0x00d0
                           0000E0   265 _ACC	=	0x00e0
                           0000F0   266 _B	=	0x00f0
                           0000FD   267 _A_INV	=	0x00fd
                           000081   268 _SP	=	0x0081
                           000082   269 _DPL	=	0x0082
                           000083   270 _DPH	=	0x0083
                           0000A1   271 _SAFE_MOD	=	0x00a1
                           0000B1   272 _GLOBAL_CFG	=	0x00b1
                           000087   273 _PCON	=	0x0087
                           0000BA   274 _POWER_CFG	=	0x00ba
                           0000B9   275 _CLOCK_CFG	=	0x00b9
                           0000A9   276 _WAKE_CTRL	=	0x00a9
                           0000FE   277 _RESET_KEEP	=	0x00fe
                           0000FF   278 _WDOG_COUNT	=	0x00ff
                           0000A8   279 _IE	=	0x00a8
                           0000B8   280 _IP	=	0x00b8
                           0000E8   281 _IE_EX	=	0x00e8
                           0000E9   282 _IP_EX	=	0x00e9
                           0000B2   283 _GPIO_IE	=	0x00b2
                           008584   284 _ROM_ADDR	=	0x8584
                           000084   285 _ROM_ADDR_L	=	0x0084
                           000085   286 _ROM_ADDR_H	=	0x0085
                           008F8E   287 _ROM_DATA_HI	=	0x8f8e
                           00008E   288 _ROM_DATA_HL	=	0x008e
                           00008F   289 _ROM_DATA_HH	=	0x008f
                           000086   290 _ROM_CTRL	=	0x0086
                           000080   291 _P0	=	0x0080
                           0000C4   292 _P0_MOD_OC	=	0x00c4
                           0000C5   293 _P0_DIR_PU	=	0x00c5
                           000090   294 _P1	=	0x0090
                           000092   295 _P1_MOD_OC	=	0x0092
                           000093   296 _P1_DIR_PU	=	0x0093
                           0000A0   297 _P2	=	0x00a0
                           000094   298 _P2_MOD_OC	=	0x0094
                           000095   299 _P2_DIR_PU	=	0x0095
                           0000B0   300 _P3	=	0x00b0
                           000096   301 _P3_MOD_OC	=	0x0096
                           000097   302 _P3_DIR_PU	=	0x0097
                           0000C0   303 _P4	=	0x00c0
                           0000C2   304 _P4_MOD_OC	=	0x00c2
                           0000C3   305 _P4_DIR_PU	=	0x00c3
                           0000C1   306 _P4_LED_KEY	=	0x00c1
                           0000AA   307 _P5_IN	=	0x00aa
                           0000AB   308 _P5_OUT_PU	=	0x00ab
                           0000AC   309 _P5_DIR	=	0x00ac
                           0000AD   310 _P6_IN	=	0x00ad
                           0000AE   311 _P6_OUT_PU	=	0x00ae
                           0000AF   312 _P6_DIR	=	0x00af
                           0000F1   313 _P7	=	0x00f1
                           0000A2   314 _XBUS_AUX	=	0x00a2
                           000088   315 _TCON	=	0x0088
                           000089   316 _TMOD	=	0x0089
                           00008A   317 _TL0	=	0x008a
                           00008B   318 _TL1	=	0x008b
                           00008C   319 _TH0	=	0x008c
                           00008D   320 _TH1	=	0x008d
                           000098   321 _SCON	=	0x0098
                           000099   322 _SBUF	=	0x0099
                           0000C8   323 _T2CON	=	0x00c8
                           0000C9   324 _T2MOD	=	0x00c9
                           00CBCA   325 _RCAP2	=	0xcbca
                           0000CA   326 _RCAP2L	=	0x00ca
                           0000CB   327 _RCAP2H	=	0x00cb
                           00CDCC   328 _T2COUNT	=	0xcdcc
                           0000CC   329 _TL2	=	0x00cc
                           0000CD   330 _TH2	=	0x00cd
                           00CFCE   331 _T2CAP1	=	0xcfce
                           0000CE   332 _T2CAP1L	=	0x00ce
                           0000CF   333 _T2CAP1H	=	0x00cf
                           0000F8   334 _SPI0_STAT	=	0x00f8
                           0000F9   335 _SPI0_DATA	=	0x00f9
                           0000FA   336 _SPI0_CTRL	=	0x00fa
                           0000FB   337 _SPI0_CK_SE	=	0x00fb
                           0000FC   338 _SPI0_SETUP	=	0x00fc
                           0000BC   339 _SCON1	=	0x00bc
                           0000BD   340 _SBUF1	=	0x00bd
                           0000BE   341 _SBAUD1	=	0x00be
                           0000BF   342 _SIF1	=	0x00bf
                           0000B4   343 _SPI1_STAT	=	0x00b4
                           0000B5   344 _SPI1_DATA	=	0x00b5
                           0000B6   345 _SPI1_CTRL	=	0x00b6
                           0000B7   346 _SPI1_CK_SE	=	0x00b7
                           0000F3   347 _ADC_CTRL	=	0x00f3
                           00F5F4   348 _ADC_DAT	=	0xf5f4
                           0000F4   349 _ADC_DAT_L	=	0x00f4
                           0000F5   350 _ADC_DAT_H	=	0x00f5
                           0000F6   351 _ADC_CHAN	=	0x00f6
                           0000A6   352 _LED_COMMON	=	0x00a6
                           0000A7   353 _LED_PWM_OE	=	0x00a7
                           00C7C6   354 _LED_DMA	=	0xc7c6
                           0000C6   355 _LED_DMA_L	=	0x00c6
                           0000C7   356 _LED_DMA_H	=	0x00c7
                           0000F7   357 _LED_STATUS	=	0x00f7
                           0000B3   358 _I2CX_INT	=	0x00b3
                           0000BB   359 _I2CS_INT_ST	=	0x00bb
                                    360 ;--------------------------------------------------------
                                    361 ; special function bits
                                    362 ;--------------------------------------------------------
                                    363 	.area RSEG    (ABS,DATA)
      000000                        364 	.org 0x0000
                           0000D7   365 _CY	=	0x00d7
                           0000D6   366 _AC	=	0x00d6
                           0000D5   367 _F0	=	0x00d5
                           0000D4   368 _RS1	=	0x00d4
                           0000D3   369 _RS0	=	0x00d3
                           0000D2   370 _OV	=	0x00d2
                           0000D1   371 _F1	=	0x00d1
                           0000D0   372 _P	=	0x00d0
                           0000AF   373 _EA	=	0x00af
                           0000AE   374 _E_DIS	=	0x00ae
                           0000AD   375 _ET2	=	0x00ad
                           0000AC   376 _ES	=	0x00ac
                           0000AB   377 _ET1	=	0x00ab
                           0000AA   378 _EX1	=	0x00aa
                           0000A9   379 _ET0	=	0x00a9
                           0000A8   380 _EX0	=	0x00a8
                           0000BF   381 _PH_FLAG	=	0x00bf
                           0000BE   382 _PL_FLAG	=	0x00be
                           0000BD   383 _PT2	=	0x00bd
                           0000BC   384 _PS	=	0x00bc
                           0000BB   385 _PT1	=	0x00bb
                           0000BA   386 _PX1	=	0x00ba
                           0000B9   387 _PT0	=	0x00b9
                           0000B8   388 _PX0	=	0x00b8
                           0000EF   389 _IE_WDOG	=	0x00ef
                           0000EE   390 _IE_GPIO	=	0x00ee
                           0000ED   391 _IE_PWM_I2C	=	0x00ed
                           0000EC   392 _IE_UART1	=	0x00ec
                           0000EB   393 _IE_ADC	=	0x00eb
                           0000E9   394 _IE_USB	=	0x00e9
                           0000E8   395 _IE_SPI0	=	0x00e8
                           000087   396 _P0_7	=	0x0087
                           000086   397 _P0_6	=	0x0086
                           000085   398 _P0_5	=	0x0085
                           000084   399 _P0_4	=	0x0084
                           000083   400 _P0_3	=	0x0083
                           000082   401 _P0_2	=	0x0082
                           000081   402 _P0_1	=	0x0081
                           000080   403 _P0_0	=	0x0080
                           000081   404 _SDA0	=	0x0081
                           000080   405 _SCL0	=	0x0080
                           000083   406 _TXD_	=	0x0083
                           000082   407 _RXD_	=	0x0082
                           000085   408 _AIN13	=	0x0085
                           000084   409 _AIN12	=	0x0084
                           000083   410 _AIN11	=	0x0083
                           000082   411 _AIN10	=	0x0082
                           000081   412 _AIN9	=	0x0081
                           000080   413 _AIN8	=	0x0080
                           000097   414 _P1_7	=	0x0097
                           000096   415 _P1_6	=	0x0096
                           000095   416 _P1_5	=	0x0095
                           000094   417 _P1_4	=	0x0094
                           000093   418 _P1_3	=	0x0093
                           000092   419 _P1_2	=	0x0092
                           000091   420 _P1_1	=	0x0091
                           000090   421 _P1_0	=	0x0090
                           000097   422 _TXD1_	=	0x0097
                           000096   423 _RXD1_	=	0x0096
                           000097   424 _SCK	=	0x0097
                           000096   425 _MISO	=	0x0096
                           000095   426 _MOSI	=	0x0095
                           000094   427 _SCS	=	0x0094
                           000092   428 _INT0_	=	0x0092
                           000091   429 _T2EX	=	0x0091
                           000091   430 _CAP2	=	0x0091
                           000090   431 _T2	=	0x0090
                           000090   432 _CAP1	=	0x0090
                           000097   433 _AIN7	=	0x0097
                           000096   434 _AIN6	=	0x0096
                           000095   435 _AIN5	=	0x0095
                           000094   436 _AIN4	=	0x0094
                           000093   437 _AIN3	=	0x0093
                           000092   438 _AIN2	=	0x0092
                           000091   439 _AIN1	=	0x0091
                           000090   440 _AIN0	=	0x0090
                           0000A7   441 _P2_7	=	0x00a7
                           0000A6   442 _P2_6	=	0x00a6
                           0000A5   443 _P2_5	=	0x00a5
                           0000A4   444 _P2_4	=	0x00a4
                           0000A3   445 _P2_3	=	0x00a3
                           0000A2   446 _P2_2	=	0x00a2
                           0000A1   447 _P2_1	=	0x00a1
                           0000A0   448 _P2_0	=	0x00a0
                           0000A7   449 _TXD1	=	0x00a7
                           0000A6   450 _RXD1	=	0x00a6
                           0000A5   451 _T2EX_	=	0x00a5
                           0000A5   452 _CAP2_	=	0x00a5
                           0000A4   453 _T2_	=	0x00a4
                           0000A4   454 _CAP1_	=	0x00a4
                           0000B7   455 _P3_7	=	0x00b7
                           0000B6   456 _P3_6	=	0x00b6
                           0000B5   457 _P3_5	=	0x00b5
                           0000B4   458 _P3_4	=	0x00b4
                           0000B3   459 _P3_3	=	0x00b3
                           0000B2   460 _P3_2	=	0x00b2
                           0000B1   461 _P3_1	=	0x00b1
                           0000B0   462 _P3_0	=	0x00b0
                           0000B7   463 _SCK1	=	0x00b7
                           0000B6   464 _MISO1	=	0x00b6
                           0000B5   465 _MOSI1	=	0x00b5
                           0000B5   466 _T1	=	0x00b5
                           0000B4   467 _T0	=	0x00b4
                           0000B3   468 _INT1	=	0x00b3
                           0000B2   469 _INT0	=	0x00b2
                           0000B1   470 _TXD	=	0x00b1
                           0000B0   471 _RXD	=	0x00b0
                           0000C6   472 _P4_6	=	0x00c6
                           0000C5   473 _P4_5	=	0x00c5
                           0000C4   474 _P4_4	=	0x00c4
                           0000C3   475 _P4_3	=	0x00c3
                           0000C2   476 _P4_2	=	0x00c2
                           0000C1   477 _P4_1	=	0x00c1
                           0000C0   478 _P4_0	=	0x00c0
                           00008F   479 _TF1	=	0x008f
                           00008E   480 _TR1	=	0x008e
                           00008D   481 _TF0	=	0x008d
                           00008C   482 _TR0	=	0x008c
                           00008B   483 _IE1	=	0x008b
                           00008A   484 _IT1	=	0x008a
                           000089   485 _IE0	=	0x0089
                           000088   486 _IT0	=	0x0088
                           00009F   487 _SM0	=	0x009f
                           00009E   488 _SM1	=	0x009e
                           00009D   489 _SM2	=	0x009d
                           00009C   490 _REN	=	0x009c
                           00009B   491 _TB8	=	0x009b
                           00009A   492 _RB8	=	0x009a
                           000099   493 _TI	=	0x0099
                           000098   494 _RI	=	0x0098
                           0000CF   495 _TF2	=	0x00cf
                           0000CF   496 _CAP1F	=	0x00cf
                           0000CE   497 _EXF2	=	0x00ce
                           0000CD   498 _RCLK	=	0x00cd
                           0000CC   499 _TCLK	=	0x00cc
                           0000CB   500 _EXEN2	=	0x00cb
                           0000CA   501 _TR2	=	0x00ca
                           0000C9   502 _C_T2	=	0x00c9
                           0000C8   503 _CP_RL2	=	0x00c8
                           0000FF   504 _S0_FST_ACT	=	0x00ff
                           0000FE   505 _S0_IF_OV	=	0x00fe
                           0000FD   506 _S0_IF_FIRST	=	0x00fd
                           0000FC   507 _S0_IF_BYTE	=	0x00fc
                           0000FB   508 _S0_FREE	=	0x00fb
                           0000FA   509 _S0_T_FIFO	=	0x00fa
                           0000F8   510 _S0_R_FIFO	=	0x00f8
                           0000F7   511 _ADC_START	=	0x00f7
                                    512 ;--------------------------------------------------------
                                    513 ; overlayable register banks
                                    514 ;--------------------------------------------------------
                                    515 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        516 	.ds 8
                                    517 ;--------------------------------------------------------
                                    518 ; internal ram data
                                    519 ;--------------------------------------------------------
                                    520 	.area DSEG    (DATA)
      00000A                        521 _ak820_leader_process_sloc0_1_0:
      00000A                        522 	.ds 2
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
                                    539 ;--------------------------------------------------------
                                    540 ; paged external ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area PSEG    (PAG,XDATA)
                                    543 ;--------------------------------------------------------
                                    544 ; uninitialized external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area XSEG    (XDATA)
      0004F9                        547 _leader_suppressed:
      0004F9                        548 	.ds 16
      000509                        549 _leader_waiting:
      000509                        550 	.ds 1
      00050A                        551 _leader_running:
      00050A                        552 	.ds 1
      00050B                        553 _leader_started:
      00050B                        554 	.ds 2
      00050D                        555 _ak820_leader_task_now_10000_593:
      00050D                        556 	.ds 2
      00050F                        557 _ak820_leader_task_slot_30000_600:
      00050F                        558 	.ds 1
      000510                        559 _ak820_leader_process_record_10000_601:
      000510                        560 	.ds 2
      000512                        561 _ak820_leader_process_slot_10000_602:
      000512                        562 	.ds 1
                                    563 ;--------------------------------------------------------
                                    564 ; absolute external ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area XABS    (ABS,XDATA)
                                    567 ;--------------------------------------------------------
                                    568 ; initialized external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area XISEG   (XDATA)
      000D9A                        571 _leader_pending:
      000D9A                        572 	.ds 1
                                    573 	.area HOME    (CODE)
                                    574 	.area GSINIT0 (CODE)
                                    575 	.area GSINIT1 (CODE)
                                    576 	.area GSINIT2 (CODE)
                                    577 	.area GSINIT3 (CODE)
                                    578 	.area GSINIT4 (CODE)
                                    579 	.area GSINIT5 (CODE)
                                    580 	.area GSINIT  (CODE)
                                    581 	.area GSFINAL (CODE)
                                    582 	.area CSEG    (CODE)
                                    583 ;--------------------------------------------------------
                                    584 ; global & static initialisations
                                    585 ;--------------------------------------------------------
                                    586 	.area HOME    (CODE)
                                    587 	.area GSINIT  (CODE)
                                    588 	.area GSFINAL (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 ;--------------------------------------------------------
                                    591 ; Home
                                    592 ;--------------------------------------------------------
                                    593 	.area HOME    (CODE)
                                    594 	.area HOME    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; code
                                    597 ;--------------------------------------------------------
                                    598 	.area CSEG    (CODE)
                                    599 ;------------------------------------------------------------
                                    600 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    601 ;------------------------------------------------------------
                                    602 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    603 ;------------------------------------------------------------
                                    604 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    605 ;	-----------------------------------------
                           000007   606 	ar7 = 0x07
                           000006   607 	ar6 = 0x06
                           000005   608 	ar5 = 0x05
                           000004   609 	ar4 = 0x04
                           000003   610 	ar3 = 0x03
                           000002   611 	ar2 = 0x02
                           000001   612 	ar1 = 0x01
                           000000   613 	ar0 = 0x00
                                    614 ;	 function ak820_leader_cancel
                                    615 ;	-----------------------------------------
      003B48                        616 _ak820_leader_cancel:
                                    617 ;	keyboards/ajazz/ak820/ak820_leader.c:18: leader_waiting = false;
      003B48 90 05 09         [24]  618 	mov	dptr,#_leader_waiting
      003B4B E4               [12]  619 	clr	a
      003B4C F0               [24]  620 	movx	@dptr,a
                                    621 ;	keyboards/ajazz/ak820/ak820_leader.c:19: leader_pending = NONE;
      003B4D 90 0D 9A         [24]  622 	mov	dptr,#_leader_pending
      003B50 14               [12]  623 	dec	a
      003B51 F0               [24]  624 	movx	@dptr,a
                                    625 ;	keyboards/ajazz/ak820/ak820_leader.c:20: for (uint8_t i = 0; i < sizeof(leader_suppressed); ++i) leader_suppressed[i] = 0;
      003B52 7F 00            [12]  626 	mov	r7,#0x00
      003B54                        627 00103$:
      003B54 BF 10 00         [24]  628 	cjne	r7,#0x10,00122$
      003B57                        629 00122$:
      003B57 50 0F            [24]  630 	jnc	00105$
      003B59 EF               [12]  631 	mov	a,r7
      003B5A 24 F9            [12]  632 	add	a, #_leader_suppressed
      003B5C F5 82            [12]  633 	mov	dpl,a
      003B5E E4               [12]  634 	clr	a
      003B5F 34 04            [12]  635 	addc	a, #(_leader_suppressed >> 8)
      003B61 F5 83            [12]  636 	mov	dph,a
      003B63 E4               [12]  637 	clr	a
      003B64 F0               [24]  638 	movx	@dptr,a
      003B65 0F               [12]  639 	inc	r7
      003B66 80 EC            [24]  640 	sjmp	00103$
      003B68                        641 00105$:
                                    642 ;	keyboards/ajazz/ak820/ak820_leader.c:21: }
      003B68 22               [24]  643 	ret
                                    644 ;------------------------------------------------------------
                                    645 ;Allocation info for local variables in function 'ak820_leader_task'
                                    646 ;------------------------------------------------------------
                                    647 ;now           Allocated with name '_ak820_leader_task_now_10000_593'
                                    648 ;slot          Allocated with name '_ak820_leader_task_slot_30000_600'
                                    649 ;------------------------------------------------------------
                                    650 ;	keyboards/ajazz/ak820/ak820_leader.c:22: void ak820_leader_task(uint16_t now) {
                                    651 ;	-----------------------------------------
                                    652 ;	 function ak820_leader_task
                                    653 ;	-----------------------------------------
      003B69                        654 _ak820_leader_task:
      003B69 AF 83            [24]  655 	mov	r7,dph
      003B6B E5 82            [12]  656 	mov	a,dpl
      003B6D 90 05 0D         [24]  657 	mov	dptr,#_ak820_leader_task_now_10000_593
      003B70 F0               [24]  658 	movx	@dptr,a
      003B71 EF               [12]  659 	mov	a,r7
      003B72 A3               [24]  660 	inc	dptr
      003B73 F0               [24]  661 	movx	@dptr,a
                                    662 ;	keyboards/ajazz/ak820/ak820_leader.c:23: if (vial_unlock_in_progress) { ak820_leader_cancel(); return; }
      003B74 90 0E 0C         [24]  663 	mov	dptr,#_vial_unlock_in_progress
      003B77 E0               [24]  664 	movx	a,@dptr
      003B78 60 03            [24]  665 	jz	00102$
      003B7A 02 3B 48         [24]  666 	ljmp	_ak820_leader_cancel
      003B7D                        667 00102$:
                                    668 ;	keyboards/ajazz/ak820/ak820_leader.c:24: if (leader_running) return;
      003B7D 90 05 0A         [24]  669 	mov	dptr,#_leader_running
      003B80 E0               [24]  670 	movx	a,@dptr
      003B81 60 01            [24]  671 	jz	00104$
      003B83 22               [24]  672 	ret
      003B84                        673 00104$:
                                    674 ;	keyboards/ajazz/ak820/ak820_leader.c:25: if (leader_waiting && (uint16_t)(now - leader_started) >= 300) leader_waiting = false;
      003B84 90 05 09         [24]  675 	mov	dptr,#_leader_waiting
      003B87 E0               [24]  676 	movx	a,@dptr
      003B88 60 25            [24]  677 	jz	00106$
      003B8A 90 05 0B         [24]  678 	mov	dptr,#_leader_started
      003B8D E0               [24]  679 	movx	a,@dptr
      003B8E FE               [12]  680 	mov	r6,a
      003B8F A3               [24]  681 	inc	dptr
      003B90 E0               [24]  682 	movx	a,@dptr
      003B91 FF               [12]  683 	mov	r7,a
      003B92 90 05 0D         [24]  684 	mov	dptr,#_ak820_leader_task_now_10000_593
      003B95 E0               [24]  685 	movx	a,@dptr
      003B96 FC               [12]  686 	mov	r4,a
      003B97 A3               [24]  687 	inc	dptr
      003B98 E0               [24]  688 	movx	a,@dptr
      003B99 FD               [12]  689 	mov	r5,a
      003B9A EC               [12]  690 	mov	a,r4
      003B9B C3               [12]  691 	clr	c
      003B9C 9E               [12]  692 	subb	a,r6
      003B9D FE               [12]  693 	mov	r6,a
      003B9E ED               [12]  694 	mov	a,r5
      003B9F 9F               [12]  695 	subb	a,r7
      003BA0 FF               [12]  696 	mov	r7,a
      003BA1 C3               [12]  697 	clr	c
      003BA2 EE               [12]  698 	mov	a,r6
      003BA3 94 2C            [12]  699 	subb	a,#0x2c
      003BA5 EF               [12]  700 	mov	a,r7
      003BA6 94 01            [12]  701 	subb	a,#0x01
      003BA8 40 05            [24]  702 	jc	00106$
      003BAA 90 05 09         [24]  703 	mov	dptr,#_leader_waiting
      003BAD E4               [12]  704 	clr	a
      003BAE F0               [24]  705 	movx	@dptr,a
      003BAF                        706 00106$:
                                    707 ;	keyboards/ajazz/ak820/ak820_leader.c:26: if (leader_pending != NONE) {
      003BAF 90 0D 9A         [24]  708 	mov	dptr,#_leader_pending
      003BB2 E0               [24]  709 	movx	a,@dptr
      003BB3 FF               [12]  710 	mov	r7,a
      003BB4 BF FF 01         [24]  711 	cjne	r7,#0xff,00151$
      003BB7 22               [24]  712 	ret
      003BB8                        713 00151$:
                                    714 ;	keyboards/ajazz/ak820/ak820_leader.c:27: uint8_t slot = leader_pending;
      003BB8 90 05 0F         [24]  715 	mov	dptr,#_ak820_leader_task_slot_30000_600
      003BBB EF               [12]  716 	mov	a,r7
      003BBC F0               [24]  717 	movx	@dptr,a
                                    718 ;	keyboards/ajazz/ak820/ak820_leader.c:28: leader_pending = NONE; /* Interpreter-generated events cannot recurse. */
      003BBD 90 0D 9A         [24]  719 	mov	dptr,#_leader_pending
      003BC0 74 FF            [12]  720 	mov	a,#0xff
      003BC2 F0               [24]  721 	movx	@dptr,a
                                    722 ;	keyboards/ajazz/ak820/ak820_leader.c:29: leader_running = true;
      003BC3 90 05 0A         [24]  723 	mov	dptr,#_leader_running
      003BC6 74 01            [12]  724 	mov	a,#0x01
      003BC8 F0               [24]  725 	movx	@dptr,a
                                    726 ;	keyboards/ajazz/ak820/ak820_leader.c:30: dynamic_keymap_macro_send(slot);
      003BC9 90 05 0F         [24]  727 	mov	dptr,#_ak820_leader_task_slot_30000_600
      003BCC E0               [24]  728 	movx	a,@dptr
      003BCD F5 82            [12]  729 	mov	dpl,a
      003BCF 12 8C 90         [24]  730 	lcall	_dynamic_keymap_macro_send
                                    731 ;	keyboards/ajazz/ak820/ak820_leader.c:31: leader_running = false;
      003BD2 90 05 0A         [24]  732 	mov	dptr,#_leader_running
      003BD5 E4               [12]  733 	clr	a
      003BD6 F0               [24]  734 	movx	@dptr,a
                                    735 ;	keyboards/ajazz/ak820/ak820_leader.c:33: }
      003BD7 22               [24]  736 	ret
                                    737 ;------------------------------------------------------------
                                    738 ;Allocation info for local variables in function 'ak820_leader_process'
                                    739 ;------------------------------------------------------------
                                    740 ;sloc0         Allocated with name '_ak820_leader_process_sloc0_1_0'
                                    741 ;record        Allocated with name '_ak820_leader_process_record_10000_601'
                                    742 ;id            Allocated with name '_ak820_leader_process_id_10000_602'
                                    743 ;mask          Allocated with name '_ak820_leader_process_mask_10000_602'
                                    744 ;index         Allocated with name '_ak820_leader_process_index_10000_602'
                                    745 ;slot          Allocated with name '_ak820_leader_process_slot_10000_602'
                                    746 ;code          Allocated with name '_ak820_leader_process_code_10000_602'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_leader.c:34: bool ak820_leader_process(keyrecord_t AK820_STATE_MEM *record) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_leader_process
                                    751 ;	-----------------------------------------
      003BD8                        752 _ak820_leader_process:
      003BD8 AF 83            [24]  753 	mov	r7,dph
      003BDA E5 82            [12]  754 	mov	a,dpl
      003BDC 90 05 10         [24]  755 	mov	dptr,#_ak820_leader_process_record_10000_601
      003BDF F0               [24]  756 	movx	@dptr,a
      003BE0 EF               [12]  757 	mov	a,r7
      003BE1 A3               [24]  758 	inc	dptr
      003BE2 F0               [24]  759 	movx	@dptr,a
                                    760 ;	keyboards/ajazz/ak820/ak820_leader.c:35: uint8_t id, mask, index, slot = NONE;
      003BE3 90 05 12         [24]  761 	mov	dptr,#_ak820_leader_process_slot_10000_602
      003BE6 74 FF            [12]  762 	mov	a,#0xff
      003BE8 F0               [24]  763 	movx	@dptr,a
                                    764 ;	keyboards/ajazz/ak820/ak820_leader.c:37: if (record->event.type != KEY_EVENT || record->event.key.row >= MATRIX_ROWS ||
      003BE9 90 05 10         [24]  765 	mov	dptr,#_ak820_leader_process_record_10000_601
      003BEC E0               [24]  766 	movx	a,@dptr
      003BED FE               [12]  767 	mov	r6,a
      003BEE A3               [24]  768 	inc	dptr
      003BEF E0               [24]  769 	movx	a,@dptr
      003BF0 FF               [12]  770 	mov	r7,a
      003BF1 8E 82            [24]  771 	mov	dpl,r6
      003BF3 8F 83            [24]  772 	mov	dph,r7
      003BF5 A3               [24]  773 	inc	dptr
      003BF6 A3               [24]  774 	inc	dptr
      003BF7 A3               [24]  775 	inc	dptr
      003BF8 A3               [24]  776 	inc	dptr
      003BF9 E0               [24]  777 	movx	a,@dptr
      003BFA FD               [12]  778 	mov	r5,a
      003BFB BD 01 34         [24]  779 	cjne	r5,#0x01,00101$
      003BFE 74 01            [12]  780 	mov	a,#0x01
      003C00 2E               [12]  781 	add	a, r6
      003C01 FC               [12]  782 	mov	r4,a
      003C02 E4               [12]  783 	clr	a
      003C03 3F               [12]  784 	addc	a, r7
      003C04 FD               [12]  785 	mov	r5,a
      003C05 8C 82            [24]  786 	mov	dpl,r4
      003C07 8D 83            [24]  787 	mov	dph,r5
      003C09 E0               [24]  788 	movx	a,@dptr
      003C0A FB               [12]  789 	mov	r3,a
      003C0B BB 10 00         [24]  790 	cjne	r3,#0x10,00252$
      003C0E                        791 00252$:
      003C0E 50 22            [24]  792 	jnc	00101$
                                    793 ;	keyboards/ajazz/ak820/ak820_leader.c:38: record->event.key.col >= MATRIX_COLS || leader_running || ak820_macro_primitive || get_repeat_key_count()) return true;
      003C10 8E 02            [24]  794 	mov	ar2,r6
      003C12 8F 03            [24]  795 	mov	ar3,r7
      003C14 8A 82            [24]  796 	mov	dpl,r2
      003C16 8B 83            [24]  797 	mov	dph,r3
      003C18 E0               [24]  798 	movx	a,@dptr
      003C19 F9               [12]  799 	mov	r1,a
      003C1A B9 08 00         [24]  800 	cjne	r1,#0x08,00254$
      003C1D                        801 00254$:
      003C1D 50 13            [24]  802 	jnc	00101$
      003C1F 90 05 0A         [24]  803 	mov	dptr,#_leader_running
      003C22 E0               [24]  804 	movx	a,@dptr
      003C23 70 0D            [24]  805 	jnz	00101$
      003C25 90 09 96         [24]  806 	mov	dptr,#_ak820_macro_primitive
      003C28 E0               [24]  807 	movx	a,@dptr
      003C29 70 07            [24]  808 	jnz	00101$
      003C2B 12 A2 60         [24]  809 	lcall	_get_repeat_key_count
      003C2E E5 82            [12]  810 	mov	a, dpl
      003C30 60 04            [24]  811 	jz	00102$
      003C32                        812 00101$:
      003C32 75 82 01         [24]  813 	mov	dpl, #0x01
      003C35 22               [24]  814 	ret
      003C36                        815 00102$:
                                    816 ;	keyboards/ajazz/ak820/ak820_leader.c:39: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003C36 8C 82            [24]  817 	mov	dpl,r4
      003C38 8D 83            [24]  818 	mov	dph,r5
      003C3A E0               [24]  819 	movx	a,@dptr
      003C3B C4               [12]  820 	swap	a
      003C3C 03               [12]  821 	rr	a
      003C3D 54 F8            [12]  822 	anl	a,#0xf8
      003C3F FC               [12]  823 	mov	r4,a
      003C40 8A 82            [24]  824 	mov	dpl,r2
      003C42 8B 83            [24]  825 	mov	dph,r3
      003C44 E0               [24]  826 	movx	a,@dptr
      003C45 2C               [12]  827 	add	a, r4
                                    828 ;	keyboards/ajazz/ak820/ak820_leader.c:40: index = id >> 3;
      003C46 FC               [12]  829 	mov	r4,a
      003C47 C4               [12]  830 	swap	a
      003C48 23               [12]  831 	rl	a
      003C49 54 1F            [12]  832 	anl	a,#0x1f
      003C4B FD               [12]  833 	mov	r5,a
                                    834 ;	keyboards/ajazz/ak820/ak820_leader.c:41: mask = 1u << (id & 7);
      003C4C 74 07            [12]  835 	mov	a,#0x07
      003C4E 5C               [12]  836 	anl	a,r4
      003C4F F5 F0            [12]  837 	mov	b,a
      003C51 05 F0            [12]  838 	inc	b
      003C53 74 01            [12]  839 	mov	a,#0x01
      003C55 80 02            [24]  840 	sjmp	00260$
      003C57                        841 00259$:
      003C57 25 E0            [12]  842 	add	a,acc
      003C59                        843 00260$:
      003C59 D5 F0 FB         [24]  844 	djnz	b,00259$
      003C5C FC               [12]  845 	mov	r4,a
                                    846 ;	keyboards/ajazz/ak820/ak820_leader.c:42: if (leader_suppressed[index] & mask) {
      003C5D ED               [12]  847 	mov	a,r5
      003C5E 24 F9            [12]  848 	add	a, #_leader_suppressed
      003C60 FB               [12]  849 	mov	r3,a
      003C61 E4               [12]  850 	clr	a
      003C62 34 04            [12]  851 	addc	a, #(_leader_suppressed >> 8)
      003C64 FD               [12]  852 	mov	r5,a
      003C65 8B 82            [24]  853 	mov	dpl,r3
      003C67 8D 83            [24]  854 	mov	dph,r5
      003C69 E0               [24]  855 	movx	a,@dptr
      003C6A FA               [12]  856 	mov	r2,a
      003C6B EC               [12]  857 	mov	a,r4
      003C6C 5A               [12]  858 	anl	a,r2
      003C6D 60 1D            [24]  859 	jz	00111$
                                    860 ;	keyboards/ajazz/ak820/ak820_leader.c:43: if (!record->event.pressed) leader_suppressed[index] &= ~mask;
      003C6F 74 05            [12]  861 	mov	a,#0x05
      003C71 2E               [12]  862 	add	a, r6
      003C72 F8               [12]  863 	mov	r0,a
      003C73 E4               [12]  864 	clr	a
      003C74 3F               [12]  865 	addc	a, r7
      003C75 F9               [12]  866 	mov	r1,a
      003C76 88 82            [24]  867 	mov	dpl,r0
      003C78 89 83            [24]  868 	mov	dph,r1
      003C7A E0               [24]  869 	movx	a,@dptr
      003C7B 70 0B            [24]  870 	jnz	00109$
      003C7D 74 FF            [12]  871 	mov	a,#0xff
      003C7F 6C               [12]  872 	xrl	a,r4
      003C80 52 02            [12]  873 	anl	ar2,a
      003C82 8B 82            [24]  874 	mov	dpl,r3
      003C84 8D 83            [24]  875 	mov	dph,r5
      003C86 EA               [12]  876 	mov	a,r2
      003C87 F0               [24]  877 	movx	@dptr,a
      003C88                        878 00109$:
                                    879 ;	keyboards/ajazz/ak820/ak820_leader.c:44: return false;
      003C88 75 82 00         [24]  880 	mov	dpl, #0x00
      003C8B 22               [24]  881 	ret
      003C8C                        882 00111$:
                                    883 ;	keyboards/ajazz/ak820/ak820_leader.c:46: if (!record->event.pressed) return true; /* Preheld release keeps its owner. */
      003C8C 74 05            [12]  884 	mov	a,#0x05
      003C8E 2E               [12]  885 	add	a, r6
      003C8F F9               [12]  886 	mov	r1,a
      003C90 E4               [12]  887 	clr	a
      003C91 3F               [12]  888 	addc	a, r7
      003C92 FA               [12]  889 	mov	r2,a
      003C93 89 82            [24]  890 	mov	dpl,r1
      003C95 8A 83            [24]  891 	mov	dph,r2
      003C97 E0               [24]  892 	movx	a,@dptr
      003C98 70 04            [24]  893 	jnz	00113$
      003C9A 75 82 01         [24]  894 	mov	dpl, #0x01
      003C9D 22               [24]  895 	ret
      003C9E                        896 00113$:
                                    897 ;	keyboards/ajazz/ak820/ak820_leader.c:47: code = record->keycode;
      003C9E 74 07            [12]  898 	mov	a,#0x07
      003CA0 2E               [12]  899 	add	a, r6
      003CA1 F5 82            [12]  900 	mov	dpl,a
      003CA3 E4               [12]  901 	clr	a
      003CA4 3F               [12]  902 	addc	a, r7
      003CA5 F5 83            [12]  903 	mov	dph,a
      003CA7 E0               [24]  904 	movx	a,@dptr
      003CA8 F9               [12]  905 	mov	r1,a
      003CA9 A3               [24]  906 	inc	dptr
      003CAA E0               [24]  907 	movx	a,@dptr
      003CAB FA               [12]  908 	mov	r2,a
                                    909 ;	keyboards/ajazz/ak820/ak820_leader.c:48: if (code == QK_LEAD) {
      003CAC 89 0A            [24]  910 	mov	_ak820_leader_process_sloc0_1_0,r1
      003CAE 8A 0B            [24]  911 	mov	(_ak820_leader_process_sloc0_1_0 + 1),r2
      003CB0 74 58            [12]  912 	mov	a,#0x58
      003CB2 B5 0A 32         [24]  913 	cjne	a,_ak820_leader_process_sloc0_1_0,00131$
      003CB5 74 7C            [12]  914 	mov	a,#0x7c
      003CB7 B5 0B 2D         [24]  915 	cjne	a,(_ak820_leader_process_sloc0_1_0 + 1),00131$
                                    916 ;	keyboards/ajazz/ak820/ak820_leader.c:49: if (leader_pending == NONE) {
      003CBA 90 0D 9A         [24]  917 	mov	dptr,#_leader_pending
      003CBD E0               [24]  918 	movx	a,@dptr
      003CBE F8               [12]  919 	mov	r0,a
      003CBF B8 FF 02         [24]  920 	cjne	r0,#0xff,00266$
      003CC2 80 03            [24]  921 	sjmp	00267$
      003CC4                        922 00266$:
      003CC4 02 3D 71         [24]  923 	ljmp	00132$
      003CC7                        924 00267$:
                                    925 ;	keyboards/ajazz/ak820/ak820_leader.c:50: leader_waiting = true;
      003CC7 C0 04            [24]  926 	push	ar4
      003CC9 90 05 09         [24]  927 	mov	dptr,#_leader_waiting
      003CCC 74 01            [12]  928 	mov	a,#0x01
      003CCE F0               [24]  929 	movx	@dptr,a
                                    930 ;	keyboards/ajazz/ak820/ak820_leader.c:51: leader_started = record->event.time;
      003CCF 8E 82            [24]  931 	mov	dpl,r6
      003CD1 8F 83            [24]  932 	mov	dph,r7
      003CD3 A3               [24]  933 	inc	dptr
      003CD4 A3               [24]  934 	inc	dptr
      003CD5 E0               [24]  935 	movx	a,@dptr
      003CD6 F8               [12]  936 	mov	r0,a
      003CD7 A3               [24]  937 	inc	dptr
      003CD8 E0               [24]  938 	movx	a,@dptr
      003CD9 FC               [12]  939 	mov	r4,a
      003CDA 90 05 0B         [24]  940 	mov	dptr,#_leader_started
      003CDD E8               [12]  941 	mov	a,r0
      003CDE F0               [24]  942 	movx	@dptr,a
      003CDF EC               [12]  943 	mov	a,r4
      003CE0 A3               [24]  944 	inc	dptr
      003CE1 F0               [24]  945 	movx	@dptr,a
      003CE2 D0 04            [24]  946 	pop	ar4
      003CE4 02 3D 71         [24]  947 	ljmp	00132$
      003CE7                        948 00131$:
                                    949 ;	keyboards/ajazz/ak820/ak820_leader.c:54: if (!leader_waiting) return true;
      003CE7 90 05 09         [24]  950 	mov	dptr,#_leader_waiting
      003CEA E0               [24]  951 	movx	a,@dptr
      003CEB 70 04            [24]  952 	jnz	00117$
      003CED 75 82 01         [24]  953 	mov	dpl, #0x01
      003CF0 22               [24]  954 	ret
      003CF1                        955 00117$:
                                    956 ;	keyboards/ajazz/ak820/ak820_leader.c:55: leader_waiting = false;
      003CF1 C0 04            [24]  957 	push	ar4
      003CF3 90 05 09         [24]  958 	mov	dptr,#_leader_waiting
      003CF6 E4               [12]  959 	clr	a
      003CF7 F0               [24]  960 	movx	@dptr,a
                                    961 ;	keyboards/ajazz/ak820/ak820_leader.c:56: if ((uint16_t)(record->event.time - leader_started) >= 300) return true;
      003CF8 8E 82            [24]  962 	mov	dpl,r6
      003CFA 8F 83            [24]  963 	mov	dph,r7
      003CFC A3               [24]  964 	inc	dptr
      003CFD A3               [24]  965 	inc	dptr
      003CFE E0               [24]  966 	movx	a,@dptr
      003CFF FE               [12]  967 	mov	r6,a
      003D00 A3               [24]  968 	inc	dptr
      003D01 E0               [24]  969 	movx	a,@dptr
      003D02 FF               [12]  970 	mov	r7,a
      003D03 90 05 0B         [24]  971 	mov	dptr,#_leader_started
      003D06 E0               [24]  972 	movx	a,@dptr
      003D07 F8               [12]  973 	mov	r0,a
      003D08 A3               [24]  974 	inc	dptr
      003D09 E0               [24]  975 	movx	a,@dptr
      003D0A FC               [12]  976 	mov	r4,a
      003D0B EE               [12]  977 	mov	a,r6
      003D0C C3               [12]  978 	clr	c
      003D0D 98               [12]  979 	subb	a,r0
      003D0E FE               [12]  980 	mov	r6,a
      003D0F EF               [12]  981 	mov	a,r7
      003D10 9C               [12]  982 	subb	a,r4
      003D11 FF               [12]  983 	mov	r7,a
      003D12 C3               [12]  984 	clr	c
      003D13 EE               [12]  985 	mov	a,r6
      003D14 94 2C            [12]  986 	subb	a,#0x2c
      003D16 EF               [12]  987 	mov	a,r7
      003D17 94 01            [12]  988 	subb	a,#0x01
      003D19 D0 04            [24]  989 	pop	ar4
      003D1B 40 04            [24]  990 	jc	00119$
      003D1D 75 82 01         [24]  991 	mov	dpl, #0x01
      003D20 22               [24]  992 	ret
      003D21                        993 00119$:
                                    994 ;	keyboards/ajazz/ak820/ak820_leader.c:58: if (code < KC_A || code > KC_EXSEL) return true;
      003D21 C3               [12]  995 	clr	c
      003D22 E5 0A            [12]  996 	mov	a,_ak820_leader_process_sloc0_1_0
      003D24 94 04            [12]  997 	subb	a,#0x04
      003D26 E5 0B            [12]  998 	mov	a,(_ak820_leader_process_sloc0_1_0 + 1)
      003D28 94 00            [12]  999 	subb	a,#0x00
      003D2A 40 09            [24] 1000 	jc	00120$
      003D2C 74 A4            [12] 1001 	mov	a,#0xa4
      003D2E 95 0A            [12] 1002 	subb	a,_ak820_leader_process_sloc0_1_0
      003D30 E4               [12] 1003 	clr	a
      003D31 95 0B            [12] 1004 	subb	a,(_ak820_leader_process_sloc0_1_0 + 1)
      003D33 50 04            [24] 1005 	jnc	00121$
                                   1006 ;	free result
      003D35                       1007 00120$:
      003D35 75 82 01         [24] 1008 	mov	dpl, #0x01
      003D38 22               [24] 1009 	ret
      003D39                       1010 00121$:
                                   1011 ;	keyboards/ajazz/ak820/ak820_leader.c:59: if (code >= KC_1 && code <= KC_0) slot = code - KC_1;
      003D39 C3               [12] 1012 	clr	c
      003D3A E5 0A            [12] 1013 	mov	a,_ak820_leader_process_sloc0_1_0
      003D3C 94 1E            [12] 1014 	subb	a,#0x1e
      003D3E E5 0B            [12] 1015 	mov	a,(_ak820_leader_process_sloc0_1_0 + 1)
      003D40 94 00            [12] 1016 	subb	a,#0x00
      003D42 40 14            [24] 1017 	jc	00127$
      003D44 74 27            [12] 1018 	mov	a,#0x27
      003D46 95 0A            [12] 1019 	subb	a,_ak820_leader_process_sloc0_1_0
      003D48 E4               [12] 1020 	clr	a
      003D49 95 0B            [12] 1021 	subb	a,(_ak820_leader_process_sloc0_1_0 + 1)
      003D4B 40 0B            [24] 1022 	jc	00127$
                                   1023 ;	free result
      003D4D 89 07            [24] 1024 	mov	ar7,r1
      003D4F EF               [12] 1025 	mov	a,r7
      003D50 24 E2            [12] 1026 	add	a,#0xe2
      003D52 90 05 12         [24] 1027 	mov	dptr,#_ak820_leader_process_slot_10000_602
      003D55 F0               [24] 1028 	movx	@dptr,a
      003D56 80 11            [24] 1029 	sjmp	00128$
      003D58                       1030 00127$:
                                   1031 ;	keyboards/ajazz/ak820/ak820_leader.c:60: else if (code >= KC_A && code <= KC_F) slot = code - KC_A + 10;
      003D58 C3               [12] 1032 	clr	c
      003D59 74 09            [12] 1033 	mov	a,#0x09
      003D5B 95 0A            [12] 1034 	subb	a,_ak820_leader_process_sloc0_1_0
      003D5D E4               [12] 1035 	clr	a
      003D5E 95 0B            [12] 1036 	subb	a,(_ak820_leader_process_sloc0_1_0 + 1)
      003D60 40 07            [24] 1037 	jc	00128$
                                   1038 ;	free result
      003D62 90 05 12         [24] 1039 	mov	dptr,#_ak820_leader_process_slot_10000_602
      003D65 74 06            [12] 1040 	mov	a,#0x06
      003D67 29               [12] 1041 	add	a, r1
      003D68 F0               [24] 1042 	movx	@dptr,a
      003D69                       1043 00128$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_leader.c:61: leader_pending = slot; /* Other basic keys are consumed without output. */
      003D69 90 05 12         [24] 1045 	mov	dptr,#_ak820_leader_process_slot_10000_602
      003D6C E0               [24] 1046 	movx	a,@dptr
      003D6D 90 0D 9A         [24] 1047 	mov	dptr,#_leader_pending
      003D70 F0               [24] 1048 	movx	@dptr,a
      003D71                       1049 00132$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_leader.c:63: leader_suppressed[index] |= mask;
      003D71 8B 82            [24] 1051 	mov	dpl,r3
      003D73 8D 83            [24] 1052 	mov	dph,r5
      003D75 E0               [24] 1053 	movx	a,@dptr
      003D76 42 04            [12] 1054 	orl	ar4,a
      003D78 8B 82            [24] 1055 	mov	dpl,r3
      003D7A 8D 83            [24] 1056 	mov	dph,r5
      003D7C EC               [12] 1057 	mov	a,r4
      003D7D F0               [24] 1058 	movx	@dptr,a
                                   1059 ;	keyboards/ajazz/ak820/ak820_leader.c:64: return false;
      003D7E 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_leader.c:65: }
      003D81 22               [24] 1062 	ret
                                   1063 	.area CSEG    (CODE)
                                   1064 	.area CONST   (CODE)
                                   1065 	.area XINIT   (CODE)
      00C12D                       1066 __xinit__leader_pending:
      00C12D FF                    1067 	.db #0xff	; 255
                                   1068 	.area CABS    (ABS,CODE)
