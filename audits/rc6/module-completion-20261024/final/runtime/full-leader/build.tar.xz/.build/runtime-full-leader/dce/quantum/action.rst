                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_leader_cancel
                                     21 	.globl _ak820_leader_task
                                     22 	.globl _pre_process_record_quantum
                                     23 	.globl _get_record_keycode
                                     24 	.globl _repeat_key_cancel
                                     25 	.globl _clear_owned_usages
                                     26 	.globl _owned_usage_key
                                     27 	.globl _clear_owned_keys
                                     28 	.globl _del_owned_key
                                     29 	.globl _add_owned_key
                                     30 	.globl _clear_owned_mods
                                     31 	.globl _del_owned_weak_mods
                                     32 	.globl _add_owned_weak_mods
                                     33 	.globl _del_owned_mods
                                     34 	.globl _add_owned_mods
                                     35 	.globl _clear_weak_mods
                                     36 	.globl _clear_mods
                                     37 	.globl _send_keyboard_report
                                     38 	.globl _layer_hold_clear
                                     39 	.globl _layer_hold_off
                                     40 	.globl _layer_hold_on
                                     41 	.globl _ak820_resolve_key
                                     42 	.globl _layer_xor
                                     43 	.globl _layer_and
                                     44 	.globl _layer_or
                                     45 	.globl _layer_off
                                     46 	.globl _layer_on
                                     47 	.globl _layer_move
                                     48 	.globl _layer_clear
                                     49 	.globl _layer_state_set
                                     50 	.globl _default_layer_xor
                                     51 	.globl _default_layer_and
                                     52 	.globl _default_layer_or
                                     53 	.globl _default_layer_set
                                     54 	.globl _process_record_quantum
                                     55 	.globl _action_for_keycode
                                     56 	.globl _mDelaymS
                                     57 	.globl _host_consumer_send
                                     58 	.globl _host_system_send
                                     59 	.globl _host_keyboard_leds
                                     60 	.globl _led_set
                                     61 	.globl _clear_keys_from_report
                                     62 	.globl ___memcpy
                                     63 	.globl _ADC_START
                                     64 	.globl _S0_R_FIFO
                                     65 	.globl _S0_T_FIFO
                                     66 	.globl _S0_FREE
                                     67 	.globl _S0_IF_BYTE
                                     68 	.globl _S0_IF_FIRST
                                     69 	.globl _S0_IF_OV
                                     70 	.globl _S0_FST_ACT
                                     71 	.globl _CP_RL2
                                     72 	.globl _C_T2
                                     73 	.globl _TR2
                                     74 	.globl _EXEN2
                                     75 	.globl _TCLK
                                     76 	.globl _RCLK
                                     77 	.globl _EXF2
                                     78 	.globl _CAP1F
                                     79 	.globl _TF2
                                     80 	.globl _RI
                                     81 	.globl _TI
                                     82 	.globl _RB8
                                     83 	.globl _TB8
                                     84 	.globl _REN
                                     85 	.globl _SM2
                                     86 	.globl _SM1
                                     87 	.globl _SM0
                                     88 	.globl _IT0
                                     89 	.globl _IE0
                                     90 	.globl _IT1
                                     91 	.globl _IE1
                                     92 	.globl _TR0
                                     93 	.globl _TF0
                                     94 	.globl _TR1
                                     95 	.globl _TF1
                                     96 	.globl _P4_0
                                     97 	.globl _P4_1
                                     98 	.globl _P4_2
                                     99 	.globl _P4_3
                                    100 	.globl _P4_4
                                    101 	.globl _P4_5
                                    102 	.globl _P4_6
                                    103 	.globl _RXD
                                    104 	.globl _TXD
                                    105 	.globl _INT0
                                    106 	.globl _INT1
                                    107 	.globl _T0
                                    108 	.globl _T1
                                    109 	.globl _MOSI1
                                    110 	.globl _MISO1
                                    111 	.globl _SCK1
                                    112 	.globl _P3_0
                                    113 	.globl _P3_1
                                    114 	.globl _P3_2
                                    115 	.globl _P3_3
                                    116 	.globl _P3_4
                                    117 	.globl _P3_5
                                    118 	.globl _P3_6
                                    119 	.globl _P3_7
                                    120 	.globl _CAP1_
                                    121 	.globl _T2_
                                    122 	.globl _CAP2_
                                    123 	.globl _T2EX_
                                    124 	.globl _RXD1
                                    125 	.globl _TXD1
                                    126 	.globl _P2_0
                                    127 	.globl _P2_1
                                    128 	.globl _P2_2
                                    129 	.globl _P2_3
                                    130 	.globl _P2_4
                                    131 	.globl _P2_5
                                    132 	.globl _P2_6
                                    133 	.globl _P2_7
                                    134 	.globl _AIN0
                                    135 	.globl _AIN1
                                    136 	.globl _AIN2
                                    137 	.globl _AIN3
                                    138 	.globl _AIN4
                                    139 	.globl _AIN5
                                    140 	.globl _AIN6
                                    141 	.globl _AIN7
                                    142 	.globl _CAP1
                                    143 	.globl _T2
                                    144 	.globl _CAP2
                                    145 	.globl _T2EX
                                    146 	.globl _INT0_
                                    147 	.globl _SCS
                                    148 	.globl _MOSI
                                    149 	.globl _MISO
                                    150 	.globl _SCK
                                    151 	.globl _RXD1_
                                    152 	.globl _TXD1_
                                    153 	.globl _P1_0
                                    154 	.globl _P1_1
                                    155 	.globl _P1_2
                                    156 	.globl _P1_3
                                    157 	.globl _P1_4
                                    158 	.globl _P1_5
                                    159 	.globl _P1_6
                                    160 	.globl _P1_7
                                    161 	.globl _AIN8
                                    162 	.globl _AIN9
                                    163 	.globl _AIN10
                                    164 	.globl _AIN11
                                    165 	.globl _AIN12
                                    166 	.globl _AIN13
                                    167 	.globl _RXD_
                                    168 	.globl _TXD_
                                    169 	.globl _SCL0
                                    170 	.globl _SDA0
                                    171 	.globl _P0_0
                                    172 	.globl _P0_1
                                    173 	.globl _P0_2
                                    174 	.globl _P0_3
                                    175 	.globl _P0_4
                                    176 	.globl _P0_5
                                    177 	.globl _P0_6
                                    178 	.globl _P0_7
                                    179 	.globl _IE_SPI0
                                    180 	.globl _IE_USB
                                    181 	.globl _IE_ADC
                                    182 	.globl _IE_UART1
                                    183 	.globl _IE_PWM_I2C
                                    184 	.globl _IE_GPIO
                                    185 	.globl _IE_WDOG
                                    186 	.globl _PX0
                                    187 	.globl _PT0
                                    188 	.globl _PX1
                                    189 	.globl _PT1
                                    190 	.globl _PS
                                    191 	.globl _PT2
                                    192 	.globl _PL_FLAG
                                    193 	.globl _PH_FLAG
                                    194 	.globl _EX0
                                    195 	.globl _ET0
                                    196 	.globl _EX1
                                    197 	.globl _ET1
                                    198 	.globl _ES
                                    199 	.globl _ET2
                                    200 	.globl _E_DIS
                                    201 	.globl _EA
                                    202 	.globl _P
                                    203 	.globl _F1
                                    204 	.globl _OV
                                    205 	.globl _RS0
                                    206 	.globl _RS1
                                    207 	.globl _F0
                                    208 	.globl _AC
                                    209 	.globl _CY
                                    210 	.globl _I2CS_INT_ST
                                    211 	.globl _I2CX_INT
                                    212 	.globl _LED_STATUS
                                    213 	.globl _LED_DMA_H
                                    214 	.globl _LED_DMA_L
                                    215 	.globl _LED_DMA
                                    216 	.globl _LED_PWM_OE
                                    217 	.globl _LED_COMMON
                                    218 	.globl _ADC_CHAN
                                    219 	.globl _ADC_DAT_H
                                    220 	.globl _ADC_DAT_L
                                    221 	.globl _ADC_DAT
                                    222 	.globl _ADC_CTRL
                                    223 	.globl _SPI1_CK_SE
                                    224 	.globl _SPI1_CTRL
                                    225 	.globl _SPI1_DATA
                                    226 	.globl _SPI1_STAT
                                    227 	.globl _SIF1
                                    228 	.globl _SBAUD1
                                    229 	.globl _SBUF1
                                    230 	.globl _SCON1
                                    231 	.globl _SPI0_SETUP
                                    232 	.globl _SPI0_CK_SE
                                    233 	.globl _SPI0_CTRL
                                    234 	.globl _SPI0_DATA
                                    235 	.globl _SPI0_STAT
                                    236 	.globl _T2CAP1H
                                    237 	.globl _T2CAP1L
                                    238 	.globl _T2CAP1
                                    239 	.globl _TH2
                                    240 	.globl _TL2
                                    241 	.globl _T2COUNT
                                    242 	.globl _RCAP2H
                                    243 	.globl _RCAP2L
                                    244 	.globl _RCAP2
                                    245 	.globl _T2MOD
                                    246 	.globl _T2CON
                                    247 	.globl _SBUF
                                    248 	.globl _SCON
                                    249 	.globl _TH1
                                    250 	.globl _TH0
                                    251 	.globl _TL1
                                    252 	.globl _TL0
                                    253 	.globl _TMOD
                                    254 	.globl _TCON
                                    255 	.globl _XBUS_AUX
                                    256 	.globl _P7
                                    257 	.globl _P6_DIR
                                    258 	.globl _P6_OUT_PU
                                    259 	.globl _P6_IN
                                    260 	.globl _P5_DIR
                                    261 	.globl _P5_OUT_PU
                                    262 	.globl _P5_IN
                                    263 	.globl _P4_LED_KEY
                                    264 	.globl _P4_DIR_PU
                                    265 	.globl _P4_MOD_OC
                                    266 	.globl _P4
                                    267 	.globl _P3_DIR_PU
                                    268 	.globl _P3_MOD_OC
                                    269 	.globl _P3
                                    270 	.globl _P2_DIR_PU
                                    271 	.globl _P2_MOD_OC
                                    272 	.globl _P2
                                    273 	.globl _P1_DIR_PU
                                    274 	.globl _P1_MOD_OC
                                    275 	.globl _P1
                                    276 	.globl _P0_DIR_PU
                                    277 	.globl _P0_MOD_OC
                                    278 	.globl _P0
                                    279 	.globl _ROM_CTRL
                                    280 	.globl _ROM_DATA_HH
                                    281 	.globl _ROM_DATA_HL
                                    282 	.globl _ROM_DATA_HI
                                    283 	.globl _ROM_ADDR_H
                                    284 	.globl _ROM_ADDR_L
                                    285 	.globl _ROM_ADDR
                                    286 	.globl _GPIO_IE
                                    287 	.globl _IP_EX
                                    288 	.globl _IE_EX
                                    289 	.globl _IP
                                    290 	.globl _IE
                                    291 	.globl _WDOG_COUNT
                                    292 	.globl _RESET_KEEP
                                    293 	.globl _WAKE_CTRL
                                    294 	.globl _CLOCK_CFG
                                    295 	.globl _POWER_CFG
                                    296 	.globl _PCON
                                    297 	.globl _GLOBAL_CFG
                                    298 	.globl _SAFE_MOD
                                    299 	.globl _DPH
                                    300 	.globl _DPL
                                    301 	.globl _SP
                                    302 	.globl _A_INV
                                    303 	.globl _B
                                    304 	.globl _ACC
                                    305 	.globl _PSW
                                    306 	.globl _disable_action_cache
                                    307 	.globl _tap_code_delay_PARM_2
                                    308 	.globl _process_action_PARM_2
                                    309 	.globl _action_exec_PARM_1
                                    310 	.globl _tp_buttons
                                    311 	.globl _action_exec
                                    312 	.globl _ak820_action_exec
                                    313 	.globl _process_record
                                    314 	.globl _process_record_handler
                                    315 	.globl _process_action
                                    316 	.globl _register_code
                                    317 	.globl _unregister_code
                                    318 	.globl _tap_code_delay
                                    319 	.globl _tap_code
                                    320 	.globl _register_mods
                                    321 	.globl _unregister_mods
                                    322 	.globl _register_weak_mods
                                    323 	.globl _unregister_weak_mods
                                    324 	.globl _clear_keyboard
                                    325 	.globl _clear_keyboard_but_mods
                                    326 	.globl _clear_keyboard_but_mods_and_keys
                                    327 ;--------------------------------------------------------
                                    328 ; special function registers
                                    329 ;--------------------------------------------------------
                                    330 	.area RSEG    (ABS,DATA)
      000000                        331 	.org 0x0000
                           0000D0   332 _PSW	=	0x00d0
                           0000E0   333 _ACC	=	0x00e0
                           0000F0   334 _B	=	0x00f0
                           0000FD   335 _A_INV	=	0x00fd
                           000081   336 _SP	=	0x0081
                           000082   337 _DPL	=	0x0082
                           000083   338 _DPH	=	0x0083
                           0000A1   339 _SAFE_MOD	=	0x00a1
                           0000B1   340 _GLOBAL_CFG	=	0x00b1
                           000087   341 _PCON	=	0x0087
                           0000BA   342 _POWER_CFG	=	0x00ba
                           0000B9   343 _CLOCK_CFG	=	0x00b9
                           0000A9   344 _WAKE_CTRL	=	0x00a9
                           0000FE   345 _RESET_KEEP	=	0x00fe
                           0000FF   346 _WDOG_COUNT	=	0x00ff
                           0000A8   347 _IE	=	0x00a8
                           0000B8   348 _IP	=	0x00b8
                           0000E8   349 _IE_EX	=	0x00e8
                           0000E9   350 _IP_EX	=	0x00e9
                           0000B2   351 _GPIO_IE	=	0x00b2
                           008584   352 _ROM_ADDR	=	0x8584
                           000084   353 _ROM_ADDR_L	=	0x0084
                           000085   354 _ROM_ADDR_H	=	0x0085
                           008F8E   355 _ROM_DATA_HI	=	0x8f8e
                           00008E   356 _ROM_DATA_HL	=	0x008e
                           00008F   357 _ROM_DATA_HH	=	0x008f
                           000086   358 _ROM_CTRL	=	0x0086
                           000080   359 _P0	=	0x0080
                           0000C4   360 _P0_MOD_OC	=	0x00c4
                           0000C5   361 _P0_DIR_PU	=	0x00c5
                           000090   362 _P1	=	0x0090
                           000092   363 _P1_MOD_OC	=	0x0092
                           000093   364 _P1_DIR_PU	=	0x0093
                           0000A0   365 _P2	=	0x00a0
                           000094   366 _P2_MOD_OC	=	0x0094
                           000095   367 _P2_DIR_PU	=	0x0095
                           0000B0   368 _P3	=	0x00b0
                           000096   369 _P3_MOD_OC	=	0x0096
                           000097   370 _P3_DIR_PU	=	0x0097
                           0000C0   371 _P4	=	0x00c0
                           0000C2   372 _P4_MOD_OC	=	0x00c2
                           0000C3   373 _P4_DIR_PU	=	0x00c3
                           0000C1   374 _P4_LED_KEY	=	0x00c1
                           0000AA   375 _P5_IN	=	0x00aa
                           0000AB   376 _P5_OUT_PU	=	0x00ab
                           0000AC   377 _P5_DIR	=	0x00ac
                           0000AD   378 _P6_IN	=	0x00ad
                           0000AE   379 _P6_OUT_PU	=	0x00ae
                           0000AF   380 _P6_DIR	=	0x00af
                           0000F1   381 _P7	=	0x00f1
                           0000A2   382 _XBUS_AUX	=	0x00a2
                           000088   383 _TCON	=	0x0088
                           000089   384 _TMOD	=	0x0089
                           00008A   385 _TL0	=	0x008a
                           00008B   386 _TL1	=	0x008b
                           00008C   387 _TH0	=	0x008c
                           00008D   388 _TH1	=	0x008d
                           000098   389 _SCON	=	0x0098
                           000099   390 _SBUF	=	0x0099
                           0000C8   391 _T2CON	=	0x00c8
                           0000C9   392 _T2MOD	=	0x00c9
                           00CBCA   393 _RCAP2	=	0xcbca
                           0000CA   394 _RCAP2L	=	0x00ca
                           0000CB   395 _RCAP2H	=	0x00cb
                           00CDCC   396 _T2COUNT	=	0xcdcc
                           0000CC   397 _TL2	=	0x00cc
                           0000CD   398 _TH2	=	0x00cd
                           00CFCE   399 _T2CAP1	=	0xcfce
                           0000CE   400 _T2CAP1L	=	0x00ce
                           0000CF   401 _T2CAP1H	=	0x00cf
                           0000F8   402 _SPI0_STAT	=	0x00f8
                           0000F9   403 _SPI0_DATA	=	0x00f9
                           0000FA   404 _SPI0_CTRL	=	0x00fa
                           0000FB   405 _SPI0_CK_SE	=	0x00fb
                           0000FC   406 _SPI0_SETUP	=	0x00fc
                           0000BC   407 _SCON1	=	0x00bc
                           0000BD   408 _SBUF1	=	0x00bd
                           0000BE   409 _SBAUD1	=	0x00be
                           0000BF   410 _SIF1	=	0x00bf
                           0000B4   411 _SPI1_STAT	=	0x00b4
                           0000B5   412 _SPI1_DATA	=	0x00b5
                           0000B6   413 _SPI1_CTRL	=	0x00b6
                           0000B7   414 _SPI1_CK_SE	=	0x00b7
                           0000F3   415 _ADC_CTRL	=	0x00f3
                           00F5F4   416 _ADC_DAT	=	0xf5f4
                           0000F4   417 _ADC_DAT_L	=	0x00f4
                           0000F5   418 _ADC_DAT_H	=	0x00f5
                           0000F6   419 _ADC_CHAN	=	0x00f6
                           0000A6   420 _LED_COMMON	=	0x00a6
                           0000A7   421 _LED_PWM_OE	=	0x00a7
                           00C7C6   422 _LED_DMA	=	0xc7c6
                           0000C6   423 _LED_DMA_L	=	0x00c6
                           0000C7   424 _LED_DMA_H	=	0x00c7
                           0000F7   425 _LED_STATUS	=	0x00f7
                           0000B3   426 _I2CX_INT	=	0x00b3
                           0000BB   427 _I2CS_INT_ST	=	0x00bb
                                    428 ;--------------------------------------------------------
                                    429 ; special function bits
                                    430 ;--------------------------------------------------------
                                    431 	.area RSEG    (ABS,DATA)
      000000                        432 	.org 0x0000
                           0000D7   433 _CY	=	0x00d7
                           0000D6   434 _AC	=	0x00d6
                           0000D5   435 _F0	=	0x00d5
                           0000D4   436 _RS1	=	0x00d4
                           0000D3   437 _RS0	=	0x00d3
                           0000D2   438 _OV	=	0x00d2
                           0000D1   439 _F1	=	0x00d1
                           0000D0   440 _P	=	0x00d0
                           0000AF   441 _EA	=	0x00af
                           0000AE   442 _E_DIS	=	0x00ae
                           0000AD   443 _ET2	=	0x00ad
                           0000AC   444 _ES	=	0x00ac
                           0000AB   445 _ET1	=	0x00ab
                           0000AA   446 _EX1	=	0x00aa
                           0000A9   447 _ET0	=	0x00a9
                           0000A8   448 _EX0	=	0x00a8
                           0000BF   449 _PH_FLAG	=	0x00bf
                           0000BE   450 _PL_FLAG	=	0x00be
                           0000BD   451 _PT2	=	0x00bd
                           0000BC   452 _PS	=	0x00bc
                           0000BB   453 _PT1	=	0x00bb
                           0000BA   454 _PX1	=	0x00ba
                           0000B9   455 _PT0	=	0x00b9
                           0000B8   456 _PX0	=	0x00b8
                           0000EF   457 _IE_WDOG	=	0x00ef
                           0000EE   458 _IE_GPIO	=	0x00ee
                           0000ED   459 _IE_PWM_I2C	=	0x00ed
                           0000EC   460 _IE_UART1	=	0x00ec
                           0000EB   461 _IE_ADC	=	0x00eb
                           0000E9   462 _IE_USB	=	0x00e9
                           0000E8   463 _IE_SPI0	=	0x00e8
                           000087   464 _P0_7	=	0x0087
                           000086   465 _P0_6	=	0x0086
                           000085   466 _P0_5	=	0x0085
                           000084   467 _P0_4	=	0x0084
                           000083   468 _P0_3	=	0x0083
                           000082   469 _P0_2	=	0x0082
                           000081   470 _P0_1	=	0x0081
                           000080   471 _P0_0	=	0x0080
                           000081   472 _SDA0	=	0x0081
                           000080   473 _SCL0	=	0x0080
                           000083   474 _TXD_	=	0x0083
                           000082   475 _RXD_	=	0x0082
                           000085   476 _AIN13	=	0x0085
                           000084   477 _AIN12	=	0x0084
                           000083   478 _AIN11	=	0x0083
                           000082   479 _AIN10	=	0x0082
                           000081   480 _AIN9	=	0x0081
                           000080   481 _AIN8	=	0x0080
                           000097   482 _P1_7	=	0x0097
                           000096   483 _P1_6	=	0x0096
                           000095   484 _P1_5	=	0x0095
                           000094   485 _P1_4	=	0x0094
                           000093   486 _P1_3	=	0x0093
                           000092   487 _P1_2	=	0x0092
                           000091   488 _P1_1	=	0x0091
                           000090   489 _P1_0	=	0x0090
                           000097   490 _TXD1_	=	0x0097
                           000096   491 _RXD1_	=	0x0096
                           000097   492 _SCK	=	0x0097
                           000096   493 _MISO	=	0x0096
                           000095   494 _MOSI	=	0x0095
                           000094   495 _SCS	=	0x0094
                           000092   496 _INT0_	=	0x0092
                           000091   497 _T2EX	=	0x0091
                           000091   498 _CAP2	=	0x0091
                           000090   499 _T2	=	0x0090
                           000090   500 _CAP1	=	0x0090
                           000097   501 _AIN7	=	0x0097
                           000096   502 _AIN6	=	0x0096
                           000095   503 _AIN5	=	0x0095
                           000094   504 _AIN4	=	0x0094
                           000093   505 _AIN3	=	0x0093
                           000092   506 _AIN2	=	0x0092
                           000091   507 _AIN1	=	0x0091
                           000090   508 _AIN0	=	0x0090
                           0000A7   509 _P2_7	=	0x00a7
                           0000A6   510 _P2_6	=	0x00a6
                           0000A5   511 _P2_5	=	0x00a5
                           0000A4   512 _P2_4	=	0x00a4
                           0000A3   513 _P2_3	=	0x00a3
                           0000A2   514 _P2_2	=	0x00a2
                           0000A1   515 _P2_1	=	0x00a1
                           0000A0   516 _P2_0	=	0x00a0
                           0000A7   517 _TXD1	=	0x00a7
                           0000A6   518 _RXD1	=	0x00a6
                           0000A5   519 _T2EX_	=	0x00a5
                           0000A5   520 _CAP2_	=	0x00a5
                           0000A4   521 _T2_	=	0x00a4
                           0000A4   522 _CAP1_	=	0x00a4
                           0000B7   523 _P3_7	=	0x00b7
                           0000B6   524 _P3_6	=	0x00b6
                           0000B5   525 _P3_5	=	0x00b5
                           0000B4   526 _P3_4	=	0x00b4
                           0000B3   527 _P3_3	=	0x00b3
                           0000B2   528 _P3_2	=	0x00b2
                           0000B1   529 _P3_1	=	0x00b1
                           0000B0   530 _P3_0	=	0x00b0
                           0000B7   531 _SCK1	=	0x00b7
                           0000B6   532 _MISO1	=	0x00b6
                           0000B5   533 _MOSI1	=	0x00b5
                           0000B5   534 _T1	=	0x00b5
                           0000B4   535 _T0	=	0x00b4
                           0000B3   536 _INT1	=	0x00b3
                           0000B2   537 _INT0	=	0x00b2
                           0000B1   538 _TXD	=	0x00b1
                           0000B0   539 _RXD	=	0x00b0
                           0000C6   540 _P4_6	=	0x00c6
                           0000C5   541 _P4_5	=	0x00c5
                           0000C4   542 _P4_4	=	0x00c4
                           0000C3   543 _P4_3	=	0x00c3
                           0000C2   544 _P4_2	=	0x00c2
                           0000C1   545 _P4_1	=	0x00c1
                           0000C0   546 _P4_0	=	0x00c0
                           00008F   547 _TF1	=	0x008f
                           00008E   548 _TR1	=	0x008e
                           00008D   549 _TF0	=	0x008d
                           00008C   550 _TR0	=	0x008c
                           00008B   551 _IE1	=	0x008b
                           00008A   552 _IT1	=	0x008a
                           000089   553 _IE0	=	0x0089
                           000088   554 _IT0	=	0x0088
                           00009F   555 _SM0	=	0x009f
                           00009E   556 _SM1	=	0x009e
                           00009D   557 _SM2	=	0x009d
                           00009C   558 _REN	=	0x009c
                           00009B   559 _TB8	=	0x009b
                           00009A   560 _RB8	=	0x009a
                           000099   561 _TI	=	0x0099
                           000098   562 _RI	=	0x0098
                           0000CF   563 _TF2	=	0x00cf
                           0000CF   564 _CAP1F	=	0x00cf
                           0000CE   565 _EXF2	=	0x00ce
                           0000CD   566 _RCLK	=	0x00cd
                           0000CC   567 _TCLK	=	0x00cc
                           0000CB   568 _EXEN2	=	0x00cb
                           0000CA   569 _TR2	=	0x00ca
                           0000C9   570 _C_T2	=	0x00c9
                           0000C8   571 _CP_RL2	=	0x00c8
                           0000FF   572 _S0_FST_ACT	=	0x00ff
                           0000FE   573 _S0_IF_OV	=	0x00fe
                           0000FD   574 _S0_IF_FIRST	=	0x00fd
                           0000FC   575 _S0_IF_BYTE	=	0x00fc
                           0000FB   576 _S0_FREE	=	0x00fb
                           0000FA   577 _S0_T_FIFO	=	0x00fa
                           0000F8   578 _S0_R_FIFO	=	0x00f8
                           0000F7   579 _ADC_START	=	0x00f7
                                    580 ;--------------------------------------------------------
                                    581 ; overlayable register banks
                                    582 ;--------------------------------------------------------
                                    583 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        584 	.ds 8
                                    585 ;--------------------------------------------------------
                                    586 ; internal ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area DSEG    (DATA)
      000018                        589 _process_action_sloc0_1_0:
      000018                        590 	.ds 1
                                    591 ;--------------------------------------------------------
                                    592 ; overlayable items in internal ram
                                    593 ;--------------------------------------------------------
                                    594 ;--------------------------------------------------------
                                    595 ; indirectly addressable internal ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area ISEG    (DATA)
                                    598 ;--------------------------------------------------------
                                    599 ; absolute internal ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area IABS    (ABS,DATA)
                                    602 	.area IABS    (ABS,DATA)
                                    603 ;--------------------------------------------------------
                                    604 ; bit data
                                    605 ;--------------------------------------------------------
                                    606 	.area BSEG    (BIT)
      00001D                        607 _process_action_sloc1_1_0:
      00001D                        608 	.ds 1
                                    609 ;--------------------------------------------------------
                                    610 ; paged external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area PSEG    (PAG,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; uninitialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XSEG    (XDATA)
      000824                        617 _tp_buttons::
      000824                        618 	.ds 2
      000826                        619 _action_exec_PARM_1:
      000826                        620 	.ds 6
      00082C                        621 _action_exec_record_10001_627:
      00082C                        622 	.ds 9
      000835                        623 _ak820_action_exec_event_10000_632:
      000835                        624 	.ds 2
      000837                        625 _ak820_action_exec_snapshot_10000_633:
      000837                        626 	.ds 6
      00083D                        627 _process_record_record_argument_10000_636:
      00083D                        628 	.ds 2
      00083F                        629 _process_record_handler_record_argument_10000_644:
      00083F                        630 	.ds 2
      000841                        631 _process_record_handler_action_10000_645:
      000841                        632 	.ds 2
      000843                        633 _process_action_PARM_2:
      000843                        634 	.ds 2
      000845                        635 _process_action_record_argument_10000_656:
      000845                        636 	.ds 2
      000847                        637 _process_action_on_40000_679:
      000847                        638 	.ds 1
      000848                        639 _register_code_code_10000_713:
      000848                        640 	.ds 1
      000849                        641 _unregister_code_code_10000_727:
      000849                        642 	.ds 1
      00084A                        643 _tap_code_delay_PARM_2:
      00084A                        644 	.ds 2
      00084C                        645 _tap_code_delay_code_10000_740:
      00084C                        646 	.ds 1
      00084D                        647 _tap_code_code_10000_747:
      00084D                        648 	.ds 1
      00084E                        649 _register_mods_mods_10000_749:
      00084E                        650 	.ds 1
      00084F                        651 _unregister_mods_mods_10000_753:
      00084F                        652 	.ds 1
      000850                        653 _register_weak_mods_mods_10000_757:
      000850                        654 	.ds 1
      000851                        655 _unregister_weak_mods_mods_10000_761:
      000851                        656 	.ds 1
                                    657 ;--------------------------------------------------------
                                    658 ; absolute external ram data
                                    659 ;--------------------------------------------------------
                                    660 	.area XABS    (ABS,XDATA)
                                    661 ;--------------------------------------------------------
                                    662 ; initialized external ram data
                                    663 ;--------------------------------------------------------
                                    664 	.area XISEG   (XDATA)
      000DAB                        665 _disable_action_cache::
      000DAB                        666 	.ds 1
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT0 (CODE)
                                    669 	.area GSINIT1 (CODE)
                                    670 	.area GSINIT2 (CODE)
                                    671 	.area GSINIT3 (CODE)
                                    672 	.area GSINIT4 (CODE)
                                    673 	.area GSINIT5 (CODE)
                                    674 	.area GSINIT  (CODE)
                                    675 	.area GSFINAL (CODE)
                                    676 	.area CSEG    (CODE)
                                    677 ;--------------------------------------------------------
                                    678 ; global & static initialisations
                                    679 ;--------------------------------------------------------
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 	.area GSFINAL (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 ;--------------------------------------------------------
                                    685 ; Home
                                    686 ;--------------------------------------------------------
                                    687 	.area HOME    (CODE)
                                    688 	.area HOME    (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; code
                                    691 ;--------------------------------------------------------
                                    692 	.area CSEG    (CODE)
                                    693 ;------------------------------------------------------------
                                    694 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    695 ;------------------------------------------------------------
                                    696 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    697 ;------------------------------------------------------------
                                    698 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    699 ;	-----------------------------------------
                           000007   700 	ar7 = 0x07
                           000006   701 	ar6 = 0x06
                           000005   702 	ar5 = 0x05
                           000004   703 	ar4 = 0x04
                           000003   704 	ar3 = 0x03
                           000002   705 	ar2 = 0x02
                           000001   706 	ar1 = 0x01
                           000000   707 	ar0 = 0x00
                                    708 ;	 function action_exec
                                    709 ;	-----------------------------------------
      0071CB                        710 _action_exec:
                                    711 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0071CB 90 08 28         [24]  712 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0071CE 12 37 A1         [24]  713 	lcall	_ak820_outline_0004
      0071D1 12 35 B8         [24]  714 	lcall	_ak820_combo_tick
                                    715 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0071D4 90 08 26         [24]  716 	mov	dptr,#_action_exec_PARM_1
      0071D7 12 46 5F         [24]  717 	lcall	_ak820_tapping_before
      0071DA E5 82            [12]  718 	mov	a, dpl
      0071DC 70 01            [24]  719 	jnz	00102$
      0071DE 22               [24]  720 	ret
      0071DF                        721 00102$:
                                    722 ;	quantum/action.c:126: if (event.pressed) {
      0071DF 90 08 2B         [24]  723 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0071E2 E0               [24]  724 	movx	a,@dptr
      0071E3 60 03            [24]  725 	jz	00104$
                                    726 ;	quantum/action.c:128: clear_weak_mods();
      0071E5 12 81 E3         [24]  727 	lcall	_clear_weak_mods
      0071E8                        728 00104$:
                                    729 ;	quantum/action.c:140: record.event = event;
      0071E8 90 0D 8A         [24]  730 	mov	dptr,#___memcpy_PARM_2
      0071EB 74 26            [12]  731 	mov	a,#_action_exec_PARM_1
      0071ED F0               [24]  732 	movx	@dptr,a
      0071EE 74 08            [12]  733 	mov	a,#(_action_exec_PARM_1 >> 8)
      0071F0 12 78 5A         [24]  734 	lcall	_ak820_outline_0049
      0071F3 12 78 7A         [24]  735 	lcall	_ak820_outline_0108
      0071F6 90 08 2C         [24]  736 	mov	dptr,#_action_exec_record_10001_627
      0071F9 F5 F0            [12]  737 	mov	b,a
      0071FB 12 B8 6D         [24]  738 	lcall	___memcpy
                                    739 ;	quantum/action.c:142: record.tap.count = 0;
      0071FE 90 08 32         [24]  740 	mov	dptr,#(_action_exec_record_10001_627 + 0x0006)
      007201 E0               [24]  741 	movx	a,@dptr
      007202 54 0F            [12]  742 	anl	a,#0x0f
      007204 F0               [24]  743 	movx	@dptr,a
                                    744 ;	quantum/action.c:147: record.keycode = 0;
      007205 90 08 33         [24]  745 	mov	dptr,#(_action_exec_record_10001_627 + 0x0007)
      007208 12 51 1C         [24]  746 	lcall	_ak820_outline_0165
                                    747 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00720B 90 08 30         [24]  748 	mov	dptr,#(_action_exec_record_10001_627 + 0x0004)
      00720E E0               [24]  749 	movx	a,@dptr
      00720F 60 0A            [24]  750 	jz	00107$
      007211 90 08 2C         [24]  751 	mov	dptr,#_action_exec_record_10001_627
      007214 12 9F 47         [24]  752 	lcall	_pre_process_record_quantum
      007217 E5 82            [12]  753 	mov	a, dpl
      007219 60 11            [24]  754 	jz	00108$
      00721B                        755 00107$:
                                    756 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      00721B 90 08 2C         [24]  757 	mov	dptr,#_action_exec_record_10001_627
      00721E 12 47 4B         [24]  758 	lcall	_ak820_tapping_process
      007221 E5 82            [12]  759 	mov	a, dpl
      007223 70 01            [24]  760 	jnz	00106$
      007225 22               [24]  761 	ret
      007226                        762 00106$:
                                    763 ;	quantum/action.c:185: process_record(&record);
      007226 90 08 2C         [24]  764 	mov	dptr,#_action_exec_record_10001_627
      007229 12 72 79         [24]  765 	lcall	_process_record
      00722C                        766 00108$:
                                    767 ;	quantum/action.c:198: if (IS_NOEVENT(event)) ak820_leader_task(event.time);
      00722C 90 08 2A         [24]  768 	mov	dptr,#(_action_exec_PARM_1 + 0x0004)
      00722F E0               [24]  769 	movx	a,@dptr
      007230 70 09            [24]  770 	jnz	00112$
      007232 90 08 28         [24]  771 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007235 12 37 A1         [24]  772 	lcall	_ak820_outline_0004
                                    773 ;	quantum/action.c:200: }
      007238 02 3B 69         [24]  774 	ljmp	_ak820_leader_task
      00723B                        775 00112$:
      00723B 22               [24]  776 	ret
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'ak820_action_exec'
                                    779 ;------------------------------------------------------------
                                    780 ;event         Allocated with name '_ak820_action_exec_event_10000_632'
                                    781 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_633'
                                    782 ;------------------------------------------------------------
                                    783 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    784 ;	-----------------------------------------
                                    785 ;	 function ak820_action_exec
                                    786 ;	-----------------------------------------
      00723C                        787 _ak820_action_exec:
      00723C 12 38 4B         [24]  788 	lcall	_ak820_outline_0104
      00723F 90 08 35         [24]  789 	mov	dptr,#_ak820_action_exec_event_10000_632
      007242 12 38 50         [24]  790 	lcall	_ak820_outline_0105
                                    791 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007245 90 08 35         [24]  792 	mov	dptr,#_ak820_action_exec_event_10000_632
      007248 12 38 18         [24]  793 	lcall	_ak820_outline_0057
      00724B 90 0D 8A         [24]  794 	mov	dptr,#___memcpy_PARM_2
      00724E ED               [12]  795 	mov	a,r5
      00724F 12 37 E0         [24]  796 	lcall	_ak820_outline_0015
      007252 90 0D 8D         [24]  797 	mov	dptr,#___memcpy_PARM_3
      007255 12 78 7A         [24]  798 	lcall	_ak820_outline_0108
      007258 90 08 37         [24]  799 	mov	dptr,#_ak820_action_exec_snapshot_10000_633
      00725B F5 F0            [12]  800 	mov	b,a
      00725D 12 B8 6D         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:207: action_exec(snapshot);
      007260 90 0D 8A         [24]  803 	mov	dptr,#___memcpy_PARM_2
      007263 74 37            [12]  804 	mov	a,#_ak820_action_exec_snapshot_10000_633
      007265 F0               [24]  805 	movx	@dptr,a
      007266 74 08            [12]  806 	mov	a,#(_ak820_action_exec_snapshot_10000_633 >> 8)
      007268 12 78 5A         [24]  807 	lcall	_ak820_outline_0049
      00726B 12 78 7A         [24]  808 	lcall	_ak820_outline_0108
      00726E 90 08 26         [24]  809 	mov	dptr,#_action_exec_PARM_1
      007271 F5 F0            [12]  810 	mov	b,a
      007273 12 B8 6D         [24]  811 	lcall	___memcpy
                                    812 ;	quantum/action.c:208: }
      007276 02 71 CB         [24]  813 	ljmp	_action_exec
                                    814 ;------------------------------------------------------------
                                    815 ;Allocation info for local variables in function 'process_record_nocache'
                                    816 ;------------------------------------------------------------
                                    817 ;record        Allocated with name '_process_record_nocache_record_10000_634'
                                    818 ;------------------------------------------------------------
                                    819 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    820 ;	-----------------------------------------
                                    821 ;	 function process_record
                                    822 ;	-----------------------------------------
      007279                        823 _process_record:
      007279 12 38 4B         [24]  824 	lcall	_ak820_outline_0104
      00727C 90 08 3D         [24]  825 	mov	dptr,#_process_record_record_argument_10000_636
      00727F 12 38 50         [24]  826 	lcall	_ak820_outline_0105
                                    827 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007282 90 08 3D         [24]  828 	mov	dptr,#_process_record_record_argument_10000_636
      007285 12 38 01         [24]  829 	lcall	_ak820_outline_0050
                                    830 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      007288 74 04            [12]  831 	mov	a,#0x04
      00728A 12 4A 23         [24]  832 	lcall	_ak820_outline_0010
      00728D 70 01            [24]  833 	jnz	00102$
                                    834 ;	quantum/action.c:354: return;
      00728F 22               [24]  835 	ret
      007290                        836 00102$:
                                    837 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007290 8E 04            [24]  838 	mov	ar4,r6
      007292 8F 05            [24]  839 	mov	ar5,r7
      007294 90 0D 8A         [24]  840 	mov	dptr,#___memcpy_PARM_2
      007297 EC               [12]  841 	mov	a,r4
      007298 F0               [24]  842 	movx	@dptr,a
      007299 ED               [12]  843 	mov	a,r5
      00729A 12 78 5A         [24]  844 	lcall	_ak820_outline_0049
      00729D 12 51 0E         [24]  845 	lcall	_ak820_outline_0107
      0072A0 90 06 3A         [24]  846 	mov	dptr,#_ak820_tapping_source_PARM_1
      0072A3 F5 F0            [12]  847 	mov	b,a
      0072A5 C0 07            [24]  848 	push	ar7
      0072A7 C0 06            [24]  849 	push	ar6
      0072A9 12 B8 6D         [24]  850 	lcall	___memcpy
      0072AC 12 45 9B         [24]  851 	lcall	_ak820_tapping_source
      0072AF AD 82            [24]  852 	mov	r5, dpl
      0072B1 D0 06            [24]  853 	pop	ar6
      0072B3 D0 07            [24]  854 	pop	ar7
                                    855 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0072B5 12 44 FF         [24]  856 	lcall	_ak820_outline_0011
      0072B8 E0               [24]  857 	movx	a,@dptr
      0072B9 FC               [12]  858 	mov	r4,a
                                    859 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0072BA 74 07            [12]  860 	mov	a,#0x07
      0072BC 2E               [12]  861 	add	a, r6
      0072BD FA               [12]  862 	mov	r2,a
      0072BE E4               [12]  863 	clr	a
      0072BF 3F               [12]  864 	addc	a, r7
      0072C0 FB               [12]  865 	mov	r3,a
      0072C1 90 0B EC         [24]  866 	mov	dptr,#_get_record_keycode_PARM_2
      0072C4 12 4A 6D         [24]  867 	lcall	_ak820_outline_0054
      0072C7 C0 07            [24]  868 	push	ar7
      0072C9 C0 06            [24]  869 	push	ar6
      0072CB C0 05            [24]  870 	push	ar5
      0072CD C0 04            [24]  871 	push	ar4
      0072CF C0 03            [24]  872 	push	ar3
      0072D1 C0 02            [24]  873 	push	ar2
      0072D3 12 9F 09         [24]  874 	lcall	_get_record_keycode
      0072D6 A8 82            [24]  875 	mov	r0, dpl
      0072D8 A9 83            [24]  876 	mov	r1, dph
      0072DA D0 02            [24]  877 	pop	ar2
      0072DC D0 03            [24]  878 	pop	ar3
      0072DE D0 04            [24]  879 	pop	ar4
      0072E0 D0 05            [24]  880 	pop	ar5
      0072E2 D0 06            [24]  881 	pop	ar6
      0072E4 D0 07            [24]  882 	pop	ar7
      0072E6 12 45 76         [24]  883 	lcall	_ak820_outline_0139
      0072E9 E8               [12]  884 	mov	a,r0
      0072EA F0               [24]  885 	movx	@dptr,a
      0072EB E9               [12]  886 	mov	a,r1
      0072EC A3               [24]  887 	inc	dptr
      0072ED F0               [24]  888 	movx	@dptr,a
                                    889 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0072EE 74 07            [12]  890 	mov	a,#0x07
      0072F0 12 37 E8         [24]  891 	lcall	_ak820_outline_0016
      0072F3 FA               [12]  892 	mov	r2,a
      0072F4 A3               [24]  893 	inc	dptr
      0072F5 E0               [24]  894 	movx	a,@dptr
      0072F6 FB               [12]  895 	mov	r3,a
      0072F7 90 06 4A         [24]  896 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0072FA ED               [12]  897 	mov	a,r5
      0072FB F0               [24]  898 	movx	@dptr,a
      0072FC 90 06 4B         [24]  899 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0072FF EC               [12]  900 	mov	a,r4
      007300 F0               [24]  901 	movx	@dptr,a
      007301 12 45 76         [24]  902 	lcall	_ak820_outline_0139
      007304 C0 07            [24]  903 	push	ar7
      007306 C0 06            [24]  904 	push	ar6
      007308 C0 05            [24]  905 	push	ar5
      00730A C0 04            [24]  906 	push	ar4
      00730C 12 48 ED         [24]  907 	lcall	_ak820_oneshot_process
      00730F E5 82            [12]  908 	mov	a, dpl
      007311 D0 04            [24]  909 	pop	ar4
      007313 D0 05            [24]  910 	pop	ar5
      007315 D0 06            [24]  911 	pop	ar6
      007317 D0 07            [24]  912 	pop	ar7
      007319 70 01            [24]  913 	jnz	00104$
      00731B 22               [24]  914 	ret
      00731C                        915 00104$:
                                    916 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00731C 12 45 5A         [24]  917 	lcall	_ak820_outline_0114
      00731F C0 07            [24]  918 	push	ar7
      007321 C0 06            [24]  919 	push	ar6
      007323 C0 05            [24]  920 	push	ar5
      007325 C0 04            [24]  921 	push	ar4
      007327 12 9F D8         [24]  922 	lcall	_process_record_quantum
      00732A E5 82            [12]  923 	mov	a, dpl
      00732C D0 04            [24]  924 	pop	ar4
      00732E D0 05            [24]  925 	pop	ar5
      007330 D0 06            [24]  926 	pop	ar6
      007332 D0 07            [24]  927 	pop	ar7
      007334 70 0A            [24]  928 	jnz	00106$
                                    929 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007336 90 05 B2         [24]  930 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007339 EC               [12]  931 	mov	a,r4
      00733A F0               [24]  932 	movx	@dptr,a
      00733B 8D 82            [24]  933 	mov	dpl, r5
                                    934 ;	quantum/action.c:376: return;
      00733D 02 2E BB         [24]  935 	ljmp	_ak820_oneshot_post
      007340                        936 00106$:
                                    937 ;	quantum/action.c:382: process_record_handler(record);
      007340 12 45 5A         [24]  938 	lcall	_ak820_outline_0114
      007343 C0 05            [24]  939 	push	ar5
      007345 C0 04            [24]  940 	push	ar4
      007347 12 73 58         [24]  941 	lcall	_process_record_handler
      00734A D0 04            [24]  942 	pop	ar4
      00734C D0 05            [24]  943 	pop	ar5
                                    944 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00734E 90 05 B2         [24]  945 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007351 EC               [12]  946 	mov	a,r4
      007352 F0               [24]  947 	movx	@dptr,a
      007353 8D 82            [24]  948 	mov	dpl, r5
                                    949 ;	quantum/action.c:392: }
      007355 02 2E BB         [24]  950 	ljmp	_ak820_oneshot_post
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'process_record_handler'
                                    953 ;------------------------------------------------------------
                                    954 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_644'
                                    955 ;record        Allocated with name '_process_record_handler_record_10000_645'
                                    956 ;action        Allocated with name '_process_record_handler_action_10000_645'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function process_record_handler
                                    961 ;	-----------------------------------------
      007358                        962 _process_record_handler:
      007358 12 38 4B         [24]  963 	lcall	_ak820_outline_0104
      00735B 90 08 3F         [24]  964 	mov	dptr,#_process_record_handler_record_argument_10000_644
      00735E 12 38 50         [24]  965 	lcall	_ak820_outline_0105
                                    966 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007361 90 08 3F         [24]  967 	mov	dptr,#_process_record_handler_record_argument_10000_644
      007364 12 37 B8         [24]  968 	lcall	_ak820_outline_0008
                                    969 ;	quantum/action.c:405: if (record->keycode) {
      007367 4C               [12]  970 	orl	a,r4
      007368 60 19            [24]  971 	jz	00102$
                                    972 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00736A 12 38 55         [24]  973 	lcall	_ak820_outline_0117
      00736D C0 07            [24]  974 	push	ar7
      00736F C0 06            [24]  975 	push	ar6
      007371 12 95 DA         [24]  976 	lcall	_action_for_keycode
      007374 12 45 7B         [24]  977 	lcall	_ak820_outline_0144
      007377 D0 06            [24]  978 	pop	ar6
      007379 D0 07            [24]  979 	pop	ar7
      00737B 90 08 41         [24]  980 	mov	dptr,#_process_record_handler_action_10000_645
      00737E 12 38 26         [24]  981 	lcall	_ak820_outline_0070
      007381 80 2B            [24]  982 	sjmp	00104$
      007383                        983 00102$:
                                    984 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007383 12 78 42         [24]  985 	lcall	_ak820_outline_0019
      007386 7A 00            [12]  986 	mov	r2,#0x00
      007388 12 45 70         [24]  987 	lcall	_ak820_outline_0138
      00738B 12 44 FF         [24]  988 	lcall	_ak820_outline_0011
      00738E E0               [24]  989 	movx	a,@dptr
      00738F 90 09 7C         [24]  990 	mov	dptr,#_ak820_resolve_key_PARM_2
      007392 F0               [24]  991 	movx	@dptr,a
      007393 8D 82            [24]  992 	mov	dpl, r5
      007395 8C 83            [24]  993 	mov	dph, r4
      007397 C0 07            [24]  994 	push	ar7
      007399 C0 06            [24]  995 	push	ar6
      00739B 12 7B DF         [24]  996 	lcall	_ak820_resolve_key
      00739E 12 95 DA         [24]  997 	lcall	_action_for_keycode
      0073A1 12 45 7B         [24]  998 	lcall	_ak820_outline_0144
      0073A4 D0 06            [24]  999 	pop	ar6
      0073A6 D0 07            [24] 1000 	pop	ar7
      0073A8 90 08 41         [24] 1001 	mov	dptr,#_process_record_handler_action_10000_645
      0073AB 12 38 26         [24] 1002 	lcall	_ak820_outline_0070
                                   1003 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0073AE                       1004 00104$:
                                   1005 ;	quantum/action.c:429: process_action(record, action);
      0073AE 90 0D 8A         [24] 1006 	mov	dptr,#___memcpy_PARM_2
      0073B1 74 41            [12] 1007 	mov	a,#_process_record_handler_action_10000_645
      0073B3 F0               [24] 1008 	movx	@dptr,a
      0073B4 74 08            [12] 1009 	mov	a,#(_process_record_handler_action_10000_645 >> 8)
      0073B6 12 78 5A         [24] 1010 	lcall	_ak820_outline_0049
      0073B9 12 51 0E         [24] 1011 	lcall	_ak820_outline_0107
      0073BC 90 08 43         [24] 1012 	mov	dptr,#_process_action_PARM_2
      0073BF F5 F0            [12] 1013 	mov	b,a
      0073C1 C0 07            [24] 1014 	push	ar7
      0073C3 C0 06            [24] 1015 	push	ar6
      0073C5 12 B8 6D         [24] 1016 	lcall	___memcpy
      0073C8 D0 06            [24] 1017 	pop	ar6
      0073CA D0 07            [24] 1018 	pop	ar7
      0073CC 12 45 5A         [24] 1019 	lcall	_ak820_outline_0114
                                   1020 ;	quantum/action.c:430: }
      0073CF 02 73 D2         [24] 1021 	ljmp	_process_action
                                   1022 ;------------------------------------------------------------
                                   1023 ;Allocation info for local variables in function 'register_mouse'
                                   1024 ;------------------------------------------------------------
                                   1025 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1026 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_653'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function process_action
                                   1031 ;	-----------------------------------------
      0073D2                       1032 _process_action:
      0073D2 12 38 4B         [24] 1033 	lcall	_ak820_outline_0104
      0073D5 90 08 45         [24] 1034 	mov	dptr,#_process_action_record_argument_10000_656
      0073D8 12 38 50         [24] 1035 	lcall	_ak820_outline_0105
                                   1036 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073DB 90 08 45         [24] 1037 	mov	dptr,#_process_action_record_argument_10000_656
      0073DE 12 37 A1         [24] 1038 	lcall	_ak820_outline_0004
                                   1039 ;	quantum/action.c:501: pressed = record->event.pressed;
      0073E1 A3               [24] 1040 	inc	dptr
      0073E2 A3               [24] 1041 	inc	dptr
      0073E3 A3               [24] 1042 	inc	dptr
      0073E4 A3               [24] 1043 	inc	dptr
      0073E5 A3               [24] 1044 	inc	dptr
      0073E6 E0               [24] 1045 	movx	a,@dptr
      0073E7 F5 18            [12] 1046 	mov	_process_action_sloc0_1_0,a
                                   1047 ;	quantum/action.c:525: switch (action.kind.id) {
      0073E9 90 08 44         [24] 1048 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073EC E0               [24] 1049 	movx	a,@dptr
      0073ED C4               [12] 1050 	swap	a
      0073EE 54 0F            [12] 1051 	anl	a,#0x0f
      0073F0 FD               [12] 1052 	mov  r5,a
      0073F1 24 F4            [12] 1053 	add	a,#0xff - 0x0b
      0073F3 50 03            [24] 1054 	jnc	00434$
      0073F5 02 76 73         [24] 1055 	ljmp	00181$
      0073F8                       1056 00434$:
                                   1057 ;	free result
      0073F8 ED               [12] 1058 	mov	a,r5
      0073F9 24 0A            [12] 1059 	add	a,#(00435$-3-.)
      0073FB 83               [24] 1060 	movc	a,@a+pc
      0073FC F5 82            [12] 1061 	mov	dpl,a
      0073FE ED               [12] 1062 	mov	a,r5
      0073FF 24 10            [12] 1063 	add	a,#(00436$-3-.)
      007401 83               [24] 1064 	movc	a,@a+pc
      007402 F5 83            [12] 1065 	mov	dph,a
      007404 E4               [12] 1066 	clr	a
      007405 73               [24] 1067 	jmp	@a+dptr
      007406                       1068 00435$:
      007406 1E                    1069 	.db	00102$
      007407 1E                    1070 	.db	00102$
      007408 73                    1071 	.db	00181$
      007409 73                    1072 	.db	00181$
      00740A A8                    1073 	.db	00123$
      00740B 73                    1074 	.db	00181$
      00740C 73                    1075 	.db	00181$
      00740D 73                    1076 	.db	00181$
      00740E 08                    1077 	.db	00131$
      00740F DA                    1078 	.db	00147$
      007410 00                    1079 	.db	00152$
      007411 00                    1080 	.db	00152$
      007412                       1081 00436$:
      007412 74                    1082 	.db	00102$>>8
      007413 74                    1083 	.db	00102$>>8
      007414 76                    1084 	.db	00181$>>8
      007415 76                    1085 	.db	00181$>>8
      007416 74                    1086 	.db	00123$>>8
      007417 76                    1087 	.db	00181$>>8
      007418 76                    1088 	.db	00181$>>8
      007419 76                    1089 	.db	00181$>>8
      00741A 75                    1090 	.db	00131$>>8
      00741B 75                    1091 	.db	00147$>>8
      00741C 76                    1092 	.db	00152$>>8
      00741D 76                    1093 	.db	00152$>>8
                                   1094 ;	quantum/action.c:528: case ACT_RMODS: {
      00741E                       1095 00102$:
                                   1096 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00741E 90 08 44         [24] 1097 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007421 E0               [24] 1098 	movx	a,@dptr
      007422 54 F0            [12] 1099 	anl	a,#0xf0
      007424 70 06            [24] 1100 	jnz	00194$
      007426 12 78 81         [24] 1101 	lcall	_ak820_outline_0109
      007429 FD               [12] 1102 	mov	r5,a
      00742A 80 07            [24] 1103 	sjmp	00195$
      00742C                       1104 00194$:
      00742C 12 78 81         [24] 1105 	lcall	_ak820_outline_0109
      00742F C4               [12] 1106 	swap	a
      007430 54 F0            [12] 1107 	anl	a,#0xf0
      007432 FD               [12] 1108 	mov	r5,a
      007433                       1109 00195$:
                                   1110 ;	quantum/action.c:531: if (pressed) {
      007433 E5 18            [12] 1111 	mov	a,_process_action_sloc0_1_0
      007435 60 35            [24] 1112 	jz	00119$
                                   1113 ;	quantum/action.c:532: if (mods) {
      007437 ED               [12] 1114 	mov	a,r5
      007438 60 29            [24] 1115 	jz	00110$
                                   1116 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00743A 12 78 93         [24] 1117 	lcall	_ak820_outline_0153
      00743D FC               [12] 1118 	mov	r4,a
      00743E BC E0 00         [24] 1119 	cjne	r4,#0xe0,00440$
      007441                       1120 00440$:
      007441 40 07            [24] 1121 	jc	00108$
      007443 12 78 93         [24] 1122 	lcall	_ak820_outline_0153
      007446 24 18            [12] 1123 	add	a,#0xff - 0xe7
      007448 50 0A            [24] 1124 	jnc	00104$
                                   1125 ;	free result
      00744A                       1126 00108$:
      00744A 7B 43            [12] 1127 	mov	r3,#_process_action_PARM_2
      00744C 7C 08            [12] 1128 	mov	r4,#(_process_action_PARM_2 >> 8)
      00744E 12 33 FC         [24] 1129 	lcall	_ak820_outline_0121
      007451 E0               [24] 1130 	movx	a,@dptr
      007452 70 07            [24] 1131 	jnz	00105$
      007454                       1132 00104$:
                                   1133 ;	quantum/action.c:537: add_owned_mods(mods);
      007454 8D 82            [24] 1134 	mov	dpl, r5
      007456 12 7D F9         [24] 1135 	lcall	_add_owned_mods
      007459 80 05            [24] 1136 	sjmp	00106$
      00745B                       1137 00105$:
                                   1138 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00745B 8D 82            [24] 1139 	mov	dpl, r5
      00745D 12 7E 18         [24] 1140 	lcall	_add_owned_weak_mods
      007460                       1141 00106$:
                                   1142 ;	quantum/action.c:541: send_keyboard_report();
      007460 12 81 33         [24] 1143 	lcall	_send_keyboard_report
      007463                       1144 00110$:
                                   1145 ;	quantum/action.c:543: register_code(action.key.code);
      007463 12 78 6A         [24] 1146 	lcall	_ak820_outline_0075
      007466 12 76 8A         [24] 1147 	lcall	_register_code
      007469 02 76 73         [24] 1148 	ljmp	00181$
      00746C                       1149 00119$:
                                   1150 ;	quantum/action.c:545: unregister_code(action.key.code);
      00746C 12 78 6A         [24] 1151 	lcall	_ak820_outline_0075
      00746F C0 05            [24] 1152 	push	ar5
      007471 12 76 F7         [24] 1153 	lcall	_unregister_code
      007474 D0 05            [24] 1154 	pop	ar5
                                   1155 ;	quantum/action.c:546: if (mods) {
      007476 ED               [12] 1156 	mov	a,r5
      007477 70 03            [24] 1157 	jnz	00444$
      007479 02 76 73         [24] 1158 	ljmp	00181$
      00747C                       1159 00444$:
                                   1160 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00747C 12 78 93         [24] 1161 	lcall	_ak820_outline_0153
      00747F FC               [12] 1162 	mov	r4,a
      007480 BC E0 00         [24] 1163 	cjne	r4,#0xe0,00445$
      007483                       1164 00445$:
      007483 40 07            [24] 1165 	jc	00115$
      007485 12 78 93         [24] 1166 	lcall	_ak820_outline_0153
      007488 24 18            [12] 1167 	add	a,#0xff - 0xe7
      00748A 50 0A            [24] 1168 	jnc	00111$
                                   1169 ;	free result
      00748C                       1170 00115$:
      00748C 7B 43            [12] 1171 	mov	r3,#_process_action_PARM_2
      00748E 7C 08            [12] 1172 	mov	r4,#(_process_action_PARM_2 >> 8)
      007490 12 33 FC         [24] 1173 	lcall	_ak820_outline_0121
      007493 E0               [24] 1174 	movx	a,@dptr
      007494 70 07            [24] 1175 	jnz	00112$
      007496                       1176 00111$:
                                   1177 ;	quantum/action.c:548: del_owned_mods(mods);
      007496 8D 82            [24] 1178 	mov	dpl, r5
      007498 12 7E 09         [24] 1179 	lcall	_del_owned_mods
      00749B 80 05            [24] 1180 	sjmp	00113$
      00749D                       1181 00112$:
                                   1182 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00749D 8D 82            [24] 1183 	mov	dpl, r5
      00749F 12 7E 28         [24] 1184 	lcall	_del_owned_weak_mods
      0074A2                       1185 00113$:
                                   1186 ;	quantum/action.c:552: send_keyboard_report();
      0074A2 12 81 33         [24] 1187 	lcall	_send_keyboard_report
                                   1188 ;	quantum/action.c:555: } break;
      0074A5 02 76 73         [24] 1189 	ljmp	00181$
                                   1190 ;	quantum/action.c:632: case ACT_USAGE:
      0074A8                       1191 00123$:
                                   1192 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0074A8 74 07            [12] 1193 	mov	a,#0x07
      0074AA 12 37 F9         [24] 1194 	lcall	_ak820_outline_0030
      0074AD 12 37 CC         [24] 1195 	lcall	_ak820_outline_0009
      0074B0 C3               [12] 1196 	clr	c
      0074B1 EC               [12] 1197 	mov	a,r4
      0074B2 94 A5            [12] 1198 	subb	a,#0xa5
      0074B4 ED               [12] 1199 	mov	a,r5
      0074B5 94 00            [12] 1200 	subb	a,#0x00
      0074B7 40 15            [24] 1201 	jc	00125$
      0074B9 74 C2            [12] 1202 	mov	a,#0xc2
      0074BB 9C               [12] 1203 	subb	a,r4
      0074BC E4               [12] 1204 	clr	a
      0074BD 9D               [12] 1205 	subb	a,r5
      0074BE 40 0E            [24] 1206 	jc	00125$
                                   1207 ;	free result
                                   1208 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0074C0 90 0A A3         [24] 1209 	mov	dptr,#_owned_usage_key_PARM_2
      0074C3 E5 18            [12] 1210 	mov	a,_process_action_sloc0_1_0
      0074C5 F0               [24] 1211 	movx	@dptr,a
      0074C6 8E 82            [24] 1212 	mov	dpl, r6
      0074C8 12 7F DE         [24] 1213 	lcall	_owned_usage_key
                                   1214 ;	quantum/action.c:640: break;
      0074CB 02 76 73         [24] 1215 	ljmp	00181$
      0074CE                       1216 00125$:
                                   1217 ;	quantum/action.c:643: switch (action.usage.page) {
      0074CE 12 78 71         [24] 1218 	lcall	_ak820_outline_0085
      0074D1 FF               [12] 1219 	mov	r7,a
      0074D2 60 08            [24] 1220 	jz	00127$
      0074D4 BF 01 02         [24] 1221 	cjne	r7,#0x01,00452$
      0074D7 80 19            [24] 1222 	sjmp	00128$
      0074D9                       1223 00452$:
      0074D9 02 76 73         [24] 1224 	ljmp	00181$
                                   1225 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0074DC                       1226 00127$:
                                   1227 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0074DC E5 18            [12] 1228 	mov	a,_process_action_sloc0_1_0
      0074DE 60 05            [24] 1229 	jz	00196$
      0074E0 12 78 88         [24] 1230 	lcall	_ak820_outline_0128
      0074E3 80 04            [24] 1231 	sjmp	00197$
      0074E5                       1232 00196$:
      0074E5 7E 00            [12] 1233 	mov	r6,#0x00
      0074E7 7F 00            [12] 1234 	mov	r7,#0x00
      0074E9                       1235 00197$:
      0074E9 12 45 5A         [24] 1236 	lcall	_ak820_outline_0114
      0074EC 12 6E C4         [24] 1237 	lcall	_host_system_send
                                   1238 ;	quantum/action.c:646: break;
      0074EF 02 76 73         [24] 1239 	ljmp	00181$
                                   1240 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0074F2                       1241 00128$:
                                   1242 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0074F2 E5 18            [12] 1243 	mov	a,_process_action_sloc0_1_0
      0074F4 60 05            [24] 1244 	jz	00198$
      0074F6 12 78 88         [24] 1245 	lcall	_ak820_outline_0128
      0074F9 80 04            [24] 1246 	sjmp	00199$
      0074FB                       1247 00198$:
      0074FB 7E 00            [12] 1248 	mov	r6,#0x00
      0074FD 7F 00            [12] 1249 	mov	r7,#0x00
      0074FF                       1250 00199$:
      0074FF 12 45 5A         [24] 1251 	lcall	_ak820_outline_0114
      007502 12 6E F4         [24] 1252 	lcall	_host_consumer_send
                                   1253 ;	quantum/action.c:651: break;
      007505 02 76 73         [24] 1254 	ljmp	00181$
                                   1255 ;	quantum/action.c:658: case ACT_LAYER: {
      007508                       1256 00131$:
                                   1257 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007508 90 08 44         [24] 1258 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00750B E0               [24] 1259 	movx	a,@dptr
      00750C 54 03            [12] 1260 	anl	a,#0x03
      00750E 90 08 47         [24] 1261 	mov	dptr,#_process_action_on_40000_679
      007511 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007512 E0               [24] 1264 	movx	a,@dptr
      007513 FF               [12] 1265 	mov	r7,a
      007514 60 11            [24] 1266 	jz	00200$
      007516 E5 18            [12] 1267 	mov	a,_process_action_sloc0_1_0
      007518 60 07            [24] 1268 	jz	00202$
      00751A 8F 06            [24] 1269 	mov	ar6,r7
      00751C 53 06 01         [24] 1270 	anl	ar6,#0x01
      00751F 80 10            [24] 1271 	sjmp	00201$
      007521                       1272 00202$:
      007521 74 02            [12] 1273 	mov	a,#0x02
      007523 5F               [12] 1274 	anl	a,r7
      007524 FE               [12] 1275 	mov	r6,a
      007525 80 0A            [24] 1276 	sjmp	00201$
      007527                       1277 00200$:
      007527 E5 18            [12] 1278 	mov	a,_process_action_sloc0_1_0
      007529 B4 01 00         [24] 1279 	cjne	a,#0x01,00457$
      00752C                       1280 00457$:
      00752C 92 1D            [24] 1281 	mov  _process_action_sloc1_1_0,c
      00752E E4               [12] 1282 	clr	a
      00752F 33               [12] 1283 	rlc	a
      007530 FE               [12] 1284 	mov	r6,a
      007531                       1285 00201$:
      007531 EE               [12] 1286 	mov	a,r6
      007532 70 03            [24] 1287 	jnz	00458$
      007534 02 76 73         [24] 1288 	ljmp	00181$
      007537                       1289 00458$:
                                   1290 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007537 12 78 93         [24] 1291 	lcall	_ak820_outline_0153
      00753A C4               [12] 1292 	swap	a
      00753B 03               [12] 1293 	rr	a
      00753C 54 07            [12] 1294 	anl	a,#0x07
      00753E 25 E0            [12] 1295 	add	a,acc
      007540 25 E0            [12] 1296 	add	a,acc
      007542 FF               [12] 1297 	mov	r7,a
                                   1298 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007543 12 78 93         [24] 1299 	lcall	_ak820_outline_0153
      007546 54 0F            [12] 1300 	anl	a,#0x0f
      007548 FE               [12] 1301 	mov	r6,a
      007549 8F F0            [24] 1302 	mov	b,r7
      00754B 05 F0            [12] 1303 	inc	b
      00754D EE               [12] 1304 	mov	a,r6
      00754E 80 02            [24] 1305 	sjmp	00460$
      007550                       1306 00459$:
      007550 25 E0            [12] 1307 	add	a,acc
      007552                       1308 00460$:
      007552 D5 F0 FB         [24] 1309 	djnz	b,00459$
      007555 FE               [12] 1310 	mov	r6,a
                                   1311 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007556 12 78 93         [24] 1312 	lcall	_ak820_outline_0153
      007559 30 E4 11         [24] 1313 	jnb	acc.4,00204$
      00755C 8F F0            [24] 1314 	mov	b,r7
      00755E 05 F0            [12] 1315 	inc	b
      007560 74 0F            [12] 1316 	mov	a,#0x0f
      007562 80 02            [24] 1317 	sjmp	00463$
      007564                       1318 00462$:
      007564 25 E0            [12] 1319 	add	a,acc
      007566                       1320 00463$:
      007566 D5 F0 FB         [24] 1321 	djnz	b,00462$
      007569 F4               [12] 1322 	cpl	a
      00756A FF               [12] 1323 	mov	r7,a
      00756B 80 02            [24] 1324 	sjmp	00205$
      00756D                       1325 00204$:
      00756D 7F 00            [12] 1326 	mov	r7,#0x00
      00756F                       1327 00205$:
                                   1328 ;	quantum/action.c:666: bits |= mask;
      00756F EE               [12] 1329 	mov	a,r6
      007570 42 07            [12] 1330 	orl	ar7,a
                                   1331 ;	quantum/action.c:667: if (!on) {
      007572 90 08 47         [24] 1332 	mov	dptr,#_process_action_on_40000_679
      007575 E0               [24] 1333 	movx	a,@dptr
      007576 70 31            [24] 1334 	jnz	00143$
                                   1335 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007578 12 78 71         [24] 1336 	lcall	_ak820_outline_0085
      00757B FE               [12] 1337 	mov	r6,a
      00757C 2E               [12] 1338 	add	a,r6
                                   1339 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00757D 90 75 81         [24] 1340 	mov	dptr,#00465$
      007580 73               [24] 1341 	jmp	@a+dptr
      007581                       1342 00465$:
      007581 80 06            [24] 1343 	sjmp	00132$
      007583 80 0C            [24] 1344 	sjmp	00133$
      007585 80 12            [24] 1345 	sjmp	00134$
      007587 80 18            [24] 1346 	sjmp	00135$
      007589                       1347 00132$:
      007589 8F 82            [24] 1348 	mov	dpl, r7
      00758B 12 78 EE         [24] 1349 	lcall	_default_layer_and
      00758E 02 76 73         [24] 1350 	ljmp	00181$
                                   1351 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007591                       1352 00133$:
      007591 8F 82            [24] 1353 	mov	dpl, r7
      007593 12 78 DD         [24] 1354 	lcall	_default_layer_or
      007596 02 76 73         [24] 1355 	ljmp	00181$
                                   1356 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007599                       1357 00134$:
      007599 8F 82            [24] 1358 	mov	dpl, r7
      00759B 12 79 04         [24] 1359 	lcall	_default_layer_xor
      00759E 02 76 73         [24] 1360 	ljmp	00181$
                                   1361 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0075A1                       1362 00135$:
      0075A1 8F 82            [24] 1363 	mov	dpl, r7
      0075A3 12 78 D2         [24] 1364 	lcall	_default_layer_set
                                   1365 ;	quantum/action.c:673: }
      0075A6 02 76 73         [24] 1366 	ljmp	00181$
      0075A9                       1367 00143$:
                                   1368 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      0075A9 12 78 71         [24] 1369 	lcall	_ak820_outline_0085
      0075AC FE               [12] 1370 	mov	r6,a
      0075AD 2E               [12] 1371 	add	a,r6
                                   1372 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0075AE 90 75 B2         [24] 1373 	mov	dptr,#00466$
      0075B1 73               [24] 1374 	jmp	@a+dptr
      0075B2                       1375 00466$:
      0075B2 80 06            [24] 1376 	sjmp	00137$
      0075B4 80 0C            [24] 1377 	sjmp	00138$
      0075B6 80 12            [24] 1378 	sjmp	00139$
      0075B8 80 18            [24] 1379 	sjmp	00140$
      0075BA                       1380 00137$:
      0075BA 8F 82            [24] 1381 	mov	dpl, r7
      0075BC 12 7A 87         [24] 1382 	lcall	_layer_and
      0075BF 02 76 73         [24] 1383 	ljmp	00181$
                                   1384 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0075C2                       1385 00138$:
      0075C2 8F 82            [24] 1386 	mov	dpl, r7
      0075C4 12 7A 76         [24] 1387 	lcall	_layer_or
      0075C7 02 76 73         [24] 1388 	ljmp	00181$
                                   1389 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0075CA                       1390 00139$:
      0075CA 8F 82            [24] 1391 	mov	dpl, r7
      0075CC 12 7A 9D         [24] 1392 	lcall	_layer_xor
      0075CF 02 76 73         [24] 1393 	ljmp	00181$
                                   1394 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0075D2                       1395 00140$:
      0075D2 8F 82            [24] 1396 	mov	dpl, r7
      0075D4 12 7A 13         [24] 1397 	lcall	_layer_state_set
                                   1398 ;	quantum/action.c:683: break;
      0075D7 02 76 73         [24] 1399 	ljmp	00181$
                                   1400 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0075DA                       1401 00147$:
                                   1402 ;	quantum/action.c:686: if (pressed) {
      0075DA E5 18            [12] 1403 	mov	a,_process_action_sloc0_1_0
      0075DC 60 11            [24] 1404 	jz	00149$
                                   1405 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0075DE 12 78 81         [24] 1406 	lcall	_ak820_outline_0109
      0075E1 F5 82            [12] 1407 	mov	dpl,a
      0075E3 12 79 74         [24] 1408 	lcall	_layer_hold_on
                                   1409 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0075E6 12 78 6A         [24] 1410 	lcall	_ak820_outline_0075
      0075E9 12 77 AD         [24] 1411 	lcall	_register_mods
      0075EC 02 76 73         [24] 1412 	ljmp	00181$
      0075EF                       1413 00149$:
                                   1414 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0075EF 12 78 6A         [24] 1415 	lcall	_ak820_outline_0075
      0075F2 12 77 C1         [24] 1416 	lcall	_unregister_mods
                                   1417 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0075F5 12 78 81         [24] 1418 	lcall	_ak820_outline_0109
      0075F8 F5 82            [12] 1419 	mov	dpl,a
      0075FA 12 79 AC         [24] 1420 	lcall	_layer_hold_off
                                   1421 ;	quantum/action.c:693: break;
      0075FD 02 76 73         [24] 1422 	ljmp	00181$
                                   1423 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      007600                       1424 00152$:
                                   1425 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      007600 12 78 93         [24] 1426 	lcall	_ak820_outline_0153
      007603 FF               [12] 1427 	mov	r7,a
      007604 BF F1 02         [24] 1428 	cjne	r7,#0xf1,00468$
      007607 80 0A            [24] 1429 	sjmp	00154$
      007609                       1430 00468$:
      007609 BF F2 02         [24] 1431 	cjne	r7,#0xf2,00469$
      00760C 80 19            [24] 1432 	sjmp	00155$
      00760E                       1433 00469$:
                                   1434 ;	quantum/action.c:712: momentary_layer_action:
      00760E BF F3 3B         [24] 1435 	cjne	r7,#0xf3,00160$
      007611 80 28            [24] 1436 	sjmp	00156$
      007613                       1437 00154$:
                                   1438 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007613 E5 18            [12] 1439 	mov	a,_process_action_sloc0_1_0
      007615 60 08            [24] 1440 	jz	00206$
      007617 12 78 51         [24] 1441 	lcall	_ak820_outline_0038
      00761A 12 79 74         [24] 1442 	lcall	_layer_hold_on
      00761D 80 54            [24] 1443 	sjmp	00181$
      00761F                       1444 00206$:
      00761F 12 78 51         [24] 1445 	lcall	_ak820_outline_0038
      007622 12 79 AC         [24] 1446 	lcall	_layer_hold_off
                                   1447 ;	quantum/action.c:714: break;
                                   1448 ;	quantum/action.c:715: case OP_OFF_ON:
      007625 80 4C            [24] 1449 	sjmp	00181$
      007627                       1450 00155$:
                                   1451 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007627 E5 18            [12] 1452 	mov	a,_process_action_sloc0_1_0
      007629 60 08            [24] 1453 	jz	00208$
      00762B 12 78 51         [24] 1454 	lcall	_ak820_outline_0038
      00762E 12 7A 58         [24] 1455 	lcall	_layer_off
      007631 80 40            [24] 1456 	sjmp	00181$
      007633                       1457 00208$:
      007633 12 78 51         [24] 1458 	lcall	_ak820_outline_0038
      007636 12 7A 3D         [24] 1459 	lcall	_layer_on
                                   1460 ;	quantum/action.c:717: break;
                                   1461 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007639 80 38            [24] 1462 	sjmp	00181$
      00763B                       1463 00156$:
                                   1464 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00763B E5 18            [12] 1465 	mov	a,_process_action_sloc0_1_0
      00763D 60 08            [24] 1466 	jz	00210$
      00763F 12 78 51         [24] 1467 	lcall	_ak820_outline_0038
      007642 12 7A 27         [24] 1468 	lcall	_layer_move
      007645 80 2C            [24] 1469 	sjmp	00181$
      007647                       1470 00210$:
      007647 12 7A 21         [24] 1471 	lcall	_layer_clear
                                   1472 ;	quantum/action.c:720: break;
                                   1473 ;	quantum/action.c:766: default:
      00764A 80 27            [24] 1474 	sjmp	00181$
      00764C                       1475 00160$:
                                   1476 ;	quantum/action.c:773: if (pressed) {
      00764C E5 18            [12] 1477 	mov	a,_process_action_sloc0_1_0
      00764E 60 08            [24] 1478 	jz	00163$
                                   1479 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007650 12 78 6A         [24] 1480 	lcall	_ak820_outline_0075
      007653 12 76 8A         [24] 1481 	lcall	_register_code
                                   1482 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007656 80 1B            [24] 1483 	sjmp	00181$
      007658                       1484 00163$:
                                   1485 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007658 12 78 93         [24] 1486 	lcall	_ak820_outline_0153
      00765B FF               [12] 1487 	mov	r7,a
      00765C BF 39 0E         [24] 1488 	cjne	r7,#0x39,00175$
                                   1489 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00765F 7F 50            [12] 1490 	mov	r7,#0x50
      007661                       1491 00187$:
      007661 EF               [12] 1492 	mov	a,r7
      007662 60 09            [24] 1493 	jz	00175$
      007664 90 00 01         [24] 1494 	mov	dptr,#0x0001
      007667 12 5A 9E         [24] 1495 	lcall	_mDelaymS
      00766A 1F               [12] 1496 	dec	r7
                                   1497 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00766B 80 F4            [24] 1498 	sjmp	00187$
      00766D                       1499 00175$:
                                   1500 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      00766D 12 78 6A         [24] 1501 	lcall	_ak820_outline_0075
      007670 12 76 F7         [24] 1502 	lcall	_unregister_code
                                   1503 ;	quantum/action.c:866: }
      007673                       1504 00181$:
                                   1505 ;	quantum/action.c:887: switch (action.kind.id) {
      007673 90 08 44         [24] 1506 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007676 E0               [24] 1507 	movx	a,@dptr
      007677 C4               [12] 1508 	swap	a
      007678 54 0F            [12] 1509 	anl	a,#0x0f
      00767A FF               [12] 1510 	mov	r7,a
      00767B BF 08 02         [24] 1511 	cjne	r7,#0x08,00478$
      00767E 80 03            [24] 1512 	sjmp	00183$
      007680                       1513 00478$:
      007680 BF 09 06         [24] 1514 	cjne	r7,#0x09,00192$
                                   1515 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007683                       1516 00183$:
                                   1517 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007683 12 6E 29         [24] 1518 	lcall	_host_keyboard_leds
                                   1519 ;	quantum/action.c:898: }
                                   1520 ;	quantum/action.c:951: }
      007686 02 98 8F         [24] 1521 	ljmp	_led_set
      007689                       1522 00192$:
      007689 22               [24] 1523 	ret
                                   1524 ;------------------------------------------------------------
                                   1525 ;Allocation info for local variables in function 'register_code'
                                   1526 ;------------------------------------------------------------
                                   1527 ;code          Allocated with name '_register_code_code_10000_713'
                                   1528 ;------------------------------------------------------------
                                   1529 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1530 ;	-----------------------------------------
                                   1531 ;	 function register_code
                                   1532 ;	-----------------------------------------
      00768A                       1533 _register_code:
      00768A E5 82            [12] 1534 	mov	a,dpl
      00768C 90 08 48         [24] 1535 	mov	dptr,#_register_code_code_10000_713
      00768F F0               [24] 1536 	movx	@dptr,a
                                   1537 ;	quantum/action.c:958: if (code == KC_NO) {
      007690 E0               [24] 1538 	movx	a,@dptr
      007691 FF               [12] 1539 	mov	r7,a
      007692 70 01            [24] 1540 	jnz	00123$
                                   1541 ;	quantum/action.c:959: return;
      007694 22               [24] 1542 	ret
      007695                       1543 00123$:
                                   1544 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007695 BF 04 00         [24] 1545 	cjne	r7,#0x04,00186$
      007698                       1546 00186$:
      007698 40 12            [24] 1547 	jc	00119$
      00769A EF               [12] 1548 	mov	a,r7
      00769B 24 5B            [12] 1549 	add	a,#0xff - 0xa4
      00769D 40 0D            [24] 1550 	jc	00119$
                                   1551 ;	free result
                                   1552 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00769F 8F 82            [24] 1553 	mov	dpl, r7
      0076A1 12 7E 9D         [24] 1554 	lcall	_add_owned_key
      0076A4 E5 82            [12] 1555 	mov	a, dpl
      0076A6 70 01            [24] 1556 	jnz	00104$
      0076A8 22               [24] 1557 	ret
      0076A9                       1558 00104$:
                                   1559 ;	quantum/action.c:1013: send_keyboard_report();
      0076A9 02 81 33         [24] 1560 	ljmp	_send_keyboard_report
      0076AC                       1561 00119$:
                                   1562 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      0076AC 12 78 98         [24] 1563 	lcall	_ak820_outline_0161
      0076AF BF E0 00         [24] 1564 	cjne	r7,#0xe0,00190$
      0076B2                       1565 00190$:
      0076B2 40 1A            [24] 1566 	jc	00115$
      0076B4 EF               [12] 1567 	mov	a,r7
      0076B5 24 18            [12] 1568 	add	a,#0xff - 0xe7
      0076B7 40 15            [24] 1569 	jc	00115$
                                   1570 ;	free result
                                   1571 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0076B9 74 07            [12] 1572 	mov	a,#0x07
      0076BB 5F               [12] 1573 	anl	a,r7
      0076BC 12 78 63         [24] 1574 	lcall	_ak820_outline_0062
      0076BF 80 02            [24] 1575 	sjmp	00194$
      0076C1                       1576 00193$:
      0076C1 25 E0            [12] 1577 	add	a,acc
      0076C3                       1578 00194$:
      0076C3 D5 F0 FB         [24] 1579 	djnz	b,00193$
      0076C6 F5 82            [12] 1580 	mov	dpl,a
      0076C8 12 7D F9         [24] 1581 	lcall	_add_owned_mods
                                   1582 ;	quantum/action.c:1016: send_keyboard_report();
      0076CB 02 81 33         [24] 1583 	ljmp	_send_keyboard_report
      0076CE                       1584 00115$:
                                   1585 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0076CE 12 78 98         [24] 1586 	lcall	_ak820_outline_0161
      0076D1 BF A5 00         [24] 1587 	cjne	r7,#0xa5,00195$
      0076D4                       1588 00195$:
      0076D4 40 05            [24] 1589 	jc	00113$
      0076D6 EF               [12] 1590 	mov	a,r7
      0076D7 24 58            [12] 1591 	add	a,#0xff - 0xa7
      0076D9 50 0D            [24] 1592 	jnc	00108$
                                   1593 ;	free result
      0076DB                       1594 00113$:
      0076DB 12 78 98         [24] 1595 	lcall	_ak820_outline_0161
      0076DE BF A8 00         [24] 1596 	cjne	r7,#0xa8,00198$
      0076E1                       1597 00198$:
      0076E1 40 13            [24] 1598 	jc	00125$
      0076E3 EF               [12] 1599 	mov	a,r7
      0076E4 24 3D            [12] 1600 	add	a,#0xff - 0xc2
      0076E6 40 0E            [24] 1601 	jc	00125$
                                   1602 ;	free result
      0076E8                       1603 00108$:
                                   1604 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0076E8 12 78 98         [24] 1605 	lcall	_ak820_outline_0161
      0076EB 90 0A A3         [24] 1606 	mov	dptr,#_owned_usage_key_PARM_2
      0076EE 74 01            [12] 1607 	mov	a,#0x01
      0076F0 F0               [24] 1608 	movx	@dptr,a
      0076F1 8F 82            [24] 1609 	mov	dpl, r7
                                   1610 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1611 ;	quantum/action.c:1031: }
      0076F3 02 7F DE         [24] 1612 	ljmp	_owned_usage_key
      0076F6                       1613 00125$:
      0076F6 22               [24] 1614 	ret
                                   1615 ;------------------------------------------------------------
                                   1616 ;Allocation info for local variables in function 'unregister_code'
                                   1617 ;------------------------------------------------------------
                                   1618 ;code          Allocated with name '_unregister_code_code_10000_727'
                                   1619 ;------------------------------------------------------------
                                   1620 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1621 ;	-----------------------------------------
                                   1622 ;	 function unregister_code
                                   1623 ;	-----------------------------------------
      0076F7                       1624 _unregister_code:
      0076F7 E5 82            [12] 1625 	mov	a,dpl
      0076F9 90 08 49         [24] 1626 	mov	dptr,#_unregister_code_code_10000_727
      0076FC F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	quantum/action.c:1038: if (code == KC_NO) {
      0076FD E0               [24] 1629 	movx	a,@dptr
      0076FE FF               [12] 1630 	mov	r7,a
      0076FF 70 01            [24] 1631 	jnz	00121$
                                   1632 ;	quantum/action.c:1039: return;
      007701 22               [24] 1633 	ret
      007702                       1634 00121$:
                                   1635 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007702 BF 04 00         [24] 1636 	cjne	r7,#0x04,00184$
      007705                       1637 00184$:
      007705 40 12            [24] 1638 	jc	00117$
      007707 EF               [12] 1639 	mov	a,r7
      007708 24 5B            [12] 1640 	add	a,#0xff - 0xa4
      00770A 40 0D            [24] 1641 	jc	00117$
                                   1642 ;	free result
                                   1643 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      00770C 8F 82            [24] 1644 	mov	dpl, r7
      00770E 12 7F 17         [24] 1645 	lcall	_del_owned_key
      007711 E5 82            [12] 1646 	mov	a, dpl
      007713 70 01            [24] 1647 	jnz	00102$
      007715 22               [24] 1648 	ret
      007716                       1649 00102$:
                                   1650 ;	quantum/action.c:1080: send_keyboard_report();
      007716 02 81 33         [24] 1651 	ljmp	_send_keyboard_report
      007719                       1652 00117$:
                                   1653 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007719 12 78 9E         [24] 1654 	lcall	_ak820_outline_0162
      00771C BF E0 00         [24] 1655 	cjne	r7,#0xe0,00188$
      00771F                       1656 00188$:
      00771F 40 1A            [24] 1657 	jc	00113$
      007721 EF               [12] 1658 	mov	a,r7
      007722 24 18            [12] 1659 	add	a,#0xff - 0xe7
      007724 40 15            [24] 1660 	jc	00113$
                                   1661 ;	free result
                                   1662 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007726 74 07            [12] 1663 	mov	a,#0x07
      007728 5F               [12] 1664 	anl	a,r7
      007729 12 78 63         [24] 1665 	lcall	_ak820_outline_0062
      00772C 80 02            [24] 1666 	sjmp	00192$
      00772E                       1667 00191$:
      00772E 25 E0            [12] 1668 	add	a,acc
      007730                       1669 00192$:
      007730 D5 F0 FB         [24] 1670 	djnz	b,00191$
      007733 F5 82            [12] 1671 	mov	dpl,a
      007735 12 7E 09         [24] 1672 	lcall	_del_owned_mods
                                   1673 ;	quantum/action.c:1083: send_keyboard_report();
      007738 02 81 33         [24] 1674 	ljmp	_send_keyboard_report
      00773B                       1675 00113$:
                                   1676 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00773B 12 78 9E         [24] 1677 	lcall	_ak820_outline_0162
      00773E BF A5 00         [24] 1678 	cjne	r7,#0xa5,00193$
      007741                       1679 00193$:
      007741 40 05            [24] 1680 	jc	00111$
      007743 EF               [12] 1681 	mov	a,r7
      007744 24 58            [12] 1682 	add	a,#0xff - 0xa7
      007746 50 0D            [24] 1683 	jnc	00106$
                                   1684 ;	free result
      007748                       1685 00111$:
      007748 12 78 9E         [24] 1686 	lcall	_ak820_outline_0162
      00774B BF A8 00         [24] 1687 	cjne	r7,#0xa8,00196$
      00774E                       1688 00196$:
      00774E 40 12            [24] 1689 	jc	00123$
      007750 EF               [12] 1690 	mov	a,r7
      007751 24 3D            [12] 1691 	add	a,#0xff - 0xc2
      007753 40 0D            [24] 1692 	jc	00123$
                                   1693 ;	free result
      007755                       1694 00106$:
                                   1695 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007755 12 78 9E         [24] 1696 	lcall	_ak820_outline_0162
      007758 90 0A A3         [24] 1697 	mov	dptr,#_owned_usage_key_PARM_2
      00775B E4               [12] 1698 	clr	a
      00775C F0               [24] 1699 	movx	@dptr,a
      00775D 8F 82            [24] 1700 	mov	dpl, r7
                                   1701 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1702 ;	quantum/action.c:1098: }
      00775F 02 7F DE         [24] 1703 	ljmp	_owned_usage_key
      007762                       1704 00123$:
      007762 22               [24] 1705 	ret
                                   1706 ;------------------------------------------------------------
                                   1707 ;Allocation info for local variables in function 'tap_code_delay'
                                   1708 ;------------------------------------------------------------
                                   1709 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1710 ;code          Allocated with name '_tap_code_delay_code_10000_740'
                                   1711 ;i             Allocated with name '_tap_code_delay_i_20000_742'
                                   1712 ;i             Allocated with name '_tap_code_delay_i_50000_745'
                                   1713 ;------------------------------------------------------------
                                   1714 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1715 ;	-----------------------------------------
                                   1716 ;	 function tap_code_delay
                                   1717 ;	-----------------------------------------
      007763                       1718 _tap_code_delay:
      007763 E5 82            [12] 1719 	mov	a,dpl
      007765 90 08 4C         [24] 1720 	mov	dptr,#_tap_code_delay_code_10000_740
      007768 F0               [24] 1721 	movx	@dptr,a
                                   1722 ;	quantum/action.c:1106: register_code(code);
      007769 E0               [24] 1723 	movx	a,@dptr
      00776A FF               [12] 1724 	mov	r7,a
      00776B F5 82            [12] 1725 	mov	dpl,a
      00776D C0 07            [24] 1726 	push	ar7
      00776F 12 76 8A         [24] 1727 	lcall	_register_code
      007772 D0 07            [24] 1728 	pop	ar7
                                   1729 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007774 90 08 4A         [24] 1730 	mov	dptr,#_tap_code_delay_PARM_2
      007777 12 45 48         [24] 1731 	lcall	_ak820_outline_0093
      00777A                       1732 00110$:
      00777A ED               [12] 1733 	mov	a,r5
      00777B 4E               [12] 1734 	orl	a,r6
      00777C 60 0D            [24] 1735 	jz	00105$
                                   1736 ;	quantum/action.c:1108: wait_ms(1);
      00777E 90 00 01         [24] 1737 	mov	dptr,#0x0001
      007781 12 5A 9E         [24] 1738 	lcall	_mDelaymS
                                   1739 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007784 1D               [12] 1740 	dec	r5
      007785 BD FF 01         [24] 1741 	cjne	r5,#0xff,00141$
      007788 1E               [12] 1742 	dec	r6
      007789                       1743 00141$:
      007789 80 EF            [24] 1744 	sjmp	00110$
      00778B                       1745 00105$:
                                   1746 ;	quantum/action.c:1110: unregister_code(code);
      00778B 8F 82            [24] 1747 	mov	dpl, r7
                                   1748 ;	quantum/action.c:1111: }
      00778D 02 76 F7         [24] 1749 	ljmp	_unregister_code
                                   1750 ;------------------------------------------------------------
                                   1751 ;Allocation info for local variables in function 'tap_code'
                                   1752 ;------------------------------------------------------------
                                   1753 ;code          Allocated with name '_tap_code_code_10000_747'
                                   1754 ;------------------------------------------------------------
                                   1755 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1756 ;	-----------------------------------------
                                   1757 ;	 function tap_code
                                   1758 ;	-----------------------------------------
      007790                       1759 _tap_code:
      007790 E5 82            [12] 1760 	mov	a,dpl
      007792 90 08 4D         [24] 1761 	mov	dptr,#_tap_code_code_10000_747
      007795 F0               [24] 1762 	movx	@dptr,a
                                   1763 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007796 E0               [24] 1764 	movx	a,@dptr
      007797 FF               [12] 1765 	mov	r7,a
      007798 BF 39 04         [24] 1766 	cjne	r7,#0x39,00103$
      00779B 7E 50            [12] 1767 	mov	r6,#0x50
      00779D 80 02            [24] 1768 	sjmp	00104$
      00779F                       1769 00103$:
      00779F 7E 00            [12] 1770 	mov	r6,#0x00
      0077A1                       1771 00104$:
      0077A1 90 08 4A         [24] 1772 	mov	dptr,#_tap_code_delay_PARM_2
      0077A4 EE               [12] 1773 	mov	a,r6
      0077A5 12 38 60         [24] 1774 	lcall	_ak820_outline_0122
      0077A8 8F 82            [24] 1775 	mov	dpl, r7
                                   1776 ;	quantum/action.c:1119: }
      0077AA 02 77 63         [24] 1777 	ljmp	_tap_code_delay
                                   1778 ;------------------------------------------------------------
                                   1779 ;Allocation info for local variables in function 'register_mods'
                                   1780 ;------------------------------------------------------------
                                   1781 ;mods          Allocated with name '_register_mods_mods_10000_749'
                                   1782 ;------------------------------------------------------------
                                   1783 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1784 ;	-----------------------------------------
                                   1785 ;	 function register_mods
                                   1786 ;	-----------------------------------------
      0077AD                       1787 _register_mods:
      0077AD E5 82            [12] 1788 	mov	a,dpl
      0077AF 90 08 4E         [24] 1789 	mov	dptr,#_register_mods_mods_10000_749
      0077B2 F0               [24] 1790 	movx	@dptr,a
                                   1791 ;	quantum/action.c:1126: if (mods) {
      0077B3 E0               [24] 1792 	movx	a,@dptr
      0077B4 FF               [12] 1793 	mov	r7,a
      0077B5 E0               [24] 1794 	movx	a,@dptr
      0077B6 60 08            [24] 1795 	jz	00103$
                                   1796 ;	quantum/action.c:1127: add_owned_mods(mods);
      0077B8 8F 82            [24] 1797 	mov	dpl, r7
      0077BA 12 7D F9         [24] 1798 	lcall	_add_owned_mods
                                   1799 ;	quantum/action.c:1128: send_keyboard_report();
                                   1800 ;	quantum/action.c:1130: }
      0077BD 02 81 33         [24] 1801 	ljmp	_send_keyboard_report
      0077C0                       1802 00103$:
      0077C0 22               [24] 1803 	ret
                                   1804 ;------------------------------------------------------------
                                   1805 ;Allocation info for local variables in function 'unregister_mods'
                                   1806 ;------------------------------------------------------------
                                   1807 ;mods          Allocated with name '_unregister_mods_mods_10000_753'
                                   1808 ;------------------------------------------------------------
                                   1809 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1810 ;	-----------------------------------------
                                   1811 ;	 function unregister_mods
                                   1812 ;	-----------------------------------------
      0077C1                       1813 _unregister_mods:
      0077C1 E5 82            [12] 1814 	mov	a,dpl
      0077C3 90 08 4F         [24] 1815 	mov	dptr,#_unregister_mods_mods_10000_753
      0077C6 F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	quantum/action.c:1137: if (mods) {
      0077C7 E0               [24] 1818 	movx	a,@dptr
      0077C8 FF               [12] 1819 	mov	r7,a
      0077C9 E0               [24] 1820 	movx	a,@dptr
      0077CA 60 08            [24] 1821 	jz	00103$
                                   1822 ;	quantum/action.c:1138: del_owned_mods(mods);
      0077CC 8F 82            [24] 1823 	mov	dpl, r7
      0077CE 12 7E 09         [24] 1824 	lcall	_del_owned_mods
                                   1825 ;	quantum/action.c:1139: send_keyboard_report();
                                   1826 ;	quantum/action.c:1141: }
      0077D1 02 81 33         [24] 1827 	ljmp	_send_keyboard_report
      0077D4                       1828 00103$:
      0077D4 22               [24] 1829 	ret
                                   1830 ;------------------------------------------------------------
                                   1831 ;Allocation info for local variables in function 'register_weak_mods'
                                   1832 ;------------------------------------------------------------
                                   1833 ;mods          Allocated with name '_register_weak_mods_mods_10000_757'
                                   1834 ;------------------------------------------------------------
                                   1835 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1836 ;	-----------------------------------------
                                   1837 ;	 function register_weak_mods
                                   1838 ;	-----------------------------------------
      0077D5                       1839 _register_weak_mods:
      0077D5 E5 82            [12] 1840 	mov	a,dpl
      0077D7 90 08 50         [24] 1841 	mov	dptr,#_register_weak_mods_mods_10000_757
      0077DA F0               [24] 1842 	movx	@dptr,a
                                   1843 ;	quantum/action.c:1148: if (mods) {
      0077DB E0               [24] 1844 	movx	a,@dptr
      0077DC FF               [12] 1845 	mov	r7,a
      0077DD E0               [24] 1846 	movx	a,@dptr
      0077DE 60 08            [24] 1847 	jz	00103$
                                   1848 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0077E0 8F 82            [24] 1849 	mov	dpl, r7
      0077E2 12 7E 18         [24] 1850 	lcall	_add_owned_weak_mods
                                   1851 ;	quantum/action.c:1150: send_keyboard_report();
                                   1852 ;	quantum/action.c:1152: }
      0077E5 02 81 33         [24] 1853 	ljmp	_send_keyboard_report
      0077E8                       1854 00103$:
      0077E8 22               [24] 1855 	ret
                                   1856 ;------------------------------------------------------------
                                   1857 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1858 ;------------------------------------------------------------
                                   1859 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_761'
                                   1860 ;------------------------------------------------------------
                                   1861 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1862 ;	-----------------------------------------
                                   1863 ;	 function unregister_weak_mods
                                   1864 ;	-----------------------------------------
      0077E9                       1865 _unregister_weak_mods:
      0077E9 E5 82            [12] 1866 	mov	a,dpl
      0077EB 90 08 51         [24] 1867 	mov	dptr,#_unregister_weak_mods_mods_10000_761
      0077EE F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	quantum/action.c:1159: if (mods) {
      0077EF E0               [24] 1870 	movx	a,@dptr
      0077F0 FF               [12] 1871 	mov	r7,a
      0077F1 E0               [24] 1872 	movx	a,@dptr
      0077F2 60 08            [24] 1873 	jz	00103$
                                   1874 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      0077F4 8F 82            [24] 1875 	mov	dpl, r7
      0077F6 12 7E 28         [24] 1876 	lcall	_del_owned_weak_mods
                                   1877 ;	quantum/action.c:1161: send_keyboard_report();
                                   1878 ;	quantum/action.c:1163: }
      0077F9 02 81 33         [24] 1879 	ljmp	_send_keyboard_report
      0077FC                       1880 00103$:
      0077FC 22               [24] 1881 	ret
                                   1882 ;------------------------------------------------------------
                                   1883 ;Allocation info for local variables in function 'clear_keyboard'
                                   1884 ;------------------------------------------------------------
                                   1885 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1886 ;	-----------------------------------------
                                   1887 ;	 function clear_keyboard
                                   1888 ;	-----------------------------------------
      0077FD                       1889 _clear_keyboard:
                                   1890 ;	quantum/action.c:1170: clear_mods();
      0077FD 12 81 AE         [24] 1891 	lcall	_clear_mods
                                   1892 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1893 ;	quantum/action.c:1172: }
      007800 02 78 03         [24] 1894 	ljmp	_clear_keyboard_but_mods
                                   1895 ;------------------------------------------------------------
                                   1896 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1897 ;------------------------------------------------------------
                                   1898 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1899 ;	-----------------------------------------
                                   1900 ;	 function clear_keyboard_but_mods
                                   1901 ;	-----------------------------------------
      007803                       1902 _clear_keyboard_but_mods:
                                   1903 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007803 90 0D B0         [24] 1904 	mov	dptr,#_actual_keyboard_report
      007806 12 70 E9         [24] 1905 	lcall	_clear_keys_from_report
                                   1906 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1907 ;	quantum/action.c:1181: }
      007809 02 78 0C         [24] 1908 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1909 ;------------------------------------------------------------
                                   1910 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1911 ;------------------------------------------------------------
                                   1912 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1913 ;	-----------------------------------------
                                   1914 ;	 function clear_keyboard_but_mods_and_keys
                                   1915 ;	-----------------------------------------
      00780C                       1916 _clear_keyboard_but_mods_and_keys:
                                   1917 ;	quantum/action.c:1189: ak820_tapping_cancel();
      00780C 12 48 CC         [24] 1918 	lcall	_ak820_tapping_cancel
                                   1919 ;	quantum/action.c:1197: ak820_leader_cancel();
      00780F 12 3B 48         [24] 1920 	lcall	_ak820_leader_cancel
                                   1921 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007812 12 2E F0         [24] 1922 	lcall	_ak820_oneshot_cancel
                                   1923 ;	quantum/action.c:1209: ak820_combo_cancel();
      007815 12 35 27         [24] 1924 	lcall	_ak820_combo_cancel
                                   1925 ;	quantum/action.c:1212: repeat_key_cancel();
      007818 12 A1 CC         [24] 1926 	lcall	_repeat_key_cancel
                                   1927 ;	quantum/action.c:1214: clear_owned_mods();
      00781B 12 7E 38         [24] 1928 	lcall	_clear_owned_mods
                                   1929 ;	quantum/action.c:1215: clear_owned_keys();
      00781E 12 7E 70         [24] 1930 	lcall	_clear_owned_keys
                                   1931 ;	quantum/action.c:1216: clear_owned_usages();
      007821 12 7F A6         [24] 1932 	lcall	_clear_owned_usages
                                   1933 ;	quantum/action.c:1217: layer_hold_clear();
      007824 12 79 E4         [24] 1934 	lcall	_layer_hold_clear
                                   1935 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007827 12 9D 1D         [24] 1936 	lcall	_clear_macro_tri_layer
                                   1937 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00782A 90 0D B0         [24] 1938 	mov	dptr,#_actual_keyboard_report
      00782D 12 70 E9         [24] 1939 	lcall	_clear_keys_from_report
                                   1940 ;	quantum/action.c:1224: host_system_send(0);
      007830 90 00 00         [24] 1941 	mov	dptr,#0x0000
      007833 12 6E C4         [24] 1942 	lcall	_host_system_send
                                   1943 ;	quantum/action.c:1225: host_consumer_send(0);
      007836 90 00 00         [24] 1944 	mov	dptr,#0x0000
      007839 12 6E F4         [24] 1945 	lcall	_host_consumer_send
                                   1946 ;	quantum/action.c:1227: clear_weak_mods();
      00783C 12 81 E3         [24] 1947 	lcall	_clear_weak_mods
                                   1948 ;	quantum/action.c:1228: send_keyboard_report();
                                   1949 ;	quantum/action.c:1236: }
      00783F 02 81 33         [24] 1950 	ljmp	_send_keyboard_report
                                   1951 ;------------------------------------------------------------
                                   1952 ;Allocation info for local variables in function 'is_tap_record'
                                   1953 ;------------------------------------------------------------
                                   1954 ;record        Allocated with name '_is_tap_record_record_10000_777'
                                   1955 ;action        Allocated with name '_is_tap_record_action_10001_781'
                                   1956 ;------------------------------------------------------------
                                   1957 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1958 ;	-----------------------------------------
                                   1959 	.area CSEG    (CODE)
                                   1960 	.area CONST   (CODE)
                                   1961 	.area XINIT   (CODE)
      00C13E                       1962 __xinit__disable_action_cache:
      00C13E 00                    1963 	.db #0x00	;  0
                                   1964 	.area CABS    (ABS,CODE)
                                   1965 
                                   1966 ; Experimental exact instruction outlining.
                                   1967 	.globl _ak820_outline_0004
                                   1968 	.globl _ak820_outline_0008
                                   1969 	.globl _ak820_outline_0009
                                   1970 	.globl _ak820_outline_0010
                                   1971 	.globl _ak820_outline_0011
                                   1972 	.globl _ak820_outline_0015
                                   1973 	.globl _ak820_outline_0016
                                   1974 	.globl _ak820_outline_0019
                                   1975 	.globl _ak820_outline_0030
                                   1976 	.globl _ak820_outline_0038
                                   1977 	.globl _ak820_outline_0049
                                   1978 	.globl _ak820_outline_0050
                                   1979 	.globl _ak820_outline_0054
                                   1980 	.globl _ak820_outline_0057
                                   1981 	.globl _ak820_outline_0062
                                   1982 	.globl _ak820_outline_0070
                                   1983 	.globl _ak820_outline_0075
                                   1984 	.globl _ak820_outline_0085
                                   1985 	.globl _ak820_outline_0093
                                   1986 	.globl _ak820_outline_0104
                                   1987 	.globl _ak820_outline_0105
                                   1988 	.globl _ak820_outline_0107
                                   1989 	.globl _ak820_outline_0108
                                   1990 	.globl _ak820_outline_0109
                                   1991 	.globl _ak820_outline_0114
                                   1992 	.globl _ak820_outline_0117
                                   1993 	.globl _ak820_outline_0121
                                   1994 	.globl _ak820_outline_0122
                                   1995 	.globl _ak820_outline_0128
                                   1996 	.globl _ak820_outline_0138
                                   1997 	.globl _ak820_outline_0139
                                   1998 	.globl _ak820_outline_0144
                                   1999 	.globl _ak820_outline_0153
                                   2000 	.globl _ak820_outline_0161
                                   2001 	.globl _ak820_outline_0162
                                   2002 	.globl _ak820_outline_0165
                                   2003 
                                   2004 	.area CSEG (CODE)
                                   2005 ; function ak820_outline_0019
      007842                       2006 _ak820_outline_0019:
      007842 8E 82            [24] 2007 	mov	dpl,r6
      007844 8F 83            [24] 2008 	mov	dph,r7
      007846 A3               [24] 2009 	inc	dptr
      007847 E0               [24] 2010 	movx	a,@dptr
      007848 FC               [12] 2011 	mov	r4,a
      007849 7D 00            [12] 2012 	mov	r5,#0x00
      00784B 8E 82            [24] 2013 	mov	dpl,r6
      00784D 8F 83            [24] 2014 	mov	dph,r7
      00784F E0               [24] 2015 	movx	a,@dptr
      007850 22               [24] 2016 	ret
                                   2017 
                                   2018 	.area CSEG (CODE)
                                   2019 ; function ak820_outline_0038
      007851                       2020 _ak820_outline_0038:
      007851 90 08 44         [24] 2021 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007854 E0               [24] 2022 	movx	a,@dptr
      007855 54 1F            [12] 2023 	anl	a,#0x1f
      007857 F5 82            [12] 2024 	mov	dpl,a
      007859 22               [24] 2025 	ret
                                   2026 
                                   2027 	.area CSEG (CODE)
                                   2028 ; function ak820_outline_0049
      00785A                       2029 _ak820_outline_0049:
      00785A A3               [24] 2030 	inc	dptr
      00785B F0               [24] 2031 	movx	@dptr,a
      00785C E4               [12] 2032 	clr	a
      00785D A3               [24] 2033 	inc	dptr
      00785E F0               [24] 2034 	movx	@dptr,a
      00785F 90 0D 8D         [24] 2035 	mov	dptr,#___memcpy_PARM_3
      007862 22               [24] 2036 	ret
                                   2037 
                                   2038 	.area CSEG (CODE)
                                   2039 ; function ak820_outline_0062
      007863                       2040 _ak820_outline_0062:
      007863 F5 F0            [12] 2041 	mov	b,a
      007865 05 F0            [12] 2042 	inc	b
      007867 74 01            [12] 2043 	mov	a,#0x01
      007869 22               [24] 2044 	ret
                                   2045 
                                   2046 	.area CSEG (CODE)
                                   2047 ; function ak820_outline_0075
      00786A                       2048 _ak820_outline_0075:
      00786A 90 08 43         [24] 2049 	mov	dptr,#_process_action_PARM_2
      00786D E0               [24] 2050 	movx	a,@dptr
      00786E F5 82            [12] 2051 	mov	dpl,a
      007870 22               [24] 2052 	ret
                                   2053 
                                   2054 	.area CSEG (CODE)
                                   2055 ; function ak820_outline_0085
      007871                       2056 _ak820_outline_0085:
      007871 90 08 44         [24] 2057 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007874 E0               [24] 2058 	movx	a,@dptr
      007875 03               [12] 2059 	rr	a
      007876 03               [12] 2060 	rr	a
      007877 54 03            [12] 2061 	anl	a,#0x03
      007879 22               [24] 2062 	ret
                                   2063 
                                   2064 	.area CSEG (CODE)
                                   2065 ; function ak820_outline_0108
      00787A                       2066 _ak820_outline_0108:
      00787A 74 06            [12] 2067 	mov	a,#0x06
      00787C F0               [24] 2068 	movx	@dptr,a
      00787D E4               [12] 2069 	clr	a
      00787E A3               [24] 2070 	inc	dptr
      00787F F0               [24] 2071 	movx	@dptr,a
      007880 22               [24] 2072 	ret
                                   2073 
                                   2074 	.area CSEG (CODE)
                                   2075 ; function ak820_outline_0109
      007881                       2076 _ak820_outline_0109:
      007881 90 08 44         [24] 2077 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007884 E0               [24] 2078 	movx	a,@dptr
      007885 54 0F            [12] 2079 	anl	a,#0x0f
      007887 22               [24] 2080 	ret
                                   2081 
                                   2082 	.area CSEG (CODE)
                                   2083 ; function ak820_outline_0128
      007888                       2084 _ak820_outline_0128:
      007888 90 08 43         [24] 2085 	mov	dptr,#_process_action_PARM_2
      00788B E0               [24] 2086 	movx	a,@dptr
      00788C FE               [12] 2087 	mov	r6,a
      00788D A3               [24] 2088 	inc	dptr
      00788E E0               [24] 2089 	movx	a,@dptr
      00788F 54 03            [12] 2090 	anl	a,#0x03
      007891 FF               [12] 2091 	mov	r7,a
      007892 22               [24] 2092 	ret
                                   2093 
                                   2094 	.area CSEG (CODE)
                                   2095 ; function ak820_outline_0153
      007893                       2096 _ak820_outline_0153:
      007893 90 08 43         [24] 2097 	mov	dptr,#_process_action_PARM_2
      007896 E0               [24] 2098 	movx	a,@dptr
      007897 22               [24] 2099 	ret
                                   2100 
                                   2101 	.area CSEG (CODE)
                                   2102 ; function ak820_outline_0161
      007898                       2103 _ak820_outline_0161:
      007898 90 08 48         [24] 2104 	mov	dptr,#_register_code_code_10000_713
      00789B E0               [24] 2105 	movx	a,@dptr
      00789C FF               [12] 2106 	mov	r7,a
      00789D 22               [24] 2107 	ret
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0162
      00789E                       2111 _ak820_outline_0162:
      00789E 90 08 49         [24] 2112 	mov	dptr,#_unregister_code_code_10000_727
      0078A1 E0               [24] 2113 	movx	a,@dptr
      0078A2 FF               [12] 2114 	mov	r7,a
      0078A3 22               [24] 2115 	ret
