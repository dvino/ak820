                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _register_code16
                                    282 	.globl _unregister_code16
                                    283 	.globl _reset_keyboard
                                    284 	.globl _soft_reset_keyboard
                                    285 	.globl _get_record_keycode
                                    286 	.globl _pre_process_record_quantum
                                    287 	.globl _process_record_quantum
                                    288 	.globl _process_record_quantum_helper
                                    289 	.globl _shutdown_user
                                    290 ;--------------------------------------------------------
                                    291 ; special function registers
                                    292 ;--------------------------------------------------------
                                    293 	.area RSEG    (ABS,DATA)
      000000                        294 	.org 0x0000
                           0000D0   295 _PSW	=	0x00d0
                           0000E0   296 _ACC	=	0x00e0
                           0000F0   297 _B	=	0x00f0
                           0000FD   298 _A_INV	=	0x00fd
                           000081   299 _SP	=	0x0081
                           000082   300 _DPL	=	0x0082
                           000083   301 _DPH	=	0x0083
                           0000A1   302 _SAFE_MOD	=	0x00a1
                           0000B1   303 _GLOBAL_CFG	=	0x00b1
                           000087   304 _PCON	=	0x0087
                           0000BA   305 _POWER_CFG	=	0x00ba
                           0000B9   306 _CLOCK_CFG	=	0x00b9
                           0000A9   307 _WAKE_CTRL	=	0x00a9
                           0000FE   308 _RESET_KEEP	=	0x00fe
                           0000FF   309 _WDOG_COUNT	=	0x00ff
                           0000A8   310 _IE	=	0x00a8
                           0000B8   311 _IP	=	0x00b8
                           0000E8   312 _IE_EX	=	0x00e8
                           0000E9   313 _IP_EX	=	0x00e9
                           0000B2   314 _GPIO_IE	=	0x00b2
                           008584   315 _ROM_ADDR	=	0x8584
                           000084   316 _ROM_ADDR_L	=	0x0084
                           000085   317 _ROM_ADDR_H	=	0x0085
                           008F8E   318 _ROM_DATA_HI	=	0x8f8e
                           00008E   319 _ROM_DATA_HL	=	0x008e
                           00008F   320 _ROM_DATA_HH	=	0x008f
                           000086   321 _ROM_CTRL	=	0x0086
                           000080   322 _P0	=	0x0080
                           0000C4   323 _P0_MOD_OC	=	0x00c4
                           0000C5   324 _P0_DIR_PU	=	0x00c5
                           000090   325 _P1	=	0x0090
                           000092   326 _P1_MOD_OC	=	0x0092
                           000093   327 _P1_DIR_PU	=	0x0093
                           0000A0   328 _P2	=	0x00a0
                           000094   329 _P2_MOD_OC	=	0x0094
                           000095   330 _P2_DIR_PU	=	0x0095
                           0000B0   331 _P3	=	0x00b0
                           000096   332 _P3_MOD_OC	=	0x0096
                           000097   333 _P3_DIR_PU	=	0x0097
                           0000C0   334 _P4	=	0x00c0
                           0000C2   335 _P4_MOD_OC	=	0x00c2
                           0000C3   336 _P4_DIR_PU	=	0x00c3
                           0000C1   337 _P4_LED_KEY	=	0x00c1
                           0000AA   338 _P5_IN	=	0x00aa
                           0000AB   339 _P5_OUT_PU	=	0x00ab
                           0000AC   340 _P5_DIR	=	0x00ac
                           0000AD   341 _P6_IN	=	0x00ad
                           0000AE   342 _P6_OUT_PU	=	0x00ae
                           0000AF   343 _P6_DIR	=	0x00af
                           0000F1   344 _P7	=	0x00f1
                           0000A2   345 _XBUS_AUX	=	0x00a2
                           000088   346 _TCON	=	0x0088
                           000089   347 _TMOD	=	0x0089
                           00008A   348 _TL0	=	0x008a
                           00008B   349 _TL1	=	0x008b
                           00008C   350 _TH0	=	0x008c
                           00008D   351 _TH1	=	0x008d
                           000098   352 _SCON	=	0x0098
                           000099   353 _SBUF	=	0x0099
                           0000C8   354 _T2CON	=	0x00c8
                           0000C9   355 _T2MOD	=	0x00c9
                           00CBCA   356 _RCAP2	=	0xcbca
                           0000CA   357 _RCAP2L	=	0x00ca
                           0000CB   358 _RCAP2H	=	0x00cb
                           00CDCC   359 _T2COUNT	=	0xcdcc
                           0000CC   360 _TL2	=	0x00cc
                           0000CD   361 _TH2	=	0x00cd
                           00CFCE   362 _T2CAP1	=	0xcfce
                           0000CE   363 _T2CAP1L	=	0x00ce
                           0000CF   364 _T2CAP1H	=	0x00cf
                           0000F8   365 _SPI0_STAT	=	0x00f8
                           0000F9   366 _SPI0_DATA	=	0x00f9
                           0000FA   367 _SPI0_CTRL	=	0x00fa
                           0000FB   368 _SPI0_CK_SE	=	0x00fb
                           0000FC   369 _SPI0_SETUP	=	0x00fc
                           0000BC   370 _SCON1	=	0x00bc
                           0000BD   371 _SBUF1	=	0x00bd
                           0000BE   372 _SBAUD1	=	0x00be
                           0000BF   373 _SIF1	=	0x00bf
                           0000B4   374 _SPI1_STAT	=	0x00b4
                           0000B5   375 _SPI1_DATA	=	0x00b5
                           0000B6   376 _SPI1_CTRL	=	0x00b6
                           0000B7   377 _SPI1_CK_SE	=	0x00b7
                           0000F3   378 _ADC_CTRL	=	0x00f3
                           00F5F4   379 _ADC_DAT	=	0xf5f4
                           0000F4   380 _ADC_DAT_L	=	0x00f4
                           0000F5   381 _ADC_DAT_H	=	0x00f5
                           0000F6   382 _ADC_CHAN	=	0x00f6
                           0000A6   383 _LED_COMMON	=	0x00a6
                           0000A7   384 _LED_PWM_OE	=	0x00a7
                           00C7C6   385 _LED_DMA	=	0xc7c6
                           0000C6   386 _LED_DMA_L	=	0x00c6
                           0000C7   387 _LED_DMA_H	=	0x00c7
                           0000F7   388 _LED_STATUS	=	0x00f7
                           0000B3   389 _I2CX_INT	=	0x00b3
                           0000BB   390 _I2CS_INT_ST	=	0x00bb
                                    391 ;--------------------------------------------------------
                                    392 ; special function bits
                                    393 ;--------------------------------------------------------
                                    394 	.area RSEG    (ABS,DATA)
      000000                        395 	.org 0x0000
                           0000D7   396 _CY	=	0x00d7
                           0000D6   397 _AC	=	0x00d6
                           0000D5   398 _F0	=	0x00d5
                           0000D4   399 _RS1	=	0x00d4
                           0000D3   400 _RS0	=	0x00d3
                           0000D2   401 _OV	=	0x00d2
                           0000D1   402 _F1	=	0x00d1
                           0000D0   403 _P	=	0x00d0
                           0000AF   404 _EA	=	0x00af
                           0000AE   405 _E_DIS	=	0x00ae
                           0000AD   406 _ET2	=	0x00ad
                           0000AC   407 _ES	=	0x00ac
                           0000AB   408 _ET1	=	0x00ab
                           0000AA   409 _EX1	=	0x00aa
                           0000A9   410 _ET0	=	0x00a9
                           0000A8   411 _EX0	=	0x00a8
                           0000BF   412 _PH_FLAG	=	0x00bf
                           0000BE   413 _PL_FLAG	=	0x00be
                           0000BD   414 _PT2	=	0x00bd
                           0000BC   415 _PS	=	0x00bc
                           0000BB   416 _PT1	=	0x00bb
                           0000BA   417 _PX1	=	0x00ba
                           0000B9   418 _PT0	=	0x00b9
                           0000B8   419 _PX0	=	0x00b8
                           0000EF   420 _IE_WDOG	=	0x00ef
                           0000EE   421 _IE_GPIO	=	0x00ee
                           0000ED   422 _IE_PWM_I2C	=	0x00ed
                           0000EC   423 _IE_UART1	=	0x00ec
                           0000EB   424 _IE_ADC	=	0x00eb
                           0000E9   425 _IE_USB	=	0x00e9
                           0000E8   426 _IE_SPI0	=	0x00e8
                           000087   427 _P0_7	=	0x0087
                           000086   428 _P0_6	=	0x0086
                           000085   429 _P0_5	=	0x0085
                           000084   430 _P0_4	=	0x0084
                           000083   431 _P0_3	=	0x0083
                           000082   432 _P0_2	=	0x0082
                           000081   433 _P0_1	=	0x0081
                           000080   434 _P0_0	=	0x0080
                           000081   435 _SDA0	=	0x0081
                           000080   436 _SCL0	=	0x0080
                           000083   437 _TXD_	=	0x0083
                           000082   438 _RXD_	=	0x0082
                           000085   439 _AIN13	=	0x0085
                           000084   440 _AIN12	=	0x0084
                           000083   441 _AIN11	=	0x0083
                           000082   442 _AIN10	=	0x0082
                           000081   443 _AIN9	=	0x0081
                           000080   444 _AIN8	=	0x0080
                           000097   445 _P1_7	=	0x0097
                           000096   446 _P1_6	=	0x0096
                           000095   447 _P1_5	=	0x0095
                           000094   448 _P1_4	=	0x0094
                           000093   449 _P1_3	=	0x0093
                           000092   450 _P1_2	=	0x0092
                           000091   451 _P1_1	=	0x0091
                           000090   452 _P1_0	=	0x0090
                           000097   453 _TXD1_	=	0x0097
                           000096   454 _RXD1_	=	0x0096
                           000097   455 _SCK	=	0x0097
                           000096   456 _MISO	=	0x0096
                           000095   457 _MOSI	=	0x0095
                           000094   458 _SCS	=	0x0094
                           000092   459 _INT0_	=	0x0092
                           000091   460 _T2EX	=	0x0091
                           000091   461 _CAP2	=	0x0091
                           000090   462 _T2	=	0x0090
                           000090   463 _CAP1	=	0x0090
                           000097   464 _AIN7	=	0x0097
                           000096   465 _AIN6	=	0x0096
                           000095   466 _AIN5	=	0x0095
                           000094   467 _AIN4	=	0x0094
                           000093   468 _AIN3	=	0x0093
                           000092   469 _AIN2	=	0x0092
                           000091   470 _AIN1	=	0x0091
                           000090   471 _AIN0	=	0x0090
                           0000A7   472 _P2_7	=	0x00a7
                           0000A6   473 _P2_6	=	0x00a6
                           0000A5   474 _P2_5	=	0x00a5
                           0000A4   475 _P2_4	=	0x00a4
                           0000A3   476 _P2_3	=	0x00a3
                           0000A2   477 _P2_2	=	0x00a2
                           0000A1   478 _P2_1	=	0x00a1
                           0000A0   479 _P2_0	=	0x00a0
                           0000A7   480 _TXD1	=	0x00a7
                           0000A6   481 _RXD1	=	0x00a6
                           0000A5   482 _T2EX_	=	0x00a5
                           0000A5   483 _CAP2_	=	0x00a5
                           0000A4   484 _T2_	=	0x00a4
                           0000A4   485 _CAP1_	=	0x00a4
                           0000B7   486 _P3_7	=	0x00b7
                           0000B6   487 _P3_6	=	0x00b6
                           0000B5   488 _P3_5	=	0x00b5
                           0000B4   489 _P3_4	=	0x00b4
                           0000B3   490 _P3_3	=	0x00b3
                           0000B2   491 _P3_2	=	0x00b2
                           0000B1   492 _P3_1	=	0x00b1
                           0000B0   493 _P3_0	=	0x00b0
                           0000B7   494 _SCK1	=	0x00b7
                           0000B6   495 _MISO1	=	0x00b6
                           0000B5   496 _MOSI1	=	0x00b5
                           0000B5   497 _T1	=	0x00b5
                           0000B4   498 _T0	=	0x00b4
                           0000B3   499 _INT1	=	0x00b3
                           0000B2   500 _INT0	=	0x00b2
                           0000B1   501 _TXD	=	0x00b1
                           0000B0   502 _RXD	=	0x00b0
                           0000C6   503 _P4_6	=	0x00c6
                           0000C5   504 _P4_5	=	0x00c5
                           0000C4   505 _P4_4	=	0x00c4
                           0000C3   506 _P4_3	=	0x00c3
                           0000C2   507 _P4_2	=	0x00c2
                           0000C1   508 _P4_1	=	0x00c1
                           0000C0   509 _P4_0	=	0x00c0
                           00008F   510 _TF1	=	0x008f
                           00008E   511 _TR1	=	0x008e
                           00008D   512 _TF0	=	0x008d
                           00008C   513 _TR0	=	0x008c
                           00008B   514 _IE1	=	0x008b
                           00008A   515 _IT1	=	0x008a
                           000089   516 _IE0	=	0x0089
                           000088   517 _IT0	=	0x0088
                           00009F   518 _SM0	=	0x009f
                           00009E   519 _SM1	=	0x009e
                           00009D   520 _SM2	=	0x009d
                           00009C   521 _REN	=	0x009c
                           00009B   522 _TB8	=	0x009b
                           00009A   523 _RB8	=	0x009a
                           000099   524 _TI	=	0x0099
                           000098   525 _RI	=	0x0098
                           0000CF   526 _TF2	=	0x00cf
                           0000CF   527 _CAP1F	=	0x00cf
                           0000CE   528 _EXF2	=	0x00ce
                           0000CD   529 _RCLK	=	0x00cd
                           0000CC   530 _TCLK	=	0x00cc
                           0000CB   531 _EXEN2	=	0x00cb
                           0000CA   532 _TR2	=	0x00ca
                           0000C9   533 _C_T2	=	0x00c9
                           0000C8   534 _CP_RL2	=	0x00c8
                           0000FF   535 _S0_FST_ACT	=	0x00ff
                           0000FE   536 _S0_IF_OV	=	0x00fe
                           0000FD   537 _S0_IF_FIRST	=	0x00fd
                           0000FC   538 _S0_IF_BYTE	=	0x00fc
                           0000FB   539 _S0_FREE	=	0x00fb
                           0000FA   540 _S0_T_FIFO	=	0x00fa
                           0000F8   541 _S0_R_FIFO	=	0x00f8
                           0000F7   542 _ADC_START	=	0x00f7
                                    543 ;--------------------------------------------------------
                                    544 ; overlayable register banks
                                    545 ;--------------------------------------------------------
                                    546 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        547 	.ds 8
                                    548 ;--------------------------------------------------------
                                    549 ; internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area DSEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000023                        568 _get_record_keycode_sloc0_1_0:
      000023                        569 	.ds 1
      000024                        570 _pre_process_record_quantum_sloc0_1_0:
      000024                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000BC9                        580 _extract_mod_bits_code_10000_599:
      000BC9                        581 	.ds 2
      000BCB                        582 _register_code16_code_10000_605:
      000BCB                        583 	.ds 2
      000BCD                        584 _unregister_code16_code_10000_610:
      000BCD                        585 	.ds 2
      000BCF                        586 _get_record_keycode_PARM_2:
      000BCF                        587 	.ds 1
      000BD0                        588 _get_record_keycode_record_argument_10000_648:
      000BD0                        589 	.ds 2
      000BD2                        590 _pre_process_record_quantum_record_argument_10000_654:
      000BD2                        591 	.ds 2
      000BD4                        592 _process_record_quantum_record_10000_658:
      000BD4                        593 	.ds 2
      000BD6                        594 _process_record_quantum_helper_PARM_2:
      000BD6                        595 	.ds 2
      000BD8                        596 _process_record_quantum_helper_keycode_10000_660:
      000BD8                        597 	.ds 2
      000BDA                        598 _get_u8_str_last_num_10000_686:
      000BDA                        599 	.ds 1
      000BDB                        600 _get_u16_str_last_num_10000_690:
      000BDB                        601 	.ds 2
                                    602 ;--------------------------------------------------------
                                    603 ; absolute external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XABS    (ABS,XDATA)
                                    606 ;--------------------------------------------------------
                                    607 ; initialized external ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area XISEG   (XDATA)
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;------------------------------------------------------------
                                    628 ;Allocation info for local variables in function 'get_u8_str'
                                    629 ;------------------------------------------------------------
                                    630 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    631 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_685'
                                    632 ;buf           Allocated with name '_get_u8_str_buf_10000_686'
                                    633 ;last_num      Allocated with name '_get_u8_str_last_num_10000_686'
                                    634 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_686'
                                    635 ;------------------------------------------------------------
                                    636 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0B DA         [24]  637 	mov	dptr,#_get_u8_str_last_num_10000_686
      0030F6 74 FF            [12]  638 	mov	a,#0xff
      0030F8 F0               [24]  639 	movx	@dptr,a
                                    640 ;------------------------------------------------------------
                                    641 ;Allocation info for local variables in function 'get_u16_str'
                                    642 ;------------------------------------------------------------
                                    643 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    644 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_689'
                                    645 ;buf           Allocated with name '_get_u16_str_buf_10000_690'
                                    646 ;last_num      Allocated with name '_get_u16_str_last_num_10000_690'
                                    647 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_690'
                                    648 ;------------------------------------------------------------
                                    649 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0B DB         [24]  650 	mov	dptr,#_get_u16_str_last_num_10000_690
      0030FC 74 FF            [12]  651 	mov	a,#0xff
      0030FE F0               [24]  652 	movx	@dptr,a
      0030FF E4               [12]  653 	clr	a
      003100 A3               [24]  654 	inc	dptr
      003101 F0               [24]  655 	movx	@dptr,a
                                    656 ;--------------------------------------------------------
                                    657 ; Home
                                    658 ;--------------------------------------------------------
                                    659 	.area HOME    (CODE)
                                    660 	.area HOME    (CODE)
                                    661 ;--------------------------------------------------------
                                    662 ; code
                                    663 ;--------------------------------------------------------
                                    664 	.area CSEG    (CODE)
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    667 ;------------------------------------------------------------
                                    668 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    669 ;------------------------------------------------------------
                                    670 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    671 ;	-----------------------------------------
                           000007   672 	ar7 = 0x07
                           000006   673 	ar6 = 0x06
                           000005   674 	ar5 = 0x05
                           000004   675 	ar4 = 0x04
                           000003   676 	ar3 = 0x03
                           000002   677 	ar2 = 0x02
                           000001   678 	ar1 = 0x01
                           000000   679 	ar0 = 0x00
                                    680 ;	 function extract_mod_bits
                                    681 ;	-----------------------------------------
      009B67                        682 _extract_mod_bits:
      009B67 12 38 47         [24]  683 	lcall	_ak820_outline_0103
      009B6A 90 0B C9         [24]  684 	mov	dptr,#_extract_mod_bits_code_10000_599
      009B6D 12 38 42         [24]  685 	lcall	_ak820_outline_0102
                                    686 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      009B70 90 0B C9         [24]  687 	mov	dptr,#_extract_mod_bits_code_10000_599
      009B73 E0               [24]  688 	movx	a,@dptr
      009B74 A3               [24]  689 	inc	dptr
      009B75 E0               [24]  690 	movx	a,@dptr
                                    691 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009B76 FF               [12]  692 	mov	r7,a
      009B77 60 05            [24]  693 	jz	00101$
      009B79 EF               [12]  694 	mov	a,r7
      009B7A 24 E0            [12]  695 	add	a,#0xff - 0x1f
      009B7C 50 04            [24]  696 	jnc	00102$
                                    697 ;	free result
      009B7E                        698 00101$:
      009B7E 75 82 00         [24]  699 	mov	dpl, #0x00
      009B81 22               [24]  700 	ret
      009B82                        701 00102$:
                                    702 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009B82 EF               [12]  703 	mov	a,r7
      009B83 30 E4 07         [24]  704 	jnb	acc.4,00106$
      009B86 EF               [12]  705 	mov	a,r7
      009B87 C4               [12]  706 	swap	a
      009B88 54 F0            [12]  707 	anl	a,#0xf0
      009B8A FE               [12]  708 	mov	r6,a
      009B8B 80 02            [24]  709 	sjmp	00107$
      009B8D                        710 00106$:
      009B8D 8F 06            [24]  711 	mov	ar6,r7
      009B8F                        712 00107$:
      009B8F 8E 82            [24]  713 	mov	dpl, r6
                                    714 ;	quantum/quantum.c:143: }
      009B91 22               [24]  715 	ret
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'do_code16'
                                    718 ;------------------------------------------------------------
                                    719 ;f             Allocated with name '_do_code16_PARM_2'
                                    720 ;code          Allocated with name '_do_code16_code_10000_602'
                                    721 ;------------------------------------------------------------
                                    722 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    723 ;	-----------------------------------------
                                    724 ;	 function register_code16
                                    725 ;	-----------------------------------------
      009B92                        726 _register_code16:
      009B92 12 38 47         [24]  727 	lcall	_ak820_outline_0103
      009B95 90 0B CB         [24]  728 	mov	dptr,#_register_code16_code_10000_605
      009B98 12 38 42         [24]  729 	lcall	_ak820_outline_0102
                                    730 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      009B9B 90 0B CB         [24]  731 	mov	dptr,#_register_code16_code_10000_605
      009B9E 12 37 A2         [24]  732 	lcall	_ak820_outline_0004
      009BA1 C0 07            [24]  733 	push	ar7
      009BA3 C0 06            [24]  734 	push	ar6
      009BA5 12 9B 67         [24]  735 	lcall	_extract_mod_bits
      009BA8 AD 82            [24]  736 	mov	r5, dpl
      009BAA D0 06            [24]  737 	pop	ar6
      009BAC D0 07            [24]  738 	pop	ar7
                                    739 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009BAE 12 99 A8         [24]  740 	lcall	_ak820_outline_0114
      009BB1 40 07            [24]  741 	jc	00105$
      009BB3 74 E7            [12]  742 	mov	a,#0xe7
      009BB5 9E               [12]  743 	subb	a,r6
      009BB6 E4               [12]  744 	clr	a
      009BB7 9F               [12]  745 	subb	a,r7
      009BB8 50 08            [24]  746 	jnc	00101$
                                    747 ;	free result
      009BBA                        748 00105$:
      009BBA 90 0B CB         [24]  749 	mov	dptr,#_register_code16_code_10000_605
      009BBD 12 6C 7A         [24]  750 	lcall	_ak820_outline_0034
      009BC0 70 07            [24]  751 	jnz	00102$
      009BC2                        752 00101$:
                                    753 ;	quantum/quantum.c:153: register_mods(mods);
      009BC2 8D 82            [24]  754 	mov	dpl, r5
      009BC4 12 74 E4         [24]  755 	lcall	_register_mods
      009BC7 80 05            [24]  756 	sjmp	00103$
      009BC9                        757 00102$:
                                    758 ;	quantum/quantum.c:155: register_weak_mods(mods);
      009BC9 8D 82            [24]  759 	mov	dpl, r5
      009BCB 12 75 0C         [24]  760 	lcall	_register_weak_mods
      009BCE                        761 00103$:
                                    762 ;	quantum/quantum.c:157: register_code(code);
      009BCE 90 0B CB         [24]  763 	mov	dptr,#_register_code16_code_10000_605
      009BD1 E0               [24]  764 	movx	a,@dptr
      009BD2 F5 82            [12]  765 	mov	dpl,a
                                    766 ;	quantum/quantum.c:167: }
      009BD4 02 73 C1         [24]  767 	ljmp	_register_code
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'unregister_code16'
                                    770 ;------------------------------------------------------------
                                    771 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    772 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    773 ;------------------------------------------------------------
                                    774 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function unregister_code16
                                    777 ;	-----------------------------------------
      009BD7                        778 _unregister_code16:
      009BD7 12 38 47         [24]  779 	lcall	_ak820_outline_0103
      009BDA 90 0B CD         [24]  780 	mov	dptr,#_unregister_code16_code_10000_610
      009BDD 12 38 42         [24]  781 	lcall	_ak820_outline_0102
                                    782 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      009BE0 90 0B CD         [24]  783 	mov	dptr,#_unregister_code16_code_10000_610
      009BE3 12 37 A2         [24]  784 	lcall	_ak820_outline_0004
      009BE6 C0 07            [24]  785 	push	ar7
      009BE8 C0 06            [24]  786 	push	ar6
      009BEA 12 9B 67         [24]  787 	lcall	_extract_mod_bits
      009BED AD 82            [24]  788 	mov	r5, dpl
      009BEF D0 06            [24]  789 	pop	ar6
                                    790 ;	quantum/quantum.c:172: unregister_code(code);
      009BF1 8E 04            [24]  791 	mov	ar4,r6
      009BF3 8C 82            [24]  792 	mov	dpl, r4
      009BF5 C0 06            [24]  793 	push	ar6
      009BF7 C0 05            [24]  794 	push	ar5
      009BF9 12 74 2E         [24]  795 	lcall	_unregister_code
      009BFC D0 05            [24]  796 	pop	ar5
      009BFE D0 06            [24]  797 	pop	ar6
      009C00 D0 07            [24]  798 	pop	ar7
                                    799 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009C02 12 99 A8         [24]  800 	lcall	_ak820_outline_0114
      009C05 40 07            [24]  801 	jc	00105$
      009C07 74 E7            [12]  802 	mov	a,#0xe7
      009C09 9E               [12]  803 	subb	a,r6
      009C0A E4               [12]  804 	clr	a
      009C0B 9F               [12]  805 	subb	a,r7
      009C0C 50 08            [24]  806 	jnc	00101$
                                    807 ;	free result
      009C0E                        808 00105$:
      009C0E 90 0B CD         [24]  809 	mov	dptr,#_unregister_code16_code_10000_610
      009C11 12 6C 7A         [24]  810 	lcall	_ak820_outline_0034
      009C14 70 05            [24]  811 	jnz	00102$
      009C16                        812 00101$:
                                    813 ;	quantum/quantum.c:174: unregister_mods(mods);
      009C16 8D 82            [24]  814 	mov	dpl, r5
      009C18 02 74 F8         [24]  815 	ljmp	_unregister_mods
      009C1B                        816 00102$:
                                    817 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      009C1B 8D 82            [24]  818 	mov	dpl, r5
                                    819 ;	quantum/quantum.c:187: }
      009C1D 02 75 20         [24]  820 	ljmp	_unregister_weak_mods
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'tap_code16_delay'
                                    823 ;------------------------------------------------------------
                                    824 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    825 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    826 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    827 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    828 ;------------------------------------------------------------
                                    829 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    830 ;	-----------------------------------------
                                    831 ;	 function shutdown_quantum
                                    832 ;	-----------------------------------------
      009C20                        833 _shutdown_quantum:
                                    834 ;	quantum/quantum.c:237: clear_keyboard();
      009C20 12 75 34         [24]  835 	lcall	_clear_keyboard
                                    836 ;	quantum/quantum.c:252: shutdown_user();
      009C23 12 9E 1E         [24]  837 	lcall	_shutdown_user
                                    838 ;	quantum/quantum.c:253: wait_ms(250);
      009C26 7F FA            [12]  839 	mov	r7,#0xfa
      009C28                        840 00106$:
      009C28 EF               [12]  841 	mov	a,r7
      009C29 60 09            [24]  842 	jz	00108$
      009C2B 90 00 01         [24]  843 	mov	dptr,#0x0001
      009C2E 12 57 E6         [24]  844 	lcall	_mDelaymS
      009C31 1F               [12]  845 	dec	r7
      009C32 80 F4            [24]  846 	sjmp	00106$
      009C34                        847 00108$:
                                    848 ;	quantum/quantum.c:258: }
      009C34 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'reset_keyboard'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function reset_keyboard
                                    856 ;	-----------------------------------------
      009C35                        857 _reset_keyboard:
                                    858 ;	quantum/quantum.c:261: shutdown_quantum();
      009C35 12 9C 20         [24]  859 	lcall	_shutdown_quantum
                                    860 ;	quantum/quantum.c:262: bootloader_jump();
                                    861 ;	quantum/quantum.c:263: }
      009C38 02 34 0E         [24]  862 	ljmp	_bootloader_jump
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    865 ;------------------------------------------------------------
                                    866 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    867 ;	-----------------------------------------
                                    868 ;	 function soft_reset_keyboard
                                    869 ;	-----------------------------------------
      009C3B                        870 _soft_reset_keyboard:
                                    871 ;	quantum/quantum.c:266: shutdown_quantum();
      009C3B 12 9C 20         [24]  872 	lcall	_shutdown_quantum
                                    873 ;	quantum/quantum.c:267: mcu_reset();
                                    874 ;	quantum/quantum.c:268: }
      009C3E 02 34 01         [24]  875 	ljmp	_mcu_reset
                                    876 ;------------------------------------------------------------
                                    877 ;Allocation info for local variables in function 'get_record_keycode'
                                    878 ;------------------------------------------------------------
                                    879 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    880 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                    881 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                    882 ;------------------------------------------------------------
                                    883 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    884 ;	-----------------------------------------
                                    885 ;	 function get_record_keycode
                                    886 ;	-----------------------------------------
      009C41                        887 _get_record_keycode:
      009C41 12 38 47         [24]  888 	lcall	_ak820_outline_0103
      009C44 90 0B D0         [24]  889 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009C47 12 38 42         [24]  890 	lcall	_ak820_outline_0102
                                    891 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C4A 90 0B D0         [24]  892 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009C4D 12 37 AC         [24]  893 	lcall	_ak820_outline_0006
                                    894 ;	quantum/quantum.c:278: if (record->keycode) {
      009C50 4C               [12]  895 	orl	a,r4
      009C51 60 04            [24]  896 	jz	00102$
                                    897 ;	quantum/quantum.c:279: return record->keycode;
      009C53 12 38 53         [24]  898 	lcall	_ak820_outline_0117
      009C56 22               [24]  899 	ret
      009C57                        900 00102$:
                                    901 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009C57 12 75 76         [24]  902 	lcall	_ak820_outline_0018
      009C5A 7A 00            [12]  903 	mov	r2,#0x00
      009C5C 12 43 2F         [24]  904 	lcall	_ak820_outline_0138
      009C5F 12 37 CA         [24]  905 	lcall	_ak820_outline_0008
      009C62 60 06            [24]  906 	jz	00105$
      009C64 90 0B CF         [24]  907 	mov	dptr,#_get_record_keycode_PARM_2
      009C67 E0               [24]  908 	movx	a,@dptr
      009C68 70 04            [24]  909 	jnz	00106$
      009C6A                        910 00105$:
                                    911 ;	assignBit
      009C6A C2 23            [12]  912 	clr	_get_record_keycode_sloc0_1_0
      009C6C 80 02            [24]  913 	sjmp	00107$
      009C6E                        914 00106$:
                                    915 ;	assignBit
      009C6E D2 23            [12]  916 	setb	_get_record_keycode_sloc0_1_0
      009C70                        917 00107$:
      009C70 90 09 5F         [24]  918 	mov	dptr,#_ak820_resolve_key_PARM_2
      009C73 A2 23            [12]  919 	mov	c,_get_record_keycode_sloc0_1_0
      009C75 E4               [12]  920 	clr	a
      009C76 33               [12]  921 	rlc	a
      009C77 F0               [24]  922 	movx	@dptr,a
      009C78 8D 82            [24]  923 	mov	dpl, r5
      009C7A 8C 83            [24]  924 	mov	dph, r4
                                    925 ;	quantum/quantum.c:287: }
      009C7C 02 79 13         [24]  926 	ljmp	_ak820_resolve_key
                                    927 ;------------------------------------------------------------
                                    928 ;Allocation info for local variables in function 'get_event_keycode'
                                    929 ;------------------------------------------------------------
                                    930 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    931 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                    932 ;------------------------------------------------------------
                                    933 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    934 ;	-----------------------------------------
                                    935 ;	 function pre_process_record_quantum
                                    936 ;	-----------------------------------------
      009C7F                        937 _pre_process_record_quantum:
      009C7F 12 38 47         [24]  938 	lcall	_ak820_outline_0103
      009C82 90 0B D2         [24]  939 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C85 12 38 42         [24]  940 	lcall	_ak820_outline_0102
                                    941 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C88 90 0B D2         [24]  942 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C8B 12 37 F9         [24]  943 	lcall	_ak820_outline_0049
                                    944 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      009C8E 90 0B CF         [24]  945 	mov	dptr,#_get_record_keycode_PARM_2
      009C91 74 01            [12]  946 	mov	a,#0x01
      009C93 12 42 F4         [24]  947 	lcall	_ak820_outline_0058
      009C96 C0 07            [24]  948 	push	ar7
      009C98 C0 06            [24]  949 	push	ar6
      009C9A 12 9C 41         [24]  950 	lcall	_get_record_keycode
      009C9D 12 43 3A         [24]  951 	lcall	_ak820_outline_0143
      009CA0 D0 06            [24]  952 	pop	ar6
      009CA2 D0 07            [24]  953 	pop	ar7
                                    954 ;	quantum/quantum.c:334: record->keycode = keycode;
      009CA4 74 07            [12]  955 	mov	a,#0x07
      009CA6 12 37 E9         [24]  956 	lcall	_ak820_outline_0019
      009CA9 EC               [12]  957 	mov	a,r4
      009CAA F0               [24]  958 	movx	@dptr,a
      009CAB ED               [12]  959 	mov	a,r5
      009CAC A3               [24]  960 	inc	dptr
      009CAD 12 42 F4         [24]  961 	lcall	_ak820_outline_0058
                                    962 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009CB0 12 35 F0         [24]  963 	lcall	_ak820_combo_process
      009CB3 E5 82            [12]  964 	mov	a, dpl
      009CB5 70 04            [24]  965 	jnz	00104$
                                    966 ;	quantum/quantum.c:366: true;
                                    967 ;	assignBit
      009CB7 C2 24            [12]  968 	clr	_pre_process_record_quantum_sloc0_1_0
      009CB9 80 02            [24]  969 	sjmp	00105$
      009CBB                        970 00104$:
                                    971 ;	assignBit
      009CBB D2 24            [12]  972 	setb	_pre_process_record_quantum_sloc0_1_0
      009CBD                        973 00105$:
      009CBD A2 24            [12]  974 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009CBF 12 38 79         [24]  975 	lcall	_ak820_outline_0165
                                    976 ;	quantum/quantum.c:367: }
      009CC2 22               [24]  977 	ret
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    980 ;------------------------------------------------------------
                                    981 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                    982 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                    983 ;------------------------------------------------------------
                                    984 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    985 ;	-----------------------------------------
                                    986 ;	 function process_record_quantum
                                    987 ;	-----------------------------------------
      009CC3                        988 _process_record_quantum:
      009CC3 12 38 47         [24]  989 	lcall	_ak820_outline_0103
      009CC6 90 0B D4         [24]  990 	mov	dptr,#_process_record_quantum_record_10000_658
      009CC9 12 38 42         [24]  991 	lcall	_ak820_outline_0102
                                    992 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      009CCC 90 0B D4         [24]  993 	mov	dptr,#_process_record_quantum_record_10000_658
      009CCF 12 37 F9         [24]  994 	lcall	_ak820_outline_0049
      009CD2 90 0B CF         [24]  995 	mov	dptr,#_get_record_keycode_PARM_2
      009CD5 E4               [12]  996 	clr	a
      009CD6 12 42 F4         [24]  997 	lcall	_ak820_outline_0058
      009CD9 12 9C 41         [24]  998 	lcall	_get_record_keycode
      009CDC 12 43 24         [24]  999 	lcall	_ak820_outline_0129
                                   1000 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      009CDF 90 0B D4         [24] 1001 	mov	dptr,#_process_record_quantum_record_10000_658
      009CE2 12 38 18         [24] 1002 	lcall	_ak820_outline_0057
      009CE5 90 0B D6         [24] 1003 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009CE8 EC               [12] 1004 	mov	a,r4
      009CE9 F0               [24] 1005 	movx	@dptr,a
      009CEA ED               [12] 1006 	mov	a,r5
      009CEB A3               [24] 1007 	inc	dptr
      009CEC 12 42 F4         [24] 1008 	lcall	_ak820_outline_0058
                                   1009 ;	quantum/quantum.c:382: }
      009CEF 02 9C F2         [24] 1010 	ljmp	_process_record_quantum_helper
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1013 ;------------------------------------------------------------
                                   1014 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1015 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_660'
                                   1016 ;record        Allocated with name '_process_record_quantum_helper_record_10000_661'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function process_record_quantum_helper
                                   1021 ;	-----------------------------------------
      009CF2                       1022 _process_record_quantum_helper:
      009CF2 12 38 47         [24] 1023 	lcall	_ak820_outline_0103
      009CF5 90 0B D8         [24] 1024 	mov	dptr,#_process_record_quantum_helper_keycode_10000_660
      009CF8 12 38 42         [24] 1025 	lcall	_ak820_outline_0102
                                   1026 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009CFB 90 0B D6         [24] 1027 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009CFE 12 37 F9         [24] 1028 	lcall	_ak820_outline_0049
                                   1029 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      009D01 90 0B D8         [24] 1030 	mov	dptr,#_process_record_quantum_helper_keycode_10000_660
      009D04 12 38 18         [24] 1031 	lcall	_ak820_outline_0057
      009D07 90 0B B4         [24] 1032 	mov	dptr,#_process_last_key_PARM_2
      009D0A 12 47 BF         [24] 1033 	lcall	_ak820_outline_0056
      009D0D 12 38 53         [24] 1034 	lcall	_ak820_outline_0117
      009D10 C0 07            [24] 1035 	push	ar7
      009D12 C0 06            [24] 1036 	push	ar6
      009D14 C0 05            [24] 1037 	push	ar5
      009D16 C0 04            [24] 1038 	push	ar4
      009D18 12 98 E8         [24] 1039 	lcall	_process_last_key
      009D1B E5 82            [12] 1040 	mov	a, dpl
      009D1D D0 04            [24] 1041 	pop	ar4
      009D1F D0 05            [24] 1042 	pop	ar5
      009D21 D0 06            [24] 1043 	pop	ar6
      009D23 D0 07            [24] 1044 	pop	ar7
      009D25 70 03            [24] 1045 	jnz	00188$
      009D27 02 9D E1         [24] 1046 	ljmp	00101$
      009D2A                       1047 00188$:
      009D2A 90 0B B9         [24] 1048 	mov	dptr,#_process_repeat_key_PARM_2
      009D2D 12 47 BF         [24] 1049 	lcall	_ak820_outline_0056
      009D30 12 38 53         [24] 1050 	lcall	_ak820_outline_0117
      009D33 C0 07            [24] 1051 	push	ar7
      009D35 C0 06            [24] 1052 	push	ar6
      009D37 C0 05            [24] 1053 	push	ar5
      009D39 C0 04            [24] 1054 	push	ar4
      009D3B 12 99 61         [24] 1055 	lcall	_process_repeat_key
      009D3E E5 82            [12] 1056 	mov	a, dpl
      009D40 D0 04            [24] 1057 	pop	ar4
      009D42 D0 05            [24] 1058 	pop	ar5
      009D44 D0 06            [24] 1059 	pop	ar6
      009D46 D0 07            [24] 1060 	pop	ar7
      009D48 70 03            [24] 1061 	jnz	00189$
      009D4A 02 9D E1         [24] 1062 	ljmp	00101$
      009D4D                       1063 00189$:
                                   1064 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      009D4D 90 0C 11         [24] 1065 	mov	dptr,#_process_record_via_PARM_2
      009D50 12 9E 1F         [24] 1066 	lcall	_ak820_outline_0009
      009D53 C0 07            [24] 1067 	push	ar7
      009D55 C0 06            [24] 1068 	push	ar6
      009D57 C0 05            [24] 1069 	push	ar5
      009D59 C0 04            [24] 1070 	push	ar4
      009D5B 12 A3 0E         [24] 1071 	lcall	_process_record_via
      009D5E E5 82            [12] 1072 	mov	a, dpl
      009D60 D0 04            [24] 1073 	pop	ar4
      009D62 D0 05            [24] 1074 	pop	ar5
      009D64 D0 06            [24] 1075 	pop	ar6
      009D66 D0 07            [24] 1076 	pop	ar7
      009D68 70 03            [24] 1077 	jnz	00190$
      009D6A 02 9D E1         [24] 1078 	ljmp	00101$
      009D6D                       1079 00190$:
                                   1080 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      009D6D 90 0B 9D         [24] 1081 	mov	dptr,#_process_caps_word_PARM_2
      009D70 12 9E 1F         [24] 1082 	lcall	_ak820_outline_0009
      009D73 C0 07            [24] 1083 	push	ar7
      009D75 C0 06            [24] 1084 	push	ar6
      009D77 C0 05            [24] 1085 	push	ar5
      009D79 C0 04            [24] 1086 	push	ar4
      009D7B 12 96 87         [24] 1087 	lcall	_process_caps_word
      009D7E E5 82            [12] 1088 	mov	a, dpl
      009D80 D0 04            [24] 1089 	pop	ar4
      009D82 D0 05            [24] 1090 	pop	ar5
      009D84 D0 06            [24] 1091 	pop	ar6
      009D86 D0 07            [24] 1092 	pop	ar7
      009D88 60 57            [24] 1093 	jz	00101$
                                   1094 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      009D8A 90 0B A2         [24] 1095 	mov	dptr,#_process_grave_esc_PARM_2
      009D8D 12 9E 1F         [24] 1096 	lcall	_ak820_outline_0009
      009D90 C0 07            [24] 1097 	push	ar7
      009D92 C0 06            [24] 1098 	push	ar6
      009D94 C0 05            [24] 1099 	push	ar5
      009D96 C0 04            [24] 1100 	push	ar4
      009D98 12 97 9A         [24] 1101 	lcall	_process_grave_esc
      009D9B E5 82            [12] 1102 	mov	a, dpl
      009D9D D0 04            [24] 1103 	pop	ar4
      009D9F D0 05            [24] 1104 	pop	ar5
      009DA1 D0 06            [24] 1105 	pop	ar6
      009DA3 D0 07            [24] 1106 	pop	ar7
      009DA5 60 3A            [24] 1107 	jz	00101$
                                   1108 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      009DA7 90 0B BD         [24] 1109 	mov	dptr,#_process_rgb_PARM_2
      009DAA 12 9E 1F         [24] 1110 	lcall	_ak820_outline_0009
      009DAD C0 07            [24] 1111 	push	ar7
      009DAF C0 06            [24] 1112 	push	ar6
      009DB1 C0 05            [24] 1113 	push	ar5
      009DB3 C0 04            [24] 1114 	push	ar4
      009DB5 12 99 B0         [24] 1115 	lcall	_process_rgb
      009DB8 E5 82            [12] 1116 	mov	a, dpl
      009DBA D0 04            [24] 1117 	pop	ar4
      009DBC D0 05            [24] 1118 	pop	ar5
      009DBE D0 06            [24] 1119 	pop	ar6
      009DC0 D0 07            [24] 1120 	pop	ar7
      009DC2 60 1D            [24] 1121 	jz	00101$
                                   1122 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      009DC4 90 0B C3         [24] 1123 	mov	dptr,#_process_tri_layer_PARM_2
      009DC7 12 9E 1F         [24] 1124 	lcall	_ak820_outline_0009
      009DCA C0 07            [24] 1125 	push	ar7
      009DCC C0 06            [24] 1126 	push	ar6
      009DCE C0 05            [24] 1127 	push	ar5
      009DD0 C0 04            [24] 1128 	push	ar4
      009DD2 12 9A 61         [24] 1129 	lcall	_process_tri_layer
      009DD5 E5 82            [12] 1130 	mov	a, dpl
      009DD7 D0 04            [24] 1131 	pop	ar4
      009DD9 D0 05            [24] 1132 	pop	ar5
      009DDB D0 06            [24] 1133 	pop	ar6
      009DDD D0 07            [24] 1134 	pop	ar7
      009DDF 70 04            [24] 1135 	jnz	00102$
                                   1136 ;	quantum/quantum.c:561: true)) {
      009DE1                       1137 00101$:
                                   1138 ;	quantum/quantum.c:562: return false;
      009DE1 75 82 00         [24] 1139 	mov	dpl, #0x00
      009DE4 22               [24] 1140 	ret
      009DE5                       1141 00102$:
                                   1142 ;	quantum/quantum.c:565: if (record->event.pressed) {
      009DE5 12 37 CA         [24] 1143 	lcall	_ak820_outline_0008
      009DE8 60 30            [24] 1144 	jz	00115$
                                   1145 ;	quantum/quantum.c:566: switch (keycode) {
      009DEA BC 00 05         [24] 1146 	cjne	r4,#0x00,00196$
      009DED BD 7C 02         [24] 1147 	cjne	r5,#0x7c,00196$
      009DF0 80 10            [24] 1148 	sjmp	00110$
      009DF2                       1149 00196$:
      009DF2 BC 01 05         [24] 1150 	cjne	r4,#0x01,00197$
      009DF5 BD 7C 02         [24] 1151 	cjne	r5,#0x7c,00197$
      009DF8 80 0F            [24] 1152 	sjmp	00111$
      009DFA                       1153 00197$:
                                   1154 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      009DFA BC 03 1D         [24] 1155 	cjne	r4,#0x03,00115$
      009DFD BD 7C 1A         [24] 1156 	cjne	r5,#0x7c,00115$
      009E00 80 0E            [24] 1157 	sjmp	00112$
      009E02                       1158 00110$:
                                   1159 ;	quantum/quantum.c:569: reset_keyboard();
      009E02 12 9C 35         [24] 1160 	lcall	_reset_keyboard
                                   1161 ;	quantum/quantum.c:570: return false;
      009E05 75 82 00         [24] 1162 	mov	dpl, #0x00
                                   1163 ;	quantum/quantum.c:571: case QK_REBOOT:
      009E08 22               [24] 1164 	ret
      009E09                       1165 00111$:
                                   1166 ;	quantum/quantum.c:572: soft_reset_keyboard();
      009E09 12 9C 3B         [24] 1167 	lcall	_soft_reset_keyboard
                                   1168 ;	quantum/quantum.c:573: return false;
      009E0C 75 82 00         [24] 1169 	mov	dpl, #0x00
                                   1170 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      009E0F 22               [24] 1171 	ret
      009E10                       1172 00112$:
                                   1173 ;	quantum/quantum.c:592: eeconfig_disable();
      009E10 12 8D F2         [24] 1174 	lcall	_eeconfig_disable
                                   1175 ;	quantum/quantum.c:593: soft_reset_keyboard();
      009E13 12 9C 3B         [24] 1176 	lcall	_soft_reset_keyboard
                                   1177 ;	quantum/quantum.c:595: return false;
      009E16 75 82 00         [24] 1178 	mov	dpl, #0x00
                                   1179 ;	quantum/quantum.c:650: }
      009E19 22               [24] 1180 	ret
      009E1A                       1181 00115$:
                                   1182 ;	quantum/quantum.c:654: return true;
      009E1A 75 82 01         [24] 1183 	mov	dpl, #0x01
                                   1184 ;	quantum/quantum.c:658: }
      009E1D 22               [24] 1185 	ret
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1188 ;------------------------------------------------------------
                                   1189 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_668'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function shutdown_user
                                   1194 ;	-----------------------------------------
      009E1E                       1195 _shutdown_user:
      009E1E 22               [24] 1196 	ret
                                   1197 ;------------------------------------------------------------
                                   1198 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1199 ;------------------------------------------------------------
                                   1200 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1201 ;	-----------------------------------------
                                   1202 	.area CSEG    (CODE)
                                   1203 	.area CONST   (CODE)
                                   1204 	.area XINIT   (CODE)
                                   1205 	.area CABS    (ABS,CODE)
                                   1206 
                                   1207 ; Experimental exact instruction outlining.
                                   1208 	.globl _ak820_outline_0004
                                   1209 	.globl _ak820_outline_0006
                                   1210 	.globl _ak820_outline_0008
                                   1211 	.globl _ak820_outline_0009
                                   1212 	.globl _ak820_outline_0018
                                   1213 	.globl _ak820_outline_0019
                                   1214 	.globl _ak820_outline_0034
                                   1215 	.globl _ak820_outline_0049
                                   1216 	.globl _ak820_outline_0056
                                   1217 	.globl _ak820_outline_0057
                                   1218 	.globl _ak820_outline_0058
                                   1219 	.globl _ak820_outline_0102
                                   1220 	.globl _ak820_outline_0103
                                   1221 	.globl _ak820_outline_0114
                                   1222 	.globl _ak820_outline_0117
                                   1223 	.globl _ak820_outline_0129
                                   1224 	.globl _ak820_outline_0138
                                   1225 	.globl _ak820_outline_0143
                                   1226 	.globl _ak820_outline_0165
                                   1227 
                                   1228 	.area CSEG (CODE)
                                   1229 ; function ak820_outline_0009
      009E1F                       1230 _ak820_outline_0009:
      009E1F EE               [12] 1231 	mov	a,r6
      009E20 F0               [24] 1232 	movx	@dptr,a
      009E21 EF               [12] 1233 	mov	a,r7
      009E22 A3               [24] 1234 	inc	dptr
      009E23 F0               [24] 1235 	movx	@dptr,a
      009E24 E4               [12] 1236 	clr	a
      009E25 A3               [24] 1237 	inc	dptr
      009E26 F0               [24] 1238 	movx	@dptr,a
      009E27 8C 82            [24] 1239 	mov	dpl,r4
      009E29 8D 83            [24] 1240 	mov	dph,r5
      009E2B 22               [24] 1241 	ret
