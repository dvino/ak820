                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000030                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000030                        588 	.ds 2
      000032                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      000032                        590 	.ds 1
      000033                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      000033                        592 	.ds 1
      000034                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      000034                        594 	.ds 2
      000036                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      000036                        596 	.ds 2
      000038                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000038                        598 	.ds 1
      000039                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000039                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000022                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000022                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000ACB                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000ACB                        628 	.ds 1
      000ACC                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000ACC                        630 	.ds 1
      000ACD                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000ACD                        632 	.ds 1
      000ACE                        633 _dynamic_keymap_get_keycode_PARM_2:
      000ACE                        634 	.ds 1
      000ACF                        635 _dynamic_keymap_get_keycode_PARM_3:
      000ACF                        636 	.ds 1
      000AD0                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000AD0                        638 	.ds 1
      000AD1                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AD1                        640 	.ds 1
      000AD2                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AD2                        642 	.ds 1
      000AD3                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AD3                        644 	.ds 2
      000AD5                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000AD5                        646 	.ds 1
      000AD6                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AD6                        648 	.ds 1
      000AD7                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000AD7                        650 	.ds 1
      000AD8                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AD8                        652 	.ds 1
      000AD9                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AD9                        654 	.ds 1
      000ADA                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000ADA                        656 	.ds 1
      000ADB                        657 _dynamic_keymap_set_encoder_PARM_2:
      000ADB                        658 	.ds 1
      000ADC                        659 _dynamic_keymap_set_encoder_PARM_3:
      000ADC                        660 	.ds 1
      000ADD                        661 _dynamic_keymap_set_encoder_PARM_4:
      000ADD                        662 	.ds 2
      000ADF                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000ADF                        664 	.ds 1
      000AE0                        665 _dynamic_keymap_get_combo_PARM_2:
      000AE0                        666 	.ds 3
      000AE3                        667 _dynamic_keymap_get_combo_index_10000_384:
      000AE3                        668 	.ds 1
      000AE4                        669 _dynamic_keymap_set_combo_PARM_2:
      000AE4                        670 	.ds 3
      000AE7                        671 _dynamic_keymap_set_combo_index_10000_390:
      000AE7                        672 	.ds 1
      000AE8                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000AE8                        674 	.ds 10
      000AF2                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000AF2                        676 	.ds 1
      000AF3                        677 _dynamic_keymap_reset_combo_10001_407:
      000AF3                        678 	.ds 10
      000AFD                        679 _ak820_dynamic_read_buffer_PARM_2:
      000AFD                        680 	.ds 2
      000AFF                        681 _ak820_dynamic_read_buffer_PARM_3:
      000AFF                        682 	.ds 2
      000B01                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B01                        684 	.ds 2
      000B03                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B03                        686 	.ds 3
      000B06                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B06                        688 	.ds 2
      000B08                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B08                        690 	.ds 1
      000B09                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B09                        692 	.ds 2
      000B0B                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B0B                        694 	.ds 3
      000B0E                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B0E                        696 	.ds 2
      000B10                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B10                        698 	.ds 2
      000B12                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B12                        700 	.ds 3
      000B15                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B15                        702 	.ds 2
      000B17                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B17                        704 	.ds 1
      000B18                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B18                        706 	.ds 1
      000B19                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B19                        708 	.ds 1
      000B1A                        709 _keycode_at_keymap_location_PARM_2:
      000B1A                        710 	.ds 1
      000B1B                        711 _keycode_at_keymap_location_PARM_3:
      000B1B                        712 	.ds 1
      000B1C                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B1C                        714 	.ds 1
      000B1D                        715 _keycode_at_encodermap_location_PARM_2:
      000B1D                        716 	.ds 1
      000B1E                        717 _keycode_at_encodermap_location_PARM_3:
      000B1E                        718 	.ds 1
      000B1F                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B1F                        720 	.ds 1
      000B20                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B20                        722 	.ds 2
      000B22                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B22                        724 	.ds 3
      000B25                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B25                        726 	.ds 2
      000B27                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B27                        728 	.ds 2
      000B29                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B29                        730 	.ds 3
      000B2C                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B2C                        732 	.ds 2
      000B2E                        733 _decode_keycode_kc_10000_454:
      000B2E                        734 	.ds 2
      000B30                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B30                        736 	.ds 1
      000B31                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B31                        738 	.ds 1
      000B32                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B32                        740 	.ds 2
      000B34                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B34                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      00820C                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00820C 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      00820F 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008210                        810 _dynamic_keymap_key_to_eeprom_address:
      008210 E5 82            [12]  811 	mov	a,dpl
      008212 90 0A CD         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      008215 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008216 E0               [24]  815 	movx	a,@dptr
      008217 FF               [12]  816 	mov	r7,a
      008218 7E 00            [12]  817 	mov	r6,#0x00
      00821A 74 40            [12]  818 	mov	a,#0x40
      00821C 12 43 29         [24]  819 	lcall	_ak820_outline_0132
      00821F 7D 00            [12]  820 	mov	r5,#0x00
      008221 90 0A CB         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008224 E0               [24]  822 	movx	a,@dptr
      008225 75 F0 10         [24]  823 	mov	b,#0x10
      008228 A4               [48]  824 	mul	ab
      008229 2E               [12]  825 	add	a, r6
      00822A FE               [12]  826 	mov	r6,a
      00822B EF               [12]  827 	mov	a,r7
      00822C 35 F0            [12]  828 	addc	a, b
      00822E FF               [12]  829 	mov	r7,a
      00822F 90 0A CC         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008232 E0               [24]  831 	movx	a,@dptr
      008233 7C 00            [12]  832 	mov	r4,#0x00
      008235 25 E0            [12]  833 	add	a,acc
      008237 FB               [12]  834 	mov	r3,a
      008238 EC               [12]  835 	mov	a,r4
      008239 33               [12]  836 	rlc	a
      00823A FC               [12]  837 	mov	r4,a
      00823B EB               [12]  838 	mov	a,r3
      00823C 2E               [12]  839 	add	a, r6
      00823D FE               [12]  840 	mov	r6,a
      00823E EC               [12]  841 	mov	a,r4
      00823F 3F               [12]  842 	addc	a, r7
      008240 FF               [12]  843 	mov	r7,a
      008241 12 43 1F         [24]  844 	lcall	_ak820_outline_0116
      008244 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      008246 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      008247                        861 _dynamic_keymap_get_keycode:
      008247 E5 82            [12]  862 	mov	a,dpl
      008249 90 0A D0         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      00824C F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      00824D E0               [24]  866 	movx	a,@dptr
      00824E FF               [12]  867 	mov	r7,a
      00824F BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008252                        869 00121$:
      008252 50 14            [24]  870 	jnc	00101$
      008254 90 0A CE         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008257 E0               [24]  872 	movx	a,@dptr
      008258 FE               [12]  873 	mov	r6,a
      008259 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      00825C                        875 00123$:
      00825C 50 0A            [24]  876 	jnc	00101$
      00825E 90 0A CF         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008261 E0               [24]  878 	movx	a,@dptr
      008262 FD               [12]  879 	mov	r5,a
      008263 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      008266                        881 00125$:
      008266 40 04            [24]  882 	jc	00102$
      008268                        883 00101$:
      008268 90 00 00         [24]  884 	mov	dptr,#0x0000
      00826B 22               [24]  885 	ret
      00826C                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00826C 12 8C C4         [24]  888 	lcall	_ak820_outline_0093
      00826F 12 82 10         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008272 12 8C D1         [24]  891 	lcall	_ak820_outline_0111
      008275 12 40 31         [24]  892 	lcall	_eeprom_read_byte
      008278 AB 82            [24]  893 	mov	r3,dpl
      00827A 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      00827C 0D               [12]  896 	inc	r5
      00827D BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008280 0E               [12]  898 	inc	r6
      008281                        899 00127$:
      008281 12 4E 24         [24]  900 	lcall	_ak820_outline_0042
      008284 12 40 31         [24]  901 	lcall	_eeprom_read_byte
      008287 AF 82            [24]  902 	mov	r7, dpl
      008289 7E 00            [12]  903 	mov	r6,#0x00
      00828B EF               [12]  904 	mov	a,r7
      00828C 42 04            [12]  905 	orl	ar4,a
      00828E EE               [12]  906 	mov	a,r6
      00828F 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008291 12 43 55         [24]  909 	lcall	_ak820_outline_0178
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008294 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008295                        925 _dynamic_keymap_set_keycode:
      008295 E5 82            [12]  926 	mov	a,dpl
      008297 90 0A D5         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      00829A F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00829B E0               [24]  930 	movx	a,@dptr
      00829C FF               [12]  931 	mov	r7,a
      00829D BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      0082A0                        933 00121$:
      0082A0 50 14            [24]  934 	jnc	00101$
      0082A2 90 0A D1         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0082A5 E0               [24]  936 	movx	a,@dptr
      0082A6 FE               [12]  937 	mov	r6,a
      0082A7 BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      0082AA                        939 00123$:
      0082AA 50 0A            [24]  940 	jnc	00101$
      0082AC 90 0A D2         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0082AF E0               [24]  942 	movx	a,@dptr
      0082B0 FD               [12]  943 	mov	r5,a
      0082B1 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      0082B4                        945 00125$:
      0082B4 40 01            [24]  946 	jc	00102$
      0082B6                        947 00101$:
      0082B6 22               [24]  948 	ret
      0082B7                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0082B7 12 8C C4         [24]  951 	lcall	_ak820_outline_0093
      0082BA 12 82 10         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      0082BD 12 8C D1         [24]  953 	lcall	_ak820_outline_0111
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0082C0 90 0A D3         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0082C3 E0               [24]  956 	movx	a,@dptr
      0082C4 FB               [12]  957 	mov	r3,a
      0082C5 A3               [24]  958 	inc	dptr
      0082C6 E0               [24]  959 	movx	a,@dptr
      0082C7 90 06 94         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      0082CA F0               [24]  961 	movx	@dptr,a
      0082CB 12 4E 24         [24]  962 	lcall	_ak820_outline_0042
      0082CE 12 4D 0C         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0082D1 0D               [12]  965 	inc	r5
      0082D2 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      0082D5 0E               [12]  967 	inc	r6
      0082D6                        968 00127$:
      0082D6 90 06 94         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      0082D9 EB               [12]  970 	mov	a,r3
      0082DA F0               [24]  971 	movx	@dptr,a
      0082DB 12 4E 24         [24]  972 	lcall	_ak820_outline_0042
                                    973 ;	quantum/dynamic_keymap.c:223: }
      0082DE 02 4D 0C         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      0082E1                        985 _dynamic_keymap_encoder_to_eeprom_address:
      0082E1 E5 82            [12]  986 	mov	a,dpl
      0082E3 90 0A D7         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      0082E6 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0082E7 E0               [24]  990 	movx	a,@dptr
      0082E8 75 F0 04         [24]  991 	mov	b,#0x04
      0082EB A4               [48]  992 	mul	ab
      0082EC 24 40            [12]  993 	add	a, #0x40
      0082EE FD               [12]  994 	mov	r5,a
      0082EF 74 06            [12]  995 	mov	a,#0x06
      0082F1 35 F0            [12]  996 	addc	a, b
      0082F3 FE               [12]  997 	mov	r6,a
      0082F4 7F 00            [12]  998 	mov	r7,#0x00
      0082F6 90 0A D6         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0082F9 E0               [24] 1000 	movx	a,@dptr
      0082FA 75 F0 04         [24] 1001 	mov	b,#0x04
      0082FD A4               [48] 1002 	mul	ab
      0082FE 2D               [12] 1003 	add	a, r5
      0082FF FD               [12] 1004 	mov	r5,a
      008300 EE               [12] 1005 	mov	a,r6
      008301 35 F0            [12] 1006 	addc	a, b
      008303 FE               [12] 1007 	mov	r6,a
      008304 12 4E 24         [24] 1008 	lcall	_ak820_outline_0042
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      008307 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      008308                       1024 _dynamic_keymap_get_encoder:
      008308 E5 82            [12] 1025 	mov	a,dpl
      00830A 90 0A DA         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      00830D F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00830E E0               [24] 1029 	movx	a,@dptr
      00830F FF               [12] 1030 	mov	r7,a
      008310 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008313                       1032 00131$:
      008313 50 0A            [24] 1033 	jnc	00101$
      008315 90 0A D8         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008318 E0               [24] 1035 	movx	a,@dptr
      008319 FE               [12] 1036 	mov	r6,a
      00831A BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      00831D                       1038 00133$:
      00831D 40 04            [24] 1039 	jc	00102$
      00831F                       1040 00101$:
      00831F 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008322 22               [24] 1042 	ret
      008323                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008323 90 0A D6         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008326 E4               [12] 1046 	clr	a
      008327 F0               [24] 1047 	movx	@dptr,a
      008328 8F 82            [24] 1048 	mov	dpl, r7
      00832A 12 82 E1         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00832D 12 8C D1         [24] 1050 	lcall	_ak820_outline_0111
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008330 90 0A D9         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008333 E0               [24] 1053 	movx	a,@dptr
      008334 FC               [12] 1054 	mov	r4,a
      008335 E0               [24] 1055 	movx	a,@dptr
      008336 60 04            [24] 1056 	jz	00106$
      008338 7B 00            [12] 1057 	mov	r3,#0x00
      00833A 80 02            [24] 1058 	sjmp	00107$
      00833C                       1059 00106$:
      00833C 7B 02            [12] 1060 	mov	r3,#0x02
      00833E                       1061 00107$:
      00833E EB               [12] 1062 	mov	a,r3
      00833F 12 8C A2         [24] 1063 	lcall	_ak820_outline_0024
      008342 12 40 31         [24] 1064 	lcall	_eeprom_read_byte
      008345 AA 82            [24] 1065 	mov	r2,dpl
      008347 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008349 EC               [12] 1068 	mov	a,r4
      00834A 60 04            [24] 1069 	jz	00108$
      00834C 7C 00            [12] 1070 	mov	r4,#0x00
      00834E 80 02            [24] 1071 	sjmp	00109$
      008350                       1072 00108$:
      008350 7C 02            [12] 1073 	mov	r4,#0x02
      008352                       1074 00109$:
      008352 EC               [12] 1075 	mov	a,r4
      008353 12 38 73         [24] 1076 	lcall	_ak820_outline_0154
      008356 0D               [12] 1077 	inc	r5
      008357 BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      00835A 0E               [12] 1079 	inc	r6
      00835B                       1080 00137$:
      00835B 12 4E 24         [24] 1081 	lcall	_ak820_outline_0042
      00835E 12 40 31         [24] 1082 	lcall	_eeprom_read_byte
      008361 AF 82            [24] 1083 	mov	r7, dpl
      008363 7E 00            [12] 1084 	mov	r6,#0x00
      008365 EF               [12] 1085 	mov	a,r7
      008366 42 03            [12] 1086 	orl	ar3,a
      008368 EE               [12] 1087 	mov	a,r6
      008369 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      00836B 8B 82            [24] 1090 	mov	dpl, r3
      00836D 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      00836F 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      008370                       1108 _dynamic_keymap_set_encoder:
      008370 E5 82            [12] 1109 	mov	a,dpl
      008372 90 0A DF         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008375 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008376 E0               [24] 1113 	movx	a,@dptr
      008377 FF               [12] 1114 	mov	r7,a
      008378 BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      00837B                       1116 00131$:
      00837B 50 0A            [24] 1117 	jnc	00101$
      00837D 90 0A DB         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008380 E0               [24] 1119 	movx	a,@dptr
      008381 FE               [12] 1120 	mov	r6,a
      008382 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      008385                       1122 00133$:
      008385 40 01            [24] 1123 	jc	00102$
      008387                       1124 00101$:
      008387 22               [24] 1125 	ret
      008388                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008388 90 0A D6         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00838B E4               [12] 1129 	clr	a
      00838C F0               [24] 1130 	movx	@dptr,a
      00838D 8F 82            [24] 1131 	mov	dpl, r7
      00838F 12 82 E1         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008392 12 8C D1         [24] 1133 	lcall	_ak820_outline_0111
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008395 90 0A DC         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008398 E0               [24] 1136 	movx	a,@dptr
      008399 FC               [12] 1137 	mov	r4,a
      00839A E0               [24] 1138 	movx	a,@dptr
      00839B 60 04            [24] 1139 	jz	00106$
      00839D 7B 00            [12] 1140 	mov	r3,#0x00
      00839F 80 02            [24] 1141 	sjmp	00107$
      0083A1                       1142 00106$:
      0083A1 7B 02            [12] 1143 	mov	r3,#0x02
      0083A3                       1144 00107$:
      0083A3 EB               [12] 1145 	mov	a,r3
      0083A4 12 8C E3         [24] 1146 	lcall	_ak820_outline_0131
      0083A7 8F 03            [24] 1147 	mov	ar3,r7
      0083A9 90 0A DD         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0083AC E0               [24] 1149 	movx	a,@dptr
      0083AD F5 30            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0083AF A3               [24] 1151 	inc	dptr
      0083B0 E0               [24] 1152 	movx	a,@dptr
      0083B1 F5 31            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0083B3 90 06 94         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083B6 F0               [24] 1155 	movx	@dptr,a
      0083B7 12 43 3F         [24] 1156 	lcall	_ak820_outline_0151
      0083BA 8B F0            [24] 1157 	mov	b, r3
      0083BC 12 4D 0C         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0083BF EC               [12] 1160 	mov	a,r4
      0083C0 60 04            [24] 1161 	jz	00108$
      0083C2 7C 00            [12] 1162 	mov	r4,#0x00
      0083C4 80 02            [24] 1163 	sjmp	00109$
      0083C6                       1164 00108$:
      0083C6 7C 02            [12] 1165 	mov	r4,#0x02
      0083C8                       1166 00109$:
      0083C8 EC               [12] 1167 	mov	a,r4
      0083C9 12 38 73         [24] 1168 	lcall	_ak820_outline_0154
      0083CC 0D               [12] 1169 	inc	r5
      0083CD BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      0083D0 0E               [12] 1171 	inc	r6
      0083D1                       1172 00137$:
      0083D1 90 06 94         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      0083D4 E5 30            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0083D6 F0               [24] 1175 	movx	@dptr,a
      0083D7 12 4E 24         [24] 1176 	lcall	_ak820_outline_0042
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      0083DA 02 4D 0C         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      0083DD                       1193 _dynamic_keymap_get_combo:
      0083DD E5 82            [12] 1194 	mov	a,dpl
      0083DF 90 0A E3         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      0083E2 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0083E3 90 0A E0         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0083E6 12 37 F9         [24] 1199 	lcall	_ak820_outline_0049
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      0083E9 90 0A E3         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      0083EC E0               [24] 1202 	movx	a,@dptr
      0083ED FD               [12] 1203 	mov	r5,a
      0083EE BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      0083F1                       1205 00132$:
      0083F1 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      0083F3 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      0083F6 22               [24] 1209 	ret
      0083F7                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0083F7 12 8C B0         [24] 1212 	lcall	_ak820_outline_0076
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0083FA 8E 02            [24] 1214 	mov	ar2,r6
      0083FC 8F 03            [24] 1215 	mov	ar3,r7
      0083FE 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008401 12 38 1E         [24] 1217 	lcall	_ak820_outline_0068
      008404 E4               [12] 1218 	clr	a
      008405 A3               [24] 1219 	inc	dptr
      008406 F0               [24] 1220 	movx	@dptr,a
      008407 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00840A 74 0A            [12] 1222 	mov	a,#0x0a
      00840C 12 38 58         [24] 1223 	lcall	_ak820_outline_0121
      00840F 12 43 35         [24] 1224 	lcall	_ak820_outline_0139
      008412 C0 07            [24] 1225 	push	ar7
      008414 C0 06            [24] 1226 	push	ar6
      008416 12 40 6C         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      008419 D0 06            [24] 1228 	pop	ar6
      00841B D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00841D 74 04            [12] 1231 	mov	a,#0x04
      00841F 12 47 6D         [24] 1232 	lcall	_ak820_outline_0011
      008422 FA               [12] 1233 	mov	r2,a
      008423 A3               [24] 1234 	inc	dptr
      008424 E0               [24] 1235 	movx	a,@dptr
      008425 FB               [12] 1236 	mov	r3,a
      008426 BA 20 13         [24] 1237 	cjne	r2,#0x20,00108$
      008429 BB 08 10         [24] 1238 	cjne	r3,#0x08,00108$
      00842C 74 06            [12] 1239 	mov	a,#0x06
      00842E 12 37 E9         [24] 1240 	lcall	_ak820_outline_0019
      008431 12 43 01         [24] 1241 	lcall	_ak820_outline_0080
      008434 BA 01 05         [24] 1242 	cjne	r2,#0x01,00136$
      008437 BB 00 02         [24] 1243 	cjne	r3,#0x00,00136$
      00843A 80 05            [24] 1244 	sjmp	00109$
      00843C                       1245 00136$:
      00843C                       1246 00108$:
      00843C 75 32 00         [24] 1247 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      00843F 80 03            [24] 1248 	sjmp	00110$
      008441                       1249 00109$:
      008441 75 32 01         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008444                       1251 00110$:
                                   1252 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008444 74 06            [12] 1253 	mov	a,#0x06
      008446 12 37 E9         [24] 1254 	lcall	_ak820_outline_0019
      008449 12 4E 64         [24] 1255 	lcall	_ak820_outline_0164
      00844C 12 38 53         [24] 1256 	lcall	_ak820_outline_0117
      00844F F0               [24] 1257 	movx	@dptr,a
      008450 A3               [24] 1258 	inc	dptr
      008451 F0               [24] 1259 	movx	@dptr,a
                                   1260 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008452 E5 32            [12] 1261 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008454 60 12            [24] 1262 	jz	00103$
      008456 12 43 1F         [24] 1263 	lcall	_ak820_outline_0116
      008459 C0 07            [24] 1264 	push	ar7
      00845B C0 06            [24] 1265 	push	ar6
      00845D 12 34 68         [24] 1266 	lcall	_ak820_combo_valid
      008460 E5 82            [12] 1267 	mov	a, dpl
      008462 D0 06            [24] 1268 	pop	ar6
      008464 D0 07            [24] 1269 	pop	ar7
      008466 70 17            [24] 1270 	jnz	00104$
      008468                       1271 00103$:
      008468 7D 00            [12] 1272 	mov	r5,#0x00
      00846A 90 0D 70         [24] 1273 	mov	dptr,#_memset_PARM_2
      00846D E4               [12] 1274 	clr	a
      00846E F0               [24] 1275 	movx	@dptr,a
      00846F 90 0D 71         [24] 1276 	mov	dptr,#_memset_PARM_3
      008472 74 0A            [12] 1277 	mov	a,#0x0a
      008474 F0               [24] 1278 	movx	@dptr,a
      008475 E4               [12] 1279 	clr	a
      008476 A3               [24] 1280 	inc	dptr
      008477 12 42 F4         [24] 1281 	lcall	_ak820_outline_0058
      00847A 8D F0            [24] 1282 	mov	b, r5
      00847C 12 B5 43         [24] 1283 	lcall	_memset
      00847F                       1284 00104$:
                                   1285 ;	quantum/dynamic_keymap.c:329: return 0;
      00847F 90 00 00         [24] 1286 	mov	dptr,#0x0000
                                   1287 ;	quantum/dynamic_keymap.c:330: }
      008482 22               [24] 1288 	ret
                                   1289 ;------------------------------------------------------------
                                   1290 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1291 ;------------------------------------------------------------
                                   1292 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1293 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1294 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1295 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1296 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1297 ;------------------------------------------------------------
                                   1298 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1299 ;	-----------------------------------------
                                   1300 ;	 function dynamic_keymap_set_combo
                                   1301 ;	-----------------------------------------
      008483                       1302 _dynamic_keymap_set_combo:
      008483 E5 82            [12] 1303 	mov	a,dpl
      008485 90 0A E7         [24] 1304 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008488 F0               [24] 1305 	movx	@dptr,a
                                   1306 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008489 90 0A E4         [24] 1307 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00848C 12 37 A2         [24] 1308 	lcall	_ak820_outline_0004
                                   1309 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      00848F C0 07            [24] 1310 	push	ar7
      008491 C0 06            [24] 1311 	push	ar6
      008493 12 34 68         [24] 1312 	lcall	_ak820_combo_valid
      008496 E5 82            [12] 1313 	mov	a, dpl
      008498 D0 06            [24] 1314 	pop	ar6
      00849A D0 07            [24] 1315 	pop	ar7
      00849C 60 07            [24] 1316 	jz	00101$
      00849E 12 3D D7         [24] 1317 	lcall	_ak820_nvm_ok
      0084A1 E5 82            [12] 1318 	mov	a, dpl
      0084A3 70 04            [24] 1319 	jnz	00102$
      0084A5                       1320 00101$:
      0084A5 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      0084A8 22               [24] 1322 	ret
      0084A9                       1323 00102$:
                                   1324 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      0084A9 90 0A E7         [24] 1325 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      0084AC E0               [24] 1326 	movx	a,@dptr
      0084AD FD               [12] 1327 	mov	r5,a
      0084AE BD 08 00         [24] 1328 	cjne	r5,#0x08,00133$
      0084B1                       1329 00133$:
      0084B1 40 04            [24] 1330 	jc	00105$
                                   1331 ;	quantum/dynamic_keymap.c:342: return -1;
      0084B3 90 FF FF         [24] 1332 	mov	dptr,#0xffff
      0084B6 22               [24] 1333 	ret
      0084B7                       1334 00105$:
                                   1335 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0084B7 12 8C B0         [24] 1336 	lcall	_ak820_outline_0076
                                   1337 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      0084BA C0 07            [24] 1338 	push	ar7
      0084BC C0 06            [24] 1339 	push	ar6
      0084BE C0 05            [24] 1340 	push	ar5
      0084C0 C0 04            [24] 1341 	push	ar4
      0084C2 12 75 34         [24] 1342 	lcall	_clear_keyboard
      0084C5 D0 04            [24] 1343 	pop	ar4
      0084C7 D0 05            [24] 1344 	pop	ar5
      0084C9 D0 06            [24] 1345 	pop	ar6
      0084CB D0 07            [24] 1346 	pop	ar7
                                   1347 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      0084CD 90 0D 68         [24] 1348 	mov	dptr,#___memcpy_PARM_2
      0084D0 12 47 BF         [24] 1349 	lcall	_ak820_outline_0056
      0084D3 E4               [12] 1350 	clr	a
      0084D4 A3               [24] 1351 	inc	dptr
      0084D5 F0               [24] 1352 	movx	@dptr,a
      0084D6 90 0D 6B         [24] 1353 	mov	dptr,#___memcpy_PARM_3
      0084D9 74 0A            [12] 1354 	mov	a,#0x0a
      0084DB 12 38 58         [24] 1355 	lcall	_ak820_outline_0121
      0084DE 90 0A E8         [24] 1356 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      0084E1 F5 F0            [12] 1357 	mov	b,a
      0084E3 C0 05            [24] 1358 	push	ar5
      0084E5 C0 04            [24] 1359 	push	ar4
      0084E7 12 B4 CD         [24] 1360 	lcall	___memcpy
      0084EA D0 04            [24] 1361 	pop	ar4
      0084EC D0 05            [24] 1362 	pop	ar5
                                   1363 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      0084EE 90 0A EC         [24] 1364 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      0084F1 74 20            [12] 1365 	mov	a,#0x20
      0084F3 F0               [24] 1366 	movx	@dptr,a
      0084F4 74 08            [12] 1367 	mov	a,#0x08
      0084F6 A3               [24] 1368 	inc	dptr
      0084F7 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      0084F8 90 0A EE         [24] 1371 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      0084FB 74 01            [12] 1372 	mov	a,#0x01
      0084FD 12 38 58         [24] 1373 	lcall	_ak820_outline_0121
                                   1374 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008500 90 05 8A         [24] 1375 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008503 12 38 1E         [24] 1376 	lcall	_ak820_outline_0068
      008506 E4               [12] 1377 	clr	a
      008507 A3               [24] 1378 	inc	dptr
      008508 F0               [24] 1379 	movx	@dptr,a
      008509 90 05 8D         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00850C 74 0A            [12] 1381 	mov	a,#0x0a
      00850E 12 38 58         [24] 1382 	lcall	_ak820_outline_0121
      008511 90 0A E8         [24] 1383 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008514 12 40 F8         [24] 1384 	lcall	_ak820_eeprom_write_block_xdata
                                   1385 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008517 12 3D E6         [24] 1386 	lcall	_ak820_nvm_flush
                                   1387 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      00851A 12 3D D7         [24] 1388 	lcall	_ak820_nvm_ok
      00851D E5 82            [12] 1389 	mov	a, dpl
      00851F 70 04            [24] 1390 	jnz	00107$
      008521 90 FF FF         [24] 1391 	mov	dptr,#0xffff
      008524 22               [24] 1392 	ret
      008525                       1393 00107$:
                                   1394 ;	quantum/dynamic_keymap.c:360: return 0;
      008525 90 00 00         [24] 1395 	mov	dptr,#0x0000
                                   1396 ;	quantum/dynamic_keymap.c:361: }
      008528 22               [24] 1397 	ret
                                   1398 ;------------------------------------------------------------
                                   1399 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1400 ;------------------------------------------------------------
                                   1401 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1402 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1403 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1404 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1405 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1406 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1407 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1408 ;------------------------------------------------------------
                                   1409 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1410 ;	-----------------------------------------
                                   1411 ;	 function dynamic_keymap_reset
                                   1412 ;	-----------------------------------------
      008529                       1413 _dynamic_keymap_reset:
                                   1414 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008529 90 0D E8         [24] 1415 	mov	dptr,#_vial_unlocked
      00852C E0               [24] 1416 	movx	a,@dptr
      00852D 90 0A F2         [24] 1417 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008530 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008531 90 0D E8         [24] 1420 	mov	dptr,#_vial_unlocked
      008534 74 01            [12] 1421 	mov	a,#0x01
      008536 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008537 7F 00            [12] 1424 	mov	r7,#0x00
      008539                       1425 00116$:
      008539 BF 06 00         [24] 1426 	cjne	r7,#0x06,00198$
      00853C                       1427 00198$:
      00853C 40 03            [24] 1428 	jc	00199$
      00853E 02 85 EC         [24] 1429 	ljmp	00104$
      008541                       1430 00199$:
                                   1431 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008541 7E 00            [12] 1432 	mov	r6,#0x00
      008543                       1433 00110$:
      008543 BE 10 00         [24] 1434 	cjne	r6,#0x10,00200$
      008546                       1435 00200$:
      008546 50 4D            [24] 1436 	jnc	00102$
                                   1437 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008548 7D 00            [12] 1438 	mov	r5,#0x00
      00854A                       1439 00107$:
      00854A BD 08 00         [24] 1440 	cjne	r5,#0x08,00202$
      00854D                       1441 00202$:
      00854D 50 43            [24] 1442 	jnc	00111$
                                   1443 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      00854F 90 0B 8E         [24] 1444 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008552 EE               [12] 1445 	mov	a,r6
      008553 F0               [24] 1446 	movx	@dptr,a
      008554 90 0B 8F         [24] 1447 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008557 ED               [12] 1448 	mov	a,r5
      008558 F0               [24] 1449 	movx	@dptr,a
      008559 8F 82            [24] 1450 	mov	dpl, r7
      00855B C0 07            [24] 1451 	push	ar7
      00855D C0 06            [24] 1452 	push	ar6
      00855F C0 05            [24] 1453 	push	ar5
      008561 12 94 F6         [24] 1454 	lcall	_keycode_at_keymap_location_raw
      008564 AB 82            [24] 1455 	mov	r3, dpl
      008566 AC 83            [24] 1456 	mov	r4, dph
      008568 D0 05            [24] 1457 	pop	ar5
      00856A D0 06            [24] 1458 	pop	ar6
      00856C D0 07            [24] 1459 	pop	ar7
      00856E 90 0A D1         [24] 1460 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008571 EE               [12] 1461 	mov	a,r6
      008572 F0               [24] 1462 	movx	@dptr,a
      008573 90 0A D2         [24] 1463 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008576 ED               [12] 1464 	mov	a,r5
      008577 F0               [24] 1465 	movx	@dptr,a
      008578 90 0A D3         [24] 1466 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00857B 12 38 24         [24] 1467 	lcall	_ak820_outline_0074
      00857E 8F 82            [24] 1468 	mov	dpl, r7
      008580 C0 07            [24] 1469 	push	ar7
      008582 C0 06            [24] 1470 	push	ar6
      008584 C0 05            [24] 1471 	push	ar5
      008586 12 82 95         [24] 1472 	lcall	_dynamic_keymap_set_keycode
      008589 D0 05            [24] 1473 	pop	ar5
      00858B D0 06            [24] 1474 	pop	ar6
      00858D D0 07            [24] 1475 	pop	ar7
                                   1476 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00858F 0D               [12] 1477 	inc	r5
      008590 80 B8            [24] 1478 	sjmp	00107$
      008592                       1479 00111$:
                                   1480 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008592 0E               [12] 1481 	inc	r6
      008593 80 AE            [24] 1482 	sjmp	00110$
      008595                       1483 00102$:
                                   1484 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008595 7E 00            [12] 1485 	mov	r6,#0x00
      008597                       1486 00113$:
      008597 BE 01 00         [24] 1487 	cjne	r6,#0x01,00204$
      00859A                       1488 00204$:
      00859A 50 4C            [24] 1489 	jnc	00117$
                                   1490 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      00859C 12 8C FF         [24] 1491 	lcall	_ak820_outline_0174
      00859F 04               [12] 1492 	inc	a
      0085A0 F0               [24] 1493 	movx	@dptr,a
      0085A1 8F 82            [24] 1494 	mov	dpl, r7
      0085A3 C0 07            [24] 1495 	push	ar7
      0085A5 12 95 3B         [24] 1496 	lcall	_keycode_at_encodermap_location_raw
      0085A8 12 43 3A         [24] 1497 	lcall	_ak820_outline_0143
      0085AB D0 07            [24] 1498 	pop	ar7
      0085AD 12 8C F6         [24] 1499 	lcall	_ak820_outline_0173
      0085B0 04               [12] 1500 	inc	a
      0085B1 F0               [24] 1501 	movx	@dptr,a
      0085B2 90 0A DD         [24] 1502 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0085B5 12 38 1E         [24] 1503 	lcall	_ak820_outline_0068
      0085B8 8F 82            [24] 1504 	mov	dpl, r7
      0085BA C0 07            [24] 1505 	push	ar7
      0085BC 12 83 70         [24] 1506 	lcall	_dynamic_keymap_set_encoder
      0085BF D0 07            [24] 1507 	pop	ar7
                                   1508 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0085C1 12 8C FF         [24] 1509 	lcall	_ak820_outline_0174
      0085C4 F0               [24] 1510 	movx	@dptr,a
      0085C5 8F 82            [24] 1511 	mov	dpl, r7
      0085C7 C0 07            [24] 1512 	push	ar7
      0085C9 12 95 3B         [24] 1513 	lcall	_keycode_at_encodermap_location_raw
      0085CC 12 43 3A         [24] 1514 	lcall	_ak820_outline_0143
      0085CF D0 07            [24] 1515 	pop	ar7
      0085D1 12 8C F6         [24] 1516 	lcall	_ak820_outline_0173
      0085D4 F0               [24] 1517 	movx	@dptr,a
      0085D5 90 0A DD         [24] 1518 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0085D8 12 38 1E         [24] 1519 	lcall	_ak820_outline_0068
      0085DB 8F 82            [24] 1520 	mov	dpl, r7
      0085DD C0 07            [24] 1521 	push	ar7
      0085DF 12 83 70         [24] 1522 	lcall	_dynamic_keymap_set_encoder
      0085E2 D0 07            [24] 1523 	pop	ar7
                                   1524 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0085E4 7E 01            [12] 1525 	mov	r6,#0x01
      0085E6 80 AF            [24] 1526 	sjmp	00113$
      0085E8                       1527 00117$:
                                   1528 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0085E8 0F               [12] 1529 	inc	r7
      0085E9 02 85 39         [24] 1530 	ljmp	00116$
      0085EC                       1531 00104$:
                                   1532 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      0085EC 90 0A F3         [24] 1533 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      0085EF 12 4E 64         [24] 1534 	lcall	_ak820_outline_0164
      0085F2 90 0A F5         [24] 1535 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      0085F5 F0               [24] 1536 	movx	@dptr,a
      0085F6 A3               [24] 1537 	inc	dptr
      0085F7 F0               [24] 1538 	movx	@dptr,a
      0085F8 90 0A F7         [24] 1539 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      0085FB F0               [24] 1540 	movx	@dptr,a
      0085FC A3               [24] 1541 	inc	dptr
      0085FD F0               [24] 1542 	movx	@dptr,a
      0085FE 90 0A F9         [24] 1543 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      008601 F0               [24] 1544 	movx	@dptr,a
      008602 A3               [24] 1545 	inc	dptr
      008603 F0               [24] 1546 	movx	@dptr,a
      008604 90 0A FB         [24] 1547 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      008607 F0               [24] 1548 	movx	@dptr,a
      008608 A3               [24] 1549 	inc	dptr
      008609 F0               [24] 1550 	movx	@dptr,a
                                   1551 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00860A FF               [12] 1552 	mov	r7,a
      00860B                       1553 00119$:
      00860B BF 08 00         [24] 1554 	cjne	r7,#0x08,00206$
      00860E                       1555 00206$:
      00860E 50 17            [24] 1556 	jnc	00105$
                                   1557 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008610 90 0A E4         [24] 1558 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008613 74 F3            [12] 1559 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      008615 F0               [24] 1560 	movx	@dptr,a
      008616 74 0A            [12] 1561 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      008618 12 38 30         [24] 1562 	lcall	_ak820_outline_0095
      00861B 8F 82            [24] 1563 	mov	dpl, r7
      00861D C0 07            [24] 1564 	push	ar7
      00861F 12 84 83         [24] 1565 	lcall	_dynamic_keymap_set_combo
      008622 D0 07            [24] 1566 	pop	ar7
                                   1567 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008624 0F               [12] 1568 	inc	r7
      008625 80 E4            [24] 1569 	sjmp	00119$
      008627                       1570 00105$:
                                   1571 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008627 90 0A F2         [24] 1572 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      00862A E0               [24] 1573 	movx	a,@dptr
      00862B 90 0D E8         [24] 1574 	mov	dptr,#_vial_unlocked
      00862E F0               [24] 1575 	movx	@dptr,a
                                   1576 ;	quantum/dynamic_keymap.c:468: }
      00862F 22               [24] 1577 	ret
                                   1578 ;------------------------------------------------------------
                                   1579 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1580 ;------------------------------------------------------------
                                   1581 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1582 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1583 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1584 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1585 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1586 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1587 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1588 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1589 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1590 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1591 ;------------------------------------------------------------
                                   1592 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1593 ;	-----------------------------------------
                                   1594 ;	 function ak820_dynamic_read_buffer
                                   1595 ;	-----------------------------------------
      008630                       1596 _ak820_dynamic_read_buffer:
      008630 12 38 47         [24] 1597 	lcall	_ak820_outline_0103
      008633 90 0B 06         [24] 1598 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008636 12 38 42         [24] 1599 	lcall	_ak820_outline_0102
                                   1600 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008639 90 0B 03         [24] 1601 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00863C 12 37 F9         [24] 1602 	lcall	_ak820_outline_0049
                                   1603 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      00863F 90 0B 08         [24] 1604 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008642 E4               [12] 1605 	clr	a
      008643 F0               [24] 1606 	movx	@dptr,a
                                   1607 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008644 90 0B 01         [24] 1608 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008647 12 38 18         [24] 1609 	lcall	_ak820_outline_0057
      00864A 8C 02            [24] 1610 	mov	ar2,r4
      00864C 8D 03            [24] 1611 	mov	ar3,r5
      00864E C3               [12] 1612 	clr	c
      00864F 74 1C            [12] 1613 	mov	a,#0x1c
      008651 9A               [12] 1614 	subb	a,r2
      008652 E4               [12] 1615 	clr	a
      008653 9B               [12] 1616 	subb	a,r3
      008654 50 01            [24] 1617 	jnc	00102$
                                   1618 ;	free result
      008656 22               [24] 1619 	ret
      008657                       1620 00102$:
                                   1621 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008657 90 0A FF         [24] 1622 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00865A 12 43 01         [24] 1623 	lcall	_ak820_outline_0080
      00865D 90 0A FD         [24] 1624 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008660 12 38 2A         [24] 1625 	lcall	_ak820_outline_0094
      008663 C3               [12] 1626 	clr	c
      008664 EA               [12] 1627 	mov	a,r2
      008665 98               [12] 1628 	subb	a,r0
      008666 EB               [12] 1629 	mov	a,r3
      008667 99               [12] 1630 	subb	a,r1
      008668 50 17            [24] 1631 	jnc	00104$
                                   1632 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      00866A E8               [12] 1633 	mov	a,r0
      00866B C3               [12] 1634 	clr	c
      00866C 9A               [12] 1635 	subb	a,r2
      00866D F8               [12] 1636 	mov	r0,a
      00866E E9               [12] 1637 	mov	a,r1
      00866F 9B               [12] 1638 	subb	a,r3
      008670 F9               [12] 1639 	mov	r1,a
                                   1640 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008671 C3               [12] 1641 	clr	c
      008672 E8               [12] 1642 	mov	a,r0
      008673 9C               [12] 1643 	subb	a,r4
      008674 E9               [12] 1644 	mov	a,r1
      008675 9D               [12] 1645 	subb	a,r5
      008676 40 04            [24] 1646 	jc	00114$
      008678 8C 00            [24] 1647 	mov	ar0,r4
      00867A 8D 01            [24] 1648 	mov	ar1,r5
      00867C                       1649 00114$:
      00867C 90 0B 08         [24] 1650 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      00867F E8               [12] 1651 	mov	a,r0
      008680 F0               [24] 1652 	movx	@dptr,a
      008681                       1653 00104$:
                                   1654 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008681 90 0B 08         [24] 1655 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008684 E0               [24] 1656 	movx	a,@dptr
      008685 F5 33            [12] 1657 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008687 E0               [24] 1658 	movx	a,@dptr
      008688 60 42            [24] 1659 	jz	00106$
      00868A C0 04            [24] 1660 	push	ar4
      00868C C0 05            [24] 1661 	push	ar5
      00868E 8E 00            [24] 1662 	mov	ar0,r6
      008690 8F 05            [24] 1663 	mov	ar5,r7
      008692 90 0B 06         [24] 1664 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008695 E0               [24] 1665 	movx	a,@dptr
      008696 F9               [12] 1666 	mov	r1,a
      008697 A3               [24] 1667 	inc	dptr
      008698 E0               [24] 1668 	movx	a,@dptr
      008699 FC               [12] 1669 	mov	r4,a
      00869A EA               [12] 1670 	mov	a,r2
      00869B 29               [12] 1671 	add	a, r1
      00869C FA               [12] 1672 	mov	r2,a
      00869D EB               [12] 1673 	mov	a,r3
      00869E 3C               [12] 1674 	addc	a, r4
      00869F FB               [12] 1675 	mov	r3,a
      0086A0 90 05 81         [24] 1676 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0086A3 EA               [12] 1677 	mov	a,r2
      0086A4 F0               [24] 1678 	movx	@dptr,a
      0086A5 EB               [12] 1679 	mov	a,r3
      0086A6 12 38 30         [24] 1680 	lcall	_ak820_outline_0095
      0086A9 90 05 84         [24] 1681 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0086AC E5 33            [12] 1682 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      0086AE 12 38 58         [24] 1683 	lcall	_ak820_outline_0121
      0086B1 88 82            [24] 1684 	mov	dpl, r0
      0086B3 8D 83            [24] 1685 	mov	dph, r5
      0086B5 C0 07            [24] 1686 	push	ar7
      0086B7 C0 06            [24] 1687 	push	ar6
      0086B9 C0 05            [24] 1688 	push	ar5
      0086BB C0 04            [24] 1689 	push	ar4
      0086BD 12 40 6C         [24] 1690 	lcall	_ak820_eeprom_read_block_xdata
      0086C0 D0 04            [24] 1691 	pop	ar4
      0086C2 D0 05            [24] 1692 	pop	ar5
      0086C4 D0 06            [24] 1693 	pop	ar6
      0086C6 D0 07            [24] 1694 	pop	ar7
                                   1695 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0086C8 D0 05            [24] 1696 	pop	ar5
      0086CA D0 04            [24] 1697 	pop	ar4
                                   1698 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0086CC                       1699 00106$:
                                   1700 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0086CC 90 0B 08         [24] 1701 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0086CF E0               [24] 1702 	movx	a,@dptr
      0086D0 FB               [12] 1703 	mov	r3,a
      0086D1                       1704 00109$:
      0086D1 8B 01            [24] 1705 	mov	ar1,r3
      0086D3 7A 00            [12] 1706 	mov	r2,#0x00
      0086D5 C3               [12] 1707 	clr	c
      0086D6 E9               [12] 1708 	mov	a,r1
      0086D7 9C               [12] 1709 	subb	a,r4
      0086D8 EA               [12] 1710 	mov	a,r2
      0086D9 9D               [12] 1711 	subb	a,r5
      0086DA 50 09            [24] 1712 	jnc	00111$
      0086DC EB               [12] 1713 	mov	a,r3
      0086DD 12 37 E9         [24] 1714 	lcall	_ak820_outline_0019
      0086E0 E4               [12] 1715 	clr	a
      0086E1 F0               [24] 1716 	movx	@dptr,a
      0086E2 0B               [12] 1717 	inc	r3
      0086E3 80 EC            [24] 1718 	sjmp	00109$
      0086E5                       1719 00111$:
                                   1720 ;	quantum/dynamic_keymap.c:483: }
      0086E5 22               [24] 1721 	ret
                                   1722 ;------------------------------------------------------------
                                   1723 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1724 ;------------------------------------------------------------
                                   1725 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1726 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1727 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1728 ;------------------------------------------------------------
                                   1729 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1730 ;	-----------------------------------------
                                   1731 ;	 function dynamic_keymap_get_buffer
                                   1732 ;	-----------------------------------------
      0086E6                       1733 _dynamic_keymap_get_buffer:
      0086E6 12 38 47         [24] 1734 	lcall	_ak820_outline_0103
      0086E9 90 0B 0E         [24] 1735 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      0086EC 12 38 42         [24] 1736 	lcall	_ak820_outline_0102
                                   1737 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      0086EF 90 0B 0E         [24] 1738 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      0086F2 12 37 F9         [24] 1739 	lcall	_ak820_outline_0049
      0086F5 90 0B 09         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      0086F8 12 38 18         [24] 1741 	lcall	_ak820_outline_0057
      0086FB 90 0B 0B         [24] 1742 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      0086FE E0               [24] 1743 	movx	a,@dptr
      0086FF F9               [12] 1744 	mov	r1,a
      008700 A3               [24] 1745 	inc	dptr
      008701 12 43 01         [24] 1746 	lcall	_ak820_outline_0080
      008704 90 0A FD         [24] 1747 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008707 E4               [12] 1748 	clr	a
      008708 F0               [24] 1749 	movx	@dptr,a
      008709 74 06            [12] 1750 	mov	a,#0x06
      00870B A3               [24] 1751 	inc	dptr
      00870C F0               [24] 1752 	movx	@dptr,a
      00870D 90 0A FF         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008710 12 47 BF         [24] 1754 	lcall	_ak820_outline_0056
      008713 90 0B 01         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008716 12 38 1E         [24] 1756 	lcall	_ak820_outline_0068
      008719 90 0B 03         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00871C E9               [12] 1758 	mov	a,r1
      00871D 12 4E 5D         [24] 1759 	lcall	_ak820_outline_0149
      008720 F0               [24] 1760 	movx	@dptr,a
      008721 90 00 40         [24] 1761 	mov	dptr,#0x0040
                                   1762 ;	quantum/dynamic_keymap.c:511: }
      008724 02 86 30         [24] 1763 	ljmp	_ak820_dynamic_read_buffer
                                   1764 ;------------------------------------------------------------
                                   1765 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1766 ;------------------------------------------------------------
                                   1767 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1768 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1769 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1770 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1771 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1772 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1773 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1774 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1775 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1776 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1777 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1778 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1779 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1780 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1781 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1783 ;------------------------------------------------------------
                                   1784 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1785 ;	-----------------------------------------
                                   1786 ;	 function dynamic_keymap_set_buffer
                                   1787 ;	-----------------------------------------
      008727                       1788 _dynamic_keymap_set_buffer:
      008727 12 38 47         [24] 1789 	lcall	_ak820_outline_0103
      00872A 90 0B 15         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      00872D 12 38 42         [24] 1791 	lcall	_ak820_outline_0102
                                   1792 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008730 90 0B 15         [24] 1793 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008733 12 37 C0         [24] 1794 	lcall	_ak820_outline_0007
      008736 74 40            [12] 1795 	mov	a,#0x40
      008738 2C               [12] 1796 	add	a, r4
      008739 FA               [12] 1797 	mov	r2,a
      00873A E4               [12] 1798 	clr	a
      00873B 3D               [12] 1799 	addc	a, r5
      00873C FB               [12] 1800 	mov	r3,a
                                   1801 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      00873D 90 0B 12         [24] 1802 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008740 12 38 2A         [24] 1803 	lcall	_ak820_outline_0094
                                   1804 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008743 90 0B 10         [24] 1805 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008746 E0               [24] 1806 	movx	a,@dptr
      008747 F5 34            [12] 1807 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008749 A3               [24] 1808 	inc	dptr
      00874A E0               [24] 1809 	movx	a,@dptr
      00874B F5 35            [12] 1810 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      00874D E5 34            [12] 1811 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00874F 45 35            [12] 1812 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008751 70 01            [24] 1813 	jnz	00102$
      008753 22               [24] 1814 	ret
      008754                       1815 00102$:
                                   1816 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008754 85 34 36         [24] 1817 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008757 85 35 37         [24] 1818 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00875A C3               [12] 1819 	clr	c
      00875B 74 1C            [12] 1820 	mov	a,#0x1c
      00875D 95 36            [12] 1821 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      00875F E4               [12] 1822 	clr	a
      008760 95 37            [12] 1823 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008762 50 01            [24] 1824 	jnc	00104$
                                   1825 ;	free result
      008764 22               [24] 1826 	ret
      008765                       1827 00104$:
                                   1828 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008765 85 34 38         [24] 1829 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1830 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008768 74 FA            [12] 1831 	mov	a,#0x100 - 0x06
      00876A 2F               [12] 1832 	add	a,r7
      00876B 40 11            [24] 1833 	jc	00105$
      00876D E4               [12] 1834 	clr	a
      00876E C3               [12] 1835 	clr	c
      00876F 9E               [12] 1836 	subb	a,r6
      008770 FE               [12] 1837 	mov	r6,a
      008771 74 06            [12] 1838 	mov	a,#0x06
      008773 9F               [12] 1839 	subb	a,r7
      008774 FF               [12] 1840 	mov	r7,a
      008775 C3               [12] 1841 	clr	c
      008776 EE               [12] 1842 	mov	a,r6
      008777 95 34            [12] 1843 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008779 EF               [12] 1844 	mov	a,r7
      00877A 95 35            [12] 1845 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00877C 50 01            [24] 1846 	jnc	00106$
      00877E                       1847 00105$:
                                   1848 ;	quantum/dynamic_keymap.c:529: return;
      00877E 22               [24] 1849 	ret
      00877F                       1850 00106$:
                                   1851 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      00877F 90 0D E8         [24] 1852 	mov	dptr,#_vial_unlocked
      008782 E0               [24] 1853 	movx	a,@dptr
      008783 60 03            [24] 1854 	jz	00207$
      008785 02 88 94         [24] 1855 	ljmp	00120$
      008788                       1856 00207$:
                                   1857 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008788 90 0B 17         [24] 1858 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      00878B E4               [12] 1859 	clr	a
      00878C F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      00878D 90 0B 18         [24] 1862 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008790 E5 38            [12] 1863 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008792 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008793 EC               [12] 1866 	mov	a,r4
      008794 30 E0 33         [24] 1867 	jnb	acc.0,00111$
                                   1868 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008797 EA               [12] 1869 	mov	a,r2
      008798 24 FF            [12] 1870 	add	a,#0xff
      00879A FE               [12] 1871 	mov	r6,a
      00879B EB               [12] 1872 	mov	a,r3
      00879C 34 FF            [12] 1873 	addc	a,#0xff
      00879E FF               [12] 1874 	mov	r7,a
      00879F 7D 00            [12] 1875 	mov	r5,#0x00
      0087A1 12 43 1F         [24] 1876 	lcall	_ak820_outline_0116
      0087A4 8D F0            [24] 1877 	mov	b, r5
      0087A6 12 40 31         [24] 1878 	lcall	_eeprom_read_byte
      0087A9 AE 82            [24] 1879 	mov	r6,dpl
      0087AB 7F 00            [12] 1880 	mov	r7,#0x00
      0087AD 12 38 6E         [24] 1881 	lcall	_ak820_outline_0150
      0087B0 E0               [24] 1882 	movx	a,@dptr
      0087B1 7C 00            [12] 1883 	mov	r4,#0x00
      0087B3 42 07            [12] 1884 	orl	ar7,a
      0087B5 EC               [12] 1885 	mov	a,r4
      0087B6 42 06            [12] 1886 	orl	ar6,a
                                   1887 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      0087B8 BF 00 09         [24] 1888 	cjne	r7,#0x00,00109$
      0087BB BE 7C 06         [24] 1889 	cjne	r6,#0x7c,00109$
                                   1890 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      0087BE 12 38 6E         [24] 1891 	lcall	_ak820_outline_0150
      0087C1 74 FF            [12] 1892 	mov	a,#0xff
      0087C3 F0               [24] 1893 	movx	@dptr,a
      0087C4                       1894 00109$:
                                   1895 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      0087C4 90 0B 17         [24] 1896 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0087C7 74 01            [12] 1897 	mov	a,#0x01
      0087C9 F0               [24] 1898 	movx	@dptr,a
      0087CA                       1899 00111$:
                                   1900 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      0087CA 90 0B 15         [24] 1901 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0087CD 12 37 F9         [24] 1902 	lcall	_ak820_outline_0049
      0087D0 E5 34            [12] 1903 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0087D2 2E               [12] 1904 	add	a, r6
      0087D3 FE               [12] 1905 	mov	r6,a
      0087D4 E5 35            [12] 1906 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0087D6 3F               [12] 1907 	addc	a, r7
      0087D7 EE               [12] 1908 	mov	a,r6
      0087D8 30 E0 5A         [24] 1909 	jnb	acc.0,00115$
                                   1910 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      0087DB AE 38            [24] 1911 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      0087DD 7F 00            [12] 1912 	mov	r7,#0x00
      0087DF EE               [12] 1913 	mov	a,r6
      0087E0 24 FF            [12] 1914 	add	a,#0xff
      0087E2 FC               [12] 1915 	mov	r4,a
      0087E3 EF               [12] 1916 	mov	a,r7
      0087E4 34 FF            [12] 1917 	addc	a,#0xff
      0087E6 FD               [12] 1918 	mov	r5,a
      0087E7 EC               [12] 1919 	mov	a,r4
      0087E8 28               [12] 1920 	add	a, r0
      0087E9 F5 82            [12] 1921 	mov	dpl,a
      0087EB ED               [12] 1922 	mov	a,r5
      0087EC 39               [12] 1923 	addc	a, r1
      0087ED F5 83            [12] 1924 	mov	dph,a
      0087EF E0               [24] 1925 	movx	a,@dptr
      0087F0 FC               [12] 1926 	mov	r4,a
      0087F1 7D 00            [12] 1927 	mov	r5,#0x00
      0087F3 E5 38            [12] 1928 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0087F5 2A               [12] 1929 	add	a, r2
      0087F6 FA               [12] 1930 	mov	r2,a
      0087F7 E4               [12] 1931 	clr	a
      0087F8 3B               [12] 1932 	addc	a, r3
      0087F9 FB               [12] 1933 	mov	r3,a
      0087FA C0 00            [24] 1934 	push	ar0
      0087FC C0 01            [24] 1935 	push	ar1
      0087FE 8B 01            [24] 1936 	mov	ar1,r3
      008800 7B 00            [12] 1937 	mov	r3,#0x00
      008802 8A 82            [24] 1938 	mov	dpl, r2
      008804 89 83            [24] 1939 	mov	dph, r1
      008806 8B F0            [24] 1940 	mov	b, r3
      008808 12 40 31         [24] 1941 	lcall	_eeprom_read_byte
      00880B AB 82            [24] 1942 	mov	r3, dpl
      00880D 7A 00            [12] 1943 	mov	r2,#0x00
      00880F EB               [12] 1944 	mov	a,r3
      008810 12 43 2F         [24] 1945 	lcall	_ak820_outline_0138
                                   1946 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008813 BD 00 05         [24] 1947 	cjne	r5,#0x00,00212$
      008816 BC 7C 02         [24] 1948 	cjne	r4,#0x7c,00212$
      008819 80 06            [24] 1949 	sjmp	00213$
      00881B                       1950 00212$:
      00881B D0 01            [24] 1951 	pop	ar1
      00881D D0 00            [24] 1952 	pop	ar0
      00881F 80 0D            [24] 1953 	sjmp	00113$
      008821                       1954 00213$:
      008821 D0 01            [24] 1955 	pop	ar1
      008823 D0 00            [24] 1956 	pop	ar0
                                   1957 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008825 1E               [12] 1958 	dec	r6
      008826 BE FF 01         [24] 1959 	cjne	r6,#0xff,00214$
      008829 1F               [12] 1960 	dec	r7
      00882A                       1961 00214$:
      00882A EE               [12] 1962 	mov	a,r6
      00882B 12 8C D8         [24] 1963 	lcall	_ak820_outline_0125
      00882E                       1964 00113$:
                                   1965 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      00882E E5 38            [12] 1966 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008830 14               [12] 1967 	dec	a
      008831 90 0B 18         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008834 F0               [24] 1969 	movx	@dptr,a
      008835                       1970 00115$:
                                   1971 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008835 90 0B 17         [24] 1972 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008838 E0               [24] 1973 	movx	a,@dptr
      008839 90 0B 19         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      00883C F0               [24] 1975 	movx	@dptr,a
      00883D                       1976 00122$:
      00883D 90 0B 19         [24] 1977 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008840 E0               [24] 1978 	movx	a,@dptr
      008841 FF               [12] 1979 	mov	r7,a
      008842 90 0B 18         [24] 1980 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008845 E0               [24] 1981 	movx	a,@dptr
      008846 FE               [12] 1982 	mov	r6,a
      008847 C3               [12] 1983 	clr	c
      008848 EF               [12] 1984 	mov	a,r7
      008849 9E               [12] 1985 	subb	a,r6
      00884A 50 48            [24] 1986 	jnc	00120$
                                   1987 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      00884C EF               [12] 1988 	mov	a,r7
      00884D 28               [12] 1989 	add	a, r0
      00884E FD               [12] 1990 	mov	r5,a
      00884F E4               [12] 1991 	clr	a
      008850 39               [12] 1992 	addc	a, r1
      008851 FE               [12] 1993 	mov	r6,a
      008852 12 47 C5         [24] 1994 	lcall	_ak820_outline_0072
      008855 7B 00            [12] 1995 	mov	r3,#0x00
      008857 8C 35            [24] 1996 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008859 8B 34            [24] 1997 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      00885B 8F 02            [24] 1998 	mov	ar2,r7
      00885D 7F 00            [12] 1999 	mov	r7,#0x00
      00885F 74 01            [12] 2000 	mov	a,#0x01
      008861 2A               [12] 2001 	add	a, r2
      008862 FB               [12] 2002 	mov	r3,a
      008863 E4               [12] 2003 	clr	a
      008864 3F               [12] 2004 	addc	a, r7
      008865 FC               [12] 2005 	mov	r4,a
      008866 EB               [12] 2006 	mov	a,r3
      008867 28               [12] 2007 	add	a, r0
      008868 F5 82            [12] 2008 	mov	dpl,a
      00886A EC               [12] 2009 	mov	a,r4
      00886B 39               [12] 2010 	addc	a, r1
      00886C F5 83            [12] 2011 	mov	dph,a
      00886E E0               [24] 2012 	movx	a,@dptr
      00886F FC               [12] 2013 	mov	r4,a
      008870 7B 00            [12] 2014 	mov	r3,#0x00
      008872 E5 35            [12] 2015 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008874 42 03            [12] 2016 	orl	ar3,a
                                   2017 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008876 BC 00 12         [24] 2018 	cjne	r4,#0x00,00123$
      008879 BB 7C 0F         [24] 2019 	cjne	r3,#0x7c,00123$
                                   2020 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      00887C 12 38 5D         [24] 2021 	lcall	_ak820_outline_0130
      00887F 74 FF            [12] 2022 	mov	a,#0xff
      008881 F0               [24] 2023 	movx	@dptr,a
                                   2024 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008882 0A               [12] 2025 	inc	r2
      008883 BA 00 01         [24] 2026 	cjne	r2,#0x00,00218$
      008886 0F               [12] 2027 	inc	r7
      008887                       2028 00218$:
      008887 EA               [12] 2029 	mov	a,r2
      008888 12 8C D8         [24] 2030 	lcall	_ak820_outline_0125
      00888B                       2031 00123$:
                                   2032 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      00888B 90 0B 19         [24] 2033 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      00888E E0               [24] 2034 	movx	a,@dptr
      00888F 24 02            [12] 2035 	add	a,#0x02
      008891 F0               [24] 2036 	movx	@dptr,a
      008892 80 A9            [24] 2037 	sjmp	00122$
      008894                       2038 00120$:
                                   2039 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008894 90 0B 15         [24] 2040 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008897 12 37 F9         [24] 2041 	lcall	_ak820_outline_0049
      00889A 74 40            [12] 2042 	mov	a,#0x40
      00889C 12 43 29         [24] 2043 	lcall	_ak820_outline_0132
      00889F 90 05 8A         [24] 2044 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0088A2 12 47 BF         [24] 2045 	lcall	_ak820_outline_0056
      0088A5 E4               [12] 2046 	clr	a
      0088A6 A3               [24] 2047 	inc	dptr
      0088A7 F0               [24] 2048 	movx	@dptr,a
      0088A8 90 05 8D         [24] 2049 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0088AB E5 36            [12] 2050 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0088AD F0               [24] 2051 	movx	@dptr,a
      0088AE E5 37            [12] 2052 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0088B0 A3               [24] 2053 	inc	dptr
      0088B1 F0               [24] 2054 	movx	@dptr,a
      0088B2 12 38 6E         [24] 2055 	lcall	_ak820_outline_0150
                                   2056 ;	quantum/dynamic_keymap.c:584: }
      0088B5 02 40 F8         [24] 2057 	ljmp	_ak820_eeprom_write_block_xdata
                                   2058 ;------------------------------------------------------------
                                   2059 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2060 ;------------------------------------------------------------
                                   2061 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2062 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2063 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2064 ;------------------------------------------------------------
                                   2065 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2066 ;	-----------------------------------------
                                   2067 ;	 function keycode_at_keymap_location
                                   2068 ;	-----------------------------------------
      0088B8                       2069 _keycode_at_keymap_location:
      0088B8 E5 82            [12] 2070 	mov	a,dpl
      0088BA 90 0B 1C         [24] 2071 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      0088BD F0               [24] 2072 	movx	@dptr,a
                                   2073 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      0088BE E0               [24] 2074 	movx	a,@dptr
      0088BF FF               [12] 2075 	mov	r7,a
      0088C0 BF 06 00         [24] 2076 	cjne	r7,#0x06,00128$
      0088C3                       2077 00128$:
      0088C3 50 23            [24] 2078 	jnc	00102$
      0088C5 90 0B 1A         [24] 2079 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0088C8 E0               [24] 2080 	movx	a,@dptr
      0088C9 FE               [12] 2081 	mov	r6,a
      0088CA BE 10 00         [24] 2082 	cjne	r6,#0x10,00130$
      0088CD                       2083 00130$:
      0088CD 50 19            [24] 2084 	jnc	00102$
      0088CF 90 0B 1B         [24] 2085 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0088D2 E0               [24] 2086 	movx	a,@dptr
      0088D3 FD               [12] 2087 	mov	r5,a
      0088D4 BD 08 00         [24] 2088 	cjne	r5,#0x08,00132$
      0088D7                       2089 00132$:
      0088D7 50 0F            [24] 2090 	jnc	00102$
                                   2091 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      0088D9 90 0A CE         [24] 2092 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0088DC EE               [12] 2093 	mov	a,r6
      0088DD F0               [24] 2094 	movx	@dptr,a
      0088DE 90 0A CF         [24] 2095 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0088E1 ED               [12] 2096 	mov	a,r5
      0088E2 F0               [24] 2097 	movx	@dptr,a
      0088E3 8F 82            [24] 2098 	mov	dpl, r7
      0088E5 02 82 47         [24] 2099 	ljmp	_dynamic_keymap_get_keycode
      0088E8                       2100 00102$:
                                   2101 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      0088E8 90 00 00         [24] 2102 	mov	dptr,#0x0000
                                   2103 ;	quantum/dynamic_keymap.c:591: }
      0088EB 22               [24] 2104 	ret
                                   2105 ;------------------------------------------------------------
                                   2106 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2107 ;------------------------------------------------------------
                                   2108 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2109 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2110 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2111 ;------------------------------------------------------------
                                   2112 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2113 ;	-----------------------------------------
                                   2114 ;	 function keycode_at_encodermap_location
                                   2115 ;	-----------------------------------------
      0088EC                       2116 _keycode_at_encodermap_location:
      0088EC E5 82            [12] 2117 	mov	a,dpl
      0088EE 90 0B 1F         [24] 2118 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      0088F1 F0               [24] 2119 	movx	@dptr,a
                                   2120 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      0088F2 E0               [24] 2121 	movx	a,@dptr
      0088F3 FF               [12] 2122 	mov	r7,a
      0088F4 BF 06 00         [24] 2123 	cjne	r7,#0x06,00120$
      0088F7                       2124 00120$:
      0088F7 50 1E            [24] 2125 	jnc	00102$
      0088F9 90 0B 1D         [24] 2126 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0088FC E0               [24] 2127 	movx	a,@dptr
      0088FD FE               [12] 2128 	mov	r6,a
      0088FE BE 01 00         [24] 2129 	cjne	r6,#0x01,00122$
      008901                       2130 00122$:
      008901 50 14            [24] 2131 	jnc	00102$
                                   2132 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008903 90 0B 1E         [24] 2133 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008906 E0               [24] 2134 	movx	a,@dptr
      008907 FE               [12] 2135 	mov	r6,a
      008908 90 0A D8         [24] 2136 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00890B E4               [12] 2137 	clr	a
      00890C F0               [24] 2138 	movx	@dptr,a
      00890D 90 0A D9         [24] 2139 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008910 EE               [12] 2140 	mov	a,r6
      008911 F0               [24] 2141 	movx	@dptr,a
      008912 8F 82            [24] 2142 	mov	dpl, r7
      008914 02 83 08         [24] 2143 	ljmp	_dynamic_keymap_get_encoder
      008917                       2144 00102$:
                                   2145 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008917 90 00 00         [24] 2146 	mov	dptr,#0x0000
                                   2147 ;	quantum/dynamic_keymap.c:599: }
      00891A 22               [24] 2148 	ret
                                   2149 ;------------------------------------------------------------
                                   2150 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2151 ;------------------------------------------------------------
                                   2152 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2153 ;	-----------------------------------------
                                   2154 ;	 function dynamic_keymap_macro_get_count
                                   2155 ;	-----------------------------------------
      00891B                       2156 _dynamic_keymap_macro_get_count:
                                   2157 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      00891B 75 82 10         [24] 2158 	mov	dpl, #0x10
                                   2159 ;	quantum/dynamic_keymap.c:604: }
      00891E 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2163 ;------------------------------------------------------------
                                   2164 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2165 ;	-----------------------------------------
                                   2166 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2167 ;	-----------------------------------------
      00891F                       2168 _dynamic_keymap_macro_get_buffer_size:
                                   2169 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      00891F 90 20 00         [24] 2170 	mov	dptr,#0x2000
                                   2171 ;	quantum/dynamic_keymap.c:608: }
      008922 22               [24] 2172 	ret
                                   2173 ;------------------------------------------------------------
                                   2174 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2175 ;------------------------------------------------------------
                                   2176 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2177 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2178 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2179 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2180 ;------------------------------------------------------------
                                   2181 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2182 ;	-----------------------------------------
                                   2183 ;	 function dynamic_keymap_macro_get_buffer
                                   2184 ;	-----------------------------------------
      008923                       2185 _dynamic_keymap_macro_get_buffer:
      008923 12 38 47         [24] 2186 	lcall	_ak820_outline_0103
      008926 90 0B 25         [24] 2187 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008929 12 38 42         [24] 2188 	lcall	_ak820_outline_0102
                                   2189 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      00892C 12 2B 2B         [24] 2190 	lcall	_ak820_macro_length
      00892F 12 43 24         [24] 2191 	lcall	_ak820_outline_0129
      008932 90 0B 25         [24] 2192 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008935 12 38 18         [24] 2193 	lcall	_ak820_outline_0057
      008938 90 0B 20         [24] 2194 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00893B E0               [24] 2195 	movx	a,@dptr
      00893C F5 39            [12] 2196 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      00893E A3               [24] 2197 	inc	dptr
      00893F E0               [24] 2198 	movx	a,@dptr
      008940 F5 3A            [12] 2199 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008942 90 0B 22         [24] 2200 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008945 12 38 2A         [24] 2201 	lcall	_ak820_outline_0094
      008948 A3               [24] 2202 	inc	dptr
      008949 E0               [24] 2203 	movx	a,@dptr
      00894A FB               [12] 2204 	mov	r3,a
      00894B 90 0A FD         [24] 2205 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00894E 12 47 BF         [24] 2206 	lcall	_ak820_outline_0056
      008951 90 0A FF         [24] 2207 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008954 12 38 1E         [24] 2208 	lcall	_ak820_outline_0068
      008957 90 0B 01         [24] 2209 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00895A E5 39            [12] 2210 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      00895C F0               [24] 2211 	movx	@dptr,a
      00895D E5 3A            [12] 2212 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      00895F A3               [24] 2213 	inc	dptr
      008960 F0               [24] 2214 	movx	@dptr,a
      008961 90 0B 03         [24] 2215 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008964 E8               [12] 2216 	mov	a,r0
      008965 F0               [24] 2217 	movx	@dptr,a
      008966 E9               [12] 2218 	mov	a,r1
      008967 A3               [24] 2219 	inc	dptr
      008968 F0               [24] 2220 	movx	@dptr,a
      008969 EB               [12] 2221 	mov	a,r3
      00896A A3               [24] 2222 	inc	dptr
      00896B F0               [24] 2223 	movx	@dptr,a
      00896C 90 08 00         [24] 2224 	mov	dptr,#0x0800
                                   2225 ;	quantum/dynamic_keymap.c:635: }
      00896F 02 86 30         [24] 2226 	ljmp	_ak820_dynamic_read_buffer
                                   2227 ;------------------------------------------------------------
                                   2228 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2229 ;------------------------------------------------------------
                                   2230 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2231 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2232 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2233 ;------------------------------------------------------------
                                   2234 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2235 ;	-----------------------------------------
                                   2236 ;	 function dynamic_keymap_macro_set_buffer
                                   2237 ;	-----------------------------------------
      008972                       2238 _dynamic_keymap_macro_set_buffer:
      008972 12 38 47         [24] 2239 	lcall	_ak820_outline_0103
      008975 90 0B 2C         [24] 2240 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008978 12 38 42         [24] 2241 	lcall	_ak820_outline_0102
                                   2242 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      00897B 90 0B 2C         [24] 2243 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      00897E 12 37 F9         [24] 2244 	lcall	_ak820_outline_0049
      008981 90 0B 27         [24] 2245 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008984 12 38 18         [24] 2246 	lcall	_ak820_outline_0057
      008987 90 0B 29         [24] 2247 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00898A E0               [24] 2248 	movx	a,@dptr
      00898B F9               [12] 2249 	mov	r1,a
      00898C A3               [24] 2250 	inc	dptr
      00898D 12 43 01         [24] 2251 	lcall	_ak820_outline_0080
      008990 90 05 10         [24] 2252 	mov	dptr,#_ak820_macro_write_PARM_2
      008993 12 38 1E         [24] 2253 	lcall	_ak820_outline_0068
      008996 90 05 12         [24] 2254 	mov	dptr,#_ak820_macro_write_PARM_3
      008999 E9               [12] 2255 	mov	a,r1
      00899A 12 4E 5D         [24] 2256 	lcall	_ak820_outline_0149
      00899D 12 42 F4         [24] 2257 	lcall	_ak820_outline_0058
                                   2258 ;	quantum/dynamic_keymap.c:640: }
      0089A0 02 2B 45         [24] 2259 	ljmp	_ak820_macro_write
                                   2260 ;------------------------------------------------------------
                                   2261 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2262 ;------------------------------------------------------------
                                   2263 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2264 ;	-----------------------------------------
                                   2265 ;	 function dynamic_keymap_macro_reset
                                   2266 ;	-----------------------------------------
      0089A3                       2267 _dynamic_keymap_macro_reset:
                                   2268 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2269 ;	quantum/dynamic_keymap.c:666: }
      0089A3 02 2E 64         [24] 2270 	ljmp	_ak820_macro_reset
                                   2271 ;------------------------------------------------------------
                                   2272 ;Allocation info for local variables in function 'decode_keycode'
                                   2273 ;------------------------------------------------------------
                                   2274 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2275 ;------------------------------------------------------------
                                   2276 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2277 ;	-----------------------------------------
                                   2278 ;	 function decode_keycode
                                   2279 ;	-----------------------------------------
      0089A6                       2280 _decode_keycode:
      0089A6 12 38 47         [24] 2281 	lcall	_ak820_outline_0103
      0089A9 90 0B 2E         [24] 2282 	mov	dptr,#_decode_keycode_kc_10000_454
      0089AC 12 38 42         [24] 2283 	lcall	_ak820_outline_0102
                                   2284 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      0089AF 90 0B 2E         [24] 2285 	mov	dptr,#_decode_keycode_kc_10000_454
      0089B2 12 37 C0         [24] 2286 	lcall	_ak820_outline_0007
      0089B5 C3               [12] 2287 	clr	c
      0089B6 E4               [12] 2288 	clr	a
      0089B7 9C               [12] 2289 	subb	a,r4
      0089B8 74 FF            [12] 2290 	mov	a,#0xff
      0089BA 9D               [12] 2291 	subb	a,r5
      0089BB 50 08            [24] 2292 	jnc	00102$
                                   2293 ;	free result
                                   2294 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      0089BD 8C 05            [24] 2295 	mov	ar5,r4
      0089BF 7C 00            [12] 2296 	mov	r4,#0x00
      0089C1 12 38 53         [24] 2297 	lcall	_ak820_outline_0117
      0089C4 22               [24] 2298 	ret
      0089C5                       2299 00102$:
                                   2300 ;	quantum/dynamic_keymap.c:672: return kc;
      0089C5 12 43 1F         [24] 2301 	lcall	_ak820_outline_0116
                                   2302 ;	quantum/dynamic_keymap.c:673: }
      0089C8 22               [24] 2303 	ret
                                   2304 ;------------------------------------------------------------
                                   2305 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2306 ;------------------------------------------------------------
                                   2307 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2308 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2309 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2310 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2311 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2312 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2313 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2314 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2315 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2316 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2317 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2318 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2319 ;------------------------------------------------------------
                                   2320 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2321 ;	-----------------------------------------
                                   2322 ;	 function dynamic_keymap_macro_send
                                   2323 ;	-----------------------------------------
      0089C9                       2324 _dynamic_keymap_macro_send:
      0089C9 E5 82            [12] 2325 	mov	a,dpl
      0089CB 90 0B 30         [24] 2326 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0089CE F0               [24] 2327 	movx	@dptr,a
                                   2328 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0089CF 90 0B 31         [24] 2329 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      0089D2 E0               [24] 2330 	movx	a,@dptr
      0089D3 60 01            [24] 2331 	jz	00102$
      0089D5 22               [24] 2332 	ret
      0089D6                       2333 00102$:
                                   2334 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0089D6 90 0B 30         [24] 2335 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0089D9 E0               [24] 2336 	movx	a,@dptr
      0089DA FF               [12] 2337 	mov	r7,a
      0089DB BF 10 00         [24] 2338 	cjne	r7,#0x10,00422$
      0089DE                       2339 00422$:
      0089DE 40 01            [24] 2340 	jc	00104$
                                   2341 ;	quantum/dynamic_keymap.c:683: return;
      0089E0 22               [24] 2342 	ret
      0089E1                       2343 00104$:
                                   2344 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      0089E1 C0 07            [24] 2345 	push	ar7
      0089E3 12 2A F2         [24] 2346 	lcall	_ak820_macro_ready
      0089E6 E5 82            [12] 2347 	mov	a, dpl
      0089E8 D0 07            [24] 2348 	pop	ar7
      0089EA 70 01            [24] 2349 	jnz	00106$
      0089EC 22               [24] 2350 	ret
      0089ED                       2351 00106$:
                                   2352 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0089ED 90 0B 32         [24] 2353 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0089F0 E4               [12] 2354 	clr	a
      0089F1 F0               [24] 2355 	movx	@dptr,a
      0089F2 74 08            [12] 2356 	mov	a,#0x08
      0089F4 A3               [24] 2357 	inc	dptr
      0089F5 F0               [24] 2358 	movx	@dptr,a
                                   2359 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0089F6 C0 07            [24] 2360 	push	ar7
      0089F8 12 2B 2B         [24] 2361 	lcall	_ak820_macro_length
      0089FB AD 82            [24] 2362 	mov	r5, dpl
      0089FD AE 83            [24] 2363 	mov	r6, dph
      0089FF D0 07            [24] 2364 	pop	ar7
      008A01 74 08            [12] 2365 	mov	a,#0x08
      008A03 2E               [12] 2366 	add	a, r6
      008A04 FE               [12] 2367 	mov	r6,a
                                   2368 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008A05 7B 00            [12] 2369 	mov	r3,#0x00
      008A07 7C 08            [12] 2370 	mov	r4,#0x08
      008A09                       2371 00111$:
      008A09 EF               [12] 2372 	mov	a,r7
      008A0A 60 31            [24] 2373 	jz	00113$
                                   2374 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008A0C EB               [12] 2375 	mov	a,r3
      008A0D B5 05 05         [24] 2376 	cjne	a,ar5,00108$
      008A10 EC               [12] 2377 	mov	a,r4
      008A11 B5 06 01         [24] 2378 	cjne	a,ar6,00108$
                                   2379 ;	quantum/dynamic_keymap.c:717: return;
      008A14 22               [24] 2380 	ret
      008A15                       2381 00108$:
                                   2382 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008A15 8B 01            [24] 2383 	mov	ar1,r3
      008A17 8C 02            [24] 2384 	mov	ar2,r4
      008A19 8A 00            [24] 2385 	mov	ar0,r2
      008A1B 7A 00            [12] 2386 	mov	r2,#0x00
      008A1D 89 82            [24] 2387 	mov	dpl, r1
      008A1F 88 83            [24] 2388 	mov	dph, r0
      008A21 8A F0            [24] 2389 	mov	b, r2
      008A23 12 40 31         [24] 2390 	lcall	_eeprom_read_byte
      008A26 E5 82            [12] 2391 	mov	a, dpl
      008A28 70 06            [24] 2392 	jnz	00110$
                                   2393 ;	quantum/dynamic_keymap.c:720: --id;
      008A2A 1F               [12] 2394 	dec	r7
      008A2B 90 0B 30         [24] 2395 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008A2E EF               [12] 2396 	mov	a,r7
      008A2F F0               [24] 2397 	movx	@dptr,a
      008A30                       2398 00110$:
                                   2399 ;	quantum/dynamic_keymap.c:722: ++p;
      008A30 0B               [12] 2400 	inc	r3
      008A31 BB 00 01         [24] 2401 	cjne	r3,#0x00,00429$
      008A34 0C               [12] 2402 	inc	r4
      008A35                       2403 00429$:
      008A35 90 0B 32         [24] 2404 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A38 12 38 24         [24] 2405 	lcall	_ak820_outline_0074
      008A3B 80 CC            [24] 2406 	sjmp	00111$
      008A3D                       2407 00113$:
                                   2408 ;	quantum/dynamic_keymap.c:728: sending = true;
      008A3D 90 0B 31         [24] 2409 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008A40 74 01            [12] 2410 	mov	a,#0x01
      008A42 F0               [24] 2411 	movx	@dptr,a
                                   2412 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008A43 12 8C F0         [24] 2413 	lcall	_ak820_outline_0159
      008A46 90 09 7A         [24] 2414 	mov	dptr,#_ak820_macro_cancelled
      008A49 F0               [24] 2415 	movx	@dptr,a
                                   2416 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008A4A 90 0B 34         [24] 2417 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008A4D F0               [24] 2418 	movx	@dptr,a
      008A4E 90 0B 35         [24] 2419 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008A51 F0               [24] 2420 	movx	@dptr,a
      008A52 90 0B 36         [24] 2421 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008A55 F0               [24] 2422 	movx	@dptr,a
      008A56 90 0B 37         [24] 2423 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008A59 F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	quantum/dynamic_keymap.c:738: while (p < end
      008A5A                       2426 00167$:
                                   2427 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008A5A 90 0B 32         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A5D E0               [24] 2429 	movx	a,@dptr
      008A5E FC               [12] 2430 	mov	r4,a
      008A5F A3               [24] 2431 	inc	dptr
      008A60 E0               [24] 2432 	movx	a,@dptr
      008A61 FF               [12] 2433 	mov	r7,a
      008A62 C3               [12] 2434 	clr	c
      008A63 EC               [12] 2435 	mov	a,r4
      008A64 9D               [12] 2436 	subb	a,r5
      008A65 EF               [12] 2437 	mov	a,r7
      008A66 9E               [12] 2438 	subb	a,r6
      008A67 40 03            [24] 2439 	jc	00430$
      008A69 02 8C 7E         [24] 2440 	ljmp	00169$
      008A6C                       2441 00430$:
      008A6C 90 09 7A         [24] 2442 	mov	dptr,#_ak820_macro_cancelled
      008A6F E0               [24] 2443 	movx	a,@dptr
      008A70 60 03            [24] 2444 	jz	00431$
      008A72 02 8C 7E         [24] 2445 	ljmp	00169$
      008A75                       2446 00431$:
                                   2447 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008A75 8C 02            [24] 2448 	mov	ar2,r4
      008A77 8F 03            [24] 2449 	mov	ar3,r7
      008A79 90 0B 32         [24] 2450 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008A7C 74 01            [12] 2451 	mov	a,#0x01
      008A7E 2C               [12] 2452 	add	a, r4
      008A7F F0               [24] 2453 	movx	@dptr,a
      008A80 E4               [12] 2454 	clr	a
      008A81 3F               [12] 2455 	addc	a, r7
      008A82 A3               [24] 2456 	inc	dptr
      008A83 F0               [24] 2457 	movx	@dptr,a
      008A84 7F 00            [12] 2458 	mov	r7,#0x00
      008A86 12 43 35         [24] 2459 	lcall	_ak820_outline_0139
      008A89 8F F0            [24] 2460 	mov	b, r7
      008A8B 12 40 31         [24] 2461 	lcall	_eeprom_read_byte
      008A8E AF 82            [24] 2462 	mov	r7, dpl
      008A90 90 0B 34         [24] 2463 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008A93 EF               [12] 2464 	mov	a,r7
      008A94 F0               [24] 2465 	movx	@dptr,a
                                   2466 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008A95 90 0B 35         [24] 2467 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008A98 E4               [12] 2468 	clr	a
      008A99 F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008A9A 90 0B 34         [24] 2471 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008A9D E0               [24] 2472 	movx	a,@dptr
      008A9E 70 03            [24] 2473 	jnz	00432$
      008AA0 02 8C 7E         [24] 2474 	ljmp	00169$
      008AA3                       2475 00432$:
                                   2476 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008AA3 90 0B 34         [24] 2477 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008AA6 E0               [24] 2478 	movx	a,@dptr
      008AA7 FF               [12] 2479 	mov	r7,a
      008AA8 BF 01 02         [24] 2480 	cjne	r7,#0x01,00433$
      008AAB 80 03            [24] 2481 	sjmp	00434$
      008AAD                       2482 00433$:
      008AAD 02 8C 60         [24] 2483 	ljmp	00164$
      008AB0                       2484 00434$:
                                   2485 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008AB0 12 8C 86         [24] 2486 	lcall	_ak820_outline_0000
      008AB3 12 40 31         [24] 2487 	lcall	_eeprom_read_byte
      008AB6 AF 82            [24] 2488 	mov	r7, dpl
      008AB8 90 0B 35         [24] 2489 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008ABB EF               [12] 2490 	mov	a,r7
      008ABC F0               [24] 2491 	movx	@dptr,a
                                   2492 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008ABD EF               [12] 2493 	mov	a,r7
      008ABE 70 03            [24] 2494 	jnz	00435$
      008AC0 02 8C 7E         [24] 2495 	ljmp	00169$
      008AC3                       2496 00435$:
                                   2497 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008AC3 12 8C BE         [24] 2498 	lcall	_ak820_outline_0087
      008AC6 BF 01 02         [24] 2499 	cjne	r7,#0x01,00436$
      008AC9 80 13            [24] 2500 	sjmp	00151$
      008ACB                       2501 00436$:
      008ACB 12 8C BE         [24] 2502 	lcall	_ak820_outline_0087
      008ACE BF 02 02         [24] 2503 	cjne	r7,#0x02,00437$
      008AD1 80 0B            [24] 2504 	sjmp	00151$
      008AD3                       2505 00437$:
      008AD3 12 8C BE         [24] 2506 	lcall	_ak820_outline_0087
      008AD6 BF 03 02         [24] 2507 	cjne	r7,#0x03,00438$
      008AD9 80 03            [24] 2508 	sjmp	00439$
      008ADB                       2509 00438$:
      008ADB 02 8B 3F         [24] 2510 	ljmp	00152$
      008ADE                       2511 00439$:
      008ADE                       2512 00151$:
                                   2513 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008ADE 12 8C 86         [24] 2514 	lcall	_ak820_outline_0000
      008AE1 12 40 31         [24] 2515 	lcall	_eeprom_read_byte
      008AE4 12 8D 08         [24] 2516 	lcall	_ak820_outline_0177
                                   2517 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008AE7 70 03            [24] 2518 	jnz	00440$
      008AE9 02 8A 5A         [24] 2519 	ljmp	00167$
      008AEC                       2520 00440$:
                                   2521 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008AEC 12 8C BE         [24] 2522 	lcall	_ak820_outline_0087
      008AEF BF 01 03         [24] 2523 	cjne	r7,#0x01,00441$
      008AF2 D3               [12] 2524 	setb	c
      008AF3 80 01            [24] 2525 	sjmp	00442$
      008AF5                       2526 00441$:
      008AF5 C3               [12] 2527 	clr	c
      008AF6                       2528 00442$:
      008AF6 92 22            [24] 2529 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008AF8 90 09 79         [24] 2530 	mov	dptr,#_ak820_macro_primitive
      008AFB B3               [12] 2531 	cpl	c
      008AFC E4               [12] 2532 	clr	a
      008AFD 33               [12] 2533 	rlc	a
      008AFE F0               [24] 2534 	movx	@dptr,a
                                   2535 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008AFF 12 8C BE         [24] 2536 	lcall	_ak820_outline_0087
      008B02 BF 01 10         [24] 2537 	cjne	r7,#0x01,00122$
      008B05 12 8C E9         [24] 2538 	lcall	_ak820_outline_0145
      008B08 C0 06            [24] 2539 	push	ar6
      008B0A C0 05            [24] 2540 	push	ar5
      008B0C 12 74 C7         [24] 2541 	lcall	_tap_code
      008B0F D0 05            [24] 2542 	pop	ar5
      008B11 D0 06            [24] 2543 	pop	ar6
      008B13 80 24            [24] 2544 	sjmp	00123$
      008B15                       2545 00122$:
                                   2546 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008B15 12 8C BE         [24] 2547 	lcall	_ak820_outline_0087
      008B18 BF 02 10         [24] 2548 	cjne	r7,#0x02,00119$
      008B1B 12 8C E9         [24] 2549 	lcall	_ak820_outline_0145
      008B1E C0 06            [24] 2550 	push	ar6
      008B20 C0 05            [24] 2551 	push	ar5
      008B22 12 73 C1         [24] 2552 	lcall	_register_code
      008B25 D0 05            [24] 2553 	pop	ar5
      008B27 D0 06            [24] 2554 	pop	ar6
      008B29 80 0E            [24] 2555 	sjmp	00123$
      008B2B                       2556 00119$:
                                   2557 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008B2B 12 8C E9         [24] 2558 	lcall	_ak820_outline_0145
      008B2E C0 06            [24] 2559 	push	ar6
      008B30 C0 05            [24] 2560 	push	ar5
      008B32 12 74 2E         [24] 2561 	lcall	_unregister_code
      008B35 D0 05            [24] 2562 	pop	ar5
      008B37 D0 06            [24] 2563 	pop	ar6
      008B39                       2564 00123$:
                                   2565 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008B39 12 8C F0         [24] 2566 	lcall	_ak820_outline_0159
      008B3C 02 8A 5A         [24] 2567 	ljmp	00167$
      008B3F                       2568 00152$:
                                   2569 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008B3F 12 8C BE         [24] 2570 	lcall	_ak820_outline_0087
      008B42 BF 05 02         [24] 2571 	cjne	r7,#0x05,00447$
      008B45 80 13            [24] 2572 	sjmp	00146$
      008B47                       2573 00447$:
      008B47 12 8C BE         [24] 2574 	lcall	_ak820_outline_0087
      008B4A BF 06 02         [24] 2575 	cjne	r7,#0x06,00448$
      008B4D 80 0B            [24] 2576 	sjmp	00146$
      008B4F                       2577 00448$:
      008B4F 12 8C BE         [24] 2578 	lcall	_ak820_outline_0087
      008B52 BF 07 02         [24] 2579 	cjne	r7,#0x07,00449$
      008B55 80 03            [24] 2580 	sjmp	00450$
      008B57                       2581 00449$:
      008B57 02 8C 00         [24] 2582 	ljmp	00147$
      008B5A                       2583 00450$:
      008B5A                       2584 00146$:
                                   2585 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B5A 12 8C 86         [24] 2586 	lcall	_ak820_outline_0000
      008B5D 12 40 31         [24] 2587 	lcall	_eeprom_read_byte
      008B60 12 8D 08         [24] 2588 	lcall	_ak820_outline_0177
                                   2589 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008B63 70 03            [24] 2590 	jnz	00451$
      008B65 02 8A 5A         [24] 2591 	ljmp	00167$
      008B68                       2592 00451$:
                                   2593 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B68 12 8C 86         [24] 2594 	lcall	_ak820_outline_0000
      008B6B 12 40 31         [24] 2595 	lcall	_eeprom_read_byte
      008B6E AF 82            [24] 2596 	mov	r7, dpl
      008B70 90 0B 37         [24] 2597 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008B73 EF               [12] 2598 	mov	a,r7
      008B74 F0               [24] 2599 	movx	@dptr,a
                                   2600 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008B75 EF               [12] 2601 	mov	a,r7
      008B76 70 03            [24] 2602 	jnz	00452$
      008B78 02 8A 5A         [24] 2603 	ljmp	00167$
      008B7B                       2604 00452$:
                                   2605 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008B7B 90 0B 36         [24] 2606 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008B7E E0               [24] 2607 	movx	a,@dptr
      008B7F FF               [12] 2608 	mov	r7,a
      008B80 90 0B 37         [24] 2609 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008B83 E0               [24] 2610 	movx	a,@dptr
      008B84 FB               [12] 2611 	mov	r3,a
      008B85 E4               [12] 2612 	clr	a
      008B86 FC               [12] 2613 	mov	r4,a
      008B87 FA               [12] 2614 	mov	r2,a
      008B88 EF               [12] 2615 	mov	a,r7
      008B89 42 04            [12] 2616 	orl	ar4,a
      008B8B EA               [12] 2617 	mov	a,r2
      008B8C 42 03            [12] 2618 	orl	ar3,a
                                   2619 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008B8E 12 43 55         [24] 2620 	lcall	_ak820_outline_0178
      008B91 C0 06            [24] 2621 	push	ar6
      008B93 C0 05            [24] 2622 	push	ar5
      008B95 12 89 A6         [24] 2623 	lcall	_decode_keycode
      008B98 AC 82            [24] 2624 	mov	r4, dpl
      008B9A AF 83            [24] 2625 	mov	r7, dph
      008B9C D0 05            [24] 2626 	pop	ar5
      008B9E D0 06            [24] 2627 	pop	ar6
                                   2628 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008BA0 90 0B 35         [24] 2629 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008BA3 E0               [24] 2630 	movx	a,@dptr
      008BA4 FB               [12] 2631 	mov	r3,a
      008BA5 BB 05 03         [24] 2632 	cjne	r3,#0x05,00453$
      008BA8 D3               [12] 2633 	setb	c
      008BA9 80 01            [24] 2634 	sjmp	00454$
      008BAB                       2635 00453$:
      008BAB C3               [12] 2636 	clr	c
      008BAC                       2637 00454$:
      008BAC 92 22            [24] 2638 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008BAE 90 09 79         [24] 2639 	mov	dptr,#_ak820_macro_primitive
      008BB1 B3               [12] 2640 	cpl	c
      008BB2 E4               [12] 2641 	clr	a
      008BB3 33               [12] 2642 	rlc	a
      008BB4 F0               [24] 2643 	movx	@dptr,a
                                   2644 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008BB5 90 0B 35         [24] 2645 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008BB8 E0               [24] 2646 	movx	a,@dptr
      008BB9 FB               [12] 2647 	mov	r3,a
      008BBA BB 05 02         [24] 2648 	cjne	r3,#0x05,00455$
      008BBD 80 0A            [24] 2649 	sjmp	00126$
      008BBF                       2650 00455$:
      008BBF BB 06 02         [24] 2651 	cjne	r3,#0x06,00456$
      008BC2 80 16            [24] 2652 	sjmp	00127$
      008BC4                       2653 00456$:
                                   2654 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008BC4 BB 07 33         [24] 2655 	cjne	r3,#0x07,00129$
      008BC7 80 22            [24] 2656 	sjmp	00128$
      008BC9                       2657 00126$:
                                   2658 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008BC9 8C 82            [24] 2659 	mov	dpl, r4
      008BCB 8F 83            [24] 2660 	mov	dph, r7
      008BCD C0 06            [24] 2661 	push	ar6
      008BCF C0 05            [24] 2662 	push	ar5
      008BD1 12 AE CB         [24] 2663 	lcall	_vial_keycode_tap
      008BD4 D0 05            [24] 2664 	pop	ar5
      008BD6 D0 06            [24] 2665 	pop	ar6
                                   2666 ;	quantum/dynamic_keymap.c:795: break;
                                   2667 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008BD8 80 20            [24] 2668 	sjmp	00129$
      008BDA                       2669 00127$:
                                   2670 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008BDA 8C 82            [24] 2671 	mov	dpl, r4
      008BDC 8F 83            [24] 2672 	mov	dph, r7
      008BDE C0 06            [24] 2673 	push	ar6
      008BE0 C0 05            [24] 2674 	push	ar5
      008BE2 12 AE 00         [24] 2675 	lcall	_vial_keycode_down
      008BE5 D0 05            [24] 2676 	pop	ar5
      008BE7 D0 06            [24] 2677 	pop	ar6
                                   2678 ;	quantum/dynamic_keymap.c:798: break;
                                   2679 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008BE9 80 0F            [24] 2680 	sjmp	00129$
      008BEB                       2681 00128$:
                                   2682 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008BEB 8C 82            [24] 2683 	mov	dpl, r4
      008BED 8F 83            [24] 2684 	mov	dph, r7
      008BEF C0 06            [24] 2685 	push	ar6
      008BF1 C0 05            [24] 2686 	push	ar5
      008BF3 12 AE 66         [24] 2687 	lcall	_vial_keycode_up
      008BF6 D0 05            [24] 2688 	pop	ar5
      008BF8 D0 06            [24] 2689 	pop	ar6
                                   2690 ;	quantum/dynamic_keymap.c:802: }
      008BFA                       2691 00129$:
                                   2692 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008BFA 12 8C F0         [24] 2693 	lcall	_ak820_outline_0159
      008BFD 02 8A 5A         [24] 2694 	ljmp	00167$
      008C00                       2695 00147$:
                                   2696 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008C00 12 8C BE         [24] 2697 	lcall	_ak820_outline_0087
      008C03 BF 04 02         [24] 2698 	cjne	r7,#0x04,00458$
      008C06 80 03            [24] 2699 	sjmp	00459$
      008C08                       2700 00458$:
      008C08 02 8A 5A         [24] 2701 	ljmp	00167$
      008C0B                       2702 00459$:
                                   2703 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C0B 12 8C 86         [24] 2704 	lcall	_ak820_outline_0000
      008C0E 12 40 31         [24] 2705 	lcall	_eeprom_read_byte
      008C11 AF 82            [24] 2706 	mov	r7, dpl
                                   2707 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008C13 90 0B 32         [24] 2708 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C16 12 38 3C         [24] 2709 	lcall	_ak820_outline_0098
      008C19 90 0B 32         [24] 2710 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C1C 74 01            [12] 2711 	mov	a,#0x01
      008C1E 2B               [12] 2712 	add	a, r3
      008C1F F0               [24] 2713 	movx	@dptr,a
      008C20 E4               [12] 2714 	clr	a
      008C21 3C               [12] 2715 	addc	a, r4
      008C22 A3               [24] 2716 	inc	dptr
      008C23 F0               [24] 2717 	movx	@dptr,a
      008C24 7A 00            [12] 2718 	mov	r2,#0x00
      008C26 12 33 FC         [24] 2719 	lcall	_ak820_outline_0120
      008C29 8A F0            [24] 2720 	mov	b, r2
      008C2B 12 40 31         [24] 2721 	lcall	_eeprom_read_byte
      008C2E AC 82            [24] 2722 	mov	r4, dpl
                                   2723 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008C30 EF               [12] 2724 	mov	a,r7
      008C31 60 4B            [24] 2725 	jz	00169$
      008C33 EC               [12] 2726 	mov	a,r4
      008C34 60 48            [24] 2727 	jz	00169$
                                   2728 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008C36 1F               [12] 2729 	dec	r7
      008C37 1C               [12] 2730 	dec	r4
      008C38 EC               [12] 2731 	mov	a,r4
      008C39 75 F0 FF         [24] 2732 	mov	b,#0xff
      008C3C A4               [48] 2733 	mul	ab
      008C3D FC               [12] 2734 	mov	r4,a
      008C3E AB F0            [24] 2735 	mov	r3,b
      008C40 7A 00            [12] 2736 	mov	r2,#0x00
      008C42 EC               [12] 2737 	mov	a,r4
      008C43 2F               [12] 2738 	add	a, r7
      008C44 FC               [12] 2739 	mov	r4,a
      008C45 EB               [12] 2740 	mov	a,r3
      008C46 3A               [12] 2741 	addc	a, r2
      008C47 FB               [12] 2742 	mov	r3,a
                                   2743 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008C48                       2744 00141$:
      008C48 8C 02            [24] 2745 	mov	ar2,r4
      008C4A 8B 07            [24] 2746 	mov	ar7,r3
      008C4C 1C               [12] 2747 	dec	r4
      008C4D BC FF 01         [24] 2748 	cjne	r4,#0xff,00462$
      008C50 1B               [12] 2749 	dec	r3
      008C51                       2750 00462$:
      008C51 EA               [12] 2751 	mov	a,r2
      008C52 4F               [12] 2752 	orl	a,r7
      008C53 70 03            [24] 2753 	jnz	00463$
      008C55 02 8A 5A         [24] 2754 	ljmp	00167$
      008C58                       2755 00463$:
      008C58 90 00 01         [24] 2756 	mov	dptr,#0x0001
      008C5B 12 57 E6         [24] 2757 	lcall	_mDelaymS
      008C5E 80 E8            [24] 2758 	sjmp	00141$
      008C60                       2759 00164$:
                                   2760 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008C60 90 0B 34         [24] 2761 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008C63 E0               [24] 2762 	movx	a,@dptr
      008C64 FF               [12] 2763 	mov	r7,a
      008C65 BF 80 00         [24] 2764 	cjne	r7,#0x80,00464$
      008C68                       2765 00464$:
      008C68 50 14            [24] 2766 	jnc	00169$
                                   2767 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008C6A 90 0B 34         [24] 2768 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008C6D E0               [24] 2769 	movx	a,@dptr
      008C6E F5 82            [12] 2770 	mov	dpl,a
      008C70 C0 06            [24] 2771 	push	ar6
      008C72 C0 05            [24] 2772 	push	ar5
      008C74 12 A1 66         [24] 2773 	lcall	_send_char
      008C77 D0 05            [24] 2774 	pop	ar5
      008C79 D0 06            [24] 2775 	pop	ar6
                                   2776 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008C7B 02 8A 5A         [24] 2777 	ljmp	00167$
      008C7E                       2778 00169$:
                                   2779 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      008C7E 12 8C F0         [24] 2780 	lcall	_ak820_outline_0159
                                   2781 ;	quantum/dynamic_keymap.c:837: sending = false;
      008C81 90 0B 31         [24] 2782 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008C84 F0               [24] 2783 	movx	@dptr,a
                                   2784 ;	quantum/dynamic_keymap.c:839: }
      008C85 22               [24] 2785 	ret
                                   2786 	.area CSEG    (CODE)
                                   2787 	.area CONST   (CODE)
                                   2788 	.area XINIT   (CODE)
                                   2789 	.area CABS    (ABS,CODE)
                                   2790 
                                   2791 ; Experimental exact instruction outlining.
                                   2792 	.globl _ak820_outline_0000
                                   2793 	.globl _ak820_outline_0004
                                   2794 	.globl _ak820_outline_0007
                                   2795 	.globl _ak820_outline_0011
                                   2796 	.globl _ak820_outline_0019
                                   2797 	.globl _ak820_outline_0024
                                   2798 	.globl _ak820_outline_0042
                                   2799 	.globl _ak820_outline_0049
                                   2800 	.globl _ak820_outline_0056
                                   2801 	.globl _ak820_outline_0057
                                   2802 	.globl _ak820_outline_0058
                                   2803 	.globl _ak820_outline_0068
                                   2804 	.globl _ak820_outline_0072
                                   2805 	.globl _ak820_outline_0074
                                   2806 	.globl _ak820_outline_0076
                                   2807 	.globl _ak820_outline_0080
                                   2808 	.globl _ak820_outline_0087
                                   2809 	.globl _ak820_outline_0093
                                   2810 	.globl _ak820_outline_0094
                                   2811 	.globl _ak820_outline_0095
                                   2812 	.globl _ak820_outline_0098
                                   2813 	.globl _ak820_outline_0102
                                   2814 	.globl _ak820_outline_0103
                                   2815 	.globl _ak820_outline_0111
                                   2816 	.globl _ak820_outline_0116
                                   2817 	.globl _ak820_outline_0117
                                   2818 	.globl _ak820_outline_0120
                                   2819 	.globl _ak820_outline_0121
                                   2820 	.globl _ak820_outline_0125
                                   2821 	.globl _ak820_outline_0129
                                   2822 	.globl _ak820_outline_0130
                                   2823 	.globl _ak820_outline_0131
                                   2824 	.globl _ak820_outline_0132
                                   2825 	.globl _ak820_outline_0138
                                   2826 	.globl _ak820_outline_0139
                                   2827 	.globl _ak820_outline_0143
                                   2828 	.globl _ak820_outline_0145
                                   2829 	.globl _ak820_outline_0149
                                   2830 	.globl _ak820_outline_0150
                                   2831 	.globl _ak820_outline_0151
                                   2832 	.globl _ak820_outline_0154
                                   2833 	.globl _ak820_outline_0159
                                   2834 	.globl _ak820_outline_0164
                                   2835 	.globl _ak820_outline_0173
                                   2836 	.globl _ak820_outline_0174
                                   2837 	.globl _ak820_outline_0177
                                   2838 	.globl _ak820_outline_0178
                                   2839 
                                   2840 	.area CSEG (CODE)
                                   2841 ; function ak820_outline_0000
      008C86                       2842 _ak820_outline_0000:
      008C86 90 0B 32         [24] 2843 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C89 E0               [24] 2844 	movx	a,@dptr
      008C8A FC               [12] 2845 	mov	r4,a
      008C8B A3               [24] 2846 	inc	dptr
      008C8C E0               [24] 2847 	movx	a,@dptr
      008C8D FF               [12] 2848 	mov	r7,a
      008C8E 90 0B 32         [24] 2849 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008C91 74 01            [12] 2850 	mov	a,#0x01
      008C93 2C               [12] 2851 	add	a,r4
      008C94 F0               [24] 2852 	movx	@dptr,a
      008C95 E4               [12] 2853 	clr	a
      008C96 3F               [12] 2854 	addc	a,r7
      008C97 A3               [24] 2855 	inc	dptr
      008C98 F0               [24] 2856 	movx	@dptr,a
      008C99 7B 00            [12] 2857 	mov	r3,#0x00
      008C9B 8C 82            [24] 2858 	mov	dpl,r4
      008C9D 8F 83            [24] 2859 	mov	dph,r7
      008C9F 8B F0            [24] 2860 	mov	b,r3
      008CA1 22               [24] 2861 	ret
                                   2862 
                                   2863 	.area CSEG (CODE)
                                   2864 ; function ak820_outline_0024
      008CA2                       2865 _ak820_outline_0024:
      008CA2 2D               [12] 2866 	add	a,r5
      008CA3 F9               [12] 2867 	mov	r1,a
      008CA4 E4               [12] 2868 	clr	a
      008CA5 3E               [12] 2869 	addc	a,r6
      008CA6 FA               [12] 2870 	mov	r2,a
      008CA7 8F 03            [24] 2871 	mov	ar3,r7
      008CA9 89 82            [24] 2872 	mov	dpl,r1
      008CAB 8A 83            [24] 2873 	mov	dph,r2
      008CAD 8B F0            [24] 2874 	mov	b,r3
      008CAF 22               [24] 2875 	ret
                                   2876 
                                   2877 	.area CSEG (CODE)
                                   2878 ; function ak820_outline_0076
      008CB0                       2879 _ak820_outline_0076:
      008CB0 ED               [12] 2880 	mov	a,r5
      008CB1 75 F0 0A         [24] 2881 	mov	b,#0x0a
      008CB4 A4               [48] 2882 	mul	ab
      008CB5 24 58            [12] 2883 	add	a,#0x58
      008CB7 FC               [12] 2884 	mov	r4,a
      008CB8 74 06            [12] 2885 	mov	a,#0x06
      008CBA 35 F0            [12] 2886 	addc	a,b
      008CBC FD               [12] 2887 	mov	r5,a
      008CBD 22               [24] 2888 	ret
                                   2889 
                                   2890 	.area CSEG (CODE)
                                   2891 ; function ak820_outline_0087
      008CBE                       2892 _ak820_outline_0087:
      008CBE 90 0B 35         [24] 2893 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      008CC1 E0               [24] 2894 	movx	a,@dptr
      008CC2 FF               [12] 2895 	mov	r7,a
      008CC3 22               [24] 2896 	ret
                                   2897 
                                   2898 	.area CSEG (CODE)
                                   2899 ; function ak820_outline_0093
      008CC4                       2900 _ak820_outline_0093:
      008CC4 90 0A CB         [24] 2901 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008CC7 EE               [12] 2902 	mov	a,r6
      008CC8 F0               [24] 2903 	movx	@dptr,a
      008CC9 90 0A CC         [24] 2904 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008CCC ED               [12] 2905 	mov	a,r5
      008CCD F0               [24] 2906 	movx	@dptr,a
      008CCE 8F 82            [24] 2907 	mov	dpl,r7
      008CD0 22               [24] 2908 	ret
                                   2909 
                                   2910 	.area CSEG (CODE)
                                   2911 ; function ak820_outline_0111
      008CD1                       2912 _ak820_outline_0111:
      008CD1 AD 82            [24] 2913 	mov	r5,dpl
      008CD3 AE 83            [24] 2914 	mov	r6,dph
      008CD5 AF F0            [24] 2915 	mov	r7,b
      008CD7 22               [24] 2916 	ret
                                   2917 
                                   2918 	.area CSEG (CODE)
                                   2919 ; function ak820_outline_0125
      008CD8                       2920 _ak820_outline_0125:
      008CD8 28               [12] 2921 	add	a,r0
      008CD9 F5 82            [12] 2922 	mov	dpl,a
      008CDB EF               [12] 2923 	mov	a,r7
      008CDC 39               [12] 2924 	addc	a,r1
      008CDD F5 83            [12] 2925 	mov	dph,a
      008CDF 74 FF            [12] 2926 	mov	a,#0xff
      008CE1 F0               [24] 2927 	movx	@dptr,a
      008CE2 22               [24] 2928 	ret
                                   2929 
                                   2930 	.area CSEG (CODE)
                                   2931 ; function ak820_outline_0131
      008CE3                       2932 _ak820_outline_0131:
      008CE3 2D               [12] 2933 	add	a,r5
      008CE4 F9               [12] 2934 	mov	r1,a
      008CE5 E4               [12] 2935 	clr	a
      008CE6 3E               [12] 2936 	addc	a,r6
      008CE7 FA               [12] 2937 	mov	r2,a
      008CE8 22               [24] 2938 	ret
                                   2939 
                                   2940 	.area CSEG (CODE)
                                   2941 ; function ak820_outline_0145
      008CE9                       2942 _ak820_outline_0145:
      008CE9 90 0B 36         [24] 2943 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008CEC E0               [24] 2944 	movx	a,@dptr
      008CED F5 82            [12] 2945 	mov	dpl,a
      008CEF 22               [24] 2946 	ret
                                   2947 
                                   2948 	.area CSEG (CODE)
                                   2949 ; function ak820_outline_0159
      008CF0                       2950 _ak820_outline_0159:
      008CF0 90 09 79         [24] 2951 	mov	dptr,#_ak820_macro_primitive
      008CF3 E4               [12] 2952 	clr	a
      008CF4 F0               [24] 2953 	movx	@dptr,a
      008CF5 22               [24] 2954 	ret
                                   2955 
                                   2956 	.area CSEG (CODE)
                                   2957 ; function ak820_outline_0173
      008CF6                       2958 _ak820_outline_0173:
      008CF6 90 0A DB         [24] 2959 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008CF9 E4               [12] 2960 	clr	a
      008CFA F0               [24] 2961 	movx	@dptr,a
      008CFB 90 0A DC         [24] 2962 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008CFE 22               [24] 2963 	ret
                                   2964 
                                   2965 	.area CSEG (CODE)
                                   2966 ; function ak820_outline_0174
      008CFF                       2967 _ak820_outline_0174:
      008CFF 90 0B 91         [24] 2968 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008D02 E4               [12] 2969 	clr	a
      008D03 F0               [24] 2970 	movx	@dptr,a
      008D04 90 0B 92         [24] 2971 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008D07 22               [24] 2972 	ret
                                   2973 
                                   2974 	.area CSEG (CODE)
                                   2975 ; function ak820_outline_0177
      008D08                       2976 _ak820_outline_0177:
      008D08 AF 82            [24] 2977 	mov	r7,dpl
      008D0A 90 0B 36         [24] 2978 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008D0D EF               [12] 2979 	mov	a,r7
      008D0E F0               [24] 2980 	movx	@dptr,a
      008D0F EF               [12] 2981 	mov	a,r7
      008D10 22               [24] 2982 	ret
