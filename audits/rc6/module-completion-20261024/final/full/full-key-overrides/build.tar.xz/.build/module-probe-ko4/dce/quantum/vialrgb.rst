                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004E                        535 _fast_set_leds_sloc0_1_0:
      00004E                        536 	.ds 2
      000050                        537 _fast_set_leds_sloc1_1_0:
      000050                        538 	.ds 2
      000052                        539 _vialrgb_get_value_sloc0_1_0:
      000052                        540 	.ds 2
      000054                        541 _vialrgb_get_value_sloc1_1_0:
      000054                        542 	.ds 2
      000056                        543 _vialrgb_set_value_sloc0_1_0:
      000056                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000D0C                        569 _g_direct_mode_colors::
      000D0C                        570 	.ds 246
      000E02                        571 _get_supported_PARM_2:
      000E02                        572 	.ds 1
      000E03                        573 _get_supported_args_10000_255:
      000E03                        574 	.ds 2
      000E05                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000E05                        576 	.ds 2
      000E07                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000E07                        578 	.ds 2
      000E09                        579 _set_mode_mode_10000_275:
      000E09                        580 	.ds 2
      000E0B                        581 _get_matrix_pos_for_led_PARM_2:
      000E0B                        582 	.ds 2
      000E0D                        583 _get_matrix_pos_for_led_led_10000_280:
      000E0D                        584 	.ds 2
      000E0F                        585 _fast_set_leds_PARM_2:
      000E0F                        586 	.ds 1
      000E10                        587 _fast_set_leds_args_10000_282:
      000E10                        588 	.ds 2
      000E12                        589 _fast_set_leds_first_index_10001_285:
      000E12                        590 	.ds 2
      000E14                        591 _fast_set_leds_num_leds_10001_285:
      000E14                        592 	.ds 1
      000E15                        593 _vialrgb_get_value_PARM_2:
      000E15                        594 	.ds 1
      000E16                        595 _vialrgb_get_value_data_10000_291:
      000E16                        596 	.ds 3
      000E19                        597 _vialrgb_set_value_PARM_2:
      000E19                        598 	.ds 1
      000E1A                        599 _vialrgb_set_value_data_10000_302:
      000E1A                        600 	.ds 3
      000E1D                        601 _vialrgb_save_PARM_2:
      000E1D                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B818                        654 _get_supported:
      00B818 12 38 42         [24]  655 	lcall	_ak820_outline_0108
      00B81B 90 0E 03         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B81E 12 38 47         [24]  657 	lcall	_ak820_outline_0109
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B821 90 0E 03         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B824 12 37 BA         [24]  660 	lcall	_ak820_outline_0006
      00B827 E0               [24]  661 	movx	a,@dptr
      00B828 FD               [12]  662 	mov	r5,a
      00B829 7C 00            [12]  663 	mov	r4,#0x00
      00B82B 12 38 36         [24]  664 	lcall	_ak820_outline_0105
      00B82E E0               [24]  665 	movx	a,@dptr
      00B82F FA               [12]  666 	mov	r2,a
      00B830 E4               [12]  667 	clr	a
      00B831 12 48 4E         [24]  668 	lcall	_ak820_outline_0148
                                    669 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B834 90 0E 02         [24]  670 	mov	dptr,#_get_supported_PARM_2
      00B837 E0               [24]  671 	movx	a,@dptr
      00B838 FB               [12]  672 	mov	r3,a
      00B839 7A 00            [12]  673 	mov	r2,#0x00
      00B83B                        674 00107$:
      00B83B C3               [12]  675 	clr	c
      00B83C EA               [12]  676 	mov	a,r2
      00B83D 9B               [12]  677 	subb	a,r3
      00B83E 50 0A            [24]  678 	jnc	00101$
      00B840 EA               [12]  679 	mov	a,r2
      00B841 12 37 F1         [24]  680 	lcall	_ak820_outline_0033
      00B844 74 FF            [12]  681 	mov	a,#0xff
      00B846 F0               [24]  682 	movx	@dptr,a
      00B847 0A               [12]  683 	inc	r2
      00B848 80 F1            [24]  684 	sjmp	00107$
      00B84A                        685 00101$:
                                    686 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B84A 8D 06            [24]  687 	mov	ar6,r5
      00B84C 8C 07            [24]  688 	mov	ar7,r4
      00B84E 8B 05            [24]  689 	mov	ar5,r3
      00B850 90 0E 03         [24]  690 	mov	dptr,#_get_supported_args_10000_255
      00B853 12 38 61         [24]  691 	lcall	_ak820_outline_0147
      00B856 7A 00            [12]  692 	mov	r2,#0x00
      00B858                        693 00110$:
      00B858 BA 07 00         [24]  694 	cjne	r2,#0x07,00159$
      00B85B                        695 00159$:
      00B85B 50 46            [24]  696 	jnc	00127$
                                    697 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B85D EA               [12]  698 	mov	a,r2
      00B85E 75 F0 02         [24]  699 	mov	b,#0x02
      00B861 A4               [48]  700 	mul	ab
      00B862 24 B0            [12]  701 	add	a, #_supported_modes
      00B864 F5 82            [12]  702 	mov	dpl,a
      00B866 74 C4            [12]  703 	mov	a,#(_supported_modes >> 8)
      00B868 12 5B 9A         [24]  704 	lcall	_ak820_outline_0113
      00B86B F8               [12]  705 	mov	r0,a
      00B86C 79 00            [12]  706 	mov	r1,#0x00
                                    707 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B86E C3               [12]  708 	clr	c
      00B86F EE               [12]  709 	mov	a,r6
      00B870 98               [12]  710 	subb	a,r0
      00B871 EF               [12]  711 	mov	a,r7
      00B872 99               [12]  712 	subb	a,r1
      00B873 50 2B            [24]  713 	jnc	00111$
                                    714 ;	free result
      00B875 BD 02 00         [24]  715 	cjne	r5,#0x02,00162$
      00B878                        716 00162$:
      00B878 40 26            [24]  717 	jc	00111$
                                    718 ;	quantum/vialrgb.c:49: args[0] = id;
      00B87A C0 06            [24]  719 	push	ar6
      00B87C C0 07            [24]  720 	push	ar7
      00B87E 88 07            [24]  721 	mov	ar7,r0
      00B880 12 33 FC         [24]  722 	lcall	_ak820_outline_0131
      00B883 EF               [12]  723 	mov	a,r7
      00B884 F0               [24]  724 	movx	@dptr,a
                                    725 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B885 12 33 FC         [24]  726 	lcall	_ak820_outline_0131
      00B888 A3               [24]  727 	inc	dptr
      00B889 89 00            [24]  728 	mov	ar0,r1
      00B88B E8               [12]  729 	mov	a,r0
      00B88C F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B88D 1D               [12]  732 	dec	r5
      00B88E 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B88F 74 02            [12]  735 	mov	a,#0x02
      00B891 2B               [12]  736 	add	a, r3
      00B892 FB               [12]  737 	mov	r3,a
      00B893 E4               [12]  738 	clr	a
      00B894 3C               [12]  739 	addc	a, r4
      00B895 FC               [12]  740 	mov	r4,a
      00B896 90 0E 03         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00B899 12 38 2A         [24]  742 	lcall	_ak820_outline_0086
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B89C D0 07            [24]  744 	pop	ar7
      00B89E D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B8A0                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B8A0 0A               [12]  749 	inc	r2
      00B8A1 80 B5            [24]  750 	sjmp	00110$
      00B8A3                        751 00127$:
      00B8A3 90 0E 03         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00B8A6 12 38 2A         [24]  753 	lcall	_ak820_outline_0086
                                    754 ;	quantum/vialrgb.c:55: }
      00B8A9 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00B8AA                        767 _qmk_id_to_vialrgb_id:
      00B8AA 12 38 42         [24]  768 	lcall	_ak820_outline_0108
      00B8AD 90 0E 05         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B8B0 12 38 47         [24]  770 	lcall	_ak820_outline_0109
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B8B3 90 0E 05         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B8B6 12 37 F9         [24]  773 	lcall	_ak820_outline_0056
      00B8B9 7D 00            [12]  774 	mov	r5,#0x00
      00B8BB                        775 00105$:
      00B8BB BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00B8BE                        777 00130$:
      00B8BE 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B8C0 12 BC D8         [24]  780 	lcall	_ak820_outline_0050
      00B8C3 A3               [24]  781 	inc	dptr
      00B8C4 E4               [12]  782 	clr	a
      00B8C5 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B8C6 7A 00            [12]  785 	mov	r2,#0x00
      00B8C8 B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00B8CB EA               [12]  787 	mov	a,r2
      00B8CC B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B8CF 12 33 FC         [24]  790 	lcall	_ak820_outline_0131
      00B8D2 12 BD 04         [24]  791 	lcall	_ak820_outline_0151
      00B8D5 22               [24]  792 	ret
      00B8D6                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B8D6 0D               [12]  795 	inc	r5
      00B8D7 80 E2            [24]  796 	sjmp	00105$
      00B8D9                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00B8D9 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00B8DC 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00B8DD                        813 _vialrgb_id_to_qmk_id:
      00B8DD 12 38 42         [24]  814 	lcall	_ak820_outline_0108
      00B8E0 90 0E 07         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B8E3 12 38 47         [24]  816 	lcall	_ak820_outline_0109
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B8E6 90 0E 07         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B8E9 12 37 F9         [24]  819 	lcall	_ak820_outline_0056
      00B8EC 7D 00            [12]  820 	mov	r5,#0x00
      00B8EE                        821 00105$:
      00B8EE BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00B8F1                        823 00130$:
      00B8F1 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B8F3 12 BC D8         [24]  826 	lcall	_ak820_outline_0050
      00B8F6 E4               [12]  827 	clr	a
      00B8F7 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B8F8 7A 00            [12]  830 	mov	r2,#0x00
      00B8FA B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00B8FD EA               [12]  832 	mov	a,r2
      00B8FE B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B901 12 33 FC         [24]  835 	lcall	_ak820_outline_0131
      00B904 A3               [24]  836 	inc	dptr
      00B905 12 BD 04         [24]  837 	lcall	_ak820_outline_0151
      00B908 22               [24]  838 	ret
      00B909                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B909 0D               [12]  841 	inc	r5
      00B90A 80 E2            [24]  842 	sjmp	00105$
      00B90C                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00B90C 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00B90F 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00B910                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B910 12 59 9D         [24]  857 	lcall	_rgb_matrix_is_enabled
      00B913 E5 82            [12]  858 	mov	a, dpl
      00B915 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B917 90 00 00         [24]  861 	mov	dptr,#0x0000
      00B91A 22               [24]  862 	ret
      00B91B                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B91B 12 59 A3         [24]  865 	lcall	_rgb_matrix_get_mode
      00B91E 7E 00            [12]  866 	mov	r6,#0x00
      00B920 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00B922 01 AA            [12]  869 	ajmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00B924                        879 _set_mode:
      00B924 12 38 42         [24]  880 	lcall	_ak820_outline_0108
      00B927 90 0E 09         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00B92A 12 38 47         [24]  882 	lcall	_ak820_outline_0109
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B92D 90 0E 09         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B930 12 37 F9         [24]  885 	lcall	_ak820_outline_0056
      00B933 90 0E 09         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00B936 12 71 E4         [24]  887 	lcall	_ak820_outline_0038
      00B939 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B93B 02 59 F0         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00B93E                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B93E C0 07            [24]  893 	push	ar7
      00B940 C0 06            [24]  894 	push	ar6
      00B942 12 59 DF         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00B945 D0 06            [24]  896 	pop	ar6
      00B947 D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B949 12 48 38         [24]  899 	lcall	_ak820_outline_0123
      00B94C 11 DD            [12]  900 	acall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00B94E 02 59 F9         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00B951                        914 _get_matrix_pos_for_led:
      00B951 12 38 42         [24]  915 	lcall	_ak820_outline_0108
      00B954 90 0E 0D         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B957 12 38 47         [24]  917 	lcall	_ak820_outline_0109
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B95A 90 0E 0D         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B95D 12 37 F9         [24]  920 	lcall	_ak820_outline_0056
      00B960 EE               [12]  921 	mov	a,r6
      00B961 24 B7            [12]  922 	add	a, #_ak820_rgb_slots
      00B963 F5 82            [12]  923 	mov	dpl,a
      00B965 EF               [12]  924 	mov	a,r7
      00B966 34 BE            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00B968 F5 83            [12]  926 	mov	dph,a
      00B96A E4               [12]  927 	clr	a
      00B96B 93               [24]  928 	movc	a,@a+dptr
      00B96C FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B96D 90 0E 0B         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B970 12 48 26         [24]  932 	lcall	_ak820_outline_0099
      00B973 12 85 80         [24]  933 	lcall	_ak820_outline_0170
      00B976 12 85 5D         [24]  934 	lcall	_ak820_outline_0104
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B979 12 38 5C         [24]  936 	lcall	_ak820_outline_0141
      00B97C A3               [24]  937 	inc	dptr
      00B97D 53 07 07         [24]  938 	anl	ar7,#0x07
      00B980 EF               [12]  939 	mov	a,r7
      00B981 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00B982 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00B983                        960 _fast_set_leds:
      00B983 12 38 42         [24]  961 	lcall	_ak820_outline_0108
      00B986 90 0E 10         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00B989 12 38 47         [24]  963 	lcall	_ak820_outline_0109
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B98C 90 0E 0F         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00B98F E0               [24]  966 	movx	a,@dptr
      00B990 FF               [12]  967 	mov	r7,a
      00B991 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00B994                        969 00159$:
      00B994 50 01            [24]  970 	jnc	00102$
      00B996 22               [24]  971 	ret
      00B997                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B997 90 0E 10         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00B99A 12 48 26         [24]  975 	lcall	_ak820_outline_0099
      00B99D 12 4D 59         [24]  976 	lcall	_ak820_outline_0079
      00B9A0 7B 00            [12]  977 	mov	r3,#0x00
      00B9A2 12 38 5C         [24]  978 	lcall	_ak820_outline_0141
      00B9A5 A3               [24]  979 	inc	dptr
      00B9A6 E0               [24]  980 	movx	a,@dptr
      00B9A7 FA               [12]  981 	mov	r2,a
      00B9A8 79 00            [12]  982 	mov	r1,#0x00
      00B9AA 90 0E 12         [24]  983 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B9AD E9               [12]  984 	mov	a,r1
      00B9AE 4C               [12]  985 	orl	a,r4
      00B9AF F0               [24]  986 	movx	@dptr,a
      00B9B0 EA               [12]  987 	mov	a,r2
      00B9B1 4B               [12]  988 	orl	a,r3
      00B9B2 A3               [24]  989 	inc	dptr
      00B9B3 F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B9B4 12 38 5C         [24]  992 	lcall	_ak820_outline_0141
      00B9B7 A3               [24]  993 	inc	dptr
      00B9B8 A3               [24]  994 	inc	dptr
      00B9B9 E0               [24]  995 	movx	a,@dptr
      00B9BA 90 0E 14         [24]  996 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B9BD F0               [24]  997 	movx	@dptr,a
                                    998 ;	quantum/vialrgb.c:119: length -= 3;
      00B9BE EF               [12]  999 	mov	a,r7
      00B9BF 24 FD            [12] 1000 	add	a,#0xfd
      00B9C1 90 0E 0F         [24] 1001 	mov	dptr,#_fast_set_leds_PARM_2
      00B9C4 F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:120: args += 3;
      00B9C5 90 0E 10         [24] 1004 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9C8 74 03            [12] 1005 	mov	a,#0x03
      00B9CA 2D               [12] 1006 	add	a, r5
      00B9CB F0               [24] 1007 	movx	@dptr,a
      00B9CC E4               [12] 1008 	clr	a
      00B9CD 3E               [12] 1009 	addc	a, r6
      00B9CE A3               [24] 1010 	inc	dptr
      00B9CF F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B9D0 90 0E 14         [24] 1013 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B9D3 E0               [24] 1014 	movx	a,@dptr
      00B9D4 FF               [12] 1015 	mov	r7,a
      00B9D5 75 F0 03         [24] 1016 	mov	b,#0x03
      00B9D8 A4               [48] 1017 	mul	ab
      00B9D9 FE               [12] 1018 	mov	r6,a
      00B9DA AD F0            [24] 1019 	mov	r5,b
      00B9DC 90 0E 0F         [24] 1020 	mov	dptr,#_fast_set_leds_PARM_2
      00B9DF E0               [24] 1021 	movx	a,@dptr
      00B9E0 FB               [12] 1022 	mov	r3,a
      00B9E1 7C 00            [12] 1023 	mov	r4,#0x00
      00B9E3 C3               [12] 1024 	clr	c
      00B9E4 EB               [12] 1025 	mov	a,r3
      00B9E5 9E               [12] 1026 	subb	a,r6
      00B9E6 EC               [12] 1027 	mov	a,r4
      00B9E7 9D               [12] 1028 	subb	a,r5
      00B9E8 40 13            [24] 1029 	jc	00103$
                                   1030 ;	free result
      00B9EA 90 0E 12         [24] 1031 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B9ED 12 48 26         [24] 1032 	lcall	_ak820_outline_0099
      00B9F0 8D 03            [24] 1033 	mov	ar3,r5
      00B9F2 8E 04            [24] 1034 	mov	ar4,r6
      00B9F4 C3               [12] 1035 	clr	c
      00B9F5 EB               [12] 1036 	mov	a,r3
      00B9F6 94 52            [12] 1037 	subb	a,#0x52
      00B9F8 EC               [12] 1038 	mov	a,r4
      00B9F9 94 00            [12] 1039 	subb	a,#0x00
      00B9FB 40 01            [24] 1040 	jc	00104$
      00B9FD                       1041 00103$:
      00B9FD 22               [24] 1042 	ret
      00B9FE                       1043 00104$:
                                   1044 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B9FE 74 52            [12] 1045 	mov	a,#0x52
      00BA00 C3               [12] 1046 	clr	c
      00BA01 9D               [12] 1047 	subb	a,r5
      00BA02 FB               [12] 1048 	mov	r3,a
      00BA03 E4               [12] 1049 	clr	a
      00BA04 9E               [12] 1050 	subb	a,r6
      00BA05 FC               [12] 1051 	mov	r4,a
      00BA06 7A 00            [12] 1052 	mov	r2,#0x00
      00BA08 C3               [12] 1053 	clr	c
      00BA09 EB               [12] 1054 	mov	a,r3
      00BA0A 9F               [12] 1055 	subb	a,r7
      00BA0B EC               [12] 1056 	mov	a,r4
      00BA0C 9A               [12] 1057 	subb	a,r2
      00BA0D 50 08            [24] 1058 	jnc	00127$
                                   1059 ;	free result
      00BA0F 90 0E 14         [24] 1060 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BA12 74 52            [12] 1061 	mov	a,#0x52
      00BA14 C3               [12] 1062 	clr	c
      00BA15 9D               [12] 1063 	subb	a,r5
      00BA16 F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BA17                       1066 00127$:
      00BA17 90 0E 14         [24] 1067 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BA1A E0               [24] 1068 	movx	a,@dptr
      00BA1B FF               [12] 1069 	mov	r7,a
      00BA1C 90 0E 12         [24] 1070 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BA1F 12 48 26         [24] 1071 	lcall	_ak820_outline_0099
      00BA22 7C 00            [12] 1072 	mov	r4,#0x00
      00BA24                       1073 00110$:
      00BA24 C3               [12] 1074 	clr	c
      00BA25 EC               [12] 1075 	mov	a,r4
      00BA26 9F               [12] 1076 	subb	a,r7
      00BA27 40 01            [24] 1077 	jc	00164$
      00BA29 22               [24] 1078 	ret
      00BA2A                       1079 00164$:
                                   1080 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00BA2A C0 07            [24] 1081 	push	ar7
      00BA2C 90 0E 2C         [24] 1082 	mov	dptr,#__mulint_PARM_2
      00BA2F 12 48 6E         [24] 1083 	lcall	_ak820_outline_0169
      00BA32 90 00 03         [24] 1084 	mov	dptr,#0x0003
      00BA35 C0 07            [24] 1085 	push	ar7
      00BA37 C0 06            [24] 1086 	push	ar6
      00BA39 C0 05            [24] 1087 	push	ar5
      00BA3B C0 04            [24] 1088 	push	ar4
      00BA3D D1 67            [12] 1089 	acall	__mulint
      00BA3F AA 82            [24] 1090 	mov	r2, dpl
      00BA41 AB 83            [24] 1091 	mov	r3, dph
      00BA43 D0 04            [24] 1092 	pop	ar4
      00BA45 D0 05            [24] 1093 	pop	ar5
      00BA47 D0 06            [24] 1094 	pop	ar6
      00BA49 D0 07            [24] 1095 	pop	ar7
      00BA4B 0D               [12] 1096 	inc	r5
      00BA4C BD 00 01         [24] 1097 	cjne	r5,#0x00,00165$
      00BA4F 0E               [12] 1098 	inc	r6
      00BA50                       1099 00165$:
      00BA50 EA               [12] 1100 	mov	a,r2
      00BA51 24 0C            [12] 1101 	add	a, #_g_direct_mode_colors
      00BA53 FA               [12] 1102 	mov	r2,a
      00BA54 EB               [12] 1103 	mov	a,r3
      00BA55 34 0D            [12] 1104 	addc	a, #(_g_direct_mode_colors >> 8)
      00BA57 FB               [12] 1105 	mov	r3,a
                                   1106 ;	quantum/vialrgb.c:128: color->h = *args++;
      00BA58 8A 4E            [24] 1107 	mov	_fast_set_leds_sloc0_1_0,r2
      00BA5A 8B 4F            [24] 1108 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00BA5C 12 BC EA         [24] 1109 	lcall	_ak820_outline_0085
      00BA5F F8               [12] 1110 	mov	r0,a
      00BA60 12 BC F8         [24] 1111 	lcall	_ak820_outline_0112
      00BA63 85 4E 82         [24] 1112 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BA66 85 4F 83         [24] 1113 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BA69 E8               [12] 1114 	mov	a,r0
      00BA6A F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/vialrgb.c:129: color->s = *args++;
      00BA6B 74 01            [12] 1117 	mov	a,#0x01
      00BA6D 2A               [12] 1118 	add	a, r2
      00BA6E F5 4E            [12] 1119 	mov	_fast_set_leds_sloc0_1_0,a
      00BA70 E4               [12] 1120 	clr	a
      00BA71 3B               [12] 1121 	addc	a, r3
      00BA72 F5 4F            [12] 1122 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00BA74 90 0E 10         [24] 1123 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA77 E0               [24] 1124 	movx	a,@dptr
      00BA78 F8               [12] 1125 	mov	r0,a
      00BA79 A3               [24] 1126 	inc	dptr
      00BA7A E0               [24] 1127 	movx	a,@dptr
      00BA7B FF               [12] 1128 	mov	r7,a
      00BA7C 88 82            [24] 1129 	mov	dpl,r0
      00BA7E 8F 83            [24] 1130 	mov	dph,r7
      00BA80 E0               [24] 1131 	movx	a,@dptr
      00BA81 F9               [12] 1132 	mov	r1,a
      00BA82 90 0E 10         [24] 1133 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA85 74 01            [12] 1134 	mov	a,#0x01
      00BA87 28               [12] 1135 	add	a, r0
      00BA88 F0               [24] 1136 	movx	@dptr,a
      00BA89 E4               [12] 1137 	clr	a
      00BA8A 3F               [12] 1138 	addc	a, r7
      00BA8B A3               [24] 1139 	inc	dptr
      00BA8C F0               [24] 1140 	movx	@dptr,a
      00BA8D 85 4E 82         [24] 1141 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BA90 85 4F 83         [24] 1142 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BA93 E9               [12] 1143 	mov	a,r1
      00BA94 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00BA95 12 BC EA         [24] 1146 	lcall	_ak820_outline_0085
      00BA98 F5 4E            [12] 1147 	mov	_fast_set_leds_sloc0_1_0,a
      00BA9A 12 BC F8         [24] 1148 	lcall	_ak820_outline_0112
                                   1149 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BA9D 74 02            [12] 1150 	mov	a,#0x02
      00BA9F 2A               [12] 1151 	add	a, r2
      00BAA0 F5 50            [12] 1152 	mov	_fast_set_leds_sloc1_1_0,a
      00BAA2 E4               [12] 1153 	clr	a
      00BAA3 3B               [12] 1154 	addc	a, r3
      00BAA4 F5 51            [12] 1155 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BAA6 C3               [12] 1156 	clr	c
      00BAA7 74 A0            [12] 1157 	mov	a,#0xa0
      00BAA9 95 4E            [12] 1158 	subb	a,_fast_set_leds_sloc0_1_0
      00BAAB D0 07            [24] 1159 	pop	ar7
      00BAAD 50 04            [24] 1160 	jnc	00114$
                                   1161 ;	free result
      00BAAF 7B A0            [12] 1162 	mov	r3,#0xa0
      00BAB1 80 04            [24] 1163 	sjmp	00115$
      00BAB3                       1164 00114$:
      00BAB3 AA 4E            [24] 1165 	mov	r2,_fast_set_leds_sloc0_1_0
      00BAB5 8A 03            [24] 1166 	mov	ar3,r2
      00BAB7                       1167 00115$:
      00BAB7 85 50 82         [24] 1168 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BABA 85 51 83         [24] 1169 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BABD EB               [12] 1170 	mov	a,r3
      00BABE F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BABF 0C               [12] 1173 	inc	r4
                                   1174 ;	quantum/vialrgb.c:133: }
      00BAC0 41 24            [24] 1175 	ajmp	00110$
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1178 ;------------------------------------------------------------
                                   1179 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1180 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1181 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1182 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1183 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1184 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1185 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1186 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function vialrgb_get_value
                                   1191 ;	-----------------------------------------
      00BAC2                       1192 _vialrgb_get_value:
      00BAC2 12 47 F5         [24] 1193 	lcall	_ak820_outline_0040
      00BAC5 90 0E 16         [24] 1194 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BAC8 12 37 E1         [24] 1195 	lcall	_ak820_outline_0019
                                   1196 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BACB 90 0E 15         [24] 1197 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BACE E0               [24] 1198 	movx	a,@dptr
      00BACF FF               [12] 1199 	mov	r7,a
      00BAD0 BF 20 02         [24] 1200 	cjne	r7,#0x20,00162$
      00BAD3 80 01            [24] 1201 	sjmp	00102$
      00BAD5                       1202 00162$:
      00BAD5 22               [24] 1203 	ret
      00BAD6                       1204 00102$:
                                   1205 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BAD6 90 0E 16         [24] 1206 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BAD9 12 BC C4         [24] 1207 	lcall	_ak820_outline_0048
                                   1208 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1209 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BADC BA 40 02         [24] 1210 	cjne	r2,#0x40,00163$
      00BADF 80 15            [24] 1211 	sjmp	00103$
      00BAE1                       1212 00163$:
      00BAE1 BA 41 02         [24] 1213 	cjne	r2,#0x41,00164$
      00BAE4 80 23            [24] 1214 	sjmp	00104$
      00BAE6                       1215 00164$:
      00BAE6 BA 42 02         [24] 1216 	cjne	r2,#0x42,00165$
      00BAE9 61 9A            [12] 1217 	ajmp	00105$
      00BAEB                       1218 00165$:
      00BAEB BA 43 02         [24] 1219 	cjne	r2,#0x43,00166$
      00BAEE 61 A6            [12] 1220 	ajmp	00106$
      00BAF0                       1221 00166$:
      00BAF0 BA 44 02         [24] 1222 	cjne	r2,#0x44,00167$
      00BAF3 61 B2            [12] 1223 	ajmp	00107$
      00BAF5                       1224 00167$:
      00BAF5 22               [24] 1225 	ret
                                   1226 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BAF6                       1227 00103$:
                                   1228 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BAF6 12 33 FC         [24] 1229 	lcall	_ak820_outline_0131
      00BAF9 74 01            [12] 1230 	mov	a,#0x01
      00BAFB F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BAFC 12 BC BC         [24] 1233 	lcall	_ak820_outline_0037
      00BAFF E4               [12] 1234 	clr	a
      00BB00 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BB01 12 BC BC         [24] 1237 	lcall	_ak820_outline_0037
      00BB04 A3               [24] 1238 	inc	dptr
      00BB05 74 A0            [12] 1239 	mov	a,#0xa0
      00BB07 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:147: break;
      00BB08 22               [24] 1242 	ret
                                   1243 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BB09                       1244 00104$:
                                   1245 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BB09 C0 06            [24] 1246 	push	ar6
      00BB0B C0 05            [24] 1247 	push	ar5
      00BB0D C0 04            [24] 1248 	push	ar4
      00BB0F C0 03            [24] 1249 	push	ar3
      00BB11 31 10            [12] 1250 	acall	_get_mode
      00BB13 A9 82            [24] 1251 	mov	r1, dpl
      00BB15 AA 83            [24] 1252 	mov	r2, dph
      00BB17 D0 03            [24] 1253 	pop	ar3
      00BB19 D0 04            [24] 1254 	pop	ar4
      00BB1B D0 05            [24] 1255 	pop	ar5
      00BB1D D0 06            [24] 1256 	pop	ar6
                                   1257 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BB1F 89 00            [24] 1258 	mov	ar0,r1
      00BB21 12 33 FC         [24] 1259 	lcall	_ak820_outline_0131
      00BB24 E8               [12] 1260 	mov	a,r0
      00BB25 F0               [24] 1261 	movx	@dptr,a
                                   1262 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BB26 12 BC BC         [24] 1263 	lcall	_ak820_outline_0037
      00BB29 8A 01            [24] 1264 	mov	ar1,r2
      00BB2B E9               [12] 1265 	mov	a,r1
      00BB2C F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BB2D 74 04            [12] 1268 	mov	a,#0x04
      00BB2F 12 94 7C         [24] 1269 	lcall	_ak820_outline_0142
      00BB32 C0 06            [24] 1270 	push	ar6
      00BB34 C0 05            [24] 1271 	push	ar5
      00BB36 C0 02            [24] 1272 	push	ar2
      00BB38 C0 01            [24] 1273 	push	ar1
      00BB3A 12 59 BE         [24] 1274 	lcall	_rgb_matrix_get_speed
      00BB3D A8 82            [24] 1275 	mov	r0, dpl
      00BB3F D0 01            [24] 1276 	pop	ar1
      00BB41 D0 02            [24] 1277 	pop	ar2
      00BB43 D0 05            [24] 1278 	pop	ar5
      00BB45 D0 06            [24] 1279 	pop	ar6
      00BB47 12 85 33         [24] 1280 	lcall	_ak820_outline_0068
                                   1281 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BB4A 74 05            [12] 1282 	mov	a,#0x05
      00BB4C 12 94 7C         [24] 1283 	lcall	_ak820_outline_0142
      00BB4F C0 06            [24] 1284 	push	ar6
      00BB51 C0 05            [24] 1285 	push	ar5
      00BB53 C0 02            [24] 1286 	push	ar2
      00BB55 C0 01            [24] 1287 	push	ar1
      00BB57 12 59 A9         [24] 1288 	lcall	_rgb_matrix_get_hue
      00BB5A A8 82            [24] 1289 	mov	r0, dpl
      00BB5C D0 01            [24] 1290 	pop	ar1
      00BB5E D0 02            [24] 1291 	pop	ar2
      00BB60 D0 05            [24] 1292 	pop	ar5
      00BB62 D0 06            [24] 1293 	pop	ar6
      00BB64 12 85 33         [24] 1294 	lcall	_ak820_outline_0068
                                   1295 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BB67 74 06            [12] 1296 	mov	a,#0x06
      00BB69 12 94 7C         [24] 1297 	lcall	_ak820_outline_0142
      00BB6C C0 06            [24] 1298 	push	ar6
      00BB6E C0 05            [24] 1299 	push	ar5
      00BB70 C0 02            [24] 1300 	push	ar2
      00BB72 C0 01            [24] 1301 	push	ar1
      00BB74 12 59 B0         [24] 1302 	lcall	_rgb_matrix_get_sat
      00BB77 A8 82            [24] 1303 	mov	r0, dpl
      00BB79 D0 01            [24] 1304 	pop	ar1
      00BB7B D0 02            [24] 1305 	pop	ar2
      00BB7D D0 05            [24] 1306 	pop	ar5
      00BB7F D0 06            [24] 1307 	pop	ar6
      00BB81 12 85 33         [24] 1308 	lcall	_ak820_outline_0068
                                   1309 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BB84 74 07            [12] 1310 	mov	a,#0x07
      00BB86 12 94 7C         [24] 1311 	lcall	_ak820_outline_0142
      00BB89 C0 02            [24] 1312 	push	ar2
      00BB8B C0 01            [24] 1313 	push	ar1
      00BB8D 12 59 B7         [24] 1314 	lcall	_rgb_matrix_get_val
      00BB90 A8 82            [24] 1315 	mov	r0, dpl
      00BB92 D0 01            [24] 1316 	pop	ar1
      00BB94 D0 02            [24] 1317 	pop	ar2
      00BB96 12 85 33         [24] 1318 	lcall	_ak820_outline_0068
                                   1319 ;	quantum/vialrgb.c:156: break;
      00BB99 22               [24] 1320 	ret
                                   1321 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BB9A                       1322 00105$:
                                   1323 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BB9A EF               [12] 1324 	mov	a,r7
      00BB9B 24 FE            [12] 1325 	add	a,#0xfe
      00BB9D 90 0E 02         [24] 1326 	mov	dptr,#_get_supported_PARM_2
      00BBA0 F0               [24] 1327 	movx	@dptr,a
      00BBA1 12 33 FC         [24] 1328 	lcall	_ak820_outline_0131
                                   1329 ;	quantum/vialrgb.c:160: break;
      00BBA4 01 18            [12] 1330 	ajmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BBA6                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BBA6 12 33 FC         [24] 1334 	lcall	_ak820_outline_0131
      00BBA9 74 52            [12] 1335 	mov	a,#0x52
      00BBAB F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BBAC 12 BC BC         [24] 1338 	lcall	_ak820_outline_0037
      00BBAF E4               [12] 1339 	clr	a
      00BBB0 F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00BBB1 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BBB2                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BBB2 12 33 FC         [24] 1346 	lcall	_ak820_outline_0131
      00BBB5 E0               [24] 1347 	movx	a,@dptr
      00BBB6 FF               [12] 1348 	mov	r7,a
      00BBB7 7A 00            [12] 1349 	mov	r2,#0x00
      00BBB9 74 03            [12] 1350 	mov	a,#0x03
      00BBBB 2D               [12] 1351 	add	a, r5
      00BBBC F8               [12] 1352 	mov	r0,a
      00BBBD E4               [12] 1353 	clr	a
      00BBBE 3E               [12] 1354 	addc	a, r6
      00BBBF F9               [12] 1355 	mov	r1,a
      00BBC0 C0 03            [24] 1356 	push	ar3
      00BBC2 C0 04            [24] 1357 	push	ar4
      00BBC4 12 38 6C         [24] 1358 	lcall	_ak820_outline_0162
      00BBC7 E0               [24] 1359 	movx	a,@dptr
      00BBC8 FB               [12] 1360 	mov	r3,a
      00BBC9 E4               [12] 1361 	clr	a
      00BBCA 4F               [12] 1362 	orl	a,r7
      00BBCB F5 52            [12] 1363 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BBCD EB               [12] 1364 	mov	a,r3
      00BBCE 4A               [12] 1365 	orl	a,r2
      00BBCF F5 53            [12] 1366 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1367 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BBD1 AC 52            [24] 1368 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BBD3 AF 53            [24] 1369 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BBD5 C3               [12] 1370 	clr	c
      00BBD6 EC               [12] 1371 	mov	a,r4
      00BBD7 94 52            [12] 1372 	subb	a,#0x52
      00BBD9 EF               [12] 1373 	mov	a,r7
      00BBDA 94 00            [12] 1374 	subb	a,#0x00
      00BBDC D0 04            [24] 1375 	pop	ar4
      00BBDE D0 03            [24] 1376 	pop	ar3
      00BBE0 40 01            [24] 1377 	jc	00109$
      00BBE2 22               [24] 1378 	ret
      00BBE3                       1379 00109$:
                                   1380 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BBE3 E5 52            [12] 1381 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BBE5 25 52            [12] 1382 	add	a,_vialrgb_get_value_sloc0_1_0
      00BBE7 FA               [12] 1383 	mov	r2,a
      00BBE8 E5 53            [12] 1384 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BBEA 33               [12] 1385 	rlc	a
      00BBEB FF               [12] 1386 	mov	r7,a
      00BBEC EA               [12] 1387 	mov	a,r2
      00BBED 24 71            [12] 1388 	add	a, #_ak820_led_points
      00BBEF F5 54            [12] 1389 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BBF1 EF               [12] 1390 	mov	a,r7
      00BBF2 34 C1            [12] 1391 	addc	a, #(_ak820_led_points >> 8)
      00BBF4 F5 55            [12] 1392 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BBF6 85 54 82         [24] 1393 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BBF9 85 55 83         [24] 1394 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BBFC E4               [12] 1395 	clr	a
      00BBFD 93               [24] 1396 	movc	a,@a+dptr
      00BBFE 12 33 FC         [24] 1397 	lcall	_ak820_outline_0131
      00BC01 F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BC02 85 54 82         [24] 1400 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BC05 85 55 83         [24] 1401 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BC08 A3               [24] 1402 	inc	dptr
      00BC09 E4               [12] 1403 	clr	a
      00BC0A 93               [24] 1404 	movc	a,@a+dptr
      00BC0B 12 38 6C         [24] 1405 	lcall	_ak820_outline_0162
      00BC0E F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BC0F 12 BC BC         [24] 1408 	lcall	_ak820_outline_0037
      00BC12 A3               [24] 1409 	inc	dptr
      00BC13 74 04            [12] 1410 	mov	a,#0x04
      00BC15 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BC16 90 0E 0B         [24] 1413 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BC19 04               [12] 1414 	inc	a
      00BC1A 2D               [12] 1415 	add	a, r5
      00BC1B F0               [24] 1416 	movx	@dptr,a
      00BC1C E4               [12] 1417 	clr	a
      00BC1D 3E               [12] 1418 	addc	a, r6
      00BC1E A3               [24] 1419 	inc	dptr
      00BC1F F0               [24] 1420 	movx	@dptr,a
      00BC20 85 52 82         [24] 1421 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BC23 85 53 83         [24] 1422 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1423 ;	quantum/vialrgb.c:187: }
                                   1424 ;	quantum/vialrgb.c:188: }
      00BC26 21 51            [24] 1425 	ajmp	_get_matrix_pos_for_led
                                   1426 ;------------------------------------------------------------
                                   1427 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1428 ;------------------------------------------------------------
                                   1429 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1430 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1431 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1432 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1433 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1434 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1435 ;------------------------------------------------------------
                                   1436 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1437 ;	-----------------------------------------
                                   1438 ;	 function vialrgb_set_value
                                   1439 ;	-----------------------------------------
      00BC28                       1440 _vialrgb_set_value:
      00BC28 12 47 F5         [24] 1441 	lcall	_ak820_outline_0040
      00BC2B 90 0E 1A         [24] 1442 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BC2E 12 37 E1         [24] 1443 	lcall	_ak820_outline_0019
                                   1444 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BC31 90 0E 19         [24] 1445 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BC34 E0               [24] 1446 	movx	a,@dptr
      00BC35 FF               [12] 1447 	mov	r7,a
      00BC36 BF 20 02         [24] 1448 	cjne	r7,#0x20,00129$
      00BC39 80 01            [24] 1449 	sjmp	00102$
      00BC3B                       1450 00129$:
      00BC3B 22               [24] 1451 	ret
      00BC3C                       1452 00102$:
                                   1453 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BC3C 90 0E 1A         [24] 1454 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BC3F 12 BC C4         [24] 1455 	lcall	_ak820_outline_0048
                                   1456 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1457 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BC42 BA 41 02         [24] 1458 	cjne	r2,#0x41,00130$
      00BC45 80 06            [24] 1459 	sjmp	00103$
      00BC47                       1460 00130$:
      00BC47 BA 42 02         [24] 1461 	cjne	r2,#0x42,00131$
      00BC4A 80 61            [24] 1462 	sjmp	00104$
      00BC4C                       1463 00131$:
      00BC4C 22               [24] 1464 	ret
                                   1465 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BC4D                       1466 00103$:
                                   1467 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BC4D 12 33 FC         [24] 1468 	lcall	_ak820_outline_0131
      00BC50 E0               [24] 1469 	movx	a,@dptr
      00BC51 FA               [12] 1470 	mov	r2,a
      00BC52 12 BC BC         [24] 1471 	lcall	_ak820_outline_0037
      00BC55 E0               [24] 1472 	movx	a,@dptr
      00BC56 F8               [12] 1473 	mov	r0,a
      00BC57 79 00            [12] 1474 	mov	r1,#0x00
      00BC59 88 57            [24] 1475 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BC5B 89 56            [24] 1476 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BC5D 8A 01            [24] 1477 	mov	ar1,r2
      00BC5F 7A 00            [12] 1478 	mov	r2,#0x00
      00BC61 E5 57            [12] 1479 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BC63 42 02            [12] 1480 	orl	ar2,a
                                   1481 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BC65 12 48 5E         [24] 1482 	lcall	_ak820_outline_0163
      00BC68 C0 06            [24] 1483 	push	ar6
      00BC6A C0 05            [24] 1484 	push	ar5
      00BC6C 31 24            [24] 1485 	acall	_set_mode
      00BC6E D0 05            [24] 1486 	pop	ar5
      00BC70 D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BC72 12 BC BC         [24] 1489 	lcall	_ak820_outline_0037
      00BC75 A3               [24] 1490 	inc	dptr
      00BC76 E0               [24] 1491 	movx	a,@dptr
      00BC77 F5 82            [12] 1492 	mov	dpl,a
      00BC79 C0 06            [24] 1493 	push	ar6
      00BC7B C0 05            [24] 1494 	push	ar5
      00BC7D 12 5A 8A         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00BC80 D0 05            [24] 1496 	pop	ar5
      00BC82 D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BC84 12 BC BC         [24] 1499 	lcall	_ak820_outline_0037
      00BC87 A3               [24] 1500 	inc	dptr
      00BC88 A3               [24] 1501 	inc	dptr
      00BC89 E0               [24] 1502 	movx	a,@dptr
      00BC8A F9               [12] 1503 	mov	r1,a
      00BC8B 7A 00            [12] 1504 	mov	r2,#0x00
      00BC8D 74 06            [12] 1505 	mov	a,#0x06
      00BC8F 2D               [12] 1506 	add	a, r5
      00BC90 12 40 49         [24] 1507 	lcall	_ak820_outline_0117
      00BC93 E0               [24] 1508 	movx	a,@dptr
      00BC94 F8               [12] 1509 	mov	r0,a
      00BC95 74 07            [12] 1510 	mov	a,#0x07
      00BC97 2D               [12] 1511 	add	a, r5
      00BC98 12 40 49         [24] 1512 	lcall	_ak820_outline_0117
      00BC9B E0               [24] 1513 	movx	a,@dptr
      00BC9C FE               [12] 1514 	mov	r6,a
      00BC9D 90 07 91         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BCA0 E8               [12] 1516 	mov	a,r0
      00BCA1 F0               [24] 1517 	movx	@dptr,a
      00BCA2 90 07 92         [24] 1518 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BCA5 EE               [12] 1519 	mov	a,r6
      00BCA6 F0               [24] 1520 	movx	@dptr,a
      00BCA7 12 48 5E         [24] 1521 	lcall	_ak820_outline_0163
                                   1522 ;	quantum/vialrgb.c:202: break;
                                   1523 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BCAA 02 5A 5B         [24] 1524 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BCAD                       1525 00104$:
                                   1526 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BCAD EF               [12] 1527 	mov	a,r7
      00BCAE 24 FE            [12] 1528 	add	a,#0xfe
      00BCB0 90 0E 0F         [24] 1529 	mov	dptr,#_fast_set_leds_PARM_2
      00BCB3 F0               [24] 1530 	movx	@dptr,a
      00BCB4 12 33 FC         [24] 1531 	lcall	_ak820_outline_0131
                                   1532 ;	quantum/vialrgb.c:210: }
                                   1533 ;	quantum/vialrgb.c:211: }
      00BCB7 21 83            [24] 1534 	ajmp	_fast_set_leds
                                   1535 ;------------------------------------------------------------
                                   1536 ;Allocation info for local variables in function 'vialrgb_save'
                                   1537 ;------------------------------------------------------------
                                   1538 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1539 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1540 ;------------------------------------------------------------
                                   1541 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1542 ;	-----------------------------------------
                                   1543 ;	 function vialrgb_save
                                   1544 ;	-----------------------------------------
      00BCB9                       1545 _vialrgb_save:
                                   1546 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1547 ;	quantum/vialrgb.c:218: }
      00BCB9 02 54 DB         [24] 1548 	ljmp	_eeconfig_update_rgb_matrix
                                   1549 	.area CSEG    (CODE)
                                   1550 	.area CONST   (CODE)
                                   1551 	.area CONST   (CODE)
      00C4B0                       1552 _supported_modes:
      00C4B0 00                    1553 	.db #0x00	; 0
      00C4B1 00                    1554 	.db #0x00	; 0
      00C4B2 01                    1555 	.db #0x01	; 1
      00C4B3 05                    1556 	.db #0x05	; 5
      00C4B4 02                    1557 	.db #0x02	; 2
      00C4B5 01                    1558 	.db #0x01	; 1
      00C4B6 06                    1559 	.db #0x06	; 6
      00C4B7 02                    1560 	.db #0x02	; 2
      00C4B8 0D                    1561 	.db #0x0d	; 13
      00C4B9 03                    1562 	.db #0x03	; 3
      00C4BA 0E                    1563 	.db #0x0e	; 14
      00C4BB 04                    1564 	.db #0x04	; 4
      00C4BC 1F                    1565 	.db #0x1f	; 31
      00C4BD 06                    1566 	.db #0x06	; 6
                                   1567 	.area CSEG    (CODE)
                                   1568 	.area XINIT   (CODE)
                                   1569 	.area CABS    (ABS,CODE)
                                   1570 
                                   1571 ; Experimental exact instruction outlining.
                                   1572 	.globl _ak820_outline_0006
                                   1573 	.globl _ak820_outline_0019
                                   1574 	.globl _ak820_outline_0033
                                   1575 	.globl _ak820_outline_0037
                                   1576 	.globl _ak820_outline_0038
                                   1577 	.globl _ak820_outline_0040
                                   1578 	.globl _ak820_outline_0048
                                   1579 	.globl _ak820_outline_0050
                                   1580 	.globl _ak820_outline_0056
                                   1581 	.globl _ak820_outline_0068
                                   1582 	.globl _ak820_outline_0079
                                   1583 	.globl _ak820_outline_0085
                                   1584 	.globl _ak820_outline_0086
                                   1585 	.globl _ak820_outline_0099
                                   1586 	.globl _ak820_outline_0104
                                   1587 	.globl _ak820_outline_0105
                                   1588 	.globl _ak820_outline_0108
                                   1589 	.globl _ak820_outline_0109
                                   1590 	.globl _ak820_outline_0112
                                   1591 	.globl _ak820_outline_0113
                                   1592 	.globl _ak820_outline_0117
                                   1593 	.globl _ak820_outline_0123
                                   1594 	.globl _ak820_outline_0131
                                   1595 	.globl _ak820_outline_0141
                                   1596 	.globl _ak820_outline_0142
                                   1597 	.globl _ak820_outline_0147
                                   1598 	.globl _ak820_outline_0148
                                   1599 	.globl _ak820_outline_0151
                                   1600 	.globl _ak820_outline_0162
                                   1601 	.globl _ak820_outline_0163
                                   1602 	.globl _ak820_outline_0169
                                   1603 	.globl _ak820_outline_0170
                                   1604 
                                   1605 	.area CSEG (CODE)
                                   1606 ; function ak820_outline_0037
      00BCBC                       1607 _ak820_outline_0037:
      00BCBC 8D 82            [24] 1608 	mov	dpl,r5
      00BCBE 8E 83            [24] 1609 	mov	dph,r6
      00BCC0 A3               [24] 1610 	inc	dptr
      00BCC1 A3               [24] 1611 	inc	dptr
      00BCC2 A3               [24] 1612 	inc	dptr
      00BCC3 22               [24] 1613 	ret
                                   1614 
                                   1615 	.area CSEG (CODE)
                                   1616 ; function ak820_outline_0048
      00BCC4                       1617 _ak820_outline_0048:
      00BCC4 E0               [24] 1618 	movx	a,@dptr
      00BCC5 FD               [12] 1619 	mov	r5,a
      00BCC6 A3               [24] 1620 	inc	dptr
      00BCC7 E0               [24] 1621 	movx	a,@dptr
      00BCC8 FE               [12] 1622 	mov	r6,a
      00BCC9 74 02            [12] 1623 	mov	a,#0x02
      00BCCB 2D               [12] 1624 	add	a,r5
      00BCCC FB               [12] 1625 	mov	r3,a
      00BCCD E4               [12] 1626 	clr	a
      00BCCE 3E               [12] 1627 	addc	a,r6
      00BCCF FC               [12] 1628 	mov	r4,a
      00BCD0 8D 82            [24] 1629 	mov	dpl,r5
      00BCD2 8E 83            [24] 1630 	mov	dph,r6
      00BCD4 A3               [24] 1631 	inc	dptr
      00BCD5 E0               [24] 1632 	movx	a,@dptr
      00BCD6 FA               [12] 1633 	mov	r2,a
      00BCD7 22               [24] 1634 	ret
                                   1635 
                                   1636 	.area CSEG (CODE)
                                   1637 ; function ak820_outline_0050
      00BCD8                       1638 _ak820_outline_0050:
      00BCD8 ED               [12] 1639 	mov	a,r5
      00BCD9 75 F0 02         [24] 1640 	mov	b,#0x02
      00BCDC A4               [48] 1641 	mul	ab
      00BCDD 24 B0            [12] 1642 	add	a,#_supported_modes
      00BCDF FB               [12] 1643 	mov	r3,a
      00BCE0 74 C4            [12] 1644 	mov	a,#(_supported_modes>>8)
      00BCE2 35 F0            [12] 1645 	addc	a,b
      00BCE4 FC               [12] 1646 	mov	r4,a
      00BCE5 8B 82            [24] 1647 	mov	dpl,r3
      00BCE7 8C 83            [24] 1648 	mov	dph,r4
      00BCE9 22               [24] 1649 	ret
                                   1650 
                                   1651 	.area CSEG (CODE)
                                   1652 ; function ak820_outline_0085
      00BCEA                       1653 _ak820_outline_0085:
      00BCEA 90 0E 10         [24] 1654 	mov	dptr,#_fast_set_leds_args_10000_282
      00BCED E0               [24] 1655 	movx	a,@dptr
      00BCEE F9               [12] 1656 	mov	r1,a
      00BCEF A3               [24] 1657 	inc	dptr
      00BCF0 E0               [24] 1658 	movx	a,@dptr
      00BCF1 FF               [12] 1659 	mov	r7,a
      00BCF2 89 82            [24] 1660 	mov	dpl,r1
      00BCF4 8F 83            [24] 1661 	mov	dph,r7
      00BCF6 E0               [24] 1662 	movx	a,@dptr
      00BCF7 22               [24] 1663 	ret
                                   1664 
                                   1665 	.area CSEG (CODE)
                                   1666 ; function ak820_outline_0112
      00BCF8                       1667 _ak820_outline_0112:
      00BCF8 90 0E 10         [24] 1668 	mov	dptr,#_fast_set_leds_args_10000_282
      00BCFB 74 01            [12] 1669 	mov	a,#0x01
      00BCFD 29               [12] 1670 	add	a,r1
      00BCFE F0               [24] 1671 	movx	@dptr,a
      00BCFF E4               [12] 1672 	clr	a
      00BD00 3F               [12] 1673 	addc	a,r7
      00BD01 A3               [24] 1674 	inc	dptr
      00BD02 F0               [24] 1675 	movx	@dptr,a
      00BD03 22               [24] 1676 	ret
                                   1677 
                                   1678 	.area CSEG (CODE)
                                   1679 ; function ak820_outline_0151
      00BD04                       1680 _ak820_outline_0151:
      00BD04 E4               [12] 1681 	clr	a
      00BD05 93               [24] 1682 	movc	a,@a+dptr
      00BD06 FC               [12] 1683 	mov	r4,a
      00BD07 7B 00            [12] 1684 	mov	r3,#0x00
      00BD09 8C 82            [24] 1685 	mov	dpl,r4
      00BD0B 8B 83            [24] 1686 	mov	dph,r3
      00BD0D 22               [24] 1687 	ret
