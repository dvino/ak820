                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_key_override_cancel
                                     21 	.globl _pre_process_record_quantum
                                     22 	.globl _get_record_keycode
                                     23 	.globl _repeat_key_cancel
                                     24 	.globl _clear_owned_usages
                                     25 	.globl _owned_usage_key
                                     26 	.globl _clear_owned_keys
                                     27 	.globl _del_owned_key
                                     28 	.globl _add_owned_key
                                     29 	.globl _clear_owned_mods
                                     30 	.globl _del_owned_weak_mods
                                     31 	.globl _add_owned_weak_mods
                                     32 	.globl _del_owned_mods
                                     33 	.globl _add_owned_mods
                                     34 	.globl _clear_weak_mods
                                     35 	.globl _clear_mods
                                     36 	.globl _send_keyboard_report
                                     37 	.globl _layer_hold_clear
                                     38 	.globl _layer_hold_off
                                     39 	.globl _layer_hold_on
                                     40 	.globl _ak820_resolve_key
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000018                        588 _process_action_sloc0_1_0:
      000018                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      000020                        606 _process_action_sloc1_1_0:
      000020                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      00086F                        616 _tp_buttons::
      00086F                        617 	.ds 2
      000871                        618 _action_exec_PARM_1:
      000871                        619 	.ds 6
      000877                        620 _action_exec_record_10001_634:
      000877                        621 	.ds 9
      000880                        622 _ak820_action_exec_event_10000_638:
      000880                        623 	.ds 2
      000882                        624 _ak820_action_exec_snapshot_10000_639:
      000882                        625 	.ds 6
      000888                        626 _process_record_record_argument_10000_642:
      000888                        627 	.ds 2
      00088A                        628 _process_record_handler_record_argument_10000_650:
      00088A                        629 	.ds 2
      00088C                        630 _process_record_handler_action_10000_651:
      00088C                        631 	.ds 2
      00088E                        632 _process_action_PARM_2:
      00088E                        633 	.ds 2
      000890                        634 _process_action_record_argument_10000_662:
      000890                        635 	.ds 2
      000892                        636 _process_action_on_40000_685:
      000892                        637 	.ds 1
      000893                        638 _register_code_code_10000_719:
      000893                        639 	.ds 1
      000894                        640 _unregister_code_code_10000_733:
      000894                        641 	.ds 1
      000895                        642 _tap_code_delay_PARM_2:
      000895                        643 	.ds 2
      000897                        644 _tap_code_delay_code_10000_746:
      000897                        645 	.ds 1
      000898                        646 _tap_code_code_10000_753:
      000898                        647 	.ds 1
      000899                        648 _register_mods_mods_10000_755:
      000899                        649 	.ds 1
      00089A                        650 _unregister_mods_mods_10000_759:
      00089A                        651 	.ds 1
      00089B                        652 _register_weak_mods_mods_10000_763:
      00089B                        653 	.ds 1
      00089C                        654 _unregister_weak_mods_mods_10000_767:
      00089C                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000E43                        664 _disable_action_cache::
      000E43                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      0074AB                        709 _action_exec:
                                    710 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0074AB 90 08 73         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0074AE 12 37 C3         [24]  712 	lcall	_ak820_outline_0006
      0074B1 12 35 B8         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0074B4 90 08 71         [24]  715 	mov	dptr,#_action_exec_PARM_1
      0074B7 12 49 46         [24]  716 	lcall	_ak820_tapping_before
      0074BA E5 82            [12]  717 	mov	a, dpl
      0074BC 70 01            [24]  718 	jnz	00102$
      0074BE 22               [24]  719 	ret
      0074BF                        720 00102$:
                                    721 ;	quantum/action.c:126: if (event.pressed) {
      0074BF 90 08 76         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0074C2 E0               [24]  723 	movx	a,@dptr
      0074C3 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:128: clear_weak_mods();
      0074C5 12 85 79         [24]  726 	lcall	_clear_weak_mods
      0074C8                        727 00104$:
                                    728 ;	quantum/action.c:140: record.event = event;
      0074C8 90 0E 20         [24]  729 	mov	dptr,#___memcpy_PARM_2
      0074CB 74 71            [12]  730 	mov	a,#_action_exec_PARM_1
      0074CD F0               [24]  731 	movx	@dptr,a
      0074CE 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      0074D0 12 7B 2D         [24]  733 	lcall	_ak820_outline_0055
      0074D3 12 7B 46         [24]  734 	lcall	_ak820_outline_0115
      0074D6 90 08 77         [24]  735 	mov	dptr,#_action_exec_record_10001_634
      0074D9 F5 F0            [12]  736 	mov	b,a
      0074DB 12 BE 98         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:142: record.tap.count = 0;
      0074DE 90 08 7D         [24]  739 	mov	dptr,#(_action_exec_record_10001_634 + 0x0006)
      0074E1 E0               [24]  740 	movx	a,@dptr
      0074E2 54 0F            [12]  741 	anl	a,#0x0f
      0074E4 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:147: record.keycode = 0;
      0074E5 90 08 7E         [24]  744 	mov	dptr,#(_action_exec_record_10001_634 + 0x0007)
      0074E8 12 53 F6         [24]  745 	lcall	_ak820_outline_0155
                                    746 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0074EB 90 08 7B         [24]  747 	mov	dptr,#(_action_exec_record_10001_634 + 0x0004)
      0074EE E0               [24]  748 	movx	a,@dptr
      0074EF 60 0A            [24]  749 	jz	00107$
      0074F1 90 08 77         [24]  750 	mov	dptr,#_action_exec_record_10001_634
      0074F4 12 A4 94         [24]  751 	lcall	_pre_process_record_quantum
      0074F7 E5 82            [12]  752 	mov	a, dpl
      0074F9 60 11            [24]  753 	jz	00110$
      0074FB                        754 00107$:
                                    755 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      0074FB 90 08 77         [24]  756 	mov	dptr,#_action_exec_record_10001_634
      0074FE 12 4A 3A         [24]  757 	lcall	_ak820_tapping_process
      007501 E5 82            [12]  758 	mov	a, dpl
      007503 70 01            [24]  759 	jnz	00106$
      007505 22               [24]  760 	ret
      007506                        761 00106$:
                                    762 ;	quantum/action.c:185: process_record(&record);
      007506 90 08 77         [24]  763 	mov	dptr,#_action_exec_record_10001_634
                                    764 ;	quantum/action.c:200: }
      007509 02 75 4A         [24]  765 	ljmp	_process_record
      00750C                        766 00110$:
      00750C 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'ak820_action_exec'
                                    770 ;------------------------------------------------------------
                                    771 ;event         Allocated with name '_ak820_action_exec_event_10000_638'
                                    772 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_639'
                                    773 ;------------------------------------------------------------
                                    774 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function ak820_action_exec
                                    777 ;	-----------------------------------------
      00750D                        778 _ak820_action_exec:
      00750D 12 38 4B         [24]  779 	lcall	_ak820_outline_0108
      007510 90 08 80         [24]  780 	mov	dptr,#_ak820_action_exec_event_10000_638
      007513 12 38 50         [24]  781 	lcall	_ak820_outline_0109
                                    782 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007516 90 08 80         [24]  783 	mov	dptr,#_ak820_action_exec_event_10000_638
      007519 12 38 19         [24]  784 	lcall	_ak820_outline_0063
      00751C 90 0E 20         [24]  785 	mov	dptr,#___memcpy_PARM_2
      00751F ED               [12]  786 	mov	a,r5
      007520 12 37 EA         [24]  787 	lcall	_ak820_outline_0019
      007523 90 0E 23         [24]  788 	mov	dptr,#___memcpy_PARM_3
      007526 12 7B 46         [24]  789 	lcall	_ak820_outline_0115
      007529 90 08 82         [24]  790 	mov	dptr,#_ak820_action_exec_snapshot_10000_639
      00752C F5 F0            [12]  791 	mov	b,a
      00752E 12 BE 98         [24]  792 	lcall	___memcpy
                                    793 ;	quantum/action.c:207: action_exec(snapshot);
      007531 90 0E 20         [24]  794 	mov	dptr,#___memcpy_PARM_2
      007534 74 82            [12]  795 	mov	a,#_ak820_action_exec_snapshot_10000_639
      007536 F0               [24]  796 	movx	@dptr,a
      007537 74 08            [12]  797 	mov	a,#(_ak820_action_exec_snapshot_10000_639 >> 8)
      007539 12 7B 2D         [24]  798 	lcall	_ak820_outline_0055
      00753C 12 7B 46         [24]  799 	lcall	_ak820_outline_0115
      00753F 90 08 71         [24]  800 	mov	dptr,#_action_exec_PARM_1
      007542 F5 F0            [12]  801 	mov	b,a
      007544 12 BE 98         [24]  802 	lcall	___memcpy
                                    803 ;	quantum/action.c:208: }
      007547 02 74 AB         [24]  804 	ljmp	_action_exec
                                    805 ;------------------------------------------------------------
                                    806 ;Allocation info for local variables in function 'process_record_nocache'
                                    807 ;------------------------------------------------------------
                                    808 ;record        Allocated with name '_process_record_nocache_record_10000_640'
                                    809 ;------------------------------------------------------------
                                    810 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function process_record
                                    813 ;	-----------------------------------------
      00754A                        814 _process_record:
      00754A 12 38 4B         [24]  815 	lcall	_ak820_outline_0108
      00754D 90 08 88         [24]  816 	mov	dptr,#_process_record_record_argument_10000_642
      007550 12 38 50         [24]  817 	lcall	_ak820_outline_0109
                                    818 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007553 90 08 88         [24]  819 	mov	dptr,#_process_record_record_argument_10000_642
      007556 12 38 02         [24]  820 	lcall	_ak820_outline_0056
                                    821 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      007559 74 04            [12]  822 	mov	a,#0x04
      00755B 12 3F F4         [24]  823 	lcall	_ak820_outline_0009
      00755E 70 01            [24]  824 	jnz	00102$
                                    825 ;	quantum/action.c:354: return;
      007560 22               [24]  826 	ret
      007561                        827 00102$:
                                    828 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007561 8E 04            [24]  829 	mov	ar4,r6
      007563 8F 05            [24]  830 	mov	ar5,r7
      007565 90 0E 20         [24]  831 	mov	dptr,#___memcpy_PARM_2
      007568 EC               [12]  832 	mov	a,r4
      007569 F0               [24]  833 	movx	@dptr,a
      00756A ED               [12]  834 	mov	a,r5
      00756B 12 7B 2D         [24]  835 	lcall	_ak820_outline_0055
      00756E 12 53 EF         [24]  836 	lcall	_ak820_outline_0114
      007571 90 06 85         [24]  837 	mov	dptr,#_ak820_tapping_source_PARM_1
      007574 F5 F0            [12]  838 	mov	b,a
      007576 C0 07            [24]  839 	push	ar7
      007578 C0 06            [24]  840 	push	ar6
      00757A 12 BE 98         [24]  841 	lcall	___memcpy
      00757D 12 48 82         [24]  842 	lcall	_ak820_tapping_source
      007580 AD 82            [24]  843 	mov	r5, dpl
      007582 D0 06            [24]  844 	pop	ar6
      007584 D0 07            [24]  845 	pop	ar7
                                    846 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007586 12 47 EC         [24]  847 	lcall	_ak820_outline_0012
      007589 E0               [24]  848 	movx	a,@dptr
      00758A FC               [12]  849 	mov	r4,a
                                    850 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      00758B 74 07            [12]  851 	mov	a,#0x07
      00758D 2E               [12]  852 	add	a, r6
      00758E FA               [12]  853 	mov	r2,a
      00758F E4               [12]  854 	clr	a
      007590 3F               [12]  855 	addc	a, r7
      007591 FB               [12]  856 	mov	r3,a
      007592 90 0C 6C         [24]  857 	mov	dptr,#_get_record_keycode_PARM_2
      007595 12 4D 55         [24]  858 	lcall	_ak820_outline_0060
      007598 C0 07            [24]  859 	push	ar7
      00759A C0 06            [24]  860 	push	ar6
      00759C C0 05            [24]  861 	push	ar5
      00759E C0 04            [24]  862 	push	ar4
      0075A0 C0 03            [24]  863 	push	ar3
      0075A2 C0 02            [24]  864 	push	ar2
      0075A4 12 A4 56         [24]  865 	lcall	_get_record_keycode
      0075A7 A8 82            [24]  866 	mov	r0, dpl
      0075A9 A9 83            [24]  867 	mov	r1, dph
      0075AB D0 02            [24]  868 	pop	ar2
      0075AD D0 03            [24]  869 	pop	ar3
      0075AF D0 04            [24]  870 	pop	ar4
      0075B1 D0 05            [24]  871 	pop	ar5
      0075B3 D0 06            [24]  872 	pop	ar6
      0075B5 D0 07            [24]  873 	pop	ar7
      0075B7 12 48 5D         [24]  874 	lcall	_ak820_outline_0149
      0075BA 12 53 FB         [24]  875 	lcall	_ak820_outline_0168
                                    876 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0075BD 74 07            [12]  877 	mov	a,#0x07
      0075BF 12 37 D7         [24]  878 	lcall	_ak820_outline_0013
      0075C2 FA               [12]  879 	mov	r2,a
      0075C3 A3               [24]  880 	inc	dptr
      0075C4 E0               [24]  881 	movx	a,@dptr
      0075C5 FB               [12]  882 	mov	r3,a
      0075C6 90 06 95         [24]  883 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0075C9 ED               [12]  884 	mov	a,r5
      0075CA F0               [24]  885 	movx	@dptr,a
      0075CB 90 06 96         [24]  886 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0075CE EC               [12]  887 	mov	a,r4
      0075CF F0               [24]  888 	movx	@dptr,a
      0075D0 12 48 5D         [24]  889 	lcall	_ak820_outline_0149
      0075D3 C0 07            [24]  890 	push	ar7
      0075D5 C0 06            [24]  891 	push	ar6
      0075D7 C0 05            [24]  892 	push	ar5
      0075D9 C0 04            [24]  893 	push	ar4
      0075DB 12 4B D8         [24]  894 	lcall	_ak820_oneshot_process
      0075DE E5 82            [12]  895 	mov	a, dpl
      0075E0 D0 04            [24]  896 	pop	ar4
      0075E2 D0 05            [24]  897 	pop	ar5
      0075E4 D0 06            [24]  898 	pop	ar6
      0075E6 D0 07            [24]  899 	pop	ar7
      0075E8 70 01            [24]  900 	jnz	00104$
      0075EA 22               [24]  901 	ret
      0075EB                        902 00104$:
                                    903 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0075EB 12 48 41         [24]  904 	lcall	_ak820_outline_0123
      0075EE C0 07            [24]  905 	push	ar7
      0075F0 C0 06            [24]  906 	push	ar6
      0075F2 C0 05            [24]  907 	push	ar5
      0075F4 C0 04            [24]  908 	push	ar4
      0075F6 12 A4 D6         [24]  909 	lcall	_process_record_quantum
      0075F9 E5 82            [12]  910 	mov	a, dpl
      0075FB D0 04            [24]  911 	pop	ar4
      0075FD D0 05            [24]  912 	pop	ar5
      0075FF D0 06            [24]  913 	pop	ar6
      007601 D0 07            [24]  914 	pop	ar7
      007603 70 0A            [24]  915 	jnz	00106$
                                    916 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007605 90 05 FD         [24]  917 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007608 EC               [12]  918 	mov	a,r4
      007609 F0               [24]  919 	movx	@dptr,a
      00760A 8D 82            [24]  920 	mov	dpl, r5
                                    921 ;	quantum/action.c:376: return;
      00760C 02 2E BB         [24]  922 	ljmp	_ak820_oneshot_post
      00760F                        923 00106$:
                                    924 ;	quantum/action.c:382: process_record_handler(record);
      00760F 12 48 41         [24]  925 	lcall	_ak820_outline_0123
      007612 C0 05            [24]  926 	push	ar5
      007614 C0 04            [24]  927 	push	ar4
      007616 12 76 27         [24]  928 	lcall	_process_record_handler
      007619 D0 04            [24]  929 	pop	ar4
      00761B D0 05            [24]  930 	pop	ar5
                                    931 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00761D 90 05 FD         [24]  932 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007620 EC               [12]  933 	mov	a,r4
      007621 F0               [24]  934 	movx	@dptr,a
      007622 8D 82            [24]  935 	mov	dpl, r5
                                    936 ;	quantum/action.c:392: }
      007624 02 2E BB         [24]  937 	ljmp	_ak820_oneshot_post
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'process_record_handler'
                                    940 ;------------------------------------------------------------
                                    941 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_650'
                                    942 ;record        Allocated with name '_process_record_handler_record_10000_651'
                                    943 ;action        Allocated with name '_process_record_handler_action_10000_651'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_record_handler
                                    948 ;	-----------------------------------------
      007627                        949 _process_record_handler:
      007627 12 38 4B         [24]  950 	lcall	_ak820_outline_0108
      00762A 90 08 8A         [24]  951 	mov	dptr,#_process_record_handler_record_argument_10000_650
      00762D 12 38 50         [24]  952 	lcall	_ak820_outline_0109
                                    953 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007630 90 08 8A         [24]  954 	mov	dptr,#_process_record_handler_record_argument_10000_650
      007633 12 37 A2         [24]  955 	lcall	_ak820_outline_0001
                                    956 ;	quantum/action.c:405: if (record->keycode) {
      007636 4C               [12]  957 	orl	a,r4
      007637 60 19            [24]  958 	jz	00102$
                                    959 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007639 12 38 55         [24]  960 	lcall	_ak820_outline_0126
      00763C C0 07            [24]  961 	push	ar7
      00763E C0 06            [24]  962 	push	ar6
      007640 12 9B 25         [24]  963 	lcall	_action_for_keycode
      007643 12 48 62         [24]  964 	lcall	_ak820_outline_0156
      007646 D0 06            [24]  965 	pop	ar6
      007648 D0 07            [24]  966 	pop	ar7
      00764A 90 08 8C         [24]  967 	mov	dptr,#_process_record_handler_action_10000_651
      00764D 12 38 2D         [24]  968 	lcall	_ak820_outline_0078
      007650 80 2B            [24]  969 	sjmp	00104$
      007652                        970 00102$:
                                    971 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007652 12 7B 0B         [24]  972 	lcall	_ak820_outline_0022
      007655 7A 00            [12]  973 	mov	r2,#0x00
      007657 12 48 57         [24]  974 	lcall	_ak820_outline_0148
      00765A 12 47 EC         [24]  975 	lcall	_ak820_outline_0012
      00765D E0               [24]  976 	movx	a,@dptr
      00765E 90 09 C7         [24]  977 	mov	dptr,#_ak820_resolve_key_PARM_2
      007661 F0               [24]  978 	movx	@dptr,a
      007662 8D 82            [24]  979 	mov	dpl, r5
      007664 8C 83            [24]  980 	mov	dph, r4
      007666 C0 07            [24]  981 	push	ar7
      007668 C0 06            [24]  982 	push	ar6
      00766A 12 7E A5         [24]  983 	lcall	_ak820_resolve_key
      00766D 12 9B 25         [24]  984 	lcall	_action_for_keycode
      007670 12 48 62         [24]  985 	lcall	_ak820_outline_0156
      007673 D0 06            [24]  986 	pop	ar6
      007675 D0 07            [24]  987 	pop	ar7
      007677 90 08 8C         [24]  988 	mov	dptr,#_process_record_handler_action_10000_651
      00767A 12 38 2D         [24]  989 	lcall	_ak820_outline_0078
                                    990 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00767D                        991 00104$:
                                    992 ;	quantum/action.c:429: process_action(record, action);
      00767D 90 0E 20         [24]  993 	mov	dptr,#___memcpy_PARM_2
      007680 74 8C            [12]  994 	mov	a,#_process_record_handler_action_10000_651
      007682 F0               [24]  995 	movx	@dptr,a
      007683 74 08            [12]  996 	mov	a,#(_process_record_handler_action_10000_651 >> 8)
      007685 12 7B 2D         [24]  997 	lcall	_ak820_outline_0055
      007688 12 53 EF         [24]  998 	lcall	_ak820_outline_0114
      00768B 90 08 8E         [24]  999 	mov	dptr,#_process_action_PARM_2
      00768E F5 F0            [12] 1000 	mov	b,a
      007690 C0 07            [24] 1001 	push	ar7
      007692 C0 06            [24] 1002 	push	ar6
      007694 12 BE 98         [24] 1003 	lcall	___memcpy
      007697 D0 06            [24] 1004 	pop	ar6
      007699 D0 07            [24] 1005 	pop	ar7
      00769B 12 48 41         [24] 1006 	lcall	_ak820_outline_0123
                                   1007 ;	quantum/action.c:430: }
      00769E 02 76 A1         [24] 1008 	ljmp	_process_action
                                   1009 ;------------------------------------------------------------
                                   1010 ;Allocation info for local variables in function 'register_mouse'
                                   1011 ;------------------------------------------------------------
                                   1012 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1013 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_659'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function process_action
                                   1018 ;	-----------------------------------------
      0076A1                       1019 _process_action:
      0076A1 12 38 4B         [24] 1020 	lcall	_ak820_outline_0108
      0076A4 90 08 90         [24] 1021 	mov	dptr,#_process_action_record_argument_10000_662
      0076A7 12 38 50         [24] 1022 	lcall	_ak820_outline_0109
                                   1023 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0076AA 90 08 90         [24] 1024 	mov	dptr,#_process_action_record_argument_10000_662
      0076AD 12 37 C3         [24] 1025 	lcall	_ak820_outline_0006
                                   1026 ;	quantum/action.c:501: pressed = record->event.pressed;
      0076B0 A3               [24] 1027 	inc	dptr
      0076B1 A3               [24] 1028 	inc	dptr
      0076B2 A3               [24] 1029 	inc	dptr
      0076B3 A3               [24] 1030 	inc	dptr
      0076B4 A3               [24] 1031 	inc	dptr
      0076B5 E0               [24] 1032 	movx	a,@dptr
      0076B6 F5 18            [12] 1033 	mov	_process_action_sloc0_1_0,a
                                   1034 ;	quantum/action.c:525: switch (action.kind.id) {
      0076B8 90 08 8F         [24] 1035 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076BB E0               [24] 1036 	movx	a,@dptr
      0076BC C4               [12] 1037 	swap	a
      0076BD 54 0F            [12] 1038 	anl	a,#0x0f
      0076BF FD               [12] 1039 	mov  r5,a
      0076C0 24 F4            [12] 1040 	add	a,#0xff - 0x0b
      0076C2 50 03            [24] 1041 	jnc	00434$
      0076C4 02 79 42         [24] 1042 	ljmp	00181$
      0076C7                       1043 00434$:
                                   1044 ;	free result
      0076C7 ED               [12] 1045 	mov	a,r5
      0076C8 24 0A            [12] 1046 	add	a,#(00435$-3-.)
      0076CA 83               [24] 1047 	movc	a,@a+pc
      0076CB F5 82            [12] 1048 	mov	dpl,a
      0076CD ED               [12] 1049 	mov	a,r5
      0076CE 24 10            [12] 1050 	add	a,#(00436$-3-.)
      0076D0 83               [24] 1051 	movc	a,@a+pc
      0076D1 F5 83            [12] 1052 	mov	dph,a
      0076D3 E4               [12] 1053 	clr	a
      0076D4 73               [24] 1054 	jmp	@a+dptr
      0076D5                       1055 00435$:
      0076D5 ED                    1056 	.db	00102$
      0076D6 ED                    1057 	.db	00102$
      0076D7 42                    1058 	.db	00181$
      0076D8 42                    1059 	.db	00181$
      0076D9 77                    1060 	.db	00123$
      0076DA 42                    1061 	.db	00181$
      0076DB 42                    1062 	.db	00181$
      0076DC 42                    1063 	.db	00181$
      0076DD D7                    1064 	.db	00131$
      0076DE A9                    1065 	.db	00147$
      0076DF CF                    1066 	.db	00152$
      0076E0 CF                    1067 	.db	00152$
      0076E1                       1068 00436$:
      0076E1 76                    1069 	.db	00102$>>8
      0076E2 76                    1070 	.db	00102$>>8
      0076E3 79                    1071 	.db	00181$>>8
      0076E4 79                    1072 	.db	00181$>>8
      0076E5 77                    1073 	.db	00123$>>8
      0076E6 79                    1074 	.db	00181$>>8
      0076E7 79                    1075 	.db	00181$>>8
      0076E8 79                    1076 	.db	00181$>>8
      0076E9 77                    1077 	.db	00131$>>8
      0076EA 78                    1078 	.db	00147$>>8
      0076EB 78                    1079 	.db	00152$>>8
      0076EC 78                    1080 	.db	00152$>>8
                                   1081 ;	quantum/action.c:528: case ACT_RMODS: {
      0076ED                       1082 00102$:
                                   1083 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0076ED 90 08 8F         [24] 1084 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076F0 E0               [24] 1085 	movx	a,@dptr
      0076F1 54 F0            [12] 1086 	anl	a,#0xf0
      0076F3 70 06            [24] 1087 	jnz	00194$
      0076F5 12 7B 4D         [24] 1088 	lcall	_ak820_outline_0118
      0076F8 FD               [12] 1089 	mov	r5,a
      0076F9 80 07            [24] 1090 	sjmp	00195$
      0076FB                       1091 00194$:
      0076FB 12 7B 4D         [24] 1092 	lcall	_ak820_outline_0118
      0076FE C4               [12] 1093 	swap	a
      0076FF 54 F0            [12] 1094 	anl	a,#0xf0
      007701 FD               [12] 1095 	mov	r5,a
      007702                       1096 00195$:
                                   1097 ;	quantum/action.c:531: if (pressed) {
      007702 E5 18            [12] 1098 	mov	a,_process_action_sloc0_1_0
      007704 60 35            [24] 1099 	jz	00119$
                                   1100 ;	quantum/action.c:532: if (mods) {
      007706 ED               [12] 1101 	mov	a,r5
      007707 60 29            [24] 1102 	jz	00110$
                                   1103 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007709 12 7B 5F         [24] 1104 	lcall	_ak820_outline_0165
      00770C FC               [12] 1105 	mov	r4,a
      00770D BC E0 00         [24] 1106 	cjne	r4,#0xe0,00440$
      007710                       1107 00440$:
      007710 40 07            [24] 1108 	jc	00108$
      007712 12 7B 5F         [24] 1109 	lcall	_ak820_outline_0165
      007715 24 18            [12] 1110 	add	a,#0xff - 0xe7
      007717 50 0A            [24] 1111 	jnc	00104$
                                   1112 ;	free result
      007719                       1113 00108$:
      007719 7B 8E            [12] 1114 	mov	r3,#_process_action_PARM_2
      00771B 7C 08            [12] 1115 	mov	r4,#(_process_action_PARM_2 >> 8)
      00771D 12 33 FC         [24] 1116 	lcall	_ak820_outline_0131
      007720 E0               [24] 1117 	movx	a,@dptr
      007721 70 07            [24] 1118 	jnz	00105$
      007723                       1119 00104$:
                                   1120 ;	quantum/action.c:537: add_owned_mods(mods);
      007723 8D 82            [24] 1121 	mov	dpl, r5
      007725 12 80 BE         [24] 1122 	lcall	_add_owned_mods
      007728 80 05            [24] 1123 	sjmp	00106$
      00772A                       1124 00105$:
                                   1125 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00772A 8D 82            [24] 1126 	mov	dpl, r5
      00772C 12 80 DD         [24] 1127 	lcall	_add_owned_weak_mods
      00772F                       1128 00106$:
                                   1129 ;	quantum/action.c:541: send_keyboard_report();
      00772F 12 83 F8         [24] 1130 	lcall	_send_keyboard_report
      007732                       1131 00110$:
                                   1132 ;	quantum/action.c:543: register_code(action.key.code);
      007732 12 7B 36         [24] 1133 	lcall	_ak820_outline_0080
      007735 12 79 59         [24] 1134 	lcall	_register_code
      007738 02 79 42         [24] 1135 	ljmp	00181$
      00773B                       1136 00119$:
                                   1137 ;	quantum/action.c:545: unregister_code(action.key.code);
      00773B 12 7B 36         [24] 1138 	lcall	_ak820_outline_0080
      00773E C0 05            [24] 1139 	push	ar5
      007740 12 79 C3         [24] 1140 	lcall	_unregister_code
      007743 D0 05            [24] 1141 	pop	ar5
                                   1142 ;	quantum/action.c:546: if (mods) {
      007745 ED               [12] 1143 	mov	a,r5
      007746 70 03            [24] 1144 	jnz	00444$
      007748 02 79 42         [24] 1145 	ljmp	00181$
      00774B                       1146 00444$:
                                   1147 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00774B 12 7B 5F         [24] 1148 	lcall	_ak820_outline_0165
      00774E FC               [12] 1149 	mov	r4,a
      00774F BC E0 00         [24] 1150 	cjne	r4,#0xe0,00445$
      007752                       1151 00445$:
      007752 40 07            [24] 1152 	jc	00115$
      007754 12 7B 5F         [24] 1153 	lcall	_ak820_outline_0165
      007757 24 18            [12] 1154 	add	a,#0xff - 0xe7
      007759 50 0A            [24] 1155 	jnc	00111$
                                   1156 ;	free result
      00775B                       1157 00115$:
      00775B 7B 8E            [12] 1158 	mov	r3,#_process_action_PARM_2
      00775D 7C 08            [12] 1159 	mov	r4,#(_process_action_PARM_2 >> 8)
      00775F 12 33 FC         [24] 1160 	lcall	_ak820_outline_0131
      007762 E0               [24] 1161 	movx	a,@dptr
      007763 70 07            [24] 1162 	jnz	00112$
      007765                       1163 00111$:
                                   1164 ;	quantum/action.c:548: del_owned_mods(mods);
      007765 8D 82            [24] 1165 	mov	dpl, r5
      007767 12 80 CE         [24] 1166 	lcall	_del_owned_mods
      00776A 80 05            [24] 1167 	sjmp	00113$
      00776C                       1168 00112$:
                                   1169 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00776C 8D 82            [24] 1170 	mov	dpl, r5
      00776E 12 80 ED         [24] 1171 	lcall	_del_owned_weak_mods
      007771                       1172 00113$:
                                   1173 ;	quantum/action.c:552: send_keyboard_report();
      007771 12 83 F8         [24] 1174 	lcall	_send_keyboard_report
                                   1175 ;	quantum/action.c:555: } break;
      007774 02 79 42         [24] 1176 	ljmp	00181$
                                   1177 ;	quantum/action.c:632: case ACT_USAGE:
      007777                       1178 00123$:
                                   1179 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007777 74 07            [12] 1180 	mov	a,#0x07
      007779 12 37 FA         [24] 1181 	lcall	_ak820_outline_0033
      00777C 12 37 CD         [24] 1182 	lcall	_ak820_outline_0010
      00777F C3               [12] 1183 	clr	c
      007780 EC               [12] 1184 	mov	a,r4
      007781 94 A5            [12] 1185 	subb	a,#0xa5
      007783 ED               [12] 1186 	mov	a,r5
      007784 94 00            [12] 1187 	subb	a,#0x00
      007786 40 15            [24] 1188 	jc	00125$
      007788 74 C2            [12] 1189 	mov	a,#0xc2
      00778A 9C               [12] 1190 	subb	a,r4
      00778B E4               [12] 1191 	clr	a
      00778C 9D               [12] 1192 	subb	a,r5
      00778D 40 0E            [24] 1193 	jc	00125$
                                   1194 ;	free result
                                   1195 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      00778F 90 0A EE         [24] 1196 	mov	dptr,#_owned_usage_key_PARM_2
      007792 E5 18            [12] 1197 	mov	a,_process_action_sloc0_1_0
      007794 F0               [24] 1198 	movx	@dptr,a
      007795 8E 82            [24] 1199 	mov	dpl, r6
      007797 12 82 A3         [24] 1200 	lcall	_owned_usage_key
                                   1201 ;	quantum/action.c:640: break;
      00779A 02 79 42         [24] 1202 	ljmp	00181$
      00779D                       1203 00125$:
                                   1204 ;	quantum/action.c:643: switch (action.usage.page) {
      00779D 12 7B 3D         [24] 1205 	lcall	_ak820_outline_0090
      0077A0 FF               [12] 1206 	mov	r7,a
      0077A1 60 08            [24] 1207 	jz	00127$
      0077A3 BF 01 02         [24] 1208 	cjne	r7,#0x01,00452$
      0077A6 80 19            [24] 1209 	sjmp	00128$
      0077A8                       1210 00452$:
      0077A8 02 79 42         [24] 1211 	ljmp	00181$
                                   1212 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0077AB                       1213 00127$:
                                   1214 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0077AB E5 18            [12] 1215 	mov	a,_process_action_sloc0_1_0
      0077AD 60 05            [24] 1216 	jz	00196$
      0077AF 12 7B 54         [24] 1217 	lcall	_ak820_outline_0138
      0077B2 80 04            [24] 1218 	sjmp	00197$
      0077B4                       1219 00196$:
      0077B4 7E 00            [12] 1220 	mov	r6,#0x00
      0077B6 7F 00            [12] 1221 	mov	r7,#0x00
      0077B8                       1222 00197$:
      0077B8 12 48 41         [24] 1223 	lcall	_ak820_outline_0123
      0077BB 12 71 A2         [24] 1224 	lcall	_host_system_send
                                   1225 ;	quantum/action.c:646: break;
      0077BE 02 79 42         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0077C1                       1228 00128$:
                                   1229 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0077C1 E5 18            [12] 1230 	mov	a,_process_action_sloc0_1_0
      0077C3 60 05            [24] 1231 	jz	00198$
      0077C5 12 7B 54         [24] 1232 	lcall	_ak820_outline_0138
      0077C8 80 04            [24] 1233 	sjmp	00199$
      0077CA                       1234 00198$:
      0077CA 7E 00            [12] 1235 	mov	r6,#0x00
      0077CC 7F 00            [12] 1236 	mov	r7,#0x00
      0077CE                       1237 00199$:
      0077CE 12 48 41         [24] 1238 	lcall	_ak820_outline_0123
      0077D1 12 71 D2         [24] 1239 	lcall	_host_consumer_send
                                   1240 ;	quantum/action.c:651: break;
      0077D4 02 79 42         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:658: case ACT_LAYER: {
      0077D7                       1243 00131$:
                                   1244 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0077D7 90 08 8F         [24] 1245 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077DA E0               [24] 1246 	movx	a,@dptr
      0077DB 54 03            [12] 1247 	anl	a,#0x03
      0077DD 90 08 92         [24] 1248 	mov	dptr,#_process_action_on_40000_685
      0077E0 F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0077E1 E0               [24] 1251 	movx	a,@dptr
      0077E2 FF               [12] 1252 	mov	r7,a
      0077E3 60 11            [24] 1253 	jz	00200$
      0077E5 E5 18            [12] 1254 	mov	a,_process_action_sloc0_1_0
      0077E7 60 07            [24] 1255 	jz	00202$
      0077E9 8F 06            [24] 1256 	mov	ar6,r7
      0077EB 53 06 01         [24] 1257 	anl	ar6,#0x01
      0077EE 80 10            [24] 1258 	sjmp	00201$
      0077F0                       1259 00202$:
      0077F0 74 02            [12] 1260 	mov	a,#0x02
      0077F2 5F               [12] 1261 	anl	a,r7
      0077F3 FE               [12] 1262 	mov	r6,a
      0077F4 80 0A            [24] 1263 	sjmp	00201$
      0077F6                       1264 00200$:
      0077F6 E5 18            [12] 1265 	mov	a,_process_action_sloc0_1_0
      0077F8 B4 01 00         [24] 1266 	cjne	a,#0x01,00457$
      0077FB                       1267 00457$:
      0077FB 92 20            [24] 1268 	mov  _process_action_sloc1_1_0,c
      0077FD E4               [12] 1269 	clr	a
      0077FE 33               [12] 1270 	rlc	a
      0077FF FE               [12] 1271 	mov	r6,a
      007800                       1272 00201$:
      007800 EE               [12] 1273 	mov	a,r6
      007801 70 03            [24] 1274 	jnz	00458$
      007803 02 79 42         [24] 1275 	ljmp	00181$
      007806                       1276 00458$:
                                   1277 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007806 12 7B 5F         [24] 1278 	lcall	_ak820_outline_0165
      007809 C4               [12] 1279 	swap	a
      00780A 03               [12] 1280 	rr	a
      00780B 54 07            [12] 1281 	anl	a,#0x07
      00780D 25 E0            [12] 1282 	add	a,acc
      00780F 25 E0            [12] 1283 	add	a,acc
      007811 FF               [12] 1284 	mov	r7,a
                                   1285 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007812 12 7B 5F         [24] 1286 	lcall	_ak820_outline_0165
      007815 54 0F            [12] 1287 	anl	a,#0x0f
      007817 FE               [12] 1288 	mov	r6,a
      007818 8F F0            [24] 1289 	mov	b,r7
      00781A 05 F0            [12] 1290 	inc	b
      00781C EE               [12] 1291 	mov	a,r6
      00781D 80 02            [24] 1292 	sjmp	00460$
      00781F                       1293 00459$:
      00781F 25 E0            [12] 1294 	add	a,acc
      007821                       1295 00460$:
      007821 D5 F0 FB         [24] 1296 	djnz	b,00459$
      007824 FE               [12] 1297 	mov	r6,a
                                   1298 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007825 12 7B 5F         [24] 1299 	lcall	_ak820_outline_0165
      007828 30 E4 11         [24] 1300 	jnb	acc.4,00204$
      00782B 8F F0            [24] 1301 	mov	b,r7
      00782D 05 F0            [12] 1302 	inc	b
      00782F 74 0F            [12] 1303 	mov	a,#0x0f
      007831 80 02            [24] 1304 	sjmp	00463$
      007833                       1305 00462$:
      007833 25 E0            [12] 1306 	add	a,acc
      007835                       1307 00463$:
      007835 D5 F0 FB         [24] 1308 	djnz	b,00462$
      007838 F4               [12] 1309 	cpl	a
      007839 FF               [12] 1310 	mov	r7,a
      00783A 80 02            [24] 1311 	sjmp	00205$
      00783C                       1312 00204$:
      00783C 7F 00            [12] 1313 	mov	r7,#0x00
      00783E                       1314 00205$:
                                   1315 ;	quantum/action.c:666: bits |= mask;
      00783E EE               [12] 1316 	mov	a,r6
      00783F 42 07            [12] 1317 	orl	ar7,a
                                   1318 ;	quantum/action.c:667: if (!on) {
      007841 90 08 92         [24] 1319 	mov	dptr,#_process_action_on_40000_685
      007844 E0               [24] 1320 	movx	a,@dptr
      007845 70 31            [24] 1321 	jnz	00143$
                                   1322 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007847 12 7B 3D         [24] 1323 	lcall	_ak820_outline_0090
      00784A FE               [12] 1324 	mov	r6,a
      00784B 2E               [12] 1325 	add	a,r6
                                   1326 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00784C 90 78 50         [24] 1327 	mov	dptr,#00465$
      00784F 73               [24] 1328 	jmp	@a+dptr
      007850                       1329 00465$:
      007850 80 06            [24] 1330 	sjmp	00132$
      007852 80 0C            [24] 1331 	sjmp	00133$
      007854 80 12            [24] 1332 	sjmp	00134$
      007856 80 18            [24] 1333 	sjmp	00135$
      007858                       1334 00132$:
      007858 8F 82            [24] 1335 	mov	dpl, r7
      00785A 12 7B BA         [24] 1336 	lcall	_default_layer_and
      00785D 02 79 42         [24] 1337 	ljmp	00181$
                                   1338 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007860                       1339 00133$:
      007860 8F 82            [24] 1340 	mov	dpl, r7
      007862 12 7B A9         [24] 1341 	lcall	_default_layer_or
      007865 02 79 42         [24] 1342 	ljmp	00181$
                                   1343 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007868                       1344 00134$:
      007868 8F 82            [24] 1345 	mov	dpl, r7
      00786A 12 7B D0         [24] 1346 	lcall	_default_layer_xor
      00786D 02 79 42         [24] 1347 	ljmp	00181$
                                   1348 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007870                       1349 00135$:
      007870 8F 82            [24] 1350 	mov	dpl, r7
      007872 12 7B 9E         [24] 1351 	lcall	_default_layer_set
                                   1352 ;	quantum/action.c:673: }
      007875 02 79 42         [24] 1353 	ljmp	00181$
      007878                       1354 00143$:
                                   1355 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007878 12 7B 3D         [24] 1356 	lcall	_ak820_outline_0090
      00787B FE               [12] 1357 	mov	r6,a
      00787C 2E               [12] 1358 	add	a,r6
                                   1359 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      00787D 90 78 81         [24] 1360 	mov	dptr,#00466$
      007880 73               [24] 1361 	jmp	@a+dptr
      007881                       1362 00466$:
      007881 80 06            [24] 1363 	sjmp	00137$
      007883 80 0C            [24] 1364 	sjmp	00138$
      007885 80 12            [24] 1365 	sjmp	00139$
      007887 80 18            [24] 1366 	sjmp	00140$
      007889                       1367 00137$:
      007889 8F 82            [24] 1368 	mov	dpl, r7
      00788B 12 7D 4D         [24] 1369 	lcall	_layer_and
      00788E 02 79 42         [24] 1370 	ljmp	00181$
                                   1371 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007891                       1372 00138$:
      007891 8F 82            [24] 1373 	mov	dpl, r7
      007893 12 7D 3C         [24] 1374 	lcall	_layer_or
      007896 02 79 42         [24] 1375 	ljmp	00181$
                                   1376 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007899                       1377 00139$:
      007899 8F 82            [24] 1378 	mov	dpl, r7
      00789B 12 7D 63         [24] 1379 	lcall	_layer_xor
      00789E 02 79 42         [24] 1380 	ljmp	00181$
                                   1381 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0078A1                       1382 00140$:
      0078A1 8F 82            [24] 1383 	mov	dpl, r7
      0078A3 12 7C DF         [24] 1384 	lcall	_layer_state_set
                                   1385 ;	quantum/action.c:683: break;
      0078A6 02 79 42         [24] 1386 	ljmp	00181$
                                   1387 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0078A9                       1388 00147$:
                                   1389 ;	quantum/action.c:686: if (pressed) {
      0078A9 E5 18            [12] 1390 	mov	a,_process_action_sloc0_1_0
      0078AB 60 11            [24] 1391 	jz	00149$
                                   1392 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0078AD 12 7B 4D         [24] 1393 	lcall	_ak820_outline_0118
      0078B0 F5 82            [12] 1394 	mov	dpl,a
      0078B2 12 7C 40         [24] 1395 	lcall	_layer_hold_on
                                   1396 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0078B5 12 7B 36         [24] 1397 	lcall	_ak820_outline_0080
      0078B8 12 7A 76         [24] 1398 	lcall	_register_mods
      0078BB 02 79 42         [24] 1399 	ljmp	00181$
      0078BE                       1400 00149$:
                                   1401 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0078BE 12 7B 36         [24] 1402 	lcall	_ak820_outline_0080
      0078C1 12 7A 8A         [24] 1403 	lcall	_unregister_mods
                                   1404 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0078C4 12 7B 4D         [24] 1405 	lcall	_ak820_outline_0118
      0078C7 F5 82            [12] 1406 	mov	dpl,a
      0078C9 12 7C 78         [24] 1407 	lcall	_layer_hold_off
                                   1408 ;	quantum/action.c:693: break;
      0078CC 02 79 42         [24] 1409 	ljmp	00181$
                                   1410 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0078CF                       1411 00152$:
                                   1412 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0078CF 12 7B 5F         [24] 1413 	lcall	_ak820_outline_0165
      0078D2 FF               [12] 1414 	mov	r7,a
      0078D3 BF F1 02         [24] 1415 	cjne	r7,#0xf1,00468$
      0078D6 80 0A            [24] 1416 	sjmp	00154$
      0078D8                       1417 00468$:
      0078D8 BF F2 02         [24] 1418 	cjne	r7,#0xf2,00469$
      0078DB 80 19            [24] 1419 	sjmp	00155$
      0078DD                       1420 00469$:
                                   1421 ;	quantum/action.c:712: momentary_layer_action:
      0078DD BF F3 3B         [24] 1422 	cjne	r7,#0xf3,00160$
      0078E0 80 28            [24] 1423 	sjmp	00156$
      0078E2                       1424 00154$:
                                   1425 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0078E2 E5 18            [12] 1426 	mov	a,_process_action_sloc0_1_0
      0078E4 60 08            [24] 1427 	jz	00206$
      0078E6 12 7B 24         [24] 1428 	lcall	_ak820_outline_0044
      0078E9 12 7C 40         [24] 1429 	lcall	_layer_hold_on
      0078EC 80 54            [24] 1430 	sjmp	00181$
      0078EE                       1431 00206$:
      0078EE 12 7B 24         [24] 1432 	lcall	_ak820_outline_0044
      0078F1 12 7C 78         [24] 1433 	lcall	_layer_hold_off
                                   1434 ;	quantum/action.c:714: break;
                                   1435 ;	quantum/action.c:715: case OP_OFF_ON:
      0078F4 80 4C            [24] 1436 	sjmp	00181$
      0078F6                       1437 00155$:
                                   1438 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0078F6 E5 18            [12] 1439 	mov	a,_process_action_sloc0_1_0
      0078F8 60 08            [24] 1440 	jz	00208$
      0078FA 12 7B 24         [24] 1441 	lcall	_ak820_outline_0044
      0078FD 12 7D 20         [24] 1442 	lcall	_layer_off
      007900 80 40            [24] 1443 	sjmp	00181$
      007902                       1444 00208$:
      007902 12 7B 24         [24] 1445 	lcall	_ak820_outline_0044
      007905 12 7D 07         [24] 1446 	lcall	_layer_on
                                   1447 ;	quantum/action.c:717: break;
                                   1448 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007908 80 38            [24] 1449 	sjmp	00181$
      00790A                       1450 00156$:
                                   1451 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00790A E5 18            [12] 1452 	mov	a,_process_action_sloc0_1_0
      00790C 60 08            [24] 1453 	jz	00210$
      00790E 12 7B 24         [24] 1454 	lcall	_ak820_outline_0044
      007911 12 7C F3         [24] 1455 	lcall	_layer_move
      007914 80 2C            [24] 1456 	sjmp	00181$
      007916                       1457 00210$:
      007916 12 7C ED         [24] 1458 	lcall	_layer_clear
                                   1459 ;	quantum/action.c:720: break;
                                   1460 ;	quantum/action.c:766: default:
      007919 80 27            [24] 1461 	sjmp	00181$
      00791B                       1462 00160$:
                                   1463 ;	quantum/action.c:773: if (pressed) {
      00791B E5 18            [12] 1464 	mov	a,_process_action_sloc0_1_0
      00791D 60 08            [24] 1465 	jz	00163$
                                   1466 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      00791F 12 7B 36         [24] 1467 	lcall	_ak820_outline_0080
      007922 12 79 59         [24] 1468 	lcall	_register_code
                                   1469 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007925 80 1B            [24] 1470 	sjmp	00181$
      007927                       1471 00163$:
                                   1472 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007927 12 7B 5F         [24] 1473 	lcall	_ak820_outline_0165
      00792A FF               [12] 1474 	mov	r7,a
      00792B BF 39 0E         [24] 1475 	cjne	r7,#0x39,00175$
                                   1476 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00792E 7F 50            [12] 1477 	mov	r7,#0x50
      007930                       1478 00187$:
      007930 EF               [12] 1479 	mov	a,r7
      007931 60 09            [24] 1480 	jz	00175$
      007933 90 00 01         [24] 1481 	mov	dptr,#0x0001
      007936 12 5D 7C         [24] 1482 	lcall	_mDelaymS
      007939 1F               [12] 1483 	dec	r7
                                   1484 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00793A 80 F4            [24] 1485 	sjmp	00187$
      00793C                       1486 00175$:
                                   1487 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      00793C 12 7B 36         [24] 1488 	lcall	_ak820_outline_0080
      00793F 12 79 C3         [24] 1489 	lcall	_unregister_code
                                   1490 ;	quantum/action.c:866: }
      007942                       1491 00181$:
                                   1492 ;	quantum/action.c:887: switch (action.kind.id) {
      007942 90 08 8F         [24] 1493 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007945 E0               [24] 1494 	movx	a,@dptr
      007946 C4               [12] 1495 	swap	a
      007947 54 0F            [12] 1496 	anl	a,#0x0f
      007949 FF               [12] 1497 	mov	r7,a
      00794A BF 08 02         [24] 1498 	cjne	r7,#0x08,00478$
      00794D 80 03            [24] 1499 	sjmp	00183$
      00794F                       1500 00478$:
      00794F BF 09 06         [24] 1501 	cjne	r7,#0x09,00192$
                                   1502 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007952                       1503 00183$:
                                   1504 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007952 12 71 07         [24] 1505 	lcall	_host_keyboard_leds
                                   1506 ;	quantum/action.c:898: }
                                   1507 ;	quantum/action.c:951: }
      007955 02 9D DD         [24] 1508 	ljmp	_led_set
      007958                       1509 00192$:
      007958 22               [24] 1510 	ret
                                   1511 ;------------------------------------------------------------
                                   1512 ;Allocation info for local variables in function 'register_code'
                                   1513 ;------------------------------------------------------------
                                   1514 ;code          Allocated with name '_register_code_code_10000_719'
                                   1515 ;------------------------------------------------------------
                                   1516 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1517 ;	-----------------------------------------
                                   1518 ;	 function register_code
                                   1519 ;	-----------------------------------------
      007959                       1520 _register_code:
      007959 E5 82            [12] 1521 	mov	a,dpl
      00795B 90 08 93         [24] 1522 	mov	dptr,#_register_code_code_10000_719
      00795E F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action.c:958: if (code == KC_NO) {
      00795F E0               [24] 1525 	movx	a,@dptr
      007960 FF               [12] 1526 	mov	r7,a
      007961 70 01            [24] 1527 	jnz	00123$
                                   1528 ;	quantum/action.c:959: return;
      007963 22               [24] 1529 	ret
      007964                       1530 00123$:
                                   1531 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007964 BF 04 00         [24] 1532 	cjne	r7,#0x04,00186$
      007967                       1533 00186$:
      007967 40 12            [24] 1534 	jc	00119$
      007969 EF               [12] 1535 	mov	a,r7
      00796A 24 5B            [12] 1536 	add	a,#0xff - 0xa4
      00796C 40 0D            [24] 1537 	jc	00119$
                                   1538 ;	free result
                                   1539 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00796E 8F 82            [24] 1540 	mov	dpl, r7
      007970 12 81 62         [24] 1541 	lcall	_add_owned_key
      007973 E5 82            [12] 1542 	mov	a, dpl
      007975 70 01            [24] 1543 	jnz	00104$
      007977 22               [24] 1544 	ret
      007978                       1545 00104$:
                                   1546 ;	quantum/action.c:1013: send_keyboard_report();
      007978 02 83 F8         [24] 1547 	ljmp	_send_keyboard_report
      00797B                       1548 00119$:
                                   1549 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00797B 12 7B 64         [24] 1550 	lcall	_ak820_outline_0175
      00797E BF E0 00         [24] 1551 	cjne	r7,#0xe0,00190$
      007981                       1552 00190$:
      007981 40 17            [24] 1553 	jc	00115$
      007983 EF               [12] 1554 	mov	a,r7
      007984 24 18            [12] 1555 	add	a,#0xff - 0xe7
      007986 40 12            [24] 1556 	jc	00115$
                                   1557 ;	free result
                                   1558 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007988 12 7B 1A         [24] 1559 	lcall	_ak820_outline_0041
      00798B 80 02            [24] 1560 	sjmp	00194$
      00798D                       1561 00193$:
      00798D 25 E0            [12] 1562 	add	a,acc
      00798F                       1563 00194$:
      00798F D5 F0 FB         [24] 1564 	djnz	b,00193$
      007992 F5 82            [12] 1565 	mov	dpl,a
      007994 12 80 BE         [24] 1566 	lcall	_add_owned_mods
                                   1567 ;	quantum/action.c:1016: send_keyboard_report();
      007997 02 83 F8         [24] 1568 	ljmp	_send_keyboard_report
      00799A                       1569 00115$:
                                   1570 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00799A 12 7B 64         [24] 1571 	lcall	_ak820_outline_0175
      00799D BF A5 00         [24] 1572 	cjne	r7,#0xa5,00195$
      0079A0                       1573 00195$:
      0079A0 40 05            [24] 1574 	jc	00113$
      0079A2 EF               [12] 1575 	mov	a,r7
      0079A3 24 58            [12] 1576 	add	a,#0xff - 0xa7
      0079A5 50 0D            [24] 1577 	jnc	00108$
                                   1578 ;	free result
      0079A7                       1579 00113$:
      0079A7 12 7B 64         [24] 1580 	lcall	_ak820_outline_0175
      0079AA BF A8 00         [24] 1581 	cjne	r7,#0xa8,00198$
      0079AD                       1582 00198$:
      0079AD 40 13            [24] 1583 	jc	00125$
      0079AF EF               [12] 1584 	mov	a,r7
      0079B0 24 3D            [12] 1585 	add	a,#0xff - 0xc2
      0079B2 40 0E            [24] 1586 	jc	00125$
                                   1587 ;	free result
      0079B4                       1588 00108$:
                                   1589 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0079B4 12 7B 64         [24] 1590 	lcall	_ak820_outline_0175
      0079B7 90 0A EE         [24] 1591 	mov	dptr,#_owned_usage_key_PARM_2
      0079BA 74 01            [12] 1592 	mov	a,#0x01
      0079BC F0               [24] 1593 	movx	@dptr,a
      0079BD 8F 82            [24] 1594 	mov	dpl, r7
                                   1595 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1596 ;	quantum/action.c:1031: }
      0079BF 02 82 A3         [24] 1597 	ljmp	_owned_usage_key
      0079C2                       1598 00125$:
      0079C2 22               [24] 1599 	ret
                                   1600 ;------------------------------------------------------------
                                   1601 ;Allocation info for local variables in function 'unregister_code'
                                   1602 ;------------------------------------------------------------
                                   1603 ;code          Allocated with name '_unregister_code_code_10000_733'
                                   1604 ;------------------------------------------------------------
                                   1605 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1606 ;	-----------------------------------------
                                   1607 ;	 function unregister_code
                                   1608 ;	-----------------------------------------
      0079C3                       1609 _unregister_code:
      0079C3 E5 82            [12] 1610 	mov	a,dpl
      0079C5 90 08 94         [24] 1611 	mov	dptr,#_unregister_code_code_10000_733
      0079C8 F0               [24] 1612 	movx	@dptr,a
                                   1613 ;	quantum/action.c:1038: if (code == KC_NO) {
      0079C9 E0               [24] 1614 	movx	a,@dptr
      0079CA FF               [12] 1615 	mov	r7,a
      0079CB 70 01            [24] 1616 	jnz	00121$
                                   1617 ;	quantum/action.c:1039: return;
      0079CD 22               [24] 1618 	ret
      0079CE                       1619 00121$:
                                   1620 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0079CE BF 04 00         [24] 1621 	cjne	r7,#0x04,00184$
      0079D1                       1622 00184$:
      0079D1 40 12            [24] 1623 	jc	00117$
      0079D3 EF               [12] 1624 	mov	a,r7
      0079D4 24 5B            [12] 1625 	add	a,#0xff - 0xa4
      0079D6 40 0D            [24] 1626 	jc	00117$
                                   1627 ;	free result
                                   1628 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0079D8 8F 82            [24] 1629 	mov	dpl, r7
      0079DA 12 81 DC         [24] 1630 	lcall	_del_owned_key
      0079DD E5 82            [12] 1631 	mov	a, dpl
      0079DF 70 01            [24] 1632 	jnz	00102$
      0079E1 22               [24] 1633 	ret
      0079E2                       1634 00102$:
                                   1635 ;	quantum/action.c:1080: send_keyboard_report();
      0079E2 02 83 F8         [24] 1636 	ljmp	_send_keyboard_report
      0079E5                       1637 00117$:
                                   1638 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      0079E5 12 7B 6A         [24] 1639 	lcall	_ak820_outline_0176
      0079E8 BF E0 00         [24] 1640 	cjne	r7,#0xe0,00188$
      0079EB                       1641 00188$:
      0079EB 40 17            [24] 1642 	jc	00113$
      0079ED EF               [12] 1643 	mov	a,r7
      0079EE 24 18            [12] 1644 	add	a,#0xff - 0xe7
      0079F0 40 12            [24] 1645 	jc	00113$
                                   1646 ;	free result
                                   1647 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      0079F2 12 7B 1A         [24] 1648 	lcall	_ak820_outline_0041
      0079F5 80 02            [24] 1649 	sjmp	00192$
      0079F7                       1650 00191$:
      0079F7 25 E0            [12] 1651 	add	a,acc
      0079F9                       1652 00192$:
      0079F9 D5 F0 FB         [24] 1653 	djnz	b,00191$
      0079FC F5 82            [12] 1654 	mov	dpl,a
      0079FE 12 80 CE         [24] 1655 	lcall	_del_owned_mods
                                   1656 ;	quantum/action.c:1083: send_keyboard_report();
      007A01 02 83 F8         [24] 1657 	ljmp	_send_keyboard_report
      007A04                       1658 00113$:
                                   1659 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A04 12 7B 6A         [24] 1660 	lcall	_ak820_outline_0176
      007A07 BF A5 00         [24] 1661 	cjne	r7,#0xa5,00193$
      007A0A                       1662 00193$:
      007A0A 40 05            [24] 1663 	jc	00111$
      007A0C EF               [12] 1664 	mov	a,r7
      007A0D 24 58            [12] 1665 	add	a,#0xff - 0xa7
      007A0F 50 0D            [24] 1666 	jnc	00106$
                                   1667 ;	free result
      007A11                       1668 00111$:
      007A11 12 7B 6A         [24] 1669 	lcall	_ak820_outline_0176
      007A14 BF A8 00         [24] 1670 	cjne	r7,#0xa8,00196$
      007A17                       1671 00196$:
      007A17 40 12            [24] 1672 	jc	00123$
      007A19 EF               [12] 1673 	mov	a,r7
      007A1A 24 3D            [12] 1674 	add	a,#0xff - 0xc2
      007A1C 40 0D            [24] 1675 	jc	00123$
                                   1676 ;	free result
      007A1E                       1677 00106$:
                                   1678 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007A1E 12 7B 6A         [24] 1679 	lcall	_ak820_outline_0176
      007A21 90 0A EE         [24] 1680 	mov	dptr,#_owned_usage_key_PARM_2
      007A24 E4               [12] 1681 	clr	a
      007A25 F0               [24] 1682 	movx	@dptr,a
      007A26 8F 82            [24] 1683 	mov	dpl, r7
                                   1684 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1685 ;	quantum/action.c:1098: }
      007A28 02 82 A3         [24] 1686 	ljmp	_owned_usage_key
      007A2B                       1687 00123$:
      007A2B 22               [24] 1688 	ret
                                   1689 ;------------------------------------------------------------
                                   1690 ;Allocation info for local variables in function 'tap_code_delay'
                                   1691 ;------------------------------------------------------------
                                   1692 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1693 ;code          Allocated with name '_tap_code_delay_code_10000_746'
                                   1694 ;i             Allocated with name '_tap_code_delay_i_20000_748'
                                   1695 ;i             Allocated with name '_tap_code_delay_i_50000_751'
                                   1696 ;------------------------------------------------------------
                                   1697 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1698 ;	-----------------------------------------
                                   1699 ;	 function tap_code_delay
                                   1700 ;	-----------------------------------------
      007A2C                       1701 _tap_code_delay:
      007A2C E5 82            [12] 1702 	mov	a,dpl
      007A2E 90 08 97         [24] 1703 	mov	dptr,#_tap_code_delay_code_10000_746
      007A31 F0               [24] 1704 	movx	@dptr,a
                                   1705 ;	quantum/action.c:1106: register_code(code);
      007A32 E0               [24] 1706 	movx	a,@dptr
      007A33 FF               [12] 1707 	mov	r7,a
      007A34 F5 82            [12] 1708 	mov	dpl,a
      007A36 C0 07            [24] 1709 	push	ar7
      007A38 12 79 59         [24] 1710 	lcall	_register_code
      007A3B D0 07            [24] 1711 	pop	ar7
                                   1712 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007A3D 90 08 95         [24] 1713 	mov	dptr,#_tap_code_delay_PARM_2
      007A40 12 48 2F         [24] 1714 	lcall	_ak820_outline_0099
      007A43                       1715 00110$:
      007A43 ED               [12] 1716 	mov	a,r5
      007A44 4E               [12] 1717 	orl	a,r6
      007A45 60 0D            [24] 1718 	jz	00105$
                                   1719 ;	quantum/action.c:1108: wait_ms(1);
      007A47 90 00 01         [24] 1720 	mov	dptr,#0x0001
      007A4A 12 5D 7C         [24] 1721 	lcall	_mDelaymS
                                   1722 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007A4D 1D               [12] 1723 	dec	r5
      007A4E BD FF 01         [24] 1724 	cjne	r5,#0xff,00141$
      007A51 1E               [12] 1725 	dec	r6
      007A52                       1726 00141$:
      007A52 80 EF            [24] 1727 	sjmp	00110$
      007A54                       1728 00105$:
                                   1729 ;	quantum/action.c:1110: unregister_code(code);
      007A54 8F 82            [24] 1730 	mov	dpl, r7
                                   1731 ;	quantum/action.c:1111: }
      007A56 02 79 C3         [24] 1732 	ljmp	_unregister_code
                                   1733 ;------------------------------------------------------------
                                   1734 ;Allocation info for local variables in function 'tap_code'
                                   1735 ;------------------------------------------------------------
                                   1736 ;code          Allocated with name '_tap_code_code_10000_753'
                                   1737 ;------------------------------------------------------------
                                   1738 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1739 ;	-----------------------------------------
                                   1740 ;	 function tap_code
                                   1741 ;	-----------------------------------------
      007A59                       1742 _tap_code:
      007A59 E5 82            [12] 1743 	mov	a,dpl
      007A5B 90 08 98         [24] 1744 	mov	dptr,#_tap_code_code_10000_753
      007A5E F0               [24] 1745 	movx	@dptr,a
                                   1746 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A5F E0               [24] 1747 	movx	a,@dptr
      007A60 FF               [12] 1748 	mov	r7,a
      007A61 BF 39 04         [24] 1749 	cjne	r7,#0x39,00103$
      007A64 7E 50            [12] 1750 	mov	r6,#0x50
      007A66 80 02            [24] 1751 	sjmp	00104$
      007A68                       1752 00103$:
      007A68 7E 00            [12] 1753 	mov	r6,#0x00
      007A6A                       1754 00104$:
      007A6A 90 08 95         [24] 1755 	mov	dptr,#_tap_code_delay_PARM_2
      007A6D EE               [12] 1756 	mov	a,r6
      007A6E 12 38 60         [24] 1757 	lcall	_ak820_outline_0132
      007A71 8F 82            [24] 1758 	mov	dpl, r7
                                   1759 ;	quantum/action.c:1119: }
      007A73 02 7A 2C         [24] 1760 	ljmp	_tap_code_delay
                                   1761 ;------------------------------------------------------------
                                   1762 ;Allocation info for local variables in function 'register_mods'
                                   1763 ;------------------------------------------------------------
                                   1764 ;mods          Allocated with name '_register_mods_mods_10000_755'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function register_mods
                                   1769 ;	-----------------------------------------
      007A76                       1770 _register_mods:
      007A76 E5 82            [12] 1771 	mov	a,dpl
      007A78 90 08 99         [24] 1772 	mov	dptr,#_register_mods_mods_10000_755
      007A7B F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action.c:1126: if (mods) {
      007A7C E0               [24] 1775 	movx	a,@dptr
      007A7D FF               [12] 1776 	mov	r7,a
      007A7E E0               [24] 1777 	movx	a,@dptr
      007A7F 60 08            [24] 1778 	jz	00103$
                                   1779 ;	quantum/action.c:1127: add_owned_mods(mods);
      007A81 8F 82            [24] 1780 	mov	dpl, r7
      007A83 12 80 BE         [24] 1781 	lcall	_add_owned_mods
                                   1782 ;	quantum/action.c:1128: send_keyboard_report();
                                   1783 ;	quantum/action.c:1130: }
      007A86 02 83 F8         [24] 1784 	ljmp	_send_keyboard_report
      007A89                       1785 00103$:
      007A89 22               [24] 1786 	ret
                                   1787 ;------------------------------------------------------------
                                   1788 ;Allocation info for local variables in function 'unregister_mods'
                                   1789 ;------------------------------------------------------------
                                   1790 ;mods          Allocated with name '_unregister_mods_mods_10000_759'
                                   1791 ;------------------------------------------------------------
                                   1792 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1793 ;	-----------------------------------------
                                   1794 ;	 function unregister_mods
                                   1795 ;	-----------------------------------------
      007A8A                       1796 _unregister_mods:
      007A8A E5 82            [12] 1797 	mov	a,dpl
      007A8C 90 08 9A         [24] 1798 	mov	dptr,#_unregister_mods_mods_10000_759
      007A8F F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	quantum/action.c:1137: if (mods) {
      007A90 E0               [24] 1801 	movx	a,@dptr
      007A91 FF               [12] 1802 	mov	r7,a
      007A92 E0               [24] 1803 	movx	a,@dptr
      007A93 60 08            [24] 1804 	jz	00103$
                                   1805 ;	quantum/action.c:1138: del_owned_mods(mods);
      007A95 8F 82            [24] 1806 	mov	dpl, r7
      007A97 12 80 CE         [24] 1807 	lcall	_del_owned_mods
                                   1808 ;	quantum/action.c:1139: send_keyboard_report();
                                   1809 ;	quantum/action.c:1141: }
      007A9A 02 83 F8         [24] 1810 	ljmp	_send_keyboard_report
      007A9D                       1811 00103$:
      007A9D 22               [24] 1812 	ret
                                   1813 ;------------------------------------------------------------
                                   1814 ;Allocation info for local variables in function 'register_weak_mods'
                                   1815 ;------------------------------------------------------------
                                   1816 ;mods          Allocated with name '_register_weak_mods_mods_10000_763'
                                   1817 ;------------------------------------------------------------
                                   1818 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1819 ;	-----------------------------------------
                                   1820 ;	 function register_weak_mods
                                   1821 ;	-----------------------------------------
      007A9E                       1822 _register_weak_mods:
      007A9E E5 82            [12] 1823 	mov	a,dpl
      007AA0 90 08 9B         [24] 1824 	mov	dptr,#_register_weak_mods_mods_10000_763
      007AA3 F0               [24] 1825 	movx	@dptr,a
                                   1826 ;	quantum/action.c:1148: if (mods) {
      007AA4 E0               [24] 1827 	movx	a,@dptr
      007AA5 FF               [12] 1828 	mov	r7,a
      007AA6 E0               [24] 1829 	movx	a,@dptr
      007AA7 60 08            [24] 1830 	jz	00103$
                                   1831 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007AA9 8F 82            [24] 1832 	mov	dpl, r7
      007AAB 12 80 DD         [24] 1833 	lcall	_add_owned_weak_mods
                                   1834 ;	quantum/action.c:1150: send_keyboard_report();
                                   1835 ;	quantum/action.c:1152: }
      007AAE 02 83 F8         [24] 1836 	ljmp	_send_keyboard_report
      007AB1                       1837 00103$:
      007AB1 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_767'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function unregister_weak_mods
                                   1847 ;	-----------------------------------------
      007AB2                       1848 _unregister_weak_mods:
      007AB2 E5 82            [12] 1849 	mov	a,dpl
      007AB4 90 08 9C         [24] 1850 	mov	dptr,#_unregister_weak_mods_mods_10000_767
      007AB7 F0               [24] 1851 	movx	@dptr,a
                                   1852 ;	quantum/action.c:1159: if (mods) {
      007AB8 E0               [24] 1853 	movx	a,@dptr
      007AB9 FF               [12] 1854 	mov	r7,a
      007ABA E0               [24] 1855 	movx	a,@dptr
      007ABB 60 08            [24] 1856 	jz	00103$
                                   1857 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007ABD 8F 82            [24] 1858 	mov	dpl, r7
      007ABF 12 80 ED         [24] 1859 	lcall	_del_owned_weak_mods
                                   1860 ;	quantum/action.c:1161: send_keyboard_report();
                                   1861 ;	quantum/action.c:1163: }
      007AC2 02 83 F8         [24] 1862 	ljmp	_send_keyboard_report
      007AC5                       1863 00103$:
      007AC5 22               [24] 1864 	ret
                                   1865 ;------------------------------------------------------------
                                   1866 ;Allocation info for local variables in function 'clear_keyboard'
                                   1867 ;------------------------------------------------------------
                                   1868 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1869 ;	-----------------------------------------
                                   1870 ;	 function clear_keyboard
                                   1871 ;	-----------------------------------------
      007AC6                       1872 _clear_keyboard:
                                   1873 ;	quantum/action.c:1170: clear_mods();
      007AC6 12 85 44         [24] 1874 	lcall	_clear_mods
                                   1875 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1876 ;	quantum/action.c:1172: }
      007AC9 02 7A CC         [24] 1877 	ljmp	_clear_keyboard_but_mods
                                   1878 ;------------------------------------------------------------
                                   1879 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1880 ;------------------------------------------------------------
                                   1881 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1882 ;	-----------------------------------------
                                   1883 ;	 function clear_keyboard_but_mods
                                   1884 ;	-----------------------------------------
      007ACC                       1885 _clear_keyboard_but_mods:
                                   1886 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007ACC 90 0E 48         [24] 1887 	mov	dptr,#_actual_keyboard_report
      007ACF 12 73 C9         [24] 1888 	lcall	_clear_keys_from_report
                                   1889 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1890 ;	quantum/action.c:1181: }
      007AD2 02 7A D5         [24] 1891 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1892 ;------------------------------------------------------------
                                   1893 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1894 ;------------------------------------------------------------
                                   1895 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1896 ;	-----------------------------------------
                                   1897 ;	 function clear_keyboard_but_mods_and_keys
                                   1898 ;	-----------------------------------------
      007AD5                       1899 _clear_keyboard_but_mods_and_keys:
                                   1900 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007AD5 12 4B B7         [24] 1901 	lcall	_ak820_tapping_cancel
                                   1902 ;	quantum/action.c:1194: ak820_key_override_cancel();
      007AD8 12 3C 9C         [24] 1903 	lcall	_ak820_key_override_cancel
                                   1904 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007ADB 12 2E F0         [24] 1905 	lcall	_ak820_oneshot_cancel
                                   1906 ;	quantum/action.c:1209: ak820_combo_cancel();
      007ADE 12 35 27         [24] 1907 	lcall	_ak820_combo_cancel
                                   1908 ;	quantum/action.c:1212: repeat_key_cancel();
      007AE1 12 A7 4F         [24] 1909 	lcall	_repeat_key_cancel
                                   1910 ;	quantum/action.c:1214: clear_owned_mods();
      007AE4 12 80 FD         [24] 1911 	lcall	_clear_owned_mods
                                   1912 ;	quantum/action.c:1215: clear_owned_keys();
      007AE7 12 81 35         [24] 1913 	lcall	_clear_owned_keys
                                   1914 ;	quantum/action.c:1216: clear_owned_usages();
      007AEA 12 82 6B         [24] 1915 	lcall	_clear_owned_usages
                                   1916 ;	quantum/action.c:1217: layer_hold_clear();
      007AED 12 7C B0         [24] 1917 	lcall	_layer_hold_clear
                                   1918 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007AF0 12 A2 6A         [24] 1919 	lcall	_clear_macro_tri_layer
                                   1920 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007AF3 90 0E 48         [24] 1921 	mov	dptr,#_actual_keyboard_report
      007AF6 12 73 C9         [24] 1922 	lcall	_clear_keys_from_report
                                   1923 ;	quantum/action.c:1224: host_system_send(0);
      007AF9 90 00 00         [24] 1924 	mov	dptr,#0x0000
      007AFC 12 71 A2         [24] 1925 	lcall	_host_system_send
                                   1926 ;	quantum/action.c:1225: host_consumer_send(0);
      007AFF 90 00 00         [24] 1927 	mov	dptr,#0x0000
      007B02 12 71 D2         [24] 1928 	lcall	_host_consumer_send
                                   1929 ;	quantum/action.c:1227: clear_weak_mods();
      007B05 12 85 79         [24] 1930 	lcall	_clear_weak_mods
                                   1931 ;	quantum/action.c:1228: send_keyboard_report();
                                   1932 ;	quantum/action.c:1236: }
      007B08 02 83 F8         [24] 1933 	ljmp	_send_keyboard_report
                                   1934 ;------------------------------------------------------------
                                   1935 ;Allocation info for local variables in function 'is_tap_record'
                                   1936 ;------------------------------------------------------------
                                   1937 ;record        Allocated with name '_is_tap_record_record_10000_783'
                                   1938 ;action        Allocated with name '_is_tap_record_action_10001_787'
                                   1939 ;------------------------------------------------------------
                                   1940 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1941 ;	-----------------------------------------
                                   1942 	.area CSEG    (CODE)
                                   1943 	.area CONST   (CODE)
                                   1944 	.area XINIT   (CODE)
      00C76B                       1945 __xinit__disable_action_cache:
      00C76B 00                    1946 	.db #0x00	;  0
                                   1947 	.area CABS    (ABS,CODE)
                                   1948 
                                   1949 ; Experimental exact instruction outlining.
                                   1950 	.globl _ak820_outline_0001
                                   1951 	.globl _ak820_outline_0006
                                   1952 	.globl _ak820_outline_0009
                                   1953 	.globl _ak820_outline_0010
                                   1954 	.globl _ak820_outline_0012
                                   1955 	.globl _ak820_outline_0013
                                   1956 	.globl _ak820_outline_0019
                                   1957 	.globl _ak820_outline_0022
                                   1958 	.globl _ak820_outline_0033
                                   1959 	.globl _ak820_outline_0041
                                   1960 	.globl _ak820_outline_0044
                                   1961 	.globl _ak820_outline_0055
                                   1962 	.globl _ak820_outline_0056
                                   1963 	.globl _ak820_outline_0060
                                   1964 	.globl _ak820_outline_0063
                                   1965 	.globl _ak820_outline_0078
                                   1966 	.globl _ak820_outline_0080
                                   1967 	.globl _ak820_outline_0090
                                   1968 	.globl _ak820_outline_0099
                                   1969 	.globl _ak820_outline_0108
                                   1970 	.globl _ak820_outline_0109
                                   1971 	.globl _ak820_outline_0114
                                   1972 	.globl _ak820_outline_0115
                                   1973 	.globl _ak820_outline_0118
                                   1974 	.globl _ak820_outline_0123
                                   1975 	.globl _ak820_outline_0126
                                   1976 	.globl _ak820_outline_0131
                                   1977 	.globl _ak820_outline_0132
                                   1978 	.globl _ak820_outline_0138
                                   1979 	.globl _ak820_outline_0148
                                   1980 	.globl _ak820_outline_0149
                                   1981 	.globl _ak820_outline_0155
                                   1982 	.globl _ak820_outline_0156
                                   1983 	.globl _ak820_outline_0165
                                   1984 	.globl _ak820_outline_0168
                                   1985 	.globl _ak820_outline_0175
                                   1986 	.globl _ak820_outline_0176
                                   1987 
                                   1988 	.area CSEG (CODE)
                                   1989 ; function ak820_outline_0022
      007B0B                       1990 _ak820_outline_0022:
      007B0B 8E 82            [24] 1991 	mov	dpl,r6
      007B0D 8F 83            [24] 1992 	mov	dph,r7
      007B0F A3               [24] 1993 	inc	dptr
      007B10 E0               [24] 1994 	movx	a,@dptr
      007B11 FC               [12] 1995 	mov	r4,a
      007B12 7D 00            [12] 1996 	mov	r5,#0x00
      007B14 8E 82            [24] 1997 	mov	dpl,r6
      007B16 8F 83            [24] 1998 	mov	dph,r7
      007B18 E0               [24] 1999 	movx	a,@dptr
      007B19 22               [24] 2000 	ret
                                   2001 
                                   2002 	.area CSEG (CODE)
                                   2003 ; function ak820_outline_0041
      007B1A                       2004 _ak820_outline_0041:
      007B1A 74 07            [12] 2005 	mov	a,#0x07
      007B1C 5F               [12] 2006 	anl	a,r7
      007B1D F5 F0            [12] 2007 	mov	b,a
      007B1F 05 F0            [12] 2008 	inc	b
      007B21 74 01            [12] 2009 	mov	a,#0x01
      007B23 22               [24] 2010 	ret
                                   2011 
                                   2012 	.area CSEG (CODE)
                                   2013 ; function ak820_outline_0044
      007B24                       2014 _ak820_outline_0044:
      007B24 90 08 8F         [24] 2015 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B27 E0               [24] 2016 	movx	a,@dptr
      007B28 54 1F            [12] 2017 	anl	a,#0x1f
      007B2A F5 82            [12] 2018 	mov	dpl,a
      007B2C 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0055
      007B2D                       2023 _ak820_outline_0055:
      007B2D A3               [24] 2024 	inc	dptr
      007B2E F0               [24] 2025 	movx	@dptr,a
      007B2F E4               [12] 2026 	clr	a
      007B30 A3               [24] 2027 	inc	dptr
      007B31 F0               [24] 2028 	movx	@dptr,a
      007B32 90 0E 23         [24] 2029 	mov	dptr,#___memcpy_PARM_3
      007B35 22               [24] 2030 	ret
                                   2031 
                                   2032 	.area CSEG (CODE)
                                   2033 ; function ak820_outline_0080
      007B36                       2034 _ak820_outline_0080:
      007B36 90 08 8E         [24] 2035 	mov	dptr,#_process_action_PARM_2
      007B39 E0               [24] 2036 	movx	a,@dptr
      007B3A F5 82            [12] 2037 	mov	dpl,a
      007B3C 22               [24] 2038 	ret
                                   2039 
                                   2040 	.area CSEG (CODE)
                                   2041 ; function ak820_outline_0090
      007B3D                       2042 _ak820_outline_0090:
      007B3D 90 08 8F         [24] 2043 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B40 E0               [24] 2044 	movx	a,@dptr
      007B41 03               [12] 2045 	rr	a
      007B42 03               [12] 2046 	rr	a
      007B43 54 03            [12] 2047 	anl	a,#0x03
      007B45 22               [24] 2048 	ret
                                   2049 
                                   2050 	.area CSEG (CODE)
                                   2051 ; function ak820_outline_0115
      007B46                       2052 _ak820_outline_0115:
      007B46 74 06            [12] 2053 	mov	a,#0x06
      007B48 F0               [24] 2054 	movx	@dptr,a
      007B49 E4               [12] 2055 	clr	a
      007B4A A3               [24] 2056 	inc	dptr
      007B4B F0               [24] 2057 	movx	@dptr,a
      007B4C 22               [24] 2058 	ret
                                   2059 
                                   2060 	.area CSEG (CODE)
                                   2061 ; function ak820_outline_0118
      007B4D                       2062 _ak820_outline_0118:
      007B4D 90 08 8F         [24] 2063 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B50 E0               [24] 2064 	movx	a,@dptr
      007B51 54 0F            [12] 2065 	anl	a,#0x0f
      007B53 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0138
      007B54                       2070 _ak820_outline_0138:
      007B54 90 08 8E         [24] 2071 	mov	dptr,#_process_action_PARM_2
      007B57 E0               [24] 2072 	movx	a,@dptr
      007B58 FE               [12] 2073 	mov	r6,a
      007B59 A3               [24] 2074 	inc	dptr
      007B5A E0               [24] 2075 	movx	a,@dptr
      007B5B 54 03            [12] 2076 	anl	a,#0x03
      007B5D FF               [12] 2077 	mov	r7,a
      007B5E 22               [24] 2078 	ret
                                   2079 
                                   2080 	.area CSEG (CODE)
                                   2081 ; function ak820_outline_0165
      007B5F                       2082 _ak820_outline_0165:
      007B5F 90 08 8E         [24] 2083 	mov	dptr,#_process_action_PARM_2
      007B62 E0               [24] 2084 	movx	a,@dptr
      007B63 22               [24] 2085 	ret
                                   2086 
                                   2087 	.area CSEG (CODE)
                                   2088 ; function ak820_outline_0175
      007B64                       2089 _ak820_outline_0175:
      007B64 90 08 93         [24] 2090 	mov	dptr,#_register_code_code_10000_719
      007B67 E0               [24] 2091 	movx	a,@dptr
      007B68 FF               [12] 2092 	mov	r7,a
      007B69 22               [24] 2093 	ret
                                   2094 
                                   2095 	.area CSEG (CODE)
                                   2096 ; function ak820_outline_0176
      007B6A                       2097 _ak820_outline_0176:
      007B6A 90 08 94         [24] 2098 	mov	dptr,#_unregister_code_code_10000_733
      007B6D E0               [24] 2099 	movx	a,@dptr
      007B6E FF               [12] 2100 	mov	r7,a
      007B6F 22               [24] 2101 	ret
