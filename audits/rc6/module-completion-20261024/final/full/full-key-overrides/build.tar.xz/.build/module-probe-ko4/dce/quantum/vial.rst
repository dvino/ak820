                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_key_override_reload
                                     12 	.globl _unregister_code16
                                     13 	.globl _register_code16
                                     14 	.globl _matrix_is_on
                                     15 	.globl _dynamic_keymap_set_key_override
                                     16 	.globl _dynamic_keymap_get_key_override
                                     17 	.globl _dynamic_keymap_set_combo
                                     18 	.globl _dynamic_keymap_get_combo
                                     19 	.globl _dynamic_keymap_set_encoder
                                     20 	.globl _dynamic_keymap_get_encoder
                                     21 	.globl _repeat_key_cancel
                                     22 	.globl _ak820_combo_reload
                                     23 	.globl _clear_keyboard
                                     24 	.globl _ak820_action_exec
                                     25 	.globl _timer_elapsed32
                                     26 	.globl _timer_read32
                                     27 	.globl _timer_read
                                     28 	.globl ___memcpy
                                     29 	.globl _ADC_START
                                     30 	.globl _S0_R_FIFO
                                     31 	.globl _S0_T_FIFO
                                     32 	.globl _S0_FREE
                                     33 	.globl _S0_IF_BYTE
                                     34 	.globl _S0_IF_FIRST
                                     35 	.globl _S0_IF_OV
                                     36 	.globl _S0_FST_ACT
                                     37 	.globl _CP_RL2
                                     38 	.globl _C_T2
                                     39 	.globl _TR2
                                     40 	.globl _EXEN2
                                     41 	.globl _TCLK
                                     42 	.globl _RCLK
                                     43 	.globl _EXF2
                                     44 	.globl _CAP1F
                                     45 	.globl _TF2
                                     46 	.globl _RI
                                     47 	.globl _TI
                                     48 	.globl _RB8
                                     49 	.globl _TB8
                                     50 	.globl _REN
                                     51 	.globl _SM2
                                     52 	.globl _SM1
                                     53 	.globl _SM0
                                     54 	.globl _IT0
                                     55 	.globl _IE0
                                     56 	.globl _IT1
                                     57 	.globl _IE1
                                     58 	.globl _TR0
                                     59 	.globl _TF0
                                     60 	.globl _TR1
                                     61 	.globl _TF1
                                     62 	.globl _P4_0
                                     63 	.globl _P4_1
                                     64 	.globl _P4_2
                                     65 	.globl _P4_3
                                     66 	.globl _P4_4
                                     67 	.globl _P4_5
                                     68 	.globl _P4_6
                                     69 	.globl _RXD
                                     70 	.globl _TXD
                                     71 	.globl _INT0
                                     72 	.globl _INT1
                                     73 	.globl _T0
                                     74 	.globl _T1
                                     75 	.globl _MOSI1
                                     76 	.globl _MISO1
                                     77 	.globl _SCK1
                                     78 	.globl _P3_0
                                     79 	.globl _P3_1
                                     80 	.globl _P3_2
                                     81 	.globl _P3_3
                                     82 	.globl _P3_4
                                     83 	.globl _P3_5
                                     84 	.globl _P3_6
                                     85 	.globl _P3_7
                                     86 	.globl _CAP1_
                                     87 	.globl _T2_
                                     88 	.globl _CAP2_
                                     89 	.globl _T2EX_
                                     90 	.globl _RXD1
                                     91 	.globl _TXD1
                                     92 	.globl _P2_0
                                     93 	.globl _P2_1
                                     94 	.globl _P2_2
                                     95 	.globl _P2_3
                                     96 	.globl _P2_4
                                     97 	.globl _P2_5
                                     98 	.globl _P2_6
                                     99 	.globl _P2_7
                                    100 	.globl _AIN0
                                    101 	.globl _AIN1
                                    102 	.globl _AIN2
                                    103 	.globl _AIN3
                                    104 	.globl _AIN4
                                    105 	.globl _AIN5
                                    106 	.globl _AIN6
                                    107 	.globl _AIN7
                                    108 	.globl _CAP1
                                    109 	.globl _T2
                                    110 	.globl _CAP2
                                    111 	.globl _T2EX
                                    112 	.globl _INT0_
                                    113 	.globl _SCS
                                    114 	.globl _MOSI
                                    115 	.globl _MISO
                                    116 	.globl _SCK
                                    117 	.globl _RXD1_
                                    118 	.globl _TXD1_
                                    119 	.globl _P1_0
                                    120 	.globl _P1_1
                                    121 	.globl _P1_2
                                    122 	.globl _P1_3
                                    123 	.globl _P1_4
                                    124 	.globl _P1_5
                                    125 	.globl _P1_6
                                    126 	.globl _P1_7
                                    127 	.globl _AIN8
                                    128 	.globl _AIN9
                                    129 	.globl _AIN10
                                    130 	.globl _AIN11
                                    131 	.globl _AIN12
                                    132 	.globl _AIN13
                                    133 	.globl _RXD_
                                    134 	.globl _TXD_
                                    135 	.globl _SCL0
                                    136 	.globl _SDA0
                                    137 	.globl _P0_0
                                    138 	.globl _P0_1
                                    139 	.globl _P0_2
                                    140 	.globl _P0_3
                                    141 	.globl _P0_4
                                    142 	.globl _P0_5
                                    143 	.globl _P0_6
                                    144 	.globl _P0_7
                                    145 	.globl _IE_SPI0
                                    146 	.globl _IE_USB
                                    147 	.globl _IE_ADC
                                    148 	.globl _IE_UART1
                                    149 	.globl _IE_PWM_I2C
                                    150 	.globl _IE_GPIO
                                    151 	.globl _IE_WDOG
                                    152 	.globl _PX0
                                    153 	.globl _PT0
                                    154 	.globl _PX1
                                    155 	.globl _PT1
                                    156 	.globl _PS
                                    157 	.globl _PT2
                                    158 	.globl _PL_FLAG
                                    159 	.globl _PH_FLAG
                                    160 	.globl _EX0
                                    161 	.globl _ET0
                                    162 	.globl _EX1
                                    163 	.globl _ET1
                                    164 	.globl _ES
                                    165 	.globl _ET2
                                    166 	.globl _E_DIS
                                    167 	.globl _EA
                                    168 	.globl _P
                                    169 	.globl _F1
                                    170 	.globl _OV
                                    171 	.globl _RS0
                                    172 	.globl _RS1
                                    173 	.globl _F0
                                    174 	.globl _AC
                                    175 	.globl _CY
                                    176 	.globl _I2CS_INT_ST
                                    177 	.globl _I2CX_INT
                                    178 	.globl _LED_STATUS
                                    179 	.globl _LED_DMA_H
                                    180 	.globl _LED_DMA_L
                                    181 	.globl _LED_DMA
                                    182 	.globl _LED_PWM_OE
                                    183 	.globl _LED_COMMON
                                    184 	.globl _ADC_CHAN
                                    185 	.globl _ADC_DAT_H
                                    186 	.globl _ADC_DAT_L
                                    187 	.globl _ADC_DAT
                                    188 	.globl _ADC_CTRL
                                    189 	.globl _SPI1_CK_SE
                                    190 	.globl _SPI1_CTRL
                                    191 	.globl _SPI1_DATA
                                    192 	.globl _SPI1_STAT
                                    193 	.globl _SIF1
                                    194 	.globl _SBAUD1
                                    195 	.globl _SBUF1
                                    196 	.globl _SCON1
                                    197 	.globl _SPI0_SETUP
                                    198 	.globl _SPI0_CK_SE
                                    199 	.globl _SPI0_CTRL
                                    200 	.globl _SPI0_DATA
                                    201 	.globl _SPI0_STAT
                                    202 	.globl _T2CAP1H
                                    203 	.globl _T2CAP1L
                                    204 	.globl _T2CAP1
                                    205 	.globl _TH2
                                    206 	.globl _TL2
                                    207 	.globl _T2COUNT
                                    208 	.globl _RCAP2H
                                    209 	.globl _RCAP2L
                                    210 	.globl _RCAP2
                                    211 	.globl _T2MOD
                                    212 	.globl _T2CON
                                    213 	.globl _SBUF
                                    214 	.globl _SCON
                                    215 	.globl _TH1
                                    216 	.globl _TH0
                                    217 	.globl _TL1
                                    218 	.globl _TL0
                                    219 	.globl _TMOD
                                    220 	.globl _TCON
                                    221 	.globl _XBUS_AUX
                                    222 	.globl _P7
                                    223 	.globl _P6_DIR
                                    224 	.globl _P6_OUT_PU
                                    225 	.globl _P6_IN
                                    226 	.globl _P5_DIR
                                    227 	.globl _P5_OUT_PU
                                    228 	.globl _P5_IN
                                    229 	.globl _P4_LED_KEY
                                    230 	.globl _P4_DIR_PU
                                    231 	.globl _P4_MOD_OC
                                    232 	.globl _P4
                                    233 	.globl _P3_DIR_PU
                                    234 	.globl _P3_MOD_OC
                                    235 	.globl _P3
                                    236 	.globl _P2_DIR_PU
                                    237 	.globl _P2_MOD_OC
                                    238 	.globl _P2
                                    239 	.globl _P1_DIR_PU
                                    240 	.globl _P1_MOD_OC
                                    241 	.globl _P1
                                    242 	.globl _P0_DIR_PU
                                    243 	.globl _P0_MOD_OC
                                    244 	.globl _P0
                                    245 	.globl _ROM_CTRL
                                    246 	.globl _ROM_DATA_HH
                                    247 	.globl _ROM_DATA_HL
                                    248 	.globl _ROM_DATA_HI
                                    249 	.globl _ROM_ADDR_H
                                    250 	.globl _ROM_ADDR_L
                                    251 	.globl _ROM_ADDR
                                    252 	.globl _GPIO_IE
                                    253 	.globl _IP_EX
                                    254 	.globl _IE_EX
                                    255 	.globl _IP
                                    256 	.globl _IE
                                    257 	.globl _WDOG_COUNT
                                    258 	.globl _RESET_KEEP
                                    259 	.globl _WAKE_CTRL
                                    260 	.globl _CLOCK_CFG
                                    261 	.globl _POWER_CFG
                                    262 	.globl _PCON
                                    263 	.globl _GLOBAL_CFG
                                    264 	.globl _SAFE_MOD
                                    265 	.globl _DPH
                                    266 	.globl _DPL
                                    267 	.globl _SP
                                    268 	.globl _A_INV
                                    269 	.globl _B
                                    270 	.globl _ACC
                                    271 	.globl _PSW
                                    272 	.globl _vial_unlock_in_progress
                                    273 	.globl _vial_unlocked
                                    274 	.globl _g_vial_magic_keycode_override
                                    275 	.globl _vial_handle_cmd_PARM_2
                                    276 	.globl _vial_unlock_task
                                    277 	.globl _vial_init
                                    278 	.globl _vial_handle_cmd
                                    279 	.globl _vial_keycode_down
                                    280 	.globl _vial_keycode_up
                                    281 	.globl _vial_keycode_tap
                                    282 ;--------------------------------------------------------
                                    283 ; special function registers
                                    284 ;--------------------------------------------------------
                                    285 	.area RSEG    (ABS,DATA)
      000000                        286 	.org 0x0000
                           0000D0   287 _PSW	=	0x00d0
                           0000E0   288 _ACC	=	0x00e0
                           0000F0   289 _B	=	0x00f0
                           0000FD   290 _A_INV	=	0x00fd
                           000081   291 _SP	=	0x0081
                           000082   292 _DPL	=	0x0082
                           000083   293 _DPH	=	0x0083
                           0000A1   294 _SAFE_MOD	=	0x00a1
                           0000B1   295 _GLOBAL_CFG	=	0x00b1
                           000087   296 _PCON	=	0x0087
                           0000BA   297 _POWER_CFG	=	0x00ba
                           0000B9   298 _CLOCK_CFG	=	0x00b9
                           0000A9   299 _WAKE_CTRL	=	0x00a9
                           0000FE   300 _RESET_KEEP	=	0x00fe
                           0000FF   301 _WDOG_COUNT	=	0x00ff
                           0000A8   302 _IE	=	0x00a8
                           0000B8   303 _IP	=	0x00b8
                           0000E8   304 _IE_EX	=	0x00e8
                           0000E9   305 _IP_EX	=	0x00e9
                           0000B2   306 _GPIO_IE	=	0x00b2
                           008584   307 _ROM_ADDR	=	0x8584
                           000084   308 _ROM_ADDR_L	=	0x0084
                           000085   309 _ROM_ADDR_H	=	0x0085
                           008F8E   310 _ROM_DATA_HI	=	0x8f8e
                           00008E   311 _ROM_DATA_HL	=	0x008e
                           00008F   312 _ROM_DATA_HH	=	0x008f
                           000086   313 _ROM_CTRL	=	0x0086
                           000080   314 _P0	=	0x0080
                           0000C4   315 _P0_MOD_OC	=	0x00c4
                           0000C5   316 _P0_DIR_PU	=	0x00c5
                           000090   317 _P1	=	0x0090
                           000092   318 _P1_MOD_OC	=	0x0092
                           000093   319 _P1_DIR_PU	=	0x0093
                           0000A0   320 _P2	=	0x00a0
                           000094   321 _P2_MOD_OC	=	0x0094
                           000095   322 _P2_DIR_PU	=	0x0095
                           0000B0   323 _P3	=	0x00b0
                           000096   324 _P3_MOD_OC	=	0x0096
                           000097   325 _P3_DIR_PU	=	0x0097
                           0000C0   326 _P4	=	0x00c0
                           0000C2   327 _P4_MOD_OC	=	0x00c2
                           0000C3   328 _P4_DIR_PU	=	0x00c3
                           0000C1   329 _P4_LED_KEY	=	0x00c1
                           0000AA   330 _P5_IN	=	0x00aa
                           0000AB   331 _P5_OUT_PU	=	0x00ab
                           0000AC   332 _P5_DIR	=	0x00ac
                           0000AD   333 _P6_IN	=	0x00ad
                           0000AE   334 _P6_OUT_PU	=	0x00ae
                           0000AF   335 _P6_DIR	=	0x00af
                           0000F1   336 _P7	=	0x00f1
                           0000A2   337 _XBUS_AUX	=	0x00a2
                           000088   338 _TCON	=	0x0088
                           000089   339 _TMOD	=	0x0089
                           00008A   340 _TL0	=	0x008a
                           00008B   341 _TL1	=	0x008b
                           00008C   342 _TH0	=	0x008c
                           00008D   343 _TH1	=	0x008d
                           000098   344 _SCON	=	0x0098
                           000099   345 _SBUF	=	0x0099
                           0000C8   346 _T2CON	=	0x00c8
                           0000C9   347 _T2MOD	=	0x00c9
                           00CBCA   348 _RCAP2	=	0xcbca
                           0000CA   349 _RCAP2L	=	0x00ca
                           0000CB   350 _RCAP2H	=	0x00cb
                           00CDCC   351 _T2COUNT	=	0xcdcc
                           0000CC   352 _TL2	=	0x00cc
                           0000CD   353 _TH2	=	0x00cd
                           00CFCE   354 _T2CAP1	=	0xcfce
                           0000CE   355 _T2CAP1L	=	0x00ce
                           0000CF   356 _T2CAP1H	=	0x00cf
                           0000F8   357 _SPI0_STAT	=	0x00f8
                           0000F9   358 _SPI0_DATA	=	0x00f9
                           0000FA   359 _SPI0_CTRL	=	0x00fa
                           0000FB   360 _SPI0_CK_SE	=	0x00fb
                           0000FC   361 _SPI0_SETUP	=	0x00fc
                           0000BC   362 _SCON1	=	0x00bc
                           0000BD   363 _SBUF1	=	0x00bd
                           0000BE   364 _SBAUD1	=	0x00be
                           0000BF   365 _SIF1	=	0x00bf
                           0000B4   366 _SPI1_STAT	=	0x00b4
                           0000B5   367 _SPI1_DATA	=	0x00b5
                           0000B6   368 _SPI1_CTRL	=	0x00b6
                           0000B7   369 _SPI1_CK_SE	=	0x00b7
                           0000F3   370 _ADC_CTRL	=	0x00f3
                           00F5F4   371 _ADC_DAT	=	0xf5f4
                           0000F4   372 _ADC_DAT_L	=	0x00f4
                           0000F5   373 _ADC_DAT_H	=	0x00f5
                           0000F6   374 _ADC_CHAN	=	0x00f6
                           0000A6   375 _LED_COMMON	=	0x00a6
                           0000A7   376 _LED_PWM_OE	=	0x00a7
                           00C7C6   377 _LED_DMA	=	0xc7c6
                           0000C6   378 _LED_DMA_L	=	0x00c6
                           0000C7   379 _LED_DMA_H	=	0x00c7
                           0000F7   380 _LED_STATUS	=	0x00f7
                           0000B3   381 _I2CX_INT	=	0x00b3
                           0000BB   382 _I2CS_INT_ST	=	0x00bb
                                    383 ;--------------------------------------------------------
                                    384 ; special function bits
                                    385 ;--------------------------------------------------------
                                    386 	.area RSEG    (ABS,DATA)
      000000                        387 	.org 0x0000
                           0000D7   388 _CY	=	0x00d7
                           0000D6   389 _AC	=	0x00d6
                           0000D5   390 _F0	=	0x00d5
                           0000D4   391 _RS1	=	0x00d4
                           0000D3   392 _RS0	=	0x00d3
                           0000D2   393 _OV	=	0x00d2
                           0000D1   394 _F1	=	0x00d1
                           0000D0   395 _P	=	0x00d0
                           0000AF   396 _EA	=	0x00af
                           0000AE   397 _E_DIS	=	0x00ae
                           0000AD   398 _ET2	=	0x00ad
                           0000AC   399 _ES	=	0x00ac
                           0000AB   400 _ET1	=	0x00ab
                           0000AA   401 _EX1	=	0x00aa
                           0000A9   402 _ET0	=	0x00a9
                           0000A8   403 _EX0	=	0x00a8
                           0000BF   404 _PH_FLAG	=	0x00bf
                           0000BE   405 _PL_FLAG	=	0x00be
                           0000BD   406 _PT2	=	0x00bd
                           0000BC   407 _PS	=	0x00bc
                           0000BB   408 _PT1	=	0x00bb
                           0000BA   409 _PX1	=	0x00ba
                           0000B9   410 _PT0	=	0x00b9
                           0000B8   411 _PX0	=	0x00b8
                           0000EF   412 _IE_WDOG	=	0x00ef
                           0000EE   413 _IE_GPIO	=	0x00ee
                           0000ED   414 _IE_PWM_I2C	=	0x00ed
                           0000EC   415 _IE_UART1	=	0x00ec
                           0000EB   416 _IE_ADC	=	0x00eb
                           0000E9   417 _IE_USB	=	0x00e9
                           0000E8   418 _IE_SPI0	=	0x00e8
                           000087   419 _P0_7	=	0x0087
                           000086   420 _P0_6	=	0x0086
                           000085   421 _P0_5	=	0x0085
                           000084   422 _P0_4	=	0x0084
                           000083   423 _P0_3	=	0x0083
                           000082   424 _P0_2	=	0x0082
                           000081   425 _P0_1	=	0x0081
                           000080   426 _P0_0	=	0x0080
                           000081   427 _SDA0	=	0x0081
                           000080   428 _SCL0	=	0x0080
                           000083   429 _TXD_	=	0x0083
                           000082   430 _RXD_	=	0x0082
                           000085   431 _AIN13	=	0x0085
                           000084   432 _AIN12	=	0x0084
                           000083   433 _AIN11	=	0x0083
                           000082   434 _AIN10	=	0x0082
                           000081   435 _AIN9	=	0x0081
                           000080   436 _AIN8	=	0x0080
                           000097   437 _P1_7	=	0x0097
                           000096   438 _P1_6	=	0x0096
                           000095   439 _P1_5	=	0x0095
                           000094   440 _P1_4	=	0x0094
                           000093   441 _P1_3	=	0x0093
                           000092   442 _P1_2	=	0x0092
                           000091   443 _P1_1	=	0x0091
                           000090   444 _P1_0	=	0x0090
                           000097   445 _TXD1_	=	0x0097
                           000096   446 _RXD1_	=	0x0096
                           000097   447 _SCK	=	0x0097
                           000096   448 _MISO	=	0x0096
                           000095   449 _MOSI	=	0x0095
                           000094   450 _SCS	=	0x0094
                           000092   451 _INT0_	=	0x0092
                           000091   452 _T2EX	=	0x0091
                           000091   453 _CAP2	=	0x0091
                           000090   454 _T2	=	0x0090
                           000090   455 _CAP1	=	0x0090
                           000097   456 _AIN7	=	0x0097
                           000096   457 _AIN6	=	0x0096
                           000095   458 _AIN5	=	0x0095
                           000094   459 _AIN4	=	0x0094
                           000093   460 _AIN3	=	0x0093
                           000092   461 _AIN2	=	0x0092
                           000091   462 _AIN1	=	0x0091
                           000090   463 _AIN0	=	0x0090
                           0000A7   464 _P2_7	=	0x00a7
                           0000A6   465 _P2_6	=	0x00a6
                           0000A5   466 _P2_5	=	0x00a5
                           0000A4   467 _P2_4	=	0x00a4
                           0000A3   468 _P2_3	=	0x00a3
                           0000A2   469 _P2_2	=	0x00a2
                           0000A1   470 _P2_1	=	0x00a1
                           0000A0   471 _P2_0	=	0x00a0
                           0000A7   472 _TXD1	=	0x00a7
                           0000A6   473 _RXD1	=	0x00a6
                           0000A5   474 _T2EX_	=	0x00a5
                           0000A5   475 _CAP2_	=	0x00a5
                           0000A4   476 _T2_	=	0x00a4
                           0000A4   477 _CAP1_	=	0x00a4
                           0000B7   478 _P3_7	=	0x00b7
                           0000B6   479 _P3_6	=	0x00b6
                           0000B5   480 _P3_5	=	0x00b5
                           0000B4   481 _P3_4	=	0x00b4
                           0000B3   482 _P3_3	=	0x00b3
                           0000B2   483 _P3_2	=	0x00b2
                           0000B1   484 _P3_1	=	0x00b1
                           0000B0   485 _P3_0	=	0x00b0
                           0000B7   486 _SCK1	=	0x00b7
                           0000B6   487 _MISO1	=	0x00b6
                           0000B5   488 _MOSI1	=	0x00b5
                           0000B5   489 _T1	=	0x00b5
                           0000B4   490 _T0	=	0x00b4
                           0000B3   491 _INT1	=	0x00b3
                           0000B2   492 _INT0	=	0x00b2
                           0000B1   493 _TXD	=	0x00b1
                           0000B0   494 _RXD	=	0x00b0
                           0000C6   495 _P4_6	=	0x00c6
                           0000C5   496 _P4_5	=	0x00c5
                           0000C4   497 _P4_4	=	0x00c4
                           0000C3   498 _P4_3	=	0x00c3
                           0000C2   499 _P4_2	=	0x00c2
                           0000C1   500 _P4_1	=	0x00c1
                           0000C0   501 _P4_0	=	0x00c0
                           00008F   502 _TF1	=	0x008f
                           00008E   503 _TR1	=	0x008e
                           00008D   504 _TF0	=	0x008d
                           00008C   505 _TR0	=	0x008c
                           00008B   506 _IE1	=	0x008b
                           00008A   507 _IT1	=	0x008a
                           000089   508 _IE0	=	0x0089
                           000088   509 _IT0	=	0x0088
                           00009F   510 _SM0	=	0x009f
                           00009E   511 _SM1	=	0x009e
                           00009D   512 _SM2	=	0x009d
                           00009C   513 _REN	=	0x009c
                           00009B   514 _TB8	=	0x009b
                           00009A   515 _RB8	=	0x009a
                           000099   516 _TI	=	0x0099
                           000098   517 _RI	=	0x0098
                           0000CF   518 _TF2	=	0x00cf
                           0000CF   519 _CAP1F	=	0x00cf
                           0000CE   520 _EXF2	=	0x00ce
                           0000CD   521 _RCLK	=	0x00cd
                           0000CC   522 _TCLK	=	0x00cc
                           0000CB   523 _EXEN2	=	0x00cb
                           0000CA   524 _TR2	=	0x00ca
                           0000C9   525 _C_T2	=	0x00c9
                           0000C8   526 _CP_RL2	=	0x00c8
                           0000FF   527 _S0_FST_ACT	=	0x00ff
                           0000FE   528 _S0_IF_OV	=	0x00fe
                           0000FD   529 _S0_IF_FIRST	=	0x00fd
                           0000FC   530 _S0_IF_BYTE	=	0x00fc
                           0000FB   531 _S0_FREE	=	0x00fb
                           0000FA   532 _S0_T_FIFO	=	0x00fa
                           0000F8   533 _S0_R_FIFO	=	0x00f8
                           0000F7   534 _ADC_START	=	0x00f7
                                    535 ;--------------------------------------------------------
                                    536 ; overlayable register banks
                                    537 ;--------------------------------------------------------
                                    538 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        539 	.ds 8
                                    540 ;--------------------------------------------------------
                                    541 ; internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area DSEG    (DATA)
      000046                        544 _vial_handle_cmd_sloc0_1_0:
      000046                        545 	.ds 2
      000048                        546 _vial_handle_cmd_sloc1_1_0:
      000048                        547 	.ds 2
      00004A                        548 _vial_handle_cmd_sloc2_1_0:
      00004A                        549 	.ds 2
      00004C                        550 _vial_handle_cmd_sloc3_1_0:
      00004C                        551 	.ds 2
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
                                    568 ;--------------------------------------------------------
                                    569 ; paged external ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area PSEG    (PAG,XDATA)
                                    572 ;--------------------------------------------------------
                                    573 ; uninitialized external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XSEG    (XDATA)
      000CC2                        576 _vial_unlock_timer:
      000CC2                        577 	.ds 4
      000CC6                        578 _vial_unlock_holding:
      000CC6                        579 	.ds 1
      000CC7                        580 _vial_keycode_firewall_in_10000_619:
      000CC7                        581 	.ds 2
      000CC9                        582 _vial_fill_packet_PARM_2:
      000CC9                        583 	.ds 1
      000CCA                        584 _vial_fill_packet_msg_10000_622:
      000CCA                        585 	.ds 2
      000CCC                        586 _vial_handle_cmd_PARM_2:
      000CCC                        587 	.ds 1
      000CCD                        588 _vial_handle_cmd_data_10000_627:
      000CCD                        589 	.ds 3
      000CD0                        590 _vial_handle_cmd_entry_70000_655:
      000CD0                        591 	.ds 10
      000CDA                        592 _vial_handle_cmd_entry_70000_656:
      000CDA                        593 	.ds 10
      000CE4                        594 _vial_handle_cmd_entry_70000_658:
      000CE4                        595 	.ds 10
      000CEE                        596 _vial_handle_cmd_entry_70000_659:
      000CEE                        597 	.ds 10
      000CF8                        598 _g_vial_magic_keycode_override::
      000CF8                        599 	.ds 2
      000CFA                        600 _vial_keycode_down_keycode_10000_661:
      000CFA                        601 	.ds 2
      000CFC                        602 _vial_keycode_down_dummy_event_30000_668:
      000CFC                        603 	.ds 6
      000D02                        604 _vial_keycode_up_keycode_10000_669:
      000D02                        605 	.ds 2
      000D04                        606 _vial_keycode_up_dummy_event_30000_676:
      000D04                        607 	.ds 6
      000D0A                        608 _vial_keycode_tap_keycode_10000_677:
      000D0A                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
      000EA3                        618 _vial_unlocked::
      000EA3                        619 	.ds 1
      000EA4                        620 _vial_unlock_in_progress::
      000EA4                        621 	.ds 1
      000EA5                        622 _vial_unlock_counter:
      000EA5                        623 	.ds 1
      000EA6                        624 _vial_unlock_combo_rows:
      000EA6                        625 	.ds 2
      000EA8                        626 _vial_unlock_combo_cols:
      000EA8                        627 	.ds 2
                                    628 	.area HOME    (CODE)
                                    629 	.area GSINIT0 (CODE)
                                    630 	.area GSINIT1 (CODE)
                                    631 	.area GSINIT2 (CODE)
                                    632 	.area GSINIT3 (CODE)
                                    633 	.area GSINIT4 (CODE)
                                    634 	.area GSINIT5 (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area CSEG    (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; global & static initialisations
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area GSINIT  (CODE)
                                    643 	.area GSFINAL (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 ;--------------------------------------------------------
                                    646 ; Home
                                    647 ;--------------------------------------------------------
                                    648 	.area HOME    (CODE)
                                    649 	.area HOME    (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; code
                                    652 ;--------------------------------------------------------
                                    653 	.area CSEG    (CODE)
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    656 ;------------------------------------------------------------
                                    657 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    658 ;------------------------------------------------------------
                                    659 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    660 ;	-----------------------------------------
                           000007   661 	ar7 = 0x07
                           000006   662 	ar6 = 0x06
                           000005   663 	ar5 = 0x05
                           000004   664 	ar4 = 0x04
                           000003   665 	ar3 = 0x03
                           000002   666 	ar2 = 0x02
                           000001   667 	ar1 = 0x01
                           000000   668 	ar0 = 0x00
                                    669 ;	 function vial_unlock_task
                                    670 ;	-----------------------------------------
      00B187                        671 _vial_unlock_task:
                                    672 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B187 90 0E A4         [24]  673 	mov	dptr,#_vial_unlock_in_progress
      00B18A E0               [24]  674 	movx	a,@dptr
      00B18B 70 01            [24]  675 	jnz	00131$
      00B18D 22               [24]  676 	ret
                                    677 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B18E                        678 00131$:
      00B18E 7F 00            [12]  679 	mov	r7,#0x00
      00B190                        680 00115$:
      00B190 BF 02 00         [24]  681 	cjne	r7,#0x02,00184$
      00B193                        682 00184$:
      00B193 50 29            [24]  683 	jnc	00105$
                                    684 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B195 EF               [12]  685 	mov	a,r7
      00B196 12 B8 0D         [24]  686 	lcall	_ak820_outline_0135
      00B199 FE               [12]  687 	mov	r6,a
      00B19A EF               [12]  688 	mov	a,r7
      00B19B 12 B8 02         [24]  689 	lcall	_ak820_outline_0134
      00B19E 90 07 C0         [24]  690 	mov	dptr,#_matrix_is_on_PARM_2
      00B1A1 F0               [24]  691 	movx	@dptr,a
      00B1A2 8E 82            [24]  692 	mov	dpl, r6
      00B1A4 C0 07            [24]  693 	push	ar7
      00B1A6 12 5D C4         [24]  694 	lcall	_matrix_is_on
      00B1A9 E5 82            [12]  695 	mov	a, dpl
      00B1AB D0 07            [24]  696 	pop	ar7
      00B1AD 70 0C            [24]  697 	jnz	00116$
                                    698 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B1AF 90 0C C6         [24]  699 	mov	dptr,#_vial_unlock_holding
      00B1B2 E4               [12]  700 	clr	a
      00B1B3 F0               [24]  701 	movx	@dptr,a
                                    702 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B1B4 90 0E A5         [24]  703 	mov	dptr,#_vial_unlock_counter
      00B1B7 74 1E            [12]  704 	mov	a,#0x1e
      00B1B9 F0               [24]  705 	movx	@dptr,a
                                    706 ;	quantum/vial.c:69: return;
      00B1BA 22               [24]  707 	ret
      00B1BB                        708 00116$:
                                    709 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B1BB 0F               [12]  710 	inc	r7
      00B1BC 80 D2            [24]  711 	sjmp	00115$
      00B1BE                        712 00105$:
                                    713 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B1BE 90 0C C6         [24]  714 	mov	dptr,#_vial_unlock_holding
      00B1C1 E0               [24]  715 	movx	a,@dptr
      00B1C2 70 12            [24]  716 	jnz	00107$
                                    717 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B1C4 90 0C C6         [24]  718 	mov	dptr,#_vial_unlock_holding
      00B1C7 74 01            [12]  719 	mov	a,#0x01
      00B1C9 F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B1CA 12 4D B2         [24]  722 	lcall	_timer_read32
      00B1CD 12 53 C3         [24]  723 	lcall	_ak820_outline_0062
      00B1D0 90 0C C2         [24]  724 	mov	dptr,#_vial_unlock_timer
      00B1D3 12 96 1F         [24]  725 	lcall	_ak820_outline_0008
      00B1D6                        726 00107$:
                                    727 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B1D6 90 0C C2         [24]  728 	mov	dptr,#_vial_unlock_timer
      00B1D9 12 53 B2         [24]  729 	lcall	_ak820_outline_0059
      00B1DC 12 4E 0B         [24]  730 	lcall	_timer_elapsed32
      00B1DF 12 53 C3         [24]  731 	lcall	_ak820_outline_0062
                                    732 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B1E2 7B 1E            [12]  733 	mov	r3,#0x1e
      00B1E4                        734 00109$:
      00B1E4 EB               [12]  735 	mov	a,r3
      00B1E5 60 22            [24]  736 	jz	00111$
      00B1E7 C3               [12]  737 	clr	c
      00B1E8 EC               [12]  738 	mov	a,r4
      00B1E9 94 64            [12]  739 	subb	a,#0x64
      00B1EB ED               [12]  740 	mov	a,r5
      00B1EC 94 00            [12]  741 	subb	a,#0x00
      00B1EE EE               [12]  742 	mov	a,r6
      00B1EF 94 00            [12]  743 	subb	a,#0x00
      00B1F1 EF               [12]  744 	mov	a,r7
      00B1F2 94 00            [12]  745 	subb	a,#0x00
      00B1F4 40 13            [24]  746 	jc	00111$
                                    747 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B1F6 EC               [12]  748 	mov	a,r4
      00B1F7 24 9C            [12]  749 	add	a,#0x9c
      00B1F9 FC               [12]  750 	mov	r4,a
      00B1FA ED               [12]  751 	mov	a,r5
      00B1FB 34 FF            [12]  752 	addc	a,#0xff
      00B1FD FD               [12]  753 	mov	r5,a
      00B1FE EE               [12]  754 	mov	a,r6
      00B1FF 34 FF            [12]  755 	addc	a,#0xff
      00B201 FE               [12]  756 	mov	r6,a
      00B202 EF               [12]  757 	mov	a,r7
      00B203 34 FF            [12]  758 	addc	a,#0xff
      00B205 FF               [12]  759 	mov	r7,a
                                    760 ;	quantum/vial.c:82: --counter;
      00B206 1B               [12]  761 	dec	r3
      00B207 80 DB            [24]  762 	sjmp	00109$
      00B209                        763 00111$:
                                    764 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B209 90 0E A5         [24]  765 	mov	dptr,#_vial_unlock_counter
      00B20C EB               [12]  766 	mov	a,r3
      00B20D F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:85: if (!counter) {
      00B20E EB               [12]  769 	mov	a,r3
      00B20F 70 0A            [24]  770 	jnz	00117$
                                    771 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B211 90 0E A4         [24]  772 	mov	dptr,#_vial_unlock_in_progress
      00B214 E4               [12]  773 	clr	a
      00B215 F0               [24]  774 	movx	@dptr,a
                                    775 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B216 90 0E A3         [24]  776 	mov	dptr,#_vial_unlocked
      00B219 04               [12]  777 	inc	a
      00B21A F0               [24]  778 	movx	@dptr,a
      00B21B                        779 00117$:
                                    780 ;	quantum/vial.c:90: }
      00B21B 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'vial_init'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/vial.c:117: void vial_init(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function vial_init
                                    788 ;	-----------------------------------------
      00B21C                        789 _vial_init:
                                    790 ;	quantum/vial.c:125: reload_combo();
      00B21C 12 35 37         [24]  791 	lcall	_ak820_combo_reload
                                    792 ;	quantum/vial.c:128: reload_key_override();
                                    793 ;	quantum/vial.c:130: }
      00B21F 02 3C AB         [24]  794 	ljmp	_ak820_key_override_reload
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    797 ;------------------------------------------------------------
                                    798 ;in            Allocated with name '_vial_keycode_firewall_in_10000_619'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function vial_keycode_firewall
                                    803 ;	-----------------------------------------
      00B222                        804 _vial_keycode_firewall:
      00B222 12 38 42         [24]  805 	lcall	_ak820_outline_0108
      00B225 90 0C C7         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B228 12 38 47         [24]  807 	lcall	_ak820_outline_0109
                                    808 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B22B 90 0C C7         [24]  809 	mov	dptr,#_vial_keycode_firewall_in_10000_619
      00B22E 12 37 C4         [24]  810 	lcall	_ak820_outline_0010
      00B231 BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00B234 BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00B237 90 0E A3         [24]  813 	mov	dptr,#_vial_unlocked
      00B23A E0               [24]  814 	movx	a,@dptr
      00B23B 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:134: return 0;
      00B23D 90 00 00         [24]  817 	mov	dptr,#0x0000
      00B240 22               [24]  818 	ret
      00B241                        819 00102$:
                                    820 ;	quantum/vial.c:135: return in;
      00B241 12 48 38         [24]  821 	lcall	_ak820_outline_0123
                                    822 ;	quantum/vial.c:136: }
      00B244 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_622'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_624'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00B245                        835 _vial_fill_packet:
      00B245 12 38 42         [24]  836 	lcall	_ak820_outline_0108
      00B248 90 0C CA         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B24B 12 38 47         [24]  838 	lcall	_ak820_outline_0109
                                    839 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B24E 90 0C CA         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_622
      00B251 12 37 F9         [24]  841 	lcall	_ak820_outline_0056
      00B254 90 0C C9         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00B257 E0               [24]  843 	movx	a,@dptr
      00B258 FD               [12]  844 	mov	r5,a
      00B259 7C 00            [12]  845 	mov	r4,#0x00
      00B25B                        846 00103$:
      00B25B BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00B25E                        848 00122$:
      00B25E 50 09            [24]  849 	jnc	00105$
      00B260 EC               [12]  850 	mov	a,r4
      00B261 12 37 F1         [24]  851 	lcall	_ak820_outline_0033
      00B264 ED               [12]  852 	mov	a,r5
      00B265 F0               [24]  853 	movx	@dptr,a
      00B266 0C               [12]  854 	inc	r4
      00B267 80 F2            [24]  855 	sjmp	00103$
      00B269                        856 00105$:
                                    857 ;	quantum/vial.c:141: }
      00B269 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00B26A                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:174: repeat_key_cancel();
      00B26A 12 A6 95         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:176: clear_keyboard();
                                    870 ;	quantum/vial.c:177: }
      00B26D 02 7A 8F         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_627'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_628'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_633'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_634'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_637'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_639'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_639'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_639'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_640'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_641'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_641'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_641'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_644'
                                    893 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_655'
                                    894 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_655'
                                    895 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_656'
                                    896 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_656'
                                    897 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_658'
                                    898 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_658'
                                    899 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_659'
                                    900 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_659'
                                    901 ;------------------------------------------------------------
                                    902 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    903 ;	-----------------------------------------
                                    904 ;	 function vial_handle_cmd
                                    905 ;	-----------------------------------------
      00B270                        906 _vial_handle_cmd:
      00B270 12 47 F5         [24]  907 	lcall	_ak820_outline_0040
      00B273 90 0C CD         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B276 12 37 E1         [24]  909 	lcall	_ak820_outline_0019
                                    910 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B279 90 0C CD         [24]  911 	mov	dptr,#_vial_handle_cmd_data_10000_627
      00B27C 12 37 F9         [24]  912 	lcall	_ak820_outline_0056
                                    913 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B27F 90 0C CC         [24]  914 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B282 E0               [24]  915 	movx	a,@dptr
      00B283 FD               [12]  916 	mov	r5,a
      00B284 BD 20 02         [24]  917 	cjne	r5,#0x20,00255$
      00B287 80 01            [24]  918 	sjmp	00102$
      00B289                        919 00255$:
                                    920 ;	quantum/vial.c:190: return;
      00B289 22               [24]  921 	ret
      00B28A                        922 00102$:
                                    923 ;	quantum/vial.c:193: switch (msg[1]) {
      00B28A 74 01            [12]  924 	mov	a,#0x01
      00B28C 12 3F EB         [24]  925 	lcall	_ak820_outline_0009
      00B28F FB               [12]  926 	mov  r3,a
      00B290 24 F2            [12]  927 	add	a,#0xff - 0x0d
      00B292 50 01            [24]  928 	jnc	00256$
      00B294 22               [24]  929 	ret
      00B295                        930 00256$:
                                    931 ;	free result
      00B295 EB               [12]  932 	mov	a,r3
      00B296 24 0A            [12]  933 	add	a,#(00257$-3-.)
      00B298 83               [24]  934 	movc	a,@a+pc
      00B299 F5 82            [12]  935 	mov	dpl,a
      00B29B EB               [12]  936 	mov	a,r3
      00B29C 24 12            [12]  937 	add	a,#(00258$-3-.)
      00B29E 83               [24]  938 	movc	a,@a+pc
      00B29F F5 83            [12]  939 	mov	dph,a
      00B2A1 E4               [12]  940 	clr	a
      00B2A2 73               [24]  941 	jmp	@a+dptr
      00B2A3                        942 00257$:
      00B2A3 BF                     943 	.db	00103$
      00B2A4 07                     944 	.db	00105$
      00B2A5 1C                     945 	.db	00106$
      00B2A6 A7                     946 	.db	00112$
      00B2A7 2D                     947 	.db	00113$
      00B2A8 77                     948 	.db	00114$
      00B2A9 E6                     949 	.db	00116$
      00B2AA 01                     950 	.db	00119$
      00B2AB 21                     951 	.db	00120$
      00B2AC 2F                     952 	.db	00121$
      00B2AD EF                     953 	.db	00143$
      00B2AE EF                     954 	.db	00143$
      00B2AF EF                     955 	.db	00143$
      00B2B0 3A                     956 	.db	00122$
      00B2B1                        957 00258$:
      00B2B1 B2                     958 	.db	00103$>>8
      00B2B2 B3                     959 	.db	00105$>>8
      00B2B3 B3                     960 	.db	00106$>>8
      00B2B4 B3                     961 	.db	00112$>>8
      00B2B5 B4                     962 	.db	00113$>>8
      00B2B6 B4                     963 	.db	00114$>>8
      00B2B7 B4                     964 	.db	00116$>>8
      00B2B8 B5                     965 	.db	00119$>>8
      00B2B9 B5                     966 	.db	00120$>>8
      00B2BA B5                     967 	.db	00121$>>8
      00B2BB B6                     968 	.db	00143$>>8
      00B2BC B6                     969 	.db	00143$>>8
      00B2BD B6                     970 	.db	00143$>>8
      00B2BE B5                     971 	.db	00122$>>8
                                    972 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B2BF                        973 00103$:
                                    974 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B2BF 90 0C C9         [24]  975 	mov	dptr,#_vial_fill_packet_PARM_2
      00B2C2 E4               [12]  976 	clr	a
      00B2C3 12 48 19         [24]  977 	lcall	_ak820_outline_0066
      00B2C6 C0 07            [24]  978 	push	ar7
      00B2C8 C0 06            [24]  979 	push	ar6
      00B2CA 12 B2 45         [24]  980 	lcall	_vial_fill_packet
      00B2CD D0 06            [24]  981 	pop	ar6
      00B2CF D0 07            [24]  982 	pop	ar7
                                    983 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B2D1 12 48 38         [24]  984 	lcall	_ak820_outline_0123
      00B2D4 74 06            [12]  985 	mov	a,#0x06
      00B2D6 12 48 19         [24]  986 	lcall	_ak820_outline_0066
                                    987 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B2D9 A3               [24]  988 	inc	dptr
      00B2DA E4               [12]  989 	clr	a
      00B2DB 12 47 ED         [24]  990 	lcall	_ak820_outline_0025
                                    991 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B2DE 12 47 ED         [24]  992 	lcall	_ak820_outline_0025
                                    993 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B2E1 A3               [24]  994 	inc	dptr
      00B2E2 F0               [24]  995 	movx	@dptr,a
                                    996 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B2E3 FB               [12]  997 	mov	r3,a
      00B2E4                        998 00135$:
      00B2E4 BB 08 00         [24]  999 	cjne	r3,#0x08,00259$
      00B2E7                       1000 00259$:
      00B2E7 50 15            [24] 1001 	jnc	00104$
      00B2E9 8B 02            [24] 1002 	mov	ar2,r3
      00B2EB 74 04            [12] 1003 	mov	a,#0x04
      00B2ED 2A               [12] 1004 	add	a, r2
      00B2EE 2E               [12] 1005 	add	a, r6
      00B2EF F9               [12] 1006 	mov	r1,a
      00B2F0 E4               [12] 1007 	clr	a
      00B2F1 3F               [12] 1008 	addc	a,r7
      00B2F2 FA               [12] 1009 	mov	r2,a
      00B2F3 EB               [12] 1010 	mov	a,r3
      00B2F4 90 C4 A8         [24] 1011 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_632
      00B2F7 93               [24] 1012 	movc	a,@a+dptr
      00B2F8 12 70 B5         [24] 1013 	lcall	_ak820_outline_0145
      00B2FB 0B               [12] 1014 	inc	r3
      00B2FC 80 E6            [24] 1015 	sjmp	00135$
      00B2FE                       1016 00104$:
                                   1017 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B2FE 74 0C            [12] 1018 	mov	a,#0x0c
      00B300 12 37 F1         [24] 1019 	lcall	_ak820_outline_0033
      00B303 74 01            [12] 1020 	mov	a,#0x01
      00B305 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	quantum/vial.c:207: break;
      00B306 22               [24] 1023 	ret
                                   1024 ;	quantum/vial.c:210: case vial_get_size: {
      00B307                       1025 00105$:
                                   1026 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B307 12 48 38         [24] 1027 	lcall	_ak820_outline_0123
      00B30A 74 7C            [12] 1028 	mov	a,#0x7c
      00B30C F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B30D 12 38 4C         [24] 1031 	lcall	_ak820_outline_0126
      00B310 74 01            [12] 1032 	mov	a,#0x01
      00B312 12 47 ED         [24] 1033 	lcall	_ak820_outline_0025
                                   1034 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B315 E4               [12] 1035 	clr	a
      00B316 12 47 ED         [24] 1036 	lcall	_ak820_outline_0025
                                   1037 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B319 A3               [24] 1038 	inc	dptr
      00B31A F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	quantum/vial.c:216: break;
      00B31B 22               [24] 1041 	ret
                                   1042 ;	quantum/vial.c:219: case vial_get_def: {
      00B31C                       1043 00106$:
                                   1044 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B31C 12 40 0C         [24] 1045 	lcall	_ak820_outline_0017
      00B31F FB               [12] 1046 	mov	r3,a
      00B320 12 47 E3         [24] 1047 	lcall	_ak820_outline_0012
      00B323 E0               [24] 1048 	movx	a,@dptr
      00B324 4B               [12] 1049 	orl	a,r3
      00B325 60 01            [24] 1050 	jz	00108$
      00B327 22               [24] 1051 	ret
      00B328                       1052 00108$:
                                   1053 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B328 12 37 E9         [24] 1054 	lcall	_ak820_outline_0032
      00B32B FB               [12] 1055 	mov	r3,a
      00B32C 7A 00            [12] 1056 	mov	r2,#0x00
      00B32E 12 3F F6         [24] 1057 	lcall	_ak820_outline_0015
      00B331 F9               [12] 1058 	mov	r1,a
      00B332 E4               [12] 1059 	clr	a
      00B333 42 03            [12] 1060 	orl	ar3,a
      00B335 E9               [12] 1061 	mov	a,r1
      00B336 42 02            [12] 1062 	orl	ar2,a
                                   1063 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B338 C3               [12] 1064 	clr	c
      00B339 EB               [12] 1065 	mov	a,r3
      00B33A 94 0C            [12] 1066 	subb	a,#0x0c
      00B33C EA               [12] 1067 	mov	a,r2
      00B33D 94 00            [12] 1068 	subb	a,#0x00
      00B33F 40 01            [24] 1069 	jc	00110$
      00B341 22               [24] 1070 	ret
      00B342                       1071 00110$:
                                   1072 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B342 EA               [12] 1073 	mov	a,r2
      00B343 C4               [12] 1074 	swap	a
      00B344 23               [12] 1075 	rl	a
      00B345 54 E0            [12] 1076 	anl	a,#0xe0
      00B347 CB               [12] 1077 	xch	a,r3
      00B348 C4               [12] 1078 	swap	a
      00B349 23               [12] 1079 	rl	a
      00B34A CB               [12] 1080 	xch	a,r3
      00B34B 6B               [12] 1081 	xrl	a,r3
      00B34C CB               [12] 1082 	xch	a,r3
      00B34D 54 E0            [12] 1083 	anl	a,#0xe0
      00B34F CB               [12] 1084 	xch	a,r3
      00B350 6B               [12] 1085 	xrl	a,r3
      00B351 FA               [12] 1086 	mov	r2,a
      00B352 8B 46            [24] 1087 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B354 8A 47            [24] 1088 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1089 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B356 74 7C            [12] 1090 	mov	a,#0x7c
      00B358 C3               [12] 1091 	clr	c
      00B359 95 46            [12] 1092 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B35B F8               [12] 1093 	mov	r0,a
      00B35C 74 01            [12] 1094 	mov	a,#0x01
      00B35E 95 47            [12] 1095 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B360 F9               [12] 1096 	mov	r1,a
                                   1097 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B361 C3               [12] 1098 	clr	c
      00B362 E8               [12] 1099 	mov	a,r0
      00B363 94 20            [12] 1100 	subb	a,#0x20
      00B365 E9               [12] 1101 	mov	a,r1
      00B366 94 00            [12] 1102 	subb	a,#0x00
      00B368 40 02            [24] 1103 	jc	00146$
      00B36A 78 20            [12] 1104 	mov	r0,#0x20
      00B36C                       1105 00146$:
                                   1106 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B36C 79 00            [12] 1107 	mov	r1,#0x00
      00B36E                       1108 00138$:
      00B36E C3               [12] 1109 	clr	c
      00B36F E9               [12] 1110 	mov	a,r1
      00B370 98               [12] 1111 	subb	a,r0
      00B371 40 01            [24] 1112 	jc	00264$
      00B373 22               [24] 1113 	ret
      00B374                       1114 00264$:
      00B374 C0 00            [24] 1115 	push	ar0
      00B376 E9               [12] 1116 	mov	a,r1
      00B377 2E               [12] 1117 	add	a, r6
      00B378 F5 48            [12] 1118 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B37A E4               [12] 1119 	clr	a
      00B37B 3F               [12] 1120 	addc	a, r7
      00B37C F5 49            [12] 1121 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B37E 89 4A            [24] 1122 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B380 75 4B 00         [24] 1123 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B383 A8 46            [24] 1124 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B385 AB 47            [24] 1125 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B387 E5 4A            [12] 1126 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B389 28               [12] 1127 	add	a, r0
      00B38A F8               [12] 1128 	mov	r0,a
      00B38B E5 4B            [12] 1129 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B38D 3B               [12] 1130 	addc	a, r3
      00B38E FB               [12] 1131 	mov	r3,a
      00B38F E8               [12] 1132 	mov	a,r0
      00B390 24 2C            [12] 1133 	add	a, #_keyboard_definition
      00B392 F5 82            [12] 1134 	mov	dpl,a
      00B394 EB               [12] 1135 	mov	a,r3
      00B395 34 C3            [12] 1136 	addc	a, #(_keyboard_definition >> 8)
      00B397 F5 83            [12] 1137 	mov	dph,a
      00B399 E4               [12] 1138 	clr	a
      00B39A 93               [24] 1139 	movc	a,@a+dptr
      00B39B 85 48 82         [24] 1140 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B39E 85 49 83         [24] 1141 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3A1 F0               [24] 1142 	movx	@dptr,a
      00B3A2 09               [12] 1143 	inc	r1
      00B3A3 D0 00            [24] 1144 	pop	ar0
                                   1145 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B3A5 80 C7            [24] 1146 	sjmp	00138$
      00B3A7                       1147 00112$:
                                   1148 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B3A7 74 02            [12] 1149 	mov	a,#0x02
      00B3A9 12 4D 38         [24] 1150 	lcall	_ak820_outline_0051
      00B3AC F5 4A            [12] 1151 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1152 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B3AE 74 03            [12] 1153 	mov	a,#0x03
      00B3B0 2E               [12] 1154 	add	a, r6
      00B3B1 F5 48            [12] 1155 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B3B3 E4               [12] 1156 	clr	a
      00B3B4 3F               [12] 1157 	addc	a, r7
      00B3B5 F5 49            [12] 1158 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B3B7 85 48 82         [24] 1159 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B3BA 85 49 83         [24] 1160 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3BD E0               [24] 1161 	movx	a,@dptr
                                   1162 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B3BE F5 46            [12] 1163 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B3C0 90 0B 63         [24] 1164 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B3C3 F0               [24] 1165 	movx	@dptr,a
      00B3C4 90 0B 64         [24] 1166 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B3C7 E4               [12] 1167 	clr	a
      00B3C8 F0               [24] 1168 	movx	@dptr,a
      00B3C9 85 4A 82         [24] 1169 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B3CC C0 07            [24] 1170 	push	ar7
      00B3CE C0 06            [24] 1171 	push	ar6
      00B3D0 C0 05            [24] 1172 	push	ar5
      00B3D2 C0 04            [24] 1173 	push	ar4
      00B3D4 C0 03            [24] 1174 	push	ar3
      00B3D6 C0 02            [24] 1175 	push	ar2
      00B3D8 12 89 5D         [24] 1176 	lcall	_dynamic_keymap_get_encoder
      00B3DB 85 82 4C         [24] 1177 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B3DE 85 83 4D         [24] 1178 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B3E1 D0 02            [24] 1179 	pop	ar2
      00B3E3 D0 03            [24] 1180 	pop	ar3
      00B3E5 D0 04            [24] 1181 	pop	ar4
      00B3E7 D0 05            [24] 1182 	pop	ar5
      00B3E9 D0 06            [24] 1183 	pop	ar6
      00B3EB D0 07            [24] 1184 	pop	ar7
                                   1185 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B3ED A9 4D            [24] 1186 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B3EF 12 48 38         [24] 1187 	lcall	_ak820_outline_0123
      00B3F2 E9               [12] 1188 	mov	a,r1
      00B3F3 F0               [24] 1189 	movx	@dptr,a
                                   1190 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B3F4 A8 4C            [24] 1191 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B3F6 12 38 4C         [24] 1192 	lcall	_ak820_outline_0126
      00B3F9 E8               [12] 1193 	mov	a,r0
      00B3FA F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B3FB 90 0B 63         [24] 1196 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B3FE E5 46            [12] 1197 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B400 F0               [24] 1198 	movx	@dptr,a
      00B401 90 0B 64         [24] 1199 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B404 74 01            [12] 1200 	mov	a,#0x01
      00B406 F0               [24] 1201 	movx	@dptr,a
      00B407 85 4A 82         [24] 1202 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B40A C0 03            [24] 1203 	push	ar3
      00B40C C0 02            [24] 1204 	push	ar2
      00B40E 12 89 5D         [24] 1205 	lcall	_dynamic_keymap_get_encoder
      00B411 85 82 4C         [24] 1206 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B414 85 83 4D         [24] 1207 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B417 D0 02            [24] 1208 	pop	ar2
      00B419 D0 03            [24] 1209 	pop	ar3
                                   1210 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B41B A9 4D            [24] 1211 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B41D 12 48 54         [24] 1212 	lcall	_ak820_outline_0149
      00B420 E9               [12] 1213 	mov	a,r1
      00B421 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B422 A8 4C            [24] 1216 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B424 85 48 82         [24] 1217 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B427 85 49 83         [24] 1218 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B42A E8               [12] 1219 	mov	a,r0
      00B42B F0               [24] 1220 	movx	@dptr,a
                                   1221 ;	quantum/vial.c:255: break;
      00B42C 22               [24] 1222 	ret
                                   1223 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B42D                       1224 00113$:
                                   1225 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B42D 12 37 E9         [24] 1226 	lcall	_ak820_outline_0032
      00B430 F5 48            [12] 1227 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B432 12 3F F6         [24] 1228 	lcall	_ak820_outline_0015
      00B435 F5 4A            [12] 1229 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B437 12 40 0C         [24] 1230 	lcall	_ak820_outline_0017
                                   1231 ;	assignBit
      00B43A 24 FF            [12] 1232 	add	a,#0xff
      00B43C E4               [12] 1233 	clr	a
      00B43D 33               [12] 1234 	rlc	a
      00B43E F5 4C            [12] 1235 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B440 12 47 E3         [24] 1236 	lcall	_ak820_outline_0012
      00B443 E0               [24] 1237 	movx	a,@dptr
      00B444 F9               [12] 1238 	mov	r1,a
      00B445 78 00            [12] 1239 	mov	r0,#0x00
      00B447 74 06            [12] 1240 	mov	a,#0x06
      00B449 12 37 CE         [24] 1241 	lcall	_ak820_outline_0013
      00B44C 7B 00            [12] 1242 	mov	r3,#0x00
      00B44E 42 00            [12] 1243 	orl	ar0,a
      00B450 EB               [12] 1244 	mov	a,r3
      00B451 42 01            [12] 1245 	orl	ar1,a
      00B453 12 38 6C         [24] 1246 	lcall	_ak820_outline_0162
      00B456 12 B2 22         [24] 1247 	lcall	_vial_keycode_firewall
      00B459 AA 82            [24] 1248 	mov	r2, dpl
      00B45B AB 83            [24] 1249 	mov	r3, dph
      00B45D 90 0B 66         [24] 1250 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B460 E5 4A            [12] 1251 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B462 F0               [24] 1252 	movx	@dptr,a
      00B463 90 0B 67         [24] 1253 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B466 E5 4C            [12] 1254 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B468 F0               [24] 1255 	movx	@dptr,a
      00B469 90 0B 68         [24] 1256 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B46C EA               [12] 1257 	mov	a,r2
      00B46D F0               [24] 1258 	movx	@dptr,a
      00B46E EB               [12] 1259 	mov	a,r3
      00B46F A3               [24] 1260 	inc	dptr
      00B470 F0               [24] 1261 	movx	@dptr,a
      00B471 85 48 82         [24] 1262 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1263 ;	quantum/vial.c:259: break;
      00B474 02 89 C4         [24] 1264 	ljmp	_dynamic_keymap_set_encoder
                                   1265 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B477                       1266 00114$:
                                   1267 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B477 90 0C C9         [24] 1268 	mov	dptr,#_vial_fill_packet_PARM_2
      00B47A 74 FF            [12] 1269 	mov	a,#0xff
      00B47C 12 48 19         [24] 1270 	lcall	_ak820_outline_0066
      00B47F C0 07            [24] 1271 	push	ar7
      00B481 C0 06            [24] 1272 	push	ar6
      00B483 12 B2 45         [24] 1273 	lcall	_vial_fill_packet
      00B486 D0 06            [24] 1274 	pop	ar6
      00B488 D0 07            [24] 1275 	pop	ar7
                                   1276 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B48A 90 0E A3         [24] 1277 	mov	dptr,#_vial_unlocked
      00B48D E0               [24] 1278 	movx	a,@dptr
      00B48E 12 48 38         [24] 1279 	lcall	_ak820_outline_0123
      00B491 F0               [24] 1280 	movx	@dptr,a
                                   1281 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B492 74 01            [12] 1282 	mov	a,#0x01
      00B494 2E               [12] 1283 	add	a, r6
      00B495 FA               [12] 1284 	mov	r2,a
      00B496 E4               [12] 1285 	clr	a
      00B497 3F               [12] 1286 	addc	a, r7
      00B498 FB               [12] 1287 	mov	r3,a
      00B499 90 0E A4         [24] 1288 	mov	dptr,#_vial_unlock_in_progress
      00B49C E0               [24] 1289 	movx	a,@dptr
      00B49D 12 48 54         [24] 1290 	lcall	_ak820_outline_0149
      00B4A0 F0               [24] 1291 	movx	@dptr,a
                                   1292 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B4A1 7B 00            [12] 1293 	mov	r3,#0x00
      00B4A3                       1294 00141$:
      00B4A3 BB 02 00         [24] 1295 	cjne	r3,#0x02,00265$
      00B4A6                       1296 00265$:
      00B4A6 40 01            [24] 1297 	jc	00266$
      00B4A8 22               [24] 1298 	ret
      00B4A9                       1299 00266$:
                                   1300 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B4A9 8B 01            [24] 1301 	mov	ar1,r3
      00B4AB 7A 00            [12] 1302 	mov	r2,#0x00
      00B4AD E9               [12] 1303 	mov	a,r1
      00B4AE 29               [12] 1304 	add	a,r1
      00B4AF F5 4C            [12] 1305 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B4B1 EA               [12] 1306 	mov	a,r2
      00B4B2 33               [12] 1307 	rlc	a
      00B4B3 F5 4D            [12] 1308 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B4B5 74 02            [12] 1309 	mov	a,#0x02
      00B4B7 25 4C            [12] 1310 	add	a, _vial_handle_cmd_sloc3_1_0
      00B4B9 F8               [12] 1311 	mov	r0,a
      00B4BA E4               [12] 1312 	clr	a
      00B4BB 35 4D            [12] 1313 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B4BD FA               [12] 1314 	mov	r2,a
      00B4BE E8               [12] 1315 	mov	a,r0
      00B4BF 2E               [12] 1316 	add	a, r6
      00B4C0 F8               [12] 1317 	mov	r0,a
      00B4C1 EA               [12] 1318 	mov	a,r2
      00B4C2 3F               [12] 1319 	addc	a, r7
      00B4C3 FA               [12] 1320 	mov	r2,a
      00B4C4 EB               [12] 1321 	mov	a,r3
      00B4C5 12 B8 0D         [24] 1322 	lcall	_ak820_outline_0135
      00B4C8 88 82            [24] 1323 	mov	dpl,r0
      00B4CA 8A 83            [24] 1324 	mov	dph,r2
      00B4CC F0               [24] 1325 	movx	@dptr,a
                                   1326 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B4CD 74 03            [12] 1327 	mov	a,#0x03
      00B4CF 25 4C            [12] 1328 	add	a, _vial_handle_cmd_sloc3_1_0
      00B4D1 F9               [12] 1329 	mov	r1,a
      00B4D2 E4               [12] 1330 	clr	a
      00B4D3 35 4D            [12] 1331 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B4D5 FA               [12] 1332 	mov	r2,a
      00B4D6 E9               [12] 1333 	mov	a,r1
      00B4D7 2E               [12] 1334 	add	a, r6
      00B4D8 F9               [12] 1335 	mov	r1,a
      00B4D9 EA               [12] 1336 	mov	a,r2
      00B4DA 3F               [12] 1337 	addc	a, r7
      00B4DB FA               [12] 1338 	mov	r2,a
      00B4DC EB               [12] 1339 	mov	a,r3
      00B4DD 12 B8 02         [24] 1340 	lcall	_ak820_outline_0134
      00B4E0 12 70 B5         [24] 1341 	lcall	_ak820_outline_0145
                                   1342 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B4E3 0B               [12] 1343 	inc	r3
                                   1344 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B4E4 80 BD            [24] 1345 	sjmp	00141$
      00B4E6                       1346 00116$:
                                   1347 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B4E6 90 0E A4         [24] 1348 	mov	dptr,#_vial_unlock_in_progress
      00B4E9 E0               [24] 1349 	movx	a,@dptr
      00B4EA 70 03            [24] 1350 	jnz	00118$
      00B4EC 12 B2 6A         [24] 1351 	lcall	_vial_release_held_state
      00B4EF                       1352 00118$:
                                   1353 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B4EF 90 0E A4         [24] 1354 	mov	dptr,#_vial_unlock_in_progress
      00B4F2 74 01            [12] 1355 	mov	a,#0x01
      00B4F4 F0               [24] 1356 	movx	@dptr,a
                                   1357 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B4F5 90 0E A5         [24] 1358 	mov	dptr,#_vial_unlock_counter
      00B4F8 74 1E            [12] 1359 	mov	a,#0x1e
      00B4FA F0               [24] 1360 	movx	@dptr,a
                                   1361 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B4FB 90 0C C6         [24] 1362 	mov	dptr,#_vial_unlock_holding
      00B4FE E4               [12] 1363 	clr	a
      00B4FF F0               [24] 1364 	movx	@dptr,a
                                   1365 ;	quantum/vial.c:287: break;
      00B500 22               [24] 1366 	ret
                                   1367 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B501                       1368 00119$:
                                   1369 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B501 90 0E A3         [24] 1370 	mov	dptr,#_vial_unlocked
      00B504 E0               [24] 1371 	movx	a,@dptr
      00B505 12 48 38         [24] 1372 	lcall	_ak820_outline_0123
      00B508 F0               [24] 1373 	movx	@dptr,a
                                   1374 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B509 90 0E A4         [24] 1375 	mov	dptr,#_vial_unlock_in_progress
      00B50C E0               [24] 1376 	movx	a,@dptr
      00B50D 12 38 4C         [24] 1377 	lcall	_ak820_outline_0126
      00B510 F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B511 74 02            [12] 1380 	mov	a,#0x02
      00B513 2E               [12] 1381 	add	a, r6
      00B514 FA               [12] 1382 	mov	r2,a
      00B515 E4               [12] 1383 	clr	a
      00B516 3F               [12] 1384 	addc	a, r7
      00B517 FB               [12] 1385 	mov	r3,a
      00B518 90 0E A5         [24] 1386 	mov	dptr,#_vial_unlock_counter
      00B51B E0               [24] 1387 	movx	a,@dptr
      00B51C 12 48 54         [24] 1388 	lcall	_ak820_outline_0149
      00B51F F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:293: break;
      00B520 22               [24] 1391 	ret
                                   1392 ;	quantum/vial.c:295: case vial_lock: {
      00B521                       1393 00120$:
                                   1394 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B521 90 0E A3         [24] 1395 	mov	dptr,#_vial_unlocked
      00B524 E4               [12] 1396 	clr	a
      00B525 F0               [24] 1397 	movx	@dptr,a
                                   1398 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B526 90 0E A4         [24] 1399 	mov	dptr,#_vial_unlock_in_progress
      00B529 F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B52A 90 0C C6         [24] 1402 	mov	dptr,#_vial_unlock_holding
      00B52D F0               [24] 1403 	movx	@dptr,a
                                   1404 ;	quantum/vial.c:301: break;
      00B52E 22               [24] 1405 	ret
                                   1406 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B52F                       1407 00121$:
                                   1408 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B52F 90 0C C9         [24] 1409 	mov	dptr,#_vial_fill_packet_PARM_2
      00B532 74 FF            [12] 1410 	mov	a,#0xff
      00B534 12 48 19         [24] 1411 	lcall	_ak820_outline_0066
                                   1412 ;	quantum/vial.c:314: break;
      00B537 02 B2 45         [24] 1413 	ljmp	_vial_fill_packet
                                   1414 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B53A                       1415 00122$:
                                   1416 ;	quantum/vial.c:347: switch (msg[2]) {
      00B53A 12 37 E9         [24] 1417 	lcall	_ak820_outline_0032
      00B53D FB               [12] 1418 	mov  r3,a
      00B53E 24 F9            [12] 1419 	add	a,#0xff - 0x06
      00B540 50 01            [24] 1420 	jnc	00268$
      00B542 22               [24] 1421 	ret
      00B543                       1422 00268$:
                                   1423 ;	free result
      00B543 EB               [12] 1424 	mov	a,r3
      00B544 2B               [12] 1425 	add	a,r3
      00B545 2B               [12] 1426 	add	a,r3
      00B546 90 B5 4A         [24] 1427 	mov	dptr,#00269$
      00B549 73               [24] 1428 	jmp	@a+dptr
      00B54A                       1429 00269$:
      00B54A 02 B5 5F         [24] 1430 	ljmp	00123$
      00B54D 02 B6 EF         [24] 1431 	ljmp	00143$
      00B550 02 B6 EF         [24] 1432 	ljmp	00143$
      00B553 02 B5 88         [24] 1433 	ljmp	00124$
      00B556 02 B5 EA         [24] 1434 	ljmp	00125$
      00B559 02 B6 48         [24] 1435 	ljmp	00128$
      00B55C 02 B6 AA         [24] 1436 	ljmp	00129$
                                   1437 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B55F                       1438 00123$:
                                   1439 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B55F 90 0C C9         [24] 1440 	mov	dptr,#_vial_fill_packet_PARM_2
      00B562 E4               [12] 1441 	clr	a
      00B563 12 48 19         [24] 1442 	lcall	_ak820_outline_0066
      00B566 C0 07            [24] 1443 	push	ar7
      00B568 C0 06            [24] 1444 	push	ar6
      00B56A 12 B2 45         [24] 1445 	lcall	_vial_fill_packet
      00B56D D0 06            [24] 1446 	pop	ar6
      00B56F D0 07            [24] 1447 	pop	ar7
                                   1448 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B571 12 48 38         [24] 1449 	lcall	_ak820_outline_0123
      00B574 E4               [12] 1450 	clr	a
      00B575 12 48 19         [24] 1451 	lcall	_ak820_outline_0066
                                   1452 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B578 A3               [24] 1453 	inc	dptr
      00B579 74 08            [12] 1454 	mov	a,#0x08
      00B57B 12 47 ED         [24] 1455 	lcall	_ak820_outline_0025
                                   1456 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B57E F0               [24] 1457 	movx	@dptr,a
                                   1458 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B57F 74 1F            [12] 1459 	mov	a,#0x1f
      00B581 12 37 F1         [24] 1460 	lcall	_ak820_outline_0033
      00B584 74 01            [12] 1461 	mov	a,#0x01
      00B586 F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	quantum/vial.c:356: break;
      00B587 22               [24] 1464 	ret
                                   1465 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B588                       1466 00124$:
                                   1467 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B588 12 3F F6         [24] 1468 	lcall	_ak820_outline_0015
      00B58B FB               [12] 1469 	mov	r3,a
                                   1470 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B58C 90 0C D0         [24] 1471 	mov	dptr,#_vial_handle_cmd_entry_70000_655
      00B58F 12 53 E4         [24] 1472 	lcall	_ak820_outline_0155
      00B592 90 0C D2         [24] 1473 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0002)
      00B595 F0               [24] 1474 	movx	@dptr,a
      00B596 A3               [24] 1475 	inc	dptr
      00B597 F0               [24] 1476 	movx	@dptr,a
      00B598 90 0C D4         [24] 1477 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0004)
      00B59B F0               [24] 1478 	movx	@dptr,a
      00B59C A3               [24] 1479 	inc	dptr
      00B59D F0               [24] 1480 	movx	@dptr,a
      00B59E 90 0C D6         [24] 1481 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0006)
      00B5A1 F0               [24] 1482 	movx	@dptr,a
      00B5A2 A3               [24] 1483 	inc	dptr
      00B5A3 F0               [24] 1484 	movx	@dptr,a
      00B5A4 90 0C D8         [24] 1485 	mov	dptr,#(_vial_handle_cmd_entry_70000_655 + 0x0008)
      00B5A7 F0               [24] 1486 	movx	@dptr,a
      00B5A8 A3               [24] 1487 	inc	dptr
      00B5A9 F0               [24] 1488 	movx	@dptr,a
                                   1489 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B5AA 90 0B 6B         [24] 1490 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B5AD 74 D0            [12] 1491 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B5AF F0               [24] 1492 	movx	@dptr,a
      00B5B0 74 0C            [12] 1493 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B5B2 12 38 1E         [24] 1494 	lcall	_ak820_outline_0076
      00B5B5 8B 82            [24] 1495 	mov	dpl, r3
      00B5B7 C0 07            [24] 1496 	push	ar7
      00B5B9 C0 06            [24] 1497 	push	ar6
      00B5BB C0 05            [24] 1498 	push	ar5
      00B5BD C0 04            [24] 1499 	push	ar4
      00B5BF 12 8A 30         [24] 1500 	lcall	_dynamic_keymap_get_combo
      00B5C2 AA 82            [24] 1501 	mov	r2, dpl
      00B5C4 D0 04            [24] 1502 	pop	ar4
      00B5C6 D0 05            [24] 1503 	pop	ar5
      00B5C8 D0 06            [24] 1504 	pop	ar6
      00B5CA D0 07            [24] 1505 	pop	ar7
      00B5CC 12 48 38         [24] 1506 	lcall	_ak820_outline_0123
      00B5CF EA               [12] 1507 	mov	a,r2
      00B5D0 F0               [24] 1508 	movx	@dptr,a
                                   1509 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B5D1 8C 01            [24] 1510 	mov	ar1,r4
      00B5D3 8D 02            [24] 1511 	mov	ar2,r5
      00B5D5 7B 00            [12] 1512 	mov	r3,#0x00
      00B5D7 90 0E 20         [24] 1513 	mov	dptr,#___memcpy_PARM_2
      00B5DA 74 D0            [12] 1514 	mov	a,#_vial_handle_cmd_entry_70000_655
      00B5DC F0               [24] 1515 	movx	@dptr,a
      00B5DD 74 0C            [12] 1516 	mov	a,#(_vial_handle_cmd_entry_70000_655 >> 8)
      00B5DF 12 B7 DA         [24] 1517 	lcall	_ak820_outline_0011
      00B5E2 12 48 5E         [24] 1518 	lcall	_ak820_outline_0163
      00B5E5 8B F0            [24] 1519 	mov	b, r3
                                   1520 ;	quantum/vial.c:387: break;
      00B5E7 02 BD AE         [24] 1521 	ljmp	___memcpy
                                   1522 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B5EA                       1523 00125$:
                                   1524 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B5EA 12 3F F6         [24] 1525 	lcall	_ak820_outline_0015
      00B5ED FB               [12] 1526 	mov	r3,a
                                   1527 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B5EE 74 04            [12] 1528 	mov	a,#0x04
      00B5F0 2E               [12] 1529 	add	a, r6
      00B5F1 F9               [12] 1530 	mov	r1,a
      00B5F2 E4               [12] 1531 	clr	a
      00B5F3 3F               [12] 1532 	addc	a, r7
      00B5F4 FA               [12] 1533 	mov	r2,a
      00B5F5 90 0E 20         [24] 1534 	mov	dptr,#___memcpy_PARM_2
      00B5F8 E9               [12] 1535 	mov	a,r1
      00B5F9 F0               [24] 1536 	movx	@dptr,a
      00B5FA EA               [12] 1537 	mov	a,r2
      00B5FB 12 B7 DA         [24] 1538 	lcall	_ak820_outline_0011
      00B5FE 90 0C DA         [24] 1539 	mov	dptr,#_vial_handle_cmd_entry_70000_656
      00B601 F5 F0            [12] 1540 	mov	b,a
      00B603 C0 07            [24] 1541 	push	ar7
      00B605 C0 06            [24] 1542 	push	ar6
      00B607 C0 03            [24] 1543 	push	ar3
      00B609 12 BD AE         [24] 1544 	lcall	___memcpy
                                   1545 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B60C 90 0C E2         [24] 1546 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B60F E0               [24] 1547 	movx	a,@dptr
      00B610 F9               [12] 1548 	mov	r1,a
      00B611 A3               [24] 1549 	inc	dptr
      00B612 E0               [24] 1550 	movx	a,@dptr
      00B613 FA               [12] 1551 	mov	r2,a
      00B614 12 48 5E         [24] 1552 	lcall	_ak820_outline_0163
      00B617 12 B2 22         [24] 1553 	lcall	_vial_keycode_firewall
      00B61A A9 82            [24] 1554 	mov	r1, dpl
      00B61C AA 83            [24] 1555 	mov	r2, dph
      00B61E D0 03            [24] 1556 	pop	ar3
      00B620 90 0C E2         [24] 1557 	mov	dptr,#(_vial_handle_cmd_entry_70000_656 + 0x0008)
      00B623 12 4D 60         [24] 1558 	lcall	_ak820_outline_0144
                                   1559 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B626 90 0B 6F         [24] 1560 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B629 74 DA            [12] 1561 	mov	a,#_vial_handle_cmd_entry_70000_656
      00B62B F0               [24] 1562 	movx	@dptr,a
      00B62C 74 0C            [12] 1563 	mov	a,#(_vial_handle_cmd_entry_70000_656 >> 8)
      00B62E 12 38 1E         [24] 1564 	lcall	_ak820_outline_0076
      00B631 8B 82            [24] 1565 	mov	dpl, r3
      00B633 12 8A C6         [24] 1566 	lcall	_dynamic_keymap_set_combo
      00B636 AA 82            [24] 1567 	mov	r2, dpl
      00B638 D0 06            [24] 1568 	pop	ar6
      00B63A D0 07            [24] 1569 	pop	ar7
      00B63C 12 48 38         [24] 1570 	lcall	_ak820_outline_0123
      00B63F EA               [12] 1571 	mov	a,r2
      00B640 F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B641 EA               [12] 1574 	mov	a,r2
      00B642 60 01            [24] 1575 	jz	00270$
      00B644 22               [24] 1576 	ret
      00B645                       1577 00270$:
                                   1578 ;	quantum/vial.c:396: break;
      00B645 02 35 37         [24] 1579 	ljmp	_ak820_combo_reload
                                   1580 ;	quantum/vial.c:400: case dynamic_vial_key_override_get: {
      00B648                       1581 00128$:
                                   1582 ;	quantum/vial.c:401: uint8_t idx = msg[3];
      00B648 12 3F F6         [24] 1583 	lcall	_ak820_outline_0015
      00B64B FB               [12] 1584 	mov	r3,a
                                   1585 ;	quantum/vial.c:402: vial_key_override_entry_t entry = { 0 };
      00B64C 90 0C E4         [24] 1586 	mov	dptr,#_vial_handle_cmd_entry_70000_658
      00B64F 12 53 E4         [24] 1587 	lcall	_ak820_outline_0155
      00B652 90 0C E6         [24] 1588 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0002)
      00B655 F0               [24] 1589 	movx	@dptr,a
      00B656 A3               [24] 1590 	inc	dptr
      00B657 F0               [24] 1591 	movx	@dptr,a
      00B658 90 0C E8         [24] 1592 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0004)
      00B65B F0               [24] 1593 	movx	@dptr,a
      00B65C A3               [24] 1594 	inc	dptr
      00B65D F0               [24] 1595 	movx	@dptr,a
      00B65E 90 0C EA         [24] 1596 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0006)
      00B661 F0               [24] 1597 	movx	@dptr,a
      00B662 90 0C EB         [24] 1598 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0007)
      00B665 F0               [24] 1599 	movx	@dptr,a
      00B666 90 0C EC         [24] 1600 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0008)
      00B669 F0               [24] 1601 	movx	@dptr,a
      00B66A 90 0C ED         [24] 1602 	mov	dptr,#(_vial_handle_cmd_entry_70000_658 + 0x0009)
      00B66D F0               [24] 1603 	movx	@dptr,a
                                   1604 ;	quantum/vial.c:403: msg[0] = dynamic_keymap_get_key_override(idx, &entry);
      00B66E 90 0B 7D         [24] 1605 	mov	dptr,#_dynamic_keymap_get_key_override_PARM_2
      00B671 74 E4            [12] 1606 	mov	a,#_vial_handle_cmd_entry_70000_658
      00B673 F0               [24] 1607 	movx	@dptr,a
      00B674 74 0C            [12] 1608 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00B676 12 38 1E         [24] 1609 	lcall	_ak820_outline_0076
      00B679 8B 82            [24] 1610 	mov	dpl, r3
      00B67B C0 07            [24] 1611 	push	ar7
      00B67D C0 06            [24] 1612 	push	ar6
      00B67F C0 05            [24] 1613 	push	ar5
      00B681 C0 04            [24] 1614 	push	ar4
      00B683 12 8B 68         [24] 1615 	lcall	_dynamic_keymap_get_key_override
      00B686 AA 82            [24] 1616 	mov	r2, dpl
      00B688 D0 04            [24] 1617 	pop	ar4
      00B68A D0 05            [24] 1618 	pop	ar5
      00B68C D0 06            [24] 1619 	pop	ar6
      00B68E D0 07            [24] 1620 	pop	ar7
      00B690 12 48 38         [24] 1621 	lcall	_ak820_outline_0123
      00B693 EA               [12] 1622 	mov	a,r2
      00B694 F0               [24] 1623 	movx	@dptr,a
                                   1624 ;	quantum/vial.c:404: memcpy(&msg[1], &entry, sizeof(entry));
      00B695 7B 00            [12] 1625 	mov	r3,#0x00
      00B697 90 0E 20         [24] 1626 	mov	dptr,#___memcpy_PARM_2
      00B69A 74 E4            [12] 1627 	mov	a,#_vial_handle_cmd_entry_70000_658
      00B69C F0               [24] 1628 	movx	@dptr,a
      00B69D 74 0C            [12] 1629 	mov	a,#(_vial_handle_cmd_entry_70000_658 >> 8)
      00B69F 12 B7 DA         [24] 1630 	lcall	_ak820_outline_0011
      00B6A2 12 38 4C         [24] 1631 	lcall	_ak820_outline_0126
      00B6A5 8B F0            [24] 1632 	mov	b, r3
                                   1633 ;	quantum/vial.c:405: break;
                                   1634 ;	quantum/vial.c:407: case dynamic_vial_key_override_set: {
      00B6A7 02 BD AE         [24] 1635 	ljmp	___memcpy
      00B6AA                       1636 00129$:
                                   1637 ;	quantum/vial.c:408: uint8_t idx = msg[3];
      00B6AA 12 3F F6         [24] 1638 	lcall	_ak820_outline_0015
      00B6AD FD               [12] 1639 	mov	r5,a
                                   1640 ;	quantum/vial.c:410: memcpy(&entry, &msg[4], sizeof(entry));
      00B6AE 74 04            [12] 1641 	mov	a,#0x04
      00B6B0 2E               [12] 1642 	add	a, r6
      00B6B1 FB               [12] 1643 	mov	r3,a
      00B6B2 E4               [12] 1644 	clr	a
      00B6B3 3F               [12] 1645 	addc	a, r7
      00B6B4 FC               [12] 1646 	mov	r4,a
      00B6B5 90 0E 20         [24] 1647 	mov	dptr,#___memcpy_PARM_2
      00B6B8 EB               [12] 1648 	mov	a,r3
      00B6B9 F0               [24] 1649 	movx	@dptr,a
      00B6BA EC               [12] 1650 	mov	a,r4
      00B6BB 12 B7 DA         [24] 1651 	lcall	_ak820_outline_0011
      00B6BE 90 0C EE         [24] 1652 	mov	dptr,#_vial_handle_cmd_entry_70000_659
      00B6C1 F5 F0            [12] 1653 	mov	b,a
      00B6C3 C0 07            [24] 1654 	push	ar7
      00B6C5 C0 06            [24] 1655 	push	ar6
      00B6C7 C0 05            [24] 1656 	push	ar5
      00B6C9 12 BD AE         [24] 1657 	lcall	___memcpy
      00B6CC D0 05            [24] 1658 	pop	ar5
                                   1659 ;	quantum/vial.c:414: msg[0] = dynamic_keymap_set_key_override(idx, &entry);
      00B6CE 90 0B 81         [24] 1660 	mov	dptr,#_dynamic_keymap_set_key_override_PARM_2
      00B6D1 74 EE            [12] 1661 	mov	a,#_vial_handle_cmd_entry_70000_659
      00B6D3 F0               [24] 1662 	movx	@dptr,a
      00B6D4 74 0C            [12] 1663 	mov	a,#(_vial_handle_cmd_entry_70000_659 >> 8)
      00B6D6 12 38 1E         [24] 1664 	lcall	_ak820_outline_0076
      00B6D9 8D 82            [24] 1665 	mov	dpl, r5
      00B6DB 12 8B E8         [24] 1666 	lcall	_dynamic_keymap_set_key_override
      00B6DE AC 82            [24] 1667 	mov	r4, dpl
      00B6E0 D0 06            [24] 1668 	pop	ar6
      00B6E2 D0 07            [24] 1669 	pop	ar7
      00B6E4 12 48 38         [24] 1670 	lcall	_ak820_outline_0123
      00B6E7 EC               [12] 1671 	mov	a,r4
      00B6E8 F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	quantum/vial.c:415: if (!msg[0]) reload_key_override();
      00B6E9 EC               [12] 1674 	mov	a,r4
      00B6EA 70 03            [24] 1675 	jnz	00143$
                                   1676 ;	quantum/vial.c:423: }
                                   1677 ;	quantum/vial.c:424: }
      00B6EC 02 3C AB         [24] 1678 	ljmp	_ak820_key_override_reload
      00B6EF                       1679 00143$:
      00B6EF 22               [24] 1680 	ret
                                   1681 ;------------------------------------------------------------
                                   1682 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1683 ;------------------------------------------------------------
                                   1684 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_661'
                                   1685 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_668'
                                   1686 ;------------------------------------------------------------
                                   1687 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1688 ;	-----------------------------------------
                                   1689 ;	 function vial_keycode_down
                                   1690 ;	-----------------------------------------
      00B6F0                       1691 _vial_keycode_down:
      00B6F0 12 38 42         [24] 1692 	lcall	_ak820_outline_0108
      00B6F3 90 0C FA         [24] 1693 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B6F6 12 38 47         [24] 1694 	lcall	_ak820_outline_0109
                                   1695 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B6F9 90 0C FA         [24] 1696 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B6FC 12 37 C4         [24] 1697 	lcall	_ak820_outline_0010
      00B6FF 74 E0            [12] 1698 	mov	a,#0x100 - 0x20
      00B701 2D               [12] 1699 	add	a,r5
      00B702 50 19            [24] 1700 	jnc	00104$
      00B704 C3               [12] 1701 	clr	c
      00B705 74 FF            [12] 1702 	mov	a,#0xff
      00B707 9C               [12] 1703 	subb	a,r4
      00B708 74 4F            [12] 1704 	mov	a,#0x4f
      00B70A 9D               [12] 1705 	subb	a,r5
      00B70B 40 10            [24] 1706 	jc	00104$
                                   1707 ;	free result
                                   1708 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B70D 90 0C FA         [24] 1709 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B710 EE               [12] 1710 	mov	a,r6
      00B711 12 38 57         [24] 1711 	lcall	_ak820_outline_0132
                                   1712 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B714 90 0C FA         [24] 1713 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B717 E0               [24] 1714 	movx	a,@dptr
      00B718 24 FE            [12] 1715 	add	a,#0xff - 0x01
      00B71A 40 01            [24] 1716 	jc	00104$
                                   1717 ;	free result
      00B71C 22               [24] 1718 	ret
      00B71D                       1719 00104$:
                                   1720 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B71D 90 0C FA         [24] 1721 	mov	dptr,#_vial_keycode_down_keycode_10000_661
      00B720 12 B7 E9         [24] 1722 	lcall	_ak820_outline_0026
                                   1723 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B723 40 06            [24] 1724 	jc	00107$
                                   1725 ;	free result
                                   1726 ;	quantum/vial.c:440: register_code16(keycode);
      00B725 12 48 38         [24] 1727 	lcall	_ak820_outline_0123
      00B728 02 A3 04         [24] 1728 	ljmp	_register_code16
      00B72B                       1729 00107$:
                                   1730 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B72B 90 0D 00         [24] 1731 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0004)
      00B72E 74 01            [12] 1732 	mov	a,#0x01
      00B730 F0               [24] 1733 	movx	@dptr,a
      00B731 90 0C FD         [24] 1734 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0001)
      00B734 74 F0            [12] 1735 	mov	a,#0xf0
      00B736 F0               [24] 1736 	movx	@dptr,a
      00B737 90 0C FC         [24] 1737 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
      00B73A F0               [24] 1738 	movx	@dptr,a
      00B73B 90 0D 01         [24] 1739 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0005)
      00B73E 74 01            [12] 1740 	mov	a,#0x01
      00B740 F0               [24] 1741 	movx	@dptr,a
      00B741 12 4D E3         [24] 1742 	lcall	_timer_read
      00B744 12 48 43         [24] 1743 	lcall	_ak820_outline_0140
      00B747 43 06 01         [24] 1744 	orl	ar6,#0x01
      00B74A 90 0C FE         [24] 1745 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_668 + 0x0002)
      00B74D 12 4D 53         [24] 1746 	lcall	_ak820_outline_0064
                                   1747 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B750 90 0C FC         [24] 1748 	mov	dptr,#_vial_keycode_down_dummy_event_30000_668
                                   1749 ;	quantum/vial.c:448: }
      00B753 02 74 DC         [24] 1750 	ljmp	_ak820_action_exec
                                   1751 ;------------------------------------------------------------
                                   1752 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1753 ;------------------------------------------------------------
                                   1754 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_669'
                                   1755 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_676'
                                   1756 ;------------------------------------------------------------
                                   1757 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1758 ;	-----------------------------------------
                                   1759 ;	 function vial_keycode_up
                                   1760 ;	-----------------------------------------
      00B756                       1761 _vial_keycode_up:
      00B756 12 38 42         [24] 1762 	lcall	_ak820_outline_0108
      00B759 90 0D 02         [24] 1763 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B75C 12 38 47         [24] 1764 	lcall	_ak820_outline_0109
                                   1765 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B75F 90 0D 02         [24] 1766 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B762 12 37 C4         [24] 1767 	lcall	_ak820_outline_0010
      00B765 74 E0            [12] 1768 	mov	a,#0x100 - 0x20
      00B767 2D               [12] 1769 	add	a,r5
      00B768 50 19            [24] 1770 	jnc	00104$
      00B76A C3               [12] 1771 	clr	c
      00B76B 74 FF            [12] 1772 	mov	a,#0xff
      00B76D 9C               [12] 1773 	subb	a,r4
      00B76E 74 4F            [12] 1774 	mov	a,#0x4f
      00B770 9D               [12] 1775 	subb	a,r5
      00B771 40 10            [24] 1776 	jc	00104$
                                   1777 ;	free result
                                   1778 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B773 90 0D 02         [24] 1779 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B776 EE               [12] 1780 	mov	a,r6
      00B777 12 38 57         [24] 1781 	lcall	_ak820_outline_0132
                                   1782 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B77A 90 0D 02         [24] 1783 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B77D E0               [24] 1784 	movx	a,@dptr
      00B77E 24 FE            [12] 1785 	add	a,#0xff - 0x01
      00B780 40 01            [24] 1786 	jc	00104$
                                   1787 ;	free result
      00B782 22               [24] 1788 	ret
      00B783                       1789 00104$:
                                   1790 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B783 90 0D 02         [24] 1791 	mov	dptr,#_vial_keycode_up_keycode_10000_669
      00B786 12 B7 E9         [24] 1792 	lcall	_ak820_outline_0026
                                   1793 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B789 40 06            [24] 1794 	jc	00107$
                                   1795 ;	free result
                                   1796 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B78B 12 48 38         [24] 1797 	lcall	_ak820_outline_0123
      00B78E 02 A3 48         [24] 1798 	ljmp	_unregister_code16
      00B791                       1799 00107$:
                                   1800 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B791 90 0D 08         [24] 1801 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0004)
      00B794 74 01            [12] 1802 	mov	a,#0x01
      00B796 F0               [24] 1803 	movx	@dptr,a
      00B797 90 0D 05         [24] 1804 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0001)
      00B79A 74 F0            [12] 1805 	mov	a,#0xf0
      00B79C F0               [24] 1806 	movx	@dptr,a
      00B79D 90 0D 04         [24] 1807 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
      00B7A0 F0               [24] 1808 	movx	@dptr,a
      00B7A1 90 0D 09         [24] 1809 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0005)
      00B7A4 E4               [12] 1810 	clr	a
      00B7A5 F0               [24] 1811 	movx	@dptr,a
      00B7A6 12 4D E3         [24] 1812 	lcall	_timer_read
      00B7A9 12 48 43         [24] 1813 	lcall	_ak820_outline_0140
      00B7AC 43 06 01         [24] 1814 	orl	ar6,#0x01
      00B7AF 90 0D 06         [24] 1815 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_676 + 0x0002)
      00B7B2 12 4D 53         [24] 1816 	lcall	_ak820_outline_0064
                                   1817 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B7B5 90 0D 04         [24] 1818 	mov	dptr,#_vial_keycode_up_dummy_event_30000_676
                                   1819 ;	quantum/vial.c:470: }
      00B7B8 02 74 DC         [24] 1820 	ljmp	_ak820_action_exec
                                   1821 ;------------------------------------------------------------
                                   1822 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1823 ;------------------------------------------------------------
                                   1824 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_677'
                                   1825 ;i             Allocated with name '_vial_keycode_tap_i_30000_680'
                                   1826 ;------------------------------------------------------------
                                   1827 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1828 ;	-----------------------------------------
                                   1829 ;	 function vial_keycode_tap
                                   1830 ;	-----------------------------------------
      00B7BB                       1831 _vial_keycode_tap:
      00B7BB 12 38 42         [24] 1832 	lcall	_ak820_outline_0108
      00B7BE 90 0D 0A         [24] 1833 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00B7C1 12 38 47         [24] 1834 	lcall	_ak820_outline_0109
                                   1835 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B7C4 90 0D 0A         [24] 1836 	mov	dptr,#_vial_keycode_tap_keycode_10000_677
      00B7C7 12 37 BA         [24] 1837 	lcall	_ak820_outline_0006
      00B7CA C0 07            [24] 1838 	push	ar7
      00B7CC C0 06            [24] 1839 	push	ar6
      00B7CE 12 B6 F0         [24] 1840 	lcall	_vial_keycode_down
      00B7D1 D0 06            [24] 1841 	pop	ar6
      00B7D3 D0 07            [24] 1842 	pop	ar7
                                   1843 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B7D5 12 48 38         [24] 1844 	lcall	_ak820_outline_0123
                                   1845 ;	quantum/vial.c:476: }
      00B7D8 E1 56            [12] 1846 	ajmp	_vial_keycode_up
                                   1847 ;------------------------------------------------------------
                                   1848 ;Allocation info for local variables in function 'process_record_vial'
                                   1849 ;------------------------------------------------------------
                                   1850 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1851 ;keycode       Allocated with name '_process_record_vial_keycode_10000_682'
                                   1852 ;------------------------------------------------------------
                                   1853 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1854 ;	-----------------------------------------
                                   1855 	.area CSEG    (CODE)
                                   1856 	.area CONST   (CODE)
                                   1857 	.area CONST   (CODE)
      00C32C                       1858 _keyboard_definition:
      00C32C FD                    1859 	.db #0xfd	; 253
      00C32D 37                    1860 	.db #0x37	; 55	'7'
      00C32E 7A                    1861 	.db #0x7a	; 122	'z'
      00C32F 58                    1862 	.db #0x58	; 88	'X'
      00C330 5A                    1863 	.db #0x5a	; 90	'Z'
      00C331 00                    1864 	.db #0x00	; 0
      00C332 00                    1865 	.db #0x00	; 0
      00C333 04                    1866 	.db #0x04	; 4
      00C334 E6                    1867 	.db #0xe6	; 230
      00C335 D6                    1868 	.db #0xd6	; 214
      00C336 B4                    1869 	.db #0xb4	; 180
      00C337 46                    1870 	.db #0x46	; 70	'F'
      00C338 02                    1871 	.db #0x02	; 2
      00C339 00                    1872 	.db #0x00	; 0
      00C33A 21                    1873 	.db #0x21	; 33
      00C33B 01                    1874 	.db #0x01	; 1
      00C33C 00                    1875 	.db #0x00	; 0
      00C33D 00                    1876 	.db #0x00	; 0
      00C33E 00                    1877 	.db #0x00	; 0
      00C33F 00                    1878 	.db #0x00	; 0
      00C340 37                    1879 	.db #0x37	; 55	'7'
      00C341 27                    1880 	.db #0x27	; 39
      00C342 97                    1881 	.db #0x97	; 151
      00C343 D6                    1882 	.db #0xd6	; 214
      00C344 E0                    1883 	.db #0xe0	; 224
      00C345 03                    1884 	.db #0x03	; 3
      00C346 CB                    1885 	.db #0xcb	; 203
      00C347 01                    1886 	.db #0x01	; 1
      00C348 3C                    1887 	.db #0x3c	; 60
      00C349 00                    1888 	.db #0x00	; 0
      00C34A 00                    1889 	.db #0x00	; 0
      00C34B 3D                    1890 	.db #0x3d	; 61
      00C34C 88                    1891 	.db #0x88	; 136
      00C34D CD                    1892 	.db #0xcd	; 205
      00C34E A5                    1893 	.db #0xa5	; 165
      00C34F AA                    1894 	.db #0xaa	; 170
      00C350 E5                    1895 	.db #0xe5	; 229
      00C351 A8                    1896 	.db #0xa8	; 168
      00C352 76                    1897 	.db #0x76	; 118	'v'
      00C353 F6                    1898 	.db #0xf6	; 246
      00C354 43                    1899 	.db #0x43	; 67	'C'
      00C355 0E                    1900 	.db #0x0e	; 14
      00C356 D2                    1901 	.db #0xd2	; 210
      00C357 90                    1902 	.db #0x90	; 144
      00C358 7D                    1903 	.db #0x7d	; 125
      00C359 94                    1904 	.db #0x94	; 148
      00C35A 79                    1905 	.db #0x79	; 121	'y'
      00C35B 78                    1906 	.db #0x78	; 120	'x'
      00C35C EF                    1907 	.db #0xef	; 239
      00C35D 49                    1908 	.db #0x49	; 73	'I'
      00C35E 3E                    1909 	.db #0x3e	; 62
      00C35F EF                    1910 	.db #0xef	; 239
      00C360 FD                    1911 	.db #0xfd	; 253
      00C361 8F                    1912 	.db #0x8f	; 143
      00C362 EF                    1913 	.db #0xef	; 239
      00C363 00                    1914 	.db #0x00	; 0
      00C364 C6                    1915 	.db #0xc6	; 198
      00C365 D1                    1916 	.db #0xd1	; 209
      00C366 DB                    1917 	.db #0xdb	; 219
      00C367 FB                    1918 	.db #0xfb	; 251
      00C368 EB                    1919 	.db #0xeb	; 235
      00C369 DE                    1920 	.db #0xde	; 222
      00C36A 66                    1921 	.db #0x66	; 102	'f'
      00C36B 63                    1922 	.db #0x63	; 99	'c'
      00C36C 0C                    1923 	.db #0x0c	; 12
      00C36D 92                    1924 	.db #0x92	; 146
      00C36E 7B                    1925 	.db #0x7b	; 123
      00C36F F9                    1926 	.db #0xf9	; 249
      00C370 D4                    1927 	.db #0xd4	; 212
      00C371 7A                    1928 	.db #0x7a	; 122	'z'
      00C372 4F                    1929 	.db #0x4f	; 79	'O'
      00C373 83                    1930 	.db #0x83	; 131
      00C374 4B                    1931 	.db #0x4b	; 75	'K'
      00C375 86                    1932 	.db #0x86	; 134
      00C376 0E                    1933 	.db #0x0e	; 14
      00C377 6A                    1934 	.db #0x6a	; 106	'j'
      00C378 F2                    1935 	.db #0xf2	; 242
      00C379 22                    1936 	.db #0x22	; 34
      00C37A 22                    1937 	.db #0x22	; 34
      00C37B 0B                    1938 	.db #0x0b	; 11
      00C37C 03                    1939 	.db #0x03	; 3
      00C37D BA                    1940 	.db #0xba	; 186
      00C37E 67                    1941 	.db #0x67	; 103	'g'
      00C37F 9B                    1942 	.db #0x9b	; 155
      00C380 7A                    1943 	.db #0x7a	; 122	'z'
      00C381 E1                    1944 	.db #0xe1	; 225
      00C382 BC                    1945 	.db #0xbc	; 188
      00C383 37                    1946 	.db #0x37	; 55	'7'
      00C384 26                    1947 	.db #0x26	; 38
      00C385 46                    1948 	.db #0x46	; 70	'F'
      00C386 78                    1949 	.db #0x78	; 120	'x'
      00C387 05                    1950 	.db #0x05	; 5
      00C388 0D                    1951 	.db #0x0d	; 13
      00C389 95                    1952 	.db #0x95	; 149
      00C38A 02                    1953 	.db #0x02	; 2
      00C38B E4                    1954 	.db #0xe4	; 228
      00C38C 18                    1955 	.db #0x18	; 24
      00C38D CA                    1956 	.db #0xca	; 202
      00C38E 33                    1957 	.db #0x33	; 51	'3'
      00C38F EA                    1958 	.db #0xea	; 234
      00C390 24                    1959 	.db #0x24	; 36
      00C391 C8                    1960 	.db #0xc8	; 200
      00C392 81                    1961 	.db #0x81	; 129
      00C393 4E                    1962 	.db #0x4e	; 78	'N'
      00C394 47                    1963 	.db #0x47	; 71	'G'
      00C395 A8                    1964 	.db #0xa8	; 168
      00C396 44                    1965 	.db #0x44	; 68	'D'
      00C397 DD                    1966 	.db #0xdd	; 221
      00C398 91                    1967 	.db #0x91	; 145
      00C399 6D                    1968 	.db #0x6d	; 109	'm'
      00C39A 69                    1969 	.db #0x69	; 105	'i'
      00C39B DB                    1970 	.db #0xdb	; 219
      00C39C 4F                    1971 	.db #0x4f	; 79	'O'
      00C39D 3A                    1972 	.db #0x3a	; 58
      00C39E 43                    1973 	.db #0x43	; 67	'C'
      00C39F 9D                    1974 	.db #0x9d	; 157
      00C3A0 26                    1975 	.db #0x26	; 38
      00C3A1 49                    1976 	.db #0x49	; 73	'I'
      00C3A2 4C                    1977 	.db #0x4c	; 76	'L'
      00C3A3 EF                    1978 	.db #0xef	; 239
      00C3A4 2B                    1979 	.db #0x2b	; 43
      00C3A5 D8                    1980 	.db #0xd8	; 216
      00C3A6 55                    1981 	.db #0x55	; 85	'U'
      00C3A7 95                    1982 	.db #0x95	; 149
      00C3A8 70                    1983 	.db #0x70	; 112	'p'
      00C3A9 B1                    1984 	.db #0xb1	; 177
      00C3AA CC                    1985 	.db #0xcc	; 204
      00C3AB CF                    1986 	.db #0xcf	; 207
      00C3AC 13                    1987 	.db #0x13	; 19
      00C3AD 32                    1988 	.db #0x32	; 50	'2'
      00C3AE 6A                    1989 	.db #0x6a	; 106	'j'
      00C3AF A1                    1990 	.db #0xa1	; 161
      00C3B0 FF                    1991 	.db #0xff	; 255
      00C3B1 99                    1992 	.db #0x99	; 153
      00C3B2 61                    1993 	.db #0x61	; 97	'a'
      00C3B3 95                    1994 	.db #0x95	; 149
      00C3B4 B1                    1995 	.db #0xb1	; 177
      00C3B5 89                    1996 	.db #0x89	; 137
      00C3B6 9B                    1997 	.db #0x9b	; 155
      00C3B7 11                    1998 	.db #0x11	; 17
      00C3B8 D9                    1999 	.db #0xd9	; 217
      00C3B9 35                    2000 	.db #0x35	; 53	'5'
      00C3BA 78                    2001 	.db #0x78	; 120	'x'
      00C3BB ED                    2002 	.db #0xed	; 237
      00C3BC CD                    2003 	.db #0xcd	; 205
      00C3BD 94                    2004 	.db #0x94	; 148
      00C3BE 6E                    2005 	.db #0x6e	; 110	'n'
      00C3BF 60                    2006 	.db #0x60	; 96
      00C3C0 8E                    2007 	.db #0x8e	; 142
      00C3C1 63                    2008 	.db #0x63	; 99	'c'
      00C3C2 8B                    2009 	.db #0x8b	; 139
      00C3C3 FF                    2010 	.db #0xff	; 255
      00C3C4 4E                    2011 	.db #0x4e	; 78	'N'
      00C3C5 20                    2012 	.db #0x20	; 32
      00C3C6 7A                    2013 	.db #0x7a	; 122	'z'
      00C3C7 B5                    2014 	.db #0xb5	; 181
      00C3C8 87                    2015 	.db #0x87	; 135
      00C3C9 C2                    2016 	.db #0xc2	; 194
      00C3CA 35                    2017 	.db #0x35	; 53	'5'
      00C3CB A4                    2018 	.db #0xa4	; 164
      00C3CC 6D                    2019 	.db #0x6d	; 109	'm'
      00C3CD 18                    2020 	.db #0x18	; 24
      00C3CE C1                    2021 	.db #0xc1	; 193
      00C3CF A3                    2022 	.db #0xa3	; 163
      00C3D0 DB                    2023 	.db #0xdb	; 219
      00C3D1 53                    2024 	.db #0x53	; 83	'S'
      00C3D2 1D                    2025 	.db #0x1d	; 29
      00C3D3 EC                    2026 	.db #0xec	; 236
      00C3D4 F0                    2027 	.db #0xf0	; 240
      00C3D5 BF                    2028 	.db #0xbf	; 191
      00C3D6 4A                    2029 	.db #0x4a	; 74	'J'
      00C3D7 4C                    2030 	.db #0x4c	; 76	'L'
      00C3D8 4A                    2031 	.db #0x4a	; 74	'J'
      00C3D9 C4                    2032 	.db #0xc4	; 196
      00C3DA AA                    2033 	.db #0xaa	; 170
      00C3DB 37                    2034 	.db #0x37	; 55	'7'
      00C3DC 19                    2035 	.db #0x19	; 25
      00C3DD 34                    2036 	.db #0x34	; 52	'4'
      00C3DE 3F                    2037 	.db #0x3f	; 63
      00C3DF A1                    2038 	.db #0xa1	; 161
      00C3E0 D3                    2039 	.db #0xd3	; 211
      00C3E1 1A                    2040 	.db #0x1a	; 26
      00C3E2 5C                    2041 	.db #0x5c	; 92
      00C3E3 03                    2042 	.db #0x03	; 3
      00C3E4 4D                    2043 	.db #0x4d	; 77	'M'
      00C3E5 BC                    2044 	.db #0xbc	; 188
      00C3E6 10                    2045 	.db #0x10	; 16
      00C3E7 2E                    2046 	.db #0x2e	; 46
      00C3E8 80                    2047 	.db #0x80	; 128
      00C3E9 F7                    2048 	.db #0xf7	; 247
      00C3EA D6                    2049 	.db #0xd6	; 214
      00C3EB 82                    2050 	.db #0x82	; 130
      00C3EC 24                    2051 	.db #0x24	; 36
      00C3ED 4C                    2052 	.db #0x4c	; 76	'L'
      00C3EE 87                    2053 	.db #0x87	; 135
      00C3EF B9                    2054 	.db #0xb9	; 185
      00C3F0 F8                    2055 	.db #0xf8	; 248
      00C3F1 BE                    2056 	.db #0xbe	; 190
      00C3F2 67                    2057 	.db #0x67	; 103	'g'
      00C3F3 96                    2058 	.db #0x96	; 150
      00C3F4 89                    2059 	.db #0x89	; 137
      00C3F5 30                    2060 	.db #0x30	; 48	'0'
      00C3F6 C8                    2061 	.db #0xc8	; 200
      00C3F7 8D                    2062 	.db #0x8d	; 141
      00C3F8 2C                    2063 	.db #0x2c	; 44
      00C3F9 F5                    2064 	.db #0xf5	; 245
      00C3FA 06                    2065 	.db #0x06	; 6
      00C3FB 05                    2066 	.db #0x05	; 5
      00C3FC 7C                    2067 	.db #0x7c	; 124
      00C3FD 48                    2068 	.db #0x48	; 72	'H'
      00C3FE 1B                    2069 	.db #0x1b	; 27
      00C3FF 76                    2070 	.db #0x76	; 118	'v'
      00C400 AA                    2071 	.db #0xaa	; 170
      00C401 3D                    2072 	.db #0x3d	; 61
      00C402 28                    2073 	.db #0x28	; 40
      00C403 FC                    2074 	.db #0xfc	; 252
      00C404 80                    2075 	.db #0x80	; 128
      00C405 75                    2076 	.db #0x75	; 117	'u'
      00C406 EB                    2077 	.db #0xeb	; 235
      00C407 78                    2078 	.db #0x78	; 120	'x'
      00C408 D0                    2079 	.db #0xd0	; 208
      00C409 8A                    2080 	.db #0x8a	; 138
      00C40A 8F                    2081 	.db #0x8f	; 143
      00C40B 27                    2082 	.db #0x27	; 39
      00C40C F7                    2083 	.db #0xf7	; 247
      00C40D F2                    2084 	.db #0xf2	; 242
      00C40E EB                    2085 	.db #0xeb	; 235
      00C40F 58                    2086 	.db #0x58	; 88	'X'
      00C410 37                    2087 	.db #0x37	; 55	'7'
      00C411 3C                    2088 	.db #0x3c	; 60
      00C412 2B                    2089 	.db #0x2b	; 43
      00C413 6F                    2090 	.db #0x6f	; 111	'o'
      00C414 0E                    2091 	.db #0x0e	; 14
      00C415 C7                    2092 	.db #0xc7	; 199
      00C416 E2                    2093 	.db #0xe2	; 226
      00C417 A0                    2094 	.db #0xa0	; 160
      00C418 97                    2095 	.db #0x97	; 151
      00C419 EE                    2096 	.db #0xee	; 238
      00C41A FD                    2097 	.db #0xfd	; 253
      00C41B 9F                    2098 	.db #0x9f	; 159
      00C41C 45                    2099 	.db #0x45	; 69	'E'
      00C41D 17                    2100 	.db #0x17	; 23
      00C41E 94                    2101 	.db #0x94	; 148
      00C41F E6                    2102 	.db #0xe6	; 230
      00C420 E7                    2103 	.db #0xe7	; 231
      00C421 FA                    2104 	.db #0xfa	; 250
      00C422 4C                    2105 	.db #0x4c	; 76	'L'
      00C423 7A                    2106 	.db #0x7a	; 122	'z'
      00C424 D6                    2107 	.db #0xd6	; 214
      00C425 7A                    2108 	.db #0x7a	; 122	'z'
      00C426 7B                    2109 	.db #0x7b	; 123
      00C427 ED                    2110 	.db #0xed	; 237
      00C428 10                    2111 	.db #0x10	; 16
      00C429 C5                    2112 	.db #0xc5	; 197
      00C42A BC                    2113 	.db #0xbc	; 188
      00C42B E3                    2114 	.db #0xe3	; 227
      00C42C A9                    2115 	.db #0xa9	; 169
      00C42D 1F                    2116 	.db #0x1f	; 31
      00C42E CF                    2117 	.db #0xcf	; 207
      00C42F C4                    2118 	.db #0xc4	; 196
      00C430 9D                    2119 	.db #0x9d	; 157
      00C431 DC                    2120 	.db #0xdc	; 220
      00C432 45                    2121 	.db #0x45	; 69	'E'
      00C433 2A                    2122 	.db #0x2a	; 42
      00C434 69                    2123 	.db #0x69	; 105	'i'
      00C435 57                    2124 	.db #0x57	; 87	'W'
      00C436 8F                    2125 	.db #0x8f	; 143
      00C437 EC                    2126 	.db #0xec	; 236
      00C438 85                    2127 	.db #0x85	; 133
      00C439 6C                    2128 	.db #0x6c	; 108	'l'
      00C43A 43                    2129 	.db #0x43	; 67	'C'
      00C43B 1C                    2130 	.db #0x1c	; 28
      00C43C BA                    2131 	.db #0xba	; 186
      00C43D 89                    2132 	.db #0x89	; 137
      00C43E 68                    2133 	.db #0x68	; 104	'h'
      00C43F 4A                    2134 	.db #0x4a	; 74	'J'
      00C440 1C                    2135 	.db #0x1c	; 28
      00C441 91                    2136 	.db #0x91	; 145
      00C442 3F                    2137 	.db #0x3f	; 63
      00C443 D1                    2138 	.db #0xd1	; 209
      00C444 B3                    2139 	.db #0xb3	; 179
      00C445 96                    2140 	.db #0x96	; 150
      00C446 1D                    2141 	.db #0x1d	; 29
      00C447 7C                    2142 	.db #0x7c	; 124
      00C448 14                    2143 	.db #0x14	; 20
      00C449 77                    2144 	.db #0x77	; 119	'w'
      00C44A 9C                    2145 	.db #0x9c	; 156
      00C44B 74                    2146 	.db #0x74	; 116	't'
      00C44C 36                    2147 	.db #0x36	; 54	'6'
      00C44D FF                    2148 	.db #0xff	; 255
      00C44E 2C                    2149 	.db #0x2c	; 44
      00C44F 66                    2150 	.db #0x66	; 102	'f'
      00C450 AF                    2151 	.db #0xaf	; 175
      00C451 0F                    2152 	.db #0x0f	; 15
      00C452 3C                    2153 	.db #0x3c	; 60
      00C453 A2                    2154 	.db #0xa2	; 162
      00C454 23                    2155 	.db #0x23	; 35
      00C455 85                    2156 	.db #0x85	; 133
      00C456 05                    2157 	.db #0x05	; 5
      00C457 87                    2158 	.db #0x87	; 135
      00C458 DA                    2159 	.db #0xda	; 218
      00C459 61                    2160 	.db #0x61	; 97	'a'
      00C45A 5E                    2161 	.db #0x5e	; 94
      00C45B 42                    2162 	.db #0x42	; 66	'B'
      00C45C 54                    2163 	.db #0x54	; 84	'T'
      00C45D 60                    2164 	.db #0x60	; 96
      00C45E 23                    2165 	.db #0x23	; 35
      00C45F CA                    2166 	.db #0xca	; 202
      00C460 BC                    2167 	.db #0xbc	; 188
      00C461 B3                    2168 	.db #0xb3	; 179
      00C462 18                    2169 	.db #0x18	; 24
      00C463 1D                    2170 	.db #0x1d	; 29
      00C464 F8                    2171 	.db #0xf8	; 248
      00C465 0A                    2172 	.db #0x0a	; 10
      00C466 55                    2173 	.db #0x55	; 85	'U'
      00C467 CD                    2174 	.db #0xcd	; 205
      00C468 A3                    2175 	.db #0xa3	; 163
      00C469 DE                    2176 	.db #0xde	; 222
      00C46A FF                    2177 	.db #0xff	; 255
      00C46B B2                    2178 	.db #0xb2	; 178
      00C46C 2A                    2179 	.db #0x2a	; 42
      00C46D 35                    2180 	.db #0x35	; 53	'5'
      00C46E 00                    2181 	.db #0x00	; 0
      00C46F D6                    2182 	.db #0xd6	; 214
      00C470 7B                    2183 	.db #0x7b	; 123
      00C471 E8                    2184 	.db #0xe8	; 232
      00C472 F2                    2185 	.db #0xf2	; 242
      00C473 1A                    2186 	.db #0x1a	; 26
      00C474 BC                    2187 	.db #0xbc	; 188
      00C475 F5                    2188 	.db #0xf5	; 245
      00C476 7E                    2189 	.db #0x7e	; 126
      00C477 48                    2190 	.db #0x48	; 72	'H'
      00C478 72                    2191 	.db #0x72	; 114	'r'
      00C479 E0                    2192 	.db #0xe0	; 224
      00C47A E4                    2193 	.db #0xe4	; 228
      00C47B E0                    2194 	.db #0xe0	; 224
      00C47C 27                    2195 	.db #0x27	; 39
      00C47D 87                    2196 	.db #0x87	; 135
      00C47E 9A                    2197 	.db #0x9a	; 154
      00C47F 51                    2198 	.db #0x51	; 81	'Q'
      00C480 D4                    2199 	.db #0xd4	; 212
      00C481 DD                    2200 	.db #0xdd	; 221
      00C482 C3                    2201 	.db #0xc3	; 195
      00C483 AA                    2202 	.db #0xaa	; 170
      00C484 49                    2203 	.db #0x49	; 73	'I'
      00C485 5A                    2204 	.db #0x5a	; 90	'Z'
      00C486 2A                    2205 	.db #0x2a	; 42
      00C487 00                    2206 	.db #0x00	; 0
      00C488 A0                    2207 	.db #0xa0	; 160
      00C489 8C                    2208 	.db #0x8c	; 140
      00C48A FF                    2209 	.db #0xff	; 255
      00C48B 74                    2210 	.db #0x74	; 116	't'
      00C48C BF                    2211 	.db #0xbf	; 191
      00C48D EC                    2212 	.db #0xec	; 236
      00C48E 1D                    2213 	.db #0x1d	; 29
      00C48F F1                    2214 	.db #0xf1	; 241
      00C490 00                    2215 	.db #0x00	; 0
      00C491 01                    2216 	.db #0x01	; 1
      00C492 D8                    2217 	.db #0xd8	; 216
      00C493 02                    2218 	.db #0x02	; 2
      00C494 CC                    2219 	.db #0xcc	; 204
      00C495 07                    2220 	.db #0x07	; 7
      00C496 00                    2221 	.db #0x00	; 0
      00C497 00                    2222 	.db #0x00	; 0
      00C498 C4                    2223 	.db #0xc4	; 196
      00C499 5E                    2224 	.db #0x5e	; 94
      00C49A 2C                    2225 	.db #0x2c	; 44
      00C49B 7E                    2226 	.db #0x7e	; 126
      00C49C B1                    2227 	.db #0xb1	; 177
      00C49D C4                    2228 	.db #0xc4	; 196
      00C49E 67                    2229 	.db #0x67	; 103	'g'
      00C49F FB                    2230 	.db #0xfb	; 251
      00C4A0 02                    2231 	.db #0x02	; 2
      00C4A1 00                    2232 	.db #0x00	; 0
      00C4A2 00                    2233 	.db #0x00	; 0
      00C4A3 00                    2234 	.db #0x00	; 0
      00C4A4 00                    2235 	.db #0x00	; 0
      00C4A5 04                    2236 	.db #0x04	; 4
      00C4A6 59                    2237 	.db #0x59	; 89	'Y'
      00C4A7 5A                    2238 	.db #0x5a	; 90	'Z'
                                   2239 	.area CSEG    (CODE)
                                   2240 	.area CONST   (CODE)
      00C4A8                       2241 _vial_handle_cmd_keyboard_uid_40000_632:
      00C4A8 04                    2242 	.db #0x04	; 4
      00C4A9 70                    2243 	.db #0x70	; 112	'p'
      00C4AA FF                    2244 	.db #0xff	; 255
      00C4AB 90                    2245 	.db #0x90	; 144
      00C4AC 01                    2246 	.db #0x01	; 1
      00C4AD B9                    2247 	.db #0xb9	; 185
      00C4AE 15                    2248 	.db #0x15	; 21
      00C4AF D3                    2249 	.db #0xd3	; 211
                                   2250 	.area CSEG    (CODE)
                                   2251 	.area XINIT   (CODE)
      00C6E1                       2252 __xinit__vial_unlocked:
      00C6E1 00                    2253 	.db #0x00	;  0
      00C6E2                       2254 __xinit__vial_unlock_in_progress:
      00C6E2 00                    2255 	.db #0x00	;  0
      00C6E3                       2256 __xinit__vial_unlock_counter:
      00C6E3 00                    2257 	.db #0x00	; 0
      00C6E4                       2258 __xinit__vial_unlock_combo_rows:
      00C6E4 00                    2259 	.db #0x00	; 0
      00C6E5 00                    2260 	.db #0x00	; 0
      00C6E6                       2261 __xinit__vial_unlock_combo_cols:
      00C6E6 00                    2262 	.db #0x00	; 0
      00C6E7 05                    2263 	.db #0x05	; 5
                                   2264 	.area CABS    (ABS,CODE)
                                   2265 
                                   2266 ; Experimental exact instruction outlining.
                                   2267 	.globl _ak820_outline_0006
                                   2268 	.globl _ak820_outline_0008
                                   2269 	.globl _ak820_outline_0009
                                   2270 	.globl _ak820_outline_0010
                                   2271 	.globl _ak820_outline_0011
                                   2272 	.globl _ak820_outline_0012
                                   2273 	.globl _ak820_outline_0013
                                   2274 	.globl _ak820_outline_0015
                                   2275 	.globl _ak820_outline_0017
                                   2276 	.globl _ak820_outline_0019
                                   2277 	.globl _ak820_outline_0025
                                   2278 	.globl _ak820_outline_0026
                                   2279 	.globl _ak820_outline_0032
                                   2280 	.globl _ak820_outline_0033
                                   2281 	.globl _ak820_outline_0040
                                   2282 	.globl _ak820_outline_0051
                                   2283 	.globl _ak820_outline_0056
                                   2284 	.globl _ak820_outline_0059
                                   2285 	.globl _ak820_outline_0062
                                   2286 	.globl _ak820_outline_0064
                                   2287 	.globl _ak820_outline_0066
                                   2288 	.globl _ak820_outline_0076
                                   2289 	.globl _ak820_outline_0108
                                   2290 	.globl _ak820_outline_0109
                                   2291 	.globl _ak820_outline_0123
                                   2292 	.globl _ak820_outline_0126
                                   2293 	.globl _ak820_outline_0132
                                   2294 	.globl _ak820_outline_0134
                                   2295 	.globl _ak820_outline_0135
                                   2296 	.globl _ak820_outline_0140
                                   2297 	.globl _ak820_outline_0144
                                   2298 	.globl _ak820_outline_0145
                                   2299 	.globl _ak820_outline_0149
                                   2300 	.globl _ak820_outline_0155
                                   2301 	.globl _ak820_outline_0162
                                   2302 	.globl _ak820_outline_0163
                                   2303 
                                   2304 	.area CSEG (CODE)
                                   2305 ; function ak820_outline_0011
      00B7DA                       2306 _ak820_outline_0011:
      00B7DA A3               [24] 2307 	inc	dptr
      00B7DB F0               [24] 2308 	movx	@dptr,a
      00B7DC E4               [12] 2309 	clr	a
      00B7DD A3               [24] 2310 	inc	dptr
      00B7DE F0               [24] 2311 	movx	@dptr,a
      00B7DF 90 0E 23         [24] 2312 	mov	dptr,#___memcpy_PARM_3
      00B7E2 74 0A            [12] 2313 	mov	a,#0x0a
      00B7E4 F0               [24] 2314 	movx	@dptr,a
      00B7E5 E4               [12] 2315 	clr	a
      00B7E6 A3               [24] 2316 	inc	dptr
      00B7E7 F0               [24] 2317 	movx	@dptr,a
      00B7E8 22               [24] 2318 	ret
                                   2319 
                                   2320 	.area CSEG (CODE)
                                   2321 ; function ak820_outline_0026
      00B7E9                       2322 _ak820_outline_0026:
      00B7E9 E0               [24] 2323 	movx	a,@dptr
      00B7EA FE               [12] 2324 	mov	r6,a
      00B7EB A3               [24] 2325 	inc	dptr
      00B7EC E0               [24] 2326 	movx	a,@dptr
      00B7ED FF               [12] 2327 	mov	r7,a
      00B7EE 90 0C F8         [24] 2328 	mov	dptr,#_g_vial_magic_keycode_override
      00B7F1 EE               [12] 2329 	mov	a,r6
      00B7F2 F0               [24] 2330 	movx	@dptr,a
      00B7F3 EF               [12] 2331 	mov	a,r7
      00B7F4 A3               [24] 2332 	inc	dptr
      00B7F5 F0               [24] 2333 	movx	@dptr,a
      00B7F6 8E 04            [24] 2334 	mov	ar4,r6
      00B7F8 8F 05            [24] 2335 	mov	ar5,r7
      00B7FA C3               [12] 2336 	clr	c
      00B7FB 74 FF            [12] 2337 	mov	a,#0xff
      00B7FD 9C               [12] 2338 	subb	a,r4
      00B7FE 74 1F            [12] 2339 	mov	a,#0x1f
      00B800 9D               [12] 2340 	subb	a,r5
      00B801 22               [24] 2341 	ret
                                   2342 
                                   2343 	.area CSEG (CODE)
                                   2344 ; function ak820_outline_0134
      00B802                       2345 _ak820_outline_0134:
      00B802 24 A8            [12] 2346 	add	a,#_vial_unlock_combo_cols
      00B804 F5 82            [12] 2347 	mov	dpl,a
      00B806 E4               [12] 2348 	clr	a
      00B807 34 0E            [12] 2349 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B809 F5 83            [12] 2350 	mov	dph,a
      00B80B E0               [24] 2351 	movx	a,@dptr
      00B80C 22               [24] 2352 	ret
                                   2353 
                                   2354 	.area CSEG (CODE)
                                   2355 ; function ak820_outline_0135
      00B80D                       2356 _ak820_outline_0135:
      00B80D 24 A6            [12] 2357 	add	a,#_vial_unlock_combo_rows
      00B80F F5 82            [12] 2358 	mov	dpl,a
      00B811 E4               [12] 2359 	clr	a
      00B812 34 0E            [12] 2360 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B814 F5 83            [12] 2361 	mov	dph,a
      00B816 E0               [24] 2362 	movx	a,@dptr
      00B817 22               [24] 2363 	ret
