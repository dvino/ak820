                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_key_override_mods
                                     12 	.globl _ak820_key_override_key
                                     13 	.globl _ak820_key_override_sync
                                     14 	.globl _biton
                                     15 	.globl _host_consumer_send
                                     16 	.globl _host_system_send
                                     17 	.globl _host_keyboard_send
                                     18 	.globl _clear_keys_from_report
                                     19 	.globl _del_key_from_report
                                     20 	.globl _add_key_to_report
                                     21 	.globl _KEYCODE2CONSUMER
                                     22 	.globl _ADC_START
                                     23 	.globl _S0_R_FIFO
                                     24 	.globl _S0_T_FIFO
                                     25 	.globl _S0_FREE
                                     26 	.globl _S0_IF_BYTE
                                     27 	.globl _S0_IF_FIRST
                                     28 	.globl _S0_IF_OV
                                     29 	.globl _S0_FST_ACT
                                     30 	.globl _CP_RL2
                                     31 	.globl _C_T2
                                     32 	.globl _TR2
                                     33 	.globl _EXEN2
                                     34 	.globl _TCLK
                                     35 	.globl _RCLK
                                     36 	.globl _EXF2
                                     37 	.globl _CAP1F
                                     38 	.globl _TF2
                                     39 	.globl _RI
                                     40 	.globl _TI
                                     41 	.globl _RB8
                                     42 	.globl _TB8
                                     43 	.globl _REN
                                     44 	.globl _SM2
                                     45 	.globl _SM1
                                     46 	.globl _SM0
                                     47 	.globl _IT0
                                     48 	.globl _IE0
                                     49 	.globl _IT1
                                     50 	.globl _IE1
                                     51 	.globl _TR0
                                     52 	.globl _TF0
                                     53 	.globl _TR1
                                     54 	.globl _TF1
                                     55 	.globl _P4_0
                                     56 	.globl _P4_1
                                     57 	.globl _P4_2
                                     58 	.globl _P4_3
                                     59 	.globl _P4_4
                                     60 	.globl _P4_5
                                     61 	.globl _P4_6
                                     62 	.globl _RXD
                                     63 	.globl _TXD
                                     64 	.globl _INT0
                                     65 	.globl _INT1
                                     66 	.globl _T0
                                     67 	.globl _T1
                                     68 	.globl _MOSI1
                                     69 	.globl _MISO1
                                     70 	.globl _SCK1
                                     71 	.globl _P3_0
                                     72 	.globl _P3_1
                                     73 	.globl _P3_2
                                     74 	.globl _P3_3
                                     75 	.globl _P3_4
                                     76 	.globl _P3_5
                                     77 	.globl _P3_6
                                     78 	.globl _P3_7
                                     79 	.globl _CAP1_
                                     80 	.globl _T2_
                                     81 	.globl _CAP2_
                                     82 	.globl _T2EX_
                                     83 	.globl _RXD1
                                     84 	.globl _TXD1
                                     85 	.globl _P2_0
                                     86 	.globl _P2_1
                                     87 	.globl _P2_2
                                     88 	.globl _P2_3
                                     89 	.globl _P2_4
                                     90 	.globl _P2_5
                                     91 	.globl _P2_6
                                     92 	.globl _P2_7
                                     93 	.globl _AIN0
                                     94 	.globl _AIN1
                                     95 	.globl _AIN2
                                     96 	.globl _AIN3
                                     97 	.globl _AIN4
                                     98 	.globl _AIN5
                                     99 	.globl _AIN6
                                    100 	.globl _AIN7
                                    101 	.globl _CAP1
                                    102 	.globl _T2
                                    103 	.globl _CAP2
                                    104 	.globl _T2EX
                                    105 	.globl _INT0_
                                    106 	.globl _SCS
                                    107 	.globl _MOSI
                                    108 	.globl _MISO
                                    109 	.globl _SCK
                                    110 	.globl _RXD1_
                                    111 	.globl _TXD1_
                                    112 	.globl _P1_0
                                    113 	.globl _P1_1
                                    114 	.globl _P1_2
                                    115 	.globl _P1_3
                                    116 	.globl _P1_4
                                    117 	.globl _P1_5
                                    118 	.globl _P1_6
                                    119 	.globl _P1_7
                                    120 	.globl _AIN8
                                    121 	.globl _AIN9
                                    122 	.globl _AIN10
                                    123 	.globl _AIN11
                                    124 	.globl _AIN12
                                    125 	.globl _AIN13
                                    126 	.globl _RXD_
                                    127 	.globl _TXD_
                                    128 	.globl _SCL0
                                    129 	.globl _SDA0
                                    130 	.globl _P0_0
                                    131 	.globl _P0_1
                                    132 	.globl _P0_2
                                    133 	.globl _P0_3
                                    134 	.globl _P0_4
                                    135 	.globl _P0_5
                                    136 	.globl _P0_6
                                    137 	.globl _P0_7
                                    138 	.globl _IE_SPI0
                                    139 	.globl _IE_USB
                                    140 	.globl _IE_ADC
                                    141 	.globl _IE_UART1
                                    142 	.globl _IE_PWM_I2C
                                    143 	.globl _IE_GPIO
                                    144 	.globl _IE_WDOG
                                    145 	.globl _PX0
                                    146 	.globl _PT0
                                    147 	.globl _PX1
                                    148 	.globl _PT1
                                    149 	.globl _PS
                                    150 	.globl _PT2
                                    151 	.globl _PL_FLAG
                                    152 	.globl _PH_FLAG
                                    153 	.globl _EX0
                                    154 	.globl _ET0
                                    155 	.globl _EX1
                                    156 	.globl _ET1
                                    157 	.globl _ES
                                    158 	.globl _ET2
                                    159 	.globl _E_DIS
                                    160 	.globl _EA
                                    161 	.globl _P
                                    162 	.globl _F1
                                    163 	.globl _OV
                                    164 	.globl _RS0
                                    165 	.globl _RS1
                                    166 	.globl _F0
                                    167 	.globl _AC
                                    168 	.globl _CY
                                    169 	.globl _I2CS_INT_ST
                                    170 	.globl _I2CX_INT
                                    171 	.globl _LED_STATUS
                                    172 	.globl _LED_DMA_H
                                    173 	.globl _LED_DMA_L
                                    174 	.globl _LED_DMA
                                    175 	.globl _LED_PWM_OE
                                    176 	.globl _LED_COMMON
                                    177 	.globl _ADC_CHAN
                                    178 	.globl _ADC_DAT_H
                                    179 	.globl _ADC_DAT_L
                                    180 	.globl _ADC_DAT
                                    181 	.globl _ADC_CTRL
                                    182 	.globl _SPI1_CK_SE
                                    183 	.globl _SPI1_CTRL
                                    184 	.globl _SPI1_DATA
                                    185 	.globl _SPI1_STAT
                                    186 	.globl _SIF1
                                    187 	.globl _SBAUD1
                                    188 	.globl _SBUF1
                                    189 	.globl _SCON1
                                    190 	.globl _SPI0_SETUP
                                    191 	.globl _SPI0_CK_SE
                                    192 	.globl _SPI0_CTRL
                                    193 	.globl _SPI0_DATA
                                    194 	.globl _SPI0_STAT
                                    195 	.globl _T2CAP1H
                                    196 	.globl _T2CAP1L
                                    197 	.globl _T2CAP1
                                    198 	.globl _TH2
                                    199 	.globl _TL2
                                    200 	.globl _T2COUNT
                                    201 	.globl _RCAP2H
                                    202 	.globl _RCAP2L
                                    203 	.globl _RCAP2
                                    204 	.globl _T2MOD
                                    205 	.globl _T2CON
                                    206 	.globl _SBUF
                                    207 	.globl _SCON
                                    208 	.globl _TH1
                                    209 	.globl _TH0
                                    210 	.globl _TL1
                                    211 	.globl _TL0
                                    212 	.globl _TMOD
                                    213 	.globl _TCON
                                    214 	.globl _XBUS_AUX
                                    215 	.globl _P7
                                    216 	.globl _P6_DIR
                                    217 	.globl _P6_OUT_PU
                                    218 	.globl _P6_IN
                                    219 	.globl _P5_DIR
                                    220 	.globl _P5_OUT_PU
                                    221 	.globl _P5_IN
                                    222 	.globl _P4_LED_KEY
                                    223 	.globl _P4_DIR_PU
                                    224 	.globl _P4_MOD_OC
                                    225 	.globl _P4
                                    226 	.globl _P3_DIR_PU
                                    227 	.globl _P3_MOD_OC
                                    228 	.globl _P3
                                    229 	.globl _P2_DIR_PU
                                    230 	.globl _P2_MOD_OC
                                    231 	.globl _P2
                                    232 	.globl _P1_DIR_PU
                                    233 	.globl _P1_MOD_OC
                                    234 	.globl _P1
                                    235 	.globl _P0_DIR_PU
                                    236 	.globl _P0_MOD_OC
                                    237 	.globl _P0
                                    238 	.globl _ROM_CTRL
                                    239 	.globl _ROM_DATA_HH
                                    240 	.globl _ROM_DATA_HL
                                    241 	.globl _ROM_DATA_HI
                                    242 	.globl _ROM_ADDR_H
                                    243 	.globl _ROM_ADDR_L
                                    244 	.globl _ROM_ADDR
                                    245 	.globl _GPIO_IE
                                    246 	.globl _IP_EX
                                    247 	.globl _IE_EX
                                    248 	.globl _IP
                                    249 	.globl _IE
                                    250 	.globl _WDOG_COUNT
                                    251 	.globl _RESET_KEEP
                                    252 	.globl _WAKE_CTRL
                                    253 	.globl _CLOCK_CFG
                                    254 	.globl _POWER_CFG
                                    255 	.globl _PCON
                                    256 	.globl _GLOBAL_CFG
                                    257 	.globl _SAFE_MOD
                                    258 	.globl _DPH
                                    259 	.globl _DPL
                                    260 	.globl _SP
                                    261 	.globl _A_INV
                                    262 	.globl _B
                                    263 	.globl _ACC
                                    264 	.globl _PSW
                                    265 	.globl _actual_keyboard_report
                                    266 	.globl _owned_usage_key_PARM_2
                                    267 	.globl _ak820_macro_change_PARM_3
                                    268 	.globl _ak820_macro_change_PARM_2
                                    269 	.globl _ak820_macro_cancelled
                                    270 	.globl _ak820_macro_primitive
                                    271 	.globl _ak820_macro_change
                                    272 	.globl _add_owned_mods
                                    273 	.globl _del_owned_mods
                                    274 	.globl _add_owned_weak_mods
                                    275 	.globl _del_owned_weak_mods
                                    276 	.globl _clear_owned_mods
                                    277 	.globl _clear_owned_keys
                                    278 	.globl _add_owned_key
                                    279 	.globl _del_owned_key
                                    280 	.globl _clear_owned_usages
                                    281 	.globl _owned_usage_key
                                    282 	.globl _send_keyboard_report
                                    283 	.globl _get_mods
                                    284 	.globl _clear_mods
                                    285 	.globl _get_weak_mods
                                    286 	.globl _add_weak_mods
                                    287 	.globl _del_weak_mods
                                    288 	.globl _clear_weak_mods
                                    289 ;--------------------------------------------------------
                                    290 ; special function registers
                                    291 ;--------------------------------------------------------
                                    292 	.area RSEG    (ABS,DATA)
      000000                        293 	.org 0x0000
                           0000D0   294 _PSW	=	0x00d0
                           0000E0   295 _ACC	=	0x00e0
                           0000F0   296 _B	=	0x00f0
                           0000FD   297 _A_INV	=	0x00fd
                           000081   298 _SP	=	0x0081
                           000082   299 _DPL	=	0x0082
                           000083   300 _DPH	=	0x0083
                           0000A1   301 _SAFE_MOD	=	0x00a1
                           0000B1   302 _GLOBAL_CFG	=	0x00b1
                           000087   303 _PCON	=	0x0087
                           0000BA   304 _POWER_CFG	=	0x00ba
                           0000B9   305 _CLOCK_CFG	=	0x00b9
                           0000A9   306 _WAKE_CTRL	=	0x00a9
                           0000FE   307 _RESET_KEEP	=	0x00fe
                           0000FF   308 _WDOG_COUNT	=	0x00ff
                           0000A8   309 _IE	=	0x00a8
                           0000B8   310 _IP	=	0x00b8
                           0000E8   311 _IE_EX	=	0x00e8
                           0000E9   312 _IP_EX	=	0x00e9
                           0000B2   313 _GPIO_IE	=	0x00b2
                           008584   314 _ROM_ADDR	=	0x8584
                           000084   315 _ROM_ADDR_L	=	0x0084
                           000085   316 _ROM_ADDR_H	=	0x0085
                           008F8E   317 _ROM_DATA_HI	=	0x8f8e
                           00008E   318 _ROM_DATA_HL	=	0x008e
                           00008F   319 _ROM_DATA_HH	=	0x008f
                           000086   320 _ROM_CTRL	=	0x0086
                           000080   321 _P0	=	0x0080
                           0000C4   322 _P0_MOD_OC	=	0x00c4
                           0000C5   323 _P0_DIR_PU	=	0x00c5
                           000090   324 _P1	=	0x0090
                           000092   325 _P1_MOD_OC	=	0x0092
                           000093   326 _P1_DIR_PU	=	0x0093
                           0000A0   327 _P2	=	0x00a0
                           000094   328 _P2_MOD_OC	=	0x0094
                           000095   329 _P2_DIR_PU	=	0x0095
                           0000B0   330 _P3	=	0x00b0
                           000096   331 _P3_MOD_OC	=	0x0096
                           000097   332 _P3_DIR_PU	=	0x0097
                           0000C0   333 _P4	=	0x00c0
                           0000C2   334 _P4_MOD_OC	=	0x00c2
                           0000C3   335 _P4_DIR_PU	=	0x00c3
                           0000C1   336 _P4_LED_KEY	=	0x00c1
                           0000AA   337 _P5_IN	=	0x00aa
                           0000AB   338 _P5_OUT_PU	=	0x00ab
                           0000AC   339 _P5_DIR	=	0x00ac
                           0000AD   340 _P6_IN	=	0x00ad
                           0000AE   341 _P6_OUT_PU	=	0x00ae
                           0000AF   342 _P6_DIR	=	0x00af
                           0000F1   343 _P7	=	0x00f1
                           0000A2   344 _XBUS_AUX	=	0x00a2
                           000088   345 _TCON	=	0x0088
                           000089   346 _TMOD	=	0x0089
                           00008A   347 _TL0	=	0x008a
                           00008B   348 _TL1	=	0x008b
                           00008C   349 _TH0	=	0x008c
                           00008D   350 _TH1	=	0x008d
                           000098   351 _SCON	=	0x0098
                           000099   352 _SBUF	=	0x0099
                           0000C8   353 _T2CON	=	0x00c8
                           0000C9   354 _T2MOD	=	0x00c9
                           00CBCA   355 _RCAP2	=	0xcbca
                           0000CA   356 _RCAP2L	=	0x00ca
                           0000CB   357 _RCAP2H	=	0x00cb
                           00CDCC   358 _T2COUNT	=	0xcdcc
                           0000CC   359 _TL2	=	0x00cc
                           0000CD   360 _TH2	=	0x00cd
                           00CFCE   361 _T2CAP1	=	0xcfce
                           0000CE   362 _T2CAP1L	=	0x00ce
                           0000CF   363 _T2CAP1H	=	0x00cf
                           0000F8   364 _SPI0_STAT	=	0x00f8
                           0000F9   365 _SPI0_DATA	=	0x00f9
                           0000FA   366 _SPI0_CTRL	=	0x00fa
                           0000FB   367 _SPI0_CK_SE	=	0x00fb
                           0000FC   368 _SPI0_SETUP	=	0x00fc
                           0000BC   369 _SCON1	=	0x00bc
                           0000BD   370 _SBUF1	=	0x00bd
                           0000BE   371 _SBAUD1	=	0x00be
                           0000BF   372 _SIF1	=	0x00bf
                           0000B4   373 _SPI1_STAT	=	0x00b4
                           0000B5   374 _SPI1_DATA	=	0x00b5
                           0000B6   375 _SPI1_CTRL	=	0x00b6
                           0000B7   376 _SPI1_CK_SE	=	0x00b7
                           0000F3   377 _ADC_CTRL	=	0x00f3
                           00F5F4   378 _ADC_DAT	=	0xf5f4
                           0000F4   379 _ADC_DAT_L	=	0x00f4
                           0000F5   380 _ADC_DAT_H	=	0x00f5
                           0000F6   381 _ADC_CHAN	=	0x00f6
                           0000A6   382 _LED_COMMON	=	0x00a6
                           0000A7   383 _LED_PWM_OE	=	0x00a7
                           00C7C6   384 _LED_DMA	=	0xc7c6
                           0000C6   385 _LED_DMA_L	=	0x00c6
                           0000C7   386 _LED_DMA_H	=	0x00c7
                           0000F7   387 _LED_STATUS	=	0x00f7
                           0000B3   388 _I2CX_INT	=	0x00b3
                           0000BB   389 _I2CS_INT_ST	=	0x00bb
                                    390 ;--------------------------------------------------------
                                    391 ; special function bits
                                    392 ;--------------------------------------------------------
                                    393 	.area RSEG    (ABS,DATA)
      000000                        394 	.org 0x0000
                           0000D7   395 _CY	=	0x00d7
                           0000D6   396 _AC	=	0x00d6
                           0000D5   397 _F0	=	0x00d5
                           0000D4   398 _RS1	=	0x00d4
                           0000D3   399 _RS0	=	0x00d3
                           0000D2   400 _OV	=	0x00d2
                           0000D1   401 _F1	=	0x00d1
                           0000D0   402 _P	=	0x00d0
                           0000AF   403 _EA	=	0x00af
                           0000AE   404 _E_DIS	=	0x00ae
                           0000AD   405 _ET2	=	0x00ad
                           0000AC   406 _ES	=	0x00ac
                           0000AB   407 _ET1	=	0x00ab
                           0000AA   408 _EX1	=	0x00aa
                           0000A9   409 _ET0	=	0x00a9
                           0000A8   410 _EX0	=	0x00a8
                           0000BF   411 _PH_FLAG	=	0x00bf
                           0000BE   412 _PL_FLAG	=	0x00be
                           0000BD   413 _PT2	=	0x00bd
                           0000BC   414 _PS	=	0x00bc
                           0000BB   415 _PT1	=	0x00bb
                           0000BA   416 _PX1	=	0x00ba
                           0000B9   417 _PT0	=	0x00b9
                           0000B8   418 _PX0	=	0x00b8
                           0000EF   419 _IE_WDOG	=	0x00ef
                           0000EE   420 _IE_GPIO	=	0x00ee
                           0000ED   421 _IE_PWM_I2C	=	0x00ed
                           0000EC   422 _IE_UART1	=	0x00ec
                           0000EB   423 _IE_ADC	=	0x00eb
                           0000E9   424 _IE_USB	=	0x00e9
                           0000E8   425 _IE_SPI0	=	0x00e8
                           000087   426 _P0_7	=	0x0087
                           000086   427 _P0_6	=	0x0086
                           000085   428 _P0_5	=	0x0085
                           000084   429 _P0_4	=	0x0084
                           000083   430 _P0_3	=	0x0083
                           000082   431 _P0_2	=	0x0082
                           000081   432 _P0_1	=	0x0081
                           000080   433 _P0_0	=	0x0080
                           000081   434 _SDA0	=	0x0081
                           000080   435 _SCL0	=	0x0080
                           000083   436 _TXD_	=	0x0083
                           000082   437 _RXD_	=	0x0082
                           000085   438 _AIN13	=	0x0085
                           000084   439 _AIN12	=	0x0084
                           000083   440 _AIN11	=	0x0083
                           000082   441 _AIN10	=	0x0082
                           000081   442 _AIN9	=	0x0081
                           000080   443 _AIN8	=	0x0080
                           000097   444 _P1_7	=	0x0097
                           000096   445 _P1_6	=	0x0096
                           000095   446 _P1_5	=	0x0095
                           000094   447 _P1_4	=	0x0094
                           000093   448 _P1_3	=	0x0093
                           000092   449 _P1_2	=	0x0092
                           000091   450 _P1_1	=	0x0091
                           000090   451 _P1_0	=	0x0090
                           000097   452 _TXD1_	=	0x0097
                           000096   453 _RXD1_	=	0x0096
                           000097   454 _SCK	=	0x0097
                           000096   455 _MISO	=	0x0096
                           000095   456 _MOSI	=	0x0095
                           000094   457 _SCS	=	0x0094
                           000092   458 _INT0_	=	0x0092
                           000091   459 _T2EX	=	0x0091
                           000091   460 _CAP2	=	0x0091
                           000090   461 _T2	=	0x0090
                           000090   462 _CAP1	=	0x0090
                           000097   463 _AIN7	=	0x0097
                           000096   464 _AIN6	=	0x0096
                           000095   465 _AIN5	=	0x0095
                           000094   466 _AIN4	=	0x0094
                           000093   467 _AIN3	=	0x0093
                           000092   468 _AIN2	=	0x0092
                           000091   469 _AIN1	=	0x0091
                           000090   470 _AIN0	=	0x0090
                           0000A7   471 _P2_7	=	0x00a7
                           0000A6   472 _P2_6	=	0x00a6
                           0000A5   473 _P2_5	=	0x00a5
                           0000A4   474 _P2_4	=	0x00a4
                           0000A3   475 _P2_3	=	0x00a3
                           0000A2   476 _P2_2	=	0x00a2
                           0000A1   477 _P2_1	=	0x00a1
                           0000A0   478 _P2_0	=	0x00a0
                           0000A7   479 _TXD1	=	0x00a7
                           0000A6   480 _RXD1	=	0x00a6
                           0000A5   481 _T2EX_	=	0x00a5
                           0000A5   482 _CAP2_	=	0x00a5
                           0000A4   483 _T2_	=	0x00a4
                           0000A4   484 _CAP1_	=	0x00a4
                           0000B7   485 _P3_7	=	0x00b7
                           0000B6   486 _P3_6	=	0x00b6
                           0000B5   487 _P3_5	=	0x00b5
                           0000B4   488 _P3_4	=	0x00b4
                           0000B3   489 _P3_3	=	0x00b3
                           0000B2   490 _P3_2	=	0x00b2
                           0000B1   491 _P3_1	=	0x00b1
                           0000B0   492 _P3_0	=	0x00b0
                           0000B7   493 _SCK1	=	0x00b7
                           0000B6   494 _MISO1	=	0x00b6
                           0000B5   495 _MOSI1	=	0x00b5
                           0000B5   496 _T1	=	0x00b5
                           0000B4   497 _T0	=	0x00b4
                           0000B3   498 _INT1	=	0x00b3
                           0000B2   499 _INT0	=	0x00b2
                           0000B1   500 _TXD	=	0x00b1
                           0000B0   501 _RXD	=	0x00b0
                           0000C6   502 _P4_6	=	0x00c6
                           0000C5   503 _P4_5	=	0x00c5
                           0000C4   504 _P4_4	=	0x00c4
                           0000C3   505 _P4_3	=	0x00c3
                           0000C2   506 _P4_2	=	0x00c2
                           0000C1   507 _P4_1	=	0x00c1
                           0000C0   508 _P4_0	=	0x00c0
                           00008F   509 _TF1	=	0x008f
                           00008E   510 _TR1	=	0x008e
                           00008D   511 _TF0	=	0x008d
                           00008C   512 _TR0	=	0x008c
                           00008B   513 _IE1	=	0x008b
                           00008A   514 _IT1	=	0x008a
                           000089   515 _IE0	=	0x0089
                           000088   516 _IT0	=	0x0088
                           00009F   517 _SM0	=	0x009f
                           00009E   518 _SM1	=	0x009e
                           00009D   519 _SM2	=	0x009d
                           00009C   520 _REN	=	0x009c
                           00009B   521 _TB8	=	0x009b
                           00009A   522 _RB8	=	0x009a
                           000099   523 _TI	=	0x0099
                           000098   524 _RI	=	0x0098
                           0000CF   525 _TF2	=	0x00cf
                           0000CF   526 _CAP1F	=	0x00cf
                           0000CE   527 _EXF2	=	0x00ce
                           0000CD   528 _RCLK	=	0x00cd
                           0000CC   529 _TCLK	=	0x00cc
                           0000CB   530 _EXEN2	=	0x00cb
                           0000CA   531 _TR2	=	0x00ca
                           0000C9   532 _C_T2	=	0x00c9
                           0000C8   533 _CP_RL2	=	0x00c8
                           0000FF   534 _S0_FST_ACT	=	0x00ff
                           0000FE   535 _S0_IF_OV	=	0x00fe
                           0000FD   536 _S0_IF_FIRST	=	0x00fd
                           0000FC   537 _S0_IF_BYTE	=	0x00fc
                           0000FB   538 _S0_FREE	=	0x00fb
                           0000FA   539 _S0_T_FIFO	=	0x00fa
                           0000F8   540 _S0_R_FIFO	=	0x00f8
                           0000F7   541 _ADC_START	=	0x00f7
                                    542 ;--------------------------------------------------------
                                    543 ; overlayable register banks
                                    544 ;--------------------------------------------------------
                                    545 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        546 	.ds 8
                                    547 ;--------------------------------------------------------
                                    548 ; internal ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area DSEG    (DATA)
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 	.area	OSEG    (OVR,DATA)
      000058                        555 _change_owned_sloc1_1_0:
      000058                        556 	.ds 1
                                    557 ;--------------------------------------------------------
                                    558 ; indirectly addressable internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area ISEG    (DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; absolute internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area IABS    (ABS,DATA)
                                    565 	.area IABS    (ABS,DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; bit data
                                    568 ;--------------------------------------------------------
                                    569 	.area BSEG    (BIT)
      000021                        570 _ak820_macro_change_sloc0_1_0:
      000021                        571 	.ds 1
      000022                        572 _change_owned_sloc0_1_0:
      000022                        573 	.ds 1
      000023                        574 _owned_usage_key_sloc0_1_0:
      000023                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; paged external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area PSEG    (PAG,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; uninitialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XSEG    (XDATA)
      0009CD                        584 _owned_mod_refs:
      0009CD                        585 	.ds 8
      0009D5                        586 _owned_weak_refs:
      0009D5                        587 	.ds 8
      0009DD                        588 _owned_mods:
      0009DD                        589 	.ds 1
      0009DE                        590 _owned_weak_mods:
      0009DE                        591 	.ds 1
      0009DF                        592 _macro_mods:
      0009DF                        593 	.ds 2
      0009E1                        594 _ak820_macro_primitive::
      0009E1                        595 	.ds 1
      0009E2                        596 _ak820_macro_cancelled::
      0009E2                        597 	.ds 1
      0009E3                        598 _ak820_macro_change_PARM_2:
      0009E3                        599 	.ds 1
      0009E4                        600 _ak820_macro_change_PARM_3:
      0009E4                        601 	.ds 1
      0009E5                        602 _ak820_macro_change_bits_10000_355:
      0009E5                        603 	.ds 2
      0009E7                        604 _change_owned_PARM_2:
      0009E7                        605 	.ds 1
      0009E8                        606 _change_owned_mods_10000_360:
      0009E8                        607 	.ds 1
      0009E9                        608 _change_owned_result_10001_364:
      0009E9                        609 	.ds 1
      0009EA                        610 _change_owned_bit_20001_365:
      0009EA                        611 	.ds 1
      0009EB                        612 _add_owned_mods_mods_10000_373:
      0009EB                        613 	.ds 1
      0009EC                        614 _del_owned_mods_mods_10000_375:
      0009EC                        615 	.ds 1
      0009ED                        616 _add_owned_weak_mods_mods_10000_377:
      0009ED                        617 	.ds 1
      0009EE                        618 _del_owned_weak_mods_mods_10000_379:
      0009EE                        619 	.ds 1
      0009EF                        620 _key_refs:
      0009EF                        621 	.ds 165
      000A94                        622 _distinct_keys:
      000A94                        623 	.ds 1
      000A95                        624 _macro_keys:
      000A95                        625 	.ds 21
      000AAA                        626 _add_owned_key_code_10000_388:
      000AAA                        627 	.ds 1
      000AAB                        628 _del_owned_key_code_10000_403:
      000AAB                        629 	.ds 1
      000AAC                        630 _usage_refs:
      000AAC                        631 	.ds 30
      000ACA                        632 _usage_order:
      000ACA                        633 	.ds 30
      000AE8                        634 _usage_lengths:
      000AE8                        635 	.ds 2
      000AEA                        636 _macro_usages:
      000AEA                        637 	.ds 4
      000AEE                        638 _owned_usage_key_PARM_2:
      000AEE                        639 	.ds 1
      000AEF                        640 _owned_usage_key_code_10000_430:
      000AEF                        641 	.ds 1
      000AF0                        642 _owned_usage_key___200000090_20000_431:
      000AF0                        643 	.ds 2
      000AF2                        644 _owned_usage_key_which_10000_431:
      000AF2                        645 	.ds 1
      000AF3                        646 _owned_usage_key_count_10000_431:
      000AF3                        647 	.ds 1
      000AF4                        648 _owned_usage_key_pos_30001_438:
      000AF4                        649 	.ds 1
      000AF5                        650 _owned_usage_key_key_40000_443:
      000AF5                        651 	.ds 1
      000AF6                        652 _send_keyboard_report_projected_10001_450:
      000AF6                        653 	.ds 32
      000B16                        654 _send_keyboard_report_empty_50002_457:
      000B16                        655 	.ds 1
      000B17                        656 _send_keyboard_report_last_report_10003_464:
      000B17                        657 	.ds 32
      000B37                        658 _send_keyboard_report_changed_10003_464:
      000B37                        659 	.ds 1
      000B38                        660 _add_weak_mods_mods_10000_482:
      000B38                        661 	.ds 1
      000B39                        662 _del_weak_mods_mods_10000_484:
      000B39                        663 	.ds 1
                                    664 ;--------------------------------------------------------
                                    665 ; absolute external ram data
                                    666 ;--------------------------------------------------------
                                    667 	.area XABS    (ABS,XDATA)
                                    668 ;--------------------------------------------------------
                                    669 ; initialized external ram data
                                    670 ;--------------------------------------------------------
                                    671 	.area XISEG   (XDATA)
      000E46                        672 _real_mods:
      000E46                        673 	.ds 1
      000E47                        674 _weak_mods:
      000E47                        675 	.ds 1
      000E48                        676 _actual_keyboard_report::
      000E48                        677 	.ds 32
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT0 (CODE)
                                    680 	.area GSINIT1 (CODE)
                                    681 	.area GSINIT2 (CODE)
                                    682 	.area GSINIT3 (CODE)
                                    683 	.area GSINIT4 (CODE)
                                    684 	.area GSINIT5 (CODE)
                                    685 	.area GSINIT  (CODE)
                                    686 	.area GSFINAL (CODE)
                                    687 	.area CSEG    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; global & static initialisations
                                    690 ;--------------------------------------------------------
                                    691 	.area HOME    (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; Home
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area HOME    (CODE)
                                    700 ;--------------------------------------------------------
                                    701 ; code
                                    702 ;--------------------------------------------------------
                                    703 	.area CSEG    (CODE)
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    706 ;------------------------------------------------------------
                                    707 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    708 ;------------------------------------------------------------
                                    709 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    710 ;	-----------------------------------------
                           000007   711 	ar7 = 0x07
                           000006   712 	ar6 = 0x06
                           000005   713 	ar5 = 0x05
                           000004   714 	ar4 = 0x04
                           000003   715 	ar3 = 0x03
                           000002   716 	ar2 = 0x02
                           000001   717 	ar1 = 0x01
                           000000   718 	ar0 = 0x00
                                    719 ;	 function ak820_macro_change
                                    720 ;	-----------------------------------------
      007F87                        721 _ak820_macro_change:
      007F87 12 38 4B         [24]  722 	lcall	_ak820_outline_0108
      007F8A 90 09 E5         [24]  723 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007F8D 12 38 50         [24]  724 	lcall	_ak820_outline_0109
                                    725 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007F90 90 09 E1         [24]  726 	mov	dptr,#_ak820_macro_primitive
      007F93 E0               [24]  727 	movx	a,@dptr
      007F94 70 04            [24]  728 	jnz	00102$
      007F96 75 82 01         [24]  729 	mov	dpl, #0x01
      007F99 22               [24]  730 	ret
      007F9A                        731 00102$:
                                    732 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007F9A 90 09 E3         [24]  733 	mov	dptr,#_ak820_macro_change_PARM_2
      007F9D E0               [24]  734 	movx	a,@dptr
      007F9E FF               [12]  735 	mov	r7,a
      007F9F 12 7B 1A         [24]  736 	lcall	_ak820_outline_0041
      007FA2 80 02            [24]  737 	sjmp	00123$
      007FA4                        738 00122$:
      007FA4 25 E0            [12]  739 	add	a,acc
      007FA6                        740 00123$:
      007FA6 D5 F0 FB         [24]  741 	djnz	b,00122$
      007FA9 FE               [12]  742 	mov	r6,a
                                    743 ;	quantum/action_util.c:101: bits += index >> 3;
      007FAA 12 85 DA         [24]  744 	lcall	_ak820_outline_0170
      007FAD FF               [12]  745 	mov	r7,a
      007FAE 90 09 E5         [24]  746 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007FB1 12 38 21         [24]  747 	lcall	_ak820_outline_0065
      007FB4 90 09 E5         [24]  748 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007FB7 EF               [12]  749 	mov	a,r7
      007FB8 2C               [12]  750 	add	a, r4
      007FB9 F0               [24]  751 	movx	@dptr,a
      007FBA E4               [12]  752 	clr	a
      007FBB 3D               [12]  753 	addc	a, r5
      007FBC A3               [24]  754 	inc	dptr
      007FBD F0               [24]  755 	movx	@dptr,a
                                    756 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007FBE 90 09 E5         [24]  757 	mov	dptr,#_ak820_macro_change_bits_10000_355
      007FC1 E0               [24]  758 	movx	a,@dptr
      007FC2 FD               [12]  759 	mov	r5,a
      007FC3 A3               [24]  760 	inc	dptr
      007FC4 E0               [24]  761 	movx	a,@dptr
      007FC5 FF               [12]  762 	mov	r7,a
      007FC6 12 40 65         [24]  763 	lcall	_ak820_outline_0190
      007FC9 E0               [24]  764 	movx	a,@dptr
      007FCA FC               [12]  765 	mov	r4,a
      007FCB EE               [12]  766 	mov	a,r6
      007FCC 5C               [12]  767 	anl	a,r4
      007FCD B4 01 00         [24]  768 	cjne	a,#0x01,00124$
      007FD0                        769 00124$:
      007FD0 B3               [12]  770 	cpl	c
      007FD1 92 21            [24]  771 	mov	_ak820_macro_change_sloc0_1_0,c
      007FD3 90 09 E4         [24]  772 	mov	dptr,#_ak820_macro_change_PARM_3
      007FD6 E0               [24]  773 	movx	a,@dptr
      007FD7 FB               [12]  774 	mov	r3,a
      007FD8 A2 21            [12]  775 	mov	c,_ak820_macro_change_sloc0_1_0
      007FDA E4               [12]  776 	clr	a
      007FDB 33               [12]  777 	rlc	a
      007FDC B5 03 04         [24]  778 	cjne	a,ar3,00104$
      007FDF 75 82 00         [24]  779 	mov	dpl, #0x00
      007FE2 22               [24]  780 	ret
      007FE3                        781 00104$:
                                    782 ;	quantum/action_util.c:103: *bits ^= mask;
      007FE3 EC               [12]  783 	mov	a,r4
      007FE4 62 06            [12]  784 	xrl	ar6,a
      007FE6 12 40 65         [24]  785 	lcall	_ak820_outline_0190
      007FE9 EE               [12]  786 	mov	a,r6
      007FEA F0               [24]  787 	movx	@dptr,a
                                    788 ;	quantum/action_util.c:104: return true;
      007FEB 75 82 01         [24]  789 	mov	dpl, #0x01
                                    790 ;	quantum/action_util.c:105: }
      007FEE 22               [24]  791 	ret
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'change_owned'
                                    794 ;------------------------------------------------------------
                                    795 ;mode          Allocated with name '_change_owned_PARM_2'
                                    796 ;mods          Allocated with name '_change_owned_mods_10000_360'
                                    797 ;kind          Allocated with name '_change_owned_kind_10000_361'
                                    798 ;pressed       Allocated with name '_change_owned_pressed_10000_361'
                                    799 ;refs          Allocated with name '_change_owned_refs_10000_361'
                                    800 ;old           Allocated with name '_change_owned_old_30000_363'
                                    801 ;result        Allocated with name '_change_owned_result_10001_364'
                                    802 ;i             Allocated with name '_change_owned_i_20001_365'
                                    803 ;bit           Allocated with name '_change_owned_bit_20001_365'
                                    804 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function change_owned
                                    809 ;	-----------------------------------------
      007FEF                        810 _change_owned:
      007FEF E5 82            [12]  811 	mov	a,dpl
      007FF1 90 09 E8         [24]  812 	mov	dptr,#_change_owned_mods_10000_360
      007FF4 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007FF5 90 09 E7         [24]  815 	mov	dptr,#_change_owned_PARM_2
      007FF8 E0               [24]  816 	movx	a,@dptr
      007FF9 FF               [12]  817 	mov	r7,a
      007FFA C3               [12]  818 	clr	c
      007FFB 13               [12]  819 	rrc	a
      007FFC FE               [12]  820 	mov	r6,a
                                    821 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007FFD 53 07 01         [24]  822 	anl	ar7,#0x01
      008000 EF               [12]  823 	mov	a,r7
      008001 B4 01 00         [24]  824 	cjne	a,#0x01,00205$
      008004                        825 00205$:
      008004 92 22            [24]  826 	mov  _change_owned_sloc0_1_0,c
      008006 B3               [12]  827 	cpl	c
      008007 E4               [12]  828 	clr	a
      008008 33               [12]  829 	rlc	a
      008009 F5 58            [12]  830 	mov	_change_owned_sloc1_1_0,a
                                    831 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      00800B EE               [12]  832 	mov	a,r6
      00800C 60 06            [24]  833 	jz	00121$
      00800E 7D D5            [12]  834 	mov	r5,#_owned_weak_refs
      008010 7F 09            [12]  835 	mov	r7,#(_owned_weak_refs >> 8)
      008012 80 04            [24]  836 	sjmp	00122$
      008014                        837 00121$:
      008014 7D CD            [12]  838 	mov	r5,#_owned_mod_refs
      008016 7F 09            [12]  839 	mov	r7,#(_owned_mod_refs >> 8)
      008018                        840 00122$:
                                    841 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      008018 90 09 E1         [24]  842 	mov	dptr,#_ak820_macro_primitive
      00801B E0               [24]  843 	movx	a,@dptr
      00801C 60 36            [24]  844 	jz	00102$
                                    845 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      00801E EE               [12]  846 	mov	a,r6
      00801F 24 DF            [12]  847 	add	a, #_macro_mods
      008021 FB               [12]  848 	mov	r3,a
      008022 E4               [12]  849 	clr	a
      008023 34 09            [12]  850 	addc	a, #(_macro_mods >> 8)
      008025 12 4D 5D         [24]  851 	lcall	_ak820_outline_0061
                                    852 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      008028 E5 58            [12]  853 	mov	a,_change_owned_sloc1_1_0
      00802A 60 0A            [24]  854 	jz	00123$
      00802C 90 09 E8         [24]  855 	mov	dptr,#_change_owned_mods_10000_360
      00802F E0               [24]  856 	movx	a,@dptr
      008030 F9               [12]  857 	mov	r1,a
      008031 EA               [12]  858 	mov	a,r2
      008032 42 01            [12]  859 	orl	ar1,a
      008034 80 07            [24]  860 	sjmp	00124$
      008036                        861 00123$:
      008036 90 09 E8         [24]  862 	mov	dptr,#_change_owned_mods_10000_360
      008039 E0               [24]  863 	movx	a,@dptr
      00803A F4               [12]  864 	cpl	a
      00803B 5A               [12]  865 	anl	a,r2
      00803C F9               [12]  866 	mov	r1,a
      00803D                        867 00124$:
      00803D 12 33 FC         [24]  868 	lcall	_ak820_outline_0131
      008040 E9               [12]  869 	mov	a,r1
      008041 F0               [24]  870 	movx	@dptr,a
                                    871 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      008042 E5 58            [12]  872 	mov	a,_change_owned_sloc1_1_0
      008044 60 06            [24]  873 	jz	00125$
      008046 74 FF            [12]  874 	mov	a,#0xff
      008048 6A               [12]  875 	xrl	a,r2
      008049 FC               [12]  876 	mov	r4,a
      00804A 80 02            [24]  877 	sjmp	00126$
      00804C                        878 00125$:
      00804C 8A 04            [24]  879 	mov	ar4,r2
      00804E                        880 00126$:
      00804E 90 09 E8         [24]  881 	mov	dptr,#_change_owned_mods_10000_360
      008051 E0               [24]  882 	movx	a,@dptr
      008052 5C               [12]  883 	anl	a,r4
      008053 F0               [24]  884 	movx	@dptr,a
      008054                        885 00102$:
                                    886 ;	quantum/action_util.c:115: uint8_t result = 0;
      008054 90 09 E9         [24]  887 	mov	dptr,#_change_owned_result_10001_364
      008057 E4               [12]  888 	clr	a
      008058 F0               [24]  889 	movx	@dptr,a
                                    890 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008059 90 09 EA         [24]  891 	mov	dptr,#_change_owned_bit_20001_365
      00805C 04               [12]  892 	inc	a
      00805D F0               [24]  893 	movx	@dptr,a
      00805E 90 09 E8         [24]  894 	mov	dptr,#_change_owned_mods_10000_360
      008061 E0               [24]  895 	movx	a,@dptr
      008062 FC               [12]  896 	mov	r4,a
      008063 7B 00            [12]  897 	mov	r3,#0x00
      008065                        898 00117$:
      008065 BB 08 00         [24]  899 	cjne	r3,#0x08,00210$
      008068                        900 00210$:
      008068 50 3F            [24]  901 	jnc	00112$
                                    902 ;	quantum/action_util.c:117: if (mods & bit) {
      00806A 90 09 EA         [24]  903 	mov	dptr,#_change_owned_bit_20001_365
      00806D E0               [24]  904 	movx	a,@dptr
      00806E 5C               [12]  905 	anl	a,r4
      00806F 60 1C            [24]  906 	jz	00109$
                                    907 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      008071 E5 58            [12]  908 	mov	a,_change_owned_sloc1_1_0
      008073 60 0C            [24]  909 	jz	00106$
      008075 EB               [12]  910 	mov	a,r3
      008076 2D               [12]  911 	add	a, r5
      008077 12 37 E0         [24]  912 	lcall	_ak820_outline_0018
      00807A F8               [12]  913 	mov	r0,a
      00807B 08               [12]  914 	inc	r0
      00807C 12 85 8D         [24]  915 	lcall	_ak820_outline_0068
      00807F 80 0C            [24]  916 	sjmp	00109$
      008081                        917 00106$:
                                    918 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      008081 EB               [12]  919 	mov	a,r3
      008082 2D               [12]  920 	add	a, r5
      008083 12 37 E0         [24]  921 	lcall	_ak820_outline_0018
      008086 F8               [12]  922 	mov	r0,a
      008087 60 04            [24]  923 	jz	00109$
      008089 18               [12]  924 	dec	r0
      00808A 12 85 8D         [24]  925 	lcall	_ak820_outline_0068
      00808D                        926 00109$:
                                    927 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      00808D EB               [12]  928 	mov	a,r3
      00808E 2D               [12]  929 	add	a, r5
      00808F 12 37 E0         [24]  930 	lcall	_ak820_outline_0018
      008092 60 0B            [24]  931 	jz	00118$
      008094 90 09 EA         [24]  932 	mov	dptr,#_change_owned_bit_20001_365
      008097 E0               [24]  933 	movx	a,@dptr
      008098 FA               [12]  934 	mov	r2,a
      008099 90 09 E9         [24]  935 	mov	dptr,#_change_owned_result_10001_364
      00809C E0               [24]  936 	movx	a,@dptr
      00809D 4A               [12]  937 	orl	a,r2
      00809E F0               [24]  938 	movx	@dptr,a
      00809F                        939 00118$:
                                    940 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00809F 0B               [12]  941 	inc	r3
      0080A0 90 09 EA         [24]  942 	mov	dptr,#_change_owned_bit_20001_365
      0080A3 E0               [24]  943 	movx	a,@dptr
      0080A4 25 E0            [12]  944 	add	a,acc
      0080A6 F0               [24]  945 	movx	@dptr,a
      0080A7 80 BC            [24]  946 	sjmp	00117$
      0080A9                        947 00112$:
                                    948 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      0080A9 EE               [12]  949 	mov	a,r6
      0080AA 60 09            [24]  950 	jz	00114$
      0080AC 90 09 E9         [24]  951 	mov	dptr,#_change_owned_result_10001_364
      0080AF E0               [24]  952 	movx	a,@dptr
      0080B0 90 09 DE         [24]  953 	mov	dptr,#_owned_weak_mods
      0080B3 F0               [24]  954 	movx	@dptr,a
      0080B4 22               [24]  955 	ret
      0080B5                        956 00114$:
                                    957 ;	quantum/action_util.c:124: else owned_mods = result;
      0080B5 90 09 E9         [24]  958 	mov	dptr,#_change_owned_result_10001_364
      0080B8 E0               [24]  959 	movx	a,@dptr
      0080B9 90 09 DD         [24]  960 	mov	dptr,#_owned_mods
      0080BC F0               [24]  961 	movx	@dptr,a
                                    962 ;	quantum/action_util.c:125: }
      0080BD 22               [24]  963 	ret
                                    964 ;------------------------------------------------------------
                                    965 ;Allocation info for local variables in function 'add_owned_mods'
                                    966 ;------------------------------------------------------------
                                    967 ;mods          Allocated with name '_add_owned_mods_mods_10000_373'
                                    968 ;------------------------------------------------------------
                                    969 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    970 ;	-----------------------------------------
                                    971 ;	 function add_owned_mods
                                    972 ;	-----------------------------------------
      0080BE                        973 _add_owned_mods:
      0080BE E5 82            [12]  974 	mov	a,dpl
      0080C0 90 09 EB         [24]  975 	mov	dptr,#_add_owned_mods_mods_10000_373
      0080C3 12 85 BD         [24]  976 	lcall	_ak820_outline_0122
      0080C6 74 01            [12]  977 	mov	a,#0x01
      0080C8 F0               [24]  978 	movx	@dptr,a
      0080C9 8F 82            [24]  979 	mov	dpl, r7
      0080CB 02 7F EF         [24]  980 	ljmp	_change_owned
                                    981 ;------------------------------------------------------------
                                    982 ;Allocation info for local variables in function 'del_owned_mods'
                                    983 ;------------------------------------------------------------
                                    984 ;mods          Allocated with name '_del_owned_mods_mods_10000_375'
                                    985 ;------------------------------------------------------------
                                    986 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    987 ;	-----------------------------------------
                                    988 ;	 function del_owned_mods
                                    989 ;	-----------------------------------------
      0080CE                        990 _del_owned_mods:
      0080CE E5 82            [12]  991 	mov	a,dpl
      0080D0 90 09 EC         [24]  992 	mov	dptr,#_del_owned_mods_mods_10000_375
      0080D3 12 85 BD         [24]  993 	lcall	_ak820_outline_0122
      0080D6 E4               [12]  994 	clr	a
      0080D7 F0               [24]  995 	movx	@dptr,a
      0080D8 8F 82            [24]  996 	mov	dpl, r7
      0080DA 02 7F EF         [24]  997 	ljmp	_change_owned
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1000 ;------------------------------------------------------------
                                   1001 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_377'
                                   1002 ;------------------------------------------------------------
                                   1003 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1004 ;	-----------------------------------------
                                   1005 ;	 function add_owned_weak_mods
                                   1006 ;	-----------------------------------------
      0080DD                       1007 _add_owned_weak_mods:
      0080DD E5 82            [12] 1008 	mov	a,dpl
      0080DF 90 09 ED         [24] 1009 	mov	dptr,#_add_owned_weak_mods_mods_10000_377
      0080E2 12 85 BD         [24] 1010 	lcall	_ak820_outline_0122
      0080E5 74 03            [12] 1011 	mov	a,#0x03
      0080E7 F0               [24] 1012 	movx	@dptr,a
      0080E8 8F 82            [24] 1013 	mov	dpl, r7
      0080EA 02 7F EF         [24] 1014 	ljmp	_change_owned
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1017 ;------------------------------------------------------------
                                   1018 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_379'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function del_owned_weak_mods
                                   1023 ;	-----------------------------------------
      0080ED                       1024 _del_owned_weak_mods:
      0080ED E5 82            [12] 1025 	mov	a,dpl
      0080EF 90 09 EE         [24] 1026 	mov	dptr,#_del_owned_weak_mods_mods_10000_379
      0080F2 12 85 BD         [24] 1027 	lcall	_ak820_outline_0122
      0080F5 74 02            [12] 1028 	mov	a,#0x02
      0080F7 F0               [24] 1029 	movx	@dptr,a
      0080F8 8F 82            [24] 1030 	mov	dpl, r7
      0080FA 02 7F EF         [24] 1031 	ljmp	_change_owned
                                   1032 ;------------------------------------------------------------
                                   1033 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1034 ;------------------------------------------------------------
                                   1035 ;i             Allocated with name '_clear_owned_mods_i_20000_383'
                                   1036 ;------------------------------------------------------------
                                   1037 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1038 ;	-----------------------------------------
                                   1039 ;	 function clear_owned_mods
                                   1040 ;	-----------------------------------------
      0080FD                       1041 _clear_owned_mods:
                                   1042 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      0080FD 7F 00            [12] 1043 	mov	r7,#0x00
      0080FF                       1044 00103$:
      0080FF BF 08 00         [24] 1045 	cjne	r7,#0x08,00122$
      008102                       1046 00122$:
      008102 50 1A            [24] 1047 	jnc	00101$
      008104 EF               [12] 1048 	mov	a,r7
      008105 24 CD            [12] 1049 	add	a, #_owned_mod_refs
      008107 FD               [12] 1050 	mov	r5,a
      008108 E4               [12] 1051 	clr	a
      008109 34 09            [12] 1052 	addc	a, #(_owned_mod_refs >> 8)
      00810B FE               [12] 1053 	mov	r6,a
      00810C EF               [12] 1054 	mov	a,r7
      00810D 24 D5            [12] 1055 	add	a, #_owned_weak_refs
      00810F F5 82            [12] 1056 	mov	dpl,a
      008111 E4               [12] 1057 	clr	a
      008112 34 09            [12] 1058 	addc	a, #(_owned_weak_refs >> 8)
      008114 F5 83            [12] 1059 	mov	dph,a
      008116 E4               [12] 1060 	clr	a
      008117 F0               [24] 1061 	movx	@dptr,a
      008118 12 85 B7         [24] 1062 	lcall	_ak820_outline_0104
      00811B 0F               [12] 1063 	inc	r7
      00811C 80 E1            [24] 1064 	sjmp	00103$
      00811E                       1065 00101$:
                                   1066 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      00811E 90 09 E0         [24] 1067 	mov	dptr,#(_macro_mods + 0x0001)
      008121 E4               [12] 1068 	clr	a
      008122 F0               [24] 1069 	movx	@dptr,a
      008123 90 09 DF         [24] 1070 	mov	dptr,#_macro_mods
      008126 F0               [24] 1071 	movx	@dptr,a
      008127 90 09 DE         [24] 1072 	mov	dptr,#_owned_weak_mods
      00812A F0               [24] 1073 	movx	@dptr,a
      00812B 90 09 DD         [24] 1074 	mov	dptr,#_owned_mods
      00812E F0               [24] 1075 	movx	@dptr,a
                                   1076 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      00812F 90 09 E2         [24] 1077 	mov	dptr,#_ak820_macro_cancelled
      008132 04               [12] 1078 	inc	a
      008133 F0               [24] 1079 	movx	@dptr,a
                                   1080 ;	quantum/action_util.c:134: }
      008134 22               [24] 1081 	ret
                                   1082 ;------------------------------------------------------------
                                   1083 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1084 ;------------------------------------------------------------
                                   1085 ;i             Allocated with name '_clear_owned_keys_i_20000_386'
                                   1086 ;i             Allocated with name '_clear_owned_keys_i_20000_387'
                                   1087 ;------------------------------------------------------------
                                   1088 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1089 ;	-----------------------------------------
                                   1090 ;	 function clear_owned_keys
                                   1091 ;	-----------------------------------------
      008135                       1092 _clear_owned_keys:
                                   1093 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008135 7F 00            [12] 1094 	mov	r7,#0x00
      008137                       1095 00104$:
      008137 EF               [12] 1096 	mov	a,r7
      008138 24 5B            [12] 1097 	add	a,#0xff - 0xa4
      00813A 40 0D            [24] 1098 	jc	00101$
                                   1099 ;	free result
      00813C EF               [12] 1100 	mov	a,r7
      00813D 24 EF            [12] 1101 	add	a, #_key_refs
      00813F F5 82            [12] 1102 	mov	dpl,a
      008141 E4               [12] 1103 	clr	a
      008142 34 09            [12] 1104 	addc	a, #(_key_refs >> 8)
      008144 12 7F 78         [24] 1105 	lcall	_ak820_outline_0171
      008147 80 EE            [24] 1106 	sjmp	00104$
      008149                       1107 00101$:
                                   1108 ;	quantum/action_util.c:142: distinct_keys = 0;
      008149 90 0A 94         [24] 1109 	mov	dptr,#_distinct_keys
      00814C E4               [12] 1110 	clr	a
      00814D F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      00814E FF               [12] 1113 	mov	r7,a
      00814F                       1114 00107$:
      00814F BF 15 00         [24] 1115 	cjne	r7,#0x15,00142$
      008152                       1116 00142$:
      008152 50 0D            [24] 1117 	jnc	00109$
      008154 EF               [12] 1118 	mov	a,r7
      008155 24 95            [12] 1119 	add	a, #_macro_keys
      008157 F5 82            [12] 1120 	mov	dpl,a
      008159 E4               [12] 1121 	clr	a
      00815A 34 0A            [12] 1122 	addc	a, #(_macro_keys >> 8)
      00815C 12 7F 78         [24] 1123 	lcall	_ak820_outline_0171
      00815F 80 EE            [24] 1124 	sjmp	00107$
      008161                       1125 00109$:
                                   1126 ;	quantum/action_util.c:144: }
      008161 22               [24] 1127 	ret
                                   1128 ;------------------------------------------------------------
                                   1129 ;Allocation info for local variables in function 'add_owned_key'
                                   1130 ;------------------------------------------------------------
                                   1131 ;code          Allocated with name '_add_owned_key_code_10000_388'
                                   1132 ;__400000079   Allocated with name '_add_owned_key___400000079_40000_397'
                                   1133 ;key           Allocated with name '_add_owned_key_key_50000_398'
                                   1134 ;i             Allocated with name '_add_owned_key_i_40000_396'
                                   1135 ;__300000081   Allocated with name '_add_owned_key___300000081_30000_400'
                                   1136 ;key           Allocated with name '_add_owned_key_key_40000_401'
                                   1137 ;------------------------------------------------------------
                                   1138 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1139 ;	-----------------------------------------
                                   1140 ;	 function add_owned_key
                                   1141 ;	-----------------------------------------
      008162                       1142 _add_owned_key:
      008162 E5 82            [12] 1143 	mov	a,dpl
      008164 90 0A AA         [24] 1144 	mov	dptr,#_add_owned_key_code_10000_388
      008167 12 85 CF         [24] 1145 	lcall	_ak820_outline_0139
                                   1146 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      00816A 74 01            [12] 1147 	mov	a,#0x01
      00816C F0               [24] 1148 	movx	@dptr,a
      00816D 90 0A 95         [24] 1149 	mov	dptr,#_macro_keys
      008170 C0 07            [24] 1150 	push	ar7
      008172 12 7F 87         [24] 1151 	lcall	_ak820_macro_change
      008175 E5 82            [12] 1152 	mov	a, dpl
      008177 D0 07            [24] 1153 	pop	ar7
      008179 70 03            [24] 1154 	jnz	00102$
      00817B F5 82            [12] 1155 	mov	dpl,a
      00817D 22               [24] 1156 	ret
      00817E                       1157 00102$:
                                   1158 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      00817E 12 85 7F         [24] 1159 	lcall	_ak820_outline_0031
      008181 FC               [12] 1160 	mov	r4,a
      008182 04               [12] 1161 	inc	a
      008183 12 85 B7         [24] 1162 	lcall	_ak820_outline_0104
      008186 EC               [12] 1163 	mov	a,r4
      008187 60 04            [24] 1164 	jz	00104$
      008189 75 82 00         [24] 1165 	mov	dpl, #0x00
      00818C 22               [24] 1166 	ret
      00818D                       1167 00104$:
                                   1168 ;	quantum/action_util.c:148: ++distinct_keys;
      00818D 90 0A 94         [24] 1169 	mov	dptr,#_distinct_keys
      008190 E0               [24] 1170 	movx	a,@dptr
      008191 24 01            [12] 1171 	add	a, #0x01
      008193 F0               [24] 1172 	movx	@dptr,a
                                   1173 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008194 90 0E 35         [24] 1174 	mov	dptr,#_keyboard_protocol
      008197 E0               [24] 1175 	movx	a,@dptr
      008198 60 11            [24] 1176 	jz	00106$
      00819A 90 0B 3C         [24] 1177 	mov	dptr,#_keymap_config
      00819D E0               [24] 1178 	movx	a,@dptr
      00819E 30 E7 0A         [24] 1179 	jnb	acc.7,00106$
                                   1180 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0081A1 12 85 E0         [24] 1181 	lcall	_ak820_outline_0182
      0081A4 12 73 5D         [24] 1182 	lcall	_add_key_to_report
                                   1183 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0081A7 75 82 01         [24] 1184 	mov	dpl, #0x01
      0081AA 22               [24] 1185 	ret
      0081AB                       1186 00106$:
                                   1187 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0081AB 90 0A 94         [24] 1188 	mov	dptr,#_distinct_keys
      0081AE E0               [24] 1189 	movx	a,@dptr
      0081AF 24 F9            [12] 1190 	add	a,#0xff - 0x06
      0081B1 50 17            [24] 1191 	jnc	00110$
                                   1192 ;	free result
                                   1193 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0081B3 7F 00            [12] 1194 	mov	r7,#0x00
      0081B5                       1195 00115$:
      0081B5 BF 06 00         [24] 1196 	cjne	r7,#0x06,00174$
      0081B8                       1197 00174$:
      0081B8 50 1E            [24] 1198 	jnc	00111$
      0081BA EF               [12] 1199 	mov	a,r7
      0081BB 24 4A            [12] 1200 	add	a, #(_actual_keyboard_report + 0x0002)
      0081BD F5 82            [12] 1201 	mov	dpl,a
      0081BF E4               [12] 1202 	clr	a
      0081C0 34 0E            [12] 1203 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      0081C2 F5 83            [12] 1204 	mov	dph,a
      0081C4 74 01            [12] 1205 	mov	a,#0x01
      0081C6 F0               [24] 1206 	movx	@dptr,a
      0081C7 0F               [12] 1207 	inc	r7
      0081C8 80 EB            [24] 1208 	sjmp	00115$
      0081CA                       1209 00110$:
                                   1210 ;	quantum/action_util.c:154: } else add_key(code);
      0081CA 90 0A AA         [24] 1211 	mov	dptr,#_add_owned_key_code_10000_388
      0081CD E0               [24] 1212 	movx	a,@dptr
                                   1213 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0081CE 90 08 60         [24] 1214 	mov	dptr,#_add_key_to_report_PARM_2
      0081D1 F0               [24] 1215 	movx	@dptr,a
      0081D2 90 0E 48         [24] 1216 	mov	dptr,#_actual_keyboard_report
      0081D5 12 73 5D         [24] 1217 	lcall	_add_key_to_report
                                   1218 ;	quantum/action_util.c:154: } else add_key(code);
      0081D8                       1219 00111$:
                                   1220 ;	quantum/action_util.c:155: return true;
      0081D8 75 82 01         [24] 1221 	mov	dpl, #0x01
                                   1222 ;	quantum/action_util.c:156: }
      0081DB 22               [24] 1223 	ret
                                   1224 ;------------------------------------------------------------
                                   1225 ;Allocation info for local variables in function 'del_owned_key'
                                   1226 ;------------------------------------------------------------
                                   1227 ;code          Allocated with name '_del_owned_key_code_10000_403'
                                   1228 ;__400000083   Allocated with name '_del_owned_key___400000083_40000_414'
                                   1229 ;key           Allocated with name '_del_owned_key_key_50000_415'
                                   1230 ;key           Allocated with name '_del_owned_key_key_40000_412'
                                   1231 ;__600000086   Allocated with name '_del_owned_key___600000086_60000_420'
                                   1232 ;key           Allocated with name '_del_owned_key_key_70000_421'
                                   1233 ;__300000088   Allocated with name '_del_owned_key___300000088_30000_423'
                                   1234 ;key           Allocated with name '_del_owned_key_key_40000_424'
                                   1235 ;------------------------------------------------------------
                                   1236 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1237 ;	-----------------------------------------
                                   1238 ;	 function del_owned_key
                                   1239 ;	-----------------------------------------
      0081DC                       1240 _del_owned_key:
      0081DC E5 82            [12] 1241 	mov	a,dpl
      0081DE 90 0A AB         [24] 1242 	mov	dptr,#_del_owned_key_code_10000_403
      0081E1 12 85 CF         [24] 1243 	lcall	_ak820_outline_0139
                                   1244 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      0081E4 E4               [12] 1245 	clr	a
      0081E5 F0               [24] 1246 	movx	@dptr,a
      0081E6 90 0A 95         [24] 1247 	mov	dptr,#_macro_keys
      0081E9 C0 07            [24] 1248 	push	ar7
      0081EB 12 7F 87         [24] 1249 	lcall	_ak820_macro_change
      0081EE E5 82            [12] 1250 	mov	a, dpl
      0081F0 D0 07            [24] 1251 	pop	ar7
      0081F2 70 03            [24] 1252 	jnz	00102$
      0081F4 F5 82            [12] 1253 	mov	dpl,a
      0081F6 22               [24] 1254 	ret
      0081F7                       1255 00102$:
                                   1256 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      0081F7 12 85 7F         [24] 1257 	lcall	_ak820_outline_0031
      0081FA FC               [12] 1258 	mov	r4,a
      0081FB 60 07            [24] 1259 	jz	00103$
      0081FD 1C               [12] 1260 	dec	r4
      0081FE 12 48 28         [24] 1261 	lcall	_ak820_outline_0069
      008201 EC               [12] 1262 	mov	a,r4
      008202 60 04            [24] 1263 	jz	00104$
      008204                       1264 00103$:
      008204 75 82 00         [24] 1265 	mov	dpl, #0x00
      008207 22               [24] 1266 	ret
      008208                       1267 00104$:
                                   1268 ;	quantum/action_util.c:160: --distinct_keys;
      008208 90 0A 94         [24] 1269 	mov	dptr,#_distinct_keys
      00820B E0               [24] 1270 	movx	a,@dptr
      00820C 14               [12] 1271 	dec	a
      00820D F0               [24] 1272 	movx	@dptr,a
                                   1273 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00820E 90 0E 35         [24] 1274 	mov	dptr,#_keyboard_protocol
      008211 E0               [24] 1275 	movx	a,@dptr
      008212 60 16            [24] 1276 	jz	00107$
      008214 90 0B 3C         [24] 1277 	mov	dptr,#_keymap_config
      008217 E0               [24] 1278 	movx	a,@dptr
      008218 30 E7 0F         [24] 1279 	jnb	acc.7,00107$
                                   1280 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00821B 90 08 63         [24] 1281 	mov	dptr,#_del_key_from_report_PARM_2
      00821E EF               [12] 1282 	mov	a,r7
      00821F F0               [24] 1283 	movx	@dptr,a
      008220 90 0E 48         [24] 1284 	mov	dptr,#_actual_keyboard_report
      008223 12 73 93         [24] 1285 	lcall	_del_key_from_report
                                   1286 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008226 75 82 01         [24] 1287 	mov	dpl, #0x01
      008229 22               [24] 1288 	ret
      00822A                       1289 00107$:
                                   1290 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      00822A 90 0A 94         [24] 1291 	mov	dptr,#_distinct_keys
      00822D E0               [24] 1292 	movx	a,@dptr
      00822E FF               [12] 1293 	mov  r7,a
      00822F 24 F9            [12] 1294 	add	a,#0xff - 0x06
      008231 50 04            [24] 1295 	jnc	00110$
                                   1296 ;	free result
      008233 75 82 01         [24] 1297 	mov	dpl, #0x01
      008236 22               [24] 1298 	ret
      008237                       1299 00110$:
                                   1300 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008237 BF 06 1F         [24] 1301 	cjne	r7,#0x06,00115$
                                   1302 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00823A 90 0E 48         [24] 1303 	mov	dptr,#_actual_keyboard_report
      00823D 12 73 C9         [24] 1304 	lcall	_clear_keys_from_report
                                   1305 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008240 7F 04            [12] 1306 	mov	r7,#0x04
      008242                       1307 00122$:
      008242 EF               [12] 1308 	mov	a,r7
      008243 24 5B            [12] 1309 	add	a,#0xff - 0xa4
      008245 40 20            [24] 1310 	jc	00116$
                                   1311 ;	free result
      008247 12 85 7F         [24] 1312 	lcall	_ak820_outline_0031
      00824A 60 0A            [24] 1313 	jz	00123$
                                   1314 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00824C 12 85 E0         [24] 1315 	lcall	_ak820_outline_0182
      00824F C0 07            [24] 1316 	push	ar7
      008251 12 73 5D         [24] 1317 	lcall	_add_key_to_report
      008254 D0 07            [24] 1318 	pop	ar7
                                   1319 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008256                       1320 00123$:
      008256 0F               [12] 1321 	inc	r7
      008257 80 E9            [24] 1322 	sjmp	00122$
      008259                       1323 00115$:
                                   1324 ;	quantum/action_util.c:169: } else del_key(code);
      008259 90 0A AB         [24] 1325 	mov	dptr,#_del_owned_key_code_10000_403
      00825C E0               [24] 1326 	movx	a,@dptr
                                   1327 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00825D 90 08 63         [24] 1328 	mov	dptr,#_del_key_from_report_PARM_2
      008260 F0               [24] 1329 	movx	@dptr,a
      008261 90 0E 48         [24] 1330 	mov	dptr,#_actual_keyboard_report
      008264 12 73 93         [24] 1331 	lcall	_del_key_from_report
                                   1332 ;	quantum/action_util.c:169: } else del_key(code);
      008267                       1333 00116$:
                                   1334 ;	quantum/action_util.c:170: return true;
      008267 75 82 01         [24] 1335 	mov	dpl, #0x01
                                   1336 ;	quantum/action_util.c:171: }
      00826A 22               [24] 1337 	ret
                                   1338 ;------------------------------------------------------------
                                   1339 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1340 ;------------------------------------------------------------
                                   1341 ;i             Allocated with name '_clear_owned_usages_i_20000_428'
                                   1342 ;i             Allocated with name '_clear_owned_usages_i_20000_429'
                                   1343 ;------------------------------------------------------------
                                   1344 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1345 ;	-----------------------------------------
                                   1346 ;	 function clear_owned_usages
                                   1347 ;	-----------------------------------------
      00826B                       1348 _clear_owned_usages:
                                   1349 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      00826B 7F 00            [12] 1350 	mov	r7,#0x00
      00826D                       1351 00104$:
      00826D BF 1E 00         [24] 1352 	cjne	r7,#0x1e,00141$
      008270                       1353 00141$:
      008270 50 14            [24] 1354 	jnc	00101$
      008272 EF               [12] 1355 	mov	a,r7
      008273 24 AC            [12] 1356 	add	a, #_usage_refs
      008275 FD               [12] 1357 	mov	r5,a
      008276 E4               [12] 1358 	clr	a
      008277 34 0A            [12] 1359 	addc	a, #(_usage_refs >> 8)
      008279 FE               [12] 1360 	mov	r6,a
      00827A EF               [12] 1361 	mov	a,r7
      00827B 12 85 9E         [24] 1362 	lcall	_ak820_outline_0073
      00827E E4               [12] 1363 	clr	a
      00827F F0               [24] 1364 	movx	@dptr,a
      008280 12 85 B7         [24] 1365 	lcall	_ak820_outline_0104
      008283 0F               [12] 1366 	inc	r7
      008284 80 E7            [24] 1367 	sjmp	00104$
      008286                       1368 00101$:
                                   1369 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      008286 90 0A E9         [24] 1370 	mov	dptr,#(_usage_lengths + 0x0001)
      008289 E4               [12] 1371 	clr	a
      00828A F0               [24] 1372 	movx	@dptr,a
      00828B 90 0A E8         [24] 1373 	mov	dptr,#_usage_lengths
      00828E F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      00828F FF               [12] 1376 	mov	r7,a
      008290                       1377 00107$:
      008290 BF 04 00         [24] 1378 	cjne	r7,#0x04,00143$
      008293                       1379 00143$:
      008293 50 0D            [24] 1380 	jnc	00109$
      008295 EF               [12] 1381 	mov	a,r7
      008296 24 EA            [12] 1382 	add	a, #_macro_usages
      008298 F5 82            [12] 1383 	mov	dpl,a
      00829A E4               [12] 1384 	clr	a
      00829B 34 0A            [12] 1385 	addc	a, #(_macro_usages >> 8)
      00829D 12 7F 78         [24] 1386 	lcall	_ak820_outline_0171
      0082A0 80 EE            [24] 1387 	sjmp	00107$
      0082A2                       1388 00109$:
                                   1389 ;	quantum/action_util.c:185: }
      0082A2 22               [24] 1390 	ret
                                   1391 ;------------------------------------------------------------
                                   1392 ;Allocation info for local variables in function 'owned_usage_key'
                                   1393 ;------------------------------------------------------------
                                   1394 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1395 ;code          Allocated with name '_owned_usage_key_code_10000_430'
                                   1396 ;__200000090   Allocated with name '_owned_usage_key___200000090_20000_431'
                                   1397 ;which         Allocated with name '_owned_usage_key_which_10000_431'
                                   1398 ;base          Allocated with name '_owned_usage_key_base_10000_431'
                                   1399 ;count         Allocated with name '_owned_usage_key_count_10000_431'
                                   1400 ;index         Allocated with name '_owned_usage_key_index_10000_431'
                                   1401 ;pos           Allocated with name '_owned_usage_key_pos_30001_438'
                                   1402 ;i             Allocated with name '_owned_usage_key_i_40001_439'
                                   1403 ;__300000091   Allocated with name '_owned_usage_key___300000091_30000_442'
                                   1404 ;key           Allocated with name '_owned_usage_key_key_40000_443'
                                   1405 ;------------------------------------------------------------
                                   1406 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1407 ;	-----------------------------------------
                                   1408 ;	 function owned_usage_key
                                   1409 ;	-----------------------------------------
      0082A3                       1410 _owned_usage_key:
      0082A3 E5 82            [12] 1411 	mov	a,dpl
      0082A5 90 0A EF         [24] 1412 	mov	dptr,#_owned_usage_key_code_10000_430
      0082A8 F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      0082A9 E0               [24] 1415 	movx	a,@dptr
      0082AA FF               [12] 1416 	mov	r7,a
      0082AB BF A8 00         [24] 1417 	cjne	r7,#0xa8,00244$
      0082AE                       1418 00244$:
      0082AE B3               [12] 1419 	cpl	c
      0082AF 92 23            [24] 1420 	mov	_owned_usage_key_sloc0_1_0,c
      0082B1 E4               [12] 1421 	clr	a
      0082B2 33               [12] 1422 	rlc	a
      0082B3 FF               [12] 1423 	mov	r7,a
      0082B4 90 0A F2         [24] 1424 	mov	dptr,#_owned_usage_key_which_10000_431
      0082B7 F0               [24] 1425 	movx	@dptr,a
                                   1426 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      0082B8 EF               [12] 1427 	mov	a,r7
      0082B9 60 02            [24] 1428 	jz	00129$
      0082BB 74 03            [12] 1429 	mov	a,#0x03
      0082BD                       1430 00129$:
      0082BD FE               [12] 1431 	mov	r6,a
                                   1432 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      0082BE EF               [12] 1433 	mov	a,r7
      0082BF 24 E8            [12] 1434 	add	a, #_usage_lengths
      0082C1 FD               [12] 1435 	mov	r5,a
      0082C2 E4               [12] 1436 	clr	a
      0082C3 34 0A            [12] 1437 	addc	a, #(_usage_lengths >> 8)
      0082C5 FF               [12] 1438 	mov	r7,a
      0082C6 12 40 65         [24] 1439 	lcall	_ak820_outline_0190
      0082C9 E0               [24] 1440 	movx	a,@dptr
      0082CA FC               [12] 1441 	mov	r4,a
                                   1442 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      0082CB 90 0A EF         [24] 1443 	mov	dptr,#_owned_usage_key_code_10000_430
      0082CE E0               [24] 1444 	movx	a,@dptr
      0082CF 24 5B            [12] 1445 	add	a,#0x5b
      0082D1 FB               [12] 1446 	mov	r3,a
                                   1447 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      0082D2 90 0A EE         [24] 1448 	mov	dptr,#_owned_usage_key_PARM_2
      0082D5 E0               [24] 1449 	movx	a,@dptr
      0082D6 FA               [12] 1450 	mov	r2,a
      0082D7 90 09 E3         [24] 1451 	mov	dptr,#_ak820_macro_change_PARM_2
      0082DA EB               [12] 1452 	mov	a,r3
      0082DB F0               [24] 1453 	movx	@dptr,a
      0082DC 90 09 E4         [24] 1454 	mov	dptr,#_ak820_macro_change_PARM_3
      0082DF EA               [12] 1455 	mov	a,r2
      0082E0 F0               [24] 1456 	movx	@dptr,a
      0082E1 90 0A EA         [24] 1457 	mov	dptr,#_macro_usages
      0082E4 C0 07            [24] 1458 	push	ar7
      0082E6 C0 06            [24] 1459 	push	ar6
      0082E8 C0 05            [24] 1460 	push	ar5
      0082EA C0 04            [24] 1461 	push	ar4
      0082EC C0 03            [24] 1462 	push	ar3
      0082EE C0 02            [24] 1463 	push	ar2
      0082F0 12 7F 87         [24] 1464 	lcall	_ak820_macro_change
      0082F3 E5 82            [12] 1465 	mov	a, dpl
      0082F5 D0 02            [24] 1466 	pop	ar2
      0082F7 D0 03            [24] 1467 	pop	ar3
      0082F9 D0 04            [24] 1468 	pop	ar4
      0082FB D0 05            [24] 1469 	pop	ar5
      0082FD D0 06            [24] 1470 	pop	ar6
      0082FF D0 07            [24] 1471 	pop	ar7
      008301 70 01            [24] 1472 	jnz	00102$
      008303 22               [24] 1473 	ret
      008304                       1474 00102$:
                                   1475 ;	quantum/action_util.c:192: if (pressed) {
      008304 EA               [12] 1476 	mov	a,r2
      008305 60 1B            [24] 1477 	jz	00115$
                                   1478 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      008307 12 85 A8         [24] 1479 	lcall	_ak820_outline_0077
      00830A 04               [12] 1480 	inc	a
      00830B 12 70 DF         [24] 1481 	lcall	_ak820_outline_0145
      00830E E8               [12] 1482 	mov	a,r0
      00830F 60 01            [24] 1483 	jz	00104$
      008311 22               [24] 1484 	ret
      008312                       1485 00104$:
                                   1486 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      008312 90 0A F3         [24] 1487 	mov	dptr,#_owned_usage_key_count_10000_431
      008315 EC               [12] 1488 	mov	a,r4
      008316 04               [12] 1489 	inc	a
      008317 F0               [24] 1490 	movx	@dptr,a
      008318 EC               [12] 1491 	mov	a,r4
      008319 2E               [12] 1492 	add	a, r6
      00831A 12 85 9E         [24] 1493 	lcall	_ak820_outline_0073
      00831D EB               [12] 1494 	mov	a,r3
      00831E F0               [24] 1495 	movx	@dptr,a
      00831F 02 83 83         [24] 1496 	ljmp	00116$
      008322                       1497 00115$:
                                   1498 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      008322 12 85 A8         [24] 1499 	lcall	_ak820_outline_0077
      008325 60 07            [24] 1500 	jz	00105$
      008327 18               [12] 1501 	dec	r0
      008328 12 85 8D         [24] 1502 	lcall	_ak820_outline_0068
      00832B E8               [12] 1503 	mov	a,r0
      00832C 60 01            [24] 1504 	jz	00106$
      00832E                       1505 00105$:
      00832E 22               [24] 1506 	ret
      00832F                       1507 00106$:
                                   1508 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      00832F 7A 00            [12] 1509 	mov	r2,#0x00
      008331                       1510 00108$:
      008331 EA               [12] 1511 	mov	a,r2
      008332 2E               [12] 1512 	add	a, r6
      008333 12 85 9E         [24] 1513 	lcall	_ak820_outline_0073
      008336 E0               [24] 1514 	movx	a,@dptr
      008337 B5 03 02         [24] 1515 	cjne	a,ar3,00251$
      00833A 80 03            [24] 1516 	sjmp	00167$
      00833C                       1517 00251$:
      00833C 0A               [12] 1518 	inc	r2
      00833D 80 F2            [24] 1519 	sjmp	00108$
      00833F                       1520 00167$:
      00833F 90 0A F4         [24] 1521 	mov	dptr,#_owned_usage_key_pos_30001_438
      008342 EA               [12] 1522 	mov	a,r2
      008343 F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:199: --count;
      008344 1C               [12] 1525 	dec	r4
      008345 90 0A F3         [24] 1526 	mov	dptr,#_owned_usage_key_count_10000_431
      008348 EC               [12] 1527 	mov	a,r4
      008349 F0               [24] 1528 	movx	@dptr,a
                                   1529 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      00834A 8A 03            [24] 1530 	mov	ar3,r2
      00834C                       1531 00125$:
      00834C C3               [12] 1532 	clr	c
      00834D EB               [12] 1533 	mov	a,r3
      00834E 9C               [12] 1534 	subb	a,r4
      00834F 50 23            [24] 1535 	jnc	00111$
      008351 C0 05            [24] 1536 	push	ar5
      008353 C0 07            [24] 1537 	push	ar7
      008355 EB               [12] 1538 	mov	a,r3
      008356 2E               [12] 1539 	add	a, r6
      008357 FA               [12] 1540 	mov	r2,a
      008358 24 CA            [12] 1541 	add	a, #_usage_order
      00835A F8               [12] 1542 	mov	r0,a
      00835B E4               [12] 1543 	clr	a
      00835C 34 0A            [12] 1544 	addc	a, #(_usage_order >> 8)
      00835E F9               [12] 1545 	mov	r1,a
      00835F 0A               [12] 1546 	inc	r2
      008360 EA               [12] 1547 	mov	a,r2
      008361 33               [12] 1548 	rlc	a
      008362 95 E0            [12] 1549 	subb	a,acc
      008364 FF               [12] 1550 	mov	r7,a
      008365 EA               [12] 1551 	mov	a,r2
      008366 12 85 C4         [24] 1552 	lcall	_ak820_outline_0133
      008369 12 38 75         [24] 1553 	lcall	_ak820_outline_0162
      00836C F0               [24] 1554 	movx	@dptr,a
      00836D 0B               [12] 1555 	inc	r3
      00836E D0 07            [24] 1556 	pop	ar7
      008370 D0 05            [24] 1557 	pop	ar5
      008372 80 D8            [24] 1558 	sjmp	00125$
      008374                       1559 00111$:
                                   1560 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      008374 12 40 65         [24] 1561 	lcall	_ak820_outline_0190
      008377 EC               [12] 1562 	mov	a,r4
      008378 F0               [24] 1563 	movx	@dptr,a
                                   1564 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      008379 90 0A F4         [24] 1565 	mov	dptr,#_owned_usage_key_pos_30001_438
      00837C E0               [24] 1566 	movx	a,@dptr
      00837D B5 04 02         [24] 1567 	cjne	a,ar4,00253$
      008380 80 01            [24] 1568 	sjmp	00116$
      008382                       1569 00253$:
      008382 22               [24] 1570 	ret
      008383                       1571 00116$:
                                   1572 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      008383 90 0A F3         [24] 1573 	mov	dptr,#_owned_usage_key_count_10000_431
      008386 E0               [24] 1574 	movx	a,@dptr
      008387 FC               [12] 1575 	mov	r4,a
      008388 12 40 65         [24] 1576 	lcall	_ak820_outline_0190
      00838B F0               [24] 1577 	movx	@dptr,a
                                   1578 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      00838C EC               [12] 1579 	mov	a,r4
      00838D 60 15            [24] 1580 	jz	00131$
      00838F EC               [12] 1581 	mov	a,r4
      008390 2E               [12] 1582 	add	a, r6
      008391 FE               [12] 1583 	mov	r6,a
      008392 1E               [12] 1584 	dec	r6
      008393 EE               [12] 1585 	mov	a,r6
      008394 33               [12] 1586 	rlc	a
      008395 95 E0            [12] 1587 	subb	a,acc
      008397 FF               [12] 1588 	mov	r7,a
      008398 EE               [12] 1589 	mov	a,r6
      008399 12 85 C4         [24] 1590 	lcall	_ak820_outline_0133
      00839C 24 A5            [12] 1591 	add	a,#0xa5
      00839E FE               [12] 1592 	mov	r6,a
      00839F 33               [12] 1593 	rlc	a
      0083A0 95 E0            [12] 1594 	subb	a,acc
      0083A2 80 02            [24] 1595 	sjmp	00132$
      0083A4                       1596 00131$:
      0083A4 7E 00            [12] 1597 	mov	r6,#0x00
      0083A6                       1598 00132$:
      0083A6 90 0A EF         [24] 1599 	mov	dptr,#_owned_usage_key_code_10000_430
      0083A9 EE               [12] 1600 	mov	a,r6
      0083AA F0               [24] 1601 	movx	@dptr,a
                                   1602 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0083AB 90 0A F2         [24] 1603 	mov	dptr,#_owned_usage_key_which_10000_431
      0083AE E0               [24] 1604 	movx	a,@dptr
      0083AF 60 18            [24] 1605 	jz	00118$
      0083B1 EE               [12] 1606 	mov	a,r6
      0083B2 60 0B            [24] 1607 	jz	00133$
      0083B4 8E 82            [24] 1608 	mov	dpl, r6
      0083B6 12 72 18         [24] 1609 	lcall	_KEYCODE2CONSUMER
      0083B9 AD 82            [24] 1610 	mov	r5, dpl
      0083BB AF 83            [24] 1611 	mov	r7, dph
      0083BD 80 04            [24] 1612 	sjmp	00134$
      0083BF                       1613 00133$:
      0083BF 7D 00            [12] 1614 	mov	r5,#0x00
      0083C1 7F 00            [12] 1615 	mov	r7,#0x00
      0083C3                       1616 00134$:
      0083C3 12 40 65         [24] 1617 	lcall	_ak820_outline_0190
      0083C6 02 71 D2         [24] 1618 	ljmp	_host_consumer_send
      0083C9                       1619 00118$:
                                   1620 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0083C9 EE               [12] 1621 	mov	a,r6
      0083CA 60 22            [24] 1622 	jz	00135$
                                   1623 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      0083CC BE A5 00         [24] 1624 	cjne	r6,#0xa5,00258$
      0083CF                       1625 00258$:
      0083CF 40 05            [24] 1626 	jc	00121$
      0083D1 EE               [12] 1627 	mov	a,r6
      0083D2 24 58            [12] 1628 	add	a,#0xff - 0xa7
      0083D4 50 08            [24] 1629 	jnc	00122$
                                   1630 ;	free result
      0083D6                       1631 00121$:
      0083D6 90 0A F0         [24] 1632 	mov	dptr,#_owned_usage_key___200000090_20000_431
      0083D9 12 53 F6         [24] 1633 	lcall	_ak820_outline_0155
      0083DC 80 09            [24] 1634 	sjmp	00123$
      0083DE                       1635 00122$:
                                   1636 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      0083DE 74 DC            [12] 1637 	mov	a,#0xdc
      0083E0 2E               [12] 1638 	add	a, r6
      0083E1 90 0A F0         [24] 1639 	mov	dptr,#_owned_usage_key___200000090_20000_431
      0083E4 12 38 60         [24] 1640 	lcall	_ak820_outline_0132
                                   1641 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0083E7                       1642 00123$:
      0083E7 90 0A F0         [24] 1643 	mov	dptr,#_owned_usage_key___200000090_20000_431
      0083EA E0               [24] 1644 	movx	a,@dptr
      0083EB FF               [12] 1645 	mov	r7,a
      0083EC 80 02            [24] 1646 	sjmp	00136$
      0083EE                       1647 00135$:
      0083EE 7F 00            [12] 1648 	mov	r7,#0x00
      0083F0                       1649 00136$:
      0083F0 7E 00            [12] 1650 	mov	r6,#0x00
      0083F2 12 48 6C         [24] 1651 	lcall	_ak820_outline_0164
                                   1652 ;	quantum/action_util.c:208: }
      0083F5 02 71 A2         [24] 1653 	ljmp	_host_system_send
                                   1654 ;------------------------------------------------------------
                                   1655 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1656 ;------------------------------------------------------------
                                   1657 ;projected     Allocated with name '_send_keyboard_report_projected_10001_450'
                                   1658 ;out           Allocated with name '_send_keyboard_report_out_10001_450'
                                   1659 ;base          Allocated with name '_send_keyboard_report_base_10001_450'
                                   1660 ;i             Allocated with name '_send_keyboard_report_i_20001_451'
                                   1661 ;overlay_key   Allocated with name '_send_keyboard_report_overlay_key_10002_452'
                                   1662 ;empty         Allocated with name '_send_keyboard_report_empty_50002_457'
                                   1663 ;i             Allocated with name '_send_keyboard_report_i_60002_458'
                                   1664 ;i             Allocated with name '_send_keyboard_report_i_70002_463'
                                   1665 ;last_report   Allocated with name '_send_keyboard_report_last_report_10003_464'
                                   1666 ;changed       Allocated with name '_send_keyboard_report_changed_10003_464'
                                   1667 ;dest          Allocated with name '_send_keyboard_report_dest_10003_464'
                                   1668 ;src           Allocated with name '_send_keyboard_report_src_10003_464'
                                   1669 ;i             Allocated with name '_send_keyboard_report_i_20003_465'
                                   1670 ;------------------------------------------------------------
                                   1671 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1672 ;	-----------------------------------------
                                   1673 ;	 function send_keyboard_report
                                   1674 ;	-----------------------------------------
      0083F8                       1675 _send_keyboard_report:
                                   1676 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      0083F8 90 0E 46         [24] 1677 	mov	dptr,#_real_mods
      0083FB E0               [24] 1678 	movx	a,@dptr
      0083FC FF               [12] 1679 	mov	r7,a
      0083FD 90 0E 48         [24] 1680 	mov	dptr,#_actual_keyboard_report
      008400 F0               [24] 1681 	movx	@dptr,a
                                   1682 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      008401 90 0E 47         [24] 1683 	mov	dptr,#_weak_mods
      008404 E0               [24] 1684 	movx	a,@dptr
      008405 42 07            [12] 1685 	orl	ar7,a
      008407 90 0E 48         [24] 1686 	mov	dptr,#_actual_keyboard_report
      00840A EF               [12] 1687 	mov	a,r7
      00840B F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00840C 90 09 DE         [24] 1690 	mov	dptr,#_owned_weak_mods
      00840F E0               [24] 1691 	movx	a,@dptr
      008410 FE               [12] 1692 	mov	r6,a
      008411 90 09 DD         [24] 1693 	mov	dptr,#_owned_mods
      008414 E0               [24] 1694 	movx	a,@dptr
      008415 4E               [12] 1695 	orl	a,r6
      008416 42 07            [12] 1696 	orl	ar7,a
      008418 90 0E 48         [24] 1697 	mov	dptr,#_actual_keyboard_report
      00841B EF               [12] 1698 	mov	a,r7
      00841C F0               [24] 1699 	movx	@dptr,a
                                   1700 ;	quantum/action_util.c:458: ak820_key_override_sync(keyboard_report->mods, get_highest_layer(layer_state | default_layer_state));
      00841D 90 0E 44         [24] 1701 	mov	dptr,#_default_layer_state
      008420 E0               [24] 1702 	movx	a,@dptr
      008421 FE               [12] 1703 	mov	r6,a
      008422 90 0E 45         [24] 1704 	mov	dptr,#_layer_state
      008425 E0               [24] 1705 	movx	a,@dptr
      008426 42 06            [12] 1706 	orl	ar6,a
      008428 8E 82            [24] 1707 	mov	dpl, r6
      00842A C0 07            [24] 1708 	push	ar7
      00842C 12 85 E9         [24] 1709 	lcall	_biton
      00842F E5 82            [12] 1710 	mov	a, dpl
      008431 D0 07            [24] 1711 	pop	ar7
      008433 90 05 56         [24] 1712 	mov	dptr,#_ak820_key_override_sync_PARM_2
      008436 F0               [24] 1713 	movx	@dptr,a
      008437 8F 82            [24] 1714 	mov	dpl, r7
      008439 12 3D C9         [24] 1715 	lcall	_ak820_key_override_sync
                                   1716 ;	quantum/action_util.c:459: keyboard_report->mods = ak820_key_override_mods(keyboard_report->mods);
      00843C 90 0E 48         [24] 1717 	mov	dptr,#_actual_keyboard_report
      00843F E0               [24] 1718 	movx	a,@dptr
      008440 F5 82            [12] 1719 	mov	dpl,a
      008442 12 3F AE         [24] 1720 	lcall	_ak820_key_override_mods
      008445 AF 82            [24] 1721 	mov	r7, dpl
      008447 90 0E 48         [24] 1722 	mov	dptr,#_actual_keyboard_report
      00844A EF               [12] 1723 	mov	a,r7
      00844B F0               [24] 1724 	movx	@dptr,a
                                   1725 ;	quantum/action_util.c:482: uint8_t AK820_STATE_MEM *out = (uint8_t AK820_STATE_MEM *)&projected;
                                   1726 ;	quantum/action_util.c:483: const uint8_t AK820_STATE_MEM *base = (const uint8_t AK820_STATE_MEM *)keyboard_report;
                                   1727 ;	quantum/action_util.c:484: for (uint8_t i = 0; i < sizeof(projected); ++i) out[i] = base[i];
      00844C 7F 00            [12] 1728 	mov	r7,#0x00
      00844E                       1729 00124$:
      00844E BF 20 00         [24] 1730 	cjne	r7,#0x20,00252$
      008451                       1731 00252$:
      008451 50 19            [24] 1732 	jnc	00101$
      008453 EF               [12] 1733 	mov	a,r7
      008454 24 F6            [12] 1734 	add	a, #_send_keyboard_report_projected_10001_450
      008456 FD               [12] 1735 	mov	r5,a
      008457 E4               [12] 1736 	clr	a
      008458 34 0A            [12] 1737 	addc	a, #(_send_keyboard_report_projected_10001_450 >> 8)
      00845A FE               [12] 1738 	mov	r6,a
      00845B EF               [12] 1739 	mov	a,r7
      00845C 24 48            [12] 1740 	add	a, #_actual_keyboard_report
      00845E F5 82            [12] 1741 	mov	dpl,a
      008460 E4               [12] 1742 	clr	a
      008461 34 0E            [12] 1743 	addc	a, #(_actual_keyboard_report >> 8)
      008463 F5 83            [12] 1744 	mov	dph,a
      008465 E0               [24] 1745 	movx	a,@dptr
      008466 12 85 B7         [24] 1746 	lcall	_ak820_outline_0104
      008469 0F               [12] 1747 	inc	r7
      00846A 80 E2            [24] 1748 	sjmp	00124$
      00846C                       1749 00101$:
                                   1750 ;	quantum/action_util.c:485: uint8_t overlay_key = ak820_key_override_key();
      00846C 12 3F 7F         [24] 1751 	lcall	_ak820_key_override_key
                                   1752 ;	quantum/action_util.c:486: if (overlay_key) {
      00846F E5 82            [12] 1753 	mov	a,dpl
      008471 FF               [12] 1754 	mov	r7,a
      008472 70 03            [24] 1755 	jnz	00254$
      008474 02 84 EE         [24] 1756 	ljmp	00117$
      008477                       1757 00254$:
                                   1758 ;	quantum/action_util.c:488: if (keyboard_protocol && keymap_config.nkro) {
      008477 90 0E 35         [24] 1759 	mov	dptr,#_keyboard_protocol
      00847A E0               [24] 1760 	movx	a,@dptr
      00847B 60 2B            [24] 1761 	jz	00112$
      00847D 90 0B 3C         [24] 1762 	mov	dptr,#_keymap_config
      008480 E0               [24] 1763 	movx	a,@dptr
      008481 30 E7 24         [24] 1764 	jnb	acc.7,00112$
                                   1765 ;	quantum/action_util.c:489: projected.nkro.bits[overlay_key >> 3] |= 1u << (overlay_key & 7);
      008484 12 85 DA         [24] 1766 	lcall	_ak820_outline_0170
      008487 24 F8            [12] 1767 	add	a,#(_send_keyboard_report_projected_10001_450 + 0x0002)
      008489 FE               [12] 1768 	mov	r6,a
      00848A E4               [12] 1769 	clr	a
      00848B 34 0A            [12] 1770 	addc	a, #((_send_keyboard_report_projected_10001_450 + 0x0002) >> 8)
      00848D FD               [12] 1771 	mov	r5,a
      00848E 12 7B 1A         [24] 1772 	lcall	_ak820_outline_0041
      008491 80 02            [24] 1773 	sjmp	00258$
      008493                       1774 00257$:
      008493 25 E0            [12] 1775 	add	a,acc
      008495                       1776 00258$:
      008495 D5 F0 FB         [24] 1777 	djnz	b,00257$
      008498 FC               [12] 1778 	mov	r4,a
      008499 8E 82            [24] 1779 	mov	dpl,r6
      00849B 8D 83            [24] 1780 	mov	dph,r5
      00849D E0               [24] 1781 	movx	a,@dptr
      00849E 42 04            [12] 1782 	orl	ar4,a
      0084A0 8E 82            [24] 1783 	mov	dpl,r6
      0084A2 8D 83            [24] 1784 	mov	dph,r5
      0084A4 EC               [12] 1785 	mov	a,r4
      0084A5 F0               [24] 1786 	movx	@dptr,a
      0084A6 80 46            [24] 1787 	sjmp	00117$
      0084A8                       1788 00112$:
                                   1789 ;	quantum/action_util.c:493: uint8_t empty = 255;
      0084A8 90 0B 16         [24] 1790 	mov	dptr,#_send_keyboard_report_empty_50002_457
      0084AB 74 FF            [12] 1791 	mov	a,#0xff
      0084AD F0               [24] 1792 	movx	@dptr,a
                                   1793 ;	quantum/action_util.c:494: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) {
      0084AE 7E 00            [12] 1794 	mov	r6,#0x00
      0084B0                       1795 00127$:
      0084B0 BE 06 00         [24] 1796 	cjne	r6,#0x06,00259$
      0084B3                       1797 00259$:
      0084B3 50 16            [24] 1798 	jnc	00106$
                                   1799 ;	quantum/action_util.c:495: if (projected.keys[i] == overlay_key) goto projected_ready;
      0084B5 EE               [12] 1800 	mov	a,r6
      0084B6 12 85 94         [24] 1801 	lcall	_ak820_outline_0071
      0084B9 E0               [24] 1802 	movx	a,@dptr
      0084BA FD               [12] 1803 	mov	r5,a
      0084BB B5 07 02         [24] 1804 	cjne	a,ar7,00261$
      0084BE 80 2E            [24] 1805 	sjmp	00117$
      0084C0                       1806 00261$:
                                   1807 ;	quantum/action_util.c:496: if (!projected.keys[i]) empty = i;
      0084C0 ED               [12] 1808 	mov	a,r5
      0084C1 70 05            [24] 1809 	jnz	00128$
      0084C3 90 0B 16         [24] 1810 	mov	dptr,#_send_keyboard_report_empty_50002_457
      0084C6 EE               [12] 1811 	mov	a,r6
      0084C7 F0               [24] 1812 	movx	@dptr,a
      0084C8                       1813 00128$:
                                   1814 ;	quantum/action_util.c:494: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) {
      0084C8 0E               [12] 1815 	inc	r6
      0084C9 80 E5            [24] 1816 	sjmp	00127$
      0084CB                       1817 00106$:
                                   1818 ;	quantum/action_util.c:498: if (empty != 255) projected.keys[empty] = overlay_key;
      0084CB 90 0B 16         [24] 1819 	mov	dptr,#_send_keyboard_report_empty_50002_457
      0084CE E0               [24] 1820 	movx	a,@dptr
      0084CF FE               [12] 1821 	mov	r6,a
      0084D0 BE FF 02         [24] 1822 	cjne	r6,#0xff,00263$
      0084D3 80 08            [24] 1823 	sjmp	00164$
      0084D5                       1824 00263$:
      0084D5 EE               [12] 1825 	mov	a,r6
      0084D6 12 85 94         [24] 1826 	lcall	_ak820_outline_0071
      0084D9 EF               [12] 1827 	mov	a,r7
      0084DA F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:499: else for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) projected.keys[i] = 1;
      0084DB 80 11            [24] 1830 	sjmp	00117$
      0084DD                       1831 00164$:
      0084DD 7F 00            [12] 1832 	mov	r7,#0x00
      0084DF                       1833 00130$:
      0084DF BF 06 00         [24] 1834 	cjne	r7,#0x06,00264$
      0084E2                       1835 00264$:
      0084E2 50 0A            [24] 1836 	jnc	00117$
      0084E4 EF               [12] 1837 	mov	a,r7
      0084E5 12 85 94         [24] 1838 	lcall	_ak820_outline_0071
      0084E8 74 01            [12] 1839 	mov	a,#0x01
      0084EA F0               [24] 1840 	movx	@dptr,a
      0084EB 0F               [12] 1841 	inc	r7
                                   1842 ;	quantum/action_util.c:502: projected_ready: ;
      0084EC 80 F1            [24] 1843 	sjmp	00130$
      0084EE                       1844 00117$:
                                   1845 ;	quantum/action_util.c:515: bool changed = false;
      0084EE 90 0B 37         [24] 1846 	mov	dptr,#_send_keyboard_report_changed_10003_464
      0084F1 E4               [12] 1847 	clr	a
      0084F2 F0               [24] 1848 	movx	@dptr,a
                                   1849 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1850 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0084F3 FF               [12] 1851 	mov	r7,a
      0084F4                       1852 00133$:
      0084F4 BF 20 00         [24] 1853 	cjne	r7,#0x20,00266$
      0084F7                       1854 00266$:
      0084F7 50 2B            [24] 1855 	jnc	00120$
                                   1856 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      0084F9 EF               [12] 1857 	mov	a,r7
      0084FA 24 17            [12] 1858 	add	a, #_send_keyboard_report_last_report_10003_464
      0084FC FD               [12] 1859 	mov	r5,a
      0084FD E4               [12] 1860 	clr	a
      0084FE 34 0B            [12] 1861 	addc	a, #(_send_keyboard_report_last_report_10003_464 >> 8)
      008500 FE               [12] 1862 	mov	r6,a
      008501 12 4D 6B         [24] 1863 	lcall	_ak820_outline_0079
      008504 EF               [12] 1864 	mov	a,r7
      008505 24 F6            [12] 1865 	add	a, #_send_keyboard_report_projected_10001_450
      008507 F5 82            [12] 1866 	mov	dpl,a
      008509 E4               [12] 1867 	clr	a
      00850A 34 0A            [12] 1868 	addc	a, #(_send_keyboard_report_projected_10001_450 >> 8)
      00850C F5 83            [12] 1869 	mov	dph,a
      00850E E0               [24] 1870 	movx	a,@dptr
      00850F FB               [12] 1871 	mov	r3,a
      008510 EC               [12] 1872 	mov	a,r4
      008511 B5 03 02         [24] 1873 	cjne	a,ar3,00268$
      008514 80 0B            [24] 1874 	sjmp	00134$
      008516                       1875 00268$:
                                   1876 ;	quantum/action_util.c:525: dest[i] = src[i];
      008516 12 38 65         [24] 1877 	lcall	_ak820_outline_0141
      008519 EB               [12] 1878 	mov	a,r3
      00851A F0               [24] 1879 	movx	@dptr,a
                                   1880 ;	quantum/action_util.c:526: changed = true;
      00851B 90 0B 37         [24] 1881 	mov	dptr,#_send_keyboard_report_changed_10003_464
      00851E 74 01            [12] 1882 	mov	a,#0x01
      008520 F0               [24] 1883 	movx	@dptr,a
      008521                       1884 00134$:
                                   1885 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008521 0F               [12] 1886 	inc	r7
      008522 80 D0            [24] 1887 	sjmp	00133$
      008524                       1888 00120$:
                                   1889 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      008524 90 0B 37         [24] 1890 	mov	dptr,#_send_keyboard_report_changed_10003_464
      008527 E0               [24] 1891 	movx	a,@dptr
      008528 60 09            [24] 1892 	jz	00135$
      00852A 90 0A F6         [24] 1893 	mov	dptr,#_send_keyboard_report_projected_10001_450
      00852D 75 F0 00         [24] 1894 	mov	b, #0x00
                                   1895 ;	quantum/action_util.c:538: }
      008530 02 71 17         [24] 1896 	ljmp	_host_keyboard_send
      008533                       1897 00135$:
      008533 22               [24] 1898 	ret
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'get_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1903 ;	-----------------------------------------
                                   1904 ;	 function get_mods
                                   1905 ;	-----------------------------------------
      008534                       1906 _get_mods:
      008534 C0 07            [24] 1907 	push	ar7
                                   1908 ;	quantum/action_util.c:549: ;
      008536 90 09 DD         [24] 1909 	mov	dptr,#_owned_mods
      008539 E0               [24] 1910 	movx	a,@dptr
      00853A FF               [12] 1911 	mov	r7,a
      00853B 90 0E 46         [24] 1912 	mov	dptr,#_real_mods
      00853E 12 40 5F         [24] 1913 	lcall	_ak820_outline_0130
                                   1914 ;	quantum/action_util.c:550: }
      008541 D0 07            [24] 1915 	pop	ar7
      008543 22               [24] 1916 	ret
                                   1917 ;------------------------------------------------------------
                                   1918 ;Allocation info for local variables in function 'add_mods'
                                   1919 ;------------------------------------------------------------
                                   1920 ;mods          Allocated with name '_add_mods_mods_10000_472'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function clear_mods
                                   1925 ;	-----------------------------------------
      008544                       1926 _clear_mods:
                                   1927 ;	quantum/action_util.c:577: real_mods = 0;
      008544 90 0E 46         [24] 1928 	mov	dptr,#_real_mods
      008547 E4               [12] 1929 	clr	a
      008548 F0               [24] 1930 	movx	@dptr,a
                                   1931 ;	quantum/action_util.c:578: }
      008549 22               [24] 1932 	ret
                                   1933 ;------------------------------------------------------------
                                   1934 ;Allocation info for local variables in function 'get_weak_mods'
                                   1935 ;------------------------------------------------------------
                                   1936 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1937 ;	-----------------------------------------
                                   1938 ;	 function get_weak_mods
                                   1939 ;	-----------------------------------------
      00854A                       1940 _get_weak_mods:
      00854A C0 07            [24] 1941 	push	ar7
                                   1942 ;	quantum/action_util.c:589: ;
      00854C 90 09 DE         [24] 1943 	mov	dptr,#_owned_weak_mods
      00854F E0               [24] 1944 	movx	a,@dptr
      008550 FF               [12] 1945 	mov	r7,a
      008551 90 0E 47         [24] 1946 	mov	dptr,#_weak_mods
      008554 12 40 5F         [24] 1947 	lcall	_ak820_outline_0130
                                   1948 ;	quantum/action_util.c:590: }
      008557 D0 07            [24] 1949 	pop	ar7
      008559 22               [24] 1950 	ret
                                   1951 ;------------------------------------------------------------
                                   1952 ;Allocation info for local variables in function 'add_weak_mods'
                                   1953 ;------------------------------------------------------------
                                   1954 ;mods          Allocated with name '_add_weak_mods_mods_10000_482'
                                   1955 ;------------------------------------------------------------
                                   1956 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1957 ;	-----------------------------------------
                                   1958 ;	 function add_weak_mods
                                   1959 ;	-----------------------------------------
      00855A                       1960 _add_weak_mods:
      00855A E5 82            [12] 1961 	mov	a,dpl
      00855C 90 0B 38         [24] 1962 	mov	dptr,#_add_weak_mods_mods_10000_482
      00855F F0               [24] 1963 	movx	@dptr,a
                                   1964 ;	quantum/action_util.c:596: weak_mods |= mods;
      008560 E0               [24] 1965 	movx	a,@dptr
      008561 FF               [12] 1966 	mov	r7,a
      008562 90 0E 47         [24] 1967 	mov	dptr,#_weak_mods
      008565 E0               [24] 1968 	movx	a,@dptr
      008566 4F               [12] 1969 	orl	a,r7
      008567 F0               [24] 1970 	movx	@dptr,a
                                   1971 ;	quantum/action_util.c:597: }
      008568 22               [24] 1972 	ret
                                   1973 ;------------------------------------------------------------
                                   1974 ;Allocation info for local variables in function 'del_weak_mods'
                                   1975 ;------------------------------------------------------------
                                   1976 ;mods          Allocated with name '_del_weak_mods_mods_10000_484'
                                   1977 ;------------------------------------------------------------
                                   1978 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1979 ;	-----------------------------------------
                                   1980 ;	 function del_weak_mods
                                   1981 ;	-----------------------------------------
      008569                       1982 _del_weak_mods:
      008569 E5 82            [12] 1983 	mov	a,dpl
      00856B 90 0B 39         [24] 1984 	mov	dptr,#_del_weak_mods_mods_10000_484
      00856E F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      00856F E0               [24] 1987 	movx	a,@dptr
      008570 F4               [12] 1988 	cpl	a
      008571 FF               [12] 1989 	mov	r7,a
      008572 90 0E 47         [24] 1990 	mov	dptr,#_weak_mods
      008575 E0               [24] 1991 	movx	a,@dptr
      008576 5F               [12] 1992 	anl	a,r7
      008577 F0               [24] 1993 	movx	@dptr,a
                                   1994 ;	quantum/action_util.c:604: }
      008578 22               [24] 1995 	ret
                                   1996 ;------------------------------------------------------------
                                   1997 ;Allocation info for local variables in function 'set_weak_mods'
                                   1998 ;------------------------------------------------------------
                                   1999 ;mods          Allocated with name '_set_weak_mods_mods_10000_486'
                                   2000 ;------------------------------------------------------------
                                   2001 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   2002 ;	-----------------------------------------
                                   2003 ;	 function clear_weak_mods
                                   2004 ;	-----------------------------------------
      008579                       2005 _clear_weak_mods:
                                   2006 ;	quantum/action_util.c:617: weak_mods = 0;
      008579 90 0E 47         [24] 2007 	mov	dptr,#_weak_mods
      00857C E4               [12] 2008 	clr	a
      00857D F0               [24] 2009 	movx	@dptr,a
                                   2010 ;	quantum/action_util.c:618: }
      00857E 22               [24] 2011 	ret
                                   2012 ;------------------------------------------------------------
                                   2013 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2014 ;------------------------------------------------------------
                                   2015 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_490'
                                   2016 ;------------------------------------------------------------
                                   2017 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2018 ;	-----------------------------------------
                                   2019 	.area CSEG    (CODE)
                                   2020 	.area CONST   (CODE)
                                   2021 	.area XINIT   (CODE)
      00C76E                       2022 __xinit__real_mods:
      00C76E 00                    2023 	.db #0x00	; 0
      00C76F                       2024 __xinit__weak_mods:
      00C76F 00                    2025 	.db #0x00	; 0
      00C770                       2026 __xinit__actual_keyboard_report:
      00C770 00                    2027 	.db #0x00	; 0
      00C771 00                    2028 	.db #0x00	; 0
      00C772 00                    2029 	.db #0x00	; 0
      00C773 00                    2030 	.db #0x00	; 0
      00C774 00                    2031 	.db #0x00	; 0
      00C775 00                    2032 	.db #0x00	; 0
      00C776 00                    2033 	.db #0x00	; 0
      00C777 00                    2034 	.db #0x00	; 0
      00C778 00                    2035 	.db 0x00
      00C779 00                    2036 	.db 0x00
      00C77A 00                    2037 	.db 0x00
      00C77B 00                    2038 	.db 0x00
      00C77C 00                    2039 	.db 0x00
      00C77D 00                    2040 	.db 0x00
      00C77E 00                    2041 	.db 0x00
      00C77F 00                    2042 	.db 0x00
      00C780 00                    2043 	.db 0x00
      00C781 00                    2044 	.db 0x00
      00C782 00                    2045 	.db 0x00
      00C783 00                    2046 	.db 0x00
      00C784 00                    2047 	.db 0x00
      00C785 00                    2048 	.db 0x00
      00C786 00                    2049 	.db 0x00
      00C787 00                    2050 	.db 0x00
      00C788 00                    2051 	.db 0x00
      00C789 00                    2052 	.db 0x00
      00C78A 00                    2053 	.db 0x00
      00C78B 00                    2054 	.db 0x00
      00C78C 00                    2055 	.db 0x00
      00C78D 00                    2056 	.db 0x00
      00C78E 00                    2057 	.db 0x00
      00C78F 00                    2058 	.db 0x00
                                   2059 	.area CABS    (ABS,CODE)
                                   2060 
                                   2061 ; Experimental exact instruction outlining.
                                   2062 	.globl _ak820_outline_0018
                                   2063 	.globl _ak820_outline_0031
                                   2064 	.globl _ak820_outline_0041
                                   2065 	.globl _ak820_outline_0061
                                   2066 	.globl _ak820_outline_0065
                                   2067 	.globl _ak820_outline_0068
                                   2068 	.globl _ak820_outline_0069
                                   2069 	.globl _ak820_outline_0071
                                   2070 	.globl _ak820_outline_0073
                                   2071 	.globl _ak820_outline_0077
                                   2072 	.globl _ak820_outline_0079
                                   2073 	.globl _ak820_outline_0104
                                   2074 	.globl _ak820_outline_0108
                                   2075 	.globl _ak820_outline_0109
                                   2076 	.globl _ak820_outline_0122
                                   2077 	.globl _ak820_outline_0130
                                   2078 	.globl _ak820_outline_0131
                                   2079 	.globl _ak820_outline_0132
                                   2080 	.globl _ak820_outline_0133
                                   2081 	.globl _ak820_outline_0139
                                   2082 	.globl _ak820_outline_0141
                                   2083 	.globl _ak820_outline_0145
                                   2084 	.globl _ak820_outline_0155
                                   2085 	.globl _ak820_outline_0162
                                   2086 	.globl _ak820_outline_0164
                                   2087 	.globl _ak820_outline_0170
                                   2088 	.globl _ak820_outline_0171
                                   2089 	.globl _ak820_outline_0182
                                   2090 	.globl _ak820_outline_0190
                                   2091 
                                   2092 	.area CSEG (CODE)
                                   2093 ; function ak820_outline_0031
      00857F                       2094 _ak820_outline_0031:
      00857F EF               [12] 2095 	mov	a,r7
      008580 24 EF            [12] 2096 	add	a,#_key_refs
      008582 FD               [12] 2097 	mov	r5,a
      008583 E4               [12] 2098 	clr	a
      008584 34 09            [12] 2099 	addc	a,#(_key_refs>>8)
      008586 FE               [12] 2100 	mov	r6,a
      008587 8D 82            [24] 2101 	mov	dpl,r5
      008589 8E 83            [24] 2102 	mov	dph,r6
      00858B E0               [24] 2103 	movx	a,@dptr
      00858C 22               [24] 2104 	ret
                                   2105 
                                   2106 	.area CSEG (CODE)
                                   2107 ; function ak820_outline_0068
      00858D                       2108 _ak820_outline_0068:
      00858D 89 82            [24] 2109 	mov	dpl,r1
      00858F 8A 83            [24] 2110 	mov	dph,r2
      008591 E8               [12] 2111 	mov	a,r0
      008592 F0               [24] 2112 	movx	@dptr,a
      008593 22               [24] 2113 	ret
                                   2114 
                                   2115 	.area CSEG (CODE)
                                   2116 ; function ak820_outline_0071
      008594                       2117 _ak820_outline_0071:
      008594 24 F8            [12] 2118 	add	a,#(_send_keyboard_report_projected_10001_450+0x0002)
      008596 F5 82            [12] 2119 	mov	dpl,a
      008598 E4               [12] 2120 	clr	a
      008599 34 0A            [12] 2121 	addc	a,#((_send_keyboard_report_projected_10001_450+0x0002)>>8)
      00859B F5 83            [12] 2122 	mov	dph,a
      00859D 22               [24] 2123 	ret
                                   2124 
                                   2125 	.area CSEG (CODE)
                                   2126 ; function ak820_outline_0073
      00859E                       2127 _ak820_outline_0073:
      00859E 24 CA            [12] 2128 	add	a,#_usage_order
      0085A0 F5 82            [12] 2129 	mov	dpl,a
      0085A2 E4               [12] 2130 	clr	a
      0085A3 34 0A            [12] 2131 	addc	a,#(_usage_order>>8)
      0085A5 F5 83            [12] 2132 	mov	dph,a
      0085A7 22               [24] 2133 	ret
                                   2134 
                                   2135 	.area CSEG (CODE)
                                   2136 ; function ak820_outline_0077
      0085A8                       2137 _ak820_outline_0077:
      0085A8 EB               [12] 2138 	mov	a,r3
      0085A9 24 AC            [12] 2139 	add	a,#_usage_refs
      0085AB F9               [12] 2140 	mov	r1,a
      0085AC E4               [12] 2141 	clr	a
      0085AD 34 0A            [12] 2142 	addc	a,#(_usage_refs>>8)
      0085AF FA               [12] 2143 	mov	r2,a
      0085B0 89 82            [24] 2144 	mov	dpl,r1
      0085B2 8A 83            [24] 2145 	mov	dph,r2
      0085B4 E0               [24] 2146 	movx	a,@dptr
      0085B5 F8               [12] 2147 	mov	r0,a
      0085B6 22               [24] 2148 	ret
                                   2149 
                                   2150 	.area CSEG (CODE)
                                   2151 ; function ak820_outline_0104
      0085B7                       2152 _ak820_outline_0104:
      0085B7 8D 82            [24] 2153 	mov	dpl,r5
      0085B9 8E 83            [24] 2154 	mov	dph,r6
      0085BB F0               [24] 2155 	movx	@dptr,a
      0085BC 22               [24] 2156 	ret
                                   2157 
                                   2158 	.area CSEG (CODE)
                                   2159 ; function ak820_outline_0122
      0085BD                       2160 _ak820_outline_0122:
      0085BD F0               [24] 2161 	movx	@dptr,a
      0085BE E0               [24] 2162 	movx	a,@dptr
      0085BF FF               [12] 2163 	mov	r7,a
      0085C0 90 09 E7         [24] 2164 	mov	dptr,#_change_owned_PARM_2
      0085C3 22               [24] 2165 	ret
                                   2166 
                                   2167 	.area CSEG (CODE)
                                   2168 ; function ak820_outline_0133
      0085C4                       2169 _ak820_outline_0133:
      0085C4 24 CA            [12] 2170 	add	a,#_usage_order
      0085C6 F5 82            [12] 2171 	mov	dpl,a
      0085C8 EF               [12] 2172 	mov	a,r7
      0085C9 34 0A            [12] 2173 	addc	a,#(_usage_order>>8)
      0085CB F5 83            [12] 2174 	mov	dph,a
      0085CD E0               [24] 2175 	movx	a,@dptr
      0085CE 22               [24] 2176 	ret
                                   2177 
                                   2178 	.area CSEG (CODE)
                                   2179 ; function ak820_outline_0139
      0085CF                       2180 _ak820_outline_0139:
      0085CF F0               [24] 2181 	movx	@dptr,a
      0085D0 E0               [24] 2182 	movx	a,@dptr
      0085D1 FF               [12] 2183 	mov	r7,a
      0085D2 90 09 E3         [24] 2184 	mov	dptr,#_ak820_macro_change_PARM_2
      0085D5 F0               [24] 2185 	movx	@dptr,a
      0085D6 90 09 E4         [24] 2186 	mov	dptr,#_ak820_macro_change_PARM_3
      0085D9 22               [24] 2187 	ret
                                   2188 
                                   2189 	.area CSEG (CODE)
                                   2190 ; function ak820_outline_0170
      0085DA                       2191 _ak820_outline_0170:
      0085DA EF               [12] 2192 	mov	a,r7
      0085DB C4               [12] 2193 	swap	a
      0085DC 23               [12] 2194 	rl	a
      0085DD 54 1F            [12] 2195 	anl	a,#0x1f
      0085DF 22               [24] 2196 	ret
                                   2197 
                                   2198 	.area CSEG (CODE)
                                   2199 ; function ak820_outline_0182
      0085E0                       2200 _ak820_outline_0182:
      0085E0 90 08 60         [24] 2201 	mov	dptr,#_add_key_to_report_PARM_2
      0085E3 EF               [12] 2202 	mov	a,r7
      0085E4 F0               [24] 2203 	movx	@dptr,a
      0085E5 90 0E 48         [24] 2204 	mov	dptr,#_actual_keyboard_report
      0085E8 22               [24] 2205 	ret
