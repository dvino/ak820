                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000017                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000017                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000012                        595 _suspended:
      000012                        596 	.ds 1
      000013                        597 _dirty:
      000013                        598 	.ds 1
      000014                        599 _rendering:
      000014                        600 	.ds 1
      000015                        601 _rgb_matrix_task_sloc0_1_0:
      000015                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      00070C                        611 _rgb_matrix_config::
      00070C                        612 	.ds 8
      000714                        613 _changed_at:
      000714                        614 	.ds 2
      000716                        615 _frame_at:
      000716                        616 	.ds 2
      000718                        617 _phase:
      000718                        618 	.ds 2
      00071A                        619 _led_index:
      00071A                        620 	.ds 1
      00071B                        621 _frame_mode:
      00071B                        622 	.ds 1
      00071C                        623 _frame_hue:
      00071C                        624 	.ds 1
      00071D                        625 _frame_sat:
      00071D                        626 	.ds 1
      00071E                        627 _frame_val:
      00071E                        628 	.ds 1
      00071F                        629 _frame_flags:
      00071F                        630 	.ds 1
      000720                        631 _frame_phase:
      000720                        632 	.ds 1
      000721                        633 _reactive_age:
      000721                        634 	.ds 82
      000773                        635 _reactive_at:
      000773                        636 	.ds 2
      000775                        637 _add_sat_PARM_2:
      000775                        638 	.ds 1
      000776                        639 _add_sat_x_10000_266:
      000776                        640 	.ds 1
      000777                        641 _sub_sat_PARM_2:
      000777                        642 	.ds 1
      000778                        643 _sub_sat_x_10000_268:
      000778                        644 	.ds 1
      000779                        645 _rgb_matrix_set_color_PARM_2:
      000779                        646 	.ds 1
      00077A                        647 _rgb_matrix_set_color_PARM_3:
      00077A                        648 	.ds 1
      00077B                        649 _rgb_matrix_set_color_PARM_4:
      00077B                        650 	.ds 1
      00077C                        651 _rgb_matrix_set_color_index_10000_284:
      00077C                        652 	.ds 2
      00077E                        653 _rgb_matrix_set_color_all_PARM_2:
      00077E                        654 	.ds 1
      00077F                        655 _rgb_matrix_set_color_all_PARM_3:
      00077F                        656 	.ds 1
      000780                        657 _rgb_matrix_set_color_all_r_10000_287:
      000780                        658 	.ds 1
      000781                        659 _sine8_theta_10000_289:
      000781                        660 	.ds 1
      000782                        661 _sine8_offset_10000_290:
      000782                        662 	.ds 1
      000783                        663 _sine8_fraction_10000_290:
      000783                        664 	.ds 1
      000784                        665 _breathing_cie_value_10000_293:
      000784                        666 	.ds 1
      000785                        667 _rgb_matrix_task_end_10000_298:
      000785                        668 	.ds 1
      000786                        669 _rgb_matrix_task_hsv_10000_298:
      000786                        670 	.ds 3
      000789                        671 _rgb_matrix_task_rgb_10000_298:
      000789                        672 	.ds 3
      00078C                        673 _process_rgb_matrix_PARM_2:
      00078C                        674 	.ds 1
      00078D                        675 _process_rgb_matrix_PARM_3:
      00078D                        676 	.ds 1
      00078E                        677 _process_rgb_matrix_row_10000_319:
      00078E                        678 	.ds 1
      00078F                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      00078F                        680 	.ds 1
      000790                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000790                        682 	.ds 1
      000791                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000791                        684 	.ds 1
      000792                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000792                        686 	.ds 1
      000793                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000793                        688 	.ds 2
      000795                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      000795                        690 	.ds 1
      000796                        691 _rgb_matrix_mode_mode_10000_411:
      000796                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      005401                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      005401 12 5B EC         [24]  746 	lcall	_ak820_outline_0186
      005404 74 52            [12]  747 	mov	a,#0x52
      005406 12 38 60         [24]  748 	lcall	_ak820_outline_0132
      005409 90 07 21         [24]  749 	mov	dptr,#_reactive_age
      00540C F5 F0            [12]  750 	mov	b,a
      00540E 12 BF 0E         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      005411 12 4D F5         [24]  753 	lcall	_timer_read
      005414 12 38 5A         [24]  754 	lcall	_ak820_outline_0127
      005417 90 07 73         [24]  755 	mov	dptr,#_reactive_at
      00541A 12 5B D8         [24]  756 	lcall	_ak820_outline_0177
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      00541D 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      00541E                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      00541E 90 07 73         [24]  772 	mov	dptr,#_reactive_at
      005421 12 37 C3         [24]  773 	lcall	_ak820_outline_0006
      005424 12 4D F8         [24]  774 	lcall	_timer_elapsed
      005427 AE 82            [24]  775 	mov	r6, dpl
      005429 E5 83            [12]  776 	mov	a,dph
      00542B C4               [12]  777 	swap	a
      00542C CE               [12]  778 	xch	a,r6
      00542D C4               [12]  779 	swap	a
      00542E 54 0F            [12]  780 	anl	a,#0x0f
      005430 6E               [12]  781 	xrl	a,r6
      005431 CE               [12]  782 	xch	a,r6
      005432 54 0F            [12]  783 	anl	a,#0x0f
      005434 CE               [12]  784 	xch	a,r6
      005435 6E               [12]  785 	xrl	a,r6
      005436 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005437 FF               [12]  788 	mov	r7,a
      005438 4E               [12]  789 	orl	a,r6
      005439 70 01            [24]  790 	jnz	00102$
      00543B 22               [24]  791 	ret
      00543C                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      00543C 8E 04            [24]  794 	mov	ar4,r6
      00543E EF               [12]  795 	mov	a,r7
      00543F C4               [12]  796 	swap	a
      005440 54 F0            [12]  797 	anl	a,#0xf0
      005442 CC               [12]  798 	xch	a,r4
      005443 C4               [12]  799 	swap	a
      005444 CC               [12]  800 	xch	a,r4
      005445 6C               [12]  801 	xrl	a,r4
      005446 CC               [12]  802 	xch	a,r4
      005447 54 F0            [12]  803 	anl	a,#0xf0
      005449 CC               [12]  804 	xch	a,r4
      00544A 6C               [12]  805 	xrl	a,r4
      00544B FD               [12]  806 	mov	r5,a
      00544C 90 07 73         [24]  807 	mov	dptr,#_reactive_at
      00544F 12 48 46         [24]  808 	lcall	_ak820_outline_0129
      005452 90 07 73         [24]  809 	mov	dptr,#_reactive_at
      005455 EC               [12]  810 	mov	a,r4
      005456 2A               [12]  811 	add	a, r2
      005457 F0               [24]  812 	movx	@dptr,a
      005458 ED               [12]  813 	mov	a,r5
      005459 3B               [12]  814 	addc	a, r3
      00545A A3               [24]  815 	inc	dptr
      00545B F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      00545C 8E 04            [24]  818 	mov	ar4,r6
      00545E 8F 05            [24]  819 	mov	ar5,r7
      005460 C3               [12]  820 	clr	c
      005461 74 FF            [12]  821 	mov	a,#0xff
      005463 9C               [12]  822 	subb	a,r4
      005464 E4               [12]  823 	clr	a
      005465 9D               [12]  824 	subb	a,r5
      005466 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      005468 7D FF            [12]  827 	mov	r5,#0xff
      00546A 80 02            [24]  828 	sjmp	00109$
      00546C                        829 00108$:
      00546C 8E 05            [24]  830 	mov	ar5,r6
      00546E                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00546E 7F 00            [12]  833 	mov	r7,#0x00
      005470                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      005470 EF               [12]  836 	mov	a,r7
      005471 24 21            [12]  837 	add	a, #_reactive_age
      005473 FC               [12]  838 	mov	r4,a
      005474 E4               [12]  839 	clr	a
      005475 34 07            [12]  840 	addc	a, #(_reactive_age >> 8)
      005477 FE               [12]  841 	mov	r6,a
      005478 8C 82            [24]  842 	mov	dpl,r4
      00547A 8E 83            [24]  843 	mov	dph,r6
      00547C E0               [24]  844 	movx	a,@dptr
      00547D FB               [12]  845 	mov	r3,a
      00547E C3               [12]  846 	clr	c
      00547F ED               [12]  847 	mov	a,r5
      005480 9B               [12]  848 	subb	a,r3
      005481 40 04            [24]  849 	jc	00110$
      005483 7B 00            [12]  850 	mov	r3,#0x00
      005485 80 08            [24]  851 	sjmp	00111$
      005487                        852 00110$:
      005487 8C 82            [24]  853 	mov	dpl,r4
      005489 8E 83            [24]  854 	mov	dph,r6
      00548B E0               [24]  855 	movx	a,@dptr
      00548C C3               [12]  856 	clr	c
      00548D 9D               [12]  857 	subb	a,r5
      00548E FB               [12]  858 	mov	r3,a
      00548F                        859 00111$:
      00548F 8C 82            [24]  860 	mov	dpl,r4
      005491 8E 83            [24]  861 	mov	dph,r6
      005493 EB               [12]  862 	mov	a,r3
      005494 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005495 0F               [12]  865 	inc	r7
      005496 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      005499                        867 00144$:
      005499 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      00549B 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      00549C                        881 _add_sat:
      00549C E5 82            [12]  882 	mov	a,dpl
      00549E 90 07 76         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      0054A1 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      0054A2 90 07 75         [24]  886 	mov	dptr,#_add_sat_PARM_2
      0054A5 E0               [24]  887 	movx	a,@dptr
      0054A6 FF               [12]  888 	mov	r7,a
      0054A7 FE               [12]  889 	mov	r6,a
      0054A8 74 FF            [12]  890 	mov	a,#0xff
      0054AA C3               [12]  891 	clr	c
      0054AB 9E               [12]  892 	subb	a,r6
      0054AC FE               [12]  893 	mov	r6,a
      0054AD 90 07 76         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      0054B0 E0               [24]  895 	movx	a,@dptr
      0054B1 FD               [12]  896 	mov	r5,a
      0054B2 C3               [12]  897 	clr	c
      0054B3 EE               [12]  898 	mov	a,r6
      0054B4 9D               [12]  899 	subb	a,r5
      0054B5 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      0054B7 7E FF            [12]  902 	mov	r6,#0xff
      0054B9 80 03            [24]  903 	sjmp	00104$
      0054BB                        904 00103$:
      0054BB EF               [12]  905 	mov	a,r7
      0054BC 2D               [12]  906 	add	a, r5
      0054BD FE               [12]  907 	mov	r6,a
      0054BE                        908 00104$:
      0054BE 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      0054C0 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      0054C1                        922 _sub_sat:
      0054C1 E5 82            [12]  923 	mov	a,dpl
      0054C3 90 07 78         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      0054C6 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      0054C7 E0               [24]  927 	movx	a,@dptr
      0054C8 FF               [12]  928 	mov	r7,a
      0054C9 90 07 77         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      0054CC E0               [24]  930 	movx	a,@dptr
      0054CD FE               [12]  931 	mov	r6,a
      0054CE C3               [12]  932 	clr	c
      0054CF EF               [12]  933 	mov	a,r7
      0054D0 9E               [12]  934 	subb	a,r6
      0054D1 50 04            [24]  935 	jnc	00103$
      0054D3 7D 00            [12]  936 	mov	r5,#0x00
      0054D5 80 04            [24]  937 	sjmp	00104$
      0054D7                        938 00103$:
      0054D7 EF               [12]  939 	mov	a,r7
      0054D8 C3               [12]  940 	clr	c
      0054D9 9E               [12]  941 	subb	a,r6
      0054DA FD               [12]  942 	mov	r5,a
      0054DB                        943 00104$:
      0054DB 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      0054DD 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      0054DE                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      0054DE D2 13            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      0054E0 12 4D F5         [24]  959 	lcall	_timer_read
      0054E3 12 38 5A         [24]  960 	lcall	_ak820_outline_0127
      0054E6 90 07 14         [24]  961 	mov	dptr,#_changed_at
      0054E9 12 5B D8         [24]  962 	lcall	_ak820_outline_0177
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      0054EC 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      0054ED                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      0054ED 90 07 13         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      0054F0 E4               [12]  978 	clr	a
      0054F1 F0               [24]  979 	movx	@dptr,a
      0054F2 90 07 12         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      0054F5 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0054F6 90 05 F6         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0054F9 12 5B BB         [24]  984 	lcall	_ak820_outline_0087
      0054FC 90 05 F9         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0054FF 12 5B B1         [24]  986 	lcall	_ak820_outline_0075
      005502 12 47 09         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      005505 C2 13            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005507 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005508                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005508 12 5B EC         [24] 1002 	lcall	_ak820_outline_0186
      00550B 12 5B B1         [24] 1003 	lcall	_ak820_outline_0075
      00550E F5 F0            [12] 1004 	mov	b,a
      005510 12 BF 0E         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      005513 12 5B CB         [24] 1007 	lcall	_ak820_outline_0120
      005516 44 01            [12] 1008 	orl	a,#0x01
      005518 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005519 12 5B AA         [24] 1011 	lcall	_ak820_outline_0070
      00551C 44 04            [12] 1012 	orl	a,#0x04
      00551E F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      00551F 90 07 0D         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005522 E4               [12] 1016 	clr	a
      005523 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      005524 90 07 0E         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005527 14               [12] 1020 	dec	a
      005528 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005529 90 07 0F         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00552C 74 50            [12] 1024 	mov	a,#0x50
      00552E F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      00552F 90 07 10         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005532 74 60            [12] 1028 	mov	a,#0x60
      005534 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      005535 90 07 11         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005538 74 FF            [12] 1032 	mov	a,#0xff
      00553A F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      00553B 02 54 ED         [24] 1036 	ljmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      00553E                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00553E 90 05 E6         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005541 12 5B BB         [24] 1047 	lcall	_ak820_outline_0087
      005544 90 05 E9         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005547 12 5B B1         [24] 1049 	lcall	_ak820_outline_0075
      00554A 12 45 9A         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      00554D 12 5B CB         [24] 1052 	lcall	_ak820_outline_0120
      005550 60 11            [24] 1053 	jz	00101$
      005552 12 5B 8B         [24] 1054 	lcall	_ak820_outline_0020
      005555 C3               [12] 1055 	clr	c
      005556 64 80            [12] 1056 	xrl	a,#0x80
      005558 94 87            [12] 1057 	subb	a,#0x87
      00555A 50 07            [24] 1058 	jnc	00101$
      00555C 12 5B AA         [24] 1059 	lcall	_ak820_outline_0070
      00555F 24 FE            [12] 1060 	add	a,#0xff - 0x01
      005561 50 03            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      005563                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      005563 12 55 08         [24] 1065 	lcall	_eeconfig_update_rgb_matrix_default
      005566                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005566 90 07 0F         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005569 E0               [24] 1069 	movx	a,@dptr
      00556A 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      00556C 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00556E 90 07 0F         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005571 74 A0            [12] 1075 	mov	a,#0xa0
      005573 F0               [24] 1076 	movx	@dptr,a
      005574                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      005574 C2 13            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      005576 C2 14            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005578 02 54 01         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      00557B                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      00557B 12 55 3E         [24] 1096 	lcall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      00557E 12 4D F5         [24] 1098 	lcall	_timer_read
      005581 12 48 4C         [24] 1099 	lcall	_ak820_outline_0140
      005584 EE               [12] 1100 	mov	a,r6
      005585 24 F0            [12] 1101 	add	a,#0xf0
      005587 FE               [12] 1102 	mov	r6,a
      005588 EF               [12] 1103 	mov	a,r7
      005589 34 FF            [12] 1104 	addc	a,#0xff
      00558B FF               [12] 1105 	mov	r7,a
      00558C 90 07 16         [24] 1106 	mov	dptr,#_frame_at
      00558F 12 4D 65         [24] 1107 	lcall	_ak820_outline_0064
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      005592 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      005593                       1122 _rgb_matrix_set_color:
      005593 12 38 4B         [24] 1123 	lcall	_ak820_outline_0108
      005596 90 07 7C         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005599 12 38 50         [24] 1125 	lcall	_ak820_outline_0109
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      00559C 90 07 7C         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      00559F 12 38 02         [24] 1128 	lcall	_ak820_outline_0056
      0055A2 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      0055A5 C3               [12] 1130 	clr	c
      0055A6 EE               [12] 1131 	mov	a,r6
      0055A7 94 52            [12] 1132 	subb	a,#0x52
      0055A9 EF               [12] 1133 	mov	a,r7
      0055AA 64 80            [12] 1134 	xrl	a,#0x80
      0055AC 94 80            [12] 1135 	subb	a,#0x80
      0055AE 50 23            [24] 1136 	jnc	00104$
      0055B0 90 07 79         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0055B3 E0               [24] 1138 	movx	a,@dptr
      0055B4 FF               [12] 1139 	mov	r7,a
      0055B5 90 07 7A         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0055B8 E0               [24] 1141 	movx	a,@dptr
      0055B9 FD               [12] 1142 	mov	r5,a
      0055BA 90 07 7B         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0055BD E0               [24] 1144 	movx	a,@dptr
      0055BE FC               [12] 1145 	mov	r4,a
      0055BF 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      0055C2 EF               [12] 1147 	mov	a,r7
      0055C3 F0               [24] 1148 	movx	@dptr,a
      0055C4 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      0055C7 ED               [12] 1150 	mov	a,r5
      0055C8 F0               [24] 1151 	movx	@dptr,a
      0055C9 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0055CC EC               [12] 1153 	mov	a,r4
      0055CD F0               [24] 1154 	movx	@dptr,a
      0055CE 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0055D0 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      0055D3                       1158 00104$:
      0055D3 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0055D4                       1171 _rgb_matrix_set_color_all:
      0055D4 E5 82            [12] 1172 	mov	a,dpl
      0055D6 90 07 80         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      0055D9 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      0055DA E0               [24] 1176 	movx	a,@dptr
      0055DB FF               [12] 1177 	mov	r7,a
      0055DC 90 07 7E         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0055DF E0               [24] 1179 	movx	a,@dptr
      0055E0 FE               [12] 1180 	mov	r6,a
      0055E1 90 07 7F         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0055E4 E0               [24] 1182 	movx	a,@dptr
      0055E5 FD               [12] 1183 	mov	r5,a
      0055E6 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      0055E9 EE               [12] 1185 	mov	a,r6
      0055EA F0               [24] 1186 	movx	@dptr,a
      0055EB 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      0055EE ED               [12] 1188 	mov	a,r5
      0055EF F0               [24] 1189 	movx	@dptr,a
      0055F0 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      0055F2 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      0055F5                       1206 _sine8:
      0055F5 E5 82            [12] 1207 	mov	a,dpl
      0055F7 90 07 81         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      0055FA F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      0055FB E0               [24] 1211 	movx	a,@dptr
      0055FC FF               [12] 1212 	mov	r7,a
      0055FD 90 07 82         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      005600 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005601 EF               [12] 1216 	mov	a,r7
      005602 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      005605 90 07 82         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      005608 74 FF            [12] 1219 	mov	a,#0xff
      00560A C3               [12] 1220 	clr	c
      00560B 9F               [12] 1221 	subb	a,r7
      00560C F0               [24] 1222 	movx	@dptr,a
      00560D                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      00560D 90 07 82         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      005610 E0               [24] 1226 	movx	a,@dptr
      005611 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      005614 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      005615 90 07 82         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      005618 E0               [24] 1231 	movx	a,@dptr
      005619 54 0F            [12] 1232 	anl	a,#0x0f
      00561B FF               [12] 1233 	mov	r7,a
      00561C 90 07 83         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      00561F F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005620 90 07 81         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      005623 E0               [24] 1238 	movx	a,@dptr
      005624 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      005627 90 07 83         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      00562A EF               [12] 1241 	mov	a,r7
      00562B 04               [12] 1242 	inc	a
      00562C F0               [24] 1243 	movx	@dptr,a
      00562D                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      00562D 90 07 82         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      005630 E0               [24] 1247 	movx	a,@dptr
      005631 C4               [12] 1248 	swap	a
      005632 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      005634 25 E0            [12] 1251 	add	a,acc
      005636 FF               [12] 1252 	mov	r7,a
      005637 90 BF F3         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      00563A 93               [24] 1254 	movc	a,@a+dptr
      00563B FE               [12] 1255 	mov	r6,a
      00563C 0F               [12] 1256 	inc	r7
      00563D EF               [12] 1257 	mov	a,r7
      00563E 90 BF F3         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      005641 93               [24] 1259 	movc	a,@a+dptr
      005642 FF               [12] 1260 	mov	r7,a
      005643 90 07 83         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      005646 E0               [24] 1262 	movx	a,@dptr
      005647 8F F0            [24] 1263 	mov	b,r7
      005649 A4               [48] 1264 	mul	ab
      00564A FF               [12] 1265 	mov	r7,a
      00564B E5 F0            [12] 1266 	mov	a,b
      00564D C4               [12] 1267 	swap	a
      00564E CF               [12] 1268 	xch	a,r7
      00564F C4               [12] 1269 	swap	a
      005650 54 0F            [12] 1270 	anl	a,#0x0f
      005652 6F               [12] 1271 	xrl	a,r7
      005653 CF               [12] 1272 	xch	a,r7
      005654 54 0F            [12] 1273 	anl	a,#0x0f
      005656 CF               [12] 1274 	xch	a,r7
      005657 6F               [12] 1275 	xrl	a,r7
      005658 CF               [12] 1276 	xch	a,r7
      005659 EF               [12] 1277 	mov	a,r7
      00565A 2E               [12] 1278 	add	a, r6
      00565B FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      00565C 90 07 81         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      00565F E0               [24] 1282 	movx	a,@dptr
      005660 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      005663 8F 06            [24] 1284 	mov	ar6,r7
      005665 74 80            [12] 1285 	mov	a,#0x80
      005667 C3               [12] 1286 	clr	c
      005668 9E               [12] 1287 	subb	a,r6
      005669 FE               [12] 1288 	mov	r6,a
      00566A 80 04            [24] 1289 	sjmp	00108$
      00566C                       1290 00107$:
      00566C 74 80            [12] 1291 	mov	a,#0x80
      00566E 2F               [12] 1292 	add	a, r7
      00566F FE               [12] 1293 	mov	r6,a
      005670                       1294 00108$:
      005670 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005672 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      005673                       1312 _breathing_cie:
      005673 E5 82            [12] 1313 	mov	a,dpl
      005675 90 07 84         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      005678 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      005679 E0               [24] 1317 	movx	a,@dptr
      00567A FF               [12] 1318 	mov	r7,a
      00567B C4               [12] 1319 	swap	a
      00567C 23               [12] 1320 	rl	a
      00567D 54 1F            [12] 1321 	anl	a,#0x1f
                                   1322 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      00567F FE               [12] 1323 	mov	r6,a
      005680 90 C2 FF         [24] 1324 	mov	dptr,#_CIE1931_CURVE
      005683 93               [24] 1325 	movc	a,@a+dptr
      005684 FD               [12] 1326 	mov	r5,a
                                   1327 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      005685 BE 1F 03         [24] 1328 	cjne	r6,#0x1f,00102$
      005688 8D 82            [24] 1329 	mov	dpl, r5
      00568A 22               [24] 1330 	ret
      00568B                       1331 00102$:
                                   1332 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      00568B EE               [12] 1333 	mov	a,r6
      00568C 04               [12] 1334 	inc	a
      00568D 90 C2 FF         [24] 1335 	mov	dptr,#_CIE1931_CURVE
      005690 93               [24] 1336 	movc	a,@a+dptr
      005691 C3               [12] 1337 	clr	c
      005692 9D               [12] 1338 	subb	a,r5
      005693 FE               [12] 1339 	mov	r6,a
                                   1340 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      005694 74 07            [12] 1341 	mov	a,#0x07
      005696 5F               [12] 1342 	anl	a,r7
                                   1343 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      005697 F5 F0            [12] 1344 	mov	b,a
      005699 EE               [12] 1345 	mov	a,r6
      00569A A4               [48] 1346 	mul	ab
                                   1347 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      00569B C4               [12] 1348 	swap	a
      00569C 23               [12] 1349 	rl	a
      00569D 54 1F            [12] 1350 	anl	a,#0x1f
      00569F 2D               [12] 1351 	add	a, r5
                                   1352 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      0056A0 F5 82            [12] 1353 	mov	dpl,a
      0056A2 22               [24] 1354 	ret
                                   1355 ;------------------------------------------------------------
                                   1356 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1357 ;------------------------------------------------------------
                                   1358 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1359 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1360 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1361 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1362 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1363 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1364 ;------------------------------------------------------------
                                   1365 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1366 ;	-----------------------------------------
                                   1367 ;	 function rgb_matrix_task
                                   1368 ;	-----------------------------------------
      0056A3                       1369 _rgb_matrix_task:
                                   1370 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      0056A3 12 54 1E         [24] 1371 	lcall	_age_reactive
                                   1372 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      0056A6 30 13 18         [24] 1373 	jnb	_dirty,00102$
      0056A9 90 07 14         [24] 1374 	mov	dptr,#_changed_at
      0056AC 12 37 C3         [24] 1375 	lcall	_ak820_outline_0006
      0056AF 12 4D F8         [24] 1376 	lcall	_timer_elapsed
      0056B2 12 48 4C         [24] 1377 	lcall	_ak820_outline_0140
      0056B5 C3               [12] 1378 	clr	c
      0056B6 EE               [12] 1379 	mov	a,r6
      0056B7 94 E8            [12] 1380 	subb	a,#0xe8
      0056B9 EF               [12] 1381 	mov	a,r7
      0056BA 94 03            [12] 1382 	subb	a,#0x03
      0056BC 40 03            [24] 1383 	jc	00102$
      0056BE 12 54 ED         [24] 1384 	lcall	_eeconfig_update_rgb_matrix
      0056C1                       1385 00102$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0056C1 30 14 03         [24] 1387 	jnb	_rendering,00254$
      0056C4 02 57 7C         [24] 1388 	ljmp	00109$
      0056C7                       1389 00254$:
                                   1390 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0056C7 90 07 16         [24] 1391 	mov	dptr,#_frame_at
      0056CA 12 37 C3         [24] 1392 	lcall	_ak820_outline_0006
      0056CD 12 4D F8         [24] 1393 	lcall	_timer_elapsed
      0056D0 12 48 4C         [24] 1394 	lcall	_ak820_outline_0140
      0056D3 C3               [12] 1395 	clr	c
      0056D4 EE               [12] 1396 	mov	a,r6
      0056D5 94 10            [12] 1397 	subb	a,#0x10
      0056D7 EF               [12] 1398 	mov	a,r7
      0056D8 94 00            [12] 1399 	subb	a,#0x00
      0056DA 50 01            [24] 1400 	jnc	00105$
      0056DC 22               [24] 1401 	ret
      0056DD                       1402 00105$:
                                   1403 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0056DD 12 4D F5         [24] 1404 	lcall	_timer_read
      0056E0 12 38 5A         [24] 1405 	lcall	_ak820_outline_0127
      0056E3 90 07 16         [24] 1406 	mov	dptr,#_frame_at
      0056E6 12 5B D8         [24] 1407 	lcall	_ak820_outline_0177
                                   1408 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      0056E9 90 07 10         [24] 1409 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0056EC E0               [24] 1410 	movx	a,@dptr
      0056ED FF               [12] 1411 	mov	r7,a
      0056EE 7E 00            [12] 1412 	mov	r6,#0x00
      0056F0 74 20            [12] 1413 	mov	a,#0x20
      0056F2 2F               [12] 1414 	add	a, r7
      0056F3 FF               [12] 1415 	mov	r7,a
      0056F4 E4               [12] 1416 	clr	a
      0056F5 3E               [12] 1417 	addc	a, r6
      0056F6 FE               [12] 1418 	mov	r6,a
      0056F7 90 07 18         [24] 1419 	mov	dptr,#_phase
      0056FA 12 38 21         [24] 1420 	lcall	_ak820_outline_0065
      0056FD EF               [12] 1421 	mov	a,r7
      0056FE 2C               [12] 1422 	add	a, r4
      0056FF FF               [12] 1423 	mov	r7,a
      005700 EE               [12] 1424 	mov	a,r6
      005701 3D               [12] 1425 	addc	a, r5
      005702 FE               [12] 1426 	mov	r6,a
      005703 90 07 18         [24] 1427 	mov	dptr,#_phase
      005706 EF               [12] 1428 	mov	a,r7
      005707 F0               [24] 1429 	movx	@dptr,a
      005708 EE               [12] 1430 	mov	a,r6
      005709 A3               [24] 1431 	inc	dptr
      00570A F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      00570B 90 07 18         [24] 1434 	mov	dptr,#_phase
      00570E E0               [24] 1435 	movx	a,@dptr
      00570F A3               [24] 1436 	inc	dptr
      005710 E0               [24] 1437 	movx	a,@dptr
      005711 FF               [12] 1438 	mov	r7,a
      005712 90 07 20         [24] 1439 	mov	dptr,#_frame_phase
      005715 F0               [24] 1440 	movx	@dptr,a
                                   1441 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005716 20 12 05         [24] 1442 	jb	_suspended,00135$
      005719 12 5B AA         [24] 1443 	lcall	_ak820_outline_0070
      00571C 70 04            [24] 1444 	jnz	00132$
      00571E                       1445 00135$:
      00571E 7E 00            [12] 1446 	mov	r6,#0x00
      005720 80 04            [24] 1447 	sjmp	00133$
      005722                       1448 00132$:
      005722 12 5B 8B         [24] 1449 	lcall	_ak820_outline_0020
      005725 FE               [12] 1450 	mov	r6,a
      005726                       1451 00133$:
      005726 90 07 1B         [24] 1452 	mov	dptr,#_frame_mode
      005729 EE               [12] 1453 	mov	a,r6
      00572A F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      00572B 90 07 0D         [24] 1456 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00572E E0               [24] 1457 	movx	a,@dptr
      00572F 90 07 1C         [24] 1458 	mov	dptr,#_frame_hue
      005732 F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005733 90 07 0E         [24] 1461 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005736 E0               [24] 1462 	movx	a,@dptr
      005737 90 07 1D         [24] 1463 	mov	dptr,#_frame_sat
      00573A F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      00573B 90 07 0F         [24] 1466 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00573E E0               [24] 1467 	movx	a,@dptr
      00573F FD               [12] 1468 	mov	r5,a
      005740 90 07 1E         [24] 1469 	mov	dptr,#_frame_val
      005743 F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005744 90 07 11         [24] 1472 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005747 E0               [24] 1473 	movx	a,@dptr
      005748 90 07 1F         [24] 1474 	mov	dptr,#_frame_flags
      00574B F0               [24] 1475 	movx	@dptr,a
                                   1476 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      00574C BE 02 26         [24] 1477 	cjne	r6,#0x02,00107$
                                   1478 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      00574F EF               [12] 1479 	mov	a,r7
      005750 24 C0            [12] 1480 	add	a,#0xc0
      005752 F5 82            [12] 1481 	mov	dpl,a
      005754 C0 05            [24] 1482 	push	ar5
      005756 12 55 F5         [24] 1483 	lcall	_sine8
      005759 AF 82            [24] 1484 	mov	r7, dpl
      00575B D0 05            [24] 1485 	pop	ar5
      00575D 8D F0            [24] 1486 	mov	b,r5
      00575F EF               [12] 1487 	mov	a,r7
      005760 A4               [48] 1488 	mul	ab
      005761 AE F0            [24] 1489 	mov	r6,b
      005763 8E 05            [24] 1490 	mov	ar5,r6
      005765 90 07 1E         [24] 1491 	mov	dptr,#_frame_val
      005768 ED               [12] 1492 	mov	a,r5
      005769 F0               [24] 1493 	movx	@dptr,a
                                   1494 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      00576A 8D 82            [24] 1495 	mov	dpl, r5
      00576C 12 56 73         [24] 1496 	lcall	_breathing_cie
      00576F E5 82            [12] 1497 	mov	a, dpl
      005771 90 07 1E         [24] 1498 	mov	dptr,#_frame_val
      005774 F0               [24] 1499 	movx	@dptr,a
      005775                       1500 00107$:
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005775 90 07 1A         [24] 1502 	mov	dptr,#_led_index
      005778 E4               [12] 1503 	clr	a
      005779 F0               [24] 1504 	movx	@dptr,a
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1506 ;	assignBit
      00577A D2 14            [12] 1507 	setb	_rendering
      00577C                       1508 00109$:
                                   1509 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      00577C 12 5B F5         [24] 1510 	lcall	_ak820_outline_0192
      00577F 24 08            [12] 1511 	add	a,#0x08
      005781 FF               [12] 1512 	mov	r7,a
      005782 90 07 85         [24] 1513 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005785 F0               [24] 1514 	movx	@dptr,a
                                   1515 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005786 EF               [12] 1516 	mov	a,r7
      005787 24 AD            [12] 1517 	add	a,#0xff - 0x52
      005789 50 06            [24] 1518 	jnc	00125$
                                   1519 ;	free result
      00578B 90 07 85         [24] 1520 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00578E 74 52            [12] 1521 	mov	a,#0x52
      005790 F0               [24] 1522 	movx	@dptr,a
                                   1523 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      005791                       1524 00125$:
      005791 12 5B F5         [24] 1525 	lcall	_ak820_outline_0192
      005794 FF               [12] 1526 	mov	r7,a
      005795 90 07 85         [24] 1527 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005798 E0               [24] 1528 	movx	a,@dptr
      005799 FE               [12] 1529 	mov	r6,a
      00579A C3               [12] 1530 	clr	c
      00579B EF               [12] 1531 	mov	a,r7
      00579C 9E               [12] 1532 	subb	a,r6
      00579D 40 03            [24] 1533 	jc	00261$
      00579F 02 59 13         [24] 1534 	ljmp	00127$
      0057A2                       1535 00261$:
                                   1536 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0057A2 12 5B D2         [24] 1537 	lcall	_ak820_outline_0146
      0057A5 E0               [24] 1538 	movx	a,@dptr
      0057A6 60 07            [24] 1539 	jz	00121$
      0057A8 90 07 1F         [24] 1540 	mov	dptr,#_frame_flags
      0057AB E0               [24] 1541 	movx	a,@dptr
      0057AC 20 E2 1C         [24] 1542 	jb	acc.2,00122$
      0057AF                       1543 00121$:
                                   1544 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0057AF 12 5B F5         [24] 1545 	lcall	_ak820_outline_0192
      0057B2 FC               [12] 1546 	mov	r4,a
      0057B3 7D 00            [12] 1547 	mov	r5,#0x00
      0057B5 90 07 79         [24] 1548 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0057B8 E4               [12] 1549 	clr	a
      0057B9 F0               [24] 1550 	movx	@dptr,a
      0057BA 90 07 7A         [24] 1551 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0057BD F0               [24] 1552 	movx	@dptr,a
      0057BE 90 07 7B         [24] 1553 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0057C1 F0               [24] 1554 	movx	@dptr,a
      0057C2 12 38 55         [24] 1555 	lcall	_ak820_outline_0126
      0057C5 12 55 93         [24] 1556 	lcall	_rgb_matrix_set_color
      0057C8 02 59 0A         [24] 1557 	ljmp	00123$
      0057CB                       1558 00122$:
                                   1559 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0057CB BE 05 29         [24] 1560 	cjne	r6,#0x05,00119$
                                   1561 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      0057CE EF               [12] 1562 	mov	a,r7
      0057CF 75 F0 03         [24] 1563 	mov	b,#0x03
      0057D2 A4               [48] 1564 	mul	ab
      0057D3 24 0C            [12] 1565 	add	a, #_g_direct_mode_colors
      0057D5 FD               [12] 1566 	mov	r5,a
      0057D6 74 0D            [12] 1567 	mov	a,#(_g_direct_mode_colors >> 8)
      0057D8 35 F0            [12] 1568 	addc	a, b
      0057DA FE               [12] 1569 	mov	r6,a
      0057DB 90 0E 20         [24] 1570 	mov	dptr,#___memcpy_PARM_2
      0057DE ED               [12] 1571 	mov	a,r5
      0057DF F0               [24] 1572 	movx	@dptr,a
      0057E0 EE               [12] 1573 	mov	a,r6
      0057E1 12 38 27         [24] 1574 	lcall	_ak820_outline_0076
      0057E4 90 0E 23         [24] 1575 	mov	dptr,#___memcpy_PARM_3
      0057E7 74 03            [12] 1576 	mov	a,#0x03
      0057E9 12 38 60         [24] 1577 	lcall	_ak820_outline_0132
      0057EC 90 07 86         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057EF F5 F0            [12] 1579 	mov	b,a
      0057F1 12 BE 98         [24] 1580 	lcall	___memcpy
      0057F4 02 58 A6         [24] 1581 	ljmp	00120$
      0057F7                       1582 00119$:
                                   1583 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      0057F7 90 07 1C         [24] 1584 	mov	dptr,#_frame_hue
      0057FA E0               [24] 1585 	movx	a,@dptr
      0057FB 90 07 86         [24] 1586 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057FE F0               [24] 1587 	movx	@dptr,a
                                   1588 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      0057FF 90 07 1D         [24] 1589 	mov	dptr,#_frame_sat
      005802 E0               [24] 1590 	movx	a,@dptr
      005803 90 07 87         [24] 1591 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005806 F0               [24] 1592 	movx	@dptr,a
                                   1593 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      005807 90 07 1E         [24] 1594 	mov	dptr,#_frame_val
      00580A E0               [24] 1595 	movx	a,@dptr
      00580B 90 07 88         [24] 1596 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      00580E F0               [24] 1597 	movx	@dptr,a
                                   1598 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      00580F 12 5B D2         [24] 1599 	lcall	_ak820_outline_0146
      005812 BE 03 0E         [24] 1600 	cjne	r6,#0x03,00113$
      005815 90 07 86         [24] 1601 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005818 E0               [24] 1602 	movx	a,@dptr
      005819 FE               [12] 1603 	mov	r6,a
      00581A 90 07 20         [24] 1604 	mov	dptr,#_frame_phase
      00581D E0               [24] 1605 	movx	a,@dptr
      00581E 2E               [12] 1606 	add	a, r6
      00581F 90 07 86         [24] 1607 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005822 F0               [24] 1608 	movx	@dptr,a
      005823                       1609 00113$:
                                   1610 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005823 12 5B D2         [24] 1611 	lcall	_ak820_outline_0146
      005826 BE 04 23         [24] 1612 	cjne	r6,#0x04,00115$
      005829 90 07 86         [24] 1613 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00582C E0               [24] 1614 	movx	a,@dptr
      00582D FE               [12] 1615 	mov	r6,a
      00582E 12 5B F5         [24] 1616 	lcall	_ak820_outline_0192
      005831 75 F0 02         [24] 1617 	mov	b,#0x02
      005834 A4               [48] 1618 	mul	ab
      005835 24 5B            [12] 1619 	add	a, #_ak820_led_points
      005837 F5 82            [12] 1620 	mov	dpl,a
      005839 74 C2            [12] 1621 	mov	a,#(_ak820_led_points >> 8)
      00583B 12 5B C4         [24] 1622 	lcall	_ak820_outline_0113
      00583E FD               [12] 1623 	mov	r5,a
      00583F 90 07 20         [24] 1624 	mov	dptr,#_frame_phase
      005842 E0               [24] 1625 	movx	a,@dptr
      005843 FC               [12] 1626 	mov	r4,a
      005844 ED               [12] 1627 	mov	a,r5
      005845 C3               [12] 1628 	clr	c
      005846 9C               [12] 1629 	subb	a,r4
      005847 2E               [12] 1630 	add	a, r6
      005848 90 07 86         [24] 1631 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00584B F0               [24] 1632 	movx	@dptr,a
      00584C                       1633 00115$:
                                   1634 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      00584C 12 5B D2         [24] 1635 	lcall	_ak820_outline_0146
      00584F BE 06 54         [24] 1636 	cjne	r6,#0x06,00120$
                                   1637 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005852 12 5B E3         [24] 1638 	lcall	_ak820_outline_0180
      005855 FE               [12] 1639 	mov	r6,a
      005856 74 07            [12] 1640 	mov	a,#0x07
      005858 C3               [12] 1641 	clr	c
      005859 9E               [12] 1642 	subb	a,r6
      00585A FE               [12] 1643 	mov	r6,a
                                   1644 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      00585B 8E F0            [24] 1645 	mov	b,r6
      00585D 05 F0            [12] 1646 	inc	b
      00585F 74 01            [12] 1647 	mov	a,#0x01
      005861 80 02            [24] 1648 	sjmp	00273$
      005863                       1649 00272$:
      005863 25 E0            [12] 1650 	add	a,acc
      005865                       1651 00273$:
      005865 D5 F0 FB         [24] 1652 	djnz	b,00272$
      005868 FD               [12] 1653 	mov	r5,a
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      005869 12 5B F5         [24] 1655 	lcall	_ak820_outline_0192
      00586C 24 21            [12] 1656 	add	a, #_reactive_age
      00586E F5 82            [12] 1657 	mov	dpl,a
      005870 E4               [12] 1658 	clr	a
      005871 34 07            [12] 1659 	addc	a, #(_reactive_age >> 8)
      005873 F5 83            [12] 1660 	mov	dph,a
      005875 E0               [24] 1661 	movx	a,@dptr
                                   1662 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005876 FC               [12] 1663 	mov	r4,a
      005877 C3               [12] 1664 	clr	c
      005878 9D               [12] 1665 	subb	a,r5
      005879 40 07            [24] 1666 	jc	00137$
      00587B 90 07 1E         [24] 1667 	mov	dptr,#_frame_val
      00587E E0               [24] 1668 	movx	a,@dptr
      00587F FB               [12] 1669 	mov	r3,a
      005880 80 1F            [24] 1670 	sjmp	00138$
      005882                       1671 00137$:
      005882 90 07 1E         [24] 1672 	mov	dptr,#_frame_val
      005885 E0               [24] 1673 	movx	a,@dptr
      005886 F5 F0            [12] 1674 	mov	b, a
      005888 EC               [12] 1675 	mov	a,r4
      005889 A4               [48] 1676 	mul	ab
      00588A FC               [12] 1677 	mov	r4,a
      00588B AA F0            [24] 1678 	mov	r2,b
      00588D 8E F0            [24] 1679 	mov	b,r6
      00588F 05 F0            [12] 1680 	inc	b
      005891 AB 04            [24] 1681 	mov	r3,ar4
      005893 AD 02            [24] 1682 	mov	r5,ar2
      005895 80 07            [24] 1683 	sjmp	00276$
      005897                       1684 00275$:
      005897 C3               [12] 1685 	clr	c
      005898 ED               [12] 1686 	mov	a,r5
      005899 13               [12] 1687 	rrc	a
      00589A FD               [12] 1688 	mov	r5,a
      00589B EB               [12] 1689 	mov	a,r3
      00589C 13               [12] 1690 	rrc	a
      00589D FB               [12] 1691 	mov	r3,a
      00589E                       1692 00276$:
      00589E D5 F0 F6         [24] 1693 	djnz	b,00275$
      0058A1                       1694 00138$:
      0058A1 90 07 88         [24] 1695 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0058A4 EB               [12] 1696 	mov	a,r3
      0058A5 F0               [24] 1697 	movx	@dptr,a
      0058A6                       1698 00120$:
                                   1699 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0058A6 12 5B D2         [24] 1700 	lcall	_ak820_outline_0146
      0058A9 BE 02 03         [24] 1701 	cjne	r6,#0x02,00277$
      0058AC D3               [12] 1702 	setb	c
      0058AD 80 01            [24] 1703 	sjmp	00278$
      0058AF                       1704 00277$:
      0058AF C3               [12] 1705 	clr	c
      0058B0                       1706 00278$:
      0058B0 B3               [12] 1707 	cpl	c
      0058B1 92 15            [24] 1708 	mov	_rgb_matrix_task_sloc0_1_0,c
      0058B3 90 0E 20         [24] 1709 	mov	dptr,#___memcpy_PARM_2
      0058B6 74 86            [12] 1710 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0058B8 F0               [24] 1711 	movx	@dptr,a
      0058B9 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0058BB 12 38 27         [24] 1713 	lcall	_ak820_outline_0076
      0058BE 90 0E 23         [24] 1714 	mov	dptr,#___memcpy_PARM_3
      0058C1 74 03            [12] 1715 	mov	a,#0x03
      0058C3 12 38 60         [24] 1716 	lcall	_ak820_outline_0132
      0058C6 90 0B 41         [24] 1717 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0058C9 F5 F0            [12] 1718 	mov	b,a
      0058CB 12 BE 98         [24] 1719 	lcall	___memcpy
      0058CE 90 0B 44         [24] 1720 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0058D1 74 89            [12] 1721 	mov	a,#_rgb_matrix_task_rgb_10000_298
      0058D3 F0               [24] 1722 	movx	@dptr,a
      0058D4 74 07            [12] 1723 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      0058D6 A3               [24] 1724 	inc	dptr
      0058D7 F0               [24] 1725 	movx	@dptr,a
      0058D8 A2 15            [12] 1726 	mov	c,_rgb_matrix_task_sloc0_1_0
      0058DA 12 38 70         [24] 1727 	lcall	_ak820_outline_0150
      0058DD 12 86 9F         [24] 1728 	lcall	_hsv_to_rgb_into
                                   1729 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      0058E0 12 5B F5         [24] 1730 	lcall	_ak820_outline_0192
      0058E3 FD               [12] 1731 	mov	r5,a
      0058E4 7E 00            [12] 1732 	mov	r6,#0x00
      0058E6 90 07 8A         [24] 1733 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      0058E9 E0               [24] 1734 	movx	a,@dptr
      0058EA FC               [12] 1735 	mov	r4,a
      0058EB 90 07 89         [24] 1736 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      0058EE E0               [24] 1737 	movx	a,@dptr
      0058EF FB               [12] 1738 	mov	r3,a
      0058F0 90 07 8B         [24] 1739 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      0058F3 E0               [24] 1740 	movx	a,@dptr
      0058F4 FA               [12] 1741 	mov	r2,a
      0058F5 90 07 79         [24] 1742 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0058F8 EC               [12] 1743 	mov	a,r4
      0058F9 F0               [24] 1744 	movx	@dptr,a
      0058FA 90 07 7A         [24] 1745 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0058FD EB               [12] 1746 	mov	a,r3
      0058FE F0               [24] 1747 	movx	@dptr,a
      0058FF 90 07 7B         [24] 1748 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005902 EA               [12] 1749 	mov	a,r2
      005903 F0               [24] 1750 	movx	@dptr,a
      005904 12 38 65         [24] 1751 	lcall	_ak820_outline_0141
      005907 12 55 93         [24] 1752 	lcall	_rgb_matrix_set_color
      00590A                       1753 00123$:
                                   1754 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      00590A 12 5B F5         [24] 1755 	lcall	_ak820_outline_0192
      00590D 24 01            [12] 1756 	add	a, #0x01
      00590F F0               [24] 1757 	movx	@dptr,a
      005910 02 57 91         [24] 1758 	ljmp	00125$
      005913                       1759 00127$:
                                   1760 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005913 BF 52 02         [24] 1761 	cjne	r7,#0x52,00130$
                                   1762 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1763 ;	assignBit
      005916 C2 14            [12] 1764 	clr	_rendering
      005918                       1765 00130$:
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005918 22               [24] 1767 	ret
                                   1768 ;------------------------------------------------------------
                                   1769 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1770 ;------------------------------------------------------------
                                   1771 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1772 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1773 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1774 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1775 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1776 ;------------------------------------------------------------
                                   1777 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1778 ;	-----------------------------------------
                                   1779 ;	 function process_rgb_matrix
                                   1780 ;	-----------------------------------------
      005919                       1781 _process_rgb_matrix:
      005919 E5 82            [12] 1782 	mov	a,dpl
      00591B 90 07 8E         [24] 1783 	mov	dptr,#_process_rgb_matrix_row_10000_319
      00591E F0               [24] 1784 	movx	@dptr,a
                                   1785 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      00591F 90 07 8D         [24] 1786 	mov	dptr,#_process_rgb_matrix_PARM_3
      005922 E0               [24] 1787 	movx	a,@dptr
      005923 60 23            [24] 1788 	jz	00101$
      005925 20 12 20         [24] 1789 	jb	_suspended,00101$
      005928 12 5B AA         [24] 1790 	lcall	_ak820_outline_0070
      00592B 60 1B            [24] 1791 	jz	00101$
                                   1792 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      00592D 12 5B 8B         [24] 1793 	lcall	_ak820_outline_0020
      005930 FF               [12] 1794 	mov	r7,a
      005931 BF 06 14         [24] 1795 	cjne	r7,#0x06,00101$
      005934 90 07 8E         [24] 1796 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005937 E0               [24] 1797 	movx	a,@dptr
      005938 FF               [12] 1798 	mov	r7,a
      005939 BF 10 00         [24] 1799 	cjne	r7,#0x10,00169$
      00593C                       1800 00169$:
      00593C 50 0A            [24] 1801 	jnc	00101$
      00593E 90 07 8C         [24] 1802 	mov	dptr,#_process_rgb_matrix_PARM_2
      005941 E0               [24] 1803 	movx	a,@dptr
      005942 FE               [12] 1804 	mov	r6,a
      005943 BE 08 00         [24] 1805 	cjne	r6,#0x08,00171$
      005946                       1806 00171$:
      005946 40 01            [24] 1807 	jc	00102$
      005948                       1808 00101$:
      005948 22               [24] 1809 	ret
      005949                       1810 00102$:
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005949 C0 07            [24] 1812 	push	ar7
      00594B C0 06            [24] 1813 	push	ar6
      00594D 12 54 1E         [24] 1814 	lcall	_age_reactive
      005950 D0 06            [24] 1815 	pop	ar6
      005952 D0 07            [24] 1816 	pop	ar7
                                   1817 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005954 EF               [12] 1818 	mov	a,r7
      005955 12 38 8B         [24] 1819 	lcall	_ak820_outline_0193
      005958 2E               [12] 1820 	add	a,r6
      005959 FF               [12] 1821 	mov	r7,a
                                   1822 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00595A 7E 00            [12] 1823 	mov	r6,#0x00
      00595C                       1824 00111$:
                                   1825 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      00595C EE               [12] 1826 	mov	a,r6
      00595D 90 BF A1         [24] 1827 	mov	dptr,#_ak820_rgb_slots
      005960 93               [24] 1828 	movc	a,@a+dptr
      005961 B5 07 29         [24] 1829 	cjne	a,ar7,00112$
                                   1830 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005964 EE               [12] 1831 	mov	a,r6
      005965 24 21            [12] 1832 	add	a, #_reactive_age
      005967 FC               [12] 1833 	mov	r4,a
      005968 E4               [12] 1834 	clr	a
      005969 34 07            [12] 1835 	addc	a, #(_reactive_age >> 8)
      00596B FD               [12] 1836 	mov	r5,a
      00596C 12 5B E3         [24] 1837 	lcall	_ak820_outline_0180
      00596F F5 F0            [12] 1838 	mov	b, a
      005971 05 F0            [12] 1839 	inc	b
      005973 7B 80            [12] 1840 	mov	r3,#0x80
      005975 E4               [12] 1841 	clr	a
      005976 FA               [12] 1842 	mov	r2,a
      005977 33               [12] 1843 	rlc	a
      005978 92 D2            [24] 1844 	mov	ov,c
      00597A 80 08            [24] 1845 	sjmp	00176$
      00597C                       1846 00175$:
      00597C A2 D2            [12] 1847 	mov	c,ov
      00597E EA               [12] 1848 	mov	a,r2
      00597F 13               [12] 1849 	rrc	a
      005980 FA               [12] 1850 	mov	r2,a
      005981 EB               [12] 1851 	mov	a,r3
      005982 13               [12] 1852 	rrc	a
      005983 FB               [12] 1853 	mov	r3,a
      005984                       1854 00176$:
      005984 D5 F0 F5         [24] 1855 	djnz	b,00175$
      005987 12 38 55         [24] 1856 	lcall	_ak820_outline_0126
      00598A EB               [12] 1857 	mov	a,r3
      00598B F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      00598C 22               [24] 1860 	ret
      00598D                       1861 00112$:
                                   1862 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00598D 0E               [12] 1863 	inc	r6
      00598E BE 52 00         [24] 1864 	cjne	r6,#0x52,00177$
      005991                       1865 00177$:
      005991 40 C9            [24] 1866 	jc	00111$
                                   1867 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      005993 22               [24] 1868 	ret
                                   1869 ;------------------------------------------------------------
                                   1870 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1871 ;------------------------------------------------------------
                                   1872 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1873 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1874 ;------------------------------------------------------------
                                   1875 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1876 ;	-----------------------------------------
                                   1877 ;	 function rgb_matrix_set_suspend_state
                                   1878 ;	-----------------------------------------
      005994                       1879 _rgb_matrix_set_suspend_state:
      005994 E5 82            [12] 1880 	mov	a,dpl
      005996 90 07 8F         [24] 1881 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      005999 F0               [24] 1882 	movx	@dptr,a
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      00599A E0               [24] 1884 	movx	a,@dptr
                                   1885 ;	assignBit
      00599B F5 17            [12] 1886 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      00599D 13               [12] 1887 	rrc	a
      00599E 92 12            [24] 1888 	mov	_suspended,c
                                   1889 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1890 ;	assignBit
      0059A0 C2 14            [12] 1891 	clr	_rendering
                                   1892 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      0059A2 12 54 01         [24] 1893 	lcall	_clear_reactive
                                   1894 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      0059A5 E5 17            [12] 1895 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      0059A7 60 0F            [24] 1896 	jz	00103$
                                   1897 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      0059A9 90 07 7E         [24] 1898 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0059AC E4               [12] 1899 	clr	a
      0059AD F0               [24] 1900 	movx	@dptr,a
      0059AE 90 07 7F         [24] 1901 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0059B1 F0               [24] 1902 	movx	@dptr,a
      0059B2 75 82 00         [24] 1903 	mov	dpl, #0x00
                                   1904 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      0059B5 02 55 D4         [24] 1905 	ljmp	_rgb_matrix_set_color_all
      0059B8                       1906 00103$:
      0059B8 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_is_enabled
                                   1914 ;	-----------------------------------------
      0059B9                       1915 _rgb_matrix_is_enabled:
      0059B9 12 5B AA         [24] 1916 	lcall	_ak820_outline_0070
      0059BC F5 82            [12] 1917 	mov	dpl,a
      0059BE 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_mode
                                   1925 ;	-----------------------------------------
      0059BF                       1926 _rgb_matrix_get_mode:
      0059BF 12 5B 8B         [24] 1927 	lcall	_ak820_outline_0020
      0059C2 F5 82            [12] 1928 	mov	dpl,a
      0059C4 22               [24] 1929 	ret
                                   1930 ;------------------------------------------------------------
                                   1931 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1932 ;------------------------------------------------------------
                                   1933 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1934 ;	-----------------------------------------
                                   1935 ;	 function rgb_matrix_get_hue
                                   1936 ;	-----------------------------------------
      0059C5                       1937 _rgb_matrix_get_hue:
      0059C5 90 07 0D         [24] 1938 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0059C8 E0               [24] 1939 	movx	a,@dptr
      0059C9 F5 82            [12] 1940 	mov	dpl,a
      0059CB 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1944 ;------------------------------------------------------------
                                   1945 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1946 ;	-----------------------------------------
                                   1947 ;	 function rgb_matrix_get_sat
                                   1948 ;	-----------------------------------------
      0059CC                       1949 _rgb_matrix_get_sat:
      0059CC 90 07 0E         [24] 1950 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0059CF E0               [24] 1951 	movx	a,@dptr
      0059D0 F5 82            [12] 1952 	mov	dpl,a
      0059D2 22               [24] 1953 	ret
                                   1954 ;------------------------------------------------------------
                                   1955 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1956 ;------------------------------------------------------------
                                   1957 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1958 ;	-----------------------------------------
                                   1959 ;	 function rgb_matrix_get_val
                                   1960 ;	-----------------------------------------
      0059D3                       1961 _rgb_matrix_get_val:
      0059D3 90 07 0F         [24] 1962 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0059D6 E0               [24] 1963 	movx	a,@dptr
      0059D7 F5 82            [12] 1964 	mov	dpl,a
      0059D9 22               [24] 1965 	ret
                                   1966 ;------------------------------------------------------------
                                   1967 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1968 ;------------------------------------------------------------
                                   1969 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1970 ;	-----------------------------------------
                                   1971 ;	 function rgb_matrix_get_speed
                                   1972 ;	-----------------------------------------
      0059DA                       1973 _rgb_matrix_get_speed:
      0059DA 90 07 10         [24] 1974 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0059DD E0               [24] 1975 	movx	a,@dptr
      0059DE F5 82            [12] 1976 	mov	dpl,a
      0059E0 22               [24] 1977 	ret
                                   1978 ;------------------------------------------------------------
                                   1979 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1980 ;------------------------------------------------------------
                                   1981 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1982 ;	-----------------------------------------
                                   1983 ;	 function rgb_matrix_toggle_noeeprom
                                   1984 ;	-----------------------------------------
      0059E1                       1985 _rgb_matrix_toggle_noeeprom:
      0059E1 12 5B AA         [24] 1986 	lcall	_ak820_outline_0070
      0059E4 FF               [12] 1987 	mov	r7,a
      0059E5 63 07 01         [24] 1988 	xrl	ar7,#0x01
      0059E8 90 07 0C         [24] 1989 	mov	dptr,#_rgb_matrix_config
      0059EB EF               [12] 1990 	mov	a,r7
      0059EC 54 03            [12] 1991 	anl	a,#0x03
      0059EE F5 F0            [12] 1992 	mov	b,a
      0059F0 E0               [24] 1993 	movx	a,@dptr
      0059F1 54 FC            [12] 1994 	anl	a,#0xfc
      0059F3 45 F0            [12] 1995 	orl	a,b
      0059F5 F0               [24] 1996 	movx	@dptr,a
                                   1997 ;	assignBit
      0059F6 C2 14            [12] 1998 	clr	_rendering
      0059F8 02 54 01         [24] 1999 	ljmp	_clear_reactive
                                   2000 ;------------------------------------------------------------
                                   2001 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   2002 ;------------------------------------------------------------
                                   2003 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   2004 ;	-----------------------------------------
                                   2005 ;	 function rgb_matrix_enable_noeeprom
                                   2006 ;	-----------------------------------------
      0059FB                       2007 _rgb_matrix_enable_noeeprom:
      0059FB 12 5B AA         [24] 2008 	lcall	_ak820_outline_0070
      0059FE 70 03            [24] 2009 	jnz	00102$
      005A00 12 54 01         [24] 2010 	lcall	_clear_reactive
      005A03                       2011 00102$:
      005A03 12 5B CB         [24] 2012 	lcall	_ak820_outline_0120
      005A06 44 01            [12] 2013 	orl	a,#0x01
      005A08 F0               [24] 2014 	movx	@dptr,a
                                   2015 ;	assignBit
      005A09 C2 14            [12] 2016 	clr	_rendering
      005A0B 22               [24] 2017 	ret
                                   2018 ;------------------------------------------------------------
                                   2019 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2020 ;------------------------------------------------------------
                                   2021 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2022 ;	-----------------------------------------
                                   2023 ;	 function rgb_matrix_disable_noeeprom
                                   2024 ;	-----------------------------------------
      005A0C                       2025 _rgb_matrix_disable_noeeprom:
      005A0C 12 5B CB         [24] 2026 	lcall	_ak820_outline_0120
      005A0F F0               [24] 2027 	movx	@dptr,a
                                   2028 ;	assignBit
      005A10 C2 14            [12] 2029 	clr	_rendering
      005A12 02 54 01         [24] 2030 	ljmp	_clear_reactive
                                   2031 ;------------------------------------------------------------
                                   2032 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2033 ;------------------------------------------------------------
                                   2034 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2035 ;------------------------------------------------------------
                                   2036 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2037 ;	-----------------------------------------
                                   2038 ;	 function rgb_matrix_mode_noeeprom
                                   2039 ;	-----------------------------------------
      005A15                       2040 _rgb_matrix_mode_noeeprom:
      005A15 E5 82            [12] 2041 	mov	a,dpl
      005A17 90 07 90         [24] 2042 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A1A F0               [24] 2043 	movx	@dptr,a
                                   2044 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005A1B E0               [24] 2045 	movx	a,@dptr
      005A1C FF               [12] 2046 	mov	r7,a
      005A1D 60 05            [24] 2047 	jz	00101$
      005A1F BF 07 00         [24] 2048 	cjne	r7,#0x07,00123$
      005A22                       2049 00123$:
      005A22 40 01            [24] 2050 	jc	00102$
      005A24                       2051 00101$:
      005A24 22               [24] 2052 	ret
      005A25                       2053 00102$:
                                   2054 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005A25 12 5B 8B         [24] 2055 	lcall	_ak820_outline_0020
      005A28 FE               [12] 2056 	mov	r6,a
      005A29 EF               [12] 2057 	mov	a,r7
      005A2A B5 06 02         [24] 2058 	cjne	a,ar6,00125$
      005A2D 80 03            [24] 2059 	sjmp	00105$
      005A2F                       2060 00125$:
      005A2F 12 54 01         [24] 2061 	lcall	_clear_reactive
      005A32                       2062 00105$:
                                   2063 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005A32 90 07 90         [24] 2064 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A35 E0               [24] 2065 	movx	a,@dptr
      005A36 90 07 0C         [24] 2066 	mov	dptr,#_rgb_matrix_config
      005A39 25 E0            [12] 2067 	add	a,acc
      005A3B 25 E0            [12] 2068 	add	a,acc
      005A3D 54 FC            [12] 2069 	anl	a,#0xfc
      005A3F F5 F0            [12] 2070 	mov	b,a
      005A41 E0               [24] 2071 	movx	a,@dptr
      005A42 54 03            [12] 2072 	anl	a,#0x03
      005A44 45 F0            [12] 2073 	orl	a,b
      005A46 F0               [24] 2074 	movx	@dptr,a
                                   2075 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2076 ;	assignBit
      005A47 C2 14            [12] 2077 	clr	_rendering
                                   2078 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005A49 22               [24] 2079 	ret
                                   2080 ;------------------------------------------------------------
                                   2081 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2082 ;------------------------------------------------------------
                                   2083 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2084 ;	-----------------------------------------
                                   2085 ;	 function rgb_matrix_step_noeeprom
                                   2086 ;	-----------------------------------------
      005A4A                       2087 _rgb_matrix_step_noeeprom:
                                   2088 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005A4A 12 5B 8B         [24] 2089 	lcall	_ak820_outline_0020
      005A4D FF               [12] 2090 	mov	r7,a
      005A4E 0F               [12] 2091 	inc	r7
      005A4F BF 07 00         [24] 2092 	cjne	r7,#0x07,00112$
      005A52                       2093 00112$:
      005A52 40 04            [24] 2094 	jc	00103$
      005A54 7F 01            [12] 2095 	mov	r7,#0x01
      005A56 80 07            [24] 2096 	sjmp	00104$
      005A58                       2097 00103$:
      005A58 12 5B 8B         [24] 2098 	lcall	_ak820_outline_0020
      005A5B FE               [12] 2099 	mov	r6,a
      005A5C 0E               [12] 2100 	inc	r6
      005A5D 8E 07            [24] 2101 	mov	ar7,r6
      005A5F                       2102 00104$:
      005A5F 8F 82            [24] 2103 	mov	dpl, r7
                                   2104 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005A61 02 5A 15         [24] 2105 	ljmp	_rgb_matrix_mode_noeeprom
                                   2106 ;------------------------------------------------------------
                                   2107 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2108 ;------------------------------------------------------------
                                   2109 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2110 ;	-----------------------------------------
                                   2111 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2112 ;	-----------------------------------------
      005A64                       2113 _rgb_matrix_step_reverse_noeeprom:
                                   2114 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005A64 12 5B 8B         [24] 2115 	lcall	_ak820_outline_0020
      005A67 24 FE            [12] 2116 	add	a,#0xff - 0x01
      005A69 40 04            [24] 2117 	jc	00103$
                                   2118 ;	free result
      005A6B 7F 06            [12] 2119 	mov	r7,#0x06
      005A6D 80 05            [24] 2120 	sjmp	00104$
      005A6F                       2121 00103$:
      005A6F 12 5B 8B         [24] 2122 	lcall	_ak820_outline_0020
      005A72 14               [12] 2123 	dec	a
      005A73 FF               [12] 2124 	mov	r7,a
      005A74                       2125 00104$:
      005A74 8F 82            [24] 2126 	mov	dpl, r7
                                   2127 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005A76 02 5A 15         [24] 2128 	ljmp	_rgb_matrix_mode_noeeprom
                                   2129 ;------------------------------------------------------------
                                   2130 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2131 ;------------------------------------------------------------
                                   2132 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2133 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2134 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function rgb_matrix_sethsv_noeeprom
                                   2139 ;	-----------------------------------------
      005A79                       2140 _rgb_matrix_sethsv_noeeprom:
      005A79 12 38 4B         [24] 2141 	lcall	_ak820_outline_0108
      005A7C 90 07 93         [24] 2142 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005A7F 12 38 50         [24] 2143 	lcall	_ak820_outline_0109
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005A82 90 07 93         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005A85 E0               [24] 2146 	movx	a,@dptr
      005A86 90 07 0D         [24] 2147 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A89 F0               [24] 2148 	movx	@dptr,a
                                   2149 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005A8A 90 07 91         [24] 2150 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005A8D E0               [24] 2151 	movx	a,@dptr
      005A8E FF               [12] 2152 	mov	r7,a
      005A8F 90 07 0E         [24] 2153 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A92 F0               [24] 2154 	movx	@dptr,a
                                   2155 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005A93 90 07 92         [24] 2156 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005A96 E0               [24] 2157 	movx	a,@dptr
      005A97 FF               [12] 2158 	mov  r7,a
      005A98 24 5F            [12] 2159 	add	a,#0xff - 0xa0
      005A9A 50 04            [24] 2160 	jnc	00103$
                                   2161 ;	free result
      005A9C 7E A0            [12] 2162 	mov	r6,#0xa0
      005A9E 80 02            [24] 2163 	sjmp	00104$
      005AA0                       2164 00103$:
      005AA0 8F 06            [24] 2165 	mov	ar6,r7
      005AA2                       2166 00104$:
      005AA2 90 07 0F         [24] 2167 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AA5 EE               [12] 2168 	mov	a,r6
      005AA6 F0               [24] 2169 	movx	@dptr,a
                                   2170 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005AA7 22               [24] 2171 	ret
                                   2172 ;------------------------------------------------------------
                                   2173 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2174 ;------------------------------------------------------------
                                   2175 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2176 ;------------------------------------------------------------
                                   2177 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2178 ;	-----------------------------------------
                                   2179 ;	 function rgb_matrix_set_speed_noeeprom
                                   2180 ;	-----------------------------------------
      005AA8                       2181 _rgb_matrix_set_speed_noeeprom:
      005AA8 E5 82            [12] 2182 	mov	a,dpl
      005AAA 90 07 95         [24] 2183 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005AAD F0               [24] 2184 	movx	@dptr,a
      005AAE E0               [24] 2185 	movx	a,@dptr
      005AAF 90 07 10         [24] 2186 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AB2 F0               [24] 2187 	movx	@dptr,a
      005AB3 22               [24] 2188 	ret
                                   2189 ;------------------------------------------------------------
                                   2190 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2191 ;------------------------------------------------------------
                                   2192 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2193 ;------------------------------------------------------------
                                   2194 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2195 ;	-----------------------------------------
                                   2196 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2197 ;	-----------------------------------------
      005AB4                       2198 _rgb_matrix_increase_hue_noeeprom:
      005AB4 90 07 0D         [24] 2199 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AB7 E0               [24] 2200 	movx	a,@dptr
      005AB8 24 08            [12] 2201 	add	a,#0x08
      005ABA 90 07 0D         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005ABD F0               [24] 2203 	movx	@dptr,a
      005ABE 22               [24] 2204 	ret
                                   2205 ;------------------------------------------------------------
                                   2206 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2207 ;------------------------------------------------------------
                                   2208 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2209 ;	-----------------------------------------
                                   2210 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2211 ;	-----------------------------------------
      005ABF                       2212 _rgb_matrix_decrease_hue_noeeprom:
      005ABF 90 07 0D         [24] 2213 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AC2 E0               [24] 2214 	movx	a,@dptr
      005AC3 24 F8            [12] 2215 	add	a,#0xf8
      005AC5 90 07 0D         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AC8 F0               [24] 2217 	movx	@dptr,a
      005AC9 22               [24] 2218 	ret
                                   2219 ;------------------------------------------------------------
                                   2220 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2221 ;------------------------------------------------------------
                                   2222 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2223 ;	-----------------------------------------
                                   2224 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2225 ;	-----------------------------------------
      005ACA                       2226 _rgb_matrix_increase_sat_noeeprom:
      005ACA 90 07 0E         [24] 2227 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005ACD 12 5B 94         [24] 2228 	lcall	_ak820_outline_0052
      005AD0 12 54 9C         [24] 2229 	lcall	_add_sat
      005AD3 AF 82            [24] 2230 	mov	r7, dpl
      005AD5 90 07 0E         [24] 2231 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AD8 EF               [12] 2232 	mov	a,r7
      005AD9 F0               [24] 2233 	movx	@dptr,a
      005ADA 22               [24] 2234 	ret
                                   2235 ;------------------------------------------------------------
                                   2236 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2237 ;------------------------------------------------------------
                                   2238 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2239 ;	-----------------------------------------
                                   2240 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2241 ;	-----------------------------------------
      005ADB                       2242 _rgb_matrix_decrease_sat_noeeprom:
      005ADB 90 07 0E         [24] 2243 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005ADE 12 5B 9F         [24] 2244 	lcall	_ak820_outline_0053
      005AE1 12 54 C1         [24] 2245 	lcall	_sub_sat
      005AE4 AF 82            [24] 2246 	mov	r7, dpl
      005AE6 90 07 0E         [24] 2247 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AE9 EF               [12] 2248 	mov	a,r7
      005AEA F0               [24] 2249 	movx	@dptr,a
      005AEB 22               [24] 2250 	ret
                                   2251 ;------------------------------------------------------------
                                   2252 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2253 ;------------------------------------------------------------
                                   2254 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2255 ;------------------------------------------------------------
                                   2256 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2257 ;	-----------------------------------------
                                   2258 ;	 function rgb_matrix_increase_val_noeeprom
                                   2259 ;	-----------------------------------------
      005AEC                       2260 _rgb_matrix_increase_val_noeeprom:
                                   2261 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005AEC 90 07 0F         [24] 2262 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AEF 12 5B 94         [24] 2263 	lcall	_ak820_outline_0052
      005AF2 12 54 9C         [24] 2264 	lcall	_add_sat
                                   2265 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005AF5 E5 82            [12] 2266 	mov	a,dpl
      005AF7 FF               [12] 2267 	mov	r7,a
      005AF8 24 5F            [12] 2268 	add	a,#0xff - 0xa0
      005AFA 50 04            [24] 2269 	jnc	00103$
                                   2270 ;	free result
      005AFC 7E A0            [12] 2271 	mov	r6,#0xa0
      005AFE 80 02            [24] 2272 	sjmp	00104$
      005B00                       2273 00103$:
      005B00 8F 06            [24] 2274 	mov	ar6,r7
      005B02                       2275 00104$:
      005B02 90 07 0F         [24] 2276 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B05 EE               [12] 2277 	mov	a,r6
      005B06 F0               [24] 2278 	movx	@dptr,a
                                   2279 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005B07 22               [24] 2280 	ret
                                   2281 ;------------------------------------------------------------
                                   2282 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2283 ;------------------------------------------------------------
                                   2284 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2285 ;	-----------------------------------------
                                   2286 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2287 ;	-----------------------------------------
      005B08                       2288 _rgb_matrix_decrease_val_noeeprom:
      005B08 90 07 0F         [24] 2289 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B0B 12 5B 9F         [24] 2290 	lcall	_ak820_outline_0053
      005B0E 12 54 C1         [24] 2291 	lcall	_sub_sat
      005B11 AF 82            [24] 2292 	mov	r7, dpl
      005B13 90 07 0F         [24] 2293 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B16 EF               [12] 2294 	mov	a,r7
      005B17 F0               [24] 2295 	movx	@dptr,a
      005B18 22               [24] 2296 	ret
                                   2297 ;------------------------------------------------------------
                                   2298 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2299 ;------------------------------------------------------------
                                   2300 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2301 ;	-----------------------------------------
                                   2302 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2303 ;	-----------------------------------------
      005B19                       2304 _rgb_matrix_increase_speed_noeeprom:
      005B19 90 07 10         [24] 2305 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B1C 12 5B 94         [24] 2306 	lcall	_ak820_outline_0052
      005B1F 12 54 9C         [24] 2307 	lcall	_add_sat
      005B22 AF 82            [24] 2308 	mov	r7, dpl
      005B24 90 07 10         [24] 2309 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B27 EF               [12] 2310 	mov	a,r7
      005B28 F0               [24] 2311 	movx	@dptr,a
      005B29 22               [24] 2312 	ret
                                   2313 ;------------------------------------------------------------
                                   2314 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2315 ;------------------------------------------------------------
                                   2316 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2317 ;	-----------------------------------------
                                   2318 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2319 ;	-----------------------------------------
      005B2A                       2320 _rgb_matrix_decrease_speed_noeeprom:
      005B2A 90 07 10         [24] 2321 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B2D 12 5B 9F         [24] 2322 	lcall	_ak820_outline_0053
      005B30 12 54 C1         [24] 2323 	lcall	_sub_sat
      005B33 AF 82            [24] 2324 	mov	r7, dpl
      005B35 90 07 10         [24] 2325 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B38 EF               [12] 2326 	mov	a,r7
      005B39 F0               [24] 2327 	movx	@dptr,a
      005B3A 22               [24] 2328 	ret
                                   2329 ;------------------------------------------------------------
                                   2330 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2331 ;------------------------------------------------------------
                                   2332 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2333 ;	-----------------------------------------
                                   2334 ;	 function rgb_matrix_toggle
                                   2335 ;	-----------------------------------------
      005B3B                       2336 _rgb_matrix_toggle:
      005B3B 12 59 E1         [24] 2337 	lcall	_rgb_matrix_toggle_noeeprom
      005B3E 02 54 DE         [24] 2338 	ljmp	_mark_dirty
                                   2339 ;------------------------------------------------------------
                                   2340 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2341 ;------------------------------------------------------------
                                   2342 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2343 ;	-----------------------------------------
                                   2344 ;	 function rgb_matrix_step
                                   2345 ;	-----------------------------------------
      005B41                       2346 _rgb_matrix_step:
      005B41 12 5A 4A         [24] 2347 	lcall	_rgb_matrix_step_noeeprom
      005B44 02 54 DE         [24] 2348 	ljmp	_mark_dirty
                                   2349 ;------------------------------------------------------------
                                   2350 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2351 ;------------------------------------------------------------
                                   2352 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2353 ;	-----------------------------------------
                                   2354 ;	 function rgb_matrix_step_reverse
                                   2355 ;	-----------------------------------------
      005B47                       2356 _rgb_matrix_step_reverse:
      005B47 12 5A 64         [24] 2357 	lcall	_rgb_matrix_step_reverse_noeeprom
      005B4A 02 54 DE         [24] 2358 	ljmp	_mark_dirty
                                   2359 ;------------------------------------------------------------
                                   2360 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2361 ;------------------------------------------------------------
                                   2362 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2363 ;	-----------------------------------------
                                   2364 ;	 function rgb_matrix_increase_hue
                                   2365 ;	-----------------------------------------
      005B4D                       2366 _rgb_matrix_increase_hue:
      005B4D 12 5A B4         [24] 2367 	lcall	_rgb_matrix_increase_hue_noeeprom
      005B50 02 54 DE         [24] 2368 	ljmp	_mark_dirty
                                   2369 ;------------------------------------------------------------
                                   2370 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2371 ;------------------------------------------------------------
                                   2372 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2373 ;	-----------------------------------------
                                   2374 ;	 function rgb_matrix_decrease_hue
                                   2375 ;	-----------------------------------------
      005B53                       2376 _rgb_matrix_decrease_hue:
      005B53 12 5A BF         [24] 2377 	lcall	_rgb_matrix_decrease_hue_noeeprom
      005B56 02 54 DE         [24] 2378 	ljmp	_mark_dirty
                                   2379 ;------------------------------------------------------------
                                   2380 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2381 ;------------------------------------------------------------
                                   2382 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2383 ;	-----------------------------------------
                                   2384 ;	 function rgb_matrix_increase_sat
                                   2385 ;	-----------------------------------------
      005B59                       2386 _rgb_matrix_increase_sat:
      005B59 12 5A CA         [24] 2387 	lcall	_rgb_matrix_increase_sat_noeeprom
      005B5C 02 54 DE         [24] 2388 	ljmp	_mark_dirty
                                   2389 ;------------------------------------------------------------
                                   2390 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2391 ;------------------------------------------------------------
                                   2392 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2393 ;	-----------------------------------------
                                   2394 ;	 function rgb_matrix_decrease_sat
                                   2395 ;	-----------------------------------------
      005B5F                       2396 _rgb_matrix_decrease_sat:
      005B5F 12 5A DB         [24] 2397 	lcall	_rgb_matrix_decrease_sat_noeeprom
      005B62 02 54 DE         [24] 2398 	ljmp	_mark_dirty
                                   2399 ;------------------------------------------------------------
                                   2400 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2401 ;------------------------------------------------------------
                                   2402 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2403 ;	-----------------------------------------
                                   2404 ;	 function rgb_matrix_increase_val
                                   2405 ;	-----------------------------------------
      005B65                       2406 _rgb_matrix_increase_val:
      005B65 12 5A EC         [24] 2407 	lcall	_rgb_matrix_increase_val_noeeprom
      005B68 02 54 DE         [24] 2408 	ljmp	_mark_dirty
                                   2409 ;------------------------------------------------------------
                                   2410 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function rgb_matrix_decrease_val
                                   2415 ;	-----------------------------------------
      005B6B                       2416 _rgb_matrix_decrease_val:
      005B6B 12 5B 08         [24] 2417 	lcall	_rgb_matrix_decrease_val_noeeprom
      005B6E 02 54 DE         [24] 2418 	ljmp	_mark_dirty
                                   2419 ;------------------------------------------------------------
                                   2420 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function rgb_matrix_increase_speed
                                   2425 ;	-----------------------------------------
      005B71                       2426 _rgb_matrix_increase_speed:
      005B71 12 5B 19         [24] 2427 	lcall	_rgb_matrix_increase_speed_noeeprom
      005B74 02 54 DE         [24] 2428 	ljmp	_mark_dirty
                                   2429 ;------------------------------------------------------------
                                   2430 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2431 ;------------------------------------------------------------
                                   2432 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2433 ;	-----------------------------------------
                                   2434 ;	 function rgb_matrix_decrease_speed
                                   2435 ;	-----------------------------------------
      005B77                       2436 _rgb_matrix_decrease_speed:
      005B77 12 5B 2A         [24] 2437 	lcall	_rgb_matrix_decrease_speed_noeeprom
      005B7A 02 54 DE         [24] 2438 	ljmp	_mark_dirty
                                   2439 ;------------------------------------------------------------
                                   2440 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2441 ;------------------------------------------------------------
                                   2442 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2443 ;------------------------------------------------------------
                                   2444 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2445 ;	-----------------------------------------
                                   2446 ;	 function rgb_matrix_mode
                                   2447 ;	-----------------------------------------
      005B7D                       2448 _rgb_matrix_mode:
      005B7D E5 82            [12] 2449 	mov	a,dpl
      005B7F 90 07 96         [24] 2450 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005B82 12 5B DE         [24] 2451 	lcall	_ak820_outline_0179
      005B85 12 5A 15         [24] 2452 	lcall	_rgb_matrix_mode_noeeprom
      005B88 02 54 DE         [24] 2453 	ljmp	_mark_dirty
                                   2454 ;------------------------------------------------------------
                                   2455 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2456 ;------------------------------------------------------------
                                   2457 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2458 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2459 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2460 ;------------------------------------------------------------
                                   2461 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2462 ;	-----------------------------------------
                                   2463 	.area CSEG    (CODE)
                                   2464 	.area CONST   (CODE)
                                   2465 	.area CONST   (CODE)
      00BFF3                       2466 _sine8_coefficients_10000_290:
      00BFF3 00                    2467 	.db #0x00	; 0
      00BFF4 31                    2468 	.db #0x31	; 49	'1'
      00BFF5 31                    2469 	.db #0x31	; 49	'1'
      00BFF6 29                    2470 	.db #0x29	; 41
      00BFF7 5A                    2471 	.db #0x5a	; 90	'Z'
      00BFF8 1B                    2472 	.db #0x1b	; 27
      00BFF9 75                    2473 	.db #0x75	; 117	'u'
      00BFFA 0A                    2474 	.db #0x0a	; 10
                                   2475 	.area CSEG    (CODE)
                                   2476 	.area XINIT   (CODE)
                                   2477 	.area CABS    (ABS,CODE)
                                   2478 
                                   2479 ; Experimental exact instruction outlining.
                                   2480 	.globl _ak820_outline_0006
                                   2481 	.globl _ak820_outline_0020
                                   2482 	.globl _ak820_outline_0052
                                   2483 	.globl _ak820_outline_0053
                                   2484 	.globl _ak820_outline_0056
                                   2485 	.globl _ak820_outline_0064
                                   2486 	.globl _ak820_outline_0065
                                   2487 	.globl _ak820_outline_0070
                                   2488 	.globl _ak820_outline_0075
                                   2489 	.globl _ak820_outline_0076
                                   2490 	.globl _ak820_outline_0087
                                   2491 	.globl _ak820_outline_0108
                                   2492 	.globl _ak820_outline_0109
                                   2493 	.globl _ak820_outline_0113
                                   2494 	.globl _ak820_outline_0120
                                   2495 	.globl _ak820_outline_0126
                                   2496 	.globl _ak820_outline_0127
                                   2497 	.globl _ak820_outline_0129
                                   2498 	.globl _ak820_outline_0132
                                   2499 	.globl _ak820_outline_0140
                                   2500 	.globl _ak820_outline_0141
                                   2501 	.globl _ak820_outline_0146
                                   2502 	.globl _ak820_outline_0150
                                   2503 	.globl _ak820_outline_0177
                                   2504 	.globl _ak820_outline_0179
                                   2505 	.globl _ak820_outline_0180
                                   2506 	.globl _ak820_outline_0186
                                   2507 	.globl _ak820_outline_0192
                                   2508 	.globl _ak820_outline_0193
                                   2509 
                                   2510 	.area CSEG (CODE)
                                   2511 ; function ak820_outline_0020
      005B8B                       2512 _ak820_outline_0020:
      005B8B 90 07 0C         [24] 2513 	mov	dptr,#_rgb_matrix_config
      005B8E E0               [24] 2514 	movx	a,@dptr
      005B8F 03               [12] 2515 	rr	a
      005B90 03               [12] 2516 	rr	a
      005B91 54 3F            [12] 2517 	anl	a,#0x3f
      005B93 22               [24] 2518 	ret
                                   2519 
                                   2520 	.area CSEG (CODE)
                                   2521 ; function ak820_outline_0052
      005B94                       2522 _ak820_outline_0052:
      005B94 E0               [24] 2523 	movx	a,@dptr
      005B95 FF               [12] 2524 	mov	r7,a
      005B96 90 07 75         [24] 2525 	mov	dptr,#_add_sat_PARM_2
      005B99 74 10            [12] 2526 	mov	a,#0x10
      005B9B F0               [24] 2527 	movx	@dptr,a
      005B9C 8F 82            [24] 2528 	mov	dpl,r7
      005B9E 22               [24] 2529 	ret
                                   2530 
                                   2531 	.area CSEG (CODE)
                                   2532 ; function ak820_outline_0053
      005B9F                       2533 _ak820_outline_0053:
      005B9F E0               [24] 2534 	movx	a,@dptr
      005BA0 FF               [12] 2535 	mov	r7,a
      005BA1 90 07 77         [24] 2536 	mov	dptr,#_sub_sat_PARM_2
      005BA4 74 10            [12] 2537 	mov	a,#0x10
      005BA6 F0               [24] 2538 	movx	@dptr,a
      005BA7 8F 82            [24] 2539 	mov	dpl,r7
      005BA9 22               [24] 2540 	ret
                                   2541 
                                   2542 	.area CSEG (CODE)
                                   2543 ; function ak820_outline_0070
      005BAA                       2544 _ak820_outline_0070:
      005BAA 90 07 0C         [24] 2545 	mov	dptr,#_rgb_matrix_config
      005BAD E0               [24] 2546 	movx	a,@dptr
      005BAE 54 03            [12] 2547 	anl	a,#0x03
      005BB0 22               [24] 2548 	ret
                                   2549 
                                   2550 	.area CSEG (CODE)
                                   2551 ; function ak820_outline_0075
      005BB1                       2552 _ak820_outline_0075:
      005BB1 74 08            [12] 2553 	mov	a,#0x08
      005BB3 F0               [24] 2554 	movx	@dptr,a
      005BB4 E4               [12] 2555 	clr	a
      005BB5 A3               [24] 2556 	inc	dptr
      005BB6 F0               [24] 2557 	movx	@dptr,a
      005BB7 90 07 0C         [24] 2558 	mov	dptr,#_rgb_matrix_config
      005BBA 22               [24] 2559 	ret
                                   2560 
                                   2561 	.area CSEG (CODE)
                                   2562 ; function ak820_outline_0087
      005BBB                       2563 _ak820_outline_0087:
      005BBB 74 18            [12] 2564 	mov	a,#0x18
      005BBD F0               [24] 2565 	movx	@dptr,a
      005BBE E4               [12] 2566 	clr	a
      005BBF A3               [24] 2567 	inc	dptr
      005BC0 F0               [24] 2568 	movx	@dptr,a
      005BC1 A3               [24] 2569 	inc	dptr
      005BC2 F0               [24] 2570 	movx	@dptr,a
      005BC3 22               [24] 2571 	ret
                                   2572 
                                   2573 	.area CSEG (CODE)
                                   2574 ; function ak820_outline_0113
      005BC4                       2575 _ak820_outline_0113:
      005BC4 35 F0            [12] 2576 	addc	a,b
      005BC6 F5 83            [12] 2577 	mov	dph,a
      005BC8 E4               [12] 2578 	clr	a
      005BC9 93               [24] 2579 	movc	a,@a+dptr
      005BCA 22               [24] 2580 	ret
                                   2581 
                                   2582 	.area CSEG (CODE)
                                   2583 ; function ak820_outline_0120
      005BCB                       2584 _ak820_outline_0120:
      005BCB 90 07 0C         [24] 2585 	mov	dptr,#_rgb_matrix_config
      005BCE E0               [24] 2586 	movx	a,@dptr
      005BCF 54 FC            [12] 2587 	anl	a,#0xfc
      005BD1 22               [24] 2588 	ret
                                   2589 
                                   2590 	.area CSEG (CODE)
                                   2591 ; function ak820_outline_0146
      005BD2                       2592 _ak820_outline_0146:
      005BD2 90 07 1B         [24] 2593 	mov	dptr,#_frame_mode
      005BD5 E0               [24] 2594 	movx	a,@dptr
      005BD6 FE               [12] 2595 	mov	r6,a
      005BD7 22               [24] 2596 	ret
                                   2597 
                                   2598 	.area CSEG (CODE)
                                   2599 ; function ak820_outline_0177
      005BD8                       2600 _ak820_outline_0177:
      005BD8 F0               [24] 2601 	movx	@dptr,a
      005BD9 E5 F0            [12] 2602 	mov	a,b
      005BDB A3               [24] 2603 	inc	dptr
      005BDC F0               [24] 2604 	movx	@dptr,a
      005BDD 22               [24] 2605 	ret
                                   2606 
                                   2607 	.area CSEG (CODE)
                                   2608 ; function ak820_outline_0179
      005BDE                       2609 _ak820_outline_0179:
      005BDE F0               [24] 2610 	movx	@dptr,a
      005BDF E0               [24] 2611 	movx	a,@dptr
      005BE0 F5 82            [12] 2612 	mov	dpl,a
      005BE2 22               [24] 2613 	ret
                                   2614 
                                   2615 	.area CSEG (CODE)
                                   2616 ; function ak820_outline_0180
      005BE3                       2617 _ak820_outline_0180:
      005BE3 90 07 10         [24] 2618 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005BE6 E0               [24] 2619 	movx	a,@dptr
      005BE7 23               [12] 2620 	rl	a
      005BE8 23               [12] 2621 	rl	a
      005BE9 54 03            [12] 2622 	anl	a,#0x03
      005BEB 22               [24] 2623 	ret
                                   2624 
                                   2625 	.area CSEG (CODE)
                                   2626 ; function ak820_outline_0186
      005BEC                       2627 _ak820_outline_0186:
      005BEC 90 0E 28         [24] 2628 	mov	dptr,#_memset_PARM_2
      005BEF E4               [12] 2629 	clr	a
      005BF0 F0               [24] 2630 	movx	@dptr,a
      005BF1 90 0E 29         [24] 2631 	mov	dptr,#_memset_PARM_3
      005BF4 22               [24] 2632 	ret
                                   2633 
                                   2634 	.area CSEG (CODE)
                                   2635 ; function ak820_outline_0192
      005BF5                       2636 _ak820_outline_0192:
      005BF5 90 07 1A         [24] 2637 	mov	dptr,#_led_index
      005BF8 E0               [24] 2638 	movx	a,@dptr
      005BF9 22               [24] 2639 	ret
