                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000E                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000E                         68 	.ds 2
      000010                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      000010                         70 	.ds 2
      000012                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000012                         72 	.ds 2
      000014                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000014                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000A                         91 _page_valid:
      00000A                         92 	.ds 1
      00000B                         93 _page_dirty:
      00000B                         94 	.ds 1
      00000C                         95 _storage_failed:
      00000C                         96 	.ds 1
      00000D                         97 _ak820_nvm_ok_sloc0_1_0:
      00000D                         98 	.ds 1
      00000E                         99 _load_page_sloc0_1_0:
      00000E                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00057E                        109 _page_data:
      00057E                        110 	.ds 64
      0005BE                        111 _cached_page:
      0005BE                        112 	.ds 1
      0005BF                        113 _batch_depth:
      0005BF                        114 	.ds 1
      0005C0                        115 _first_failure_stage:
      0005C0                        116 	.ds 1
      0005C1                        117 _nvm_fail_stage_10000_20:
      0005C1                        118 	.ds 1
      0005C2                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005C2                        120 	.ds 2
      0005C4                        121 _crc_byte_PARM_2:
      0005C4                        122 	.ds 1
      0005C5                        123 _crc_byte_crc_10000_25:
      0005C5                        124 	.ds 2
      0005C7                        125 _page_crc_crc_10000_30:
      0005C7                        126 	.ds 2
      0005C9                        127 _write_page_address_10000_32:
      0005C9                        128 	.ds 2
      0005CB                        129 _journal_header_valid_header_10000_39:
      0005CB                        130 	.ds 2
      0005CD                        131 _recover_journal_header_10000_46:
      0005CD                        132 	.ds 9
      0005D6                        133 _ak820_nvm_flush_header_10000_62:
      0005D6                        134 	.ds 9
      0005DF                        135 _ak820_nvm_flush_stage_10000_62:
      0005DF                        136 	.ds 1
      0005E0                        137 _load_page_page_10000_87:
      0005E0                        138 	.ds 1
      0005E1                        139 _read_offset_offset_10000_93:
      0005E1                        140 	.ds 2
      0005E3                        141 _eeprom_read_byte_addr_10000_97:
      0005E3                        142 	.ds 3
      0005E6                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005E6                        144 	.ds 3
      0005E9                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005E9                        146 	.ds 2
      0005EB                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005EB                        148 	.ds 2
      0005ED                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005ED                        150 	.ds 2
      0005EF                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005EF                        152 	.ds 3
      0005F2                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005F2                        154 	.ds 2
      0005F4                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005F4                        156 	.ds 2
      0005F6                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005F6                        158 	.ds 3
      0005F9                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005F9                        160 	.ds 2
      0005FB                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005FB                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      004066                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      004066 E5 82            [12]  215 	mov	a,dpl
      004068 90 05 C1         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      00406B F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      00406C 20 0C 08         [24]  219 	jb	_storage_failed,00102$
      00406F 90 05 C1         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      004072 E0               [24]  221 	movx	a,@dptr
      004073 90 05 C0         [24]  222 	mov	dptr,#_first_failure_stage
      004076 F0               [24]  223 	movx	@dptr,a
      004077                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      004077 D2 0C            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      004079 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      00407A                        239 _ak820_nvm_diagnostic:
      00407A 12 38 42         [24]  240 	lcall	_ak820_outline_0108
      00407D 90 05 C2         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      004080 12 38 47         [24]  242 	lcall	_ak820_outline_0109
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      004083 90 05 C2         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      004086 12 37 F9         [24]  245 	lcall	_ak820_outline_0056
      004089 A2 0C            [12]  246 	mov	c,_storage_failed
      00408B E4               [12]  247 	clr	a
      00408C 33               [12]  248 	rlc	a
      00408D 12 48 38         [24]  249 	lcall	_ak820_outline_0123
      004090 12 48 19         [24]  250 	lcall	_ak820_outline_0066
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      004093 A3               [24]  252 	inc	dptr
      004094 A2 0A            [12]  253 	mov	c,_page_valid
      004096 E4               [12]  254 	clr	a
      004097 33               [12]  255 	rlc	a
      004098 12 47 ED         [24]  256 	lcall	_ak820_outline_0025
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      00409B A2 0B            [12]  258 	mov	c,_page_dirty
      00409D E4               [12]  259 	clr	a
      00409E 33               [12]  260 	rlc	a
      00409F F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      0040A0 74 03            [12]  263 	mov	a,#0x03
      0040A2 12 48 68         [24]  264 	lcall	_ak820_outline_0167
      0040A5 90 05 BF         [24]  265 	mov	dptr,#_batch_depth
      0040A8 E0               [24]  266 	movx	a,@dptr
      0040A9 12 38 4C         [24]  267 	lcall	_ak820_outline_0126
      0040AC F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      0040AD 74 04            [12]  270 	mov	a,#0x04
      0040AF 12 48 68         [24]  271 	lcall	_ak820_outline_0167
      0040B2 90 05 BE         [24]  272 	mov	dptr,#_cached_page
      0040B5 E0               [24]  273 	movx	a,@dptr
      0040B6 12 38 4C         [24]  274 	lcall	_ak820_outline_0126
      0040B9 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      0040BA 12 47 E3         [24]  277 	lcall	_ak820_outline_0012
      0040BD E4               [12]  278 	clr	a
      0040BE F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      0040BF 74 06            [12]  281 	mov	a,#0x06
      0040C1 12 48 48         [24]  282 	lcall	_ak820_outline_0143
      0040C4 90 05 C0         [24]  283 	mov	dptr,#_first_failure_stage
      0040C7 E0               [24]  284 	movx	a,@dptr
      0040C8 12 48 38         [24]  285 	lcall	_ak820_outline_0123
      0040CB F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      0040CC 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      0040CD                        300 _crc_byte:
      0040CD 12 38 42         [24]  301 	lcall	_ak820_outline_0108
      0040D0 90 05 C5         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      0040D3 12 38 47         [24]  303 	lcall	_ak820_outline_0109
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      0040D6 90 05 C4         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      0040D9 E0               [24]  306 	movx	a,@dptr
      0040DA FF               [12]  307 	mov	r7,a
      0040DB 7E 00            [12]  308 	mov	r6,#0x00
      0040DD 90 05 C5         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      0040E0 E0               [24]  310 	movx	a,@dptr
      0040E1 6E               [12]  311 	xrl	a,r6
      0040E2 F0               [24]  312 	movx	@dptr,a
      0040E3 A3               [24]  313 	inc	dptr
      0040E4 E0               [24]  314 	movx	a,@dptr
      0040E5 6F               [12]  315 	xrl	a,r7
      0040E6 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      0040E7 7F 00            [12]  318 	mov	r7,#0x00
      0040E9                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      0040E9 90 05 C5         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      0040EC 12 48 26         [24]  322 	lcall	_ak820_outline_0099
      0040EF 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      0040F2 ED               [12]  324 	mov	a,r5
      0040F3 2D               [12]  325 	add	a,r5
      0040F4 FB               [12]  326 	mov	r3,a
      0040F5 EE               [12]  327 	mov	a,r6
      0040F6 33               [12]  328 	rlc	a
      0040F7 FC               [12]  329 	mov	r4,a
      0040F8 63 03 21         [24]  330 	xrl	ar3,#0x21
      0040FB 63 04 10         [24]  331 	xrl	ar4,#0x10
      0040FE 80 06            [24]  332 	sjmp	00107$
      004100                        333 00106$:
      004100 ED               [12]  334 	mov	a,r5
      004101 2D               [12]  335 	add	a,r5
      004102 FB               [12]  336 	mov	r3,a
      004103 EE               [12]  337 	mov	a,r6
      004104 33               [12]  338 	rlc	a
      004105 FC               [12]  339 	mov	r4,a
      004106                        340 00107$:
      004106 90 05 C5         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      004109 12 38 2A         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      00410C 0F               [12]  344 	inc	r7
      00410D BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      004110 12 33 FC         [24]  347 	lcall	_ak820_outline_0131
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      004113 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      004114                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      004114 90 05 C7         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      004117 74 FF            [12]  363 	mov	a,#0xff
      004119 F0               [24]  364 	movx	@dptr,a
      00411A A3               [24]  365 	inc	dptr
      00411B F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      00411C 7F 00            [12]  368 	mov	r7,#0x00
      00411E                        369 00102$:
      00411E 90 05 C7         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      004121 12 48 26         [24]  371 	lcall	_ak820_outline_0099
      004124 12 48 2C         [24]  372 	lcall	_ak820_outline_0111
      004127 90 05 C4         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      00412A F0               [24]  374 	movx	@dptr,a
      00412B 12 38 5C         [24]  375 	lcall	_ak820_outline_0141
      00412E C0 07            [24]  376 	push	ar7
      004130 12 40 CD         [24]  377 	lcall	_crc_byte
      004133 AD 82            [24]  378 	mov	r5, dpl
      004135 AE 83            [24]  379 	mov	r6, dph
      004137 D0 07            [24]  380 	pop	ar7
      004139 90 05 C7         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      00413C 12 48 6E         [24]  382 	lcall	_ak820_outline_0169
      00413F 0F               [12]  383 	inc	r7
      004140 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      004143 12 38 5C         [24]  386 	lcall	_ak820_outline_0141
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      004146 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      004147                        399 _write_page:
      004147 12 38 42         [24]  400 	lcall	_ak820_outline_0108
      00414A 90 05 C9         [24]  401 	mov	dptr,#_write_page_address_10000_32
      00414D 12 38 47         [24]  402 	lcall	_ak820_outline_0109
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      004150 90 05 C9         [24]  404 	mov	dptr,#_write_page_address_10000_32
      004153 12 37 BA         [24]  405 	lcall	_ak820_outline_0006
      004156 C0 07            [24]  406 	push	ar7
      004158 C0 06            [24]  407 	push	ar6
      00415A 12 39 B8         [24]  408 	lcall	_ak820_flash_erase
      00415D E5 82            [12]  409 	mov	a, dpl
      00415F D0 06            [24]  410 	pop	ar6
      004161 D0 07            [24]  411 	pop	ar7
      004163 70 03            [24]  412 	jnz	00102$
      004165 F5 82            [12]  413 	mov	dpl,a
      004167 22               [24]  414 	ret
      004168                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      004168 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      00416B 74 7E            [12]  418 	mov	a,#_page_data
      00416D F0               [24]  419 	movx	@dptr,a
      00416E 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      004170 A3               [24]  421 	inc	dptr
      004171 12 48 19         [24]  422 	lcall	_ak820_outline_0066
      004174 12 3A CC         [24]  423 	lcall	_ak820_flash_program_page
      004177 E5 82            [12]  424 	mov	a, dpl
      004179 70 03            [24]  425 	jnz	00120$
      00417B F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00417D 22               [24]  428 	ret
      00417E                        429 00120$:
      00417E 7F 00            [12]  430 	mov	r7,#0x00
      004180                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      004180 8F 05            [24]  433 	mov	ar5,r7
      004182 7E 00            [12]  434 	mov	r6,#0x00
      004184 90 05 C9         [24]  435 	mov	dptr,#_write_page_address_10000_32
      004187 12 38 61         [24]  436 	lcall	_ak820_outline_0147
      00418A ED               [12]  437 	mov	a,r5
      00418B 2B               [12]  438 	add	a, r3
      00418C FB               [12]  439 	mov	r3,a
      00418D EE               [12]  440 	mov	a,r6
      00418E 3C               [12]  441 	addc	a, r4
      00418F FC               [12]  442 	mov	r4,a
      004190 12 33 FC         [24]  443 	lcall	_ak820_outline_0131
      004193 12 38 AB         [24]  444 	lcall	_ak820_flash_read
      004196 AE 82            [24]  445 	mov	r6, dpl
      004198 12 48 2C         [24]  446 	lcall	_ak820_outline_0111
      00419B FD               [12]  447 	mov	r5,a
      00419C EE               [12]  448 	mov	a,r6
      00419D B5 05 02         [24]  449 	cjne	a,ar5,00149$
      0041A0 80 04            [24]  450 	sjmp	00109$
      0041A2                        451 00149$:
      0041A2 75 82 00         [24]  452 	mov	dpl, #0x00
      0041A5 22               [24]  453 	ret
      0041A6                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041A6 0F               [12]  456 	inc	r7
      0041A7 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      0041AA 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      0041AD 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      0041AE                        472 _journal_header_valid:
      0041AE 12 38 42         [24]  473 	lcall	_ak820_outline_0108
      0041B1 90 05 CB         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      0041B4 12 38 47         [24]  475 	lcall	_ak820_outline_0109
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      0041B7 90 05 CB         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      0041BA 12 37 BA         [24]  478 	lcall	_ak820_outline_0006
      0041BD E0               [24]  479 	movx	a,@dptr
      0041BE FD               [12]  480 	mov	r5,a
      0041BF BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      0041C2 80 04            [24]  482 	sjmp	00116$
      0041C4                        483 00138$:
      0041C4 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      0041C7 22               [24]  486 	ret
      0041C8                        487 00116$:
      0041C8 7D 01            [12]  488 	mov	r5,#0x01
      0041CA                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      0041CA ED               [12]  491 	mov	a,r5
      0041CB 12 37 CE         [24]  492 	lcall	_ak820_outline_0013
      0041CE FC               [12]  493 	mov	r4,a
      0041CF 8D 02            [24]  494 	mov	ar2,r5
      0041D1 7B 00            [12]  495 	mov	r3,#0x00
      0041D3 74 04            [12]  496 	mov	a,#0x04
      0041D5 2A               [12]  497 	add	a, r2
      0041D6 FA               [12]  498 	mov	r2,a
      0041D7 E4               [12]  499 	clr	a
      0041D8 3B               [12]  500 	addc	a, r3
      0041D9 FB               [12]  501 	mov	r3,a
      0041DA EA               [12]  502 	mov	a,r2
      0041DB 2E               [12]  503 	add	a, r6
      0041DC F5 82            [12]  504 	mov	dpl,a
      0041DE EB               [12]  505 	mov	a,r3
      0041DF 3F               [12]  506 	addc	a, r7
      0041E0 F5 83            [12]  507 	mov	dph,a
      0041E2 E0               [24]  508 	movx	a,@dptr
      0041E3 62 04            [12]  509 	xrl	ar4,a
      0041E5 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      0041E8 80 04            [24]  511 	sjmp	00107$
      0041EA                        512 00139$:
      0041EA 75 82 00         [24]  513 	mov	dpl, #0x00
      0041ED 22               [24]  514 	ret
      0041EE                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      0041EE 0D               [12]  517 	inc	r5
      0041EF BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      0041F2 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      0041F5 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      0041F6                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      0041F6 7F 00            [12]  537 	mov	r7,#0x00
      0041F8                        538 00115$:
      0041F8 EF               [12]  539 	mov	a,r7
      0041F9 24 CD            [12]  540 	add	a, #_recover_journal_header_10000_46
      0041FB FD               [12]  541 	mov	r5,a
      0041FC E4               [12]  542 	clr	a
      0041FD 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      0041FF FE               [12]  544 	mov	r6,a
      004200 8F 04            [24]  545 	mov	ar4,r7
      004202 7B 00            [12]  546 	mov	r3,#0x00
      004204 74 40            [12]  547 	mov	a,#0x40
      004206 2C               [12]  548 	add	a, r4
      004207 FC               [12]  549 	mov	r4,a
      004208 74 EF            [12]  550 	mov	a,#0xef
      00420A 3B               [12]  551 	addc	a, r3
      00420B FB               [12]  552 	mov	r3,a
      00420C 12 48 74         [24]  553 	lcall	_ak820_outline_0189
      00420F 12 38 AB         [24]  554 	lcall	_ak820_flash_read
      004212 AC 82            [24]  555 	mov	r4, dpl
      004214 12 48 1F         [24]  556 	lcall	_ak820_outline_0069
      004217 0F               [12]  557 	inc	r7
      004218 BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      00421B 90 05 CD         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      00421E 12 41 AE         [24]  561 	lcall	_journal_header_valid
      004221 E5 82            [12]  562 	mov	a, dpl
      004223 70 01            [24]  563 	jnz	00103$
      004225 22               [24]  564 	ret
      004226                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      004226 90 05 CE         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      004229 E0               [24]  568 	movx	a,@dptr
      00422A FF               [12]  569 	mov	r7,a
      00422B 7E 00            [12]  570 	mov	r6,#0x00
      00422D 90 05 CF         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      004230 E0               [24]  572 	movx	a,@dptr
      004231 FC               [12]  573 	mov	r4,a
      004232 E4               [12]  574 	clr	a
      004233 42 07            [12]  575 	orl	ar7,a
      004235 EC               [12]  576 	mov	a,r4
      004236 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      004238 90 05 D0         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      00423B E0               [24]  580 	movx	a,@dptr
      00423C FD               [12]  581 	mov	r5,a
      00423D 7C 00            [12]  582 	mov	r4,#0x00
      00423F 90 05 D1         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      004242 E0               [24]  584 	movx	a,@dptr
      004243 FA               [12]  585 	mov	r2,a
      004244 E4               [12]  586 	clr	a
      004245 12 48 4E         [24]  587 	lcall	_ak820_outline_0148
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      004248 C3               [12]  589 	clr	c
      004249 EF               [12]  590 	mov	a,r7
      00424A 94 A0            [12]  591 	subb	a,#0xa0
      00424C EE               [12]  592 	mov	a,r6
      00424D 94 00            [12]  593 	subb	a,#0x00
      00424F 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      004251 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      004254 02 40 66         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      004257                        600 00134$:
      004257 7B 00            [12]  601 	mov	r3,#0x00
      004259                        602 00117$:
      004259 C0 05            [24]  603 	push	ar5
      00425B C0 04            [24]  604 	push	ar4
      00425D EB               [12]  605 	mov	a,r3
      00425E 24 7E            [12]  606 	add	a, #_page_data
      004260 F9               [12]  607 	mov	r1,a
      004261 E4               [12]  608 	clr	a
      004262 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      004264 FA               [12]  610 	mov	r2,a
      004265 8B 00            [24]  611 	mov	ar0,r3
      004267 7D 00            [12]  612 	mov	r5,#0x00
      004269 74 EF            [12]  613 	mov	a,#0xef
      00426B 2D               [12]  614 	add	a, r5
      00426C FD               [12]  615 	mov	r5,a
      00426D 88 82            [24]  616 	mov	dpl, r0
      00426F 8D 83            [24]  617 	mov	dph, r5
      004271 12 38 AB         [24]  618 	lcall	_ak820_flash_read
      004274 AD 82            [24]  619 	mov	r5, dpl
      004276 12 48 5E         [24]  620 	lcall	_ak820_outline_0163
      004279 ED               [12]  621 	mov	a,r5
      00427A F0               [24]  622 	movx	@dptr,a
      00427B 0B               [12]  623 	inc	r3
      00427C BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      00427F 80 06            [24]  625 	sjmp	00191$
      004281                        626 00190$:
      004281 D0 04            [24]  627 	pop	ar4
      004283 D0 05            [24]  628 	pop	ar5
      004285 80 D2            [24]  629 	sjmp	00117$
      004287                        630 00191$:
      004287 D0 04            [24]  631 	pop	ar4
      004289 D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      00428B C0 07            [24]  634 	push	ar7
      00428D C0 06            [24]  635 	push	ar6
      00428F C0 05            [24]  636 	push	ar5
      004291 C0 04            [24]  637 	push	ar4
      004293 12 41 14         [24]  638 	lcall	_page_crc
      004296 AA 82            [24]  639 	mov	r2, dpl
      004298 AB 83            [24]  640 	mov	r3, dph
      00429A D0 04            [24]  641 	pop	ar4
      00429C D0 05            [24]  642 	pop	ar5
      00429E D0 06            [24]  643 	pop	ar6
      0042A0 D0 07            [24]  644 	pop	ar7
      0042A2 EA               [12]  645 	mov	a,r2
      0042A3 B5 05 06         [24]  646 	cjne	a,ar5,00192$
      0042A6 EB               [12]  647 	mov	a,r3
      0042A7 B5 04 02         [24]  648 	cjne	a,ar4,00192$
      0042AA 80 06            [24]  649 	sjmp	00113$
      0042AC                        650 00192$:
      0042AC 75 82 02         [24]  651 	mov	dpl, #0x02
      0042AF 02 40 66         [24]  652 	ljmp	_nvm_fail
      0042B2                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      0042B2 EE               [12]  655 	mov	a,r6
      0042B3 54 03            [12]  656 	anl	a,#0x03
      0042B5 A2 E0            [12]  657 	mov	c,acc.0
      0042B7 CF               [12]  658 	xch	a,r7
      0042B8 13               [12]  659 	rrc	a
      0042B9 CF               [12]  660 	xch	a,r7
      0042BA 13               [12]  661 	rrc	a
      0042BB A2 E0            [12]  662 	mov	c,acc.0
      0042BD CF               [12]  663 	xch	a,r7
      0042BE 13               [12]  664 	rrc	a
      0042BF CF               [12]  665 	xch	a,r7
      0042C0 13               [12]  666 	rrc	a
      0042C1 CF               [12]  667 	xch	a,r7
      0042C2 24 C7            [12]  668 	add	a,#0xc7
      0042C4 FE               [12]  669 	mov	r6,a
      0042C5 12 48 63         [24]  670 	lcall	_ak820_outline_0164
      0042C8 12 41 47         [24]  671 	lcall	_write_page
      0042CB E5 82            [12]  672 	mov	a, dpl
      0042CD 70 06            [24]  673 	jnz	00110$
      0042CF 75 82 03         [24]  674 	mov	dpl, #0x03
      0042D2 02 40 66         [24]  675 	ljmp	_nvm_fail
      0042D5                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      0042D5 90 EF 40         [24]  678 	mov	dptr,#0xef40
      0042D8 12 39 B8         [24]  679 	lcall	_ak820_flash_erase
      0042DB E5 82            [12]  680 	mov	a, dpl
      0042DD 70 06            [24]  681 	jnz	00119$
      0042DF 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      0042E2 02 40 66         [24]  684 	ljmp	_nvm_fail
      0042E5                        685 00119$:
      0042E5 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      0042E6                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      0042E6 C2 0C            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      0042E8 90 05 C0         [24]  699 	mov	dptr,#_first_failure_stage
      0042EB E4               [12]  700 	clr	a
      0042EC F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      0042ED C2 0B            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      0042EF C2 0A            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      0042F1 90 05 BF         [24]  708 	mov	dptr,#_batch_depth
      0042F4 E4               [12]  709 	clr	a
      0042F5 F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      0042F6 12 41 F6         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      0042F9 02 2A B7         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      0042FC                        723 _ak820_nvm_ok:
      0042FC A2 0C            [12]  724 	mov	c,_storage_failed
      0042FE B3               [12]  725 	cpl	c
      0042FF 92 0D            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004301 12 38 67         [24]  727 	lcall	_ak820_outline_0150
      004304 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      004305                        736 _ak820_nvm_schema_fault:
      004305 75 82 10         [24]  737 	mov	dpl, #0x10
      004308 02 40 66         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      00430B                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      00430B 30 0B 03         [24]  753 	jnb	_page_dirty,00101$
      00430E 30 0C 01         [24]  754 	jnb	_storage_failed,00102$
      004311                        755 00101$:
      004311 22               [24]  756 	ret
      004312                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      004312 12 41 14         [24]  759 	lcall	_page_crc
      004315 12 48 43         [24]  760 	lcall	_ak820_outline_0140
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      004318 90 05 D6         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00431B 74 A5            [12]  763 	mov	a,#0xa5
      00431D F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      00431E 90 05 BE         [24]  766 	mov	dptr,#_cached_page
      004321 E0               [24]  767 	movx	a,@dptr
      004322 90 05 D7         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      004325 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      004326 90 05 D8         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004329 E4               [12]  772 	clr	a
      00432A F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      00432B 8E 05            [24]  775 	mov	ar5,r6
      00432D 90 05 D9         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004330 ED               [12]  777 	mov	a,r5
      004331 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      004332 8F 06            [24]  780 	mov	ar6,r7
      004334 90 05 DA         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      004337 EE               [12]  782 	mov	a,r6
      004338 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      004339 7F 01            [12]  785 	mov	r7,#0x01
      00433B                        786 00128$:
      00433B 8F 06            [24]  787 	mov	ar6,r7
      00433D EE               [12]  788 	mov	a,r6
      00433E 24 04            [12]  789 	add	a,#0x04
      004340 FE               [12]  790 	mov	r6,a
      004341 33               [12]  791 	rlc	a
      004342 95 E0            [12]  792 	subb	a,acc
      004344 FD               [12]  793 	mov	r5,a
      004345 EE               [12]  794 	mov	a,r6
      004346 24 D6            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      004348 FE               [12]  796 	mov	r6,a
      004349 ED               [12]  797 	mov	a,r5
      00434A 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      00434C FD               [12]  799 	mov	r5,a
      00434D 12 47 FC         [24]  800 	lcall	_ak820_outline_0045
      004350 FC               [12]  801 	mov	r4,a
      004351 63 04 FF         [24]  802 	xrl	ar4,#0xff
      004354 8E 82            [24]  803 	mov	dpl,r6
      004356 8D 83            [24]  804 	mov	dph,r5
      004358 EC               [12]  805 	mov	a,r4
      004359 F0               [24]  806 	movx	@dptr,a
      00435A 0F               [12]  807 	inc	r7
      00435B BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      00435E 90 05 DF         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004361 74 05            [12]  811 	mov	a,#0x05
      004363 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004364 90 EF 40         [24]  814 	mov	dptr,#0xef40
      004367 12 39 B8         [24]  815 	lcall	_ak820_flash_erase
      00436A E5 82            [12]  816 	mov	a, dpl
      00436C 70 03            [24]  817 	jnz	00269$
      00436E 02 44 55         [24]  818 	ljmp	00127$
      004371                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004371 90 05 DF         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004374 74 06            [12]  822 	mov	a,#0x06
      004376 F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004377 7F 00            [12]  825 	mov	r7,#0x00
      004379                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004379 12 48 08         [24]  828 	lcall	_ak820_outline_0057
      00437C 12 38 AB         [24]  829 	lcall	_ak820_flash_read
      00437F E5 82            [12]  830 	mov	a, dpl
      004381 60 03            [24]  831 	jz	00270$
      004383 02 44 55         [24]  832 	ljmp	00127$
      004386                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004386 0F               [12]  835 	inc	r7
      004387 BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      00438A 90 05 DF         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00438D 74 07            [12]  839 	mov	a,#0x07
      00438F F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      004390 90 EF 00         [24]  842 	mov	dptr,#0xef00
      004393 12 41 47         [24]  843 	lcall	_write_page
      004396 E5 82            [12]  844 	mov	a, dpl
      004398 70 03            [24]  845 	jnz	00273$
      00439A 02 44 55         [24]  846 	ljmp	00127$
      00439D                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      00439D 90 05 DF         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0043A0 74 08            [12]  850 	mov	a,#0x08
      0043A2 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0043A3 7F 01            [12]  853 	mov	r7,#0x01
      0043A5                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      0043A5 12 47 FC         [24]  856 	lcall	_ak820_outline_0045
      0043A8 FE               [12]  857 	mov	r6,a
      0043A9 60 23            [24]  858 	jz	00133$
      0043AB 8F 05            [24]  859 	mov	ar5,r7
      0043AD 7C 00            [12]  860 	mov	r4,#0x00
      0043AF 74 40            [12]  861 	mov	a,#0x40
      0043B1 2D               [12]  862 	add	a, r5
      0043B2 FD               [12]  863 	mov	r5,a
      0043B3 74 EF            [12]  864 	mov	a,#0xef
      0043B5 3C               [12]  865 	addc	a, r4
      0043B6 FC               [12]  866 	mov	r4,a
      0043B7 90 04 F2         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      0043BA EE               [12]  868 	mov	a,r6
      0043BB F0               [24]  869 	movx	@dptr,a
      0043BC 8D 82            [24]  870 	mov	dpl, r5
      0043BE 8C 83            [24]  871 	mov	dph, r4
      0043C0 C0 07            [24]  872 	push	ar7
      0043C2 12 3A 18         [24]  873 	lcall	_ak820_flash_program
      0043C5 E5 82            [12]  874 	mov	a, dpl
      0043C7 D0 07            [24]  875 	pop	ar7
      0043C9 70 03            [24]  876 	jnz	00275$
      0043CB 02 44 55         [24]  877 	ljmp	00127$
      0043CE                        878 00275$:
      0043CE                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      0043CE 0F               [12]  881 	inc	r7
      0043CF BF 09 D3         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      0043D2 90 05 DF         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0043D5 74 09            [12]  885 	mov	a,#0x09
      0043D7 F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      0043D8 7F 01            [12]  888 	mov	r7,#0x01
      0043DA                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      0043DA 12 48 08         [24]  891 	lcall	_ak820_outline_0057
      0043DD 12 38 AB         [24]  892 	lcall	_ak820_flash_read
      0043E0 AE 82            [24]  893 	mov	r6, dpl
      0043E2 12 47 FC         [24]  894 	lcall	_ak820_outline_0045
      0043E5 FD               [12]  895 	mov	r5,a
      0043E6 EE               [12]  896 	mov	a,r6
      0043E7 B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      0043EA 0F               [12]  899 	inc	r7
      0043EB BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      0043EE 90 05 DF         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0043F1 74 0A            [12]  903 	mov	a,#0x0a
      0043F3 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      0043F4 90 05 D6         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0043F7 E0               [24]  907 	movx	a,@dptr
      0043F8 90 04 F2         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      0043FB F0               [24]  909 	movx	@dptr,a
      0043FC 90 EF 40         [24]  910 	mov	dptr,#0xef40
      0043FF 12 3A 18         [24]  911 	lcall	_ak820_flash_program
      004402 E5 82            [12]  912 	mov	a, dpl
      004404 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004406 90 05 DF         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004409 74 0B            [12]  916 	mov	a,#0x0b
      00440B F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      00440C 90 EF 40         [24]  919 	mov	dptr,#0xef40
      00440F 12 38 AB         [24]  920 	lcall	_ak820_flash_read
      004412 AF 82            [24]  921 	mov	r7, dpl
      004414 90 05 D6         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004417 E0               [24]  923 	movx	a,@dptr
      004418 FE               [12]  924 	mov	r6,a
      004419 EF               [12]  925 	mov	a,r7
      00441A B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      00441D 90 05 DF         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004420 74 0C            [12]  929 	mov	a,#0x0c
      004422 F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      004423 90 05 BE         [24]  932 	mov	dptr,#_cached_page
      004426 E0               [24]  933 	movx	a,@dptr
      004427 FE               [12]  934 	mov	r6,a
      004428 E4               [12]  935 	clr	a
      004429 C3               [12]  936 	clr	c
      00442A CE               [12]  937 	xch	a,r6
      00442B 13               [12]  938 	rrc	a
      00442C CE               [12]  939 	xch	a,r6
      00442D 13               [12]  940 	rrc	a
      00442E A2 E0            [12]  941 	mov	c,acc.0
      004430 CE               [12]  942 	xch	a,r6
      004431 13               [12]  943 	rrc	a
      004432 CE               [12]  944 	xch	a,r6
      004433 13               [12]  945 	rrc	a
      004434 CE               [12]  946 	xch	a,r6
      004435 24 C7            [12]  947 	add	a,#0xc7
      004437 FF               [12]  948 	mov	r7,a
      004438 12 48 38         [24]  949 	lcall	_ak820_outline_0123
      00443B 12 41 47         [24]  950 	lcall	_write_page
      00443E E5 82            [12]  951 	mov	a, dpl
      004440 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      004442 90 05 DF         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004445 74 0D            [12]  955 	mov	a,#0x0d
      004447 F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      004448 90 EF 40         [24]  958 	mov	dptr,#0xef40
      00444B 12 39 B8         [24]  959 	lcall	_ak820_flash_erase
      00444E E5 82            [12]  960 	mov	a, dpl
      004450 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      004452 C2 0B            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      004454 22               [24]  967 	ret
      004455                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      004455 90 05 DF         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004458 E0               [24]  971 	movx	a,@dptr
      004459 F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      00445B 02 40 66         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      00445E                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      00445E 90 05 BF         [24]  984 	mov	dptr,#_batch_depth
      004461 E0               [24]  985 	movx	a,@dptr
      004462 FF               [12]  986 	mov	r7,a
      004463 BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      004466 75 82 0F         [24]  988 	mov	dpl, #0x0f
      004469 02 40 66         [24]  989 	ljmp	_nvm_fail
      00446C                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      00446C 90 05 BF         [24]  992 	mov	dptr,#_batch_depth
      00446F EF               [12]  993 	mov	a,r7
      004470 04               [12]  994 	inc	a
      004471 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004472 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      004473                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      004473 90 05 BF         [24] 1007 	mov	dptr,#_batch_depth
      004476 E0               [24] 1008 	movx	a,@dptr
      004477 FF               [12] 1009 	mov	r7,a
      004478 E0               [24] 1010 	movx	a,@dptr
      004479 60 06            [24] 1011 	jz	00102$
      00447B EF               [12] 1012 	mov	a,r7
      00447C 14               [12] 1013 	dec	a
      00447D 90 05 BF         [24] 1014 	mov	dptr,#_batch_depth
      004480 F0               [24] 1015 	movx	@dptr,a
      004481                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      004481 90 05 BF         [24] 1018 	mov	dptr,#_batch_depth
      004484 E0               [24] 1019 	movx	a,@dptr
      004485 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004487 02 43 0B         [24] 1022 	ljmp	_ak820_nvm_flush
      00448A                       1023 00105$:
      00448A 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      00448B                       1035 _load_page:
      00448B E5 82            [12] 1036 	mov	a,dpl
      00448D 90 05 E0         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      004490 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      004491 30 0A 17         [24] 1040 	jnb	_page_valid,00102$
      004494 90 05 BE         [24] 1041 	mov	dptr,#_cached_page
      004497 E0               [24] 1042 	movx	a,@dptr
      004498 FF               [12] 1043 	mov	r7,a
      004499 90 05 E0         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      00449C E0               [24] 1045 	movx	a,@dptr
      00449D FE               [12] 1046 	mov	r6,a
      00449E EF               [12] 1047 	mov	a,r7
      00449F B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      0044A2 A2 0C            [12] 1049 	mov	c,_storage_failed
      0044A4 B3               [12] 1050 	cpl	c
      0044A5 92 0E            [24] 1051 	mov  _load_page_sloc0_1_0,c
      0044A7 12 38 67         [24] 1052 	lcall	_ak820_outline_0150
      0044AA 22               [24] 1053 	ret
      0044AB                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      0044AB 12 43 0B         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      0044AE 30 0C 04         [24] 1058 	jnb	_storage_failed,00119$
      0044B1 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044B4 22               [24] 1061 	ret
      0044B5                       1062 00119$:
      0044B5 7F 00            [12] 1063 	mov	r7,#0x00
      0044B7                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      0044B7 EF               [12] 1066 	mov	a,r7
      0044B8 24 7E            [12] 1067 	add	a, #_page_data
      0044BA FD               [12] 1068 	mov	r5,a
      0044BB E4               [12] 1069 	clr	a
      0044BC 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      0044BE FE               [12] 1071 	mov	r6,a
      0044BF 90 05 E0         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      0044C2 E0               [24] 1073 	movx	a,@dptr
      0044C3 FC               [12] 1074 	mov	r4,a
      0044C4 FA               [12] 1075 	mov	r2,a
      0044C5 E4               [12] 1076 	clr	a
      0044C6 C3               [12] 1077 	clr	c
      0044C7 CA               [12] 1078 	xch	a,r2
      0044C8 13               [12] 1079 	rrc	a
      0044C9 CA               [12] 1080 	xch	a,r2
      0044CA 13               [12] 1081 	rrc	a
      0044CB A2 E0            [12] 1082 	mov	c,acc.0
      0044CD CA               [12] 1083 	xch	a,r2
      0044CE 13               [12] 1084 	rrc	a
      0044CF CA               [12] 1085 	xch	a,r2
      0044D0 13               [12] 1086 	rrc	a
      0044D1 CA               [12] 1087 	xch	a,r2
      0044D2 24 C7            [12] 1088 	add	a,#0xc7
      0044D4 FB               [12] 1089 	mov	r3,a
      0044D5 8F 01            [24] 1090 	mov	ar1,r7
      0044D7 89 00            [24] 1091 	mov	ar0,r1
      0044D9 79 00            [12] 1092 	mov	r1,#0x00
      0044DB E8               [12] 1093 	mov	a,r0
      0044DC 2A               [12] 1094 	add	a, r2
      0044DD FA               [12] 1095 	mov	r2,a
      0044DE E9               [12] 1096 	mov	a,r1
      0044DF 3B               [12] 1097 	addc	a, r3
      0044E0 FB               [12] 1098 	mov	r3,a
      0044E1 12 48 54         [24] 1099 	lcall	_ak820_outline_0149
      0044E4 12 38 AB         [24] 1100 	lcall	_ak820_flash_read
      0044E7 AB 82            [24] 1101 	mov	r3, dpl
      0044E9 12 38 5C         [24] 1102 	lcall	_ak820_outline_0141
      0044EC EB               [12] 1103 	mov	a,r3
      0044ED F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0044EE 0F               [12] 1106 	inc	r7
      0044EF BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      0044F2 90 05 BE         [24] 1109 	mov	dptr,#_cached_page
      0044F5 EC               [12] 1110 	mov	a,r4
      0044F6 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      0044F7 D2 0A            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      0044F9 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      0044FC 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      0044FD                       1128 _read_offset:
      0044FD 12 38 42         [24] 1129 	lcall	_ak820_outline_0108
      004500 90 05 E1         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      004503 12 38 47         [24] 1131 	lcall	_ak820_outline_0109
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004506 90 05 E1         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      004509 12 37 F9         [24] 1134 	lcall	_ak820_outline_0056
      00450C C3               [12] 1135 	clr	c
      00450D 94 28            [12] 1136 	subb	a,#0x28
      00450F 40 04            [24] 1137 	jc	00102$
      004511 75 82 00         [24] 1138 	mov	dpl, #0x00
      004514 22               [24] 1139 	ret
      004515                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004515 30 0A 34         [24] 1142 	jnb	_page_valid,00104$
      004518 8E 04            [24] 1143 	mov	ar4,r6
      00451A EF               [12] 1144 	mov	a,r7
      00451B A2 E7            [12] 1145 	mov	c,acc.7
      00451D CC               [12] 1146 	xch	a,r4
      00451E 33               [12] 1147 	rlc	a
      00451F CC               [12] 1148 	xch	a,r4
      004520 33               [12] 1149 	rlc	a
      004521 A2 E7            [12] 1150 	mov	c,acc.7
      004523 CC               [12] 1151 	xch	a,r4
      004524 33               [12] 1152 	rlc	a
      004525 CC               [12] 1153 	xch	a,r4
      004526 33               [12] 1154 	rlc	a
      004527 CC               [12] 1155 	xch	a,r4
      004528 54 03            [12] 1156 	anl	a,#0x03
      00452A FD               [12] 1157 	mov	r5,a
      00452B 90 05 BE         [24] 1158 	mov	dptr,#_cached_page
      00452E E0               [24] 1159 	movx	a,@dptr
      00452F FA               [12] 1160 	mov	r2,a
      004530 7B 00            [12] 1161 	mov	r3,#0x00
      004532 EC               [12] 1162 	mov	a,r4
      004533 B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      004536 ED               [12] 1164 	mov	a,r5
      004537 B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00453A 74 3F            [12] 1167 	mov	a,#0x3f
      00453C 5E               [12] 1168 	anl	a,r6
      00453D 7D 00            [12] 1169 	mov	r5,#0x00
      00453F 24 7E            [12] 1170 	add	a, #_page_data
      004541 F5 82            [12] 1171 	mov	dpl,a
      004543 ED               [12] 1172 	mov	a,r5
      004544 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      004546 F5 83            [12] 1174 	mov	dph,a
      004548 E0               [24] 1175 	movx	a,@dptr
      004549 F5 82            [12] 1176 	mov	dpl,a
      00454B 22               [24] 1177 	ret
      00454C                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      00454C 74 C7            [12] 1180 	mov	a,#0xc7
      00454E 2F               [12] 1181 	add	a, r7
      00454F FF               [12] 1182 	mov	r7,a
      004550 12 48 38         [24] 1183 	lcall	_ak820_outline_0123
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004553 02 38 AB         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      004556                       1195 _eeprom_read_byte:
      004556 C0 07            [24] 1196 	push	ar7
      004558 C0 06            [24] 1197 	push	ar6
      00455A 12 47 F5         [24] 1198 	lcall	_ak820_outline_0040
      00455D 90 05 E3         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004560 12 37 E1         [24] 1200 	lcall	_ak820_outline_0019
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004563 90 05 E3         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004566 12 37 BA         [24] 1203 	lcall	_ak820_outline_0006
      004569 C0 06            [24] 1204 	push	ar6
      00456B C0 05            [24] 1205 	push	ar5
      00456D C0 04            [24] 1206 	push	ar4
      00456F C0 03            [24] 1207 	push	ar3
      004571 C0 02            [24] 1208 	push	ar2
      004573 C0 01            [24] 1209 	push	ar1
      004575 C0 00            [24] 1210 	push	ar0
      004577 12 44 FD         [24] 1211 	lcall	_read_offset
      00457A AF 82            [24] 1212 	mov	r7, dpl
      00457C D0 00            [24] 1213 	pop	ar0
      00457E D0 01            [24] 1214 	pop	ar1
      004580 D0 02            [24] 1215 	pop	ar2
      004582 D0 03            [24] 1216 	pop	ar3
      004584 D0 04            [24] 1217 	pop	ar4
      004586 D0 05            [24] 1218 	pop	ar5
      004588 D0 06            [24] 1219 	pop	ar6
      00458A 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00458C D0 06            [24] 1222 	pop	ar6
      00458E D0 07            [24] 1223 	pop	ar7
      004590 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      004591                       1238 _ak820_eeprom_read_block_xdata:
      004591 12 38 42         [24] 1239 	lcall	_ak820_outline_0108
      004594 90 05 EB         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004597 12 38 47         [24] 1241 	lcall	_ak820_outline_0109
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00459A 90 05 E6         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00459D 12 37 F9         [24] 1244 	lcall	_ak820_outline_0056
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0045A0 90 05 EB         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0045A3 12 38 18         [24] 1247 	lcall	_ak820_outline_0065
      0045A6 90 05 ED         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0045A9 12 38 24         [24] 1249 	lcall	_ak820_outline_0078
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0045AC 90 05 E9         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0045AF 12 38 18         [24] 1252 	lcall	_ak820_outline_0065
      0045B2                       1253 00103$:
      0045B2 8C 02            [24] 1254 	mov	ar2,r4
      0045B4 8D 03            [24] 1255 	mov	ar3,r5
      0045B6 1C               [12] 1256 	dec	r4
      0045B7 BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      0045BA 1D               [12] 1258 	dec	r5
      0045BB                       1259 00130$:
      0045BB EA               [12] 1260 	mov	a,r2
      0045BC 4B               [12] 1261 	orl	a,r3
      0045BD 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0045BF 8E 02            [24] 1264 	mov	ar2,r6
      0045C1 8F 03            [24] 1265 	mov	ar3,r7
      0045C3 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      0045C5 2B               [12] 1267 	add	a,r3
      0045C6 50 17            [24] 1268 	jnc	00102$
      0045C8 90 05 ED         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0045CB 12 48 3D         [24] 1270 	lcall	_ak820_outline_0129
      0045CE 12 48 54         [24] 1271 	lcall	_ak820_outline_0149
      0045D1 E4               [12] 1272 	clr	a
      0045D2 F0               [24] 1273 	movx	@dptr,a
      0045D3 90 05 ED         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0045D6 04               [12] 1275 	inc	a
      0045D7 2A               [12] 1276 	add	a, r2
      0045D8 F0               [24] 1277 	movx	@dptr,a
      0045D9 E4               [12] 1278 	clr	a
      0045DA 3B               [12] 1279 	addc	a, r3
      0045DB A3               [24] 1280 	inc	dptr
      0045DC F0               [24] 1281 	movx	@dptr,a
      0045DD 80 D3            [24] 1282 	sjmp	00103$
      0045DF                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0045DF 90 05 ED         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0045E2 12 48 3D         [24] 1286 	lcall	_ak820_outline_0129
      0045E5 12 48 38         [24] 1287 	lcall	_ak820_outline_0123
      0045E8 C0 07            [24] 1288 	push	ar7
      0045EA C0 06            [24] 1289 	push	ar6
      0045EC C0 05            [24] 1290 	push	ar5
      0045EE C0 04            [24] 1291 	push	ar4
      0045F0 C0 03            [24] 1292 	push	ar3
      0045F2 C0 02            [24] 1293 	push	ar2
      0045F4 12 44 FD         [24] 1294 	lcall	_read_offset
      0045F7 A9 82            [24] 1295 	mov	r1, dpl
      0045F9 D0 02            [24] 1296 	pop	ar2
      0045FB D0 03            [24] 1297 	pop	ar3
      0045FD D0 04            [24] 1298 	pop	ar4
      0045FF D0 05            [24] 1299 	pop	ar5
      004601 D0 06            [24] 1300 	pop	ar6
      004603 D0 07            [24] 1301 	pop	ar7
      004605 12 48 54         [24] 1302 	lcall	_ak820_outline_0149
      004608 E9               [12] 1303 	mov	a,r1
      004609 F0               [24] 1304 	movx	@dptr,a
      00460A 90 05 ED         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00460D 74 01            [12] 1306 	mov	a,#0x01
      00460F 2A               [12] 1307 	add	a, r2
      004610 F0               [24] 1308 	movx	@dptr,a
      004611 E4               [12] 1309 	clr	a
      004612 3B               [12] 1310 	addc	a, r3
      004613 A3               [24] 1311 	inc	dptr
      004614 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004615 0E               [12] 1314 	inc	r6
      004616 BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      004619 0F               [12] 1316 	inc	r7
      00461A 80 96            [24] 1317 	sjmp	00103$
      00461C                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      00461C 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      00461D                       1336 _ak820_eeprom_write_block_xdata:
      00461D 12 38 42         [24] 1337 	lcall	_ak820_outline_0108
      004620 90 05 F4         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004623 12 38 47         [24] 1339 	lcall	_ak820_outline_0109
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004626 90 05 EF         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004629 12 37 F9         [24] 1342 	lcall	_ak820_outline_0056
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      00462C 90 05 F4         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00462F 12 38 18         [24] 1345 	lcall	_ak820_outline_0065
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004632 8E 02            [24] 1347 	mov	ar2,r6
      004634 8F 03            [24] 1348 	mov	ar3,r7
      004636 C3               [12] 1349 	clr	c
      004637 E4               [12] 1350 	clr	a
      004638 9A               [12] 1351 	subb	a,r2
      004639 74 28            [12] 1352 	mov	a,#0x28
      00463B 9B               [12] 1353 	subb	a,r3
      00463C 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      00463E E4               [12] 1356 	clr	a
      00463F C3               [12] 1357 	clr	c
      004640 9E               [12] 1358 	subb	a,r6
      004641 FA               [12] 1359 	mov	r2,a
      004642 74 28            [12] 1360 	mov	a,#0x28
      004644 9F               [12] 1361 	subb	a,r7
      004645 FB               [12] 1362 	mov	r3,a
      004646 90 05 F2         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004649 12 38 3C         [24] 1364 	lcall	_ak820_outline_0107
      00464C C3               [12] 1365 	clr	c
      00464D EA               [12] 1366 	mov	a,r2
      00464E 98               [12] 1367 	subb	a,r0
      00464F EB               [12] 1368 	mov	a,r3
      004650 99               [12] 1369 	subb	a,r1
      004651 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      004653                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004653 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004656 02 40 66         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004659                       1378 00125$:
      004659 90 05 F2         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00465C 12 48 3D         [24] 1380 	lcall	_ak820_outline_0129
      00465F                       1381 00108$:
      00465F 8A 00            [24] 1382 	mov	ar0,r2
      004661 8B 01            [24] 1383 	mov	ar1,r3
      004663 1A               [12] 1384 	dec	r2
      004664 BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      004667 1B               [12] 1386 	dec	r3
      004668                       1387 00159$:
      004668 E8               [12] 1388 	mov	a,r0
      004669 49               [12] 1389 	orl	a,r1
      00466A 70 03            [24] 1390 	jnz	00160$
      00466C 02 46 F6         [24] 1391 	ljmp	00110$
      00466F                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00466F C0 02            [24] 1394 	push	ar2
      004671 C0 03            [24] 1395 	push	ar3
      004673 12 40 36         [24] 1396 	lcall	_ak820_outline_0081
      004676 F9               [12] 1397 	mov	r1,a
      004677 A3               [24] 1398 	inc	dptr
      004678 12 48 59         [24] 1399 	lcall	_ak820_outline_0156
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00467B 8E 0E            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00467D 8F 0F            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00467F A8 0E            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004681 E5 0F            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004683 A2 E7            [12] 1405 	mov	c,acc.7
      004685 C8               [12] 1406 	xch	a,r0
      004686 33               [12] 1407 	rlc	a
      004687 C8               [12] 1408 	xch	a,r0
      004688 33               [12] 1409 	rlc	a
      004689 A2 E7            [12] 1410 	mov	c,acc.7
      00468B C8               [12] 1411 	xch	a,r0
      00468C 33               [12] 1412 	rlc	a
      00468D C8               [12] 1413 	xch	a,r0
      00468E 33               [12] 1414 	rlc	a
      00468F C8               [12] 1415 	xch	a,r0
      004690 54 03            [12] 1416 	anl	a,#0x03
      004692 FB               [12] 1417 	mov	r3,a
      004693 88 82            [24] 1418 	mov	dpl, r0
      004695 C0 07            [24] 1419 	push	ar7
      004697 C0 06            [24] 1420 	push	ar6
      004699 C0 05            [24] 1421 	push	ar5
      00469B C0 04            [24] 1422 	push	ar4
      00469D C0 03            [24] 1423 	push	ar3
      00469F C0 02            [24] 1424 	push	ar2
      0046A1 C0 01            [24] 1425 	push	ar1
      0046A3 12 44 8B         [24] 1426 	lcall	_load_page
      0046A6 E5 82            [12] 1427 	mov	a, dpl
      0046A8 D0 01            [24] 1428 	pop	ar1
      0046AA D0 02            [24] 1429 	pop	ar2
      0046AC D0 03            [24] 1430 	pop	ar3
      0046AE D0 04            [24] 1431 	pop	ar4
      0046B0 D0 05            [24] 1432 	pop	ar5
      0046B2 D0 06            [24] 1433 	pop	ar6
      0046B4 D0 07            [24] 1434 	pop	ar7
      0046B6 D0 03            [24] 1435 	pop	ar3
      0046B8 D0 02            [24] 1436 	pop	ar2
      0046BA 70 01            [24] 1437 	jnz	00105$
      0046BC 22               [24] 1438 	ret
      0046BD                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0046BD C0 06            [24] 1441 	push	ar6
      0046BF C0 07            [24] 1442 	push	ar7
      0046C1 74 3F            [12] 1443 	mov	a,#0x3f
      0046C3 55 0E            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0046C5 7F 00            [12] 1445 	mov	r7,#0x00
      0046C7 24 7E            [12] 1446 	add	a, #_page_data
      0046C9 F5 0E            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0046CB EF               [12] 1448 	mov	a,r7
      0046CC 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      0046CE F5 0F            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0046D0 85 0E 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0046D3 85 0F 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0046D6 E0               [24] 1453 	movx	a,@dptr
      0046D7 B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      0046DA D0 07            [24] 1455 	pop	ar7
      0046DC D0 06            [24] 1456 	pop	ar6
      0046DE 80 0E            [24] 1457 	sjmp	00107$
      0046E0                       1458 00162$:
      0046E0 D0 07            [24] 1459 	pop	ar7
      0046E2 D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0046E4 85 0E 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0046E7 85 0F 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0046EA E9               [12] 1464 	mov	a,r1
      0046EB F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      0046EC D2 0B            [12] 1468 	setb	_page_dirty
      0046EE                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0046EE 0E               [12] 1471 	inc	r6
      0046EF BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      0046F2 0F               [12] 1473 	inc	r7
      0046F3                       1474 00163$:
      0046F3 02 46 5F         [24] 1475 	ljmp	00108$
      0046F6                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0046F6 90 05 BF         [24] 1478 	mov	dptr,#_batch_depth
      0046F9 E0               [24] 1479 	movx	a,@dptr
      0046FA 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0046FC 02 43 0B         [24] 1482 	ljmp	_ak820_nvm_flush
      0046FF                       1483 00113$:
      0046FF 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      004700                       1502 _ak820_eeprom_update_block_xdata:
      004700 12 38 42         [24] 1503 	lcall	_ak820_outline_0108
      004703 90 05 FB         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004706 12 38 47         [24] 1505 	lcall	_ak820_outline_0109
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004709 90 05 FB         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00470C 12 37 F9         [24] 1508 	lcall	_ak820_outline_0056
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00470F 90 05 F6         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004712 E0               [24] 1511 	movx	a,@dptr
      004713 F5 14            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004715 A3               [24] 1513 	inc	dptr
      004716 E0               [24] 1514 	movx	a,@dptr
      004717 F5 15            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004719 A3               [24] 1516 	inc	dptr
      00471A E0               [24] 1517 	movx	a,@dptr
      00471B F5 16            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      00471D A9 14            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00471F AA 15            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004721 E4               [12] 1522 	clr	a
      004722 F5 10            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004724 F5 11            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004726                       1525 00105$:
      004726 90 05 F9         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004729 E0               [24] 1527 	movx	a,@dptr
      00472A F5 12            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      00472C A3               [24] 1529 	inc	dptr
      00472D E0               [24] 1530 	movx	a,@dptr
      00472E F5 13            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004730 C3               [12] 1532 	clr	c
      004731 E5 10            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004733 95 12            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004735 E5 11            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004737 95 13            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004739 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00473B 89 00            [24] 1539 	mov	ar0,r1
      00473D 8A 05            [24] 1540 	mov	ar5,r2
      00473F E5 10            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004741 28               [12] 1542 	add	a, r0
      004742 F8               [12] 1543 	mov	r0,a
      004743 E5 11            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004745 3D               [12] 1545 	addc	a, r5
      004746 FD               [12] 1546 	mov	r5,a
      004747 88 82            [24] 1547 	mov	dpl, r0
      004749 8D 83            [24] 1548 	mov	dph, r5
      00474B C0 07            [24] 1549 	push	ar7
      00474D C0 06            [24] 1550 	push	ar6
      00474F C0 02            [24] 1551 	push	ar2
      004751 C0 01            [24] 1552 	push	ar1
      004753 12 44 FD         [24] 1553 	lcall	_read_offset
      004756 AD 82            [24] 1554 	mov	r5, dpl
      004758 D0 01            [24] 1555 	pop	ar1
      00475A D0 02            [24] 1556 	pop	ar2
      00475C D0 06            [24] 1557 	pop	ar6
      00475E D0 07            [24] 1558 	pop	ar7
      004760 E5 10            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004762 2E               [12] 1560 	add	a, r6
      004763 F5 82            [12] 1561 	mov	dpl,a
      004765 E5 11            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004767 3F               [12] 1563 	addc	a, r7
      004768 F5 83            [12] 1564 	mov	dph,a
      00476A E0               [24] 1565 	movx	a,@dptr
      00476B FC               [12] 1566 	mov	r4,a
      00476C ED               [12] 1567 	mov	a,r5
      00476D B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      004770 80 27            [24] 1569 	sjmp	00106$
      004772                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004772 90 05 FB         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004775 E0               [24] 1573 	movx	a,@dptr
      004776 F8               [12] 1574 	mov	r0,a
      004777 A3               [24] 1575 	inc	dptr
      004778 E0               [24] 1576 	movx	a,@dptr
      004779 FD               [12] 1577 	mov	r5,a
      00477A 90 05 EF         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00477D E5 14            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00477F F0               [24] 1580 	movx	@dptr,a
      004780 E5 15            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004782 A3               [24] 1582 	inc	dptr
      004783 F0               [24] 1583 	movx	@dptr,a
      004784 E5 16            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004786 A3               [24] 1585 	inc	dptr
      004787 F0               [24] 1586 	movx	@dptr,a
      004788 90 05 F2         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00478B E5 12            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00478D F0               [24] 1589 	movx	@dptr,a
      00478E E5 13            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004790 A3               [24] 1591 	inc	dptr
      004791 F0               [24] 1592 	movx	@dptr,a
      004792 88 82            [24] 1593 	mov	dpl, r0
      004794 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004796 02 46 1D         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      004799                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004799 05 10            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      00479B E4               [12] 1600 	clr	a
      00479C B5 10 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00479F 05 11            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0047A1 80 83            [24] 1603 	sjmp	00105$
      0047A3                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0047A3 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      0047A4                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0047A4 12 43 0B         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0047A7 7F 00            [12] 1621 	mov	r7,#0x00
      0047A9                       1622 00111$:
      0047A9 BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      0047AC 22               [24] 1624 	ret
      0047AD                       1625 00165$:
      0047AD 20 0C 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0047B0 8F 82            [24] 1628 	mov	dpl, r7
      0047B2 C0 07            [24] 1629 	push	ar7
      0047B4 12 44 8B         [24] 1630 	lcall	_load_page
      0047B7 E5 82            [12] 1631 	mov	a, dpl
      0047B9 D0 07            [24] 1632 	pop	ar7
      0047BB 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0047BD 22               [24] 1635 	ret
      0047BE                       1636 00126$:
      0047BE 7E 00            [12] 1637 	mov	r6,#0x00
      0047C0                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0047C0 EE               [12] 1640 	mov	a,r6
      0047C1 24 7E            [12] 1641 	add	a, #_page_data
      0047C3 FC               [12] 1642 	mov	r4,a
      0047C4 E4               [12] 1643 	clr	a
      0047C5 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      0047C7 FD               [12] 1645 	mov	r5,a
      0047C8 12 40 36         [24] 1646 	lcall	_ak820_outline_0081
      0047CB 60 07            [24] 1647 	jz	00108$
      0047CD 12 38 4C         [24] 1648 	lcall	_ak820_outline_0126
      0047D0 E4               [12] 1649 	clr	a
      0047D1 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      0047D2 D2 0B            [12] 1652 	setb	_page_dirty
      0047D4                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0047D4 0E               [12] 1655 	inc	r6
      0047D5 BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0047D8 C0 07            [24] 1658 	push	ar7
      0047DA 12 43 0B         [24] 1659 	lcall	_ak820_nvm_flush
      0047DD D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0047DF 0F               [12] 1662 	inc	r7
      0047E0 80 C7            [24] 1663 	sjmp	00111$
      0047E2                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0047E2 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0006
                                   1674 	.globl _ak820_outline_0012
                                   1675 	.globl _ak820_outline_0013
                                   1676 	.globl _ak820_outline_0019
                                   1677 	.globl _ak820_outline_0025
                                   1678 	.globl _ak820_outline_0040
                                   1679 	.globl _ak820_outline_0045
                                   1680 	.globl _ak820_outline_0056
                                   1681 	.globl _ak820_outline_0057
                                   1682 	.globl _ak820_outline_0065
                                   1683 	.globl _ak820_outline_0066
                                   1684 	.globl _ak820_outline_0069
                                   1685 	.globl _ak820_outline_0078
                                   1686 	.globl _ak820_outline_0081
                                   1687 	.globl _ak820_outline_0086
                                   1688 	.globl _ak820_outline_0099
                                   1689 	.globl _ak820_outline_0107
                                   1690 	.globl _ak820_outline_0108
                                   1691 	.globl _ak820_outline_0109
                                   1692 	.globl _ak820_outline_0111
                                   1693 	.globl _ak820_outline_0123
                                   1694 	.globl _ak820_outline_0126
                                   1695 	.globl _ak820_outline_0129
                                   1696 	.globl _ak820_outline_0131
                                   1697 	.globl _ak820_outline_0140
                                   1698 	.globl _ak820_outline_0141
                                   1699 	.globl _ak820_outline_0143
                                   1700 	.globl _ak820_outline_0147
                                   1701 	.globl _ak820_outline_0148
                                   1702 	.globl _ak820_outline_0149
                                   1703 	.globl _ak820_outline_0150
                                   1704 	.globl _ak820_outline_0156
                                   1705 	.globl _ak820_outline_0163
                                   1706 	.globl _ak820_outline_0164
                                   1707 	.globl _ak820_outline_0167
                                   1708 	.globl _ak820_outline_0169
                                   1709 	.globl _ak820_outline_0189
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0012
      0047E3                       1713 _ak820_outline_0012:
      0047E3 8E 82            [24] 1714 	mov	dpl,r6
      0047E5 8F 83            [24] 1715 	mov	dph,r7
      0047E7 A3               [24] 1716 	inc	dptr
      0047E8 A3               [24] 1717 	inc	dptr
      0047E9 A3               [24] 1718 	inc	dptr
      0047EA A3               [24] 1719 	inc	dptr
      0047EB A3               [24] 1720 	inc	dptr
      0047EC 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0025
      0047ED                       1725 _ak820_outline_0025:
      0047ED F0               [24] 1726 	movx	@dptr,a
      0047EE 8E 82            [24] 1727 	mov	dpl,r6
      0047F0 8F 83            [24] 1728 	mov	dph,r7
      0047F2 A3               [24] 1729 	inc	dptr
      0047F3 A3               [24] 1730 	inc	dptr
      0047F4 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0040
      0047F5                       1735 _ak820_outline_0040:
      0047F5 AF F0            [24] 1736 	mov	r7,b
      0047F7 AE 83            [24] 1737 	mov	r6,dph
      0047F9 E5 82            [12] 1738 	mov	a,dpl
      0047FB 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0045
      0047FC                       1743 _ak820_outline_0045:
      0047FC EF               [12] 1744 	mov	a,r7
      0047FD 24 D6            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      0047FF F5 82            [12] 1746 	mov	dpl,a
      004801 E4               [12] 1747 	clr	a
      004802 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004804 F5 83            [12] 1749 	mov	dph,a
      004806 E0               [24] 1750 	movx	a,@dptr
      004807 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0057
      004808                       1755 _ak820_outline_0057:
      004808 8F 06            [24] 1756 	mov	ar6,r7
      00480A 7D 00            [12] 1757 	mov	r5,#0x00
      00480C 74 40            [12] 1758 	mov	a,#0x40
      00480E 2E               [12] 1759 	add	a,r6
      00480F FE               [12] 1760 	mov	r6,a
      004810 74 EF            [12] 1761 	mov	a,#0xef
      004812 3D               [12] 1762 	addc	a,r5
      004813 FD               [12] 1763 	mov	r5,a
      004814 8E 82            [24] 1764 	mov	dpl,r6
      004816 8D 83            [24] 1765 	mov	dph,r5
      004818 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0066
      004819                       1770 _ak820_outline_0066:
      004819 F0               [24] 1771 	movx	@dptr,a
      00481A 8E 82            [24] 1772 	mov	dpl,r6
      00481C 8F 83            [24] 1773 	mov	dph,r7
      00481E 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0069
      00481F                       1778 _ak820_outline_0069:
      00481F 8D 82            [24] 1779 	mov	dpl,r5
      004821 8E 83            [24] 1780 	mov	dph,r6
      004823 EC               [12] 1781 	mov	a,r4
      004824 F0               [24] 1782 	movx	@dptr,a
      004825 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0099
      004826                       1787 _ak820_outline_0099:
      004826 E0               [24] 1788 	movx	a,@dptr
      004827 FD               [12] 1789 	mov	r5,a
      004828 A3               [24] 1790 	inc	dptr
      004829 E0               [24] 1791 	movx	a,@dptr
      00482A FE               [12] 1792 	mov	r6,a
      00482B 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0111
      00482C                       1797 _ak820_outline_0111:
      00482C EF               [12] 1798 	mov	a,r7
      00482D 24 7E            [12] 1799 	add	a,#_page_data
      00482F F5 82            [12] 1800 	mov	dpl,a
      004831 E4               [12] 1801 	clr	a
      004832 34 05            [12] 1802 	addc	a,#(_page_data>>8)
      004834 F5 83            [12] 1803 	mov	dph,a
      004836 E0               [24] 1804 	movx	a,@dptr
      004837 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0123
      004838                       1809 _ak820_outline_0123:
      004838 8E 82            [24] 1810 	mov	dpl,r6
      00483A 8F 83            [24] 1811 	mov	dph,r7
      00483C 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0129
      00483D                       1816 _ak820_outline_0129:
      00483D E0               [24] 1817 	movx	a,@dptr
      00483E FA               [12] 1818 	mov	r2,a
      00483F A3               [24] 1819 	inc	dptr
      004840 E0               [24] 1820 	movx	a,@dptr
      004841 FB               [12] 1821 	mov	r3,a
      004842 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0140
      004843                       1826 _ak820_outline_0140:
      004843 AE 82            [24] 1827 	mov	r6,dpl
      004845 AF 83            [24] 1828 	mov	r7,dph
      004847 22               [24] 1829 	ret
                                   1830 
                                   1831 	.area CSEG (CODE)
                                   1832 ; function ak820_outline_0143
      004848                       1833 _ak820_outline_0143:
      004848 2E               [12] 1834 	add	a,r6
      004849 FE               [12] 1835 	mov	r6,a
      00484A E4               [12] 1836 	clr	a
      00484B 3F               [12] 1837 	addc	a,r7
      00484C FF               [12] 1838 	mov	r7,a
      00484D 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0148
      00484E                       1843 _ak820_outline_0148:
      00484E 42 05            [12] 1844 	orl	ar5,a
      004850 EA               [12] 1845 	mov	a,r2
      004851 42 04            [12] 1846 	orl	ar4,a
      004853 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0149
      004854                       1851 _ak820_outline_0149:
      004854 8A 82            [24] 1852 	mov	dpl,r2
      004856 8B 83            [24] 1853 	mov	dph,r3
      004858 22               [24] 1854 	ret
                                   1855 
                                   1856 	.area CSEG (CODE)
                                   1857 ; function ak820_outline_0156
      004859                       1858 _ak820_outline_0156:
      004859 AC 82            [24] 1859 	mov	r4,dpl
      00485B AD 83            [24] 1860 	mov	r5,dph
      00485D 22               [24] 1861 	ret
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0163
      00485E                       1865 _ak820_outline_0163:
      00485E 89 82            [24] 1866 	mov	dpl,r1
      004860 8A 83            [24] 1867 	mov	dph,r2
      004862 22               [24] 1868 	ret
                                   1869 
                                   1870 	.area CSEG (CODE)
                                   1871 ; function ak820_outline_0164
      004863                       1872 _ak820_outline_0164:
      004863 8F 82            [24] 1873 	mov	dpl,r7
      004865 8E 83            [24] 1874 	mov	dph,r6
      004867 22               [24] 1875 	ret
                                   1876 
                                   1877 	.area CSEG (CODE)
                                   1878 ; function ak820_outline_0167
      004868                       1879 _ak820_outline_0167:
      004868 2E               [12] 1880 	add	a,r6
      004869 FC               [12] 1881 	mov	r4,a
      00486A E4               [12] 1882 	clr	a
      00486B 3F               [12] 1883 	addc	a,r7
      00486C FD               [12] 1884 	mov	r5,a
      00486D 22               [24] 1885 	ret
                                   1886 
                                   1887 	.area CSEG (CODE)
                                   1888 ; function ak820_outline_0169
      00486E                       1889 _ak820_outline_0169:
      00486E ED               [12] 1890 	mov	a,r5
      00486F F0               [24] 1891 	movx	@dptr,a
      004870 EE               [12] 1892 	mov	a,r6
      004871 A3               [24] 1893 	inc	dptr
      004872 F0               [24] 1894 	movx	@dptr,a
      004873 22               [24] 1895 	ret
                                   1896 
                                   1897 	.area CSEG (CODE)
                                   1898 ; function ak820_outline_0189
      004874                       1899 _ak820_outline_0189:
      004874 8C 82            [24] 1900 	mov	dpl,r4
      004876 8B 83            [24] 1901 	mov	dph,r3
      004878 22               [24] 1902 	ret
