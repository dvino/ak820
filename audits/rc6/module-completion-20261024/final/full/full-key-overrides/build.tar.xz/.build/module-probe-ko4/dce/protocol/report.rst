                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _biton
                                     12 	.globl _memset
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _del_key_from_report_PARM_2
                                    257 	.globl _add_key_to_report_PARM_2
                                    258 	.globl _del_key_bit_PARM_2
                                    259 	.globl _add_key_bit_PARM_2
                                    260 	.globl _del_key_byte_PARM_2
                                    261 	.globl _add_key_byte_PARM_2
                                    262 	.globl _KEYCODE2CONSUMER
                                    263 	.globl _add_key_byte
                                    264 	.globl _del_key_byte
                                    265 	.globl _add_key_bit
                                    266 	.globl _del_key_bit
                                    267 	.globl _add_key_to_report
                                    268 	.globl _del_key_from_report
                                    269 	.globl _clear_keys_from_report
                                    270 ;--------------------------------------------------------
                                    271 ; special function registers
                                    272 ;--------------------------------------------------------
                                    273 	.area RSEG    (ABS,DATA)
      000000                        274 	.org 0x0000
                           0000D0   275 _PSW	=	0x00d0
                           0000E0   276 _ACC	=	0x00e0
                           0000F0   277 _B	=	0x00f0
                           0000FD   278 _A_INV	=	0x00fd
                           000081   279 _SP	=	0x0081
                           000082   280 _DPL	=	0x0082
                           000083   281 _DPH	=	0x0083
                           0000A1   282 _SAFE_MOD	=	0x00a1
                           0000B1   283 _GLOBAL_CFG	=	0x00b1
                           000087   284 _PCON	=	0x0087
                           0000BA   285 _POWER_CFG	=	0x00ba
                           0000B9   286 _CLOCK_CFG	=	0x00b9
                           0000A9   287 _WAKE_CTRL	=	0x00a9
                           0000FE   288 _RESET_KEEP	=	0x00fe
                           0000FF   289 _WDOG_COUNT	=	0x00ff
                           0000A8   290 _IE	=	0x00a8
                           0000B8   291 _IP	=	0x00b8
                           0000E8   292 _IE_EX	=	0x00e8
                           0000E9   293 _IP_EX	=	0x00e9
                           0000B2   294 _GPIO_IE	=	0x00b2
                           008584   295 _ROM_ADDR	=	0x8584
                           000084   296 _ROM_ADDR_L	=	0x0084
                           000085   297 _ROM_ADDR_H	=	0x0085
                           008F8E   298 _ROM_DATA_HI	=	0x8f8e
                           00008E   299 _ROM_DATA_HL	=	0x008e
                           00008F   300 _ROM_DATA_HH	=	0x008f
                           000086   301 _ROM_CTRL	=	0x0086
                           000080   302 _P0	=	0x0080
                           0000C4   303 _P0_MOD_OC	=	0x00c4
                           0000C5   304 _P0_DIR_PU	=	0x00c5
                           000090   305 _P1	=	0x0090
                           000092   306 _P1_MOD_OC	=	0x0092
                           000093   307 _P1_DIR_PU	=	0x0093
                           0000A0   308 _P2	=	0x00a0
                           000094   309 _P2_MOD_OC	=	0x0094
                           000095   310 _P2_DIR_PU	=	0x0095
                           0000B0   311 _P3	=	0x00b0
                           000096   312 _P3_MOD_OC	=	0x0096
                           000097   313 _P3_DIR_PU	=	0x0097
                           0000C0   314 _P4	=	0x00c0
                           0000C2   315 _P4_MOD_OC	=	0x00c2
                           0000C3   316 _P4_DIR_PU	=	0x00c3
                           0000C1   317 _P4_LED_KEY	=	0x00c1
                           0000AA   318 _P5_IN	=	0x00aa
                           0000AB   319 _P5_OUT_PU	=	0x00ab
                           0000AC   320 _P5_DIR	=	0x00ac
                           0000AD   321 _P6_IN	=	0x00ad
                           0000AE   322 _P6_OUT_PU	=	0x00ae
                           0000AF   323 _P6_DIR	=	0x00af
                           0000F1   324 _P7	=	0x00f1
                           0000A2   325 _XBUS_AUX	=	0x00a2
                           000088   326 _TCON	=	0x0088
                           000089   327 _TMOD	=	0x0089
                           00008A   328 _TL0	=	0x008a
                           00008B   329 _TL1	=	0x008b
                           00008C   330 _TH0	=	0x008c
                           00008D   331 _TH1	=	0x008d
                           000098   332 _SCON	=	0x0098
                           000099   333 _SBUF	=	0x0099
                           0000C8   334 _T2CON	=	0x00c8
                           0000C9   335 _T2MOD	=	0x00c9
                           00CBCA   336 _RCAP2	=	0xcbca
                           0000CA   337 _RCAP2L	=	0x00ca
                           0000CB   338 _RCAP2H	=	0x00cb
                           00CDCC   339 _T2COUNT	=	0xcdcc
                           0000CC   340 _TL2	=	0x00cc
                           0000CD   341 _TH2	=	0x00cd
                           00CFCE   342 _T2CAP1	=	0xcfce
                           0000CE   343 _T2CAP1L	=	0x00ce
                           0000CF   344 _T2CAP1H	=	0x00cf
                           0000F8   345 _SPI0_STAT	=	0x00f8
                           0000F9   346 _SPI0_DATA	=	0x00f9
                           0000FA   347 _SPI0_CTRL	=	0x00fa
                           0000FB   348 _SPI0_CK_SE	=	0x00fb
                           0000FC   349 _SPI0_SETUP	=	0x00fc
                           0000BC   350 _SCON1	=	0x00bc
                           0000BD   351 _SBUF1	=	0x00bd
                           0000BE   352 _SBAUD1	=	0x00be
                           0000BF   353 _SIF1	=	0x00bf
                           0000B4   354 _SPI1_STAT	=	0x00b4
                           0000B5   355 _SPI1_DATA	=	0x00b5
                           0000B6   356 _SPI1_CTRL	=	0x00b6
                           0000B7   357 _SPI1_CK_SE	=	0x00b7
                           0000F3   358 _ADC_CTRL	=	0x00f3
                           00F5F4   359 _ADC_DAT	=	0xf5f4
                           0000F4   360 _ADC_DAT_L	=	0x00f4
                           0000F5   361 _ADC_DAT_H	=	0x00f5
                           0000F6   362 _ADC_CHAN	=	0x00f6
                           0000A6   363 _LED_COMMON	=	0x00a6
                           0000A7   364 _LED_PWM_OE	=	0x00a7
                           00C7C6   365 _LED_DMA	=	0xc7c6
                           0000C6   366 _LED_DMA_L	=	0x00c6
                           0000C7   367 _LED_DMA_H	=	0x00c7
                           0000F7   368 _LED_STATUS	=	0x00f7
                           0000B3   369 _I2CX_INT	=	0x00b3
                           0000BB   370 _I2CS_INT_ST	=	0x00bb
                                    371 ;--------------------------------------------------------
                                    372 ; special function bits
                                    373 ;--------------------------------------------------------
                                    374 	.area RSEG    (ABS,DATA)
      000000                        375 	.org 0x0000
                           0000D7   376 _CY	=	0x00d7
                           0000D6   377 _AC	=	0x00d6
                           0000D5   378 _F0	=	0x00d5
                           0000D4   379 _RS1	=	0x00d4
                           0000D3   380 _RS0	=	0x00d3
                           0000D2   381 _OV	=	0x00d2
                           0000D1   382 _F1	=	0x00d1
                           0000D0   383 _P	=	0x00d0
                           0000AF   384 _EA	=	0x00af
                           0000AE   385 _E_DIS	=	0x00ae
                           0000AD   386 _ET2	=	0x00ad
                           0000AC   387 _ES	=	0x00ac
                           0000AB   388 _ET1	=	0x00ab
                           0000AA   389 _EX1	=	0x00aa
                           0000A9   390 _ET0	=	0x00a9
                           0000A8   391 _EX0	=	0x00a8
                           0000BF   392 _PH_FLAG	=	0x00bf
                           0000BE   393 _PL_FLAG	=	0x00be
                           0000BD   394 _PT2	=	0x00bd
                           0000BC   395 _PS	=	0x00bc
                           0000BB   396 _PT1	=	0x00bb
                           0000BA   397 _PX1	=	0x00ba
                           0000B9   398 _PT0	=	0x00b9
                           0000B8   399 _PX0	=	0x00b8
                           0000EF   400 _IE_WDOG	=	0x00ef
                           0000EE   401 _IE_GPIO	=	0x00ee
                           0000ED   402 _IE_PWM_I2C	=	0x00ed
                           0000EC   403 _IE_UART1	=	0x00ec
                           0000EB   404 _IE_ADC	=	0x00eb
                           0000E9   405 _IE_USB	=	0x00e9
                           0000E8   406 _IE_SPI0	=	0x00e8
                           000087   407 _P0_7	=	0x0087
                           000086   408 _P0_6	=	0x0086
                           000085   409 _P0_5	=	0x0085
                           000084   410 _P0_4	=	0x0084
                           000083   411 _P0_3	=	0x0083
                           000082   412 _P0_2	=	0x0082
                           000081   413 _P0_1	=	0x0081
                           000080   414 _P0_0	=	0x0080
                           000081   415 _SDA0	=	0x0081
                           000080   416 _SCL0	=	0x0080
                           000083   417 _TXD_	=	0x0083
                           000082   418 _RXD_	=	0x0082
                           000085   419 _AIN13	=	0x0085
                           000084   420 _AIN12	=	0x0084
                           000083   421 _AIN11	=	0x0083
                           000082   422 _AIN10	=	0x0082
                           000081   423 _AIN9	=	0x0081
                           000080   424 _AIN8	=	0x0080
                           000097   425 _P1_7	=	0x0097
                           000096   426 _P1_6	=	0x0096
                           000095   427 _P1_5	=	0x0095
                           000094   428 _P1_4	=	0x0094
                           000093   429 _P1_3	=	0x0093
                           000092   430 _P1_2	=	0x0092
                           000091   431 _P1_1	=	0x0091
                           000090   432 _P1_0	=	0x0090
                           000097   433 _TXD1_	=	0x0097
                           000096   434 _RXD1_	=	0x0096
                           000097   435 _SCK	=	0x0097
                           000096   436 _MISO	=	0x0096
                           000095   437 _MOSI	=	0x0095
                           000094   438 _SCS	=	0x0094
                           000092   439 _INT0_	=	0x0092
                           000091   440 _T2EX	=	0x0091
                           000091   441 _CAP2	=	0x0091
                           000090   442 _T2	=	0x0090
                           000090   443 _CAP1	=	0x0090
                           000097   444 _AIN7	=	0x0097
                           000096   445 _AIN6	=	0x0096
                           000095   446 _AIN5	=	0x0095
                           000094   447 _AIN4	=	0x0094
                           000093   448 _AIN3	=	0x0093
                           000092   449 _AIN2	=	0x0092
                           000091   450 _AIN1	=	0x0091
                           000090   451 _AIN0	=	0x0090
                           0000A7   452 _P2_7	=	0x00a7
                           0000A6   453 _P2_6	=	0x00a6
                           0000A5   454 _P2_5	=	0x00a5
                           0000A4   455 _P2_4	=	0x00a4
                           0000A3   456 _P2_3	=	0x00a3
                           0000A2   457 _P2_2	=	0x00a2
                           0000A1   458 _P2_1	=	0x00a1
                           0000A0   459 _P2_0	=	0x00a0
                           0000A7   460 _TXD1	=	0x00a7
                           0000A6   461 _RXD1	=	0x00a6
                           0000A5   462 _T2EX_	=	0x00a5
                           0000A5   463 _CAP2_	=	0x00a5
                           0000A4   464 _T2_	=	0x00a4
                           0000A4   465 _CAP1_	=	0x00a4
                           0000B7   466 _P3_7	=	0x00b7
                           0000B6   467 _P3_6	=	0x00b6
                           0000B5   468 _P3_5	=	0x00b5
                           0000B4   469 _P3_4	=	0x00b4
                           0000B3   470 _P3_3	=	0x00b3
                           0000B2   471 _P3_2	=	0x00b2
                           0000B1   472 _P3_1	=	0x00b1
                           0000B0   473 _P3_0	=	0x00b0
                           0000B7   474 _SCK1	=	0x00b7
                           0000B6   475 _MISO1	=	0x00b6
                           0000B5   476 _MOSI1	=	0x00b5
                           0000B5   477 _T1	=	0x00b5
                           0000B4   478 _T0	=	0x00b4
                           0000B3   479 _INT1	=	0x00b3
                           0000B2   480 _INT0	=	0x00b2
                           0000B1   481 _TXD	=	0x00b1
                           0000B0   482 _RXD	=	0x00b0
                           0000C6   483 _P4_6	=	0x00c6
                           0000C5   484 _P4_5	=	0x00c5
                           0000C4   485 _P4_4	=	0x00c4
                           0000C3   486 _P4_3	=	0x00c3
                           0000C2   487 _P4_2	=	0x00c2
                           0000C1   488 _P4_1	=	0x00c1
                           0000C0   489 _P4_0	=	0x00c0
                           00008F   490 _TF1	=	0x008f
                           00008E   491 _TR1	=	0x008e
                           00008D   492 _TF0	=	0x008d
                           00008C   493 _TR0	=	0x008c
                           00008B   494 _IE1	=	0x008b
                           00008A   495 _IT1	=	0x008a
                           000089   496 _IE0	=	0x0089
                           000088   497 _IT0	=	0x0088
                           00009F   498 _SM0	=	0x009f
                           00009E   499 _SM1	=	0x009e
                           00009D   500 _SM2	=	0x009d
                           00009C   501 _REN	=	0x009c
                           00009B   502 _TB8	=	0x009b
                           00009A   503 _RB8	=	0x009a
                           000099   504 _TI	=	0x0099
                           000098   505 _RI	=	0x0098
                           0000CF   506 _TF2	=	0x00cf
                           0000CF   507 _CAP1F	=	0x00cf
                           0000CE   508 _EXF2	=	0x00ce
                           0000CD   509 _RCLK	=	0x00cd
                           0000CC   510 _TCLK	=	0x00cc
                           0000CB   511 _EXEN2	=	0x00cb
                           0000CA   512 _TR2	=	0x00ca
                           0000C9   513 _C_T2	=	0x00c9
                           0000C8   514 _CP_RL2	=	0x00c8
                           0000FF   515 _S0_FST_ACT	=	0x00ff
                           0000FE   516 _S0_IF_OV	=	0x00fe
                           0000FD   517 _S0_IF_FIRST	=	0x00fd
                           0000FC   518 _S0_IF_BYTE	=	0x00fc
                           0000FB   519 _S0_FREE	=	0x00fb
                           0000FA   520 _S0_T_FIFO	=	0x00fa
                           0000F8   521 _S0_R_FIFO	=	0x00f8
                           0000F7   522 _ADC_START	=	0x00f7
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable register banks
                                    525 ;--------------------------------------------------------
                                    526 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        527 	.ds 8
                                    528 ;--------------------------------------------------------
                                    529 ; internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area DSEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable items in internal ram
                                    534 ;--------------------------------------------------------
                                    535 ;--------------------------------------------------------
                                    536 ; indirectly addressable internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area ISEG    (DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; absolute internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area IABS    (ABS,DATA)
                                    543 	.area IABS    (ABS,DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; bit data
                                    546 ;--------------------------------------------------------
                                    547 	.area BSEG    (BIT)
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      000852                        556 _KEYCODE2CONSUMER_key_10000_117:
      000852                        557 	.ds 1
      000853                        558 _add_key_byte_PARM_2:
      000853                        559 	.ds 1
      000854                        560 _add_key_byte_report_arg_10000_144:
      000854                        561 	.ds 2
      000856                        562 _add_key_byte_empty_10000_145:
      000856                        563 	.ds 1
      000857                        564 _del_key_byte_PARM_2:
      000857                        565 	.ds 1
      000858                        566 _del_key_byte_report_arg_10000_156:
      000858                        567 	.ds 2
      00085A                        568 _add_key_bit_PARM_2:
      00085A                        569 	.ds 1
      00085B                        570 _add_key_bit_report_arg_10000_162:
      00085B                        571 	.ds 2
      00085D                        572 _del_key_bit_PARM_2:
      00085D                        573 	.ds 1
      00085E                        574 _del_key_bit_report_arg_10000_167:
      00085E                        575 	.ds 2
      000860                        576 _add_key_to_report_PARM_2:
      000860                        577 	.ds 1
      000861                        578 _add_key_to_report_report_arg_10000_172:
      000861                        579 	.ds 2
      000863                        580 _del_key_from_report_PARM_2:
      000863                        581 	.ds 1
      000864                        582 _del_key_from_report_report_arg_10000_176:
      000864                        583 	.ds 2
      000866                        584 _clear_keys_from_report_report_arg_10000_180:
      000866                        585 	.ds 2
                                    586 ;--------------------------------------------------------
                                    587 ; absolute external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area XABS    (ABS,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; initialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XISEG   (XDATA)
                                    594 	.area HOME    (CODE)
                                    595 	.area GSINIT0 (CODE)
                                    596 	.area GSINIT1 (CODE)
                                    597 	.area GSINIT2 (CODE)
                                    598 	.area GSINIT3 (CODE)
                                    599 	.area GSINIT4 (CODE)
                                    600 	.area GSINIT5 (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area CSEG    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; global & static initialisations
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 	.area GSFINAL (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; Home
                                    613 ;--------------------------------------------------------
                                    614 	.area HOME    (CODE)
                                    615 	.area HOME    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; code
                                    618 ;--------------------------------------------------------
                                    619 	.area CSEG    (CODE)
                                    620 ;------------------------------------------------------------
                                    621 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    622 ;------------------------------------------------------------
                                    623 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    624 ;------------------------------------------------------------
                                    625 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    626 ;	-----------------------------------------
                           000007   627 	ar7 = 0x07
                           000006   628 	ar6 = 0x06
                           000005   629 	ar5 = 0x05
                           000004   630 	ar4 = 0x04
                           000003   631 	ar3 = 0x03
                           000002   632 	ar2 = 0x02
                           000001   633 	ar1 = 0x01
                           000000   634 	ar0 = 0x00
                                    635 ;	 function KEYCODE2CONSUMER
                                    636 ;	-----------------------------------------
      0071EC                        637 _KEYCODE2CONSUMER:
      0071EC E5 82            [12]  638 	mov	a,dpl
      0071EE 90 08 52         [24]  639 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      0071F1 F0               [24]  640 	movx	@dptr,a
                                    641 ;	tmk_core/protocol/report.c:43: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      0071F2 E0               [24]  642 	movx	a,@dptr
      0071F3 FF               [12]  643 	mov	r7,a
      0071F4 BF A8 00         [24]  644 	cjne	r7,#0xa8,00113$
      0071F7                        645 00113$:
      0071F7 40 05            [24]  646 	jc	00101$
      0071F9 EF               [12]  647 	mov	a,r7
      0071FA 24 3D            [12]  648 	add	a,#0xff - 0xc2
      0071FC 50 04            [24]  649 	jnc	00102$
                                    650 ;	free result
      0071FE                        651 00101$:
      0071FE 90 00 00         [24]  652 	mov	dptr,#0x0000
      007201 22               [24]  653 	ret
      007202                        654 00102$:
                                    655 ;	tmk_core/protocol/report.c:44: return usages[key - KC_AUDIO_MUTE];
      007202 EF               [12]  656 	mov	a,r7
      007203 24 58            [12]  657 	add	a,#0x58
      007205 FF               [12]  658 	mov	r7,a
      007206 C2 D5            [12]  659 	clr	F0
      007208 75 F0 02         [24]  660 	mov	b,#0x02
      00720B EF               [12]  661 	mov	a,r7
      00720C 30 E7 04         [24]  662 	jnb	acc.7,00116$
      00720F B2 D5            [12]  663 	cpl	F0
      007211 F4               [12]  664 	cpl	a
      007212 04               [12]  665 	inc	a
      007213                        666 00116$:
      007213 A4               [48]  667 	mul	ab
      007214 30 D5 03         [24]  668 	jnb	F0,00117$
      007217 12 73 FA         [24]  669 	lcall	_ak820_outline_0137
      00721A                        670 00117$:
      00721A 24 33            [12]  671 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      00721C F5 82            [12]  672 	mov	dpl,a
      00721E 74 BF            [12]  673 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      007220 12 5B 9A         [24]  674 	lcall	_ak820_outline_0113
      007223 FE               [12]  675 	mov	r6,a
      007224 A3               [24]  676 	inc	dptr
      007225 E4               [12]  677 	clr	a
      007226 93               [24]  678 	movc	a,@a+dptr
                                    679 ;	tmk_core/protocol/report.c:45: }
      007227 8E 82            [24]  680 	mov	dpl,r6
      007229 F5 83            [12]  681 	mov	dph,a
      00722B 22               [24]  682 	ret
                                    683 ;------------------------------------------------------------
                                    684 ;Allocation info for local variables in function 'has_anykey'
                                    685 ;------------------------------------------------------------
                                    686 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    687 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    688 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    689 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    690 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.c:62: uint8_t has_anykey(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function add_key_byte
                                    695 ;	-----------------------------------------
      00722C                        696 _add_key_byte:
      00722C 12 38 42         [24]  697 	lcall	_ak820_outline_0108
      00722F 90 08 54         [24]  698 	mov	dptr,#_add_key_byte_report_arg_10000_144
      007232 12 38 47         [24]  699 	lcall	_ak820_outline_0109
                                    700 ;	tmk_core/protocol/report.c:139: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007235 90 08 54         [24]  701 	mov	dptr,#_add_key_byte_report_arg_10000_144
      007238 12 37 F9         [24]  702 	lcall	_ak820_outline_0056
                                    703 ;	tmk_core/protocol/report.c:185: int8_t empty = -1;
      00723B 90 08 56         [24]  704 	mov	dptr,#_add_key_byte_empty_10000_145
      00723E 74 FF            [12]  705 	mov	a,#0xff
      007240 F0               [24]  706 	movx	@dptr,a
                                    707 ;	tmk_core/protocol/report.c:200: }
      007241 7D 00            [12]  708 	mov	r5,#0x00
      007243                        709 00112$:
                                    710 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007243 C3               [12]  711 	clr	c
      007244 ED               [12]  712 	mov	a,r5
      007245 64 80            [12]  713 	xrl	a,#0x80
      007247 94 86            [12]  714 	subb	a,#0x86
      007249 50 29            [24]  715 	jnc	00106$
                                    716 ;	tmk_core/protocol/report.c:187: if (keyboard_report->keys[i] == code) {
      00724B 12 74 05         [24]  717 	lcall	_ak820_outline_0152
      00724E F5 82            [12]  718 	mov	dpl,a
      007250 E4               [12]  719 	clr	a
      007251 3C               [12]  720 	addc	a, r4
      007252 F5 83            [12]  721 	mov	dph,a
      007254 E0               [24]  722 	movx	a,@dptr
      007255 FC               [12]  723 	mov	r4,a
      007256 90 08 53         [24]  724 	mov	dptr,#_add_key_byte_PARM_2
      007259 E0               [24]  725 	movx	a,@dptr
      00725A FB               [12]  726 	mov	r3,a
      00725B EC               [12]  727 	mov	a,r4
      00725C B5 03 02         [24]  728 	cjne	a,ar3,00167$
      00725F 80 13            [24]  729 	sjmp	00106$
      007261                        730 00167$:
                                    731 ;	tmk_core/protocol/report.c:190: if (empty == -1 && keyboard_report->keys[i] == 0) {
      007261 90 08 56         [24]  732 	mov	dptr,#_add_key_byte_empty_10000_145
      007264 E0               [24]  733 	movx	a,@dptr
      007265 FB               [12]  734 	mov	r3,a
      007266 BB FF 08         [24]  735 	cjne	r3,#0xff,00113$
      007269 EC               [12]  736 	mov	a,r4
      00726A 70 05            [24]  737 	jnz	00113$
                                    738 ;	tmk_core/protocol/report.c:191: empty = i;
      00726C 90 08 56         [24]  739 	mov	dptr,#_add_key_byte_empty_10000_145
      00726F ED               [12]  740 	mov	a,r5
      007270 F0               [24]  741 	movx	@dptr,a
      007271                        742 00113$:
                                    743 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007271 0D               [12]  744 	inc	r5
      007272 80 CF            [24]  745 	sjmp	00112$
      007274                        746 00106$:
                                    747 ;	tmk_core/protocol/report.c:194: if (i == KEYBOARD_REPORT_KEYS) {
      007274 BD 06 1D         [24]  748 	cjne	r5,#0x06,00114$
                                    749 ;	tmk_core/protocol/report.c:195: if (empty != -1) {
      007277 90 08 56         [24]  750 	mov	dptr,#_add_key_byte_empty_10000_145
      00727A E0               [24]  751 	movx	a,@dptr
      00727B FD               [12]  752 	mov	r5,a
      00727C BD FF 01         [24]  753 	cjne	r5,#0xff,00173$
      00727F 22               [24]  754 	ret
      007280                        755 00173$:
                                    756 ;	tmk_core/protocol/report.c:196: keyboard_report->keys[empty] = code;
      007280 74 02            [12]  757 	mov	a,#0x02
      007282 12 48 48         [24]  758 	lcall	_ak820_outline_0143
      007285 ED               [12]  759 	mov	a,r5
      007286 2E               [12]  760 	add	a, r6
      007287 FD               [12]  761 	mov	r5,a
      007288 E4               [12]  762 	clr	a
      007289 3F               [12]  763 	addc	a, r7
      00728A FC               [12]  764 	mov	r4,a
      00728B 90 08 53         [24]  765 	mov	dptr,#_add_key_byte_PARM_2
      00728E E0               [24]  766 	movx	a,@dptr
      00728F 8D 82            [24]  767 	mov	dpl,r5
      007291 8C 83            [24]  768 	mov	dph,r4
      007293 F0               [24]  769 	movx	@dptr,a
      007294                        770 00114$:
                                    771 ;	tmk_core/protocol/report.c:200: }
      007294 22               [24]  772 	ret
                                    773 ;------------------------------------------------------------
                                    774 ;Allocation info for local variables in function 'del_key_byte'
                                    775 ;------------------------------------------------------------
                                    776 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    777 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    778 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    779 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    780 ;------------------------------------------------------------
                                    781 ;	tmk_core/protocol/report.c:206: void del_key_byte(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function del_key_byte
                                    784 ;	-----------------------------------------
      007295                        785 _del_key_byte:
      007295 12 38 42         [24]  786 	lcall	_ak820_outline_0108
      007298 90 08 58         [24]  787 	mov	dptr,#_del_key_byte_report_arg_10000_156
      00729B 12 38 47         [24]  788 	lcall	_ak820_outline_0109
                                    789 ;	tmk_core/protocol/report.c:207: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00729E 90 08 58         [24]  790 	mov	dptr,#_del_key_byte_report_arg_10000_156
      0072A1 12 37 F9         [24]  791 	lcall	_ak820_outline_0056
                                    792 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0072A4 7D 00            [12]  793 	mov	r5,#0x00
      0072A6                        794 00105$:
      0072A6 BD 06 00         [24]  795 	cjne	r5,#0x06,00131$
      0072A9                        796 00131$:
      0072A9 50 1A            [24]  797 	jnc	00107$
                                    798 ;	tmk_core/protocol/report.c:235: if (keyboard_report->keys[i] == code) {
      0072AB 12 74 05         [24]  799 	lcall	_ak820_outline_0152
      0072AE FB               [12]  800 	mov	r3,a
      0072AF E4               [12]  801 	clr	a
      0072B0 3C               [12]  802 	addc	a, r4
      0072B1 12 4D 4B         [24]  803 	lcall	_ak820_outline_0061
      0072B4 90 08 57         [24]  804 	mov	dptr,#_del_key_byte_PARM_2
      0072B7 E0               [24]  805 	movx	a,@dptr
      0072B8 F9               [12]  806 	mov	r1,a
      0072B9 EA               [12]  807 	mov	a,r2
      0072BA B5 01 05         [24]  808 	cjne	a,ar1,00106$
                                    809 ;	tmk_core/protocol/report.c:236: keyboard_report->keys[i] = 0;
      0072BD 12 33 FC         [24]  810 	lcall	_ak820_outline_0131
      0072C0 E4               [12]  811 	clr	a
      0072C1 F0               [24]  812 	movx	@dptr,a
      0072C2                        813 00106$:
                                    814 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0072C2 0D               [12]  815 	inc	r5
      0072C3 80 E1            [24]  816 	sjmp	00105$
      0072C5                        817 00107$:
                                    818 ;	tmk_core/protocol/report.c:240: }
      0072C5 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'add_key_bit'
                                    822 ;------------------------------------------------------------
                                    823 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    824 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    825 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    826 ;------------------------------------------------------------
                                    827 ;	tmk_core/protocol/report.c:247: void add_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function add_key_bit
                                    830 ;	-----------------------------------------
      0072C6                        831 _add_key_bit:
      0072C6 12 38 42         [24]  832 	lcall	_ak820_outline_0108
      0072C9 90 08 5B         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_162
      0072CC 12 38 47         [24]  834 	lcall	_ak820_outline_0109
                                    835 ;	tmk_core/protocol/report.c:248: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0072CF 90 08 5B         [24]  836 	mov	dptr,#_add_key_bit_report_arg_10000_162
      0072D2 12 37 F9         [24]  837 	lcall	_ak820_outline_0056
                                    838 ;	tmk_core/protocol/report.c:249: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      0072D5 90 08 5A         [24]  839 	mov	dptr,#_add_key_bit_PARM_2
      0072D8 E0               [24]  840 	movx	a,@dptr
      0072D9 FD               [12]  841 	mov	r5,a
      0072DA C4               [12]  842 	swap	a
      0072DB 23               [12]  843 	rl	a
      0072DC 54 1F            [12]  844 	anl	a,#0x1f
      0072DE FC               [12]  845 	mov	r4,a
      0072DF BC 1E 00         [24]  846 	cjne	r4,#0x1e,00112$
      0072E2                        847 00112$:
      0072E2 50 16            [24]  848 	jnc	00103$
                                    849 ;	tmk_core/protocol/report.c:250: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      0072E4 12 73 E3         [24]  850 	lcall	_ak820_outline_0034
      0072E7 80 02            [24]  851 	sjmp	00115$
      0072E9                        852 00114$:
      0072E9 25 E0            [12]  853 	add	a,acc
      0072EB                        854 00115$:
      0072EB D5 F0 FB         [24]  855 	djnz	b,00114$
      0072EE FF               [12]  856 	mov	r7,a
      0072EF 12 48 74         [24]  857 	lcall	_ak820_outline_0189
      0072F2 E0               [24]  858 	movx	a,@dptr
      0072F3 42 07            [12]  859 	orl	ar7,a
      0072F5 12 48 74         [24]  860 	lcall	_ak820_outline_0189
      0072F8 EF               [12]  861 	mov	a,r7
      0072F9 F0               [24]  862 	movx	@dptr,a
      0072FA                        863 00103$:
                                    864 ;	tmk_core/protocol/report.c:254: }
      0072FA 22               [24]  865 	ret
                                    866 ;------------------------------------------------------------
                                    867 ;Allocation info for local variables in function 'del_key_bit'
                                    868 ;------------------------------------------------------------
                                    869 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    870 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    871 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    872 ;------------------------------------------------------------
                                    873 ;	tmk_core/protocol/report.c:260: void del_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function del_key_bit
                                    876 ;	-----------------------------------------
      0072FB                        877 _del_key_bit:
      0072FB 12 38 42         [24]  878 	lcall	_ak820_outline_0108
      0072FE 90 08 5E         [24]  879 	mov	dptr,#_del_key_bit_report_arg_10000_167
      007301 12 38 47         [24]  880 	lcall	_ak820_outline_0109
                                    881 ;	tmk_core/protocol/report.c:261: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007304 90 08 5E         [24]  882 	mov	dptr,#_del_key_bit_report_arg_10000_167
      007307 12 37 F9         [24]  883 	lcall	_ak820_outline_0056
                                    884 ;	tmk_core/protocol/report.c:262: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      00730A 90 08 5D         [24]  885 	mov	dptr,#_del_key_bit_PARM_2
      00730D E0               [24]  886 	movx	a,@dptr
      00730E FD               [12]  887 	mov	r5,a
      00730F C4               [12]  888 	swap	a
      007310 23               [12]  889 	rl	a
      007311 54 1F            [12]  890 	anl	a,#0x1f
      007313 FC               [12]  891 	mov	r4,a
      007314 BC 1E 00         [24]  892 	cjne	r4,#0x1e,00112$
      007317                        893 00112$:
      007317 50 17            [24]  894 	jnc	00103$
                                    895 ;	tmk_core/protocol/report.c:263: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      007319 12 73 E3         [24]  896 	lcall	_ak820_outline_0034
      00731C 80 02            [24]  897 	sjmp	00115$
      00731E                        898 00114$:
      00731E 25 E0            [12]  899 	add	a,acc
      007320                        900 00115$:
      007320 D5 F0 FB         [24]  901 	djnz	b,00114$
      007323 F4               [12]  902 	cpl	a
      007324 FF               [12]  903 	mov	r7,a
      007325 12 48 74         [24]  904 	lcall	_ak820_outline_0189
      007328 E0               [24]  905 	movx	a,@dptr
      007329 52 07            [12]  906 	anl	ar7,a
      00732B 12 48 74         [24]  907 	lcall	_ak820_outline_0189
      00732E EF               [12]  908 	mov	a,r7
      00732F F0               [24]  909 	movx	@dptr,a
      007330                        910 00103$:
                                    911 ;	tmk_core/protocol/report.c:267: }
      007330 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'add_key_to_report'
                                    915 ;------------------------------------------------------------
                                    916 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    917 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    918 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    919 ;------------------------------------------------------------
                                    920 ;	tmk_core/protocol/report.c:274: void add_key_to_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function add_key_to_report
                                    923 ;	-----------------------------------------
      007331                        924 _add_key_to_report:
      007331 12 38 42         [24]  925 	lcall	_ak820_outline_0108
      007334 90 08 61         [24]  926 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      007337 12 38 47         [24]  927 	lcall	_ak820_outline_0109
                                    928 ;	tmk_core/protocol/report.c:275: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00733A 90 08 61         [24]  929 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      00733D 12 37 F9         [24]  930 	lcall	_ak820_outline_0056
                                    931 ;	tmk_core/protocol/report.c:277: if (keyboard_protocol && keymap_config.nkro) {
      007340 90 0E 35         [24]  932 	mov	dptr,#_keyboard_protocol
      007343 E0               [24]  933 	movx	a,@dptr
      007344 60 13            [24]  934 	jz	00102$
      007346 90 0B 3C         [24]  935 	mov	dptr,#_keymap_config
      007349 E0               [24]  936 	movx	a,@dptr
      00734A 30 E7 0C         [24]  937 	jnb	acc.7,00102$
                                    938 ;	tmk_core/protocol/report.c:278: add_key_bit(keyboard_report, key);
      00734D 90 08 60         [24]  939 	mov	dptr,#_add_key_to_report_PARM_2
      007350 E0               [24]  940 	movx	a,@dptr
      007351 90 08 5A         [24]  941 	mov	dptr,#_add_key_bit_PARM_2
      007354 12 48 19         [24]  942 	lcall	_ak820_outline_0066
                                    943 ;	tmk_core/protocol/report.c:279: return;
      007357 41 C6            [12]  944 	ajmp	_add_key_bit
      007359                        945 00102$:
                                    946 ;	tmk_core/protocol/report.c:282: add_key_byte(keyboard_report, key);
      007359 90 08 60         [24]  947 	mov	dptr,#_add_key_to_report_PARM_2
      00735C E0               [24]  948 	movx	a,@dptr
      00735D 90 08 53         [24]  949 	mov	dptr,#_add_key_byte_PARM_2
      007360 12 48 19         [24]  950 	lcall	_ak820_outline_0066
                                    951 ;	tmk_core/protocol/report.c:283: }
      007363 41 2C            [12]  952 	ajmp	_add_key_byte
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'del_key_from_report'
                                    955 ;------------------------------------------------------------
                                    956 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    957 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    958 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    959 ;------------------------------------------------------------
                                    960 ;	tmk_core/protocol/report.c:289: void del_key_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function del_key_from_report
                                    963 ;	-----------------------------------------
      007365                        964 _del_key_from_report:
      007365 12 38 42         [24]  965 	lcall	_ak820_outline_0108
      007368 90 08 64         [24]  966 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      00736B 12 38 47         [24]  967 	lcall	_ak820_outline_0109
                                    968 ;	tmk_core/protocol/report.c:290: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00736E 90 08 64         [24]  969 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      007371 12 37 F9         [24]  970 	lcall	_ak820_outline_0056
                                    971 ;	tmk_core/protocol/report.c:292: if (keyboard_protocol && keymap_config.nkro) {
      007374 90 0E 35         [24]  972 	mov	dptr,#_keyboard_protocol
      007377 E0               [24]  973 	movx	a,@dptr
      007378 60 13            [24]  974 	jz	00102$
      00737A 90 0B 3C         [24]  975 	mov	dptr,#_keymap_config
      00737D E0               [24]  976 	movx	a,@dptr
      00737E 30 E7 0C         [24]  977 	jnb	acc.7,00102$
                                    978 ;	tmk_core/protocol/report.c:293: del_key_bit(keyboard_report, key);
      007381 90 08 63         [24]  979 	mov	dptr,#_del_key_from_report_PARM_2
      007384 E0               [24]  980 	movx	a,@dptr
      007385 90 08 5D         [24]  981 	mov	dptr,#_del_key_bit_PARM_2
      007388 12 48 19         [24]  982 	lcall	_ak820_outline_0066
                                    983 ;	tmk_core/protocol/report.c:294: return;
      00738B 41 FB            [24]  984 	ajmp	_del_key_bit
      00738D                        985 00102$:
                                    986 ;	tmk_core/protocol/report.c:297: del_key_byte(keyboard_report, key);
      00738D 90 08 63         [24]  987 	mov	dptr,#_del_key_from_report_PARM_2
      007390 E0               [24]  988 	movx	a,@dptr
      007391 90 08 57         [24]  989 	mov	dptr,#_del_key_byte_PARM_2
      007394 12 48 19         [24]  990 	lcall	_ak820_outline_0066
                                    991 ;	tmk_core/protocol/report.c:298: }
      007397 41 95            [12]  992 	ajmp	_del_key_byte
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    995 ;------------------------------------------------------------
                                    996 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                    997 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                    998 ;------------------------------------------------------------
                                    999 ;	tmk_core/protocol/report.c:304: void clear_keys_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                   1000 ;	-----------------------------------------
                                   1001 ;	 function clear_keys_from_report
                                   1002 ;	-----------------------------------------
      007399                       1003 _clear_keys_from_report:
      007399 12 38 42         [24] 1004 	lcall	_ak820_outline_0108
      00739C 90 08 66         [24] 1005 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      00739F 12 38 47         [24] 1006 	lcall	_ak820_outline_0109
                                   1007 ;	tmk_core/protocol/report.c:305: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0073A2 90 08 66         [24] 1008 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      0073A5 12 37 F9         [24] 1009 	lcall	_ak820_outline_0056
                                   1010 ;	tmk_core/protocol/report.c:308: if (keyboard_protocol && keymap_config.nkro) {
      0073A8 90 0E 35         [24] 1011 	mov	dptr,#_keyboard_protocol
      0073AB E0               [24] 1012 	movx	a,@dptr
      0073AC 60 1E            [24] 1013 	jz	00102$
      0073AE 90 0B 3C         [24] 1014 	mov	dptr,#_keymap_config
      0073B1 E0               [24] 1015 	movx	a,@dptr
      0073B2 30 E7 17         [24] 1016 	jnb	acc.7,00102$
                                   1017 ;	tmk_core/protocol/report.c:309: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      0073B5 74 02            [12] 1018 	mov	a,#0x02
      0073B7 12 48 68         [24] 1019 	lcall	_ak820_outline_0167
      0073BA 7B 00            [12] 1020 	mov	r3,#0x00
      0073BC 12 74 0F         [24] 1021 	lcall	_ak820_outline_0187
      0073BF 74 1E            [12] 1022 	mov	a,#0x1e
      0073C1 12 38 57         [24] 1023 	lcall	_ak820_outline_0132
      0073C4 12 38 4C         [24] 1024 	lcall	_ak820_outline_0126
      0073C7 8B F0            [24] 1025 	mov	b, r3
                                   1026 ;	tmk_core/protocol/report.c:310: return;
      0073C9 02 BE 24         [24] 1027 	ljmp	_memset
      0073CC                       1028 00102$:
                                   1029 ;	tmk_core/protocol/report.c:313: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      0073CC 74 02            [12] 1030 	mov	a,#0x02
      0073CE 12 48 48         [24] 1031 	lcall	_ak820_outline_0143
      0073D1 7D 00            [12] 1032 	mov	r5,#0x00
      0073D3 12 74 0F         [24] 1033 	lcall	_ak820_outline_0187
      0073D6 74 06            [12] 1034 	mov	a,#0x06
      0073D8 F0               [24] 1035 	movx	@dptr,a
      0073D9 E4               [12] 1036 	clr	a
      0073DA A3               [24] 1037 	inc	dptr
      0073DB 12 48 19         [24] 1038 	lcall	_ak820_outline_0066
      0073DE 8D F0            [24] 1039 	mov	b, r5
                                   1040 ;	tmk_core/protocol/report.c:314: }
      0073E0 02 BE 24         [24] 1041 	ljmp	_memset
                                   1042 	.area CSEG    (CODE)
                                   1043 	.area CONST   (CODE)
                                   1044 	.area CONST   (CODE)
      00BF33                       1045 _KEYCODE2CONSUMER_usages_10000_118:
      00BF33 E2 00                 1046 	.byte #0xe2, #0x00	; 226
      00BF35 E9 00                 1047 	.byte #0xe9, #0x00	; 233
      00BF37 EA 00                 1048 	.byte #0xea, #0x00	; 234
      00BF39 B5 00                 1049 	.byte #0xb5, #0x00	; 181
      00BF3B B6 00                 1050 	.byte #0xb6, #0x00	; 182
      00BF3D B7 00                 1051 	.byte #0xb7, #0x00	; 183
      00BF3F CD 00                 1052 	.byte #0xcd, #0x00	; 205
      00BF41 83 01                 1053 	.byte #0x83, #0x01	; 387
      00BF43 CC 00                 1054 	.byte #0xcc, #0x00	; 204
      00BF45 8A 01                 1055 	.byte #0x8a, #0x01	; 394
      00BF47 92 01                 1056 	.byte #0x92, #0x01	; 402
      00BF49 94 01                 1057 	.byte #0x94, #0x01	; 404
      00BF4B 21 02                 1058 	.byte #0x21, #0x02	; 545
      00BF4D 23 02                 1059 	.byte #0x23, #0x02	; 547
      00BF4F 24 02                 1060 	.byte #0x24, #0x02	; 548
      00BF51 25 02                 1061 	.byte #0x25, #0x02	; 549
      00BF53 26 02                 1062 	.byte #0x26, #0x02	; 550
      00BF55 27 02                 1063 	.byte #0x27, #0x02	; 551
      00BF57 2A 02                 1064 	.byte #0x2a, #0x02	; 554
      00BF59 B3 00                 1065 	.byte #0xb3, #0x00	; 179
      00BF5B B4 00                 1066 	.byte #0xb4, #0x00	; 180
      00BF5D 6F 00                 1067 	.byte #0x6f, #0x00	; 111
      00BF5F 70 00                 1068 	.byte #0x70, #0x00	; 112
      00BF61 9F 01                 1069 	.byte #0x9f, #0x01	; 415
      00BF63 CB 01                 1070 	.byte #0xcb, #0x01	; 459
      00BF65 9F 02                 1071 	.byte #0x9f, #0x02	; 671
      00BF67 A0 02                 1072 	.byte #0xa0, #0x02	; 672
                                   1073 	.area CSEG    (CODE)
                                   1074 	.area XINIT   (CODE)
                                   1075 	.area CABS    (ABS,CODE)
                                   1076 
                                   1077 ; Experimental exact instruction outlining.
                                   1078 	.globl _ak820_outline_0034
                                   1079 	.globl _ak820_outline_0056
                                   1080 	.globl _ak820_outline_0061
                                   1081 	.globl _ak820_outline_0066
                                   1082 	.globl _ak820_outline_0108
                                   1083 	.globl _ak820_outline_0109
                                   1084 	.globl _ak820_outline_0113
                                   1085 	.globl _ak820_outline_0126
                                   1086 	.globl _ak820_outline_0131
                                   1087 	.globl _ak820_outline_0132
                                   1088 	.globl _ak820_outline_0137
                                   1089 	.globl _ak820_outline_0143
                                   1090 	.globl _ak820_outline_0152
                                   1091 	.globl _ak820_outline_0167
                                   1092 	.globl _ak820_outline_0187
                                   1093 	.globl _ak820_outline_0189
                                   1094 
                                   1095 	.area CSEG (CODE)
                                   1096 ; function ak820_outline_0034
      0073E3                       1097 _ak820_outline_0034:
      0073E3 74 02            [12] 1098 	mov	a,#0x02
      0073E5 2E               [12] 1099 	add	a,r6
      0073E6 FE               [12] 1100 	mov	r6,a
      0073E7 E4               [12] 1101 	clr	a
      0073E8 3F               [12] 1102 	addc	a,r7
      0073E9 FF               [12] 1103 	mov	r7,a
      0073EA EC               [12] 1104 	mov	a,r4
      0073EB 2E               [12] 1105 	add	a,r6
      0073EC FC               [12] 1106 	mov	r4,a
      0073ED E4               [12] 1107 	clr	a
      0073EE 3F               [12] 1108 	addc	a,r7
      0073EF FB               [12] 1109 	mov	r3,a
      0073F0 74 07            [12] 1110 	mov	a,#0x07
      0073F2 5D               [12] 1111 	anl	a,r5
      0073F3 F5 F0            [12] 1112 	mov	b,a
      0073F5 05 F0            [12] 1113 	inc	b
      0073F7 74 01            [12] 1114 	mov	a,#0x01
      0073F9 22               [24] 1115 	ret
                                   1116 
                                   1117 	.area CSEG (CODE)
                                   1118 ; function ak820_outline_0137
      0073FA                       1119 _ak820_outline_0137:
      0073FA F4               [12] 1120 	cpl	a
      0073FB 24 01            [12] 1121 	add	a,#0x01
      0073FD C5 F0            [12] 1122 	xch	a,b
      0073FF F4               [12] 1123 	cpl	a
      007400 34 00            [12] 1124 	addc	a,#0x00
      007402 C5 F0            [12] 1125 	xch	a,b
      007404 22               [24] 1126 	ret
                                   1127 
                                   1128 	.area CSEG (CODE)
                                   1129 ; function ak820_outline_0152
      007405                       1130 _ak820_outline_0152:
      007405 74 02            [12] 1131 	mov	a,#0x02
      007407 2E               [12] 1132 	add	a,r6
      007408 FB               [12] 1133 	mov	r3,a
      007409 E4               [12] 1134 	clr	a
      00740A 3F               [12] 1135 	addc	a,r7
      00740B FC               [12] 1136 	mov	r4,a
      00740C ED               [12] 1137 	mov	a,r5
      00740D 2B               [12] 1138 	add	a,r3
      00740E 22               [24] 1139 	ret
                                   1140 
                                   1141 	.area CSEG (CODE)
                                   1142 ; function ak820_outline_0187
      00740F                       1143 _ak820_outline_0187:
      00740F 90 0E 28         [24] 1144 	mov	dptr,#_memset_PARM_2
      007412 E4               [12] 1145 	clr	a
      007413 F0               [24] 1146 	movx	@dptr,a
      007414 90 0E 29         [24] 1147 	mov	dptr,#_memset_PARM_3
      007417 22               [24] 1148 	ret
