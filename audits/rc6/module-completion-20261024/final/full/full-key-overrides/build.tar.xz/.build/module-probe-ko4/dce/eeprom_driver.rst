                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006E0                         85 _eeprom_read_word_addr_10000_91:
      0006E0                         86 	.ds 3
      0006E3                         87 _eeprom_read_word_ret_10000_92:
      0006E3                         88 	.ds 2
      0006E5                         89 _eeprom_read_dword_addr_10000_93:
      0006E5                         90 	.ds 3
      0006E8                         91 _eeprom_read_dword_ret_10000_94:
      0006E8                         92 	.ds 4
      0006EC                         93 _eeprom_write_byte_PARM_2:
      0006EC                         94 	.ds 1
      0006ED                         95 _eeprom_write_byte_addr_10000_95:
      0006ED                         96 	.ds 3
      0006F0                         97 _eeprom_write_word_PARM_2:
      0006F0                         98 	.ds 2
      0006F2                         99 _eeprom_write_word_addr_10000_97:
      0006F2                        100 	.ds 3
      0006F5                        101 _eeprom_write_dword_PARM_2:
      0006F5                        102 	.ds 4
      0006F9                        103 _eeprom_write_dword_addr_10000_99:
      0006F9                        104 	.ds 3
      0006FC                        105 _eeprom_update_byte_PARM_2:
      0006FC                        106 	.ds 1
      0006FD                        107 _eeprom_update_byte_addr_10000_107:
      0006FD                        108 	.ds 3
      000700                        109 _eeprom_update_word_PARM_2:
      000700                        110 	.ds 2
      000702                        111 _eeprom_update_word_addr_10000_111:
      000702                        112 	.ds 3
      000705                        113 _eeprom_update_dword_PARM_2:
      000705                        114 	.ds 4
      000709                        115 _eeprom_update_dword_addr_10000_115:
      000709                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0051DE                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0051DE 12 47 F5         [24]  170 	lcall	_ak820_outline_0040
      0051E1 90 06 E0         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0051E4 12 37 E1         [24]  172 	lcall	_ak820_outline_0019
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0051E7 90 06 E3         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0051EA 12 53 E4         [24]  175 	lcall	_ak820_outline_0155
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0051ED 90 06 E0         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0051F0 12 53 99         [24]  178 	lcall	_ak820_outline_0023
      0051F3 90 05 E6         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0051F6 ED               [12]  180 	mov	a,r5
      0051F7 12 37 E1         [24]  181 	lcall	_ak820_outline_0019
      0051FA 90 05 E9         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0051FD 12 53 DD         [24]  183 	lcall	_ak820_outline_0114
      005200 90 06 E3         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005203 12 45 91         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005206 90 06 E3         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005209 12 53 D4         [24]  188 	lcall	_ak820_outline_0095
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      00520C 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      00520D                        201 _eeprom_read_dword:
      00520D 12 47 F5         [24]  202 	lcall	_ak820_outline_0040
      005210 90 06 E5         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005213 12 37 E1         [24]  204 	lcall	_ak820_outline_0019
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005216 90 06 E8         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005219 12 53 A9         [24]  207 	lcall	_ak820_outline_0054
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      00521C 90 06 E5         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00521F 12 53 99         [24]  210 	lcall	_ak820_outline_0023
      005222 90 05 E6         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005225 ED               [12]  212 	mov	a,r5
      005226 12 37 E1         [24]  213 	lcall	_ak820_outline_0019
      005229 90 05 E9         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00522C 74 04            [12]  215 	mov	a,#0x04
      00522E 12 38 57         [24]  216 	lcall	_ak820_outline_0132
      005231 90 06 E8         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005234 12 45 91         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005237 90 06 E8         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00523A 12 53 B2         [24]  221 	lcall	_ak820_outline_0059
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      00523D 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      00523E                        234 _eeprom_write_byte:
      00523E 12 47 F5         [24]  235 	lcall	_ak820_outline_0040
      005241 90 06 ED         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005244 12 37 E1         [24]  237 	lcall	_ak820_outline_0019
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005247 90 06 ED         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      00524A 12 53 73         [24]  240 	lcall	_ak820_outline_0003
      00524D 74 01            [12]  241 	mov	a,#0x01
      00524F 12 38 57         [24]  242 	lcall	_ak820_outline_0132
      005252 90 06 EC         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005255 02 46 1D         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005258                        256 _eeprom_write_word:
      005258 12 47 F5         [24]  257 	lcall	_ak820_outline_0040
      00525B 90 06 F2         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00525E 12 37 E1         [24]  259 	lcall	_ak820_outline_0019
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005261 90 06 F2         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005264 12 53 73         [24]  262 	lcall	_ak820_outline_0003
      005267 12 53 DD         [24]  263 	lcall	_ak820_outline_0114
      00526A 90 06 F0         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00526D 02 46 1D         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005270                        277 _eeprom_write_dword:
      005270 12 47 F5         [24]  278 	lcall	_ak820_outline_0040
      005273 90 06 F9         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005276 12 37 E1         [24]  280 	lcall	_ak820_outline_0019
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005279 90 06 F9         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00527C 12 53 73         [24]  283 	lcall	_ak820_outline_0003
      00527F 74 04            [12]  284 	mov	a,#0x04
      005281 12 38 57         [24]  285 	lcall	_ak820_outline_0132
      005284 90 06 F5         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005287 02 46 1D         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00528A                        307 _eeprom_update_byte:
      00528A C0 07            [24]  308 	push	ar7
      00528C C0 06            [24]  309 	push	ar6
      00528E C0 05            [24]  310 	push	ar5
      005290 C0 04            [24]  311 	push	ar4
      005292 12 47 F5         [24]  312 	lcall	_ak820_outline_0040
      005295 90 06 FD         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005298 12 37 E1         [24]  314 	lcall	_ak820_outline_0019
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00529B 90 06 FD         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00529E 12 53 8A         [24]  317 	lcall	_ak820_outline_0005
      0052A1 12 45 56         [24]  318 	lcall	_eeprom_read_byte
      0052A4 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      0052A6 90 06 FC         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      0052A9 E0               [24]  322 	movx	a,@dptr
      0052AA FE               [12]  323 	mov	r6,a
      0052AB EF               [12]  324 	mov	a,r7
      0052AC B5 06 02         [24]  325 	cjne	a,ar6,00112$
      0052AF 80 36            [24]  326 	sjmp	00103$
      0052B1                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      0052B1 90 06 FD         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0052B4 12 38 18         [24]  330 	lcall	_ak820_outline_0065
      0052B7 A3               [24]  331 	inc	dptr
      0052B8 E0               [24]  332 	movx	a,@dptr
      0052B9 FF               [12]  333 	mov	r7,a
      0052BA 90 06 EC         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      0052BD EE               [12]  335 	mov	a,r6
      0052BE F0               [24]  336 	movx	@dptr,a
      0052BF 12 38 4C         [24]  337 	lcall	_ak820_outline_0126
      0052C2 8F F0            [24]  338 	mov	b, r7
      0052C4 C0 07            [24]  339 	push	ar7
      0052C6 C0 06            [24]  340 	push	ar6
      0052C8 C0 05            [24]  341 	push	ar5
      0052CA C0 04            [24]  342 	push	ar4
      0052CC C0 03            [24]  343 	push	ar3
      0052CE C0 02            [24]  344 	push	ar2
      0052D0 C0 01            [24]  345 	push	ar1
      0052D2 C0 00            [24]  346 	push	ar0
      0052D4 12 52 3E         [24]  347 	lcall	_eeprom_write_byte
      0052D7 D0 00            [24]  348 	pop	ar0
      0052D9 D0 01            [24]  349 	pop	ar1
      0052DB D0 02            [24]  350 	pop	ar2
      0052DD D0 03            [24]  351 	pop	ar3
      0052DF D0 04            [24]  352 	pop	ar4
      0052E1 D0 05            [24]  353 	pop	ar5
      0052E3 D0 06            [24]  354 	pop	ar6
      0052E5 D0 07            [24]  355 	pop	ar7
      0052E7                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      0052E7 D0 04            [24]  358 	pop	ar4
      0052E9 D0 05            [24]  359 	pop	ar5
      0052EB D0 06            [24]  360 	pop	ar6
      0052ED D0 07            [24]  361 	pop	ar7
      0052EF 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      0052F0                        374 _eeprom_update_word:
      0052F0 12 47 F5         [24]  375 	lcall	_ak820_outline_0040
      0052F3 90 07 02         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0052F6 12 37 E1         [24]  377 	lcall	_ak820_outline_0019
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0052F9 90 07 02         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0052FC 12 53 8A         [24]  380 	lcall	_ak820_outline_0005
      0052FF 12 51 DE         [24]  381 	lcall	_eeprom_read_word
      005302 12 48 43         [24]  382 	lcall	_ak820_outline_0140
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      005305 90 07 00         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      005308 12 38 18         [24]  385 	lcall	_ak820_outline_0065
      00530B EE               [12]  386 	mov	a,r6
      00530C B5 04 05         [24]  387 	cjne	a,ar4,00112$
      00530F EF               [12]  388 	mov	a,r7
      005310 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      005313 22               [24]  390 	ret
      005314                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005314 90 07 02         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005317 E0               [24]  394 	movx	a,@dptr
      005318 FB               [12]  395 	mov	r3,a
      005319 A3               [24]  396 	inc	dptr
      00531A 12 37 F9         [24]  397 	lcall	_ak820_outline_0056
      00531D 90 06 F0         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      005320 12 38 24         [24]  399 	lcall	_ak820_outline_0078
      005323 8B 82            [24]  400 	mov	dpl, r3
      005325 8E 83            [24]  401 	mov	dph, r6
      005327 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      005329 02 52 58         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      00532C                        416 _eeprom_update_dword:
      00532C 12 47 F5         [24]  417 	lcall	_ak820_outline_0040
      00532F 90 07 09         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005332 12 37 E1         [24]  419 	lcall	_ak820_outline_0019
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005335 90 07 09         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005338 12 53 8A         [24]  422 	lcall	_ak820_outline_0005
      00533B 12 52 0D         [24]  423 	lcall	_eeprom_read_dword
      00533E 12 53 C3         [24]  424 	lcall	_ak820_outline_0062
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      005341 90 07 05         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      005344 E0               [24]  427 	movx	a,@dptr
      005345 F8               [12]  428 	mov	r0,a
      005346 A3               [24]  429 	inc	dptr
      005347 12 53 CB         [24]  430 	lcall	_ak820_outline_0094
      00534A EC               [12]  431 	mov	a,r4
      00534B B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      00534E ED               [12]  433 	mov	a,r5
      00534F B5 01 09         [24]  434 	cjne	a,ar1,00112$
      005352 EE               [12]  435 	mov	a,r6
      005353 B5 02 05         [24]  436 	cjne	a,ar2,00112$
      005356 EF               [12]  437 	mov	a,r7
      005357 B5 03 01         [24]  438 	cjne	a,ar3,00112$
      00535A 22               [24]  439 	ret
      00535B                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      00535B 90 07 09         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00535E 12 53 99         [24]  443 	lcall	_ak820_outline_0023
      005361 90 06 F5         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      005364 12 53 E9         [24]  445 	lcall	_ak820_outline_0168
      005367 EA               [12]  446 	mov	a,r2
      005368 A3               [24]  447 	inc	dptr
      005369 F0               [24]  448 	movx	@dptr,a
      00536A EB               [12]  449 	mov	a,r3
      00536B A3               [24]  450 	inc	dptr
      00536C F0               [24]  451 	movx	@dptr,a
      00536D 12 53 A2         [24]  452 	lcall	_ak820_outline_0049
                                    453 ;	drivers/eeprom/eeprom_driver.c:101: }
      005370 02 52 70         [24]  454 	ljmp	_eeprom_write_dword
                                    455 	.area CSEG    (CODE)
                                    456 	.area CONST   (CODE)
                                    457 	.area XINIT   (CODE)
                                    458 	.area CABS    (ABS,CODE)
                                    459 
                                    460 ; Experimental exact instruction outlining.
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0005
                                    463 	.globl _ak820_outline_0019
                                    464 	.globl _ak820_outline_0023
                                    465 	.globl _ak820_outline_0040
                                    466 	.globl _ak820_outline_0049
                                    467 	.globl _ak820_outline_0054
                                    468 	.globl _ak820_outline_0056
                                    469 	.globl _ak820_outline_0059
                                    470 	.globl _ak820_outline_0062
                                    471 	.globl _ak820_outline_0065
                                    472 	.globl _ak820_outline_0078
                                    473 	.globl _ak820_outline_0094
                                    474 	.globl _ak820_outline_0095
                                    475 	.globl _ak820_outline_0114
                                    476 	.globl _ak820_outline_0126
                                    477 	.globl _ak820_outline_0132
                                    478 	.globl _ak820_outline_0140
                                    479 	.globl _ak820_outline_0155
                                    480 	.globl _ak820_outline_0168
                                    481 
                                    482 	.area CSEG (CODE)
                                    483 ; function ak820_outline_0003
      005373                        484 _ak820_outline_0003:
      005373 E0               [24]  485 	movx	a,@dptr
      005374 FD               [12]  486 	mov	r5,a
      005375 A3               [24]  487 	inc	dptr
      005376 E0               [24]  488 	movx	a,@dptr
      005377 FE               [12]  489 	mov	r6,a
      005378 A3               [24]  490 	inc	dptr
      005379 E0               [24]  491 	movx	a,@dptr
      00537A FF               [12]  492 	mov	r7,a
      00537B 90 05 EF         [24]  493 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00537E ED               [12]  494 	mov	a,r5
      00537F F0               [24]  495 	movx	@dptr,a
      005380 EE               [12]  496 	mov	a,r6
      005381 A3               [24]  497 	inc	dptr
      005382 F0               [24]  498 	movx	@dptr,a
      005383 EF               [12]  499 	mov	a,r7
      005384 A3               [24]  500 	inc	dptr
      005385 F0               [24]  501 	movx	@dptr,a
      005386 90 05 F2         [24]  502 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005389 22               [24]  503 	ret
                                    504 
                                    505 	.area CSEG (CODE)
                                    506 ; function ak820_outline_0005
      00538A                        507 _ak820_outline_0005:
      00538A E0               [24]  508 	movx	a,@dptr
      00538B FD               [12]  509 	mov	r5,a
      00538C A3               [24]  510 	inc	dptr
      00538D E0               [24]  511 	movx	a,@dptr
      00538E FE               [12]  512 	mov	r6,a
      00538F A3               [24]  513 	inc	dptr
      005390 E0               [24]  514 	movx	a,@dptr
      005391 FF               [12]  515 	mov	r7,a
      005392 8D 82            [24]  516 	mov	dpl,r5
      005394 8E 83            [24]  517 	mov	dph,r6
      005396 8F F0            [24]  518 	mov	b,r7
      005398 22               [24]  519 	ret
                                    520 
                                    521 	.area CSEG (CODE)
                                    522 ; function ak820_outline_0023
      005399                        523 _ak820_outline_0023:
      005399 E0               [24]  524 	movx	a,@dptr
      00539A FD               [12]  525 	mov	r5,a
      00539B A3               [24]  526 	inc	dptr
      00539C E0               [24]  527 	movx	a,@dptr
      00539D FE               [12]  528 	mov	r6,a
      00539E A3               [24]  529 	inc	dptr
      00539F E0               [24]  530 	movx	a,@dptr
      0053A0 FF               [12]  531 	mov	r7,a
      0053A1 22               [24]  532 	ret
                                    533 
                                    534 	.area CSEG (CODE)
                                    535 ; function ak820_outline_0049
      0053A2                        536 _ak820_outline_0049:
      0053A2 8D 82            [24]  537 	mov	dpl,r5
      0053A4 8E 83            [24]  538 	mov	dph,r6
      0053A6 8F F0            [24]  539 	mov	b,r7
      0053A8 22               [24]  540 	ret
                                    541 
                                    542 	.area CSEG (CODE)
                                    543 ; function ak820_outline_0054
      0053A9                        544 _ak820_outline_0054:
      0053A9 E4               [12]  545 	clr	a
      0053AA F0               [24]  546 	movx	@dptr,a
      0053AB A3               [24]  547 	inc	dptr
      0053AC F0               [24]  548 	movx	@dptr,a
      0053AD A3               [24]  549 	inc	dptr
      0053AE F0               [24]  550 	movx	@dptr,a
      0053AF A3               [24]  551 	inc	dptr
      0053B0 F0               [24]  552 	movx	@dptr,a
      0053B1 22               [24]  553 	ret
                                    554 
                                    555 	.area CSEG (CODE)
                                    556 ; function ak820_outline_0059
      0053B2                        557 _ak820_outline_0059:
      0053B2 E0               [24]  558 	movx	a,@dptr
      0053B3 FC               [12]  559 	mov	r4,a
      0053B4 A3               [24]  560 	inc	dptr
      0053B5 E0               [24]  561 	movx	a,@dptr
      0053B6 FD               [12]  562 	mov	r5,a
      0053B7 A3               [24]  563 	inc	dptr
      0053B8 E0               [24]  564 	movx	a,@dptr
      0053B9 FE               [12]  565 	mov	r6,a
      0053BA A3               [24]  566 	inc	dptr
      0053BB E0               [24]  567 	movx	a,@dptr
      0053BC 8C 82            [24]  568 	mov	dpl,r4
      0053BE 8D 83            [24]  569 	mov	dph,r5
      0053C0 8E F0            [24]  570 	mov	b,r6
      0053C2 22               [24]  571 	ret
                                    572 
                                    573 	.area CSEG (CODE)
                                    574 ; function ak820_outline_0062
      0053C3                        575 _ak820_outline_0062:
      0053C3 AC 82            [24]  576 	mov	r4,dpl
      0053C5 AD 83            [24]  577 	mov	r5,dph
      0053C7 AE F0            [24]  578 	mov	r6,b
      0053C9 FF               [12]  579 	mov	r7,a
      0053CA 22               [24]  580 	ret
                                    581 
                                    582 	.area CSEG (CODE)
                                    583 ; function ak820_outline_0094
      0053CB                        584 _ak820_outline_0094:
      0053CB E0               [24]  585 	movx	a,@dptr
      0053CC F9               [12]  586 	mov	r1,a
      0053CD A3               [24]  587 	inc	dptr
      0053CE E0               [24]  588 	movx	a,@dptr
      0053CF FA               [12]  589 	mov	r2,a
      0053D0 A3               [24]  590 	inc	dptr
      0053D1 E0               [24]  591 	movx	a,@dptr
      0053D2 FB               [12]  592 	mov	r3,a
      0053D3 22               [24]  593 	ret
                                    594 
                                    595 	.area CSEG (CODE)
                                    596 ; function ak820_outline_0095
      0053D4                        597 _ak820_outline_0095:
      0053D4 E0               [24]  598 	movx	a,@dptr
      0053D5 FE               [12]  599 	mov	r6,a
      0053D6 A3               [24]  600 	inc	dptr
      0053D7 E0               [24]  601 	movx	a,@dptr
      0053D8 8E 82            [24]  602 	mov	dpl,r6
      0053DA F5 83            [12]  603 	mov	dph,a
      0053DC 22               [24]  604 	ret
                                    605 
                                    606 	.area CSEG (CODE)
                                    607 ; function ak820_outline_0114
      0053DD                        608 _ak820_outline_0114:
      0053DD 74 02            [12]  609 	mov	a,#0x02
      0053DF F0               [24]  610 	movx	@dptr,a
      0053E0 E4               [12]  611 	clr	a
      0053E1 A3               [24]  612 	inc	dptr
      0053E2 F0               [24]  613 	movx	@dptr,a
      0053E3 22               [24]  614 	ret
                                    615 
                                    616 	.area CSEG (CODE)
                                    617 ; function ak820_outline_0155
      0053E4                        618 _ak820_outline_0155:
      0053E4 E4               [12]  619 	clr	a
      0053E5 F0               [24]  620 	movx	@dptr,a
      0053E6 A3               [24]  621 	inc	dptr
      0053E7 F0               [24]  622 	movx	@dptr,a
      0053E8 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0168
      0053E9                        627 _ak820_outline_0168:
      0053E9 E8               [12]  628 	mov	a,r0
      0053EA F0               [24]  629 	movx	@dptr,a
      0053EB E9               [12]  630 	mov	a,r1
      0053EC A3               [24]  631 	inc	dptr
      0053ED F0               [24]  632 	movx	@dptr,a
      0053EE 22               [24]  633 	ret
