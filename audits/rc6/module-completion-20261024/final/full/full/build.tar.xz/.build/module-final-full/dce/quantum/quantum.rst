                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _register_code16
                                    282 	.globl _unregister_code16
                                    283 	.globl _reset_keyboard
                                    284 	.globl _soft_reset_keyboard
                                    285 	.globl _get_record_keycode
                                    286 	.globl _pre_process_record_quantum
                                    287 	.globl _process_record_quantum
                                    288 	.globl _process_record_quantum_helper
                                    289 	.globl _shutdown_user
                                    290 ;--------------------------------------------------------
                                    291 ; special function registers
                                    292 ;--------------------------------------------------------
                                    293 	.area RSEG    (ABS,DATA)
      000000                        294 	.org 0x0000
                           0000D0   295 _PSW	=	0x00d0
                           0000E0   296 _ACC	=	0x00e0
                           0000F0   297 _B	=	0x00f0
                           0000FD   298 _A_INV	=	0x00fd
                           000081   299 _SP	=	0x0081
                           000082   300 _DPL	=	0x0082
                           000083   301 _DPH	=	0x0083
                           0000A1   302 _SAFE_MOD	=	0x00a1
                           0000B1   303 _GLOBAL_CFG	=	0x00b1
                           000087   304 _PCON	=	0x0087
                           0000BA   305 _POWER_CFG	=	0x00ba
                           0000B9   306 _CLOCK_CFG	=	0x00b9
                           0000A9   307 _WAKE_CTRL	=	0x00a9
                           0000FE   308 _RESET_KEEP	=	0x00fe
                           0000FF   309 _WDOG_COUNT	=	0x00ff
                           0000A8   310 _IE	=	0x00a8
                           0000B8   311 _IP	=	0x00b8
                           0000E8   312 _IE_EX	=	0x00e8
                           0000E9   313 _IP_EX	=	0x00e9
                           0000B2   314 _GPIO_IE	=	0x00b2
                           008584   315 _ROM_ADDR	=	0x8584
                           000084   316 _ROM_ADDR_L	=	0x0084
                           000085   317 _ROM_ADDR_H	=	0x0085
                           008F8E   318 _ROM_DATA_HI	=	0x8f8e
                           00008E   319 _ROM_DATA_HL	=	0x008e
                           00008F   320 _ROM_DATA_HH	=	0x008f
                           000086   321 _ROM_CTRL	=	0x0086
                           000080   322 _P0	=	0x0080
                           0000C4   323 _P0_MOD_OC	=	0x00c4
                           0000C5   324 _P0_DIR_PU	=	0x00c5
                           000090   325 _P1	=	0x0090
                           000092   326 _P1_MOD_OC	=	0x0092
                           000093   327 _P1_DIR_PU	=	0x0093
                           0000A0   328 _P2	=	0x00a0
                           000094   329 _P2_MOD_OC	=	0x0094
                           000095   330 _P2_DIR_PU	=	0x0095
                           0000B0   331 _P3	=	0x00b0
                           000096   332 _P3_MOD_OC	=	0x0096
                           000097   333 _P3_DIR_PU	=	0x0097
                           0000C0   334 _P4	=	0x00c0
                           0000C2   335 _P4_MOD_OC	=	0x00c2
                           0000C3   336 _P4_DIR_PU	=	0x00c3
                           0000C1   337 _P4_LED_KEY	=	0x00c1
                           0000AA   338 _P5_IN	=	0x00aa
                           0000AB   339 _P5_OUT_PU	=	0x00ab
                           0000AC   340 _P5_DIR	=	0x00ac
                           0000AD   341 _P6_IN	=	0x00ad
                           0000AE   342 _P6_OUT_PU	=	0x00ae
                           0000AF   343 _P6_DIR	=	0x00af
                           0000F1   344 _P7	=	0x00f1
                           0000A2   345 _XBUS_AUX	=	0x00a2
                           000088   346 _TCON	=	0x0088
                           000089   347 _TMOD	=	0x0089
                           00008A   348 _TL0	=	0x008a
                           00008B   349 _TL1	=	0x008b
                           00008C   350 _TH0	=	0x008c
                           00008D   351 _TH1	=	0x008d
                           000098   352 _SCON	=	0x0098
                           000099   353 _SBUF	=	0x0099
                           0000C8   354 _T2CON	=	0x00c8
                           0000C9   355 _T2MOD	=	0x00c9
                           00CBCA   356 _RCAP2	=	0xcbca
                           0000CA   357 _RCAP2L	=	0x00ca
                           0000CB   358 _RCAP2H	=	0x00cb
                           00CDCC   359 _T2COUNT	=	0xcdcc
                           0000CC   360 _TL2	=	0x00cc
                           0000CD   361 _TH2	=	0x00cd
                           00CFCE   362 _T2CAP1	=	0xcfce
                           0000CE   363 _T2CAP1L	=	0x00ce
                           0000CF   364 _T2CAP1H	=	0x00cf
                           0000F8   365 _SPI0_STAT	=	0x00f8
                           0000F9   366 _SPI0_DATA	=	0x00f9
                           0000FA   367 _SPI0_CTRL	=	0x00fa
                           0000FB   368 _SPI0_CK_SE	=	0x00fb
                           0000FC   369 _SPI0_SETUP	=	0x00fc
                           0000BC   370 _SCON1	=	0x00bc
                           0000BD   371 _SBUF1	=	0x00bd
                           0000BE   372 _SBAUD1	=	0x00be
                           0000BF   373 _SIF1	=	0x00bf
                           0000B4   374 _SPI1_STAT	=	0x00b4
                           0000B5   375 _SPI1_DATA	=	0x00b5
                           0000B6   376 _SPI1_CTRL	=	0x00b6
                           0000B7   377 _SPI1_CK_SE	=	0x00b7
                           0000F3   378 _ADC_CTRL	=	0x00f3
                           00F5F4   379 _ADC_DAT	=	0xf5f4
                           0000F4   380 _ADC_DAT_L	=	0x00f4
                           0000F5   381 _ADC_DAT_H	=	0x00f5
                           0000F6   382 _ADC_CHAN	=	0x00f6
                           0000A6   383 _LED_COMMON	=	0x00a6
                           0000A7   384 _LED_PWM_OE	=	0x00a7
                           00C7C6   385 _LED_DMA	=	0xc7c6
                           0000C6   386 _LED_DMA_L	=	0x00c6
                           0000C7   387 _LED_DMA_H	=	0x00c7
                           0000F7   388 _LED_STATUS	=	0x00f7
                           0000B3   389 _I2CX_INT	=	0x00b3
                           0000BB   390 _I2CS_INT_ST	=	0x00bb
                                    391 ;--------------------------------------------------------
                                    392 ; special function bits
                                    393 ;--------------------------------------------------------
                                    394 	.area RSEG    (ABS,DATA)
      000000                        395 	.org 0x0000
                           0000D7   396 _CY	=	0x00d7
                           0000D6   397 _AC	=	0x00d6
                           0000D5   398 _F0	=	0x00d5
                           0000D4   399 _RS1	=	0x00d4
                           0000D3   400 _RS0	=	0x00d3
                           0000D2   401 _OV	=	0x00d2
                           0000D1   402 _F1	=	0x00d1
                           0000D0   403 _P	=	0x00d0
                           0000AF   404 _EA	=	0x00af
                           0000AE   405 _E_DIS	=	0x00ae
                           0000AD   406 _ET2	=	0x00ad
                           0000AC   407 _ES	=	0x00ac
                           0000AB   408 _ET1	=	0x00ab
                           0000AA   409 _EX1	=	0x00aa
                           0000A9   410 _ET0	=	0x00a9
                           0000A8   411 _EX0	=	0x00a8
                           0000BF   412 _PH_FLAG	=	0x00bf
                           0000BE   413 _PL_FLAG	=	0x00be
                           0000BD   414 _PT2	=	0x00bd
                           0000BC   415 _PS	=	0x00bc
                           0000BB   416 _PT1	=	0x00bb
                           0000BA   417 _PX1	=	0x00ba
                           0000B9   418 _PT0	=	0x00b9
                           0000B8   419 _PX0	=	0x00b8
                           0000EF   420 _IE_WDOG	=	0x00ef
                           0000EE   421 _IE_GPIO	=	0x00ee
                           0000ED   422 _IE_PWM_I2C	=	0x00ed
                           0000EC   423 _IE_UART1	=	0x00ec
                           0000EB   424 _IE_ADC	=	0x00eb
                           0000E9   425 _IE_USB	=	0x00e9
                           0000E8   426 _IE_SPI0	=	0x00e8
                           000087   427 _P0_7	=	0x0087
                           000086   428 _P0_6	=	0x0086
                           000085   429 _P0_5	=	0x0085
                           000084   430 _P0_4	=	0x0084
                           000083   431 _P0_3	=	0x0083
                           000082   432 _P0_2	=	0x0082
                           000081   433 _P0_1	=	0x0081
                           000080   434 _P0_0	=	0x0080
                           000081   435 _SDA0	=	0x0081
                           000080   436 _SCL0	=	0x0080
                           000083   437 _TXD_	=	0x0083
                           000082   438 _RXD_	=	0x0082
                           000085   439 _AIN13	=	0x0085
                           000084   440 _AIN12	=	0x0084
                           000083   441 _AIN11	=	0x0083
                           000082   442 _AIN10	=	0x0082
                           000081   443 _AIN9	=	0x0081
                           000080   444 _AIN8	=	0x0080
                           000097   445 _P1_7	=	0x0097
                           000096   446 _P1_6	=	0x0096
                           000095   447 _P1_5	=	0x0095
                           000094   448 _P1_4	=	0x0094
                           000093   449 _P1_3	=	0x0093
                           000092   450 _P1_2	=	0x0092
                           000091   451 _P1_1	=	0x0091
                           000090   452 _P1_0	=	0x0090
                           000097   453 _TXD1_	=	0x0097
                           000096   454 _RXD1_	=	0x0096
                           000097   455 _SCK	=	0x0097
                           000096   456 _MISO	=	0x0096
                           000095   457 _MOSI	=	0x0095
                           000094   458 _SCS	=	0x0094
                           000092   459 _INT0_	=	0x0092
                           000091   460 _T2EX	=	0x0091
                           000091   461 _CAP2	=	0x0091
                           000090   462 _T2	=	0x0090
                           000090   463 _CAP1	=	0x0090
                           000097   464 _AIN7	=	0x0097
                           000096   465 _AIN6	=	0x0096
                           000095   466 _AIN5	=	0x0095
                           000094   467 _AIN4	=	0x0094
                           000093   468 _AIN3	=	0x0093
                           000092   469 _AIN2	=	0x0092
                           000091   470 _AIN1	=	0x0091
                           000090   471 _AIN0	=	0x0090
                           0000A7   472 _P2_7	=	0x00a7
                           0000A6   473 _P2_6	=	0x00a6
                           0000A5   474 _P2_5	=	0x00a5
                           0000A4   475 _P2_4	=	0x00a4
                           0000A3   476 _P2_3	=	0x00a3
                           0000A2   477 _P2_2	=	0x00a2
                           0000A1   478 _P2_1	=	0x00a1
                           0000A0   479 _P2_0	=	0x00a0
                           0000A7   480 _TXD1	=	0x00a7
                           0000A6   481 _RXD1	=	0x00a6
                           0000A5   482 _T2EX_	=	0x00a5
                           0000A5   483 _CAP2_	=	0x00a5
                           0000A4   484 _T2_	=	0x00a4
                           0000A4   485 _CAP1_	=	0x00a4
                           0000B7   486 _P3_7	=	0x00b7
                           0000B6   487 _P3_6	=	0x00b6
                           0000B5   488 _P3_5	=	0x00b5
                           0000B4   489 _P3_4	=	0x00b4
                           0000B3   490 _P3_3	=	0x00b3
                           0000B2   491 _P3_2	=	0x00b2
                           0000B1   492 _P3_1	=	0x00b1
                           0000B0   493 _P3_0	=	0x00b0
                           0000B7   494 _SCK1	=	0x00b7
                           0000B6   495 _MISO1	=	0x00b6
                           0000B5   496 _MOSI1	=	0x00b5
                           0000B5   497 _T1	=	0x00b5
                           0000B4   498 _T0	=	0x00b4
                           0000B3   499 _INT1	=	0x00b3
                           0000B2   500 _INT0	=	0x00b2
                           0000B1   501 _TXD	=	0x00b1
                           0000B0   502 _RXD	=	0x00b0
                           0000C6   503 _P4_6	=	0x00c6
                           0000C5   504 _P4_5	=	0x00c5
                           0000C4   505 _P4_4	=	0x00c4
                           0000C3   506 _P4_3	=	0x00c3
                           0000C2   507 _P4_2	=	0x00c2
                           0000C1   508 _P4_1	=	0x00c1
                           0000C0   509 _P4_0	=	0x00c0
                           00008F   510 _TF1	=	0x008f
                           00008E   511 _TR1	=	0x008e
                           00008D   512 _TF0	=	0x008d
                           00008C   513 _TR0	=	0x008c
                           00008B   514 _IE1	=	0x008b
                           00008A   515 _IT1	=	0x008a
                           000089   516 _IE0	=	0x0089
                           000088   517 _IT0	=	0x0088
                           00009F   518 _SM0	=	0x009f
                           00009E   519 _SM1	=	0x009e
                           00009D   520 _SM2	=	0x009d
                           00009C   521 _REN	=	0x009c
                           00009B   522 _TB8	=	0x009b
                           00009A   523 _RB8	=	0x009a
                           000099   524 _TI	=	0x0099
                           000098   525 _RI	=	0x0098
                           0000CF   526 _TF2	=	0x00cf
                           0000CF   527 _CAP1F	=	0x00cf
                           0000CE   528 _EXF2	=	0x00ce
                           0000CD   529 _RCLK	=	0x00cd
                           0000CC   530 _TCLK	=	0x00cc
                           0000CB   531 _EXEN2	=	0x00cb
                           0000CA   532 _TR2	=	0x00ca
                           0000C9   533 _C_T2	=	0x00c9
                           0000C8   534 _CP_RL2	=	0x00c8
                           0000FF   535 _S0_FST_ACT	=	0x00ff
                           0000FE   536 _S0_IF_OV	=	0x00fe
                           0000FD   537 _S0_IF_FIRST	=	0x00fd
                           0000FC   538 _S0_IF_BYTE	=	0x00fc
                           0000FB   539 _S0_FREE	=	0x00fb
                           0000FA   540 _S0_T_FIFO	=	0x00fa
                           0000F8   541 _S0_R_FIFO	=	0x00f8
                           0000F7   542 _ADC_START	=	0x00f7
                                    543 ;--------------------------------------------------------
                                    544 ; overlayable register banks
                                    545 ;--------------------------------------------------------
                                    546 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        547 	.ds 8
                                    548 ;--------------------------------------------------------
                                    549 ; internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area DSEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; overlayable items in internal ram
                                    554 ;--------------------------------------------------------
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000023                        568 _get_record_keycode_sloc0_1_0:
      000023                        569 	.ds 1
      000024                        570 _pre_process_record_quantum_sloc0_1_0:
      000024                        571 	.ds 1
      000025                        572 _process_ak820_nkro_sloc0_1_0:
      000025                        573 	.ds 1
                                    574 ;--------------------------------------------------------
                                    575 ; paged external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area PSEG    (PAG,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; uninitialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XSEG    (XDATA)
      000BCC                        582 _extract_mod_bits_code_10000_599:
      000BCC                        583 	.ds 2
      000BCE                        584 _register_code16_code_10000_605:
      000BCE                        585 	.ds 2
      000BD0                        586 _unregister_code16_code_10000_610:
      000BD0                        587 	.ds 2
      000BD2                        588 _get_record_keycode_PARM_2:
      000BD2                        589 	.ds 1
      000BD3                        590 _get_record_keycode_record_argument_10000_648:
      000BD3                        591 	.ds 2
      000BD5                        592 _pre_process_record_quantum_record_argument_10000_654:
      000BD5                        593 	.ds 2
      000BD7                        594 _process_record_quantum_record_10000_658:
      000BD7                        595 	.ds 2
      000BD9                        596 _process_ak820_nkro_PARM_2:
      000BD9                        597 	.ds 3
      000BDC                        598 _process_ak820_nkro_keycode_10000_660:
      000BDC                        599 	.ds 2
      000BDE                        600 _process_record_quantum_helper_PARM_2:
      000BDE                        601 	.ds 2
      000BE0                        602 _process_record_quantum_helper_keycode_10000_665:
      000BE0                        603 	.ds 2
      000BE2                        604 _get_u8_str_last_num_10000_691:
      000BE2                        605 	.ds 1
      000BE3                        606 _get_u16_str_last_num_10000_695:
      000BE3                        607 	.ds 2
                                    608 ;--------------------------------------------------------
                                    609 ; absolute external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area XABS    (ABS,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; initialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XISEG   (XDATA)
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT0 (CODE)
                                    618 	.area GSINIT1 (CODE)
                                    619 	.area GSINIT2 (CODE)
                                    620 	.area GSINIT3 (CODE)
                                    621 	.area GSINIT4 (CODE)
                                    622 	.area GSINIT5 (CODE)
                                    623 	.area GSINIT  (CODE)
                                    624 	.area GSFINAL (CODE)
                                    625 	.area CSEG    (CODE)
                                    626 ;--------------------------------------------------------
                                    627 ; global & static initialisations
                                    628 ;--------------------------------------------------------
                                    629 	.area HOME    (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area GSINIT  (CODE)
                                    633 ;------------------------------------------------------------
                                    634 ;Allocation info for local variables in function 'get_u8_str'
                                    635 ;------------------------------------------------------------
                                    636 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    637 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_690'
                                    638 ;buf           Allocated with name '_get_u8_str_buf_10000_691'
                                    639 ;last_num      Allocated with name '_get_u8_str_last_num_10000_691'
                                    640 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_691'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0B E2         [24]  643 	mov	dptr,#_get_u8_str_last_num_10000_691
      0030F6 74 FF            [12]  644 	mov	a,#0xff
      0030F8 F0               [24]  645 	movx	@dptr,a
                                    646 ;------------------------------------------------------------
                                    647 ;Allocation info for local variables in function 'get_u16_str'
                                    648 ;------------------------------------------------------------
                                    649 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    650 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_694'
                                    651 ;buf           Allocated with name '_get_u16_str_buf_10000_695'
                                    652 ;last_num      Allocated with name '_get_u16_str_last_num_10000_695'
                                    653 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_695'
                                    654 ;------------------------------------------------------------
                                    655 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0B E3         [24]  656 	mov	dptr,#_get_u16_str_last_num_10000_695
      0030FC 74 FF            [12]  657 	mov	a,#0xff
      0030FE F0               [24]  658 	movx	@dptr,a
      0030FF E4               [12]  659 	clr	a
      003100 A3               [24]  660 	inc	dptr
      003101 F0               [24]  661 	movx	@dptr,a
                                    662 ;--------------------------------------------------------
                                    663 ; Home
                                    664 ;--------------------------------------------------------
                                    665 	.area HOME    (CODE)
                                    666 	.area HOME    (CODE)
                                    667 ;--------------------------------------------------------
                                    668 ; code
                                    669 ;--------------------------------------------------------
                                    670 	.area CSEG    (CODE)
                                    671 ;------------------------------------------------------------
                                    672 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    673 ;------------------------------------------------------------
                                    674 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    677 ;	-----------------------------------------
                           000007   678 	ar7 = 0x07
                           000006   679 	ar6 = 0x06
                           000005   680 	ar5 = 0x05
                           000004   681 	ar4 = 0x04
                           000003   682 	ar3 = 0x03
                           000002   683 	ar2 = 0x02
                           000001   684 	ar1 = 0x01
                           000000   685 	ar0 = 0x00
                                    686 ;	 function extract_mod_bits
                                    687 ;	-----------------------------------------
      009BE1                        688 _extract_mod_bits:
      009BE1 12 38 44         [24]  689 	lcall	_ak820_outline_0103
      009BE4 90 0B CC         [24]  690 	mov	dptr,#_extract_mod_bits_code_10000_599
      009BE7 12 38 49         [24]  691 	lcall	_ak820_outline_0104
                                    692 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      009BEA 90 0B CC         [24]  693 	mov	dptr,#_extract_mod_bits_code_10000_599
      009BED E0               [24]  694 	movx	a,@dptr
      009BEE A3               [24]  695 	inc	dptr
      009BEF E0               [24]  696 	movx	a,@dptr
                                    697 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009BF0 FF               [12]  698 	mov	r7,a
      009BF1 60 05            [24]  699 	jz	00101$
      009BF3 EF               [12]  700 	mov	a,r7
      009BF4 24 E0            [12]  701 	add	a,#0xff - 0x1f
      009BF6 50 04            [24]  702 	jnc	00102$
                                    703 ;	free result
      009BF8                        704 00101$:
      009BF8 75 82 00         [24]  705 	mov	dpl, #0x00
      009BFB 22               [24]  706 	ret
      009BFC                        707 00102$:
                                    708 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009BFC EF               [12]  709 	mov	a,r7
      009BFD 30 E4 07         [24]  710 	jnb	acc.4,00106$
      009C00 EF               [12]  711 	mov	a,r7
      009C01 C4               [12]  712 	swap	a
      009C02 54 F0            [12]  713 	anl	a,#0xf0
      009C04 FE               [12]  714 	mov	r6,a
      009C05 80 02            [24]  715 	sjmp	00107$
      009C07                        716 00106$:
      009C07 8F 06            [24]  717 	mov	ar6,r7
      009C09                        718 00107$:
      009C09 8E 82            [24]  719 	mov	dpl, r6
                                    720 ;	quantum/quantum.c:143: }
      009C0B 22               [24]  721 	ret
                                    722 ;------------------------------------------------------------
                                    723 ;Allocation info for local variables in function 'do_code16'
                                    724 ;------------------------------------------------------------
                                    725 ;f             Allocated with name '_do_code16_PARM_2'
                                    726 ;code          Allocated with name '_do_code16_code_10000_602'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function register_code16
                                    731 ;	-----------------------------------------
      009C0C                        732 _register_code16:
      009C0C 12 38 44         [24]  733 	lcall	_ak820_outline_0103
      009C0F 90 0B CE         [24]  734 	mov	dptr,#_register_code16_code_10000_605
      009C12 12 38 49         [24]  735 	lcall	_ak820_outline_0104
                                    736 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      009C15 90 0B CE         [24]  737 	mov	dptr,#_register_code16_code_10000_605
      009C18 12 37 A1         [24]  738 	lcall	_ak820_outline_0004
      009C1B C0 07            [24]  739 	push	ar7
      009C1D C0 06            [24]  740 	push	ar6
      009C1F 12 9B E1         [24]  741 	lcall	_extract_mod_bits
      009C22 AD 82            [24]  742 	mov	r5, dpl
      009C24 D0 06            [24]  743 	pop	ar6
      009C26 D0 07            [24]  744 	pop	ar7
                                    745 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009C28 12 9A 21         [24]  746 	lcall	_ak820_outline_0114
      009C2B 40 07            [24]  747 	jc	00105$
      009C2D 74 E7            [12]  748 	mov	a,#0xe7
      009C2F 9E               [12]  749 	subb	a,r6
      009C30 E4               [12]  750 	clr	a
      009C31 9F               [12]  751 	subb	a,r7
      009C32 50 08            [24]  752 	jnc	00101$
                                    753 ;	free result
      009C34                        754 00105$:
      009C34 90 0B CE         [24]  755 	mov	dptr,#_register_code16_code_10000_605
      009C37 12 6C F6         [24]  756 	lcall	_ak820_outline_0035
      009C3A 70 07            [24]  757 	jnz	00102$
      009C3C                        758 00101$:
                                    759 ;	quantum/quantum.c:153: register_mods(mods);
      009C3C 8D 82            [24]  760 	mov	dpl, r5
      009C3E 12 75 62         [24]  761 	lcall	_register_mods
      009C41 80 05            [24]  762 	sjmp	00103$
      009C43                        763 00102$:
                                    764 ;	quantum/quantum.c:155: register_weak_mods(mods);
      009C43 8D 82            [24]  765 	mov	dpl, r5
      009C45 12 75 8A         [24]  766 	lcall	_register_weak_mods
      009C48                        767 00103$:
                                    768 ;	quantum/quantum.c:157: register_code(code);
      009C48 90 0B CE         [24]  769 	mov	dptr,#_register_code16_code_10000_605
      009C4B E0               [24]  770 	movx	a,@dptr
      009C4C F5 82            [12]  771 	mov	dpl,a
                                    772 ;	quantum/quantum.c:167: }
      009C4E 02 74 3F         [24]  773 	ljmp	_register_code
                                    774 ;------------------------------------------------------------
                                    775 ;Allocation info for local variables in function 'unregister_code16'
                                    776 ;------------------------------------------------------------
                                    777 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    778 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    779 ;------------------------------------------------------------
                                    780 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function unregister_code16
                                    783 ;	-----------------------------------------
      009C51                        784 _unregister_code16:
      009C51 12 38 44         [24]  785 	lcall	_ak820_outline_0103
      009C54 90 0B D0         [24]  786 	mov	dptr,#_unregister_code16_code_10000_610
      009C57 12 38 49         [24]  787 	lcall	_ak820_outline_0104
                                    788 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      009C5A 90 0B D0         [24]  789 	mov	dptr,#_unregister_code16_code_10000_610
      009C5D 12 37 A1         [24]  790 	lcall	_ak820_outline_0004
      009C60 C0 07            [24]  791 	push	ar7
      009C62 C0 06            [24]  792 	push	ar6
      009C64 12 9B E1         [24]  793 	lcall	_extract_mod_bits
      009C67 AD 82            [24]  794 	mov	r5, dpl
      009C69 D0 06            [24]  795 	pop	ar6
                                    796 ;	quantum/quantum.c:172: unregister_code(code);
      009C6B 8E 04            [24]  797 	mov	ar4,r6
      009C6D 8C 82            [24]  798 	mov	dpl, r4
      009C6F C0 06            [24]  799 	push	ar6
      009C71 C0 05            [24]  800 	push	ar5
      009C73 12 74 AC         [24]  801 	lcall	_unregister_code
      009C76 D0 05            [24]  802 	pop	ar5
      009C78 D0 06            [24]  803 	pop	ar6
      009C7A D0 07            [24]  804 	pop	ar7
                                    805 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009C7C 12 9A 21         [24]  806 	lcall	_ak820_outline_0114
      009C7F 40 07            [24]  807 	jc	00105$
      009C81 74 E7            [12]  808 	mov	a,#0xe7
      009C83 9E               [12]  809 	subb	a,r6
      009C84 E4               [12]  810 	clr	a
      009C85 9F               [12]  811 	subb	a,r7
      009C86 50 08            [24]  812 	jnc	00101$
                                    813 ;	free result
      009C88                        814 00105$:
      009C88 90 0B D0         [24]  815 	mov	dptr,#_unregister_code16_code_10000_610
      009C8B 12 6C F6         [24]  816 	lcall	_ak820_outline_0035
      009C8E 70 05            [24]  817 	jnz	00102$
      009C90                        818 00101$:
                                    819 ;	quantum/quantum.c:174: unregister_mods(mods);
      009C90 8D 82            [24]  820 	mov	dpl, r5
      009C92 02 75 76         [24]  821 	ljmp	_unregister_mods
      009C95                        822 00102$:
                                    823 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      009C95 8D 82            [24]  824 	mov	dpl, r5
                                    825 ;	quantum/quantum.c:187: }
      009C97 02 75 9E         [24]  826 	ljmp	_unregister_weak_mods
                                    827 ;------------------------------------------------------------
                                    828 ;Allocation info for local variables in function 'tap_code16_delay'
                                    829 ;------------------------------------------------------------
                                    830 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    831 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    832 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    833 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    834 ;------------------------------------------------------------
                                    835 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    836 ;	-----------------------------------------
                                    837 ;	 function shutdown_quantum
                                    838 ;	-----------------------------------------
      009C9A                        839 _shutdown_quantum:
                                    840 ;	quantum/quantum.c:237: clear_keyboard();
      009C9A 12 75 B2         [24]  841 	lcall	_clear_keyboard
                                    842 ;	quantum/quantum.c:252: shutdown_user();
      009C9D 12 9F 21         [24]  843 	lcall	_shutdown_user
                                    844 ;	quantum/quantum.c:253: wait_ms(250);
      009CA0 7F FA            [12]  845 	mov	r7,#0xfa
      009CA2                        846 00106$:
      009CA2 EF               [12]  847 	mov	a,r7
      009CA3 60 09            [24]  848 	jz	00108$
      009CA5 90 00 01         [24]  849 	mov	dptr,#0x0001
      009CA8 12 58 62         [24]  850 	lcall	_mDelaymS
      009CAB 1F               [12]  851 	dec	r7
      009CAC 80 F4            [24]  852 	sjmp	00106$
      009CAE                        853 00108$:
                                    854 ;	quantum/quantum.c:258: }
      009CAE 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'reset_keyboard'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function reset_keyboard
                                    862 ;	-----------------------------------------
      009CAF                        863 _reset_keyboard:
                                    864 ;	quantum/quantum.c:261: shutdown_quantum();
      009CAF 12 9C 9A         [24]  865 	lcall	_shutdown_quantum
                                    866 ;	quantum/quantum.c:262: bootloader_jump();
                                    867 ;	quantum/quantum.c:263: }
      009CB2 02 34 0E         [24]  868 	ljmp	_bootloader_jump
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    871 ;------------------------------------------------------------
                                    872 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function soft_reset_keyboard
                                    875 ;	-----------------------------------------
      009CB5                        876 _soft_reset_keyboard:
                                    877 ;	quantum/quantum.c:266: shutdown_quantum();
      009CB5 12 9C 9A         [24]  878 	lcall	_shutdown_quantum
                                    879 ;	quantum/quantum.c:267: mcu_reset();
                                    880 ;	quantum/quantum.c:268: }
      009CB8 02 34 01         [24]  881 	ljmp	_mcu_reset
                                    882 ;------------------------------------------------------------
                                    883 ;Allocation info for local variables in function 'get_record_keycode'
                                    884 ;------------------------------------------------------------
                                    885 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    886 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                    887 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function get_record_keycode
                                    892 ;	-----------------------------------------
      009CBB                        893 _get_record_keycode:
      009CBB 12 38 44         [24]  894 	lcall	_ak820_outline_0103
      009CBE 90 0B D3         [24]  895 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009CC1 12 38 49         [24]  896 	lcall	_ak820_outline_0104
                                    897 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009CC4 90 0B D3         [24]  898 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009CC7 12 37 B8         [24]  899 	lcall	_ak820_outline_0008
                                    900 ;	quantum/quantum.c:278: if (record->keycode) {
      009CCA 4C               [12]  901 	orl	a,r4
      009CCB 60 04            [24]  902 	jz	00102$
                                    903 ;	quantum/quantum.c:279: return record->keycode;
      009CCD 12 38 55         [24]  904 	lcall	_ak820_outline_0117
      009CD0 22               [24]  905 	ret
      009CD1                        906 00102$:
                                    907 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009CD1 12 75 F4         [24]  908 	lcall	_ak820_outline_0019
      009CD4 7A 00            [12]  909 	mov	r2,#0x00
      009CD6 12 43 36         [24]  910 	lcall	_ak820_outline_0138
      009CD9 12 37 AB         [24]  911 	lcall	_ak820_outline_0005
      009CDC 60 06            [24]  912 	jz	00105$
      009CDE 90 0B D2         [24]  913 	mov	dptr,#_get_record_keycode_PARM_2
      009CE1 E0               [24]  914 	movx	a,@dptr
      009CE2 70 04            [24]  915 	jnz	00106$
      009CE4                        916 00105$:
                                    917 ;	assignBit
      009CE4 C2 23            [12]  918 	clr	_get_record_keycode_sloc0_1_0
      009CE6 80 02            [24]  919 	sjmp	00107$
      009CE8                        920 00106$:
                                    921 ;	assignBit
      009CE8 D2 23            [12]  922 	setb	_get_record_keycode_sloc0_1_0
      009CEA                        923 00107$:
      009CEA 90 09 62         [24]  924 	mov	dptr,#_ak820_resolve_key_PARM_2
      009CED A2 23            [12]  925 	mov	c,_get_record_keycode_sloc0_1_0
      009CEF E4               [12]  926 	clr	a
      009CF0 33               [12]  927 	rlc	a
      009CF1 F0               [24]  928 	movx	@dptr,a
      009CF2 8D 82            [24]  929 	mov	dpl, r5
      009CF4 8C 83            [24]  930 	mov	dph, r4
                                    931 ;	quantum/quantum.c:287: }
      009CF6 02 79 91         [24]  932 	ljmp	_ak820_resolve_key
                                    933 ;------------------------------------------------------------
                                    934 ;Allocation info for local variables in function 'get_event_keycode'
                                    935 ;------------------------------------------------------------
                                    936 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    937 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                    938 ;------------------------------------------------------------
                                    939 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    940 ;	-----------------------------------------
                                    941 ;	 function pre_process_record_quantum
                                    942 ;	-----------------------------------------
      009CF9                        943 _pre_process_record_quantum:
      009CF9 12 38 44         [24]  944 	lcall	_ak820_outline_0103
      009CFC 90 0B D5         [24]  945 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009CFF 12 38 49         [24]  946 	lcall	_ak820_outline_0104
                                    947 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009D02 90 0B D5         [24]  948 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009D05 12 38 01         [24]  949 	lcall	_ak820_outline_0050
                                    950 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      009D08 90 0B D2         [24]  951 	mov	dptr,#_get_record_keycode_PARM_2
      009D0B 12 48 31         [24]  952 	lcall	_ak820_outline_0054
      009D0E C0 07            [24]  953 	push	ar7
      009D10 C0 06            [24]  954 	push	ar6
      009D12 12 9C BB         [24]  955 	lcall	_get_record_keycode
      009D15 12 43 41         [24]  956 	lcall	_ak820_outline_0144
      009D18 D0 06            [24]  957 	pop	ar6
      009D1A D0 07            [24]  958 	pop	ar7
                                    959 ;	quantum/quantum.c:334: record->keycode = keycode;
      009D1C 74 07            [12]  960 	mov	a,#0x07
      009D1E 12 37 F1         [24]  961 	lcall	_ak820_outline_0030
      009D21 EC               [12]  962 	mov	a,r4
      009D22 F0               [24]  963 	movx	@dptr,a
      009D23 ED               [12]  964 	mov	a,r5
      009D24 A3               [24]  965 	inc	dptr
      009D25 12 42 FB         [24]  966 	lcall	_ak820_outline_0060
                                    967 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009D28 12 35 EF         [24]  968 	lcall	_ak820_combo_process
      009D2B E5 82            [12]  969 	mov	a, dpl
      009D2D 70 04            [24]  970 	jnz	00104$
                                    971 ;	quantum/quantum.c:366: true;
                                    972 ;	assignBit
      009D2F C2 24            [12]  973 	clr	_pre_process_record_quantum_sloc0_1_0
      009D31 80 02            [24]  974 	sjmp	00105$
      009D33                        975 00104$:
                                    976 ;	assignBit
      009D33 D2 24            [12]  977 	setb	_pre_process_record_quantum_sloc0_1_0
      009D35                        978 00105$:
      009D35 A2 24            [12]  979 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009D37 12 38 81         [24]  980 	lcall	_ak820_outline_0166
                                    981 ;	quantum/quantum.c:367: }
      009D3A 22               [24]  982 	ret
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    985 ;------------------------------------------------------------
                                    986 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                    987 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                    988 ;------------------------------------------------------------
                                    989 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    990 ;	-----------------------------------------
                                    991 ;	 function process_record_quantum
                                    992 ;	-----------------------------------------
      009D3B                        993 _process_record_quantum:
      009D3B 12 38 44         [24]  994 	lcall	_ak820_outline_0103
      009D3E 90 0B D7         [24]  995 	mov	dptr,#_process_record_quantum_record_10000_658
      009D41 12 38 49         [24]  996 	lcall	_ak820_outline_0104
                                    997 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      009D44 90 0B D7         [24]  998 	mov	dptr,#_process_record_quantum_record_10000_658
      009D47 12 38 01         [24]  999 	lcall	_ak820_outline_0050
      009D4A 90 0B D2         [24] 1000 	mov	dptr,#_get_record_keycode_PARM_2
      009D4D E4               [12] 1001 	clr	a
      009D4E 12 42 FB         [24] 1002 	lcall	_ak820_outline_0060
      009D51 12 9C BB         [24] 1003 	lcall	_get_record_keycode
      009D54 12 43 2B         [24] 1004 	lcall	_ak820_outline_0130
                                   1005 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      009D57 90 0B D7         [24] 1006 	mov	dptr,#_process_record_quantum_record_10000_658
      009D5A 12 38 20         [24] 1007 	lcall	_ak820_outline_0059
      009D5D 90 0B DE         [24] 1008 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009D60 EC               [12] 1009 	mov	a,r4
      009D61 F0               [24] 1010 	movx	@dptr,a
      009D62 ED               [12] 1011 	mov	a,r5
      009D63 A3               [24] 1012 	inc	dptr
      009D64 12 42 FB         [24] 1013 	lcall	_ak820_outline_0060
                                   1014 ;	quantum/quantum.c:382: }
      009D67 02 9D D5         [24] 1015 	ljmp	_process_record_quantum_helper
                                   1016 ;------------------------------------------------------------
                                   1017 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1018 ;------------------------------------------------------------
                                   1019 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1020 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_660'
                                   1021 ;record        Allocated with name '_process_ak820_nkro_record_10000_661'
                                   1022 ;------------------------------------------------------------
                                   1023 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1024 ;	-----------------------------------------
                                   1025 ;	 function process_ak820_nkro
                                   1026 ;	-----------------------------------------
      009D6A                       1027 _process_ak820_nkro:
      009D6A 12 38 44         [24] 1028 	lcall	_ak820_outline_0103
      009D6D 90 0B DC         [24] 1029 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009D70 12 38 49         [24] 1030 	lcall	_ak820_outline_0104
                                   1031 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009D73 90 0B D9         [24] 1032 	mov	dptr,#_process_ak820_nkro_PARM_2
      009D76 12 38 01         [24] 1033 	lcall	_ak820_outline_0050
                                   1034 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      009D79 90 0B DC         [24] 1035 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009D7C 12 38 20         [24] 1036 	lcall	_ak820_outline_0059
      009D7F C3               [12] 1037 	clr	c
      009D80 EC               [12] 1038 	mov	a,r4
      009D81 94 11            [12] 1039 	subb	a,#0x11
      009D83 ED               [12] 1040 	mov	a,r5
      009D84 94 70            [12] 1041 	subb	a,#0x70
      009D86 40 08            [24] 1042 	jc	00101$
      009D88 74 13            [12] 1043 	mov	a,#0x13
      009D8A 9C               [12] 1044 	subb	a,r4
      009D8B 74 70            [12] 1045 	mov	a,#0x70
      009D8D 9D               [12] 1046 	subb	a,r5
      009D8E 50 04            [24] 1047 	jnc	00102$
                                   1048 ;	free result
      009D90                       1049 00101$:
      009D90 75 82 01         [24] 1050 	mov	dpl, #0x01
      009D93 22               [24] 1051 	ret
      009D94                       1052 00102$:
                                   1053 ;	quantum/quantum.c:406: if (record->event.pressed) {
      009D94 12 37 AB         [24] 1054 	lcall	_ak820_outline_0005
      009D97 60 38            [24] 1055 	jz	00105$
                                   1056 ;	quantum/quantum.c:407: clear_keyboard();
      009D99 C0 05            [24] 1057 	push	ar5
      009D9B C0 04            [24] 1058 	push	ar4
      009D9D 12 75 B2         [24] 1059 	lcall	_clear_keyboard
      009DA0 D0 04            [24] 1060 	pop	ar4
      009DA2 D0 05            [24] 1061 	pop	ar5
                                   1062 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      009DA4 BC 13 14         [24] 1063 	cjne	r4,#0x13,00108$
      009DA7 BD 70 11         [24] 1064 	cjne	r5,#0x70,00108$
      009DAA 90 0A B4         [24] 1065 	mov	dptr,#_keymap_config
      009DAD E0               [24] 1066 	movx	a,@dptr
      009DAE 23               [12] 1067 	rl	a
      009DAF 54 01            [12] 1068 	anl	a,#0x01
      009DB1 B4 01 00         [24] 1069 	cjne	a,#0x01,00136$
      009DB4                       1070 00136$:
      009DB4 92 25            [24] 1071 	mov  _process_ak820_nkro_sloc0_1_0,c
      009DB6 E4               [12] 1072 	clr	a
      009DB7 33               [12] 1073 	rlc	a
      009DB8 FF               [12] 1074 	mov	r7,a
      009DB9 80 09            [24] 1075 	sjmp	00109$
      009DBB                       1076 00108$:
      009DBB E4               [12] 1077 	clr	a
      009DBC BC 11 04         [24] 1078 	cjne	r4,#0x11,00137$
      009DBF BD 70 01         [24] 1079 	cjne	r5,#0x70,00137$
      009DC2 04               [12] 1080 	inc	a
      009DC3                       1081 00137$:
      009DC3 FF               [12] 1082 	mov	r7,a
      009DC4                       1083 00109$:
                                   1084 ;	assignBit
      009DC4 EF               [12] 1085 	mov	a,r7
      009DC5 24 FF            [12] 1086 	add	a,#0xff
      009DC7 E4               [12] 1087 	clr	a
      009DC8 33               [12] 1088 	rlc	a
      009DC9 90 0A B4         [24] 1089 	mov	dptr,#_keymap_config
      009DCC 13               [12] 1090 	rrc	a
      009DCD E0               [24] 1091 	movx	a,@dptr
      009DCE 92 E7            [24] 1092 	mov	acc.7,c
      009DD0 F0               [24] 1093 	movx	@dptr,a
      009DD1                       1094 00105$:
                                   1095 ;	quantum/quantum.c:410: return false;
      009DD1 75 82 00         [24] 1096 	mov	dpl, #0x00
                                   1097 ;	quantum/quantum.c:411: }
      009DD4 22               [24] 1098 	ret
                                   1099 ;------------------------------------------------------------
                                   1100 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1101 ;------------------------------------------------------------
                                   1102 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1103 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_665'
                                   1104 ;record        Allocated with name '_process_record_quantum_helper_record_10000_666'
                                   1105 ;------------------------------------------------------------
                                   1106 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1107 ;	-----------------------------------------
                                   1108 ;	 function process_record_quantum_helper
                                   1109 ;	-----------------------------------------
      009DD5                       1110 _process_record_quantum_helper:
      009DD5 12 38 44         [24] 1111 	lcall	_ak820_outline_0103
      009DD8 90 0B E0         [24] 1112 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009DDB 12 38 49         [24] 1113 	lcall	_ak820_outline_0104
                                   1114 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009DDE 90 0B DE         [24] 1115 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009DE1 12 38 01         [24] 1116 	lcall	_ak820_outline_0050
                                   1117 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      009DE4 90 0B E0         [24] 1118 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009DE7 12 38 20         [24] 1119 	lcall	_ak820_outline_0059
      009DEA 90 0B D9         [24] 1120 	mov	dptr,#_process_ak820_nkro_PARM_2
      009DED 12 9F 22         [24] 1121 	lcall	_ak820_outline_0006
      009DF0 C0 07            [24] 1122 	push	ar7
      009DF2 C0 06            [24] 1123 	push	ar6
      009DF4 C0 05            [24] 1124 	push	ar5
      009DF6 C0 04            [24] 1125 	push	ar4
      009DF8 12 9D 6A         [24] 1126 	lcall	_process_ak820_nkro
      009DFB E5 82            [12] 1127 	mov	a, dpl
      009DFD D0 04            [24] 1128 	pop	ar4
      009DFF D0 05            [24] 1129 	pop	ar5
      009E01 D0 06            [24] 1130 	pop	ar6
      009E03 D0 07            [24] 1131 	pop	ar7
      009E05 70 03            [24] 1132 	jnz	00196$
      009E07 02 9E E4         [24] 1133 	ljmp	00101$
      009E0A                       1134 00196$:
                                   1135 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      009E0A 90 0B B7         [24] 1136 	mov	dptr,#_process_last_key_PARM_2
      009E0D 12 48 41         [24] 1137 	lcall	_ak820_outline_0058
      009E10 12 38 55         [24] 1138 	lcall	_ak820_outline_0117
      009E13 C0 07            [24] 1139 	push	ar7
      009E15 C0 06            [24] 1140 	push	ar6
      009E17 C0 05            [24] 1141 	push	ar5
      009E19 C0 04            [24] 1142 	push	ar4
      009E1B 12 99 61         [24] 1143 	lcall	_process_last_key
      009E1E E5 82            [12] 1144 	mov	a, dpl
      009E20 D0 04            [24] 1145 	pop	ar4
      009E22 D0 05            [24] 1146 	pop	ar5
      009E24 D0 06            [24] 1147 	pop	ar6
      009E26 D0 07            [24] 1148 	pop	ar7
      009E28 70 03            [24] 1149 	jnz	00197$
      009E2A 02 9E E4         [24] 1150 	ljmp	00101$
      009E2D                       1151 00197$:
      009E2D 90 0B BC         [24] 1152 	mov	dptr,#_process_repeat_key_PARM_2
      009E30 12 48 41         [24] 1153 	lcall	_ak820_outline_0058
      009E33 12 38 55         [24] 1154 	lcall	_ak820_outline_0117
      009E36 C0 07            [24] 1155 	push	ar7
      009E38 C0 06            [24] 1156 	push	ar6
      009E3A C0 05            [24] 1157 	push	ar5
      009E3C C0 04            [24] 1158 	push	ar4
      009E3E 12 99 DA         [24] 1159 	lcall	_process_repeat_key
      009E41 E5 82            [12] 1160 	mov	a, dpl
      009E43 D0 04            [24] 1161 	pop	ar4
      009E45 D0 05            [24] 1162 	pop	ar5
      009E47 D0 06            [24] 1163 	pop	ar6
      009E49 D0 07            [24] 1164 	pop	ar7
      009E4B 70 03            [24] 1165 	jnz	00198$
      009E4D 02 9E E4         [24] 1166 	ljmp	00101$
      009E50                       1167 00198$:
                                   1168 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      009E50 90 0C 19         [24] 1169 	mov	dptr,#_process_record_via_PARM_2
      009E53 12 9F 22         [24] 1170 	lcall	_ak820_outline_0006
      009E56 C0 07            [24] 1171 	push	ar7
      009E58 C0 06            [24] 1172 	push	ar6
      009E5A C0 05            [24] 1173 	push	ar5
      009E5C C0 04            [24] 1174 	push	ar4
      009E5E 12 A4 0F         [24] 1175 	lcall	_process_record_via
      009E61 E5 82            [12] 1176 	mov	a, dpl
      009E63 D0 04            [24] 1177 	pop	ar4
      009E65 D0 05            [24] 1178 	pop	ar5
      009E67 D0 06            [24] 1179 	pop	ar6
      009E69 D0 07            [24] 1180 	pop	ar7
      009E6B 70 03            [24] 1181 	jnz	00199$
      009E6D 02 9E E4         [24] 1182 	ljmp	00101$
      009E70                       1183 00199$:
                                   1184 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      009E70 90 0B A0         [24] 1185 	mov	dptr,#_process_caps_word_PARM_2
      009E73 12 9F 22         [24] 1186 	lcall	_ak820_outline_0006
      009E76 C0 07            [24] 1187 	push	ar7
      009E78 C0 06            [24] 1188 	push	ar6
      009E7A C0 05            [24] 1189 	push	ar5
      009E7C C0 04            [24] 1190 	push	ar4
      009E7E 12 97 00         [24] 1191 	lcall	_process_caps_word
      009E81 E5 82            [12] 1192 	mov	a, dpl
      009E83 D0 04            [24] 1193 	pop	ar4
      009E85 D0 05            [24] 1194 	pop	ar5
      009E87 D0 06            [24] 1195 	pop	ar6
      009E89 D0 07            [24] 1196 	pop	ar7
      009E8B 60 57            [24] 1197 	jz	00101$
                                   1198 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      009E8D 90 0B A5         [24] 1199 	mov	dptr,#_process_grave_esc_PARM_2
      009E90 12 9F 22         [24] 1200 	lcall	_ak820_outline_0006
      009E93 C0 07            [24] 1201 	push	ar7
      009E95 C0 06            [24] 1202 	push	ar6
      009E97 C0 05            [24] 1203 	push	ar5
      009E99 C0 04            [24] 1204 	push	ar4
      009E9B 12 98 13         [24] 1205 	lcall	_process_grave_esc
      009E9E E5 82            [12] 1206 	mov	a, dpl
      009EA0 D0 04            [24] 1207 	pop	ar4
      009EA2 D0 05            [24] 1208 	pop	ar5
      009EA4 D0 06            [24] 1209 	pop	ar6
      009EA6 D0 07            [24] 1210 	pop	ar7
      009EA8 60 3A            [24] 1211 	jz	00101$
                                   1212 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      009EAA 90 0B C0         [24] 1213 	mov	dptr,#_process_rgb_PARM_2
      009EAD 12 9F 22         [24] 1214 	lcall	_ak820_outline_0006
      009EB0 C0 07            [24] 1215 	push	ar7
      009EB2 C0 06            [24] 1216 	push	ar6
      009EB4 C0 05            [24] 1217 	push	ar5
      009EB6 C0 04            [24] 1218 	push	ar4
      009EB8 12 9A 29         [24] 1219 	lcall	_process_rgb
      009EBB E5 82            [12] 1220 	mov	a, dpl
      009EBD D0 04            [24] 1221 	pop	ar4
      009EBF D0 05            [24] 1222 	pop	ar5
      009EC1 D0 06            [24] 1223 	pop	ar6
      009EC3 D0 07            [24] 1224 	pop	ar7
      009EC5 60 1D            [24] 1225 	jz	00101$
                                   1226 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      009EC7 90 0B C6         [24] 1227 	mov	dptr,#_process_tri_layer_PARM_2
      009ECA 12 9F 22         [24] 1228 	lcall	_ak820_outline_0006
      009ECD C0 07            [24] 1229 	push	ar7
      009ECF C0 06            [24] 1230 	push	ar6
      009ED1 C0 05            [24] 1231 	push	ar5
      009ED3 C0 04            [24] 1232 	push	ar4
      009ED5 12 9A DA         [24] 1233 	lcall	_process_tri_layer
      009ED8 E5 82            [12] 1234 	mov	a, dpl
      009EDA D0 04            [24] 1235 	pop	ar4
      009EDC D0 05            [24] 1236 	pop	ar5
      009EDE D0 06            [24] 1237 	pop	ar6
      009EE0 D0 07            [24] 1238 	pop	ar7
      009EE2 70 04            [24] 1239 	jnz	00102$
                                   1240 ;	quantum/quantum.c:561: true)) {
      009EE4                       1241 00101$:
                                   1242 ;	quantum/quantum.c:562: return false;
      009EE4 75 82 00         [24] 1243 	mov	dpl, #0x00
      009EE7 22               [24] 1244 	ret
      009EE8                       1245 00102$:
                                   1246 ;	quantum/quantum.c:565: if (record->event.pressed) {
      009EE8 12 37 AB         [24] 1247 	lcall	_ak820_outline_0005
      009EEB 60 30            [24] 1248 	jz	00116$
                                   1249 ;	quantum/quantum.c:566: switch (keycode) {
      009EED BC 00 05         [24] 1250 	cjne	r4,#0x00,00205$
      009EF0 BD 7C 02         [24] 1251 	cjne	r5,#0x7c,00205$
      009EF3 80 10            [24] 1252 	sjmp	00111$
      009EF5                       1253 00205$:
      009EF5 BC 01 05         [24] 1254 	cjne	r4,#0x01,00206$
      009EF8 BD 7C 02         [24] 1255 	cjne	r5,#0x7c,00206$
      009EFB 80 0F            [24] 1256 	sjmp	00112$
      009EFD                       1257 00206$:
                                   1258 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      009EFD BC 03 1D         [24] 1259 	cjne	r4,#0x03,00116$
      009F00 BD 7C 1A         [24] 1260 	cjne	r5,#0x7c,00116$
      009F03 80 0E            [24] 1261 	sjmp	00113$
      009F05                       1262 00111$:
                                   1263 ;	quantum/quantum.c:569: reset_keyboard();
      009F05 12 9C AF         [24] 1264 	lcall	_reset_keyboard
                                   1265 ;	quantum/quantum.c:570: return false;
      009F08 75 82 00         [24] 1266 	mov	dpl, #0x00
                                   1267 ;	quantum/quantum.c:571: case QK_REBOOT:
      009F0B 22               [24] 1268 	ret
      009F0C                       1269 00112$:
                                   1270 ;	quantum/quantum.c:572: soft_reset_keyboard();
      009F0C 12 9C B5         [24] 1271 	lcall	_soft_reset_keyboard
                                   1272 ;	quantum/quantum.c:573: return false;
      009F0F 75 82 00         [24] 1273 	mov	dpl, #0x00
                                   1274 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      009F12 22               [24] 1275 	ret
      009F13                       1276 00113$:
                                   1277 ;	quantum/quantum.c:592: eeconfig_disable();
      009F13 12 8E 6B         [24] 1278 	lcall	_eeconfig_disable
                                   1279 ;	quantum/quantum.c:593: soft_reset_keyboard();
      009F16 12 9C B5         [24] 1280 	lcall	_soft_reset_keyboard
                                   1281 ;	quantum/quantum.c:595: return false;
      009F19 75 82 00         [24] 1282 	mov	dpl, #0x00
                                   1283 ;	quantum/quantum.c:650: }
      009F1C 22               [24] 1284 	ret
      009F1D                       1285 00116$:
                                   1286 ;	quantum/quantum.c:654: return true;
      009F1D 75 82 01         [24] 1287 	mov	dpl, #0x01
                                   1288 ;	quantum/quantum.c:658: }
      009F20 22               [24] 1289 	ret
                                   1290 ;------------------------------------------------------------
                                   1291 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1292 ;------------------------------------------------------------
                                   1293 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_673'
                                   1294 ;------------------------------------------------------------
                                   1295 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1296 ;	-----------------------------------------
                                   1297 ;	 function shutdown_user
                                   1298 ;	-----------------------------------------
      009F21                       1299 _shutdown_user:
      009F21 22               [24] 1300 	ret
                                   1301 ;------------------------------------------------------------
                                   1302 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1303 ;------------------------------------------------------------
                                   1304 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1305 ;	-----------------------------------------
                                   1306 	.area CSEG    (CODE)
                                   1307 	.area CONST   (CODE)
                                   1308 	.area XINIT   (CODE)
                                   1309 	.area CABS    (ABS,CODE)
                                   1310 
                                   1311 ; Experimental exact instruction outlining.
                                   1312 	.globl _ak820_outline_0004
                                   1313 	.globl _ak820_outline_0005
                                   1314 	.globl _ak820_outline_0006
                                   1315 	.globl _ak820_outline_0008
                                   1316 	.globl _ak820_outline_0019
                                   1317 	.globl _ak820_outline_0030
                                   1318 	.globl _ak820_outline_0035
                                   1319 	.globl _ak820_outline_0050
                                   1320 	.globl _ak820_outline_0054
                                   1321 	.globl _ak820_outline_0058
                                   1322 	.globl _ak820_outline_0059
                                   1323 	.globl _ak820_outline_0060
                                   1324 	.globl _ak820_outline_0103
                                   1325 	.globl _ak820_outline_0104
                                   1326 	.globl _ak820_outline_0114
                                   1327 	.globl _ak820_outline_0117
                                   1328 	.globl _ak820_outline_0130
                                   1329 	.globl _ak820_outline_0138
                                   1330 	.globl _ak820_outline_0144
                                   1331 	.globl _ak820_outline_0166
                                   1332 
                                   1333 	.area CSEG (CODE)
                                   1334 ; function ak820_outline_0006
      009F22                       1335 _ak820_outline_0006:
      009F22 EE               [12] 1336 	mov	a,r6
      009F23 F0               [24] 1337 	movx	@dptr,a
      009F24 EF               [12] 1338 	mov	a,r7
      009F25 A3               [24] 1339 	inc	dptr
      009F26 F0               [24] 1340 	movx	@dptr,a
      009F27 E4               [12] 1341 	clr	a
      009F28 A3               [24] 1342 	inc	dptr
      009F29 F0               [24] 1343 	movx	@dptr,a
      009F2A 8C 82            [24] 1344 	mov	dpl,r4
      009F2C 8D 83            [24] 1345 	mov	dph,r5
      009F2E 22               [24] 1346 	ret
