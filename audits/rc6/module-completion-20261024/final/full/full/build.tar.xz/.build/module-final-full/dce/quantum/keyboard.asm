;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module keyboard
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _quantum_task
	.globl _switch_events
	.globl _quantum_init
	.globl _should_process_keypress
	.globl _last_encoder_activity_trigger
	.globl _last_matrix_activity_trigger
	.globl _caps_word_task
	.globl _vial_unlock_task
	.globl _vial_init
	.globl _eeprom_driver_init
	.globl _via_init
	.globl _encoder_read
	.globl _encoder_init
	.globl _rgb_matrix_init
	.globl _rgb_matrix_task
	.globl _process_rgb_matrix
	.globl _ak820_action_exec
	.globl _print_set_sendchar
	.globl _sendchar
	.globl _led_task
	.globl _led_init_ports
	.globl _magic
	.globl _matrix_print
	.globl _matrix_get_row
	.globl _matrix_scan
	.globl _matrix_init
	.globl _keyboard_post_init_user
	.globl _timer_elapsed32
	.globl _timer_read32
	.globl _timer_read
	.globl _timer_init
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _switch_events_PARM_3
	.globl _switch_events_PARM_2
	.globl _keyboard_post_init_kb
	.globl _matrix_can_read
	.globl _keyboard_setup
	.globl _is_keyboard_master
	.globl _housekeeping_task
	.globl _keyboard_init
	.globl _keyboard_task
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_switch_events_PARM_2:
	.ds 1
_switch_events_PARM_3:
	.ds 1
_switch_events_row_10000_492:
	.ds 1
_generate_tick_event_last_tick_10000_495:
	.ds 2
_matrix_task_last_tick_60000_524:
	.ds 2
_matrix_task_dummy_event_70000_525:
	.ds 6
_matrix_task_matrix_previous_10001_502:
	.ds 16
_matrix_task_matrix_changed_10002_503:
	.ds 1
_matrix_task_last_tick_60002_528:
	.ds 2
_matrix_task_dummy_event_70002_529:
	.ds 6
_matrix_task_row_changes_30003_512:
	.ds 1
_matrix_task_col_mask_30004_515:
	.ds 1
_matrix_task_dummy_event_90004_521:
	.ds 6
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_last_input_modification_time:
	.ds 4
_last_matrix_modification_time:
	.ds 4
_last_encoder_modification_time:
	.ds 4
_last_pointing_device_modification_time:
	.ds 4
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'generate_tick_event'
;------------------------------------------------------------
;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_495'
;now           Allocated with name '_generate_tick_event_now_10000_495'
;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_497'
;------------------------------------------------------------
;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
	mov	dptr,#_generate_tick_event_last_tick_10000_495
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;------------------------------------------------------------
;Allocation info for local variables in function 'matrix_task'
;------------------------------------------------------------
;last_tick     Allocated with name '_matrix_task_last_tick_60000_524'
;now           Allocated with name '_matrix_task_now_60000_524'
;dummy_event   Allocated with name '_matrix_task_dummy_event_70000_525'
;matrix_previous Allocated with name '_matrix_task_matrix_previous_10001_502'
;matrix_changed Allocated with name '_matrix_task_matrix_changed_10002_503'
;row           Allocated with name '_matrix_task_row_20002_504'
;last_tick     Allocated with name '_matrix_task_last_tick_60002_528'
;now           Allocated with name '_matrix_task_now_60002_528'
;dummy_event   Allocated with name '_matrix_task_dummy_event_70002_529'
;process_keypress Allocated with name '_matrix_task_process_keypress_10003_510'
;row           Allocated with name '_matrix_task_row_20003_511'
;__400030089   Allocated with name '_matrix_task___400030089_40003_512'
;current_row   Allocated with name '_matrix_task_current_row_30003_512'
;row_changes   Allocated with name '_matrix_task_row_changes_30003_512'
;__500030090   Allocated with name '_matrix_task___500030090_50003_530'
;__500030091   Allocated with name '_matrix_task___500030091_50003_530'
;row           Allocated with name '_matrix_task_row_60003_531'
;rowdata       Allocated with name '_matrix_task_rowdata_60003_531'
;col_mask      Allocated with name '_matrix_task_col_mask_30004_515'
;col           Allocated with name '_matrix_task_col_40004_516'
;key_pressed   Allocated with name '_matrix_task_key_pressed_70004_519'
;dummy_event   Allocated with name '_matrix_task_dummy_event_90004_521'
;------------------------------------------------------------
;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
	mov	dptr,#_matrix_task_last_tick_60000_524
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_matrix_task_last_tick_60002_528
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'IS_KEYEVENT'
;------------------------------------------------------------
;event         Allocated with name '_IS_KEYEVENT_PARM_1'
;------------------------------------------------------------
;	quantum/keyboard.c:36: bool IS_KEYEVENT(const keyevent_t event) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function last_matrix_activity_trigger
;	-----------------------------------------
_last_matrix_activity_trigger:
;	quantum/keyboard.c:190: last_matrix_modification_time = last_input_modification_time = sync_timer_read32();
	lcall	_timer_read32
	lcall	_ak820_outline_0056
	mov	dptr,#_last_input_modification_time
	lcall	_ak820_outline_0007
	mov	dptr,#_last_matrix_modification_time
	lcall	_ak820_outline_0007
;	quantum/keyboard.c:191: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'last_encoder_activity_time'
;------------------------------------------------------------
;	quantum/keyboard.c:194: uint32_t        last_encoder_activity_time(void) {
;	-----------------------------------------
;	 function last_encoder_activity_trigger
;	-----------------------------------------
_last_encoder_activity_trigger:
;	quantum/keyboard.c:201: last_encoder_modification_time = last_input_modification_time = sync_timer_read32();
	lcall	_timer_read32
	lcall	_ak820_outline_0056
	mov	dptr,#_last_input_modification_time
	lcall	_ak820_outline_0007
	mov	dptr,#_last_encoder_modification_time
	lcall	_ak820_outline_0007
;	quantum/keyboard.c:202: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'last_pointing_device_activity_time'
;------------------------------------------------------------
;	quantum/keyboard.c:205: uint32_t        last_pointing_device_activity_time(void) {
;	-----------------------------------------
;	 function keyboard_post_init_kb
;	-----------------------------------------
_keyboard_post_init_kb:
;	quantum/keyboard.c:345: keyboard_post_init_user();
;	quantum/keyboard.c:346: }
	ljmp	_keyboard_post_init_user
;------------------------------------------------------------
;Allocation info for local variables in function 'matrix_can_read'
;------------------------------------------------------------
;	quantum/keyboard.c:352: __attribute__((weak)) bool matrix_can_read(void) {
;	-----------------------------------------
;	 function matrix_can_read
;	-----------------------------------------
_matrix_can_read:
;	quantum/keyboard.c:353: return true;
	mov	dpl, #0x01
;	quantum/keyboard.c:354: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'keyboard_setup'
;------------------------------------------------------------
;	quantum/keyboard.c:360: void keyboard_setup(void) {
;	-----------------------------------------
;	 function keyboard_setup
;	-----------------------------------------
_keyboard_setup:
;	quantum/keyboard.c:361: print_set_sendchar(sendchar);
	mov	dptr,#_sendchar
	lcall	_print_set_sendchar
;	quantum/keyboard.c:363: eeprom_driver_init();
	lcall	_eeprom_driver_init
;	quantum/keyboard.c:366: vial_init();
;	quantum/keyboard.c:372: keyboard_pre_init_kb();
;	quantum/keyboard.c:373: }
	ljmp	_vial_init
;------------------------------------------------------------
;Allocation info for local variables in function 'is_keyboard_master'
;------------------------------------------------------------
;	quantum/keyboard.c:381: __attribute__((weak)) bool is_keyboard_master(void) {
;	-----------------------------------------
;	 function is_keyboard_master
;	-----------------------------------------
_is_keyboard_master:
;	quantum/keyboard.c:382: return true;
	mov	dpl, #0x01
;	quantum/keyboard.c:383: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'is_keyboard_left'
;------------------------------------------------------------
;	quantum/keyboard.c:389: __attribute__((weak)) bool is_keyboard_left(void) {
;	-----------------------------------------
;	 function should_process_keypress
;	-----------------------------------------
_should_process_keypress:
;	quantum/keyboard.c:401: return is_keyboard_master();
;	quantum/keyboard.c:402: }
	ljmp	_is_keyboard_master
;------------------------------------------------------------
;Allocation info for local variables in function 'housekeeping_task_kb'
;------------------------------------------------------------
;	quantum/keyboard.c:409: __attribute__((weak)) void housekeeping_task_kb(void) {}
;	-----------------------------------------
;	 function housekeeping_task
;	-----------------------------------------
_housekeeping_task:
;	quantum/keyboard.c:424: housekeeping_task_user();
;	quantum/keyboard.c:425: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'quantum_init'
;------------------------------------------------------------
;	quantum/keyboard.c:431: void quantum_init(void) {
;	-----------------------------------------
;	 function quantum_init
;	-----------------------------------------
_quantum_init:
;	quantum/keyboard.c:432: magic();
	lcall	_magic
;	quantum/keyboard.c:433: led_init_ports();
	lcall	_led_init_ports
;	quantum/keyboard.c:444: rgb_matrix_init();
;	quantum/keyboard.c:452: }
	ljmp	_rgb_matrix_init
;------------------------------------------------------------
;Allocation info for local variables in function 'keyboard_init'
;------------------------------------------------------------
;	quantum/keyboard.c:458: void keyboard_init(void) {
;	-----------------------------------------
;	 function keyboard_init
;	-----------------------------------------
_keyboard_init:
;	quantum/keyboard.c:459: timer_init();
	lcall	_timer_init
;	quantum/keyboard.c:462: via_init();
	lcall	_via_init
;	quantum/keyboard.c:468: encoder_init();
	lcall	_encoder_init
;	quantum/keyboard.c:470: matrix_init();
	lcall	_matrix_init
;	quantum/keyboard.c:471: quantum_init();
	lcall	_quantum_init
;	quantum/keyboard.c:521: keyboard_post_init_kb(); /* Always keep this last */
;	quantum/keyboard.c:522: }
	ljmp	_keyboard_post_init_kb
;------------------------------------------------------------
;Allocation info for local variables in function 'switch_events'
;------------------------------------------------------------
;col           Allocated with name '_switch_events_PARM_2'
;pressed       Allocated with name '_switch_events_PARM_3'
;row           Allocated with name '_switch_events_row_10000_492'
;------------------------------------------------------------
;	quantum/keyboard.c:529: void switch_events(uint8_t row, uint8_t col, bool pressed) {
;	-----------------------------------------
;	 function switch_events
;	-----------------------------------------
_switch_events:
	mov	a,dpl
	mov	dptr,#_switch_events_row_10000_492
	movx	@dptr,a
;	quantum/keyboard.c:534: process_rgb_matrix(row, col, pressed);
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_switch_events_PARM_2
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_switch_events_PARM_3
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_process_rgb_matrix_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_process_rgb_matrix_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dpl, r7
;	quantum/keyboard.c:536: }
	ljmp	_process_rgb_matrix
;------------------------------------------------------------
;Allocation info for local variables in function 'generate_tick_event'
;------------------------------------------------------------
;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_495'
;now           Allocated with name '_generate_tick_event_now_10000_495'
;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_497'
;------------------------------------------------------------
;	quantum/keyboard.c:542: static inline void generate_tick_event(void) {
;	-----------------------------------------
;	 function matrix_task
;	-----------------------------------------
_matrix_task:
;	quantum/keyboard.c:562: if (!matrix_can_read()) {
	lcall	_matrix_can_read
	mov	a, dpl
	jnz	00102$
;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
	lcall	_timer_read
	lcall	_ak820_outline_0130
;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
	mov	dptr,#_matrix_task_last_tick_60000_524
	lcall	_ak820_outline_0059
	mov	a,r6
	clr	c
	subb	a,r4
	mov	r4,a
	mov	a,r7
	subb	a,r5
	orl	a,r4
	jz	00120$
;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
	mov	dptr,#_matrix_task_dummy_event_70000_525
	clr	a
	movx	@dptr,a
	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0001)
	movx	@dptr,a
	lcall	_timer_read
	lcall	_ak820_outline_0144
	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0002)
	lcall	_ak820_outline_0070
	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0004)
	clr	a
	movx	@dptr,a
	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0005)
	movx	@dptr,a
;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
	mov	dptr,#_matrix_task_dummy_event_70000_525
	push	ar7
	push	ar6
	lcall	_ak820_action_exec
	pop	ar6
	pop	ar7
;	quantum/keyboard.c:550: last_tick = now;
	mov	dptr,#_matrix_task_last_tick_60000_524
	lcall	_ak820_outline_0058
;	quantum/keyboard.c:563: generate_tick_event();
00120$:
;	quantum/keyboard.c:564: return false;
	mov	dpl, #0x00
	ret
00102$:
;	quantum/keyboard.c:569: matrix_scan();
	lcall	_matrix_scan
;	quantum/keyboard.c:573: vial_unlock_task();
	lcall	_vial_unlock_task
;	quantum/keyboard.c:575: bool matrix_changed = false;
	mov	dptr,#_matrix_task_matrix_changed_10002_503
	clr	a
	movx	@dptr,a
;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
	mov	r7,a
00127$:
	cjne	r7,#0x10,00247$
00247$:
	jnc	00103$
	mov	dptr,#_matrix_task_matrix_changed_10002_503
	movx	a,@dptr
	jnz	00103$
;	quantum/keyboard.c:577: matrix_changed |= matrix_previous[row] ^ matrix_get_row(row);
	mov	a,r7
	lcall	_ak820_outline_0066
	movx	a,@dptr
	mov	r6,a
	mov	dpl, r7
	lcall	_matrix_get_row
	mov	a,dpl
	xrl	a,r6
;	assignBit
	mov	dptr,#_matrix_task_matrix_changed_10002_503
	add	a,#0xff
	clr	a
	rlc	a
	movx	@dptr,a
;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
	inc	r7
	sjmp	00127$
00103$:
;	quantum/keyboard.c:583: if (!matrix_changed) {
	mov	dptr,#_matrix_task_matrix_changed_10002_503
	movx	a,@dptr
	jnz	00105$
;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
	lcall	_timer_read
	lcall	_ak820_outline_0130
;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
	mov	dptr,#_matrix_task_last_tick_60002_528
	lcall	_ak820_outline_0059
	mov	a,r6
	clr	c
	subb	a,r4
	mov	r4,a
	mov	a,r7
	subb	a,r5
	orl	a,r4
	jz	00123$
;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
	mov	dptr,#_matrix_task_dummy_event_70002_529
	clr	a
	movx	@dptr,a
	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0001)
	movx	@dptr,a
	lcall	_timer_read
	lcall	_ak820_outline_0144
	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0002)
	lcall	_ak820_outline_0070
	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0004)
	clr	a
	movx	@dptr,a
	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0005)
	movx	@dptr,a
;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
	mov	dptr,#_matrix_task_dummy_event_70002_529
	push	ar7
	push	ar6
	lcall	_ak820_action_exec
	pop	ar6
	pop	ar7
;	quantum/keyboard.c:550: last_tick = now;
	mov	dptr,#_matrix_task_last_tick_60002_528
	lcall	_ak820_outline_0058
;	quantum/keyboard.c:584: generate_tick_event();
00123$:
;	quantum/keyboard.c:585: return matrix_changed;
	mov	dpl, #0x00
	ret
00105$:
;	quantum/keyboard.c:588: if (debug_config.matrix) {
	mov	dptr,#_debug_config
	movx	a,@dptr
	jnb	acc.1,00107$
;	quantum/keyboard.c:589: matrix_print();
	lcall	_matrix_print
00107$:
;	quantum/keyboard.c:592: const bool process_keypress = should_process_keypress();
	lcall	_should_process_keypress
	mov	r7, dpl
;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
	mov	r6,#0x00
00133$:
	cjne	r6,#0x10,00253$
00253$:
	jc	00254$
	ljmp	00117$
00254$:
;	quantum/keyboard.c:595: const matrix_row_t current_row = matrix_get_row(row);
	mov	dpl, r6
	lcall	_matrix_get_row
	mov	r5, dpl
;	quantum/keyboard.c:596: const matrix_row_t row_changes = current_row ^ matrix_previous[row];
	mov	a,r6
	lcall	_ak820_outline_0066
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	xrl	ar4,a
	mov	dptr,#_matrix_task_row_changes_30003_512
	mov	a,r4
	movx	@dptr,a
;	quantum/keyboard.c:598: if (!row_changes || has_ghost_in_row(row, current_row)) {
	mov	a,r4
	jnz	00255$
	ljmp	00116$
00255$:
;	quantum/keyboard.c:602: matrix_row_t col_mask = 1;
	mov	dptr,#_matrix_task_col_mask_30004_515
	mov	a,#0x01
	movx	@dptr,a
;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
	mov	r4,#0x00
00130$:
	cjne	r4,#0x08,00256$
00256$:
	jc	00257$
	ljmp	00115$
00257$:
;	quantum/keyboard.c:604: if (row_changes & col_mask) {
	mov	dptr,#_matrix_task_row_changes_30003_512
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_matrix_task_col_mask_30004_515
	movx	a,@dptr
	mov	r2,a
	anl	a,r3
	jz	00131$
;	quantum/keyboard.c:605: const bool key_pressed = current_row & col_mask;
	mov	a,r5
	anl	ar2,a
;	assignBit
	mov	a,r2
	add	a,#0xff
	clr	a
	rlc	a
	mov	r2,a
;	quantum/keyboard.c:607: if (process_keypress) {
	mov	a,r7
	jz	00112$
;	quantum/keyboard.c:609: MAKE_KEYEVENT(row, col, key_pressed);
	mov	dptr,#_matrix_task_dummy_event_90004_521
	mov	a,r4
	movx	@dptr,a
	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0001)
	mov	a,r6
	movx	@dptr,a
	lcall	_timer_read
	mov	r1, dpl
	mov	r3, dph
	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0002)
	mov	a,r1
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0004)
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0005)
	mov	a,r2
	movx	@dptr,a
;	quantum/keyboard.c:610: AK820_ACTION_EXEC(dummy_event);
	mov	dptr,#_matrix_task_dummy_event_90004_521
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar2
	lcall	_ak820_action_exec
	pop	ar2
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
00112$:
;	quantum/keyboard.c:613: switch_events(row, col, key_pressed);
	mov	dptr,#_switch_events_PARM_2
	mov	a,r4
	movx	@dptr,a
	mov	dptr,#_switch_events_PARM_3
	mov	a,r2
	movx	@dptr,a
	mov	dpl, r6
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_switch_events
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
00131$:
;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
	inc	r4
	mov	dptr,#_matrix_task_col_mask_30004_515
	movx	a,@dptr
	add	a,acc
	movx	@dptr,a
	ljmp	00130$
00115$:
;	quantum/keyboard.c:617: matrix_previous[row] = current_row;
	mov	a,r6
	lcall	_ak820_outline_0066
	mov	a,r5
	movx	@dptr,a
00116$:
;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
	inc	r6
	ljmp	00133$
00117$:
;	quantum/keyboard.c:620: return matrix_changed;
	mov	dpl, #0x01
;	quantum/keyboard.c:621: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'quantum_task'
;------------------------------------------------------------
;	quantum/keyboard.c:627: void quantum_task(void) {
;	-----------------------------------------
;	 function quantum_task
;	-----------------------------------------
_quantum_task:
;	quantum/keyboard.c:694: caps_word_task();
;	quantum/keyboard.c:700: }
	ljmp	_caps_word_task
;------------------------------------------------------------
;Allocation info for local variables in function 'keyboard_task'
;------------------------------------------------------------
;activity_has_occurred Allocated with name '_keyboard_task_activity_has_occurred_10000_536'
;------------------------------------------------------------
;	quantum/keyboard.c:703: void keyboard_task(void) {
;	-----------------------------------------
;	 function keyboard_task
;	-----------------------------------------
_keyboard_task:
;	quantum/keyboard.c:705: if (matrix_task()) {
	lcall	_matrix_task
	mov	a, dpl
	jz	00102$
;	quantum/keyboard.c:706: last_matrix_activity_trigger();
	lcall	_last_matrix_activity_trigger
;	quantum/keyboard.c:707: activity_has_occurred = true;
00102$:
;	quantum/keyboard.c:710: quantum_task();
	lcall	_quantum_task
;	quantum/keyboard.c:724: rgb_matrix_task();
	lcall	_rgb_matrix_task
;	quantum/keyboard.c:734: if (encoder_read()) {
	lcall	_encoder_read
	mov	a, dpl
	jz	00104$
;	quantum/keyboard.c:735: last_encoder_activity_trigger();
	lcall	_last_encoder_activity_trigger
;	quantum/keyboard.c:736: activity_has_occurred = true;
00104$:
;	quantum/keyboard.c:790: led_task();
;	quantum/keyboard.c:791: }
	ljmp	_led_task
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__last_input_modification_time:
	.byte #0x00, #0x00, #0x00, #0x00	; 0
__xinit__last_matrix_modification_time:
	.byte #0x00, #0x00, #0x00, #0x00	; 0
__xinit__last_encoder_modification_time:
	.byte #0x00, #0x00, #0x00, #0x00	; 0
__xinit__last_pointing_device_modification_time:
	.byte #0x00, #0x00, #0x00, #0x00	; 0
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0007
	.globl _ak820_outline_0056
	.globl _ak820_outline_0058
	.globl _ak820_outline_0059
	.globl _ak820_outline_0066
	.globl _ak820_outline_0070
	.globl _ak820_outline_0130
	.globl _ak820_outline_0144

	.area CSEG (CODE)
; function ak820_outline_0066
_ak820_outline_0066:
	add	a,#_matrix_task_matrix_previous_10001_502
	mov	dpl,a
	clr	a
	addc	a,#(_matrix_task_matrix_previous_10001_502>>8)
	mov	dph,a
	ret
