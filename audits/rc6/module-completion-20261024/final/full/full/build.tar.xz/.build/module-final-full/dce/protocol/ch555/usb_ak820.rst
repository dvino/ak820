                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000014                        576 _control_setup_valid_interface_10000_286:
      000014                        577 	.ds 1
      000015                        578 _control_setup_zero_index_10000_286:
      000015                        579 	.ds 1
      000016                        580 _control_setup_zero_value_10000_286:
      000016                        581 	.ds 1
      000017                        582 _control_setup_zero_length_10000_286:
      000017                        583 	.ds 1
      000018                        584 _control_setup_sloc0_1_0:
      000018                        585 	.ds 1
      000019                        586 _control_setup_sloc2_1_0:
      000019                        587 	.ds 1
      00001A                        588 _ak820_usb_try_send_sloc0_1_0:
      00001A                        589 	.ds 1
      00001B                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001B                        591 	.ds 1
      00001C                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001C                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      000761                        602 _D0SetupReqCode::
      000761                        603 	.ds 1
      000762                        604 _D0SetupLen::
      000762                        605 	.ds 2
      000764                        606 _pD0Descr::
      000764                        607 	.ds 3
      000767                        608 _D0UsbConfig::
      000767                        609 	.ds 1
      000768                        610 _USB_EnumStatus::
      000768                        611 	.ds 1
      000769                        612 _USB_SleepStatus::
      000769                        613 	.ds 1
      00076A                        614 _MCU_Sleep_Operate::
      00076A                        615 	.ds 1
      00076B                        616 _KB_USB_UpStatus::
      00076B                        617 	.ds 1
      00076C                        618 _KB_USB_SetReport::
      00076C                        619 	.ds 1
      00076D                        620 _ak820_boot_stage::
      00076D                        621 	.ds 1
      00076E                        622 _ak820_main_heartbeat::
      00076E                        623 	.ds 1
      00076F                        624 _raw_state:
      00076F                        625 	.ds 1
      000770                        626 _raw_buffer:
      000770                        627 	.ds 32
      000790                        628 _raw_reply_without_nvm:
      000790                        629 	.ds 1
      000791                        630 _keyboard_reset:
      000791                        631 	.ds 1
      000792                        632 _input_snapshot:
      000792                        633 	.ds 46
      0007C0                        634 _control_phase:
      0007C0                        635 	.ds 1
      0007C1                        636 _output_kind:
      0007C1                        637 	.ds 1
      0007C2                        638 _output_report_id:
      0007C2                        639 	.ds 1
      0007C3                        640 _control_zlp:
      0007C3                        641 	.ds 1
      0007C4                        642 _control_pointer:
      0007C4                        643 	.ds 2
      0007C6                        644 _descriptor_select_PARM_2:
      0007C6                        645 	.ds 1
      0007C7                        646 _descriptor_select_PARM_3:
      0007C7                        647 	.ds 2
      0007C9                        648 _descriptor_select_type_10000_268:
      0007C9                        649 	.ds 1
      0007CA                        650 _control_setup_length_10000_286:
      0007CA                        651 	.ds 2
      0007CC                        652 _control_setup_offset_10000_286:
      0007CC                        653 	.ds 1
      0007CD                        654 _ak820_usb_send_PARM_2:
      0007CD                        655 	.ds 2
      0007CF                        656 _ak820_usb_send_PARM_3:
      0007CF                        657 	.ds 1
      0007D0                        658 _ak820_usb_send_endpoint_10000_422:
      0007D0                        659 	.ds 1
      0007D1                        660 _ak820_usb_send_offset_10000_423:
      0007D1                        661 	.ds 1
      0007D2                        662 _ak820_usb_try_send_PARM_2:
      0007D2                        663 	.ds 2
      0007D4                        664 _ak820_usb_try_send_PARM_3:
      0007D4                        665 	.ds 1
      0007D5                        666 _ak820_usb_try_send_endpoint_10000_443:
      0007D5                        667 	.ds 1
      0007D6                        668 _ak820_usb_try_send_sent_10000_444:
      0007D6                        669 	.ds 1
      0007D7                        670 _ak820_usb_raw_send_PARM_2:
      0007D7                        671 	.ds 1
      0007D8                        672 _ak820_usb_raw_send_report_10000_459:
      0007D8                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      0059C5                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      0059C5 90 07 6F         [24]  727 	mov	dptr,#_raw_state
      0059C8 E0               [24]  728 	movx	a,@dptr
      0059C9 FF               [12]  729 	mov	r7,a
      0059CA BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      0059CD 80 1C            [24]  731 	sjmp	00101$
      0059CF                        732 00130$:
      0059CF 90 07 6F         [24]  733 	mov	dptr,#_raw_state
      0059D2 E0               [24]  734 	movx	a,@dptr
      0059D3 FF               [12]  735 	mov	r7,a
      0059D4 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      0059D7 80 12            [24]  737 	sjmp	00101$
      0059D9                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      0059D9 90 07 6F         [24]  740 	mov	dptr,#_raw_state
      0059DC E0               [24]  741 	movx	a,@dptr
      0059DD FF               [12]  742 	mov	r7,a
      0059DE BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      0059E1 80 08            [24]  744 	sjmp	00101$
      0059E3                        745 00132$:
      0059E3 90 07 6F         [24]  746 	mov	dptr,#_raw_state
      0059E6 E0               [24]  747 	movx	a,@dptr
      0059E7 FF               [12]  748 	mov	r7,a
      0059E8 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      0059EB                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      0059EB 90 07 6F         [24]  752 	mov	dptr,#_raw_state
      0059EE 74 07            [12]  753 	mov	a,#0x07
      0059F0 F0               [24]  754 	movx	@dptr,a
      0059F1 80 05            [24]  755 	sjmp	00103$
      0059F3                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      0059F3 90 07 6F         [24]  758 	mov	dptr,#_raw_state
      0059F6 E4               [12]  759 	clr	a
      0059F7 F0               [24]  760 	movx	@dptr,a
      0059F8                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      0059F8 90 07 C1         [24]  763 	mov	dptr,#_output_kind
      0059FB E4               [12]  764 	clr	a
      0059FC F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      0059FD 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      0059FE                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      0059FE 90 07 6F         [24]  777 	mov	dptr,#_raw_state
      005A01 E0               [24]  778 	movx	a,@dptr
      005A02 FF               [12]  779 	mov	r7,a
      005A03 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005A06 90 07 6F         [24]  781 	mov	dptr,#_raw_state
      005A09 74 06            [12]  782 	mov	a,#0x06
      005A0B F0               [24]  783 	movx	@dptr,a
      005A0C 22               [24]  784 	ret
      005A0D                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005A0D 90 07 6F         [24]  787 	mov	dptr,#_raw_state
      005A10 E0               [24]  788 	movx	a,@dptr
      005A11 FF               [12]  789 	mov	r7,a
      005A12 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005A15 90 07 6F         [24]  791 	mov	dptr,#_raw_state
      005A18 E4               [12]  792 	clr	a
      005A19 F0               [24]  793 	movx	@dptr,a
      005A1A                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005A1A 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005A1B                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005A1B 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005A1E 74 01            [12]  809 	mov	a,#0x01
      005A20 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A21 F5 82            [12]  812 	mov	dpl,a
      005A23 74 12            [12]  813 	mov	a,#0x12
      005A25 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A26 A3               [24]  816 	inc	dptr
      005A27 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A28 A3               [24]  819 	inc	dptr
      005A29 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005A2A 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005A2D E4               [12]  823 	clr	a
      005A2E F0               [24]  824 	movx	@dptr,a
      005A2F 15 82            [12]  825 	dec	dpl
      005A31 F0               [24]  826 	movx	@dptr,a
      005A32 15 82            [12]  827 	dec	dpl
      005A34 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005A35 FF               [12]  830 	mov	r7,a
      005A36                        831 00103$:
      005A36 EF               [12]  832 	mov	a,r7
      005A37 24 92            [12]  833 	add	a, #_input_snapshot
      005A39 F5 82            [12]  834 	mov	dpl,a
      005A3B E4               [12]  835 	clr	a
      005A3C 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005A3E F5 83            [12]  837 	mov	dph,a
      005A40 E4               [12]  838 	clr	a
      005A41 F0               [24]  839 	movx	@dptr,a
      005A42 0F               [12]  840 	inc	r7
      005A43 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005A46                        842 00139$:
      005A46 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005A48 90 07 9A         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005A4B 74 06            [12]  846 	mov	a,#0x06
      005A4D F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005A4E 90 07 BA         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005A51 03               [12]  850 	rr	a
      005A52 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005A53 90 07 BD         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005A56 04               [12]  854 	inc	a
      005A57 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005A58 7F 00            [12]  857 	mov	r7,#0x00
      005A5A                        858 00105$:
      005A5A 8F 06            [24]  859 	mov	ar6,r7
      005A5C 74 C0            [12]  860 	mov	a,#0xc0
      005A5E 2E               [12]  861 	add	a, r6
      005A5F F5 82            [12]  862 	mov	dpl,a
      005A61 74 10            [12]  863 	mov	a,#0x10
      005A63 24 00            [12]  864 	add	a, #0x00
      005A65 F5 83            [12]  865 	mov	dph,a
      005A67 E4               [12]  866 	clr	a
      005A68 F0               [24]  867 	movx	@dptr,a
      005A69 0F               [12]  868 	inc	r7
      005A6A BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005A6D                        870 00141$:
      005A6D 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005A6F 02 59 C5         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005A72                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005A72 90 07 6F         [24]  884 	mov	dptr,#_raw_state
      005A75 E0               [24]  885 	movx	a,@dptr
      005A76 FF               [12]  886 	mov	r7,a
      005A77 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005A7A 90 07 6F         [24]  888 	mov	dptr,#_raw_state
      005A7D E4               [12]  889 	clr	a
      005A7E F0               [24]  890 	movx	@dptr,a
      005A7F                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005A7F 90 07 C1         [24]  893 	mov	dptr,#_output_kind
      005A82 E4               [12]  894 	clr	a
      005A83 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005A84 90 07 C0         [24]  897 	mov	dptr,#_control_phase
      005A87 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005A88 90 07 61         [24]  900 	mov	dptr,#_D0SetupReqCode
      005A8B 14               [12]  901 	dec	a
      005A8C F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005A8D 90 22 00         [24]  904 	mov	dptr,#0x2200
      005A90 74 CF            [12]  905 	mov	a,#0xcf
      005A92 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005A93 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005A94                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005A94 90 07 62         [24]  921 	mov	dptr,#_D0SetupLen
      005A97 E0               [24]  922 	movx	a,@dptr
      005A98 FE               [12]  923 	mov	r6,a
      005A99 A3               [24]  924 	inc	dptr
      005A9A E0               [24]  925 	movx	a,@dptr
      005A9B FF               [12]  926 	mov	r7,a
      005A9C C3               [12]  927 	clr	c
      005A9D 74 40            [12]  928 	mov	a,#0x40
      005A9F 9E               [12]  929 	subb	a,r6
      005AA0 E4               [12]  930 	clr	a
      005AA1 9F               [12]  931 	subb	a,r7
      005AA2 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005AA4 7E 40            [12]  934 	mov	r6,#0x40
      005AA6 80 07            [24]  935 	sjmp	00110$
      005AA8                        936 00109$:
      005AA8 90 07 62         [24]  937 	mov	dptr,#_D0SetupLen
      005AAB E0               [24]  938 	movx	a,@dptr
      005AAC FE               [12]  939 	mov	r6,a
      005AAD A3               [24]  940 	inc	dptr
      005AAE E0               [24]  941 	movx	a,@dptr
      005AAF                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005AAF 7F 00            [12]  944 	mov	r7,#0x00
      005AB1                        945 00105$:
      005AB1 C3               [12]  946 	clr	c
      005AB2 EF               [12]  947 	mov	a,r7
      005AB3 9E               [12]  948 	subb	a,r6
      005AB4 50 2A            [24]  949 	jnc	00101$
      005AB6 8F 04            [24]  950 	mov	ar4,r7
      005AB8 74 10            [12]  951 	mov	a,#0x10
      005ABA 24 00            [12]  952 	add	a, #0x00
      005ABC FD               [12]  953 	mov	r5,a
      005ABD 90 07 C4         [24]  954 	mov	dptr,#_control_pointer
      005AC0 E0               [24]  955 	movx	a,@dptr
      005AC1 FA               [12]  956 	mov	r2,a
      005AC2 A3               [24]  957 	inc	dptr
      005AC3 E0               [24]  958 	movx	a,@dptr
      005AC4 FB               [12]  959 	mov	r3,a
      005AC5 8A 82            [24]  960 	mov	dpl,r2
      005AC7 8B 83            [24]  961 	mov	dph,r3
      005AC9 E4               [12]  962 	clr	a
      005ACA 93               [24]  963 	movc	a,@a+dptr
      005ACB F9               [12]  964 	mov	r1,a
      005ACC 90 07 C4         [24]  965 	mov	dptr,#_control_pointer
      005ACF 74 01            [12]  966 	mov	a,#0x01
      005AD1 2A               [12]  967 	add	a, r2
      005AD2 F0               [24]  968 	movx	@dptr,a
      005AD3 E4               [12]  969 	clr	a
      005AD4 3B               [12]  970 	addc	a, r3
      005AD5 A3               [24]  971 	inc	dptr
      005AD6 F0               [24]  972 	movx	@dptr,a
      005AD7 8C 82            [24]  973 	mov	dpl,r4
      005AD9 8D 83            [24]  974 	mov	dph,r5
      005ADB E9               [12]  975 	mov	a,r1
      005ADC F0               [24]  976 	movx	@dptr,a
      005ADD 0F               [12]  977 	inc	r7
      005ADE 80 D1            [24]  978 	sjmp	00105$
      005AE0                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005AE0 8E 05            [24]  981 	mov	ar5,r6
      005AE2 7F 00            [12]  982 	mov	r7,#0x00
      005AE4 90 07 62         [24]  983 	mov	dptr,#_D0SetupLen
      005AE7 E0               [24]  984 	movx	a,@dptr
      005AE8 FB               [12]  985 	mov	r3,a
      005AE9 A3               [24]  986 	inc	dptr
      005AEA E0               [24]  987 	movx	a,@dptr
      005AEB FC               [12]  988 	mov	r4,a
      005AEC EB               [12]  989 	mov	a,r3
      005AED C3               [12]  990 	clr	c
      005AEE 9D               [12]  991 	subb	a,r5
      005AEF FB               [12]  992 	mov	r3,a
      005AF0 EC               [12]  993 	mov	a,r4
      005AF1 9F               [12]  994 	subb	a,r7
      005AF2 FC               [12]  995 	mov	r4,a
      005AF3 90 07 62         [24]  996 	mov	dptr,#_D0SetupLen
      005AF6 EB               [12]  997 	mov	a,r3
      005AF7 F0               [24]  998 	movx	@dptr,a
      005AF8 EC               [12]  999 	mov	a,r4
      005AF9 A3               [24] 1000 	inc	dptr
      005AFA F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005AFB EE               [12] 1003 	mov	a,r6
      005AFC 70 05            [24] 1004 	jnz	00103$
      005AFE 90 07 C3         [24] 1005 	mov	dptr,#_control_zlp
      005B01 E4               [12] 1006 	clr	a
      005B02 F0               [24] 1007 	movx	@dptr,a
      005B03                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005B03 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005B06 EE               [12] 1011 	mov	a,r6
      005B07 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005B08 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005B0B E0               [24] 1015 	movx	a,@dptr
      005B0C 54 C0            [12] 1016 	anl	a,#0xc0
      005B0E F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005B0F 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005B10                       1032 _descriptor_select:
      005B10 E5 82            [12] 1033 	mov	a,dpl
      005B12 90 07 C9         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      005B15 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005B16 E0               [24] 1037 	movx	a,@dptr
      005B17 FF               [12] 1038 	mov	r7,a
      005B18 BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005B1B 90 07 C6         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005B1E E0               [24] 1041 	movx	a,@dptr
      005B1F 70 1A            [24] 1042 	jnz	00102$
      005B21 90 07 C7         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005B24 E0               [24] 1044 	movx	a,@dptr
      005B25 F5 F0            [12] 1045 	mov	b,a
      005B27 A3               [24] 1046 	inc	dptr
      005B28 E0               [24] 1047 	movx	a,@dptr
      005B29 45 F0            [12] 1048 	orl	a,b
      005B2B 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005B2D 90 07 C4         [24] 1051 	mov	dptr,#_control_pointer
      005B30 74 C0            [12] 1052 	mov	a,#_DeviceDescriptor
      005B32 F0               [24] 1053 	movx	@dptr,a
      005B33 74 BD            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005B35 A3               [24] 1055 	inc	dptr
      005B36 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      005B37 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005B3A 22               [24] 1059 	ret
      005B3B                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005B3B 90 07 C9         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      005B3E E0               [24] 1063 	movx	a,@dptr
      005B3F FF               [12] 1064 	mov	r7,a
      005B40 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005B43 90 07 C6         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005B46 E0               [24] 1067 	movx	a,@dptr
      005B47 70 1A            [24] 1068 	jnz	00106$
      005B49 90 07 C7         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005B4C E0               [24] 1070 	movx	a,@dptr
      005B4D F5 F0            [12] 1071 	mov	b,a
      005B4F A3               [24] 1072 	inc	dptr
      005B50 E0               [24] 1073 	movx	a,@dptr
      005B51 45 F0            [12] 1074 	orl	a,b
      005B53 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005B55 90 07 C4         [24] 1077 	mov	dptr,#_control_pointer
      005B58 74 D2            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005B5A F0               [24] 1079 	movx	@dptr,a
      005B5B 74 BD            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005B5D A3               [24] 1081 	inc	dptr
      005B5E F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      005B5F 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005B62 22               [24] 1085 	ret
      005B63                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      005B63 90 07 C9         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      005B66 E0               [24] 1089 	movx	a,@dptr
      005B67 FF               [12] 1090 	mov	r7,a
      005B68 BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005B6B 80 03            [24] 1092 	sjmp	00239$
      005B6D                       1093 00238$:
      005B6D 02 5C 07         [24] 1094 	ljmp	00119$
      005B70                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      005B70 90 07 C7         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005B73 E0               [24] 1098 	movx	a,@dptr
      005B74 FD               [12] 1099 	mov	r5,a
      005B75 A3               [24] 1100 	inc	dptr
      005B76 E0               [24] 1101 	movx	a,@dptr
      005B77 FE               [12] 1102 	mov	r6,a
      005B78 90 07 C7         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005B7B E0               [24] 1104 	movx	a,@dptr
      005B7C F5 F0            [12] 1105 	mov	b,a
      005B7E A3               [24] 1106 	inc	dptr
      005B7F E0               [24] 1107 	movx	a,@dptr
      005B80 45 F0            [12] 1108 	orl	a,b
      005B82 60 0C            [24] 1109 	jz	00110$
      005B84 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005B87 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005B8A 80 04            [24] 1112 	sjmp	00110$
      005B8C                       1113 00241$:
      005B8C 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005B8F 22               [24] 1115 	ret
      005B90                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      005B90 90 07 C6         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005B93 E0               [24] 1119 	movx	a,@dptr
      005B94 FE               [12] 1120 	mov  r6,a
      005B95 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005B97 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005B99 EE               [12] 1124 	mov	a,r6
      005B9A 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005B9B 90 5B 9F         [24] 1127 	mov	dptr,#00243$
      005B9E 73               [24] 1128 	jmp	@a+dptr
      005B9F                       1129 00243$:
      005B9F 80 06            [24] 1130 	sjmp	00112$
      005BA1 80 1B            [24] 1131 	sjmp	00113$
      005BA3 80 30            [24] 1132 	sjmp	00114$
      005BA5 80 45            [24] 1133 	sjmp	00115$
      005BA7                       1134 00112$:
      005BA7 90 07 C4         [24] 1135 	mov	dptr,#_control_pointer
      005BAA 74 26            [12] 1136 	mov	a,#_LanguageString
      005BAC F0               [24] 1137 	movx	@dptr,a
      005BAD 74 BE            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005BAF A3               [24] 1139 	inc	dptr
      005BB0 F0               [24] 1140 	movx	@dptr,a
      005BB1 90 BE 26         [24] 1141 	mov	dptr,#_LanguageString
      005BB4 E4               [12] 1142 	clr	a
      005BB5 93               [24] 1143 	movc	a,@a+dptr
      005BB6 FE               [12] 1144 	mov	r6,a
      005BB7 7D 00            [12] 1145 	mov	r5,#0x00
      005BB9 8E 82            [24] 1146 	mov	dpl, r6
      005BBB 8D 83            [24] 1147 	mov	dph, r5
      005BBD 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005BBE                       1150 00113$:
      005BBE 90 07 C4         [24] 1151 	mov	dptr,#_control_pointer
      005BC1 74 2A            [12] 1152 	mov	a,#_ManufacturerString
      005BC3 F0               [24] 1153 	movx	@dptr,a
      005BC4 74 BE            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005BC6 A3               [24] 1155 	inc	dptr
      005BC7 F0               [24] 1156 	movx	@dptr,a
      005BC8 90 BE 2A         [24] 1157 	mov	dptr,#_ManufacturerString
      005BCB E4               [12] 1158 	clr	a
      005BCC 93               [24] 1159 	movc	a,@a+dptr
      005BCD FE               [12] 1160 	mov	r6,a
      005BCE 7D 00            [12] 1161 	mov	r5,#0x00
      005BD0 8E 82            [24] 1162 	mov	dpl, r6
      005BD2 8D 83            [24] 1163 	mov	dph, r5
      005BD4 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005BD5                       1166 00114$:
      005BD5 90 07 C4         [24] 1167 	mov	dptr,#_control_pointer
      005BD8 74 38            [12] 1168 	mov	a,#_ProductString
      005BDA F0               [24] 1169 	movx	@dptr,a
      005BDB 74 BE            [12] 1170 	mov	a,#(_ProductString >> 8)
      005BDD A3               [24] 1171 	inc	dptr
      005BDE F0               [24] 1172 	movx	@dptr,a
      005BDF 90 BE 38         [24] 1173 	mov	dptr,#_ProductString
      005BE2 E4               [12] 1174 	clr	a
      005BE3 93               [24] 1175 	movc	a,@a+dptr
      005BE4 FE               [12] 1176 	mov	r6,a
      005BE5 7D 00            [12] 1177 	mov	r5,#0x00
      005BE7 8E 82            [24] 1178 	mov	dpl, r6
      005BE9 8D 83            [24] 1179 	mov	dph, r5
      005BEB 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005BEC                       1182 00115$:
      005BEC 90 07 C4         [24] 1183 	mov	dptr,#_control_pointer
      005BEF 74 70            [12] 1184 	mov	a,#_SerialNumberString
      005BF1 F0               [24] 1185 	movx	@dptr,a
      005BF2 74 BE            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005BF4 A3               [24] 1187 	inc	dptr
      005BF5 F0               [24] 1188 	movx	@dptr,a
      005BF6 90 BE 70         [24] 1189 	mov	dptr,#_SerialNumberString
      005BF9 E4               [12] 1190 	clr	a
      005BFA 93               [24] 1191 	movc	a,@a+dptr
      005BFB FE               [12] 1192 	mov	r6,a
      005BFC 7D 00            [12] 1193 	mov	r5,#0x00
      005BFE 8E 82            [24] 1194 	mov	dpl, r6
      005C00 8D 83            [24] 1195 	mov	dph, r5
      005C02 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      005C03                       1198 00116$:
      005C03 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005C06 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      005C07                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      005C07 90 07 C6         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005C0A E0               [24] 1205 	movx	a,@dptr
      005C0B 70 11            [24] 1206 	jnz	00120$
      005C0D 90 07 C7         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005C10 E0               [24] 1208 	movx	a,@dptr
      005C11 FD               [12] 1209 	mov	r5,a
      005C12 A3               [24] 1210 	inc	dptr
      005C13 E0               [24] 1211 	movx	a,@dptr
      005C14 FE               [12] 1212 	mov	r6,a
      005C15 C3               [12] 1213 	clr	c
      005C16 ED               [12] 1214 	mov	a,r5
      005C17 94 03            [12] 1215 	subb	a,#0x03
      005C19 EE               [12] 1216 	mov	a,r6
      005C1A 94 00            [12] 1217 	subb	a,#0x00
      005C1C 40 04            [24] 1218 	jc	00121$
      005C1E                       1219 00120$:
      005C1E 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005C21 22               [24] 1221 	ret
      005C22                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005C22 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005C25 80 03            [24] 1225 	sjmp	00127$
      005C27                       1226 00246$:
      005C27 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      005C2A                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005C2A ED               [12] 1230 	mov	a,r5
      005C2B 75 F0 04         [24] 1231 	mov	b,#0x04
      005C2E A4               [48] 1232 	mul	ab
      005C2F 24 49            [12] 1233 	add	a, #_interface_descriptors
      005C31 FE               [12] 1234 	mov	r6,a
      005C32 74 B7            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      005C34 35 F0            [12] 1236 	addc	a, b
      005C36 FF               [12] 1237 	mov	r7,a
      005C37 8E 82            [24] 1238 	mov	dpl,r6
      005C39 8F 83            [24] 1239 	mov	dph,r7
      005C3B A3               [24] 1240 	inc	dptr
      005C3C A3               [24] 1241 	inc	dptr
      005C3D E4               [12] 1242 	clr	a
      005C3E 93               [24] 1243 	movc	a,@a+dptr
      005C3F FC               [12] 1244 	mov	r4,a
      005C40 A3               [24] 1245 	inc	dptr
      005C41 E4               [12] 1246 	clr	a
      005C42 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      005C43 FD               [12] 1249 	mov	r5,a
      005C44 4C               [12] 1250 	orl	a,r4
      005C45 70 04            [24] 1251 	jnz	00124$
      005C47 90 00 00         [24] 1252 	mov	dptr,#0x0000
      005C4A 22               [24] 1253 	ret
      005C4B                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      005C4B 90 07 C9         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      005C4E E0               [24] 1257 	movx	a,@dptr
      005C4F FB               [12] 1258 	mov	r3,a
      005C50 BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005C53 8E 82            [24] 1261 	mov	dpl,r6
      005C55 8F 83            [24] 1262 	mov	dph,r7
      005C57 E4               [12] 1263 	clr	a
      005C58 93               [24] 1264 	movc	a,@a+dptr
      005C59 FE               [12] 1265 	mov	r6,a
      005C5A A3               [24] 1266 	inc	dptr
      005C5B E4               [12] 1267 	clr	a
      005C5C 93               [24] 1268 	movc	a,@a+dptr
      005C5D FF               [12] 1269 	mov	r7,a
      005C5E 90 07 C4         [24] 1270 	mov	dptr,#_control_pointer
      005C61 EE               [12] 1271 	mov	a,r6
      005C62 F0               [24] 1272 	movx	@dptr,a
      005C63 EF               [12] 1273 	mov	a,r7
      005C64 A3               [24] 1274 	inc	dptr
      005C65 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      005C66 74 07            [12] 1277 	mov	a,#0x07
      005C68 2C               [12] 1278 	add	a, r4
      005C69 F5 82            [12] 1279 	mov	dpl,a
      005C6B E4               [12] 1280 	clr	a
      005C6C 3D               [12] 1281 	addc	a, r5
      005C6D F5 83            [12] 1282 	mov	dph,a
      005C6F E4               [12] 1283 	clr	a
      005C70 93               [24] 1284 	movc	a,@a+dptr
      005C71 FE               [12] 1285 	mov	r6,a
      005C72 A3               [24] 1286 	inc	dptr
      005C73 E4               [12] 1287 	clr	a
      005C74 93               [24] 1288 	movc	a,@a+dptr
      005C75 FF               [12] 1289 	mov	r7,a
      005C76 8E 82            [24] 1290 	mov	dpl, r6
      005C78 8F 83            [24] 1291 	mov	dph, r7
      005C7A 22               [24] 1292 	ret
      005C7B                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      005C7B 90 07 C4         [24] 1295 	mov	dptr,#_control_pointer
      005C7E EC               [12] 1296 	mov	a,r4
      005C7F F0               [24] 1297 	movx	@dptr,a
      005C80 ED               [12] 1298 	mov	a,r5
      005C81 A3               [24] 1299 	inc	dptr
      005C82 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      005C83 90 00 09         [24] 1302 	mov	dptr,#0x0009
      005C86 22               [24] 1303 	ret
      005C87                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      005C87 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      005C8A 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      005C8B                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005C8B 90 10 00         [24] 1330 	mov	dptr,#0x1000
      005C8E E0               [24] 1331 	movx	a,@dptr
      005C8F FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005C90 A3               [24] 1334 	inc	dptr
      005C91 A3               [24] 1335 	inc	dptr
      005C92 E0               [24] 1336 	movx	a,@dptr
      005C93 FE               [12] 1337 	mov	r6,a
      005C94 A3               [24] 1338 	inc	dptr
      005C95 E0               [24] 1339 	movx	a,@dptr
      005C96 FC               [12] 1340 	mov	r4,a
      005C97 7D 00            [12] 1341 	mov	r5,#0x00
      005C99 8E 03            [24] 1342 	mov	ar3,r6
      005C9B 7E 00            [12] 1343 	mov	r6,#0x00
      005C9D ED               [12] 1344 	mov	a,r5
      005C9E 4B               [12] 1345 	orl	a,r3
      005C9F FD               [12] 1346 	mov	r5,a
      005CA0 EC               [12] 1347 	mov	a,r4
      005CA1 4E               [12] 1348 	orl	a,r6
      005CA2 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005CA3 A3               [24] 1351 	inc	dptr
      005CA4 E0               [24] 1352 	movx	a,@dptr
      005CA5 FC               [12] 1353 	mov	r4,a
      005CA6 A3               [24] 1354 	inc	dptr
      005CA7 E0               [24] 1355 	movx	a,@dptr
      005CA8 FA               [12] 1356 	mov	r2,a
      005CA9 7B 00            [12] 1357 	mov	r3,#0x00
      005CAB 8C 01            [24] 1358 	mov	ar1,r4
      005CAD 7C 00            [12] 1359 	mov	r4,#0x00
      005CAF EB               [12] 1360 	mov	a,r3
      005CB0 49               [12] 1361 	orl	a,r1
      005CB1 FB               [12] 1362 	mov	r3,a
      005CB2 EA               [12] 1363 	mov	a,r2
      005CB3 4C               [12] 1364 	orl	a,r4
      005CB4 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      005CB5 C3               [12] 1367 	clr	c
      005CB6 EB               [12] 1368 	mov	a,r3
      005CB7 94 03            [12] 1369 	subb	a,#0x03
      005CB9 EC               [12] 1370 	mov	a,r4
      005CBA 94 00            [12] 1371 	subb	a,#0x00
      005CBC 92 14            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      005CBE EB               [12] 1374 	mov	a,r3
      005CBF 4C               [12] 1375 	orl	a,r4
      005CC0 B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      005CC3                       1377 01201$:
      005CC3 92 15            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      005CC5 ED               [12] 1380 	mov	a,r5
      005CC6 4E               [12] 1381 	orl	a,r6
      005CC7 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      005CCA                       1383 01202$:
                                   1384 ;	assignBit
      005CCA 92 18            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      005CCC 92 16            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      005CCE 90 07 CC         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      005CD1 E4               [12] 1389 	clr	a
      005CD2 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005CD3 90 07 6F         [24] 1392 	mov	dptr,#_raw_state
      005CD6 E0               [24] 1393 	movx	a,@dptr
      005CD7 FA               [12] 1394 	mov	r2,a
      005CD8 BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      005CDB 90 07 6F         [24] 1396 	mov	dptr,#_raw_state
      005CDE E4               [12] 1397 	clr	a
      005CDF F0               [24] 1398 	movx	@dptr,a
      005CE0                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      005CE0 C0 07            [24] 1401 	push	ar7
      005CE2 90 07 C1         [24] 1402 	mov	dptr,#_output_kind
      005CE5 E4               [12] 1403 	clr	a
      005CE6 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      005CE7 90 07 C0         [24] 1406 	mov	dptr,#_control_phase
      005CEA F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      005CEB 90 07 C3         [24] 1409 	mov	dptr,#_control_zlp
      005CEE F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005CEF 90 10 01         [24] 1412 	mov	dptr,#0x1001
      005CF2 E0               [24] 1413 	movx	a,@dptr
      005CF3 90 07 61         [24] 1414 	mov	dptr,#_D0SetupReqCode
      005CF6 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005CF7 90 10 06         [24] 1417 	mov	dptr,#0x1006
      005CFA E0               [24] 1418 	movx	a,@dptr
      005CFB FA               [12] 1419 	mov	r2,a
      005CFC A3               [24] 1420 	inc	dptr
      005CFD E0               [24] 1421 	movx	a,@dptr
      005CFE F9               [12] 1422 	mov	r1,a
      005CFF 78 00            [12] 1423 	mov	r0,#0x00
      005D01 7F 00            [12] 1424 	mov	r7,#0x00
      005D03 90 07 62         [24] 1425 	mov	dptr,#_D0SetupLen
      005D06 E8               [12] 1426 	mov	a,r0
      005D07 4A               [12] 1427 	orl	a,r2
      005D08 F0               [24] 1428 	movx	@dptr,a
      005D09 E9               [12] 1429 	mov	a,r1
      005D0A 4F               [12] 1430 	orl	a,r7
      005D0B A3               [24] 1431 	inc	dptr
      005D0C F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      005D0D 90 07 62         [24] 1434 	mov	dptr,#_D0SetupLen
      005D10 E0               [24] 1435 	movx	a,@dptr
      005D11 FA               [12] 1436 	mov	r2,a
      005D12 A3               [24] 1437 	inc	dptr
      005D13 E0               [24] 1438 	movx	a,@dptr
      005D14 4A               [12] 1439 	orl	a,r2
      005D15 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      005D18                       1441 01205$:
      005D18 92 17            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005D1A 90 22 00         [24] 1444 	mov	dptr,#0x2200
      005D1D 74 C2            [12] 1445 	mov	a,#0xc2
      005D1F F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      005D20 90 22 08         [24] 1448 	mov	dptr,#0x2208
      005D23 E4               [12] 1449 	clr	a
      005D24 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      005D25 90 07 61         [24] 1452 	mov	dptr,#_D0SetupReqCode
      005D28 E0               [24] 1453 	movx	a,@dptr
      005D29 F5 16            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      005D2B C3               [12] 1455 	clr	c
      005D2C 74 0B            [12] 1456 	mov	a,#0x0b
      005D2E 95 16            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      005D30 D0 07            [24] 1458 	pop	ar7
      005D32 50 03            [24] 1459 	jnc	01206$
      005D34 02 5A 72         [24] 1460 	ljmp	_control_stall
      005D37                       1461 01206$:
                                   1462 ;	free result
      005D37 E5 16            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      005D39 F5 F0            [12] 1464 	mov	b,a
      005D3B 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      005D3D 83               [24] 1466 	movc	a,@a+pc
      005D3E F5 82            [12] 1467 	mov	dpl,a
      005D40 E5 F0            [12] 1468 	mov	a,b
      005D42 24 10            [12] 1469 	add	a,#(01208$-3-.)
      005D44 83               [24] 1470 	movc	a,@a+pc
      005D45 F5 83            [12] 1471 	mov	dph,a
      005D47 E4               [12] 1472 	clr	a
      005D48 73               [24] 1473 	jmp	@a+dptr
      005D49                       1474 01207$:
      005D49 F1                    1475 	.db	00188$
      005D4A 97                    1476 	.db	00205$
      005D4B DA                    1477 	.db	00282$
      005D4C 97                    1478 	.db	00205$
      005D4D 1E                    1479 	.db	00290$
      005D4E 1B                    1480 	.db	00116$
      005D4F 61                    1481 	.db	00103$
      005D50 1E                    1482 	.db	00290$
      005D51 20                    1483 	.db	00150$
      005D52 44                    1484 	.db	00123$
      005D53 50                    1485 	.db	00157$
      005D54 A3                    1486 	.db	00173$
      005D55                       1487 01208$:
      005D55 5F                    1488 	.db	00188$>>8
      005D56 60                    1489 	.db	00205$>>8
      005D57 63                    1490 	.db	00282$>>8
      005D58 60                    1491 	.db	00205$>>8
      005D59 64                    1492 	.db	00290$>>8
      005D5A 5E                    1493 	.db	00116$>>8
      005D5B 5D                    1494 	.db	00103$>>8
      005D5C 64                    1495 	.db	00290$>>8
      005D5D 5F                    1496 	.db	00150$>>8
      005D5E 5E                    1497 	.db	00123$>>8
      005D5F 5F                    1498 	.db	00157$>>8
      005D60 5F                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      005D61                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      005D61 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      005D64 80 08            [24] 1504 	sjmp	00112$
      005D66                       1505 01209$:
      005D66 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      005D69 80 03            [24] 1507 	sjmp	01211$
      005D6B                       1508 01210$:
      005D6B 02 5A 72         [24] 1509 	ljmp	_control_stall
      005D6E                       1510 01211$:
      005D6E                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005D6E 8E 01            [24] 1513 	mov	ar1,r6
      005D70 B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      005D73 80 09            [24] 1515 	sjmp	00301$
      005D75                       1516 01212$:
      005D75 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      005D78 80 04            [24] 1518 	sjmp	00301$
      005D7A                       1519 01213$:
                                   1520 ;	assignBit
      005D7A C2 19            [12] 1521 	clr	_control_setup_sloc2_1_0
      005D7C 80 02            [24] 1522 	sjmp	00302$
      005D7E                       1523 00301$:
                                   1524 ;	assignBit
      005D7E D2 19            [12] 1525 	setb	_control_setup_sloc2_1_0
      005D80                       1526 00302$:
      005D80 E4               [12] 1527 	clr	a
      005D81 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      005D84 04               [12] 1529 	inc	a
      005D85                       1530 01214$:
      005D85 FA               [12] 1531 	mov	r2,a
      005D86 A2 19            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      005D88 E4               [12] 1533 	clr	a
      005D89 33               [12] 1534 	rlc	a
      005D8A B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      005D8D 80 03            [24] 1536 	sjmp	00105$
      005D8F                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      005D8F 02 5A 72         [24] 1539 	ljmp	_control_stall
      005D92                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      005D92 8E 02            [24] 1542 	mov	ar2,r6
      005D94 90 07 C6         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      005D97 ED               [12] 1544 	mov	a,r5
      005D98 F0               [24] 1545 	movx	@dptr,a
      005D99 90 07 C7         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      005D9C EB               [12] 1547 	mov	a,r3
      005D9D F0               [24] 1548 	movx	@dptr,a
      005D9E EC               [12] 1549 	mov	a,r4
      005D9F A3               [24] 1550 	inc	dptr
      005DA0 F0               [24] 1551 	movx	@dptr,a
      005DA1 8A 82            [24] 1552 	mov	dpl, r2
      005DA3 12 5B 10         [24] 1553 	lcall	_descriptor_select
      005DA6 85 82 17         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      005DA9 85 83 18         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      005DAC E5 17            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      005DAE 45 18            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005DB0 70 03            [24] 1559 	jnz	00107$
      005DB2 02 5A 72         [24] 1560 	ljmp	_control_stall
      005DB5                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005DB5 90 07 62         [24] 1563 	mov	dptr,#_D0SetupLen
      005DB8 E0               [24] 1564 	movx	a,@dptr
      005DB9 F8               [12] 1565 	mov	r0,a
      005DBA A3               [24] 1566 	inc	dptr
      005DBB E0               [24] 1567 	movx	a,@dptr
      005DBC FA               [12] 1568 	mov	r2,a
      005DBD C3               [12] 1569 	clr	c
      005DBE E5 17            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      005DC0 98               [12] 1571 	subb	a,r0
      005DC1 E5 18            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005DC3 9A               [12] 1573 	subb	a,r2
      005DC4 50 06            [24] 1574 	jnc	00303$
      005DC6 E5 17            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      005DC8 54 3F            [12] 1576 	anl	a,#0x3f
      005DCA 60 04            [24] 1577 	jz	00304$
      005DCC                       1578 00303$:
                                   1579 ;	assignBit
      005DCC C2 19            [12] 1580 	clr	_control_setup_sloc2_1_0
      005DCE 80 02            [24] 1581 	sjmp	00305$
      005DD0                       1582 00304$:
                                   1583 ;	assignBit
      005DD0 D2 19            [12] 1584 	setb	_control_setup_sloc2_1_0
      005DD2                       1585 00305$:
      005DD2 90 07 C3         [24] 1586 	mov	dptr,#_control_zlp
      005DD5 A2 19            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      005DD7 E4               [12] 1588 	clr	a
      005DD8 33               [12] 1589 	rlc	a
      005DD9 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      005DDA 90 07 62         [24] 1592 	mov	dptr,#_D0SetupLen
      005DDD E0               [24] 1593 	movx	a,@dptr
      005DDE F9               [12] 1594 	mov	r1,a
      005DDF A3               [24] 1595 	inc	dptr
      005DE0 E0               [24] 1596 	movx	a,@dptr
      005DE1 FA               [12] 1597 	mov	r2,a
      005DE2 C3               [12] 1598 	clr	c
      005DE3 E5 17            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      005DE5 99               [12] 1600 	subb	a,r1
      005DE6 E5 18            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005DE8 9A               [12] 1602 	subb	a,r2
      005DE9 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      005DEB 90 07 62         [24] 1605 	mov	dptr,#_D0SetupLen
      005DEE E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      005DF0 F0               [24] 1607 	movx	@dptr,a
      005DF1 E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005DF3 A3               [24] 1609 	inc	dptr
      005DF4 F0               [24] 1610 	movx	@dptr,a
      005DF5                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005DF5 90 07 62         [24] 1613 	mov	dptr,#_D0SetupLen
      005DF8 E0               [24] 1614 	movx	a,@dptr
      005DF9 F9               [12] 1615 	mov	r1,a
      005DFA A3               [24] 1616 	inc	dptr
      005DFB E0               [24] 1617 	movx	a,@dptr
      005DFC 49               [12] 1618 	orl	a,r1
      005DFD 60 04            [24] 1619 	jz	00306$
      005DFF 7A 01            [12] 1620 	mov	r2,#0x01
      005E01 80 02            [24] 1621 	sjmp	00307$
      005E03                       1622 00306$:
      005E03 7A 02            [12] 1623 	mov	r2,#0x02
      005E05                       1624 00307$:
      005E05 90 07 C0         [24] 1625 	mov	dptr,#_control_phase
      005E08 EA               [12] 1626 	mov	a,r2
      005E09 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      005E0A 90 07 62         [24] 1629 	mov	dptr,#_D0SetupLen
      005E0D E0               [24] 1630 	movx	a,@dptr
      005E0E F9               [12] 1631 	mov	r1,a
      005E0F A3               [24] 1632 	inc	dptr
      005E10 E0               [24] 1633 	movx	a,@dptr
      005E11 49               [12] 1634 	orl	a,r1
      005E12 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      005E14 02 5A 94         [24] 1637 	ljmp	_control_next
      005E17                       1638 00111$:
      005E17 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      005E18 02 5A 72         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      005E1B                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005E1B EF               [12] 1645 	mov	a,r7
      005E1C 70 23            [24] 1646 	jnz	00118$
      005E1E 30 15 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      005E21 30 17 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      005E24 8D 01            [24] 1649 	mov	ar1,r5
      005E26 8E 02            [24] 1650 	mov	ar2,r6
      005E28 C3               [12] 1651 	clr	c
      005E29 74 7F            [12] 1652 	mov	a,#0x7f
      005E2B 99               [12] 1653 	subb	a,r1
      005E2C E4               [12] 1654 	clr	a
      005E2D 9A               [12] 1655 	subb	a,r2
      005E2E 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      005E30 90 07 62         [24] 1659 	mov	dptr,#_D0SetupLen
      005E33 ED               [12] 1660 	mov	a,r5
      005E34 F0               [24] 1661 	movx	@dptr,a
      005E35 EE               [12] 1662 	mov	a,r6
      005E36 A3               [24] 1663 	inc	dptr
      005E37 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      005E38 90 07 C0         [24] 1666 	mov	dptr,#_control_phase
      005E3B 74 03            [12] 1667 	mov	a,#0x03
      005E3D F0               [24] 1668 	movx	@dptr,a
      005E3E 02 64 21         [24] 1669 	ljmp	00291$
      005E41                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      005E41 02 5A 72         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005E44                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005E44 EF               [12] 1676 	mov	a,r7
      005E45 70 3C            [24] 1677 	jnz	00145$
      005E47 30 15 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      005E4A 30 17 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      005E4D 8D 01            [24] 1680 	mov	ar1,r5
      005E4F 8E 02            [24] 1681 	mov	ar2,r6
      005E51 C3               [12] 1682 	clr	c
      005E52 74 01            [12] 1683 	mov	a,#0x01
      005E54 99               [12] 1684 	subb	a,r1
      005E55 E4               [12] 1685 	clr	a
      005E56 9A               [12] 1686 	subb	a,r2
      005E57 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      005E59 C0 06            [24] 1690 	push	ar6
      005E5B C0 05            [24] 1691 	push	ar5
      005E5D 12 5A 1B         [24] 1692 	lcall	_endpoints_reset
      005E60 D0 05            [24] 1693 	pop	ar5
      005E62 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      005E64 90 07 67         [24] 1696 	mov	dptr,#_D0UsbConfig
      005E67 ED               [12] 1697 	mov	a,r5
      005E68 F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      005E69 A2 18            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      005E6B B3               [12] 1701 	cpl	c
      005E6C 92 19            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      005E6E 90 07 68         [24] 1703 	mov	dptr,#_USB_EnumStatus
      005E71 E4               [12] 1704 	clr	a
      005E72 33               [12] 1705 	rlc	a
      005E73 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      005E74 90 07 91         [24] 1708 	mov	dptr,#_keyboard_reset
      005E77 74 01            [12] 1709 	mov	a,#0x01
      005E79 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      005E7A 90 07 C0         [24] 1712 	mov	dptr,#_control_phase
      005E7D 74 03            [12] 1713 	mov	a,#0x03
      005E7F F0               [24] 1714 	movx	@dptr,a
      005E80 02 64 21         [24] 1715 	ljmp	00291$
      005E83                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      005E83 BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      005E86 80 03            [24] 1719 	sjmp	01232$
      005E88                       1720 01231$:
      005E88 02 5A 72         [24] 1721 	ljmp	_control_stall
      005E8B                       1722 01232$:
      005E8B 90 07 67         [24] 1723 	mov	dptr,#_D0UsbConfig
      005E8E E0               [24] 1724 	movx	a,@dptr
      005E8F 70 03            [24] 1725 	jnz	01233$
      005E91 02 5A 72         [24] 1726 	ljmp	_control_stall
      005E94                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      005E94 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      005E97 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      005E9A 8D 01            [24] 1731 	mov	ar1,r5
      005E9C 8E 02            [24] 1732 	mov	ar2,r6
      005E9E B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      005EA1 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      005EA4 90 07 62         [24] 1735 	mov	dptr,#_D0SetupLen
      005EA7 E0               [24] 1736 	movx	a,@dptr
      005EA8 F9               [12] 1737 	mov	r1,a
      005EA9 A3               [24] 1738 	inc	dptr
      005EAA E0               [24] 1739 	movx	a,@dptr
      005EAB FA               [12] 1740 	mov	r2,a
      005EAC B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      005EAF BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      005EB2 90 07 6F         [24] 1743 	mov	dptr,#_raw_state
      005EB5 E0               [24] 1744 	movx	a,@dptr
      005EB6 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      005EB8 90 07 6F         [24] 1747 	mov	dptr,#_raw_state
      005EBB 74 01            [12] 1748 	mov	a,#0x01
      005EBD F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      005EBE 90 07 C1         [24] 1751 	mov	dptr,#_output_kind
      005EC1 F0               [24] 1752 	movx	@dptr,a
      005EC2 80 52            [24] 1753 	sjmp	00136$
      005EC4                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      005EC4 EB               [12] 1756 	mov	a,r3
      005EC5 4C               [12] 1757 	orl	a,r4
      005EC6 70 20            [24] 1758 	jnz	00130$
      005EC8 8D 01            [24] 1759 	mov	ar1,r5
      005ECA 8E 02            [24] 1760 	mov	ar2,r6
      005ECC B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      005ECF BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      005ED2 90 07 62         [24] 1763 	mov	dptr,#_D0SetupLen
      005ED5 E0               [24] 1764 	movx	a,@dptr
      005ED6 F9               [12] 1765 	mov	r1,a
      005ED7 A3               [24] 1766 	inc	dptr
      005ED8 E0               [24] 1767 	movx	a,@dptr
      005ED9 FA               [12] 1768 	mov	r2,a
      005EDA B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      005EDD BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      005EE0 90 07 C1         [24] 1772 	mov	dptr,#_output_kind
      005EE3 74 02            [12] 1773 	mov	a,#0x02
      005EE5 F0               [24] 1774 	movx	@dptr,a
      005EE6 80 2E            [24] 1775 	sjmp	00136$
      005EE8                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      005EE8 BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      005EEB BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      005EEE 8D 01            [24] 1780 	mov	ar1,r5
      005EF0 8E 02            [24] 1781 	mov	ar2,r6
      005EF2 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      005EF5 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      005EF8 90 07 62         [24] 1784 	mov	dptr,#_D0SetupLen
      005EFB E0               [24] 1785 	movx	a,@dptr
      005EFC F9               [12] 1786 	mov	r1,a
      005EFD A3               [24] 1787 	inc	dptr
      005EFE E0               [24] 1788 	movx	a,@dptr
      005EFF FA               [12] 1789 	mov	r2,a
      005F00 B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      005F03 BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      005F06 90 07 C1         [24] 1793 	mov	dptr,#_output_kind
      005F09 74 03            [12] 1794 	mov	a,#0x03
      005F0B F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      005F0C 90 07 C2         [24] 1797 	mov	dptr,#_output_report_id
      005F0F 23               [12] 1798 	rl	a
      005F10 F0               [24] 1799 	movx	@dptr,a
      005F11 80 03            [24] 1800 	sjmp	00136$
      005F13                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      005F13 02 5A 72         [24] 1803 	ljmp	_control_stall
      005F16                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      005F16 90 07 C0         [24] 1806 	mov	dptr,#_control_phase
      005F19 74 04            [12] 1807 	mov	a,#0x04
      005F1B F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      005F1C 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      005F1D 02 5A 72         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      005F20                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      005F20 BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      005F23 30 15 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      005F26 30 16 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      005F29 90 07 62         [24] 1819 	mov	dptr,#_D0SetupLen
      005F2C E0               [24] 1820 	movx	a,@dptr
      005F2D F9               [12] 1821 	mov	r1,a
      005F2E A3               [24] 1822 	inc	dptr
      005F2F E0               [24] 1823 	movx	a,@dptr
      005F30 FA               [12] 1824 	mov	r2,a
      005F31 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      005F34 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      005F37 90 07 67         [24] 1828 	mov	dptr,#_D0UsbConfig
      005F3A E0               [24] 1829 	movx	a,@dptr
      005F3B 90 10 00         [24] 1830 	mov	dptr,#0x1000
      005F3E F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      005F3F 90 22 08         [24] 1833 	mov	dptr,#0x2208
      005F42 74 01            [12] 1834 	mov	a,#0x01
      005F44 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      005F45 90 07 C0         [24] 1837 	mov	dptr,#_control_phase
      005F48 04               [12] 1838 	inc	a
      005F49 F0               [24] 1839 	movx	@dptr,a
      005F4A 02 64 21         [24] 1840 	ljmp	00291$
      005F4D                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      005F4D 02 5A 72         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      005F50                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      005F50 BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      005F53 30 14 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      005F56 30 16 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      005F59 90 07 62         [24] 1850 	mov	dptr,#_D0SetupLen
      005F5C E0               [24] 1851 	movx	a,@dptr
      005F5D F9               [12] 1852 	mov	r1,a
      005F5E A3               [24] 1853 	inc	dptr
      005F5F E0               [24] 1854 	movx	a,@dptr
      005F60 FA               [12] 1855 	mov	r2,a
      005F61 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      005F64 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      005F67 90 07 67         [24] 1858 	mov	dptr,#_D0UsbConfig
      005F6A E0               [24] 1859 	movx	a,@dptr
      005F6B 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      005F6D 90 10 00         [24] 1862 	mov	dptr,#0x1000
      005F70 E4               [12] 1863 	clr	a
      005F71 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      005F72 90 22 08         [24] 1866 	mov	dptr,#0x2208
      005F75 04               [12] 1867 	inc	a
      005F76 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      005F77 90 07 C0         [24] 1870 	mov	dptr,#_control_phase
      005F7A 04               [12] 1871 	inc	a
      005F7B F0               [24] 1872 	movx	@dptr,a
      005F7C 02 64 21         [24] 1873 	ljmp	00291$
      005F7F                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      005F7F 30 14 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      005F82 90 07 67         [24] 1877 	mov	dptr,#_D0UsbConfig
      005F85 E0               [24] 1878 	movx	a,@dptr
      005F86 60 18            [24] 1879 	jz	00161$
      005F88 BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      005F8B 30 17 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      005F8E EB               [12] 1883 	mov	a,r3
      005F8F 4C               [12] 1884 	orl	a,r4
      005F90 70 05            [24] 1885 	jnz	00159$
      005F92 90 06 3F         [24] 1886 	mov	dptr,#_keyboard_idle
      005F95 EE               [12] 1887 	mov	a,r6
      005F96 F0               [24] 1888 	movx	@dptr,a
      005F97                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      005F97 90 07 C0         [24] 1891 	mov	dptr,#_control_phase
      005F9A 74 03            [12] 1892 	mov	a,#0x03
      005F9C F0               [24] 1893 	movx	@dptr,a
      005F9D 02 64 21         [24] 1894 	ljmp	00291$
      005FA0                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      005FA0 02 5A 72         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      005FA3                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      005FA3 BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      005FA6 30 14 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      005FA9 30 16 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      005FAC 30 17 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      005FAF 90 07 67         [24] 1905 	mov	dptr,#_D0UsbConfig
      005FB2 E0               [24] 1906 	movx	a,@dptr
      005FB3 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      005FB5 90 07 C0         [24] 1909 	mov	dptr,#_control_phase
      005FB8 74 03            [12] 1910 	mov	a,#0x03
      005FBA F0               [24] 1911 	movx	@dptr,a
      005FBB 02 64 21         [24] 1912 	ljmp	00291$
      005FBE                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      005FBE EB               [12] 1915 	mov	a,r3
      005FBF 4C               [12] 1916 	orl	a,r4
      005FC0 70 2C            [24] 1917 	jnz	00175$
      005FC2 90 07 67         [24] 1918 	mov	dptr,#_D0UsbConfig
      005FC5 E0               [24] 1919 	movx	a,@dptr
      005FC6 60 26            [24] 1920 	jz	00175$
      005FC8 BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      005FCB 30 17 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      005FCE 8D 01            [24] 1923 	mov	ar1,r5
      005FD0 8E 02            [24] 1924 	mov	ar2,r6
      005FD2 C3               [12] 1925 	clr	c
      005FD3 74 01            [12] 1926 	mov	a,#0x01
      005FD5 99               [12] 1927 	subb	a,r1
      005FD6 E4               [12] 1928 	clr	a
      005FD7 9A               [12] 1929 	subb	a,r2
      005FD8 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      005FDA 90 0D 82         [24] 1933 	mov	dptr,#_keyboard_protocol
      005FDD ED               [12] 1934 	mov	a,r5
      005FDE F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      005FDF 90 07 91         [24] 1937 	mov	dptr,#_keyboard_reset
      005FE2 74 01            [12] 1938 	mov	a,#0x01
      005FE4 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      005FE5 90 07 C0         [24] 1941 	mov	dptr,#_control_phase
      005FE8 74 03            [12] 1942 	mov	a,#0x03
      005FEA F0               [24] 1943 	movx	@dptr,a
      005FEB 02 64 21         [24] 1944 	ljmp	00291$
      005FEE                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      005FEE 02 5A 72         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      005FF1                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      005FF1 20 16 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      005FF4 02 5A 72         [24] 1952 	ljmp	_control_stall
      005FF7                       1953 01283$:
      005FF7 90 07 62         [24] 1954 	mov	dptr,#_D0SetupLen
      005FFA E0               [24] 1955 	movx	a,@dptr
      005FFB F9               [12] 1956 	mov	r1,a
      005FFC A3               [24] 1957 	inc	dptr
      005FFD E0               [24] 1958 	movx	a,@dptr
      005FFE FA               [12] 1959 	mov	r2,a
      005FFF B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      006002 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      006005 80 03            [24] 1962 	sjmp	01285$
      006007                       1963 01284$:
      006007 02 5A 72         [24] 1964 	ljmp	_control_stall
      00600A                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00600A E4               [12] 1967 	clr	a
      00600B BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      00600E 04               [12] 1969 	inc	a
      00600F                       1970 01286$:
      00600F FA               [12] 1971 	mov	r2,a
      006010 60 03            [24] 1972 	jz	00196$
      006012 20 15 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      006015                       1974 00196$:
      006015 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      006018 30 14 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      00601B 90 07 67         [24] 1977 	mov	dptr,#_D0UsbConfig
      00601E E0               [24] 1978 	movx	a,@dptr
      00601F 70 29            [24] 1979 	jnz	00189$
      006021                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006021 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      006024 90 07 67         [24] 1983 	mov	dptr,#_D0UsbConfig
      006027 E0               [24] 1984 	movx	a,@dptr
      006028 60 6A            [24] 1985 	jz	00190$
      00602A EB               [12] 1986 	mov	a,r3
      00602B 4C               [12] 1987 	orl	a,r4
      00602C 60 1C            [24] 1988 	jz	00189$
      00602E 8B 00            [24] 1989 	mov	ar0,r3
      006030 8C 01            [24] 1990 	mov	ar1,r4
      006032 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      006035 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      006038 80 10            [24] 1993 	sjmp	00189$
      00603A                       1994 01298$:
      00603A C3               [12] 1995 	clr	c
      00603B E8               [12] 1996 	mov	a,r0
      00603C 94 81            [12] 1997 	subb	a,#0x81
      00603E E9               [12] 1998 	mov	a,r1
      00603F 94 00            [12] 1999 	subb	a,#0x00
      006041 40 51            [24] 2000 	jc	00190$
      006043 74 83            [12] 2001 	mov	a,#0x83
      006045 98               [12] 2002 	subb	a,r0
      006046 E4               [12] 2003 	clr	a
      006047 99               [12] 2004 	subb	a,r1
      006048 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      00604A                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      00604A 8B 01            [24] 2009 	mov	ar1,r3
      00604C 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      00604F EA               [12] 2012 	mov	a,r2
      006050 60 0B            [24] 2013 	jz	00308$
      006052 90 07 69         [24] 2014 	mov	dptr,#_USB_SleepStatus
      006055 E0               [24] 2015 	movx	a,@dptr
      006056 54 01            [12] 2016 	anl	a,#0x01
      006058 25 E0            [12] 2017 	add	a,acc
      00605A FA               [12] 2018 	mov	r2,a
      00605B 80 22            [24] 2019 	sjmp	00309$
      00605D                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      00605D BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      006060 E9               [12] 2023 	mov	a,r1
      006061 60 18            [24] 2024 	jz	00310$
      006063 89 00            [24] 2025 	mov	ar0,r1
      006065 79 00            [12] 2026 	mov	r1,#0x00
      006067 74 22            [12] 2027 	mov	a,#0x22
      006069 29               [12] 2028 	add	a, r1
      00606A F9               [12] 2029 	mov	r1,a
      00606B 88 82            [24] 2030 	mov	dpl,r0
      00606D 89 83            [24] 2031 	mov	dph,r1
      00606F E0               [24] 2032 	movx	a,@dptr
      006070 F9               [12] 2033 	mov	r1,a
      006071 53 01 03         [24] 2034 	anl	ar1,#0x03
      006074 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      006077 79 01            [12] 2036 	mov	r1,#0x01
      006079 80 02            [24] 2037 	sjmp	00311$
      00607B                       2038 00310$:
      00607B 79 00            [12] 2039 	mov	r1,#0x00
      00607D                       2040 00311$:
      00607D 89 02            [24] 2041 	mov	ar2,r1
      00607F                       2042 00309$:
      00607F 90 10 00         [24] 2043 	mov	dptr,#0x1000
      006082 EA               [12] 2044 	mov	a,r2
      006083 F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      006084 A3               [24] 2047 	inc	dptr
      006085 E4               [12] 2048 	clr	a
      006086 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      006087 90 22 08         [24] 2051 	mov	dptr,#0x2208
      00608A 74 02            [12] 2052 	mov	a,#0x02
      00608C F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      00608D 90 07 C0         [24] 2055 	mov	dptr,#_control_phase
      006090 F0               [24] 2056 	movx	@dptr,a
      006091 02 64 21         [24] 2057 	ljmp	00291$
      006094                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006094 02 5A 72         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006097                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      006097 20 17 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      00609A 02 61 2A         [24] 2065 	ljmp	00279$
      00609D                       2066 01307$:
      00609D 90 07 67         [24] 2067 	mov	dptr,#_D0UsbConfig
      0060A0 E0               [24] 2068 	movx	a,@dptr
      0060A1 70 03            [24] 2069 	jnz	01308$
      0060A3 02 61 2A         [24] 2070 	ljmp	00279$
      0060A6                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      0060A6 EF               [12] 2073 	mov	a,r7
      0060A7 70 29            [24] 2074 	jnz	00218$
      0060A9 8D 01            [24] 2075 	mov	ar1,r5
      0060AB 8E 02            [24] 2076 	mov	ar2,r6
      0060AD B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      0060B0 BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      0060B3 30 15 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0060B6 90 07 61         [24] 2081 	mov	dptr,#_D0SetupReqCode
      0060B9 E0               [24] 2082 	movx	a,@dptr
      0060BA FA               [12] 2083 	mov	r2,a
      0060BB BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      0060BE 90 07 69         [24] 2085 	mov	dptr,#_USB_SleepStatus
      0060C1 E0               [24] 2086 	movx	a,@dptr
      0060C2 43 E0 01         [24] 2087 	orl	acc,#0x01
      0060C5 F0               [24] 2088 	movx	@dptr,a
      0060C6 80 59            [24] 2089 	sjmp	00219$
      0060C8                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      0060C8 90 07 69         [24] 2092 	mov	dptr,#_USB_SleepStatus
      0060CB E0               [24] 2093 	movx	a,@dptr
      0060CC 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      0060CF F0               [24] 2095 	movx	@dptr,a
      0060D0 80 4F            [24] 2096 	sjmp	00219$
      0060D2                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0060D2 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      0060D5 30 16 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      0060D8 8B 01            [24] 2101 	mov	ar1,r3
      0060DA 8C 02            [24] 2102 	mov	ar2,r4
      0060DC C3               [12] 2103 	clr	c
      0060DD E9               [12] 2104 	mov	a,r1
      0060DE 94 81            [12] 2105 	subb	a,#0x81
      0060E0 EA               [12] 2106 	mov	a,r2
      0060E1 94 00            [12] 2107 	subb	a,#0x00
      0060E3 40 39            [24] 2108 	jc	00212$
      0060E5 74 83            [12] 2109 	mov	a,#0x83
      0060E7 99               [12] 2110 	subb	a,r1
      0060E8 E4               [12] 2111 	clr	a
      0060E9 9A               [12] 2112 	subb	a,r2
      0060EA 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      0060EC 8B 02            [24] 2116 	mov	ar2,r3
      0060EE 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0060F1 8A 00            [24] 2119 	mov	ar0,r2
      0060F3 79 00            [12] 2120 	mov	r1,#0x00
      0060F5 74 22            [12] 2121 	mov	a,#0x22
      0060F7 29               [12] 2122 	add	a, r1
      0060F8 F9               [12] 2123 	mov	r1,a
      0060F9 88 17            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      0060FB 89 18            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0060FD 90 07 61         [24] 2126 	mov	dptr,#_D0SetupReqCode
      006100 E0               [24] 2127 	movx	a,@dptr
      006101 F9               [12] 2128 	mov	r1,a
      006102 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006105 79 03            [12] 2130 	mov	r1,#0x03
      006107 80 02            [24] 2131 	sjmp	00319$
      006109                       2132 00318$:
      006109 79 02            [12] 2133 	mov	r1,#0x02
      00610B                       2134 00319$:
      00610B 43 01 10         [24] 2135 	orl	ar1,#0x10
      00610E 85 17 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      006111 85 18 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006114 E9               [12] 2138 	mov	a,r1
      006115 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006116 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      006119 12 59 FE         [24] 2142 	lcall	_raw_complete
      00611C 80 03            [24] 2143 	sjmp	00219$
      00611E                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      00611E 02 5A 72         [24] 2146 	ljmp	_control_stall
      006121                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006121 90 07 C0         [24] 2149 	mov	dptr,#_control_phase
      006124 74 03            [12] 2150 	mov	a,#0x03
      006126 F0               [24] 2151 	movx	@dptr,a
      006127 02 64 21         [24] 2152 	ljmp	00291$
      00612A                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00612A E4               [12] 2155 	clr	a
      00612B BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      00612E 04               [12] 2157 	inc	a
      00612F                       2158 01324$:
      00612F FA               [12] 2159 	mov	r2,a
      006130 70 03            [24] 2160 	jnz	01326$
      006132 02 63 9C         [24] 2161 	ljmp	00273$
      006135                       2162 01326$:
      006135 90 07 61         [24] 2163 	mov	dptr,#_D0SetupReqCode
      006138 E0               [24] 2164 	movx	a,@dptr
      006139 F9               [12] 2165 	mov	r1,a
      00613A B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      00613D 80 03            [24] 2167 	sjmp	01328$
      00613F                       2168 01327$:
      00613F 02 63 9C         [24] 2169 	ljmp	00273$
      006142                       2170 01328$:
      006142 90 07 67         [24] 2171 	mov	dptr,#_D0UsbConfig
      006145 E0               [24] 2172 	movx	a,@dptr
      006146 70 03            [24] 2173 	jnz	01329$
      006148 02 63 9C         [24] 2174 	ljmp	00273$
      00614B                       2175 01329$:
      00614B 90 07 62         [24] 2176 	mov	dptr,#_D0SetupLen
      00614E E0               [24] 2177 	movx	a,@dptr
      00614F F8               [12] 2178 	mov	r0,a
      006150 A3               [24] 2179 	inc	dptr
      006151 E0               [24] 2180 	movx	a,@dptr
      006152 48               [12] 2181 	orl	a,r0
      006153 70 03            [24] 2182 	jnz	01330$
      006155 02 63 9C         [24] 2183 	ljmp	00273$
      006158                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      006158 C0 03            [24] 2186 	push	ar3
      00615A C0 04            [24] 2187 	push	ar4
      00615C 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      00615E 8E 00            [24] 2190 	mov	ar0,r6
      006160 B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      006163 E8               [12] 2192 	mov	a,r0
      006164 80 01            [24] 2193 	sjmp	01332$
      006166                       2194 01331$:
      006166 E4               [12] 2195 	clr	a
      006167                       2196 01332$:
      006167 F5 17            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      006169 D0 04            [24] 2198 	pop	ar4
      00616B D0 03            [24] 2199 	pop	ar3
      00616D E5 17            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      00616F 60 17            [24] 2201 	jz	00251$
      006171 EB               [12] 2202 	mov	a,r3
      006172 4C               [12] 2203 	orl	a,r4
      006173 70 13            [24] 2204 	jnz	00251$
      006175 E9               [12] 2205 	mov	a,r1
      006176 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      006178 90 07 CA         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      00617B 74 08            [12] 2209 	mov	a,#0x08
      00617D F0               [24] 2210 	movx	@dptr,a
      00617E E4               [12] 2211 	clr	a
      00617F A3               [24] 2212 	inc	dptr
      006180 F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006181 90 07 CC         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      006184 F0               [24] 2216 	movx	@dptr,a
      006185 02 63 0C         [24] 2217 	ljmp	00252$
      006188                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006188 E5 17            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      00618A 60 27            [24] 2221 	jz	00245$
      00618C BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      00618F BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006192 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      006195                       2226 01339$:
      006195 50 1C            [24] 2227 	jnc	00245$
      006197 E9               [12] 2228 	mov	a,r1
      006198 90 B7 42         [24] 2229 	mov	dptr,#_shared_lengths
      00619B 93               [24] 2230 	movc	a,@a+dptr
      00619C F8               [12] 2231 	mov	r0,a
      00619D 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      00619F 90 07 CA         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      0061A2 E8               [12] 2235 	mov	a,r0
      0061A3 F0               [24] 2236 	movx	@dptr,a
      0061A4 E4               [12] 2237 	clr	a
      0061A5 A3               [24] 2238 	inc	dptr
      0061A6 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      0061A7 E9               [12] 2241 	mov	a,r1
      0061A8 90 B7 3B         [24] 2242 	mov	dptr,#_shared_offsets
      0061AB 93               [24] 2243 	movc	a,@a+dptr
      0061AC 90 07 CC         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      0061AF F0               [24] 2245 	movx	@dptr,a
      0061B0 02 63 0C         [24] 2246 	ljmp	00252$
      0061B3                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0061B3 E5 17            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      0061B5 60 7A            [24] 2250 	jz	00240$
      0061B7 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      0061BA BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      0061BD E9               [12] 2253 	mov	a,r1
      0061BE 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0061C0 90 07 62         [24] 2256 	mov	dptr,#_D0SetupLen
      0061C3 E0               [24] 2257 	movx	a,@dptr
      0061C4 F8               [12] 2258 	mov	r0,a
      0061C5 A3               [24] 2259 	inc	dptr
      0061C6 E0               [24] 2260 	movx	a,@dptr
      0061C7 F9               [12] 2261 	mov	r1,a
      0061C8 C3               [12] 2262 	clr	c
      0061C9 E8               [12] 2263 	mov	a,r0
      0061CA 94 20            [12] 2264 	subb	a,#0x20
      0061CC E9               [12] 2265 	mov	a,r1
      0061CD 94 00            [12] 2266 	subb	a,#0x00
      0061CF 50 0A            [24] 2267 	jnc	00320$
      0061D1 90 07 62         [24] 2268 	mov	dptr,#_D0SetupLen
      0061D4 E0               [24] 2269 	movx	a,@dptr
      0061D5 F8               [12] 2270 	mov	r0,a
      0061D6 A3               [24] 2271 	inc	dptr
      0061D7 E0               [24] 2272 	movx	a,@dptr
      0061D8 F9               [12] 2273 	mov	r1,a
      0061D9 80 04            [24] 2274 	sjmp	00321$
      0061DB                       2275 00320$:
      0061DB 78 20            [12] 2276 	mov	r0,#0x20
      0061DD 79 00            [12] 2277 	mov	r1,#0x00
      0061DF                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0061DF 75 17 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      0061E2                       2281 00293$:
      0061E2 C0 03            [24] 2282 	push	ar3
      0061E4 C0 04            [24] 2283 	push	ar4
      0061E6 AB 17            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      0061E8 7C 00            [12] 2285 	mov	r4,#0x00
      0061EA C3               [12] 2286 	clr	c
      0061EB EB               [12] 2287 	mov	a,r3
      0061EC 98               [12] 2288 	subb	a,r0
      0061ED EC               [12] 2289 	mov	a,r4
      0061EE 99               [12] 2290 	subb	a,r1
      0061EF D0 04            [24] 2291 	pop	ar4
      0061F1 D0 03            [24] 2292 	pop	ar3
      0061F3 50 32            [24] 2293 	jnc	00222$
      0061F5 C0 00            [24] 2294 	push	ar0
      0061F7 C0 01            [24] 2295 	push	ar1
      0061F9 85 17 19         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0061FC 74 10            [12] 2297 	mov	a,#0x10
      0061FE 24 00            [12] 2298 	add	a, #0x00
      006200 F5 1A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      006202 A8 17            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      006204 79 00            [12] 2301 	mov	r1,#0x00
      006206 74 C0            [12] 2302 	mov	a,#0xc0
      006208 28               [12] 2303 	add	a, r0
      006209 F8               [12] 2304 	mov	r0,a
      00620A E4               [12] 2305 	clr	a
      00620B 39               [12] 2306 	addc	a, r1
      00620C F9               [12] 2307 	mov	r1,a
      00620D 88 82            [24] 2308 	mov	dpl,r0
      00620F 74 10            [12] 2309 	mov	a,#0x10
      006211 29               [12] 2310 	add	a, r1
      006212 F5 83            [12] 2311 	mov	dph,a
      006214 E0               [24] 2312 	movx	a,@dptr
      006215 85 19 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      006218 85 1A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      00621B F0               [24] 2315 	movx	@dptr,a
      00621C E5 17            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      00621E 04               [12] 2317 	inc	a
      00621F F5 17            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      006221 D0 01            [24] 2319 	pop	ar1
      006223 D0 00            [24] 2320 	pop	ar0
      006225 80 BB            [24] 2321 	sjmp	00293$
      006227                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      006227 90 07 CA         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      00622A E4               [12] 2325 	clr	a
      00622B F0               [24] 2326 	movx	@dptr,a
      00622C A3               [24] 2327 	inc	dptr
      00622D F0               [24] 2328 	movx	@dptr,a
      00622E 02 63 0C         [24] 2329 	ljmp	00252$
      006231                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006231 8D 00            [24] 2332 	mov	ar0,r5
      006233 8E 01            [24] 2333 	mov	ar1,r6
      006235 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      006238 B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      00623B EB               [12] 2336 	mov	a,r3
      00623C 4C               [12] 2337 	orl	a,r4
      00623D 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      00623F 90 07 6C         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      006242 E0               [24] 2341 	movx	a,@dptr
      006243 90 10 00         [24] 2342 	mov	dptr,#0x1000
      006246 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      006247 90 07 CA         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      00624A E4               [12] 2346 	clr	a
      00624B F0               [24] 2347 	movx	@dptr,a
      00624C A3               [24] 2348 	inc	dptr
      00624D F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      00624E 90 07 62         [24] 2351 	mov	dptr,#_D0SetupLen
      006251 04               [12] 2352 	inc	a
      006252 F0               [24] 2353 	movx	@dptr,a
      006253 E4               [12] 2354 	clr	a
      006254 A3               [24] 2355 	inc	dptr
      006255 F0               [24] 2356 	movx	@dptr,a
      006256 02 63 0C         [24] 2357 	ljmp	00252$
      006259                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006259 B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      00625C B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      00625F BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      006262 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006265 C0 03            [24] 2365 	push	ar3
      006267 C0 04            [24] 2366 	push	ar4
      006269 90 10 00         [24] 2367 	mov	dptr,#0x1000
      00626C 74 06            [12] 2368 	mov	a,#0x06
      00626E F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      00626F 90 07 6C         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      006272 E0               [24] 2372 	movx	a,@dptr
      006273 90 10 01         [24] 2373 	mov	dptr,#0x1001
      006276 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      006277 90 07 CA         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      00627A E4               [12] 2377 	clr	a
      00627B F0               [24] 2378 	movx	@dptr,a
      00627C A3               [24] 2379 	inc	dptr
      00627D F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      00627E 90 07 62         [24] 2382 	mov	dptr,#_D0SetupLen
      006281 E0               [24] 2383 	movx	a,@dptr
      006282 FB               [12] 2384 	mov	r3,a
      006283 A3               [24] 2385 	inc	dptr
      006284 E0               [24] 2386 	movx	a,@dptr
      006285 FC               [12] 2387 	mov	r4,a
      006286 C3               [12] 2388 	clr	c
      006287 74 02            [12] 2389 	mov	a,#0x02
      006289 9B               [12] 2390 	subb	a,r3
      00628A E4               [12] 2391 	clr	a
      00628B 9C               [12] 2392 	subb	a,r4
      00628C D0 04            [24] 2393 	pop	ar4
      00628E D0 03            [24] 2394 	pop	ar3
      006290 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      006292 90 07 62         [24] 2397 	mov	dptr,#_D0SetupLen
      006295 74 02            [12] 2398 	mov	a,#0x02
      006297 F0               [24] 2399 	movx	@dptr,a
      006298 E4               [12] 2400 	clr	a
      006299 A3               [24] 2401 	inc	dptr
      00629A F0               [24] 2402 	movx	@dptr,a
      00629B 80 6F            [24] 2403 	sjmp	00252$
      00629D                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00629D B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      0062A0 B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      0062A3 BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      0062A6 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      0062A9 90 10 00         [24] 2411 	mov	dptr,#0x1000
      0062AC 74 41            [12] 2412 	mov	a,#0x41
      0062AE F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      0062AF A3               [24] 2415 	inc	dptr
      0062B0 74 4B            [12] 2416 	mov	a,#0x4b
      0062B2 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      0062B3 A3               [24] 2419 	inc	dptr
      0062B4 74 42            [12] 2420 	mov	a,#0x42
      0062B6 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      0062B7 A3               [24] 2423 	inc	dptr
      0062B8 74 54            [12] 2424 	mov	a,#0x54
      0062BA F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      0062BB A3               [24] 2427 	inc	dptr
      0062BC 74 01            [12] 2428 	mov	a,#0x01
      0062BE F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      0062BF 90 07 6D         [24] 2431 	mov	dptr,#_ak820_boot_stage
      0062C2 E0               [24] 2432 	movx	a,@dptr
      0062C3 90 10 05         [24] 2433 	mov	dptr,#0x1005
      0062C6 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0062C7 90 07 6E         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      0062CA E0               [24] 2437 	movx	a,@dptr
      0062CB 90 10 06         [24] 2438 	mov	dptr,#0x1006
      0062CE F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0062CF 90 07 68         [24] 2441 	mov	dptr,#_USB_EnumStatus
      0062D2 E0               [24] 2442 	movx	a,@dptr
      0062D3 60 02            [24] 2443 	jz	00322$
      0062D5 74 01            [12] 2444 	mov	a,#0x01
      0062D7                       2445 00322$:
      0062D7 F9               [12] 2446 	mov	r1,a
      0062D8 90 07 69         [24] 2447 	mov	dptr,#_USB_SleepStatus
      0062DB E0               [24] 2448 	movx	a,@dptr
      0062DC 54 02            [12] 2449 	anl	a,#0x02
      0062DE F8               [12] 2450 	mov	r0,a
      0062DF E9               [12] 2451 	mov	a,r1
      0062E0 42 00            [12] 2452 	orl	ar0,a
      0062E2 90 10 07         [24] 2453 	mov	dptr,#0x1007
      0062E5 E8               [12] 2454 	mov	a,r0
      0062E6 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      0062E7 90 07 CA         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      0062EA E4               [12] 2458 	clr	a
      0062EB F0               [24] 2459 	movx	@dptr,a
      0062EC A3               [24] 2460 	inc	dptr
      0062ED F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      0062EE 90 07 62         [24] 2463 	mov	dptr,#_D0SetupLen
      0062F1 E0               [24] 2464 	movx	a,@dptr
      0062F2 F8               [12] 2465 	mov	r0,a
      0062F3 A3               [24] 2466 	inc	dptr
      0062F4 E0               [24] 2467 	movx	a,@dptr
      0062F5 F9               [12] 2468 	mov	r1,a
      0062F6 C3               [12] 2469 	clr	c
      0062F7 74 08            [12] 2470 	mov	a,#0x08
      0062F9 98               [12] 2471 	subb	a,r0
      0062FA E4               [12] 2472 	clr	a
      0062FB 99               [12] 2473 	subb	a,r1
      0062FC 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      0062FE 90 07 62         [24] 2476 	mov	dptr,#_D0SetupLen
      006301 74 08            [12] 2477 	mov	a,#0x08
      006303 F0               [24] 2478 	movx	@dptr,a
      006304 E4               [12] 2479 	clr	a
      006305 A3               [24] 2480 	inc	dptr
      006306 F0               [24] 2481 	movx	@dptr,a
      006307 80 03            [24] 2482 	sjmp	00252$
      006309                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006309 02 5A 72         [24] 2485 	ljmp	_control_stall
      00630C                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      00630C 90 07 CA         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      00630F E0               [24] 2489 	movx	a,@dptr
      006310 F5 19            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      006312 A3               [24] 2491 	inc	dptr
      006313 E0               [24] 2492 	movx	a,@dptr
      006314 F5 1A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      006316 E5 19            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      006318 45 1A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      00631A 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      00631C 90 07 62         [24] 2498 	mov	dptr,#_D0SetupLen
      00631F E0               [24] 2499 	movx	a,@dptr
      006320 F8               [12] 2500 	mov	r0,a
      006321 A3               [24] 2501 	inc	dptr
      006322 E0               [24] 2502 	movx	a,@dptr
      006323 F9               [12] 2503 	mov	r1,a
      006324 C3               [12] 2504 	clr	c
      006325 E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      006327 98               [12] 2506 	subb	a,r0
      006328 E5 1A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00632A 99               [12] 2508 	subb	a,r1
      00632B 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      00632D 90 07 62         [24] 2511 	mov	dptr,#_D0SetupLen
      006330 E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      006332 F0               [24] 2513 	movx	@dptr,a
      006333 E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006335 A3               [24] 2515 	inc	dptr
      006336 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006337                       2518 00559$:
      006337 75 19 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      00633A                       2520 00296$:
      00633A 90 07 62         [24] 2521 	mov	dptr,#_D0SetupLen
      00633D E0               [24] 2522 	movx	a,@dptr
      00633E F8               [12] 2523 	mov	r0,a
      00633F C3               [12] 2524 	clr	c
      006340 E5 19            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      006342 98               [12] 2526 	subb	a,r0
      006343 50 46            [24] 2527 	jnc	00263$
      006345 85 19 17         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006348 74 10            [12] 2529 	mov	a,#0x10
      00634A 24 00            [12] 2530 	add	a, #0x00
      00634C F5 18            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      00634E 90 07 CC         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      006351 E0               [24] 2533 	movx	a,@dptr
      006352 25 19            [12] 2534 	add	a, _control_setup_sloc4_1_0
      006354 24 92            [12] 2535 	add	a, #_input_snapshot
      006356 F5 82            [12] 2536 	mov	dpl,a
      006358 E4               [12] 2537 	clr	a
      006359 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      00635B F5 83            [12] 2539 	mov	dph,a
      00635D E0               [24] 2540 	movx	a,@dptr
      00635E 85 17 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      006361 85 18 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006364 F0               [24] 2543 	movx	@dptr,a
      006365 E5 19            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      006367 04               [12] 2545 	inc	a
      006368 F5 19            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      00636A 80 CE            [24] 2547 	sjmp	00296$
      00636C                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      00636C BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      00636F BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      006372 90 07 62         [24] 2552 	mov	dptr,#_D0SetupLen
      006375 E0               [24] 2553 	movx	a,@dptr
      006376 F8               [12] 2554 	mov	r0,a
      006377 A3               [24] 2555 	inc	dptr
      006378 E0               [24] 2556 	movx	a,@dptr
      006379 F9               [12] 2557 	mov	r1,a
      00637A C3               [12] 2558 	clr	c
      00637B 74 20            [12] 2559 	mov	a,#0x20
      00637D 98               [12] 2560 	subb	a,r0
      00637E E4               [12] 2561 	clr	a
      00637F 99               [12] 2562 	subb	a,r1
      006380 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      006382 90 07 62         [24] 2565 	mov	dptr,#_D0SetupLen
      006385 74 20            [12] 2566 	mov	a,#0x20
      006387 F0               [24] 2567 	movx	@dptr,a
      006388 E4               [12] 2568 	clr	a
      006389 A3               [24] 2569 	inc	dptr
      00638A F0               [24] 2570 	movx	@dptr,a
      00638B                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      00638B 90 07 62         [24] 2573 	mov	dptr,#_D0SetupLen
      00638E E0               [24] 2574 	movx	a,@dptr
      00638F 90 22 08         [24] 2575 	mov	dptr,#0x2208
      006392 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006393 90 07 C0         [24] 2578 	mov	dptr,#_control_phase
      006396 74 02            [12] 2579 	mov	a,#0x02
      006398 F0               [24] 2580 	movx	@dptr,a
      006399 02 64 21         [24] 2581 	ljmp	00291$
      00639C                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      00639C EB               [12] 2584 	mov	a,r3
      00639D 4C               [12] 2585 	orl	a,r4
      00639E 70 37            [24] 2586 	jnz	00265$
      0063A0 90 07 67         [24] 2587 	mov	dptr,#_D0UsbConfig
      0063A3 E0               [24] 2588 	movx	a,@dptr
      0063A4 60 31            [24] 2589 	jz	00265$
      0063A6 EA               [12] 2590 	mov	a,r2
      0063A7 60 2E            [24] 2591 	jz	00265$
      0063A9 90 07 61         [24] 2592 	mov	dptr,#_D0SetupReqCode
      0063AC E0               [24] 2593 	movx	a,@dptr
      0063AD FA               [12] 2594 	mov	r2,a
      0063AE BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      0063B1 30 16 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      0063B4 90 07 62         [24] 2597 	mov	dptr,#_D0SetupLen
      0063B7 E0               [24] 2598 	movx	a,@dptr
      0063B8 F9               [12] 2599 	mov	r1,a
      0063B9 A3               [24] 2600 	inc	dptr
      0063BA E0               [24] 2601 	movx	a,@dptr
      0063BB FA               [12] 2602 	mov	r2,a
      0063BC B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      0063BF BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      0063C2 90 0D 82         [24] 2606 	mov	dptr,#_keyboard_protocol
      0063C5 E0               [24] 2607 	movx	a,@dptr
      0063C6 90 10 00         [24] 2608 	mov	dptr,#0x1000
      0063C9 F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      0063CA 90 22 08         [24] 2611 	mov	dptr,#0x2208
      0063CD 74 01            [12] 2612 	mov	a,#0x01
      0063CF F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      0063D0 90 07 C0         [24] 2615 	mov	dptr,#_control_phase
      0063D3 04               [12] 2616 	inc	a
      0063D4 F0               [24] 2617 	movx	@dptr,a
      0063D5 80 4A            [24] 2618 	sjmp	00291$
      0063D7                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      0063D7 02 5A 72         [24] 2622 	ljmp	_control_stall
      0063DA                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0063DA 30 14 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      0063DD 90 07 67         [24] 2626 	mov	dptr,#_D0UsbConfig
      0063E0 E0               [24] 2627 	movx	a,@dptr
      0063E1 60 38            [24] 2628 	jz	00284$
      0063E3 BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      0063E6 8E 05            [24] 2630 	mov	ar5,r6
      0063E8 7E 00            [12] 2631 	mov	r6,#0x00
      0063EA ED               [12] 2632 	mov	a,r5
      0063EB 4E               [12] 2633 	orl	a,r6
      0063EC 70 2D            [24] 2634 	jnz	00284$
      0063EE 90 07 62         [24] 2635 	mov	dptr,#_D0SetupLen
      0063F1 E0               [24] 2636 	movx	a,@dptr
      0063F2 FE               [12] 2637 	mov	r6,a
      0063F3 A3               [24] 2638 	inc	dptr
      0063F4 E0               [24] 2639 	movx	a,@dptr
      0063F5 FF               [12] 2640 	mov	r7,a
      0063F6 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      0063F9 BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0063FC EB               [12] 2644 	mov	a,r3
      0063FD 4C               [12] 2645 	orl	a,r4
      0063FE 70 07            [24] 2646 	jnz	00324$
      006400 90 06 3F         [24] 2647 	mov	dptr,#_keyboard_idle
      006403 E0               [24] 2648 	movx	a,@dptr
      006404 FF               [12] 2649 	mov	r7,a
      006405 80 02            [24] 2650 	sjmp	00325$
      006407                       2651 00324$:
      006407 7F 00            [12] 2652 	mov	r7,#0x00
      006409                       2653 00325$:
      006409 90 10 00         [24] 2654 	mov	dptr,#0x1000
      00640C EF               [12] 2655 	mov	a,r7
      00640D F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      00640E 90 22 08         [24] 2658 	mov	dptr,#0x2208
      006411 74 01            [12] 2659 	mov	a,#0x01
      006413 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006414 90 07 C0         [24] 2662 	mov	dptr,#_control_phase
      006417 04               [12] 2663 	inc	a
      006418 F0               [24] 2664 	movx	@dptr,a
      006419 80 06            [24] 2665 	sjmp	00291$
      00641B                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      00641B 02 5A 72         [24] 2669 	ljmp	_control_stall
      00641E                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      00641E 02 5A 72         [24] 2672 	ljmp	_control_stall
      006421                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006421 90 22 00         [24] 2675 	mov	dptr,#0x2200
      006424 74 C0            [12] 2676 	mov	a,#0xc0
      006426 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006427 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      006428                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006428 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      00642B E0               [24] 2692 	movx	a,@dptr
      00642C 20 E6 01         [24] 2693 	jb	acc.6,00102$
      00642F 22               [24] 2694 	ret
      006430                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006430 90 07 C0         [24] 2697 	mov	dptr,#_control_phase
      006433 E0               [24] 2698 	movx	a,@dptr
      006434 FF               [12] 2699 	mov	r7,a
      006435 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      006438 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      00643B E0               [24] 2702 	movx	a,@dptr
      00643C 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      00643E 90 07 C0         [24] 2705 	mov	dptr,#_control_phase
      006441 E4               [12] 2706 	clr	a
      006442 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006443 90 22 00         [24] 2709 	mov	dptr,#0x2200
      006446 74 02            [12] 2710 	mov	a,#0x02
      006448 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006449 22               [24] 2713 	ret
      00644A                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      00644A BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      00644D 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      006450 E0               [24] 2718 	movx	a,@dptr
      006451 FF               [12] 2719 	mov	r7,a
      006452 90 07 62         [24] 2720 	mov	dptr,#_D0SetupLen
      006455 E0               [24] 2721 	movx	a,@dptr
      006456 FD               [12] 2722 	mov	r5,a
      006457 A3               [24] 2723 	inc	dptr
      006458 E0               [24] 2724 	movx	a,@dptr
      006459 FE               [12] 2725 	mov	r6,a
      00645A 7C 00            [12] 2726 	mov	r4,#0x00
      00645C EF               [12] 2727 	mov	a,r7
      00645D B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      006460 EC               [12] 2729 	mov	a,r4
      006461 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      006464 80 03            [24] 2731 	sjmp	00107$
      006466                       2732 00209$:
      006466                       2733 00106$:
      006466 02 5A 72         [24] 2734 	ljmp	_control_stall
      006469                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006469 90 07 C1         [24] 2737 	mov	dptr,#_output_kind
      00646C E0               [24] 2738 	movx	a,@dptr
      00646D FF               [12] 2739 	mov	r7,a
      00646E BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      006471 90 07 6F         [24] 2741 	mov	dptr,#_raw_state
      006474 E0               [24] 2742 	movx	a,@dptr
      006475 FE               [12] 2743 	mov	r6,a
      006476 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006479 7E 00            [12] 2746 	mov	r6,#0x00
      00647B                       2747 00121$:
      00647B EE               [12] 2748 	mov	a,r6
      00647C 24 70            [12] 2749 	add	a, #_raw_buffer
      00647E FC               [12] 2750 	mov	r4,a
      00647F E4               [12] 2751 	clr	a
      006480 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      006482 FD               [12] 2753 	mov	r5,a
      006483 8E 82            [24] 2754 	mov	dpl,r6
      006485 74 10            [12] 2755 	mov	a,#0x10
      006487 24 00            [12] 2756 	add	a, #0x00
      006489 F5 83            [12] 2757 	mov	dph,a
      00648B E0               [24] 2758 	movx	a,@dptr
      00648C 8C 82            [24] 2759 	mov	dpl,r4
      00648E 8D 83            [24] 2760 	mov	dph,r5
      006490 F0               [24] 2761 	movx	@dptr,a
      006491 0E               [12] 2762 	inc	r6
      006492 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      006495                       2764 00214$:
      006495 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006497 90 07 6F         [24] 2767 	mov	dptr,#_raw_state
      00649A 74 02            [12] 2768 	mov	a,#0x02
      00649C F0               [24] 2769 	movx	@dptr,a
      00649D 80 2B            [24] 2770 	sjmp	00119$
      00649F                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      00649F BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      0064A2 90 10 00         [24] 2775 	mov	dptr,#0x1000
      0064A5 E0               [24] 2776 	movx	a,@dptr
      0064A6 90 07 6C         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      0064A9 F0               [24] 2778 	movx	@dptr,a
      0064AA 80 1E            [24] 2779 	sjmp	00119$
      0064AC                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0064AC BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      0064AF 90 10 00         [24] 2783 	mov	dptr,#0x1000
      0064B2 E0               [24] 2784 	movx	a,@dptr
      0064B3 FF               [12] 2785 	mov	r7,a
      0064B4 90 07 C2         [24] 2786 	mov	dptr,#_output_report_id
      0064B7 E0               [24] 2787 	movx	a,@dptr
      0064B8 FE               [12] 2788 	mov	r6,a
      0064B9 EF               [12] 2789 	mov	a,r7
      0064BA B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      0064BD 90 10 01         [24] 2792 	mov	dptr,#0x1001
      0064C0 E0               [24] 2793 	movx	a,@dptr
      0064C1 90 07 6C         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      0064C4 F0               [24] 2795 	movx	@dptr,a
      0064C5 80 03            [24] 2796 	sjmp	00119$
      0064C7                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      0064C7 02 5A 72         [24] 2799 	ljmp	_control_stall
      0064CA                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      0064CA 90 07 C1         [24] 2802 	mov	dptr,#_output_kind
      0064CD E4               [12] 2803 	clr	a
      0064CE F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      0064CF 90 07 62         [24] 2806 	mov	dptr,#_D0SetupLen
      0064D2 F0               [24] 2807 	movx	@dptr,a
      0064D3 A3               [24] 2808 	inc	dptr
      0064D4 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      0064D5 90 07 C0         [24] 2811 	mov	dptr,#_control_phase
      0064D8 74 03            [12] 2812 	mov	a,#0x03
      0064DA F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      0064DB 90 22 08         [24] 2815 	mov	dptr,#0x2208
      0064DE E4               [12] 2816 	clr	a
      0064DF F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      0064E0 F5 82            [12] 2819 	mov	dpl,a
      0064E2 74 48            [12] 2820 	mov	a,#0x48
      0064E4 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      0064E5 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      0064E6                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      0064E6 90 07 C0         [24] 2833 	mov	dptr,#_control_phase
      0064E9 E0               [24] 2834 	movx	a,@dptr
      0064EA FF               [12] 2835 	mov	r7,a
      0064EB BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      0064EE 90 07 62         [24] 2838 	mov	dptr,#_D0SetupLen
      0064F1 E0               [24] 2839 	movx	a,@dptr
      0064F2 FD               [12] 2840 	mov	r5,a
      0064F3 A3               [24] 2841 	inc	dptr
      0064F4 E0               [24] 2842 	movx	a,@dptr
      0064F5 4D               [12] 2843 	orl	a,r5
      0064F6 70 06            [24] 2844 	jnz	00101$
      0064F8 90 07 C3         [24] 2845 	mov	dptr,#_control_zlp
      0064FB E0               [24] 2846 	movx	a,@dptr
      0064FC 60 0A            [24] 2847 	jz	00102$
      0064FE                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      0064FE 90 22 00         [24] 2850 	mov	dptr,#0x2200
      006501 E0               [24] 2851 	movx	a,@dptr
      006502 64 40            [12] 2852 	xrl	a,#0x40
      006504 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006505 02 5A 94         [24] 2856 	ljmp	_control_next
      006508                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006508 90 07 C0         [24] 2859 	mov	dptr,#_control_phase
      00650B 74 02            [12] 2860 	mov	a,#0x02
      00650D F0               [24] 2861 	movx	@dptr,a
      00650E 80 18            [24] 2862 	sjmp	00110$
      006510                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006510 BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006513 90 07 61         [24] 2867 	mov	dptr,#_D0SetupReqCode
      006516 E0               [24] 2868 	movx	a,@dptr
      006517 FF               [12] 2869 	mov	r7,a
      006518 BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      00651B 90 07 62         [24] 2871 	mov	dptr,#_D0SetupLen
      00651E E0               [24] 2872 	movx	a,@dptr
      00651F 90 22 07         [24] 2873 	mov	dptr,#0x2207
      006522 F0               [24] 2874 	movx	@dptr,a
      006523                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006523 90 07 C0         [24] 2877 	mov	dptr,#_control_phase
      006526 E4               [12] 2878 	clr	a
      006527 F0               [24] 2879 	movx	@dptr,a
      006528                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006528 90 22 00         [24] 2882 	mov	dptr,#0x2200
      00652B 74 82            [12] 2883 	mov	a,#0x82
      00652D F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      00652E 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      00652F                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      00652F                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      00652F 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      006532 E0               [24] 2902 	movx	a,@dptr
      006533 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006536 12 5A 1B         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006539 90 22 07         [24] 2907 	mov	dptr,#0x2207
      00653C E4               [12] 2908 	clr	a
      00653D F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      00653E 90 07 69         [24] 2911 	mov	dptr,#_USB_SleepStatus
      006541 F0               [24] 2912 	movx	@dptr,a
      006542 90 07 68         [24] 2913 	mov	dptr,#_USB_EnumStatus
      006545 F0               [24] 2914 	movx	@dptr,a
      006546 90 07 67         [24] 2915 	mov	dptr,#_D0UsbConfig
      006549 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      00654A 90 07 6C         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      00654D F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      00654E 90 0D 82         [24] 2921 	mov	dptr,#_keyboard_protocol
      006551 04               [12] 2922 	inc	a
      006552 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006553 90 06 3F         [24] 2925 	mov	dptr,#_keyboard_idle
      006556 E4               [12] 2926 	clr	a
      006557 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006558 90 07 91         [24] 2929 	mov	dptr,#_keyboard_reset
      00655B 04               [12] 2930 	inc	a
      00655C F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      00655D 90 07 61         [24] 2933 	mov	dptr,#_D0SetupReqCode
      006560 74 FF            [12] 2934 	mov	a,#0xff
      006562 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006563 90 07 62         [24] 2937 	mov	dptr,#_D0SetupLen
      006566 E4               [12] 2938 	clr	a
      006567 F0               [24] 2939 	movx	@dptr,a
      006568 A3               [24] 2940 	inc	dptr
      006569 F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      00656A 90 07 C0         [24] 2943 	mov	dptr,#_control_phase
      00656D F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00656E 90 22 00         [24] 2946 	mov	dptr,#0x2200
      006571 74 02            [12] 2947 	mov	a,#0x02
      006573 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006574 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      006577 E4               [12] 2951 	clr	a
      006578 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006579 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      00657C 04               [12] 2955 	inc	a
      00657D F0               [24] 2956 	movx	@dptr,a
      00657E 02 66 14         [24] 2957 	ljmp	00130$
      006581                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006581 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      006584 E0               [24] 2961 	movx	a,@dptr
      006585 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006588 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      00658B E0               [24] 2965 	movx	a,@dptr
      00658C FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      00658D 74 07            [12] 2968 	mov	a,#0x07
      00658F 5F               [12] 2969 	anl	a,r7
      006590 FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006591 EF               [12] 2972 	mov	a,r7
      006592 54 18            [12] 2973 	anl	a,#0x18
      006594 70 08            [24] 2974 	jnz	00115$
      006596 EE               [12] 2975 	mov	a,r6
      006597 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006599 12 64 28         [24] 2978 	lcall	_control_out
      00659C 80 43            [24] 2979 	sjmp	00116$
      00659E                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      00659E 8F 05            [24] 2982 	mov	ar5,r7
      0065A0 74 18            [12] 2983 	mov	a,#0x18
      0065A2 5D               [12] 2984 	anl	a,r5
      0065A3 FC               [12] 2985 	mov	r4,a
      0065A4 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      0065A7 EE               [12] 2988 	mov	a,r6
      0065A8 70 05            [24] 2989 	jnz	00106$
      0065AA 12 64 E6         [24] 2990 	lcall	_control_in
      0065AD 80 32            [24] 2991 	sjmp	00116$
      0065AF                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      0065AF EE               [12] 2994 	mov	a,r6
      0065B0 24 FC            [12] 2995 	add	a,#0xff - 0x03
      0065B2 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      0065B4 8E 04            [24] 2999 	mov	ar4,r6
      0065B6 7B 00            [12] 3000 	mov	r3,#0x00
      0065B8 74 22            [12] 3001 	mov	a,#0x22
      0065BA 2B               [12] 3002 	add	a, r3
      0065BB FB               [12] 3003 	mov	r3,a
      0065BC 8C 82            [24] 3004 	mov	dpl,r4
      0065BE 8B 83            [24] 3005 	mov	dph,r3
      0065C0 E0               [24] 3006 	movx	a,@dptr
      0065C1 FA               [12] 3007 	mov	r2,a
      0065C2 74 FC            [12] 3008 	mov	a,#0xfc
      0065C4 5A               [12] 3009 	anl	a,r2
      0065C5 44 02            [12] 3010 	orl	a,#0x02
      0065C7 8C 82            [24] 3011 	mov	dpl,r4
      0065C9 8B 83            [24] 3012 	mov	dph,r3
      0065CB F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0065CC BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      0065CF 12 59 FE         [24] 3016 	lcall	_raw_complete
      0065D2 80 0D            [24] 3017 	sjmp	00116$
      0065D4                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      0065D4 53 05 18         [24] 3020 	anl	ar5,#0x18
      0065D7 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      0065DA EF               [12] 3022 	mov	a,r7
      0065DB 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      0065DE 12 5C 8B         [24] 3025 	lcall	_control_setup
      0065E1                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      0065E1 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      0065E4 E4               [12] 3029 	clr	a
      0065E5 F0               [24] 3030 	movx	@dptr,a
      0065E6 80 2C            [24] 3031 	sjmp	00130$
      0065E8                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      0065E8 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      0065EB E0               [24] 3035 	movx	a,@dptr
      0065EC 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      0065EF 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      0065F2 E0               [24] 3039 	movx	a,@dptr
      0065F3 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      0065F6 90 07 69         [24] 3041 	mov	dptr,#_USB_SleepStatus
      0065F9 E0               [24] 3042 	movx	a,@dptr
      0065FA 43 E0 02         [24] 3043 	orl	acc,#0x02
      0065FD F0               [24] 3044 	movx	@dptr,a
      0065FE 80 0E            [24] 3045 	sjmp	00120$
      006600                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006600 90 07 69         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006603 E0               [24] 3049 	movx	a,@dptr
      006604 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006607 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006608 90 07 91         [24] 3053 	mov	dptr,#_keyboard_reset
      00660B 74 01            [12] 3054 	mov	a,#0x01
      00660D F0               [24] 3055 	movx	@dptr,a
      00660E                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      00660E 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006611 74 04            [12] 3059 	mov	a,#0x04
      006613 F0               [24] 3060 	movx	@dptr,a
      006614                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006614 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006617 E0               [24] 3064 	movx	a,@dptr
      006618 54 25            [12] 3065 	anl	a,#0x25
      00661A 60 03            [24] 3066 	jz	00242$
      00661C 02 65 2F         [24] 3067 	ljmp	00129$
      00661F                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      00661F 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006620                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3080 ;	assignBit
      006620 C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006622 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006625 E4               [12] 3084 	clr	a
      006626 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006627 90 07 6F         [24] 3087 	mov	dptr,#_raw_state
      00662A F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      00662B 12 5A 1B         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      00662E 90 07 69         [24] 3092 	mov	dptr,#_USB_SleepStatus
      006631 E4               [12] 3093 	clr	a
      006632 F0               [24] 3094 	movx	@dptr,a
      006633 90 07 68         [24] 3095 	mov	dptr,#_USB_EnumStatus
      006636 F0               [24] 3096 	movx	@dptr,a
      006637 90 07 67         [24] 3097 	mov	dptr,#_D0UsbConfig
      00663A F0               [24] 3098 	movx	@dptr,a
      00663B 90 22 07         [24] 3099 	mov	dptr,#0x2207
      00663E F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      00663F 90 07 6A         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      006642 F0               [24] 3103 	movx	@dptr,a
      006643 90 07 6B         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      006646 F0               [24] 3105 	movx	@dptr,a
      006647 90 07 6C         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      00664A F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      00664B 90 0D 82         [24] 3109 	mov	dptr,#_keyboard_protocol
      00664E 04               [12] 3110 	inc	a
      00664F F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006650 90 06 3F         [24] 3113 	mov	dptr,#_keyboard_idle
      006653 E4               [12] 3114 	clr	a
      006654 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006655 90 07 91         [24] 3117 	mov	dptr,#_keyboard_reset
      006658 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006659 90 07 C0         [24] 3120 	mov	dptr,#_control_phase
      00665C F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      00665D 90 07 61         [24] 3123 	mov	dptr,#_D0SetupReqCode
      006660 14               [12] 3124 	dec	a
      006661 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006662 90 07 62         [24] 3127 	mov	dptr,#_D0SetupLen
      006665 E4               [12] 3128 	clr	a
      006666 F0               [24] 3129 	movx	@dptr,a
      006667 A3               [24] 3130 	inc	dptr
      006668 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006669 90 22 00         [24] 3133 	mov	dptr,#0x2200
      00666C 74 02            [12] 3134 	mov	a,#0x02
      00666E F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      00666F 90 22 37         [24] 3137 	mov	dptr,#0x2237
      006672 74 7F            [12] 3138 	mov	a,#0x7f
      006674 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006675 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      006678 74 FF            [12] 3142 	mov	a,#0xff
      00667A F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      00667B 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      00667E 74 07            [12] 3146 	mov	a,#0x07
      006680 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006681 A3               [24] 3149 	inc	dptr
      006682 74 80            [12] 3150 	mov	a,#0x80
      006684 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3153 ;	assignBit
      006685 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006687 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      006688                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006688 90 07 69         [24] 3169 	mov	dptr,#_USB_SleepStatus
      00668B E0               [24] 3170 	movx	a,@dptr
      00668C FF               [12] 3171 	mov	r7,a
      00668D BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006690 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      006693 E0               [24] 3175 	movx	a,@dptr
      006694 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006695 E0               [24] 3178 	movx	a,@dptr
      006696 FE               [12] 3179 	mov	r6,a
      006697 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      00669A 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      00669D EE               [12] 3182 	mov	a,r6
      00669E F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      00669F 7E 0A            [12] 3185 	mov	r6,#0x0a
      0066A1                       3186 00108$:
      0066A1 EE               [12] 3187 	mov	a,r6
      0066A2 60 09            [24] 3188 	jz	00105$
      0066A4 90 00 01         [24] 3189 	mov	dptr,#0x0001
      0066A7 12 58 62         [24] 3190 	lcall	_mDelaymS
      0066AA 1E               [12] 3191 	dec	r6
      0066AB 80 F4            [24] 3192 	sjmp	00108$
      0066AD                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      0066AD 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      0066B0 EF               [12] 3196 	mov	a,r7
      0066B1 F0               [24] 3197 	movx	@dptr,a
      0066B2                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      0066B2 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      0066B3                       3220 _ak820_usb_send:
      0066B3 E5 82            [12] 3221 	mov	a,dpl
      0066B5 90 07 D0         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0066B8 F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      0066B9 90 07 D1         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0066BC 74 2E            [12] 3226 	mov	a,#0x2e
      0066BE F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      0066BF 90 07 D0         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0066C2 E0               [24] 3230 	movx	a,@dptr
      0066C3 FF               [12] 3231 	mov	r7,a
      0066C4 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      0066C7                       3233 00306$:
      0066C7 40 14            [24] 3234 	jc	00101$
      0066C9 EF               [12] 3235 	mov	a,r7
      0066CA 24 FC            [12] 3236 	add	a,#0xff - 0x03
      0066CC 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      0066CE 90 07 CF         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      0066D1 E0               [24] 3240 	movx	a,@dptr
      0066D2 FE               [12] 3241 	mov  r6,a
      0066D3 24 BF            [12] 3242 	add	a,#0xff - 0x40
      0066D5 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      0066D7 90 07 68         [24] 3245 	mov	dptr,#_USB_EnumStatus
      0066DA E0               [24] 3246 	movx	a,@dptr
      0066DB 70 04            [24] 3247 	jnz	00102$
      0066DD                       3248 00101$:
      0066DD 75 82 00         [24] 3249 	mov	dpl, #0x00
      0066E0 22               [24] 3250 	ret
      0066E1                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      0066E1 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      0066E4 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      0066E7 80 04            [24] 3256 	sjmp	00107$
      0066E9                       3257 00313$:
      0066E9 75 82 00         [24] 3258 	mov	dpl, #0x00
      0066EC 22               [24] 3259 	ret
      0066ED                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      0066ED 90 07 D1         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0066F0 E4               [12] 3263 	clr	a
      0066F1 F0               [24] 3264 	movx	@dptr,a
      0066F2 80 3C            [24] 3265 	sjmp	00119$
      0066F4                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      0066F4 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      0066F7 90 07 CD         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      0066FA E0               [24] 3271 	movx	a,@dptr
      0066FB FD               [12] 3272 	mov	r5,a
      0066FC A3               [24] 3273 	inc	dptr
      0066FD E0               [24] 3274 	movx	a,@dptr
      0066FE FF               [12] 3275 	mov	r7,a
      0066FF 8D 82            [24] 3276 	mov	dpl,r5
      006701 8F 83            [24] 3277 	mov	dph,r7
      006703 E0               [24] 3278 	movx	a,@dptr
      006704 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006705 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      006708                       3282 00316$:
      006708 50 0E            [24] 3283 	jnc	00108$
      00670A EF               [12] 3284 	mov	a,r7
      00670B 90 B7 42         [24] 3285 	mov	dptr,#_shared_lengths
      00670E 93               [24] 3286 	movc	a,@a+dptr
      00670F FD               [12] 3287 	mov	r5,a
      006710 60 06            [24] 3288 	jz	00108$
      006712 EE               [12] 3289 	mov	a,r6
      006713 B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      006716 80 04            [24] 3291 	sjmp	00109$
      006718                       3292 00319$:
      006718                       3293 00108$:
      006718 75 82 00         [24] 3294 	mov	dpl, #0x00
      00671B 22               [24] 3295 	ret
      00671C                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      00671C EF               [12] 3298 	mov	a,r7
      00671D 90 B7 3B         [24] 3299 	mov	dptr,#_shared_offsets
      006720 93               [24] 3300 	movc	a,@a+dptr
      006721 90 07 D1         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006724 F0               [24] 3302 	movx	@dptr,a
      006725 80 09            [24] 3303 	sjmp	00119$
      006727                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006727 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      00672A 80 04            [24] 3307 	sjmp	00119$
      00672C                       3308 00320$:
      00672C 75 82 00         [24] 3309 	mov	dpl, #0x00
      00672F 22               [24] 3310 	ret
      006730                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006730 90 07 69         [24] 3313 	mov	dptr,#_USB_SleepStatus
      006733 E0               [24] 3314 	movx	a,@dptr
      006734 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      006737 12 66 88         [24] 3316 	lcall	_USB_WakeUp_PC
      00673A 75 82 00         [24] 3317 	mov	dpl, #0x00
      00673D 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      00673E                       3320 00184$:
      00673E 7F FA            [12] 3321 	mov	r7,#0xfa
      006740                       3322 00127$:
      006740 90 07 D0         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006743 E0               [24] 3324 	movx	a,@dptr
      006744 FC               [12] 3325 	mov	r4,a
      006745 7D 00            [12] 3326 	mov	r5,#0x00
      006747 8C 02            [24] 3327 	mov	ar2,r4
      006749 74 22            [12] 3328 	mov	a,#0x22
      00674B 2D               [12] 3329 	add	a, r5
      00674C FB               [12] 3330 	mov	r3,a
      00674D 8A 82            [24] 3331 	mov	dpl,r2
      00674F 8B 83            [24] 3332 	mov	dph,r3
      006751 E0               [24] 3333 	movx	a,@dptr
      006752 54 03            [12] 3334 	anl	a,#0x03
      006754 70 14            [24] 3335 	jnz	00129$
      006756 8F 03            [24] 3336 	mov	ar3,r7
      006758 1F               [12] 3337 	dec	r7
      006759 EB               [12] 3338 	mov	a,r3
      00675A 60 0E            [24] 3339 	jz	00129$
      00675C 7B 28            [12] 3340 	mov	r3,#0x28
      00675E                       3341 00141$:
      00675E EB               [12] 3342 	mov	a,r3
      00675F 60 DF            [24] 3343 	jz	00127$
      006761 90 00 01         [24] 3344 	mov	dptr,#0x0001
      006764 12 58 1E         [24] 3345 	lcall	_mDelayuS
      006767 1B               [12] 3346 	dec	r3
      006768 80 F4            [24] 3347 	sjmp	00141$
      00676A                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      00676A A2 AF            [12] 3350 	mov	c,_EA
      00676C E4               [12] 3351 	clr	a
      00676D 33               [12] 3352 	rlc	a
      00676E FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3355 ;	assignBit
      00676F C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006771 90 07 68         [24] 3358 	mov	dptr,#_USB_EnumStatus
      006774 E0               [24] 3359 	movx	a,@dptr
      006775 60 25            [24] 3360 	jz	00130$
      006777 90 07 D0         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00677A E0               [24] 3362 	movx	a,@dptr
      00677B FB               [12] 3363 	mov	r3,a
      00677C F9               [12] 3364 	mov	r1,a
      00677D 7A 00            [12] 3365 	mov	r2,#0x00
      00677F 74 22            [12] 3366 	mov	a,#0x22
      006781 2A               [12] 3367 	add	a, r2
      006782 FA               [12] 3368 	mov	r2,a
      006783 89 82            [24] 3369 	mov	dpl,r1
      006785 8A 83            [24] 3370 	mov	dph,r2
      006787 E0               [24] 3371 	movx	a,@dptr
      006788 FA               [12] 3372 	mov	r2,a
      006789 53 02 03         [24] 3373 	anl	ar2,#0x03
      00678C BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      00678F BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      006792 90 07 6F         [24] 3377 	mov	dptr,#_raw_state
      006795 E0               [24] 3378 	movx	a,@dptr
      006796 FB               [12] 3379 	mov	r3,a
      006797 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      00679A 80 09            [24] 3381 	sjmp	00192$
      00679C                       3382 00331$:
      00679C                       3383 00130$:
                                   3384 ;	assignBit
      00679C EF               [12] 3385 	mov	a,r7
      00679D 24 FF            [12] 3386 	add	a,#0xff
      00679F 92 AF            [24] 3387 	mov	_EA,c
      0067A1 75 82 00         [24] 3388 	mov	dpl, #0x00
      0067A4 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      0067A5                       3391 00192$:
      0067A5 7B 00            [12] 3392 	mov	r3,#0x00
      0067A7                       3393 00144$:
      0067A7 C3               [12] 3394 	clr	c
      0067A8 EB               [12] 3395 	mov	a,r3
      0067A9 9E               [12] 3396 	subb	a,r6
      0067AA 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      0067AC C0 07            [24] 3399 	push	ar7
      0067AE 90 07 D0         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0067B1 E0               [24] 3401 	movx	a,@dptr
      0067B2 F9               [12] 3402 	mov	r1,a
      0067B3 E4               [12] 3403 	clr	a
      0067B4 C3               [12] 3404 	clr	c
      0067B5 C9               [12] 3405 	xch	a,r1
      0067B6 13               [12] 3406 	rrc	a
      0067B7 C9               [12] 3407 	xch	a,r1
      0067B8 13               [12] 3408 	rrc	a
      0067B9 A2 E0            [12] 3409 	mov	c,acc.0
      0067BB C9               [12] 3410 	xch	a,r1
      0067BC 13               [12] 3411 	rrc	a
      0067BD C9               [12] 3412 	xch	a,r1
      0067BE 13               [12] 3413 	rrc	a
      0067BF C9               [12] 3414 	xch	a,r1
      0067C0 FA               [12] 3415 	mov	r2,a
      0067C1 8B 00            [24] 3416 	mov	ar0,r3
      0067C3 7F 00            [12] 3417 	mov	r7,#0x00
      0067C5 E8               [12] 3418 	mov	a,r0
      0067C6 29               [12] 3419 	add	a, r1
      0067C7 F9               [12] 3420 	mov	r1,a
      0067C8 EF               [12] 3421 	mov	a,r7
      0067C9 3A               [12] 3422 	addc	a, r2
      0067CA 24 10            [12] 3423 	add	a,#0x10
      0067CC FA               [12] 3424 	mov	r2,a
      0067CD 90 07 CD         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      0067D0 E0               [24] 3426 	movx	a,@dptr
      0067D1 F8               [12] 3427 	mov	r0,a
      0067D2 A3               [24] 3428 	inc	dptr
      0067D3 E0               [24] 3429 	movx	a,@dptr
      0067D4 FF               [12] 3430 	mov	r7,a
      0067D5 EB               [12] 3431 	mov	a,r3
      0067D6 28               [12] 3432 	add	a, r0
      0067D7 F5 1B            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      0067D9 E4               [12] 3434 	clr	a
      0067DA 3F               [12] 3435 	addc	a, r7
      0067DB F5 1C            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      0067DD 85 1B 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      0067E0 85 1C 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      0067E3 E0               [24] 3439 	movx	a,@dptr
      0067E4 89 82            [24] 3440 	mov	dpl,r1
      0067E6 8A 83            [24] 3441 	mov	dph,r2
      0067E8 F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      0067E9 90 07 D1         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0067EC E0               [24] 3445 	movx	a,@dptr
      0067ED F5 1D            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      0067EF 74 2E            [12] 3447 	mov	a,#0x2e
      0067F1 B5 1D 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      0067F4 D0 07            [24] 3449 	pop	ar7
      0067F6 80 18            [24] 3450 	sjmp	00145$
      0067F8                       3451 00333$:
      0067F8 D0 07            [24] 3452 	pop	ar7
      0067FA EB               [12] 3453 	mov	a,r3
      0067FB 25 1D            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      0067FD 24 92            [12] 3455 	add	a, #_input_snapshot
      0067FF F9               [12] 3456 	mov	r1,a
      006800 E4               [12] 3457 	clr	a
      006801 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      006803 FA               [12] 3459 	mov	r2,a
      006804 85 1B 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006807 85 1C 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      00680A E0               [24] 3462 	movx	a,@dptr
      00680B 89 82            [24] 3463 	mov	dpl,r1
      00680D 8A 83            [24] 3464 	mov	dph,r2
      00680F F0               [24] 3465 	movx	@dptr,a
      006810                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006810 0B               [12] 3468 	inc	r3
      006811 80 94            [24] 3469 	sjmp	00144$
      006813                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006813 90 07 D0         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006816 E0               [24] 3473 	movx	a,@dptr
      006817 FB               [12] 3474 	mov	r3,a
      006818 F9               [12] 3475 	mov	r1,a
      006819 7A 00            [12] 3476 	mov	r2,#0x00
      00681B 74 08            [12] 3477 	mov	a,#0x08
      00681D 29               [12] 3478 	add	a, r1
      00681E F9               [12] 3479 	mov	r1,a
      00681F 74 22            [12] 3480 	mov	a,#0x22
      006821 3A               [12] 3481 	addc	a, r2
      006822 FA               [12] 3482 	mov	r2,a
      006823 89 82            [24] 3483 	mov	dpl,r1
      006825 8A 83            [24] 3484 	mov	dph,r2
      006827 EE               [12] 3485 	mov	a,r6
      006828 F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006829 BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      00682C 90 07 6F         [24] 3489 	mov	dptr,#_raw_state
      00682F 74 04            [12] 3490 	mov	a,#0x04
      006831 F0               [24] 3491 	movx	@dptr,a
      006832                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006832 74 22            [12] 3494 	mov	a,#0x22
      006834 2D               [12] 3495 	add	a, r5
      006835 FD               [12] 3496 	mov	r5,a
      006836 8C 82            [24] 3497 	mov	dpl,r4
      006838 8D 83            [24] 3498 	mov	dph,r5
      00683A E0               [24] 3499 	movx	a,@dptr
      00683B FE               [12] 3500 	mov	r6,a
      00683C 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      00683F 8C 82            [24] 3502 	mov	dpl,r4
      006841 8D 83            [24] 3503 	mov	dph,r5
      006843 EE               [12] 3504 	mov	a,r6
      006844 F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3507 ;	assignBit
      006845 EF               [12] 3508 	mov	a,r7
      006846 24 FF            [12] 3509 	add	a,#0xff
      006848 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      00684A 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      00684D 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      00684E                       3528 _ak820_usb_try_send:
      00684E E5 82            [12] 3529 	mov	a,dpl
      006850 90 07 D5         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006853 F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      006854 A2 AF            [12] 3534 	mov	c,_EA
      006856 92 1A            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006858 90 07 D6         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      00685B E4               [12] 3538 	clr	a
      00685C F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3541 ;	assignBit
      00685D C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      00685F 90 07 D5         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006862 E0               [24] 3545 	movx	a,@dptr
      006863 FF               [12] 3546 	mov	r7,a
      006864 BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      006867                       3548 00152$:
      006867 40 4E            [24] 3549 	jc	00102$
      006869 EF               [12] 3550 	mov	a,r7
      00686A 24 FD            [12] 3551 	add	a,#0xff - 0x02
      00686C 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      00686E 90 07 68         [24] 3554 	mov	dptr,#_USB_EnumStatus
      006871 E0               [24] 3555 	movx	a,@dptr
      006872 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006874 90 07 69         [24] 3558 	mov	dptr,#_USB_SleepStatus
      006877 E0               [24] 3559 	movx	a,@dptr
      006878 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      00687B 90 07 91         [24] 3561 	mov	dptr,#_keyboard_reset
      00687E E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      00687F 70 36            [24] 3564 	jnz	00102$
      006881 8F 06            [24] 3565 	mov	ar6,r7
      006883 24 22            [12] 3566 	add	a,#0x22
      006885 FD               [12] 3567 	mov	r5,a
      006886 8E 82            [24] 3568 	mov	dpl,r6
      006888 8D 83            [24] 3569 	mov	dph,r5
      00688A E0               [24] 3570 	movx	a,@dptr
      00688B FE               [12] 3571 	mov	r6,a
      00688C 53 06 03         [24] 3572 	anl	ar6,#0x03
      00688F BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006892 90 07 D2         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006895 E0               [24] 3576 	movx	a,@dptr
      006896 FD               [12] 3577 	mov	r5,a
      006897 A3               [24] 3578 	inc	dptr
      006898 E0               [24] 3579 	movx	a,@dptr
      006899 FE               [12] 3580 	mov	r6,a
      00689A 90 07 D4         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      00689D E0               [24] 3582 	movx	a,@dptr
      00689E FC               [12] 3583 	mov	r4,a
      00689F 90 07 CD         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      0068A2 ED               [12] 3585 	mov	a,r5
      0068A3 F0               [24] 3586 	movx	@dptr,a
      0068A4 EE               [12] 3587 	mov	a,r6
      0068A5 A3               [24] 3588 	inc	dptr
      0068A6 F0               [24] 3589 	movx	@dptr,a
      0068A7 90 07 CF         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      0068AA EC               [12] 3591 	mov	a,r4
      0068AB F0               [24] 3592 	movx	@dptr,a
      0068AC 8F 82            [24] 3593 	mov	dpl, r7
      0068AE 12 66 B3         [24] 3594 	lcall	_ak820_usb_send
      0068B1 E5 82            [12] 3595 	mov	a, dpl
      0068B3 90 07 D6         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0068B6 F0               [24] 3597 	movx	@dptr,a
      0068B7                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3600 ;	assignBit
      0068B7 A2 1A            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      0068B9 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      0068BB 90 07 D6         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0068BE E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      0068BF F5 82            [12] 3607 	mov	dpl,a
      0068C1 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      0068C2                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      0068C2 90 07 70         [24] 3618 	mov	dptr,#_raw_buffer
      0068C5 E0               [24] 3619 	movx	a,@dptr
      0068C6 FF               [12] 3620 	mov	r7,a
      0068C7 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      0068CA 80 35            [24] 3622 	sjmp	00108$
      0068CC                       3623 00302$:
      0068CC BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      0068CF 80 34            [24] 3625 	sjmp	00109$
      0068D1                       3626 00303$:
      0068D1 BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      0068D4 80 2B            [24] 3628 	sjmp	00108$
      0068D6                       3629 00304$:
      0068D6 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      0068D9 80 47            [24] 3631 	sjmp	00116$
      0068DB                       3632 00305$:
      0068DB BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      0068DE 80 21            [24] 3634 	sjmp	00108$
      0068E0                       3635 00306$:
      0068E0 BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      0068E3 80 1C            [24] 3637 	sjmp	00108$
      0068E5                       3638 00307$:
      0068E5 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      0068E8 80 17            [24] 3640 	sjmp	00108$
      0068EA                       3641 00308$:
      0068EA BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      0068ED 80 12            [24] 3643 	sjmp	00108$
      0068EF                       3644 00309$:
      0068EF BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      0068F2 80 0D            [24] 3646 	sjmp	00108$
      0068F4                       3647 00310$:
      0068F4 BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      0068F7 80 08            [24] 3649 	sjmp	00108$
      0068F9                       3650 00311$:
      0068F9 BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      0068FC 80 46            [24] 3652 	sjmp	00124$
      0068FE                       3653 00312$:
      0068FE 02 69 99         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006901                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006901 75 82 01         [24] 3658 	mov	dpl, #0x01
      006904 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006905                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006905 12 6B CB         [24] 3663 	lcall	_ak820_outline_0158
      006908 BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      00690B 80 0D            [24] 3665 	sjmp	00113$
      00690D                       3666 00313$:
      00690D BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      006910 80 08            [24] 3668 	sjmp	00113$
      006912                       3669 00314$:
      006912 BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      006915 80 03            [24] 3671 	sjmp	00113$
      006917                       3672 00315$:
      006917 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      00691A                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      00691A 75 82 01         [24] 3677 	mov	dpl, #0x01
      00691D 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      00691E                       3680 00114$:
      00691E 75 82 00         [24] 3681 	mov	dpl, #0x00
      006921 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006922                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006922 12 6B CB         [24] 3686 	lcall	_ak820_outline_0158
      006925 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      006928 80 12            [24] 3688 	sjmp	00121$
      00692A                       3689 00318$:
      00692A BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      00692D 80 0D            [24] 3691 	sjmp	00121$
      00692F                       3692 00319$:
      00692F BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      006932 80 08            [24] 3694 	sjmp	00121$
      006934                       3695 00320$:
      006934 BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      006937 80 03            [24] 3697 	sjmp	00121$
      006939                       3698 00321$:
      006939 BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      00693C                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      00693C 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      00693F 22               [24] 3705 	ret
      006940                       3706 00122$:
      006940 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006943 22               [24] 3709 	ret
      006944                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006944 12 6B CB         [24] 3712 	lcall	_ak820_outline_0158
      006947 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      006949 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      00694B EF               [12] 3716 	mov	a,r7
      00694C 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      00694E 83               [24] 3718 	movc	a,@a+pc
      00694F F5 82            [12] 3719 	mov	dpl,a
      006951 EF               [12] 3720 	mov	a,r7
      006952 24 12            [12] 3721 	add	a,#(00326$-3-.)
      006954 83               [24] 3722 	movc	a,@a+pc
      006955 F5 83            [12] 3723 	mov	dph,a
      006957 E4               [12] 3724 	clr	a
      006958 73               [24] 3725 	jmp	@a+dptr
      006959                       3726 00325$:
      006959 75                    3727 	.db	00134$
      00695A 75                    3728 	.db	00134$
      00695B 75                    3729 	.db	00134$
      00695C 75                    3730 	.db	00134$
      00695D 95                    3731 	.db	00142$
      00695E 75                    3732 	.db	00134$
      00695F 75                    3733 	.db	00134$
      006960 75                    3734 	.db	00134$
      006961 75                    3735 	.db	00134$
      006962 75                    3736 	.db	00134$
      006963 75                    3737 	.db	00134$
      006964 95                    3738 	.db	00142$
      006965 95                    3739 	.db	00142$
      006966 79                    3740 	.db	00135$
      006967                       3741 00326$:
      006967 69                    3742 	.db	00134$>>8
      006968 69                    3743 	.db	00134$>>8
      006969 69                    3744 	.db	00134$>>8
      00696A 69                    3745 	.db	00134$>>8
      00696B 69                    3746 	.db	00142$>>8
      00696C 69                    3747 	.db	00134$>>8
      00696D 69                    3748 	.db	00134$>>8
      00696E 69                    3749 	.db	00134$>>8
      00696F 69                    3750 	.db	00134$>>8
      006970 69                    3751 	.db	00134$>>8
      006971 69                    3752 	.db	00134$>>8
      006972 69                    3753 	.db	00142$>>8
      006973 69                    3754 	.db	00142$>>8
      006974 69                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006975                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006975 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006978 22               [24] 3761 	ret
      006979                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006979 90 07 72         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      00697C E0               [24] 3765 	movx	a,@dptr
      00697D FF               [12] 3766 	mov	r7,a
      00697E 60 0D            [24] 3767 	jz	00139$
      006980 BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      006983 80 08            [24] 3769 	sjmp	00139$
      006985                       3770 00328$:
      006985 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      006988 80 03            [24] 3772 	sjmp	00139$
      00698A                       3773 00329$:
      00698A BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      00698D                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      00698D 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006990 22               [24] 3780 	ret
      006991                       3781 00140$:
      006991 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006994 22               [24] 3784 	ret
      006995                       3785 00142$:
      006995 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006998 22               [24] 3788 	ret
      006999                       3789 00144$:
      006999 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      00699C 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      00699D                       3804 _ak820_usb_raw_send:
      00699D 12 42 D7         [24] 3805 	lcall	_ak820_outline_0036
      0069A0 90 07 D8         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      0069A3 12 37 E0         [24] 3807 	lcall	_ak820_outline_0015
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      0069A6 90 07 D7         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      0069A9 E0               [24] 3810 	movx	a,@dptr
      0069AA FF               [12] 3811 	mov	r7,a
      0069AB BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      0069AE C0 07            [24] 3814 	push	ar7
      0069B0 12 3D ED         [24] 3815 	lcall	_ak820_nvm_flush
      0069B3 D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      0069B5 90 07 90         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      0069B8 E0               [24] 3819 	movx	a,@dptr
      0069B9 70 07            [24] 3820 	jnz	00103$
      0069BB 12 3D DE         [24] 3821 	lcall	_ak820_nvm_ok
      0069BE E5 82            [12] 3822 	mov	a, dpl
      0069C0 60 17            [24] 3823 	jz	00106$
      0069C2                       3824 00103$:
      0069C2 90 07 D8         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      0069C5 12 43 0E         [24] 3826 	lcall	_ak820_outline_0092
      0069C8 90 07 CD         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      0069CB 12 43 51         [24] 3828 	lcall	_ak820_outline_0156
      0069CE 90 07 CF         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      0069D1 EF               [12] 3830 	mov	a,r7
      0069D2 F0               [24] 3831 	movx	@dptr,a
      0069D3 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      0069D6 02 66 B3         [24] 3834 	ljmp	_ak820_usb_send
      0069D9                       3835 00106$:
      0069D9 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      0069DA                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      0069DA A2 AF            [12] 3852 	mov	c,_EA
      0069DC E4               [12] 3853 	clr	a
      0069DD 33               [12] 3854 	rlc	a
      0069DE FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3857 ;	assignBit
      0069DF C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      0069E1 90 07 68         [24] 3860 	mov	dptr,#_USB_EnumStatus
      0069E4 E0               [24] 3861 	movx	a,@dptr
      0069E5 60 0A            [24] 3862 	jz	00101$
      0069E7 90 07 6F         [24] 3863 	mov	dptr,#_raw_state
      0069EA E0               [24] 3864 	movx	a,@dptr
      0069EB FE               [12] 3865 	mov	r6,a
      0069EC BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      0069EF 80 06            [24] 3867 	sjmp	00102$
      0069F1                       3868 00270$:
      0069F1                       3869 00101$:
                                   3870 ;	assignBit
      0069F1 EF               [12] 3871 	mov	a,r7
      0069F2 24 FF            [12] 3872 	add	a,#0xff
      0069F4 92 AF            [24] 3873 	mov	_EA,c
      0069F6 22               [24] 3874 	ret
      0069F7                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      0069F7 90 07 6F         [24] 3877 	mov	dptr,#_raw_state
      0069FA 74 03            [12] 3878 	mov	a,#0x03
      0069FC F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3881 ;	assignBit
      0069FD EF               [12] 3882 	mov	a,r7
      0069FE 24 FF            [12] 3883 	add	a,#0xff
      006A00 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006A02 90 07 70         [24] 3886 	mov	dptr,#_raw_buffer
      006A05 E0               [24] 3887 	movx	a,@dptr
      006A06 FF               [12] 3888 	mov	r7,a
      006A07 E4               [12] 3889 	clr	a
      006A08 BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      006A0B 04               [12] 3891 	inc	a
      006A0C                       3892 00271$:
      006A0C FF               [12] 3893 	mov	r7,a
      006A0D 70 03            [24] 3894 	jnz	00273$
      006A0F 02 6A AF         [24] 3895 	ljmp	00118$
      006A12                       3896 00273$:
      006A12 90 07 71         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      006A15 E0               [24] 3898 	movx	a,@dptr
      006A16 60 03            [24] 3899 	jz	00274$
      006A18 02 6A AF         [24] 3900 	ljmp	00118$
      006A1B                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006A1B 90 07 72         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      006A1E E0               [24] 3904 	movx	a,@dptr
      006A1F FD               [12] 3905 	mov	r5,a
      006A20 7E 00            [12] 3906 	mov	r6,#0x00
      006A22 90 07 73         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      006A25 E0               [24] 3908 	movx	a,@dptr
      006A26 7B 00            [12] 3909 	mov	r3,#0x00
      006A28 42 06            [12] 3910 	orl	ar6,a
      006A2A EB               [12] 3911 	mov	a,r3
      006A2B 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006A2D 90 07 74         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      006A30 E0               [24] 3915 	movx	a,@dptr
      006A31 FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006A32 7B 05            [12] 3918 	mov	r3,#0x05
      006A34                       3919 00128$:
      006A34 EB               [12] 3920 	mov	a,r3
      006A35 12 6B B9         [24] 3921 	lcall	_ak820_outline_0100
      006A38 0B               [12] 3922 	inc	r3
      006A39 BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      006A3C                       3924 00275$:
      006A3C 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006A3E EC               [12] 3927 	mov	a,r4
      006A3F 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      006A41 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      006A43 EC               [12] 3931 	mov	a,r4
      006A44 60 26            [24] 3932 	jz	00165$
      006A46 8C 03            [24] 3933 	mov	ar3,r4
      006A48 1B               [12] 3934 	dec	r3
      006A49 7A 00            [12] 3935 	mov	r2,#0x00
      006A4B 74 FF            [12] 3936 	mov	a,#0xff
      006A4D C3               [12] 3937 	clr	c
      006A4E 9B               [12] 3938 	subb	a,r3
      006A4F FB               [12] 3939 	mov	r3,a
      006A50 74 FF            [12] 3940 	mov	a,#0xff
      006A52 9A               [12] 3941 	subb	a,r2
      006A53 FA               [12] 3942 	mov	r2,a
      006A54 8E 00            [24] 3943 	mov	ar0,r6
      006A56 8D 01            [24] 3944 	mov	ar1,r5
      006A58 C3               [12] 3945 	clr	c
      006A59 EB               [12] 3946 	mov	a,r3
      006A5A 98               [12] 3947 	subb	a,r0
      006A5B EA               [12] 3948 	mov	a,r2
      006A5C 99               [12] 3949 	subb	a,r1
      006A5D 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      006A5F                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006A5F 90 07 71         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      006A62 74 FF            [12] 3955 	mov	a,#0xff
      006A64 F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006A65 90 07 74         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      006A68 E4               [12] 3959 	clr	a
      006A69 F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006A6A 80 3A            [24] 3962 	sjmp	00108$
      006A6C                       3963 00165$:
      006A6C 7B 00            [12] 3964 	mov	r3,#0x00
      006A6E                       3965 00131$:
      006A6E C3               [12] 3966 	clr	c
      006A6F EB               [12] 3967 	mov	a,r3
      006A70 9C               [12] 3968 	subb	a,r4
      006A71 50 33            [24] 3969 	jnc	00108$
      006A73 C0 04            [24] 3970 	push	ar4
      006A75 8B 02            [24] 3971 	mov	ar2,r3
      006A77 74 05            [12] 3972 	mov	a,#0x05
      006A79 2A               [12] 3973 	add	a, r2
      006A7A F9               [12] 3974 	mov	r1,a
      006A7B 33               [12] 3975 	rlc	a
      006A7C 95 E0            [12] 3976 	subb	a,acc
      006A7E FA               [12] 3977 	mov	r2,a
      006A7F E9               [12] 3978 	mov	a,r1
      006A80 24 70            [12] 3979 	add	a, #_raw_buffer
      006A82 F9               [12] 3980 	mov	r1,a
      006A83 EA               [12] 3981 	mov	a,r2
      006A84 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      006A86 FA               [12] 3983 	mov	r2,a
      006A87 8B 1E            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006A89 75 1F 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006A8C 8E 00            [24] 3986 	mov	ar0,r6
      006A8E 8D 04            [24] 3987 	mov	ar4,r5
      006A90 E5 1E            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006A92 28               [12] 3989 	add	a, r0
      006A93 F8               [12] 3990 	mov	r0,a
      006A94 E5 1F            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006A96 3C               [12] 3992 	addc	a, r4
      006A97 FC               [12] 3993 	mov	r4,a
      006A98 88 82            [24] 3994 	mov	dpl,r0
      006A9A 8C 83            [24] 3995 	mov	dph,r4
      006A9C E4               [12] 3996 	clr	a
      006A9D 93               [24] 3997 	movc	a,@a+dptr
      006A9E 12 6B C5         [24] 3998 	lcall	_ak820_outline_0135
      006AA1 0B               [12] 3999 	inc	r3
      006AA2 D0 04            [24] 4000 	pop	ar4
      006AA4 80 C8            [24] 4001 	sjmp	00131$
      006AA6                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006AA6 12 6B A5         [24] 4004 	lcall	_ak820_outline_0041
      006AA9 12 66 B3         [24] 4005 	lcall	_ak820_usb_send
      006AAC 02 6B 55         [24] 4006 	ljmp	00119$
      006AAF                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006AAF EF               [12] 4009 	mov	a,r7
      006AB0 70 03            [24] 4010 	jnz	00281$
      006AB2 02 6B 32         [24] 4011 	ljmp	00114$
      006AB5                       4012 00281$:
      006AB5 12 6B CB         [24] 4013 	lcall	_ak820_outline_0158
      006AB8 BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      006ABB 80 03            [24] 4015 	sjmp	00283$
      006ABD                       4016 00282$:
      006ABD 02 6B 32         [24] 4017 	ljmp	00114$
      006AC0                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006AC0 7F 02            [12] 4020 	mov	r7,#0x02
      006AC2                       4021 00133$:
      006AC2 EF               [12] 4022 	mov	a,r7
      006AC3 12 6B B9         [24] 4023 	lcall	_ak820_outline_0100
      006AC6 0F               [12] 4024 	inc	r7
      006AC7 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      006ACA                       4026 00284$:
      006ACA 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006ACC 90 07 72         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      006ACF 74 01            [12] 4030 	mov	a,#0x01
      006AD1 F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006AD2 90 07 73         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      006AD5 74 A8            [12] 4034 	mov	a,#0xa8
      006AD7 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006AD8 90 07 74         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      006ADB 12 3B 5C         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006ADE 7F 00            [12] 4040 	mov	r7,#0x00
      006AE0                       4041 00135$:
      006AE0 8F 06            [24] 4042 	mov	ar6,r7
      006AE2 74 0B            [12] 4043 	mov	a,#0x0b
      006AE4 2E               [12] 4044 	add	a, r6
      006AE5 24 70            [12] 4045 	add	a,#_raw_buffer
      006AE7 FE               [12] 4046 	mov	r6,a
      006AE8 E4               [12] 4047 	clr	a
      006AE9 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      006AEB FD               [12] 4049 	mov	r5,a
      006AEC EF               [12] 4050 	mov	a,r7
      006AED 24 60            [12] 4051 	add	a, #_ak820_flash_diagnostic
      006AEF F5 82            [12] 4052 	mov	dpl,a
      006AF1 E4               [12] 4053 	clr	a
      006AF2 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006AF4 F5 83            [12] 4055 	mov	dph,a
      006AF6 E0               [24] 4056 	movx	a,@dptr
      006AF7 8E 82            [24] 4057 	mov	dpl,r6
      006AF9 8D 83            [24] 4058 	mov	dph,r5
      006AFB F0               [24] 4059 	movx	@dptr,a
      006AFC 0F               [12] 4060 	inc	r7
      006AFD BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      006B00                       4062 00286$:
      006B00 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006B02 90 0D F0         [24] 4065 	mov	dptr,#_vial_unlocked
      006B05 E0               [24] 4066 	movx	a,@dptr
      006B06 90 07 81         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      006B09 F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006B0A 90 0D F1         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      006B0D E0               [24] 4071 	movx	a,@dptr
      006B0E 90 07 82         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      006B11 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006B12 90 07 68         [24] 4075 	mov	dptr,#_USB_EnumStatus
      006B15 E0               [24] 4076 	movx	a,@dptr
      006B16 90 07 83         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      006B19 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006B1A 90 07 69         [24] 4080 	mov	dptr,#_USB_SleepStatus
      006B1D E0               [24] 4081 	movx	a,@dptr
      006B1E 90 07 84         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      006B21 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006B22 90 07 6F         [24] 4085 	mov	dptr,#_raw_state
      006B25 E0               [24] 4086 	movx	a,@dptr
      006B26 90 07 85         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      006B29 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006B2A 12 6B A5         [24] 4090 	lcall	_ak820_outline_0041
      006B2D 12 66 B3         [24] 4091 	lcall	_ak820_usb_send
      006B30 80 23            [24] 4092 	sjmp	00119$
      006B32                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006B32 12 68 C2         [24] 4095 	lcall	_raw_request_is_nonpersistent
      006B35 E5 82            [12] 4096 	mov	a, dpl
      006B37 90 07 90         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      006B3A F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      006B3B 12 3F 40         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006B3E 90 0C 22         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      006B41 74 20            [12] 4103 	mov	a,#0x20
      006B43 F0               [24] 4104 	movx	@dptr,a
      006B44 90 07 70         [24] 4105 	mov	dptr,#_raw_buffer
      006B47 75 F0 00         [24] 4106 	mov	b, #0x00
      006B4A 12 A4 60         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      006B4D 12 3F 55         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      006B50 90 07 90         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      006B53 E4               [12] 4112 	clr	a
      006B54 F0               [24] 4113 	movx	@dptr,a
      006B55                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4116 ;	assignBit
      006B55 A2 AF            [12] 4117 	mov	c,_EA
      006B57 92 1B            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4120 ;	assignBit
      006B59 C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006B5B 12 6B D1         [24] 4123 	lcall	_ak820_outline_0160
      006B5E BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      006B61 90 07 6F         [24] 4125 	mov	dptr,#_raw_state
      006B64 74 05            [12] 4126 	mov	a,#0x05
      006B66 F0               [24] 4127 	movx	@dptr,a
      006B67 80 1B            [24] 4128 	sjmp	00127$
      006B69                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006B69 12 6B D1         [24] 4131 	lcall	_ak820_outline_0160
      006B6C BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      006B6F 80 0E            [24] 4133 	sjmp	00121$
      006B71                       4134 00290$:
      006B71 12 6B D1         [24] 4135 	lcall	_ak820_outline_0160
      006B74 BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      006B77 80 06            [24] 4137 	sjmp	00121$
      006B79                       4138 00291$:
      006B79 12 6B D1         [24] 4139 	lcall	_ak820_outline_0160
      006B7C BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      006B7F                       4141 00121$:
      006B7F 90 07 6F         [24] 4142 	mov	dptr,#_raw_state
      006B82 E4               [12] 4143 	clr	a
      006B83 F0               [24] 4144 	movx	@dptr,a
      006B84                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4147 ;	assignBit
      006B84 A2 1B            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006B86 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      006B88 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      006B89                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      006B89 A2 AF            [12] 4165 	mov	c,_EA
      006B8B 92 1C            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4168 ;	assignBit
      006B8D C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      006B8F 90 07 91         [24] 4171 	mov	dptr,#_keyboard_reset
      006B92 E0               [24] 4172 	movx	a,@dptr
      006B93 FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      006B94 E4               [12] 4175 	clr	a
      006B95 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4178 ;	assignBit
      006B96 A2 1C            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006B98 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      006B9A EF               [12] 4182 	mov	a,r7
      006B9B B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      006B9E                       4184 00103$:
      006B9E B3               [12] 4185 	cpl	c
      006B9F 92 1C            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006BA1 12 38 81         [24] 4187 	lcall	_ak820_outline_0166
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      006BA4 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00B73B                       4193 _shared_offsets:
      00B73B 00                    4194 	.db #0x00	; 0
      00B73C 00                    4195 	.db #0x00	; 0
      00B73D 28                    4196 	.db #0x28	; 40
      00B73E 28                    4197 	.db #0x28	; 40
      00B73F 2B                    4198 	.db #0x2b	; 43
      00B740 00                    4199 	.db #0x00	; 0
      00B741 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00B742                       4203 _shared_lengths:
      00B742 00                    4204 	.db #0x00	; 0
      00B743 00                    4205 	.db #0x00	; 0
      00B744 00                    4206 	.db #0x00	; 0
      00B745 03                    4207 	.db #0x03	; 3
      00B746 03                    4208 	.db #0x03	; 3
      00B747 00                    4209 	.db #0x00	; 0
      00B748 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00B749                       4213 _interface_descriptors:
      00B749 E4 BC                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00B74B E4 BD                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00B74D 97 BD                 4216 	.byte _RawReport, (_RawReport >> 8)
      00B74F FD BD                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00B751 29 BD                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00B753 16 BE                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0015
                                   4226 	.globl _ak820_outline_0036
                                   4227 	.globl _ak820_outline_0041
                                   4228 	.globl _ak820_outline_0092
                                   4229 	.globl _ak820_outline_0100
                                   4230 	.globl _ak820_outline_0135
                                   4231 	.globl _ak820_outline_0156
                                   4232 	.globl _ak820_outline_0158
                                   4233 	.globl _ak820_outline_0160
                                   4234 	.globl _ak820_outline_0166
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0041
      006BA5                       4238 _ak820_outline_0041:
      006BA5 90 07 CD         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      006BA8 74 70            [12] 4240 	mov	a,#_raw_buffer
      006BAA F0               [24] 4241 	movx	@dptr,a
      006BAB 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      006BAD A3               [24] 4243 	inc	dptr
      006BAE F0               [24] 4244 	movx	@dptr,a
      006BAF 90 07 CF         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      006BB2 74 20            [12] 4246 	mov	a,#0x20
      006BB4 F0               [24] 4247 	movx	@dptr,a
      006BB5 75 82 03         [24] 4248 	mov	dpl,#0x03
      006BB8 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0100
      006BB9                       4253 _ak820_outline_0100:
      006BB9 24 70            [12] 4254 	add	a,#_raw_buffer
      006BBB F5 82            [12] 4255 	mov	dpl,a
      006BBD E4               [12] 4256 	clr	a
      006BBE 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      006BC0 F5 83            [12] 4258 	mov	dph,a
      006BC2 E4               [12] 4259 	clr	a
      006BC3 F0               [24] 4260 	movx	@dptr,a
      006BC4 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0135
      006BC5                       4265 _ak820_outline_0135:
      006BC5 89 82            [24] 4266 	mov	dpl,r1
      006BC7 8A 83            [24] 4267 	mov	dph,r2
      006BC9 F0               [24] 4268 	movx	@dptr,a
      006BCA 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0158
      006BCB                       4273 _ak820_outline_0158:
      006BCB 90 07 71         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      006BCE E0               [24] 4275 	movx	a,@dptr
      006BCF FF               [12] 4276 	mov	r7,a
      006BD0 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0160
      006BD1                       4281 _ak820_outline_0160:
      006BD1 90 07 6F         [24] 4282 	mov	dptr,#_raw_state
      006BD4 E0               [24] 4283 	movx	a,@dptr
      006BD5 FF               [12] 4284 	mov	r7,a
      006BD6 22               [24] 4285 	ret
