                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      000010                        552 _ak820_tapping_before_sloc0_1_0:
      000010                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      000667                        562 _source_state:
      000667                        563 	.ds 130
      0006E9                        564 _pending_time:
      0006E9                        565 	.ds 2
      0006EB                        566 _pending_code:
      0006EB                        567 	.ds 2
      0006ED                        568 _ak820_tapping_source_PARM_1:
      0006ED                        569 	.ds 2
      0006EF                        570 _hold_PARM_2:
      0006EF                        571 	.ds 1
      0006F0                        572 _hold_code_10000_603:
      0006F0                        573 	.ds 2
      0006F2                        574 _hold_mods_30000_606:
      0006F2                        575 	.ds 1
      0006F3                        576 _commit_pending_id_10000_612:
      0006F3                        577 	.ds 1
      0006F4                        578 _ak820_tapping_before_event_10000_613:
      0006F4                        579 	.ds 2
      0006F6                        580 _ak820_tapping_process_record_10000_624:
      0006F6                        581 	.ds 2
      0006F8                        582 _ak820_tapping_process_code_10000_625:
      0006F8                        583 	.ds 2
      0006FA                        584 _ak820_tapping_process_sc_mods_10000_625:
      0006FA                        585 	.ds 1
      0006FB                        586 _ak820_oneshot_mods::
      0006FB                        587 	.ds 1
      0006FC                        588 _ak820_oneshot_consumed::
      0006FC                        589 	.ds 1
      0006FD                        590 _ak820_oneshot_process_PARM_2:
      0006FD                        591 	.ds 1
      0006FE                        592 _ak820_oneshot_process_PARM_3:
      0006FE                        593 	.ds 1
      0006FF                        594 _ak820_oneshot_process_code_10000_650:
      0006FF                        595 	.ds 2
      000701                        596 _ak820_oneshot_process_mods_10000_651:
      000701                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E9C                        606 _pending:
      000E9C                        607 	.ds 1
      000E9D                        608 _ak820_oneshot_target::
      000E9D                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004940                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004940 90 06 EE         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004943 E0               [24]  656 	movx	a,@dptr
      004944 FF               [12]  657 	mov	r7,a
      004945 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004948                        659 00147$:
      004948 50 14            [24]  660 	jnc	00102$
      00494A 90 06 ED         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      00494D E0               [24]  662 	movx	a,@dptr
      00494E FE               [12]  663 	mov	r6,a
      00494F BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004952                        665 00149$:
      004952 50 0A            [24]  666 	jnc	00102$
      004954 8F 05            [24]  667 	mov	ar5,r7
      004956 ED               [12]  668 	mov	a,r5
      004957 12 38 C2         [24]  669 	lcall	_ak820_outline_0179
      00495A 2E               [12]  670 	add	a,r6
      00495B F5 82            [12]  671 	mov	dpl,a
      00495D 22               [24]  672 	ret
      00495E                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      00495E 90 06 ED         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004961 E0               [24]  676 	movx	a,@dptr
      004962 FE               [12]  677 	mov	r6,a
      004963 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004966                        679 00151$:
      004966 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004968 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      00496B 75 82 80         [24]  683 	mov	dpl, #0x80
      00496E 22               [24]  684 	ret
      00496F                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      00496F BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004972 75 82 81         [24]  688 	mov	dpl, #0x81
      004975 22               [24]  689 	ret
      004976                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004976 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004979 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      00497A                        707 _hold:
      00497A 12 38 81         [24]  708 	lcall	_ak820_outline_0111
      00497D 90 06 F0         [24]  709 	mov	dptr,#_hold_code_10000_603
      004980 12 38 86         [24]  710 	lcall	_ak820_outline_0112
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004983 90 06 F0         [24]  712 	mov	dptr,#_hold_code_10000_603
      004986 12 4D E6         [24]  713 	lcall	_ak820_outline_0010
      004989 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      00498B 2D               [12]  715 	add	a,r5
      00498C 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      00498E 8F 05            [24]  718 	mov	ar5,r7
      004990 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004993 90 06 F2         [24]  720 	mov	dptr,#_hold_mods_30000_606
      004996 ED               [12]  721 	mov	a,r5
      004997 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004998 ED               [12]  724 	mov	a,r5
      004999 30 E4 08         [24]  725 	jnb	acc.4,00102$
      00499C ED               [12]  726 	mov	a,r5
      00499D C4               [12]  727 	swap	a
      00499E 54 F0            [12]  728 	anl	a,#0xf0
      0049A0 90 06 F2         [24]  729 	mov	dptr,#_hold_mods_30000_606
      0049A3 F0               [24]  730 	movx	@dptr,a
      0049A4                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0049A4 90 06 EF         [24]  733 	mov	dptr,#_hold_PARM_2
      0049A7 E0               [24]  734 	movx	a,@dptr
      0049A8 60 09            [24]  735 	jz	00104$
      0049AA 90 06 F2         [24]  736 	mov	dptr,#_hold_mods_30000_606
      0049AD E0               [24]  737 	movx	a,@dptr
      0049AE F5 82            [12]  738 	mov	dpl,a
      0049B0 02 7B 3A         [24]  739 	ljmp	_register_mods
      0049B3                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0049B3 90 06 F2         [24]  742 	mov	dptr,#_hold_mods_30000_606
      0049B6 E0               [24]  743 	movx	a,@dptr
      0049B7 F5 82            [12]  744 	mov	dpl,a
      0049B9 02 7B 4E         [24]  745 	ljmp	_unregister_mods
      0049BC                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      0049BC 8F 06            [24]  748 	mov	ar6,r7
      0049BE 74 0F            [12]  749 	mov	a,#0x0f
      0049C0 5E               [12]  750 	anl	a,r6
      0049C1 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      0049C2 90 06 EF         [24]  753 	mov	dptr,#_hold_PARM_2
      0049C5 E0               [24]  754 	movx	a,@dptr
      0049C6 60 05            [24]  755 	jz	00107$
      0049C8 8F 82            [24]  756 	mov	dpl, r7
      0049CA 02 7D 22         [24]  757 	ljmp	_layer_hold_on
      0049CD                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0049CD 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0049CF 02 7D 59         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      0049D2                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0049D2 90 0E 9C         [24]  774 	mov	dptr,#_pending
      0049D5 E0               [24]  775 	movx	a,@dptr
      0049D6 90 06 F3         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      0049D9 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0049DA 12 4E 3A         [24]  779 	lcall	_ak820_outline_0162
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0049DD 90 06 F3         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      0049E0 E0               [24]  782 	movx	a,@dptr
      0049E1 24 67            [12]  783 	add	a,#_source_state
      0049E3 FF               [12]  784 	mov	r7,a
      0049E4 E4               [12]  785 	clr	a
      0049E5 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      0049E7 FE               [12]  787 	mov	r6,a
      0049E8 12 43 74         [24]  788 	lcall	_ak820_outline_0163
      0049EB E0               [24]  789 	movx	a,@dptr
      0049EC FD               [12]  790 	mov	r5,a
      0049ED 43 05 04         [24]  791 	orl	ar5,#0x04
      0049F0 12 43 74         [24]  792 	lcall	_ak820_outline_0163
      0049F3 ED               [12]  793 	mov	a,r5
      0049F4 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      0049F5 90 06 EB         [24]  796 	mov	dptr,#_pending_code
      0049F8 12 38 2D         [24]  797 	lcall	_ak820_outline_0058
      0049FB 90 06 EF         [24]  798 	mov	dptr,#_hold_PARM_2
      0049FE 74 01            [12]  799 	mov	a,#0x01
      004A00 12 43 46         [24]  800 	lcall	_ak820_outline_0071
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004A03 21 7A            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      004A05                        813 _ak820_tapping_before:
      004A05 12 38 81         [24]  814 	lcall	_ak820_outline_0111
      004A08 90 06 F4         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A0B 12 38 86         [24]  816 	lcall	_ak820_outline_0112
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004A0E 90 06 F4         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A11 12 4D E6         [24]  819 	lcall	_ak820_outline_0010
      004A14 12 4D FF         [24]  820 	lcall	_ak820_outline_0027
      004A17 C0 07            [24]  821 	push	ar7
      004A19 C0 06            [24]  822 	push	ar6
      004A1B 12 BE 8E         [24]  823 	lcall	___memcpy
      004A1E 31 40            [12]  824 	acall	_ak820_tapping_source
      004A20 AD 82            [24]  825 	mov	r5, dpl
      004A22 D0 06            [24]  826 	pop	ar6
      004A24 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004A26 90 0F 0D         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004A29 E0               [24]  830 	movx	a,@dptr
      004A2A 60 29            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004A2C 74 04            [12]  833 	mov	a,#0x04
      004A2E 12 48 A1         [24]  834 	lcall	_ak820_outline_0012
      004A31 60 1E            [24]  835 	jz	00102$
      004A33 BD FF 02         [24]  836 	cjne	r5,#0xff,00218$
      004A36 80 19            [24]  837 	sjmp	00102$
      004A38                        838 00218$:
      004A38 74 05            [12]  839 	mov	a,#0x05
      004A3A 12 48 A1         [24]  840 	lcall	_ak820_outline_0012
      004A3D 70 12            [24]  841 	jnz	00102$
      004A3F ED               [12]  842 	mov	a,r5
      004A40 24 67            [12]  843 	add	a, #_source_state
      004A42 FB               [12]  844 	mov	r3,a
      004A43 E4               [12]  845 	clr	a
      004A44 34 06            [12]  846 	addc	a, #(_source_state >> 8)
      004A46 12 49 07         [24]  847 	lcall	_ak820_outline_0052
      004A49 53 02 FD         [24]  848 	anl	ar2,#0xfd
      004A4C 12 33 FC         [24]  849 	lcall	_ak820_outline_0131
      004A4F EA               [12]  850 	mov	a,r2
      004A50 F0               [24]  851 	movx	@dptr,a
      004A51                        852 00102$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004A51 75 82 00         [24]  854 	mov	dpl, #0x00
      004A54 22               [24]  855 	ret
      004A55                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004A55 90 0E 9C         [24]  858 	mov	dptr,#_pending
      004A58 E0               [24]  859 	movx	a,@dptr
      004A59 FC               [12]  860 	mov	r4,a
      004A5A BC FF 02         [24]  861 	cjne	r4,#0xff,00220$
      004A5D 80 3A            [24]  862 	sjmp	00108$
      004A5F                        863 00220$:
      004A5F 12 38 25         [24]  864 	lcall	_ak820_outline_0035
      004A62 FA               [12]  865 	mov	r2,a
      004A63 A3               [24]  866 	inc	dptr
      004A64 E0               [24]  867 	movx	a,@dptr
      004A65 FB               [12]  868 	mov	r3,a
      004A66 90 06 E9         [24]  869 	mov	dptr,#_pending_time
      004A69 12 38 6F         [24]  870 	lcall	_ak820_outline_0104
      004A6C EA               [12]  871 	mov	a,r2
      004A6D C3               [12]  872 	clr	c
      004A6E 98               [12]  873 	subb	a,r0
      004A6F FA               [12]  874 	mov	r2,a
      004A70 EB               [12]  875 	mov	a,r3
      004A71 99               [12]  876 	subb	a,r1
      004A72 FB               [12]  877 	mov	r3,a
      004A73 C3               [12]  878 	clr	c
      004A74 EA               [12]  879 	mov	a,r2
      004A75 94 C8            [12]  880 	subb	a,#0xc8
      004A77 EB               [12]  881 	mov	a,r3
      004A78 94 00            [12]  882 	subb	a,#0x00
      004A7A 50 17            [24]  883 	jnc	00107$
                                    884 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004A7C 74 04            [12]  885 	mov	a,#0x04
      004A7E 12 48 C0         [24]  886 	lcall	_ak820_outline_0021
      004A81 60 16            [24]  887 	jz	00108$
      004A83 12 37 E0         [24]  888 	lcall	_ak820_outline_0005
      004A86 60 11            [24]  889 	jz	00108$
      004A88 BD FF 02         [24]  890 	cjne	r5,#0xff,00224$
      004A8B 80 06            [24]  891 	sjmp	00107$
      004A8D                        892 00224$:
      004A8D ED               [12]  893 	mov	a,r5
      004A8E B5 04 02         [24]  894 	cjne	a,ar4,00225$
      004A91 80 06            [24]  895 	sjmp	00108$
      004A93                        896 00225$:
      004A93                        897 00107$:
      004A93 C0 05            [24]  898 	push	ar5
      004A95 31 D2            [12]  899 	acall	_commit_pending
      004A97 D0 05            [24]  900 	pop	ar5
      004A99                        901 00108$:
                                    902 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004A99 90 06 F4         [24]  903 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A9C 12 38 2D         [24]  904 	lcall	_ak820_outline_0058
      004A9F 74 04            [12]  905 	mov	a,#0x04
      004AA1 12 48 A1         [24]  906 	lcall	_ak820_outline_0012
      004AA4 60 03            [24]  907 	jz	00114$
      004AA6 BD FF 04         [24]  908 	cjne	r5,#0xff,00115$
      004AA9                        909 00114$:
      004AA9 75 82 01         [24]  910 	mov	dpl, #0x01
      004AAC 22               [24]  911 	ret
      004AAD                        912 00115$:
                                    913 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004AAD ED               [12]  914 	mov	a,r5
      004AAE 24 67            [12]  915 	add	a, #_source_state
      004AB0 FC               [12]  916 	mov	r4,a
      004AB1 E4               [12]  917 	clr	a
      004AB2 34 06            [12]  918 	addc	a, #(_source_state >> 8)
      004AB4 FD               [12]  919 	mov	r5,a
      004AB5 12 43 52         [24]  920 	lcall	_ak820_outline_0085
      004AB8 FB               [12]  921 	mov	r3,a
      004AB9 30 E1 13         [24]  922 	jnb	acc.1,00120$
                                    923 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004ABC 74 05            [12]  924 	mov	a,#0x05
      004ABE 2E               [12]  925 	add	a, r6
      004ABF 12 38 0B         [24]  926 	lcall	_ak820_outline_0019
      004AC2 70 07            [24]  927 	jnz	00118$
      004AC4 74 FD            [12]  928 	mov	a,#0xfd
      004AC6 5B               [12]  929 	anl	a,r3
      004AC7 12 38 A3         [24]  930 	lcall	_ak820_outline_0132
      004ACA F0               [24]  931 	movx	@dptr,a
      004ACB                        932 00118$:
                                    933 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004ACB 75 82 00         [24]  934 	mov	dpl, #0x00
      004ACE 22               [24]  935 	ret
      004ACF                        936 00120$:
                                    937 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004ACF 12 43 09         [24]  938 	lcall	_ak820_outline_0014
      004AD2 E0               [24]  939 	movx	a,@dptr
      004AD3 FF               [12]  940 	mov	r7,a
      004AD4 8B 06            [24]  941 	mov	ar6,r3
      004AD6 53 06 01         [24]  942 	anl	ar6,#0x01
      004AD9 EE               [12]  943 	mov	a,r6
      004ADA B4 01 00         [24]  944 	cjne	a,#0x01,00231$
      004ADD                        945 00231$:
      004ADD B3               [12]  946 	cpl	c
      004ADE 92 10            [24]  947 	mov	_ak820_tapping_before_sloc0_1_0,c
      004AE0 8F F0            [24]  948 	mov	b,r7
      004AE2 E4               [12]  949 	clr	a
      004AE3 33               [12]  950 	rlc	a
      004AE4 B5 F0 04         [24]  951 	cjne	a,b,00122$
      004AE7 75 82 00         [24]  952 	mov	dpl, #0x00
      004AEA 22               [24]  953 	ret
      004AEB                        954 00122$:
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004AEB 63 03 01         [24]  956 	xrl	ar3,#0x01
      004AEE 12 38 A3         [24]  957 	lcall	_ak820_outline_0132
      004AF1 EB               [12]  958 	mov	a,r3
      004AF2 F0               [24]  959 	movx	@dptr,a
                                    960 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004AF3 75 82 01         [24]  961 	mov	dpl, #0x01
                                    962 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004AF6 22               [24]  963 	ret
                                    964 ;------------------------------------------------------------
                                    965 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    966 ;------------------------------------------------------------
                                    967 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    968 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    969 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    970 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    971 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    972 ;------------------------------------------------------------
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    974 ;	-----------------------------------------
                                    975 ;	 function ak820_tapping_process
                                    976 ;	-----------------------------------------
      004AF7                        977 _ak820_tapping_process:
      004AF7 12 38 81         [24]  978 	lcall	_ak820_outline_0111
      004AFA 90 06 F6         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004AFD 12 38 86         [24]  980 	lcall	_ak820_outline_0112
                                    981 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004B00 90 06 FA         [24]  982 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B03 E4               [12]  983 	clr	a
      004B04 F0               [24]  984 	movx	@dptr,a
                                    985 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004B05 90 06 F6         [24]  986 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B08 12 38 2D         [24]  987 	lcall	_ak820_outline_0058
      004B0B 74 04            [12]  988 	mov	a,#0x04
      004B0D 12 48 AC         [24]  989 	lcall	_ak820_outline_0013
      004B10 70 04            [24]  990 	jnz	00102$
      004B12 75 82 01         [24]  991 	mov	dpl, #0x01
      004B15 22               [24]  992 	ret
      004B16                        993 00102$:
                                    994 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004B16 8E 04            [24]  995 	mov	ar4,r6
      004B18 8F 05            [24]  996 	mov	ar5,r7
      004B1A 12 4D FF         [24]  997 	lcall	_ak820_outline_0027
      004B1D C0 07            [24]  998 	push	ar7
      004B1F C0 06            [24]  999 	push	ar6
      004B21 12 BE 8E         [24] 1000 	lcall	___memcpy
      004B24 31 40            [12] 1001 	acall	_ak820_tapping_source
      004B26 AD 82            [24] 1002 	mov	r5, dpl
      004B28 D0 06            [24] 1003 	pop	ar6
      004B2A D0 07            [24] 1004 	pop	ar7
                                   1005 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004B2C BD FF 04         [24] 1006 	cjne	r5,#0xff,00104$
      004B2F 75 82 01         [24] 1007 	mov	dpl, #0x01
      004B32 22               [24] 1008 	ret
      004B33                       1009 00104$:
                                   1010 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004B33 74 07            [12] 1011 	mov	a,#0x07
      004B35 12 38 1D         [24] 1012 	lcall	_ak820_outline_0026
      004B38 12 38 2D         [24] 1013 	lcall	_ak820_outline_0058
      004B3B 90 06 F8         [24] 1014 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B3E 12 49 1A         [24] 1015 	lcall	_ak820_outline_0064
                                   1016 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004B41 BE 1A 15         [24] 1017 	cjne	r6,#0x1a,00111$
      004B44 BF 7C 12         [24] 1018 	cjne	r7,#0x7c,00111$
      004B47 90 06 F8         [24] 1019 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B4A 74 26            [12] 1020 	mov	a,#0x26
      004B4C F0               [24] 1021 	movx	@dptr,a
      004B4D 74 22            [12] 1022 	mov	a,#0x22
      004B4F A3               [24] 1023 	inc	dptr
      004B50 F0               [24] 1024 	movx	@dptr,a
      004B51 90 06 FA         [24] 1025 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B54 74 02            [12] 1026 	mov	a,#0x02
      004B56 F0               [24] 1027 	movx	@dptr,a
      004B57 80 28            [24] 1028 	sjmp	00112$
      004B59                       1029 00111$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004B59 BE 1B 15         [24] 1031 	cjne	r6,#0x1b,00108$
      004B5C BF 7C 12         [24] 1032 	cjne	r7,#0x7c,00108$
      004B5F 90 06 F8         [24] 1033 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B62 74 27            [12] 1034 	mov	a,#0x27
      004B64 F0               [24] 1035 	movx	@dptr,a
      004B65 74 32            [12] 1036 	mov	a,#0x32
      004B67 A3               [24] 1037 	inc	dptr
      004B68 F0               [24] 1038 	movx	@dptr,a
      004B69 90 06 FA         [24] 1039 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B6C 74 20            [12] 1040 	mov	a,#0x20
      004B6E F0               [24] 1041 	movx	@dptr,a
      004B6F 80 10            [24] 1042 	sjmp	00112$
      004B71                       1043 00108$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004B71 BE 1E 0D         [24] 1045 	cjne	r6,#0x1e,00112$
      004B74 BF 7C 0A         [24] 1046 	cjne	r7,#0x7c,00112$
      004B77 90 06 F8         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B7A 74 28            [12] 1048 	mov	a,#0x28
      004B7C F0               [24] 1049 	movx	@dptr,a
      004B7D 74 32            [12] 1050 	mov	a,#0x32
      004B7F A3               [24] 1051 	inc	dptr
      004B80 F0               [24] 1052 	movx	@dptr,a
      004B81                       1053 00112$:
                                   1054 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004B81 90 06 F8         [24] 1055 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B84 E0               [24] 1056 	movx	a,@dptr
      004B85 A3               [24] 1057 	inc	dptr
      004B86 E0               [24] 1058 	movx	a,@dptr
      004B87 FF               [12] 1059 	mov	r7,a
                                   1060 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004B88 BF 20 00         [24] 1061 	cjne	r7,#0x20,00242$
      004B8B                       1062 00242$:
      004B8B 40 05            [24] 1063 	jc	00113$
      004B8D BF 50 00         [24] 1064 	cjne	r7,#0x50,00244$
      004B90                       1065 00244$:
      004B90 40 04            [24] 1066 	jc	00114$
      004B92                       1067 00113$:
      004B92 75 82 01         [24] 1068 	mov	dpl, #0x01
      004B95 22               [24] 1069 	ret
      004B96                       1070 00114$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004B96 BF 40 00         [24] 1072 	cjne	r7,#0x40,00246$
      004B99                       1073 00246$:
      004B99 40 0C            [24] 1074 	jc	00117$
      004B9B 53 07 0F         [24] 1075 	anl	ar7,#0x0f
      004B9E BF 06 00         [24] 1076 	cjne	r7,#0x06,00248$
      004BA1                       1077 00248$:
      004BA1 40 04            [24] 1078 	jc	00117$
      004BA3 75 82 00         [24] 1079 	mov	dpl, #0x00
      004BA6 22               [24] 1080 	ret
      004BA7                       1081 00117$:
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004BA7 90 06 F6         [24] 1083 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004BAA 12 38 2D         [24] 1084 	lcall	_ak820_outline_0058
      004BAD 74 05            [12] 1085 	mov	a,#0x05
      004BAF 12 48 A1         [24] 1086 	lcall	_ak820_outline_0012
      004BB2 60 20            [24] 1087 	jz	00131$
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004BB4 90 0E 9C         [24] 1089 	mov	dptr,#_pending
      004BB7 ED               [12] 1090 	mov	a,r5
      004BB8 F0               [24] 1091 	movx	@dptr,a
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004BB9 12 38 25         [24] 1093 	lcall	_ak820_outline_0035
      004BBC FE               [12] 1094 	mov	r6,a
      004BBD A3               [24] 1095 	inc	dptr
      004BBE E0               [24] 1096 	movx	a,@dptr
      004BBF FF               [12] 1097 	mov	r7,a
      004BC0 90 06 E9         [24] 1098 	mov	dptr,#_pending_time
      004BC3 12 49 1A         [24] 1099 	lcall	_ak820_outline_0064
                                   1100 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004BC6 90 06 F8         [24] 1101 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BC9 12 38 2D         [24] 1102 	lcall	_ak820_outline_0058
      004BCC 90 06 EB         [24] 1103 	mov	dptr,#_pending_code
      004BCF 12 49 1A         [24] 1104 	lcall	_ak820_outline_0064
      004BD2 81 81            [12] 1105 	ajmp	00132$
      004BD4                       1106 00131$:
                                   1107 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004BD4 90 0E 9C         [24] 1108 	mov	dptr,#_pending
      004BD7 E0               [24] 1109 	movx	a,@dptr
      004BD8 FF               [12] 1110 	mov	r7,a
      004BD9 ED               [12] 1111 	mov	a,r5
      004BDA B5 07 02         [24] 1112 	cjne	a,ar7,00251$
      004BDD 80 02            [24] 1113 	sjmp	00252$
      004BDF                       1114 00251$:
      004BDF 81 5B            [12] 1115 	ajmp	00128$
      004BE1                       1116 00252$:
                                   1117 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004BE1 12 4E 3A         [24] 1118 	lcall	_ak820_outline_0162
                                   1119 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004BE4 90 06 FA         [24] 1120 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004BE7 E0               [24] 1121 	movx	a,@dptr
      004BE8 FF               [12] 1122 	mov	r7,a
      004BE9 E0               [24] 1123 	movx	a,@dptr
      004BEA 60 05            [24] 1124 	jz	00120$
      004BEC 8F 82            [24] 1125 	mov	dpl, r7
      004BEE 12 81 97         [24] 1126 	lcall	_add_owned_mods
      004BF1                       1127 00120$:
                                   1128 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004BF1 90 06 F6         [24] 1129 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004BF4 12 38 2D         [24] 1130 	lcall	_ak820_outline_0058
      004BF7 74 07            [12] 1131 	mov	a,#0x07
      004BF9 12 4E 34         [24] 1132 	lcall	_ak820_outline_0145
      004BFC 90 06 F8         [24] 1133 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BFF E0               [24] 1134 	movx	a,@dptr
      004C00 F9               [12] 1135 	mov	r1,a
      004C01 7A 00            [12] 1136 	mov	r2,#0x00
      004C03 12 33 FC         [24] 1137 	lcall	_ak820_outline_0131
      004C06 12 4E 27         [24] 1138 	lcall	_ak820_outline_0102
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004C09 C3               [12] 1140 	clr	c
      004C0A 04               [12] 1141 	inc	a
      004C0B 99               [12] 1142 	subb	a,r1
      004C0C 50 3B            [24] 1143 	jnc	00122$
                                   1144 ;	free result
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004C0E 74 06            [12] 1146 	mov	a,#0x06
      004C10 12 38 1D         [24] 1147 	lcall	_ak820_outline_0026
      004C13 E0               [24] 1148 	movx	a,@dptr
      004C14 54 0F            [12] 1149 	anl	a,#0x0f
      004C16 44 10            [12] 1150 	orl	a,#0x10
      004C18 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004C19 74 05            [12] 1153 	mov	a,#0x05
      004C1B 12 4E 34         [24] 1154 	lcall	_ak820_outline_0145
      004C1E 12 33 FC         [24] 1155 	lcall	_ak820_outline_0131
      004C21 74 01            [12] 1156 	mov	a,#0x01
      004C23 F0               [24] 1157 	movx	@dptr,a
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004C24 12 4E 19         [24] 1159 	lcall	_ak820_outline_0080
      004C27 12 4E 2D         [24] 1160 	lcall	_ak820_outline_0116
      004C2A C0 07            [24] 1161 	push	ar7
      004C2C C0 06            [24] 1162 	push	ar6
      004C2E C0 04            [24] 1163 	push	ar4
      004C30 C0 03            [24] 1164 	push	ar3
      004C32 12 75 E1         [24] 1165 	lcall	_process_record
      004C35 D0 03            [24] 1166 	pop	ar3
      004C37 D0 04            [24] 1167 	pop	ar4
      004C39 D0 06            [24] 1168 	pop	ar6
      004C3B D0 07            [24] 1169 	pop	ar7
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004C3D 12 38 62         [24] 1171 	lcall	_ak820_outline_0098
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004C40 FC               [12] 1173 	mov	r4,a
      004C41 12 38 92         [24] 1174 	lcall	_ak820_outline_0124
      004C44 8C F0            [24] 1175 	mov	b, r4
      004C46 12 75 E1         [24] 1176 	lcall	_process_record
      004C49                       1177 00122$:
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004C49 90 06 FA         [24] 1179 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004C4C E0               [24] 1180 	movx	a,@dptr
      004C4D FF               [12] 1181 	mov	r7,a
      004C4E E0               [24] 1182 	movx	a,@dptr
      004C4F 60 30            [24] 1183 	jz	00132$
                                   1184 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004C51 8F 82            [24] 1185 	mov	dpl, r7
      004C53 12 81 A6         [24] 1186 	lcall	_del_owned_mods
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004C56 12 84 C9         [24] 1188 	lcall	_send_keyboard_report
      004C59 80 26            [24] 1189 	sjmp	00132$
      004C5B                       1190 00128$:
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004C5B ED               [12] 1192 	mov	a,r5
      004C5C 24 67            [12] 1193 	add	a, #_source_state
      004C5E FE               [12] 1194 	mov	r6,a
      004C5F E4               [12] 1195 	clr	a
      004C60 34 06            [12] 1196 	addc	a, #(_source_state >> 8)
      004C62 FF               [12] 1197 	mov	r7,a
      004C63 12 38 69         [24] 1198 	lcall	_ak820_outline_0103
      004C66 FD               [12] 1199 	mov	r5,a
      004C67 30 E2 17         [24] 1200 	jnb	acc.2,00132$
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004C6A 53 05 FB         [24] 1202 	anl	ar5,#0xfb
      004C6D 12 38 92         [24] 1203 	lcall	_ak820_outline_0124
      004C70 ED               [12] 1204 	mov	a,r5
      004C71 F0               [24] 1205 	movx	@dptr,a
                                   1206 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004C72 90 06 F8         [24] 1207 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C75 12 38 2D         [24] 1208 	lcall	_ak820_outline_0058
      004C78 90 06 EF         [24] 1209 	mov	dptr,#_hold_PARM_2
      004C7B E4               [12] 1210 	clr	a
      004C7C 12 43 46         [24] 1211 	lcall	_ak820_outline_0071
      004C7F 31 7A            [12] 1212 	acall	_hold
      004C81                       1213 00132$:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004C81 75 82 00         [24] 1215 	mov	dpl, #0x00
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004C84 22               [24] 1217 	ret
                                   1218 ;------------------------------------------------------------
                                   1219 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1220 ;------------------------------------------------------------
                                   1221 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1222 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1223 ;------------------------------------------------------------
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1225 ;	-----------------------------------------
                                   1226 ;	 function ak820_tapping_cancel
                                   1227 ;	-----------------------------------------
      004C85                       1228 _ak820_tapping_cancel:
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004C85 12 4E 3A         [24] 1230 	lcall	_ak820_outline_0162
                                   1231 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004C88 7F 00            [12] 1232 	mov	r7,#0x00
      004C8A                       1233 00103$:
      004C8A BF 82 00         [24] 1234 	cjne	r7,#0x82,00122$
      004C8D                       1235 00122$:
      004C8D 50 16            [24] 1236 	jnc	00105$
                                   1237 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004C8F 12 4D F0         [24] 1238 	lcall	_ak820_outline_0024
                                   1239 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004C92 74 02            [12] 1240 	mov	a,#0x02
      004C94 5C               [12] 1241 	anl	a,r4
      004C95 FB               [12] 1242 	mov	r3,a
      004C96 53 04 01         [24] 1243 	anl	ar4,#0x01
      004C99 EC               [12] 1244 	mov	a,r4
      004C9A 2C               [12] 1245 	add	a,r4
      004C9B 42 03            [12] 1246 	orl	ar3,a
      004C9D 12 38 B2         [24] 1247 	lcall	_ak820_outline_0143
      004CA0 EB               [12] 1248 	mov	a,r3
      004CA1 F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004CA2 0F               [12] 1251 	inc	r7
      004CA3 80 E5            [24] 1252 	sjmp	00103$
      004CA5                       1253 00105$:
                                   1254 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004CA5 22               [24] 1255 	ret
                                   1256 ;------------------------------------------------------------
                                   1257 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1258 ;------------------------------------------------------------
                                   1259 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1260 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1261 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1262 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1263 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1264 ;------------------------------------------------------------
                                   1265 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1266 ;	-----------------------------------------
                                   1267 ;	 function ak820_oneshot_process
                                   1268 ;	-----------------------------------------
      004CA6                       1269 _ak820_oneshot_process:
      004CA6 12 38 81         [24] 1270 	lcall	_ak820_outline_0111
      004CA9 90 06 FF         [24] 1271 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004CAC 12 38 86         [24] 1272 	lcall	_ak820_outline_0112
                                   1273 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004CAF 90 06 FD         [24] 1274 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004CB2 E0               [24] 1275 	movx	a,@dptr
      004CB3 FF               [12] 1276 	mov	r7,a
      004CB4 BF FF 02         [24] 1277 	cjne	r7,#0xff,00248$
      004CB7 80 0B            [24] 1278 	sjmp	00101$
      004CB9                       1279 00248$:
      004CB9 C0 07            [24] 1280 	push	ar7
      004CBB 12 A7 C3         [24] 1281 	lcall	_get_repeat_key_count
      004CBE E5 82            [12] 1282 	mov	a, dpl
      004CC0 D0 07            [24] 1283 	pop	ar7
      004CC2 60 04            [24] 1284 	jz	00102$
      004CC4                       1285 00101$:
      004CC4 75 82 01         [24] 1286 	mov	dpl, #0x01
      004CC7 22               [24] 1287 	ret
      004CC8                       1288 00102$:
                                   1289 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004CC8 90 06 FF         [24] 1290 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004CCB E0               [24] 1291 	movx	a,@dptr
      004CCC FD               [12] 1292 	mov	r5,a
      004CCD A3               [24] 1293 	inc	dptr
      004CCE E0               [24] 1294 	movx	a,@dptr
      004CCF FB               [12] 1295 	mov	r3,a
      004CD0 BB 52 02         [24] 1296 	cjne	r3,#0x52,00250$
      004CD3 80 02            [24] 1297 	sjmp	00251$
      004CD5                       1298 00250$:
      004CD5 A1 78            [12] 1299 	ajmp	00116$
      004CD7                       1300 00251$:
      004CD7 8D 04            [24] 1301 	mov	ar4,r5
      004CD9 53 04 E0         [24] 1302 	anl	ar4,#0xe0
      004CDC BC A0 02         [24] 1303 	cjne	r4,#0xa0,00252$
      004CDF 80 02            [24] 1304 	sjmp	00253$
      004CE1                       1305 00252$:
      004CE1 A1 78            [12] 1306 	ajmp	00116$
      004CE3                       1307 00253$:
                                   1308 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004CE3 8D 04            [24] 1309 	mov	ar4,r5
      004CE5 53 04 0F         [24] 1310 	anl	ar4,#0x0f
      004CE8 90 07 01         [24] 1311 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CEB EC               [12] 1312 	mov	a,r4
      004CEC F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004CED ED               [12] 1315 	mov	a,r5
      004CEE 30 E4 08         [24] 1316 	jnb	acc.4,00105$
      004CF1 EC               [12] 1317 	mov	a,r4
      004CF2 C4               [12] 1318 	swap	a
      004CF3 54 F0            [12] 1319 	anl	a,#0xf0
      004CF5 90 07 01         [24] 1320 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CF8 F0               [24] 1321 	movx	@dptr,a
      004CF9                       1322 00105$:
                                   1323 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004CF9 90 06 FE         [24] 1324 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004CFC E0               [24] 1325 	movx	a,@dptr
      004CFD 60 2D            [24] 1326 	jz	00113$
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004CFF 12 4D F0         [24] 1328 	lcall	_ak820_outline_0024
      004D02 43 04 08         [24] 1329 	orl	ar4,#0x08
      004D05 12 43 3F         [24] 1330 	lcall	_ak820_outline_0069
                                   1331 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004D08 53 04 EF         [24] 1332 	anl	ar4,#0xef
      004D0B 12 43 3F         [24] 1333 	lcall	_ak820_outline_0069
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004D0E 90 0E 9D         [24] 1335 	mov	dptr,#_ak820_oneshot_target
      004D11 E0               [24] 1336 	movx	a,@dptr
      004D12 FC               [12] 1337 	mov	r4,a
      004D13 BC FF 02         [24] 1338 	cjne	r4,#0xff,00256$
      004D16 80 09            [24] 1339 	sjmp	00107$
      004D18                       1340 00256$:
      004D18 12 4E 20         [24] 1341 	lcall	_ak820_outline_0081
      004D1B 43 04 10         [24] 1342 	orl	ar4,#0x10
      004D1E 12 43 3F         [24] 1343 	lcall	_ak820_outline_0069
      004D21                       1344 00107$:
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004D21 90 07 01         [24] 1346 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D24 E0               [24] 1347 	movx	a,@dptr
      004D25 F5 82            [12] 1348 	mov	dpl,a
      004D27 12 7B 3A         [24] 1349 	lcall	_register_mods
      004D2A 80 48            [24] 1350 	sjmp	00114$
      004D2C                       1351 00113$:
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004D2C 12 4D F0         [24] 1353 	lcall	_ak820_outline_0024
      004D2F 30 E3 42         [24] 1354 	jnb	acc.3,00114$
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004D32 EC               [12] 1356 	mov	a,r4
      004D33 20 E4 24         [24] 1357 	jb	acc.4,00109$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004D36 90 06 FB         [24] 1359 	mov	dptr,#_ak820_oneshot_mods
      004D39 E0               [24] 1360 	movx	a,@dptr
      004D3A F4               [12] 1361 	cpl	a
      004D3B FC               [12] 1362 	mov	r4,a
      004D3C 90 07 01         [24] 1363 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D3F E0               [24] 1364 	movx	a,@dptr
      004D40 FB               [12] 1365 	mov	r3,a
      004D41 52 04            [12] 1366 	anl	ar4,a
      004D43 8C 82            [24] 1367 	mov	dpl, r4
      004D45 C0 06            [24] 1368 	push	ar6
      004D47 C0 05            [24] 1369 	push	ar5
      004D49 C0 03            [24] 1370 	push	ar3
      004D4B 12 81 97         [24] 1371 	lcall	_add_owned_mods
      004D4E D0 03            [24] 1372 	pop	ar3
      004D50 D0 05            [24] 1373 	pop	ar5
      004D52 D0 06            [24] 1374 	pop	ar6
                                   1375 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004D54 90 06 FB         [24] 1376 	mov	dptr,#_ak820_oneshot_mods
      004D57 E0               [24] 1377 	movx	a,@dptr
      004D58 4B               [12] 1378 	orl	a,r3
      004D59 F0               [24] 1379 	movx	@dptr,a
      004D5A                       1380 00109$:
                                   1381 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004D5A 90 07 01         [24] 1382 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004D5D E0               [24] 1383 	movx	a,@dptr
      004D5E F5 82            [12] 1384 	mov	dpl,a
      004D60 C0 06            [24] 1385 	push	ar6
      004D62 C0 05            [24] 1386 	push	ar5
      004D64 12 7B 4E         [24] 1387 	lcall	_unregister_mods
      004D67 D0 05            [24] 1388 	pop	ar5
      004D69 D0 06            [24] 1389 	pop	ar6
                                   1390 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004D6B 12 4E 20         [24] 1391 	lcall	_ak820_outline_0081
      004D6E 53 04 E7         [24] 1392 	anl	ar4,#0xe7
      004D71 12 43 3F         [24] 1393 	lcall	_ak820_outline_0069
      004D74                       1394 00114$:
                                   1395 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004D74 75 82 00         [24] 1396 	mov	dpl, #0x00
      004D77 22               [24] 1397 	ret
      004D78                       1398 00116$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004D78 90 06 FE         [24] 1400 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004D7B E0               [24] 1401 	movx	a,@dptr
      004D7C 60 64            [24] 1402 	jz	00124$
      004D7E 90 06 FF         [24] 1403 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004D81 12 38 5C         [24] 1404 	lcall	_ak820_outline_0086
      004D84 C3               [12] 1405 	clr	c
      004D85 74 01            [12] 1406 	mov	a,#0x01
      004D87 9D               [12] 1407 	subb	a,r5
      004D88 E4               [12] 1408 	clr	a
      004D89 9E               [12] 1409 	subb	a,r6
      004D8A 50 56            [24] 1410 	jnc	00124$
                                   1411 ;	free result
                                   1412 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004D8C C3               [12] 1413 	clr	c
      004D8D ED               [12] 1414 	mov	a,r5
      004D8E 94 E0            [12] 1415 	subb	a,#0xe0
      004D90 EE               [12] 1416 	mov	a,r6
      004D91 94 00            [12] 1417 	subb	a,#0x00
      004D93 40 07            [24] 1418 	jc	00129$
      004D95 74 E7            [12] 1419 	mov	a,#0xe7
      004D97 9D               [12] 1420 	subb	a,r5
      004D98 E4               [12] 1421 	clr	a
      004D99 9E               [12] 1422 	subb	a,r6
      004D9A 50 46            [24] 1423 	jnc	00124$
                                   1424 ;	free result
      004D9C                       1425 00129$:
                                   1426 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004D9C 74 AE            [12] 1427 	mov	a,#0x100 - 0x52
      004D9E 2E               [12] 1428 	add	a,r6
      004D9F 50 09            [24] 1429 	jnc	00165$
      004DA1 C3               [12] 1430 	clr	c
      004DA2 74 DF            [12] 1431 	mov	a,#0xdf
      004DA4 9D               [12] 1432 	subb	a,r5
      004DA5 74 52            [12] 1433 	mov	a,#0x52
      004DA7 9E               [12] 1434 	subb	a,r6
      004DA8 50 38            [24] 1435 	jnc	00124$
                                   1436 ;	free result
                                   1437 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004DAA                       1438 00165$:
      004DAA 7E 00            [12] 1439 	mov	r6,#0x00
      004DAC                       1440 00131$:
      004DAC BE 82 00         [24] 1441 	cjne	r6,#0x82,00265$
      004DAF                       1442 00265$:
      004DAF 50 1A            [24] 1443 	jnc	00120$
                                   1444 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004DB1 EE               [12] 1445 	mov	a,r6
      004DB2 24 67            [12] 1446 	add	a, #_source_state
      004DB4 FC               [12] 1447 	mov	r4,a
      004DB5 E4               [12] 1448 	clr	a
      004DB6 34 06            [12] 1449 	addc	a, #(_source_state >> 8)
      004DB8 FD               [12] 1450 	mov	r5,a
      004DB9 12 43 52         [24] 1451 	lcall	_ak820_outline_0085
      004DBC FB               [12] 1452 	mov	r3,a
      004DBD 30 E3 08         [24] 1453 	jnb	acc.3,00132$
      004DC0 43 03 10         [24] 1454 	orl	ar3,#0x10
      004DC3 12 38 A3         [24] 1455 	lcall	_ak820_outline_0132
      004DC6 EB               [12] 1456 	mov	a,r3
      004DC7 F0               [24] 1457 	movx	@dptr,a
      004DC8                       1458 00132$:
                                   1459 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004DC8 0E               [12] 1460 	inc	r6
      004DC9 80 E1            [24] 1461 	sjmp	00131$
      004DCB                       1462 00120$:
                                   1463 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004DCB 90 06 FB         [24] 1464 	mov	dptr,#_ak820_oneshot_mods
      004DCE E0               [24] 1465 	movx	a,@dptr
      004DCF FE               [12] 1466 	mov	r6,a
      004DD0 E0               [24] 1467 	movx	a,@dptr
      004DD1 60 0F            [24] 1468 	jz	00124$
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004DD3 90 06 FC         [24] 1470 	mov	dptr,#_ak820_oneshot_consumed
      004DD6 EE               [12] 1471 	mov	a,r6
      004DD7 F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004DD8 90 0E 9D         [24] 1474 	mov	dptr,#_ak820_oneshot_target
      004DDB EF               [12] 1475 	mov	a,r7
      004DDC F0               [24] 1476 	movx	@dptr,a
                                   1477 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004DDD 90 06 FB         [24] 1478 	mov	dptr,#_ak820_oneshot_mods
      004DE0 E4               [12] 1479 	clr	a
      004DE1 F0               [24] 1480 	movx	@dptr,a
      004DE2                       1481 00124$:
                                   1482 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004DE2 75 82 01         [24] 1483 	mov	dpl, #0x01
                                   1484 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004DE5 22               [24] 1485 	ret
                                   1486 	.area CSEG    (CODE)
                                   1487 	.area CONST   (CODE)
                                   1488 	.area XINIT   (CODE)
      00C74E                       1489 __xinit__pending:
      00C74E FF                    1490 	.db #0xff	; 255
      00C74F                       1491 __xinit__ak820_oneshot_target:
      00C74F FF                    1492 	.db #0xff	; 255
                                   1493 	.area CABS    (ABS,CODE)
                                   1494 
                                   1495 ; Experimental exact instruction outlining.
                                   1496 	.globl _ak820_outline_0005
                                   1497 	.globl _ak820_outline_0010
                                   1498 	.globl _ak820_outline_0012
                                   1499 	.globl _ak820_outline_0013
                                   1500 	.globl _ak820_outline_0014
                                   1501 	.globl _ak820_outline_0019
                                   1502 	.globl _ak820_outline_0021
                                   1503 	.globl _ak820_outline_0024
                                   1504 	.globl _ak820_outline_0026
                                   1505 	.globl _ak820_outline_0027
                                   1506 	.globl _ak820_outline_0035
                                   1507 	.globl _ak820_outline_0052
                                   1508 	.globl _ak820_outline_0058
                                   1509 	.globl _ak820_outline_0064
                                   1510 	.globl _ak820_outline_0069
                                   1511 	.globl _ak820_outline_0071
                                   1512 	.globl _ak820_outline_0080
                                   1513 	.globl _ak820_outline_0081
                                   1514 	.globl _ak820_outline_0085
                                   1515 	.globl _ak820_outline_0086
                                   1516 	.globl _ak820_outline_0098
                                   1517 	.globl _ak820_outline_0102
                                   1518 	.globl _ak820_outline_0103
                                   1519 	.globl _ak820_outline_0104
                                   1520 	.globl _ak820_outline_0111
                                   1521 	.globl _ak820_outline_0112
                                   1522 	.globl _ak820_outline_0116
                                   1523 	.globl _ak820_outline_0124
                                   1524 	.globl _ak820_outline_0131
                                   1525 	.globl _ak820_outline_0132
                                   1526 	.globl _ak820_outline_0143
                                   1527 	.globl _ak820_outline_0145
                                   1528 	.globl _ak820_outline_0162
                                   1529 	.globl _ak820_outline_0163
                                   1530 	.globl _ak820_outline_0179
                                   1531 
                                   1532 	.area CSEG (CODE)
                                   1533 ; function ak820_outline_0010
      004DE6                       1534 _ak820_outline_0010:
      004DE6 E0               [24] 1535 	movx	a,@dptr
      004DE7 FE               [12] 1536 	mov	r6,a
      004DE8 A3               [24] 1537 	inc	dptr
      004DE9 E0               [24] 1538 	movx	a,@dptr
      004DEA FF               [12] 1539 	mov	r7,a
      004DEB 8E 04            [24] 1540 	mov	ar4,r6
      004DED 8F 05            [24] 1541 	mov	ar5,r7
      004DEF 22               [24] 1542 	ret
                                   1543 
                                   1544 	.area CSEG (CODE)
                                   1545 ; function ak820_outline_0024
      004DF0                       1546 _ak820_outline_0024:
      004DF0 EF               [12] 1547 	mov	a,r7
      004DF1 24 67            [12] 1548 	add	a,#_source_state
      004DF3 FD               [12] 1549 	mov	r5,a
      004DF4 E4               [12] 1550 	clr	a
      004DF5 34 06            [12] 1551 	addc	a,#(_source_state>>8)
      004DF7 FE               [12] 1552 	mov	r6,a
      004DF8 8D 82            [24] 1553 	mov	dpl,r5
      004DFA 8E 83            [24] 1554 	mov	dph,r6
      004DFC E0               [24] 1555 	movx	a,@dptr
      004DFD FC               [12] 1556 	mov	r4,a
      004DFE 22               [24] 1557 	ret
                                   1558 
                                   1559 	.area CSEG (CODE)
                                   1560 ; function ak820_outline_0027
      004DFF                       1561 _ak820_outline_0027:
      004DFF 90 0E 8C         [24] 1562 	mov	dptr,#___memcpy_PARM_2
      004E02 EC               [12] 1563 	mov	a,r4
      004E03 F0               [24] 1564 	movx	@dptr,a
      004E04 ED               [12] 1565 	mov	a,r5
      004E05 A3               [24] 1566 	inc	dptr
      004E06 F0               [24] 1567 	movx	@dptr,a
      004E07 E4               [12] 1568 	clr	a
      004E08 A3               [24] 1569 	inc	dptr
      004E09 F0               [24] 1570 	movx	@dptr,a
      004E0A 90 0E 8F         [24] 1571 	mov	dptr,#___memcpy_PARM_3
      004E0D 74 02            [12] 1572 	mov	a,#0x02
      004E0F F0               [24] 1573 	movx	@dptr,a
      004E10 E4               [12] 1574 	clr	a
      004E11 A3               [24] 1575 	inc	dptr
      004E12 F0               [24] 1576 	movx	@dptr,a
      004E13 90 06 ED         [24] 1577 	mov	dptr,#_ak820_tapping_source_PARM_1
      004E16 F5 F0            [12] 1578 	mov	b,a
      004E18 22               [24] 1579 	ret
                                   1580 
                                   1581 	.area CSEG (CODE)
                                   1582 ; function ak820_outline_0080
      004E19                       1583 _ak820_outline_0080:
      004E19 8E 00            [24] 1584 	mov	ar0,r6
      004E1B 8F 01            [24] 1585 	mov	ar1,r7
      004E1D 7A 00            [12] 1586 	mov	r2,#0x00
      004E1F 22               [24] 1587 	ret
                                   1588 
                                   1589 	.area CSEG (CODE)
                                   1590 ; function ak820_outline_0081
      004E20                       1591 _ak820_outline_0081:
      004E20 8D 82            [24] 1592 	mov	dpl,r5
      004E22 8E 83            [24] 1593 	mov	dph,r6
      004E24 E0               [24] 1594 	movx	a,@dptr
      004E25 FC               [12] 1595 	mov	r4,a
      004E26 22               [24] 1596 	ret
                                   1597 
                                   1598 	.area CSEG (CODE)
                                   1599 ; function ak820_outline_0102
      004E27                       1600 _ak820_outline_0102:
      004E27 E9               [12] 1601 	mov	a,r1
      004E28 F0               [24] 1602 	movx	@dptr,a
      004E29 EA               [12] 1603 	mov	a,r2
      004E2A A3               [24] 1604 	inc	dptr
      004E2B F0               [24] 1605 	movx	@dptr,a
      004E2C 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0116
      004E2D                       1610 _ak820_outline_0116:
      004E2D 88 82            [24] 1611 	mov	dpl,r0
      004E2F 89 83            [24] 1612 	mov	dph,r1
      004E31 8A F0            [24] 1613 	mov	b,r2
      004E33 22               [24] 1614 	ret
                                   1615 
                                   1616 	.area CSEG (CODE)
                                   1617 ; function ak820_outline_0145
      004E34                       1618 _ak820_outline_0145:
      004E34 2E               [12] 1619 	add	a,r6
      004E35 FB               [12] 1620 	mov	r3,a
      004E36 E4               [12] 1621 	clr	a
      004E37 3F               [12] 1622 	addc	a,r7
      004E38 FC               [12] 1623 	mov	r4,a
      004E39 22               [24] 1624 	ret
                                   1625 
                                   1626 	.area CSEG (CODE)
                                   1627 ; function ak820_outline_0162
      004E3A                       1628 _ak820_outline_0162:
      004E3A 90 0E 9C         [24] 1629 	mov	dptr,#_pending
      004E3D 74 FF            [12] 1630 	mov	a,#0xff
      004E3F F0               [24] 1631 	movx	@dptr,a
      004E40 22               [24] 1632 	ret
