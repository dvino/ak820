                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B89                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B89 E5 82            [12]  215 	mov	a,dpl
      003B8B 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B8E F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B8F 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003B92 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B95 E0               [24]  221 	movx	a,@dptr
      003B96 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003B99 F0               [24]  223 	movx	@dptr,a
      003B9A                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B9A D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B9C 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B9D                        239 _ak820_nvm_diagnostic:
      003B9D 12 38 81         [24]  240 	lcall	_ak820_outline_0111
      003BA0 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BA3 12 38 86         [24]  242 	lcall	_ak820_outline_0112
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BA6 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BA9 12 38 2D         [24]  245 	lcall	_ak820_outline_0058
      003BAC A2 0B            [12]  246 	mov	c,_storage_failed
      003BAE E4               [12]  247 	clr	a
      003BAF 33               [12]  248 	rlc	a
      003BB0 12 38 92         [24]  249 	lcall	_ak820_outline_0124
      003BB3 12 43 46         [24]  250 	lcall	_ak820_outline_0071
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BB6 A3               [24]  252 	inc	dptr
      003BB7 A2 09            [12]  253 	mov	c,_page_valid
      003BB9 E4               [12]  254 	clr	a
      003BBA 33               [12]  255 	rlc	a
      003BBB 12 43 13         [24]  256 	lcall	_ak820_outline_0037
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BBE A2 0A            [12]  258 	mov	c,_page_dirty
      003BC0 E4               [12]  259 	clr	a
      003BC1 33               [12]  260 	rlc	a
      003BC2 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BC3 74 03            [12]  263 	mov	a,#0x03
      003BC5 12 43 79         [24]  264 	lcall	_ak820_outline_0166
      003BC8 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003BCB E0               [24]  266 	movx	a,@dptr
      003BCC 12 38 A3         [24]  267 	lcall	_ak820_outline_0132
      003BCF F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BD0 74 04            [12]  270 	mov	a,#0x04
      003BD2 12 43 79         [24]  271 	lcall	_ak820_outline_0166
      003BD5 90 05 5D         [24]  272 	mov	dptr,#_cached_page
      003BD8 E0               [24]  273 	movx	a,@dptr
      003BD9 12 38 A3         [24]  274 	lcall	_ak820_outline_0132
      003BDC F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BDD 12 43 09         [24]  277 	lcall	_ak820_outline_0014
      003BE0 E4               [12]  278 	clr	a
      003BE1 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BE2 74 06            [12]  281 	mov	a,#0x06
      003BE4 2E               [12]  282 	add	a, r6
      003BE5 FE               [12]  283 	mov	r6,a
      003BE6 E4               [12]  284 	clr	a
      003BE7 3F               [12]  285 	addc	a, r7
      003BE8 FF               [12]  286 	mov	r7,a
      003BE9 90 05 5F         [24]  287 	mov	dptr,#_first_failure_stage
      003BEC E0               [24]  288 	movx	a,@dptr
      003BED 12 38 92         [24]  289 	lcall	_ak820_outline_0124
      003BF0 F0               [24]  290 	movx	@dptr,a
                                    291 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BF1 22               [24]  292 	ret
                                    293 ;------------------------------------------------------------
                                    294 ;Allocation info for local variables in function 'crc_byte'
                                    295 ;------------------------------------------------------------
                                    296 ;value         Allocated with name '_crc_byte_PARM_2'
                                    297 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    298 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    299 ;------------------------------------------------------------
                                    300 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    301 ;	-----------------------------------------
                                    302 ;	 function crc_byte
                                    303 ;	-----------------------------------------
      003BF2                        304 _crc_byte:
      003BF2 12 38 81         [24]  305 	lcall	_ak820_outline_0111
      003BF5 90 05 64         [24]  306 	mov	dptr,#_crc_byte_crc_10000_25
      003BF8 12 38 86         [24]  307 	lcall	_ak820_outline_0112
                                    308 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BFB 90 05 63         [24]  309 	mov	dptr,#_crc_byte_PARM_2
      003BFE E0               [24]  310 	movx	a,@dptr
      003BFF FF               [12]  311 	mov	r7,a
      003C00 7E 00            [12]  312 	mov	r6,#0x00
      003C02 90 05 64         [24]  313 	mov	dptr,#_crc_byte_crc_10000_25
      003C05 E0               [24]  314 	movx	a,@dptr
      003C06 6E               [12]  315 	xrl	a,r6
      003C07 F0               [24]  316 	movx	@dptr,a
      003C08 A3               [24]  317 	inc	dptr
      003C09 E0               [24]  318 	movx	a,@dptr
      003C0A 6F               [12]  319 	xrl	a,r7
      003C0B F0               [24]  320 	movx	@dptr,a
                                    321 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C0C 7F 00            [12]  322 	mov	r7,#0x00
      003C0E                        323 00102$:
                                    324 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C0E 90 05 64         [24]  325 	mov	dptr,#_crc_byte_crc_10000_25
      003C11 12 38 5C         [24]  326 	lcall	_ak820_outline_0086
      003C14 30 E7 0E         [24]  327 	jnb	acc.7,00106$
      003C17 ED               [12]  328 	mov	a,r5
      003C18 2D               [12]  329 	add	a,r5
      003C19 FB               [12]  330 	mov	r3,a
      003C1A EE               [12]  331 	mov	a,r6
      003C1B 33               [12]  332 	rlc	a
      003C1C FC               [12]  333 	mov	r4,a
      003C1D 63 03 21         [24]  334 	xrl	ar3,#0x21
      003C20 63 04 10         [24]  335 	xrl	ar4,#0x10
      003C23 80 06            [24]  336 	sjmp	00107$
      003C25                        337 00106$:
      003C25 ED               [12]  338 	mov	a,r5
      003C26 2D               [12]  339 	add	a,r5
      003C27 FB               [12]  340 	mov	r3,a
      003C28 EE               [12]  341 	mov	a,r6
      003C29 33               [12]  342 	rlc	a
      003C2A FC               [12]  343 	mov	r4,a
      003C2B                        344 00107$:
      003C2B 90 05 64         [24]  345 	mov	dptr,#_crc_byte_crc_10000_25
      003C2E 12 38 56         [24]  346 	lcall	_ak820_outline_0084
                                    347 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C31 0F               [12]  348 	inc	r7
      003C32 BF 08 D9         [24]  349 	cjne	r7,#0x08,00102$
                                    350 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C35 12 33 FC         [24]  351 	lcall	_ak820_outline_0131
                                    352 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C38 22               [24]  353 	ret
                                    354 ;------------------------------------------------------------
                                    355 ;Allocation info for local variables in function 'page_crc'
                                    356 ;------------------------------------------------------------
                                    357 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    358 ;i             Allocated with name '_page_crc_i_10000_30'
                                    359 ;------------------------------------------------------------
                                    360 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    361 ;	-----------------------------------------
                                    362 ;	 function page_crc
                                    363 ;	-----------------------------------------
      003C39                        364 _page_crc:
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C39 90 05 66         [24]  366 	mov	dptr,#_page_crc_crc_10000_30
      003C3C 74 FF            [12]  367 	mov	a,#0xff
      003C3E F0               [24]  368 	movx	@dptr,a
      003C3F A3               [24]  369 	inc	dptr
      003C40 F0               [24]  370 	movx	@dptr,a
                                    371 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C41 7F 00            [12]  372 	mov	r7,#0x00
      003C43                        373 00102$:
      003C43 90 05 66         [24]  374 	mov	dptr,#_page_crc_crc_10000_30
      003C46 12 38 5C         [24]  375 	lcall	_ak820_outline_0086
      003C49 12 43 58         [24]  376 	lcall	_ak820_outline_0109
      003C4C 90 05 63         [24]  377 	mov	dptr,#_crc_byte_PARM_2
      003C4F F0               [24]  378 	movx	@dptr,a
      003C50 12 38 B2         [24]  379 	lcall	_ak820_outline_0143
      003C53 C0 07            [24]  380 	push	ar7
      003C55 12 3B F2         [24]  381 	lcall	_crc_byte
      003C58 AD 82            [24]  382 	mov	r5, dpl
      003C5A AE 83            [24]  383 	mov	r6, dph
      003C5C D0 07            [24]  384 	pop	ar7
      003C5E 90 05 66         [24]  385 	mov	dptr,#_page_crc_crc_10000_30
      003C61 12 43 7F         [24]  386 	lcall	_ak820_outline_0168
      003C64 0F               [12]  387 	inc	r7
      003C65 BF 40 DB         [24]  388 	cjne	r7,#0x40,00102$
                                    389 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C68 12 38 B2         [24]  390 	lcall	_ak820_outline_0143
                                    391 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C6B 22               [24]  392 	ret
                                    393 ;------------------------------------------------------------
                                    394 ;Allocation info for local variables in function 'write_page'
                                    395 ;------------------------------------------------------------
                                    396 ;address       Allocated with name '_write_page_address_10000_32'
                                    397 ;i             Allocated with name '_write_page_i_10000_33'
                                    398 ;------------------------------------------------------------
                                    399 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    400 ;	-----------------------------------------
                                    401 ;	 function write_page
                                    402 ;	-----------------------------------------
      003C6C                        403 _write_page:
      003C6C 12 38 81         [24]  404 	lcall	_ak820_outline_0111
      003C6F 90 05 68         [24]  405 	mov	dptr,#_write_page_address_10000_32
      003C72 12 38 86         [24]  406 	lcall	_ak820_outline_0112
                                    407 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C75 90 05 68         [24]  408 	mov	dptr,#_write_page_address_10000_32
      003C78 12 37 ED         [24]  409 	lcall	_ak820_outline_0006
      003C7B C0 07            [24]  410 	push	ar7
      003C7D C0 06            [24]  411 	push	ar6
      003C7F 12 3A 02         [24]  412 	lcall	_ak820_flash_erase
      003C82 E5 82            [12]  413 	mov	a, dpl
      003C84 D0 06            [24]  414 	pop	ar6
      003C86 D0 07            [24]  415 	pop	ar7
      003C88 70 03            [24]  416 	jnz	00102$
      003C8A F5 82            [12]  417 	mov	dpl,a
      003C8C 22               [24]  418 	ret
      003C8D                        419 00102$:
                                    420 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C8D 90 04 F9         [24]  421 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C90 74 1D            [12]  422 	mov	a,#_page_data
      003C92 F0               [24]  423 	movx	@dptr,a
      003C93 74 05            [12]  424 	mov	a,#(_page_data >> 8)
      003C95 A3               [24]  425 	inc	dptr
      003C96 12 43 46         [24]  426 	lcall	_ak820_outline_0071
      003C99 12 3B 16         [24]  427 	lcall	_ak820_flash_program_page
      003C9C E5 82            [12]  428 	mov	a, dpl
      003C9E 70 03            [24]  429 	jnz	00120$
      003CA0 F5 82            [12]  430 	mov	dpl,a
                                    431 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CA2 22               [24]  432 	ret
      003CA3                        433 00120$:
      003CA3 7F 00            [12]  434 	mov	r7,#0x00
      003CA5                        435 00108$:
                                    436 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003CA5 8F 05            [24]  437 	mov	ar5,r7
      003CA7 7E 00            [12]  438 	mov	r6,#0x00
      003CA9 90 05 68         [24]  439 	mov	dptr,#_write_page_address_10000_32
      003CAC 12 38 7B         [24]  440 	lcall	_ak820_outline_0107
      003CAF ED               [12]  441 	mov	a,r5
      003CB0 2B               [12]  442 	add	a, r3
      003CB1 FB               [12]  443 	mov	r3,a
      003CB2 EE               [12]  444 	mov	a,r6
      003CB3 3C               [12]  445 	addc	a, r4
      003CB4 FC               [12]  446 	mov	r4,a
      003CB5 12 33 FC         [24]  447 	lcall	_ak820_outline_0131
      003CB8 12 38 F5         [24]  448 	lcall	_ak820_flash_read
      003CBB AE 82            [24]  449 	mov	r6, dpl
      003CBD 12 43 58         [24]  450 	lcall	_ak820_outline_0109
      003CC0 FD               [12]  451 	mov	r5,a
      003CC1 EE               [12]  452 	mov	a,r6
      003CC2 B5 05 02         [24]  453 	cjne	a,ar5,00149$
      003CC5 80 04            [24]  454 	sjmp	00109$
      003CC7                        455 00149$:
      003CC7 75 82 00         [24]  456 	mov	dpl, #0x00
      003CCA 22               [24]  457 	ret
      003CCB                        458 00109$:
                                    459 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CCB 0F               [12]  460 	inc	r7
      003CCC BF 40 D6         [24]  461 	cjne	r7,#0x40,00108$
                                    462 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CCF 75 82 01         [24]  463 	mov	dpl, #0x01
                                    464 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CD2 22               [24]  465 	ret
                                    466 ;------------------------------------------------------------
                                    467 ;Allocation info for local variables in function 'journal_header_valid'
                                    468 ;------------------------------------------------------------
                                    469 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    470 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    471 ;------------------------------------------------------------
                                    472 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    473 ;	-----------------------------------------
                                    474 ;	 function journal_header_valid
                                    475 ;	-----------------------------------------
      003CD3                        476 _journal_header_valid:
      003CD3 12 38 81         [24]  477 	lcall	_ak820_outline_0111
      003CD6 90 05 6A         [24]  478 	mov	dptr,#_journal_header_valid_header_10000_39
      003CD9 12 38 86         [24]  479 	lcall	_ak820_outline_0112
                                    480 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CDC 90 05 6A         [24]  481 	mov	dptr,#_journal_header_valid_header_10000_39
      003CDF 12 37 ED         [24]  482 	lcall	_ak820_outline_0006
      003CE2 E0               [24]  483 	movx	a,@dptr
      003CE3 FD               [12]  484 	mov	r5,a
      003CE4 BD A5 02         [24]  485 	cjne	r5,#0xa5,00138$
      003CE7 80 04            [24]  486 	sjmp	00116$
      003CE9                        487 00138$:
      003CE9 75 82 00         [24]  488 	mov	dpl, #0x00
                                    489 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CEC 22               [24]  490 	ret
      003CED                        491 00116$:
      003CED 7D 01            [12]  492 	mov	r5,#0x01
      003CEF                        493 00106$:
                                    494 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CEF ED               [12]  495 	mov	a,r5
      003CF0 12 38 1D         [24]  496 	lcall	_ak820_outline_0026
      003CF3 E0               [24]  497 	movx	a,@dptr
      003CF4 FC               [12]  498 	mov	r4,a
      003CF5 8D 02            [24]  499 	mov	ar2,r5
      003CF7 7B 00            [12]  500 	mov	r3,#0x00
      003CF9 74 04            [12]  501 	mov	a,#0x04
      003CFB 2A               [12]  502 	add	a, r2
      003CFC FA               [12]  503 	mov	r2,a
      003CFD E4               [12]  504 	clr	a
      003CFE 3B               [12]  505 	addc	a, r3
      003CFF FB               [12]  506 	mov	r3,a
      003D00 EA               [12]  507 	mov	a,r2
      003D01 2E               [12]  508 	add	a, r6
      003D02 F5 82            [12]  509 	mov	dpl,a
      003D04 EB               [12]  510 	mov	a,r3
      003D05 3F               [12]  511 	addc	a, r7
      003D06 F5 83            [12]  512 	mov	dph,a
      003D08 E0               [24]  513 	movx	a,@dptr
      003D09 62 04            [12]  514 	xrl	ar4,a
      003D0B BC FF 02         [24]  515 	cjne	r4,#0xff,00139$
      003D0E 80 04            [24]  516 	sjmp	00107$
      003D10                        517 00139$:
      003D10 75 82 00         [24]  518 	mov	dpl, #0x00
      003D13 22               [24]  519 	ret
      003D14                        520 00107$:
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D14 0D               [12]  522 	inc	r5
      003D15 BD 05 D7         [24]  523 	cjne	r5,#0x05,00106$
                                    524 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D18 75 82 01         [24]  525 	mov	dpl, #0x01
                                    526 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D1B 22               [24]  527 	ret
                                    528 ;------------------------------------------------------------
                                    529 ;Allocation info for local variables in function 'recover_journal'
                                    530 ;------------------------------------------------------------
                                    531 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    532 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    533 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    534 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    535 ;------------------------------------------------------------
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    537 ;	-----------------------------------------
                                    538 ;	 function recover_journal
                                    539 ;	-----------------------------------------
      003D1C                        540 _recover_journal:
                                    541 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D1C 7F 00            [12]  542 	mov	r7,#0x00
      003D1E                        543 00115$:
      003D1E EF               [12]  544 	mov	a,r7
      003D1F 24 6C            [12]  545 	add	a, #_recover_journal_header_10000_46
      003D21 FD               [12]  546 	mov	r5,a
      003D22 E4               [12]  547 	clr	a
      003D23 34 05            [12]  548 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D25 FE               [12]  549 	mov	r6,a
      003D26 8F 04            [24]  550 	mov	ar4,r7
      003D28 7B 00            [12]  551 	mov	r3,#0x00
      003D2A 74 40            [12]  552 	mov	a,#0x40
      003D2C 2C               [12]  553 	add	a, r4
      003D2D FC               [12]  554 	mov	r4,a
      003D2E 74 EF            [12]  555 	mov	a,#0xef
      003D30 3B               [12]  556 	addc	a, r3
      003D31 FB               [12]  557 	mov	r3,a
      003D32 12 43 8A         [24]  558 	lcall	_ak820_outline_0190
      003D35 12 38 F5         [24]  559 	lcall	_ak820_flash_read
      003D38 AC 82            [24]  560 	mov	r4, dpl
      003D3A 12 43 3F         [24]  561 	lcall	_ak820_outline_0069
      003D3D 0F               [12]  562 	inc	r7
      003D3E BF 09 DD         [24]  563 	cjne	r7,#0x09,00115$
                                    564 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D41 90 05 6C         [24]  565 	mov	dptr,#_recover_journal_header_10000_46
      003D44 12 3C D3         [24]  566 	lcall	_journal_header_valid
      003D47 E5 82            [12]  567 	mov	a, dpl
      003D49 70 01            [24]  568 	jnz	00103$
      003D4B 22               [24]  569 	ret
      003D4C                        570 00103$:
                                    571 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D4C 90 05 6D         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D4F E0               [24]  573 	movx	a,@dptr
      003D50 FF               [12]  574 	mov	r7,a
      003D51 7E 00            [12]  575 	mov	r6,#0x00
      003D53 90 05 6E         [24]  576 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D56 E0               [24]  577 	movx	a,@dptr
      003D57 FC               [12]  578 	mov	r4,a
      003D58 E4               [12]  579 	clr	a
      003D59 42 07            [12]  580 	orl	ar7,a
      003D5B EC               [12]  581 	mov	a,r4
      003D5C 42 06            [12]  582 	orl	ar6,a
                                    583 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D5E 90 05 6F         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D61 E0               [24]  585 	movx	a,@dptr
      003D62 FD               [12]  586 	mov	r5,a
      003D63 7C 00            [12]  587 	mov	r4,#0x00
      003D65 90 05 70         [24]  588 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D68 E0               [24]  589 	movx	a,@dptr
      003D69 FA               [12]  590 	mov	r2,a
      003D6A E4               [12]  591 	clr	a
      003D6B 12 43 69         [24]  592 	lcall	_ak820_outline_0149
                                    593 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D6E C3               [12]  594 	clr	c
      003D6F EF               [12]  595 	mov	a,r7
      003D70 94 A0            [12]  596 	subb	a,#0xa0
      003D72 EE               [12]  597 	mov	a,r6
      003D73 94 00            [12]  598 	subb	a,#0x00
      003D75 40 06            [24]  599 	jc	00134$
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D77 75 82 01         [24]  601 	mov	dpl, #0x01
                                    602 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D7A 02 3B 89         [24]  603 	ljmp	_nvm_fail
                                    604 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D7D                        605 00134$:
      003D7D 7B 00            [12]  606 	mov	r3,#0x00
      003D7F                        607 00117$:
      003D7F C0 05            [24]  608 	push	ar5
      003D81 C0 04            [24]  609 	push	ar4
      003D83 EB               [12]  610 	mov	a,r3
      003D84 24 1D            [12]  611 	add	a, #_page_data
      003D86 F9               [12]  612 	mov	r1,a
      003D87 E4               [12]  613 	clr	a
      003D88 34 05            [12]  614 	addc	a, #(_page_data >> 8)
      003D8A FA               [12]  615 	mov	r2,a
      003D8B 8B 00            [24]  616 	mov	ar0,r3
      003D8D 7D 00            [12]  617 	mov	r5,#0x00
      003D8F 74 EF            [12]  618 	mov	a,#0xef
      003D91 2D               [12]  619 	add	a, r5
      003D92 FD               [12]  620 	mov	r5,a
      003D93 88 82            [24]  621 	mov	dpl, r0
      003D95 8D 83            [24]  622 	mov	dph, r5
      003D97 12 38 F5         [24]  623 	lcall	_ak820_flash_read
      003D9A AD 82            [24]  624 	mov	r5, dpl
      003D9C 12 43 85         [24]  625 	lcall	_ak820_outline_0177
      003D9F ED               [12]  626 	mov	a,r5
      003DA0 F0               [24]  627 	movx	@dptr,a
      003DA1 0B               [12]  628 	inc	r3
      003DA2 BB 40 02         [24]  629 	cjne	r3,#0x40,00190$
      003DA5 80 06            [24]  630 	sjmp	00191$
      003DA7                        631 00190$:
      003DA7 D0 04            [24]  632 	pop	ar4
      003DA9 D0 05            [24]  633 	pop	ar5
      003DAB 80 D2            [24]  634 	sjmp	00117$
      003DAD                        635 00191$:
      003DAD D0 04            [24]  636 	pop	ar4
      003DAF D0 05            [24]  637 	pop	ar5
                                    638 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DB1 C0 07            [24]  639 	push	ar7
      003DB3 C0 06            [24]  640 	push	ar6
      003DB5 C0 05            [24]  641 	push	ar5
      003DB7 C0 04            [24]  642 	push	ar4
      003DB9 12 3C 39         [24]  643 	lcall	_page_crc
      003DBC AA 82            [24]  644 	mov	r2, dpl
      003DBE AB 83            [24]  645 	mov	r3, dph
      003DC0 D0 04            [24]  646 	pop	ar4
      003DC2 D0 05            [24]  647 	pop	ar5
      003DC4 D0 06            [24]  648 	pop	ar6
      003DC6 D0 07            [24]  649 	pop	ar7
      003DC8 EA               [12]  650 	mov	a,r2
      003DC9 B5 05 06         [24]  651 	cjne	a,ar5,00192$
      003DCC EB               [12]  652 	mov	a,r3
      003DCD B5 04 02         [24]  653 	cjne	a,ar4,00192$
      003DD0 80 06            [24]  654 	sjmp	00113$
      003DD2                        655 00192$:
      003DD2 75 82 02         [24]  656 	mov	dpl, #0x02
      003DD5 02 3B 89         [24]  657 	ljmp	_nvm_fail
      003DD8                        658 00113$:
                                    659 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DD8 EE               [12]  660 	mov	a,r6
      003DD9 54 03            [12]  661 	anl	a,#0x03
      003DDB A2 E0            [12]  662 	mov	c,acc.0
      003DDD CF               [12]  663 	xch	a,r7
      003DDE 13               [12]  664 	rrc	a
      003DDF CF               [12]  665 	xch	a,r7
      003DE0 13               [12]  666 	rrc	a
      003DE1 A2 E0            [12]  667 	mov	c,acc.0
      003DE3 CF               [12]  668 	xch	a,r7
      003DE4 13               [12]  669 	rrc	a
      003DE5 CF               [12]  670 	xch	a,r7
      003DE6 13               [12]  671 	rrc	a
      003DE7 CF               [12]  672 	xch	a,r7
      003DE8 24 C7            [12]  673 	add	a,#0xc7
      003DEA FE               [12]  674 	mov	r6,a
      003DEB 12 43 74         [24]  675 	lcall	_ak820_outline_0163
      003DEE 12 3C 6C         [24]  676 	lcall	_write_page
      003DF1 E5 82            [12]  677 	mov	a, dpl
      003DF3 70 06            [24]  678 	jnz	00110$
      003DF5 75 82 03         [24]  679 	mov	dpl, #0x03
      003DF8 02 3B 89         [24]  680 	ljmp	_nvm_fail
      003DFB                        681 00110$:
                                    682 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DFB 90 EF 40         [24]  683 	mov	dptr,#0xef40
      003DFE 12 3A 02         [24]  684 	lcall	_ak820_flash_erase
      003E01 E5 82            [12]  685 	mov	a, dpl
      003E03 70 06            [24]  686 	jnz	00119$
      003E05 75 82 04         [24]  687 	mov	dpl, #0x04
                                    688 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E08 02 3B 89         [24]  689 	ljmp	_nvm_fail
      003E0B                        690 00119$:
      003E0B 22               [24]  691 	ret
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    694 ;------------------------------------------------------------
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function eeprom_driver_init
                                    698 ;	-----------------------------------------
      003E0C                        699 _eeprom_driver_init:
                                    700 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    701 ;	assignBit
      003E0C C2 0B            [12]  702 	clr	_storage_failed
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E0E 90 05 5F         [24]  704 	mov	dptr,#_first_failure_stage
      003E11 E4               [12]  705 	clr	a
      003E12 F0               [24]  706 	movx	@dptr,a
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    708 ;	assignBit
      003E13 C2 0A            [12]  709 	clr	_page_dirty
                                    710 ;	assignBit
      003E15 C2 09            [12]  711 	clr	_page_valid
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E17 90 05 5E         [24]  713 	mov	dptr,#_batch_depth
      003E1A E4               [12]  714 	clr	a
      003E1B F0               [24]  715 	movx	@dptr,a
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E1C 12 3D 1C         [24]  717 	lcall	_recover_journal
                                    718 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E1F 02 2A B7         [24]  720 	ljmp	_ak820_macro_init
                                    721 ;------------------------------------------------------------
                                    722 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    723 ;------------------------------------------------------------
                                    724 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    725 ;	-----------------------------------------
                                    726 ;	 function ak820_nvm_ok
                                    727 ;	-----------------------------------------
      003E22                        728 _ak820_nvm_ok:
      003E22 A2 0B            [12]  729 	mov	c,_storage_failed
      003E24 B3               [12]  730 	cpl	c
      003E25 92 0C            [24]  731 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E27 12 38 B7         [24]  732 	lcall	_ak820_outline_0151
      003E2A 22               [24]  733 	ret
                                    734 ;------------------------------------------------------------
                                    735 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    736 ;------------------------------------------------------------
                                    737 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    738 ;	-----------------------------------------
                                    739 ;	 function ak820_nvm_schema_fault
                                    740 ;	-----------------------------------------
      003E2B                        741 _ak820_nvm_schema_fault:
      003E2B 75 82 10         [24]  742 	mov	dpl, #0x10
      003E2E 02 3B 89         [24]  743 	ljmp	_nvm_fail
                                    744 ;------------------------------------------------------------
                                    745 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    746 ;------------------------------------------------------------
                                    747 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    748 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    749 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    750 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    751 ;------------------------------------------------------------
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function ak820_nvm_flush
                                    755 ;	-----------------------------------------
      003E31                        756 _ak820_nvm_flush:
                                    757 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E31 30 0A 03         [24]  758 	jnb	_page_dirty,00101$
      003E34 30 0B 01         [24]  759 	jnb	_storage_failed,00102$
      003E37                        760 00101$:
      003E37 22               [24]  761 	ret
      003E38                        762 00102$:
                                    763 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E38 12 3C 39         [24]  764 	lcall	_page_crc
      003E3B 12 43 64         [24]  765 	lcall	_ak820_outline_0142
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E3E 90 05 75         [24]  767 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E41 74 A5            [12]  768 	mov	a,#0xa5
      003E43 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E44 90 05 5D         [24]  771 	mov	dptr,#_cached_page
      003E47 E0               [24]  772 	movx	a,@dptr
      003E48 90 05 76         [24]  773 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E4B F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E4C 90 05 77         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E4F E4               [12]  777 	clr	a
      003E50 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E51 8E 05            [24]  780 	mov	ar5,r6
      003E53 90 05 78         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E56 ED               [12]  782 	mov	a,r5
      003E57 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E58 8F 06            [24]  785 	mov	ar6,r7
      003E5A 90 05 79         [24]  786 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E5D EE               [12]  787 	mov	a,r6
      003E5E F0               [24]  788 	movx	@dptr,a
                                    789 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E5F 7F 01            [12]  790 	mov	r7,#0x01
      003E61                        791 00128$:
      003E61 8F 06            [24]  792 	mov	ar6,r7
      003E63 EE               [12]  793 	mov	a,r6
      003E64 24 04            [12]  794 	add	a,#0x04
      003E66 FE               [12]  795 	mov	r6,a
      003E67 33               [12]  796 	rlc	a
      003E68 95 E0            [12]  797 	subb	a,acc
      003E6A FD               [12]  798 	mov	r5,a
      003E6B EE               [12]  799 	mov	a,r6
      003E6C 24 75            [12]  800 	add	a, #_ak820_nvm_flush_header_10000_62
      003E6E FE               [12]  801 	mov	r6,a
      003E6F ED               [12]  802 	mov	a,r5
      003E70 34 05            [12]  803 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E72 FD               [12]  804 	mov	r5,a
      003E73 12 43 22         [24]  805 	lcall	_ak820_outline_0048
      003E76 FC               [12]  806 	mov	r4,a
      003E77 63 04 FF         [24]  807 	xrl	ar4,#0xff
      003E7A 8E 82            [24]  808 	mov	dpl,r6
      003E7C 8D 83            [24]  809 	mov	dph,r5
      003E7E EC               [12]  810 	mov	a,r4
      003E7F F0               [24]  811 	movx	@dptr,a
      003E80 0F               [12]  812 	inc	r7
      003E81 BF 05 DD         [24]  813 	cjne	r7,#0x05,00128$
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E84 90 05 7E         [24]  815 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E87 74 05            [12]  816 	mov	a,#0x05
      003E89 F0               [24]  817 	movx	@dptr,a
                                    818 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E8A 90 EF 40         [24]  819 	mov	dptr,#0xef40
      003E8D 12 3A 02         [24]  820 	lcall	_ak820_flash_erase
      003E90 E5 82            [12]  821 	mov	a, dpl
      003E92 70 03            [24]  822 	jnz	00269$
      003E94 02 3F 7B         [24]  823 	ljmp	00127$
      003E97                        824 00269$:
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E97 90 05 7E         [24]  826 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E9A 74 06            [12]  827 	mov	a,#0x06
      003E9C F0               [24]  828 	movx	@dptr,a
                                    829 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E9D 7F 00            [12]  830 	mov	r7,#0x00
      003E9F                        831 00130$:
                                    832 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E9F 12 43 2E         [24]  833 	lcall	_ak820_outline_0059
      003EA2 12 38 F5         [24]  834 	lcall	_ak820_flash_read
      003EA5 E5 82            [12]  835 	mov	a, dpl
      003EA7 60 03            [24]  836 	jz	00270$
      003EA9 02 3F 7B         [24]  837 	ljmp	00127$
      003EAC                        838 00270$:
                                    839 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EAC 0F               [12]  840 	inc	r7
      003EAD BF 40 EF         [24]  841 	cjne	r7,#0x40,00130$
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003EB0 90 05 7E         [24]  843 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB3 74 07            [12]  844 	mov	a,#0x07
      003EB5 F0               [24]  845 	movx	@dptr,a
                                    846 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EB6 90 EF 00         [24]  847 	mov	dptr,#0xef00
      003EB9 12 3C 6C         [24]  848 	lcall	_write_page
      003EBC E5 82            [12]  849 	mov	a, dpl
      003EBE 70 03            [24]  850 	jnz	00273$
      003EC0 02 3F 7B         [24]  851 	ljmp	00127$
      003EC3                        852 00273$:
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EC3 90 05 7E         [24]  854 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EC6 74 08            [12]  855 	mov	a,#0x08
      003EC8 F0               [24]  856 	movx	@dptr,a
                                    857 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EC9 7F 01            [12]  858 	mov	r7,#0x01
      003ECB                        859 00132$:
                                    860 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003ECB 12 43 22         [24]  861 	lcall	_ak820_outline_0048
      003ECE FE               [12]  862 	mov	r6,a
      003ECF 60 23            [24]  863 	jz	00133$
      003ED1 8F 05            [24]  864 	mov	ar5,r7
      003ED3 7C 00            [12]  865 	mov	r4,#0x00
      003ED5 74 40            [12]  866 	mov	a,#0x40
      003ED7 2D               [12]  867 	add	a, r5
      003ED8 FD               [12]  868 	mov	r5,a
      003ED9 74 EF            [12]  869 	mov	a,#0xef
      003EDB 3C               [12]  870 	addc	a, r4
      003EDC FC               [12]  871 	mov	r4,a
      003EDD 90 04 F6         [24]  872 	mov	dptr,#_ak820_flash_program_PARM_2
      003EE0 EE               [12]  873 	mov	a,r6
      003EE1 F0               [24]  874 	movx	@dptr,a
      003EE2 8D 82            [24]  875 	mov	dpl, r5
      003EE4 8C 83            [24]  876 	mov	dph, r4
      003EE6 C0 07            [24]  877 	push	ar7
      003EE8 12 3A 62         [24]  878 	lcall	_ak820_flash_program
      003EEB E5 82            [12]  879 	mov	a, dpl
      003EED D0 07            [24]  880 	pop	ar7
      003EEF 70 03            [24]  881 	jnz	00275$
      003EF1 02 3F 7B         [24]  882 	ljmp	00127$
      003EF4                        883 00275$:
      003EF4                        884 00133$:
                                    885 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EF4 0F               [12]  886 	inc	r7
      003EF5 BF 09 D3         [24]  887 	cjne	r7,#0x09,00132$
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EF8 90 05 7E         [24]  889 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EFB 74 09            [12]  890 	mov	a,#0x09
      003EFD F0               [24]  891 	movx	@dptr,a
                                    892 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EFE 7F 01            [12]  893 	mov	r7,#0x01
      003F00                        894 00134$:
                                    895 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F00 12 43 2E         [24]  896 	lcall	_ak820_outline_0059
      003F03 12 38 F5         [24]  897 	lcall	_ak820_flash_read
      003F06 AE 82            [24]  898 	mov	r6, dpl
      003F08 12 43 22         [24]  899 	lcall	_ak820_outline_0048
      003F0B FD               [12]  900 	mov	r5,a
      003F0C EE               [12]  901 	mov	a,r6
      003F0D B5 05 6B         [24]  902 	cjne	a,ar5,00127$
                                    903 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F10 0F               [12]  904 	inc	r7
      003F11 BF 09 EC         [24]  905 	cjne	r7,#0x09,00134$
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F14 90 05 7E         [24]  907 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F17 74 0A            [12]  908 	mov	a,#0x0a
      003F19 F0               [24]  909 	movx	@dptr,a
                                    910 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F1A 90 05 75         [24]  911 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F1D E0               [24]  912 	movx	a,@dptr
      003F1E 90 04 F6         [24]  913 	mov	dptr,#_ak820_flash_program_PARM_2
      003F21 F0               [24]  914 	movx	@dptr,a
      003F22 90 EF 40         [24]  915 	mov	dptr,#0xef40
      003F25 12 3A 62         [24]  916 	lcall	_ak820_flash_program
      003F28 E5 82            [12]  917 	mov	a, dpl
      003F2A 60 4F            [24]  918 	jz	00127$
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F2C 90 05 7E         [24]  920 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F2F 74 0B            [12]  921 	mov	a,#0x0b
      003F31 F0               [24]  922 	movx	@dptr,a
                                    923 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F32 90 EF 40         [24]  924 	mov	dptr,#0xef40
      003F35 12 38 F5         [24]  925 	lcall	_ak820_flash_read
      003F38 AF 82            [24]  926 	mov	r7, dpl
      003F3A 90 05 75         [24]  927 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F3D E0               [24]  928 	movx	a,@dptr
      003F3E FE               [12]  929 	mov	r6,a
      003F3F EF               [12]  930 	mov	a,r7
      003F40 B5 06 38         [24]  931 	cjne	a,ar6,00127$
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F43 90 05 7E         [24]  933 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F46 74 0C            [12]  934 	mov	a,#0x0c
      003F48 F0               [24]  935 	movx	@dptr,a
                                    936 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F49 90 05 5D         [24]  937 	mov	dptr,#_cached_page
      003F4C E0               [24]  938 	movx	a,@dptr
      003F4D FE               [12]  939 	mov	r6,a
      003F4E E4               [12]  940 	clr	a
      003F4F C3               [12]  941 	clr	c
      003F50 CE               [12]  942 	xch	a,r6
      003F51 13               [12]  943 	rrc	a
      003F52 CE               [12]  944 	xch	a,r6
      003F53 13               [12]  945 	rrc	a
      003F54 A2 E0            [12]  946 	mov	c,acc.0
      003F56 CE               [12]  947 	xch	a,r6
      003F57 13               [12]  948 	rrc	a
      003F58 CE               [12]  949 	xch	a,r6
      003F59 13               [12]  950 	rrc	a
      003F5A CE               [12]  951 	xch	a,r6
      003F5B 24 C7            [12]  952 	add	a,#0xc7
      003F5D FF               [12]  953 	mov	r7,a
      003F5E 12 38 92         [24]  954 	lcall	_ak820_outline_0124
      003F61 12 3C 6C         [24]  955 	lcall	_write_page
      003F64 E5 82            [12]  956 	mov	a, dpl
      003F66 60 13            [24]  957 	jz	00127$
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F68 90 05 7E         [24]  959 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F6B 74 0D            [12]  960 	mov	a,#0x0d
      003F6D F0               [24]  961 	movx	@dptr,a
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F6E 90 EF 40         [24]  963 	mov	dptr,#0xef40
      003F71 12 3A 02         [24]  964 	lcall	_ak820_flash_erase
      003F74 E5 82            [12]  965 	mov	a, dpl
      003F76 60 03            [24]  966 	jz	00127$
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    968 ;	assignBit
      003F78 C2 0A            [12]  969 	clr	_page_dirty
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    971 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F7A 22               [24]  972 	ret
      003F7B                        973 00127$:
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F7B 90 05 7E         [24]  975 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F7E E0               [24]  976 	movx	a,@dptr
      003F7F F5 82            [12]  977 	mov	dpl,a
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F81 02 3B 89         [24]  979 	ljmp	_nvm_fail
                                    980 ;------------------------------------------------------------
                                    981 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    982 ;------------------------------------------------------------
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function ak820_nvm_begin
                                    986 ;	-----------------------------------------
      003F84                        987 _ak820_nvm_begin:
                                    988 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F84 90 05 5E         [24]  989 	mov	dptr,#_batch_depth
      003F87 E0               [24]  990 	movx	a,@dptr
      003F88 FF               [12]  991 	mov	r7,a
      003F89 BF FF 06         [24]  992 	cjne	r7,#0xff,00102$
      003F8C 75 82 0F         [24]  993 	mov	dpl, #0x0f
      003F8F 02 3B 89         [24]  994 	ljmp	_nvm_fail
      003F92                        995 00102$:
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F92 90 05 5E         [24]  997 	mov	dptr,#_batch_depth
      003F95 EF               [12]  998 	mov	a,r7
      003F96 04               [12]  999 	inc	a
      003F97 F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F98 22               [24] 1002 	ret
                                   1003 ;------------------------------------------------------------
                                   1004 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1005 ;------------------------------------------------------------
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1007 ;	-----------------------------------------
                                   1008 ;	 function ak820_nvm_end
                                   1009 ;	-----------------------------------------
      003F99                       1010 _ak820_nvm_end:
                                   1011 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F99 90 05 5E         [24] 1012 	mov	dptr,#_batch_depth
      003F9C E0               [24] 1013 	movx	a,@dptr
      003F9D FF               [12] 1014 	mov	r7,a
      003F9E E0               [24] 1015 	movx	a,@dptr
      003F9F 60 06            [24] 1016 	jz	00102$
      003FA1 EF               [12] 1017 	mov	a,r7
      003FA2 14               [12] 1018 	dec	a
      003FA3 90 05 5E         [24] 1019 	mov	dptr,#_batch_depth
      003FA6 F0               [24] 1020 	movx	@dptr,a
      003FA7                       1021 00102$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003FA7 90 05 5E         [24] 1023 	mov	dptr,#_batch_depth
      003FAA E0               [24] 1024 	movx	a,@dptr
      003FAB 70 03            [24] 1025 	jnz	00105$
                                   1026 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FAD 02 3E 31         [24] 1027 	ljmp	_ak820_nvm_flush
      003FB0                       1028 00105$:
      003FB0 22               [24] 1029 	ret
                                   1030 ;------------------------------------------------------------
                                   1031 ;Allocation info for local variables in function 'load_page'
                                   1032 ;------------------------------------------------------------
                                   1033 ;page          Allocated with name '_load_page_page_10000_87'
                                   1034 ;i             Allocated with name '_load_page_i_10000_88'
                                   1035 ;------------------------------------------------------------
                                   1036 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1037 ;	-----------------------------------------
                                   1038 ;	 function load_page
                                   1039 ;	-----------------------------------------
      003FB1                       1040 _load_page:
      003FB1 E5 82            [12] 1041 	mov	a,dpl
      003FB3 90 05 7F         [24] 1042 	mov	dptr,#_load_page_page_10000_87
      003FB6 F0               [24] 1043 	movx	@dptr,a
                                   1044 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FB7 30 09 17         [24] 1045 	jnb	_page_valid,00102$
      003FBA 90 05 5D         [24] 1046 	mov	dptr,#_cached_page
      003FBD E0               [24] 1047 	movx	a,@dptr
      003FBE FF               [12] 1048 	mov	r7,a
      003FBF 90 05 7F         [24] 1049 	mov	dptr,#_load_page_page_10000_87
      003FC2 E0               [24] 1050 	movx	a,@dptr
      003FC3 FE               [12] 1051 	mov	r6,a
      003FC4 EF               [12] 1052 	mov	a,r7
      003FC5 B5 06 09         [24] 1053 	cjne	a,ar6,00102$
      003FC8 A2 0B            [12] 1054 	mov	c,_storage_failed
      003FCA B3               [12] 1055 	cpl	c
      003FCB 92 0D            [24] 1056 	mov  _load_page_sloc0_1_0,c
      003FCD 12 38 B7         [24] 1057 	lcall	_ak820_outline_0151
      003FD0 22               [24] 1058 	ret
      003FD1                       1059 00102$:
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FD1 12 3E 31         [24] 1061 	lcall	_ak820_nvm_flush
                                   1062 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FD4 30 0B 04         [24] 1063 	jnb	_storage_failed,00119$
      003FD7 75 82 00         [24] 1064 	mov	dpl, #0x00
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FDA 22               [24] 1066 	ret
      003FDB                       1067 00119$:
      003FDB 7F 00            [12] 1068 	mov	r7,#0x00
      003FDD                       1069 00107$:
                                   1070 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FDD EF               [12] 1071 	mov	a,r7
      003FDE 24 1D            [12] 1072 	add	a, #_page_data
      003FE0 FD               [12] 1073 	mov	r5,a
      003FE1 E4               [12] 1074 	clr	a
      003FE2 34 05            [12] 1075 	addc	a, #(_page_data >> 8)
      003FE4 FE               [12] 1076 	mov	r6,a
      003FE5 90 05 7F         [24] 1077 	mov	dptr,#_load_page_page_10000_87
      003FE8 E0               [24] 1078 	movx	a,@dptr
      003FE9 FC               [12] 1079 	mov	r4,a
      003FEA FA               [12] 1080 	mov	r2,a
      003FEB E4               [12] 1081 	clr	a
      003FEC C3               [12] 1082 	clr	c
      003FED CA               [12] 1083 	xch	a,r2
      003FEE 13               [12] 1084 	rrc	a
      003FEF CA               [12] 1085 	xch	a,r2
      003FF0 13               [12] 1086 	rrc	a
      003FF1 A2 E0            [12] 1087 	mov	c,acc.0
      003FF3 CA               [12] 1088 	xch	a,r2
      003FF4 13               [12] 1089 	rrc	a
      003FF5 CA               [12] 1090 	xch	a,r2
      003FF6 13               [12] 1091 	rrc	a
      003FF7 CA               [12] 1092 	xch	a,r2
      003FF8 24 C7            [12] 1093 	add	a,#0xc7
      003FFA FB               [12] 1094 	mov	r3,a
      003FFB 8F 01            [24] 1095 	mov	ar1,r7
      003FFD 89 00            [24] 1096 	mov	ar0,r1
      003FFF 79 00            [12] 1097 	mov	r1,#0x00
      004001 E8               [12] 1098 	mov	a,r0
      004002 2A               [12] 1099 	add	a, r2
      004003 FA               [12] 1100 	mov	r2,a
      004004 E9               [12] 1101 	mov	a,r1
      004005 3B               [12] 1102 	addc	a, r3
      004006 FB               [12] 1103 	mov	r3,a
      004007 12 38 AD         [24] 1104 	lcall	_ak820_outline_0134
      00400A 12 38 F5         [24] 1105 	lcall	_ak820_flash_read
      00400D AB 82            [24] 1106 	mov	r3, dpl
      00400F 12 38 B2         [24] 1107 	lcall	_ak820_outline_0143
      004012 EB               [12] 1108 	mov	a,r3
      004013 F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004014 0F               [12] 1111 	inc	r7
      004015 BF 40 C5         [24] 1112 	cjne	r7,#0x40,00107$
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004018 90 05 5D         [24] 1114 	mov	dptr,#_cached_page
      00401B EC               [12] 1115 	mov	a,r4
      00401C F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1118 ;	assignBit
      00401D D2 09            [12] 1119 	setb	_page_valid
                                   1120 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00401F 75 82 01         [24] 1121 	mov	dpl, #0x01
                                   1122 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004022 22               [24] 1123 	ret
                                   1124 ;------------------------------------------------------------
                                   1125 ;Allocation info for local variables in function 'read_offset'
                                   1126 ;------------------------------------------------------------
                                   1127 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1128 ;------------------------------------------------------------
                                   1129 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1130 ;	-----------------------------------------
                                   1131 ;	 function read_offset
                                   1132 ;	-----------------------------------------
      004023                       1133 _read_offset:
      004023 12 38 81         [24] 1134 	lcall	_ak820_outline_0111
      004026 90 05 80         [24] 1135 	mov	dptr,#_read_offset_offset_10000_93
      004029 12 38 86         [24] 1136 	lcall	_ak820_outline_0112
                                   1137 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00402C 90 05 80         [24] 1138 	mov	dptr,#_read_offset_offset_10000_93
      00402F 12 38 2D         [24] 1139 	lcall	_ak820_outline_0058
      004032 C3               [12] 1140 	clr	c
      004033 94 28            [12] 1141 	subb	a,#0x28
      004035 40 04            [24] 1142 	jc	00102$
      004037 75 82 00         [24] 1143 	mov	dpl, #0x00
      00403A 22               [24] 1144 	ret
      00403B                       1145 00102$:
                                   1146 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00403B 30 09 34         [24] 1147 	jnb	_page_valid,00104$
      00403E 8E 04            [24] 1148 	mov	ar4,r6
      004040 EF               [12] 1149 	mov	a,r7
      004041 A2 E7            [12] 1150 	mov	c,acc.7
      004043 CC               [12] 1151 	xch	a,r4
      004044 33               [12] 1152 	rlc	a
      004045 CC               [12] 1153 	xch	a,r4
      004046 33               [12] 1154 	rlc	a
      004047 A2 E7            [12] 1155 	mov	c,acc.7
      004049 CC               [12] 1156 	xch	a,r4
      00404A 33               [12] 1157 	rlc	a
      00404B CC               [12] 1158 	xch	a,r4
      00404C 33               [12] 1159 	rlc	a
      00404D CC               [12] 1160 	xch	a,r4
      00404E 54 03            [12] 1161 	anl	a,#0x03
      004050 FD               [12] 1162 	mov	r5,a
      004051 90 05 5D         [24] 1163 	mov	dptr,#_cached_page
      004054 E0               [24] 1164 	movx	a,@dptr
      004055 FA               [12] 1165 	mov	r2,a
      004056 7B 00            [12] 1166 	mov	r3,#0x00
      004058 EC               [12] 1167 	mov	a,r4
      004059 B5 02 16         [24] 1168 	cjne	a,ar2,00104$
      00405C ED               [12] 1169 	mov	a,r5
      00405D B5 03 12         [24] 1170 	cjne	a,ar3,00104$
                                   1171 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004060 74 3F            [12] 1172 	mov	a,#0x3f
      004062 5E               [12] 1173 	anl	a,r6
      004063 7D 00            [12] 1174 	mov	r5,#0x00
      004065 24 1D            [12] 1175 	add	a, #_page_data
      004067 F5 82            [12] 1176 	mov	dpl,a
      004069 ED               [12] 1177 	mov	a,r5
      00406A 34 05            [12] 1178 	addc	a, #(_page_data >> 8)
      00406C F5 83            [12] 1179 	mov	dph,a
      00406E E0               [24] 1180 	movx	a,@dptr
      00406F F5 82            [12] 1181 	mov	dpl,a
      004071 22               [24] 1182 	ret
      004072                       1183 00104$:
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004072 74 C7            [12] 1185 	mov	a,#0xc7
      004074 2F               [12] 1186 	add	a, r7
      004075 FF               [12] 1187 	mov	r7,a
      004076 12 38 92         [24] 1188 	lcall	_ak820_outline_0124
                                   1189 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004079 02 38 F5         [24] 1190 	ljmp	_ak820_flash_read
                                   1191 ;------------------------------------------------------------
                                   1192 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1193 ;------------------------------------------------------------
                                   1194 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1195 ;------------------------------------------------------------
                                   1196 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1197 ;	-----------------------------------------
                                   1198 ;	 function eeprom_read_byte
                                   1199 ;	-----------------------------------------
      00407C                       1200 _eeprom_read_byte:
      00407C C0 07            [24] 1201 	push	ar7
      00407E C0 06            [24] 1202 	push	ar6
      004080 12 43 1B         [24] 1203 	lcall	_ak820_outline_0041
      004083 90 05 82         [24] 1204 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004086 12 38 15         [24] 1205 	lcall	_ak820_outline_0020
                                   1206 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004089 90 05 82         [24] 1207 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00408C 12 37 ED         [24] 1208 	lcall	_ak820_outline_0006
      00408F C0 06            [24] 1209 	push	ar6
      004091 C0 05            [24] 1210 	push	ar5
      004093 C0 04            [24] 1211 	push	ar4
      004095 C0 03            [24] 1212 	push	ar3
      004097 C0 02            [24] 1213 	push	ar2
      004099 C0 01            [24] 1214 	push	ar1
      00409B C0 00            [24] 1215 	push	ar0
      00409D 12 40 23         [24] 1216 	lcall	_read_offset
      0040A0 AF 82            [24] 1217 	mov	r7, dpl
      0040A2 D0 00            [24] 1218 	pop	ar0
      0040A4 D0 01            [24] 1219 	pop	ar1
      0040A6 D0 02            [24] 1220 	pop	ar2
      0040A8 D0 03            [24] 1221 	pop	ar3
      0040AA D0 04            [24] 1222 	pop	ar4
      0040AC D0 05            [24] 1223 	pop	ar5
      0040AE D0 06            [24] 1224 	pop	ar6
      0040B0 8F 82            [24] 1225 	mov	dpl, r7
                                   1226 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040B2 D0 06            [24] 1227 	pop	ar6
      0040B4 D0 07            [24] 1228 	pop	ar7
      0040B6 22               [24] 1229 	ret
                                   1230 ;------------------------------------------------------------
                                   1231 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1232 ;------------------------------------------------------------
                                   1233 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1234 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1235 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1236 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1237 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1238 ;------------------------------------------------------------
                                   1239 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1240 ;	-----------------------------------------
                                   1241 ;	 function ak820_eeprom_read_block_xdata
                                   1242 ;	-----------------------------------------
      0040B7                       1243 _ak820_eeprom_read_block_xdata:
      0040B7 12 38 81         [24] 1244 	lcall	_ak820_outline_0111
      0040BA 90 05 8A         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040BD 12 38 86         [24] 1246 	lcall	_ak820_outline_0112
                                   1247 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040C0 90 05 85         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040C3 12 38 2D         [24] 1249 	lcall	_ak820_outline_0058
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040C6 90 05 8A         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040C9 12 38 44         [24] 1252 	lcall	_ak820_outline_0065
      0040CC 90 05 8C         [24] 1253 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040CF 12 38 50         [24] 1254 	lcall	_ak820_outline_0078
                                   1255 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040D2 90 05 88         [24] 1256 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040D5 12 38 44         [24] 1257 	lcall	_ak820_outline_0065
      0040D8                       1258 00103$:
      0040D8 8C 02            [24] 1259 	mov	ar2,r4
      0040DA 8D 03            [24] 1260 	mov	ar3,r5
      0040DC 1C               [12] 1261 	dec	r4
      0040DD BC FF 01         [24] 1262 	cjne	r4,#0xff,00130$
      0040E0 1D               [12] 1263 	dec	r5
      0040E1                       1264 00130$:
      0040E1 EA               [12] 1265 	mov	a,r2
      0040E2 4B               [12] 1266 	orl	a,r3
      0040E3 60 5D            [24] 1267 	jz	00106$
                                   1268 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040E5 8E 02            [24] 1269 	mov	ar2,r6
      0040E7 8F 03            [24] 1270 	mov	ar3,r7
      0040E9 74 D8            [12] 1271 	mov	a,#0x100 - 0x28
      0040EB 2B               [12] 1272 	add	a,r3
      0040EC 50 17            [24] 1273 	jnc	00102$
      0040EE 90 05 8C         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F1 12 43 4C         [24] 1275 	lcall	_ak820_outline_0083
      0040F4 12 38 AD         [24] 1276 	lcall	_ak820_outline_0134
      0040F7 E4               [12] 1277 	clr	a
      0040F8 F0               [24] 1278 	movx	@dptr,a
      0040F9 90 05 8C         [24] 1279 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040FC 04               [12] 1280 	inc	a
      0040FD 2A               [12] 1281 	add	a, r2
      0040FE F0               [24] 1282 	movx	@dptr,a
      0040FF E4               [12] 1283 	clr	a
      004100 3B               [12] 1284 	addc	a, r3
      004101 A3               [24] 1285 	inc	dptr
      004102 F0               [24] 1286 	movx	@dptr,a
      004103 80 D3            [24] 1287 	sjmp	00103$
      004105                       1288 00102$:
                                   1289 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004105 90 05 8C         [24] 1290 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004108 12 43 4C         [24] 1291 	lcall	_ak820_outline_0083
      00410B 12 38 92         [24] 1292 	lcall	_ak820_outline_0124
      00410E C0 07            [24] 1293 	push	ar7
      004110 C0 06            [24] 1294 	push	ar6
      004112 C0 05            [24] 1295 	push	ar5
      004114 C0 04            [24] 1296 	push	ar4
      004116 C0 03            [24] 1297 	push	ar3
      004118 C0 02            [24] 1298 	push	ar2
      00411A 12 40 23         [24] 1299 	lcall	_read_offset
      00411D A9 82            [24] 1300 	mov	r1, dpl
      00411F D0 02            [24] 1301 	pop	ar2
      004121 D0 03            [24] 1302 	pop	ar3
      004123 D0 04            [24] 1303 	pop	ar4
      004125 D0 05            [24] 1304 	pop	ar5
      004127 D0 06            [24] 1305 	pop	ar6
      004129 D0 07            [24] 1306 	pop	ar7
      00412B 12 38 AD         [24] 1307 	lcall	_ak820_outline_0134
      00412E E9               [12] 1308 	mov	a,r1
      00412F F0               [24] 1309 	movx	@dptr,a
      004130 90 05 8C         [24] 1310 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004133 74 01            [12] 1311 	mov	a,#0x01
      004135 2A               [12] 1312 	add	a, r2
      004136 F0               [24] 1313 	movx	@dptr,a
      004137 E4               [12] 1314 	clr	a
      004138 3B               [12] 1315 	addc	a, r3
      004139 A3               [24] 1316 	inc	dptr
      00413A F0               [24] 1317 	movx	@dptr,a
                                   1318 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00413B 0E               [12] 1319 	inc	r6
      00413C BE 00 99         [24] 1320 	cjne	r6,#0x00,00103$
      00413F 0F               [12] 1321 	inc	r7
      004140 80 96            [24] 1322 	sjmp	00103$
      004142                       1323 00106$:
                                   1324 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004142 22               [24] 1325 	ret
                                   1326 ;------------------------------------------------------------
                                   1327 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1328 ;------------------------------------------------------------
                                   1329 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1330 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1331 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1332 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1333 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1334 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1335 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1336 ;------------------------------------------------------------
                                   1337 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1338 ;	-----------------------------------------
                                   1339 ;	 function ak820_eeprom_write_block_xdata
                                   1340 ;	-----------------------------------------
      004143                       1341 _ak820_eeprom_write_block_xdata:
      004143 12 38 81         [24] 1342 	lcall	_ak820_outline_0111
      004146 90 05 93         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004149 12 38 86         [24] 1344 	lcall	_ak820_outline_0112
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00414C 90 05 8E         [24] 1346 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00414F 12 38 2D         [24] 1347 	lcall	_ak820_outline_0058
                                   1348 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004152 90 05 93         [24] 1349 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004155 12 38 44         [24] 1350 	lcall	_ak820_outline_0065
                                   1351 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004158 8E 02            [24] 1352 	mov	ar2,r6
      00415A 8F 03            [24] 1353 	mov	ar3,r7
      00415C C3               [12] 1354 	clr	c
      00415D E4               [12] 1355 	clr	a
      00415E 9A               [12] 1356 	subb	a,r2
      00415F 74 28            [12] 1357 	mov	a,#0x28
      004161 9B               [12] 1358 	subb	a,r3
      004162 40 15            [24] 1359 	jc	00101$
                                   1360 ;	free result
      004164 E4               [12] 1361 	clr	a
      004165 C3               [12] 1362 	clr	c
      004166 9E               [12] 1363 	subb	a,r6
      004167 FA               [12] 1364 	mov	r2,a
      004168 74 28            [12] 1365 	mov	a,#0x28
      00416A 9F               [12] 1366 	subb	a,r7
      00416B FB               [12] 1367 	mov	r3,a
      00416C 90 05 91         [24] 1368 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00416F 12 38 6F         [24] 1369 	lcall	_ak820_outline_0104
      004172 C3               [12] 1370 	clr	c
      004173 EA               [12] 1371 	mov	a,r2
      004174 98               [12] 1372 	subb	a,r0
      004175 EB               [12] 1373 	mov	a,r3
      004176 99               [12] 1374 	subb	a,r1
      004177 50 06            [24] 1375 	jnc	00125$
                                   1376 ;	free result
      004179                       1377 00101$:
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004179 75 82 0E         [24] 1379 	mov	dpl, #0x0e
                                   1380 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00417C 02 3B 89         [24] 1381 	ljmp	_nvm_fail
                                   1382 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      00417F                       1383 00125$:
      00417F 90 05 91         [24] 1384 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004182 12 43 4C         [24] 1385 	lcall	_ak820_outline_0083
      004185                       1386 00108$:
      004185 8A 00            [24] 1387 	mov	ar0,r2
      004187 8B 01            [24] 1388 	mov	ar1,r3
      004189 1A               [12] 1389 	dec	r2
      00418A BA FF 01         [24] 1390 	cjne	r2,#0xff,00159$
      00418D 1B               [12] 1391 	dec	r3
      00418E                       1392 00159$:
      00418E E8               [12] 1393 	mov	a,r0
      00418F 49               [12] 1394 	orl	a,r1
      004190 70 03            [24] 1395 	jnz	00160$
      004192 02 42 1C         [24] 1396 	ljmp	00110$
      004195                       1397 00160$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004195 C0 02            [24] 1399 	push	ar2
      004197 C0 03            [24] 1400 	push	ar3
      004199 12 43 52         [24] 1401 	lcall	_ak820_outline_0085
      00419C F9               [12] 1402 	mov	r1,a
      00419D A3               [24] 1403 	inc	dptr
      00419E 12 43 6F         [24] 1404 	lcall	_ak820_outline_0156
                                   1405 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0041A1 8E 0C            [24] 1406 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0041A3 8F 0D            [24] 1407 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0041A5 A8 0C            [24] 1408 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041A7 E5 0D            [12] 1409 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041A9 A2 E7            [12] 1410 	mov	c,acc.7
      0041AB C8               [12] 1411 	xch	a,r0
      0041AC 33               [12] 1412 	rlc	a
      0041AD C8               [12] 1413 	xch	a,r0
      0041AE 33               [12] 1414 	rlc	a
      0041AF A2 E7            [12] 1415 	mov	c,acc.7
      0041B1 C8               [12] 1416 	xch	a,r0
      0041B2 33               [12] 1417 	rlc	a
      0041B3 C8               [12] 1418 	xch	a,r0
      0041B4 33               [12] 1419 	rlc	a
      0041B5 C8               [12] 1420 	xch	a,r0
      0041B6 54 03            [12] 1421 	anl	a,#0x03
      0041B8 FB               [12] 1422 	mov	r3,a
      0041B9 88 82            [24] 1423 	mov	dpl, r0
      0041BB C0 07            [24] 1424 	push	ar7
      0041BD C0 06            [24] 1425 	push	ar6
      0041BF C0 05            [24] 1426 	push	ar5
      0041C1 C0 04            [24] 1427 	push	ar4
      0041C3 C0 03            [24] 1428 	push	ar3
      0041C5 C0 02            [24] 1429 	push	ar2
      0041C7 C0 01            [24] 1430 	push	ar1
      0041C9 12 3F B1         [24] 1431 	lcall	_load_page
      0041CC E5 82            [12] 1432 	mov	a, dpl
      0041CE D0 01            [24] 1433 	pop	ar1
      0041D0 D0 02            [24] 1434 	pop	ar2
      0041D2 D0 03            [24] 1435 	pop	ar3
      0041D4 D0 04            [24] 1436 	pop	ar4
      0041D6 D0 05            [24] 1437 	pop	ar5
      0041D8 D0 06            [24] 1438 	pop	ar6
      0041DA D0 07            [24] 1439 	pop	ar7
      0041DC D0 03            [24] 1440 	pop	ar3
      0041DE D0 02            [24] 1441 	pop	ar2
      0041E0 70 01            [24] 1442 	jnz	00105$
      0041E2 22               [24] 1443 	ret
      0041E3                       1444 00105$:
                                   1445 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041E3 C0 06            [24] 1446 	push	ar6
      0041E5 C0 07            [24] 1447 	push	ar7
      0041E7 74 3F            [12] 1448 	mov	a,#0x3f
      0041E9 55 0C            [12] 1449 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041EB 7F 00            [12] 1450 	mov	r7,#0x00
      0041ED 24 1D            [12] 1451 	add	a, #_page_data
      0041EF F5 0C            [12] 1452 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041F1 EF               [12] 1453 	mov	a,r7
      0041F2 34 05            [12] 1454 	addc	a, #(_page_data >> 8)
      0041F4 F5 0D            [12] 1455 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041F6 85 0C 82         [24] 1456 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041F9 85 0D 83         [24] 1457 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041FC E0               [24] 1458 	movx	a,@dptr
      0041FD B5 01 06         [24] 1459 	cjne	a,ar1,00162$
      004200 D0 07            [24] 1460 	pop	ar7
      004202 D0 06            [24] 1461 	pop	ar6
      004204 80 0E            [24] 1462 	sjmp	00107$
      004206                       1463 00162$:
      004206 D0 07            [24] 1464 	pop	ar7
      004208 D0 06            [24] 1465 	pop	ar6
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00420A 85 0C 82         [24] 1467 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00420D 85 0D 83         [24] 1468 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004210 E9               [12] 1469 	mov	a,r1
      004211 F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1472 ;	assignBit
      004212 D2 0A            [12] 1473 	setb	_page_dirty
      004214                       1474 00107$:
                                   1475 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004214 0E               [12] 1476 	inc	r6
      004215 BE 00 01         [24] 1477 	cjne	r6,#0x00,00163$
      004218 0F               [12] 1478 	inc	r7
      004219                       1479 00163$:
      004219 02 41 85         [24] 1480 	ljmp	00108$
      00421C                       1481 00110$:
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00421C 90 05 5E         [24] 1483 	mov	dptr,#_batch_depth
      00421F E0               [24] 1484 	movx	a,@dptr
      004220 70 03            [24] 1485 	jnz	00113$
                                   1486 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004222 02 3E 31         [24] 1487 	ljmp	_ak820_nvm_flush
      004225                       1488 00113$:
      004225 22               [24] 1489 	ret
                                   1490 ;------------------------------------------------------------
                                   1491 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1492 ;------------------------------------------------------------
                                   1493 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1494 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1495 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1496 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1497 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1498 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1499 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1500 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1501 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1502 ;------------------------------------------------------------
                                   1503 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1504 ;	-----------------------------------------
                                   1505 ;	 function ak820_eeprom_update_block_xdata
                                   1506 ;	-----------------------------------------
      004226                       1507 _ak820_eeprom_update_block_xdata:
      004226 12 38 81         [24] 1508 	lcall	_ak820_outline_0111
      004229 90 05 9A         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00422C 12 38 86         [24] 1510 	lcall	_ak820_outline_0112
                                   1511 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00422F 90 05 9A         [24] 1512 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004232 12 38 2D         [24] 1513 	lcall	_ak820_outline_0058
                                   1514 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004235 90 05 95         [24] 1515 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004238 E0               [24] 1516 	movx	a,@dptr
      004239 F5 12            [12] 1517 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00423B A3               [24] 1518 	inc	dptr
      00423C E0               [24] 1519 	movx	a,@dptr
      00423D F5 13            [12] 1520 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00423F A3               [24] 1521 	inc	dptr
      004240 E0               [24] 1522 	movx	a,@dptr
      004241 F5 14            [12] 1523 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004243 A9 12            [24] 1524 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004245 AA 13            [24] 1525 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1526 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004247 E4               [12] 1527 	clr	a
      004248 F5 0E            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00424A F5 0F            [12] 1529 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00424C                       1530 00105$:
      00424C 90 05 98         [24] 1531 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00424F E0               [24] 1532 	movx	a,@dptr
      004250 F5 10            [12] 1533 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004252 A3               [24] 1534 	inc	dptr
      004253 E0               [24] 1535 	movx	a,@dptr
      004254 F5 11            [12] 1536 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004256 C3               [12] 1537 	clr	c
      004257 E5 0E            [12] 1538 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004259 95 10            [12] 1539 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00425B E5 0F            [12] 1540 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00425D 95 11            [12] 1541 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00425F 50 68            [24] 1542 	jnc	00107$
                                   1543 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004261 89 00            [24] 1544 	mov	ar0,r1
      004263 8A 05            [24] 1545 	mov	ar5,r2
      004265 E5 0E            [12] 1546 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004267 28               [12] 1547 	add	a, r0
      004268 F8               [12] 1548 	mov	r0,a
      004269 E5 0F            [12] 1549 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00426B 3D               [12] 1550 	addc	a, r5
      00426C FD               [12] 1551 	mov	r5,a
      00426D 88 82            [24] 1552 	mov	dpl, r0
      00426F 8D 83            [24] 1553 	mov	dph, r5
      004271 C0 07            [24] 1554 	push	ar7
      004273 C0 06            [24] 1555 	push	ar6
      004275 C0 02            [24] 1556 	push	ar2
      004277 C0 01            [24] 1557 	push	ar1
      004279 12 40 23         [24] 1558 	lcall	_read_offset
      00427C AD 82            [24] 1559 	mov	r5, dpl
      00427E D0 01            [24] 1560 	pop	ar1
      004280 D0 02            [24] 1561 	pop	ar2
      004282 D0 06            [24] 1562 	pop	ar6
      004284 D0 07            [24] 1563 	pop	ar7
      004286 E5 0E            [12] 1564 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004288 2E               [12] 1565 	add	a, r6
      004289 F5 82            [12] 1566 	mov	dpl,a
      00428B E5 0F            [12] 1567 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00428D 3F               [12] 1568 	addc	a, r7
      00428E F5 83            [12] 1569 	mov	dph,a
      004290 E0               [24] 1570 	movx	a,@dptr
      004291 FC               [12] 1571 	mov	r4,a
      004292 ED               [12] 1572 	mov	a,r5
      004293 B5 04 02         [24] 1573 	cjne	a,ar4,00131$
      004296 80 27            [24] 1574 	sjmp	00106$
      004298                       1575 00131$:
                                   1576 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004298 90 05 9A         [24] 1577 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00429B E0               [24] 1578 	movx	a,@dptr
      00429C F8               [12] 1579 	mov	r0,a
      00429D A3               [24] 1580 	inc	dptr
      00429E E0               [24] 1581 	movx	a,@dptr
      00429F FD               [12] 1582 	mov	r5,a
      0042A0 90 05 8E         [24] 1583 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0042A3 E5 12            [12] 1584 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042A5 F0               [24] 1585 	movx	@dptr,a
      0042A6 E5 13            [12] 1586 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0042A8 A3               [24] 1587 	inc	dptr
      0042A9 F0               [24] 1588 	movx	@dptr,a
      0042AA E5 14            [12] 1589 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042AC A3               [24] 1590 	inc	dptr
      0042AD F0               [24] 1591 	movx	@dptr,a
      0042AE 90 05 91         [24] 1592 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042B1 E5 10            [12] 1593 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042B3 F0               [24] 1594 	movx	@dptr,a
      0042B4 E5 11            [12] 1595 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042B6 A3               [24] 1596 	inc	dptr
      0042B7 F0               [24] 1597 	movx	@dptr,a
      0042B8 88 82            [24] 1598 	mov	dpl, r0
      0042BA 8D 83            [24] 1599 	mov	dph, r5
                                   1600 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042BC 02 41 43         [24] 1601 	ljmp	_ak820_eeprom_write_block_xdata
      0042BF                       1602 00106$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042BF 05 0E            [12] 1604 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042C1 E4               [12] 1605 	clr	a
      0042C2 B5 0E 87         [24] 1606 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042C5 05 0F            [12] 1607 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042C7 80 83            [24] 1608 	sjmp	00105$
      0042C9                       1609 00107$:
                                   1610 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042C9 22               [24] 1611 	ret
                                   1612 ;------------------------------------------------------------
                                   1613 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1614 ;------------------------------------------------------------
                                   1615 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1616 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1617 ;------------------------------------------------------------
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1619 ;	-----------------------------------------
                                   1620 ;	 function eeprom_driver_erase
                                   1621 ;	-----------------------------------------
      0042CA                       1622 _eeprom_driver_erase:
                                   1623 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042CA 12 3E 31         [24] 1624 	lcall	_ak820_nvm_flush
                                   1625 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042CD 7F 00            [12] 1626 	mov	r7,#0x00
      0042CF                       1627 00111$:
      0042CF BF A0 01         [24] 1628 	cjne	r7,#0xa0,00165$
      0042D2 22               [24] 1629 	ret
      0042D3                       1630 00165$:
      0042D3 20 0B 32         [24] 1631 	jb	_storage_failed,00113$
                                   1632 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042D6 8F 82            [24] 1633 	mov	dpl, r7
      0042D8 C0 07            [24] 1634 	push	ar7
      0042DA 12 3F B1         [24] 1635 	lcall	_load_page
      0042DD E5 82            [12] 1636 	mov	a, dpl
      0042DF D0 07            [24] 1637 	pop	ar7
      0042E1 70 01            [24] 1638 	jnz	00126$
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042E3 22               [24] 1640 	ret
      0042E4                       1641 00126$:
      0042E4 7E 00            [12] 1642 	mov	r6,#0x00
      0042E6                       1643 00107$:
                                   1644 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042E6 EE               [12] 1645 	mov	a,r6
      0042E7 24 1D            [12] 1646 	add	a, #_page_data
      0042E9 FC               [12] 1647 	mov	r4,a
      0042EA E4               [12] 1648 	clr	a
      0042EB 34 05            [12] 1649 	addc	a, #(_page_data >> 8)
      0042ED FD               [12] 1650 	mov	r5,a
      0042EE 12 43 52         [24] 1651 	lcall	_ak820_outline_0085
      0042F1 60 07            [24] 1652 	jz	00108$
      0042F3 12 38 A3         [24] 1653 	lcall	_ak820_outline_0132
      0042F6 E4               [12] 1654 	clr	a
      0042F7 F0               [24] 1655 	movx	@dptr,a
                                   1656 ;	assignBit
      0042F8 D2 0A            [12] 1657 	setb	_page_dirty
      0042FA                       1658 00108$:
                                   1659 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042FA 0E               [12] 1660 	inc	r6
      0042FB BE 40 E8         [24] 1661 	cjne	r6,#0x40,00107$
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042FE C0 07            [24] 1663 	push	ar7
      004300 12 3E 31         [24] 1664 	lcall	_ak820_nvm_flush
      004303 D0 07            [24] 1665 	pop	ar7
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004305 0F               [12] 1667 	inc	r7
      004306 80 C7            [24] 1668 	sjmp	00111$
      004308                       1669 00113$:
                                   1670 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004308 22               [24] 1671 	ret
                                   1672 	.area CSEG    (CODE)
                                   1673 	.area CONST   (CODE)
                                   1674 	.area XINIT   (CODE)
                                   1675 	.area CABS    (ABS,CODE)
                                   1676 
                                   1677 ; Experimental exact instruction outlining.
                                   1678 	.globl _ak820_outline_0006
                                   1679 	.globl _ak820_outline_0014
                                   1680 	.globl _ak820_outline_0020
                                   1681 	.globl _ak820_outline_0026
                                   1682 	.globl _ak820_outline_0037
                                   1683 	.globl _ak820_outline_0041
                                   1684 	.globl _ak820_outline_0048
                                   1685 	.globl _ak820_outline_0058
                                   1686 	.globl _ak820_outline_0059
                                   1687 	.globl _ak820_outline_0065
                                   1688 	.globl _ak820_outline_0069
                                   1689 	.globl _ak820_outline_0071
                                   1690 	.globl _ak820_outline_0078
                                   1691 	.globl _ak820_outline_0083
                                   1692 	.globl _ak820_outline_0084
                                   1693 	.globl _ak820_outline_0085
                                   1694 	.globl _ak820_outline_0086
                                   1695 	.globl _ak820_outline_0104
                                   1696 	.globl _ak820_outline_0107
                                   1697 	.globl _ak820_outline_0109
                                   1698 	.globl _ak820_outline_0111
                                   1699 	.globl _ak820_outline_0112
                                   1700 	.globl _ak820_outline_0124
                                   1701 	.globl _ak820_outline_0131
                                   1702 	.globl _ak820_outline_0132
                                   1703 	.globl _ak820_outline_0134
                                   1704 	.globl _ak820_outline_0142
                                   1705 	.globl _ak820_outline_0143
                                   1706 	.globl _ak820_outline_0149
                                   1707 	.globl _ak820_outline_0151
                                   1708 	.globl _ak820_outline_0156
                                   1709 	.globl _ak820_outline_0163
                                   1710 	.globl _ak820_outline_0166
                                   1711 	.globl _ak820_outline_0168
                                   1712 	.globl _ak820_outline_0177
                                   1713 	.globl _ak820_outline_0190
                                   1714 
                                   1715 	.area CSEG (CODE)
                                   1716 ; function ak820_outline_0014
      004309                       1717 _ak820_outline_0014:
      004309 8E 82            [24] 1718 	mov	dpl,r6
      00430B 8F 83            [24] 1719 	mov	dph,r7
      00430D A3               [24] 1720 	inc	dptr
      00430E A3               [24] 1721 	inc	dptr
      00430F A3               [24] 1722 	inc	dptr
      004310 A3               [24] 1723 	inc	dptr
      004311 A3               [24] 1724 	inc	dptr
      004312 22               [24] 1725 	ret
                                   1726 
                                   1727 	.area CSEG (CODE)
                                   1728 ; function ak820_outline_0037
      004313                       1729 _ak820_outline_0037:
      004313 F0               [24] 1730 	movx	@dptr,a
      004314 8E 82            [24] 1731 	mov	dpl,r6
      004316 8F 83            [24] 1732 	mov	dph,r7
      004318 A3               [24] 1733 	inc	dptr
      004319 A3               [24] 1734 	inc	dptr
      00431A 22               [24] 1735 	ret
                                   1736 
                                   1737 	.area CSEG (CODE)
                                   1738 ; function ak820_outline_0041
      00431B                       1739 _ak820_outline_0041:
      00431B AF F0            [24] 1740 	mov	r7,b
      00431D AE 83            [24] 1741 	mov	r6,dph
      00431F E5 82            [12] 1742 	mov	a,dpl
      004321 22               [24] 1743 	ret
                                   1744 
                                   1745 	.area CSEG (CODE)
                                   1746 ; function ak820_outline_0048
      004322                       1747 _ak820_outline_0048:
      004322 EF               [12] 1748 	mov	a,r7
      004323 24 75            [12] 1749 	add	a,#_ak820_nvm_flush_header_10000_62
      004325 F5 82            [12] 1750 	mov	dpl,a
      004327 E4               [12] 1751 	clr	a
      004328 34 05            [12] 1752 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00432A F5 83            [12] 1753 	mov	dph,a
      00432C E0               [24] 1754 	movx	a,@dptr
      00432D 22               [24] 1755 	ret
                                   1756 
                                   1757 	.area CSEG (CODE)
                                   1758 ; function ak820_outline_0059
      00432E                       1759 _ak820_outline_0059:
      00432E 8F 06            [24] 1760 	mov	ar6,r7
      004330 7D 00            [12] 1761 	mov	r5,#0x00
      004332 74 40            [12] 1762 	mov	a,#0x40
      004334 2E               [12] 1763 	add	a,r6
      004335 FE               [12] 1764 	mov	r6,a
      004336 74 EF            [12] 1765 	mov	a,#0xef
      004338 3D               [12] 1766 	addc	a,r5
      004339 FD               [12] 1767 	mov	r5,a
      00433A 8E 82            [24] 1768 	mov	dpl,r6
      00433C 8D 83            [24] 1769 	mov	dph,r5
      00433E 22               [24] 1770 	ret
                                   1771 
                                   1772 	.area CSEG (CODE)
                                   1773 ; function ak820_outline_0069
      00433F                       1774 _ak820_outline_0069:
      00433F 8D 82            [24] 1775 	mov	dpl,r5
      004341 8E 83            [24] 1776 	mov	dph,r6
      004343 EC               [12] 1777 	mov	a,r4
      004344 F0               [24] 1778 	movx	@dptr,a
      004345 22               [24] 1779 	ret
                                   1780 
                                   1781 	.area CSEG (CODE)
                                   1782 ; function ak820_outline_0071
      004346                       1783 _ak820_outline_0071:
      004346 F0               [24] 1784 	movx	@dptr,a
      004347 8E 82            [24] 1785 	mov	dpl,r6
      004349 8F 83            [24] 1786 	mov	dph,r7
      00434B 22               [24] 1787 	ret
                                   1788 
                                   1789 	.area CSEG (CODE)
                                   1790 ; function ak820_outline_0083
      00434C                       1791 _ak820_outline_0083:
      00434C E0               [24] 1792 	movx	a,@dptr
      00434D FA               [12] 1793 	mov	r2,a
      00434E A3               [24] 1794 	inc	dptr
      00434F E0               [24] 1795 	movx	a,@dptr
      004350 FB               [12] 1796 	mov	r3,a
      004351 22               [24] 1797 	ret
                                   1798 
                                   1799 	.area CSEG (CODE)
                                   1800 ; function ak820_outline_0085
      004352                       1801 _ak820_outline_0085:
      004352 8C 82            [24] 1802 	mov	dpl,r4
      004354 8D 83            [24] 1803 	mov	dph,r5
      004356 E0               [24] 1804 	movx	a,@dptr
      004357 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0109
      004358                       1809 _ak820_outline_0109:
      004358 EF               [12] 1810 	mov	a,r7
      004359 24 1D            [12] 1811 	add	a,#_page_data
      00435B F5 82            [12] 1812 	mov	dpl,a
      00435D E4               [12] 1813 	clr	a
      00435E 34 05            [12] 1814 	addc	a,#(_page_data>>8)
      004360 F5 83            [12] 1815 	mov	dph,a
      004362 E0               [24] 1816 	movx	a,@dptr
      004363 22               [24] 1817 	ret
                                   1818 
                                   1819 	.area CSEG (CODE)
                                   1820 ; function ak820_outline_0142
      004364                       1821 _ak820_outline_0142:
      004364 AE 82            [24] 1822 	mov	r6,dpl
      004366 AF 83            [24] 1823 	mov	r7,dph
      004368 22               [24] 1824 	ret
                                   1825 
                                   1826 	.area CSEG (CODE)
                                   1827 ; function ak820_outline_0149
      004369                       1828 _ak820_outline_0149:
      004369 42 05            [12] 1829 	orl	ar5,a
      00436B EA               [12] 1830 	mov	a,r2
      00436C 42 04            [12] 1831 	orl	ar4,a
      00436E 22               [24] 1832 	ret
                                   1833 
                                   1834 	.area CSEG (CODE)
                                   1835 ; function ak820_outline_0156
      00436F                       1836 _ak820_outline_0156:
      00436F AC 82            [24] 1837 	mov	r4,dpl
      004371 AD 83            [24] 1838 	mov	r5,dph
      004373 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0163
      004374                       1843 _ak820_outline_0163:
      004374 8F 82            [24] 1844 	mov	dpl,r7
      004376 8E 83            [24] 1845 	mov	dph,r6
      004378 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0166
      004379                       1850 _ak820_outline_0166:
      004379 2E               [12] 1851 	add	a,r6
      00437A FC               [12] 1852 	mov	r4,a
      00437B E4               [12] 1853 	clr	a
      00437C 3F               [12] 1854 	addc	a,r7
      00437D FD               [12] 1855 	mov	r5,a
      00437E 22               [24] 1856 	ret
                                   1857 
                                   1858 	.area CSEG (CODE)
                                   1859 ; function ak820_outline_0168
      00437F                       1860 _ak820_outline_0168:
      00437F ED               [12] 1861 	mov	a,r5
      004380 F0               [24] 1862 	movx	@dptr,a
      004381 EE               [12] 1863 	mov	a,r6
      004382 A3               [24] 1864 	inc	dptr
      004383 F0               [24] 1865 	movx	@dptr,a
      004384 22               [24] 1866 	ret
                                   1867 
                                   1868 	.area CSEG (CODE)
                                   1869 ; function ak820_outline_0177
      004385                       1870 _ak820_outline_0177:
      004385 89 82            [24] 1871 	mov	dpl,r1
      004387 8A 83            [24] 1872 	mov	dph,r2
      004389 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0190
      00438A                       1877 _ak820_outline_0190:
      00438A 8C 82            [24] 1878 	mov	dpl,r4
      00438C 8B 83            [24] 1879 	mov	dph,r3
      00438E 22               [24] 1880 	ret
