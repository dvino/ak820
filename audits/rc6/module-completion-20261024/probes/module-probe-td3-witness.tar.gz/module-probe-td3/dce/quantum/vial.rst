                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_tap_dance
                                     17 	.globl _dynamic_keymap_get_tap_dance
                                     18 	.globl _dynamic_keymap_set_encoder
                                     19 	.globl _dynamic_keymap_get_encoder
                                     20 	.globl _repeat_key_cancel
                                     21 	.globl _ak820_combo_reload
                                     22 	.globl _clear_keyboard
                                     23 	.globl _ak820_action_exec
                                     24 	.globl _timer_elapsed32
                                     25 	.globl _timer_read32
                                     26 	.globl _timer_read
                                     27 	.globl ___memcpy
                                     28 	.globl _ADC_START
                                     29 	.globl _S0_R_FIFO
                                     30 	.globl _S0_T_FIFO
                                     31 	.globl _S0_FREE
                                     32 	.globl _S0_IF_BYTE
                                     33 	.globl _S0_IF_FIRST
                                     34 	.globl _S0_IF_OV
                                     35 	.globl _S0_FST_ACT
                                     36 	.globl _CP_RL2
                                     37 	.globl _C_T2
                                     38 	.globl _TR2
                                     39 	.globl _EXEN2
                                     40 	.globl _TCLK
                                     41 	.globl _RCLK
                                     42 	.globl _EXF2
                                     43 	.globl _CAP1F
                                     44 	.globl _TF2
                                     45 	.globl _RI
                                     46 	.globl _TI
                                     47 	.globl _RB8
                                     48 	.globl _TB8
                                     49 	.globl _REN
                                     50 	.globl _SM2
                                     51 	.globl _SM1
                                     52 	.globl _SM0
                                     53 	.globl _IT0
                                     54 	.globl _IE0
                                     55 	.globl _IT1
                                     56 	.globl _IE1
                                     57 	.globl _TR0
                                     58 	.globl _TF0
                                     59 	.globl _TR1
                                     60 	.globl _TF1
                                     61 	.globl _P4_0
                                     62 	.globl _P4_1
                                     63 	.globl _P4_2
                                     64 	.globl _P4_3
                                     65 	.globl _P4_4
                                     66 	.globl _P4_5
                                     67 	.globl _P4_6
                                     68 	.globl _RXD
                                     69 	.globl _TXD
                                     70 	.globl _INT0
                                     71 	.globl _INT1
                                     72 	.globl _T0
                                     73 	.globl _T1
                                     74 	.globl _MOSI1
                                     75 	.globl _MISO1
                                     76 	.globl _SCK1
                                     77 	.globl _P3_0
                                     78 	.globl _P3_1
                                     79 	.globl _P3_2
                                     80 	.globl _P3_3
                                     81 	.globl _P3_4
                                     82 	.globl _P3_5
                                     83 	.globl _P3_6
                                     84 	.globl _P3_7
                                     85 	.globl _CAP1_
                                     86 	.globl _T2_
                                     87 	.globl _CAP2_
                                     88 	.globl _T2EX_
                                     89 	.globl _RXD1
                                     90 	.globl _TXD1
                                     91 	.globl _P2_0
                                     92 	.globl _P2_1
                                     93 	.globl _P2_2
                                     94 	.globl _P2_3
                                     95 	.globl _P2_4
                                     96 	.globl _P2_5
                                     97 	.globl _P2_6
                                     98 	.globl _P2_7
                                     99 	.globl _AIN0
                                    100 	.globl _AIN1
                                    101 	.globl _AIN2
                                    102 	.globl _AIN3
                                    103 	.globl _AIN4
                                    104 	.globl _AIN5
                                    105 	.globl _AIN6
                                    106 	.globl _AIN7
                                    107 	.globl _CAP1
                                    108 	.globl _T2
                                    109 	.globl _CAP2
                                    110 	.globl _T2EX
                                    111 	.globl _INT0_
                                    112 	.globl _SCS
                                    113 	.globl _MOSI
                                    114 	.globl _MISO
                                    115 	.globl _SCK
                                    116 	.globl _RXD1_
                                    117 	.globl _TXD1_
                                    118 	.globl _P1_0
                                    119 	.globl _P1_1
                                    120 	.globl _P1_2
                                    121 	.globl _P1_3
                                    122 	.globl _P1_4
                                    123 	.globl _P1_5
                                    124 	.globl _P1_6
                                    125 	.globl _P1_7
                                    126 	.globl _AIN8
                                    127 	.globl _AIN9
                                    128 	.globl _AIN10
                                    129 	.globl _AIN11
                                    130 	.globl _AIN12
                                    131 	.globl _AIN13
                                    132 	.globl _RXD_
                                    133 	.globl _TXD_
                                    134 	.globl _SCL0
                                    135 	.globl _SDA0
                                    136 	.globl _P0_0
                                    137 	.globl _P0_1
                                    138 	.globl _P0_2
                                    139 	.globl _P0_3
                                    140 	.globl _P0_4
                                    141 	.globl _P0_5
                                    142 	.globl _P0_6
                                    143 	.globl _P0_7
                                    144 	.globl _IE_SPI0
                                    145 	.globl _IE_USB
                                    146 	.globl _IE_ADC
                                    147 	.globl _IE_UART1
                                    148 	.globl _IE_PWM_I2C
                                    149 	.globl _IE_GPIO
                                    150 	.globl _IE_WDOG
                                    151 	.globl _PX0
                                    152 	.globl _PT0
                                    153 	.globl _PX1
                                    154 	.globl _PT1
                                    155 	.globl _PS
                                    156 	.globl _PT2
                                    157 	.globl _PL_FLAG
                                    158 	.globl _PH_FLAG
                                    159 	.globl _EX0
                                    160 	.globl _ET0
                                    161 	.globl _EX1
                                    162 	.globl _ET1
                                    163 	.globl _ES
                                    164 	.globl _ET2
                                    165 	.globl _E_DIS
                                    166 	.globl _EA
                                    167 	.globl _P
                                    168 	.globl _F1
                                    169 	.globl _OV
                                    170 	.globl _RS0
                                    171 	.globl _RS1
                                    172 	.globl _F0
                                    173 	.globl _AC
                                    174 	.globl _CY
                                    175 	.globl _I2CS_INT_ST
                                    176 	.globl _I2CX_INT
                                    177 	.globl _LED_STATUS
                                    178 	.globl _LED_DMA_H
                                    179 	.globl _LED_DMA_L
                                    180 	.globl _LED_DMA
                                    181 	.globl _LED_PWM_OE
                                    182 	.globl _LED_COMMON
                                    183 	.globl _ADC_CHAN
                                    184 	.globl _ADC_DAT_H
                                    185 	.globl _ADC_DAT_L
                                    186 	.globl _ADC_DAT
                                    187 	.globl _ADC_CTRL
                                    188 	.globl _SPI1_CK_SE
                                    189 	.globl _SPI1_CTRL
                                    190 	.globl _SPI1_DATA
                                    191 	.globl _SPI1_STAT
                                    192 	.globl _SIF1
                                    193 	.globl _SBAUD1
                                    194 	.globl _SBUF1
                                    195 	.globl _SCON1
                                    196 	.globl _SPI0_SETUP
                                    197 	.globl _SPI0_CK_SE
                                    198 	.globl _SPI0_CTRL
                                    199 	.globl _SPI0_DATA
                                    200 	.globl _SPI0_STAT
                                    201 	.globl _T2CAP1H
                                    202 	.globl _T2CAP1L
                                    203 	.globl _T2CAP1
                                    204 	.globl _TH2
                                    205 	.globl _TL2
                                    206 	.globl _T2COUNT
                                    207 	.globl _RCAP2H
                                    208 	.globl _RCAP2L
                                    209 	.globl _RCAP2
                                    210 	.globl _T2MOD
                                    211 	.globl _T2CON
                                    212 	.globl _SBUF
                                    213 	.globl _SCON
                                    214 	.globl _TH1
                                    215 	.globl _TH0
                                    216 	.globl _TL1
                                    217 	.globl _TL0
                                    218 	.globl _TMOD
                                    219 	.globl _TCON
                                    220 	.globl _XBUS_AUX
                                    221 	.globl _P7
                                    222 	.globl _P6_DIR
                                    223 	.globl _P6_OUT_PU
                                    224 	.globl _P6_IN
                                    225 	.globl _P5_DIR
                                    226 	.globl _P5_OUT_PU
                                    227 	.globl _P5_IN
                                    228 	.globl _P4_LED_KEY
                                    229 	.globl _P4_DIR_PU
                                    230 	.globl _P4_MOD_OC
                                    231 	.globl _P4
                                    232 	.globl _P3_DIR_PU
                                    233 	.globl _P3_MOD_OC
                                    234 	.globl _P3
                                    235 	.globl _P2_DIR_PU
                                    236 	.globl _P2_MOD_OC
                                    237 	.globl _P2
                                    238 	.globl _P1_DIR_PU
                                    239 	.globl _P1_MOD_OC
                                    240 	.globl _P1
                                    241 	.globl _P0_DIR_PU
                                    242 	.globl _P0_MOD_OC
                                    243 	.globl _P0
                                    244 	.globl _ROM_CTRL
                                    245 	.globl _ROM_DATA_HH
                                    246 	.globl _ROM_DATA_HL
                                    247 	.globl _ROM_DATA_HI
                                    248 	.globl _ROM_ADDR_H
                                    249 	.globl _ROM_ADDR_L
                                    250 	.globl _ROM_ADDR
                                    251 	.globl _GPIO_IE
                                    252 	.globl _IP_EX
                                    253 	.globl _IE_EX
                                    254 	.globl _IP
                                    255 	.globl _IE
                                    256 	.globl _WDOG_COUNT
                                    257 	.globl _RESET_KEEP
                                    258 	.globl _WAKE_CTRL
                                    259 	.globl _CLOCK_CFG
                                    260 	.globl _POWER_CFG
                                    261 	.globl _PCON
                                    262 	.globl _GLOBAL_CFG
                                    263 	.globl _SAFE_MOD
                                    264 	.globl _DPH
                                    265 	.globl _DPL
                                    266 	.globl _SP
                                    267 	.globl _A_INV
                                    268 	.globl _B
                                    269 	.globl _ACC
                                    270 	.globl _PSW
                                    271 	.globl _vial_unlock_in_progress
                                    272 	.globl _vial_unlocked
                                    273 	.globl _g_vial_magic_keycode_override
                                    274 	.globl _vial_handle_cmd_PARM_2
                                    275 	.globl _vial_unlock_task
                                    276 	.globl _vial_init
                                    277 	.globl _vial_handle_cmd
                                    278 	.globl _vial_keycode_down
                                    279 	.globl _vial_keycode_up
                                    280 	.globl _vial_keycode_tap
                                    281 ;--------------------------------------------------------
                                    282 ; special function registers
                                    283 ;--------------------------------------------------------
                                    284 	.area RSEG    (ABS,DATA)
      000000                        285 	.org 0x0000
                           0000D0   286 _PSW	=	0x00d0
                           0000E0   287 _ACC	=	0x00e0
                           0000F0   288 _B	=	0x00f0
                           0000FD   289 _A_INV	=	0x00fd
                           000081   290 _SP	=	0x0081
                           000082   291 _DPL	=	0x0082
                           000083   292 _DPH	=	0x0083
                           0000A1   293 _SAFE_MOD	=	0x00a1
                           0000B1   294 _GLOBAL_CFG	=	0x00b1
                           000087   295 _PCON	=	0x0087
                           0000BA   296 _POWER_CFG	=	0x00ba
                           0000B9   297 _CLOCK_CFG	=	0x00b9
                           0000A9   298 _WAKE_CTRL	=	0x00a9
                           0000FE   299 _RESET_KEEP	=	0x00fe
                           0000FF   300 _WDOG_COUNT	=	0x00ff
                           0000A8   301 _IE	=	0x00a8
                           0000B8   302 _IP	=	0x00b8
                           0000E8   303 _IE_EX	=	0x00e8
                           0000E9   304 _IP_EX	=	0x00e9
                           0000B2   305 _GPIO_IE	=	0x00b2
                           008584   306 _ROM_ADDR	=	0x8584
                           000084   307 _ROM_ADDR_L	=	0x0084
                           000085   308 _ROM_ADDR_H	=	0x0085
                           008F8E   309 _ROM_DATA_HI	=	0x8f8e
                           00008E   310 _ROM_DATA_HL	=	0x008e
                           00008F   311 _ROM_DATA_HH	=	0x008f
                           000086   312 _ROM_CTRL	=	0x0086
                           000080   313 _P0	=	0x0080
                           0000C4   314 _P0_MOD_OC	=	0x00c4
                           0000C5   315 _P0_DIR_PU	=	0x00c5
                           000090   316 _P1	=	0x0090
                           000092   317 _P1_MOD_OC	=	0x0092
                           000093   318 _P1_DIR_PU	=	0x0093
                           0000A0   319 _P2	=	0x00a0
                           000094   320 _P2_MOD_OC	=	0x0094
                           000095   321 _P2_DIR_PU	=	0x0095
                           0000B0   322 _P3	=	0x00b0
                           000096   323 _P3_MOD_OC	=	0x0096
                           000097   324 _P3_DIR_PU	=	0x0097
                           0000C0   325 _P4	=	0x00c0
                           0000C2   326 _P4_MOD_OC	=	0x00c2
                           0000C3   327 _P4_DIR_PU	=	0x00c3
                           0000C1   328 _P4_LED_KEY	=	0x00c1
                           0000AA   329 _P5_IN	=	0x00aa
                           0000AB   330 _P5_OUT_PU	=	0x00ab
                           0000AC   331 _P5_DIR	=	0x00ac
                           0000AD   332 _P6_IN	=	0x00ad
                           0000AE   333 _P6_OUT_PU	=	0x00ae
                           0000AF   334 _P6_DIR	=	0x00af
                           0000F1   335 _P7	=	0x00f1
                           0000A2   336 _XBUS_AUX	=	0x00a2
                           000088   337 _TCON	=	0x0088
                           000089   338 _TMOD	=	0x0089
                           00008A   339 _TL0	=	0x008a
                           00008B   340 _TL1	=	0x008b
                           00008C   341 _TH0	=	0x008c
                           00008D   342 _TH1	=	0x008d
                           000098   343 _SCON	=	0x0098
                           000099   344 _SBUF	=	0x0099
                           0000C8   345 _T2CON	=	0x00c8
                           0000C9   346 _T2MOD	=	0x00c9
                           00CBCA   347 _RCAP2	=	0xcbca
                           0000CA   348 _RCAP2L	=	0x00ca
                           0000CB   349 _RCAP2H	=	0x00cb
                           00CDCC   350 _T2COUNT	=	0xcdcc
                           0000CC   351 _TL2	=	0x00cc
                           0000CD   352 _TH2	=	0x00cd
                           00CFCE   353 _T2CAP1	=	0xcfce
                           0000CE   354 _T2CAP1L	=	0x00ce
                           0000CF   355 _T2CAP1H	=	0x00cf
                           0000F8   356 _SPI0_STAT	=	0x00f8
                           0000F9   357 _SPI0_DATA	=	0x00f9
                           0000FA   358 _SPI0_CTRL	=	0x00fa
                           0000FB   359 _SPI0_CK_SE	=	0x00fb
                           0000FC   360 _SPI0_SETUP	=	0x00fc
                           0000BC   361 _SCON1	=	0x00bc
                           0000BD   362 _SBUF1	=	0x00bd
                           0000BE   363 _SBAUD1	=	0x00be
                           0000BF   364 _SIF1	=	0x00bf
                           0000B4   365 _SPI1_STAT	=	0x00b4
                           0000B5   366 _SPI1_DATA	=	0x00b5
                           0000B6   367 _SPI1_CTRL	=	0x00b6
                           0000B7   368 _SPI1_CK_SE	=	0x00b7
                           0000F3   369 _ADC_CTRL	=	0x00f3
                           00F5F4   370 _ADC_DAT	=	0xf5f4
                           0000F4   371 _ADC_DAT_L	=	0x00f4
                           0000F5   372 _ADC_DAT_H	=	0x00f5
                           0000F6   373 _ADC_CHAN	=	0x00f6
                           0000A6   374 _LED_COMMON	=	0x00a6
                           0000A7   375 _LED_PWM_OE	=	0x00a7
                           00C7C6   376 _LED_DMA	=	0xc7c6
                           0000C6   377 _LED_DMA_L	=	0x00c6
                           0000C7   378 _LED_DMA_H	=	0x00c7
                           0000F7   379 _LED_STATUS	=	0x00f7
                           0000B3   380 _I2CX_INT	=	0x00b3
                           0000BB   381 _I2CS_INT_ST	=	0x00bb
                                    382 ;--------------------------------------------------------
                                    383 ; special function bits
                                    384 ;--------------------------------------------------------
                                    385 	.area RSEG    (ABS,DATA)
      000000                        386 	.org 0x0000
                           0000D7   387 _CY	=	0x00d7
                           0000D6   388 _AC	=	0x00d6
                           0000D5   389 _F0	=	0x00d5
                           0000D4   390 _RS1	=	0x00d4
                           0000D3   391 _RS0	=	0x00d3
                           0000D2   392 _OV	=	0x00d2
                           0000D1   393 _F1	=	0x00d1
                           0000D0   394 _P	=	0x00d0
                           0000AF   395 _EA	=	0x00af
                           0000AE   396 _E_DIS	=	0x00ae
                           0000AD   397 _ET2	=	0x00ad
                           0000AC   398 _ES	=	0x00ac
                           0000AB   399 _ET1	=	0x00ab
                           0000AA   400 _EX1	=	0x00aa
                           0000A9   401 _ET0	=	0x00a9
                           0000A8   402 _EX0	=	0x00a8
                           0000BF   403 _PH_FLAG	=	0x00bf
                           0000BE   404 _PL_FLAG	=	0x00be
                           0000BD   405 _PT2	=	0x00bd
                           0000BC   406 _PS	=	0x00bc
                           0000BB   407 _PT1	=	0x00bb
                           0000BA   408 _PX1	=	0x00ba
                           0000B9   409 _PT0	=	0x00b9
                           0000B8   410 _PX0	=	0x00b8
                           0000EF   411 _IE_WDOG	=	0x00ef
                           0000EE   412 _IE_GPIO	=	0x00ee
                           0000ED   413 _IE_PWM_I2C	=	0x00ed
                           0000EC   414 _IE_UART1	=	0x00ec
                           0000EB   415 _IE_ADC	=	0x00eb
                           0000E9   416 _IE_USB	=	0x00e9
                           0000E8   417 _IE_SPI0	=	0x00e8
                           000087   418 _P0_7	=	0x0087
                           000086   419 _P0_6	=	0x0086
                           000085   420 _P0_5	=	0x0085
                           000084   421 _P0_4	=	0x0084
                           000083   422 _P0_3	=	0x0083
                           000082   423 _P0_2	=	0x0082
                           000081   424 _P0_1	=	0x0081
                           000080   425 _P0_0	=	0x0080
                           000081   426 _SDA0	=	0x0081
                           000080   427 _SCL0	=	0x0080
                           000083   428 _TXD_	=	0x0083
                           000082   429 _RXD_	=	0x0082
                           000085   430 _AIN13	=	0x0085
                           000084   431 _AIN12	=	0x0084
                           000083   432 _AIN11	=	0x0083
                           000082   433 _AIN10	=	0x0082
                           000081   434 _AIN9	=	0x0081
                           000080   435 _AIN8	=	0x0080
                           000097   436 _P1_7	=	0x0097
                           000096   437 _P1_6	=	0x0096
                           000095   438 _P1_5	=	0x0095
                           000094   439 _P1_4	=	0x0094
                           000093   440 _P1_3	=	0x0093
                           000092   441 _P1_2	=	0x0092
                           000091   442 _P1_1	=	0x0091
                           000090   443 _P1_0	=	0x0090
                           000097   444 _TXD1_	=	0x0097
                           000096   445 _RXD1_	=	0x0096
                           000097   446 _SCK	=	0x0097
                           000096   447 _MISO	=	0x0096
                           000095   448 _MOSI	=	0x0095
                           000094   449 _SCS	=	0x0094
                           000092   450 _INT0_	=	0x0092
                           000091   451 _T2EX	=	0x0091
                           000091   452 _CAP2	=	0x0091
                           000090   453 _T2	=	0x0090
                           000090   454 _CAP1	=	0x0090
                           000097   455 _AIN7	=	0x0097
                           000096   456 _AIN6	=	0x0096
                           000095   457 _AIN5	=	0x0095
                           000094   458 _AIN4	=	0x0094
                           000093   459 _AIN3	=	0x0093
                           000092   460 _AIN2	=	0x0092
                           000091   461 _AIN1	=	0x0091
                           000090   462 _AIN0	=	0x0090
                           0000A7   463 _P2_7	=	0x00a7
                           0000A6   464 _P2_6	=	0x00a6
                           0000A5   465 _P2_5	=	0x00a5
                           0000A4   466 _P2_4	=	0x00a4
                           0000A3   467 _P2_3	=	0x00a3
                           0000A2   468 _P2_2	=	0x00a2
                           0000A1   469 _P2_1	=	0x00a1
                           0000A0   470 _P2_0	=	0x00a0
                           0000A7   471 _TXD1	=	0x00a7
                           0000A6   472 _RXD1	=	0x00a6
                           0000A5   473 _T2EX_	=	0x00a5
                           0000A5   474 _CAP2_	=	0x00a5
                           0000A4   475 _T2_	=	0x00a4
                           0000A4   476 _CAP1_	=	0x00a4
                           0000B7   477 _P3_7	=	0x00b7
                           0000B6   478 _P3_6	=	0x00b6
                           0000B5   479 _P3_5	=	0x00b5
                           0000B4   480 _P3_4	=	0x00b4
                           0000B3   481 _P3_3	=	0x00b3
                           0000B2   482 _P3_2	=	0x00b2
                           0000B1   483 _P3_1	=	0x00b1
                           0000B0   484 _P3_0	=	0x00b0
                           0000B7   485 _SCK1	=	0x00b7
                           0000B6   486 _MISO1	=	0x00b6
                           0000B5   487 _MOSI1	=	0x00b5
                           0000B5   488 _T1	=	0x00b5
                           0000B4   489 _T0	=	0x00b4
                           0000B3   490 _INT1	=	0x00b3
                           0000B2   491 _INT0	=	0x00b2
                           0000B1   492 _TXD	=	0x00b1
                           0000B0   493 _RXD	=	0x00b0
                           0000C6   494 _P4_6	=	0x00c6
                           0000C5   495 _P4_5	=	0x00c5
                           0000C4   496 _P4_4	=	0x00c4
                           0000C3   497 _P4_3	=	0x00c3
                           0000C2   498 _P4_2	=	0x00c2
                           0000C1   499 _P4_1	=	0x00c1
                           0000C0   500 _P4_0	=	0x00c0
                           00008F   501 _TF1	=	0x008f
                           00008E   502 _TR1	=	0x008e
                           00008D   503 _TF0	=	0x008d
                           00008C   504 _TR0	=	0x008c
                           00008B   505 _IE1	=	0x008b
                           00008A   506 _IT1	=	0x008a
                           000089   507 _IE0	=	0x0089
                           000088   508 _IT0	=	0x0088
                           00009F   509 _SM0	=	0x009f
                           00009E   510 _SM1	=	0x009e
                           00009D   511 _SM2	=	0x009d
                           00009C   512 _REN	=	0x009c
                           00009B   513 _TB8	=	0x009b
                           00009A   514 _RB8	=	0x009a
                           000099   515 _TI	=	0x0099
                           000098   516 _RI	=	0x0098
                           0000CF   517 _TF2	=	0x00cf
                           0000CF   518 _CAP1F	=	0x00cf
                           0000CE   519 _EXF2	=	0x00ce
                           0000CD   520 _RCLK	=	0x00cd
                           0000CC   521 _TCLK	=	0x00cc
                           0000CB   522 _EXEN2	=	0x00cb
                           0000CA   523 _TR2	=	0x00ca
                           0000C9   524 _C_T2	=	0x00c9
                           0000C8   525 _CP_RL2	=	0x00c8
                           0000FF   526 _S0_FST_ACT	=	0x00ff
                           0000FE   527 _S0_IF_OV	=	0x00fe
                           0000FD   528 _S0_IF_FIRST	=	0x00fd
                           0000FC   529 _S0_IF_BYTE	=	0x00fc
                           0000FB   530 _S0_FREE	=	0x00fb
                           0000FA   531 _S0_T_FIFO	=	0x00fa
                           0000F8   532 _S0_R_FIFO	=	0x00f8
                           0000F7   533 _ADC_START	=	0x00f7
                                    534 ;--------------------------------------------------------
                                    535 ; overlayable register banks
                                    536 ;--------------------------------------------------------
                                    537 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        538 	.ds 8
                                    539 ;--------------------------------------------------------
                                    540 ; internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area DSEG    (DATA)
      000046                        543 _vial_handle_cmd_sloc0_1_0:
      000046                        544 	.ds 2
      000048                        545 _vial_handle_cmd_sloc1_1_0:
      000048                        546 	.ds 2
      00004A                        547 _vial_handle_cmd_sloc2_1_0:
      00004A                        548 	.ds 2
      00004C                        549 _vial_handle_cmd_sloc3_1_0:
      00004C                        550 	.ds 2
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 ;--------------------------------------------------------
                                    555 ; indirectly addressable internal ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area ISEG    (DATA)
                                    558 ;--------------------------------------------------------
                                    559 ; absolute internal ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area IABS    (ABS,DATA)
                                    562 	.area IABS    (ABS,DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; bit data
                                    565 ;--------------------------------------------------------
                                    566 	.area BSEG    (BIT)
                                    567 ;--------------------------------------------------------
                                    568 ; paged external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area PSEG    (PAG,XDATA)
                                    571 ;--------------------------------------------------------
                                    572 ; uninitialized external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area XSEG    (XDATA)
      000D2E                        575 _vial_unlock_timer:
      000D2E                        576 	.ds 4
      000D32                        577 _vial_unlock_holding:
      000D32                        578 	.ds 1
      000D33                        579 _vial_keycode_firewall_in_10000_611:
      000D33                        580 	.ds 2
      000D35                        581 _vial_fill_packet_PARM_2:
      000D35                        582 	.ds 1
      000D36                        583 _vial_fill_packet_msg_10000_614:
      000D36                        584 	.ds 2
      000D38                        585 _vial_handle_cmd_PARM_2:
      000D38                        586 	.ds 1
      000D39                        587 _vial_handle_cmd_data_10000_619:
      000D39                        588 	.ds 3
      000D3C                        589 _vial_handle_cmd_td_70000_647:
      000D3C                        590 	.ds 10
      000D46                        591 _vial_handle_cmd_td_70000_648:
      000D46                        592 	.ds 10
      000D50                        593 _vial_handle_cmd_entry_70000_649:
      000D50                        594 	.ds 10
      000D5A                        595 _vial_handle_cmd_entry_70000_650:
      000D5A                        596 	.ds 10
      000D64                        597 _g_vial_magic_keycode_override::
      000D64                        598 	.ds 2
      000D66                        599 _vial_keycode_down_keycode_10000_652:
      000D66                        600 	.ds 2
      000D68                        601 _vial_keycode_down_dummy_event_30000_659:
      000D68                        602 	.ds 6
      000D6E                        603 _vial_keycode_up_keycode_10000_660:
      000D6E                        604 	.ds 2
      000D70                        605 _vial_keycode_up_dummy_event_30000_667:
      000D70                        606 	.ds 6
      000D76                        607 _vial_keycode_tap_keycode_10000_668:
      000D76                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
      000F0C                        617 _vial_unlocked::
      000F0C                        618 	.ds 1
      000F0D                        619 _vial_unlock_in_progress::
      000F0D                        620 	.ds 1
      000F0E                        621 _vial_unlock_counter:
      000F0E                        622 	.ds 1
      000F0F                        623 _vial_unlock_combo_rows:
      000F0F                        624 	.ds 2
      000F11                        625 _vial_unlock_combo_cols:
      000F11                        626 	.ds 2
                                    627 	.area HOME    (CODE)
                                    628 	.area GSINIT0 (CODE)
                                    629 	.area GSINIT1 (CODE)
                                    630 	.area GSINIT2 (CODE)
                                    631 	.area GSINIT3 (CODE)
                                    632 	.area GSINIT4 (CODE)
                                    633 	.area GSINIT5 (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 	.area GSFINAL (CODE)
                                    636 	.area CSEG    (CODE)
                                    637 ;--------------------------------------------------------
                                    638 ; global & static initialisations
                                    639 ;--------------------------------------------------------
                                    640 	.area HOME    (CODE)
                                    641 	.area GSINIT  (CODE)
                                    642 	.area GSFINAL (CODE)
                                    643 	.area GSINIT  (CODE)
                                    644 ;--------------------------------------------------------
                                    645 ; Home
                                    646 ;--------------------------------------------------------
                                    647 	.area HOME    (CODE)
                                    648 	.area HOME    (CODE)
                                    649 ;--------------------------------------------------------
                                    650 ; code
                                    651 ;--------------------------------------------------------
                                    652 	.area CSEG    (CODE)
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    655 ;------------------------------------------------------------
                                    656 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    657 ;------------------------------------------------------------
                                    658 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    659 ;	-----------------------------------------
                           000007   660 	ar7 = 0x07
                           000006   661 	ar6 = 0x06
                           000005   662 	ar5 = 0x05
                           000004   663 	ar4 = 0x04
                           000003   664 	ar3 = 0x03
                           000002   665 	ar2 = 0x02
                           000001   666 	ar1 = 0x01
                           000000   667 	ar0 = 0x00
                                    668 ;	 function vial_unlock_task
                                    669 ;	-----------------------------------------
      00B230                        670 _vial_unlock_task:
                                    671 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B230 90 0F 0D         [24]  672 	mov	dptr,#_vial_unlock_in_progress
      00B233 E0               [24]  673 	movx	a,@dptr
      00B234 70 01            [24]  674 	jnz	00131$
      00B236 22               [24]  675 	ret
                                    676 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B237                        677 00131$:
      00B237 7F 00            [12]  678 	mov	r7,#0x00
      00B239                        679 00115$:
      00B239 BF 02 00         [24]  680 	cjne	r7,#0x02,00184$
      00B23C                        681 00184$:
      00B23C 50 29            [24]  682 	jnc	00105$
                                    683 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B23E EF               [12]  684 	mov	a,r7
      00B23F 12 B8 F1         [24]  685 	lcall	_ak820_outline_0137
      00B242 FE               [12]  686 	mov	r6,a
      00B243 EF               [12]  687 	mov	a,r7
      00B244 12 B8 E6         [24]  688 	lcall	_ak820_outline_0136
      00B247 90 08 28         [24]  689 	mov	dptr,#_matrix_is_on_PARM_2
      00B24A F0               [24]  690 	movx	@dptr,a
      00B24B 8E 82            [24]  691 	mov	dpl, r6
      00B24D C0 07            [24]  692 	push	ar7
      00B24F 12 5E 88         [24]  693 	lcall	_matrix_is_on
      00B252 E5 82            [12]  694 	mov	a, dpl
      00B254 D0 07            [24]  695 	pop	ar7
      00B256 70 0C            [24]  696 	jnz	00116$
                                    697 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B258 90 0D 32         [24]  698 	mov	dptr,#_vial_unlock_holding
      00B25B E4               [12]  699 	clr	a
      00B25C F0               [24]  700 	movx	@dptr,a
                                    701 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B25D 90 0F 0E         [24]  702 	mov	dptr,#_vial_unlock_counter
      00B260 74 1E            [12]  703 	mov	a,#0x1e
      00B262 F0               [24]  704 	movx	@dptr,a
                                    705 ;	quantum/vial.c:69: return;
      00B263 22               [24]  706 	ret
      00B264                        707 00116$:
                                    708 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B264 0F               [12]  709 	inc	r7
      00B265 80 D2            [24]  710 	sjmp	00115$
      00B267                        711 00105$:
                                    712 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B267 90 0D 32         [24]  713 	mov	dptr,#_vial_unlock_holding
      00B26A E0               [24]  714 	movx	a,@dptr
      00B26B 70 12            [24]  715 	jnz	00107$
                                    716 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B26D 90 0D 32         [24]  717 	mov	dptr,#_vial_unlock_holding
      00B270 74 01            [12]  718 	mov	a,#0x01
      00B272 F0               [24]  719 	movx	@dptr,a
                                    720 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B273 12 4E 86         [24]  721 	lcall	_timer_read32
      00B276 12 54 99         [24]  722 	lcall	_ak820_outline_0062
      00B279 90 0D 2E         [24]  723 	mov	dptr,#_vial_unlock_timer
      00B27C 12 96 21         [24]  724 	lcall	_ak820_outline_0007
      00B27F                        725 00107$:
                                    726 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B27F 90 0D 2E         [24]  727 	mov	dptr,#_vial_unlock_timer
      00B282 12 54 88         [24]  728 	lcall	_ak820_outline_0061
      00B285 12 4E DF         [24]  729 	lcall	_timer_elapsed32
      00B288 12 54 99         [24]  730 	lcall	_ak820_outline_0062
                                    731 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B28B 7B 1E            [12]  732 	mov	r3,#0x1e
      00B28D                        733 00109$:
      00B28D EB               [12]  734 	mov	a,r3
      00B28E 60 22            [24]  735 	jz	00111$
      00B290 C3               [12]  736 	clr	c
      00B291 EC               [12]  737 	mov	a,r4
      00B292 94 64            [12]  738 	subb	a,#0x64
      00B294 ED               [12]  739 	mov	a,r5
      00B295 94 00            [12]  740 	subb	a,#0x00
      00B297 EE               [12]  741 	mov	a,r6
      00B298 94 00            [12]  742 	subb	a,#0x00
      00B29A EF               [12]  743 	mov	a,r7
      00B29B 94 00            [12]  744 	subb	a,#0x00
      00B29D 40 13            [24]  745 	jc	00111$
                                    746 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B29F EC               [12]  747 	mov	a,r4
      00B2A0 24 9C            [12]  748 	add	a,#0x9c
      00B2A2 FC               [12]  749 	mov	r4,a
      00B2A3 ED               [12]  750 	mov	a,r5
      00B2A4 34 FF            [12]  751 	addc	a,#0xff
      00B2A6 FD               [12]  752 	mov	r5,a
      00B2A7 EE               [12]  753 	mov	a,r6
      00B2A8 34 FF            [12]  754 	addc	a,#0xff
      00B2AA FE               [12]  755 	mov	r6,a
      00B2AB EF               [12]  756 	mov	a,r7
      00B2AC 34 FF            [12]  757 	addc	a,#0xff
      00B2AE FF               [12]  758 	mov	r7,a
                                    759 ;	quantum/vial.c:82: --counter;
      00B2AF 1B               [12]  760 	dec	r3
      00B2B0 80 DB            [24]  761 	sjmp	00109$
      00B2B2                        762 00111$:
                                    763 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B2B2 90 0F 0E         [24]  764 	mov	dptr,#_vial_unlock_counter
      00B2B5 EB               [12]  765 	mov	a,r3
      00B2B6 F0               [24]  766 	movx	@dptr,a
                                    767 ;	quantum/vial.c:85: if (!counter) {
      00B2B7 EB               [12]  768 	mov	a,r3
      00B2B8 70 0A            [24]  769 	jnz	00117$
                                    770 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B2BA 90 0F 0D         [24]  771 	mov	dptr,#_vial_unlock_in_progress
      00B2BD E4               [12]  772 	clr	a
      00B2BE F0               [24]  773 	movx	@dptr,a
                                    774 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B2BF 90 0F 0C         [24]  775 	mov	dptr,#_vial_unlocked
      00B2C2 04               [12]  776 	inc	a
      00B2C3 F0               [24]  777 	movx	@dptr,a
      00B2C4                        778 00117$:
                                    779 ;	quantum/vial.c:90: }
      00B2C4 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'vial_init'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/vial.c:117: void vial_init(void) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function vial_init
                                    787 ;	-----------------------------------------
      00B2C5                        788 _vial_init:
                                    789 ;	quantum/vial.c:125: reload_combo();
                                    790 ;	quantum/vial.c:130: }
      00B2C5 02 35 7C         [24]  791 	ljmp	_ak820_combo_reload
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    794 ;------------------------------------------------------------
                                    795 ;in            Allocated with name '_vial_keycode_firewall_in_10000_611'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function vial_keycode_firewall
                                    800 ;	-----------------------------------------
      00B2C8                        801 _vial_keycode_firewall:
      00B2C8 12 38 81         [24]  802 	lcall	_ak820_outline_0111
      00B2CB 90 0D 33         [24]  803 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B2CE 12 38 86         [24]  804 	lcall	_ak820_outline_0112
                                    805 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B2D1 90 0D 33         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B2D4 12 4D E6         [24]  807 	lcall	_ak820_outline_0010
      00B2D7 BC 00 0D         [24]  808 	cjne	r4,#0x00,00102$
      00B2DA BD 7C 0A         [24]  809 	cjne	r5,#0x7c,00102$
      00B2DD 90 0F 0C         [24]  810 	mov	dptr,#_vial_unlocked
      00B2E0 E0               [24]  811 	movx	a,@dptr
      00B2E1 70 04            [24]  812 	jnz	00102$
                                    813 ;	quantum/vial.c:134: return 0;
      00B2E3 90 00 00         [24]  814 	mov	dptr,#0x0000
      00B2E6 22               [24]  815 	ret
      00B2E7                        816 00102$:
                                    817 ;	quantum/vial.c:135: return in;
      00B2E7 12 38 92         [24]  818 	lcall	_ak820_outline_0124
                                    819 ;	quantum/vial.c:136: }
      00B2EA 22               [24]  820 	ret
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'vial_fill_packet'
                                    823 ;------------------------------------------------------------
                                    824 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    825 ;msg           Allocated with name '_vial_fill_packet_msg_10000_614'
                                    826 ;i             Allocated with name '_vial_fill_packet_i_20000_616'
                                    827 ;------------------------------------------------------------
                                    828 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    829 ;	-----------------------------------------
                                    830 ;	 function vial_fill_packet
                                    831 ;	-----------------------------------------
      00B2EB                        832 _vial_fill_packet:
      00B2EB 12 38 81         [24]  833 	lcall	_ak820_outline_0111
      00B2EE 90 0D 36         [24]  834 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B2F1 12 38 86         [24]  835 	lcall	_ak820_outline_0112
                                    836 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B2F4 90 0D 36         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B2F7 12 38 2D         [24]  838 	lcall	_ak820_outline_0058
      00B2FA 90 0D 35         [24]  839 	mov	dptr,#_vial_fill_packet_PARM_2
      00B2FD E0               [24]  840 	movx	a,@dptr
      00B2FE FD               [12]  841 	mov	r5,a
      00B2FF 7C 00            [12]  842 	mov	r4,#0x00
      00B301                        843 00103$:
      00B301 BC 20 00         [24]  844 	cjne	r4,#0x20,00122$
      00B304                        845 00122$:
      00B304 50 09            [24]  846 	jnc	00105$
      00B306 EC               [12]  847 	mov	a,r4
      00B307 12 38 1D         [24]  848 	lcall	_ak820_outline_0026
      00B30A ED               [12]  849 	mov	a,r5
      00B30B F0               [24]  850 	movx	@dptr,a
      00B30C 0C               [12]  851 	inc	r4
      00B30D 80 F2            [24]  852 	sjmp	00103$
      00B30F                        853 00105$:
                                    854 ;	quantum/vial.c:141: }
      00B30F 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'vial_release_held_state'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function vial_release_held_state
                                    862 ;	-----------------------------------------
      00B310                        863 _vial_release_held_state:
                                    864 ;	quantum/vial.c:174: repeat_key_cancel();
      00B310 12 A7 2F         [24]  865 	lcall	_repeat_key_cancel
                                    866 ;	quantum/vial.c:176: clear_keyboard();
                                    867 ;	quantum/vial.c:177: }
      00B313 02 7B 8A         [24]  868 	ljmp	_clear_keyboard
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    871 ;------------------------------------------------------------
                                    872 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    873 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    874 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    875 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    876 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    877 ;data          Allocated with name '_vial_handle_cmd_data_10000_619'
                                    878 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_620'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50000_625'
                                    880 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_626'
                                    881 ;page          Allocated with name '_vial_handle_cmd_page_40001_629'
                                    882 ;start         Allocated with name '_vial_handle_cmd_start_40002_631'
                                    883 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_631'
                                    884 ;count         Allocated with name '_vial_handle_cmd_count_40002_631'
                                    885 ;i             Allocated with name '_vial_handle_cmd_i_50002_632'
                                    886 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_633'
                                    887 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_633'
                                    888 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_633'
                                    889 ;i             Allocated with name '_vial_handle_cmd_i_50000_636'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    891 ;td            Allocated with name '_vial_handle_cmd_td_70000_647'
                                    892 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_648'
                                    893 ;td            Allocated with name '_vial_handle_cmd_td_70000_648'
                                    894 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_649'
                                    895 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_649'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_650'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_650'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function vial_handle_cmd
                                    902 ;	-----------------------------------------
      00B316                        903 _vial_handle_cmd:
      00B316 12 43 1B         [24]  904 	lcall	_ak820_outline_0041
      00B319 90 0D 39         [24]  905 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B31C 12 38 15         [24]  906 	lcall	_ak820_outline_0020
                                    907 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B31F 90 0D 39         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B322 12 38 2D         [24]  909 	lcall	_ak820_outline_0058
                                    910 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B325 90 0D 38         [24]  911 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B328 E0               [24]  912 	movx	a,@dptr
      00B329 FD               [12]  913 	mov	r5,a
      00B32A BD 20 02         [24]  914 	cjne	r5,#0x20,00246$
      00B32D 80 01            [24]  915 	sjmp	00102$
      00B32F                        916 00246$:
                                    917 ;	quantum/vial.c:190: return;
      00B32F 22               [24]  918 	ret
      00B330                        919 00102$:
                                    920 ;	quantum/vial.c:193: switch (msg[1]) {
      00B330 74 01            [12]  921 	mov	a,#0x01
      00B332 12 48 AC         [24]  922 	lcall	_ak820_outline_0013
      00B335 FB               [12]  923 	mov  r3,a
      00B336 24 F2            [12]  924 	add	a,#0xff - 0x0d
      00B338 50 01            [24]  925 	jnc	00247$
      00B33A 22               [24]  926 	ret
      00B33B                        927 00247$:
                                    928 ;	free result
      00B33B EB               [12]  929 	mov	a,r3
      00B33C 24 0A            [12]  930 	add	a,#(00248$-3-.)
      00B33E 83               [24]  931 	movc	a,@a+pc
      00B33F F5 82            [12]  932 	mov	dpl,a
      00B341 EB               [12]  933 	mov	a,r3
      00B342 24 12            [12]  934 	add	a,#(00249$-3-.)
      00B344 83               [24]  935 	movc	a,@a+pc
      00B345 F5 83            [12]  936 	mov	dph,a
      00B347 E4               [12]  937 	clr	a
      00B348 73               [24]  938 	jmp	@a+dptr
      00B349                        939 00248$:
      00B349 65                     940 	.db	00103$
      00B34A AD                     941 	.db	00105$
      00B34B C1                     942 	.db	00106$
      00B34C 4D                     943 	.db	00112$
      00B34D D3                     944 	.db	00113$
      00B34E 1D                     945 	.db	00114$
      00B34F 8C                     946 	.db	00116$
      00B350 A7                     947 	.db	00119$
      00B351 C7                     948 	.db	00120$
      00B352 D5                     949 	.db	00121$
      00B353 C9                     950 	.db	00141$
      00B354 C9                     951 	.db	00141$
      00B355 C9                     952 	.db	00141$
      00B356 E0                     953 	.db	00122$
      00B357                        954 00249$:
      00B357 B3                     955 	.db	00103$>>8
      00B358 B3                     956 	.db	00105$>>8
      00B359 B3                     957 	.db	00106$>>8
      00B35A B4                     958 	.db	00112$>>8
      00B35B B4                     959 	.db	00113$>>8
      00B35C B5                     960 	.db	00114$>>8
      00B35D B5                     961 	.db	00116$>>8
      00B35E B5                     962 	.db	00119$>>8
      00B35F B5                     963 	.db	00120$>>8
      00B360 B5                     964 	.db	00121$>>8
      00B361 B7                     965 	.db	00141$>>8
      00B362 B7                     966 	.db	00141$>>8
      00B363 B7                     967 	.db	00141$>>8
      00B364 B5                     968 	.db	00122$>>8
                                    969 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B365                        970 00103$:
                                    971 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B365 90 0D 35         [24]  972 	mov	dptr,#_vial_fill_packet_PARM_2
      00B368 E4               [12]  973 	clr	a
      00B369 12 43 46         [24]  974 	lcall	_ak820_outline_0071
      00B36C C0 07            [24]  975 	push	ar7
      00B36E C0 06            [24]  976 	push	ar6
      00B370 12 B2 EB         [24]  977 	lcall	_vial_fill_packet
      00B373 D0 06            [24]  978 	pop	ar6
      00B375 D0 07            [24]  979 	pop	ar7
                                    980 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B377 12 38 92         [24]  981 	lcall	_ak820_outline_0124
      00B37A 74 06            [12]  982 	mov	a,#0x06
      00B37C 12 43 46         [24]  983 	lcall	_ak820_outline_0071
                                    984 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B37F A3               [24]  985 	inc	dptr
      00B380 E4               [12]  986 	clr	a
      00B381 12 43 13         [24]  987 	lcall	_ak820_outline_0037
                                    988 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B384 12 43 13         [24]  989 	lcall	_ak820_outline_0037
                                    990 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B387 A3               [24]  991 	inc	dptr
      00B388 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B389 FB               [12]  994 	mov	r3,a
      00B38A                        995 00133$:
      00B38A BB 08 00         [24]  996 	cjne	r3,#0x08,00250$
      00B38D                        997 00250$:
      00B38D 50 15            [24]  998 	jnc	00104$
      00B38F 8B 02            [24]  999 	mov	ar2,r3
      00B391 74 04            [12] 1000 	mov	a,#0x04
      00B393 2A               [12] 1001 	add	a, r2
      00B394 2E               [12] 1002 	add	a, r6
      00B395 F9               [12] 1003 	mov	r1,a
      00B396 E4               [12] 1004 	clr	a
      00B397 3F               [12] 1005 	addc	a,r7
      00B398 FA               [12] 1006 	mov	r2,a
      00B399 EB               [12] 1007 	mov	a,r3
      00B39A 90 C5 88         [24] 1008 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_624
      00B39D 93               [24] 1009 	movc	a,@a+dptr
      00B39E 12 71 79         [24] 1010 	lcall	_ak820_outline_0146
      00B3A1 0B               [12] 1011 	inc	r3
      00B3A2 80 E6            [24] 1012 	sjmp	00133$
      00B3A4                       1013 00104$:
                                   1014 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B3A4 74 0C            [12] 1015 	mov	a,#0x0c
      00B3A6 12 38 1D         [24] 1016 	lcall	_ak820_outline_0026
      00B3A9 74 01            [12] 1017 	mov	a,#0x01
      00B3AB F0               [24] 1018 	movx	@dptr,a
                                   1019 ;	quantum/vial.c:207: break;
      00B3AC 22               [24] 1020 	ret
                                   1021 ;	quantum/vial.c:210: case vial_get_size: {
      00B3AD                       1022 00105$:
                                   1023 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B3AD 12 38 92         [24] 1024 	lcall	_ak820_outline_0124
      00B3B0 74 7C            [12] 1025 	mov	a,#0x7c
      00B3B2 12 38 75         [24] 1026 	lcall	_ak820_outline_0106
                                   1027 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B3B5 74 01            [12] 1028 	mov	a,#0x01
      00B3B7 12 43 13         [24] 1029 	lcall	_ak820_outline_0037
                                   1030 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B3BA E4               [12] 1031 	clr	a
      00B3BB 12 43 13         [24] 1032 	lcall	_ak820_outline_0037
                                   1033 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B3BE A3               [24] 1034 	inc	dptr
      00B3BF F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/vial.c:216: break;
      00B3C0 22               [24] 1037 	ret
                                   1038 ;	quantum/vial.c:219: case vial_get_def: {
      00B3C1                       1039 00106$:
                                   1040 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B3C1 12 48 CB         [24] 1041 	lcall	_ak820_outline_0022
      00B3C4 E0               [24] 1042 	movx	a,@dptr
      00B3C5 FB               [12] 1043 	mov	r3,a
      00B3C6 12 43 09         [24] 1044 	lcall	_ak820_outline_0014
      00B3C9 E0               [24] 1045 	movx	a,@dptr
      00B3CA 4B               [12] 1046 	orl	a,r3
      00B3CB 60 01            [24] 1047 	jz	00108$
      00B3CD 22               [24] 1048 	ret
      00B3CE                       1049 00108$:
                                   1050 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B3CE 12 38 25         [24] 1051 	lcall	_ak820_outline_0035
      00B3D1 FB               [12] 1052 	mov	r3,a
      00B3D2 7A 00            [12] 1053 	mov	r2,#0x00
      00B3D4 12 48 B7         [24] 1054 	lcall	_ak820_outline_0018
      00B3D7 F9               [12] 1055 	mov	r1,a
      00B3D8 E4               [12] 1056 	clr	a
      00B3D9 42 03            [12] 1057 	orl	ar3,a
      00B3DB E9               [12] 1058 	mov	a,r1
      00B3DC 42 02            [12] 1059 	orl	ar2,a
                                   1060 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B3DE C3               [12] 1061 	clr	c
      00B3DF EB               [12] 1062 	mov	a,r3
      00B3E0 94 0C            [12] 1063 	subb	a,#0x0c
      00B3E2 EA               [12] 1064 	mov	a,r2
      00B3E3 94 00            [12] 1065 	subb	a,#0x00
      00B3E5 40 01            [24] 1066 	jc	00110$
      00B3E7 22               [24] 1067 	ret
      00B3E8                       1068 00110$:
                                   1069 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B3E8 EA               [12] 1070 	mov	a,r2
      00B3E9 C4               [12] 1071 	swap	a
      00B3EA 23               [12] 1072 	rl	a
      00B3EB 54 E0            [12] 1073 	anl	a,#0xe0
      00B3ED CB               [12] 1074 	xch	a,r3
      00B3EE C4               [12] 1075 	swap	a
      00B3EF 23               [12] 1076 	rl	a
      00B3F0 CB               [12] 1077 	xch	a,r3
      00B3F1 6B               [12] 1078 	xrl	a,r3
      00B3F2 CB               [12] 1079 	xch	a,r3
      00B3F3 54 E0            [12] 1080 	anl	a,#0xe0
      00B3F5 CB               [12] 1081 	xch	a,r3
      00B3F6 6B               [12] 1082 	xrl	a,r3
      00B3F7 FA               [12] 1083 	mov	r2,a
      00B3F8 8B 46            [24] 1084 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B3FA 8A 47            [24] 1085 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1086 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B3FC 74 7C            [12] 1087 	mov	a,#0x7c
      00B3FE C3               [12] 1088 	clr	c
      00B3FF 95 46            [12] 1089 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B401 F8               [12] 1090 	mov	r0,a
      00B402 74 01            [12] 1091 	mov	a,#0x01
      00B404 95 47            [12] 1092 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B406 F9               [12] 1093 	mov	r1,a
                                   1094 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B407 C3               [12] 1095 	clr	c
      00B408 E8               [12] 1096 	mov	a,r0
      00B409 94 20            [12] 1097 	subb	a,#0x20
      00B40B E9               [12] 1098 	mov	a,r1
      00B40C 94 00            [12] 1099 	subb	a,#0x00
      00B40E 40 02            [24] 1100 	jc	00144$
      00B410 78 20            [12] 1101 	mov	r0,#0x20
      00B412                       1102 00144$:
                                   1103 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B412 79 00            [12] 1104 	mov	r1,#0x00
      00B414                       1105 00136$:
      00B414 C3               [12] 1106 	clr	c
      00B415 E9               [12] 1107 	mov	a,r1
      00B416 98               [12] 1108 	subb	a,r0
      00B417 40 01            [24] 1109 	jc	00255$
      00B419 22               [24] 1110 	ret
      00B41A                       1111 00255$:
      00B41A C0 00            [24] 1112 	push	ar0
      00B41C E9               [12] 1113 	mov	a,r1
      00B41D 2E               [12] 1114 	add	a, r6
      00B41E F5 48            [12] 1115 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B420 E4               [12] 1116 	clr	a
      00B421 3F               [12] 1117 	addc	a, r7
      00B422 F5 49            [12] 1118 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B424 89 4A            [24] 1119 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B426 75 4B 00         [24] 1120 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B429 A8 46            [24] 1121 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B42B AB 47            [24] 1122 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B42D E5 4A            [12] 1123 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B42F 28               [12] 1124 	add	a, r0
      00B430 F8               [12] 1125 	mov	r0,a
      00B431 E5 4B            [12] 1126 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B433 3B               [12] 1127 	addc	a, r3
      00B434 FB               [12] 1128 	mov	r3,a
      00B435 E8               [12] 1129 	mov	a,r0
      00B436 24 0C            [12] 1130 	add	a, #_keyboard_definition
      00B438 F5 82            [12] 1131 	mov	dpl,a
      00B43A EB               [12] 1132 	mov	a,r3
      00B43B 34 C4            [12] 1133 	addc	a, #(_keyboard_definition >> 8)
      00B43D F5 83            [12] 1134 	mov	dph,a
      00B43F E4               [12] 1135 	clr	a
      00B440 93               [24] 1136 	movc	a,@a+dptr
      00B441 85 48 82         [24] 1137 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B444 85 49 83         [24] 1138 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B447 F0               [24] 1139 	movx	@dptr,a
      00B448 09               [12] 1140 	inc	r1
      00B449 D0 00            [24] 1141 	pop	ar0
                                   1142 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B44B 80 C7            [24] 1143 	sjmp	00136$
      00B44D                       1144 00112$:
                                   1145 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B44D 74 02            [12] 1146 	mov	a,#0x02
      00B44F 12 48 C0         [24] 1147 	lcall	_ak820_outline_0021
      00B452 F5 4A            [12] 1148 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1149 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B454 74 03            [12] 1150 	mov	a,#0x03
      00B456 2E               [12] 1151 	add	a, r6
      00B457 F5 48            [12] 1152 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B459 E4               [12] 1153 	clr	a
      00B45A 3F               [12] 1154 	addc	a, r7
      00B45B F5 49            [12] 1155 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B45D 85 48 82         [24] 1156 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B460 85 49 83         [24] 1157 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B463 E0               [24] 1158 	movx	a,@dptr
                                   1159 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B464 F5 46            [12] 1160 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B466 90 0B AB         [24] 1161 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B469 F0               [24] 1162 	movx	@dptr,a
      00B46A 90 0B AC         [24] 1163 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B46D E4               [12] 1164 	clr	a
      00B46E F0               [24] 1165 	movx	@dptr,a
      00B46F 85 4A 82         [24] 1166 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B472 C0 07            [24] 1167 	push	ar7
      00B474 C0 06            [24] 1168 	push	ar6
      00B476 C0 05            [24] 1169 	push	ar5
      00B478 C0 04            [24] 1170 	push	ar4
      00B47A C0 03            [24] 1171 	push	ar3
      00B47C C0 02            [24] 1172 	push	ar2
      00B47E 12 89 62         [24] 1173 	lcall	_dynamic_keymap_get_encoder
      00B481 85 82 4C         [24] 1174 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B484 85 83 4D         [24] 1175 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B487 D0 02            [24] 1176 	pop	ar2
      00B489 D0 03            [24] 1177 	pop	ar3
      00B48B D0 04            [24] 1178 	pop	ar4
      00B48D D0 05            [24] 1179 	pop	ar5
      00B48F D0 06            [24] 1180 	pop	ar6
      00B491 D0 07            [24] 1181 	pop	ar7
                                   1182 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B493 A9 4D            [24] 1183 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B495 12 38 92         [24] 1184 	lcall	_ak820_outline_0124
      00B498 E9               [12] 1185 	mov	a,r1
      00B499 F0               [24] 1186 	movx	@dptr,a
                                   1187 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B49A A8 4C            [24] 1188 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B49C 12 38 A3         [24] 1189 	lcall	_ak820_outline_0132
      00B49F E8               [12] 1190 	mov	a,r0
      00B4A0 F0               [24] 1191 	movx	@dptr,a
                                   1192 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B4A1 90 0B AB         [24] 1193 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B4A4 E5 46            [12] 1194 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B4A6 F0               [24] 1195 	movx	@dptr,a
      00B4A7 90 0B AC         [24] 1196 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B4AA 74 01            [12] 1197 	mov	a,#0x01
      00B4AC F0               [24] 1198 	movx	@dptr,a
      00B4AD 85 4A 82         [24] 1199 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B4B0 C0 03            [24] 1200 	push	ar3
      00B4B2 C0 02            [24] 1201 	push	ar2
      00B4B4 12 89 62         [24] 1202 	lcall	_dynamic_keymap_get_encoder
      00B4B7 85 82 4C         [24] 1203 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B4BA 85 83 4D         [24] 1204 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B4BD D0 02            [24] 1205 	pop	ar2
      00B4BF D0 03            [24] 1206 	pop	ar3
                                   1207 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B4C1 A9 4D            [24] 1208 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B4C3 12 38 AD         [24] 1209 	lcall	_ak820_outline_0134
      00B4C6 E9               [12] 1210 	mov	a,r1
      00B4C7 F0               [24] 1211 	movx	@dptr,a
                                   1212 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B4C8 A8 4C            [24] 1213 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B4CA 85 48 82         [24] 1214 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B4CD 85 49 83         [24] 1215 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B4D0 E8               [12] 1216 	mov	a,r0
      00B4D1 F0               [24] 1217 	movx	@dptr,a
                                   1218 ;	quantum/vial.c:255: break;
      00B4D2 22               [24] 1219 	ret
                                   1220 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B4D3                       1221 00113$:
                                   1222 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B4D3 12 38 25         [24] 1223 	lcall	_ak820_outline_0035
      00B4D6 F5 48            [12] 1224 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B4D8 12 48 B7         [24] 1225 	lcall	_ak820_outline_0018
      00B4DB F5 4A            [12] 1226 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B4DD 12 48 CB         [24] 1227 	lcall	_ak820_outline_0022
      00B4E0 E0               [24] 1228 	movx	a,@dptr
                                   1229 ;	assignBit
      00B4E1 24 FF            [12] 1230 	add	a,#0xff
      00B4E3 E4               [12] 1231 	clr	a
      00B4E4 33               [12] 1232 	rlc	a
      00B4E5 F5 4C            [12] 1233 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B4E7 12 43 09         [24] 1234 	lcall	_ak820_outline_0014
      00B4EA E0               [24] 1235 	movx	a,@dptr
      00B4EB F9               [12] 1236 	mov	r1,a
      00B4EC 78 00            [12] 1237 	mov	r0,#0x00
      00B4EE 74 06            [12] 1238 	mov	a,#0x06
      00B4F0 12 38 1D         [24] 1239 	lcall	_ak820_outline_0026
      00B4F3 E0               [24] 1240 	movx	a,@dptr
      00B4F4 7B 00            [12] 1241 	mov	r3,#0x00
      00B4F6 42 00            [12] 1242 	orl	ar0,a
      00B4F8 EB               [12] 1243 	mov	a,r3
      00B4F9 42 01            [12] 1244 	orl	ar1,a
      00B4FB 12 7C 55         [24] 1245 	lcall	_ak820_outline_0196
      00B4FE 12 B2 C8         [24] 1246 	lcall	_vial_keycode_firewall
      00B501 AA 82            [24] 1247 	mov	r2, dpl
      00B503 AB 83            [24] 1248 	mov	r3, dph
      00B505 90 0B AE         [24] 1249 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B508 E5 4A            [12] 1250 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B50A F0               [24] 1251 	movx	@dptr,a
      00B50B 90 0B AF         [24] 1252 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B50E E5 4C            [12] 1253 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B510 F0               [24] 1254 	movx	@dptr,a
      00B511 90 0B B0         [24] 1255 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B514 12 49 34         [24] 1256 	lcall	_ak820_outline_0167
      00B517 85 48 82         [24] 1257 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1258 ;	quantum/vial.c:259: break;
      00B51A 02 89 C9         [24] 1259 	ljmp	_dynamic_keymap_set_encoder
                                   1260 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B51D                       1261 00114$:
                                   1262 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B51D 90 0D 35         [24] 1263 	mov	dptr,#_vial_fill_packet_PARM_2
      00B520 74 FF            [12] 1264 	mov	a,#0xff
      00B522 12 43 46         [24] 1265 	lcall	_ak820_outline_0071
      00B525 C0 07            [24] 1266 	push	ar7
      00B527 C0 06            [24] 1267 	push	ar6
      00B529 12 B2 EB         [24] 1268 	lcall	_vial_fill_packet
      00B52C D0 06            [24] 1269 	pop	ar6
      00B52E D0 07            [24] 1270 	pop	ar7
                                   1271 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B530 90 0F 0C         [24] 1272 	mov	dptr,#_vial_unlocked
      00B533 E0               [24] 1273 	movx	a,@dptr
      00B534 12 38 92         [24] 1274 	lcall	_ak820_outline_0124
      00B537 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B538 74 01            [12] 1277 	mov	a,#0x01
      00B53A 2E               [12] 1278 	add	a, r6
      00B53B FA               [12] 1279 	mov	r2,a
      00B53C E4               [12] 1280 	clr	a
      00B53D 3F               [12] 1281 	addc	a, r7
      00B53E FB               [12] 1282 	mov	r3,a
      00B53F 90 0F 0D         [24] 1283 	mov	dptr,#_vial_unlock_in_progress
      00B542 E0               [24] 1284 	movx	a,@dptr
      00B543 12 38 AD         [24] 1285 	lcall	_ak820_outline_0134
      00B546 F0               [24] 1286 	movx	@dptr,a
                                   1287 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B547 7B 00            [12] 1288 	mov	r3,#0x00
      00B549                       1289 00139$:
      00B549 BB 02 00         [24] 1290 	cjne	r3,#0x02,00256$
      00B54C                       1291 00256$:
      00B54C 40 01            [24] 1292 	jc	00257$
      00B54E 22               [24] 1293 	ret
      00B54F                       1294 00257$:
                                   1295 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B54F 8B 01            [24] 1296 	mov	ar1,r3
      00B551 7A 00            [12] 1297 	mov	r2,#0x00
      00B553 E9               [12] 1298 	mov	a,r1
      00B554 29               [12] 1299 	add	a,r1
      00B555 F5 4C            [12] 1300 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B557 EA               [12] 1301 	mov	a,r2
      00B558 33               [12] 1302 	rlc	a
      00B559 F5 4D            [12] 1303 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B55B 74 02            [12] 1304 	mov	a,#0x02
      00B55D 25 4C            [12] 1305 	add	a, _vial_handle_cmd_sloc3_1_0
      00B55F F8               [12] 1306 	mov	r0,a
      00B560 E4               [12] 1307 	clr	a
      00B561 35 4D            [12] 1308 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B563 FA               [12] 1309 	mov	r2,a
      00B564 E8               [12] 1310 	mov	a,r0
      00B565 2E               [12] 1311 	add	a, r6
      00B566 F8               [12] 1312 	mov	r0,a
      00B567 EA               [12] 1313 	mov	a,r2
      00B568 3F               [12] 1314 	addc	a, r7
      00B569 FA               [12] 1315 	mov	r2,a
      00B56A EB               [12] 1316 	mov	a,r3
      00B56B 12 B8 F1         [24] 1317 	lcall	_ak820_outline_0137
      00B56E 88 82            [24] 1318 	mov	dpl,r0
      00B570 8A 83            [24] 1319 	mov	dph,r2
      00B572 F0               [24] 1320 	movx	@dptr,a
                                   1321 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B573 74 03            [12] 1322 	mov	a,#0x03
      00B575 25 4C            [12] 1323 	add	a, _vial_handle_cmd_sloc3_1_0
      00B577 F9               [12] 1324 	mov	r1,a
      00B578 E4               [12] 1325 	clr	a
      00B579 35 4D            [12] 1326 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B57B FA               [12] 1327 	mov	r2,a
      00B57C E9               [12] 1328 	mov	a,r1
      00B57D 2E               [12] 1329 	add	a, r6
      00B57E F9               [12] 1330 	mov	r1,a
      00B57F EA               [12] 1331 	mov	a,r2
      00B580 3F               [12] 1332 	addc	a, r7
      00B581 FA               [12] 1333 	mov	r2,a
      00B582 EB               [12] 1334 	mov	a,r3
      00B583 12 B8 E6         [24] 1335 	lcall	_ak820_outline_0136
      00B586 12 71 79         [24] 1336 	lcall	_ak820_outline_0146
                                   1337 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B589 0B               [12] 1338 	inc	r3
                                   1339 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B58A 80 BD            [24] 1340 	sjmp	00139$
      00B58C                       1341 00116$:
                                   1342 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B58C 90 0F 0D         [24] 1343 	mov	dptr,#_vial_unlock_in_progress
      00B58F E0               [24] 1344 	movx	a,@dptr
      00B590 70 03            [24] 1345 	jnz	00118$
      00B592 12 B3 10         [24] 1346 	lcall	_vial_release_held_state
      00B595                       1347 00118$:
                                   1348 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B595 90 0F 0D         [24] 1349 	mov	dptr,#_vial_unlock_in_progress
      00B598 74 01            [12] 1350 	mov	a,#0x01
      00B59A F0               [24] 1351 	movx	@dptr,a
                                   1352 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B59B 90 0F 0E         [24] 1353 	mov	dptr,#_vial_unlock_counter
      00B59E 74 1E            [12] 1354 	mov	a,#0x1e
      00B5A0 F0               [24] 1355 	movx	@dptr,a
                                   1356 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B5A1 90 0D 32         [24] 1357 	mov	dptr,#_vial_unlock_holding
      00B5A4 E4               [12] 1358 	clr	a
      00B5A5 F0               [24] 1359 	movx	@dptr,a
                                   1360 ;	quantum/vial.c:287: break;
      00B5A6 22               [24] 1361 	ret
                                   1362 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B5A7                       1363 00119$:
                                   1364 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B5A7 90 0F 0C         [24] 1365 	mov	dptr,#_vial_unlocked
      00B5AA E0               [24] 1366 	movx	a,@dptr
      00B5AB 12 38 92         [24] 1367 	lcall	_ak820_outline_0124
      00B5AE F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B5AF 90 0F 0D         [24] 1370 	mov	dptr,#_vial_unlock_in_progress
      00B5B2 E0               [24] 1371 	movx	a,@dptr
      00B5B3 12 38 A3         [24] 1372 	lcall	_ak820_outline_0132
      00B5B6 F0               [24] 1373 	movx	@dptr,a
                                   1374 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B5B7 74 02            [12] 1375 	mov	a,#0x02
      00B5B9 2E               [12] 1376 	add	a, r6
      00B5BA FA               [12] 1377 	mov	r2,a
      00B5BB E4               [12] 1378 	clr	a
      00B5BC 3F               [12] 1379 	addc	a, r7
      00B5BD FB               [12] 1380 	mov	r3,a
      00B5BE 90 0F 0E         [24] 1381 	mov	dptr,#_vial_unlock_counter
      00B5C1 E0               [24] 1382 	movx	a,@dptr
      00B5C2 12 38 AD         [24] 1383 	lcall	_ak820_outline_0134
      00B5C5 F0               [24] 1384 	movx	@dptr,a
                                   1385 ;	quantum/vial.c:293: break;
      00B5C6 22               [24] 1386 	ret
                                   1387 ;	quantum/vial.c:295: case vial_lock: {
      00B5C7                       1388 00120$:
                                   1389 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B5C7 90 0F 0C         [24] 1390 	mov	dptr,#_vial_unlocked
      00B5CA E4               [12] 1391 	clr	a
      00B5CB F0               [24] 1392 	movx	@dptr,a
                                   1393 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B5CC 90 0F 0D         [24] 1394 	mov	dptr,#_vial_unlock_in_progress
      00B5CF F0               [24] 1395 	movx	@dptr,a
                                   1396 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B5D0 90 0D 32         [24] 1397 	mov	dptr,#_vial_unlock_holding
      00B5D3 F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vial.c:301: break;
      00B5D4 22               [24] 1400 	ret
                                   1401 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B5D5                       1402 00121$:
                                   1403 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B5D5 90 0D 35         [24] 1404 	mov	dptr,#_vial_fill_packet_PARM_2
      00B5D8 74 FF            [12] 1405 	mov	a,#0xff
      00B5DA 12 43 46         [24] 1406 	lcall	_ak820_outline_0071
                                   1407 ;	quantum/vial.c:314: break;
      00B5DD 02 B2 EB         [24] 1408 	ljmp	_vial_fill_packet
                                   1409 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B5E0                       1410 00122$:
                                   1411 ;	quantum/vial.c:347: switch (msg[2]) {
      00B5E0 12 38 25         [24] 1412 	lcall	_ak820_outline_0035
      00B5E3 FB               [12] 1413 	mov  r3,a
      00B5E4 24 FB            [12] 1414 	add	a,#0xff - 0x04
      00B5E6 50 01            [24] 1415 	jnc	00259$
      00B5E8 22               [24] 1416 	ret
      00B5E9                       1417 00259$:
                                   1418 ;	free result
      00B5E9 EB               [12] 1419 	mov	a,r3
      00B5EA 2B               [12] 1420 	add	a,r3
      00B5EB 2B               [12] 1421 	add	a,r3
      00B5EC 90 B5 F0         [24] 1422 	mov	dptr,#00260$
      00B5EF 73               [24] 1423 	jmp	@a+dptr
      00B5F0                       1424 00260$:
      00B5F0 02 B5 FF         [24] 1425 	ljmp	00123$
      00B5F3 02 B6 28         [24] 1426 	ljmp	00124$
      00B5F6 02 B6 8A         [24] 1427 	ljmp	00125$
      00B5F9 02 B7 12         [24] 1428 	ljmp	00126$
      00B5FC 02 B7 70         [24] 1429 	ljmp	00127$
                                   1430 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B5FF                       1431 00123$:
                                   1432 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B5FF 90 0D 35         [24] 1433 	mov	dptr,#_vial_fill_packet_PARM_2
      00B602 E4               [12] 1434 	clr	a
      00B603 12 43 46         [24] 1435 	lcall	_ak820_outline_0071
      00B606 C0 07            [24] 1436 	push	ar7
      00B608 C0 06            [24] 1437 	push	ar6
      00B60A 12 B2 EB         [24] 1438 	lcall	_vial_fill_packet
      00B60D D0 06            [24] 1439 	pop	ar6
      00B60F D0 07            [24] 1440 	pop	ar7
                                   1441 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B611 12 38 92         [24] 1442 	lcall	_ak820_outline_0124
      00B614 74 08            [12] 1443 	mov	a,#0x08
      00B616 12 43 46         [24] 1444 	lcall	_ak820_outline_0071
                                   1445 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B619 A3               [24] 1446 	inc	dptr
      00B61A 12 43 13         [24] 1447 	lcall	_ak820_outline_0037
                                   1448 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B61D E4               [12] 1449 	clr	a
      00B61E F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B61F 74 1F            [12] 1452 	mov	a,#0x1f
      00B621 12 38 1D         [24] 1453 	lcall	_ak820_outline_0026
      00B624 74 01            [12] 1454 	mov	a,#0x01
      00B626 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	quantum/vial.c:356: break;
      00B627 22               [24] 1457 	ret
                                   1458 ;	quantum/vial.c:359: case dynamic_vial_tap_dance_get: {
      00B628                       1459 00124$:
                                   1460 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B628 12 48 B7         [24] 1461 	lcall	_ak820_outline_0018
      00B62B FB               [12] 1462 	mov	r3,a
                                   1463 ;	quantum/vial.c:361: vial_tap_dance_entry_t td = { 0 };
      00B62C 90 0D 3C         [24] 1464 	mov	dptr,#_vial_handle_cmd_td_70000_647
      00B62F 12 49 28         [24] 1465 	lcall	_ak820_outline_0150
      00B632 90 0D 3E         [24] 1466 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0002)
      00B635 F0               [24] 1467 	movx	@dptr,a
      00B636 A3               [24] 1468 	inc	dptr
      00B637 F0               [24] 1469 	movx	@dptr,a
      00B638 90 0D 40         [24] 1470 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0004)
      00B63B F0               [24] 1471 	movx	@dptr,a
      00B63C A3               [24] 1472 	inc	dptr
      00B63D F0               [24] 1473 	movx	@dptr,a
      00B63E 90 0D 42         [24] 1474 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0006)
      00B641 F0               [24] 1475 	movx	@dptr,a
      00B642 A3               [24] 1476 	inc	dptr
      00B643 F0               [24] 1477 	movx	@dptr,a
      00B644 90 0D 44         [24] 1478 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0008)
      00B647 F0               [24] 1479 	movx	@dptr,a
      00B648 A3               [24] 1480 	inc	dptr
      00B649 F0               [24] 1481 	movx	@dptr,a
                                   1482 ;	quantum/vial.c:362: msg[0] = dynamic_keymap_get_tap_dance(idx, &td);
      00B64A 90 0B B3         [24] 1483 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      00B64D 74 3C            [12] 1484 	mov	a,#_vial_handle_cmd_td_70000_647
      00B64F F0               [24] 1485 	movx	@dptr,a
      00B650 74 0D            [12] 1486 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B652 12 38 4A         [24] 1487 	lcall	_ak820_outline_0077
      00B655 8B 82            [24] 1488 	mov	dpl, r3
      00B657 C0 07            [24] 1489 	push	ar7
      00B659 C0 06            [24] 1490 	push	ar6
      00B65B C0 05            [24] 1491 	push	ar5
      00B65D C0 04            [24] 1492 	push	ar4
      00B65F 12 8A 34         [24] 1493 	lcall	_dynamic_keymap_get_tap_dance
      00B662 AA 82            [24] 1494 	mov	r2, dpl
      00B664 D0 04            [24] 1495 	pop	ar4
      00B666 D0 05            [24] 1496 	pop	ar5
      00B668 D0 06            [24] 1497 	pop	ar6
      00B66A D0 07            [24] 1498 	pop	ar7
      00B66C 12 38 92         [24] 1499 	lcall	_ak820_outline_0124
      00B66F EA               [12] 1500 	mov	a,r2
      00B670 F0               [24] 1501 	movx	@dptr,a
                                   1502 ;	quantum/vial.c:363: memcpy(&msg[1], &td, sizeof(td));
      00B671 8C 01            [24] 1503 	mov	ar1,r4
      00B673 8D 02            [24] 1504 	mov	ar2,r5
      00B675 7B 00            [12] 1505 	mov	r3,#0x00
      00B677 90 0E 8C         [24] 1506 	mov	dptr,#___memcpy_PARM_2
      00B67A 74 3C            [12] 1507 	mov	a,#_vial_handle_cmd_td_70000_647
      00B67C F0               [24] 1508 	movx	@dptr,a
      00B67D 74 0D            [12] 1509 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B67F 12 B8 B4         [24] 1510 	lcall	_ak820_outline_0009
      00B682 12 43 85         [24] 1511 	lcall	_ak820_outline_0177
      00B685 8B F0            [24] 1512 	mov	b, r3
                                   1513 ;	quantum/vial.c:364: break;
      00B687 02 BE 8E         [24] 1514 	ljmp	___memcpy
                                   1515 ;	quantum/vial.c:366: case dynamic_vial_tap_dance_set: {
      00B68A                       1516 00125$:
                                   1517 ;	quantum/vial.c:367: uint8_t idx = msg[3];
      00B68A 12 48 B7         [24] 1518 	lcall	_ak820_outline_0018
      00B68D FB               [12] 1519 	mov	r3,a
                                   1520 ;	quantum/vial.c:369: memcpy(&td, &msg[4], sizeof(td));
      00B68E 74 04            [12] 1521 	mov	a,#0x04
      00B690 2E               [12] 1522 	add	a, r6
      00B691 F9               [12] 1523 	mov	r1,a
      00B692 E4               [12] 1524 	clr	a
      00B693 3F               [12] 1525 	addc	a, r7
      00B694 FA               [12] 1526 	mov	r2,a
      00B695 90 0E 8C         [24] 1527 	mov	dptr,#___memcpy_PARM_2
      00B698 E9               [12] 1528 	mov	a,r1
      00B699 F0               [24] 1529 	movx	@dptr,a
      00B69A EA               [12] 1530 	mov	a,r2
      00B69B 12 B8 B4         [24] 1531 	lcall	_ak820_outline_0009
      00B69E 90 0D 46         [24] 1532 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00B6A1 F5 F0            [12] 1533 	mov	b,a
      00B6A3 C0 07            [24] 1534 	push	ar7
      00B6A5 C0 06            [24] 1535 	push	ar6
      00B6A7 C0 03            [24] 1536 	push	ar3
      00B6A9 12 BE 8E         [24] 1537 	lcall	___memcpy
                                   1538 ;	quantum/vial.c:370: td.on_tap = vial_keycode_firewall(td.on_tap);
      00B6AC 90 0D 46         [24] 1539 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00B6AF 12 B8 DC         [24] 1540 	lcall	_ak820_outline_0045
      00B6B2 12 B2 C8         [24] 1541 	lcall	_vial_keycode_firewall
      00B6B5 12 B2 2B         [24] 1542 	lcall	_ak820_outline_0193
      00B6B8 90 0D 46         [24] 1543 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00B6BB 12 4E 27         [24] 1544 	lcall	_ak820_outline_0102
                                   1545 ;	quantum/vial.c:371: td.on_hold = vial_keycode_firewall(td.on_hold);
      00B6BE 90 0D 48         [24] 1546 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0002)
      00B6C1 12 B8 DC         [24] 1547 	lcall	_ak820_outline_0045
      00B6C4 12 B2 C8         [24] 1548 	lcall	_vial_keycode_firewall
      00B6C7 12 B2 2B         [24] 1549 	lcall	_ak820_outline_0193
      00B6CA 90 0D 48         [24] 1550 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0002)
      00B6CD 12 4E 27         [24] 1551 	lcall	_ak820_outline_0102
                                   1552 ;	quantum/vial.c:372: td.on_double_tap = vial_keycode_firewall(td.on_double_tap);
      00B6D0 90 0D 4A         [24] 1553 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0004)
      00B6D3 12 B8 DC         [24] 1554 	lcall	_ak820_outline_0045
      00B6D6 12 B2 C8         [24] 1555 	lcall	_vial_keycode_firewall
      00B6D9 12 B2 2B         [24] 1556 	lcall	_ak820_outline_0193
      00B6DC 90 0D 4A         [24] 1557 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0004)
      00B6DF 12 4E 27         [24] 1558 	lcall	_ak820_outline_0102
                                   1559 ;	quantum/vial.c:373: td.on_tap_hold = vial_keycode_firewall(td.on_tap_hold);
      00B6E2 90 0D 4C         [24] 1560 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0006)
      00B6E5 12 B8 DC         [24] 1561 	lcall	_ak820_outline_0045
      00B6E8 12 B2 C8         [24] 1562 	lcall	_vial_keycode_firewall
      00B6EB 12 B2 2B         [24] 1563 	lcall	_ak820_outline_0193
      00B6EE D0 03            [24] 1564 	pop	ar3
      00B6F0 90 0D 4C         [24] 1565 	mov	dptr,#(_vial_handle_cmd_td_70000_648 + 0x0006)
      00B6F3 12 4E 27         [24] 1566 	lcall	_ak820_outline_0102
                                   1567 ;	quantum/vial.c:374: msg[0] = dynamic_keymap_set_tap_dance(idx, &td);
      00B6F6 90 0B B7         [24] 1568 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      00B6F9 74 46            [12] 1569 	mov	a,#_vial_handle_cmd_td_70000_648
      00B6FB F0               [24] 1570 	movx	@dptr,a
      00B6FC 74 0D            [12] 1571 	mov	a,#(_vial_handle_cmd_td_70000_648 >> 8)
      00B6FE 12 38 4A         [24] 1572 	lcall	_ak820_outline_0077
      00B701 8B 82            [24] 1573 	mov	dpl, r3
      00B703 12 8A B6         [24] 1574 	lcall	_dynamic_keymap_set_tap_dance
      00B706 AA 82            [24] 1575 	mov	r2, dpl
      00B708 D0 06            [24] 1576 	pop	ar6
      00B70A D0 07            [24] 1577 	pop	ar7
      00B70C 12 38 92         [24] 1578 	lcall	_ak820_outline_0124
      00B70F EA               [12] 1579 	mov	a,r2
      00B710 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/vial.c:376: break;
      00B711 22               [24] 1582 	ret
                                   1583 ;	quantum/vial.c:380: case dynamic_vial_combo_get: {
      00B712                       1584 00126$:
                                   1585 ;	quantum/vial.c:381: uint8_t idx = msg[3];
      00B712 12 48 B7         [24] 1586 	lcall	_ak820_outline_0018
      00B715 FB               [12] 1587 	mov	r3,a
                                   1588 ;	quantum/vial.c:382: vial_combo_entry_t entry = { { 0 }, 0 };
      00B716 90 0D 50         [24] 1589 	mov	dptr,#_vial_handle_cmd_entry_70000_649
      00B719 12 49 28         [24] 1590 	lcall	_ak820_outline_0150
      00B71C 90 0D 52         [24] 1591 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0002)
      00B71F F0               [24] 1592 	movx	@dptr,a
      00B720 A3               [24] 1593 	inc	dptr
      00B721 F0               [24] 1594 	movx	@dptr,a
      00B722 90 0D 54         [24] 1595 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0004)
      00B725 F0               [24] 1596 	movx	@dptr,a
      00B726 A3               [24] 1597 	inc	dptr
      00B727 F0               [24] 1598 	movx	@dptr,a
      00B728 90 0D 56         [24] 1599 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0006)
      00B72B F0               [24] 1600 	movx	@dptr,a
      00B72C A3               [24] 1601 	inc	dptr
      00B72D F0               [24] 1602 	movx	@dptr,a
      00B72E 90 0D 58         [24] 1603 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0008)
      00B731 F0               [24] 1604 	movx	@dptr,a
      00B732 A3               [24] 1605 	inc	dptr
      00B733 F0               [24] 1606 	movx	@dptr,a
                                   1607 ;	quantum/vial.c:383: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B734 90 0B BB         [24] 1608 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B737 74 50            [12] 1609 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B739 F0               [24] 1610 	movx	@dptr,a
      00B73A 74 0D            [12] 1611 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B73C 12 38 4A         [24] 1612 	lcall	_ak820_outline_0077
      00B73F 8B 82            [24] 1613 	mov	dpl, r3
      00B741 C0 07            [24] 1614 	push	ar7
      00B743 C0 06            [24] 1615 	push	ar6
      00B745 C0 05            [24] 1616 	push	ar5
      00B747 C0 04            [24] 1617 	push	ar4
      00B749 12 8B 55         [24] 1618 	lcall	_dynamic_keymap_get_combo
      00B74C AA 82            [24] 1619 	mov	r2, dpl
      00B74E D0 04            [24] 1620 	pop	ar4
      00B750 D0 05            [24] 1621 	pop	ar5
      00B752 D0 06            [24] 1622 	pop	ar6
      00B754 D0 07            [24] 1623 	pop	ar7
      00B756 12 38 92         [24] 1624 	lcall	_ak820_outline_0124
      00B759 EA               [12] 1625 	mov	a,r2
      00B75A F0               [24] 1626 	movx	@dptr,a
                                   1627 ;	quantum/vial.c:384: memcpy(&msg[1], &entry, sizeof(entry));
      00B75B 7B 00            [12] 1628 	mov	r3,#0x00
      00B75D 90 0E 8C         [24] 1629 	mov	dptr,#___memcpy_PARM_2
      00B760 74 50            [12] 1630 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B762 F0               [24] 1631 	movx	@dptr,a
      00B763 74 0D            [12] 1632 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B765 12 B8 B4         [24] 1633 	lcall	_ak820_outline_0009
      00B768 12 38 A3         [24] 1634 	lcall	_ak820_outline_0132
      00B76B 8B F0            [24] 1635 	mov	b, r3
                                   1636 ;	quantum/vial.c:385: break;
      00B76D 02 BE 8E         [24] 1637 	ljmp	___memcpy
                                   1638 ;	quantum/vial.c:387: case dynamic_vial_combo_set: {
      00B770                       1639 00127$:
                                   1640 ;	quantum/vial.c:388: uint8_t idx = msg[3];
      00B770 12 48 B7         [24] 1641 	lcall	_ak820_outline_0018
      00B773 FD               [12] 1642 	mov	r5,a
                                   1643 ;	quantum/vial.c:390: memcpy(&entry, &msg[4], sizeof(entry));
      00B774 74 04            [12] 1644 	mov	a,#0x04
      00B776 12 4E 34         [24] 1645 	lcall	_ak820_outline_0145
      00B779 90 0E 8C         [24] 1646 	mov	dptr,#___memcpy_PARM_2
      00B77C EB               [12] 1647 	mov	a,r3
      00B77D F0               [24] 1648 	movx	@dptr,a
      00B77E EC               [12] 1649 	mov	a,r4
      00B77F 12 B8 B4         [24] 1650 	lcall	_ak820_outline_0009
      00B782 90 0D 5A         [24] 1651 	mov	dptr,#_vial_handle_cmd_entry_70000_650
      00B785 F5 F0            [12] 1652 	mov	b,a
      00B787 C0 07            [24] 1653 	push	ar7
      00B789 C0 06            [24] 1654 	push	ar6
      00B78B C0 05            [24] 1655 	push	ar5
      00B78D 12 BE 8E         [24] 1656 	lcall	___memcpy
                                   1657 ;	quantum/vial.c:391: entry.output = vial_keycode_firewall(entry.output);
      00B790 90 0D 62         [24] 1658 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B793 12 38 7B         [24] 1659 	lcall	_ak820_outline_0107
      00B796 12 33 FC         [24] 1660 	lcall	_ak820_outline_0131
      00B799 12 B2 C8         [24] 1661 	lcall	_vial_keycode_firewall
      00B79C AB 82            [24] 1662 	mov	r3, dpl
      00B79E AC 83            [24] 1663 	mov	r4, dph
      00B7A0 D0 05            [24] 1664 	pop	ar5
      00B7A2 90 0D 62         [24] 1665 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B7A5 12 38 56         [24] 1666 	lcall	_ak820_outline_0084
                                   1667 ;	quantum/vial.c:392: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B7A8 90 0B BF         [24] 1668 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B7AB 74 5A            [12] 1669 	mov	a,#_vial_handle_cmd_entry_70000_650
      00B7AD F0               [24] 1670 	movx	@dptr,a
      00B7AE 74 0D            [12] 1671 	mov	a,#(_vial_handle_cmd_entry_70000_650 >> 8)
      00B7B0 12 38 4A         [24] 1672 	lcall	_ak820_outline_0077
      00B7B3 8D 82            [24] 1673 	mov	dpl, r5
      00B7B5 12 8B EA         [24] 1674 	lcall	_dynamic_keymap_set_combo
      00B7B8 AC 82            [24] 1675 	mov	r4, dpl
      00B7BA D0 06            [24] 1676 	pop	ar6
      00B7BC D0 07            [24] 1677 	pop	ar7
      00B7BE 12 38 92         [24] 1678 	lcall	_ak820_outline_0124
      00B7C1 EC               [12] 1679 	mov	a,r4
      00B7C2 F0               [24] 1680 	movx	@dptr,a
                                   1681 ;	quantum/vial.c:393: if (!msg[0]) reload_combo();
      00B7C3 EC               [12] 1682 	mov	a,r4
      00B7C4 70 03            [24] 1683 	jnz	00141$
                                   1684 ;	quantum/vial.c:419: }
                                   1685 ;	quantum/vial.c:420: }
      00B7C6 02 35 7C         [24] 1686 	ljmp	_ak820_combo_reload
      00B7C9                       1687 00141$:
      00B7C9 22               [24] 1688 	ret
                                   1689 ;------------------------------------------------------------
                                   1690 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1691 ;------------------------------------------------------------
                                   1692 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_652'
                                   1693 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_659'
                                   1694 ;------------------------------------------------------------
                                   1695 ;	quantum/vial.c:424: void vial_keycode_down(uint16_t keycode) {
                                   1696 ;	-----------------------------------------
                                   1697 ;	 function vial_keycode_down
                                   1698 ;	-----------------------------------------
      00B7CA                       1699 _vial_keycode_down:
      00B7CA 12 38 81         [24] 1700 	lcall	_ak820_outline_0111
      00B7CD 90 0D 66         [24] 1701 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B7D0 12 38 86         [24] 1702 	lcall	_ak820_outline_0112
                                   1703 ;	quantum/vial.c:428: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B7D3 90 0D 66         [24] 1704 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B7D6 12 4D E6         [24] 1705 	lcall	_ak820_outline_0010
      00B7D9 74 E0            [12] 1706 	mov	a,#0x100 - 0x20
      00B7DB 2D               [12] 1707 	add	a,r5
      00B7DC 50 19            [24] 1708 	jnc	00104$
      00B7DE C3               [12] 1709 	clr	c
      00B7DF 74 FF            [12] 1710 	mov	a,#0xff
      00B7E1 9C               [12] 1711 	subb	a,r4
      00B7E2 74 4F            [12] 1712 	mov	a,#0x4f
      00B7E4 9D               [12] 1713 	subb	a,r5
      00B7E5 40 10            [24] 1714 	jc	00104$
                                   1715 ;	free result
                                   1716 ;	quantum/vial.c:429: keycode = (uint8_t)keycode;
      00B7E7 90 0D 66         [24] 1717 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B7EA EE               [12] 1718 	mov	a,r6
      00B7EB 12 38 A8         [24] 1719 	lcall	_ak820_outline_0133
                                   1720 ;	quantum/vial.c:430: if (keycode <= KC_TRANSPARENT) return;
      00B7EE 90 0D 66         [24] 1721 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B7F1 E0               [24] 1722 	movx	a,@dptr
      00B7F2 24 FE            [12] 1723 	add	a,#0xff - 0x01
      00B7F4 40 01            [24] 1724 	jc	00104$
                                   1725 ;	free result
      00B7F6 22               [24] 1726 	ret
      00B7F7                       1727 00104$:
                                   1728 ;	quantum/vial.c:433: g_vial_magic_keycode_override = keycode;
      00B7F7 90 0D 66         [24] 1729 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B7FA 12 B8 C3         [24] 1730 	lcall	_ak820_outline_0028
                                   1731 ;	quantum/vial.c:435: if (keycode <= QK_MODS_MAX) {
      00B7FD 40 06            [24] 1732 	jc	00107$
                                   1733 ;	free result
                                   1734 ;	quantum/vial.c:436: register_code16(keycode);
      00B7FF 12 38 92         [24] 1735 	lcall	_ak820_outline_0124
      00B802 02 A3 31         [24] 1736 	ljmp	_register_code16
      00B805                       1737 00107$:
                                   1738 ;	quantum/vial.c:438: keyevent_t dummy_event = {
      00B805 90 0D 6C         [24] 1739 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0004)
      00B808 74 01            [12] 1740 	mov	a,#0x01
      00B80A F0               [24] 1741 	movx	@dptr,a
      00B80B 90 0D 69         [24] 1742 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0001)
      00B80E 74 F0            [12] 1743 	mov	a,#0xf0
      00B810 F0               [24] 1744 	movx	@dptr,a
      00B811 90 0D 68         [24] 1745 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
      00B814 F0               [24] 1746 	movx	@dptr,a
      00B815 90 0D 6D         [24] 1747 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0005)
      00B818 74 01            [12] 1748 	mov	a,#0x01
      00B81A F0               [24] 1749 	movx	@dptr,a
      00B81B 12 4E B7         [24] 1750 	lcall	_timer_read
      00B81E 12 43 64         [24] 1751 	lcall	_ak820_outline_0142
      00B821 43 06 01         [24] 1752 	orl	ar6,#0x01
      00B824 90 0D 6A         [24] 1753 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0002)
      00B827 12 49 1A         [24] 1754 	lcall	_ak820_outline_0064
                                   1755 ;	quantum/vial.c:442: AK820_ACTION_EXEC(dummy_event);
      00B82A 90 0D 68         [24] 1756 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
                                   1757 ;	quantum/vial.c:444: }
      00B82D 02 75 A6         [24] 1758 	ljmp	_ak820_action_exec
                                   1759 ;------------------------------------------------------------
                                   1760 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1761 ;------------------------------------------------------------
                                   1762 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_660'
                                   1763 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_667'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/vial.c:446: void vial_keycode_up(uint16_t keycode) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function vial_keycode_up
                                   1768 ;	-----------------------------------------
      00B830                       1769 _vial_keycode_up:
      00B830 12 38 81         [24] 1770 	lcall	_ak820_outline_0111
      00B833 90 0D 6E         [24] 1771 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B836 12 38 86         [24] 1772 	lcall	_ak820_outline_0112
                                   1773 ;	quantum/vial.c:450: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B839 90 0D 6E         [24] 1774 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B83C 12 4D E6         [24] 1775 	lcall	_ak820_outline_0010
      00B83F 74 E0            [12] 1776 	mov	a,#0x100 - 0x20
      00B841 2D               [12] 1777 	add	a,r5
      00B842 50 19            [24] 1778 	jnc	00104$
      00B844 C3               [12] 1779 	clr	c
      00B845 74 FF            [12] 1780 	mov	a,#0xff
      00B847 9C               [12] 1781 	subb	a,r4
      00B848 74 4F            [12] 1782 	mov	a,#0x4f
      00B84A 9D               [12] 1783 	subb	a,r5
      00B84B 40 10            [24] 1784 	jc	00104$
                                   1785 ;	free result
                                   1786 ;	quantum/vial.c:451: keycode = (uint8_t)keycode;
      00B84D 90 0D 6E         [24] 1787 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B850 EE               [12] 1788 	mov	a,r6
      00B851 12 38 A8         [24] 1789 	lcall	_ak820_outline_0133
                                   1790 ;	quantum/vial.c:452: if (keycode <= KC_TRANSPARENT) return;
      00B854 90 0D 6E         [24] 1791 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B857 E0               [24] 1792 	movx	a,@dptr
      00B858 24 FE            [12] 1793 	add	a,#0xff - 0x01
      00B85A 40 01            [24] 1794 	jc	00104$
                                   1795 ;	free result
      00B85C 22               [24] 1796 	ret
      00B85D                       1797 00104$:
                                   1798 ;	quantum/vial.c:455: g_vial_magic_keycode_override = keycode;
      00B85D 90 0D 6E         [24] 1799 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B860 12 B8 C3         [24] 1800 	lcall	_ak820_outline_0028
                                   1801 ;	quantum/vial.c:457: if (keycode <= QK_MODS_MAX) {
      00B863 40 06            [24] 1802 	jc	00107$
                                   1803 ;	free result
                                   1804 ;	quantum/vial.c:458: unregister_code16(keycode);
      00B865 12 38 92         [24] 1805 	lcall	_ak820_outline_0124
      00B868 02 A3 75         [24] 1806 	ljmp	_unregister_code16
      00B86B                       1807 00107$:
                                   1808 ;	quantum/vial.c:460: keyevent_t dummy_event = {
      00B86B 90 0D 74         [24] 1809 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0004)
      00B86E 74 01            [12] 1810 	mov	a,#0x01
      00B870 F0               [24] 1811 	movx	@dptr,a
      00B871 90 0D 71         [24] 1812 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0001)
      00B874 74 F0            [12] 1813 	mov	a,#0xf0
      00B876 F0               [24] 1814 	movx	@dptr,a
      00B877 90 0D 70         [24] 1815 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
      00B87A F0               [24] 1816 	movx	@dptr,a
      00B87B 90 0D 75         [24] 1817 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0005)
      00B87E E4               [12] 1818 	clr	a
      00B87F F0               [24] 1819 	movx	@dptr,a
      00B880 12 4E B7         [24] 1820 	lcall	_timer_read
      00B883 12 43 64         [24] 1821 	lcall	_ak820_outline_0142
      00B886 43 06 01         [24] 1822 	orl	ar6,#0x01
      00B889 90 0D 72         [24] 1823 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0002)
      00B88C 12 49 1A         [24] 1824 	lcall	_ak820_outline_0064
                                   1825 ;	quantum/vial.c:464: AK820_ACTION_EXEC(dummy_event);
      00B88F 90 0D 70         [24] 1826 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
                                   1827 ;	quantum/vial.c:466: }
      00B892 02 75 A6         [24] 1828 	ljmp	_ak820_action_exec
                                   1829 ;------------------------------------------------------------
                                   1830 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1831 ;------------------------------------------------------------
                                   1832 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_668'
                                   1833 ;i             Allocated with name '_vial_keycode_tap_i_30000_671'
                                   1834 ;------------------------------------------------------------
                                   1835 ;	quantum/vial.c:468: void vial_keycode_tap(uint16_t keycode) {
                                   1836 ;	-----------------------------------------
                                   1837 ;	 function vial_keycode_tap
                                   1838 ;	-----------------------------------------
      00B895                       1839 _vial_keycode_tap:
      00B895 12 38 81         [24] 1840 	lcall	_ak820_outline_0111
      00B898 90 0D 76         [24] 1841 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B89B 12 38 86         [24] 1842 	lcall	_ak820_outline_0112
                                   1843 ;	quantum/vial.c:469: vial_keycode_down(keycode);
      00B89E 90 0D 76         [24] 1844 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B8A1 12 37 ED         [24] 1845 	lcall	_ak820_outline_0006
      00B8A4 C0 07            [24] 1846 	push	ar7
      00B8A6 C0 06            [24] 1847 	push	ar6
      00B8A8 12 B7 CA         [24] 1848 	lcall	_vial_keycode_down
      00B8AB D0 06            [24] 1849 	pop	ar6
      00B8AD D0 07            [24] 1850 	pop	ar7
                                   1851 ;	quantum/vial.c:471: vial_keycode_up(keycode);
      00B8AF 12 38 92         [24] 1852 	lcall	_ak820_outline_0124
                                   1853 ;	quantum/vial.c:472: }
      00B8B2 01 30            [12] 1854 	ajmp	_vial_keycode_up
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'process_record_vial'
                                   1857 ;------------------------------------------------------------
                                   1858 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1859 ;keycode       Allocated with name '_process_record_vial_keycode_10000_673'
                                   1860 ;------------------------------------------------------------
                                   1861 ;	quantum/vial.c:682: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1862 ;	-----------------------------------------
                                   1863 	.area CSEG    (CODE)
                                   1864 	.area CONST   (CODE)
                                   1865 	.area CONST   (CODE)
      00C40C                       1866 _keyboard_definition:
      00C40C FD                    1867 	.db #0xfd	; 253
      00C40D 37                    1868 	.db #0x37	; 55	'7'
      00C40E 7A                    1869 	.db #0x7a	; 122	'z'
      00C40F 58                    1870 	.db #0x58	; 88	'X'
      00C410 5A                    1871 	.db #0x5a	; 90	'Z'
      00C411 00                    1872 	.db #0x00	; 0
      00C412 00                    1873 	.db #0x00	; 0
      00C413 04                    1874 	.db #0x04	; 4
      00C414 E6                    1875 	.db #0xe6	; 230
      00C415 D6                    1876 	.db #0xd6	; 214
      00C416 B4                    1877 	.db #0xb4	; 180
      00C417 46                    1878 	.db #0x46	; 70	'F'
      00C418 02                    1879 	.db #0x02	; 2
      00C419 00                    1880 	.db #0x00	; 0
      00C41A 21                    1881 	.db #0x21	; 33
      00C41B 01                    1882 	.db #0x01	; 1
      00C41C 00                    1883 	.db #0x00	; 0
      00C41D 00                    1884 	.db #0x00	; 0
      00C41E 00                    1885 	.db #0x00	; 0
      00C41F 00                    1886 	.db #0x00	; 0
      00C420 37                    1887 	.db #0x37	; 55	'7'
      00C421 27                    1888 	.db #0x27	; 39
      00C422 97                    1889 	.db #0x97	; 151
      00C423 D6                    1890 	.db #0xd6	; 214
      00C424 E0                    1891 	.db #0xe0	; 224
      00C425 03                    1892 	.db #0x03	; 3
      00C426 CB                    1893 	.db #0xcb	; 203
      00C427 01                    1894 	.db #0x01	; 1
      00C428 3C                    1895 	.db #0x3c	; 60
      00C429 00                    1896 	.db #0x00	; 0
      00C42A 00                    1897 	.db #0x00	; 0
      00C42B 3D                    1898 	.db #0x3d	; 61
      00C42C 88                    1899 	.db #0x88	; 136
      00C42D CD                    1900 	.db #0xcd	; 205
      00C42E A5                    1901 	.db #0xa5	; 165
      00C42F AA                    1902 	.db #0xaa	; 170
      00C430 E5                    1903 	.db #0xe5	; 229
      00C431 A8                    1904 	.db #0xa8	; 168
      00C432 76                    1905 	.db #0x76	; 118	'v'
      00C433 F6                    1906 	.db #0xf6	; 246
      00C434 43                    1907 	.db #0x43	; 67	'C'
      00C435 0E                    1908 	.db #0x0e	; 14
      00C436 D2                    1909 	.db #0xd2	; 210
      00C437 90                    1910 	.db #0x90	; 144
      00C438 7D                    1911 	.db #0x7d	; 125
      00C439 94                    1912 	.db #0x94	; 148
      00C43A 79                    1913 	.db #0x79	; 121	'y'
      00C43B 78                    1914 	.db #0x78	; 120	'x'
      00C43C EF                    1915 	.db #0xef	; 239
      00C43D 49                    1916 	.db #0x49	; 73	'I'
      00C43E 3E                    1917 	.db #0x3e	; 62
      00C43F EF                    1918 	.db #0xef	; 239
      00C440 FD                    1919 	.db #0xfd	; 253
      00C441 8F                    1920 	.db #0x8f	; 143
      00C442 EF                    1921 	.db #0xef	; 239
      00C443 00                    1922 	.db #0x00	; 0
      00C444 C6                    1923 	.db #0xc6	; 198
      00C445 D1                    1924 	.db #0xd1	; 209
      00C446 DB                    1925 	.db #0xdb	; 219
      00C447 FB                    1926 	.db #0xfb	; 251
      00C448 EB                    1927 	.db #0xeb	; 235
      00C449 DE                    1928 	.db #0xde	; 222
      00C44A 66                    1929 	.db #0x66	; 102	'f'
      00C44B 63                    1930 	.db #0x63	; 99	'c'
      00C44C 0C                    1931 	.db #0x0c	; 12
      00C44D 92                    1932 	.db #0x92	; 146
      00C44E 7B                    1933 	.db #0x7b	; 123
      00C44F F9                    1934 	.db #0xf9	; 249
      00C450 D4                    1935 	.db #0xd4	; 212
      00C451 7A                    1936 	.db #0x7a	; 122	'z'
      00C452 4F                    1937 	.db #0x4f	; 79	'O'
      00C453 83                    1938 	.db #0x83	; 131
      00C454 4B                    1939 	.db #0x4b	; 75	'K'
      00C455 86                    1940 	.db #0x86	; 134
      00C456 0E                    1941 	.db #0x0e	; 14
      00C457 6A                    1942 	.db #0x6a	; 106	'j'
      00C458 F2                    1943 	.db #0xf2	; 242
      00C459 22                    1944 	.db #0x22	; 34
      00C45A 22                    1945 	.db #0x22	; 34
      00C45B 0B                    1946 	.db #0x0b	; 11
      00C45C 03                    1947 	.db #0x03	; 3
      00C45D BA                    1948 	.db #0xba	; 186
      00C45E 67                    1949 	.db #0x67	; 103	'g'
      00C45F 9B                    1950 	.db #0x9b	; 155
      00C460 7A                    1951 	.db #0x7a	; 122	'z'
      00C461 E1                    1952 	.db #0xe1	; 225
      00C462 BC                    1953 	.db #0xbc	; 188
      00C463 37                    1954 	.db #0x37	; 55	'7'
      00C464 26                    1955 	.db #0x26	; 38
      00C465 46                    1956 	.db #0x46	; 70	'F'
      00C466 78                    1957 	.db #0x78	; 120	'x'
      00C467 05                    1958 	.db #0x05	; 5
      00C468 0D                    1959 	.db #0x0d	; 13
      00C469 95                    1960 	.db #0x95	; 149
      00C46A 02                    1961 	.db #0x02	; 2
      00C46B E4                    1962 	.db #0xe4	; 228
      00C46C 18                    1963 	.db #0x18	; 24
      00C46D CA                    1964 	.db #0xca	; 202
      00C46E 33                    1965 	.db #0x33	; 51	'3'
      00C46F EA                    1966 	.db #0xea	; 234
      00C470 24                    1967 	.db #0x24	; 36
      00C471 C8                    1968 	.db #0xc8	; 200
      00C472 81                    1969 	.db #0x81	; 129
      00C473 4E                    1970 	.db #0x4e	; 78	'N'
      00C474 47                    1971 	.db #0x47	; 71	'G'
      00C475 A8                    1972 	.db #0xa8	; 168
      00C476 44                    1973 	.db #0x44	; 68	'D'
      00C477 DD                    1974 	.db #0xdd	; 221
      00C478 91                    1975 	.db #0x91	; 145
      00C479 6D                    1976 	.db #0x6d	; 109	'm'
      00C47A 69                    1977 	.db #0x69	; 105	'i'
      00C47B DB                    1978 	.db #0xdb	; 219
      00C47C 4F                    1979 	.db #0x4f	; 79	'O'
      00C47D 3A                    1980 	.db #0x3a	; 58
      00C47E 43                    1981 	.db #0x43	; 67	'C'
      00C47F 9D                    1982 	.db #0x9d	; 157
      00C480 26                    1983 	.db #0x26	; 38
      00C481 49                    1984 	.db #0x49	; 73	'I'
      00C482 4C                    1985 	.db #0x4c	; 76	'L'
      00C483 EF                    1986 	.db #0xef	; 239
      00C484 2B                    1987 	.db #0x2b	; 43
      00C485 D8                    1988 	.db #0xd8	; 216
      00C486 55                    1989 	.db #0x55	; 85	'U'
      00C487 95                    1990 	.db #0x95	; 149
      00C488 70                    1991 	.db #0x70	; 112	'p'
      00C489 B1                    1992 	.db #0xb1	; 177
      00C48A CC                    1993 	.db #0xcc	; 204
      00C48B CF                    1994 	.db #0xcf	; 207
      00C48C 13                    1995 	.db #0x13	; 19
      00C48D 32                    1996 	.db #0x32	; 50	'2'
      00C48E 6A                    1997 	.db #0x6a	; 106	'j'
      00C48F A1                    1998 	.db #0xa1	; 161
      00C490 FF                    1999 	.db #0xff	; 255
      00C491 99                    2000 	.db #0x99	; 153
      00C492 61                    2001 	.db #0x61	; 97	'a'
      00C493 95                    2002 	.db #0x95	; 149
      00C494 B1                    2003 	.db #0xb1	; 177
      00C495 89                    2004 	.db #0x89	; 137
      00C496 9B                    2005 	.db #0x9b	; 155
      00C497 11                    2006 	.db #0x11	; 17
      00C498 D9                    2007 	.db #0xd9	; 217
      00C499 35                    2008 	.db #0x35	; 53	'5'
      00C49A 78                    2009 	.db #0x78	; 120	'x'
      00C49B ED                    2010 	.db #0xed	; 237
      00C49C CD                    2011 	.db #0xcd	; 205
      00C49D 94                    2012 	.db #0x94	; 148
      00C49E 6E                    2013 	.db #0x6e	; 110	'n'
      00C49F 60                    2014 	.db #0x60	; 96
      00C4A0 8E                    2015 	.db #0x8e	; 142
      00C4A1 63                    2016 	.db #0x63	; 99	'c'
      00C4A2 8B                    2017 	.db #0x8b	; 139
      00C4A3 FF                    2018 	.db #0xff	; 255
      00C4A4 4E                    2019 	.db #0x4e	; 78	'N'
      00C4A5 20                    2020 	.db #0x20	; 32
      00C4A6 7A                    2021 	.db #0x7a	; 122	'z'
      00C4A7 B5                    2022 	.db #0xb5	; 181
      00C4A8 87                    2023 	.db #0x87	; 135
      00C4A9 C2                    2024 	.db #0xc2	; 194
      00C4AA 35                    2025 	.db #0x35	; 53	'5'
      00C4AB A4                    2026 	.db #0xa4	; 164
      00C4AC 6D                    2027 	.db #0x6d	; 109	'm'
      00C4AD 18                    2028 	.db #0x18	; 24
      00C4AE C1                    2029 	.db #0xc1	; 193
      00C4AF A3                    2030 	.db #0xa3	; 163
      00C4B0 DB                    2031 	.db #0xdb	; 219
      00C4B1 53                    2032 	.db #0x53	; 83	'S'
      00C4B2 1D                    2033 	.db #0x1d	; 29
      00C4B3 EC                    2034 	.db #0xec	; 236
      00C4B4 F0                    2035 	.db #0xf0	; 240
      00C4B5 BF                    2036 	.db #0xbf	; 191
      00C4B6 4A                    2037 	.db #0x4a	; 74	'J'
      00C4B7 4C                    2038 	.db #0x4c	; 76	'L'
      00C4B8 4A                    2039 	.db #0x4a	; 74	'J'
      00C4B9 C4                    2040 	.db #0xc4	; 196
      00C4BA AA                    2041 	.db #0xaa	; 170
      00C4BB 37                    2042 	.db #0x37	; 55	'7'
      00C4BC 19                    2043 	.db #0x19	; 25
      00C4BD 34                    2044 	.db #0x34	; 52	'4'
      00C4BE 3F                    2045 	.db #0x3f	; 63
      00C4BF A1                    2046 	.db #0xa1	; 161
      00C4C0 D3                    2047 	.db #0xd3	; 211
      00C4C1 1A                    2048 	.db #0x1a	; 26
      00C4C2 5C                    2049 	.db #0x5c	; 92
      00C4C3 03                    2050 	.db #0x03	; 3
      00C4C4 4D                    2051 	.db #0x4d	; 77	'M'
      00C4C5 BC                    2052 	.db #0xbc	; 188
      00C4C6 10                    2053 	.db #0x10	; 16
      00C4C7 2E                    2054 	.db #0x2e	; 46
      00C4C8 80                    2055 	.db #0x80	; 128
      00C4C9 F7                    2056 	.db #0xf7	; 247
      00C4CA D6                    2057 	.db #0xd6	; 214
      00C4CB 82                    2058 	.db #0x82	; 130
      00C4CC 24                    2059 	.db #0x24	; 36
      00C4CD 4C                    2060 	.db #0x4c	; 76	'L'
      00C4CE 87                    2061 	.db #0x87	; 135
      00C4CF B9                    2062 	.db #0xb9	; 185
      00C4D0 F8                    2063 	.db #0xf8	; 248
      00C4D1 BE                    2064 	.db #0xbe	; 190
      00C4D2 67                    2065 	.db #0x67	; 103	'g'
      00C4D3 96                    2066 	.db #0x96	; 150
      00C4D4 89                    2067 	.db #0x89	; 137
      00C4D5 30                    2068 	.db #0x30	; 48	'0'
      00C4D6 C8                    2069 	.db #0xc8	; 200
      00C4D7 8D                    2070 	.db #0x8d	; 141
      00C4D8 2C                    2071 	.db #0x2c	; 44
      00C4D9 F5                    2072 	.db #0xf5	; 245
      00C4DA 06                    2073 	.db #0x06	; 6
      00C4DB 05                    2074 	.db #0x05	; 5
      00C4DC 7C                    2075 	.db #0x7c	; 124
      00C4DD 48                    2076 	.db #0x48	; 72	'H'
      00C4DE 1B                    2077 	.db #0x1b	; 27
      00C4DF 76                    2078 	.db #0x76	; 118	'v'
      00C4E0 AA                    2079 	.db #0xaa	; 170
      00C4E1 3D                    2080 	.db #0x3d	; 61
      00C4E2 28                    2081 	.db #0x28	; 40
      00C4E3 FC                    2082 	.db #0xfc	; 252
      00C4E4 80                    2083 	.db #0x80	; 128
      00C4E5 75                    2084 	.db #0x75	; 117	'u'
      00C4E6 EB                    2085 	.db #0xeb	; 235
      00C4E7 78                    2086 	.db #0x78	; 120	'x'
      00C4E8 D0                    2087 	.db #0xd0	; 208
      00C4E9 8A                    2088 	.db #0x8a	; 138
      00C4EA 8F                    2089 	.db #0x8f	; 143
      00C4EB 27                    2090 	.db #0x27	; 39
      00C4EC F7                    2091 	.db #0xf7	; 247
      00C4ED F2                    2092 	.db #0xf2	; 242
      00C4EE EB                    2093 	.db #0xeb	; 235
      00C4EF 58                    2094 	.db #0x58	; 88	'X'
      00C4F0 37                    2095 	.db #0x37	; 55	'7'
      00C4F1 3C                    2096 	.db #0x3c	; 60
      00C4F2 2B                    2097 	.db #0x2b	; 43
      00C4F3 6F                    2098 	.db #0x6f	; 111	'o'
      00C4F4 0E                    2099 	.db #0x0e	; 14
      00C4F5 C7                    2100 	.db #0xc7	; 199
      00C4F6 E2                    2101 	.db #0xe2	; 226
      00C4F7 A0                    2102 	.db #0xa0	; 160
      00C4F8 97                    2103 	.db #0x97	; 151
      00C4F9 EE                    2104 	.db #0xee	; 238
      00C4FA FD                    2105 	.db #0xfd	; 253
      00C4FB 9F                    2106 	.db #0x9f	; 159
      00C4FC 45                    2107 	.db #0x45	; 69	'E'
      00C4FD 17                    2108 	.db #0x17	; 23
      00C4FE 94                    2109 	.db #0x94	; 148
      00C4FF E6                    2110 	.db #0xe6	; 230
      00C500 E7                    2111 	.db #0xe7	; 231
      00C501 FA                    2112 	.db #0xfa	; 250
      00C502 4C                    2113 	.db #0x4c	; 76	'L'
      00C503 7A                    2114 	.db #0x7a	; 122	'z'
      00C504 D6                    2115 	.db #0xd6	; 214
      00C505 7A                    2116 	.db #0x7a	; 122	'z'
      00C506 7B                    2117 	.db #0x7b	; 123
      00C507 ED                    2118 	.db #0xed	; 237
      00C508 10                    2119 	.db #0x10	; 16
      00C509 C5                    2120 	.db #0xc5	; 197
      00C50A BC                    2121 	.db #0xbc	; 188
      00C50B E3                    2122 	.db #0xe3	; 227
      00C50C A9                    2123 	.db #0xa9	; 169
      00C50D 1F                    2124 	.db #0x1f	; 31
      00C50E CF                    2125 	.db #0xcf	; 207
      00C50F C4                    2126 	.db #0xc4	; 196
      00C510 9D                    2127 	.db #0x9d	; 157
      00C511 DC                    2128 	.db #0xdc	; 220
      00C512 45                    2129 	.db #0x45	; 69	'E'
      00C513 2A                    2130 	.db #0x2a	; 42
      00C514 69                    2131 	.db #0x69	; 105	'i'
      00C515 57                    2132 	.db #0x57	; 87	'W'
      00C516 8F                    2133 	.db #0x8f	; 143
      00C517 EC                    2134 	.db #0xec	; 236
      00C518 85                    2135 	.db #0x85	; 133
      00C519 6C                    2136 	.db #0x6c	; 108	'l'
      00C51A 43                    2137 	.db #0x43	; 67	'C'
      00C51B 1C                    2138 	.db #0x1c	; 28
      00C51C BA                    2139 	.db #0xba	; 186
      00C51D 89                    2140 	.db #0x89	; 137
      00C51E 68                    2141 	.db #0x68	; 104	'h'
      00C51F 4A                    2142 	.db #0x4a	; 74	'J'
      00C520 1C                    2143 	.db #0x1c	; 28
      00C521 91                    2144 	.db #0x91	; 145
      00C522 3F                    2145 	.db #0x3f	; 63
      00C523 D1                    2146 	.db #0xd1	; 209
      00C524 B3                    2147 	.db #0xb3	; 179
      00C525 96                    2148 	.db #0x96	; 150
      00C526 1D                    2149 	.db #0x1d	; 29
      00C527 7C                    2150 	.db #0x7c	; 124
      00C528 14                    2151 	.db #0x14	; 20
      00C529 77                    2152 	.db #0x77	; 119	'w'
      00C52A 9C                    2153 	.db #0x9c	; 156
      00C52B 74                    2154 	.db #0x74	; 116	't'
      00C52C 36                    2155 	.db #0x36	; 54	'6'
      00C52D FF                    2156 	.db #0xff	; 255
      00C52E 2C                    2157 	.db #0x2c	; 44
      00C52F 66                    2158 	.db #0x66	; 102	'f'
      00C530 AF                    2159 	.db #0xaf	; 175
      00C531 0F                    2160 	.db #0x0f	; 15
      00C532 3C                    2161 	.db #0x3c	; 60
      00C533 A2                    2162 	.db #0xa2	; 162
      00C534 23                    2163 	.db #0x23	; 35
      00C535 85                    2164 	.db #0x85	; 133
      00C536 05                    2165 	.db #0x05	; 5
      00C537 87                    2166 	.db #0x87	; 135
      00C538 DA                    2167 	.db #0xda	; 218
      00C539 61                    2168 	.db #0x61	; 97	'a'
      00C53A 5E                    2169 	.db #0x5e	; 94
      00C53B 42                    2170 	.db #0x42	; 66	'B'
      00C53C 54                    2171 	.db #0x54	; 84	'T'
      00C53D 60                    2172 	.db #0x60	; 96
      00C53E 23                    2173 	.db #0x23	; 35
      00C53F CA                    2174 	.db #0xca	; 202
      00C540 BC                    2175 	.db #0xbc	; 188
      00C541 B3                    2176 	.db #0xb3	; 179
      00C542 18                    2177 	.db #0x18	; 24
      00C543 1D                    2178 	.db #0x1d	; 29
      00C544 F8                    2179 	.db #0xf8	; 248
      00C545 0A                    2180 	.db #0x0a	; 10
      00C546 55                    2181 	.db #0x55	; 85	'U'
      00C547 CD                    2182 	.db #0xcd	; 205
      00C548 A3                    2183 	.db #0xa3	; 163
      00C549 DE                    2184 	.db #0xde	; 222
      00C54A FF                    2185 	.db #0xff	; 255
      00C54B B2                    2186 	.db #0xb2	; 178
      00C54C 2A                    2187 	.db #0x2a	; 42
      00C54D 35                    2188 	.db #0x35	; 53	'5'
      00C54E 00                    2189 	.db #0x00	; 0
      00C54F D6                    2190 	.db #0xd6	; 214
      00C550 7B                    2191 	.db #0x7b	; 123
      00C551 E8                    2192 	.db #0xe8	; 232
      00C552 F2                    2193 	.db #0xf2	; 242
      00C553 1A                    2194 	.db #0x1a	; 26
      00C554 BC                    2195 	.db #0xbc	; 188
      00C555 F5                    2196 	.db #0xf5	; 245
      00C556 7E                    2197 	.db #0x7e	; 126
      00C557 48                    2198 	.db #0x48	; 72	'H'
      00C558 72                    2199 	.db #0x72	; 114	'r'
      00C559 E0                    2200 	.db #0xe0	; 224
      00C55A E4                    2201 	.db #0xe4	; 228
      00C55B E0                    2202 	.db #0xe0	; 224
      00C55C 27                    2203 	.db #0x27	; 39
      00C55D 87                    2204 	.db #0x87	; 135
      00C55E 9A                    2205 	.db #0x9a	; 154
      00C55F 51                    2206 	.db #0x51	; 81	'Q'
      00C560 D4                    2207 	.db #0xd4	; 212
      00C561 DD                    2208 	.db #0xdd	; 221
      00C562 C3                    2209 	.db #0xc3	; 195
      00C563 AA                    2210 	.db #0xaa	; 170
      00C564 49                    2211 	.db #0x49	; 73	'I'
      00C565 5A                    2212 	.db #0x5a	; 90	'Z'
      00C566 2A                    2213 	.db #0x2a	; 42
      00C567 00                    2214 	.db #0x00	; 0
      00C568 A0                    2215 	.db #0xa0	; 160
      00C569 8C                    2216 	.db #0x8c	; 140
      00C56A FF                    2217 	.db #0xff	; 255
      00C56B 74                    2218 	.db #0x74	; 116	't'
      00C56C BF                    2219 	.db #0xbf	; 191
      00C56D EC                    2220 	.db #0xec	; 236
      00C56E 1D                    2221 	.db #0x1d	; 29
      00C56F F1                    2222 	.db #0xf1	; 241
      00C570 00                    2223 	.db #0x00	; 0
      00C571 01                    2224 	.db #0x01	; 1
      00C572 D8                    2225 	.db #0xd8	; 216
      00C573 02                    2226 	.db #0x02	; 2
      00C574 CC                    2227 	.db #0xcc	; 204
      00C575 07                    2228 	.db #0x07	; 7
      00C576 00                    2229 	.db #0x00	; 0
      00C577 00                    2230 	.db #0x00	; 0
      00C578 C4                    2231 	.db #0xc4	; 196
      00C579 5E                    2232 	.db #0x5e	; 94
      00C57A 2C                    2233 	.db #0x2c	; 44
      00C57B 7E                    2234 	.db #0x7e	; 126
      00C57C B1                    2235 	.db #0xb1	; 177
      00C57D C4                    2236 	.db #0xc4	; 196
      00C57E 67                    2237 	.db #0x67	; 103	'g'
      00C57F FB                    2238 	.db #0xfb	; 251
      00C580 02                    2239 	.db #0x02	; 2
      00C581 00                    2240 	.db #0x00	; 0
      00C582 00                    2241 	.db #0x00	; 0
      00C583 00                    2242 	.db #0x00	; 0
      00C584 00                    2243 	.db #0x00	; 0
      00C585 04                    2244 	.db #0x04	; 4
      00C586 59                    2245 	.db #0x59	; 89	'Y'
      00C587 5A                    2246 	.db #0x5a	; 90	'Z'
                                   2247 	.area CSEG    (CODE)
                                   2248 	.area CONST   (CODE)
      00C588                       2249 _vial_handle_cmd_keyboard_uid_40000_624:
      00C588 04                    2250 	.db #0x04	; 4
      00C589 70                    2251 	.db #0x70	; 112	'p'
      00C58A FF                    2252 	.db #0xff	; 255
      00C58B 90                    2253 	.db #0x90	; 144
      00C58C 01                    2254 	.db #0x01	; 1
      00C58D B9                    2255 	.db #0xb9	; 185
      00C58E 15                    2256 	.db #0x15	; 21
      00C58F D3                    2257 	.db #0xd3	; 211
                                   2258 	.area CSEG    (CODE)
                                   2259 	.area XINIT   (CODE)
      00C7BE                       2260 __xinit__vial_unlocked:
      00C7BE 00                    2261 	.db #0x00	;  0
      00C7BF                       2262 __xinit__vial_unlock_in_progress:
      00C7BF 00                    2263 	.db #0x00	;  0
      00C7C0                       2264 __xinit__vial_unlock_counter:
      00C7C0 00                    2265 	.db #0x00	; 0
      00C7C1                       2266 __xinit__vial_unlock_combo_rows:
      00C7C1 00                    2267 	.db #0x00	; 0
      00C7C2 00                    2268 	.db #0x00	; 0
      00C7C3                       2269 __xinit__vial_unlock_combo_cols:
      00C7C3 00                    2270 	.db #0x00	; 0
      00C7C4 05                    2271 	.db #0x05	; 5
                                   2272 	.area CABS    (ABS,CODE)
                                   2273 
                                   2274 ; Experimental exact instruction outlining.
                                   2275 	.globl _ak820_outline_0006
                                   2276 	.globl _ak820_outline_0007
                                   2277 	.globl _ak820_outline_0009
                                   2278 	.globl _ak820_outline_0010
                                   2279 	.globl _ak820_outline_0013
                                   2280 	.globl _ak820_outline_0014
                                   2281 	.globl _ak820_outline_0018
                                   2282 	.globl _ak820_outline_0020
                                   2283 	.globl _ak820_outline_0021
                                   2284 	.globl _ak820_outline_0022
                                   2285 	.globl _ak820_outline_0026
                                   2286 	.globl _ak820_outline_0028
                                   2287 	.globl _ak820_outline_0035
                                   2288 	.globl _ak820_outline_0037
                                   2289 	.globl _ak820_outline_0041
                                   2290 	.globl _ak820_outline_0045
                                   2291 	.globl _ak820_outline_0058
                                   2292 	.globl _ak820_outline_0061
                                   2293 	.globl _ak820_outline_0062
                                   2294 	.globl _ak820_outline_0064
                                   2295 	.globl _ak820_outline_0071
                                   2296 	.globl _ak820_outline_0077
                                   2297 	.globl _ak820_outline_0084
                                   2298 	.globl _ak820_outline_0102
                                   2299 	.globl _ak820_outline_0106
                                   2300 	.globl _ak820_outline_0107
                                   2301 	.globl _ak820_outline_0111
                                   2302 	.globl _ak820_outline_0112
                                   2303 	.globl _ak820_outline_0124
                                   2304 	.globl _ak820_outline_0131
                                   2305 	.globl _ak820_outline_0132
                                   2306 	.globl _ak820_outline_0133
                                   2307 	.globl _ak820_outline_0134
                                   2308 	.globl _ak820_outline_0136
                                   2309 	.globl _ak820_outline_0137
                                   2310 	.globl _ak820_outline_0142
                                   2311 	.globl _ak820_outline_0145
                                   2312 	.globl _ak820_outline_0146
                                   2313 	.globl _ak820_outline_0150
                                   2314 	.globl _ak820_outline_0167
                                   2315 	.globl _ak820_outline_0177
                                   2316 	.globl _ak820_outline_0193
                                   2317 	.globl _ak820_outline_0196
                                   2318 
                                   2319 	.area CSEG (CODE)
                                   2320 ; function ak820_outline_0009
      00B8B4                       2321 _ak820_outline_0009:
      00B8B4 A3               [24] 2322 	inc	dptr
      00B8B5 F0               [24] 2323 	movx	@dptr,a
      00B8B6 E4               [12] 2324 	clr	a
      00B8B7 A3               [24] 2325 	inc	dptr
      00B8B8 F0               [24] 2326 	movx	@dptr,a
      00B8B9 90 0E 8F         [24] 2327 	mov	dptr,#___memcpy_PARM_3
      00B8BC 74 0A            [12] 2328 	mov	a,#0x0a
      00B8BE F0               [24] 2329 	movx	@dptr,a
      00B8BF E4               [12] 2330 	clr	a
      00B8C0 A3               [24] 2331 	inc	dptr
      00B8C1 F0               [24] 2332 	movx	@dptr,a
      00B8C2 22               [24] 2333 	ret
                                   2334 
                                   2335 	.area CSEG (CODE)
                                   2336 ; function ak820_outline_0028
      00B8C3                       2337 _ak820_outline_0028:
      00B8C3 E0               [24] 2338 	movx	a,@dptr
      00B8C4 FE               [12] 2339 	mov	r6,a
      00B8C5 A3               [24] 2340 	inc	dptr
      00B8C6 E0               [24] 2341 	movx	a,@dptr
      00B8C7 FF               [12] 2342 	mov	r7,a
      00B8C8 90 0D 64         [24] 2343 	mov	dptr,#_g_vial_magic_keycode_override
      00B8CB EE               [12] 2344 	mov	a,r6
      00B8CC F0               [24] 2345 	movx	@dptr,a
      00B8CD EF               [12] 2346 	mov	a,r7
      00B8CE A3               [24] 2347 	inc	dptr
      00B8CF F0               [24] 2348 	movx	@dptr,a
      00B8D0 8E 04            [24] 2349 	mov	ar4,r6
      00B8D2 8F 05            [24] 2350 	mov	ar5,r7
      00B8D4 C3               [12] 2351 	clr	c
      00B8D5 74 FF            [12] 2352 	mov	a,#0xff
      00B8D7 9C               [12] 2353 	subb	a,r4
      00B8D8 74 1F            [12] 2354 	mov	a,#0x1f
      00B8DA 9D               [12] 2355 	subb	a,r5
      00B8DB 22               [24] 2356 	ret
                                   2357 
                                   2358 	.area CSEG (CODE)
                                   2359 ; function ak820_outline_0045
      00B8DC                       2360 _ak820_outline_0045:
      00B8DC E0               [24] 2361 	movx	a,@dptr
      00B8DD F9               [12] 2362 	mov	r1,a
      00B8DE A3               [24] 2363 	inc	dptr
      00B8DF E0               [24] 2364 	movx	a,@dptr
      00B8E0 FA               [12] 2365 	mov	r2,a
      00B8E1 89 82            [24] 2366 	mov	dpl,r1
      00B8E3 8A 83            [24] 2367 	mov	dph,r2
      00B8E5 22               [24] 2368 	ret
                                   2369 
                                   2370 	.area CSEG (CODE)
                                   2371 ; function ak820_outline_0136
      00B8E6                       2372 _ak820_outline_0136:
      00B8E6 24 11            [12] 2373 	add	a,#_vial_unlock_combo_cols
      00B8E8 F5 82            [12] 2374 	mov	dpl,a
      00B8EA E4               [12] 2375 	clr	a
      00B8EB 34 0F            [12] 2376 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B8ED F5 83            [12] 2377 	mov	dph,a
      00B8EF E0               [24] 2378 	movx	a,@dptr
      00B8F0 22               [24] 2379 	ret
                                   2380 
                                   2381 	.area CSEG (CODE)
                                   2382 ; function ak820_outline_0137
      00B8F1                       2383 _ak820_outline_0137:
      00B8F1 24 0F            [12] 2384 	add	a,#_vial_unlock_combo_rows
      00B8F3 F5 82            [12] 2385 	mov	dpl,a
      00B8F5 E4               [12] 2386 	clr	a
      00B8F6 34 0F            [12] 2387 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B8F8 F5 83            [12] 2388 	mov	dph,a
      00B8FA E0               [24] 2389 	movx	a,@dptr
      00B8FB 22               [24] 2390 	ret
