                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_tap_dance_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_combo_PARM_2
                                    294 	.globl _dynamic_keymap_get_combo_PARM_2
                                    295 	.globl _dynamic_keymap_set_tap_dance_PARM_2
                                    296 	.globl _dynamic_keymap_get_tap_dance_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_tap_dance
                                    317 	.globl _dynamic_keymap_set_tap_dance
                                    318 	.globl _dynamic_keymap_get_combo
                                    319 	.globl _dynamic_keymap_set_combo
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000031                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      000031                        594 	.ds 2
      000033                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      000033                        596 	.ds 1
      000034                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      000034                        598 	.ds 1
      000035                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      000035                        600 	.ds 2
      000037                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      000037                        602 	.ds 2
      000039                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      000039                        604 	.ds 1
      00003A                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      00003A                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000026                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000026                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B9E                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B9E                        634 	.ds 1
      000B9F                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B9F                        636 	.ds 1
      000BA0                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_371:
      000BA0                        638 	.ds 1
      000BA1                        639 _dynamic_keymap_get_keycode_PARM_2:
      000BA1                        640 	.ds 1
      000BA2                        641 _dynamic_keymap_get_keycode_PARM_3:
      000BA2                        642 	.ds 1
      000BA3                        643 _dynamic_keymap_get_keycode_layer_10000_373:
      000BA3                        644 	.ds 1
      000BA4                        645 _dynamic_keymap_set_keycode_PARM_2:
      000BA4                        646 	.ds 1
      000BA5                        647 _dynamic_keymap_set_keycode_PARM_3:
      000BA5                        648 	.ds 1
      000BA6                        649 _dynamic_keymap_set_keycode_PARM_4:
      000BA6                        650 	.ds 2
      000BA8                        651 _dynamic_keymap_set_keycode_layer_10000_377:
      000BA8                        652 	.ds 1
      000BA9                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000BA9                        654 	.ds 1
      000BAA                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_381:
      000BAA                        656 	.ds 1
      000BAB                        657 _dynamic_keymap_get_encoder_PARM_2:
      000BAB                        658 	.ds 1
      000BAC                        659 _dynamic_keymap_get_encoder_PARM_3:
      000BAC                        660 	.ds 1
      000BAD                        661 _dynamic_keymap_get_encoder_layer_10000_383:
      000BAD                        662 	.ds 1
      000BAE                        663 _dynamic_keymap_set_encoder_PARM_2:
      000BAE                        664 	.ds 1
      000BAF                        665 _dynamic_keymap_set_encoder_PARM_3:
      000BAF                        666 	.ds 1
      000BB0                        667 _dynamic_keymap_set_encoder_PARM_4:
      000BB0                        668 	.ds 2
      000BB2                        669 _dynamic_keymap_set_encoder_layer_10000_387:
      000BB2                        670 	.ds 1
      000BB3                        671 _dynamic_keymap_get_tap_dance_PARM_2:
      000BB3                        672 	.ds 3
      000BB6                        673 _dynamic_keymap_get_tap_dance_index_10000_391:
      000BB6                        674 	.ds 1
      000BB7                        675 _dynamic_keymap_set_tap_dance_PARM_2:
      000BB7                        676 	.ds 3
      000BBA                        677 _dynamic_keymap_set_tap_dance_index_10000_395:
      000BBA                        678 	.ds 1
      000BBB                        679 _dynamic_keymap_get_combo_PARM_2:
      000BBB                        680 	.ds 3
      000BBE                        681 _dynamic_keymap_get_combo_index_10000_398:
      000BBE                        682 	.ds 1
      000BBF                        683 _dynamic_keymap_set_combo_PARM_2:
      000BBF                        684 	.ds 3
      000BC2                        685 _dynamic_keymap_set_combo_index_10000_404:
      000BC2                        686 	.ds 1
      000BC3                        687 _dynamic_keymap_set_combo_stored_10002_409:
      000BC3                        688 	.ds 10
      000BCD                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_412:
      000BCD                        690 	.ds 1
      000BCE                        691 _dynamic_keymap_reset_td_10001_421:
      000BCE                        692 	.ds 10
      000BD8                        693 _dynamic_keymap_reset_combo_10002_424:
      000BD8                        694 	.ds 10
      000BE2                        695 _ak820_dynamic_read_buffer_PARM_2:
      000BE2                        696 	.ds 2
      000BE4                        697 _ak820_dynamic_read_buffer_PARM_3:
      000BE4                        698 	.ds 2
      000BE6                        699 _ak820_dynamic_read_buffer_PARM_4:
      000BE6                        700 	.ds 2
      000BE8                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BE8                        702 	.ds 3
      000BEB                        703 _ak820_dynamic_read_buffer_base_10000_426:
      000BEB                        704 	.ds 2
      000BED                        705 _ak820_dynamic_read_buffer_available_10000_427:
      000BED                        706 	.ds 1
      000BEE                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BEE                        708 	.ds 2
      000BF0                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BF0                        710 	.ds 3
      000BF3                        711 _dynamic_keymap_get_buffer_offset_10000_433:
      000BF3                        712 	.ds 2
      000BF5                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BF5                        714 	.ds 2
      000BF7                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BF7                        716 	.ds 3
      000BFA                        717 _dynamic_keymap_set_buffer_offset_10000_435:
      000BFA                        718 	.ds 2
      000BFC                        719 _dynamic_keymap_set_buffer_chk_offset_30001_442:
      000BFC                        720 	.ds 1
      000BFD                        721 _dynamic_keymap_set_buffer_chk_sz_30001_442:
      000BFD                        722 	.ds 1
      000BFE                        723 _dynamic_keymap_set_buffer_i_40001_449:
      000BFE                        724 	.ds 1
      000BFF                        725 _keycode_at_keymap_location_PARM_2:
      000BFF                        726 	.ds 1
      000C00                        727 _keycode_at_keymap_location_PARM_3:
      000C00                        728 	.ds 1
      000C01                        729 _keycode_at_keymap_location_layer_num_10000_453:
      000C01                        730 	.ds 1
      000C02                        731 _keycode_at_encodermap_location_PARM_2:
      000C02                        732 	.ds 1
      000C03                        733 _keycode_at_encodermap_location_PARM_3:
      000C03                        734 	.ds 1
      000C04                        735 _keycode_at_encodermap_location_layer_num_10000_457:
      000C04                        736 	.ds 1
      000C05                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000C05                        738 	.ds 2
      000C07                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000C07                        740 	.ds 3
      000C0A                        741 _dynamic_keymap_macro_get_buffer_offset_10000_465:
      000C0A                        742 	.ds 2
      000C0C                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000C0C                        744 	.ds 2
      000C0E                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000C0E                        746 	.ds 3
      000C11                        747 _dynamic_keymap_macro_set_buffer_offset_10000_467:
      000C11                        748 	.ds 2
      000C13                        749 _decode_keycode_kc_10000_471:
      000C13                        750 	.ds 2
      000C15                        751 _dynamic_keymap_macro_send_id_10000_474:
      000C15                        752 	.ds 1
      000C16                        753 _dynamic_keymap_macro_send_sending_10000_475:
      000C16                        754 	.ds 1
      000C17                        755 _dynamic_keymap_macro_send_p_10001_480:
      000C17                        756 	.ds 2
      000C19                        757 _dynamic_keymap_macro_send_data_10003_487:
      000C19                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      00886C                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00886C 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      00886F 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_371'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      008870                        826 _dynamic_keymap_key_to_eeprom_address:
      008870 E5 82            [12]  827 	mov	a,dpl
      008872 90 0B A0         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_371
      008875 F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008876 E0               [24]  831 	movx	a,@dptr
      008877 FF               [12]  832 	mov	r7,a
      008878 7E 00            [12]  833 	mov	r6,#0x00
      00887A 74 40            [12]  834 	mov	a,#0x40
      00887C 2E               [12]  835 	add	a, r6
      00887D FE               [12]  836 	mov	r6,a
      00887E E4               [12]  837 	clr	a
      00887F 3F               [12]  838 	addc	a, r7
      008880 FF               [12]  839 	mov	r7,a
      008881 7D 00            [12]  840 	mov	r5,#0x00
      008883 90 0B 9E         [24]  841 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008886 E0               [24]  842 	movx	a,@dptr
      008887 75 F0 10         [24]  843 	mov	b,#0x10
      00888A A4               [48]  844 	mul	ab
      00888B 2E               [12]  845 	add	a, r6
      00888C FE               [12]  846 	mov	r6,a
      00888D EF               [12]  847 	mov	a,r7
      00888E 35 F0            [12]  848 	addc	a, b
      008890 FF               [12]  849 	mov	r7,a
      008891 90 0B 9F         [24]  850 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008894 E0               [24]  851 	movx	a,@dptr
      008895 7C 00            [12]  852 	mov	r4,#0x00
      008897 25 E0            [12]  853 	add	a,acc
      008899 FB               [12]  854 	mov	r3,a
      00889A EC               [12]  855 	mov	a,r4
      00889B 33               [12]  856 	rlc	a
      00889C FC               [12]  857 	mov	r4,a
      00889D EB               [12]  858 	mov	a,r3
      00889E 2E               [12]  859 	add	a, r6
      00889F FE               [12]  860 	mov	r6,a
      0088A0 EC               [12]  861 	mov	a,r4
      0088A1 3F               [12]  862 	addc	a, r7
      0088A2 FF               [12]  863 	mov	r7,a
      0088A3 12 7C 21         [24]  864 	lcall	_ak820_outline_0118
                                    865 ;	quantum/dynamic_keymap.c:206: }
      0088A6 22               [24]  866 	ret
                                    867 ;------------------------------------------------------------
                                    868 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    869 ;------------------------------------------------------------
                                    870 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    871 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    872 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_373'
                                    873 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_376'
                                    874 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_376'
                                    875 ;------------------------------------------------------------
                                    876 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    877 ;	-----------------------------------------
                                    878 ;	 function dynamic_keymap_get_keycode
                                    879 ;	-----------------------------------------
      0088A7                        880 _dynamic_keymap_get_keycode:
      0088A7 E5 82            [12]  881 	mov	a,dpl
      0088A9 90 0B A3         [24]  882 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_373
      0088AC F0               [24]  883 	movx	@dptr,a
                                    884 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0088AD E0               [24]  885 	movx	a,@dptr
      0088AE FF               [12]  886 	mov	r7,a
      0088AF BF 06 00         [24]  887 	cjne	r7,#0x06,00121$
      0088B2                        888 00121$:
      0088B2 50 14            [24]  889 	jnc	00101$
      0088B4 90 0B A1         [24]  890 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0088B7 E0               [24]  891 	movx	a,@dptr
      0088B8 FE               [12]  892 	mov	r6,a
      0088B9 BE 10 00         [24]  893 	cjne	r6,#0x10,00123$
      0088BC                        894 00123$:
      0088BC 50 0A            [24]  895 	jnc	00101$
      0088BE 90 0B A2         [24]  896 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0088C1 E0               [24]  897 	movx	a,@dptr
      0088C2 FD               [12]  898 	mov	r5,a
      0088C3 BD 08 00         [24]  899 	cjne	r5,#0x08,00125$
      0088C6                        900 00125$:
      0088C6 40 04            [24]  901 	jc	00102$
      0088C8                        902 00101$:
      0088C8 90 00 00         [24]  903 	mov	dptr,#0x0000
      0088CB 22               [24]  904 	ret
      0088CC                        905 00102$:
                                    906 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0088CC 12 94 58         [24]  907 	lcall	_ak820_outline_0101
      0088CF 11 70            [12]  908 	acall	_dynamic_keymap_key_to_eeprom_address
                                    909 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      0088D1 12 94 6C         [24]  910 	lcall	_ak820_outline_0122
      0088D4 12 40 7C         [24]  911 	lcall	_eeprom_read_byte
      0088D7 AB 82            [24]  912 	mov	r3,dpl
      0088D9 7C 00            [12]  913 	mov	r4,#0x00
                                    914 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      0088DB 0D               [12]  915 	inc	r5
      0088DC BD 00 01         [24]  916 	cjne	r5,#0x00,00127$
      0088DF 0E               [12]  917 	inc	r6
      0088E0                        918 00127$:
      0088E0 12 72 A8         [24]  919 	lcall	_ak820_outline_0063
      0088E3 12 40 7C         [24]  920 	lcall	_eeprom_read_byte
      0088E6 AF 82            [24]  921 	mov	r7, dpl
      0088E8 7E 00            [12]  922 	mov	r6,#0x00
      0088EA EF               [12]  923 	mov	a,r7
      0088EB 42 04            [12]  924 	orl	ar4,a
      0088ED EE               [12]  925 	mov	a,r6
      0088EE 42 03            [12]  926 	orl	ar3,a
                                    927 ;	quantum/dynamic_keymap.c:214: return keycode;
      0088F0 12 43 8A         [24]  928 	lcall	_ak820_outline_0190
                                    929 ;	quantum/dynamic_keymap.c:215: }
      0088F3 22               [24]  930 	ret
                                    931 ;------------------------------------------------------------
                                    932 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    933 ;------------------------------------------------------------
                                    934 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    935 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    936 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    937 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_377'
                                    938 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_380'
                                    939 ;------------------------------------------------------------
                                    940 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    941 ;	-----------------------------------------
                                    942 ;	 function dynamic_keymap_set_keycode
                                    943 ;	-----------------------------------------
      0088F4                        944 _dynamic_keymap_set_keycode:
      0088F4 E5 82            [12]  945 	mov	a,dpl
      0088F6 90 0B A8         [24]  946 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_377
      0088F9 F0               [24]  947 	movx	@dptr,a
                                    948 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0088FA E0               [24]  949 	movx	a,@dptr
      0088FB FF               [12]  950 	mov	r7,a
      0088FC BF 06 00         [24]  951 	cjne	r7,#0x06,00121$
      0088FF                        952 00121$:
      0088FF 50 14            [24]  953 	jnc	00101$
      008901 90 0B A4         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008904 E0               [24]  955 	movx	a,@dptr
      008905 FE               [12]  956 	mov	r6,a
      008906 BE 10 00         [24]  957 	cjne	r6,#0x10,00123$
      008909                        958 00123$:
      008909 50 0A            [24]  959 	jnc	00101$
      00890B 90 0B A5         [24]  960 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00890E E0               [24]  961 	movx	a,@dptr
      00890F FD               [12]  962 	mov	r5,a
      008910 BD 08 00         [24]  963 	cjne	r5,#0x08,00125$
      008913                        964 00125$:
      008913 40 01            [24]  965 	jc	00102$
      008915                        966 00101$:
      008915 22               [24]  967 	ret
      008916                        968 00102$:
                                    969 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008916 12 94 58         [24]  970 	lcall	_ak820_outline_0101
      008919 11 70            [12]  971 	acall	_dynamic_keymap_key_to_eeprom_address
      00891B 12 94 6C         [24]  972 	lcall	_ak820_outline_0122
                                    973 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      00891E 90 0B A6         [24]  974 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008921 E0               [24]  975 	movx	a,@dptr
      008922 FB               [12]  976 	mov	r3,a
      008923 A3               [24]  977 	inc	dptr
      008924 E0               [24]  978 	movx	a,@dptr
      008925 90 07 64         [24]  979 	mov	dptr,#_eeprom_update_byte_PARM_2
      008928 12 54 77         [24]  980 	lcall	_ak820_outline_0036
      00892B 12 53 5E         [24]  981 	lcall	_eeprom_update_byte
                                    982 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      00892E 0D               [12]  983 	inc	r5
      00892F BD 00 01         [24]  984 	cjne	r5,#0x00,00127$
      008932 0E               [12]  985 	inc	r6
      008933                        986 00127$:
      008933 90 07 64         [24]  987 	mov	dptr,#_eeprom_update_byte_PARM_2
      008936 EB               [12]  988 	mov	a,r3
      008937 12 54 77         [24]  989 	lcall	_ak820_outline_0036
                                    990 ;	quantum/dynamic_keymap.c:223: }
      00893A 02 53 5E         [24]  991 	ljmp	_eeprom_update_byte
                                    992 ;------------------------------------------------------------
                                    993 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    994 ;------------------------------------------------------------
                                    995 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    996 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    999 ;	-----------------------------------------
                                   1000 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                   1001 ;	-----------------------------------------
      00893D                       1002 _dynamic_keymap_encoder_to_eeprom_address:
      00893D E5 82            [12] 1003 	mov	a,dpl
      00893F 90 0B AA         [24] 1004 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381
      008942 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008943 E0               [24] 1007 	movx	a,@dptr
      008944 12 38 CC         [24] 1008 	lcall	_ak820_outline_0195
      008947 24 40            [12] 1009 	add	a, #0x40
      008949 FD               [12] 1010 	mov	r5,a
      00894A 74 06            [12] 1011 	mov	a,#0x06
      00894C 35 F0            [12] 1012 	addc	a, b
      00894E FE               [12] 1013 	mov	r6,a
      00894F 7F 00            [12] 1014 	mov	r7,#0x00
      008951 90 0B A9         [24] 1015 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008954 E0               [24] 1016 	movx	a,@dptr
      008955 12 38 CC         [24] 1017 	lcall	_ak820_outline_0195
      008958 2D               [12] 1018 	add	a, r5
      008959 FD               [12] 1019 	mov	r5,a
      00895A EE               [12] 1020 	mov	a,r6
      00895B 35 F0            [12] 1021 	addc	a, b
      00895D FE               [12] 1022 	mov	r6,a
      00895E 12 72 A8         [24] 1023 	lcall	_ak820_outline_0063
                                   1024 ;	quantum/dynamic_keymap.c:228: }
      008961 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1028 ;------------------------------------------------------------
                                   1029 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1030 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1031 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_383'
                                   1032 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_386'
                                   1033 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_386'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function dynamic_keymap_get_encoder
                                   1038 ;	-----------------------------------------
      008962                       1039 _dynamic_keymap_get_encoder:
      008962 E5 82            [12] 1040 	mov	a,dpl
      008964 90 0B AD         [24] 1041 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_383
      008967 F0               [24] 1042 	movx	@dptr,a
                                   1043 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008968 E0               [24] 1044 	movx	a,@dptr
      008969 FF               [12] 1045 	mov	r7,a
      00896A BF 06 00         [24] 1046 	cjne	r7,#0x06,00131$
      00896D                       1047 00131$:
      00896D 50 0A            [24] 1048 	jnc	00101$
      00896F 90 0B AB         [24] 1049 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008972 E0               [24] 1050 	movx	a,@dptr
      008973 FE               [12] 1051 	mov	r6,a
      008974 BE 01 00         [24] 1052 	cjne	r6,#0x01,00133$
      008977                       1053 00133$:
      008977 40 04            [24] 1054 	jc	00102$
      008979                       1055 00101$:
      008979 90 00 00         [24] 1056 	mov	dptr,#0x0000
      00897C 22               [24] 1057 	ret
      00897D                       1058 00102$:
                                   1059 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00897D 90 0B A9         [24] 1060 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008980 E4               [12] 1061 	clr	a
      008981 F0               [24] 1062 	movx	@dptr,a
      008982 8F 82            [24] 1063 	mov	dpl, r7
      008984 31 3D            [12] 1064 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008986 12 94 6C         [24] 1065 	lcall	_ak820_outline_0122
                                   1066 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008989 90 0B AC         [24] 1067 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00898C E0               [24] 1068 	movx	a,@dptr
      00898D FC               [12] 1069 	mov	r4,a
      00898E E0               [24] 1070 	movx	a,@dptr
      00898F 60 04            [24] 1071 	jz	00106$
      008991 7B 00            [12] 1072 	mov	r3,#0x00
      008993 80 02            [24] 1073 	sjmp	00107$
      008995                       1074 00106$:
      008995 7B 02            [12] 1075 	mov	r3,#0x02
      008997                       1076 00107$:
      008997 EB               [12] 1077 	mov	a,r3
      008998 12 7B CC         [24] 1078 	lcall	_ak820_outline_0016
      00899B 12 40 7C         [24] 1079 	lcall	_eeprom_read_byte
      00899E AA 82            [24] 1080 	mov	r2,dpl
      0089A0 7B 00            [12] 1081 	mov	r3,#0x00
                                   1082 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0089A2 EC               [12] 1083 	mov	a,r4
      0089A3 60 04            [24] 1084 	jz	00108$
      0089A5 7C 00            [12] 1085 	mov	r4,#0x00
      0089A7 80 02            [24] 1086 	sjmp	00109$
      0089A9                       1087 00108$:
      0089A9 7C 02            [12] 1088 	mov	r4,#0x02
      0089AB                       1089 00109$:
      0089AB EC               [12] 1090 	mov	a,r4
      0089AC 12 38 BC         [24] 1091 	lcall	_ak820_outline_0165
      0089AF 0D               [12] 1092 	inc	r5
      0089B0 BD 00 01         [24] 1093 	cjne	r5,#0x00,00137$
      0089B3 0E               [12] 1094 	inc	r6
      0089B4                       1095 00137$:
      0089B4 12 72 A8         [24] 1096 	lcall	_ak820_outline_0063
      0089B7 12 40 7C         [24] 1097 	lcall	_eeprom_read_byte
      0089BA AF 82            [24] 1098 	mov	r7, dpl
      0089BC 7E 00            [12] 1099 	mov	r6,#0x00
      0089BE EF               [12] 1100 	mov	a,r7
      0089BF 42 03            [12] 1101 	orl	ar3,a
      0089C1 EE               [12] 1102 	mov	a,r6
      0089C2 42 02            [12] 1103 	orl	ar2,a
                                   1104 ;	quantum/dynamic_keymap.c:236: return keycode;
      0089C4 8B 82            [24] 1105 	mov	dpl, r3
      0089C6 8A 83            [24] 1106 	mov	dph, r2
                                   1107 ;	quantum/dynamic_keymap.c:237: }
      0089C8 22               [24] 1108 	ret
                                   1109 ;------------------------------------------------------------
                                   1110 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1111 ;------------------------------------------------------------
                                   1112 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1113 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1114 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1115 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1116 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_387'
                                   1117 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_390'
                                   1118 ;------------------------------------------------------------
                                   1119 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1120 ;	-----------------------------------------
                                   1121 ;	 function dynamic_keymap_set_encoder
                                   1122 ;	-----------------------------------------
      0089C9                       1123 _dynamic_keymap_set_encoder:
      0089C9 E5 82            [12] 1124 	mov	a,dpl
      0089CB 90 0B B2         [24] 1125 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_387
      0089CE F0               [24] 1126 	movx	@dptr,a
                                   1127 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0089CF E0               [24] 1128 	movx	a,@dptr
      0089D0 FF               [12] 1129 	mov	r7,a
      0089D1 BF 06 00         [24] 1130 	cjne	r7,#0x06,00131$
      0089D4                       1131 00131$:
      0089D4 50 0A            [24] 1132 	jnc	00101$
      0089D6 90 0B AE         [24] 1133 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0089D9 E0               [24] 1134 	movx	a,@dptr
      0089DA FE               [12] 1135 	mov	r6,a
      0089DB BE 01 00         [24] 1136 	cjne	r6,#0x01,00133$
      0089DE                       1137 00133$:
      0089DE 40 01            [24] 1138 	jc	00102$
      0089E0                       1139 00101$:
      0089E0 22               [24] 1140 	ret
      0089E1                       1141 00102$:
                                   1142 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0089E1 90 0B A9         [24] 1143 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0089E4 E4               [12] 1144 	clr	a
      0089E5 F0               [24] 1145 	movx	@dptr,a
      0089E6 8F 82            [24] 1146 	mov	dpl, r7
      0089E8 31 3D            [12] 1147 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0089EA 12 94 6C         [24] 1148 	lcall	_ak820_outline_0122
                                   1149 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0089ED 90 0B AF         [24] 1150 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0089F0 E0               [24] 1151 	movx	a,@dptr
      0089F1 FC               [12] 1152 	mov	r4,a
      0089F2 E0               [24] 1153 	movx	a,@dptr
      0089F3 60 04            [24] 1154 	jz	00106$
      0089F5 7B 00            [12] 1155 	mov	r3,#0x00
      0089F7 80 02            [24] 1156 	sjmp	00107$
      0089F9                       1157 00106$:
      0089F9 7B 02            [12] 1158 	mov	r3,#0x02
      0089FB                       1159 00107$:
      0089FB EB               [12] 1160 	mov	a,r3
      0089FC 12 94 7E         [24] 1161 	lcall	_ak820_outline_0144
      0089FF 8F 03            [24] 1162 	mov	ar3,r7
      008A01 90 0B B0         [24] 1163 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008A04 E0               [24] 1164 	movx	a,@dptr
      008A05 F5 31            [12] 1165 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008A07 A3               [24] 1166 	inc	dptr
      008A08 E0               [24] 1167 	movx	a,@dptr
      008A09 F5 32            [12] 1168 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008A0B 90 07 64         [24] 1169 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A0E F0               [24] 1170 	movx	@dptr,a
      008A0F 12 43 85         [24] 1171 	lcall	_ak820_outline_0177
      008A12 8B F0            [24] 1172 	mov	b, r3
      008A14 12 53 5E         [24] 1173 	lcall	_eeprom_update_byte
                                   1174 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008A17 EC               [12] 1175 	mov	a,r4
      008A18 60 04            [24] 1176 	jz	00108$
      008A1A 7C 00            [12] 1177 	mov	r4,#0x00
      008A1C 80 02            [24] 1178 	sjmp	00109$
      008A1E                       1179 00108$:
      008A1E 7C 02            [12] 1180 	mov	r4,#0x02
      008A20                       1181 00109$:
      008A20 EC               [12] 1182 	mov	a,r4
      008A21 12 38 BC         [24] 1183 	lcall	_ak820_outline_0165
      008A24 0D               [12] 1184 	inc	r5
      008A25 BD 00 01         [24] 1185 	cjne	r5,#0x00,00137$
      008A28 0E               [12] 1186 	inc	r6
      008A29                       1187 00137$:
      008A29 90 07 64         [24] 1188 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A2C E5 31            [12] 1189 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008A2E 12 54 77         [24] 1190 	lcall	_ak820_outline_0036
                                   1191 ;	quantum/dynamic_keymap.c:245: }
      008A31 02 53 5E         [24] 1192 	ljmp	_eeprom_update_byte
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'dynamic_keymap_get_tap_dance'
                                   1195 ;------------------------------------------------------------
                                   1196 ;buffer        Allocated with name '_dynamic_keymap_get_tap_dance_PARM_2'
                                   1197 ;index         Allocated with name '_dynamic_keymap_get_tap_dance_index_10000_391'
                                   1198 ;entry         Allocated with name '_dynamic_keymap_get_tap_dance_entry_10000_392'
                                   1199 ;------------------------------------------------------------
                                   1200 ;	quantum/dynamic_keymap.c:268: int dynamic_keymap_get_tap_dance(uint8_t index, vial_tap_dance_entry_t *buffer) {
                                   1201 ;	-----------------------------------------
                                   1202 ;	 function dynamic_keymap_get_tap_dance
                                   1203 ;	-----------------------------------------
      008A34                       1204 _dynamic_keymap_get_tap_dance:
      008A34 E5 82            [12] 1205 	mov	a,dpl
      008A36 90 0B B6         [24] 1206 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      008A39 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/dynamic_keymap.c:269: vial_tap_dance_entry_t AK820_STATE_MEM *entry = (vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      008A3A 90 0B B3         [24] 1209 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      008A3D 12 38 2D         [24] 1210 	lcall	_ak820_outline_0058
                                   1211 ;	quantum/dynamic_keymap.c:270: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      008A40 90 0B B6         [24] 1212 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      008A43 E0               [24] 1213 	movx	a,@dptr
      008A44 FD               [12] 1214 	mov	r5,a
      008A45 BD 08 00         [24] 1215 	cjne	r5,#0x08,00130$
      008A48                       1216 00130$:
      008A48 40 04            [24] 1217 	jc	00102$
      008A4A 90 FF FF         [24] 1218 	mov	dptr,#0xffff
      008A4D 22               [24] 1219 	ret
      008A4E                       1220 00102$:
                                   1221 ;	quantum/dynamic_keymap.c:271: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008A4E 8E 03            [24] 1222 	mov	ar3,r6
      008A50 8F 04            [24] 1223 	mov	ar4,r7
      008A52 BD 06 00         [24] 1224 	cjne	r5,#0x06,00132$
      008A55                       1225 00132$:
      008A55 50 0C            [24] 1226 	jnc	00107$
      008A57 8D 02            [24] 1227 	mov	ar2,r5
      008A59 EA               [12] 1228 	mov	a,r2
      008A5A 75 F0 0A         [24] 1229 	mov	b,#0x0a
      008A5D A4               [48] 1230 	mul	ab
      008A5E F9               [12] 1231 	mov	r1,a
      008A5F 7A 00            [12] 1232 	mov	r2,#0x00
      008A61 80 11            [24] 1233 	sjmp	00108$
      008A63                       1234 00107$:
      008A63 ED               [12] 1235 	mov	a,r5
      008A64 24 FA            [12] 1236 	add	a,#0xfa
      008A66 75 F0 0A         [24] 1237 	mov	b,#0x0a
      008A69 A4               [48] 1238 	mul	ab
      008A6A F8               [12] 1239 	mov	r0,a
      008A6B 7D 00            [12] 1240 	mov	r5,#0x00
      008A6D 74 40            [12] 1241 	mov	a,#0x40
      008A6F 28               [12] 1242 	add	a, r0
      008A70 F9               [12] 1243 	mov	r1,a
      008A71 E4               [12] 1244 	clr	a
      008A72 3D               [12] 1245 	addc	a, r5
      008A73 FA               [12] 1246 	mov	r2,a
      008A74                       1247 00108$:
      008A74 74 C0            [12] 1248 	mov	a,#0xc0
      008A76 29               [12] 1249 	add	a, r1
      008A77 F9               [12] 1250 	mov	r1,a
      008A78 74 06            [12] 1251 	mov	a,#0x06
      008A7A 3A               [12] 1252 	addc	a, r2
      008A7B FA               [12] 1253 	mov	r2,a
      008A7C 90 05 85         [24] 1254 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008A7F E9               [12] 1255 	mov	a,r1
      008A80 F0               [24] 1256 	movx	@dptr,a
      008A81 EA               [12] 1257 	mov	a,r2
      008A82 12 38 4A         [24] 1258 	lcall	_ak820_outline_0077
      008A85 90 05 88         [24] 1259 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008A88 12 94 65         [24] 1260 	lcall	_ak820_outline_0115
      008A8B 12 33 FC         [24] 1261 	lcall	_ak820_outline_0131
      008A8E C0 07            [24] 1262 	push	ar7
      008A90 C0 06            [24] 1263 	push	ar6
      008A92 12 40 B7         [24] 1264 	lcall	_ak820_eeprom_read_block_xdata
      008A95 D0 06            [24] 1265 	pop	ar6
      008A97 D0 07            [24] 1266 	pop	ar7
                                   1267 ;	quantum/dynamic_keymap.c:272: if (!ak820_tap_dance_valid(entry)) memset(entry, 0, sizeof(*entry));
      008A99 12 38 92         [24] 1268 	lcall	_ak820_outline_0124
      008A9C C0 07            [24] 1269 	push	ar7
      008A9E C0 06            [24] 1270 	push	ar6
      008AA0 12 43 8F         [24] 1271 	lcall	_ak820_tap_dance_valid
      008AA3 E5 82            [12] 1272 	mov	a, dpl
      008AA5 D0 06            [24] 1273 	pop	ar6
      008AA7 D0 07            [24] 1274 	pop	ar7
      008AA9 70 07            [24] 1275 	jnz	00104$
      008AAB FD               [12] 1276 	mov	r5,a
      008AAC 12 94 2F         [24] 1277 	lcall	_ak820_outline_0043
      008AAF 12 BF 04         [24] 1278 	lcall	_memset
      008AB2                       1279 00104$:
                                   1280 ;	quantum/dynamic_keymap.c:273: return 0;
      008AB2 90 00 00         [24] 1281 	mov	dptr,#0x0000
                                   1282 ;	quantum/dynamic_keymap.c:274: }
      008AB5 22               [24] 1283 	ret
                                   1284 ;------------------------------------------------------------
                                   1285 ;Allocation info for local variables in function 'dynamic_keymap_set_tap_dance'
                                   1286 ;------------------------------------------------------------
                                   1287 ;buffer        Allocated with name '_dynamic_keymap_set_tap_dance_PARM_2'
                                   1288 ;index         Allocated with name '_dynamic_keymap_set_tap_dance_index_10000_395'
                                   1289 ;entry         Allocated with name '_dynamic_keymap_set_tap_dance_entry_10000_396'
                                   1290 ;------------------------------------------------------------
                                   1291 ;	quantum/dynamic_keymap.c:275: int dynamic_keymap_set_tap_dance(uint8_t index, const vial_tap_dance_entry_t *buffer) {
                                   1292 ;	-----------------------------------------
                                   1293 ;	 function dynamic_keymap_set_tap_dance
                                   1294 ;	-----------------------------------------
      008AB6                       1295 _dynamic_keymap_set_tap_dance:
      008AB6 E5 82            [12] 1296 	mov	a,dpl
      008AB8 90 0B BA         [24] 1297 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      008ABB F0               [24] 1298 	movx	@dptr,a
                                   1299 ;	quantum/dynamic_keymap.c:276: const vial_tap_dance_entry_t AK820_STATE_MEM *entry = (const vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      008ABC 90 0B B7         [24] 1300 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      008ABF 12 38 2D         [24] 1301 	lcall	_ak820_outline_0058
                                   1302 ;	quantum/dynamic_keymap.c:277: if (index >= AK820_EXTENSION_ENTRIES || !ak820_tap_dance_valid(entry) || !ak820_nvm_ok()) return -1;
      008AC2 90 0B BA         [24] 1303 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      008AC5 E0               [24] 1304 	movx	a,@dptr
      008AC6 FD               [12] 1305 	mov	r5,a
      008AC7 BD 08 00         [24] 1306 	cjne	r5,#0x08,00139$
      008ACA                       1307 00139$:
      008ACA 50 1D            [24] 1308 	jnc	00101$
      008ACC 12 38 92         [24] 1309 	lcall	_ak820_outline_0124
      008ACF C0 07            [24] 1310 	push	ar7
      008AD1 C0 06            [24] 1311 	push	ar6
      008AD3 C0 05            [24] 1312 	push	ar5
      008AD5 12 43 8F         [24] 1313 	lcall	_ak820_tap_dance_valid
      008AD8 E5 82            [12] 1314 	mov	a, dpl
      008ADA D0 05            [24] 1315 	pop	ar5
      008ADC D0 06            [24] 1316 	pop	ar6
      008ADE D0 07            [24] 1317 	pop	ar7
      008AE0 60 07            [24] 1318 	jz	00101$
      008AE2 12 3E 22         [24] 1319 	lcall	_ak820_nvm_ok
      008AE5 E5 82            [12] 1320 	mov	a, dpl
      008AE7 70 04            [24] 1321 	jnz	00102$
      008AE9                       1322 00101$:
      008AE9 90 FF FF         [24] 1323 	mov	dptr,#0xffff
      008AEC 22               [24] 1324 	ret
      008AED                       1325 00102$:
                                   1326 ;	quantum/dynamic_keymap.c:278: clear_keyboard();
      008AED C0 07            [24] 1327 	push	ar7
      008AEF C0 06            [24] 1328 	push	ar6
      008AF1 C0 05            [24] 1329 	push	ar5
      008AF3 12 7B 8A         [24] 1330 	lcall	_clear_keyboard
      008AF6 D0 05            [24] 1331 	pop	ar5
      008AF8 D0 06            [24] 1332 	pop	ar6
      008AFA D0 07            [24] 1333 	pop	ar7
                                   1334 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008AFC BD 06 00         [24] 1335 	cjne	r5,#0x06,00143$
      008AFF                       1336 00143$:
      008AFF 50 0C            [24] 1337 	jnc	00107$
      008B01 8D 04            [24] 1338 	mov	ar4,r5
      008B03 EC               [12] 1339 	mov	a,r4
      008B04 75 F0 0A         [24] 1340 	mov	b,#0x0a
      008B07 A4               [48] 1341 	mul	ab
      008B08 FB               [12] 1342 	mov	r3,a
      008B09 7C 00            [12] 1343 	mov	r4,#0x00
      008B0B 80 11            [24] 1344 	sjmp	00108$
      008B0D                       1345 00107$:
      008B0D ED               [12] 1346 	mov	a,r5
      008B0E 24 FA            [12] 1347 	add	a,#0xfa
      008B10 75 F0 0A         [24] 1348 	mov	b,#0x0a
      008B13 A4               [48] 1349 	mul	ab
      008B14 FD               [12] 1350 	mov	r5,a
      008B15 7A 00            [12] 1351 	mov	r2,#0x00
      008B17 74 40            [12] 1352 	mov	a,#0x40
      008B19 2D               [12] 1353 	add	a, r5
      008B1A FB               [12] 1354 	mov	r3,a
      008B1B E4               [12] 1355 	clr	a
      008B1C 3A               [12] 1356 	addc	a, r2
      008B1D FC               [12] 1357 	mov	r4,a
      008B1E                       1358 00108$:
      008B1E 74 C0            [12] 1359 	mov	a,#0xc0
      008B20 2B               [12] 1360 	add	a, r3
      008B21 FB               [12] 1361 	mov	r3,a
      008B22 74 06            [12] 1362 	mov	a,#0x06
      008B24 3C               [12] 1363 	addc	a, r4
      008B25 FC               [12] 1364 	mov	r4,a
      008B26 90 05 95         [24] 1365 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008B29 EB               [12] 1366 	mov	a,r3
      008B2A F0               [24] 1367 	movx	@dptr,a
      008B2B EC               [12] 1368 	mov	a,r4
      008B2C 12 38 4A         [24] 1369 	lcall	_ak820_outline_0077
      008B2F 90 05 98         [24] 1370 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008B32 74 0A            [12] 1371 	mov	a,#0x0a
      008B34 F0               [24] 1372 	movx	@dptr,a
      008B35 E4               [12] 1373 	clr	a
      008B36 A3               [24] 1374 	inc	dptr
      008B37 12 43 46         [24] 1375 	lcall	_ak820_outline_0071
      008B3A 12 42 26         [24] 1376 	lcall	_ak820_eeprom_update_block_xdata
                                   1377 ;	quantum/dynamic_keymap.c:280: ak820_nvm_flush();
      008B3D 12 3E 31         [24] 1378 	lcall	_ak820_nvm_flush
                                   1379 ;	quantum/dynamic_keymap.c:281: return ak820_nvm_ok() ? 0 : -1;
      008B40 12 3E 22         [24] 1380 	lcall	_ak820_nvm_ok
      008B43 E5 82            [12] 1381 	mov	a, dpl
      008B45 60 06            [24] 1382 	jz	00109$
      008B47 7E 00            [12] 1383 	mov	r6,#0x00
      008B49 7F 00            [12] 1384 	mov	r7,#0x00
      008B4B 80 04            [24] 1385 	sjmp	00110$
      008B4D                       1386 00109$:
      008B4D 7E FF            [12] 1387 	mov	r6,#0xff
      008B4F 7F FF            [12] 1388 	mov	r7,#0xff
      008B51                       1389 00110$:
      008B51 12 38 92         [24] 1390 	lcall	_ak820_outline_0124
                                   1391 ;	quantum/dynamic_keymap.c:282: }
      008B54 22               [24] 1392 	ret
                                   1393 ;------------------------------------------------------------
                                   1394 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1395 ;------------------------------------------------------------
                                   1396 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1397 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1398 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_398'
                                   1399 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_399'
                                   1400 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_401'
                                   1401 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_402'
                                   1402 ;------------------------------------------------------------
                                   1403 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1404 ;	-----------------------------------------
                                   1405 ;	 function dynamic_keymap_get_combo
                                   1406 ;	-----------------------------------------
      008B55                       1407 _dynamic_keymap_get_combo:
      008B55 E5 82            [12] 1408 	mov	a,dpl
      008B57 90 0B BE         [24] 1409 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008B5A F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B5B 90 0B BB         [24] 1412 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008B5E 12 38 2D         [24] 1413 	lcall	_ak820_outline_0058
                                   1414 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008B61 90 0B BE         [24] 1415 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008B64 E0               [24] 1416 	movx	a,@dptr
      008B65 FD               [12] 1417 	mov	r5,a
      008B66 BD 08 00         [24] 1418 	cjne	r5,#0x08,00132$
      008B69                       1419 00132$:
      008B69 40 04            [24] 1420 	jc	00102$
                                   1421 ;	quantum/dynamic_keymap.c:315: return -1;
      008B6B 90 FF FF         [24] 1422 	mov	dptr,#0xffff
      008B6E 22               [24] 1423 	ret
      008B6F                       1424 00102$:
                                   1425 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B6F 12 94 44         [24] 1426 	lcall	_ak820_outline_0087
                                   1427 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008B72 8E 02            [24] 1428 	mov	ar2,r6
      008B74 8F 03            [24] 1429 	mov	ar3,r7
      008B76 90 05 85         [24] 1430 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008B79 EC               [12] 1431 	mov	a,r4
      008B7A F0               [24] 1432 	movx	@dptr,a
      008B7B ED               [12] 1433 	mov	a,r5
      008B7C 12 38 4A         [24] 1434 	lcall	_ak820_outline_0077
      008B7F 90 05 88         [24] 1435 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008B82 12 94 65         [24] 1436 	lcall	_ak820_outline_0115
      008B85 12 38 AD         [24] 1437 	lcall	_ak820_outline_0134
      008B88 C0 07            [24] 1438 	push	ar7
      008B8A C0 06            [24] 1439 	push	ar6
      008B8C 12 40 B7         [24] 1440 	lcall	_ak820_eeprom_read_block_xdata
      008B8F D0 06            [24] 1441 	pop	ar6
      008B91 D0 07            [24] 1442 	pop	ar7
                                   1443 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008B93 74 04            [12] 1444 	mov	a,#0x04
      008B95 12 48 AC         [24] 1445 	lcall	_ak820_outline_0013
      008B98 FA               [12] 1446 	mov	r2,a
      008B99 A3               [24] 1447 	inc	dptr
      008B9A E0               [24] 1448 	movx	a,@dptr
      008B9B FB               [12] 1449 	mov	r3,a
      008B9C BA 20 13         [24] 1450 	cjne	r2,#0x20,00108$
      008B9F BB 08 10         [24] 1451 	cjne	r3,#0x08,00108$
      008BA2 74 06            [12] 1452 	mov	a,#0x06
      008BA4 12 38 1D         [24] 1453 	lcall	_ak820_outline_0026
      008BA7 12 43 4C         [24] 1454 	lcall	_ak820_outline_0083
      008BAA BA 01 05         [24] 1455 	cjne	r2,#0x01,00136$
      008BAD BB 00 02         [24] 1456 	cjne	r3,#0x00,00136$
      008BB0 80 05            [24] 1457 	sjmp	00109$
      008BB2                       1458 00136$:
      008BB2                       1459 00108$:
      008BB2 75 33 00         [24] 1460 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008BB5 80 03            [24] 1461 	sjmp	00110$
      008BB7                       1462 00109$:
      008BB7 75 33 01         [24] 1463 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008BBA                       1464 00110$:
                                   1465 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008BBA 74 06            [12] 1466 	mov	a,#0x06
      008BBC 12 38 1D         [24] 1467 	lcall	_ak820_outline_0026
      008BBF E4               [12] 1468 	clr	a
      008BC0 F0               [24] 1469 	movx	@dptr,a
      008BC1 A3               [24] 1470 	inc	dptr
      008BC2 12 38 75         [24] 1471 	lcall	_ak820_outline_0106
      008BC5 F0               [24] 1472 	movx	@dptr,a
      008BC6 A3               [24] 1473 	inc	dptr
      008BC7 F0               [24] 1474 	movx	@dptr,a
                                   1475 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008BC8 E5 33            [12] 1476 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008BCA 60 12            [24] 1477 	jz	00103$
      008BCC 12 38 92         [24] 1478 	lcall	_ak820_outline_0124
      008BCF C0 07            [24] 1479 	push	ar7
      008BD1 C0 06            [24] 1480 	push	ar6
      008BD3 12 34 D0         [24] 1481 	lcall	_ak820_combo_valid
      008BD6 E5 82            [12] 1482 	mov	a, dpl
      008BD8 D0 06            [24] 1483 	pop	ar6
      008BDA D0 07            [24] 1484 	pop	ar7
      008BDC 70 08            [24] 1485 	jnz	00104$
      008BDE                       1486 00103$:
      008BDE 7D 00            [12] 1487 	mov	r5,#0x00
      008BE0 12 94 2F         [24] 1488 	lcall	_ak820_outline_0043
      008BE3 12 BF 04         [24] 1489 	lcall	_memset
      008BE6                       1490 00104$:
                                   1491 ;	quantum/dynamic_keymap.c:329: return 0;
      008BE6 90 00 00         [24] 1492 	mov	dptr,#0x0000
                                   1493 ;	quantum/dynamic_keymap.c:330: }
      008BE9 22               [24] 1494 	ret
                                   1495 ;------------------------------------------------------------
                                   1496 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1497 ;------------------------------------------------------------
                                   1498 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1499 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_404'
                                   1500 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_405'
                                   1501 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_408'
                                   1502 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_409'
                                   1503 ;------------------------------------------------------------
                                   1504 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1505 ;	-----------------------------------------
                                   1506 ;	 function dynamic_keymap_set_combo
                                   1507 ;	-----------------------------------------
      008BEA                       1508 _dynamic_keymap_set_combo:
      008BEA E5 82            [12] 1509 	mov	a,dpl
      008BEC 90 0B C2         [24] 1510 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008BEF F0               [24] 1511 	movx	@dptr,a
                                   1512 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008BF0 90 0B BF         [24] 1513 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008BF3 12 37 ED         [24] 1514 	lcall	_ak820_outline_0006
                                   1515 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008BF6 C0 07            [24] 1516 	push	ar7
      008BF8 C0 06            [24] 1517 	push	ar6
      008BFA 12 34 D0         [24] 1518 	lcall	_ak820_combo_valid
      008BFD E5 82            [12] 1519 	mov	a, dpl
      008BFF D0 06            [24] 1520 	pop	ar6
      008C01 D0 07            [24] 1521 	pop	ar7
      008C03 60 07            [24] 1522 	jz	00101$
      008C05 12 3E 22         [24] 1523 	lcall	_ak820_nvm_ok
      008C08 E5 82            [12] 1524 	mov	a, dpl
      008C0A 70 04            [24] 1525 	jnz	00102$
      008C0C                       1526 00101$:
      008C0C 90 FF FF         [24] 1527 	mov	dptr,#0xffff
      008C0F 22               [24] 1528 	ret
      008C10                       1529 00102$:
                                   1530 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008C10 90 0B C2         [24] 1531 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008C13 E0               [24] 1532 	movx	a,@dptr
      008C14 FD               [12] 1533 	mov	r5,a
      008C15 BD 08 00         [24] 1534 	cjne	r5,#0x08,00133$
      008C18                       1535 00133$:
      008C18 40 04            [24] 1536 	jc	00105$
                                   1537 ;	quantum/dynamic_keymap.c:342: return -1;
      008C1A 90 FF FF         [24] 1538 	mov	dptr,#0xffff
      008C1D 22               [24] 1539 	ret
      008C1E                       1540 00105$:
                                   1541 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008C1E 12 94 44         [24] 1542 	lcall	_ak820_outline_0087
                                   1543 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008C21 C0 07            [24] 1544 	push	ar7
      008C23 C0 06            [24] 1545 	push	ar6
      008C25 C0 05            [24] 1546 	push	ar5
      008C27 C0 04            [24] 1547 	push	ar4
      008C29 12 7B 8A         [24] 1548 	lcall	_clear_keyboard
      008C2C D0 04            [24] 1549 	pop	ar4
      008C2E D0 05            [24] 1550 	pop	ar5
      008C30 D0 06            [24] 1551 	pop	ar6
      008C32 D0 07            [24] 1552 	pop	ar7
                                   1553 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008C34 90 0E 8C         [24] 1554 	mov	dptr,#___memcpy_PARM_2
      008C37 12 49 1A         [24] 1555 	lcall	_ak820_outline_0064
      008C3A E4               [12] 1556 	clr	a
      008C3B A3               [24] 1557 	inc	dptr
      008C3C F0               [24] 1558 	movx	@dptr,a
      008C3D 90 0E 8F         [24] 1559 	mov	dptr,#___memcpy_PARM_3
      008C40 12 94 65         [24] 1560 	lcall	_ak820_outline_0115
      008C43 90 0B C3         [24] 1561 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008C46 F5 F0            [12] 1562 	mov	b,a
      008C48 C0 05            [24] 1563 	push	ar5
      008C4A C0 04            [24] 1564 	push	ar4
      008C4C 12 BE 8E         [24] 1565 	lcall	___memcpy
      008C4F D0 04            [24] 1566 	pop	ar4
      008C51 D0 05            [24] 1567 	pop	ar5
                                   1568 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008C53 90 0B C7         [24] 1569 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0004)
      008C56 74 20            [12] 1570 	mov	a,#0x20
      008C58 F0               [24] 1571 	movx	@dptr,a
      008C59 74 08            [12] 1572 	mov	a,#0x08
      008C5B A3               [24] 1573 	inc	dptr
      008C5C F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008C5D 90 0B C9         [24] 1576 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0006)
      008C60 74 01            [12] 1577 	mov	a,#0x01
      008C62 12 38 A8         [24] 1578 	lcall	_ak820_outline_0133
                                   1579 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008C65 90 05 8E         [24] 1580 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008C68 EC               [12] 1581 	mov	a,r4
      008C69 F0               [24] 1582 	movx	@dptr,a
      008C6A ED               [12] 1583 	mov	a,r5
      008C6B 12 38 4A         [24] 1584 	lcall	_ak820_outline_0077
      008C6E 90 05 91         [24] 1585 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008C71 12 94 65         [24] 1586 	lcall	_ak820_outline_0115
      008C74 90 0B C3         [24] 1587 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008C77 12 41 43         [24] 1588 	lcall	_ak820_eeprom_write_block_xdata
                                   1589 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008C7A 12 3E 31         [24] 1590 	lcall	_ak820_nvm_flush
                                   1591 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008C7D 12 3E 22         [24] 1592 	lcall	_ak820_nvm_ok
      008C80 E5 82            [12] 1593 	mov	a, dpl
      008C82 70 04            [24] 1594 	jnz	00107$
      008C84 90 FF FF         [24] 1595 	mov	dptr,#0xffff
      008C87 22               [24] 1596 	ret
      008C88                       1597 00107$:
                                   1598 ;	quantum/dynamic_keymap.c:360: return 0;
      008C88 90 00 00         [24] 1599 	mov	dptr,#0x0000
                                   1600 ;	quantum/dynamic_keymap.c:361: }
      008C8B 22               [24] 1601 	ret
                                   1602 ;------------------------------------------------------------
                                   1603 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1604 ;------------------------------------------------------------
                                   1605 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_412'
                                   1606 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_413'
                                   1607 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_415'
                                   1608 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_417'
                                   1609 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_419'
                                   1610 ;td            Allocated with name '_dynamic_keymap_reset_td_10001_421'
                                   1611 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_422'
                                   1612 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10002_424'
                                   1613 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_425'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function dynamic_keymap_reset
                                   1618 ;	-----------------------------------------
      008C8C                       1619 _dynamic_keymap_reset:
                                   1620 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008C8C 90 0F 0C         [24] 1621 	mov	dptr,#_vial_unlocked
      008C8F E0               [24] 1622 	movx	a,@dptr
      008C90 90 0B CD         [24] 1623 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008C93 F0               [24] 1624 	movx	@dptr,a
                                   1625 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008C94 90 0F 0C         [24] 1626 	mov	dptr,#_vial_unlocked
      008C97 74 01            [12] 1627 	mov	a,#0x01
      008C99 F0               [24] 1628 	movx	@dptr,a
                                   1629 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008C9A 7F 00            [12] 1630 	mov	r7,#0x00
      008C9C                       1631 00117$:
      008C9C BF 06 00         [24] 1632 	cjne	r7,#0x06,00217$
      008C9F                       1633 00217$:
      008C9F 40 02            [24] 1634 	jc	00218$
      008CA1 A1 4A            [12] 1635 	ajmp	00104$
      008CA3                       1636 00218$:
                                   1637 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008CA3 7E 00            [12] 1638 	mov	r6,#0x00
      008CA5                       1639 00111$:
      008CA5 BE 10 00         [24] 1640 	cjne	r6,#0x10,00219$
      008CA8                       1641 00219$:
      008CA8 50 4C            [24] 1642 	jnc	00102$
                                   1643 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008CAA 7D 00            [12] 1644 	mov	r5,#0x00
      008CAC                       1645 00108$:
      008CAC BD 08 00         [24] 1646 	cjne	r5,#0x08,00221$
      008CAF                       1647 00221$:
      008CAF 50 42            [24] 1648 	jnc	00112$
                                   1649 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008CB1 90 0C 73         [24] 1650 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008CB4 EE               [12] 1651 	mov	a,r6
      008CB5 F0               [24] 1652 	movx	@dptr,a
      008CB6 90 0C 74         [24] 1653 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008CB9 ED               [12] 1654 	mov	a,r5
      008CBA F0               [24] 1655 	movx	@dptr,a
      008CBB 8F 82            [24] 1656 	mov	dpl, r7
      008CBD C0 07            [24] 1657 	push	ar7
      008CBF C0 06            [24] 1658 	push	ar6
      008CC1 C0 05            [24] 1659 	push	ar5
      008CC3 12 9C 77         [24] 1660 	lcall	_keycode_at_keymap_location_raw
      008CC6 AB 82            [24] 1661 	mov	r3, dpl
      008CC8 AC 83            [24] 1662 	mov	r4, dph
      008CCA D0 05            [24] 1663 	pop	ar5
      008CCC D0 06            [24] 1664 	pop	ar6
      008CCE D0 07            [24] 1665 	pop	ar7
      008CD0 90 0B A4         [24] 1666 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008CD3 EE               [12] 1667 	mov	a,r6
      008CD4 F0               [24] 1668 	movx	@dptr,a
      008CD5 90 0B A5         [24] 1669 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008CD8 ED               [12] 1670 	mov	a,r5
      008CD9 F0               [24] 1671 	movx	@dptr,a
      008CDA 90 0B A6         [24] 1672 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008CDD 12 38 56         [24] 1673 	lcall	_ak820_outline_0084
      008CE0 8F 82            [24] 1674 	mov	dpl, r7
      008CE2 C0 07            [24] 1675 	push	ar7
      008CE4 C0 06            [24] 1676 	push	ar6
      008CE6 C0 05            [24] 1677 	push	ar5
      008CE8 11 F4            [12] 1678 	acall	_dynamic_keymap_set_keycode
      008CEA D0 05            [24] 1679 	pop	ar5
      008CEC D0 06            [24] 1680 	pop	ar6
      008CEE D0 07            [24] 1681 	pop	ar7
                                   1682 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008CF0 0D               [12] 1683 	inc	r5
      008CF1 80 B9            [24] 1684 	sjmp	00108$
      008CF3                       1685 00112$:
                                   1686 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008CF3 0E               [12] 1687 	inc	r6
      008CF4 80 AF            [24] 1688 	sjmp	00111$
      008CF6                       1689 00102$:
                                   1690 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008CF6 7E 00            [12] 1691 	mov	r6,#0x00
      008CF8                       1692 00114$:
      008CF8 BE 01 00         [24] 1693 	cjne	r6,#0x01,00223$
      008CFB                       1694 00223$:
      008CFB 50 4A            [24] 1695 	jnc	00118$
                                   1696 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008CFD 12 94 9A         [24] 1697 	lcall	_ak820_outline_0186
      008D00 04               [12] 1698 	inc	a
      008D01 F0               [24] 1699 	movx	@dptr,a
      008D02 8F 82            [24] 1700 	mov	dpl, r7
      008D04 C0 07            [24] 1701 	push	ar7
      008D06 12 9C BC         [24] 1702 	lcall	_keycode_at_encodermap_location_raw
      008D09 12 43 6F         [24] 1703 	lcall	_ak820_outline_0156
      008D0C D0 07            [24] 1704 	pop	ar7
      008D0E 12 94 91         [24] 1705 	lcall	_ak820_outline_0185
      008D11 04               [12] 1706 	inc	a
      008D12 F0               [24] 1707 	movx	@dptr,a
      008D13 90 0B B0         [24] 1708 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008D16 12 38 50         [24] 1709 	lcall	_ak820_outline_0078
      008D19 8F 82            [24] 1710 	mov	dpl, r7
      008D1B C0 07            [24] 1711 	push	ar7
      008D1D 31 C9            [24] 1712 	acall	_dynamic_keymap_set_encoder
      008D1F D0 07            [24] 1713 	pop	ar7
                                   1714 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008D21 12 94 9A         [24] 1715 	lcall	_ak820_outline_0186
      008D24 F0               [24] 1716 	movx	@dptr,a
      008D25 8F 82            [24] 1717 	mov	dpl, r7
      008D27 C0 07            [24] 1718 	push	ar7
      008D29 12 9C BC         [24] 1719 	lcall	_keycode_at_encodermap_location_raw
      008D2C 12 43 6F         [24] 1720 	lcall	_ak820_outline_0156
      008D2F D0 07            [24] 1721 	pop	ar7
      008D31 12 94 91         [24] 1722 	lcall	_ak820_outline_0185
      008D34 F0               [24] 1723 	movx	@dptr,a
      008D35 90 0B B0         [24] 1724 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008D38 12 38 50         [24] 1725 	lcall	_ak820_outline_0078
      008D3B 8F 82            [24] 1726 	mov	dpl, r7
      008D3D C0 07            [24] 1727 	push	ar7
      008D3F 31 C9            [24] 1728 	acall	_dynamic_keymap_set_encoder
      008D41 D0 07            [24] 1729 	pop	ar7
                                   1730 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008D43 7E 01            [12] 1731 	mov	r6,#0x01
      008D45 80 B1            [24] 1732 	sjmp	00114$
      008D47                       1733 00118$:
                                   1734 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008D47 0F               [12] 1735 	inc	r7
      008D48 81 9C            [12] 1736 	ajmp	00117$
      008D4A                       1737 00104$:
                                   1738 ;	quantum/dynamic_keymap.c:442: vial_tap_dance_entry_t td = { KC_NO, KC_NO, KC_NO, KC_NO, TAPPING_TERM };
      008D4A 90 0B CE         [24] 1739 	mov	dptr,#_dynamic_keymap_reset_td_10001_421
      008D4D 12 49 28         [24] 1740 	lcall	_ak820_outline_0150
      008D50 90 0B D0         [24] 1741 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0002)
      008D53 F0               [24] 1742 	movx	@dptr,a
      008D54 A3               [24] 1743 	inc	dptr
      008D55 F0               [24] 1744 	movx	@dptr,a
      008D56 90 0B D2         [24] 1745 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0004)
      008D59 F0               [24] 1746 	movx	@dptr,a
      008D5A A3               [24] 1747 	inc	dptr
      008D5B F0               [24] 1748 	movx	@dptr,a
      008D5C 90 0B D4         [24] 1749 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0006)
      008D5F F0               [24] 1750 	movx	@dptr,a
      008D60 A3               [24] 1751 	inc	dptr
      008D61 F0               [24] 1752 	movx	@dptr,a
      008D62 90 0B D6         [24] 1753 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0008)
      008D65 74 C8            [12] 1754 	mov	a,#0xc8
      008D67 12 38 A8         [24] 1755 	lcall	_ak820_outline_0133
                                   1756 ;	quantum/dynamic_keymap.c:443: for (size_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008D6A FF               [12] 1757 	mov	r7,a
      008D6B                       1758 00120$:
      008D6B BF 08 00         [24] 1759 	cjne	r7,#0x08,00225$
      008D6E                       1760 00225$:
      008D6E 50 18            [24] 1761 	jnc	00105$
                                   1762 ;	quantum/dynamic_keymap.c:444: dynamic_keymap_set_tap_dance(i, &td);
      008D70 8F 06            [24] 1763 	mov	ar6,r7
      008D72 90 0B B7         [24] 1764 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      008D75 74 CE            [12] 1765 	mov	a,#_dynamic_keymap_reset_td_10001_421
      008D77 F0               [24] 1766 	movx	@dptr,a
      008D78 74 0B            [12] 1767 	mov	a,#(_dynamic_keymap_reset_td_10001_421 >> 8)
      008D7A 12 38 4A         [24] 1768 	lcall	_ak820_outline_0077
      008D7D 8E 82            [24] 1769 	mov	dpl, r6
      008D7F C0 07            [24] 1770 	push	ar7
      008D81 51 B6            [24] 1771 	acall	_dynamic_keymap_set_tap_dance
      008D83 D0 07            [24] 1772 	pop	ar7
                                   1773 ;	quantum/dynamic_keymap.c:443: for (size_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008D85 0F               [12] 1774 	inc	r7
      008D86 80 E3            [24] 1775 	sjmp	00120$
      008D88                       1776 00105$:
                                   1777 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008D88 90 0B D8         [24] 1778 	mov	dptr,#_dynamic_keymap_reset_combo_10002_424
      008D8B 12 49 28         [24] 1779 	lcall	_ak820_outline_0150
      008D8E 90 0B DA         [24] 1780 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0002)
      008D91 F0               [24] 1781 	movx	@dptr,a
      008D92 A3               [24] 1782 	inc	dptr
      008D93 F0               [24] 1783 	movx	@dptr,a
      008D94 90 0B DC         [24] 1784 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0004)
      008D97 F0               [24] 1785 	movx	@dptr,a
      008D98 A3               [24] 1786 	inc	dptr
      008D99 F0               [24] 1787 	movx	@dptr,a
      008D9A 90 0B DE         [24] 1788 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0006)
      008D9D F0               [24] 1789 	movx	@dptr,a
      008D9E A3               [24] 1790 	inc	dptr
      008D9F F0               [24] 1791 	movx	@dptr,a
      008DA0 90 0B E0         [24] 1792 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0008)
      008DA3 F0               [24] 1793 	movx	@dptr,a
      008DA4 A3               [24] 1794 	inc	dptr
      008DA5 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008DA6 FF               [12] 1797 	mov	r7,a
      008DA7                       1798 00123$:
      008DA7 BF 08 00         [24] 1799 	cjne	r7,#0x08,00227$
      008DAA                       1800 00227$:
      008DAA 50 18            [24] 1801 	jnc	00106$
                                   1802 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008DAC 8F 06            [24] 1803 	mov	ar6,r7
      008DAE 90 0B BF         [24] 1804 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008DB1 74 D8            [12] 1805 	mov	a,#_dynamic_keymap_reset_combo_10002_424
      008DB3 F0               [24] 1806 	movx	@dptr,a
      008DB4 74 0B            [12] 1807 	mov	a,#(_dynamic_keymap_reset_combo_10002_424 >> 8)
      008DB6 12 38 4A         [24] 1808 	lcall	_ak820_outline_0077
      008DB9 8E 82            [24] 1809 	mov	dpl, r6
      008DBB C0 07            [24] 1810 	push	ar7
      008DBD 71 EA            [12] 1811 	acall	_dynamic_keymap_set_combo
      008DBF D0 07            [24] 1812 	pop	ar7
                                   1813 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008DC1 0F               [12] 1814 	inc	r7
      008DC2 80 E3            [24] 1815 	sjmp	00123$
      008DC4                       1816 00106$:
                                   1817 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008DC4 90 0B CD         [24] 1818 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008DC7 E0               [24] 1819 	movx	a,@dptr
      008DC8 90 0F 0C         [24] 1820 	mov	dptr,#_vial_unlocked
      008DCB F0               [24] 1821 	movx	@dptr,a
                                   1822 ;	quantum/dynamic_keymap.c:468: }
      008DCC 22               [24] 1823 	ret
                                   1824 ;------------------------------------------------------------
                                   1825 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1826 ;------------------------------------------------------------
                                   1827 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1828 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1829 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1830 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1831 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1832 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_426'
                                   1833 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_427'
                                   1834 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_427'
                                   1835 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_430'
                                   1836 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_432'
                                   1837 ;------------------------------------------------------------
                                   1838 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1839 ;	-----------------------------------------
                                   1840 ;	 function ak820_dynamic_read_buffer
                                   1841 ;	-----------------------------------------
      008DCD                       1842 _ak820_dynamic_read_buffer:
      008DCD 12 38 81         [24] 1843 	lcall	_ak820_outline_0111
      008DD0 90 0B EB         [24] 1844 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008DD3 12 38 86         [24] 1845 	lcall	_ak820_outline_0112
                                   1846 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008DD6 90 0B E8         [24] 1847 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008DD9 12 38 2D         [24] 1848 	lcall	_ak820_outline_0058
                                   1849 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008DDC 90 0B ED         [24] 1850 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008DDF E4               [12] 1851 	clr	a
      008DE0 F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008DE1 90 0B E6         [24] 1854 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008DE4 12 38 44         [24] 1855 	lcall	_ak820_outline_0065
      008DE7 8C 02            [24] 1856 	mov	ar2,r4
      008DE9 8D 03            [24] 1857 	mov	ar3,r5
      008DEB C3               [12] 1858 	clr	c
      008DEC 74 1C            [12] 1859 	mov	a,#0x1c
      008DEE 9A               [12] 1860 	subb	a,r2
      008DEF E4               [12] 1861 	clr	a
      008DF0 9B               [12] 1862 	subb	a,r3
      008DF1 50 01            [24] 1863 	jnc	00102$
                                   1864 ;	free result
      008DF3 22               [24] 1865 	ret
      008DF4                       1866 00102$:
                                   1867 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008DF4 90 0B E4         [24] 1868 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008DF7 12 43 4C         [24] 1869 	lcall	_ak820_outline_0083
      008DFA 90 0B E2         [24] 1870 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008DFD 12 38 6F         [24] 1871 	lcall	_ak820_outline_0104
      008E00 C3               [12] 1872 	clr	c
      008E01 EA               [12] 1873 	mov	a,r2
      008E02 98               [12] 1874 	subb	a,r0
      008E03 EB               [12] 1875 	mov	a,r3
      008E04 99               [12] 1876 	subb	a,r1
      008E05 50 17            [24] 1877 	jnc	00104$
                                   1878 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008E07 E8               [12] 1879 	mov	a,r0
      008E08 C3               [12] 1880 	clr	c
      008E09 9A               [12] 1881 	subb	a,r2
      008E0A F8               [12] 1882 	mov	r0,a
      008E0B E9               [12] 1883 	mov	a,r1
      008E0C 9B               [12] 1884 	subb	a,r3
      008E0D F9               [12] 1885 	mov	r1,a
                                   1886 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008E0E C3               [12] 1887 	clr	c
      008E0F E8               [12] 1888 	mov	a,r0
      008E10 9C               [12] 1889 	subb	a,r4
      008E11 E9               [12] 1890 	mov	a,r1
      008E12 9D               [12] 1891 	subb	a,r5
      008E13 40 04            [24] 1892 	jc	00114$
      008E15 8C 00            [24] 1893 	mov	ar0,r4
      008E17 8D 01            [24] 1894 	mov	ar1,r5
      008E19                       1895 00114$:
      008E19 90 0B ED         [24] 1896 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008E1C E8               [12] 1897 	mov	a,r0
      008E1D F0               [24] 1898 	movx	@dptr,a
      008E1E                       1899 00104$:
                                   1900 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008E1E 90 0B ED         [24] 1901 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008E21 E0               [24] 1902 	movx	a,@dptr
      008E22 F5 34            [12] 1903 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008E24 E0               [24] 1904 	movx	a,@dptr
      008E25 60 42            [24] 1905 	jz	00106$
      008E27 C0 04            [24] 1906 	push	ar4
      008E29 C0 05            [24] 1907 	push	ar5
      008E2B 8E 00            [24] 1908 	mov	ar0,r6
      008E2D 8F 05            [24] 1909 	mov	ar5,r7
      008E2F 90 0B EB         [24] 1910 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008E32 E0               [24] 1911 	movx	a,@dptr
      008E33 F9               [12] 1912 	mov	r1,a
      008E34 A3               [24] 1913 	inc	dptr
      008E35 E0               [24] 1914 	movx	a,@dptr
      008E36 FC               [12] 1915 	mov	r4,a
      008E37 EA               [12] 1916 	mov	a,r2
      008E38 29               [12] 1917 	add	a, r1
      008E39 FA               [12] 1918 	mov	r2,a
      008E3A EB               [12] 1919 	mov	a,r3
      008E3B 3C               [12] 1920 	addc	a, r4
      008E3C FB               [12] 1921 	mov	r3,a
      008E3D 90 05 85         [24] 1922 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008E40 EA               [12] 1923 	mov	a,r2
      008E41 F0               [24] 1924 	movx	@dptr,a
      008E42 EB               [12] 1925 	mov	a,r3
      008E43 12 38 4A         [24] 1926 	lcall	_ak820_outline_0077
      008E46 90 05 88         [24] 1927 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008E49 E5 34            [12] 1928 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008E4B 12 38 A8         [24] 1929 	lcall	_ak820_outline_0133
      008E4E 88 82            [24] 1930 	mov	dpl, r0
      008E50 8D 83            [24] 1931 	mov	dph, r5
      008E52 C0 07            [24] 1932 	push	ar7
      008E54 C0 06            [24] 1933 	push	ar6
      008E56 C0 05            [24] 1934 	push	ar5
      008E58 C0 04            [24] 1935 	push	ar4
      008E5A 12 40 B7         [24] 1936 	lcall	_ak820_eeprom_read_block_xdata
      008E5D D0 04            [24] 1937 	pop	ar4
      008E5F D0 05            [24] 1938 	pop	ar5
      008E61 D0 06            [24] 1939 	pop	ar6
      008E63 D0 07            [24] 1940 	pop	ar7
                                   1941 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008E65 D0 05            [24] 1942 	pop	ar5
      008E67 D0 04            [24] 1943 	pop	ar4
                                   1944 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008E69                       1945 00106$:
                                   1946 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008E69 90 0B ED         [24] 1947 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008E6C E0               [24] 1948 	movx	a,@dptr
      008E6D FB               [12] 1949 	mov	r3,a
      008E6E                       1950 00109$:
      008E6E 8B 01            [24] 1951 	mov	ar1,r3
      008E70 7A 00            [12] 1952 	mov	r2,#0x00
      008E72 C3               [12] 1953 	clr	c
      008E73 E9               [12] 1954 	mov	a,r1
      008E74 9C               [12] 1955 	subb	a,r4
      008E75 EA               [12] 1956 	mov	a,r2
      008E76 9D               [12] 1957 	subb	a,r5
      008E77 50 09            [24] 1958 	jnc	00111$
      008E79 EB               [12] 1959 	mov	a,r3
      008E7A 12 38 1D         [24] 1960 	lcall	_ak820_outline_0026
      008E7D E4               [12] 1961 	clr	a
      008E7E F0               [24] 1962 	movx	@dptr,a
      008E7F 0B               [12] 1963 	inc	r3
      008E80 80 EC            [24] 1964 	sjmp	00109$
      008E82                       1965 00111$:
                                   1966 ;	quantum/dynamic_keymap.c:483: }
      008E82 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1970 ;------------------------------------------------------------
                                   1971 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1972 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1973 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_433'
                                   1974 ;------------------------------------------------------------
                                   1975 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1976 ;	-----------------------------------------
                                   1977 ;	 function dynamic_keymap_get_buffer
                                   1978 ;	-----------------------------------------
      008E83                       1979 _dynamic_keymap_get_buffer:
      008E83 12 38 81         [24] 1980 	lcall	_ak820_outline_0111
      008E86 90 0B F3         [24] 1981 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008E89 12 38 86         [24] 1982 	lcall	_ak820_outline_0112
                                   1983 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008E8C 90 0B F3         [24] 1984 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008E8F 12 38 2D         [24] 1985 	lcall	_ak820_outline_0058
      008E92 90 0B EE         [24] 1986 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008E95 12 38 44         [24] 1987 	lcall	_ak820_outline_0065
      008E98 90 0B F0         [24] 1988 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008E9B E0               [24] 1989 	movx	a,@dptr
      008E9C F9               [12] 1990 	mov	r1,a
      008E9D A3               [24] 1991 	inc	dptr
      008E9E 12 43 4C         [24] 1992 	lcall	_ak820_outline_0083
      008EA1 90 0B E2         [24] 1993 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008EA4 E4               [12] 1994 	clr	a
      008EA5 F0               [24] 1995 	movx	@dptr,a
      008EA6 74 06            [12] 1996 	mov	a,#0x06
      008EA8 A3               [24] 1997 	inc	dptr
      008EA9 F0               [24] 1998 	movx	@dptr,a
      008EAA 90 0B E4         [24] 1999 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008EAD 12 49 1A         [24] 2000 	lcall	_ak820_outline_0064
      008EB0 90 0B E6         [24] 2001 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008EB3 12 38 50         [24] 2002 	lcall	_ak820_outline_0078
      008EB6 90 0B E8         [24] 2003 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008EB9 12 4E 27         [24] 2004 	lcall	_ak820_outline_0102
      008EBC EB               [12] 2005 	mov	a,r3
      008EBD A3               [24] 2006 	inc	dptr
      008EBE F0               [24] 2007 	movx	@dptr,a
      008EBF 90 00 40         [24] 2008 	mov	dptr,#0x0040
                                   2009 ;	quantum/dynamic_keymap.c:511: }
      008EC2 A1 CD            [12] 2010 	ajmp	_ak820_dynamic_read_buffer
                                   2011 ;------------------------------------------------------------
                                   2012 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2013 ;------------------------------------------------------------
                                   2014 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2015 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2016 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2017 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2018 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2019 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_435'
                                   2020 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_436'
                                   2021 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_436'
                                   2022 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_436'
                                   2023 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_439'
                                   2024 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_442'
                                   2025 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_442'
                                   2026 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_444'
                                   2027 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_447'
                                   2028 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_449'
                                   2029 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_450'
                                   2030 ;------------------------------------------------------------
                                   2031 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2032 ;	-----------------------------------------
                                   2033 ;	 function dynamic_keymap_set_buffer
                                   2034 ;	-----------------------------------------
      008EC4                       2035 _dynamic_keymap_set_buffer:
      008EC4 12 38 81         [24] 2036 	lcall	_ak820_outline_0111
      008EC7 90 0B FA         [24] 2037 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008ECA 12 38 86         [24] 2038 	lcall	_ak820_outline_0112
                                   2039 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008ECD 90 0B FA         [24] 2040 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008ED0 12 4D E6         [24] 2041 	lcall	_ak820_outline_0010
      008ED3 74 40            [12] 2042 	mov	a,#0x40
      008ED5 2C               [12] 2043 	add	a, r4
      008ED6 FA               [12] 2044 	mov	r2,a
      008ED7 E4               [12] 2045 	clr	a
      008ED8 3D               [12] 2046 	addc	a, r5
      008ED9 FB               [12] 2047 	mov	r3,a
                                   2048 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008EDA 90 0B F7         [24] 2049 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008EDD 12 38 6F         [24] 2050 	lcall	_ak820_outline_0104
                                   2051 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008EE0 90 0B F5         [24] 2052 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008EE3 E0               [24] 2053 	movx	a,@dptr
      008EE4 F5 35            [12] 2054 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008EE6 A3               [24] 2055 	inc	dptr
      008EE7 E0               [24] 2056 	movx	a,@dptr
      008EE8 F5 36            [12] 2057 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008EEA E5 35            [12] 2058 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008EEC 45 36            [12] 2059 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008EEE 70 01            [24] 2060 	jnz	00102$
      008EF0 22               [24] 2061 	ret
      008EF1                       2062 00102$:
                                   2063 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008EF1 85 35 37         [24] 2064 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008EF4 85 36 38         [24] 2065 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008EF7 C3               [12] 2066 	clr	c
      008EF8 74 1C            [12] 2067 	mov	a,#0x1c
      008EFA 95 37            [12] 2068 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008EFC E4               [12] 2069 	clr	a
      008EFD 95 38            [12] 2070 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008EFF 50 01            [24] 2071 	jnc	00104$
                                   2072 ;	free result
      008F01 22               [24] 2073 	ret
      008F02                       2074 00104$:
                                   2075 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008F02 85 35 39         [24] 2076 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2077 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008F05 74 FA            [12] 2078 	mov	a,#0x100 - 0x06
      008F07 2F               [12] 2079 	add	a,r7
      008F08 40 11            [24] 2080 	jc	00105$
      008F0A E4               [12] 2081 	clr	a
      008F0B C3               [12] 2082 	clr	c
      008F0C 9E               [12] 2083 	subb	a,r6
      008F0D FE               [12] 2084 	mov	r6,a
      008F0E 74 06            [12] 2085 	mov	a,#0x06
      008F10 9F               [12] 2086 	subb	a,r7
      008F11 FF               [12] 2087 	mov	r7,a
      008F12 C3               [12] 2088 	clr	c
      008F13 EE               [12] 2089 	mov	a,r6
      008F14 95 35            [12] 2090 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F16 EF               [12] 2091 	mov	a,r7
      008F17 95 36            [12] 2092 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F19 50 01            [24] 2093 	jnc	00106$
      008F1B                       2094 00105$:
                                   2095 ;	quantum/dynamic_keymap.c:529: return;
      008F1B 22               [24] 2096 	ret
      008F1C                       2097 00106$:
                                   2098 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008F1C 90 0F 0C         [24] 2099 	mov	dptr,#_vial_unlocked
      008F1F E0               [24] 2100 	movx	a,@dptr
      008F20 60 03            [24] 2101 	jz	00207$
      008F22 02 90 2E         [24] 2102 	ljmp	00120$
      008F25                       2103 00207$:
                                   2104 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008F25 90 0B FC         [24] 2105 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008F28 E4               [12] 2106 	clr	a
      008F29 F0               [24] 2107 	movx	@dptr,a
                                   2108 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008F2A 90 0B FD         [24] 2109 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008F2D E5 39            [12] 2110 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F2F F0               [24] 2111 	movx	@dptr,a
                                   2112 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008F30 EC               [12] 2113 	mov	a,r4
      008F31 30 E0 30         [24] 2114 	jnb	acc.0,00111$
                                   2115 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008F34 EA               [12] 2116 	mov	a,r2
      008F35 24 FF            [12] 2117 	add	a,#0xff
      008F37 FE               [12] 2118 	mov	r6,a
      008F38 EB               [12] 2119 	mov	a,r3
      008F39 34 FF            [12] 2120 	addc	a,#0xff
      008F3B FF               [12] 2121 	mov	r7,a
      008F3C 7D 00            [12] 2122 	mov	r5,#0x00
      008F3E 12 7C 21         [24] 2123 	lcall	_ak820_outline_0118
      008F41 12 40 7C         [24] 2124 	lcall	_eeprom_read_byte
      008F44 AE 82            [24] 2125 	mov	r6,dpl
      008F46 7F 00            [12] 2126 	mov	r7,#0x00
      008F48 12 38 9D         [24] 2127 	lcall	_ak820_outline_0129
      008F4B 7C 00            [12] 2128 	mov	r4,#0x00
      008F4D 42 07            [12] 2129 	orl	ar7,a
      008F4F EC               [12] 2130 	mov	a,r4
      008F50 42 06            [12] 2131 	orl	ar6,a
                                   2132 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008F52 BF 00 09         [24] 2133 	cjne	r7,#0x00,00109$
      008F55 BE 7C 06         [24] 2134 	cjne	r6,#0x7c,00109$
                                   2135 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008F58 12 7C 55         [24] 2136 	lcall	_ak820_outline_0196
      008F5B 74 FF            [12] 2137 	mov	a,#0xff
      008F5D F0               [24] 2138 	movx	@dptr,a
      008F5E                       2139 00109$:
                                   2140 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008F5E 90 0B FC         [24] 2141 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008F61 74 01            [12] 2142 	mov	a,#0x01
      008F63 F0               [24] 2143 	movx	@dptr,a
      008F64                       2144 00111$:
                                   2145 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008F64 90 0B FA         [24] 2146 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008F67 12 38 2D         [24] 2147 	lcall	_ak820_outline_0058
      008F6A E5 35            [12] 2148 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F6C 2E               [12] 2149 	add	a, r6
      008F6D FE               [12] 2150 	mov	r6,a
      008F6E E5 36            [12] 2151 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F70 3F               [12] 2152 	addc	a, r7
      008F71 EE               [12] 2153 	mov	a,r6
      008F72 30 E0 5A         [24] 2154 	jnb	acc.0,00115$
                                   2155 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008F75 AE 39            [24] 2156 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008F77 7F 00            [12] 2157 	mov	r7,#0x00
      008F79 EE               [12] 2158 	mov	a,r6
      008F7A 24 FF            [12] 2159 	add	a,#0xff
      008F7C FC               [12] 2160 	mov	r4,a
      008F7D EF               [12] 2161 	mov	a,r7
      008F7E 34 FF            [12] 2162 	addc	a,#0xff
      008F80 FD               [12] 2163 	mov	r5,a
      008F81 EC               [12] 2164 	mov	a,r4
      008F82 28               [12] 2165 	add	a, r0
      008F83 F5 82            [12] 2166 	mov	dpl,a
      008F85 ED               [12] 2167 	mov	a,r5
      008F86 39               [12] 2168 	addc	a, r1
      008F87 F5 83            [12] 2169 	mov	dph,a
      008F89 E0               [24] 2170 	movx	a,@dptr
      008F8A FC               [12] 2171 	mov	r4,a
      008F8B 7D 00            [12] 2172 	mov	r5,#0x00
      008F8D E5 39            [12] 2173 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F8F 2A               [12] 2174 	add	a, r2
      008F90 FA               [12] 2175 	mov	r2,a
      008F91 E4               [12] 2176 	clr	a
      008F92 3B               [12] 2177 	addc	a, r3
      008F93 FB               [12] 2178 	mov	r3,a
      008F94 C0 00            [24] 2179 	push	ar0
      008F96 C0 01            [24] 2180 	push	ar1
      008F98 8B 01            [24] 2181 	mov	ar1,r3
      008F9A 7B 00            [12] 2182 	mov	r3,#0x00
      008F9C 8A 82            [24] 2183 	mov	dpl, r2
      008F9E 89 83            [24] 2184 	mov	dph, r1
      008FA0 8B F0            [24] 2185 	mov	b, r3
      008FA2 12 40 7C         [24] 2186 	lcall	_eeprom_read_byte
      008FA5 AB 82            [24] 2187 	mov	r3, dpl
      008FA7 7A 00            [12] 2188 	mov	r2,#0x00
      008FA9 EB               [12] 2189 	mov	a,r3
      008FAA 12 43 69         [24] 2190 	lcall	_ak820_outline_0149
                                   2191 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008FAD BD 00 05         [24] 2192 	cjne	r5,#0x00,00212$
      008FB0 BC 7C 02         [24] 2193 	cjne	r4,#0x7c,00212$
      008FB3 80 06            [24] 2194 	sjmp	00213$
      008FB5                       2195 00212$:
      008FB5 D0 01            [24] 2196 	pop	ar1
      008FB7 D0 00            [24] 2197 	pop	ar0
      008FB9 80 0D            [24] 2198 	sjmp	00113$
      008FBB                       2199 00213$:
      008FBB D0 01            [24] 2200 	pop	ar1
      008FBD D0 00            [24] 2201 	pop	ar0
                                   2202 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008FBF 1E               [12] 2203 	dec	r6
      008FC0 BE FF 01         [24] 2204 	cjne	r6,#0xff,00214$
      008FC3 1F               [12] 2205 	dec	r7
      008FC4                       2206 00214$:
      008FC4 EE               [12] 2207 	mov	a,r6
      008FC5 12 94 73         [24] 2208 	lcall	_ak820_outline_0138
      008FC8                       2209 00113$:
                                   2210 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008FC8 E5 39            [12] 2211 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008FCA 14               [12] 2212 	dec	a
      008FCB 90 0B FD         [24] 2213 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008FCE F0               [24] 2214 	movx	@dptr,a
      008FCF                       2215 00115$:
                                   2216 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008FCF 90 0B FC         [24] 2217 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008FD2 E0               [24] 2218 	movx	a,@dptr
      008FD3 90 0B FE         [24] 2219 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008FD6 F0               [24] 2220 	movx	@dptr,a
      008FD7                       2221 00122$:
      008FD7 90 0B FE         [24] 2222 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008FDA E0               [24] 2223 	movx	a,@dptr
      008FDB FF               [12] 2224 	mov	r7,a
      008FDC 90 0B FD         [24] 2225 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008FDF E0               [24] 2226 	movx	a,@dptr
      008FE0 FE               [12] 2227 	mov	r6,a
      008FE1 C3               [12] 2228 	clr	c
      008FE2 EF               [12] 2229 	mov	a,r7
      008FE3 9E               [12] 2230 	subb	a,r6
      008FE4 50 48            [24] 2231 	jnc	00120$
                                   2232 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008FE6 EF               [12] 2233 	mov	a,r7
      008FE7 28               [12] 2234 	add	a, r0
      008FE8 FD               [12] 2235 	mov	r5,a
      008FE9 E4               [12] 2236 	clr	a
      008FEA 39               [12] 2237 	addc	a, r1
      008FEB FE               [12] 2238 	mov	r6,a
      008FEC 12 4E 20         [24] 2239 	lcall	_ak820_outline_0081
      008FEF 7B 00            [12] 2240 	mov	r3,#0x00
      008FF1 8C 36            [24] 2241 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008FF3 8B 35            [24] 2242 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008FF5 8F 02            [24] 2243 	mov	ar2,r7
      008FF7 7F 00            [12] 2244 	mov	r7,#0x00
      008FF9 74 01            [12] 2245 	mov	a,#0x01
      008FFB 2A               [12] 2246 	add	a, r2
      008FFC FB               [12] 2247 	mov	r3,a
      008FFD E4               [12] 2248 	clr	a
      008FFE 3F               [12] 2249 	addc	a, r7
      008FFF FC               [12] 2250 	mov	r4,a
      009000 EB               [12] 2251 	mov	a,r3
      009001 28               [12] 2252 	add	a, r0
      009002 F5 82            [12] 2253 	mov	dpl,a
      009004 EC               [12] 2254 	mov	a,r4
      009005 39               [12] 2255 	addc	a, r1
      009006 F5 83            [12] 2256 	mov	dph,a
      009008 E0               [24] 2257 	movx	a,@dptr
      009009 FC               [12] 2258 	mov	r4,a
      00900A 7B 00            [12] 2259 	mov	r3,#0x00
      00900C E5 36            [12] 2260 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00900E 42 03            [12] 2261 	orl	ar3,a
                                   2262 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      009010 BC 00 12         [24] 2263 	cjne	r4,#0x00,00123$
      009013 BB 7C 0F         [24] 2264 	cjne	r3,#0x7c,00123$
                                   2265 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      009016 12 38 B2         [24] 2266 	lcall	_ak820_outline_0143
      009019 74 FF            [12] 2267 	mov	a,#0xff
      00901B F0               [24] 2268 	movx	@dptr,a
                                   2269 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      00901C 0A               [12] 2270 	inc	r2
      00901D BA 00 01         [24] 2271 	cjne	r2,#0x00,00218$
      009020 0F               [12] 2272 	inc	r7
      009021                       2273 00218$:
      009021 EA               [12] 2274 	mov	a,r2
      009022 12 94 73         [24] 2275 	lcall	_ak820_outline_0138
      009025                       2276 00123$:
                                   2277 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009025 90 0B FE         [24] 2278 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      009028 E0               [24] 2279 	movx	a,@dptr
      009029 24 02            [12] 2280 	add	a,#0x02
      00902B F0               [24] 2281 	movx	@dptr,a
      00902C 80 A9            [24] 2282 	sjmp	00122$
      00902E                       2283 00120$:
                                   2284 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      00902E 90 0B FA         [24] 2285 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      009031 12 38 2D         [24] 2286 	lcall	_ak820_outline_0058
      009034 74 40            [12] 2287 	mov	a,#0x40
      009036 2E               [12] 2288 	add	a, r6
      009037 FE               [12] 2289 	mov	r6,a
      009038 E4               [12] 2290 	clr	a
      009039 3F               [12] 2291 	addc	a, r7
      00903A FF               [12] 2292 	mov	r7,a
      00903B 90 05 8E         [24] 2293 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00903E 12 49 1A         [24] 2294 	lcall	_ak820_outline_0064
      009041 E4               [12] 2295 	clr	a
      009042 A3               [24] 2296 	inc	dptr
      009043 F0               [24] 2297 	movx	@dptr,a
      009044 90 05 91         [24] 2298 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      009047 E5 37            [12] 2299 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      009049 F0               [24] 2300 	movx	@dptr,a
      00904A E5 38            [12] 2301 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00904C A3               [24] 2302 	inc	dptr
      00904D F0               [24] 2303 	movx	@dptr,a
      00904E 12 7C 55         [24] 2304 	lcall	_ak820_outline_0196
                                   2305 ;	quantum/dynamic_keymap.c:584: }
      009051 02 41 43         [24] 2306 	ljmp	_ak820_eeprom_write_block_xdata
                                   2307 ;------------------------------------------------------------
                                   2308 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2309 ;------------------------------------------------------------
                                   2310 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2311 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2312 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_453'
                                   2313 ;------------------------------------------------------------
                                   2314 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2315 ;	-----------------------------------------
                                   2316 ;	 function keycode_at_keymap_location
                                   2317 ;	-----------------------------------------
      009054                       2318 _keycode_at_keymap_location:
      009054 E5 82            [12] 2319 	mov	a,dpl
      009056 90 0C 01         [24] 2320 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_453
      009059 F0               [24] 2321 	movx	@dptr,a
                                   2322 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      00905A E0               [24] 2323 	movx	a,@dptr
      00905B FF               [12] 2324 	mov	r7,a
      00905C BF 06 00         [24] 2325 	cjne	r7,#0x06,00128$
      00905F                       2326 00128$:
      00905F 50 23            [24] 2327 	jnc	00102$
      009061 90 0B FF         [24] 2328 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009064 E0               [24] 2329 	movx	a,@dptr
      009065 FE               [12] 2330 	mov	r6,a
      009066 BE 10 00         [24] 2331 	cjne	r6,#0x10,00130$
      009069                       2332 00130$:
      009069 50 19            [24] 2333 	jnc	00102$
      00906B 90 0C 00         [24] 2334 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      00906E E0               [24] 2335 	movx	a,@dptr
      00906F FD               [12] 2336 	mov	r5,a
      009070 BD 08 00         [24] 2337 	cjne	r5,#0x08,00132$
      009073                       2338 00132$:
      009073 50 0F            [24] 2339 	jnc	00102$
                                   2340 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      009075 90 0B A1         [24] 2341 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      009078 EE               [12] 2342 	mov	a,r6
      009079 F0               [24] 2343 	movx	@dptr,a
      00907A 90 0B A2         [24] 2344 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00907D ED               [12] 2345 	mov	a,r5
      00907E F0               [24] 2346 	movx	@dptr,a
      00907F 8F 82            [24] 2347 	mov	dpl, r7
      009081 02 88 A7         [24] 2348 	ljmp	_dynamic_keymap_get_keycode
      009084                       2349 00102$:
                                   2350 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      009084 90 00 00         [24] 2351 	mov	dptr,#0x0000
                                   2352 ;	quantum/dynamic_keymap.c:591: }
      009087 22               [24] 2353 	ret
                                   2354 ;------------------------------------------------------------
                                   2355 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2356 ;------------------------------------------------------------
                                   2357 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2358 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2359 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_457'
                                   2360 ;------------------------------------------------------------
                                   2361 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2362 ;	-----------------------------------------
                                   2363 ;	 function keycode_at_encodermap_location
                                   2364 ;	-----------------------------------------
      009088                       2365 _keycode_at_encodermap_location:
      009088 E5 82            [12] 2366 	mov	a,dpl
      00908A 90 0C 04         [24] 2367 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_457
      00908D F0               [24] 2368 	movx	@dptr,a
                                   2369 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      00908E E0               [24] 2370 	movx	a,@dptr
      00908F FF               [12] 2371 	mov	r7,a
      009090 BF 06 00         [24] 2372 	cjne	r7,#0x06,00120$
      009093                       2373 00120$:
      009093 50 1E            [24] 2374 	jnc	00102$
      009095 90 0C 02         [24] 2375 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      009098 E0               [24] 2376 	movx	a,@dptr
      009099 FE               [12] 2377 	mov	r6,a
      00909A BE 01 00         [24] 2378 	cjne	r6,#0x01,00122$
      00909D                       2379 00122$:
      00909D 50 14            [24] 2380 	jnc	00102$
                                   2381 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      00909F 90 0C 03         [24] 2382 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0090A2 E0               [24] 2383 	movx	a,@dptr
      0090A3 FE               [12] 2384 	mov	r6,a
      0090A4 90 0B AB         [24] 2385 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0090A7 E4               [12] 2386 	clr	a
      0090A8 F0               [24] 2387 	movx	@dptr,a
      0090A9 90 0B AC         [24] 2388 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0090AC EE               [12] 2389 	mov	a,r6
      0090AD F0               [24] 2390 	movx	@dptr,a
      0090AE 8F 82            [24] 2391 	mov	dpl, r7
      0090B0 02 89 62         [24] 2392 	ljmp	_dynamic_keymap_get_encoder
      0090B3                       2393 00102$:
                                   2394 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      0090B3 90 00 00         [24] 2395 	mov	dptr,#0x0000
                                   2396 ;	quantum/dynamic_keymap.c:599: }
      0090B6 22               [24] 2397 	ret
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function dynamic_keymap_macro_get_count
                                   2404 ;	-----------------------------------------
      0090B7                       2405 _dynamic_keymap_macro_get_count:
                                   2406 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0090B7 75 82 10         [24] 2407 	mov	dpl, #0x10
                                   2408 ;	quantum/dynamic_keymap.c:604: }
      0090BA 22               [24] 2409 	ret
                                   2410 ;------------------------------------------------------------
                                   2411 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2412 ;------------------------------------------------------------
                                   2413 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2414 ;	-----------------------------------------
                                   2415 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2416 ;	-----------------------------------------
      0090BB                       2417 _dynamic_keymap_macro_get_buffer_size:
                                   2418 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0090BB 90 20 00         [24] 2419 	mov	dptr,#0x2000
                                   2420 ;	quantum/dynamic_keymap.c:608: }
      0090BE 22               [24] 2421 	ret
                                   2422 ;------------------------------------------------------------
                                   2423 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2424 ;------------------------------------------------------------
                                   2425 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2426 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2427 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2428 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_465'
                                   2429 ;------------------------------------------------------------
                                   2430 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2431 ;	-----------------------------------------
                                   2432 ;	 function dynamic_keymap_macro_get_buffer
                                   2433 ;	-----------------------------------------
      0090BF                       2434 _dynamic_keymap_macro_get_buffer:
      0090BF 12 38 81         [24] 2435 	lcall	_ak820_outline_0111
      0090C2 90 0C 0A         [24] 2436 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      0090C5 12 38 86         [24] 2437 	lcall	_ak820_outline_0112
                                   2438 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      0090C8 12 2B 2B         [24] 2439 	lcall	_ak820_macro_length
      0090CB 12 43 64         [24] 2440 	lcall	_ak820_outline_0142
      0090CE 90 0C 0A         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      0090D1 12 38 44         [24] 2442 	lcall	_ak820_outline_0065
      0090D4 90 0C 05         [24] 2443 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      0090D7 E0               [24] 2444 	movx	a,@dptr
      0090D8 F5 3A            [12] 2445 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      0090DA A3               [24] 2446 	inc	dptr
      0090DB E0               [24] 2447 	movx	a,@dptr
      0090DC F5 3B            [12] 2448 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      0090DE 90 0C 07         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      0090E1 12 38 6F         [24] 2450 	lcall	_ak820_outline_0104
      0090E4 A3               [24] 2451 	inc	dptr
      0090E5 E0               [24] 2452 	movx	a,@dptr
      0090E6 FB               [12] 2453 	mov	r3,a
      0090E7 90 0B E2         [24] 2454 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0090EA 12 49 1A         [24] 2455 	lcall	_ak820_outline_0064
      0090ED 90 0B E4         [24] 2456 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0090F0 12 38 50         [24] 2457 	lcall	_ak820_outline_0078
      0090F3 90 0B E6         [24] 2458 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0090F6 E5 3A            [12] 2459 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      0090F8 F0               [24] 2460 	movx	@dptr,a
      0090F9 E5 3B            [12] 2461 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      0090FB A3               [24] 2462 	inc	dptr
      0090FC F0               [24] 2463 	movx	@dptr,a
      0090FD 90 0B E8         [24] 2464 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009100 E8               [12] 2465 	mov	a,r0
      009101 F0               [24] 2466 	movx	@dptr,a
      009102 E9               [12] 2467 	mov	a,r1
      009103 A3               [24] 2468 	inc	dptr
      009104 F0               [24] 2469 	movx	@dptr,a
      009105 EB               [12] 2470 	mov	a,r3
      009106 A3               [24] 2471 	inc	dptr
      009107 F0               [24] 2472 	movx	@dptr,a
      009108 90 08 00         [24] 2473 	mov	dptr,#0x0800
                                   2474 ;	quantum/dynamic_keymap.c:635: }
      00910B 02 8D CD         [24] 2475 	ljmp	_ak820_dynamic_read_buffer
                                   2476 ;------------------------------------------------------------
                                   2477 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2478 ;------------------------------------------------------------
                                   2479 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2480 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2481 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_467'
                                   2482 ;------------------------------------------------------------
                                   2483 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2484 ;	-----------------------------------------
                                   2485 ;	 function dynamic_keymap_macro_set_buffer
                                   2486 ;	-----------------------------------------
      00910E                       2487 _dynamic_keymap_macro_set_buffer:
      00910E 12 38 81         [24] 2488 	lcall	_ak820_outline_0111
      009111 90 0C 11         [24] 2489 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      009114 12 38 86         [24] 2490 	lcall	_ak820_outline_0112
                                   2491 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009117 90 0C 11         [24] 2492 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      00911A 12 38 2D         [24] 2493 	lcall	_ak820_outline_0058
      00911D 90 0C 0C         [24] 2494 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      009120 12 38 44         [24] 2495 	lcall	_ak820_outline_0065
      009123 90 0C 0E         [24] 2496 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009126 E0               [24] 2497 	movx	a,@dptr
      009127 F9               [12] 2498 	mov	r1,a
      009128 A3               [24] 2499 	inc	dptr
      009129 12 43 4C         [24] 2500 	lcall	_ak820_outline_0083
      00912C 90 05 14         [24] 2501 	mov	dptr,#_ak820_macro_write_PARM_2
      00912F 12 38 50         [24] 2502 	lcall	_ak820_outline_0078
      009132 90 05 16         [24] 2503 	mov	dptr,#_ak820_macro_write_PARM_3
      009135 12 4E 27         [24] 2504 	lcall	_ak820_outline_0102
      009138 EB               [12] 2505 	mov	a,r3
      009139 A3               [24] 2506 	inc	dptr
      00913A 12 43 46         [24] 2507 	lcall	_ak820_outline_0071
                                   2508 ;	quantum/dynamic_keymap.c:640: }
      00913D 02 2B 45         [24] 2509 	ljmp	_ak820_macro_write
                                   2510 ;------------------------------------------------------------
                                   2511 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2512 ;------------------------------------------------------------
                                   2513 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2514 ;	-----------------------------------------
                                   2515 ;	 function dynamic_keymap_macro_reset
                                   2516 ;	-----------------------------------------
      009140                       2517 _dynamic_keymap_macro_reset:
                                   2518 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2519 ;	quantum/dynamic_keymap.c:666: }
      009140 02 2E 64         [24] 2520 	ljmp	_ak820_macro_reset
                                   2521 ;------------------------------------------------------------
                                   2522 ;Allocation info for local variables in function 'decode_keycode'
                                   2523 ;------------------------------------------------------------
                                   2524 ;kc            Allocated with name '_decode_keycode_kc_10000_471'
                                   2525 ;------------------------------------------------------------
                                   2526 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2527 ;	-----------------------------------------
                                   2528 ;	 function decode_keycode
                                   2529 ;	-----------------------------------------
      009143                       2530 _decode_keycode:
      009143 12 38 81         [24] 2531 	lcall	_ak820_outline_0111
      009146 90 0C 13         [24] 2532 	mov	dptr,#_decode_keycode_kc_10000_471
      009149 12 38 86         [24] 2533 	lcall	_ak820_outline_0112
                                   2534 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      00914C 90 0C 13         [24] 2535 	mov	dptr,#_decode_keycode_kc_10000_471
      00914F 12 4D E6         [24] 2536 	lcall	_ak820_outline_0010
      009152 C3               [12] 2537 	clr	c
      009153 E4               [12] 2538 	clr	a
      009154 9C               [12] 2539 	subb	a,r4
      009155 74 FF            [12] 2540 	mov	a,#0xff
      009157 9D               [12] 2541 	subb	a,r5
      009158 50 08            [24] 2542 	jnc	00102$
                                   2543 ;	free result
                                   2544 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      00915A 8C 05            [24] 2545 	mov	ar5,r4
      00915C 7C 00            [12] 2546 	mov	r4,#0x00
      00915E 12 38 A3         [24] 2547 	lcall	_ak820_outline_0132
      009161 22               [24] 2548 	ret
      009162                       2549 00102$:
                                   2550 ;	quantum/dynamic_keymap.c:672: return kc;
      009162 12 38 92         [24] 2551 	lcall	_ak820_outline_0124
                                   2552 ;	quantum/dynamic_keymap.c:673: }
      009165 22               [24] 2553 	ret
                                   2554 ;------------------------------------------------------------
                                   2555 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2556 ;------------------------------------------------------------
                                   2557 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_474'
                                   2558 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_475'
                                   2559 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_480'
                                   2560 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_481'
                                   2561 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_487'
                                   2562 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_505'
                                   2563 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_509'
                                   2564 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_509'
                                   2565 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_511'
                                   2566 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_513'
                                   2567 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_517'
                                   2568 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_519'
                                   2569 ;------------------------------------------------------------
                                   2570 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2571 ;	-----------------------------------------
                                   2572 ;	 function dynamic_keymap_macro_send
                                   2573 ;	-----------------------------------------
      009166                       2574 _dynamic_keymap_macro_send:
      009166 E5 82            [12] 2575 	mov	a,dpl
      009168 90 0C 15         [24] 2576 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      00916B F0               [24] 2577 	movx	@dptr,a
                                   2578 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      00916C 90 0C 16         [24] 2579 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      00916F E0               [24] 2580 	movx	a,@dptr
      009170 60 01            [24] 2581 	jz	00102$
      009172 22               [24] 2582 	ret
      009173                       2583 00102$:
                                   2584 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      009173 90 0C 15         [24] 2585 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      009176 E0               [24] 2586 	movx	a,@dptr
      009177 FF               [12] 2587 	mov	r7,a
      009178 BF 10 00         [24] 2588 	cjne	r7,#0x10,00422$
      00917B                       2589 00422$:
      00917B 40 01            [24] 2590 	jc	00104$
                                   2591 ;	quantum/dynamic_keymap.c:683: return;
      00917D 22               [24] 2592 	ret
      00917E                       2593 00104$:
                                   2594 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      00917E C0 07            [24] 2595 	push	ar7
      009180 12 2A F2         [24] 2596 	lcall	_ak820_macro_ready
      009183 E5 82            [12] 2597 	mov	a, dpl
      009185 D0 07            [24] 2598 	pop	ar7
      009187 70 01            [24] 2599 	jnz	00106$
      009189 22               [24] 2600 	ret
      00918A                       2601 00106$:
                                   2602 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      00918A 90 0C 17         [24] 2603 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00918D E4               [12] 2604 	clr	a
      00918E F0               [24] 2605 	movx	@dptr,a
      00918F 74 08            [12] 2606 	mov	a,#0x08
      009191 A3               [24] 2607 	inc	dptr
      009192 F0               [24] 2608 	movx	@dptr,a
                                   2609 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      009193 C0 07            [24] 2610 	push	ar7
      009195 12 2B 2B         [24] 2611 	lcall	_ak820_macro_length
      009198 AD 82            [24] 2612 	mov	r5, dpl
      00919A AE 83            [24] 2613 	mov	r6, dph
      00919C D0 07            [24] 2614 	pop	ar7
      00919E 74 08            [12] 2615 	mov	a,#0x08
      0091A0 2E               [12] 2616 	add	a, r6
      0091A1 FE               [12] 2617 	mov	r6,a
                                   2618 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      0091A2 7B 00            [12] 2619 	mov	r3,#0x00
      0091A4 7C 08            [12] 2620 	mov	r4,#0x08
      0091A6                       2621 00111$:
      0091A6 EF               [12] 2622 	mov	a,r7
      0091A7 60 31            [24] 2623 	jz	00113$
                                   2624 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      0091A9 EB               [12] 2625 	mov	a,r3
      0091AA B5 05 05         [24] 2626 	cjne	a,ar5,00108$
      0091AD EC               [12] 2627 	mov	a,r4
      0091AE B5 06 01         [24] 2628 	cjne	a,ar6,00108$
                                   2629 ;	quantum/dynamic_keymap.c:717: return;
      0091B1 22               [24] 2630 	ret
      0091B2                       2631 00108$:
                                   2632 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0091B2 8B 01            [24] 2633 	mov	ar1,r3
      0091B4 8C 02            [24] 2634 	mov	ar2,r4
      0091B6 8A 00            [24] 2635 	mov	ar0,r2
      0091B8 7A 00            [12] 2636 	mov	r2,#0x00
      0091BA 89 82            [24] 2637 	mov	dpl, r1
      0091BC 88 83            [24] 2638 	mov	dph, r0
      0091BE 8A F0            [24] 2639 	mov	b, r2
      0091C0 12 40 7C         [24] 2640 	lcall	_eeprom_read_byte
      0091C3 E5 82            [12] 2641 	mov	a, dpl
      0091C5 70 06            [24] 2642 	jnz	00110$
                                   2643 ;	quantum/dynamic_keymap.c:720: --id;
      0091C7 1F               [12] 2644 	dec	r7
      0091C8 90 0C 15         [24] 2645 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      0091CB EF               [12] 2646 	mov	a,r7
      0091CC F0               [24] 2647 	movx	@dptr,a
      0091CD                       2648 00110$:
                                   2649 ;	quantum/dynamic_keymap.c:722: ++p;
      0091CD 0B               [12] 2650 	inc	r3
      0091CE BB 00 01         [24] 2651 	cjne	r3,#0x00,00429$
      0091D1 0C               [12] 2652 	inc	r4
      0091D2                       2653 00429$:
      0091D2 90 0C 17         [24] 2654 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0091D5 12 38 56         [24] 2655 	lcall	_ak820_outline_0084
      0091D8 80 CC            [24] 2656 	sjmp	00111$
      0091DA                       2657 00113$:
                                   2658 ;	quantum/dynamic_keymap.c:728: sending = true;
      0091DA 90 0C 16         [24] 2659 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      0091DD 74 01            [12] 2660 	mov	a,#0x01
      0091DF F0               [24] 2661 	movx	@dptr,a
                                   2662 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      0091E0 12 94 8B         [24] 2663 	lcall	_ak820_outline_0171
      0091E3 90 0A 4D         [24] 2664 	mov	dptr,#_ak820_macro_cancelled
      0091E6 F0               [24] 2665 	movx	@dptr,a
                                   2666 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      0091E7 90 0C 19         [24] 2667 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0091EA F0               [24] 2668 	movx	@dptr,a
      0091EB 90 0C 1A         [24] 2669 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      0091EE F0               [24] 2670 	movx	@dptr,a
      0091EF 90 0C 1B         [24] 2671 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      0091F2 F0               [24] 2672 	movx	@dptr,a
      0091F3 90 0C 1C         [24] 2673 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      0091F6 F0               [24] 2674 	movx	@dptr,a
                                   2675 ;	quantum/dynamic_keymap.c:738: while (p < end
      0091F7                       2676 00167$:
                                   2677 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      0091F7 90 0C 17         [24] 2678 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0091FA E0               [24] 2679 	movx	a,@dptr
      0091FB FC               [12] 2680 	mov	r4,a
      0091FC A3               [24] 2681 	inc	dptr
      0091FD E0               [24] 2682 	movx	a,@dptr
      0091FE FF               [12] 2683 	mov	r7,a
      0091FF C3               [12] 2684 	clr	c
      009200 EC               [12] 2685 	mov	a,r4
      009201 9D               [12] 2686 	subb	a,r5
      009202 EF               [12] 2687 	mov	a,r7
      009203 9E               [12] 2688 	subb	a,r6
      009204 40 02            [24] 2689 	jc	00430$
      009206 81 0B            [12] 2690 	ajmp	00169$
      009208                       2691 00430$:
      009208 90 0A 4D         [24] 2692 	mov	dptr,#_ak820_macro_cancelled
      00920B E0               [24] 2693 	movx	a,@dptr
      00920C 60 02            [24] 2694 	jz	00431$
      00920E 81 0B            [12] 2695 	ajmp	00169$
      009210                       2696 00431$:
                                   2697 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009210 8C 02            [24] 2698 	mov	ar2,r4
      009212 8F 03            [24] 2699 	mov	ar3,r7
      009214 90 0C 17         [24] 2700 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009217 74 01            [12] 2701 	mov	a,#0x01
      009219 2C               [12] 2702 	add	a, r4
      00921A F0               [24] 2703 	movx	@dptr,a
      00921B E4               [12] 2704 	clr	a
      00921C 3F               [12] 2705 	addc	a, r7
      00921D A3               [24] 2706 	inc	dptr
      00921E F0               [24] 2707 	movx	@dptr,a
      00921F 7F 00            [12] 2708 	mov	r7,#0x00
      009221 12 38 AD         [24] 2709 	lcall	_ak820_outline_0134
      009224 8F F0            [24] 2710 	mov	b, r7
      009226 12 40 7C         [24] 2711 	lcall	_eeprom_read_byte
      009229 AF 82            [24] 2712 	mov	r7, dpl
      00922B 90 0C 19         [24] 2713 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00922E EF               [12] 2714 	mov	a,r7
      00922F F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      009230 90 0C 1A         [24] 2717 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009233 E4               [12] 2718 	clr	a
      009234 F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      009235 90 0C 19         [24] 2721 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009238 E0               [24] 2722 	movx	a,@dptr
      009239 70 02            [24] 2723 	jnz	00432$
      00923B 81 0B            [12] 2724 	ajmp	00169$
      00923D                       2725 00432$:
                                   2726 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      00923D 90 0C 19         [24] 2727 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009240 E0               [24] 2728 	movx	a,@dptr
      009241 FF               [12] 2729 	mov	r7,a
      009242 BF 01 02         [24] 2730 	cjne	r7,#0x01,00433$
      009245 80 02            [24] 2731 	sjmp	00434$
      009247                       2732 00433$:
      009247 61 EE            [12] 2733 	ajmp	00164$
      009249                       2734 00434$:
                                   2735 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009249 12 94 13         [24] 2736 	lcall	_ak820_outline_0000
      00924C 12 40 7C         [24] 2737 	lcall	_eeprom_read_byte
      00924F AF 82            [24] 2738 	mov	r7, dpl
      009251 90 0C 1A         [24] 2739 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009254 EF               [12] 2740 	mov	a,r7
      009255 F0               [24] 2741 	movx	@dptr,a
                                   2742 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      009256 EF               [12] 2743 	mov	a,r7
      009257 70 02            [24] 2744 	jnz	00435$
      009259 81 0B            [12] 2745 	ajmp	00169$
      00925B                       2746 00435$:
                                   2747 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      00925B 12 94 52         [24] 2748 	lcall	_ak820_outline_0097
      00925E BF 01 02         [24] 2749 	cjne	r7,#0x01,00436$
      009261 80 12            [24] 2750 	sjmp	00151$
      009263                       2751 00436$:
      009263 12 94 52         [24] 2752 	lcall	_ak820_outline_0097
      009266 BF 02 02         [24] 2753 	cjne	r7,#0x02,00437$
      009269 80 0A            [24] 2754 	sjmp	00151$
      00926B                       2755 00437$:
      00926B 12 94 52         [24] 2756 	lcall	_ak820_outline_0097
      00926E BF 03 02         [24] 2757 	cjne	r7,#0x03,00438$
      009271 80 02            [24] 2758 	sjmp	00439$
      009273                       2759 00438$:
      009273 41 D4            [12] 2760 	ajmp	00152$
      009275                       2761 00439$:
      009275                       2762 00151$:
                                   2763 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009275 12 94 13         [24] 2764 	lcall	_ak820_outline_0000
      009278 12 40 7C         [24] 2765 	lcall	_eeprom_read_byte
      00927B 12 94 A3         [24] 2766 	lcall	_ak820_outline_0189
                                   2767 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      00927E 70 02            [24] 2768 	jnz	00440$
      009280 21 F7            [12] 2769 	ajmp	00167$
      009282                       2770 00440$:
                                   2771 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      009282 12 94 52         [24] 2772 	lcall	_ak820_outline_0097
      009285 BF 01 03         [24] 2773 	cjne	r7,#0x01,00441$
      009288 D3               [12] 2774 	setb	c
      009289 80 01            [24] 2775 	sjmp	00442$
      00928B                       2776 00441$:
      00928B C3               [12] 2777 	clr	c
      00928C                       2778 00442$:
      00928C 92 26            [24] 2779 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00928E 90 0A 4C         [24] 2780 	mov	dptr,#_ak820_macro_primitive
      009291 B3               [12] 2781 	cpl	c
      009292 E4               [12] 2782 	clr	a
      009293 33               [12] 2783 	rlc	a
      009294 F0               [24] 2784 	movx	@dptr,a
                                   2785 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      009295 12 94 52         [24] 2786 	lcall	_ak820_outline_0097
      009298 BF 01 10         [24] 2787 	cjne	r7,#0x01,00122$
      00929B 12 94 84         [24] 2788 	lcall	_ak820_outline_0159
      00929E C0 06            [24] 2789 	push	ar6
      0092A0 C0 05            [24] 2790 	push	ar5
      0092A2 12 7B 1E         [24] 2791 	lcall	_tap_code
      0092A5 D0 05            [24] 2792 	pop	ar5
      0092A7 D0 06            [24] 2793 	pop	ar6
      0092A9 80 24            [24] 2794 	sjmp	00123$
      0092AB                       2795 00122$:
                                   2796 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0092AB 12 94 52         [24] 2797 	lcall	_ak820_outline_0097
      0092AE BF 02 10         [24] 2798 	cjne	r7,#0x02,00119$
      0092B1 12 94 84         [24] 2799 	lcall	_ak820_outline_0159
      0092B4 C0 06            [24] 2800 	push	ar6
      0092B6 C0 05            [24] 2801 	push	ar5
      0092B8 12 7A 1A         [24] 2802 	lcall	_register_code
      0092BB D0 05            [24] 2803 	pop	ar5
      0092BD D0 06            [24] 2804 	pop	ar6
      0092BF 80 0E            [24] 2805 	sjmp	00123$
      0092C1                       2806 00119$:
                                   2807 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      0092C1 12 94 84         [24] 2808 	lcall	_ak820_outline_0159
      0092C4 C0 06            [24] 2809 	push	ar6
      0092C6 C0 05            [24] 2810 	push	ar5
      0092C8 12 7A 87         [24] 2811 	lcall	_unregister_code
      0092CB D0 05            [24] 2812 	pop	ar5
      0092CD D0 06            [24] 2813 	pop	ar6
      0092CF                       2814 00123$:
                                   2815 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      0092CF 12 94 8B         [24] 2816 	lcall	_ak820_outline_0171
      0092D2 21 F7            [12] 2817 	ajmp	00167$
      0092D4                       2818 00152$:
                                   2819 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0092D4 12 94 52         [24] 2820 	lcall	_ak820_outline_0097
      0092D7 BF 05 02         [24] 2821 	cjne	r7,#0x05,00447$
      0092DA 80 12            [24] 2822 	sjmp	00146$
      0092DC                       2823 00447$:
      0092DC 12 94 52         [24] 2824 	lcall	_ak820_outline_0097
      0092DF BF 06 02         [24] 2825 	cjne	r7,#0x06,00448$
      0092E2 80 0A            [24] 2826 	sjmp	00146$
      0092E4                       2827 00448$:
      0092E4 12 94 52         [24] 2828 	lcall	_ak820_outline_0097
      0092E7 BF 07 02         [24] 2829 	cjne	r7,#0x07,00449$
      0092EA 80 02            [24] 2830 	sjmp	00450$
      0092EC                       2831 00449$:
      0092EC 61 90            [12] 2832 	ajmp	00147$
      0092EE                       2833 00450$:
      0092EE                       2834 00146$:
                                   2835 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092EE 12 94 13         [24] 2836 	lcall	_ak820_outline_0000
      0092F1 12 40 7C         [24] 2837 	lcall	_eeprom_read_byte
      0092F4 12 94 A3         [24] 2838 	lcall	_ak820_outline_0189
                                   2839 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      0092F7 70 02            [24] 2840 	jnz	00451$
      0092F9 21 F7            [12] 2841 	ajmp	00167$
      0092FB                       2842 00451$:
                                   2843 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092FB 12 94 13         [24] 2844 	lcall	_ak820_outline_0000
      0092FE 12 40 7C         [24] 2845 	lcall	_eeprom_read_byte
      009301 AF 82            [24] 2846 	mov	r7, dpl
      009303 90 0C 1C         [24] 2847 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      009306 EF               [12] 2848 	mov	a,r7
      009307 F0               [24] 2849 	movx	@dptr,a
                                   2850 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      009308 EF               [12] 2851 	mov	a,r7
      009309 70 02            [24] 2852 	jnz	00452$
      00930B 21 F7            [12] 2853 	ajmp	00167$
      00930D                       2854 00452$:
                                   2855 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      00930D 90 0C 1B         [24] 2856 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      009310 E0               [24] 2857 	movx	a,@dptr
      009311 FF               [12] 2858 	mov	r7,a
      009312 90 0C 1C         [24] 2859 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      009315 E0               [24] 2860 	movx	a,@dptr
      009316 FB               [12] 2861 	mov	r3,a
      009317 E4               [12] 2862 	clr	a
      009318 FC               [12] 2863 	mov	r4,a
      009319 FA               [12] 2864 	mov	r2,a
      00931A EF               [12] 2865 	mov	a,r7
      00931B 42 04            [12] 2866 	orl	ar4,a
      00931D EA               [12] 2867 	mov	a,r2
      00931E 42 03            [12] 2868 	orl	ar3,a
                                   2869 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      009320 12 43 8A         [24] 2870 	lcall	_ak820_outline_0190
      009323 C0 06            [24] 2871 	push	ar6
      009325 C0 05            [24] 2872 	push	ar5
      009327 31 43            [12] 2873 	acall	_decode_keycode
      009329 AC 82            [24] 2874 	mov	r4, dpl
      00932B AF 83            [24] 2875 	mov	r7, dph
      00932D D0 05            [24] 2876 	pop	ar5
      00932F D0 06            [24] 2877 	pop	ar6
                                   2878 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      009331 90 0C 1A         [24] 2879 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009334 E0               [24] 2880 	movx	a,@dptr
      009335 FB               [12] 2881 	mov	r3,a
      009336 BB 05 03         [24] 2882 	cjne	r3,#0x05,00453$
      009339 D3               [12] 2883 	setb	c
      00933A 80 01            [24] 2884 	sjmp	00454$
      00933C                       2885 00453$:
      00933C C3               [12] 2886 	clr	c
      00933D                       2887 00454$:
      00933D 92 26            [24] 2888 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00933F 90 0A 4C         [24] 2889 	mov	dptr,#_ak820_macro_primitive
      009342 B3               [12] 2890 	cpl	c
      009343 E4               [12] 2891 	clr	a
      009344 33               [12] 2892 	rlc	a
      009345 F0               [24] 2893 	movx	@dptr,a
                                   2894 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      009346 90 0C 1A         [24] 2895 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009349 E0               [24] 2896 	movx	a,@dptr
      00934A FB               [12] 2897 	mov	r3,a
      00934B BB 05 02         [24] 2898 	cjne	r3,#0x05,00455$
      00934E 80 0A            [24] 2899 	sjmp	00126$
      009350                       2900 00455$:
      009350 BB 06 02         [24] 2901 	cjne	r3,#0x06,00456$
      009353 80 16            [24] 2902 	sjmp	00127$
      009355                       2903 00456$:
                                   2904 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      009355 BB 07 33         [24] 2905 	cjne	r3,#0x07,00129$
      009358 80 22            [24] 2906 	sjmp	00128$
      00935A                       2907 00126$:
                                   2908 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      00935A 8C 82            [24] 2909 	mov	dpl, r4
      00935C 8F 83            [24] 2910 	mov	dph, r7
      00935E C0 06            [24] 2911 	push	ar6
      009360 C0 05            [24] 2912 	push	ar5
      009362 12 B8 95         [24] 2913 	lcall	_vial_keycode_tap
      009365 D0 05            [24] 2914 	pop	ar5
      009367 D0 06            [24] 2915 	pop	ar6
                                   2916 ;	quantum/dynamic_keymap.c:795: break;
                                   2917 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      009369 80 20            [24] 2918 	sjmp	00129$
      00936B                       2919 00127$:
                                   2920 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      00936B 8C 82            [24] 2921 	mov	dpl, r4
      00936D 8F 83            [24] 2922 	mov	dph, r7
      00936F C0 06            [24] 2923 	push	ar6
      009371 C0 05            [24] 2924 	push	ar5
      009373 12 B7 CA         [24] 2925 	lcall	_vial_keycode_down
      009376 D0 05            [24] 2926 	pop	ar5
      009378 D0 06            [24] 2927 	pop	ar6
                                   2928 ;	quantum/dynamic_keymap.c:798: break;
                                   2929 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      00937A 80 0F            [24] 2930 	sjmp	00129$
      00937C                       2931 00128$:
                                   2932 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      00937C 8C 82            [24] 2933 	mov	dpl, r4
      00937E 8F 83            [24] 2934 	mov	dph, r7
      009380 C0 06            [24] 2935 	push	ar6
      009382 C0 05            [24] 2936 	push	ar5
      009384 12 B8 30         [24] 2937 	lcall	_vial_keycode_up
      009387 D0 05            [24] 2938 	pop	ar5
      009389 D0 06            [24] 2939 	pop	ar6
                                   2940 ;	quantum/dynamic_keymap.c:802: }
      00938B                       2941 00129$:
                                   2942 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      00938B 12 94 8B         [24] 2943 	lcall	_ak820_outline_0171
      00938E 21 F7            [12] 2944 	ajmp	00167$
      009390                       2945 00147$:
                                   2946 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      009390 12 94 52         [24] 2947 	lcall	_ak820_outline_0097
      009393 BF 04 02         [24] 2948 	cjne	r7,#0x04,00458$
      009396 80 02            [24] 2949 	sjmp	00459$
      009398                       2950 00458$:
      009398 21 F7            [12] 2951 	ajmp	00167$
      00939A                       2952 00459$:
                                   2953 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00939A 12 94 13         [24] 2954 	lcall	_ak820_outline_0000
      00939D 12 40 7C         [24] 2955 	lcall	_eeprom_read_byte
      0093A0 AF 82            [24] 2956 	mov	r7, dpl
                                   2957 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0093A2 90 0C 17         [24] 2958 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0093A5 12 38 7B         [24] 2959 	lcall	_ak820_outline_0107
      0093A8 90 0C 17         [24] 2960 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0093AB 74 01            [12] 2961 	mov	a,#0x01
      0093AD 2B               [12] 2962 	add	a, r3
      0093AE F0               [24] 2963 	movx	@dptr,a
      0093AF E4               [12] 2964 	clr	a
      0093B0 3C               [12] 2965 	addc	a, r4
      0093B1 A3               [24] 2966 	inc	dptr
      0093B2 F0               [24] 2967 	movx	@dptr,a
      0093B3 7A 00            [12] 2968 	mov	r2,#0x00
      0093B5 12 33 FC         [24] 2969 	lcall	_ak820_outline_0131
      0093B8 8A F0            [24] 2970 	mov	b, r2
      0093BA 12 40 7C         [24] 2971 	lcall	_eeprom_read_byte
      0093BD AC 82            [24] 2972 	mov	r4, dpl
                                   2973 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      0093BF EF               [12] 2974 	mov	a,r7
      0093C0 60 49            [24] 2975 	jz	00169$
      0093C2 EC               [12] 2976 	mov	a,r4
      0093C3 60 46            [24] 2977 	jz	00169$
                                   2978 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0093C5 1F               [12] 2979 	dec	r7
      0093C6 1C               [12] 2980 	dec	r4
      0093C7 EC               [12] 2981 	mov	a,r4
      0093C8 75 F0 FF         [24] 2982 	mov	b,#0xff
      0093CB A4               [48] 2983 	mul	ab
      0093CC FC               [12] 2984 	mov	r4,a
      0093CD AB F0            [24] 2985 	mov	r3,b
      0093CF 7A 00            [12] 2986 	mov	r2,#0x00
      0093D1 EC               [12] 2987 	mov	a,r4
      0093D2 2F               [12] 2988 	add	a, r7
      0093D3 FC               [12] 2989 	mov	r4,a
      0093D4 EB               [12] 2990 	mov	a,r3
      0093D5 3A               [12] 2991 	addc	a, r2
      0093D6 FB               [12] 2992 	mov	r3,a
                                   2993 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      0093D7                       2994 00141$:
      0093D7 8C 02            [24] 2995 	mov	ar2,r4
      0093D9 8B 07            [24] 2996 	mov	ar7,r3
      0093DB 1C               [12] 2997 	dec	r4
      0093DC BC FF 01         [24] 2998 	cjne	r4,#0xff,00462$
      0093DF 1B               [12] 2999 	dec	r3
      0093E0                       3000 00462$:
      0093E0 EA               [12] 3001 	mov	a,r2
      0093E1 4F               [12] 3002 	orl	a,r7
      0093E2 70 02            [24] 3003 	jnz	00463$
      0093E4 21 F7            [12] 3004 	ajmp	00167$
      0093E6                       3005 00463$:
      0093E6 90 00 01         [24] 3006 	mov	dptr,#0x0001
      0093E9 12 5E 16         [24] 3007 	lcall	_mDelaymS
      0093EC 80 E9            [24] 3008 	sjmp	00141$
      0093EE                       3009 00164$:
                                   3010 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      0093EE 90 0C 19         [24] 3011 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0093F1 E0               [24] 3012 	movx	a,@dptr
      0093F2 FF               [12] 3013 	mov	r7,a
      0093F3 BF 80 00         [24] 3014 	cjne	r7,#0x80,00464$
      0093F6                       3015 00464$:
      0093F6 50 13            [24] 3016 	jnc	00169$
                                   3017 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      0093F8 90 0C 19         [24] 3018 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      0093FB E0               [24] 3019 	movx	a,@dptr
      0093FC F5 82            [12] 3020 	mov	dpl,a
      0093FE C0 06            [24] 3021 	push	ar6
      009400 C0 05            [24] 3022 	push	ar5
      009402 12 AA 73         [24] 3023 	lcall	_send_char
      009405 D0 05            [24] 3024 	pop	ar5
      009407 D0 06            [24] 3025 	pop	ar6
                                   3026 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009409 21 F7            [12] 3027 	ajmp	00167$
      00940B                       3028 00169$:
                                   3029 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      00940B 12 94 8B         [24] 3030 	lcall	_ak820_outline_0171
                                   3031 ;	quantum/dynamic_keymap.c:837: sending = false;
      00940E 90 0C 16         [24] 3032 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009411 F0               [24] 3033 	movx	@dptr,a
                                   3034 ;	quantum/dynamic_keymap.c:839: }
      009412 22               [24] 3035 	ret
                                   3036 	.area CSEG    (CODE)
                                   3037 	.area CONST   (CODE)
                                   3038 	.area XINIT   (CODE)
                                   3039 	.area CABS    (ABS,CODE)
                                   3040 
                                   3041 ; Experimental exact instruction outlining.
                                   3042 	.globl _ak820_outline_0000
                                   3043 	.globl _ak820_outline_0006
                                   3044 	.globl _ak820_outline_0010
                                   3045 	.globl _ak820_outline_0013
                                   3046 	.globl _ak820_outline_0016
                                   3047 	.globl _ak820_outline_0026
                                   3048 	.globl _ak820_outline_0036
                                   3049 	.globl _ak820_outline_0043
                                   3050 	.globl _ak820_outline_0058
                                   3051 	.globl _ak820_outline_0063
                                   3052 	.globl _ak820_outline_0064
                                   3053 	.globl _ak820_outline_0065
                                   3054 	.globl _ak820_outline_0071
                                   3055 	.globl _ak820_outline_0077
                                   3056 	.globl _ak820_outline_0078
                                   3057 	.globl _ak820_outline_0081
                                   3058 	.globl _ak820_outline_0083
                                   3059 	.globl _ak820_outline_0084
                                   3060 	.globl _ak820_outline_0087
                                   3061 	.globl _ak820_outline_0097
                                   3062 	.globl _ak820_outline_0101
                                   3063 	.globl _ak820_outline_0102
                                   3064 	.globl _ak820_outline_0104
                                   3065 	.globl _ak820_outline_0106
                                   3066 	.globl _ak820_outline_0107
                                   3067 	.globl _ak820_outline_0111
                                   3068 	.globl _ak820_outline_0112
                                   3069 	.globl _ak820_outline_0115
                                   3070 	.globl _ak820_outline_0118
                                   3071 	.globl _ak820_outline_0122
                                   3072 	.globl _ak820_outline_0124
                                   3073 	.globl _ak820_outline_0129
                                   3074 	.globl _ak820_outline_0131
                                   3075 	.globl _ak820_outline_0132
                                   3076 	.globl _ak820_outline_0133
                                   3077 	.globl _ak820_outline_0134
                                   3078 	.globl _ak820_outline_0138
                                   3079 	.globl _ak820_outline_0142
                                   3080 	.globl _ak820_outline_0143
                                   3081 	.globl _ak820_outline_0144
                                   3082 	.globl _ak820_outline_0149
                                   3083 	.globl _ak820_outline_0150
                                   3084 	.globl _ak820_outline_0156
                                   3085 	.globl _ak820_outline_0159
                                   3086 	.globl _ak820_outline_0165
                                   3087 	.globl _ak820_outline_0171
                                   3088 	.globl _ak820_outline_0177
                                   3089 	.globl _ak820_outline_0185
                                   3090 	.globl _ak820_outline_0186
                                   3091 	.globl _ak820_outline_0189
                                   3092 	.globl _ak820_outline_0190
                                   3093 	.globl _ak820_outline_0195
                                   3094 	.globl _ak820_outline_0196
                                   3095 
                                   3096 	.area CSEG (CODE)
                                   3097 ; function ak820_outline_0000
      009413                       3098 _ak820_outline_0000:
      009413 90 0C 17         [24] 3099 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009416 E0               [24] 3100 	movx	a,@dptr
      009417 FC               [12] 3101 	mov	r4,a
      009418 A3               [24] 3102 	inc	dptr
      009419 E0               [24] 3103 	movx	a,@dptr
      00941A FF               [12] 3104 	mov	r7,a
      00941B 90 0C 17         [24] 3105 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00941E 74 01            [12] 3106 	mov	a,#0x01
      009420 2C               [12] 3107 	add	a,r4
      009421 F0               [24] 3108 	movx	@dptr,a
      009422 E4               [12] 3109 	clr	a
      009423 3F               [12] 3110 	addc	a,r7
      009424 A3               [24] 3111 	inc	dptr
      009425 F0               [24] 3112 	movx	@dptr,a
      009426 7B 00            [12] 3113 	mov	r3,#0x00
      009428 8C 82            [24] 3114 	mov	dpl,r4
      00942A 8F 83            [24] 3115 	mov	dph,r7
      00942C 8B F0            [24] 3116 	mov	b,r3
      00942E 22               [24] 3117 	ret
                                   3118 
                                   3119 	.area CSEG (CODE)
                                   3120 ; function ak820_outline_0043
      00942F                       3121 _ak820_outline_0043:
      00942F 90 0E 94         [24] 3122 	mov	dptr,#_memset_PARM_2
      009432 E4               [12] 3123 	clr	a
      009433 F0               [24] 3124 	movx	@dptr,a
      009434 90 0E 95         [24] 3125 	mov	dptr,#_memset_PARM_3
      009437 74 0A            [12] 3126 	mov	a,#0x0a
      009439 F0               [24] 3127 	movx	@dptr,a
      00943A E4               [12] 3128 	clr	a
      00943B A3               [24] 3129 	inc	dptr
      00943C F0               [24] 3130 	movx	@dptr,a
      00943D 8E 82            [24] 3131 	mov	dpl,r6
      00943F 8F 83            [24] 3132 	mov	dph,r7
      009441 8D F0            [24] 3133 	mov	b,r5
      009443 22               [24] 3134 	ret
                                   3135 
                                   3136 	.area CSEG (CODE)
                                   3137 ; function ak820_outline_0087
      009444                       3138 _ak820_outline_0087:
      009444 ED               [12] 3139 	mov	a,r5
      009445 75 F0 0A         [24] 3140 	mov	b,#0x0a
      009448 A4               [48] 3141 	mul	ab
      009449 24 58            [12] 3142 	add	a,#0x58
      00944B FC               [12] 3143 	mov	r4,a
      00944C 74 06            [12] 3144 	mov	a,#0x06
      00944E 35 F0            [12] 3145 	addc	a,b
      009450 FD               [12] 3146 	mov	r5,a
      009451 22               [24] 3147 	ret
                                   3148 
                                   3149 	.area CSEG (CODE)
                                   3150 ; function ak820_outline_0097
      009452                       3151 _ak820_outline_0097:
      009452 90 0C 1A         [24] 3152 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0001)
      009455 E0               [24] 3153 	movx	a,@dptr
      009456 FF               [12] 3154 	mov	r7,a
      009457 22               [24] 3155 	ret
                                   3156 
                                   3157 	.area CSEG (CODE)
                                   3158 ; function ak820_outline_0101
      009458                       3159 _ak820_outline_0101:
      009458 90 0B 9E         [24] 3160 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00945B EE               [12] 3161 	mov	a,r6
      00945C F0               [24] 3162 	movx	@dptr,a
      00945D 90 0B 9F         [24] 3163 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009460 ED               [12] 3164 	mov	a,r5
      009461 F0               [24] 3165 	movx	@dptr,a
      009462 8F 82            [24] 3166 	mov	dpl,r7
      009464 22               [24] 3167 	ret
                                   3168 
                                   3169 	.area CSEG (CODE)
                                   3170 ; function ak820_outline_0115
      009465                       3171 _ak820_outline_0115:
      009465 74 0A            [12] 3172 	mov	a,#0x0a
      009467 F0               [24] 3173 	movx	@dptr,a
      009468 E4               [12] 3174 	clr	a
      009469 A3               [24] 3175 	inc	dptr
      00946A F0               [24] 3176 	movx	@dptr,a
      00946B 22               [24] 3177 	ret
                                   3178 
                                   3179 	.area CSEG (CODE)
                                   3180 ; function ak820_outline_0122
      00946C                       3181 _ak820_outline_0122:
      00946C AD 82            [24] 3182 	mov	r5,dpl
      00946E AE 83            [24] 3183 	mov	r6,dph
      009470 AF F0            [24] 3184 	mov	r7,b
      009472 22               [24] 3185 	ret
                                   3186 
                                   3187 	.area CSEG (CODE)
                                   3188 ; function ak820_outline_0138
      009473                       3189 _ak820_outline_0138:
      009473 28               [12] 3190 	add	a,r0
      009474 F5 82            [12] 3191 	mov	dpl,a
      009476 EF               [12] 3192 	mov	a,r7
      009477 39               [12] 3193 	addc	a,r1
      009478 F5 83            [12] 3194 	mov	dph,a
      00947A 74 FF            [12] 3195 	mov	a,#0xff
      00947C F0               [24] 3196 	movx	@dptr,a
      00947D 22               [24] 3197 	ret
                                   3198 
                                   3199 	.area CSEG (CODE)
                                   3200 ; function ak820_outline_0144
      00947E                       3201 _ak820_outline_0144:
      00947E 2D               [12] 3202 	add	a,r5
      00947F F9               [12] 3203 	mov	r1,a
      009480 E4               [12] 3204 	clr	a
      009481 3E               [12] 3205 	addc	a,r6
      009482 FA               [12] 3206 	mov	r2,a
      009483 22               [24] 3207 	ret
                                   3208 
                                   3209 	.area CSEG (CODE)
                                   3210 ; function ak820_outline_0159
      009484                       3211 _ak820_outline_0159:
      009484 90 0C 1B         [24] 3212 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      009487 E0               [24] 3213 	movx	a,@dptr
      009488 F5 82            [12] 3214 	mov	dpl,a
      00948A 22               [24] 3215 	ret
                                   3216 
                                   3217 	.area CSEG (CODE)
                                   3218 ; function ak820_outline_0171
      00948B                       3219 _ak820_outline_0171:
      00948B 90 0A 4C         [24] 3220 	mov	dptr,#_ak820_macro_primitive
      00948E E4               [12] 3221 	clr	a
      00948F F0               [24] 3222 	movx	@dptr,a
      009490 22               [24] 3223 	ret
                                   3224 
                                   3225 	.area CSEG (CODE)
                                   3226 ; function ak820_outline_0185
      009491                       3227 _ak820_outline_0185:
      009491 90 0B AE         [24] 3228 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009494 E4               [12] 3229 	clr	a
      009495 F0               [24] 3230 	movx	@dptr,a
      009496 90 0B AF         [24] 3231 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      009499 22               [24] 3232 	ret
                                   3233 
                                   3234 	.area CSEG (CODE)
                                   3235 ; function ak820_outline_0186
      00949A                       3236 _ak820_outline_0186:
      00949A 90 0C 76         [24] 3237 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      00949D E4               [12] 3238 	clr	a
      00949E F0               [24] 3239 	movx	@dptr,a
      00949F 90 0C 77         [24] 3240 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0094A2 22               [24] 3241 	ret
                                   3242 
                                   3243 	.area CSEG (CODE)
                                   3244 ; function ak820_outline_0189
      0094A3                       3245 _ak820_outline_0189:
      0094A3 AF 82            [24] 3246 	mov	r7,dpl
      0094A5 90 0C 1B         [24] 3247 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      0094A8 EF               [12] 3248 	mov	a,r7
      0094A9 F0               [24] 3249 	movx	@dptr,a
      0094AA EF               [12] 3250 	mov	a,r7
      0094AB 22               [24] 3251 	ret
