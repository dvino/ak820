;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module keymap_introspection
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ak820_led_points
	.globl _encoder_map
	.globl _keymaps
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _keycode_at_encodermap_location_raw_PARM_3
	.globl _keycode_at_encodermap_location_raw_PARM_2
	.globl _keycode_at_keymap_location_raw_PARM_3
	.globl _keycode_at_keymap_location_raw_PARM_2
	.globl _keyboard_post_init_user
	.globl _keycode_at_keymap_location_raw
	.globl _keycode_at_encodermap_location_raw
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_keycode_at_keymap_location_raw_PARM_2:
	.ds 1
_keycode_at_keymap_location_raw_PARM_3:
	.ds 1
_keycode_at_keymap_location_raw_layer_num_10000_614:
	.ds 1
_keycode_at_encodermap_location_raw_PARM_2:
	.ds 1
_keycode_at_encodermap_location_raw_PARM_3:
	.ds 1
_keycode_at_encodermap_location_raw_layer_num_10000_622:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function keyboard_post_init_user
;	-----------------------------------------
_keyboard_post_init_user:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'keymap_layer_count_raw'
;------------------------------------------------------------
;	quantum/keymap_introspection.c:20: uint8_t keymap_layer_count_raw(void) {
;	-----------------------------------------
;	 function keycode_at_keymap_location_raw
;	-----------------------------------------
_keycode_at_keymap_location_raw:
	mov	a,dpl
	mov	dptr,#_keycode_at_keymap_location_raw_layer_num_10000_614
	movx	@dptr,a
;	quantum/keymap_introspection.c:37: if (layer_num < NUM_KEYMAP_LAYERS_RAW && row < MATRIX_ROWS && column < MATRIX_COLS) {
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x02,00128$
00128$:
	jnc	00102$
	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x10,00130$
00130$:
	jnc	00102$
	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x08,00132$
00132$:
	jnc	00102$
;	quantum/keymap_introspection.c:38: return pgm_read_word(&keymaps[layer_num][row][column]);
	mov	ar4,r7
	clr	a
	add	a,#_keymaps
	mov	r7,a
	mov	a,r4
	addc	a, #(_keymaps >> 8)
	mov	r4,a
	mov	a,r6
	mov	b,#0x10
	mul	ab
	add	a, r7
	mov	r7,a
	mov	a,r4
	addc	a, b
	mov	r4,a
	mov	a,r5
	add	a,r5
	add	a, r7
	mov	dpl,a
	clr	a
	addc	a, r4
	lcall	_ak820_outline_0088
	ret
00102$:
;	quantum/keymap_introspection.c:40: return KC_TRNS;
	mov	dptr,#0x0001
;	quantum/keymap_introspection.c:41: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'encodermap_layer_count_raw'
;------------------------------------------------------------
;	quantum/keymap_introspection.c:56: uint8_t encodermap_layer_count_raw(void) {
;	-----------------------------------------
;	 function keycode_at_encodermap_location_raw
;	-----------------------------------------
_keycode_at_encodermap_location_raw:
	mov	a,dpl
	mov	dptr,#_keycode_at_encodermap_location_raw_layer_num_10000_622
	movx	@dptr,a
;	quantum/keymap_introspection.c:67: if (layer_num < NUM_ENCODERMAP_LAYERS_RAW && encoder_idx < NUM_ENCODERS) {
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x02,00129$
00129$:
	jnc	00102$
	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00131$
00131$:
	jnc	00102$
;	quantum/keymap_introspection.c:68: return pgm_read_word(&encoder_map[layer_num][encoder_idx][clockwise ? 0 : 1]);
	mov	a,r7
	lcall	_ak820_outline_0195
	add	a, #_encoder_map
	mov	r6,a
	mov	a,#(_encoder_map >> 8)
	addc	a, b
	mov	r7,a
	clr	a
	add	a, r7
	mov	r7,a
	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
	movx	a,@dptr
	jz	00106$
	mov	r4,#0x00
	mov	r5,#0x00
	sjmp	00107$
00106$:
	mov	r4,#0x01
	mov	r5,#0x00
00107$:
	mov	a,r4
	lcall	_ak820_outline_0157
	add	a, r6
	mov	dpl,a
	mov	a,r5
	addc	a, r7
	lcall	_ak820_outline_0088
	ret
00102$:
;	quantum/keymap_introspection.c:70: return KC_TRNS;
	mov	dptr,#0x0001
;	quantum/keymap_introspection.c:71: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_keymaps:
	.byte #0x29, #0x00	; 41
	.byte #0x35, #0x00	; 53
	.byte #0x2b, #0x00	; 43
	.byte #0x39, #0x00	; 57
	.byte #0xe1, #0x00	; 225
	.byte #0xe0, #0x00	; 224
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x3a, #0x00	; 58
	.byte #0x1e, #0x00	; 30
	.byte #0x14, #0x00	; 20
	.byte #0x04, #0x00	; 4
	.byte #0x00, #0x00	; 0
	.byte #0xe3, #0x00	; 227
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x3b, #0x00	; 59
	.byte #0x1f, #0x00	; 31
	.byte #0x1a, #0x00	; 26
	.byte #0x16, #0x00	; 22
	.byte #0x1d, #0x00	; 29
	.byte #0xe2, #0x00	; 226
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x3c, #0x00	; 60
	.byte #0x20, #0x00	; 32
	.byte #0x08, #0x00	; 8
	.byte #0x07, #0x00	; 7
	.byte #0x1b, #0x00	; 27
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x3d, #0x00	; 61
	.byte #0x21, #0x00	; 33
	.byte #0x15, #0x00	; 21
	.byte #0x09, #0x00	; 9
	.byte #0x06, #0x00	; 6
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x3e, #0x00	; 62
	.byte #0x22, #0x00	; 34
	.byte #0x17, #0x00	; 23
	.byte #0x0a, #0x00	; 10
	.byte #0x19, #0x00	; 25
	.byte #0x2c, #0x00	; 44
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x3f, #0x00	; 63
	.byte #0x23, #0x00	; 35
	.byte #0x1c, #0x00	; 28
	.byte #0x0b, #0x00	; 11
	.byte #0x05, #0x00	; 5
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x40, #0x00	; 64
	.byte #0x24, #0x00	; 36
	.byte #0x18, #0x00	; 24
	.byte #0x0d, #0x00	; 13
	.byte #0x11, #0x00	; 17
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x41, #0x00	; 65
	.byte #0x25, #0x00	; 37
	.byte #0x0c, #0x00	; 12
	.byte #0x0e, #0x00	; 14
	.byte #0x10, #0x00	; 16
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x42, #0x00	; 66
	.byte #0x26, #0x00	; 38
	.byte #0x12, #0x00	; 18
	.byte #0x0f, #0x00	; 15
	.byte #0x36, #0x00	; 54
	.byte #0xe6, #0x00	; 230
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x43, #0x00	; 67
	.byte #0x27, #0x00	; 39
	.byte #0x13, #0x00	; 19
	.byte #0x33, #0x00	; 51
	.byte #0x37, #0x00	; 55
	.byte #0x21, #0x52	; 21025
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x44, #0x00	; 68
	.byte #0x2d, #0x00	; 45
	.byte #0x2f, #0x00	; 47
	.byte #0x34, #0x00	; 52
	.byte #0x38, #0x00	; 56
	.byte #0xe4, #0x00	; 228
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x45, #0x00	; 69
	.byte #0x2e, #0x00	; 46
	.byte #0x30, #0x00	; 48
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xae, #0x00	; 174
	.byte #0x2a, #0x00	; 42
	.byte #0x31, #0x00	; 49
	.byte #0x28, #0x00	; 40
	.byte #0xe5, #0x00	; 229
	.byte #0x50, #0x00	; 80
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x4c, #0x00	; 76
	.byte #0x4e, #0x00	; 78
	.byte #0x52, #0x00	; 82
	.byte #0x51, #0x00	; 81
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x4a, #0x00	; 74
	.byte #0x4b, #0x00	; 75
	.byte #0x4d, #0x00	; 77
	.byte #0x00, #0x00	; 0
	.byte #0x4f, #0x00	; 79
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xb3, #0x00	; 179
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xb5, #0x00	; 181
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xb2, #0x00	; 178
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xaf, #0x00	; 175
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xac, #0x00	; 172
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xab, #0x00	; 171
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xae, #0x00	; 174
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xad, #0x00	; 173
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xa8, #0x00	; 168
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xaa, #0x00	; 170
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xa9, #0x00	; 169
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0xa8, #0x00	; 168
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x01, #0x00	; 1
	.byte #0x2a, #0x78	; 30762
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x20, #0x78	; 30752
	.byte #0x23, #0x78	; 30755
	.byte #0x27, #0x78	; 30759
	.byte #0x28, #0x78	; 30760
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.byte #0x21, #0x78	; 30753
	.byte #0x22, #0x78	; 30754
	.byte #0x24, #0x78	; 30756
	.byte #0x00, #0x00	; 0
	.byte #0x29, #0x78	; 30761
	.byte #0x00, #0x00	; 0
	.byte #0x00, #0x00	; 0
	.area CSEG    (CODE)
	.area CONST   (CODE)
_encoder_map:
	.byte #0xa9, #0x00	; 169
	.byte #0xaa, #0x00	; 170
	.byte #0xbb, #0x00	; 187
	.byte #0xbc, #0x00	; 188
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ak820_led_points:
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x19	; 25
	.db #0x00	; 0
	.db #0x27	; 39
	.db #0x00	; 0
	.db #0x35	; 53	'5'
	.db #0x00	; 0
	.db #0x44	; 68	'D'
	.db #0x00	; 0
	.db #0x55	; 85	'U'
	.db #0x00	; 0
	.db #0x64	; 100	'd'
	.db #0x00	; 0
	.db #0x72	; 114	'r'
	.db #0x00	; 0
	.db #0x80	; 128
	.db #0x00	; 0
	.db #0x92	; 146
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x00	; 0
	.db #0xae	; 174
	.db #0x00	; 0
	.db #0xbc	; 188
	.db #0x00	; 0
	.db #0xcb	; 203
	.db #0x00	; 0
	.db #0x07	; 7
	.db #0x0d	; 13
	.db #0x15	; 21
	.db #0x0d	; 13
	.db #0x24	; 36
	.db #0x0d	; 13
	.db #0x32	; 50	'2'
	.db #0x0d	; 13
	.db #0x40	; 64
	.db #0x0d	; 13
	.db #0x4e	; 78	'N'
	.db #0x0d	; 13
	.db #0x5c	; 92
	.db #0x0d	; 13
	.db #0x6b	; 107	'k'
	.db #0x0d	; 13
	.db #0x79	; 121	'y'
	.db #0x0d	; 13
	.db #0x87	; 135
	.db #0x0d	; 13
	.db #0x95	; 149
	.db #0x0d	; 13
	.db #0xa4	; 164
	.db #0x0d	; 13
	.db #0xb2	; 178
	.db #0x0d	; 13
	.db #0xc7	; 199
	.db #0x0d	; 13
	.db #0xe0	; 224
	.db #0x0d	; 13
	.db #0x0b	; 11
	.db #0x1a	; 26
	.db #0x1c	; 28
	.db #0x1a	; 26
	.db #0x2b	; 43
	.db #0x1a	; 26
	.db #0x39	; 57	'9'
	.db #0x1a	; 26
	.db #0x47	; 71	'G'
	.db #0x1a	; 26
	.db #0x55	; 85	'U'
	.db #0x1a	; 26
	.db #0x64	; 100	'd'
	.db #0x1a	; 26
	.db #0x72	; 114	'r'
	.db #0x1a	; 26
	.db #0x80	; 128
	.db #0x1a	; 26
	.db #0x8e	; 142
	.db #0x1a	; 26
	.db #0x9c	; 156
	.db #0x1a	; 26
	.db #0xab	; 171
	.db #0x1a	; 26
	.db #0xb9	; 185
	.db #0x1a	; 26
	.db #0xcb	; 203
	.db #0x1a	; 26
	.db #0xe0	; 224
	.db #0x1a	; 26
	.db #0x0c	; 12
	.db #0x26	; 38
	.db #0x20	; 32
	.db #0x26	; 38
	.db #0x2e	; 46
	.db #0x26	; 38
	.db #0x3c	; 60
	.db #0x26	; 38
	.db #0x4b	; 75	'K'
	.db #0x26	; 38
	.db #0x59	; 89	'Y'
	.db #0x26	; 38
	.db #0x67	; 103	'g'
	.db #0x26	; 38
	.db #0x75	; 117	'u'
	.db #0x26	; 38
	.db #0x84	; 132
	.db #0x26	; 38
	.db #0x92	; 146
	.db #0x26	; 38
	.db #0xa0	; 160
	.db #0x26	; 38
	.db #0xae	; 174
	.db #0x26	; 38
	.db #0xc5	; 197
	.db #0x26	; 38
	.db #0xe0	; 224
	.db #0x26	; 38
	.db #0x10	; 16
	.db #0x33	; 51	'3'
	.db #0x27	; 39
	.db #0x33	; 51	'3'
	.db #0x35	; 53	'5'
	.db #0x33	; 51	'3'
	.db #0x44	; 68	'D'
	.db #0x33	; 51	'3'
	.db #0x52	; 82	'R'
	.db #0x33	; 51	'3'
	.db #0x60	; 96
	.db #0x33	; 51	'3'
	.db #0x6e	; 110	'n'
	.db #0x33	; 51	'3'
	.db #0x7c	; 124
	.db #0x33	; 51	'3'
	.db #0x8b	; 139
	.db #0x33	; 51	'3'
	.db #0x99	; 153
	.db #0x33	; 51	'3'
	.db #0xa7	; 167
	.db #0x33	; 51	'3'
	.db #0xbb	; 187
	.db #0x33	; 51	'3'
	.db #0xd2	; 210
	.db #0x33	; 51	'3'
	.db #0xe0	; 224
	.db #0x33	; 51	'3'
	.db #0x09	; 9
	.db #0x40	; 64
	.db #0x1b	; 27
	.db #0x40	; 64
	.db #0x2c	; 44
	.db #0x40	; 64
	.db #0x62	; 98	'b'
	.db #0x40	; 64
	.db #0x95	; 149
	.db #0x40	; 64
	.db #0xa4	; 164
	.db #0x40	; 64
	.db #0xb2	; 178
	.db #0x40	; 64
	.db #0xc4	; 196
	.db #0x40	; 64
	.db #0xd2	; 210
	.db #0x40	; 64
	.db #0xe0	; 224
	.db #0x40	; 64
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0088
	.globl _ak820_outline_0157
	.globl _ak820_outline_0195

	.area CSEG (CODE)
; function ak820_outline_0088
_ak820_outline_0088:
	mov	dph,a
	clr	a
	movc	a,@a+dptr
	mov	r6,a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	ret
