                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004E                        535 _fast_set_leds_sloc0_1_0:
      00004E                        536 	.ds 2
      000050                        537 _fast_set_leds_sloc1_1_0:
      000050                        538 	.ds 2
      000052                        539 _vialrgb_get_value_sloc0_1_0:
      000052                        540 	.ds 2
      000054                        541 _vialrgb_get_value_sloc1_1_0:
      000054                        542 	.ds 2
      000056                        543 _vialrgb_set_value_sloc0_1_0:
      000056                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000D78                        569 _g_direct_mode_colors::
      000D78                        570 	.ds 246
      000E6E                        571 _get_supported_PARM_2:
      000E6E                        572 	.ds 1
      000E6F                        573 _get_supported_args_10000_255:
      000E6F                        574 	.ds 2
      000E71                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000E71                        576 	.ds 2
      000E73                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000E73                        578 	.ds 2
      000E75                        579 _set_mode_mode_10000_275:
      000E75                        580 	.ds 2
      000E77                        581 _get_matrix_pos_for_led_PARM_2:
      000E77                        582 	.ds 2
      000E79                        583 _get_matrix_pos_for_led_led_10000_280:
      000E79                        584 	.ds 2
      000E7B                        585 _fast_set_leds_PARM_2:
      000E7B                        586 	.ds 1
      000E7C                        587 _fast_set_leds_args_10000_282:
      000E7C                        588 	.ds 2
      000E7E                        589 _fast_set_leds_first_index_10001_285:
      000E7E                        590 	.ds 2
      000E80                        591 _fast_set_leds_num_leds_10001_285:
      000E80                        592 	.ds 1
      000E81                        593 _vialrgb_get_value_PARM_2:
      000E81                        594 	.ds 1
      000E82                        595 _vialrgb_get_value_data_10000_291:
      000E82                        596 	.ds 3
      000E85                        597 _vialrgb_set_value_PARM_2:
      000E85                        598 	.ds 1
      000E86                        599 _vialrgb_set_value_data_10000_302:
      000E86                        600 	.ds 3
      000E89                        601 _vialrgb_save_PARM_2:
      000E89                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B8FC                        654 _get_supported:
      00B8FC 12 38 81         [24]  655 	lcall	_ak820_outline_0111
      00B8FF 90 0E 6F         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B902 12 38 86         [24]  657 	lcall	_ak820_outline_0112
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B905 90 0E 6F         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B908 12 37 ED         [24]  660 	lcall	_ak820_outline_0006
      00B90B E0               [24]  661 	movx	a,@dptr
      00B90C FD               [12]  662 	mov	r5,a
      00B90D 7C 00            [12]  663 	mov	r4,#0x00
      00B90F 12 38 8B         [24]  664 	lcall	_ak820_outline_0117
      00B912 FA               [12]  665 	mov	r2,a
      00B913 E4               [12]  666 	clr	a
      00B914 12 43 69         [24]  667 	lcall	_ak820_outline_0149
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B917 90 0E 6E         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B91A E0               [24]  670 	movx	a,@dptr
      00B91B FB               [12]  671 	mov	r3,a
      00B91C 7A 00            [12]  672 	mov	r2,#0x00
      00B91E                        673 00107$:
      00B91E C3               [12]  674 	clr	c
      00B91F EA               [12]  675 	mov	a,r2
      00B920 9B               [12]  676 	subb	a,r3
      00B921 50 0A            [24]  677 	jnc	00101$
      00B923 EA               [12]  678 	mov	a,r2
      00B924 12 38 1D         [24]  679 	lcall	_ak820_outline_0026
      00B927 74 FF            [12]  680 	mov	a,#0xff
      00B929 F0               [24]  681 	movx	@dptr,a
      00B92A 0A               [12]  682 	inc	r2
      00B92B 80 F1            [24]  683 	sjmp	00107$
      00B92D                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B92D 8D 06            [24]  686 	mov	ar6,r5
      00B92F 8C 07            [24]  687 	mov	ar7,r4
      00B931 8B 05            [24]  688 	mov	ar5,r3
      00B933 90 0E 6F         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B936 12 38 7B         [24]  690 	lcall	_ak820_outline_0107
      00B939 7A 00            [12]  691 	mov	r2,#0x00
      00B93B                        692 00110$:
      00B93B BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B93E                        694 00159$:
      00B93E 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B940 EA               [12]  697 	mov	a,r2
      00B941 75 F0 02         [24]  698 	mov	b,#0x02
      00B944 A4               [48]  699 	mul	ab
      00B945 24 90            [12]  700 	add	a, #_supported_modes
      00B947 F5 82            [12]  701 	mov	dpl,a
      00B949 74 C5            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B94B 12 5C 59         [24]  703 	lcall	_ak820_outline_0113
      00B94E F8               [12]  704 	mov	r0,a
      00B94F 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B951 C3               [12]  707 	clr	c
      00B952 EE               [12]  708 	mov	a,r6
      00B953 98               [12]  709 	subb	a,r0
      00B954 EF               [12]  710 	mov	a,r7
      00B955 99               [12]  711 	subb	a,r1
      00B956 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B958 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B95B                        715 00162$:
      00B95B 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B95D C0 06            [24]  718 	push	ar6
      00B95F C0 07            [24]  719 	push	ar7
      00B961 88 07            [24]  720 	mov	ar7,r0
      00B963 12 33 FC         [24]  721 	lcall	_ak820_outline_0131
      00B966 EF               [12]  722 	mov	a,r7
      00B967 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B968 12 33 FC         [24]  725 	lcall	_ak820_outline_0131
      00B96B A3               [24]  726 	inc	dptr
      00B96C 89 00            [24]  727 	mov	ar0,r1
      00B96E E8               [12]  728 	mov	a,r0
      00B96F F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B970 1D               [12]  731 	dec	r5
      00B971 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B972 74 02            [12]  734 	mov	a,#0x02
      00B974 2B               [12]  735 	add	a, r3
      00B975 FB               [12]  736 	mov	r3,a
      00B976 E4               [12]  737 	clr	a
      00B977 3C               [12]  738 	addc	a, r4
      00B978 FC               [12]  739 	mov	r4,a
      00B979 90 0E 6F         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00B97C 12 38 56         [24]  741 	lcall	_ak820_outline_0084
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B97F D0 07            [24]  743 	pop	ar7
      00B981 D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B983                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B983 0A               [12]  748 	inc	r2
      00B984 80 B5            [24]  749 	sjmp	00110$
      00B986                        750 00127$:
      00B986 90 0E 6F         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00B989 12 38 56         [24]  752 	lcall	_ak820_outline_0084
                                    753 ;	quantum/vialrgb.c:55: }
      00B98C 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00B98D                        766 _qmk_id_to_vialrgb_id:
      00B98D 12 38 81         [24]  767 	lcall	_ak820_outline_0111
      00B990 90 0E 71         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B993 12 38 86         [24]  769 	lcall	_ak820_outline_0112
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B996 90 0E 71         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B999 12 38 2D         [24]  772 	lcall	_ak820_outline_0058
      00B99C 7D 00            [12]  773 	mov	r5,#0x00
      00B99E                        774 00105$:
      00B99E BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00B9A1                        776 00130$:
      00B9A1 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B9A3 12 BD AF         [24]  779 	lcall	_ak820_outline_0053
      00B9A6 A3               [24]  780 	inc	dptr
      00B9A7 E4               [12]  781 	clr	a
      00B9A8 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B9A9 7A 00            [12]  784 	mov	r2,#0x00
      00B9AB B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00B9AE EA               [12]  786 	mov	a,r2
      00B9AF B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B9B2 12 33 FC         [24]  789 	lcall	_ak820_outline_0131
      00B9B5 12 BD DB         [24]  790 	lcall	_ak820_outline_0152
      00B9B8 22               [24]  791 	ret
      00B9B9                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B9B9 0D               [12]  794 	inc	r5
      00B9BA 80 E2            [24]  795 	sjmp	00105$
      00B9BC                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00B9BC 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00B9BF 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00B9C0                        812 _vialrgb_id_to_qmk_id:
      00B9C0 12 38 81         [24]  813 	lcall	_ak820_outline_0111
      00B9C3 90 0E 73         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B9C6 12 38 86         [24]  815 	lcall	_ak820_outline_0112
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B9C9 90 0E 73         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B9CC 12 38 2D         [24]  818 	lcall	_ak820_outline_0058
      00B9CF 7D 00            [12]  819 	mov	r5,#0x00
      00B9D1                        820 00105$:
      00B9D1 BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00B9D4                        822 00130$:
      00B9D4 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B9D6 12 BD AF         [24]  825 	lcall	_ak820_outline_0053
      00B9D9 E4               [12]  826 	clr	a
      00B9DA 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B9DB 7A 00            [12]  829 	mov	r2,#0x00
      00B9DD B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00B9E0 EA               [12]  831 	mov	a,r2
      00B9E1 B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B9E4 12 33 FC         [24]  834 	lcall	_ak820_outline_0131
      00B9E7 A3               [24]  835 	inc	dptr
      00B9E8 12 BD DB         [24]  836 	lcall	_ak820_outline_0152
      00B9EB 22               [24]  837 	ret
      00B9EC                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B9EC 0D               [12]  840 	inc	r5
      00B9ED 80 E2            [24]  841 	sjmp	00105$
      00B9EF                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00B9EF 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00B9F2 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00B9F3                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B9F3 12 5A 5C         [24]  856 	lcall	_rgb_matrix_is_enabled
      00B9F6 E5 82            [12]  857 	mov	a, dpl
      00B9F8 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B9FA 90 00 00         [24]  860 	mov	dptr,#0x0000
      00B9FD 22               [24]  861 	ret
      00B9FE                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B9FE 12 5A 62         [24]  864 	lcall	_rgb_matrix_get_mode
      00BA01 7E 00            [12]  865 	mov	r6,#0x00
      00BA03 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00BA05 21 8D            [12]  868 	ajmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00BA07                        878 _set_mode:
      00BA07 12 38 81         [24]  879 	lcall	_ak820_outline_0111
      00BA0A 90 0E 75         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00BA0D 12 38 86         [24]  881 	lcall	_ak820_outline_0112
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00BA10 90 0E 75         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00BA13 12 38 2D         [24]  884 	lcall	_ak820_outline_0058
      00BA16 90 0E 75         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00BA19 12 48 E2         [24]  886 	lcall	_ak820_outline_0038
      00BA1C 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00BA1E 02 5A AF         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00BA21                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00BA21 C0 07            [24]  892 	push	ar7
      00BA23 C0 06            [24]  893 	push	ar6
      00BA25 12 5A 9E         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00BA28 D0 06            [24]  895 	pop	ar6
      00BA2A D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00BA2C 12 38 92         [24]  898 	lcall	_ak820_outline_0124
      00BA2F 31 C0            [12]  899 	acall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00BA31 02 5A B8         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00BA34                        913 _get_matrix_pos_for_led:
      00BA34 12 38 81         [24]  914 	lcall	_ak820_outline_0111
      00BA37 90 0E 79         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BA3A 12 38 86         [24]  916 	lcall	_ak820_outline_0112
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00BA3D 90 0E 79         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BA40 12 38 2D         [24]  919 	lcall	_ak820_outline_0058
      00BA43 EE               [12]  920 	mov	a,r6
      00BA44 24 97            [12]  921 	add	a, #_ak820_rgb_slots
      00BA46 F5 82            [12]  922 	mov	dpl,a
      00BA48 EF               [12]  923 	mov	a,r7
      00BA49 34 BF            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00BA4B F5 83            [12]  925 	mov	dph,a
      00BA4D E4               [12]  926 	clr	a
      00BA4E 93               [24]  927 	movc	a,@a+dptr
      00BA4F FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00BA50 90 0E 77         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BA53 12 38 5C         [24]  931 	lcall	_ak820_outline_0086
      00BA56 EF               [12]  932 	mov	a,r7
      00BA57 12 5C 8F         [24]  933 	lcall	_ak820_outline_0194
      00BA5A 12 85 B4         [24]  934 	lcall	_ak820_outline_0130
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00BA5D 12 38 B2         [24]  936 	lcall	_ak820_outline_0143
      00BA60 A3               [24]  937 	inc	dptr
      00BA61 53 07 07         [24]  938 	anl	ar7,#0x07
      00BA64 EF               [12]  939 	mov	a,r7
      00BA65 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00BA66 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00BA67                        960 _fast_set_leds:
      00BA67 12 38 81         [24]  961 	lcall	_ak820_outline_0111
      00BA6A 90 0E 7C         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA6D 12 38 86         [24]  963 	lcall	_ak820_outline_0112
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00BA70 90 0E 7B         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00BA73 E0               [24]  966 	movx	a,@dptr
      00BA74 FF               [12]  967 	mov	r7,a
      00BA75 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00BA78                        969 00159$:
      00BA78 50 01            [24]  970 	jnc	00102$
      00BA7A 22               [24]  971 	ret
      00BA7B                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BA7B 90 0E 7C         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA7E 12 38 5C         [24]  975 	lcall	_ak820_outline_0086
      00BA81 12 4E 20         [24]  976 	lcall	_ak820_outline_0081
      00BA84 7B 00            [12]  977 	mov	r3,#0x00
      00BA86 12 38 B2         [24]  978 	lcall	_ak820_outline_0143
      00BA89 A3               [24]  979 	inc	dptr
      00BA8A E0               [24]  980 	movx	a,@dptr
      00BA8B FA               [12]  981 	mov	r2,a
      00BA8C 79 00            [12]  982 	mov	r1,#0x00
      00BA8E 90 0E 7E         [24]  983 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BA91 E9               [12]  984 	mov	a,r1
      00BA92 4C               [12]  985 	orl	a,r4
      00BA93 F0               [24]  986 	movx	@dptr,a
      00BA94 EA               [12]  987 	mov	a,r2
      00BA95 4B               [12]  988 	orl	a,r3
      00BA96 A3               [24]  989 	inc	dptr
      00BA97 F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00BA98 12 38 B2         [24]  992 	lcall	_ak820_outline_0143
      00BA9B A3               [24]  993 	inc	dptr
      00BA9C A3               [24]  994 	inc	dptr
      00BA9D E0               [24]  995 	movx	a,@dptr
      00BA9E 90 0E 80         [24]  996 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BAA1 F0               [24]  997 	movx	@dptr,a
                                    998 ;	quantum/vialrgb.c:119: length -= 3;
      00BAA2 EF               [12]  999 	mov	a,r7
      00BAA3 24 FD            [12] 1000 	add	a,#0xfd
      00BAA5 90 0E 7B         [24] 1001 	mov	dptr,#_fast_set_leds_PARM_2
      00BAA8 F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:120: args += 3;
      00BAA9 90 0E 7C         [24] 1004 	mov	dptr,#_fast_set_leds_args_10000_282
      00BAAC 74 03            [12] 1005 	mov	a,#0x03
      00BAAE 2D               [12] 1006 	add	a, r5
      00BAAF F0               [24] 1007 	movx	@dptr,a
      00BAB0 E4               [12] 1008 	clr	a
      00BAB1 3E               [12] 1009 	addc	a, r6
      00BAB2 A3               [24] 1010 	inc	dptr
      00BAB3 F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00BAB4 90 0E 80         [24] 1013 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BAB7 E0               [24] 1014 	movx	a,@dptr
      00BAB8 FF               [12] 1015 	mov	r7,a
      00BAB9 75 F0 03         [24] 1016 	mov	b,#0x03
      00BABC A4               [48] 1017 	mul	ab
      00BABD FE               [12] 1018 	mov	r6,a
      00BABE AD F0            [24] 1019 	mov	r5,b
      00BAC0 90 0E 7B         [24] 1020 	mov	dptr,#_fast_set_leds_PARM_2
      00BAC3 E0               [24] 1021 	movx	a,@dptr
      00BAC4 FB               [12] 1022 	mov	r3,a
      00BAC5 7C 00            [12] 1023 	mov	r4,#0x00
      00BAC7 C3               [12] 1024 	clr	c
      00BAC8 EB               [12] 1025 	mov	a,r3
      00BAC9 9E               [12] 1026 	subb	a,r6
      00BACA EC               [12] 1027 	mov	a,r4
      00BACB 9D               [12] 1028 	subb	a,r5
      00BACC 40 13            [24] 1029 	jc	00103$
                                   1030 ;	free result
      00BACE 90 0E 7E         [24] 1031 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BAD1 12 38 5C         [24] 1032 	lcall	_ak820_outline_0086
      00BAD4 8D 03            [24] 1033 	mov	ar3,r5
      00BAD6 8E 04            [24] 1034 	mov	ar4,r6
      00BAD8 C3               [12] 1035 	clr	c
      00BAD9 EB               [12] 1036 	mov	a,r3
      00BADA 94 52            [12] 1037 	subb	a,#0x52
      00BADC EC               [12] 1038 	mov	a,r4
      00BADD 94 00            [12] 1039 	subb	a,#0x00
      00BADF 40 01            [24] 1040 	jc	00104$
      00BAE1                       1041 00103$:
      00BAE1 22               [24] 1042 	ret
      00BAE2                       1043 00104$:
                                   1044 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00BAE2 74 52            [12] 1045 	mov	a,#0x52
      00BAE4 C3               [12] 1046 	clr	c
      00BAE5 9D               [12] 1047 	subb	a,r5
      00BAE6 FB               [12] 1048 	mov	r3,a
      00BAE7 E4               [12] 1049 	clr	a
      00BAE8 9E               [12] 1050 	subb	a,r6
      00BAE9 FC               [12] 1051 	mov	r4,a
      00BAEA 7A 00            [12] 1052 	mov	r2,#0x00
      00BAEC C3               [12] 1053 	clr	c
      00BAED EB               [12] 1054 	mov	a,r3
      00BAEE 9F               [12] 1055 	subb	a,r7
      00BAEF EC               [12] 1056 	mov	a,r4
      00BAF0 9A               [12] 1057 	subb	a,r2
      00BAF1 50 08            [24] 1058 	jnc	00127$
                                   1059 ;	free result
      00BAF3 90 0E 80         [24] 1060 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BAF6 74 52            [12] 1061 	mov	a,#0x52
      00BAF8 C3               [12] 1062 	clr	c
      00BAF9 9D               [12] 1063 	subb	a,r5
      00BAFA F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BAFB                       1066 00127$:
      00BAFB 90 0E 80         [24] 1067 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BAFE E0               [24] 1068 	movx	a,@dptr
      00BAFF FF               [12] 1069 	mov	r7,a
      00BB00 90 0E 7E         [24] 1070 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BB03 12 38 5C         [24] 1071 	lcall	_ak820_outline_0086
      00BB06 7C 00            [12] 1072 	mov	r4,#0x00
      00BB08                       1073 00110$:
      00BB08 C3               [12] 1074 	clr	c
      00BB09 EC               [12] 1075 	mov	a,r4
      00BB0A 9F               [12] 1076 	subb	a,r7
      00BB0B 40 01            [24] 1077 	jc	00164$
      00BB0D 22               [24] 1078 	ret
      00BB0E                       1079 00164$:
                                   1080 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00BB0E C0 07            [24] 1081 	push	ar7
      00BB10 90 0E 98         [24] 1082 	mov	dptr,#__mulint_PARM_2
      00BB13 12 43 7F         [24] 1083 	lcall	_ak820_outline_0168
      00BB16 90 00 03         [24] 1084 	mov	dptr,#0x0003
      00BB19 C0 07            [24] 1085 	push	ar7
      00BB1B C0 06            [24] 1086 	push	ar6
      00BB1D C0 05            [24] 1087 	push	ar5
      00BB1F C0 04            [24] 1088 	push	ar4
      00BB21 12 BF 47         [24] 1089 	lcall	__mulint
      00BB24 AA 82            [24] 1090 	mov	r2, dpl
      00BB26 AB 83            [24] 1091 	mov	r3, dph
      00BB28 D0 04            [24] 1092 	pop	ar4
      00BB2A D0 05            [24] 1093 	pop	ar5
      00BB2C D0 06            [24] 1094 	pop	ar6
      00BB2E D0 07            [24] 1095 	pop	ar7
      00BB30 0D               [12] 1096 	inc	r5
      00BB31 BD 00 01         [24] 1097 	cjne	r5,#0x00,00165$
      00BB34 0E               [12] 1098 	inc	r6
      00BB35                       1099 00165$:
      00BB35 EA               [12] 1100 	mov	a,r2
      00BB36 24 78            [12] 1101 	add	a, #_g_direct_mode_colors
      00BB38 FA               [12] 1102 	mov	r2,a
      00BB39 EB               [12] 1103 	mov	a,r3
      00BB3A 34 0D            [12] 1104 	addc	a, #(_g_direct_mode_colors >> 8)
      00BB3C FB               [12] 1105 	mov	r3,a
                                   1106 ;	quantum/vialrgb.c:128: color->h = *args++;
      00BB3D 8A 4E            [24] 1107 	mov	_fast_set_leds_sloc0_1_0,r2
      00BB3F 8B 4F            [24] 1108 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00BB41 12 BD C1         [24] 1109 	lcall	_ak820_outline_0090
      00BB44 F8               [12] 1110 	mov	r0,a
      00BB45 12 BD CF         [24] 1111 	lcall	_ak820_outline_0110
      00BB48 85 4E 82         [24] 1112 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BB4B 85 4F 83         [24] 1113 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BB4E E8               [12] 1114 	mov	a,r0
      00BB4F F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/vialrgb.c:129: color->s = *args++;
      00BB50 74 01            [12] 1117 	mov	a,#0x01
      00BB52 2A               [12] 1118 	add	a, r2
      00BB53 F5 4E            [12] 1119 	mov	_fast_set_leds_sloc0_1_0,a
      00BB55 E4               [12] 1120 	clr	a
      00BB56 3B               [12] 1121 	addc	a, r3
      00BB57 F5 4F            [12] 1122 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00BB59 90 0E 7C         [24] 1123 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB5C E0               [24] 1124 	movx	a,@dptr
      00BB5D F8               [12] 1125 	mov	r0,a
      00BB5E A3               [24] 1126 	inc	dptr
      00BB5F E0               [24] 1127 	movx	a,@dptr
      00BB60 FF               [12] 1128 	mov	r7,a
      00BB61 88 82            [24] 1129 	mov	dpl,r0
      00BB63 8F 83            [24] 1130 	mov	dph,r7
      00BB65 E0               [24] 1131 	movx	a,@dptr
      00BB66 F9               [12] 1132 	mov	r1,a
      00BB67 90 0E 7C         [24] 1133 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB6A 74 01            [12] 1134 	mov	a,#0x01
      00BB6C 28               [12] 1135 	add	a, r0
      00BB6D F0               [24] 1136 	movx	@dptr,a
      00BB6E E4               [12] 1137 	clr	a
      00BB6F 3F               [12] 1138 	addc	a, r7
      00BB70 A3               [24] 1139 	inc	dptr
      00BB71 F0               [24] 1140 	movx	@dptr,a
      00BB72 85 4E 82         [24] 1141 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BB75 85 4F 83         [24] 1142 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BB78 E9               [12] 1143 	mov	a,r1
      00BB79 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00BB7A 12 BD C1         [24] 1146 	lcall	_ak820_outline_0090
      00BB7D F5 4E            [12] 1147 	mov	_fast_set_leds_sloc0_1_0,a
      00BB7F 12 BD CF         [24] 1148 	lcall	_ak820_outline_0110
                                   1149 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BB82 74 02            [12] 1150 	mov	a,#0x02
      00BB84 2A               [12] 1151 	add	a, r2
      00BB85 F5 50            [12] 1152 	mov	_fast_set_leds_sloc1_1_0,a
      00BB87 E4               [12] 1153 	clr	a
      00BB88 3B               [12] 1154 	addc	a, r3
      00BB89 F5 51            [12] 1155 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BB8B C3               [12] 1156 	clr	c
      00BB8C 74 A0            [12] 1157 	mov	a,#0xa0
      00BB8E 95 4E            [12] 1158 	subb	a,_fast_set_leds_sloc0_1_0
      00BB90 D0 07            [24] 1159 	pop	ar7
      00BB92 50 04            [24] 1160 	jnc	00114$
                                   1161 ;	free result
      00BB94 7B A0            [12] 1162 	mov	r3,#0xa0
      00BB96 80 04            [24] 1163 	sjmp	00115$
      00BB98                       1164 00114$:
      00BB98 AA 4E            [24] 1165 	mov	r2,_fast_set_leds_sloc0_1_0
      00BB9A 8A 03            [24] 1166 	mov	ar3,r2
      00BB9C                       1167 00115$:
      00BB9C 85 50 82         [24] 1168 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BB9F 85 51 83         [24] 1169 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BBA2 EB               [12] 1170 	mov	a,r3
      00BBA3 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BBA4 0C               [12] 1173 	inc	r4
                                   1174 ;	quantum/vialrgb.c:133: }
      00BBA5 61 08            [24] 1175 	ajmp	00110$
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1178 ;------------------------------------------------------------
                                   1179 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1180 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1181 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1182 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1183 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1184 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1185 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1186 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function vialrgb_get_value
                                   1191 ;	-----------------------------------------
      00BBA7                       1192 _vialrgb_get_value:
      00BBA7 12 43 1B         [24] 1193 	lcall	_ak820_outline_0041
      00BBAA 90 0E 82         [24] 1194 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BBAD 12 38 15         [24] 1195 	lcall	_ak820_outline_0020
                                   1196 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BBB0 90 0E 81         [24] 1197 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BBB3 E0               [24] 1198 	movx	a,@dptr
      00BBB4 FF               [12] 1199 	mov	r7,a
      00BBB5 BF 20 02         [24] 1200 	cjne	r7,#0x20,00162$
      00BBB8 80 01            [24] 1201 	sjmp	00102$
      00BBBA                       1202 00162$:
      00BBBA 22               [24] 1203 	ret
      00BBBB                       1204 00102$:
                                   1205 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BBBB 90 0E 82         [24] 1206 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BBBE 12 BD 9B         [24] 1207 	lcall	_ak820_outline_0051
                                   1208 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1209 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BBC1 BA 40 02         [24] 1210 	cjne	r2,#0x40,00163$
      00BBC4 80 15            [24] 1211 	sjmp	00103$
      00BBC6                       1212 00163$:
      00BBC6 BA 41 02         [24] 1213 	cjne	r2,#0x41,00164$
      00BBC9 80 23            [24] 1214 	sjmp	00104$
      00BBCB                       1215 00164$:
      00BBCB BA 42 02         [24] 1216 	cjne	r2,#0x42,00165$
      00BBCE 81 7E            [12] 1217 	ajmp	00105$
      00BBD0                       1218 00165$:
      00BBD0 BA 43 02         [24] 1219 	cjne	r2,#0x43,00166$
      00BBD3 81 8A            [12] 1220 	ajmp	00106$
      00BBD5                       1221 00166$:
      00BBD5 BA 44 02         [24] 1222 	cjne	r2,#0x44,00167$
      00BBD8 81 96            [12] 1223 	ajmp	00107$
      00BBDA                       1224 00167$:
      00BBDA 22               [24] 1225 	ret
                                   1226 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BBDB                       1227 00103$:
                                   1228 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BBDB 12 33 FC         [24] 1229 	lcall	_ak820_outline_0131
      00BBDE 74 01            [12] 1230 	mov	a,#0x01
      00BBE0 F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BBE1 12 48 EA         [24] 1233 	lcall	_ak820_outline_0040
      00BBE4 E4               [12] 1234 	clr	a
      00BBE5 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BBE6 12 48 EA         [24] 1237 	lcall	_ak820_outline_0040
      00BBE9 A3               [24] 1238 	inc	dptr
      00BBEA 74 A0            [12] 1239 	mov	a,#0xa0
      00BBEC F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:147: break;
      00BBED 22               [24] 1242 	ret
                                   1243 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BBEE                       1244 00104$:
                                   1245 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BBEE C0 06            [24] 1246 	push	ar6
      00BBF0 C0 05            [24] 1247 	push	ar5
      00BBF2 C0 04            [24] 1248 	push	ar4
      00BBF4 C0 03            [24] 1249 	push	ar3
      00BBF6 31 F3            [12] 1250 	acall	_get_mode
      00BBF8 12 B2 2B         [24] 1251 	lcall	_ak820_outline_0193
      00BBFB D0 03            [24] 1252 	pop	ar3
      00BBFD D0 04            [24] 1253 	pop	ar4
      00BBFF D0 05            [24] 1254 	pop	ar5
      00BC01 D0 06            [24] 1255 	pop	ar6
                                   1256 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BC03 89 00            [24] 1257 	mov	ar0,r1
      00BC05 12 33 FC         [24] 1258 	lcall	_ak820_outline_0131
      00BC08 E8               [12] 1259 	mov	a,r0
      00BC09 F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BC0A 12 48 EA         [24] 1262 	lcall	_ak820_outline_0040
      00BC0D 8A 01            [24] 1263 	mov	ar1,r2
      00BC0F E9               [12] 1264 	mov	a,r1
      00BC10 F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BC11 74 04            [12] 1267 	mov	a,#0x04
      00BC13 12 94 7E         [24] 1268 	lcall	_ak820_outline_0144
      00BC16 C0 06            [24] 1269 	push	ar6
      00BC18 C0 05            [24] 1270 	push	ar5
      00BC1A C0 02            [24] 1271 	push	ar2
      00BC1C C0 01            [24] 1272 	push	ar1
      00BC1E 12 5A 7D         [24] 1273 	lcall	_rgb_matrix_get_speed
      00BC21 A8 82            [24] 1274 	mov	r0, dpl
      00BC23 D0 01            [24] 1275 	pop	ar1
      00BC25 D0 02            [24] 1276 	pop	ar2
      00BC27 D0 05            [24] 1277 	pop	ar5
      00BC29 D0 06            [24] 1278 	pop	ar6
      00BC2B 12 85 8D         [24] 1279 	lcall	_ak820_outline_0068
                                   1280 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BC2E 74 05            [12] 1281 	mov	a,#0x05
      00BC30 12 94 7E         [24] 1282 	lcall	_ak820_outline_0144
      00BC33 C0 06            [24] 1283 	push	ar6
      00BC35 C0 05            [24] 1284 	push	ar5
      00BC37 C0 02            [24] 1285 	push	ar2
      00BC39 C0 01            [24] 1286 	push	ar1
      00BC3B 12 5A 68         [24] 1287 	lcall	_rgb_matrix_get_hue
      00BC3E A8 82            [24] 1288 	mov	r0, dpl
      00BC40 D0 01            [24] 1289 	pop	ar1
      00BC42 D0 02            [24] 1290 	pop	ar2
      00BC44 D0 05            [24] 1291 	pop	ar5
      00BC46 D0 06            [24] 1292 	pop	ar6
      00BC48 12 85 8D         [24] 1293 	lcall	_ak820_outline_0068
                                   1294 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BC4B 74 06            [12] 1295 	mov	a,#0x06
      00BC4D 12 94 7E         [24] 1296 	lcall	_ak820_outline_0144
      00BC50 C0 06            [24] 1297 	push	ar6
      00BC52 C0 05            [24] 1298 	push	ar5
      00BC54 C0 02            [24] 1299 	push	ar2
      00BC56 C0 01            [24] 1300 	push	ar1
      00BC58 12 5A 6F         [24] 1301 	lcall	_rgb_matrix_get_sat
      00BC5B A8 82            [24] 1302 	mov	r0, dpl
      00BC5D D0 01            [24] 1303 	pop	ar1
      00BC5F D0 02            [24] 1304 	pop	ar2
      00BC61 D0 05            [24] 1305 	pop	ar5
      00BC63 D0 06            [24] 1306 	pop	ar6
      00BC65 12 85 8D         [24] 1307 	lcall	_ak820_outline_0068
                                   1308 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BC68 74 07            [12] 1309 	mov	a,#0x07
      00BC6A 12 94 7E         [24] 1310 	lcall	_ak820_outline_0144
      00BC6D C0 02            [24] 1311 	push	ar2
      00BC6F C0 01            [24] 1312 	push	ar1
      00BC71 12 5A 76         [24] 1313 	lcall	_rgb_matrix_get_val
      00BC74 A8 82            [24] 1314 	mov	r0, dpl
      00BC76 D0 01            [24] 1315 	pop	ar1
      00BC78 D0 02            [24] 1316 	pop	ar2
      00BC7A 12 85 8D         [24] 1317 	lcall	_ak820_outline_0068
                                   1318 ;	quantum/vialrgb.c:156: break;
      00BC7D 22               [24] 1319 	ret
                                   1320 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BC7E                       1321 00105$:
                                   1322 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BC7E EF               [12] 1323 	mov	a,r7
      00BC7F 24 FE            [12] 1324 	add	a,#0xfe
      00BC81 90 0E 6E         [24] 1325 	mov	dptr,#_get_supported_PARM_2
      00BC84 F0               [24] 1326 	movx	@dptr,a
      00BC85 12 33 FC         [24] 1327 	lcall	_ak820_outline_0131
                                   1328 ;	quantum/vialrgb.c:160: break;
      00BC88 01 FC            [12] 1329 	ajmp	_get_supported
                                   1330 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BC8A                       1331 00106$:
                                   1332 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BC8A 12 33 FC         [24] 1333 	lcall	_ak820_outline_0131
      00BC8D 74 52            [12] 1334 	mov	a,#0x52
      00BC8F F0               [24] 1335 	movx	@dptr,a
                                   1336 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BC90 12 48 EA         [24] 1337 	lcall	_ak820_outline_0040
      00BC93 E4               [12] 1338 	clr	a
      00BC94 F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:166: break;
      00BC95 22               [24] 1341 	ret
                                   1342 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BC96                       1343 00107$:
                                   1344 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BC96 12 33 FC         [24] 1345 	lcall	_ak820_outline_0131
      00BC99 E0               [24] 1346 	movx	a,@dptr
      00BC9A FF               [12] 1347 	mov	r7,a
      00BC9B 7A 00            [12] 1348 	mov	r2,#0x00
      00BC9D 74 03            [12] 1349 	mov	a,#0x03
      00BC9F 2D               [12] 1350 	add	a, r5
      00BCA0 F8               [12] 1351 	mov	r0,a
      00BCA1 E4               [12] 1352 	clr	a
      00BCA2 3E               [12] 1353 	addc	a, r6
      00BCA3 F9               [12] 1354 	mov	r1,a
      00BCA4 C0 03            [24] 1355 	push	ar3
      00BCA6 C0 04            [24] 1356 	push	ar4
      00BCA8 12 38 9D         [24] 1357 	lcall	_ak820_outline_0129
      00BCAB FB               [12] 1358 	mov	r3,a
      00BCAC E4               [12] 1359 	clr	a
      00BCAD 4F               [12] 1360 	orl	a,r7
      00BCAE F5 52            [12] 1361 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BCB0 EB               [12] 1362 	mov	a,r3
      00BCB1 4A               [12] 1363 	orl	a,r2
      00BCB2 F5 53            [12] 1364 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1365 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BCB4 AC 52            [24] 1366 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BCB6 AF 53            [24] 1367 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BCB8 C3               [12] 1368 	clr	c
      00BCB9 EC               [12] 1369 	mov	a,r4
      00BCBA 94 52            [12] 1370 	subb	a,#0x52
      00BCBC EF               [12] 1371 	mov	a,r7
      00BCBD 94 00            [12] 1372 	subb	a,#0x00
      00BCBF D0 04            [24] 1373 	pop	ar4
      00BCC1 D0 03            [24] 1374 	pop	ar3
      00BCC3 40 01            [24] 1375 	jc	00109$
      00BCC5 22               [24] 1376 	ret
      00BCC6                       1377 00109$:
                                   1378 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BCC6 E5 52            [12] 1379 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BCC8 25 52            [12] 1380 	add	a,_vialrgb_get_value_sloc0_1_0
      00BCCA FA               [12] 1381 	mov	r2,a
      00BCCB E5 53            [12] 1382 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BCCD 33               [12] 1383 	rlc	a
      00BCCE FF               [12] 1384 	mov	r7,a
      00BCCF EA               [12] 1385 	mov	a,r2
      00BCD0 24 51            [12] 1386 	add	a, #_ak820_led_points
      00BCD2 F5 54            [12] 1387 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BCD4 EF               [12] 1388 	mov	a,r7
      00BCD5 34 C2            [12] 1389 	addc	a, #(_ak820_led_points >> 8)
      00BCD7 F5 55            [12] 1390 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BCD9 85 54 82         [24] 1391 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BCDC 85 55 83         [24] 1392 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BCDF E4               [12] 1393 	clr	a
      00BCE0 93               [24] 1394 	movc	a,@a+dptr
      00BCE1 12 33 FC         [24] 1395 	lcall	_ak820_outline_0131
      00BCE4 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BCE5 85 54 82         [24] 1398 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BCE8 85 55 83         [24] 1399 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BCEB A3               [24] 1400 	inc	dptr
      00BCEC E4               [12] 1401 	clr	a
      00BCED 93               [24] 1402 	movc	a,@a+dptr
      00BCEE 12 7C 55         [24] 1403 	lcall	_ak820_outline_0196
      00BCF1 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BCF2 12 48 EA         [24] 1406 	lcall	_ak820_outline_0040
      00BCF5 A3               [24] 1407 	inc	dptr
      00BCF6 74 04            [12] 1408 	mov	a,#0x04
      00BCF8 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BCF9 90 0E 77         [24] 1411 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BCFC 04               [12] 1412 	inc	a
      00BCFD 2D               [12] 1413 	add	a, r5
      00BCFE F0               [24] 1414 	movx	@dptr,a
      00BCFF E4               [12] 1415 	clr	a
      00BD00 3E               [12] 1416 	addc	a, r6
      00BD01 A3               [24] 1417 	inc	dptr
      00BD02 F0               [24] 1418 	movx	@dptr,a
      00BD03 85 52 82         [24] 1419 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BD06 85 53 83         [24] 1420 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1421 ;	quantum/vialrgb.c:187: }
                                   1422 ;	quantum/vialrgb.c:188: }
      00BD09 41 34            [24] 1423 	ajmp	_get_matrix_pos_for_led
                                   1424 ;------------------------------------------------------------
                                   1425 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1426 ;------------------------------------------------------------
                                   1427 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1428 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1429 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1430 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1431 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1432 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1433 ;------------------------------------------------------------
                                   1434 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1435 ;	-----------------------------------------
                                   1436 ;	 function vialrgb_set_value
                                   1437 ;	-----------------------------------------
      00BD0B                       1438 _vialrgb_set_value:
      00BD0B 12 43 1B         [24] 1439 	lcall	_ak820_outline_0041
      00BD0E 90 0E 86         [24] 1440 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BD11 12 38 15         [24] 1441 	lcall	_ak820_outline_0020
                                   1442 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BD14 90 0E 85         [24] 1443 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BD17 E0               [24] 1444 	movx	a,@dptr
      00BD18 FF               [12] 1445 	mov	r7,a
      00BD19 BF 20 02         [24] 1446 	cjne	r7,#0x20,00129$
      00BD1C 80 01            [24] 1447 	sjmp	00102$
      00BD1E                       1448 00129$:
      00BD1E 22               [24] 1449 	ret
      00BD1F                       1450 00102$:
                                   1451 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BD1F 90 0E 86         [24] 1452 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BD22 12 BD 9B         [24] 1453 	lcall	_ak820_outline_0051
                                   1454 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1455 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BD25 BA 41 02         [24] 1456 	cjne	r2,#0x41,00130$
      00BD28 80 06            [24] 1457 	sjmp	00103$
      00BD2A                       1458 00130$:
      00BD2A BA 42 02         [24] 1459 	cjne	r2,#0x42,00131$
      00BD2D 80 5D            [24] 1460 	sjmp	00104$
      00BD2F                       1461 00131$:
      00BD2F 22               [24] 1462 	ret
                                   1463 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BD30                       1464 00103$:
                                   1465 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BD30 12 33 FC         [24] 1466 	lcall	_ak820_outline_0131
      00BD33 E0               [24] 1467 	movx	a,@dptr
      00BD34 FA               [12] 1468 	mov	r2,a
      00BD35 12 48 EA         [24] 1469 	lcall	_ak820_outline_0040
      00BD38 E0               [24] 1470 	movx	a,@dptr
      00BD39 F8               [12] 1471 	mov	r0,a
      00BD3A 79 00            [12] 1472 	mov	r1,#0x00
      00BD3C 88 57            [24] 1473 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BD3E 89 56            [24] 1474 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BD40 8A 01            [24] 1475 	mov	ar1,r2
      00BD42 7A 00            [12] 1476 	mov	r2,#0x00
      00BD44 E5 57            [12] 1477 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BD46 42 02            [12] 1478 	orl	ar2,a
                                   1479 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BD48 12 43 85         [24] 1480 	lcall	_ak820_outline_0177
      00BD4B C0 06            [24] 1481 	push	ar6
      00BD4D C0 05            [24] 1482 	push	ar5
      00BD4F 51 07            [24] 1483 	acall	_set_mode
      00BD51 D0 05            [24] 1484 	pop	ar5
      00BD53 D0 06            [24] 1485 	pop	ar6
                                   1486 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BD55 12 48 EA         [24] 1487 	lcall	_ak820_outline_0040
      00BD58 A3               [24] 1488 	inc	dptr
      00BD59 E0               [24] 1489 	movx	a,@dptr
      00BD5A F5 82            [12] 1490 	mov	dpl,a
      00BD5C C0 06            [24] 1491 	push	ar6
      00BD5E C0 05            [24] 1492 	push	ar5
      00BD60 12 5B 49         [24] 1493 	lcall	_rgb_matrix_set_speed_noeeprom
      00BD63 D0 05            [24] 1494 	pop	ar5
      00BD65 D0 06            [24] 1495 	pop	ar6
                                   1496 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BD67 12 48 EA         [24] 1497 	lcall	_ak820_outline_0040
      00BD6A A3               [24] 1498 	inc	dptr
      00BD6B A3               [24] 1499 	inc	dptr
      00BD6C E0               [24] 1500 	movx	a,@dptr
      00BD6D F9               [12] 1501 	mov	r1,a
      00BD6E 7A 00            [12] 1502 	mov	r2,#0x00
      00BD70 74 06            [12] 1503 	mov	a,#0x06
      00BD72 12 BD E5         [24] 1504 	lcall	_ak820_outline_0180
      00BD75 F8               [12] 1505 	mov	r0,a
      00BD76 74 07            [12] 1506 	mov	a,#0x07
      00BD78 12 BD E5         [24] 1507 	lcall	_ak820_outline_0180
      00BD7B FE               [12] 1508 	mov	r6,a
      00BD7C 90 07 F9         [24] 1509 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BD7F E8               [12] 1510 	mov	a,r0
      00BD80 F0               [24] 1511 	movx	@dptr,a
      00BD81 90 07 FA         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BD84 EE               [12] 1513 	mov	a,r6
      00BD85 F0               [24] 1514 	movx	@dptr,a
      00BD86 12 43 85         [24] 1515 	lcall	_ak820_outline_0177
                                   1516 ;	quantum/vialrgb.c:202: break;
                                   1517 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BD89 02 5B 1A         [24] 1518 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BD8C                       1519 00104$:
                                   1520 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BD8C EF               [12] 1521 	mov	a,r7
      00BD8D 24 FE            [12] 1522 	add	a,#0xfe
      00BD8F 90 0E 7B         [24] 1523 	mov	dptr,#_fast_set_leds_PARM_2
      00BD92 F0               [24] 1524 	movx	@dptr,a
      00BD93 12 33 FC         [24] 1525 	lcall	_ak820_outline_0131
                                   1526 ;	quantum/vialrgb.c:210: }
                                   1527 ;	quantum/vialrgb.c:211: }
      00BD96 41 67            [24] 1528 	ajmp	_fast_set_leds
                                   1529 ;------------------------------------------------------------
                                   1530 ;Allocation info for local variables in function 'vialrgb_save'
                                   1531 ;------------------------------------------------------------
                                   1532 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1533 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1534 ;------------------------------------------------------------
                                   1535 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1536 ;	-----------------------------------------
                                   1537 ;	 function vialrgb_save
                                   1538 ;	-----------------------------------------
      00BD98                       1539 _vialrgb_save:
                                   1540 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1541 ;	quantum/vialrgb.c:218: }
      00BD98 02 55 9D         [24] 1542 	ljmp	_eeconfig_update_rgb_matrix
                                   1543 	.area CSEG    (CODE)
                                   1544 	.area CONST   (CODE)
                                   1545 	.area CONST   (CODE)
      00C590                       1546 _supported_modes:
      00C590 00                    1547 	.db #0x00	; 0
      00C591 00                    1548 	.db #0x00	; 0
      00C592 01                    1549 	.db #0x01	; 1
      00C593 05                    1550 	.db #0x05	; 5
      00C594 02                    1551 	.db #0x02	; 2
      00C595 01                    1552 	.db #0x01	; 1
      00C596 06                    1553 	.db #0x06	; 6
      00C597 02                    1554 	.db #0x02	; 2
      00C598 0D                    1555 	.db #0x0d	; 13
      00C599 03                    1556 	.db #0x03	; 3
      00C59A 0E                    1557 	.db #0x0e	; 14
      00C59B 04                    1558 	.db #0x04	; 4
      00C59C 1F                    1559 	.db #0x1f	; 31
      00C59D 06                    1560 	.db #0x06	; 6
                                   1561 	.area CSEG    (CODE)
                                   1562 	.area XINIT   (CODE)
                                   1563 	.area CABS    (ABS,CODE)
                                   1564 
                                   1565 ; Experimental exact instruction outlining.
                                   1566 	.globl _ak820_outline_0006
                                   1567 	.globl _ak820_outline_0020
                                   1568 	.globl _ak820_outline_0026
                                   1569 	.globl _ak820_outline_0038
                                   1570 	.globl _ak820_outline_0040
                                   1571 	.globl _ak820_outline_0041
                                   1572 	.globl _ak820_outline_0051
                                   1573 	.globl _ak820_outline_0053
                                   1574 	.globl _ak820_outline_0058
                                   1575 	.globl _ak820_outline_0068
                                   1576 	.globl _ak820_outline_0081
                                   1577 	.globl _ak820_outline_0084
                                   1578 	.globl _ak820_outline_0086
                                   1579 	.globl _ak820_outline_0090
                                   1580 	.globl _ak820_outline_0107
                                   1581 	.globl _ak820_outline_0110
                                   1582 	.globl _ak820_outline_0111
                                   1583 	.globl _ak820_outline_0112
                                   1584 	.globl _ak820_outline_0113
                                   1585 	.globl _ak820_outline_0117
                                   1586 	.globl _ak820_outline_0124
                                   1587 	.globl _ak820_outline_0129
                                   1588 	.globl _ak820_outline_0130
                                   1589 	.globl _ak820_outline_0131
                                   1590 	.globl _ak820_outline_0143
                                   1591 	.globl _ak820_outline_0144
                                   1592 	.globl _ak820_outline_0149
                                   1593 	.globl _ak820_outline_0152
                                   1594 	.globl _ak820_outline_0168
                                   1595 	.globl _ak820_outline_0177
                                   1596 	.globl _ak820_outline_0180
                                   1597 	.globl _ak820_outline_0193
                                   1598 	.globl _ak820_outline_0194
                                   1599 	.globl _ak820_outline_0196
                                   1600 
                                   1601 	.area CSEG (CODE)
                                   1602 ; function ak820_outline_0051
      00BD9B                       1603 _ak820_outline_0051:
      00BD9B E0               [24] 1604 	movx	a,@dptr
      00BD9C FD               [12] 1605 	mov	r5,a
      00BD9D A3               [24] 1606 	inc	dptr
      00BD9E E0               [24] 1607 	movx	a,@dptr
      00BD9F FE               [12] 1608 	mov	r6,a
      00BDA0 74 02            [12] 1609 	mov	a,#0x02
      00BDA2 2D               [12] 1610 	add	a,r5
      00BDA3 FB               [12] 1611 	mov	r3,a
      00BDA4 E4               [12] 1612 	clr	a
      00BDA5 3E               [12] 1613 	addc	a,r6
      00BDA6 FC               [12] 1614 	mov	r4,a
      00BDA7 8D 82            [24] 1615 	mov	dpl,r5
      00BDA9 8E 83            [24] 1616 	mov	dph,r6
      00BDAB A3               [24] 1617 	inc	dptr
      00BDAC E0               [24] 1618 	movx	a,@dptr
      00BDAD FA               [12] 1619 	mov	r2,a
      00BDAE 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0053
      00BDAF                       1624 _ak820_outline_0053:
      00BDAF ED               [12] 1625 	mov	a,r5
      00BDB0 75 F0 02         [24] 1626 	mov	b,#0x02
      00BDB3 A4               [48] 1627 	mul	ab
      00BDB4 24 90            [12] 1628 	add	a,#_supported_modes
      00BDB6 FB               [12] 1629 	mov	r3,a
      00BDB7 74 C5            [12] 1630 	mov	a,#(_supported_modes>>8)
      00BDB9 35 F0            [12] 1631 	addc	a,b
      00BDBB FC               [12] 1632 	mov	r4,a
      00BDBC 8B 82            [24] 1633 	mov	dpl,r3
      00BDBE 8C 83            [24] 1634 	mov	dph,r4
      00BDC0 22               [24] 1635 	ret
                                   1636 
                                   1637 	.area CSEG (CODE)
                                   1638 ; function ak820_outline_0090
      00BDC1                       1639 _ak820_outline_0090:
      00BDC1 90 0E 7C         [24] 1640 	mov	dptr,#_fast_set_leds_args_10000_282
      00BDC4 E0               [24] 1641 	movx	a,@dptr
      00BDC5 F9               [12] 1642 	mov	r1,a
      00BDC6 A3               [24] 1643 	inc	dptr
      00BDC7 E0               [24] 1644 	movx	a,@dptr
      00BDC8 FF               [12] 1645 	mov	r7,a
      00BDC9 89 82            [24] 1646 	mov	dpl,r1
      00BDCB 8F 83            [24] 1647 	mov	dph,r7
      00BDCD E0               [24] 1648 	movx	a,@dptr
      00BDCE 22               [24] 1649 	ret
                                   1650 
                                   1651 	.area CSEG (CODE)
                                   1652 ; function ak820_outline_0110
      00BDCF                       1653 _ak820_outline_0110:
      00BDCF 90 0E 7C         [24] 1654 	mov	dptr,#_fast_set_leds_args_10000_282
      00BDD2 74 01            [12] 1655 	mov	a,#0x01
      00BDD4 29               [12] 1656 	add	a,r1
      00BDD5 F0               [24] 1657 	movx	@dptr,a
      00BDD6 E4               [12] 1658 	clr	a
      00BDD7 3F               [12] 1659 	addc	a,r7
      00BDD8 A3               [24] 1660 	inc	dptr
      00BDD9 F0               [24] 1661 	movx	@dptr,a
      00BDDA 22               [24] 1662 	ret
                                   1663 
                                   1664 	.area CSEG (CODE)
                                   1665 ; function ak820_outline_0152
      00BDDB                       1666 _ak820_outline_0152:
      00BDDB E4               [12] 1667 	clr	a
      00BDDC 93               [24] 1668 	movc	a,@a+dptr
      00BDDD FC               [12] 1669 	mov	r4,a
      00BDDE 7B 00            [12] 1670 	mov	r3,#0x00
      00BDE0 8C 82            [24] 1671 	mov	dpl,r4
      00BDE2 8B 83            [24] 1672 	mov	dph,r3
      00BDE4 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0180
      00BDE5                       1677 _ak820_outline_0180:
      00BDE5 2D               [12] 1678 	add	a,r5
      00BDE6 F5 82            [12] 1679 	mov	dpl,a
      00BDE8 E4               [12] 1680 	clr	a
      00BDE9 3E               [12] 1681 	addc	a,r6
      00BDEA F5 83            [12] 1682 	mov	dph,a
      00BDEC E0               [24] 1683 	movx	a,@dptr
      00BDED 22               [24] 1684 	ret
