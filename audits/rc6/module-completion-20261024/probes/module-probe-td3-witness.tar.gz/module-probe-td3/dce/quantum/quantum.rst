                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_tap_dance_process
                                     18 	.globl _process_repeat_key
                                     19 	.globl _process_last_key
                                     20 	.globl _process_caps_word
                                     21 	.globl _process_record_via
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _post_process_record_user_PARM_2
                                    283 	.globl _post_process_record_kb_PARM_2
                                    284 	.globl _process_record_user_PARM_2
                                    285 	.globl _process_record_kb_PARM_2
                                    286 	.globl _pre_process_record_user_PARM_2
                                    287 	.globl _pre_process_record_kb_PARM_2
                                    288 	.globl _register_code16
                                    289 	.globl _unregister_code16
                                    290 	.globl _pre_process_record_kb
                                    291 	.globl _pre_process_record_user
                                    292 	.globl _process_action_kb
                                    293 	.globl _process_record_kb
                                    294 	.globl _process_record_user
                                    295 	.globl _post_process_record_kb
                                    296 	.globl _post_process_record_user
                                    297 	.globl _reset_keyboard
                                    298 	.globl _soft_reset_keyboard
                                    299 	.globl _get_record_keycode
                                    300 	.globl _pre_process_record_quantum
                                    301 	.globl _post_process_record_quantum
                                    302 	.globl _process_record_quantum
                                    303 	.globl _process_record_quantum_helper
                                    304 	.globl _shutdown_user
                                    305 ;--------------------------------------------------------
                                    306 ; special function registers
                                    307 ;--------------------------------------------------------
                                    308 	.area RSEG    (ABS,DATA)
      000000                        309 	.org 0x0000
                           0000D0   310 _PSW	=	0x00d0
                           0000E0   311 _ACC	=	0x00e0
                           0000F0   312 _B	=	0x00f0
                           0000FD   313 _A_INV	=	0x00fd
                           000081   314 _SP	=	0x0081
                           000082   315 _DPL	=	0x0082
                           000083   316 _DPH	=	0x0083
                           0000A1   317 _SAFE_MOD	=	0x00a1
                           0000B1   318 _GLOBAL_CFG	=	0x00b1
                           000087   319 _PCON	=	0x0087
                           0000BA   320 _POWER_CFG	=	0x00ba
                           0000B9   321 _CLOCK_CFG	=	0x00b9
                           0000A9   322 _WAKE_CTRL	=	0x00a9
                           0000FE   323 _RESET_KEEP	=	0x00fe
                           0000FF   324 _WDOG_COUNT	=	0x00ff
                           0000A8   325 _IE	=	0x00a8
                           0000B8   326 _IP	=	0x00b8
                           0000E8   327 _IE_EX	=	0x00e8
                           0000E9   328 _IP_EX	=	0x00e9
                           0000B2   329 _GPIO_IE	=	0x00b2
                           008584   330 _ROM_ADDR	=	0x8584
                           000084   331 _ROM_ADDR_L	=	0x0084
                           000085   332 _ROM_ADDR_H	=	0x0085
                           008F8E   333 _ROM_DATA_HI	=	0x8f8e
                           00008E   334 _ROM_DATA_HL	=	0x008e
                           00008F   335 _ROM_DATA_HH	=	0x008f
                           000086   336 _ROM_CTRL	=	0x0086
                           000080   337 _P0	=	0x0080
                           0000C4   338 _P0_MOD_OC	=	0x00c4
                           0000C5   339 _P0_DIR_PU	=	0x00c5
                           000090   340 _P1	=	0x0090
                           000092   341 _P1_MOD_OC	=	0x0092
                           000093   342 _P1_DIR_PU	=	0x0093
                           0000A0   343 _P2	=	0x00a0
                           000094   344 _P2_MOD_OC	=	0x0094
                           000095   345 _P2_DIR_PU	=	0x0095
                           0000B0   346 _P3	=	0x00b0
                           000096   347 _P3_MOD_OC	=	0x0096
                           000097   348 _P3_DIR_PU	=	0x0097
                           0000C0   349 _P4	=	0x00c0
                           0000C2   350 _P4_MOD_OC	=	0x00c2
                           0000C3   351 _P4_DIR_PU	=	0x00c3
                           0000C1   352 _P4_LED_KEY	=	0x00c1
                           0000AA   353 _P5_IN	=	0x00aa
                           0000AB   354 _P5_OUT_PU	=	0x00ab
                           0000AC   355 _P5_DIR	=	0x00ac
                           0000AD   356 _P6_IN	=	0x00ad
                           0000AE   357 _P6_OUT_PU	=	0x00ae
                           0000AF   358 _P6_DIR	=	0x00af
                           0000F1   359 _P7	=	0x00f1
                           0000A2   360 _XBUS_AUX	=	0x00a2
                           000088   361 _TCON	=	0x0088
                           000089   362 _TMOD	=	0x0089
                           00008A   363 _TL0	=	0x008a
                           00008B   364 _TL1	=	0x008b
                           00008C   365 _TH0	=	0x008c
                           00008D   366 _TH1	=	0x008d
                           000098   367 _SCON	=	0x0098
                           000099   368 _SBUF	=	0x0099
                           0000C8   369 _T2CON	=	0x00c8
                           0000C9   370 _T2MOD	=	0x00c9
                           00CBCA   371 _RCAP2	=	0xcbca
                           0000CA   372 _RCAP2L	=	0x00ca
                           0000CB   373 _RCAP2H	=	0x00cb
                           00CDCC   374 _T2COUNT	=	0xcdcc
                           0000CC   375 _TL2	=	0x00cc
                           0000CD   376 _TH2	=	0x00cd
                           00CFCE   377 _T2CAP1	=	0xcfce
                           0000CE   378 _T2CAP1L	=	0x00ce
                           0000CF   379 _T2CAP1H	=	0x00cf
                           0000F8   380 _SPI0_STAT	=	0x00f8
                           0000F9   381 _SPI0_DATA	=	0x00f9
                           0000FA   382 _SPI0_CTRL	=	0x00fa
                           0000FB   383 _SPI0_CK_SE	=	0x00fb
                           0000FC   384 _SPI0_SETUP	=	0x00fc
                           0000BC   385 _SCON1	=	0x00bc
                           0000BD   386 _SBUF1	=	0x00bd
                           0000BE   387 _SBAUD1	=	0x00be
                           0000BF   388 _SIF1	=	0x00bf
                           0000B4   389 _SPI1_STAT	=	0x00b4
                           0000B5   390 _SPI1_DATA	=	0x00b5
                           0000B6   391 _SPI1_CTRL	=	0x00b6
                           0000B7   392 _SPI1_CK_SE	=	0x00b7
                           0000F3   393 _ADC_CTRL	=	0x00f3
                           00F5F4   394 _ADC_DAT	=	0xf5f4
                           0000F4   395 _ADC_DAT_L	=	0x00f4
                           0000F5   396 _ADC_DAT_H	=	0x00f5
                           0000F6   397 _ADC_CHAN	=	0x00f6
                           0000A6   398 _LED_COMMON	=	0x00a6
                           0000A7   399 _LED_PWM_OE	=	0x00a7
                           00C7C6   400 _LED_DMA	=	0xc7c6
                           0000C6   401 _LED_DMA_L	=	0x00c6
                           0000C7   402 _LED_DMA_H	=	0x00c7
                           0000F7   403 _LED_STATUS	=	0x00f7
                           0000B3   404 _I2CX_INT	=	0x00b3
                           0000BB   405 _I2CS_INT_ST	=	0x00bb
                                    406 ;--------------------------------------------------------
                                    407 ; special function bits
                                    408 ;--------------------------------------------------------
                                    409 	.area RSEG    (ABS,DATA)
      000000                        410 	.org 0x0000
                           0000D7   411 _CY	=	0x00d7
                           0000D6   412 _AC	=	0x00d6
                           0000D5   413 _F0	=	0x00d5
                           0000D4   414 _RS1	=	0x00d4
                           0000D3   415 _RS0	=	0x00d3
                           0000D2   416 _OV	=	0x00d2
                           0000D1   417 _F1	=	0x00d1
                           0000D0   418 _P	=	0x00d0
                           0000AF   419 _EA	=	0x00af
                           0000AE   420 _E_DIS	=	0x00ae
                           0000AD   421 _ET2	=	0x00ad
                           0000AC   422 _ES	=	0x00ac
                           0000AB   423 _ET1	=	0x00ab
                           0000AA   424 _EX1	=	0x00aa
                           0000A9   425 _ET0	=	0x00a9
                           0000A8   426 _EX0	=	0x00a8
                           0000BF   427 _PH_FLAG	=	0x00bf
                           0000BE   428 _PL_FLAG	=	0x00be
                           0000BD   429 _PT2	=	0x00bd
                           0000BC   430 _PS	=	0x00bc
                           0000BB   431 _PT1	=	0x00bb
                           0000BA   432 _PX1	=	0x00ba
                           0000B9   433 _PT0	=	0x00b9
                           0000B8   434 _PX0	=	0x00b8
                           0000EF   435 _IE_WDOG	=	0x00ef
                           0000EE   436 _IE_GPIO	=	0x00ee
                           0000ED   437 _IE_PWM_I2C	=	0x00ed
                           0000EC   438 _IE_UART1	=	0x00ec
                           0000EB   439 _IE_ADC	=	0x00eb
                           0000E9   440 _IE_USB	=	0x00e9
                           0000E8   441 _IE_SPI0	=	0x00e8
                           000087   442 _P0_7	=	0x0087
                           000086   443 _P0_6	=	0x0086
                           000085   444 _P0_5	=	0x0085
                           000084   445 _P0_4	=	0x0084
                           000083   446 _P0_3	=	0x0083
                           000082   447 _P0_2	=	0x0082
                           000081   448 _P0_1	=	0x0081
                           000080   449 _P0_0	=	0x0080
                           000081   450 _SDA0	=	0x0081
                           000080   451 _SCL0	=	0x0080
                           000083   452 _TXD_	=	0x0083
                           000082   453 _RXD_	=	0x0082
                           000085   454 _AIN13	=	0x0085
                           000084   455 _AIN12	=	0x0084
                           000083   456 _AIN11	=	0x0083
                           000082   457 _AIN10	=	0x0082
                           000081   458 _AIN9	=	0x0081
                           000080   459 _AIN8	=	0x0080
                           000097   460 _P1_7	=	0x0097
                           000096   461 _P1_6	=	0x0096
                           000095   462 _P1_5	=	0x0095
                           000094   463 _P1_4	=	0x0094
                           000093   464 _P1_3	=	0x0093
                           000092   465 _P1_2	=	0x0092
                           000091   466 _P1_1	=	0x0091
                           000090   467 _P1_0	=	0x0090
                           000097   468 _TXD1_	=	0x0097
                           000096   469 _RXD1_	=	0x0096
                           000097   470 _SCK	=	0x0097
                           000096   471 _MISO	=	0x0096
                           000095   472 _MOSI	=	0x0095
                           000094   473 _SCS	=	0x0094
                           000092   474 _INT0_	=	0x0092
                           000091   475 _T2EX	=	0x0091
                           000091   476 _CAP2	=	0x0091
                           000090   477 _T2	=	0x0090
                           000090   478 _CAP1	=	0x0090
                           000097   479 _AIN7	=	0x0097
                           000096   480 _AIN6	=	0x0096
                           000095   481 _AIN5	=	0x0095
                           000094   482 _AIN4	=	0x0094
                           000093   483 _AIN3	=	0x0093
                           000092   484 _AIN2	=	0x0092
                           000091   485 _AIN1	=	0x0091
                           000090   486 _AIN0	=	0x0090
                           0000A7   487 _P2_7	=	0x00a7
                           0000A6   488 _P2_6	=	0x00a6
                           0000A5   489 _P2_5	=	0x00a5
                           0000A4   490 _P2_4	=	0x00a4
                           0000A3   491 _P2_3	=	0x00a3
                           0000A2   492 _P2_2	=	0x00a2
                           0000A1   493 _P2_1	=	0x00a1
                           0000A0   494 _P2_0	=	0x00a0
                           0000A7   495 _TXD1	=	0x00a7
                           0000A6   496 _RXD1	=	0x00a6
                           0000A5   497 _T2EX_	=	0x00a5
                           0000A5   498 _CAP2_	=	0x00a5
                           0000A4   499 _T2_	=	0x00a4
                           0000A4   500 _CAP1_	=	0x00a4
                           0000B7   501 _P3_7	=	0x00b7
                           0000B6   502 _P3_6	=	0x00b6
                           0000B5   503 _P3_5	=	0x00b5
                           0000B4   504 _P3_4	=	0x00b4
                           0000B3   505 _P3_3	=	0x00b3
                           0000B2   506 _P3_2	=	0x00b2
                           0000B1   507 _P3_1	=	0x00b1
                           0000B0   508 _P3_0	=	0x00b0
                           0000B7   509 _SCK1	=	0x00b7
                           0000B6   510 _MISO1	=	0x00b6
                           0000B5   511 _MOSI1	=	0x00b5
                           0000B5   512 _T1	=	0x00b5
                           0000B4   513 _T0	=	0x00b4
                           0000B3   514 _INT1	=	0x00b3
                           0000B2   515 _INT0	=	0x00b2
                           0000B1   516 _TXD	=	0x00b1
                           0000B0   517 _RXD	=	0x00b0
                           0000C6   518 _P4_6	=	0x00c6
                           0000C5   519 _P4_5	=	0x00c5
                           0000C4   520 _P4_4	=	0x00c4
                           0000C3   521 _P4_3	=	0x00c3
                           0000C2   522 _P4_2	=	0x00c2
                           0000C1   523 _P4_1	=	0x00c1
                           0000C0   524 _P4_0	=	0x00c0
                           00008F   525 _TF1	=	0x008f
                           00008E   526 _TR1	=	0x008e
                           00008D   527 _TF0	=	0x008d
                           00008C   528 _TR0	=	0x008c
                           00008B   529 _IE1	=	0x008b
                           00008A   530 _IT1	=	0x008a
                           000089   531 _IE0	=	0x0089
                           000088   532 _IT0	=	0x0088
                           00009F   533 _SM0	=	0x009f
                           00009E   534 _SM1	=	0x009e
                           00009D   535 _SM2	=	0x009d
                           00009C   536 _REN	=	0x009c
                           00009B   537 _TB8	=	0x009b
                           00009A   538 _RB8	=	0x009a
                           000099   539 _TI	=	0x0099
                           000098   540 _RI	=	0x0098
                           0000CF   541 _TF2	=	0x00cf
                           0000CF   542 _CAP1F	=	0x00cf
                           0000CE   543 _EXF2	=	0x00ce
                           0000CD   544 _RCLK	=	0x00cd
                           0000CC   545 _TCLK	=	0x00cc
                           0000CB   546 _EXEN2	=	0x00cb
                           0000CA   547 _TR2	=	0x00ca
                           0000C9   548 _C_T2	=	0x00c9
                           0000C8   549 _CP_RL2	=	0x00c8
                           0000FF   550 _S0_FST_ACT	=	0x00ff
                           0000FE   551 _S0_IF_OV	=	0x00fe
                           0000FD   552 _S0_IF_FIRST	=	0x00fd
                           0000FC   553 _S0_IF_BYTE	=	0x00fc
                           0000FB   554 _S0_FREE	=	0x00fb
                           0000FA   555 _S0_T_FIFO	=	0x00fa
                           0000F8   556 _S0_R_FIFO	=	0x00f8
                           0000F7   557 _ADC_START	=	0x00f7
                                    558 ;--------------------------------------------------------
                                    559 ; overlayable register banks
                                    560 ;--------------------------------------------------------
                                    561 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        562 	.ds 8
                                    563 ;--------------------------------------------------------
                                    564 ; internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area DSEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; overlayable items in internal ram
                                    569 ;--------------------------------------------------------
                                    570 ;--------------------------------------------------------
                                    571 ; indirectly addressable internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area ISEG    (DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; absolute internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area IABS    (ABS,DATA)
                                    578 	.area IABS    (ABS,DATA)
                                    579 ;--------------------------------------------------------
                                    580 ; bit data
                                    581 ;--------------------------------------------------------
                                    582 	.area BSEG    (BIT)
      000027                        583 _get_record_keycode_sloc0_1_0:
      000027                        584 	.ds 1
      000028                        585 _pre_process_record_quantum_sloc0_1_0:
      000028                        586 	.ds 1
      000029                        587 _process_ak820_nkro_sloc0_1_0:
      000029                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; paged external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area PSEG    (PAG,XDATA)
                                    593 ;--------------------------------------------------------
                                    594 ; uninitialized external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area XSEG    (XDATA)
      000CB1                        597 _extract_mod_bits_code_10000_606:
      000CB1                        598 	.ds 2
      000CB3                        599 _register_code16_code_10000_612:
      000CB3                        600 	.ds 2
      000CB5                        601 _unregister_code16_code_10000_617:
      000CB5                        602 	.ds 2
      000CB7                        603 _pre_process_record_kb_PARM_2:
      000CB7                        604 	.ds 3
      000CBA                        605 _pre_process_record_kb_keycode_10000_631:
      000CBA                        606 	.ds 2
      000CBC                        607 _pre_process_record_user_PARM_2:
      000CBC                        608 	.ds 3
      000CBF                        609 _process_record_kb_PARM_2:
      000CBF                        610 	.ds 3
      000CC2                        611 _process_record_kb_keycode_10000_637:
      000CC2                        612 	.ds 2
      000CC4                        613 _process_record_user_PARM_2:
      000CC4                        614 	.ds 3
      000CC7                        615 _post_process_record_kb_PARM_2:
      000CC7                        616 	.ds 3
      000CCA                        617 _post_process_record_kb_keycode_10000_641:
      000CCA                        618 	.ds 2
      000CCC                        619 _post_process_record_user_PARM_2:
      000CCC                        620 	.ds 3
      000CCF                        621 _get_record_keycode_PARM_2:
      000CCF                        622 	.ds 1
      000CD0                        623 _get_record_keycode_record_argument_10000_655:
      000CD0                        624 	.ds 3
      000CD3                        625 _pre_process_record_quantum_record_argument_10000_661:
      000CD3                        626 	.ds 3
      000CD6                        627 _post_process_record_quantum_record_10000_664:
      000CD6                        628 	.ds 3
      000CD9                        629 _process_record_quantum_record_10000_666:
      000CD9                        630 	.ds 3
      000CDC                        631 _process_ak820_nkro_PARM_2:
      000CDC                        632 	.ds 3
      000CDF                        633 _process_ak820_nkro_keycode_10000_668:
      000CDF                        634 	.ds 2
      000CE1                        635 _process_record_quantum_helper_PARM_2:
      000CE1                        636 	.ds 3
      000CE4                        637 _process_record_quantum_helper_keycode_10000_673:
      000CE4                        638 	.ds 2
      000CE6                        639 _get_u8_str_last_num_10000_699:
      000CE6                        640 	.ds 1
      000CE7                        641 _get_u16_str_last_num_10000_703:
      000CE7                        642 	.ds 2
                                    643 ;--------------------------------------------------------
                                    644 ; absolute external ram data
                                    645 ;--------------------------------------------------------
                                    646 	.area XABS    (ABS,XDATA)
                                    647 ;--------------------------------------------------------
                                    648 ; initialized external ram data
                                    649 ;--------------------------------------------------------
                                    650 	.area XISEG   (XDATA)
                                    651 	.area HOME    (CODE)
                                    652 	.area GSINIT0 (CODE)
                                    653 	.area GSINIT1 (CODE)
                                    654 	.area GSINIT2 (CODE)
                                    655 	.area GSINIT3 (CODE)
                                    656 	.area GSINIT4 (CODE)
                                    657 	.area GSINIT5 (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area CSEG    (CODE)
                                    661 ;--------------------------------------------------------
                                    662 ; global & static initialisations
                                    663 ;--------------------------------------------------------
                                    664 	.area HOME    (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area GSINIT  (CODE)
                                    668 ;------------------------------------------------------------
                                    669 ;Allocation info for local variables in function 'get_u8_str'
                                    670 ;------------------------------------------------------------
                                    671 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    672 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_698'
                                    673 ;buf           Allocated with name '_get_u8_str_buf_10000_699'
                                    674 ;last_num      Allocated with name '_get_u8_str_last_num_10000_699'
                                    675 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_699'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/quantum.c:778: static uint8_t last_num = 0xFF;
      0030F3 90 0C E6         [24]  678 	mov	dptr,#_get_u8_str_last_num_10000_699
      0030F6 74 FF            [12]  679 	mov	a,#0xff
      0030F8 F0               [24]  680 	movx	@dptr,a
                                    681 ;------------------------------------------------------------
                                    682 ;Allocation info for local variables in function 'get_u16_str'
                                    683 ;------------------------------------------------------------
                                    684 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    685 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_702'
                                    686 ;buf           Allocated with name '_get_u16_str_buf_10000_703'
                                    687 ;last_num      Allocated with name '_get_u16_str_last_num_10000_703'
                                    688 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_703'
                                    689 ;------------------------------------------------------------
                                    690 ;	quantum/quantum.c:798: static uint16_t last_num = 0xFF;
      0030F9 90 0C E7         [24]  691 	mov	dptr,#_get_u16_str_last_num_10000_703
      0030FC 74 FF            [12]  692 	mov	a,#0xff
      0030FE F0               [24]  693 	movx	@dptr,a
      0030FF E4               [12]  694 	clr	a
      003100 A3               [24]  695 	inc	dptr
      003101 F0               [24]  696 	movx	@dptr,a
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    708 ;------------------------------------------------------------
                                    709 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    710 ;------------------------------------------------------------
                                    711 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function extract_mod_bits
                                    722 ;	-----------------------------------------
      00A306                        723 _extract_mod_bits:
      00A306 12 38 81         [24]  724 	lcall	_ak820_outline_0111
      00A309 90 0C B1         [24]  725 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A30C 12 38 86         [24]  726 	lcall	_ak820_outline_0112
                                    727 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A30F 90 0C B1         [24]  728 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A312 E0               [24]  729 	movx	a,@dptr
      00A313 A3               [24]  730 	inc	dptr
      00A314 E0               [24]  731 	movx	a,@dptr
                                    732 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A315 FF               [12]  733 	mov	r7,a
      00A316 60 05            [24]  734 	jz	00101$
      00A318 EF               [12]  735 	mov	a,r7
      00A319 24 E0            [12]  736 	add	a,#0xff - 0x1f
      00A31B 50 04            [24]  737 	jnc	00102$
                                    738 ;	free result
      00A31D                        739 00101$:
      00A31D 75 82 00         [24]  740 	mov	dpl, #0x00
      00A320 22               [24]  741 	ret
      00A321                        742 00102$:
                                    743 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A321 EF               [12]  744 	mov	a,r7
      00A322 30 E4 07         [24]  745 	jnb	acc.4,00106$
      00A325 EF               [12]  746 	mov	a,r7
      00A326 C4               [12]  747 	swap	a
      00A327 54 F0            [12]  748 	anl	a,#0xf0
      00A329 FE               [12]  749 	mov	r6,a
      00A32A 80 02            [24]  750 	sjmp	00107$
      00A32C                        751 00106$:
      00A32C 8F 06            [24]  752 	mov	ar6,r7
      00A32E                        753 00107$:
      00A32E 8E 82            [24]  754 	mov	dpl, r6
                                    755 ;	quantum/quantum.c:143: }
      00A330 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'do_code16'
                                    759 ;------------------------------------------------------------
                                    760 ;f             Allocated with name '_do_code16_PARM_2'
                                    761 ;code          Allocated with name '_do_code16_code_10000_609'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function register_code16
                                    766 ;	-----------------------------------------
      00A331                        767 _register_code16:
      00A331 12 38 81         [24]  768 	lcall	_ak820_outline_0111
      00A334 90 0C B3         [24]  769 	mov	dptr,#_register_code16_code_10000_612
      00A337 12 38 86         [24]  770 	lcall	_ak820_outline_0112
                                    771 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A33A 90 0C B3         [24]  772 	mov	dptr,#_register_code16_code_10000_612
      00A33D 12 37 ED         [24]  773 	lcall	_ak820_outline_0006
      00A340 C0 07            [24]  774 	push	ar7
      00A342 C0 06            [24]  775 	push	ar6
      00A344 71 06            [12]  776 	acall	_extract_mod_bits
      00A346 AD 82            [24]  777 	mov	r5, dpl
      00A348 D0 06            [24]  778 	pop	ar6
      00A34A D0 07            [24]  779 	pop	ar7
                                    780 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A34C 12 A1 3E         [24]  781 	lcall	_ak820_outline_0125
      00A34F 40 07            [24]  782 	jc	00105$
      00A351 74 E7            [12]  783 	mov	a,#0xe7
      00A353 9E               [12]  784 	subb	a,r6
      00A354 E4               [12]  785 	clr	a
      00A355 9F               [12]  786 	subb	a,r7
      00A356 50 08            [24]  787 	jnc	00101$
                                    788 ;	free result
      00A358                        789 00105$:
      00A358 90 0C B3         [24]  790 	mov	dptr,#_register_code16_code_10000_612
      00A35B 12 48 E2         [24]  791 	lcall	_ak820_outline_0038
      00A35E 70 07            [24]  792 	jnz	00102$
      00A360                        793 00101$:
                                    794 ;	quantum/quantum.c:153: register_mods(mods);
      00A360 8D 82            [24]  795 	mov	dpl, r5
      00A362 12 7B 3A         [24]  796 	lcall	_register_mods
      00A365 80 05            [24]  797 	sjmp	00103$
      00A367                        798 00102$:
                                    799 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A367 8D 82            [24]  800 	mov	dpl, r5
      00A369 12 7B 62         [24]  801 	lcall	_register_weak_mods
      00A36C                        802 00103$:
                                    803 ;	quantum/quantum.c:157: register_code(code);
      00A36C 90 0C B3         [24]  804 	mov	dptr,#_register_code16_code_10000_612
      00A36F E0               [24]  805 	movx	a,@dptr
      00A370 F5 82            [12]  806 	mov	dpl,a
                                    807 ;	quantum/quantum.c:167: }
      00A372 02 7A 1A         [24]  808 	ljmp	_register_code
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'unregister_code16'
                                    811 ;------------------------------------------------------------
                                    812 ;code          Allocated with name '_unregister_code16_code_10000_617'
                                    813 ;mods          Allocated with name '_unregister_code16_mods_10000_618'
                                    814 ;------------------------------------------------------------
                                    815 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    816 ;	-----------------------------------------
                                    817 ;	 function unregister_code16
                                    818 ;	-----------------------------------------
      00A375                        819 _unregister_code16:
      00A375 12 38 81         [24]  820 	lcall	_ak820_outline_0111
      00A378 90 0C B5         [24]  821 	mov	dptr,#_unregister_code16_code_10000_617
      00A37B 12 38 86         [24]  822 	lcall	_ak820_outline_0112
                                    823 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A37E 90 0C B5         [24]  824 	mov	dptr,#_unregister_code16_code_10000_617
      00A381 12 37 ED         [24]  825 	lcall	_ak820_outline_0006
      00A384 C0 07            [24]  826 	push	ar7
      00A386 C0 06            [24]  827 	push	ar6
      00A388 71 06            [12]  828 	acall	_extract_mod_bits
      00A38A AD 82            [24]  829 	mov	r5, dpl
      00A38C D0 06            [24]  830 	pop	ar6
                                    831 ;	quantum/quantum.c:172: unregister_code(code);
      00A38E 8E 04            [24]  832 	mov	ar4,r6
      00A390 8C 82            [24]  833 	mov	dpl, r4
      00A392 C0 06            [24]  834 	push	ar6
      00A394 C0 05            [24]  835 	push	ar5
      00A396 12 7A 87         [24]  836 	lcall	_unregister_code
      00A399 D0 05            [24]  837 	pop	ar5
      00A39B D0 06            [24]  838 	pop	ar6
      00A39D D0 07            [24]  839 	pop	ar7
                                    840 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A39F 12 A1 3E         [24]  841 	lcall	_ak820_outline_0125
      00A3A2 40 07            [24]  842 	jc	00105$
      00A3A4 74 E7            [12]  843 	mov	a,#0xe7
      00A3A6 9E               [12]  844 	subb	a,r6
      00A3A7 E4               [12]  845 	clr	a
      00A3A8 9F               [12]  846 	subb	a,r7
      00A3A9 50 08            [24]  847 	jnc	00101$
                                    848 ;	free result
      00A3AB                        849 00105$:
      00A3AB 90 0C B5         [24]  850 	mov	dptr,#_unregister_code16_code_10000_617
      00A3AE 12 48 E2         [24]  851 	lcall	_ak820_outline_0038
      00A3B1 70 05            [24]  852 	jnz	00102$
      00A3B3                        853 00101$:
                                    854 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A3B3 8D 82            [24]  855 	mov	dpl, r5
      00A3B5 02 7B 4E         [24]  856 	ljmp	_unregister_mods
      00A3B8                        857 00102$:
                                    858 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A3B8 8D 82            [24]  859 	mov	dpl, r5
                                    860 ;	quantum/quantum.c:187: }
      00A3BA 02 7B 76         [24]  861 	ljmp	_unregister_weak_mods
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'tap_code16_delay'
                                    864 ;------------------------------------------------------------
                                    865 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    866 ;code          Allocated with name '_tap_code16_delay_code_10000_622'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_20000_624'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_50000_627'
                                    869 ;------------------------------------------------------------
                                    870 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function pre_process_record_kb
                                    873 ;	-----------------------------------------
      00A3BD                        874 _pre_process_record_kb:
      00A3BD 12 38 81         [24]  875 	lcall	_ak820_outline_0111
      00A3C0 90 0C BA         [24]  876 	mov	dptr,#_pre_process_record_kb_keycode_10000_631
      00A3C3 12 38 86         [24]  877 	lcall	_ak820_outline_0112
                                    878 ;	quantum/quantum.c:211: return pre_process_record_user(keycode, record);
      00A3C6 90 0C BA         [24]  879 	mov	dptr,#_pre_process_record_kb_keycode_10000_631
      00A3C9 12 38 2D         [24]  880 	lcall	_ak820_outline_0058
      00A3CC 90 0C B7         [24]  881 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A3CF 12 A1 35         [24]  882 	lcall	_ak820_outline_0029
      00A3D2 90 0C BC         [24]  883 	mov	dptr,#_pre_process_record_user_PARM_2
      00A3D5 12 A7 22         [24]  884 	lcall	_ak820_outline_0011
                                    885 ;	quantum/quantum.c:212: }
      00A3D8 61 DA            [12]  886 	ajmp	_pre_process_record_user
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'pre_process_record_user'
                                    889 ;------------------------------------------------------------
                                    890 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    891 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_633'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/quantum.c:214: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function pre_process_record_user
                                    896 ;	-----------------------------------------
      00A3DA                        897 _pre_process_record_user:
                                    898 ;	quantum/quantum.c:215: return true;
      00A3DA 75 82 01         [24]  899 	mov	dpl, #0x01
                                    900 ;	quantum/quantum.c:216: }
      00A3DD 22               [24]  901 	ret
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'process_action_kb'
                                    904 ;------------------------------------------------------------
                                    905 ;record        Allocated with name '_process_action_kb_record_10000_635'
                                    906 ;------------------------------------------------------------
                                    907 ;	quantum/quantum.c:218: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    908 ;	-----------------------------------------
                                    909 ;	 function process_action_kb
                                    910 ;	-----------------------------------------
      00A3DE                        911 _process_action_kb:
                                    912 ;	quantum/quantum.c:219: return true;
      00A3DE 75 82 01         [24]  913 	mov	dpl, #0x01
                                    914 ;	quantum/quantum.c:220: }
      00A3E1 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'process_record_kb'
                                    918 ;------------------------------------------------------------
                                    919 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    920 ;keycode       Allocated with name '_process_record_kb_keycode_10000_637'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/quantum.c:222: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function process_record_kb
                                    925 ;	-----------------------------------------
      00A3E2                        926 _process_record_kb:
      00A3E2 12 38 81         [24]  927 	lcall	_ak820_outline_0111
      00A3E5 90 0C C2         [24]  928 	mov	dptr,#_process_record_kb_keycode_10000_637
      00A3E8 12 38 86         [24]  929 	lcall	_ak820_outline_0112
                                    930 ;	quantum/quantum.c:223: return process_record_user(keycode, record);
      00A3EB 90 0C C2         [24]  931 	mov	dptr,#_process_record_kb_keycode_10000_637
      00A3EE 12 38 2D         [24]  932 	lcall	_ak820_outline_0058
      00A3F1 90 0C BF         [24]  933 	mov	dptr,#_process_record_kb_PARM_2
      00A3F4 12 A1 35         [24]  934 	lcall	_ak820_outline_0029
      00A3F7 90 0C C4         [24]  935 	mov	dptr,#_process_record_user_PARM_2
      00A3FA 12 A7 22         [24]  936 	lcall	_ak820_outline_0011
                                    937 ;	quantum/quantum.c:224: }
      00A3FD 61 FF            [12]  938 	ajmp	_process_record_user
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'process_record_user'
                                    941 ;------------------------------------------------------------
                                    942 ;record        Allocated with name '_process_record_user_PARM_2'
                                    943 ;keycode       Allocated with name '_process_record_user_keycode_10000_639'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/quantum.c:226: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_record_user
                                    948 ;	-----------------------------------------
      00A3FF                        949 _process_record_user:
                                    950 ;	quantum/quantum.c:227: return true;
      00A3FF 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	quantum/quantum.c:228: }
      00A402 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'post_process_record_kb'
                                    956 ;------------------------------------------------------------
                                    957 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    958 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_641'
                                    959 ;------------------------------------------------------------
                                    960 ;	quantum/quantum.c:230: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function post_process_record_kb
                                    963 ;	-----------------------------------------
      00A403                        964 _post_process_record_kb:
      00A403 12 38 81         [24]  965 	lcall	_ak820_outline_0111
      00A406 90 0C CA         [24]  966 	mov	dptr,#_post_process_record_kb_keycode_10000_641
      00A409 12 38 86         [24]  967 	lcall	_ak820_outline_0112
                                    968 ;	quantum/quantum.c:231: post_process_record_user(keycode, record);
      00A40C 90 0C CA         [24]  969 	mov	dptr,#_post_process_record_kb_keycode_10000_641
      00A40F 12 38 2D         [24]  970 	lcall	_ak820_outline_0058
      00A412 90 0C C7         [24]  971 	mov	dptr,#_post_process_record_kb_PARM_2
      00A415 12 A1 35         [24]  972 	lcall	_ak820_outline_0029
      00A418 90 0C CC         [24]  973 	mov	dptr,#_post_process_record_user_PARM_2
      00A41B 12 A7 22         [24]  974 	lcall	_ak820_outline_0011
                                    975 ;	quantum/quantum.c:232: }
      00A41E 81 20            [24]  976 	ajmp	_post_process_record_user
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'post_process_record_user'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    981 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_643'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/quantum.c:234: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    984 ;	-----------------------------------------
                                    985 ;	 function post_process_record_user
                                    986 ;	-----------------------------------------
      00A420                        987 _post_process_record_user:
      00A420 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'shutdown_quantum'
                                    991 ;------------------------------------------------------------
                                    992 ;i             Allocated with name '_shutdown_quantum_i_30000_649'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/quantum.c:236: void shutdown_quantum(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function shutdown_quantum
                                    997 ;	-----------------------------------------
      00A421                        998 _shutdown_quantum:
                                    999 ;	quantum/quantum.c:237: clear_keyboard();
      00A421 12 7B 8A         [24] 1000 	lcall	_clear_keyboard
                                   1001 ;	quantum/quantum.c:252: shutdown_user();
      00A424 F1 14            [12] 1002 	acall	_shutdown_user
                                   1003 ;	quantum/quantum.c:253: wait_ms(250);
      00A426 7F FA            [12] 1004 	mov	r7,#0xfa
      00A428                       1005 00106$:
      00A428 EF               [12] 1006 	mov	a,r7
      00A429 60 09            [24] 1007 	jz	00108$
      00A42B 90 00 01         [24] 1008 	mov	dptr,#0x0001
      00A42E 12 5E 16         [24] 1009 	lcall	_mDelaymS
      00A431 1F               [12] 1010 	dec	r7
      00A432 80 F4            [24] 1011 	sjmp	00106$
      00A434                       1012 00108$:
                                   1013 ;	quantum/quantum.c:258: }
      00A434 22               [24] 1014 	ret
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'reset_keyboard'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function reset_keyboard
                                   1021 ;	-----------------------------------------
      00A435                       1022 _reset_keyboard:
                                   1023 ;	quantum/quantum.c:261: shutdown_quantum();
      00A435 91 21            [24] 1024 	acall	_shutdown_quantum
                                   1025 ;	quantum/quantum.c:262: bootloader_jump();
                                   1026 ;	quantum/quantum.c:263: }
      00A437 02 34 0E         [24] 1027 	ljmp	_bootloader_jump
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function soft_reset_keyboard
                                   1034 ;	-----------------------------------------
      00A43A                       1035 _soft_reset_keyboard:
                                   1036 ;	quantum/quantum.c:266: shutdown_quantum();
      00A43A 91 21            [24] 1037 	acall	_shutdown_quantum
                                   1038 ;	quantum/quantum.c:267: mcu_reset();
                                   1039 ;	quantum/quantum.c:268: }
      00A43C 02 34 01         [24] 1040 	ljmp	_mcu_reset
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'get_record_keycode'
                                   1043 ;------------------------------------------------------------
                                   1044 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1045 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_655'
                                   1046 ;record        Allocated with name '_get_record_keycode_record_10000_656'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1049 ;	-----------------------------------------
                                   1050 ;	 function get_record_keycode
                                   1051 ;	-----------------------------------------
      00A43F                       1052 _get_record_keycode:
      00A43F 12 43 1B         [24] 1053 	lcall	_ak820_outline_0041
      00A442 90 0C D0         [24] 1054 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A445 12 38 15         [24] 1055 	lcall	_ak820_outline_0020
                                   1056 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A448 90 0C D0         [24] 1057 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A44B 12 37 F7         [24] 1058 	lcall	_ak820_outline_0008
                                   1059 ;	quantum/quantum.c:278: if (record->keycode) {
      00A44E 4C               [12] 1060 	orl	a,r4
      00A44F 60 04            [24] 1061 	jz	00102$
                                   1062 ;	quantum/quantum.c:279: return record->keycode;
      00A451 12 38 A3         [24] 1063 	lcall	_ak820_outline_0132
      00A454 22               [24] 1064 	ret
      00A455                       1065 00102$:
                                   1066 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A455 12 7B E8         [24] 1067 	lcall	_ak820_outline_0025
      00A458 7A 00            [12] 1068 	mov	r2,#0x00
      00A45A 12 43 69         [24] 1069 	lcall	_ak820_outline_0149
      00A45D 12 37 E0         [24] 1070 	lcall	_ak820_outline_0005
      00A460 60 06            [24] 1071 	jz	00105$
      00A462 90 0C CF         [24] 1072 	mov	dptr,#_get_record_keycode_PARM_2
      00A465 E0               [24] 1073 	movx	a,@dptr
      00A466 70 04            [24] 1074 	jnz	00106$
      00A468                       1075 00105$:
                                   1076 ;	assignBit
      00A468 C2 27            [12] 1077 	clr	_get_record_keycode_sloc0_1_0
      00A46A 80 02            [24] 1078 	sjmp	00107$
      00A46C                       1079 00106$:
                                   1080 ;	assignBit
      00A46C D2 27            [12] 1081 	setb	_get_record_keycode_sloc0_1_0
      00A46E                       1082 00107$:
      00A46E 90 0A 32         [24] 1083 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A471 A2 27            [12] 1084 	mov	c,_get_record_keycode_sloc0_1_0
      00A473 E4               [12] 1085 	clr	a
      00A474 33               [12] 1086 	rlc	a
      00A475 F0               [24] 1087 	movx	@dptr,a
      00A476 8D 82            [24] 1088 	mov	dpl, r5
      00A478 8C 83            [24] 1089 	mov	dph, r4
                                   1090 ;	quantum/quantum.c:287: }
      00A47A 02 7F 7E         [24] 1091 	ljmp	_ak820_resolve_key
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'get_event_keycode'
                                   1094 ;------------------------------------------------------------
                                   1095 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1096 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_659'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function pre_process_record_quantum
                                   1101 ;	-----------------------------------------
      00A47D                       1102 _pre_process_record_quantum:
      00A47D 12 43 1B         [24] 1103 	lcall	_ak820_outline_0041
      00A480 90 0C D3         [24] 1104 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A483 12 38 15         [24] 1105 	lcall	_ak820_outline_0020
                                   1106 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A486 90 0C D3         [24] 1107 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A489 12 38 2D         [24] 1108 	lcall	_ak820_outline_0058
                                   1109 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A48C 8E 03            [24] 1110 	mov	ar3,r6
      00A48E 8F 04            [24] 1111 	mov	ar4,r7
      00A490 7D 00            [12] 1112 	mov	r5,#0x00
      00A492 90 0C CF         [24] 1113 	mov	dptr,#_get_record_keycode_PARM_2
      00A495 74 01            [12] 1114 	mov	a,#0x01
      00A497 F0               [24] 1115 	movx	@dptr,a
      00A498 12 33 FC         [24] 1116 	lcall	_ak820_outline_0131
      00A49B 8D F0            [24] 1117 	mov	b, r5
      00A49D C0 07            [24] 1118 	push	ar7
      00A49F C0 06            [24] 1119 	push	ar6
      00A4A1 91 3F            [24] 1120 	acall	_get_record_keycode
      00A4A3 12 43 6F         [24] 1121 	lcall	_ak820_outline_0156
      00A4A6 D0 06            [24] 1122 	pop	ar6
      00A4A8 D0 07            [24] 1123 	pop	ar7
                                   1124 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A4AA 74 07            [12] 1125 	mov	a,#0x07
      00A4AC 12 38 1D         [24] 1126 	lcall	_ak820_outline_0026
      00A4AF EC               [12] 1127 	mov	a,r4
      00A4B0 F0               [24] 1128 	movx	@dptr,a
      00A4B1 ED               [12] 1129 	mov	a,r5
      00A4B2 A3               [24] 1130 	inc	dptr
      00A4B3 12 43 46         [24] 1131 	lcall	_ak820_outline_0071
                                   1132 ;	quantum/quantum.c:351: if (!ak820_tap_dance_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      00A4B6 C0 07            [24] 1133 	push	ar7
      00A4B8 C0 06            [24] 1134 	push	ar6
      00A4BA C0 05            [24] 1135 	push	ar5
      00A4BC C0 04            [24] 1136 	push	ar4
      00A4BE 12 46 E0         [24] 1137 	lcall	_ak820_tap_dance_process
      00A4C1 E5 82            [12] 1138 	mov	a, dpl
      00A4C3 D0 04            [24] 1139 	pop	ar4
      00A4C5 D0 05            [24] 1140 	pop	ar5
      00A4C7 D0 06            [24] 1141 	pop	ar6
      00A4C9 D0 07            [24] 1142 	pop	ar7
      00A4CB 70 03            [24] 1143 	jnz	00102$
      00A4CD F5 82            [12] 1144 	mov	dpl,a
      00A4CF 22               [24] 1145 	ret
      00A4D0                       1146 00102$:
                                   1147 ;	quantum/quantum.c:353: return pre_process_record_kb(keycode, record) &&
      00A4D0 90 0C B7         [24] 1148 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A4D3 12 A7 15         [24] 1149 	lcall	_ak820_outline_0002
      00A4D6 C0 07            [24] 1150 	push	ar7
      00A4D8 C0 06            [24] 1151 	push	ar6
      00A4DA 71 BD            [12] 1152 	acall	_pre_process_record_kb
      00A4DC E5 82            [12] 1153 	mov	a, dpl
      00A4DE D0 06            [24] 1154 	pop	ar6
      00A4E0 D0 07            [24] 1155 	pop	ar7
      00A4E2 60 0A            [24] 1156 	jz	00105$
                                   1157 ;	quantum/quantum.c:356: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A4E4 12 38 92         [24] 1158 	lcall	_ak820_outline_0124
      00A4E7 12 36 32         [24] 1159 	lcall	_ak820_combo_process
      00A4EA E5 82            [12] 1160 	mov	a, dpl
      00A4EC 70 04            [24] 1161 	jnz	00106$
                                   1162 ;	quantum/quantum.c:361: true;
      00A4EE                       1163 00105$:
                                   1164 ;	assignBit
      00A4EE C2 28            [12] 1165 	clr	_pre_process_record_quantum_sloc0_1_0
      00A4F0 80 02            [24] 1166 	sjmp	00107$
      00A4F2                       1167 00106$:
                                   1168 ;	assignBit
      00A4F2 D2 28            [12] 1169 	setb	_pre_process_record_quantum_sloc0_1_0
      00A4F4                       1170 00107$:
      00A4F4 A2 28            [12] 1171 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A4F6 12 38 B7         [24] 1172 	lcall	_ak820_outline_0151
                                   1173 ;	quantum/quantum.c:362: }
      00A4F9 22               [24] 1174 	ret
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1177 ;------------------------------------------------------------
                                   1178 ;record        Allocated with name '_post_process_record_quantum_record_10000_664'
                                   1179 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_665'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/quantum.c:365: void post_process_record_quantum(keyrecord_t *record) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function post_process_record_quantum
                                   1184 ;	-----------------------------------------
      00A4FA                       1185 _post_process_record_quantum:
      00A4FA 12 43 1B         [24] 1186 	lcall	_ak820_outline_0041
      00A4FD 90 0C D6         [24] 1187 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A500 12 38 15         [24] 1188 	lcall	_ak820_outline_0020
                                   1189 ;	quantum/quantum.c:366: uint16_t keycode = get_record_keycode(record, false);
      00A503 90 0C D6         [24] 1190 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A506 12 54 6E         [24] 1191 	lcall	_ak820_outline_0015
      00A509 90 0C CF         [24] 1192 	mov	dptr,#_get_record_keycode_PARM_2
      00A50C E4               [12] 1193 	clr	a
      00A50D 12 54 77         [24] 1194 	lcall	_ak820_outline_0036
      00A510 91 3F            [24] 1195 	acall	_get_record_keycode
      00A512 12 43 64         [24] 1196 	lcall	_ak820_outline_0142
                                   1197 ;	quantum/quantum.c:367: post_process_record_kb(keycode, record);
      00A515 90 0C D6         [24] 1198 	mov	dptr,#_post_process_record_quantum_record_10000_664
      00A518 12 A1 35         [24] 1199 	lcall	_ak820_outline_0029
      00A51B 90 0C C7         [24] 1200 	mov	dptr,#_post_process_record_kb_PARM_2
      00A51E 12 A7 22         [24] 1201 	lcall	_ak820_outline_0011
                                   1202 ;	quantum/quantum.c:368: }
      00A521 81 03            [12] 1203 	ajmp	_post_process_record_kb
                                   1204 ;------------------------------------------------------------
                                   1205 ;Allocation info for local variables in function 'process_record_quantum'
                                   1206 ;------------------------------------------------------------
                                   1207 ;record        Allocated with name '_process_record_quantum_record_10000_666'
                                   1208 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_667'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	quantum/quantum.c:370: bool process_record_quantum(keyrecord_t *record) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function process_record_quantum
                                   1213 ;	-----------------------------------------
      00A523                       1214 _process_record_quantum:
      00A523 12 43 1B         [24] 1215 	lcall	_ak820_outline_0041
      00A526 90 0C D9         [24] 1216 	mov	dptr,#_process_record_quantum_record_10000_666
      00A529 12 38 15         [24] 1217 	lcall	_ak820_outline_0020
                                   1218 ;	quantum/quantum.c:372: uint16_t keycode = get_record_keycode(record, false);
      00A52C 90 0C D9         [24] 1219 	mov	dptr,#_process_record_quantum_record_10000_666
      00A52F 12 54 6E         [24] 1220 	lcall	_ak820_outline_0015
      00A532 90 0C CF         [24] 1221 	mov	dptr,#_get_record_keycode_PARM_2
      00A535 E4               [12] 1222 	clr	a
      00A536 12 54 77         [24] 1223 	lcall	_ak820_outline_0036
      00A539 91 3F            [24] 1224 	acall	_get_record_keycode
      00A53B 12 43 64         [24] 1225 	lcall	_ak820_outline_0142
                                   1226 ;	quantum/quantum.c:376: return process_record_quantum_helper(keycode, record);
      00A53E 90 0C D9         [24] 1227 	mov	dptr,#_process_record_quantum_record_10000_666
      00A541 12 A1 35         [24] 1228 	lcall	_ak820_outline_0029
      00A544 90 0C E1         [24] 1229 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A547 12 A7 22         [24] 1230 	lcall	_ak820_outline_0011
                                   1231 ;	quantum/quantum.c:377: }
      00A54A A1 B7            [24] 1232 	ajmp	_process_record_quantum_helper
                                   1233 ;------------------------------------------------------------
                                   1234 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1235 ;------------------------------------------------------------
                                   1236 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1237 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_668'
                                   1238 ;record        Allocated with name '_process_ak820_nkro_record_10000_669'
                                   1239 ;------------------------------------------------------------
                                   1240 ;	quantum/quantum.c:394: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1241 ;	-----------------------------------------
                                   1242 ;	 function process_ak820_nkro
                                   1243 ;	-----------------------------------------
      00A54C                       1244 _process_ak820_nkro:
      00A54C 12 38 81         [24] 1245 	lcall	_ak820_outline_0111
      00A54F 90 0C DF         [24] 1246 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A552 12 38 86         [24] 1247 	lcall	_ak820_outline_0112
                                   1248 ;	quantum/quantum.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A555 90 0C DC         [24] 1249 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A558 12 38 2D         [24] 1250 	lcall	_ak820_outline_0058
                                   1251 ;	quantum/quantum.c:400: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A55B 90 0C DF         [24] 1252 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A55E 12 38 44         [24] 1253 	lcall	_ak820_outline_0065
      00A561 C3               [12] 1254 	clr	c
      00A562 EC               [12] 1255 	mov	a,r4
      00A563 94 11            [12] 1256 	subb	a,#0x11
      00A565 ED               [12] 1257 	mov	a,r5
      00A566 94 70            [12] 1258 	subb	a,#0x70
      00A568 40 08            [24] 1259 	jc	00101$
      00A56A 74 13            [12] 1260 	mov	a,#0x13
      00A56C 9C               [12] 1261 	subb	a,r4
      00A56D 74 70            [12] 1262 	mov	a,#0x70
      00A56F 9D               [12] 1263 	subb	a,r5
      00A570 50 04            [24] 1264 	jnc	00102$
                                   1265 ;	free result
      00A572                       1266 00101$:
      00A572 75 82 01         [24] 1267 	mov	dpl, #0x01
      00A575 22               [24] 1268 	ret
      00A576                       1269 00102$:
                                   1270 ;	quantum/quantum.c:401: if (record->event.pressed) {
      00A576 12 37 E0         [24] 1271 	lcall	_ak820_outline_0005
      00A579 60 38            [24] 1272 	jz	00105$
                                   1273 ;	quantum/quantum.c:402: clear_keyboard();
      00A57B C0 05            [24] 1274 	push	ar5
      00A57D C0 04            [24] 1275 	push	ar4
      00A57F 12 7B 8A         [24] 1276 	lcall	_clear_keyboard
      00A582 D0 04            [24] 1277 	pop	ar4
      00A584 D0 05            [24] 1278 	pop	ar5
                                   1279 ;	quantum/quantum.c:403: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A586 BC 13 14         [24] 1280 	cjne	r4,#0x13,00108$
      00A589 BD 70 11         [24] 1281 	cjne	r5,#0x70,00108$
      00A58C 90 0B 84         [24] 1282 	mov	dptr,#_keymap_config
      00A58F E0               [24] 1283 	movx	a,@dptr
      00A590 23               [12] 1284 	rl	a
      00A591 54 01            [12] 1285 	anl	a,#0x01
      00A593 B4 01 00         [24] 1286 	cjne	a,#0x01,00136$
      00A596                       1287 00136$:
      00A596 92 29            [24] 1288 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A598 E4               [12] 1289 	clr	a
      00A599 33               [12] 1290 	rlc	a
      00A59A FF               [12] 1291 	mov	r7,a
      00A59B 80 09            [24] 1292 	sjmp	00109$
      00A59D                       1293 00108$:
      00A59D E4               [12] 1294 	clr	a
      00A59E BC 11 04         [24] 1295 	cjne	r4,#0x11,00137$
      00A5A1 BD 70 01         [24] 1296 	cjne	r5,#0x70,00137$
      00A5A4 04               [12] 1297 	inc	a
      00A5A5                       1298 00137$:
      00A5A5 FF               [12] 1299 	mov	r7,a
      00A5A6                       1300 00109$:
                                   1301 ;	assignBit
      00A5A6 EF               [12] 1302 	mov	a,r7
      00A5A7 24 FF            [12] 1303 	add	a,#0xff
      00A5A9 E4               [12] 1304 	clr	a
      00A5AA 33               [12] 1305 	rlc	a
      00A5AB 90 0B 84         [24] 1306 	mov	dptr,#_keymap_config
      00A5AE 13               [12] 1307 	rrc	a
      00A5AF E0               [24] 1308 	movx	a,@dptr
      00A5B0 92 E7            [24] 1309 	mov	acc.7,c
      00A5B2 F0               [24] 1310 	movx	@dptr,a
      00A5B3                       1311 00105$:
                                   1312 ;	quantum/quantum.c:405: return false;
      00A5B3 75 82 00         [24] 1313 	mov	dpl, #0x00
                                   1314 ;	quantum/quantum.c:406: }
      00A5B6 22               [24] 1315 	ret
                                   1316 ;------------------------------------------------------------
                                   1317 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1318 ;------------------------------------------------------------
                                   1319 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1320 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_673'
                                   1321 ;record        Allocated with name '_process_record_quantum_helper_record_10000_674'
                                   1322 ;------------------------------------------------------------
                                   1323 ;	quantum/quantum.c:409: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1324 ;	-----------------------------------------
                                   1325 ;	 function process_record_quantum_helper
                                   1326 ;	-----------------------------------------
      00A5B7                       1327 _process_record_quantum_helper:
      00A5B7 12 38 81         [24] 1328 	lcall	_ak820_outline_0111
      00A5BA 90 0C E4         [24] 1329 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A5BD 12 38 86         [24] 1330 	lcall	_ak820_outline_0112
                                   1331 ;	quantum/quantum.c:411: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A5C0 90 0C E1         [24] 1332 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A5C3 12 38 2D         [24] 1333 	lcall	_ak820_outline_0058
                                   1334 ;	quantum/quantum.c:454: process_ak820_nkro(keycode, record) &&
      00A5C6 90 0C E4         [24] 1335 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A5C9 12 38 44         [24] 1336 	lcall	_ak820_outline_0065
      00A5CC 90 0C DC         [24] 1337 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A5CF 12 A7 15         [24] 1338 	lcall	_ak820_outline_0002
      00A5D2 C0 07            [24] 1339 	push	ar7
      00A5D4 C0 06            [24] 1340 	push	ar6
      00A5D6 C0 05            [24] 1341 	push	ar5
      00A5D8 C0 04            [24] 1342 	push	ar4
      00A5DA B1 4C            [24] 1343 	acall	_process_ak820_nkro
      00A5DC E5 82            [12] 1344 	mov	a, dpl
      00A5DE D0 04            [24] 1345 	pop	ar4
      00A5E0 D0 05            [24] 1346 	pop	ar5
      00A5E2 D0 06            [24] 1347 	pop	ar6
      00A5E4 D0 07            [24] 1348 	pop	ar7
      00A5E6 70 02            [24] 1349 	jnz	00204$
      00A5E8 C1 D5            [12] 1350 	ajmp	00101$
      00A5EA                       1351 00204$:
                                   1352 ;	quantum/quantum.c:465: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A5EA 90 0C 9A         [24] 1353 	mov	dptr,#_process_last_key_PARM_2
      00A5ED 12 A7 15         [24] 1354 	lcall	_ak820_outline_0002
      00A5F0 C0 07            [24] 1355 	push	ar7
      00A5F2 C0 06            [24] 1356 	push	ar6
      00A5F4 C0 05            [24] 1357 	push	ar5
      00A5F6 C0 04            [24] 1358 	push	ar4
      00A5F8 11 6F            [12] 1359 	acall	_process_last_key
      00A5FA E5 82            [12] 1360 	mov	a, dpl
      00A5FC D0 04            [24] 1361 	pop	ar4
      00A5FE D0 05            [24] 1362 	pop	ar5
      00A600 D0 06            [24] 1363 	pop	ar6
      00A602 D0 07            [24] 1364 	pop	ar7
      00A604 70 02            [24] 1365 	jnz	00205$
      00A606 C1 D5            [12] 1366 	ajmp	00101$
      00A608                       1367 00205$:
      00A608 90 0C A0         [24] 1368 	mov	dptr,#_process_repeat_key_PARM_2
      00A60B 12 A7 15         [24] 1369 	lcall	_ak820_outline_0002
      00A60E C0 07            [24] 1370 	push	ar7
      00A610 C0 06            [24] 1371 	push	ar6
      00A612 C0 05            [24] 1372 	push	ar5
      00A614 C0 04            [24] 1373 	push	ar4
      00A616 11 EC            [12] 1374 	acall	_process_repeat_key
      00A618 E5 82            [12] 1375 	mov	a, dpl
      00A61A D0 04            [24] 1376 	pop	ar4
      00A61C D0 05            [24] 1377 	pop	ar5
      00A61E D0 06            [24] 1378 	pop	ar6
      00A620 D0 07            [24] 1379 	pop	ar7
      00A622 70 02            [24] 1380 	jnz	00206$
      00A624 C1 D5            [12] 1381 	ajmp	00101$
      00A626                       1382 00206$:
                                   1383 ;	quantum/quantum.c:474: process_record_via(keycode, record) &&
      00A626 90 0D 21         [24] 1384 	mov	dptr,#_process_record_via_PARM_2
      00A629 12 A7 15         [24] 1385 	lcall	_ak820_outline_0002
      00A62C C0 07            [24] 1386 	push	ar7
      00A62E C0 06            [24] 1387 	push	ar6
      00A630 C0 05            [24] 1388 	push	ar5
      00A632 C0 04            [24] 1389 	push	ar4
      00A634 12 AC 15         [24] 1390 	lcall	_process_record_via
      00A637 E5 82            [12] 1391 	mov	a, dpl
      00A639 D0 04            [24] 1392 	pop	ar4
      00A63B D0 05            [24] 1393 	pop	ar5
      00A63D D0 06            [24] 1394 	pop	ar6
      00A63F D0 07            [24] 1395 	pop	ar7
      00A641 70 02            [24] 1396 	jnz	00207$
      00A643 C1 D5            [12] 1397 	ajmp	00101$
      00A645                       1398 00207$:
                                   1399 ;	quantum/quantum.c:484: process_record_kb(keycode, record) &&
      00A645 90 0C BF         [24] 1400 	mov	dptr,#_process_record_kb_PARM_2
      00A648 12 A7 15         [24] 1401 	lcall	_ak820_outline_0002
      00A64B C0 07            [24] 1402 	push	ar7
      00A64D C0 06            [24] 1403 	push	ar6
      00A64F C0 05            [24] 1404 	push	ar5
      00A651 C0 04            [24] 1405 	push	ar4
      00A653 71 E2            [12] 1406 	acall	_process_record_kb
      00A655 E5 82            [12] 1407 	mov	a, dpl
      00A657 D0 04            [24] 1408 	pop	ar4
      00A659 D0 05            [24] 1409 	pop	ar5
      00A65B D0 06            [24] 1410 	pop	ar6
      00A65D D0 07            [24] 1411 	pop	ar7
      00A65F 70 02            [24] 1412 	jnz	00208$
      00A661 C1 D5            [12] 1413 	ajmp	00101$
      00A663                       1414 00208$:
                                   1415 ;	quantum/quantum.c:507: process_caps_word(keycode, record) &&
      00A663 90 0C 82         [24] 1416 	mov	dptr,#_process_caps_word_PARM_2
      00A666 12 A7 15         [24] 1417 	lcall	_ak820_outline_0002
      00A669 C0 07            [24] 1418 	push	ar7
      00A66B C0 06            [24] 1419 	push	ar6
      00A66D C0 05            [24] 1420 	push	ar5
      00A66F C0 04            [24] 1421 	push	ar4
      00A671 12 9D FA         [24] 1422 	lcall	_process_caps_word
      00A674 E5 82            [12] 1423 	mov	a, dpl
      00A676 D0 04            [24] 1424 	pop	ar4
      00A678 D0 05            [24] 1425 	pop	ar5
      00A67A D0 06            [24] 1426 	pop	ar6
      00A67C D0 07            [24] 1427 	pop	ar7
      00A67E 60 55            [24] 1428 	jz	00101$
                                   1429 ;	quantum/quantum.c:537: process_grave_esc(keycode, record) &&
      00A680 90 0C 87         [24] 1430 	mov	dptr,#_process_grave_esc_PARM_2
      00A683 12 A7 15         [24] 1431 	lcall	_ak820_outline_0002
      00A686 C0 07            [24] 1432 	push	ar7
      00A688 C0 06            [24] 1433 	push	ar6
      00A68A C0 05            [24] 1434 	push	ar5
      00A68C C0 04            [24] 1435 	push	ar4
      00A68E 12 9F 0C         [24] 1436 	lcall	_process_grave_esc
      00A691 E5 82            [12] 1437 	mov	a, dpl
      00A693 D0 04            [24] 1438 	pop	ar4
      00A695 D0 05            [24] 1439 	pop	ar5
      00A697 D0 06            [24] 1440 	pop	ar6
      00A699 D0 07            [24] 1441 	pop	ar7
      00A69B 60 38            [24] 1442 	jz	00101$
                                   1443 ;	quantum/quantum.c:540: process_rgb(keycode, record) &&
      00A69D 90 0C A5         [24] 1444 	mov	dptr,#_process_rgb_PARM_2
      00A6A0 12 A7 15         [24] 1445 	lcall	_ak820_outline_0002
      00A6A3 C0 07            [24] 1446 	push	ar7
      00A6A5 C0 06            [24] 1447 	push	ar6
      00A6A7 C0 05            [24] 1448 	push	ar5
      00A6A9 C0 04            [24] 1449 	push	ar4
      00A6AB 31 46            [12] 1450 	acall	_process_rgb
      00A6AD E5 82            [12] 1451 	mov	a, dpl
      00A6AF D0 04            [24] 1452 	pop	ar4
      00A6B1 D0 05            [24] 1453 	pop	ar5
      00A6B3 D0 06            [24] 1454 	pop	ar6
      00A6B5 D0 07            [24] 1455 	pop	ar7
      00A6B7 60 1C            [24] 1456 	jz	00101$
                                   1457 ;	quantum/quantum.c:552: process_tri_layer(keycode, record) &&
      00A6B9 90 0C AB         [24] 1458 	mov	dptr,#_process_tri_layer_PARM_2
      00A6BC 12 A7 15         [24] 1459 	lcall	_ak820_outline_0002
      00A6BF C0 07            [24] 1460 	push	ar7
      00A6C1 C0 06            [24] 1461 	push	ar6
      00A6C3 C0 05            [24] 1462 	push	ar5
      00A6C5 C0 04            [24] 1463 	push	ar4
      00A6C7 31 F7            [12] 1464 	acall	_process_tri_layer
      00A6C9 E5 82            [12] 1465 	mov	a, dpl
      00A6CB D0 04            [24] 1466 	pop	ar4
      00A6CD D0 05            [24] 1467 	pop	ar5
      00A6CF D0 06            [24] 1468 	pop	ar6
      00A6D1 D0 07            [24] 1469 	pop	ar7
      00A6D3 70 04            [24] 1470 	jnz	00102$
                                   1471 ;	quantum/quantum.c:554: true)) {
      00A6D5                       1472 00101$:
                                   1473 ;	quantum/quantum.c:555: return false;
      00A6D5 75 82 00         [24] 1474 	mov	dpl, #0x00
      00A6D8 22               [24] 1475 	ret
      00A6D9                       1476 00102$:
                                   1477 ;	quantum/quantum.c:558: if (record->event.pressed) {
      00A6D9 74 05            [12] 1478 	mov	a,#0x05
      00A6DB 12 48 C0         [24] 1479 	lcall	_ak820_outline_0021
      00A6DE 60 2D            [24] 1480 	jz	00117$
                                   1481 ;	quantum/quantum.c:559: switch (keycode) {
      00A6E0 BC 00 05         [24] 1482 	cjne	r4,#0x00,00214$
      00A6E3 BD 7C 02         [24] 1483 	cjne	r5,#0x7c,00214$
      00A6E6 80 10            [24] 1484 	sjmp	00112$
      00A6E8                       1485 00214$:
      00A6E8 BC 01 05         [24] 1486 	cjne	r4,#0x01,00215$
      00A6EB BD 7C 02         [24] 1487 	cjne	r5,#0x7c,00215$
      00A6EE 80 0E            [24] 1488 	sjmp	00113$
      00A6F0                       1489 00215$:
                                   1490 ;	quantum/quantum.c:561: case QK_BOOTLOADER:
      00A6F0 BC 03 1A         [24] 1491 	cjne	r4,#0x03,00117$
      00A6F3 BD 7C 17         [24] 1492 	cjne	r5,#0x7c,00117$
      00A6F6 80 0C            [24] 1493 	sjmp	00114$
      00A6F8                       1494 00112$:
                                   1495 ;	quantum/quantum.c:562: reset_keyboard();
      00A6F8 91 35            [24] 1496 	acall	_reset_keyboard
                                   1497 ;	quantum/quantum.c:563: return false;
      00A6FA 75 82 00         [24] 1498 	mov	dpl, #0x00
                                   1499 ;	quantum/quantum.c:564: case QK_REBOOT:
      00A6FD 22               [24] 1500 	ret
      00A6FE                       1501 00113$:
                                   1502 ;	quantum/quantum.c:565: soft_reset_keyboard();
      00A6FE 91 3A            [24] 1503 	acall	_soft_reset_keyboard
                                   1504 ;	quantum/quantum.c:566: return false;
      00A700 75 82 00         [24] 1505 	mov	dpl, #0x00
                                   1506 ;	quantum/quantum.c:578: case QK_CLEAR_EEPROM:
      00A703 22               [24] 1507 	ret
      00A704                       1508 00114$:
                                   1509 ;	quantum/quantum.c:585: eeconfig_disable();
      00A704 12 95 88         [24] 1510 	lcall	_eeconfig_disable
                                   1511 ;	quantum/quantum.c:586: soft_reset_keyboard();
      00A707 91 3A            [24] 1512 	acall	_soft_reset_keyboard
                                   1513 ;	quantum/quantum.c:588: return false;
      00A709 75 82 00         [24] 1514 	mov	dpl, #0x00
                                   1515 ;	quantum/quantum.c:643: }
      00A70C 22               [24] 1516 	ret
      00A70D                       1517 00117$:
                                   1518 ;	quantum/quantum.c:646: return process_action_kb(record);
      00A70D 7D 00            [12] 1519 	mov	r5,#0x00
      00A70F 12 7C 21         [24] 1520 	lcall	_ak820_outline_0118
                                   1521 ;	quantum/quantum.c:647: }
      00A712 61 DE            [12] 1522 	ajmp	_process_action_kb
                                   1523 ;------------------------------------------------------------
                                   1524 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1525 ;------------------------------------------------------------
                                   1526 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_681'
                                   1527 ;------------------------------------------------------------
                                   1528 ;	quantum/quantum.c:649: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1529 ;	-----------------------------------------
                                   1530 ;	 function shutdown_user
                                   1531 ;	-----------------------------------------
      00A714                       1532 _shutdown_user:
      00A714 22               [24] 1533 	ret
                                   1534 ;------------------------------------------------------------
                                   1535 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/quantum.c:665: void suspend_power_down_quantum(void) {
                                   1538 ;	-----------------------------------------
                                   1539 	.area CSEG    (CODE)
                                   1540 	.area CONST   (CODE)
                                   1541 	.area XINIT   (CODE)
                                   1542 	.area CABS    (ABS,CODE)
                                   1543 
                                   1544 ; Experimental exact instruction outlining.
                                   1545 	.globl _ak820_outline_0002
                                   1546 	.globl _ak820_outline_0005
                                   1547 	.globl _ak820_outline_0006
                                   1548 	.globl _ak820_outline_0008
                                   1549 	.globl _ak820_outline_0011
                                   1550 	.globl _ak820_outline_0015
                                   1551 	.globl _ak820_outline_0020
                                   1552 	.globl _ak820_outline_0021
                                   1553 	.globl _ak820_outline_0025
                                   1554 	.globl _ak820_outline_0026
                                   1555 	.globl _ak820_outline_0029
                                   1556 	.globl _ak820_outline_0036
                                   1557 	.globl _ak820_outline_0038
                                   1558 	.globl _ak820_outline_0041
                                   1559 	.globl _ak820_outline_0058
                                   1560 	.globl _ak820_outline_0065
                                   1561 	.globl _ak820_outline_0071
                                   1562 	.globl _ak820_outline_0111
                                   1563 	.globl _ak820_outline_0112
                                   1564 	.globl _ak820_outline_0118
                                   1565 	.globl _ak820_outline_0124
                                   1566 	.globl _ak820_outline_0125
                                   1567 	.globl _ak820_outline_0131
                                   1568 	.globl _ak820_outline_0132
                                   1569 	.globl _ak820_outline_0142
                                   1570 	.globl _ak820_outline_0149
                                   1571 	.globl _ak820_outline_0151
                                   1572 	.globl _ak820_outline_0156
                                   1573 
                                   1574 	.area CSEG (CODE)
                                   1575 ; function ak820_outline_0002
      00A715                       1576 _ak820_outline_0002:
      00A715 EE               [12] 1577 	mov	a,r6
      00A716 F0               [24] 1578 	movx	@dptr,a
      00A717 EF               [12] 1579 	mov	a,r7
      00A718 A3               [24] 1580 	inc	dptr
      00A719 F0               [24] 1581 	movx	@dptr,a
      00A71A E4               [12] 1582 	clr	a
      00A71B A3               [24] 1583 	inc	dptr
      00A71C F0               [24] 1584 	movx	@dptr,a
      00A71D 8C 82            [24] 1585 	mov	dpl,r4
      00A71F 8D 83            [24] 1586 	mov	dph,r5
      00A721 22               [24] 1587 	ret
                                   1588 
                                   1589 	.area CSEG (CODE)
                                   1590 ; function ak820_outline_0011
      00A722                       1591 _ak820_outline_0011:
      00A722 EB               [12] 1592 	mov	a,r3
      00A723 F0               [24] 1593 	movx	@dptr,a
      00A724 EC               [12] 1594 	mov	a,r4
      00A725 A3               [24] 1595 	inc	dptr
      00A726 F0               [24] 1596 	movx	@dptr,a
      00A727 ED               [12] 1597 	mov	a,r5
      00A728 A3               [24] 1598 	inc	dptr
      00A729 F0               [24] 1599 	movx	@dptr,a
      00A72A 8E 82            [24] 1600 	mov	dpl,r6
      00A72C 8F 83            [24] 1601 	mov	dph,r7
      00A72E 22               [24] 1602 	ret
