                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      00003C                        553 _raw_hid_receive_sloc0_1_0:
      00003C                        554 	.ds 4
      000040                        555 _raw_hid_receive_sloc1_1_0:
      000040                        556 	.ds 1
      000041                        557 _raw_hid_receive_sloc2_1_0:
      000041                        558 	.ds 1
      000042                        559 _raw_hid_receive_sloc3_1_0:
      000042                        560 	.ds 2
      000044                        561 _raw_hid_receive_sloc4_1_0:
      000044                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002B                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002B                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000D1C                        589 _via_eeprom_set_valid_valid_10000_611:
      000D1C                        590 	.ds 1
      000D1D                        591 _via_set_layout_options_value_10000_627:
      000D1D                        592 	.ds 4
      000D21                        593 _process_record_via_PARM_2:
      000D21                        594 	.ds 3
      000D24                        595 _process_record_via_keycode_10000_629:
      000D24                        596 	.ds 2
      000D26                        597 _raw_hid_receive_kb_PARM_2:
      000D26                        598 	.ds 1
      000D27                        599 _raw_hid_receive_kb_data_10000_635:
      000D27                        600 	.ds 3
      000D2A                        601 _raw_hid_receive_PARM_2:
      000D2A                        602 	.ds 1
      000D2B                        603 _raw_hid_receive_packet_10000_637:
      000D2B                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AB36                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AB36 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AB39 75 F0 00         [24]  659 	mov	b, #0x00
      00AB3C 12 40 7C         [24]  660 	lcall	_eeprom_read_byte
      00AB3F AF 82            [24]  661 	mov	r7, dpl
      00AB41 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00AB44 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AB47 75 F0 00         [24]  664 	mov	b, #0x00
      00AB4A 12 40 7C         [24]  665 	lcall	_eeprom_read_byte
      00AB4D AF 82            [24]  666 	mov	r7, dpl
      00AB4F BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AB52 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AB55 75 F0 00         [24]  669 	mov	b, #0x00
      00AB58 12 40 7C         [24]  670 	lcall	_eeprom_read_byte
      00AB5B AF 82            [24]  671 	mov	r7, dpl
      00AB5D BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AB60 80 04            [24]  673 	sjmp	00104$
      00AB62                        674 00126$:
      00AB62                        675 00103$:
                                    676 ;	assignBit
      00AB62 C2 2B            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AB64 80 02            [24]  678 	sjmp	00105$
      00AB66                        679 00104$:
                                    680 ;	assignBit
      00AB66 D2 2B            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AB68                        682 00105$:
      00AB68 A2 2B            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AB6A 12 38 B7         [24]  684 	lcall	_ak820_outline_0151
                                    685 ;	quantum/via.c:104: }
      00AB6D 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AB6E                        699 _via_eeprom_set_valid:
      00AB6E E5 82            [12]  700 	mov	a,dpl
      00AB70 90 0D 1C         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AB73 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AB74 E0               [24]  704 	movx	a,@dptr
      00AB75 60 04            [24]  705 	jz	00103$
      00AB77 7F 03            [12]  706 	mov	r7,#0x03
      00AB79 80 02            [24]  707 	sjmp	00104$
      00AB7B                        708 00103$:
      00AB7B 7F FF            [12]  709 	mov	r7,#0xff
      00AB7D                        710 00104$:
      00AB7D 90 07 64         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB80 EF               [12]  712 	mov	a,r7
      00AB81 F0               [24]  713 	movx	@dptr,a
      00AB82 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AB85 75 F0 00         [24]  715 	mov	b, #0x00
      00AB88 12 53 5E         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AB8B 90 0D 1C         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AB8E E0               [24]  719 	movx	a,@dptr
      00AB8F 60 04            [24]  720 	jz	00105$
      00AB91 7F 20            [12]  721 	mov	r7,#0x20
      00AB93 80 02            [24]  722 	sjmp	00106$
      00AB95                        723 00105$:
      00AB95 7F FF            [12]  724 	mov	r7,#0xff
      00AB97                        725 00106$:
      00AB97 90 07 64         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB9A EF               [12]  727 	mov	a,r7
      00AB9B F0               [24]  728 	movx	@dptr,a
      00AB9C 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AB9F 75 F0 00         [24]  730 	mov	b, #0x00
      00ABA2 12 53 5E         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00ABA5 90 0D 1C         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00ABA8 E0               [24]  734 	movx	a,@dptr
      00ABA9 60 04            [24]  735 	jz	00107$
      00ABAB 7F 08            [12]  736 	mov	r7,#0x08
      00ABAD 80 02            [24]  737 	sjmp	00108$
      00ABAF                        738 00107$:
      00ABAF 7F FF            [12]  739 	mov	r7,#0xff
      00ABB1                        740 00108$:
      00ABB1 90 07 64         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00ABB4 EF               [12]  742 	mov	a,r7
      00ABB5 F0               [24]  743 	movx	@dptr,a
      00ABB6 90 00 27         [24]  744 	mov	dptr,#0x0027
      00ABB9 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00ABBC 02 53 5E         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00ABBF                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00ABBF 71 E2            [12]  757 	acall	_via_get_layout_options
      00ABC1 71 FA            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00ABC3 71 36            [12]  760 	acall	_via_eeprom_is_valid
      00ABC5 E5 82            [12]  761 	mov	a, dpl
      00ABC7 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00ABC9 02 3E 2B         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00ABCC                        766 00103$:
      00ABCC 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00ABCD                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00ABCD 75 82 00         [24]  777 	mov	dpl, #0x00
      00ABD0 71 6E            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00ABD2 12 96 47         [24]  780 	lcall	_ak820_outline_0160
      00ABD5 71 FB            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00ABD7 12 8C 8C         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00ABDA 12 91 40         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00ABDD 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00ABE0 61 6E            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00ABE2                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00ABE2 90 00 28         [24]  799 	mov	dptr,#0x0028
      00ABE5 75 F0 00         [24]  800 	mov	b, #0x00
      00ABE8 12 40 7C         [24]  801 	lcall	_eeprom_read_byte
      00ABEB AF 82            [24]  802 	mov	r7, dpl
      00ABED 7E 00            [12]  803 	mov	r6,#0x00
      00ABEF 7D 00            [12]  804 	mov	r5,#0x00
      00ABF1 7C 00            [12]  805 	mov	r4,#0x00
      00ABF3 12 43 74         [24]  806 	lcall	_ak820_outline_0163
      00ABF6 8D F0            [24]  807 	mov	b, r5
      00ABF8 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00ABF9 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00ABFA                        820 _via_set_layout_options_kb:
      00ABFA 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_627'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00ABFB                        831 _via_set_layout_options:
      00ABFB 12 96 3F         [24]  832 	lcall	_ak820_outline_0127
      00ABFE 90 0D 1D         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AC01 12 96 2D         [24]  834 	lcall	_ak820_outline_0049
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00AC04 90 0D 1D         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AC07 E0               [24]  837 	movx	a,@dptr
      00AC08 90 07 64         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AC0B F0               [24]  839 	movx	@dptr,a
      00AC0C 90 00 28         [24]  840 	mov	dptr,#0x0028
      00AC0F 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00AC12 02 53 5E         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_629'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_634'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00AC15                        855 _process_record_via:
      00AC15 12 38 81         [24]  856 	lcall	_ak820_outline_0111
      00AC18 90 0D 24         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_629
      00AC1B 12 38 86         [24]  858 	lcall	_ak820_outline_0112
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00AC1E 90 0D 21         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00AC21 12 54 6E         [24]  861 	lcall	_ak820_outline_0015
      00AC24 74 05            [12]  862 	mov	a,#0x05
      00AC26 12 38 BC         [24]  863 	lcall	_ak820_outline_0165
      00AC29 12 72 A8         [24]  864 	lcall	_ak820_outline_0063
      00AC2C 12 BF 67         [24]  865 	lcall	__gptrget
      00AC2F 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00AC31 90 0D 24         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_629
      00AC34 12 4D E6         [24]  869 	lcall	_ak820_outline_0010
      00AC37 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00AC39 2D               [12]  871 	add	a,r5
      00AC3A 50 12            [24]  872 	jnc	00105$
      00AC3C C3               [12]  873 	clr	c
      00AC3D 74 7F            [12]  874 	mov	a,#0x7f
      00AC3F 9C               [12]  875 	subb	a,r4
      00AC40 74 77            [12]  876 	mov	a,#0x77
      00AC42 9D               [12]  877 	subb	a,r5
      00AC43 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AC45 8E 82            [24]  882 	mov	dpl, r6
      00AC47 12 91 66         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AC4A 75 82 00         [24]  885 	mov	dpl, #0x00
      00AC4D 22               [24]  886 	ret
      00AC4E                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AC4E 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AC51 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AC52                        903 _raw_hid_receive_kb:
      00AC52 12 43 1B         [24]  904 	lcall	_ak820_outline_0041
      00AC55 90 0D 27         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AC58 12 38 15         [24]  906 	lcall	_ak820_outline_0020
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AC5B 90 0D 27         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AC5E 12 54 48         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AC61 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AC63 02 BF 2C         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_638'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_653'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_656'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_657'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_658'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_663'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_675'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_680'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_687'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_692'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AC66                        950 _raw_hid_receive:
      00AC66 12 43 1B         [24]  951 	lcall	_ak820_outline_0041
      00AC69 90 0D 2B         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AC6C 12 38 15         [24]  953 	lcall	_ak820_outline_0020
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AC6F 90 0D 2B         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AC72 12 38 2D         [24]  956 	lcall	_ak820_outline_0058
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AC75 74 01            [12]  958 	mov	a,#0x01
      00AC77 12 43 79         [24]  959 	lcall	_ak820_outline_0166
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AC7A 90 0D 2A         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AC7D E0               [24]  962 	movx	a,@dptr
      00AC7E FB               [12]  963 	mov	r3,a
      00AC7F BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AC82 80 01            [24]  965 	sjmp	00102$
      00AC84                        966 00520$:
      00AC84 22               [24]  967 	ret
      00AC85                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AC85 90 0F 0D         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AC88 E0               [24]  971 	movx	a,@dptr
      00AC89 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AC8B 12 38 69         [24]  974 	lcall	_ak820_outline_0103
      00AC8E FA               [12]  975 	mov	r2,a
      00AC8F BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00AC92 80 01            [24]  977 	sjmp	00104$
      00AC94                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00AC94 22               [24]  980 	ret
      00AC95                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AC95 12 43 52         [24]  983 	lcall	_ak820_outline_0085
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AC98 FA               [12]  985 	mov	r2,a
      00AC99 60 21            [24]  986 	jz	00114$
      00AC9B BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00AC9E 80 1C            [24]  988 	sjmp	00114$
      00ACA0                        989 00524$:
      00ACA0 BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00ACA3 80 17            [24]  991 	sjmp	00114$
      00ACA5                        992 00525$:
      00ACA5 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00ACA8 80 12            [24]  994 	sjmp	00114$
      00ACAA                        995 00526$:
      00ACAA BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00ACAD 80 0D            [24]  997 	sjmp	00114$
      00ACAF                        998 00527$:
      00ACAF BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00ACB2 80 08            [24] 1000 	sjmp	00114$
      00ACB4                       1001 00528$:
      00ACB4 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00ACB7 80 03            [24] 1003 	sjmp	00530$
      00ACB9                       1004 00529$:
      00ACB9 02 B1 DA         [24] 1005 	ljmp	00171$
      00ACBC                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00ACBC                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00ACBC 12 38 69         [24] 1010 	lcall	_ak820_outline_0103
      00ACBF FA               [12] 1011 	mov	r2,a
      00ACC0 BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00ACC3 80 6B            [24] 1013 	sjmp	00115$
      00ACC5                       1014 00531$:
      00ACC5 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00ACC8 80 73            [24] 1016 	sjmp	00116$
      00ACCA                       1017 00532$:
      00ACCA BA 03 02         [24] 1018 	cjne	r2,#0x03,00533$
      00ACCD A1 FB            [24] 1019 	ajmp	00125$
      00ACCF                       1020 00533$:
      00ACCF BA 04 02         [24] 1021 	cjne	r2,#0x04,00534$
      00ACD2 C1 8D            [12] 1022 	ajmp	00129$
      00ACD4                       1023 00534$:
      00ACD4 BA 05 02         [24] 1024 	cjne	r2,#0x05,00535$
      00ACD7 C1 C6            [12] 1025 	ajmp	00130$
      00ACD9                       1026 00535$:
      00ACD9 BA 06 03         [24] 1027 	cjne	r2,#0x06,00536$
      00ACDC 02 AF 33         [24] 1028 	ljmp	00135$
      00ACDF                       1029 00536$:
      00ACDF BA 07 03         [24] 1030 	cjne	r2,#0x07,00537$
      00ACE2 02 AF 45         [24] 1031 	ljmp	00136$
      00ACE5                       1032 00537$:
      00ACE5 BA 08 03         [24] 1033 	cjne	r2,#0x08,00538$
      00ACE8 02 AF 60         [24] 1034 	ljmp	00137$
      00ACEB                       1035 00538$:
      00ACEB BA 09 03         [24] 1036 	cjne	r2,#0x09,00539$
      00ACEE 02 AF 7B         [24] 1037 	ljmp	00138$
      00ACF1                       1038 00539$:
      00ACF1 BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00ACF4 02 B1 6A         [24] 1040 	ljmp	00161$
      00ACF7                       1041 00540$:
      00ACF7 BA 0C 03         [24] 1042 	cjne	r2,#0x0c,00541$
      00ACFA 02 AF 96         [24] 1043 	ljmp	00139$
      00ACFD                       1044 00541$:
      00ACFD BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00AD00 02 AF B7         [24] 1046 	ljmp	00140$
      00AD03                       1047 00542$:
      00AD03 BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00AD06 02 AF DF         [24] 1049 	ljmp	00141$
      00AD09                       1050 00543$:
      00AD09 BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00AD0C 02 B0 26         [24] 1052 	ljmp	00144$
      00AD0F                       1053 00544$:
      00AD0F BA 10 03         [24] 1054 	cjne	r2,#0x10,00545$
      00AD12 02 B0 94         [24] 1055 	ljmp	00151$
      00AD15                       1056 00545$:
      00AD15 BA 11 03         [24] 1057 	cjne	r2,#0x11,00546$
      00AD18 02 B0 AC         [24] 1058 	ljmp	00154$
      00AD1B                       1059 00546$:
      00AD1B BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00AD1E 02 B0 CC         [24] 1061 	ljmp	00155$
      00AD21                       1062 00547$:
      00AD21 BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00AD24 02 B1 12         [24] 1064 	ljmp	00158$
      00AD27                       1065 00548$:
      00AD27 BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00AD2A 02 B1 A9         [24] 1067 	ljmp	00168$
      00AD2D                       1068 00549$:
      00AD2D 02 B1 C2         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00AD30                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00AD30 12 38 A3         [24] 1073 	lcall	_ak820_outline_0132
      00AD33 E4               [12] 1074 	clr	a
      00AD34 12 43 13         [24] 1075 	lcall	_ak820_outline_0037
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00AD37 74 09            [12] 1077 	mov	a,#0x09
      00AD39 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00AD3A 02 B1 DA         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00AD3D                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00AD3D 12 43 52         [24] 1084 	lcall	_ak820_outline_0085
      00AD40 FA               [12] 1085 	mov	r2,a
      00AD41 BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00AD44 80 0C            [24] 1087 	sjmp	00117$
      00AD46                       1088 00550$:
      00AD46 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00AD49 80 32            [24] 1090 	sjmp	00118$
      00AD4B                       1091 00551$:
      00AD4B BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00AD4E A1 B7            [24] 1093 	ajmp	00119$
      00AD50                       1094 00552$:
      00AD50 A1 E1            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00AD52                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AD52 12 4E 86         [24] 1099 	lcall	_timer_read32
      00AD55 85 82 3C         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD58 85 83 3D         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD5B 85 F0 3E         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD5E F5 3F            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AD60 12 38 92         [24] 1105 	lcall	_ak820_outline_0124
      00AD63 A3               [24] 1106 	inc	dptr
      00AD64 A3               [24] 1107 	inc	dptr
      00AD65 E5 3F            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD67 12 43 13         [24] 1109 	lcall	_ak820_outline_0037
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AD6A A3               [24] 1111 	inc	dptr
      00AD6B E5 3E            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD6D F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AD6E 12 48 CB         [24] 1115 	lcall	_ak820_outline_0022
      00AD71 E5 3D            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD73 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AD74 12 43 09         [24] 1119 	lcall	_ak820_outline_0014
      00AD77 E5 3C            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD79 F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00AD7A 02 B1 DA         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00AD7D                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AD7D C0 03            [24] 1127 	push	ar3
      00AD7F C0 07            [24] 1128 	push	ar7
      00AD81 C0 06            [24] 1129 	push	ar6
      00AD83 C0 03            [24] 1130 	push	ar3
      00AD85 71 E2            [12] 1131 	acall	_via_get_layout_options
      00AD87 85 82 3C         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD8A 85 83 3D         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD8D 85 F0 3E         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD90 F5 3F            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AD92 D0 03            [24] 1136 	pop	ar3
      00AD94 D0 06            [24] 1137 	pop	ar6
      00AD96 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AD98 12 38 92         [24] 1140 	lcall	_ak820_outline_0124
      00AD9B A3               [24] 1141 	inc	dptr
      00AD9C A3               [24] 1142 	inc	dptr
      00AD9D E5 3F            [12] 1143 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD9F 12 43 13         [24] 1144 	lcall	_ak820_outline_0037
                                   1145 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00ADA2 A3               [24] 1146 	inc	dptr
      00ADA3 E5 3E            [12] 1147 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ADA5 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00ADA6 12 48 CB         [24] 1150 	lcall	_ak820_outline_0022
      00ADA9 E5 3D            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ADAB F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00ADAC 12 43 09         [24] 1154 	lcall	_ak820_outline_0014
      00ADAF E5 3C            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00ADB1 F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00ADB2 D0 03            [24] 1158 	pop	ar3
      00ADB4 02 B1 DA         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00ADB7                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00ADB7 90 0F 0C         [24] 1163 	mov	dptr,#_vial_unlocked
      00ADBA E0               [24] 1164 	movx	a,@dptr
      00ADBB 70 03            [24] 1165 	jnz	00553$
      00ADBD 02 B1 DA         [24] 1166 	ljmp	00171$
      00ADC0                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00ADC0 7A 01            [12] 1169 	mov	r2,#0x01
      00ADC2 79 00            [12] 1170 	mov	r1,#0x00
      00ADC4                       1171 00173$:
      00ADC4 B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00ADC7                       1173 00554$:
      00ADC7 40 03            [24] 1174 	jc	00555$
      00ADC9 02 B1 DA         [24] 1175 	ljmp	00171$
      00ADCC                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00ADCC 89 82            [24] 1178 	mov	dpl, r1
      00ADCE 12 5E D7         [24] 1179 	lcall	_matrix_get_row
      00ADD1 A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00ADD3 EA               [12] 1182 	mov	a,r2
      00ADD4 2C               [12] 1183 	add	a, r4
      00ADD5 F5 82            [12] 1184 	mov	dpl,a
      00ADD7 E4               [12] 1185 	clr	a
      00ADD8 3D               [12] 1186 	addc	a, r5
      00ADD9 F5 83            [12] 1187 	mov	dph,a
      00ADDB 0A               [12] 1188 	inc	r2
      00ADDC E8               [12] 1189 	mov	a,r0
      00ADDD F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00ADDE 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00ADDF 80 E3            [24] 1194 	sjmp	00173$
      00ADE1                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00ADE1 12 4E 19         [24] 1197 	lcall	_ak820_outline_0080
      00ADE4 90 0D 26         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ADE7 12 B1 FF         [24] 1199 	lcall	_ak820_outline_0046
      00ADEA C0 07            [24] 1200 	push	ar7
      00ADEC C0 06            [24] 1201 	push	ar6
      00ADEE C0 03            [24] 1202 	push	ar3
      00ADF0 91 52            [24] 1203 	acall	_raw_hid_receive_kb
      00ADF2 D0 03            [24] 1204 	pop	ar3
      00ADF4 D0 06            [24] 1205 	pop	ar6
      00ADF6 D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00ADF8 02 B1 DA         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00ADFB                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00ADFB 12 43 52         [24] 1212 	lcall	_ak820_outline_0085
      00ADFE FA               [12] 1213 	mov	r2,a
      00ADFF BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00AE02 80 02            [24] 1215 	sjmp	00557$
      00AE04                       1216 00556$:
      00AE04 C1 73            [12] 1217 	ajmp	00127$
      00AE06                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AE06 C0 03            [24] 1220 	push	ar3
      00AE08 12 38 25         [24] 1221 	lcall	_ak820_outline_0035
      00AE0B F8               [12] 1222 	mov	r0,a
      00AE0C 79 00            [12] 1223 	mov	r1,#0x00
      00AE0E 7B 00            [12] 1224 	mov	r3,#0x00
      00AE10 88 3F            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AE12 8B 3C            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AE14 8B 3D            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AE16 8B 3E            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AE18 12 48 B7         [24] 1229 	lcall	_ak820_outline_0018
      00AE1B F8               [12] 1230 	mov	r0,a
      00AE1C 89 03            [24] 1231 	mov	ar3,r1
      00AE1E 88 02            [24] 1232 	mov	ar2,r0
      00AE20 E4               [12] 1233 	clr	a
      00AE21 42 3C            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00AE23 E9               [12] 1235 	mov	a,r1
      00AE24 42 3D            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AE26 EA               [12] 1237 	mov	a,r2
      00AE27 42 3E            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AE29 EB               [12] 1239 	mov	a,r3
      00AE2A 42 3F            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AE2C 12 48 CB         [24] 1241 	lcall	_ak820_outline_0022
      00AE2F E0               [24] 1242 	movx	a,@dptr
      00AE30 F8               [12] 1243 	mov	r0,a
      00AE31 79 00            [12] 1244 	mov	r1,#0x00
      00AE33 7A 00            [12] 1245 	mov	r2,#0x00
      00AE35 8A 03            [24] 1246 	mov	ar3,r2
      00AE37 89 02            [24] 1247 	mov	ar2,r1
      00AE39 88 01            [24] 1248 	mov	ar1,r0
      00AE3B E4               [12] 1249 	clr	a
      00AE3C 42 3C            [12] 1250 	orl	_raw_hid_receive_sloc0_1_0,a
      00AE3E E9               [12] 1251 	mov	a,r1
      00AE3F 42 3D            [12] 1252 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AE41 EA               [12] 1253 	mov	a,r2
      00AE42 42 3E            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AE44 EB               [12] 1255 	mov	a,r3
      00AE45 42 3F            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AE47 12 43 09         [24] 1257 	lcall	_ak820_outline_0014
      00AE4A E0               [24] 1258 	movx	a,@dptr
      00AE4B F8               [12] 1259 	mov	r0,a
      00AE4C E4               [12] 1260 	clr	a
      00AE4D F9               [12] 1261 	mov	r1,a
      00AE4E FA               [12] 1262 	mov	r2,a
      00AE4F FB               [12] 1263 	mov	r3,a
      00AE50 E5 3D            [12] 1264 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AE52 42 01            [12] 1265 	orl	ar1,a
      00AE54 E5 3E            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AE56 42 02            [12] 1267 	orl	ar2,a
      00AE58 E5 3F            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AE5A 42 03            [12] 1269 	orl	ar3,a
                                   1270 ;	quantum/via.c:323: via_set_layout_options(value);
      00AE5C 12 4E 2D         [24] 1271 	lcall	_ak820_outline_0116
      00AE5F EB               [12] 1272 	mov	a, r3
      00AE60 C0 07            [24] 1273 	push	ar7
      00AE62 C0 06            [24] 1274 	push	ar6
      00AE64 C0 03            [24] 1275 	push	ar3
      00AE66 71 FB            [12] 1276 	acall	_via_set_layout_options
      00AE68 D0 03            [24] 1277 	pop	ar3
      00AE6A D0 06            [24] 1278 	pop	ar6
      00AE6C D0 07            [24] 1279 	pop	ar7
                                   1280 ;	quantum/via.c:324: break;
      00AE6E D0 03            [24] 1281 	pop	ar3
      00AE70 02 B1 DA         [24] 1282 	ljmp	00171$
                                   1283 ;	quantum/via.c:326: default: {
      00AE73                       1284 00127$:
                                   1285 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AE73 12 4E 19         [24] 1286 	lcall	_ak820_outline_0080
      00AE76 90 0D 26         [24] 1287 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AE79 12 B1 FF         [24] 1288 	lcall	_ak820_outline_0046
      00AE7C C0 07            [24] 1289 	push	ar7
      00AE7E C0 06            [24] 1290 	push	ar6
      00AE80 C0 03            [24] 1291 	push	ar3
      00AE82 91 52            [24] 1292 	acall	_raw_hid_receive_kb
      00AE84 D0 03            [24] 1293 	pop	ar3
      00AE86 D0 06            [24] 1294 	pop	ar6
      00AE88 D0 07            [24] 1295 	pop	ar7
                                   1296 ;	quantum/via.c:331: break;
      00AE8A 02 B1 DA         [24] 1297 	ljmp	00171$
                                   1298 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AE8D                       1299 00129$:
                                   1300 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AE8D 12 43 52         [24] 1301 	lcall	_ak820_outline_0085
      00AE90 FA               [12] 1302 	mov	r2,a
      00AE91 12 38 25         [24] 1303 	lcall	_ak820_outline_0035
      00AE94 F9               [12] 1304 	mov	r1,a
      00AE95 12 48 B7         [24] 1305 	lcall	_ak820_outline_0018
      00AE98 F8               [12] 1306 	mov	r0,a
      00AE99 90 0B A1         [24] 1307 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AE9C E9               [12] 1308 	mov	a,r1
      00AE9D F0               [24] 1309 	movx	@dptr,a
      00AE9E 90 0B A2         [24] 1310 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AEA1 E8               [12] 1311 	mov	a,r0
      00AEA2 F0               [24] 1312 	movx	@dptr,a
      00AEA3 8A 82            [24] 1313 	mov	dpl, r2
      00AEA5 C0 07            [24] 1314 	push	ar7
      00AEA7 C0 06            [24] 1315 	push	ar6
      00AEA9 C0 03            [24] 1316 	push	ar3
      00AEAB 12 88 A7         [24] 1317 	lcall	_dynamic_keymap_get_keycode
      00AEAE 12 B2 2B         [24] 1318 	lcall	_ak820_outline_0193
      00AEB1 D0 03            [24] 1319 	pop	ar3
      00AEB3 D0 06            [24] 1320 	pop	ar6
      00AEB5 D0 07            [24] 1321 	pop	ar7
                                   1322 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AEB7 12 48 CB         [24] 1323 	lcall	_ak820_outline_0022
      00AEBA 8A 00            [24] 1324 	mov	ar0,r2
      00AEBC E8               [12] 1325 	mov	a,r0
      00AEBD F0               [24] 1326 	movx	@dptr,a
                                   1327 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AEBE 12 43 09         [24] 1328 	lcall	_ak820_outline_0014
      00AEC1 E9               [12] 1329 	mov	a,r1
      00AEC2 F0               [24] 1330 	movx	@dptr,a
                                   1331 ;	quantum/via.c:337: break;
      00AEC3 02 B1 DA         [24] 1332 	ljmp	00171$
                                   1333 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AEC6                       1334 00130$:
                                   1335 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AEC6 90 0F 0C         [24] 1336 	mov	dptr,#_vial_unlocked
      00AEC9 E0               [24] 1337 	movx	a,@dptr
      00AECA 70 19            [24] 1338 	jnz	00132$
      00AECC 12 48 CB         [24] 1339 	lcall	_ak820_outline_0022
      00AECF E0               [24] 1340 	movx	a,@dptr
      00AED0 FA               [12] 1341 	mov	r2,a
      00AED1 BA 7C 11         [24] 1342 	cjne	r2,#0x7c,00132$
      00AED4 74 05            [12] 1343 	mov	a,#0x05
      00AED6 2E               [12] 1344 	add	a, r6
      00AED7 12 38 0B         [24] 1345 	lcall	_ak820_outline_0019
      00AEDA 70 09            [24] 1346 	jnz	00132$
                                   1347 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AEDC 12 38 92         [24] 1348 	lcall	_ak820_outline_0124
      00AEDF 74 FF            [12] 1349 	mov	a,#0xff
      00AEE1 F0               [24] 1350 	movx	@dptr,a
                                   1351 ;	quantum/via.c:345: break;
      00AEE2 02 B1 DA         [24] 1352 	ljmp	00171$
      00AEE5                       1353 00132$:
                                   1354 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AEE5 C0 03            [24] 1355 	push	ar3
      00AEE7 12 43 52         [24] 1356 	lcall	_ak820_outline_0085
      00AEEA F5 41            [12] 1357 	mov	_raw_hid_receive_sloc2_1_0,a
      00AEEC 12 38 25         [24] 1358 	lcall	_ak820_outline_0035
      00AEEF F5 40            [12] 1359 	mov	_raw_hid_receive_sloc1_1_0,a
      00AEF1 12 48 B7         [24] 1360 	lcall	_ak820_outline_0018
      00AEF4 F5 3C            [12] 1361 	mov	_raw_hid_receive_sloc0_1_0,a
      00AEF6 12 48 CB         [24] 1362 	lcall	_ak820_outline_0022
      00AEF9 E0               [24] 1363 	movx	a,@dptr
      00AEFA FB               [12] 1364 	mov	r3,a
      00AEFB 78 00            [12] 1365 	mov	r0,#0x00
      00AEFD 12 43 09         [24] 1366 	lcall	_ak820_outline_0014
      00AF00 E0               [24] 1367 	movx	a,@dptr
      00AF01 7A 00            [12] 1368 	mov	r2,#0x00
      00AF03 42 00            [12] 1369 	orl	ar0,a
      00AF05 EA               [12] 1370 	mov	a,r2
      00AF06 42 03            [12] 1371 	orl	ar3,a
      00AF08 90 0B A4         [24] 1372 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00AF0B E5 40            [12] 1373 	mov	a,_raw_hid_receive_sloc1_1_0
      00AF0D F0               [24] 1374 	movx	@dptr,a
      00AF0E 90 0B A5         [24] 1375 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00AF11 E5 3C            [12] 1376 	mov	a,_raw_hid_receive_sloc0_1_0
      00AF13 F0               [24] 1377 	movx	@dptr,a
      00AF14 90 0B A6         [24] 1378 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00AF17 E8               [12] 1379 	mov	a,r0
      00AF18 F0               [24] 1380 	movx	@dptr,a
      00AF19 EB               [12] 1381 	mov	a,r3
      00AF1A A3               [24] 1382 	inc	dptr
      00AF1B F0               [24] 1383 	movx	@dptr,a
      00AF1C 85 41 82         [24] 1384 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00AF1F C0 07            [24] 1385 	push	ar7
      00AF21 C0 06            [24] 1386 	push	ar6
      00AF23 C0 03            [24] 1387 	push	ar3
      00AF25 12 88 F4         [24] 1388 	lcall	_dynamic_keymap_set_keycode
      00AF28 D0 03            [24] 1389 	pop	ar3
      00AF2A D0 06            [24] 1390 	pop	ar6
      00AF2C D0 07            [24] 1391 	pop	ar7
                                   1392 ;	quantum/via.c:349: break;
      00AF2E D0 03            [24] 1393 	pop	ar3
      00AF30 02 B1 DA         [24] 1394 	ljmp	00171$
                                   1395 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00AF33                       1396 00135$:
                                   1397 ;	quantum/via.c:352: dynamic_keymap_reset();
      00AF33 C0 07            [24] 1398 	push	ar7
      00AF35 C0 06            [24] 1399 	push	ar6
      00AF37 C0 03            [24] 1400 	push	ar3
      00AF39 12 8C 8C         [24] 1401 	lcall	_dynamic_keymap_reset
      00AF3C D0 03            [24] 1402 	pop	ar3
      00AF3E D0 06            [24] 1403 	pop	ar6
      00AF40 D0 07            [24] 1404 	pop	ar7
                                   1405 ;	quantum/via.c:353: break;
      00AF42 02 B1 DA         [24] 1406 	ljmp	00171$
                                   1407 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AF45                       1408 00136$:
                                   1409 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AF45 12 4E 19         [24] 1410 	lcall	_ak820_outline_0080
      00AF48 90 0E 85         [24] 1411 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AF4B 12 B1 FF         [24] 1412 	lcall	_ak820_outline_0046
      00AF4E C0 07            [24] 1413 	push	ar7
      00AF50 C0 06            [24] 1414 	push	ar6
      00AF52 C0 03            [24] 1415 	push	ar3
      00AF54 12 BD 0B         [24] 1416 	lcall	_vialrgb_set_value
      00AF57 D0 03            [24] 1417 	pop	ar3
      00AF59 D0 06            [24] 1418 	pop	ar6
      00AF5B D0 07            [24] 1419 	pop	ar7
                                   1420 ;	quantum/via.c:375: break;
      00AF5D 02 B1 DA         [24] 1421 	ljmp	00171$
                                   1422 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AF60                       1423 00137$:
                                   1424 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AF60 12 4E 19         [24] 1425 	lcall	_ak820_outline_0080
      00AF63 90 0E 81         [24] 1426 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AF66 12 B1 FF         [24] 1427 	lcall	_ak820_outline_0046
      00AF69 C0 07            [24] 1428 	push	ar7
      00AF6B C0 06            [24] 1429 	push	ar6
      00AF6D C0 03            [24] 1430 	push	ar3
      00AF6F 12 BB A7         [24] 1431 	lcall	_vialrgb_get_value
      00AF72 D0 03            [24] 1432 	pop	ar3
      00AF74 D0 06            [24] 1433 	pop	ar6
      00AF76 D0 07            [24] 1434 	pop	ar7
                                   1435 ;	quantum/via.c:397: break;
      00AF78 02 B1 DA         [24] 1436 	ljmp	00171$
                                   1437 ;	quantum/via.c:399: case id_lighting_save: {
      00AF7B                       1438 00138$:
                                   1439 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AF7B 12 4E 19         [24] 1440 	lcall	_ak820_outline_0080
      00AF7E 90 0E 89         [24] 1441 	mov	dptr,#_vialrgb_save_PARM_2
      00AF81 12 B1 FF         [24] 1442 	lcall	_ak820_outline_0046
      00AF84 C0 07            [24] 1443 	push	ar7
      00AF86 C0 06            [24] 1444 	push	ar6
      00AF88 C0 03            [24] 1445 	push	ar3
      00AF8A 12 BD 98         [24] 1446 	lcall	_vialrgb_save
      00AF8D D0 03            [24] 1447 	pop	ar3
      00AF8F D0 06            [24] 1448 	pop	ar6
      00AF91 D0 07            [24] 1449 	pop	ar7
                                   1450 ;	quantum/via.c:419: break;
      00AF93 02 B1 DA         [24] 1451 	ljmp	00171$
                                   1452 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AF96                       1453 00139$:
                                   1454 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AF96 C0 07            [24] 1455 	push	ar7
      00AF98 C0 06            [24] 1456 	push	ar6
      00AF9A C0 05            [24] 1457 	push	ar5
      00AF9C C0 04            [24] 1458 	push	ar4
      00AF9E C0 03            [24] 1459 	push	ar3
      00AFA0 12 90 B7         [24] 1460 	lcall	_dynamic_keymap_macro_get_count
      00AFA3 AA 82            [24] 1461 	mov	r2, dpl
      00AFA5 D0 03            [24] 1462 	pop	ar3
      00AFA7 D0 04            [24] 1463 	pop	ar4
      00AFA9 D0 05            [24] 1464 	pop	ar5
      00AFAB D0 06            [24] 1465 	pop	ar6
      00AFAD D0 07            [24] 1466 	pop	ar7
      00AFAF 12 38 A3         [24] 1467 	lcall	_ak820_outline_0132
      00AFB2 EA               [12] 1468 	mov	a,r2
      00AFB3 F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	quantum/via.c:430: break;
      00AFB4 02 B1 DA         [24] 1471 	ljmp	00171$
                                   1472 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AFB7                       1473 00140$:
                                   1474 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AFB7 C0 07            [24] 1475 	push	ar7
      00AFB9 C0 06            [24] 1476 	push	ar6
      00AFBB C0 05            [24] 1477 	push	ar5
      00AFBD C0 04            [24] 1478 	push	ar4
      00AFBF C0 03            [24] 1479 	push	ar3
      00AFC1 12 90 BB         [24] 1480 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AFC4 12 B2 2B         [24] 1481 	lcall	_ak820_outline_0193
      00AFC7 D0 03            [24] 1482 	pop	ar3
      00AFC9 D0 04            [24] 1483 	pop	ar4
      00AFCB D0 05            [24] 1484 	pop	ar5
      00AFCD D0 06            [24] 1485 	pop	ar6
      00AFCF D0 07            [24] 1486 	pop	ar7
                                   1487 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AFD1 8A 00            [24] 1488 	mov	ar0,r2
      00AFD3 12 38 A3         [24] 1489 	lcall	_ak820_outline_0132
      00AFD6 E8               [12] 1490 	mov	a,r0
      00AFD7 12 43 13         [24] 1491 	lcall	_ak820_outline_0037
                                   1492 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AFDA E9               [12] 1493 	mov	a,r1
      00AFDB F0               [24] 1494 	movx	@dptr,a
                                   1495 ;	quantum/via.c:436: break;
      00AFDC 02 B1 DA         [24] 1496 	ljmp	00171$
                                   1497 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AFDF                       1498 00141$:
                                   1499 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AFDF C0 03            [24] 1500 	push	ar3
      00AFE1 12 B1 E8         [24] 1501 	lcall	_ak820_outline_0003
      00AFE4 89 3C            [24] 1502 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AFE6 8A 3D            [24] 1503 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1504 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AFE8 12 48 B7         [24] 1505 	lcall	_ak820_outline_0018
      00AFEB FB               [12] 1506 	mov	r3,a
                                   1507 ;	quantum/via.c:441: if (size <= 28)
      00AFEC 8B 42            [24] 1508 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AFEE 75 43 00         [24] 1509 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AFF1 C3               [12] 1510 	clr	c
      00AFF2 74 1C            [12] 1511 	mov	a,#0x1c
      00AFF4 9B               [12] 1512 	subb	a,r3
      00AFF5 D0 03            [24] 1513 	pop	ar3
      00AFF7 50 03            [24] 1514 	jnc	00562$
      00AFF9 02 B1 DA         [24] 1515 	ljmp	00171$
      00AFFC                       1516 00562$:
                                   1517 ;	free result
                                   1518 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AFFC 12 B2 08         [24] 1519 	lcall	_ak820_outline_0074
      00AFFF 90 0C 05         [24] 1520 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00B002 E5 42            [12] 1521 	mov	a,_raw_hid_receive_sloc3_1_0
      00B004 F0               [24] 1522 	movx	@dptr,a
      00B005 E5 43            [12] 1523 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B007 A3               [24] 1524 	inc	dptr
      00B008 F0               [24] 1525 	movx	@dptr,a
      00B009 90 0C 07         [24] 1526 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00B00C 12 B2 12         [24] 1527 	lcall	_ak820_outline_0092
      00B00F 85 3C 82         [24] 1528 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00B012 85 3D 83         [24] 1529 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00B015 C0 07            [24] 1530 	push	ar7
      00B017 C0 06            [24] 1531 	push	ar6
      00B019 C0 03            [24] 1532 	push	ar3
      00B01B 12 90 BF         [24] 1533 	lcall	_dynamic_keymap_macro_get_buffer
      00B01E D0 03            [24] 1534 	pop	ar3
      00B020 D0 06            [24] 1535 	pop	ar6
      00B022 D0 07            [24] 1536 	pop	ar7
                                   1537 ;	quantum/via.c:443: break;
      00B024 21 DA            [12] 1538 	ajmp	00171$
                                   1539 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00B026                       1540 00144$:
                                   1541 ;	quantum/via.c:448: if (!vial_unlocked) {
      00B026 90 0F 0C         [24] 1542 	mov	dptr,#_vial_unlocked
      00B029 E0               [24] 1543 	movx	a,@dptr
      00B02A 70 01            [24] 1544 	jnz	00146$
                                   1545 ;	quantum/via.c:450: return;
      00B02C 22               [24] 1546 	ret
      00B02D                       1547 00146$:
                                   1548 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B02D C0 03            [24] 1549 	push	ar3
      00B02F 12 B1 E8         [24] 1550 	lcall	_ak820_outline_0003
      00B032 89 42            [24] 1551 	mov	_raw_hid_receive_sloc3_1_0,r1
      00B034 8A 43            [24] 1552 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1553 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00B036 12 48 B7         [24] 1554 	lcall	_ak820_outline_0018
      00B039 F5 3C            [12] 1555 	mov	_raw_hid_receive_sloc0_1_0, a
      00B03B 75 3D 00         [24] 1556 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1557 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00B03E 85 3C 44         [24] 1558 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00B041 85 3D 45         [24] 1559 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00B044 C3               [12] 1560 	clr	c
      00B045 74 1C            [12] 1561 	mov	a,#0x1c
      00B047 95 44            [12] 1562 	subb	a,_raw_hid_receive_sloc4_1_0
      00B049 E4               [12] 1563 	clr	a
      00B04A 95 45            [12] 1564 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B04C D0 03            [24] 1565 	pop	ar3
      00B04E 40 43            [24] 1566 	jc	00147$
                                   1567 ;	free result
      00B050 8B 01            [24] 1568 	mov	ar1,r3
      00B052 7A 00            [12] 1569 	mov	r2,#0x00
      00B054 E9               [12] 1570 	mov	a,r1
      00B055 24 FC            [12] 1571 	add	a,#0xfc
      00B057 F9               [12] 1572 	mov	r1,a
      00B058 EA               [12] 1573 	mov	a,r2
      00B059 34 FF            [12] 1574 	addc	a,#0xff
      00B05B FA               [12] 1575 	mov	r2,a
      00B05C C3               [12] 1576 	clr	c
      00B05D E9               [12] 1577 	mov	a,r1
      00B05E 95 44            [12] 1578 	subb	a,_raw_hid_receive_sloc4_1_0
      00B060 EA               [12] 1579 	mov	a,r2
      00B061 95 45            [12] 1580 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B063 40 2E            [24] 1581 	jc	00147$
                                   1582 ;	free result
      00B065 12 B2 08         [24] 1583 	lcall	_ak820_outline_0074
      00B068 90 0C 0C         [24] 1584 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00B06B E5 3C            [12] 1585 	mov	a,_raw_hid_receive_sloc0_1_0
      00B06D F0               [24] 1586 	movx	@dptr,a
      00B06E E5 3D            [12] 1587 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B070 A3               [24] 1588 	inc	dptr
      00B071 F0               [24] 1589 	movx	@dptr,a
      00B072 90 0C 0E         [24] 1590 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00B075 12 B2 12         [24] 1591 	lcall	_ak820_outline_0092
      00B078 85 42 82         [24] 1592 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00B07B 85 43 83         [24] 1593 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00B07E C0 07            [24] 1594 	push	ar7
      00B080 C0 06            [24] 1595 	push	ar6
      00B082 C0 03            [24] 1596 	push	ar3
      00B084 12 91 0E         [24] 1597 	lcall	_dynamic_keymap_macro_set_buffer
      00B087 E5 82            [12] 1598 	mov	a, dpl
      00B089 D0 03            [24] 1599 	pop	ar3
      00B08B D0 06            [24] 1600 	pop	ar6
      00B08D D0 07            [24] 1601 	pop	ar7
      00B08F 60 02            [24] 1602 	jz	00566$
      00B091 21 DA            [12] 1603 	ajmp	00171$
      00B093                       1604 00566$:
      00B093                       1605 00147$:
      00B093 22               [24] 1606 	ret
                                   1607 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B094                       1608 00151$:
                                   1609 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B094 90 0F 0C         [24] 1610 	mov	dptr,#_vial_unlocked
      00B097 E0               [24] 1611 	movx	a,@dptr
      00B098 70 01            [24] 1612 	jnz	00153$
      00B09A 22               [24] 1613 	ret
      00B09B                       1614 00153$:
                                   1615 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B09B C0 07            [24] 1616 	push	ar7
      00B09D C0 06            [24] 1617 	push	ar6
      00B09F C0 03            [24] 1618 	push	ar3
      00B0A1 12 91 40         [24] 1619 	lcall	_dynamic_keymap_macro_reset
      00B0A4 D0 03            [24] 1620 	pop	ar3
      00B0A6 D0 06            [24] 1621 	pop	ar6
      00B0A8 D0 07            [24] 1622 	pop	ar7
                                   1623 ;	quantum/via.c:473: break;
      00B0AA 21 DA            [12] 1624 	ajmp	00171$
                                   1625 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B0AC                       1626 00154$:
                                   1627 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B0AC C0 07            [24] 1628 	push	ar7
      00B0AE C0 06            [24] 1629 	push	ar6
      00B0B0 C0 05            [24] 1630 	push	ar5
      00B0B2 C0 04            [24] 1631 	push	ar4
      00B0B4 C0 03            [24] 1632 	push	ar3
      00B0B6 12 88 6C         [24] 1633 	lcall	_dynamic_keymap_get_layer_count
      00B0B9 AA 82            [24] 1634 	mov	r2, dpl
      00B0BB D0 03            [24] 1635 	pop	ar3
      00B0BD D0 04            [24] 1636 	pop	ar4
      00B0BF D0 05            [24] 1637 	pop	ar5
      00B0C1 D0 06            [24] 1638 	pop	ar6
      00B0C3 D0 07            [24] 1639 	pop	ar7
      00B0C5 12 38 A3         [24] 1640 	lcall	_ak820_outline_0132
      00B0C8 EA               [12] 1641 	mov	a,r2
      00B0C9 F0               [24] 1642 	movx	@dptr,a
                                   1643 ;	quantum/via.c:477: break;
      00B0CA 21 DA            [12] 1644 	ajmp	00171$
                                   1645 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B0CC                       1646 00155$:
                                   1647 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B0CC C0 03            [24] 1648 	push	ar3
      00B0CE 12 B1 E8         [24] 1649 	lcall	_ak820_outline_0003
      00B0D1 89 44            [24] 1650 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B0D3 8A 45            [24] 1651 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1652 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B0D5 12 48 B7         [24] 1653 	lcall	_ak820_outline_0018
      00B0D8 FB               [12] 1654 	mov	r3,a
                                   1655 ;	quantum/via.c:482: if (size <= 28)
      00B0D9 8B 42            [24] 1656 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B0DB 75 43 00         [24] 1657 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B0DE C3               [12] 1658 	clr	c
      00B0DF 74 1C            [12] 1659 	mov	a,#0x1c
      00B0E1 9B               [12] 1660 	subb	a,r3
      00B0E2 D0 03            [24] 1661 	pop	ar3
      00B0E4 50 02            [24] 1662 	jnc	00568$
      00B0E6 21 DA            [12] 1663 	ajmp	00171$
      00B0E8                       1664 00568$:
                                   1665 ;	free result
                                   1666 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B0E8 12 B2 08         [24] 1667 	lcall	_ak820_outline_0074
      00B0EB 90 0B EE         [24] 1668 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B0EE E5 42            [12] 1669 	mov	a,_raw_hid_receive_sloc3_1_0
      00B0F0 F0               [24] 1670 	movx	@dptr,a
      00B0F1 E5 43            [12] 1671 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B0F3 A3               [24] 1672 	inc	dptr
      00B0F4 F0               [24] 1673 	movx	@dptr,a
      00B0F5 90 0B F0         [24] 1674 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B0F8 12 B2 12         [24] 1675 	lcall	_ak820_outline_0092
      00B0FB 85 44 82         [24] 1676 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B0FE 85 45 83         [24] 1677 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B101 C0 07            [24] 1678 	push	ar7
      00B103 C0 06            [24] 1679 	push	ar6
      00B105 C0 03            [24] 1680 	push	ar3
      00B107 12 8E 83         [24] 1681 	lcall	_dynamic_keymap_get_buffer
      00B10A D0 03            [24] 1682 	pop	ar3
      00B10C D0 06            [24] 1683 	pop	ar6
      00B10E D0 07            [24] 1684 	pop	ar7
                                   1685 ;	quantum/via.c:484: break;
      00B110 21 DA            [12] 1686 	ajmp	00171$
                                   1687 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B112                       1688 00158$:
                                   1689 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B112 12 43 52         [24] 1690 	lcall	_ak820_outline_0085
      00B115 FD               [12] 1691 	mov	r5,a
      00B116 7C 00            [12] 1692 	mov	r4,#0x00
      00B118 12 38 25         [24] 1693 	lcall	_ak820_outline_0035
      00B11B 7A 00            [12] 1694 	mov	r2,#0x00
      00B11D 42 04            [12] 1695 	orl	ar4,a
      00B11F EA               [12] 1696 	mov	a,r2
      00B120 42 05            [12] 1697 	orl	ar5,a
      00B122 8C 44            [24] 1698 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B124 8D 45            [24] 1699 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1700 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B126 12 48 B7         [24] 1701 	lcall	_ak820_outline_0018
      00B129 F9               [12] 1702 	mov	r1,a
      00B12A 7A 00            [12] 1703 	mov	r2,#0x00
                                   1704 ;	quantum/via.c:489: if (size <= 28)
      00B12C 89 00            [24] 1705 	mov	ar0,r1
      00B12E E8               [12] 1706 	mov	a,r0
      00B12F 24 E3            [12] 1707 	add	a,#0xff - 0x1c
      00B131 50 02            [24] 1708 	jnc	00569$
      00B133 21 DA            [12] 1709 	ajmp	00171$
      00B135                       1710 00569$:
                                   1711 ;	free result
                                   1712 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B135 C0 03            [24] 1713 	push	ar3
      00B137 74 04            [12] 1714 	mov	a,#0x04
      00B139 2E               [12] 1715 	add	a, r6
      00B13A F8               [12] 1716 	mov	r0,a
      00B13B E4               [12] 1717 	clr	a
      00B13C 3F               [12] 1718 	addc	a, r7
      00B13D FB               [12] 1719 	mov	r3,a
      00B13E 7D 00            [12] 1720 	mov	r5,#0x00
      00B140 90 0B F5         [24] 1721 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B143 12 4E 27         [24] 1722 	lcall	_ak820_outline_0102
      00B146 90 0B F7         [24] 1723 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B149 E8               [12] 1724 	mov	a,r0
      00B14A F0               [24] 1725 	movx	@dptr,a
      00B14B EB               [12] 1726 	mov	a,r3
      00B14C A3               [24] 1727 	inc	dptr
      00B14D F0               [24] 1728 	movx	@dptr,a
      00B14E ED               [12] 1729 	mov	a,r5
      00B14F A3               [24] 1730 	inc	dptr
      00B150 F0               [24] 1731 	movx	@dptr,a
      00B151 85 44 82         [24] 1732 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B154 85 45 83         [24] 1733 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B157 C0 07            [24] 1734 	push	ar7
      00B159 C0 06            [24] 1735 	push	ar6
      00B15B C0 03            [24] 1736 	push	ar3
      00B15D 12 8E C4         [24] 1737 	lcall	_dynamic_keymap_set_buffer
      00B160 D0 03            [24] 1738 	pop	ar3
      00B162 D0 06            [24] 1739 	pop	ar6
      00B164 D0 07            [24] 1740 	pop	ar7
                                   1741 ;	quantum/via.c:491: break;
      00B166 D0 03            [24] 1742 	pop	ar3
      00B168 21 DA            [12] 1743 	ajmp	00171$
                                   1744 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B16A                       1745 00161$:
                                   1746 ;	quantum/via.c:497: if (!vial_unlocked)
      00B16A 90 0F 0C         [24] 1747 	mov	dptr,#_vial_unlocked
      00B16D E0               [24] 1748 	movx	a,@dptr
      00B16E 70 02            [24] 1749 	jnz	00570$
      00B170 21 DA            [12] 1750 	ajmp	00171$
      00B172                       1751 00570$:
                                   1752 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B172 12 B2 24         [24] 1753 	lcall	_ak820_outline_0158
      00B175 90 07 3E         [24] 1754 	mov	dptr,#_raw_hid_send_PARM_2
      00B178 12 B2 1B         [24] 1755 	lcall	_ak820_outline_0093
      00B17B C0 07            [24] 1756 	push	ar7
      00B17D C0 06            [24] 1757 	push	ar6
      00B17F C0 03            [24] 1758 	push	ar3
      00B181 12 50 72         [24] 1759 	lcall	_raw_hid_send
      00B184 D0 03            [24] 1760 	pop	ar3
      00B186 D0 06            [24] 1761 	pop	ar6
      00B188 D0 07            [24] 1762 	pop	ar7
                                   1763 ;	quantum/via.c:503: wait_ms(100);
      00B18A 7D 64            [12] 1764 	mov	r5,#0x64
      00B18C                       1765 00176$:
      00B18C ED               [12] 1766 	mov	a,r5
      00B18D 60 09            [24] 1767 	jz	00166$
      00B18F 90 00 01         [24] 1768 	mov	dptr,#0x0001
      00B192 12 5E 16         [24] 1769 	lcall	_mDelaymS
      00B195 1D               [12] 1770 	dec	r5
      00B196 80 F4            [24] 1771 	sjmp	00176$
      00B198                       1772 00166$:
                                   1773 ;	quantum/via.c:504: bootloader_jump();
      00B198 C0 07            [24] 1774 	push	ar7
      00B19A C0 06            [24] 1775 	push	ar6
      00B19C C0 03            [24] 1776 	push	ar3
      00B19E 12 34 0E         [24] 1777 	lcall	_bootloader_jump
      00B1A1 D0 03            [24] 1778 	pop	ar3
      00B1A3 D0 06            [24] 1779 	pop	ar6
      00B1A5 D0 07            [24] 1780 	pop	ar7
                                   1781 ;	quantum/via.c:505: break;
                                   1782 ;	quantum/via.c:509: case id_vial_prefix: {
      00B1A7 80 31            [24] 1783 	sjmp	00171$
      00B1A9                       1784 00168$:
                                   1785 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B1A9 12 B2 24         [24] 1786 	lcall	_ak820_outline_0158
      00B1AC 90 0D 38         [24] 1787 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B1AF 12 B2 1B         [24] 1788 	lcall	_ak820_outline_0093
      00B1B2 C0 07            [24] 1789 	push	ar7
      00B1B4 C0 06            [24] 1790 	push	ar6
      00B1B6 C0 03            [24] 1791 	push	ar3
      00B1B8 71 16            [12] 1792 	acall	_vial_handle_cmd
      00B1BA D0 03            [24] 1793 	pop	ar3
      00B1BC D0 06            [24] 1794 	pop	ar6
      00B1BE D0 07            [24] 1795 	pop	ar7
                                   1796 ;	quantum/via.c:511: break;
                                   1797 ;	quantum/via.c:514: default: {
      00B1C0 80 18            [24] 1798 	sjmp	00171$
      00B1C2                       1799 00169$:
                                   1800 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B1C2 12 B2 24         [24] 1801 	lcall	_ak820_outline_0158
      00B1C5 90 0D 26         [24] 1802 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B1C8 12 B2 1B         [24] 1803 	lcall	_ak820_outline_0093
      00B1CB C0 07            [24] 1804 	push	ar7
      00B1CD C0 06            [24] 1805 	push	ar6
      00B1CF C0 03            [24] 1806 	push	ar3
      00B1D1 12 AC 52         [24] 1807 	lcall	_raw_hid_receive_kb
      00B1D4 D0 03            [24] 1808 	pop	ar3
      00B1D6 D0 06            [24] 1809 	pop	ar6
      00B1D8 D0 07            [24] 1810 	pop	ar7
                                   1811 ;	quantum/via.c:521: skip:
      00B1DA                       1812 00171$:
                                   1813 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B1DA 7D 00            [12] 1814 	mov	r5,#0x00
      00B1DC 90 07 3E         [24] 1815 	mov	dptr,#_raw_hid_send_PARM_2
      00B1DF EB               [12] 1816 	mov	a,r3
      00B1E0 12 43 46         [24] 1817 	lcall	_ak820_outline_0071
      00B1E3 8D F0            [24] 1818 	mov	b, r5
                                   1819 ;	quantum/via.c:526: }
      00B1E5 02 50 72         [24] 1820 	ljmp	_raw_hid_send
                                   1821 	.area CSEG    (CODE)
                                   1822 	.area CONST   (CODE)
                                   1823 	.area XINIT   (CODE)
                                   1824 	.area CABS    (ABS,CODE)
                                   1825 
                                   1826 ; Experimental exact instruction outlining.
                                   1827 	.globl _ak820_outline_0001
                                   1828 	.globl _ak820_outline_0003
                                   1829 	.globl _ak820_outline_0010
                                   1830 	.globl _ak820_outline_0014
                                   1831 	.globl _ak820_outline_0015
                                   1832 	.globl _ak820_outline_0018
                                   1833 	.globl _ak820_outline_0019
                                   1834 	.globl _ak820_outline_0020
                                   1835 	.globl _ak820_outline_0022
                                   1836 	.globl _ak820_outline_0035
                                   1837 	.globl _ak820_outline_0037
                                   1838 	.globl _ak820_outline_0041
                                   1839 	.globl _ak820_outline_0046
                                   1840 	.globl _ak820_outline_0049
                                   1841 	.globl _ak820_outline_0058
                                   1842 	.globl _ak820_outline_0063
                                   1843 	.globl _ak820_outline_0071
                                   1844 	.globl _ak820_outline_0074
                                   1845 	.globl _ak820_outline_0080
                                   1846 	.globl _ak820_outline_0085
                                   1847 	.globl _ak820_outline_0092
                                   1848 	.globl _ak820_outline_0093
                                   1849 	.globl _ak820_outline_0102
                                   1850 	.globl _ak820_outline_0103
                                   1851 	.globl _ak820_outline_0111
                                   1852 	.globl _ak820_outline_0112
                                   1853 	.globl _ak820_outline_0116
                                   1854 	.globl _ak820_outline_0124
                                   1855 	.globl _ak820_outline_0127
                                   1856 	.globl _ak820_outline_0132
                                   1857 	.globl _ak820_outline_0151
                                   1858 	.globl _ak820_outline_0158
                                   1859 	.globl _ak820_outline_0160
                                   1860 	.globl _ak820_outline_0163
                                   1861 	.globl _ak820_outline_0165
                                   1862 	.globl _ak820_outline_0166
                                   1863 	.globl _ak820_outline_0193
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0003
      00B1E8                       1867 _ak820_outline_0003:
      00B1E8 8C 82            [24] 1868 	mov	dpl,r4
      00B1EA 8D 83            [24] 1869 	mov	dph,r5
      00B1EC E0               [24] 1870 	movx	a,@dptr
      00B1ED FA               [12] 1871 	mov	r2,a
      00B1EE 79 00            [12] 1872 	mov	r1,#0x00
      00B1F0 8E 82            [24] 1873 	mov	dpl,r6
      00B1F2 8F 83            [24] 1874 	mov	dph,r7
      00B1F4 A3               [24] 1875 	inc	dptr
      00B1F5 A3               [24] 1876 	inc	dptr
      00B1F6 E0               [24] 1877 	movx	a,@dptr
      00B1F7 7B 00            [12] 1878 	mov	r3,#0x00
      00B1F9 42 01            [12] 1879 	orl	ar1,a
      00B1FB EB               [12] 1880 	mov	a,r3
      00B1FC 42 02            [12] 1881 	orl	ar2,a
      00B1FE 22               [24] 1882 	ret
                                   1883 
                                   1884 	.area CSEG (CODE)
                                   1885 ; function ak820_outline_0046
      00B1FF                       1886 _ak820_outline_0046:
      00B1FF EB               [12] 1887 	mov	a,r3
      00B200 F0               [24] 1888 	movx	@dptr,a
      00B201 88 82            [24] 1889 	mov	dpl,r0
      00B203 89 83            [24] 1890 	mov	dph,r1
      00B205 8A F0            [24] 1891 	mov	b,r2
      00B207 22               [24] 1892 	ret
                                   1893 
                                   1894 	.area CSEG (CODE)
                                   1895 ; function ak820_outline_0074
      00B208                       1896 _ak820_outline_0074:
      00B208 74 04            [12] 1897 	mov	a,#0x04
      00B20A 2E               [12] 1898 	add	a,r6
      00B20B F9               [12] 1899 	mov	r1,a
      00B20C E4               [12] 1900 	clr	a
      00B20D 3F               [12] 1901 	addc	a,r7
      00B20E F8               [12] 1902 	mov	r0,a
      00B20F 7A 00            [12] 1903 	mov	r2,#0x00
      00B211 22               [24] 1904 	ret
                                   1905 
                                   1906 	.area CSEG (CODE)
                                   1907 ; function ak820_outline_0092
      00B212                       1908 _ak820_outline_0092:
      00B212 E9               [12] 1909 	mov	a,r1
      00B213 F0               [24] 1910 	movx	@dptr,a
      00B214 E8               [12] 1911 	mov	a,r0
      00B215 A3               [24] 1912 	inc	dptr
      00B216 F0               [24] 1913 	movx	@dptr,a
      00B217 EA               [12] 1914 	mov	a,r2
      00B218 A3               [24] 1915 	inc	dptr
      00B219 F0               [24] 1916 	movx	@dptr,a
      00B21A 22               [24] 1917 	ret
                                   1918 
                                   1919 	.area CSEG (CODE)
                                   1920 ; function ak820_outline_0093
      00B21B                       1921 _ak820_outline_0093:
      00B21B EB               [12] 1922 	mov	a,r3
      00B21C F0               [24] 1923 	movx	@dptr,a
      00B21D 8A 82            [24] 1924 	mov	dpl,r2
      00B21F 8C 83            [24] 1925 	mov	dph,r4
      00B221 8D F0            [24] 1926 	mov	b,r5
      00B223 22               [24] 1927 	ret
                                   1928 
                                   1929 	.area CSEG (CODE)
                                   1930 ; function ak820_outline_0158
      00B224                       1931 _ak820_outline_0158:
      00B224 8E 02            [24] 1932 	mov	ar2,r6
      00B226 8F 04            [24] 1933 	mov	ar4,r7
      00B228 7D 00            [12] 1934 	mov	r5,#0x00
      00B22A 22               [24] 1935 	ret
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0193
      00B22B                       1939 _ak820_outline_0193:
      00B22B A9 82            [24] 1940 	mov	r1,dpl
      00B22D AA 83            [24] 1941 	mov	r2,dph
      00B22F 22               [24] 1942 	ret
