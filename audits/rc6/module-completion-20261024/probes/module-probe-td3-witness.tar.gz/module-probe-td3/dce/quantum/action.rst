                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_tap_dance_cancel
                                     21 	.globl _ak820_tap_dance_before
                                     22 	.globl _pre_process_record_quantum
                                     23 	.globl _get_record_keycode
                                     24 	.globl _repeat_key_cancel
                                     25 	.globl _clear_owned_usages
                                     26 	.globl _owned_usage_key
                                     27 	.globl _clear_owned_keys
                                     28 	.globl _del_owned_key
                                     29 	.globl _add_owned_key
                                     30 	.globl _clear_owned_mods
                                     31 	.globl _del_owned_weak_mods
                                     32 	.globl _add_owned_weak_mods
                                     33 	.globl _del_owned_mods
                                     34 	.globl _add_owned_mods
                                     35 	.globl _clear_weak_mods
                                     36 	.globl _clear_mods
                                     37 	.globl _send_keyboard_report
                                     38 	.globl _layer_hold_clear
                                     39 	.globl _layer_hold_off
                                     40 	.globl _layer_hold_on
                                     41 	.globl _ak820_resolve_key
                                     42 	.globl _layer_xor
                                     43 	.globl _layer_and
                                     44 	.globl _layer_or
                                     45 	.globl _layer_off
                                     46 	.globl _layer_on
                                     47 	.globl _layer_move
                                     48 	.globl _layer_clear
                                     49 	.globl _layer_state_set
                                     50 	.globl _default_layer_xor
                                     51 	.globl _default_layer_and
                                     52 	.globl _default_layer_or
                                     53 	.globl _default_layer_set
                                     54 	.globl _post_process_record_quantum
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      000017                        590 _process_action_sloc0_1_0:
      000017                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      000021                        608 _process_action_sloc1_1_0:
      000021                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      0008D7                        618 _tp_buttons::
      0008D7                        619 	.ds 2
      0008D9                        620 _action_exec_PARM_1:
      0008D9                        621 	.ds 6
      0008DF                        622 _action_exec_record_10001_632:
      0008DF                        623 	.ds 9
      0008E8                        624 _ak820_action_exec_event_10000_636:
      0008E8                        625 	.ds 2
      0008EA                        626 _ak820_action_exec_snapshot_10000_637:
      0008EA                        627 	.ds 6
      0008F0                        628 _process_record_record_10000_640:
      0008F0                        629 	.ds 3
      0008F3                        630 _process_record_handler_record_argument_10000_648:
      0008F3                        631 	.ds 3
      0008F6                        632 _process_record_handler_action_10000_649:
      0008F6                        633 	.ds 2
      0008F8                        634 _process_action_PARM_2:
      0008F8                        635 	.ds 2
      0008FA                        636 _process_action_record_argument_10000_660:
      0008FA                        637 	.ds 3
      0008FD                        638 _process_action_on_40000_683:
      0008FD                        639 	.ds 1
      0008FE                        640 _register_code_code_10000_717:
      0008FE                        641 	.ds 1
      0008FF                        642 _unregister_code_code_10000_731:
      0008FF                        643 	.ds 1
      000900                        644 _tap_code_delay_PARM_2:
      000900                        645 	.ds 2
      000902                        646 _tap_code_delay_code_10000_744:
      000902                        647 	.ds 1
      000903                        648 _tap_code_code_10000_751:
      000903                        649 	.ds 1
      000904                        650 _register_mods_mods_10000_753:
      000904                        651 	.ds 1
      000905                        652 _unregister_mods_mods_10000_757:
      000905                        653 	.ds 1
      000906                        654 _register_weak_mods_mods_10000_761:
      000906                        655 	.ds 1
      000907                        656 _unregister_weak_mods_mods_10000_765:
      000907                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000EAC                        666 _disable_action_cache::
      000EAC                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      007534                        711 _action_exec:
                                    712 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007534 90 08 DB         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007537 12 37 ED         [24]  714 	lcall	_ak820_outline_0006
      00753A 12 35 FC         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      00753D 90 08 D9         [24]  717 	mov	dptr,#_action_exec_PARM_1
      007540 12 4A 05         [24]  718 	lcall	_ak820_tapping_before
      007543 E5 82            [12]  719 	mov	a, dpl
      007545 70 01            [24]  720 	jnz	00102$
      007547 22               [24]  721 	ret
      007548                        722 00102$:
                                    723 ;	quantum/action.c:106: if (!ak820_tap_dance_before(&event)) return;
      007548 90 08 D9         [24]  724 	mov	dptr,#_action_exec_PARM_1
      00754B 12 45 C4         [24]  725 	lcall	_ak820_tap_dance_before
      00754E E5 82            [12]  726 	mov	a, dpl
      007550 70 01            [24]  727 	jnz	00104$
      007552 22               [24]  728 	ret
      007553                        729 00104$:
                                    730 ;	quantum/action.c:125: if (event.pressed) {
      007553 90 08 DE         [24]  731 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007556 E0               [24]  732 	movx	a,@dptr
      007557 60 03            [24]  733 	jz	00106$
                                    734 ;	quantum/action.c:127: clear_weak_mods();
      007559 12 85 79         [24]  735 	lcall	_clear_weak_mods
      00755C                        736 00106$:
                                    737 ;	quantum/action.c:139: record.event = event;
      00755C 90 0E 8C         [24]  738 	mov	dptr,#___memcpy_PARM_2
      00755F 74 D9            [12]  739 	mov	a,#_action_exec_PARM_1
      007561 F0               [24]  740 	movx	@dptr,a
      007562 74 08            [12]  741 	mov	a,#(_action_exec_PARM_1 >> 8)
      007564 12 38 4A         [24]  742 	lcall	_ak820_outline_0077
      007567 12 7C 07         [24]  743 	lcall	_ak820_outline_0076
      00756A 90 08 DF         [24]  744 	mov	dptr,#_action_exec_record_10001_632
      00756D F5 F0            [12]  745 	mov	b,a
      00756F 12 BE 8E         [24]  746 	lcall	___memcpy
                                    747 ;	quantum/action.c:141: record.tap.count = 0;
      007572 90 08 E5         [24]  748 	mov	dptr,#(_action_exec_record_10001_632 + 0x0006)
      007575 E0               [24]  749 	movx	a,@dptr
      007576 54 0F            [12]  750 	anl	a,#0x0f
      007578 F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action.c:146: record.keycode = 0;
      007579 90 08 E6         [24]  753 	mov	dptr,#(_action_exec_record_10001_632 + 0x0007)
      00757C 12 49 28         [24]  754 	lcall	_ak820_outline_0150
                                    755 ;	quantum/action.c:177: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00757F 90 08 E3         [24]  756 	mov	dptr,#(_action_exec_record_10001_632 + 0x0004)
      007582 E0               [24]  757 	movx	a,@dptr
      007583 60 0D            [24]  758 	jz	00109$
      007585 90 08 DF         [24]  759 	mov	dptr,#_action_exec_record_10001_632
      007588 75 F0 00         [24]  760 	mov	b, #0x00
      00758B 12 A4 7D         [24]  761 	lcall	_pre_process_record_quantum
      00758E E5 82            [12]  762 	mov	a, dpl
      007590 60 13            [24]  763 	jz	00112$
      007592                        764 00109$:
                                    765 ;	quantum/action.c:179: if (!ak820_tapping_process(&record)) return;
      007592 90 08 DF         [24]  766 	mov	dptr,#_action_exec_record_10001_632
      007595 12 4A F7         [24]  767 	lcall	_ak820_tapping_process
      007598 E5 82            [12]  768 	mov	a, dpl
      00759A 70 01            [24]  769 	jnz	00108$
      00759C 22               [24]  770 	ret
      00759D                        771 00108$:
                                    772 ;	quantum/action.c:184: process_record(&record);
      00759D 90 08 DF         [24]  773 	mov	dptr,#_action_exec_record_10001_632
      0075A0 75 F0 00         [24]  774 	mov	b, #0x00
                                    775 ;	quantum/action.c:199: }
      0075A3 A1 E1            [12]  776 	ajmp	_process_record
      0075A5                        777 00112$:
      0075A5 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_action_exec'
                                    781 ;------------------------------------------------------------
                                    782 ;event         Allocated with name '_ak820_action_exec_event_10000_636'
                                    783 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_637'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/action.c:202: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function ak820_action_exec
                                    788 ;	-----------------------------------------
      0075A6                        789 _ak820_action_exec:
      0075A6 12 38 81         [24]  790 	lcall	_ak820_outline_0111
      0075A9 90 08 E8         [24]  791 	mov	dptr,#_ak820_action_exec_event_10000_636
      0075AC 12 38 86         [24]  792 	lcall	_ak820_outline_0112
                                    793 ;	quantum/action.c:205: keyevent_t snapshot = *event;
      0075AF 90 08 E8         [24]  794 	mov	dptr,#_ak820_action_exec_event_10000_636
      0075B2 12 38 5C         [24]  795 	lcall	_ak820_outline_0086
      0075B5 7F 00            [12]  796 	mov	r7,#0x00
      0075B7 90 0E 8C         [24]  797 	mov	dptr,#___memcpy_PARM_2
      0075BA ED               [12]  798 	mov	a,r5
      0075BB 12 38 15         [24]  799 	lcall	_ak820_outline_0020
      0075BE 12 7C 07         [24]  800 	lcall	_ak820_outline_0076
      0075C1 90 08 EA         [24]  801 	mov	dptr,#_ak820_action_exec_snapshot_10000_637
      0075C4 F5 F0            [12]  802 	mov	b,a
      0075C6 12 BE 8E         [24]  803 	lcall	___memcpy
                                    804 ;	quantum/action.c:206: action_exec(snapshot);
      0075C9 90 0E 8C         [24]  805 	mov	dptr,#___memcpy_PARM_2
      0075CC 74 EA            [12]  806 	mov	a,#_ak820_action_exec_snapshot_10000_637
      0075CE F0               [24]  807 	movx	@dptr,a
      0075CF 74 08            [12]  808 	mov	a,#(_ak820_action_exec_snapshot_10000_637 >> 8)
      0075D1 12 38 4A         [24]  809 	lcall	_ak820_outline_0077
      0075D4 12 7C 07         [24]  810 	lcall	_ak820_outline_0076
      0075D7 90 08 D9         [24]  811 	mov	dptr,#_action_exec_PARM_1
      0075DA F5 F0            [12]  812 	mov	b,a
      0075DC 12 BE 8E         [24]  813 	lcall	___memcpy
                                    814 ;	quantum/action.c:207: }
      0075DF A1 34            [12]  815 	ajmp	_action_exec
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'process_record_nocache'
                                    818 ;------------------------------------------------------------
                                    819 ;record        Allocated with name '_process_record_nocache_record_10000_638'
                                    820 ;------------------------------------------------------------
                                    821 ;	quantum/action.c:292: void process_record_nocache(keyrecord_t *record) {
                                    822 ;	-----------------------------------------
                                    823 ;	 function process_record
                                    824 ;	-----------------------------------------
      0075E1                        825 _process_record:
      0075E1 12 43 1B         [24]  826 	lcall	_ak820_outline_0041
      0075E4 90 08 F0         [24]  827 	mov	dptr,#_process_record_record_10000_640
      0075E7 12 38 15         [24]  828 	lcall	_ak820_outline_0020
                                    829 ;	quantum/action.c:346: if (IS_NOEVENT(record->event)) {
      0075EA 90 08 F0         [24]  830 	mov	dptr,#_process_record_record_10000_640
      0075ED 12 54 6E         [24]  831 	lcall	_ak820_outline_0015
      0075F0 74 04            [12]  832 	mov	a,#0x04
      0075F2 12 7B DA         [24]  833 	lcall	_ak820_outline_0017
      0075F5 12 BF 67         [24]  834 	lcall	__gptrget
      0075F8 70 01            [24]  835 	jnz	00102$
                                    836 ;	quantum/action.c:347: return;
      0075FA 22               [24]  837 	ret
      0075FB                        838 00102$:
                                    839 ;	quantum/action.c:355: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0075FB 8D 02            [24]  840 	mov	ar2,r5
      0075FD 8E 03            [24]  841 	mov	ar3,r6
      0075FF 8F 04            [24]  842 	mov	ar4,r7
      007601 90 0E 8C         [24]  843 	mov	dptr,#___memcpy_PARM_2
      007604 12 49 34         [24]  844 	lcall	_ak820_outline_0167
      007607 EC               [12]  845 	mov	a,r4
      007608 A3               [24]  846 	inc	dptr
      007609 F0               [24]  847 	movx	@dptr,a
      00760A 90 0E 8F         [24]  848 	mov	dptr,#___memcpy_PARM_3
      00760D 12 54 AA         [24]  849 	lcall	_ak820_outline_0114
      007610 90 06 ED         [24]  850 	mov	dptr,#_ak820_tapping_source_PARM_1
      007613 F5 F0            [12]  851 	mov	b,a
      007615 C0 07            [24]  852 	push	ar7
      007617 C0 06            [24]  853 	push	ar6
      007619 C0 05            [24]  854 	push	ar5
      00761B 12 BE 8E         [24]  855 	lcall	___memcpy
      00761E 12 49 40         [24]  856 	lcall	_ak820_tapping_source
      007621 AC 82            [24]  857 	mov	r4, dpl
      007623 D0 05            [24]  858 	pop	ar5
      007625 D0 06            [24]  859 	pop	ar6
      007627 D0 07            [24]  860 	pop	ar7
                                    861 ;	quantum/action.c:356: bool oneshot_pressed = record->event.pressed;
      007629 74 05            [12]  862 	mov	a,#0x05
      00762B 12 7B CC         [24]  863 	lcall	_ak820_outline_0016
      00762E 12 BF 67         [24]  864 	lcall	__gptrget
      007631 FB               [12]  865 	mov	r3,a
                                    866 ;	quantum/action.c:357: record->keycode = get_record_keycode(record, true);
      007632 12 7C 3A         [24]  867 	lcall	_ak820_outline_0153
      007635 90 0C CF         [24]  868 	mov	dptr,#_get_record_keycode_PARM_2
      007638 74 01            [12]  869 	mov	a,#0x01
      00763A 12 54 77         [24]  870 	lcall	_ak820_outline_0036
      00763D C0 04            [24]  871 	push	ar4
      00763F C0 03            [24]  872 	push	ar3
      007641 C0 02            [24]  873 	push	ar2
      007643 C0 01            [24]  874 	push	ar1
      007645 C0 00            [24]  875 	push	ar0
      007647 12 A4 3F         [24]  876 	lcall	_get_record_keycode
      00764A 12 43 64         [24]  877 	lcall	_ak820_outline_0142
      00764D D0 00            [24]  878 	pop	ar0
      00764F D0 01            [24]  879 	pop	ar1
      007651 D0 02            [24]  880 	pop	ar2
      007653 D0 03            [24]  881 	pop	ar3
      007655 D0 04            [24]  882 	pop	ar4
      007657 12 4E 2D         [24]  883 	lcall	_ak820_outline_0116
      00765A EE               [12]  884 	mov	a,r6
      00765B 12 BF 2C         [24]  885 	lcall	__gptrput
      00765E A3               [24]  886 	inc	dptr
      00765F EF               [12]  887 	mov	a,r7
      007660 12 BF 2C         [24]  888 	lcall	__gptrput
                                    889 ;	quantum/action.c:358: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007663 90 08 F0         [24]  890 	mov	dptr,#_process_record_record_10000_640
      007666 12 54 6E         [24]  891 	lcall	_ak820_outline_0015
      007669 12 7C 3A         [24]  892 	lcall	_ak820_outline_0153
      00766C 12 4E 2D         [24]  893 	lcall	_ak820_outline_0116
      00766F 12 BF 67         [24]  894 	lcall	__gptrget
      007672 F8               [12]  895 	mov	r0,a
      007673 A3               [24]  896 	inc	dptr
      007674 12 BF 67         [24]  897 	lcall	__gptrget
      007677 F9               [12]  898 	mov	r1,a
      007678 90 06 FD         [24]  899 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00767B EC               [12]  900 	mov	a,r4
      00767C F0               [24]  901 	movx	@dptr,a
      00767D 90 06 FE         [24]  902 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007680 EB               [12]  903 	mov	a,r3
      007681 F0               [24]  904 	movx	@dptr,a
      007682 12 7C 55         [24]  905 	lcall	_ak820_outline_0196
      007685 C0 07            [24]  906 	push	ar7
      007687 C0 06            [24]  907 	push	ar6
      007689 C0 05            [24]  908 	push	ar5
      00768B C0 04            [24]  909 	push	ar4
      00768D C0 03            [24]  910 	push	ar3
      00768F 12 4C A6         [24]  911 	lcall	_ak820_oneshot_process
      007692 E5 82            [12]  912 	mov	a, dpl
      007694 D0 03            [24]  913 	pop	ar3
      007696 D0 04            [24]  914 	pop	ar4
      007698 D0 05            [24]  915 	pop	ar5
      00769A D0 06            [24]  916 	pop	ar6
      00769C D0 07            [24]  917 	pop	ar7
      00769E 70 01            [24]  918 	jnz	00104$
      0076A0 22               [24]  919 	ret
      0076A1                        920 00104$:
                                    921 ;	quantum/action.c:360: if (!process_record_quantum(record)) {
      0076A1 12 72 A8         [24]  922 	lcall	_ak820_outline_0063
      0076A4 C0 04            [24]  923 	push	ar4
      0076A6 C0 03            [24]  924 	push	ar3
      0076A8 12 A5 23         [24]  925 	lcall	_process_record_quantum
      0076AB E5 82            [12]  926 	mov	a, dpl
      0076AD D0 03            [24]  927 	pop	ar3
      0076AF D0 04            [24]  928 	pop	ar4
      0076B1 70 0A            [24]  929 	jnz	00106$
                                    930 ;	quantum/action.c:362: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0076B3 90 05 9C         [24]  931 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0076B6 EB               [12]  932 	mov	a,r3
      0076B7 F0               [24]  933 	movx	@dptr,a
      0076B8 8C 82            [24]  934 	mov	dpl, r4
                                    935 ;	quantum/action.c:369: return;
      0076BA 02 2E BB         [24]  936 	ljmp	_ak820_oneshot_post
      0076BD                        937 00106$:
                                    938 ;	quantum/action.c:375: process_record_handler(record);
      0076BD 90 08 F0         [24]  939 	mov	dptr,#_process_record_record_10000_640
      0076C0 12 54 48         [24]  940 	lcall	_ak820_outline_0001
      0076C3 C0 04            [24]  941 	push	ar4
      0076C5 C0 03            [24]  942 	push	ar3
      0076C7 D1 E0            [24]  943 	acall	_process_record_handler
                                    944 ;	quantum/action.c:379: post_process_record_quantum(record);
      0076C9 90 08 F0         [24]  945 	mov	dptr,#_process_record_record_10000_640
      0076CC 12 54 48         [24]  946 	lcall	_ak820_outline_0001
      0076CF 12 A4 FA         [24]  947 	lcall	_post_process_record_quantum
      0076D2 D0 03            [24]  948 	pop	ar3
      0076D4 D0 04            [24]  949 	pop	ar4
                                    950 ;	quantum/action.c:381: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0076D6 90 05 9C         [24]  951 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0076D9 EB               [12]  952 	mov	a,r3
      0076DA F0               [24]  953 	movx	@dptr,a
      0076DB 8C 82            [24]  954 	mov	dpl, r4
                                    955 ;	quantum/action.c:383: }
      0076DD 02 2E BB         [24]  956 	ljmp	_ak820_oneshot_post
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'process_record_handler'
                                    959 ;------------------------------------------------------------
                                    960 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_648'
                                    961 ;record        Allocated with name '_process_record_handler_record_10000_649'
                                    962 ;action        Allocated with name '_process_record_handler_action_10000_649'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action.c:385: void process_record_handler(keyrecord_t *record_argument) {
                                    965 ;	-----------------------------------------
                                    966 ;	 function process_record_handler
                                    967 ;	-----------------------------------------
      0076E0                        968 _process_record_handler:
      0076E0 12 43 1B         [24]  969 	lcall	_ak820_outline_0041
      0076E3 90 08 F3         [24]  970 	mov	dptr,#_process_record_handler_record_argument_10000_648
      0076E6 12 38 15         [24]  971 	lcall	_ak820_outline_0020
                                    972 ;	quantum/action.c:389: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0076E9 90 08 F3         [24]  973 	mov	dptr,#_process_record_handler_record_argument_10000_648
      0076EC 12 37 F7         [24]  974 	lcall	_ak820_outline_0008
                                    975 ;	quantum/action.c:396: if (record->keycode) {
      0076EF 4C               [12]  976 	orl	a,r4
      0076F0 60 19            [24]  977 	jz	00102$
                                    978 ;	quantum/action.c:397: action.code = action_for_keycode(record->keycode);
      0076F2 12 38 A3         [24]  979 	lcall	_ak820_outline_0132
      0076F5 C0 07            [24]  980 	push	ar7
      0076F7 C0 06            [24]  981 	push	ar6
      0076F9 12 9A 94         [24]  982 	lcall	_action_for_keycode
      0076FC 12 43 6F         [24]  983 	lcall	_ak820_outline_0156
      0076FF D0 06            [24]  984 	pop	ar6
      007701 D0 07            [24]  985 	pop	ar7
      007703 90 08 F6         [24]  986 	mov	dptr,#_process_record_handler_action_10000_649
      007706 12 38 50         [24]  987 	lcall	_ak820_outline_0078
      007709 80 2B            [24]  988 	sjmp	00104$
      00770B                        989 00102$:
                                    990 ;	quantum/action.c:400: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      00770B 12 7B E8         [24]  991 	lcall	_ak820_outline_0025
      00770E 7A 00            [12]  992 	mov	r2,#0x00
      007710 12 43 69         [24]  993 	lcall	_ak820_outline_0149
      007713 12 43 09         [24]  994 	lcall	_ak820_outline_0014
      007716 E0               [24]  995 	movx	a,@dptr
      007717 90 0A 32         [24]  996 	mov	dptr,#_ak820_resolve_key_PARM_2
      00771A F0               [24]  997 	movx	@dptr,a
      00771B 8D 82            [24]  998 	mov	dpl, r5
      00771D 8C 83            [24]  999 	mov	dph, r4
      00771F C0 07            [24] 1000 	push	ar7
      007721 C0 06            [24] 1001 	push	ar6
      007723 12 7F 7E         [24] 1002 	lcall	_ak820_resolve_key
      007726 12 9A 94         [24] 1003 	lcall	_action_for_keycode
      007729 12 43 6F         [24] 1004 	lcall	_ak820_outline_0156
      00772C D0 06            [24] 1005 	pop	ar6
      00772E D0 07            [24] 1006 	pop	ar7
      007730 90 08 F6         [24] 1007 	mov	dptr,#_process_record_handler_action_10000_649
      007733 12 38 50         [24] 1008 	lcall	_ak820_outline_0078
                                   1009 ;	quantum/action.c:409: ac_dprintf("ACTION: ");
      007736                       1010 00104$:
                                   1011 ;	quantum/action.c:420: process_action(record, action);
      007736 7D 00            [12] 1012 	mov	r5,#0x00
      007738 90 0E 8C         [24] 1013 	mov	dptr,#___memcpy_PARM_2
      00773B 74 F6            [12] 1014 	mov	a,#_process_record_handler_action_10000_649
      00773D F0               [24] 1015 	movx	@dptr,a
      00773E 74 08            [12] 1016 	mov	a,#(_process_record_handler_action_10000_649 >> 8)
      007740 12 38 4A         [24] 1017 	lcall	_ak820_outline_0077
      007743 90 0E 8F         [24] 1018 	mov	dptr,#___memcpy_PARM_3
      007746 12 54 AA         [24] 1019 	lcall	_ak820_outline_0114
      007749 90 08 F8         [24] 1020 	mov	dptr,#_process_action_PARM_2
      00774C F5 F0            [12] 1021 	mov	b,a
      00774E C0 07            [24] 1022 	push	ar7
      007750 C0 06            [24] 1023 	push	ar6
      007752 C0 05            [24] 1024 	push	ar5
      007754 12 BE 8E         [24] 1025 	lcall	___memcpy
      007757 D0 05            [24] 1026 	pop	ar5
      007759 D0 06            [24] 1027 	pop	ar6
      00775B D0 07            [24] 1028 	pop	ar7
      00775D 12 7C 21         [24] 1029 	lcall	_ak820_outline_0118
                                   1030 ;	quantum/action.c:421: }
      007760 E1 62            [24] 1031 	ajmp	_process_action
                                   1032 ;------------------------------------------------------------
                                   1033 ;Allocation info for local variables in function 'register_mouse'
                                   1034 ;------------------------------------------------------------
                                   1035 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1036 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_657'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	quantum/action.c:433: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function process_action
                                   1041 ;	-----------------------------------------
      007762                       1042 _process_action:
      007762 12 43 1B         [24] 1043 	lcall	_ak820_outline_0041
      007765 90 08 FA         [24] 1044 	mov	dptr,#_process_action_record_argument_10000_660
      007768 12 38 15         [24] 1045 	lcall	_ak820_outline_0020
                                   1046 ;	quantum/action.c:486: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00776B 90 08 FA         [24] 1047 	mov	dptr,#_process_action_record_argument_10000_660
      00776E 12 37 ED         [24] 1048 	lcall	_ak820_outline_0006
                                   1049 ;	quantum/action.c:492: pressed = record->event.pressed;
      007771 A3               [24] 1050 	inc	dptr
      007772 A3               [24] 1051 	inc	dptr
      007773 A3               [24] 1052 	inc	dptr
      007774 A3               [24] 1053 	inc	dptr
      007775 A3               [24] 1054 	inc	dptr
      007776 E0               [24] 1055 	movx	a,@dptr
      007777 F5 17            [12] 1056 	mov	_process_action_sloc0_1_0,a
                                   1057 ;	quantum/action.c:516: switch (action.kind.id) {
      007779 90 08 F9         [24] 1058 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00777C E0               [24] 1059 	movx	a,@dptr
      00777D C4               [12] 1060 	swap	a
      00777E 54 0F            [12] 1061 	anl	a,#0x0f
      007780 FD               [12] 1062 	mov  r5,a
      007781 24 F4            [12] 1063 	add	a,#0xff - 0x0b
      007783 50 03            [24] 1064 	jnc	00434$
      007785 02 7A 03         [24] 1065 	ljmp	00181$
      007788                       1066 00434$:
                                   1067 ;	free result
      007788 ED               [12] 1068 	mov	a,r5
      007789 24 0A            [12] 1069 	add	a,#(00435$-3-.)
      00778B 83               [24] 1070 	movc	a,@a+pc
      00778C F5 82            [12] 1071 	mov	dpl,a
      00778E ED               [12] 1072 	mov	a,r5
      00778F 24 10            [12] 1073 	add	a,#(00436$-3-.)
      007791 83               [24] 1074 	movc	a,@a+pc
      007792 F5 83            [12] 1075 	mov	dph,a
      007794 E4               [12] 1076 	clr	a
      007795 73               [24] 1077 	jmp	@a+dptr
      007796                       1078 00435$:
      007796 AE                    1079 	.db	00102$
      007797 AE                    1080 	.db	00102$
      007798 03                    1081 	.db	00181$
      007799 03                    1082 	.db	00181$
      00779A 38                    1083 	.db	00123$
      00779B 03                    1084 	.db	00181$
      00779C 03                    1085 	.db	00181$
      00779D 03                    1086 	.db	00181$
      00779E 98                    1087 	.db	00131$
      00779F 6A                    1088 	.db	00147$
      0077A0 90                    1089 	.db	00152$
      0077A1 90                    1090 	.db	00152$
      0077A2                       1091 00436$:
      0077A2 77                    1092 	.db	00102$>>8
      0077A3 77                    1093 	.db	00102$>>8
      0077A4 7A                    1094 	.db	00181$>>8
      0077A5 7A                    1095 	.db	00181$>>8
      0077A6 78                    1096 	.db	00123$>>8
      0077A7 7A                    1097 	.db	00181$>>8
      0077A8 7A                    1098 	.db	00181$>>8
      0077A9 7A                    1099 	.db	00181$>>8
      0077AA 78                    1100 	.db	00131$>>8
      0077AB 79                    1101 	.db	00147$>>8
      0077AC 79                    1102 	.db	00152$>>8
      0077AD 79                    1103 	.db	00152$>>8
                                   1104 ;	quantum/action.c:519: case ACT_RMODS: {
      0077AE                       1105 00102$:
                                   1106 ;	quantum/action.c:520: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0077AE 90 08 F9         [24] 1107 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077B1 E0               [24] 1108 	movx	a,@dptr
      0077B2 54 F0            [12] 1109 	anl	a,#0xf0
      0077B4 70 06            [24] 1110 	jnz	00194$
      0077B6 12 7C 28         [24] 1111 	lcall	_ak820_outline_0119
      0077B9 FD               [12] 1112 	mov	r5,a
      0077BA 80 07            [24] 1113 	sjmp	00195$
      0077BC                       1114 00194$:
      0077BC 12 7C 28         [24] 1115 	lcall	_ak820_outline_0119
      0077BF C4               [12] 1116 	swap	a
      0077C0 54 F0            [12] 1117 	anl	a,#0xf0
      0077C2 FD               [12] 1118 	mov	r5,a
      0077C3                       1119 00195$:
                                   1120 ;	quantum/action.c:522: if (pressed) {
      0077C3 E5 17            [12] 1121 	mov	a,_process_action_sloc0_1_0
      0077C5 60 35            [24] 1122 	jz	00119$
                                   1123 ;	quantum/action.c:523: if (mods) {
      0077C7 ED               [12] 1124 	mov	a,r5
      0077C8 60 29            [24] 1125 	jz	00110$
                                   1126 ;	quantum/action.c:524: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0077CA 12 7C 44         [24] 1127 	lcall	_ak820_outline_0164
      0077CD FC               [12] 1128 	mov	r4,a
      0077CE BC E0 00         [24] 1129 	cjne	r4,#0xe0,00440$
      0077D1                       1130 00440$:
      0077D1 40 07            [24] 1131 	jc	00108$
      0077D3 12 7C 44         [24] 1132 	lcall	_ak820_outline_0164
      0077D6 24 18            [12] 1133 	add	a,#0xff - 0xe7
      0077D8 50 0A            [24] 1134 	jnc	00104$
                                   1135 ;	free result
      0077DA                       1136 00108$:
      0077DA 7B F8            [12] 1137 	mov	r3,#_process_action_PARM_2
      0077DC 7C 08            [12] 1138 	mov	r4,#(_process_action_PARM_2 >> 8)
      0077DE 12 33 FC         [24] 1139 	lcall	_ak820_outline_0131
      0077E1 E0               [24] 1140 	movx	a,@dptr
      0077E2 70 07            [24] 1141 	jnz	00105$
      0077E4                       1142 00104$:
                                   1143 ;	quantum/action.c:528: add_owned_mods(mods);
      0077E4 8D 82            [24] 1144 	mov	dpl, r5
      0077E6 12 81 97         [24] 1145 	lcall	_add_owned_mods
      0077E9 80 05            [24] 1146 	sjmp	00106$
      0077EB                       1147 00105$:
                                   1148 ;	quantum/action.c:530: add_owned_weak_mods(mods);
      0077EB 8D 82            [24] 1149 	mov	dpl, r5
      0077ED 12 81 B4         [24] 1150 	lcall	_add_owned_weak_mods
      0077F0                       1151 00106$:
                                   1152 ;	quantum/action.c:532: send_keyboard_report();
      0077F0 12 84 C9         [24] 1153 	lcall	_send_keyboard_report
      0077F3                       1154 00110$:
                                   1155 ;	quantum/action.c:534: register_code(action.key.code);
      0077F3 12 7C 11         [24] 1156 	lcall	_ak820_outline_0082
      0077F6 12 7A 1A         [24] 1157 	lcall	_register_code
      0077F9 02 7A 03         [24] 1158 	ljmp	00181$
      0077FC                       1159 00119$:
                                   1160 ;	quantum/action.c:536: unregister_code(action.key.code);
      0077FC 12 7C 11         [24] 1161 	lcall	_ak820_outline_0082
      0077FF C0 05            [24] 1162 	push	ar5
      007801 12 7A 87         [24] 1163 	lcall	_unregister_code
      007804 D0 05            [24] 1164 	pop	ar5
                                   1165 ;	quantum/action.c:537: if (mods) {
      007806 ED               [12] 1166 	mov	a,r5
      007807 70 03            [24] 1167 	jnz	00444$
      007809 02 7A 03         [24] 1168 	ljmp	00181$
      00780C                       1169 00444$:
                                   1170 ;	quantum/action.c:538: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00780C 12 7C 44         [24] 1171 	lcall	_ak820_outline_0164
      00780F FC               [12] 1172 	mov	r4,a
      007810 BC E0 00         [24] 1173 	cjne	r4,#0xe0,00445$
      007813                       1174 00445$:
      007813 40 07            [24] 1175 	jc	00115$
      007815 12 7C 44         [24] 1176 	lcall	_ak820_outline_0164
      007818 24 18            [12] 1177 	add	a,#0xff - 0xe7
      00781A 50 0A            [24] 1178 	jnc	00111$
                                   1179 ;	free result
      00781C                       1180 00115$:
      00781C 7B F8            [12] 1181 	mov	r3,#_process_action_PARM_2
      00781E 7C 08            [12] 1182 	mov	r4,#(_process_action_PARM_2 >> 8)
      007820 12 33 FC         [24] 1183 	lcall	_ak820_outline_0131
      007823 E0               [24] 1184 	movx	a,@dptr
      007824 70 07            [24] 1185 	jnz	00112$
      007826                       1186 00111$:
                                   1187 ;	quantum/action.c:539: del_owned_mods(mods);
      007826 8D 82            [24] 1188 	mov	dpl, r5
      007828 12 81 A6         [24] 1189 	lcall	_del_owned_mods
      00782B 80 05            [24] 1190 	sjmp	00113$
      00782D                       1191 00112$:
                                   1192 ;	quantum/action.c:541: del_owned_weak_mods(mods);
      00782D 8D 82            [24] 1193 	mov	dpl, r5
      00782F 12 81 C3         [24] 1194 	lcall	_del_owned_weak_mods
      007832                       1195 00113$:
                                   1196 ;	quantum/action.c:543: send_keyboard_report();
      007832 12 84 C9         [24] 1197 	lcall	_send_keyboard_report
                                   1198 ;	quantum/action.c:546: } break;
      007835 02 7A 03         [24] 1199 	ljmp	00181$
                                   1200 ;	quantum/action.c:623: case ACT_USAGE:
      007838                       1201 00123$:
                                   1202 ;	quantum/action.c:629: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007838 74 07            [12] 1203 	mov	a,#0x07
      00783A 12 38 1D         [24] 1204 	lcall	_ak820_outline_0026
      00783D 12 4D E6         [24] 1205 	lcall	_ak820_outline_0010
      007840 C3               [12] 1206 	clr	c
      007841 EC               [12] 1207 	mov	a,r4
      007842 94 A5            [12] 1208 	subb	a,#0xa5
      007844 ED               [12] 1209 	mov	a,r5
      007845 94 00            [12] 1210 	subb	a,#0x00
      007847 40 15            [24] 1211 	jc	00125$
      007849 74 C2            [12] 1212 	mov	a,#0xc2
      00784B 9C               [12] 1213 	subb	a,r4
      00784C E4               [12] 1214 	clr	a
      00784D 9D               [12] 1215 	subb	a,r5
      00784E 40 0E            [24] 1216 	jc	00125$
                                   1217 ;	free result
                                   1218 ;	quantum/action.c:630: owned_usage_key((uint8_t)record->keycode, pressed);
      007850 90 0B 59         [24] 1219 	mov	dptr,#_owned_usage_key_PARM_2
      007853 E5 17            [12] 1220 	mov	a,_process_action_sloc0_1_0
      007855 F0               [24] 1221 	movx	@dptr,a
      007856 8E 82            [24] 1222 	mov	dpl, r6
      007858 12 83 76         [24] 1223 	lcall	_owned_usage_key
                                   1224 ;	quantum/action.c:631: break;
      00785B 02 7A 03         [24] 1225 	ljmp	00181$
      00785E                       1226 00125$:
                                   1227 ;	quantum/action.c:634: switch (action.usage.page) {
      00785E 12 7C 18         [24] 1228 	lcall	_ak820_outline_0094
      007861 FF               [12] 1229 	mov	r7,a
      007862 60 08            [24] 1230 	jz	00127$
      007864 BF 01 02         [24] 1231 	cjne	r7,#0x01,00452$
      007867 80 19            [24] 1232 	sjmp	00128$
      007869                       1233 00452$:
      007869 02 7A 03         [24] 1234 	ljmp	00181$
                                   1235 ;	quantum/action.c:635: case PAGE_SYSTEM:
      00786C                       1236 00127$:
                                   1237 ;	quantum/action.c:636: host_system_send(pressed ? action.usage.code : 0);
      00786C E5 17            [12] 1238 	mov	a,_process_action_sloc0_1_0
      00786E 60 05            [24] 1239 	jz	00196$
      007870 12 7C 2F         [24] 1240 	lcall	_ak820_outline_0140
      007873 80 04            [24] 1241 	sjmp	00197$
      007875                       1242 00196$:
      007875 7E 00            [12] 1243 	mov	r6,#0x00
      007877 7F 00            [12] 1244 	mov	r7,#0x00
      007879                       1245 00197$:
      007879 12 38 92         [24] 1246 	lcall	_ak820_outline_0124
      00787C 12 72 3C         [24] 1247 	lcall	_host_system_send
                                   1248 ;	quantum/action.c:637: break;
      00787F 02 7A 03         [24] 1249 	ljmp	00181$
                                   1250 ;	quantum/action.c:638: case PAGE_CONSUMER:
      007882                       1251 00128$:
                                   1252 ;	quantum/action.c:639: host_consumer_send(pressed ? action.usage.code : 0);
      007882 E5 17            [12] 1253 	mov	a,_process_action_sloc0_1_0
      007884 60 05            [24] 1254 	jz	00198$
      007886 12 7C 2F         [24] 1255 	lcall	_ak820_outline_0140
      007889 80 04            [24] 1256 	sjmp	00199$
      00788B                       1257 00198$:
      00788B 7E 00            [12] 1258 	mov	r6,#0x00
      00788D 7F 00            [12] 1259 	mov	r7,#0x00
      00788F                       1260 00199$:
      00788F 12 38 92         [24] 1261 	lcall	_ak820_outline_0124
      007892 12 72 6B         [24] 1262 	lcall	_host_consumer_send
                                   1263 ;	quantum/action.c:642: break;
      007895 02 7A 03         [24] 1264 	ljmp	00181$
                                   1265 ;	quantum/action.c:649: case ACT_LAYER: {
      007898                       1266 00131$:
                                   1267 ;	quantum/action.c:650: uint8_t on = action.layer_bitop.on;
      007898 90 08 F9         [24] 1268 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00789B E0               [24] 1269 	movx	a,@dptr
      00789C 54 03            [12] 1270 	anl	a,#0x03
      00789E 90 08 FD         [24] 1271 	mov	dptr,#_process_action_on_40000_683
      0078A1 F0               [24] 1272 	movx	@dptr,a
                                   1273 ;	quantum/action.c:653: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0078A2 E0               [24] 1274 	movx	a,@dptr
      0078A3 FF               [12] 1275 	mov	r7,a
      0078A4 60 11            [24] 1276 	jz	00200$
      0078A6 E5 17            [12] 1277 	mov	a,_process_action_sloc0_1_0
      0078A8 60 07            [24] 1278 	jz	00202$
      0078AA 8F 06            [24] 1279 	mov	ar6,r7
      0078AC 53 06 01         [24] 1280 	anl	ar6,#0x01
      0078AF 80 10            [24] 1281 	sjmp	00201$
      0078B1                       1282 00202$:
      0078B1 74 02            [12] 1283 	mov	a,#0x02
      0078B3 5F               [12] 1284 	anl	a,r7
      0078B4 FE               [12] 1285 	mov	r6,a
      0078B5 80 0A            [24] 1286 	sjmp	00201$
      0078B7                       1287 00200$:
      0078B7 E5 17            [12] 1288 	mov	a,_process_action_sloc0_1_0
      0078B9 B4 01 00         [24] 1289 	cjne	a,#0x01,00457$
      0078BC                       1290 00457$:
      0078BC 92 21            [24] 1291 	mov  _process_action_sloc1_1_0,c
      0078BE E4               [12] 1292 	clr	a
      0078BF 33               [12] 1293 	rlc	a
      0078C0 FE               [12] 1294 	mov	r6,a
      0078C1                       1295 00201$:
      0078C1 EE               [12] 1296 	mov	a,r6
      0078C2 70 03            [24] 1297 	jnz	00458$
      0078C4 02 7A 03         [24] 1298 	ljmp	00181$
      0078C7                       1299 00458$:
                                   1300 ;	quantum/action.c:654: uint8_t shift = action.layer_bitop.part * 4;
      0078C7 12 7C 44         [24] 1301 	lcall	_ak820_outline_0164
      0078CA C4               [12] 1302 	swap	a
      0078CB 03               [12] 1303 	rr	a
      0078CC 54 07            [12] 1304 	anl	a,#0x07
      0078CE 25 E0            [12] 1305 	add	a,acc
      0078D0 25 E0            [12] 1306 	add	a,acc
      0078D2 FF               [12] 1307 	mov	r7,a
                                   1308 ;	quantum/action.c:655: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0078D3 12 7C 44         [24] 1309 	lcall	_ak820_outline_0164
      0078D6 54 0F            [12] 1310 	anl	a,#0x0f
      0078D8 FE               [12] 1311 	mov	r6,a
      0078D9 8F F0            [24] 1312 	mov	b,r7
      0078DB 05 F0            [12] 1313 	inc	b
      0078DD EE               [12] 1314 	mov	a,r6
      0078DE 80 02            [24] 1315 	sjmp	00460$
      0078E0                       1316 00459$:
      0078E0 25 E0            [12] 1317 	add	a,acc
      0078E2                       1318 00460$:
      0078E2 D5 F0 FB         [24] 1319 	djnz	b,00459$
      0078E5 FE               [12] 1320 	mov	r6,a
                                   1321 ;	quantum/action.c:656: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0078E6 12 7C 44         [24] 1322 	lcall	_ak820_outline_0164
      0078E9 30 E4 11         [24] 1323 	jnb	acc.4,00204$
      0078EC 8F F0            [24] 1324 	mov	b,r7
      0078EE 05 F0            [12] 1325 	inc	b
      0078F0 74 0F            [12] 1326 	mov	a,#0x0f
      0078F2 80 02            [24] 1327 	sjmp	00463$
      0078F4                       1328 00462$:
      0078F4 25 E0            [12] 1329 	add	a,acc
      0078F6                       1330 00463$:
      0078F6 D5 F0 FB         [24] 1331 	djnz	b,00462$
      0078F9 F4               [12] 1332 	cpl	a
      0078FA FF               [12] 1333 	mov	r7,a
      0078FB 80 02            [24] 1334 	sjmp	00205$
      0078FD                       1335 00204$:
      0078FD 7F 00            [12] 1336 	mov	r7,#0x00
      0078FF                       1337 00205$:
                                   1338 ;	quantum/action.c:657: bits |= mask;
      0078FF EE               [12] 1339 	mov	a,r6
      007900 42 07            [12] 1340 	orl	ar7,a
                                   1341 ;	quantum/action.c:658: if (!on) {
      007902 90 08 FD         [24] 1342 	mov	dptr,#_process_action_on_40000_683
      007905 E0               [24] 1343 	movx	a,@dptr
      007906 70 31            [24] 1344 	jnz	00143$
                                   1345 ;	quantum/action.c:659: switch (action.layer_bitop.op) {
      007908 12 7C 18         [24] 1346 	lcall	_ak820_outline_0094
      00790B FE               [12] 1347 	mov	r6,a
      00790C 2E               [12] 1348 	add	a,r6
                                   1349 ;	quantum/action.c:660: case OP_BIT_AND: default_layer_and(bits); break;
      00790D 90 79 11         [24] 1350 	mov	dptr,#00465$
      007910 73               [24] 1351 	jmp	@a+dptr
      007911                       1352 00465$:
      007911 80 06            [24] 1353 	sjmp	00132$
      007913 80 0C            [24] 1354 	sjmp	00133$
      007915 80 12            [24] 1355 	sjmp	00134$
      007917 80 18            [24] 1356 	sjmp	00135$
      007919                       1357 00132$:
      007919 8F 82            [24] 1358 	mov	dpl, r7
      00791B 12 7C 9F         [24] 1359 	lcall	_default_layer_and
      00791E 02 7A 03         [24] 1360 	ljmp	00181$
                                   1361 ;	quantum/action.c:661: case OP_BIT_OR: default_layer_or(bits); break;
      007921                       1362 00133$:
      007921 8F 82            [24] 1363 	mov	dpl, r7
      007923 12 7C 8F         [24] 1364 	lcall	_default_layer_or
      007926 02 7A 03         [24] 1365 	ljmp	00181$
                                   1366 ;	quantum/action.c:662: case OP_BIT_XOR: default_layer_xor(bits); break;
      007929                       1367 00134$:
      007929 8F 82            [24] 1368 	mov	dpl, r7
      00792B 12 7C B4         [24] 1369 	lcall	_default_layer_xor
      00792E 02 7A 03         [24] 1370 	ljmp	00181$
                                   1371 ;	quantum/action.c:663: case OP_BIT_SET: default_layer_set(bits); break;
      007931                       1372 00135$:
      007931 8F 82            [24] 1373 	mov	dpl, r7
      007933 12 7C 85         [24] 1374 	lcall	_default_layer_set
                                   1375 ;	quantum/action.c:664: }
      007936 02 7A 03         [24] 1376 	ljmp	00181$
      007939                       1377 00143$:
                                   1378 ;	quantum/action.c:666: switch (action.layer_bitop.op) {
      007939 12 7C 18         [24] 1379 	lcall	_ak820_outline_0094
      00793C FE               [12] 1380 	mov	r6,a
      00793D 2E               [12] 1381 	add	a,r6
                                   1382 ;	quantum/action.c:667: case OP_BIT_AND: layer_and(bits); break;
      00793E 90 79 42         [24] 1383 	mov	dptr,#00466$
      007941 73               [24] 1384 	jmp	@a+dptr
      007942                       1385 00466$:
      007942 80 06            [24] 1386 	sjmp	00137$
      007944 80 0C            [24] 1387 	sjmp	00138$
      007946 80 12            [24] 1388 	sjmp	00139$
      007948 80 18            [24] 1389 	sjmp	00140$
      00794A                       1390 00137$:
      00794A 8F 82            [24] 1391 	mov	dpl, r7
      00794C 12 7E 2B         [24] 1392 	lcall	_layer_and
      00794F 02 7A 03         [24] 1393 	ljmp	00181$
                                   1394 ;	quantum/action.c:668: case OP_BIT_OR: layer_or(bits); break;
      007952                       1395 00138$:
      007952 8F 82            [24] 1396 	mov	dpl, r7
      007954 12 7E 1B         [24] 1397 	lcall	_layer_or
      007957 02 7A 03         [24] 1398 	ljmp	00181$
                                   1399 ;	quantum/action.c:669: case OP_BIT_XOR: layer_xor(bits); break;
      00795A                       1400 00139$:
      00795A 8F 82            [24] 1401 	mov	dpl, r7
      00795C 12 7E 40         [24] 1402 	lcall	_layer_xor
      00795F 02 7A 03         [24] 1403 	ljmp	00181$
                                   1404 ;	quantum/action.c:670: case OP_BIT_SET: layer_state_set(bits); break;
      007962                       1405 00140$:
      007962 8F 82            [24] 1406 	mov	dpl, r7
      007964 12 7D BD         [24] 1407 	lcall	_layer_state_set
                                   1408 ;	quantum/action.c:674: break;
      007967 02 7A 03         [24] 1409 	ljmp	00181$
                                   1410 ;	quantum/action.c:676: case ACT_LAYER_MODS:
      00796A                       1411 00147$:
                                   1412 ;	quantum/action.c:677: if (pressed) {
      00796A E5 17            [12] 1413 	mov	a,_process_action_sloc0_1_0
      00796C 60 11            [24] 1414 	jz	00149$
                                   1415 ;	quantum/action.c:678: layer_hold_on(action.layer_mods.layer);
      00796E 12 7C 28         [24] 1416 	lcall	_ak820_outline_0119
      007971 F5 82            [12] 1417 	mov	dpl,a
      007973 12 7D 22         [24] 1418 	lcall	_layer_hold_on
                                   1419 ;	quantum/action.c:679: register_mods(action.layer_mods.mods);
      007976 12 7C 11         [24] 1420 	lcall	_ak820_outline_0082
      007979 12 7B 3A         [24] 1421 	lcall	_register_mods
      00797C 02 7A 03         [24] 1422 	ljmp	00181$
      00797F                       1423 00149$:
                                   1424 ;	quantum/action.c:681: unregister_mods(action.layer_mods.mods);
      00797F 12 7C 11         [24] 1425 	lcall	_ak820_outline_0082
      007982 12 7B 4E         [24] 1426 	lcall	_unregister_mods
                                   1427 ;	quantum/action.c:682: layer_hold_off(action.layer_mods.layer);
      007985 12 7C 28         [24] 1428 	lcall	_ak820_outline_0119
      007988 F5 82            [12] 1429 	mov	dpl,a
      00798A 12 7D 59         [24] 1430 	lcall	_layer_hold_off
                                   1431 ;	quantum/action.c:684: break;
      00798D 02 7A 03         [24] 1432 	ljmp	00181$
                                   1433 ;	quantum/action.c:686: case ACT_LAYER_TAP_EXT:
      007990                       1434 00152$:
                                   1435 ;	quantum/action.c:687: switch (action.layer_tap.code) {
      007990 12 7C 44         [24] 1436 	lcall	_ak820_outline_0164
      007993 FF               [12] 1437 	mov	r7,a
      007994 BF F1 02         [24] 1438 	cjne	r7,#0xf1,00468$
      007997 80 0A            [24] 1439 	sjmp	00154$
      007999                       1440 00468$:
      007999 BF F2 02         [24] 1441 	cjne	r7,#0xf2,00469$
      00799C 80 19            [24] 1442 	sjmp	00155$
      00799E                       1443 00469$:
                                   1444 ;	quantum/action.c:703: momentary_layer_action:
      00799E BF F3 3B         [24] 1445 	cjne	r7,#0xf3,00160$
      0079A1 80 28            [24] 1446 	sjmp	00156$
      0079A3                       1447 00154$:
                                   1448 ;	quantum/action.c:704: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0079A3 E5 17            [12] 1449 	mov	a,_process_action_sloc0_1_0
      0079A5 60 08            [24] 1450 	jz	00206$
      0079A7 12 7B F7         [24] 1451 	lcall	_ak820_outline_0047
      0079AA 12 7D 22         [24] 1452 	lcall	_layer_hold_on
      0079AD 80 54            [24] 1453 	sjmp	00181$
      0079AF                       1454 00206$:
      0079AF 12 7B F7         [24] 1455 	lcall	_ak820_outline_0047
      0079B2 12 7D 59         [24] 1456 	lcall	_layer_hold_off
                                   1457 ;	quantum/action.c:705: break;
                                   1458 ;	quantum/action.c:706: case OP_OFF_ON:
      0079B5 80 4C            [24] 1459 	sjmp	00181$
      0079B7                       1460 00155$:
                                   1461 ;	quantum/action.c:707: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0079B7 E5 17            [12] 1462 	mov	a,_process_action_sloc0_1_0
      0079B9 60 08            [24] 1463 	jz	00208$
      0079BB 12 7B F7         [24] 1464 	lcall	_ak820_outline_0047
      0079BE 12 7D FE         [24] 1465 	lcall	_layer_off
      0079C1 80 40            [24] 1466 	sjmp	00181$
      0079C3                       1467 00208$:
      0079C3 12 7B F7         [24] 1468 	lcall	_ak820_outline_0047
      0079C6 12 7D E4         [24] 1469 	lcall	_layer_on
                                   1470 ;	quantum/action.c:708: break;
                                   1471 ;	quantum/action.c:709: case OP_SET_CLEAR:
      0079C9 80 38            [24] 1472 	sjmp	00181$
      0079CB                       1473 00156$:
                                   1474 ;	quantum/action.c:710: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0079CB E5 17            [12] 1475 	mov	a,_process_action_sloc0_1_0
      0079CD 60 08            [24] 1476 	jz	00210$
      0079CF 12 7B F7         [24] 1477 	lcall	_ak820_outline_0047
      0079D2 12 7D CF         [24] 1478 	lcall	_layer_move
      0079D5 80 2C            [24] 1479 	sjmp	00181$
      0079D7                       1480 00210$:
      0079D7 12 7D CA         [24] 1481 	lcall	_layer_clear
                                   1482 ;	quantum/action.c:711: break;
                                   1483 ;	quantum/action.c:757: default:
      0079DA 80 27            [24] 1484 	sjmp	00181$
      0079DC                       1485 00160$:
                                   1486 ;	quantum/action.c:764: if (pressed) {
      0079DC E5 17            [12] 1487 	mov	a,_process_action_sloc0_1_0
      0079DE 60 08            [24] 1488 	jz	00163$
                                   1489 ;	quantum/action.c:766: register_code(action.layer_tap.code);
      0079E0 12 7C 11         [24] 1490 	lcall	_ak820_outline_0082
      0079E3 12 7A 1A         [24] 1491 	lcall	_register_code
                                   1492 ;	quantum/action.c:768: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0079E6 80 1B            [24] 1493 	sjmp	00181$
      0079E8                       1494 00163$:
                                   1495 ;	quantum/action.c:769: if (action.layer_tap.code == KC_CAPS) {
      0079E8 12 7C 44         [24] 1496 	lcall	_ak820_outline_0164
      0079EB FF               [12] 1497 	mov	r7,a
      0079EC BF 39 0E         [24] 1498 	cjne	r7,#0x39,00175$
                                   1499 ;	quantum/action.c:770: wait_ms(TAP_HOLD_CAPS_DELAY);
      0079EF 7F 50            [12] 1500 	mov	r7,#0x50
      0079F1                       1501 00187$:
      0079F1 EF               [12] 1502 	mov	a,r7
      0079F2 60 09            [24] 1503 	jz	00175$
      0079F4 90 00 01         [24] 1504 	mov	dptr,#0x0001
      0079F7 12 5E 16         [24] 1505 	lcall	_mDelaymS
      0079FA 1F               [12] 1506 	dec	r7
                                   1507 ;	quantum/action.c:772: wait_ms(TAP_CODE_DELAY);
      0079FB 80 F4            [24] 1508 	sjmp	00187$
      0079FD                       1509 00175$:
                                   1510 ;	quantum/action.c:774: unregister_code(action.layer_tap.code);
      0079FD 12 7C 11         [24] 1511 	lcall	_ak820_outline_0082
      007A00 12 7A 87         [24] 1512 	lcall	_unregister_code
                                   1513 ;	quantum/action.c:857: }
      007A03                       1514 00181$:
                                   1515 ;	quantum/action.c:878: switch (action.kind.id) {
      007A03 90 08 F9         [24] 1516 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007A06 E0               [24] 1517 	movx	a,@dptr
      007A07 C4               [12] 1518 	swap	a
      007A08 54 0F            [12] 1519 	anl	a,#0x0f
      007A0A FF               [12] 1520 	mov	r7,a
      007A0B BF 08 02         [24] 1521 	cjne	r7,#0x08,00478$
      007A0E 80 03            [24] 1522 	sjmp	00183$
      007A10                       1523 00478$:
      007A10 BF 09 06         [24] 1524 	cjne	r7,#0x09,00192$
                                   1525 ;	quantum/action.c:880: case ACT_LAYER_MODS:
      007A13                       1526 00183$:
                                   1527 ;	quantum/action.c:885: led_set(host_keyboard_leds());
      007A13 12 71 A1         [24] 1528 	lcall	_host_keyboard_leds
                                   1529 ;	quantum/action.c:889: }
                                   1530 ;	quantum/action.c:942: }
      007A16 02 9D 43         [24] 1531 	ljmp	_led_set
      007A19                       1532 00192$:
      007A19 22               [24] 1533 	ret
                                   1534 ;------------------------------------------------------------
                                   1535 ;Allocation info for local variables in function 'register_code'
                                   1536 ;------------------------------------------------------------
                                   1537 ;code          Allocated with name '_register_code_code_10000_717'
                                   1538 ;------------------------------------------------------------
                                   1539 ;	quantum/action.c:948: __attribute__((weak)) void register_code(uint8_t code) {
                                   1540 ;	-----------------------------------------
                                   1541 ;	 function register_code
                                   1542 ;	-----------------------------------------
      007A1A                       1543 _register_code:
      007A1A E5 82            [12] 1544 	mov	a,dpl
      007A1C 90 08 FE         [24] 1545 	mov	dptr,#_register_code_code_10000_717
      007A1F F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/action.c:949: if (code == KC_NO) {
      007A20 E0               [24] 1548 	movx	a,@dptr
      007A21 FF               [12] 1549 	mov	r7,a
      007A22 70 01            [24] 1550 	jnz	00123$
                                   1551 ;	quantum/action.c:950: return;
      007A24 22               [24] 1552 	ret
      007A25                       1553 00123$:
                                   1554 ;	quantum/action.c:985: } else if (IS_BASIC_KEYCODE(code)) {
      007A25 BF 04 00         [24] 1555 	cjne	r7,#0x04,00186$
      007A28                       1556 00186$:
      007A28 40 12            [24] 1557 	jc	00119$
      007A2A EF               [12] 1558 	mov	a,r7
      007A2B 24 5B            [12] 1559 	add	a,#0xff - 0xa4
      007A2D 40 0D            [24] 1560 	jc	00119$
                                   1561 ;	free result
                                   1562 ;	quantum/action.c:990: if (!add_owned_key(code)) return;
      007A2F 8F 82            [24] 1563 	mov	dpl, r7
      007A31 12 82 37         [24] 1564 	lcall	_add_owned_key
      007A34 E5 82            [12] 1565 	mov	a, dpl
      007A36 70 01            [24] 1566 	jnz	00104$
      007A38 22               [24] 1567 	ret
      007A39                       1568 00104$:
                                   1569 ;	quantum/action.c:1004: send_keyboard_report();
      007A39 02 84 C9         [24] 1570 	ljmp	_send_keyboard_report
      007A3C                       1571 00119$:
                                   1572 ;	quantum/action.c:1005: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A3C 12 7C 49         [24] 1573 	lcall	_ak820_outline_0173
      007A3F BF E0 00         [24] 1574 	cjne	r7,#0xe0,00190$
      007A42                       1575 00190$:
      007A42 40 1A            [24] 1576 	jc	00115$
      007A44 EF               [12] 1577 	mov	a,r7
      007A45 24 18            [12] 1578 	add	a,#0xff - 0xe7
      007A47 40 15            [24] 1579 	jc	00115$
                                   1580 ;	free result
                                   1581 ;	quantum/action.c:1006: add_owned_mods(MOD_BIT(code));
      007A49 74 07            [12] 1582 	mov	a,#0x07
      007A4B 5F               [12] 1583 	anl	a,r7
      007A4C 12 7C 00         [24] 1584 	lcall	_ak820_outline_0067
      007A4F 80 02            [24] 1585 	sjmp	00194$
      007A51                       1586 00193$:
      007A51 25 E0            [12] 1587 	add	a,acc
      007A53                       1588 00194$:
      007A53 D5 F0 FB         [24] 1589 	djnz	b,00193$
      007A56 F5 82            [12] 1590 	mov	dpl,a
      007A58 12 81 97         [24] 1591 	lcall	_add_owned_mods
                                   1592 ;	quantum/action.c:1007: send_keyboard_report();
      007A5B 02 84 C9         [24] 1593 	ljmp	_send_keyboard_report
      007A5E                       1594 00115$:
                                   1595 ;	quantum/action.c:1010: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A5E 12 7C 49         [24] 1596 	lcall	_ak820_outline_0173
      007A61 BF A5 00         [24] 1597 	cjne	r7,#0xa5,00195$
      007A64                       1598 00195$:
      007A64 40 05            [24] 1599 	jc	00113$
      007A66 EF               [12] 1600 	mov	a,r7
      007A67 24 58            [12] 1601 	add	a,#0xff - 0xa7
      007A69 50 0D            [24] 1602 	jnc	00108$
                                   1603 ;	free result
      007A6B                       1604 00113$:
      007A6B 12 7C 49         [24] 1605 	lcall	_ak820_outline_0173
      007A6E BF A8 00         [24] 1606 	cjne	r7,#0xa8,00198$
      007A71                       1607 00198$:
      007A71 40 13            [24] 1608 	jc	00125$
      007A73 EF               [12] 1609 	mov	a,r7
      007A74 24 3D            [12] 1610 	add	a,#0xff - 0xc2
      007A76 40 0E            [24] 1611 	jc	00125$
                                   1612 ;	free result
      007A78                       1613 00108$:
                                   1614 ;	quantum/action.c:1012: owned_usage_key(code, true);
      007A78 12 7C 49         [24] 1615 	lcall	_ak820_outline_0173
      007A7B 90 0B 59         [24] 1616 	mov	dptr,#_owned_usage_key_PARM_2
      007A7E 74 01            [12] 1617 	mov	a,#0x01
      007A80 F0               [24] 1618 	movx	@dptr,a
      007A81 8F 82            [24] 1619 	mov	dpl, r7
                                   1620 ;	quantum/action.c:1020: register_mouse(code, true);
                                   1621 ;	quantum/action.c:1022: }
      007A83 02 83 76         [24] 1622 	ljmp	_owned_usage_key
      007A86                       1623 00125$:
      007A86 22               [24] 1624 	ret
                                   1625 ;------------------------------------------------------------
                                   1626 ;Allocation info for local variables in function 'unregister_code'
                                   1627 ;------------------------------------------------------------
                                   1628 ;code          Allocated with name '_unregister_code_code_10000_731'
                                   1629 ;------------------------------------------------------------
                                   1630 ;	quantum/action.c:1028: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1631 ;	-----------------------------------------
                                   1632 ;	 function unregister_code
                                   1633 ;	-----------------------------------------
      007A87                       1634 _unregister_code:
      007A87 E5 82            [12] 1635 	mov	a,dpl
      007A89 90 08 FF         [24] 1636 	mov	dptr,#_unregister_code_code_10000_731
      007A8C F0               [24] 1637 	movx	@dptr,a
                                   1638 ;	quantum/action.c:1029: if (code == KC_NO) {
      007A8D E0               [24] 1639 	movx	a,@dptr
      007A8E FF               [12] 1640 	mov	r7,a
      007A8F 70 01            [24] 1641 	jnz	00121$
                                   1642 ;	quantum/action.c:1030: return;
      007A91 22               [24] 1643 	ret
      007A92                       1644 00121$:
                                   1645 ;	quantum/action.c:1062: } else if (IS_BASIC_KEYCODE(code)) {
      007A92 BF 04 00         [24] 1646 	cjne	r7,#0x04,00184$
      007A95                       1647 00184$:
      007A95 40 12            [24] 1648 	jc	00117$
      007A97 EF               [12] 1649 	mov	a,r7
      007A98 24 5B            [12] 1650 	add	a,#0xff - 0xa4
      007A9A 40 0D            [24] 1651 	jc	00117$
                                   1652 ;	free result
                                   1653 ;	quantum/action.c:1064: if (!del_owned_key(code)) return;
      007A9C 8F 82            [24] 1654 	mov	dpl, r7
      007A9E 12 82 B0         [24] 1655 	lcall	_del_owned_key
      007AA1 E5 82            [12] 1656 	mov	a, dpl
      007AA3 70 01            [24] 1657 	jnz	00102$
      007AA5 22               [24] 1658 	ret
      007AA6                       1659 00102$:
                                   1660 ;	quantum/action.c:1071: send_keyboard_report();
      007AA6 02 84 C9         [24] 1661 	ljmp	_send_keyboard_report
      007AA9                       1662 00117$:
                                   1663 ;	quantum/action.c:1072: } else if (IS_MODIFIER_KEYCODE(code)) {
      007AA9 12 7C 4F         [24] 1664 	lcall	_ak820_outline_0174
      007AAC BF E0 00         [24] 1665 	cjne	r7,#0xe0,00188$
      007AAF                       1666 00188$:
      007AAF 40 1A            [24] 1667 	jc	00113$
      007AB1 EF               [12] 1668 	mov	a,r7
      007AB2 24 18            [12] 1669 	add	a,#0xff - 0xe7
      007AB4 40 15            [24] 1670 	jc	00113$
                                   1671 ;	free result
                                   1672 ;	quantum/action.c:1073: del_owned_mods(MOD_BIT(code));
      007AB6 74 07            [12] 1673 	mov	a,#0x07
      007AB8 5F               [12] 1674 	anl	a,r7
      007AB9 12 7C 00         [24] 1675 	lcall	_ak820_outline_0067
      007ABC 80 02            [24] 1676 	sjmp	00192$
      007ABE                       1677 00191$:
      007ABE 25 E0            [12] 1678 	add	a,acc
      007AC0                       1679 00192$:
      007AC0 D5 F0 FB         [24] 1680 	djnz	b,00191$
      007AC3 F5 82            [12] 1681 	mov	dpl,a
      007AC5 12 81 A6         [24] 1682 	lcall	_del_owned_mods
                                   1683 ;	quantum/action.c:1074: send_keyboard_report();
      007AC8 02 84 C9         [24] 1684 	ljmp	_send_keyboard_report
      007ACB                       1685 00113$:
                                   1686 ;	quantum/action.c:1077: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007ACB 12 7C 4F         [24] 1687 	lcall	_ak820_outline_0174
      007ACE BF A5 00         [24] 1688 	cjne	r7,#0xa5,00193$
      007AD1                       1689 00193$:
      007AD1 40 05            [24] 1690 	jc	00111$
      007AD3 EF               [12] 1691 	mov	a,r7
      007AD4 24 58            [12] 1692 	add	a,#0xff - 0xa7
      007AD6 50 0D            [24] 1693 	jnc	00106$
                                   1694 ;	free result
      007AD8                       1695 00111$:
      007AD8 12 7C 4F         [24] 1696 	lcall	_ak820_outline_0174
      007ADB BF A8 00         [24] 1697 	cjne	r7,#0xa8,00196$
      007ADE                       1698 00196$:
      007ADE 40 12            [24] 1699 	jc	00123$
      007AE0 EF               [12] 1700 	mov	a,r7
      007AE1 24 3D            [12] 1701 	add	a,#0xff - 0xc2
      007AE3 40 0D            [24] 1702 	jc	00123$
                                   1703 ;	free result
      007AE5                       1704 00106$:
                                   1705 ;	quantum/action.c:1079: owned_usage_key(code, false);
      007AE5 12 7C 4F         [24] 1706 	lcall	_ak820_outline_0174
      007AE8 90 0B 59         [24] 1707 	mov	dptr,#_owned_usage_key_PARM_2
      007AEB E4               [12] 1708 	clr	a
      007AEC F0               [24] 1709 	movx	@dptr,a
      007AED 8F 82            [24] 1710 	mov	dpl, r7
                                   1711 ;	quantum/action.c:1087: register_mouse(code, false);
                                   1712 ;	quantum/action.c:1089: }
      007AEF 02 83 76         [24] 1713 	ljmp	_owned_usage_key
      007AF2                       1714 00123$:
      007AF2 22               [24] 1715 	ret
                                   1716 ;------------------------------------------------------------
                                   1717 ;Allocation info for local variables in function 'tap_code_delay'
                                   1718 ;------------------------------------------------------------
                                   1719 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1720 ;code          Allocated with name '_tap_code_delay_code_10000_744'
                                   1721 ;i             Allocated with name '_tap_code_delay_i_20000_746'
                                   1722 ;i             Allocated with name '_tap_code_delay_i_50000_749'
                                   1723 ;------------------------------------------------------------
                                   1724 ;	quantum/action.c:1096: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1725 ;	-----------------------------------------
                                   1726 ;	 function tap_code_delay
                                   1727 ;	-----------------------------------------
      007AF3                       1728 _tap_code_delay:
      007AF3 E5 82            [12] 1729 	mov	a,dpl
      007AF5 90 09 02         [24] 1730 	mov	dptr,#_tap_code_delay_code_10000_744
      007AF8 F0               [24] 1731 	movx	@dptr,a
                                   1732 ;	quantum/action.c:1097: register_code(code);
      007AF9 E0               [24] 1733 	movx	a,@dptr
      007AFA FF               [12] 1734 	mov	r7,a
      007AFB F5 82            [12] 1735 	mov	dpl,a
      007AFD C0 07            [24] 1736 	push	ar7
      007AFF 51 1A            [12] 1737 	acall	_register_code
      007B01 D0 07            [24] 1738 	pop	ar7
                                   1739 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007B03 90 09 00         [24] 1740 	mov	dptr,#_tap_code_delay_PARM_2
      007B06 12 38 5C         [24] 1741 	lcall	_ak820_outline_0086
      007B09                       1742 00110$:
      007B09 ED               [12] 1743 	mov	a,r5
      007B0A 4E               [12] 1744 	orl	a,r6
      007B0B 60 0D            [24] 1745 	jz	00105$
                                   1746 ;	quantum/action.c:1099: wait_ms(1);
      007B0D 90 00 01         [24] 1747 	mov	dptr,#0x0001
      007B10 12 5E 16         [24] 1748 	lcall	_mDelaymS
                                   1749 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007B13 1D               [12] 1750 	dec	r5
      007B14 BD FF 01         [24] 1751 	cjne	r5,#0xff,00141$
      007B17 1E               [12] 1752 	dec	r6
      007B18                       1753 00141$:
      007B18 80 EF            [24] 1754 	sjmp	00110$
      007B1A                       1755 00105$:
                                   1756 ;	quantum/action.c:1101: unregister_code(code);
      007B1A 8F 82            [24] 1757 	mov	dpl, r7
                                   1758 ;	quantum/action.c:1102: }
      007B1C 41 87            [12] 1759 	ajmp	_unregister_code
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'tap_code'
                                   1762 ;------------------------------------------------------------
                                   1763 ;code          Allocated with name '_tap_code_code_10000_751'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action.c:1108: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function tap_code
                                   1768 ;	-----------------------------------------
      007B1E                       1769 _tap_code:
      007B1E E5 82            [12] 1770 	mov	a,dpl
      007B20 90 09 03         [24] 1771 	mov	dptr,#_tap_code_code_10000_751
      007B23 F0               [24] 1772 	movx	@dptr,a
                                   1773 ;	quantum/action.c:1109: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007B24 E0               [24] 1774 	movx	a,@dptr
      007B25 FF               [12] 1775 	mov	r7,a
      007B26 BF 39 04         [24] 1776 	cjne	r7,#0x39,00103$
      007B29 7E 50            [12] 1777 	mov	r6,#0x50
      007B2B 80 02            [24] 1778 	sjmp	00104$
      007B2D                       1779 00103$:
      007B2D 7E 00            [12] 1780 	mov	r6,#0x00
      007B2F                       1781 00104$:
      007B2F 90 09 00         [24] 1782 	mov	dptr,#_tap_code_delay_PARM_2
      007B32 EE               [12] 1783 	mov	a,r6
      007B33 12 38 A8         [24] 1784 	lcall	_ak820_outline_0133
      007B36 8F 82            [24] 1785 	mov	dpl, r7
                                   1786 ;	quantum/action.c:1110: }
      007B38 41 F3            [12] 1787 	ajmp	_tap_code_delay
                                   1788 ;------------------------------------------------------------
                                   1789 ;Allocation info for local variables in function 'register_mods'
                                   1790 ;------------------------------------------------------------
                                   1791 ;mods          Allocated with name '_register_mods_mods_10000_753'
                                   1792 ;------------------------------------------------------------
                                   1793 ;	quantum/action.c:1116: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1794 ;	-----------------------------------------
                                   1795 ;	 function register_mods
                                   1796 ;	-----------------------------------------
      007B3A                       1797 _register_mods:
      007B3A E5 82            [12] 1798 	mov	a,dpl
      007B3C 90 09 04         [24] 1799 	mov	dptr,#_register_mods_mods_10000_753
      007B3F F0               [24] 1800 	movx	@dptr,a
                                   1801 ;	quantum/action.c:1117: if (mods) {
      007B40 E0               [24] 1802 	movx	a,@dptr
      007B41 FF               [12] 1803 	mov	r7,a
      007B42 E0               [24] 1804 	movx	a,@dptr
      007B43 60 08            [24] 1805 	jz	00103$
                                   1806 ;	quantum/action.c:1118: add_owned_mods(mods);
      007B45 8F 82            [24] 1807 	mov	dpl, r7
      007B47 12 81 97         [24] 1808 	lcall	_add_owned_mods
                                   1809 ;	quantum/action.c:1119: send_keyboard_report();
                                   1810 ;	quantum/action.c:1121: }
      007B4A 02 84 C9         [24] 1811 	ljmp	_send_keyboard_report
      007B4D                       1812 00103$:
      007B4D 22               [24] 1813 	ret
                                   1814 ;------------------------------------------------------------
                                   1815 ;Allocation info for local variables in function 'unregister_mods'
                                   1816 ;------------------------------------------------------------
                                   1817 ;mods          Allocated with name '_unregister_mods_mods_10000_757'
                                   1818 ;------------------------------------------------------------
                                   1819 ;	quantum/action.c:1127: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1820 ;	-----------------------------------------
                                   1821 ;	 function unregister_mods
                                   1822 ;	-----------------------------------------
      007B4E                       1823 _unregister_mods:
      007B4E E5 82            [12] 1824 	mov	a,dpl
      007B50 90 09 05         [24] 1825 	mov	dptr,#_unregister_mods_mods_10000_757
      007B53 F0               [24] 1826 	movx	@dptr,a
                                   1827 ;	quantum/action.c:1128: if (mods) {
      007B54 E0               [24] 1828 	movx	a,@dptr
      007B55 FF               [12] 1829 	mov	r7,a
      007B56 E0               [24] 1830 	movx	a,@dptr
      007B57 60 08            [24] 1831 	jz	00103$
                                   1832 ;	quantum/action.c:1129: del_owned_mods(mods);
      007B59 8F 82            [24] 1833 	mov	dpl, r7
      007B5B 12 81 A6         [24] 1834 	lcall	_del_owned_mods
                                   1835 ;	quantum/action.c:1130: send_keyboard_report();
                                   1836 ;	quantum/action.c:1132: }
      007B5E 02 84 C9         [24] 1837 	ljmp	_send_keyboard_report
      007B61                       1838 00103$:
      007B61 22               [24] 1839 	ret
                                   1840 ;------------------------------------------------------------
                                   1841 ;Allocation info for local variables in function 'register_weak_mods'
                                   1842 ;------------------------------------------------------------
                                   1843 ;mods          Allocated with name '_register_weak_mods_mods_10000_761'
                                   1844 ;------------------------------------------------------------
                                   1845 ;	quantum/action.c:1138: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1846 ;	-----------------------------------------
                                   1847 ;	 function register_weak_mods
                                   1848 ;	-----------------------------------------
      007B62                       1849 _register_weak_mods:
      007B62 E5 82            [12] 1850 	mov	a,dpl
      007B64 90 09 06         [24] 1851 	mov	dptr,#_register_weak_mods_mods_10000_761
      007B67 F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action.c:1139: if (mods) {
      007B68 E0               [24] 1854 	movx	a,@dptr
      007B69 FF               [12] 1855 	mov	r7,a
      007B6A E0               [24] 1856 	movx	a,@dptr
      007B6B 60 08            [24] 1857 	jz	00103$
                                   1858 ;	quantum/action.c:1140: add_owned_weak_mods(mods);
      007B6D 8F 82            [24] 1859 	mov	dpl, r7
      007B6F 12 81 B4         [24] 1860 	lcall	_add_owned_weak_mods
                                   1861 ;	quantum/action.c:1141: send_keyboard_report();
                                   1862 ;	quantum/action.c:1143: }
      007B72 02 84 C9         [24] 1863 	ljmp	_send_keyboard_report
      007B75                       1864 00103$:
      007B75 22               [24] 1865 	ret
                                   1866 ;------------------------------------------------------------
                                   1867 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1868 ;------------------------------------------------------------
                                   1869 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_765'
                                   1870 ;------------------------------------------------------------
                                   1871 ;	quantum/action.c:1149: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1872 ;	-----------------------------------------
                                   1873 ;	 function unregister_weak_mods
                                   1874 ;	-----------------------------------------
      007B76                       1875 _unregister_weak_mods:
      007B76 E5 82            [12] 1876 	mov	a,dpl
      007B78 90 09 07         [24] 1877 	mov	dptr,#_unregister_weak_mods_mods_10000_765
      007B7B F0               [24] 1878 	movx	@dptr,a
                                   1879 ;	quantum/action.c:1150: if (mods) {
      007B7C E0               [24] 1880 	movx	a,@dptr
      007B7D FF               [12] 1881 	mov	r7,a
      007B7E E0               [24] 1882 	movx	a,@dptr
      007B7F 60 08            [24] 1883 	jz	00103$
                                   1884 ;	quantum/action.c:1151: del_owned_weak_mods(mods);
      007B81 8F 82            [24] 1885 	mov	dpl, r7
      007B83 12 81 C3         [24] 1886 	lcall	_del_owned_weak_mods
                                   1887 ;	quantum/action.c:1152: send_keyboard_report();
                                   1888 ;	quantum/action.c:1154: }
      007B86 02 84 C9         [24] 1889 	ljmp	_send_keyboard_report
      007B89                       1890 00103$:
      007B89 22               [24] 1891 	ret
                                   1892 ;------------------------------------------------------------
                                   1893 ;Allocation info for local variables in function 'clear_keyboard'
                                   1894 ;------------------------------------------------------------
                                   1895 ;	quantum/action.c:1160: void clear_keyboard(void) {
                                   1896 ;	-----------------------------------------
                                   1897 ;	 function clear_keyboard
                                   1898 ;	-----------------------------------------
      007B8A                       1899 _clear_keyboard:
                                   1900 ;	quantum/action.c:1161: clear_mods();
      007B8A 12 85 44         [24] 1901 	lcall	_clear_mods
                                   1902 ;	quantum/action.c:1162: clear_keyboard_but_mods();
                                   1903 ;	quantum/action.c:1163: }
      007B8D 61 8F            [12] 1904 	ajmp	_clear_keyboard_but_mods
                                   1905 ;------------------------------------------------------------
                                   1906 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1907 ;------------------------------------------------------------
                                   1908 ;	quantum/action.c:1169: void clear_keyboard_but_mods(void) {
                                   1909 ;	-----------------------------------------
                                   1910 ;	 function clear_keyboard_but_mods
                                   1911 ;	-----------------------------------------
      007B8F                       1912 _clear_keyboard_but_mods:
                                   1913 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B8F 90 0E B1         [24] 1914 	mov	dptr,#_actual_keyboard_report
      007B92 12 74 5E         [24] 1915 	lcall	_clear_keys_from_report
                                   1916 ;	quantum/action.c:1171: clear_keyboard_but_mods_and_keys();
                                   1917 ;	quantum/action.c:1172: }
      007B95 61 97            [12] 1918 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	quantum/action.c:1178: void clear_keyboard_but_mods_and_keys(void) {
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function clear_keyboard_but_mods_and_keys
                                   1925 ;	-----------------------------------------
      007B97                       1926 _clear_keyboard_but_mods_and_keys:
                                   1927 ;	quantum/action.c:1180: ak820_tapping_cancel();
      007B97 12 4C 85         [24] 1928 	lcall	_ak820_tapping_cancel
                                   1929 ;	quantum/action.c:1182: ak820_tap_dance_cancel();
      007B9A 12 48 71         [24] 1930 	lcall	_ak820_tap_dance_cancel
                                   1931 ;	quantum/action.c:1197: ak820_oneshot_cancel();
      007B9D 12 2E F0         [24] 1932 	lcall	_ak820_oneshot_cancel
                                   1933 ;	quantum/action.c:1200: ak820_combo_cancel();
      007BA0 12 35 6C         [24] 1934 	lcall	_ak820_combo_cancel
                                   1935 ;	quantum/action.c:1203: repeat_key_cancel();
      007BA3 12 A7 2F         [24] 1936 	lcall	_repeat_key_cancel
                                   1937 ;	quantum/action.c:1205: clear_owned_mods();
      007BA6 12 81 D2         [24] 1938 	lcall	_clear_owned_mods
                                   1939 ;	quantum/action.c:1206: clear_owned_keys();
      007BA9 12 82 0A         [24] 1940 	lcall	_clear_owned_keys
                                   1941 ;	quantum/action.c:1207: clear_owned_usages();
      007BAC 12 83 3E         [24] 1942 	lcall	_clear_owned_usages
                                   1943 ;	quantum/action.c:1208: layer_hold_clear();
      007BAF B1 90            [12] 1944 	acall	_layer_hold_clear
                                   1945 ;	quantum/action.c:1210: clear_macro_tri_layer();
      007BB1 12 A1 EC         [24] 1946 	lcall	_clear_macro_tri_layer
                                   1947 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007BB4 90 0E B1         [24] 1948 	mov	dptr,#_actual_keyboard_report
      007BB7 12 74 5E         [24] 1949 	lcall	_clear_keys_from_report
                                   1950 ;	quantum/action.c:1215: host_system_send(0);
      007BBA 90 00 00         [24] 1951 	mov	dptr,#0x0000
      007BBD 12 72 3C         [24] 1952 	lcall	_host_system_send
                                   1953 ;	quantum/action.c:1216: host_consumer_send(0);
      007BC0 90 00 00         [24] 1954 	mov	dptr,#0x0000
      007BC3 12 72 6B         [24] 1955 	lcall	_host_consumer_send
                                   1956 ;	quantum/action.c:1218: clear_weak_mods();
      007BC6 12 85 79         [24] 1957 	lcall	_clear_weak_mods
                                   1958 ;	quantum/action.c:1219: send_keyboard_report();
                                   1959 ;	quantum/action.c:1227: }
      007BC9 02 84 C9         [24] 1960 	ljmp	_send_keyboard_report
                                   1961 ;------------------------------------------------------------
                                   1962 ;Allocation info for local variables in function 'is_tap_record'
                                   1963 ;------------------------------------------------------------
                                   1964 ;record        Allocated with name '_is_tap_record_record_10000_781'
                                   1965 ;action        Allocated with name '_is_tap_record_action_10001_785'
                                   1966 ;------------------------------------------------------------
                                   1967 ;	quantum/action.c:1233: bool is_tap_record(keyrecord_t *record) {
                                   1968 ;	-----------------------------------------
                                   1969 	.area CSEG    (CODE)
                                   1970 	.area CONST   (CODE)
                                   1971 	.area XINIT   (CODE)
      00C75E                       1972 __xinit__disable_action_cache:
      00C75E 00                    1973 	.db #0x00	;  0
                                   1974 	.area CABS    (ABS,CODE)
                                   1975 
                                   1976 ; Experimental exact instruction outlining.
                                   1977 	.globl _ak820_outline_0001
                                   1978 	.globl _ak820_outline_0006
                                   1979 	.globl _ak820_outline_0008
                                   1980 	.globl _ak820_outline_0010
                                   1981 	.globl _ak820_outline_0014
                                   1982 	.globl _ak820_outline_0015
                                   1983 	.globl _ak820_outline_0016
                                   1984 	.globl _ak820_outline_0017
                                   1985 	.globl _ak820_outline_0020
                                   1986 	.globl _ak820_outline_0025
                                   1987 	.globl _ak820_outline_0026
                                   1988 	.globl _ak820_outline_0036
                                   1989 	.globl _ak820_outline_0041
                                   1990 	.globl _ak820_outline_0047
                                   1991 	.globl _ak820_outline_0063
                                   1992 	.globl _ak820_outline_0067
                                   1993 	.globl _ak820_outline_0076
                                   1994 	.globl _ak820_outline_0077
                                   1995 	.globl _ak820_outline_0078
                                   1996 	.globl _ak820_outline_0082
                                   1997 	.globl _ak820_outline_0086
                                   1998 	.globl _ak820_outline_0094
                                   1999 	.globl _ak820_outline_0111
                                   2000 	.globl _ak820_outline_0112
                                   2001 	.globl _ak820_outline_0114
                                   2002 	.globl _ak820_outline_0116
                                   2003 	.globl _ak820_outline_0118
                                   2004 	.globl _ak820_outline_0119
                                   2005 	.globl _ak820_outline_0124
                                   2006 	.globl _ak820_outline_0131
                                   2007 	.globl _ak820_outline_0132
                                   2008 	.globl _ak820_outline_0133
                                   2009 	.globl _ak820_outline_0140
                                   2010 	.globl _ak820_outline_0142
                                   2011 	.globl _ak820_outline_0149
                                   2012 	.globl _ak820_outline_0150
                                   2013 	.globl _ak820_outline_0153
                                   2014 	.globl _ak820_outline_0156
                                   2015 	.globl _ak820_outline_0164
                                   2016 	.globl _ak820_outline_0167
                                   2017 	.globl _ak820_outline_0173
                                   2018 	.globl _ak820_outline_0174
                                   2019 	.globl _ak820_outline_0196
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0016
      007BCC                       2023 _ak820_outline_0016:
      007BCC 2D               [12] 2024 	add	a,r5
      007BCD F9               [12] 2025 	mov	r1,a
      007BCE E4               [12] 2026 	clr	a
      007BCF 3E               [12] 2027 	addc	a,r6
      007BD0 FA               [12] 2028 	mov	r2,a
      007BD1 8F 03            [24] 2029 	mov	ar3,r7
      007BD3 89 82            [24] 2030 	mov	dpl,r1
      007BD5 8A 83            [24] 2031 	mov	dph,r2
      007BD7 8B F0            [24] 2032 	mov	b,r3
      007BD9 22               [24] 2033 	ret
                                   2034 
                                   2035 	.area CSEG (CODE)
                                   2036 ; function ak820_outline_0017
      007BDA                       2037 _ak820_outline_0017:
      007BDA 2D               [12] 2038 	add	a,r5
      007BDB FA               [12] 2039 	mov	r2,a
      007BDC E4               [12] 2040 	clr	a
      007BDD 3E               [12] 2041 	addc	a,r6
      007BDE FB               [12] 2042 	mov	r3,a
      007BDF 8F 04            [24] 2043 	mov	ar4,r7
      007BE1 8A 82            [24] 2044 	mov	dpl,r2
      007BE3 8B 83            [24] 2045 	mov	dph,r3
      007BE5 8C F0            [24] 2046 	mov	b,r4
      007BE7 22               [24] 2047 	ret
                                   2048 
                                   2049 	.area CSEG (CODE)
                                   2050 ; function ak820_outline_0025
      007BE8                       2051 _ak820_outline_0025:
      007BE8 8E 82            [24] 2052 	mov	dpl,r6
      007BEA 8F 83            [24] 2053 	mov	dph,r7
      007BEC A3               [24] 2054 	inc	dptr
      007BED E0               [24] 2055 	movx	a,@dptr
      007BEE FC               [12] 2056 	mov	r4,a
      007BEF 7D 00            [12] 2057 	mov	r5,#0x00
      007BF1 8E 82            [24] 2058 	mov	dpl,r6
      007BF3 8F 83            [24] 2059 	mov	dph,r7
      007BF5 E0               [24] 2060 	movx	a,@dptr
      007BF6 22               [24] 2061 	ret
                                   2062 
                                   2063 	.area CSEG (CODE)
                                   2064 ; function ak820_outline_0047
      007BF7                       2065 _ak820_outline_0047:
      007BF7 90 08 F9         [24] 2066 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007BFA E0               [24] 2067 	movx	a,@dptr
      007BFB 54 1F            [12] 2068 	anl	a,#0x1f
      007BFD F5 82            [12] 2069 	mov	dpl,a
      007BFF 22               [24] 2070 	ret
                                   2071 
                                   2072 	.area CSEG (CODE)
                                   2073 ; function ak820_outline_0067
      007C00                       2074 _ak820_outline_0067:
      007C00 F5 F0            [12] 2075 	mov	b,a
      007C02 05 F0            [12] 2076 	inc	b
      007C04 74 01            [12] 2077 	mov	a,#0x01
      007C06 22               [24] 2078 	ret
                                   2079 
                                   2080 	.area CSEG (CODE)
                                   2081 ; function ak820_outline_0076
      007C07                       2082 _ak820_outline_0076:
      007C07 90 0E 8F         [24] 2083 	mov	dptr,#___memcpy_PARM_3
      007C0A 74 06            [12] 2084 	mov	a,#0x06
      007C0C F0               [24] 2085 	movx	@dptr,a
      007C0D E4               [12] 2086 	clr	a
      007C0E A3               [24] 2087 	inc	dptr
      007C0F F0               [24] 2088 	movx	@dptr,a
      007C10 22               [24] 2089 	ret
                                   2090 
                                   2091 	.area CSEG (CODE)
                                   2092 ; function ak820_outline_0082
      007C11                       2093 _ak820_outline_0082:
      007C11 90 08 F8         [24] 2094 	mov	dptr,#_process_action_PARM_2
      007C14 E0               [24] 2095 	movx	a,@dptr
      007C15 F5 82            [12] 2096 	mov	dpl,a
      007C17 22               [24] 2097 	ret
                                   2098 
                                   2099 	.area CSEG (CODE)
                                   2100 ; function ak820_outline_0094
      007C18                       2101 _ak820_outline_0094:
      007C18 90 08 F9         [24] 2102 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C1B E0               [24] 2103 	movx	a,@dptr
      007C1C 03               [12] 2104 	rr	a
      007C1D 03               [12] 2105 	rr	a
      007C1E 54 03            [12] 2106 	anl	a,#0x03
      007C20 22               [24] 2107 	ret
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0118
      007C21                       2111 _ak820_outline_0118:
      007C21 8E 82            [24] 2112 	mov	dpl,r6
      007C23 8F 83            [24] 2113 	mov	dph,r7
      007C25 8D F0            [24] 2114 	mov	b,r5
      007C27 22               [24] 2115 	ret
                                   2116 
                                   2117 	.area CSEG (CODE)
                                   2118 ; function ak820_outline_0119
      007C28                       2119 _ak820_outline_0119:
      007C28 90 08 F9         [24] 2120 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C2B E0               [24] 2121 	movx	a,@dptr
      007C2C 54 0F            [12] 2122 	anl	a,#0x0f
      007C2E 22               [24] 2123 	ret
                                   2124 
                                   2125 	.area CSEG (CODE)
                                   2126 ; function ak820_outline_0140
      007C2F                       2127 _ak820_outline_0140:
      007C2F 90 08 F8         [24] 2128 	mov	dptr,#_process_action_PARM_2
      007C32 E0               [24] 2129 	movx	a,@dptr
      007C33 FE               [12] 2130 	mov	r6,a
      007C34 A3               [24] 2131 	inc	dptr
      007C35 E0               [24] 2132 	movx	a,@dptr
      007C36 54 03            [12] 2133 	anl	a,#0x03
      007C38 FF               [12] 2134 	mov	r7,a
      007C39 22               [24] 2135 	ret
                                   2136 
                                   2137 	.area CSEG (CODE)
                                   2138 ; function ak820_outline_0153
      007C3A                       2139 _ak820_outline_0153:
      007C3A 74 07            [12] 2140 	mov	a,#0x07
      007C3C 2D               [12] 2141 	add	a,r5
      007C3D F8               [12] 2142 	mov	r0,a
      007C3E E4               [12] 2143 	clr	a
      007C3F 3E               [12] 2144 	addc	a,r6
      007C40 F9               [12] 2145 	mov	r1,a
      007C41 8F 02            [24] 2146 	mov	ar2,r7
      007C43 22               [24] 2147 	ret
                                   2148 
                                   2149 	.area CSEG (CODE)
                                   2150 ; function ak820_outline_0164
      007C44                       2151 _ak820_outline_0164:
      007C44 90 08 F8         [24] 2152 	mov	dptr,#_process_action_PARM_2
      007C47 E0               [24] 2153 	movx	a,@dptr
      007C48 22               [24] 2154 	ret
                                   2155 
                                   2156 	.area CSEG (CODE)
                                   2157 ; function ak820_outline_0173
      007C49                       2158 _ak820_outline_0173:
      007C49 90 08 FE         [24] 2159 	mov	dptr,#_register_code_code_10000_717
      007C4C E0               [24] 2160 	movx	a,@dptr
      007C4D FF               [12] 2161 	mov	r7,a
      007C4E 22               [24] 2162 	ret
                                   2163 
                                   2164 	.area CSEG (CODE)
                                   2165 ; function ak820_outline_0174
      007C4F                       2166 _ak820_outline_0174:
      007C4F 90 08 FF         [24] 2167 	mov	dptr,#_unregister_code_code_10000_731
      007C52 E0               [24] 2168 	movx	a,@dptr
      007C53 FF               [12] 2169 	mov	r7,a
      007C54 22               [24] 2170 	ret
                                   2171 
                                   2172 	.area CSEG (CODE)
                                   2173 ; function ak820_outline_0196
      007C55                       2174 _ak820_outline_0196:
      007C55 88 82            [24] 2175 	mov	dpl,r0
      007C57 89 83            [24] 2176 	mov	dph,r1
      007C59 22               [24] 2177 	ret
