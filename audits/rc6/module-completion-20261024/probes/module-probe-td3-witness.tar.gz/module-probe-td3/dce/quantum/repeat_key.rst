                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000CE9                        554 _last_record:
      000CE9                        555 	.ds 9
      000CF2                        556 _ak820_repeat_invoking:
      000CF2                        557 	.ds 1
      000CF3                        558 _registered_record:
      000CF3                        559 	.ds 9
      000CFC                        560 _registered_repeat_count:
      000CFC                        561 	.ds 1
      000CFD                        562 _registered_mods:
      000CFD                        563 	.ds 1
      000CFE                        564 _set_last_mods_mods_10000_170:
      000CFE                        565 	.ds 1
      000CFF                        566 _set_last_record_PARM_2:
      000CFF                        567 	.ds 3
      000D02                        568 _set_last_record_keycode_10000_172:
      000D02                        569 	.ds 2
      000D04                        570 _update_last_repeat_count_dir_10000_174:
      000D04                        571 	.ds 1
      000D05                        572 _repeat_invoke_PARM_2:
      000D05                        573 	.ds 1
      000D06                        574 _repeat_invoke_event_10000_182:
      000D06                        575 	.ds 3
      000D09                        576 _repeat_key_invoke_event_10000_197:
      000D09                        577 	.ds 3
      000D0C                        578 _find_alt_keycode_PARM_2:
      000D0C                        579 	.ds 1
      000D0D                        580 _find_alt_keycode_PARM_3:
      000D0D                        581 	.ds 1
      000D0E                        582 _find_alt_keycode_table_10000_199:
      000D0E                        583 	.ds 3
      000D11                        584 _get_alt_repeat_key_keycode_keycode_10000_206:
      000D11                        585 	.ds 2
      000D13                        586 _get_alt_repeat_key_keycode_mods_10000_206:
      000D13                        587 	.ds 1
      000D14                        588 _get_alt_repeat_key_keycode_alt_keycode_10000_206:
      000D14                        589 	.ds 2
      000D16                        590 _alt_repeat_key_invoke_event_10000_220:
      000D16                        591 	.ds 3
      000D19                        592 _get_alt_repeat_key_keycode_user_PARM_2:
      000D19                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000F04                        602 _last_mods:
      000F04                        603 	.ds 1
      000F05                        604 _last_repeat_count:
      000F05                        605 	.ds 1
      000F06                        606 _processing_repeat_count:
      000F06                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function repeat_key_cancel
                                    640 ;	-----------------------------------------
      00A72F                        641 _repeat_key_cancel:
                           000007   642 	ar7 = 0x07
                           000006   643 	ar6 = 0x06
                           000005   644 	ar5 = 0x05
                           000004   645 	ar4 = 0x04
                           000003   646 	ar3 = 0x03
                           000002   647 	ar2 = 0x02
                           000001   648 	ar1 = 0x01
                           000000   649 	ar0 = 0x00
                                    650 ;	quantum/repeat_key.c:45: registered_record.keycode = 0;
      00A72F 90 0C FA         [24]  651 	mov	dptr,#(_registered_record + 0x0007)
      00A732 12 49 28         [24]  652 	lcall	_ak820_outline_0150
                                    653 ;	quantum/repeat_key.c:46: }
      00A735 22               [24]  654 	ret
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'get_last_keycode'
                                    657 ;------------------------------------------------------------
                                    658 ;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
                                    659 ;	-----------------------------------------
                                    660 ;	 function set_last_mods
                                    661 ;	-----------------------------------------
      00A736                        662 _set_last_mods:
      00A736 E5 82            [12]  663 	mov	a,dpl
      00A738 90 0C FE         [24]  664 	mov	dptr,#_set_last_mods_mods_10000_170
      00A73B F0               [24]  665 	movx	@dptr,a
                                    666 ;	quantum/repeat_key.c:66: last_mods = mods;
      00A73C E0               [24]  667 	movx	a,@dptr
      00A73D 90 0F 04         [24]  668 	mov	dptr,#_last_mods
      00A740 F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/repeat_key.c:67: }
      00A741 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'set_last_record'
                                    674 ;------------------------------------------------------------
                                    675 ;record        Allocated with name '_set_last_record_PARM_2'
                                    676 ;keycode       Allocated with name '_set_last_record_keycode_10000_172'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t* record) {
                                    679 ;	-----------------------------------------
                                    680 ;	 function set_last_record
                                    681 ;	-----------------------------------------
      00A742                        682 _set_last_record:
      00A742 12 38 81         [24]  683 	lcall	_ak820_outline_0111
      00A745 90 0D 02         [24]  684 	mov	dptr,#_set_last_record_keycode_10000_172
      00A748 12 38 86         [24]  685 	lcall	_ak820_outline_0112
                                    686 ;	quantum/repeat_key.c:70: last_record         = *record;
      00A74B 90 0C FF         [24]  687 	mov	dptr,#_set_last_record_PARM_2
      00A74E 12 54 6E         [24]  688 	lcall	_ak820_outline_0015
      00A751 90 0E 8C         [24]  689 	mov	dptr,#___memcpy_PARM_2
      00A754 ED               [12]  690 	mov	a,r5
      00A755 12 38 15         [24]  691 	lcall	_ak820_outline_0020
      00A758 90 0E 8F         [24]  692 	mov	dptr,#___memcpy_PARM_3
      00A75B 74 09            [12]  693 	mov	a,#0x09
      00A75D 12 38 A8         [24]  694 	lcall	_ak820_outline_0133
      00A760 90 0C E9         [24]  695 	mov	dptr,#_last_record
      00A763 F5 F0            [12]  696 	mov	b,a
      00A765 12 BE 8E         [24]  697 	lcall	___memcpy
                                    698 ;	quantum/repeat_key.c:71: last_record.keycode = keycode;
      00A768 90 0D 02         [24]  699 	mov	dptr,#_set_last_record_keycode_10000_172
      00A76B 12 38 2D         [24]  700 	lcall	_ak820_outline_0058
      00A76E 90 0C F0         [24]  701 	mov	dptr,#(_last_record + 0x0007)
      00A771 12 49 1A         [24]  702 	lcall	_ak820_outline_0064
                                    703 ;	quantum/repeat_key.c:72: last_repeat_count   = 0;
      00A774 90 0F 05         [24]  704 	mov	dptr,#_last_repeat_count
      00A777 E4               [12]  705 	clr	a
      00A778 F0               [24]  706 	movx	@dptr,a
                                    707 ;	quantum/repeat_key.c:73: }
      00A779 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    711 ;------------------------------------------------------------
                                    712 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function update_last_repeat_count
                                    717 ;	-----------------------------------------
      00A77A                        718 _update_last_repeat_count:
      00A77A E5 82            [12]  719 	mov	a,dpl
      00A77C 90 0D 04         [24]  720 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A77F F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
      00A780 E0               [24]  723 	movx	a,@dptr
      00A781 FF               [12]  724 	mov	r7,a
      00A782 33               [12]  725 	rlc	a
      00A783 E4               [12]  726 	clr	a
      00A784 33               [12]  727 	rlc	a
      00A785 FE               [12]  728 	mov	r6,a
      00A786 90 0F 05         [24]  729 	mov	dptr,#_last_repeat_count
      00A789 E0               [24]  730 	movx	a,@dptr
      00A78A FD               [12]  731 	mov	r5,a
      00A78B 33               [12]  732 	rlc	a
      00A78C E4               [12]  733 	clr	a
      00A78D 33               [12]  734 	rlc	a
      00A78E FC               [12]  735 	mov	r4,a
      00A78F EE               [12]  736 	mov	a,r6
      00A790 B5 04 02         [24]  737 	cjne	a,ar4,00131$
      00A793 80 06            [24]  738 	sjmp	00104$
      00A795                        739 00131$:
                                    740 ;	quantum/repeat_key.c:78: last_repeat_count = dir;
      00A795 90 0F 05         [24]  741 	mov	dptr,#_last_repeat_count
      00A798 EF               [12]  742 	mov	a,r7
      00A799 F0               [24]  743 	movx	@dptr,a
      00A79A 22               [24]  744 	ret
      00A79B                        745 00104$:
                                    746 ;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      00A79B EE               [12]  747 	mov	a,r6
      00A79C 60 0F            [24]  748 	jz	00108$
      00A79E C3               [12]  749 	clr	c
      00A79F 74 01            [12]  750 	mov	a,#(0x81 ^ 0x80)
      00A7A1 8D F0            [24]  751 	mov	b,r5
      00A7A3 63 F0 80         [24]  752 	xrl	b,#0x80
      00A7A6 95 F0            [12]  753 	subb	a,b
      00A7A8 E4               [12]  754 	clr	a
      00A7A9 33               [12]  755 	rlc	a
      00A7AA FF               [12]  756 	mov	r7,a
                                    757 ;	free result
      00A7AB 80 09            [24]  758 	sjmp	00109$
      00A7AD                        759 00108$:
      00A7AD C3               [12]  760 	clr	c
      00A7AE ED               [12]  761 	mov	a,r5
      00A7AF 64 80            [12]  762 	xrl	a,#0x80
      00A7B1 94 FF            [12]  763 	subb	a,#0xff
      00A7B3 E4               [12]  764 	clr	a
      00A7B4 33               [12]  765 	rlc	a
      00A7B5 FF               [12]  766 	mov	r7,a
      00A7B6                        767 00109$:
      00A7B6 EF               [12]  768 	mov	a,r7
      00A7B7 60 09            [24]  769 	jz	00106$
                                    770 ;	quantum/repeat_key.c:80: last_repeat_count += dir;
      00A7B9 90 0D 04         [24]  771 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A7BC E0               [24]  772 	movx	a,@dptr
      00A7BD 90 0F 05         [24]  773 	mov	dptr,#_last_repeat_count
      00A7C0 2D               [12]  774 	add	a, r5
      00A7C1 F0               [24]  775 	movx	@dptr,a
      00A7C2                        776 00106$:
                                    777 ;	quantum/repeat_key.c:82: }
      00A7C2 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function get_repeat_key_count
                                    785 ;	-----------------------------------------
      00A7C3                        786 _get_repeat_key_count:
                                    787 ;	quantum/repeat_key.c:85: return processing_repeat_count;
      00A7C3 90 0F 06         [24]  788 	mov	dptr,#_processing_repeat_count
      00A7C6 E0               [24]  789 	movx	a,@dptr
                                    790 ;	quantum/repeat_key.c:86: }
      00A7C7 F5 82            [12]  791 	mov	dpl,a
      00A7C9 22               [24]  792 	ret
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'repeat_invoke'
                                    795 ;------------------------------------------------------------
                                    796 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    797 ;event         Allocated with name '_repeat_invoke_event_10000_182'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t* event, bool alternate) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function repeat_invoke
                                    802 ;	-----------------------------------------
      00A7CA                        803 _repeat_invoke:
      00A7CA 12 43 1B         [24]  804 	lcall	_ak820_outline_0041
      00A7CD 90 0D 06         [24]  805 	mov	dptr,#_repeat_invoke_event_10000_182
      00A7D0 12 38 15         [24]  806 	lcall	_ak820_outline_0020
                                    807 ;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
      00A7D3 90 0C F2         [24]  808 	mov	dptr,#_ak820_repeat_invoking
      00A7D6 E0               [24]  809 	movx	a,@dptr
      00A7D7 60 01            [24]  810 	jz	00102$
      00A7D9 22               [24]  811 	ret
      00A7DA                        812 00102$:
                                    813 ;	quantum/repeat_key.c:99: if (processing_repeat_count) {
      00A7DA 90 0F 06         [24]  814 	mov	dptr,#_processing_repeat_count
      00A7DD E0               [24]  815 	movx	a,@dptr
      00A7DE 60 01            [24]  816 	jz	00104$
                                    817 ;	quantum/repeat_key.c:100: return;
      00A7E0 22               [24]  818 	ret
      00A7E1                        819 00104$:
                                    820 ;	quantum/repeat_key.c:103: if (event->pressed) {
      00A7E1 90 0D 06         [24]  821 	mov	dptr,#_repeat_invoke_event_10000_182
      00A7E4 12 54 6E         [24]  822 	lcall	_ak820_outline_0015
      00A7E7 74 05            [12]  823 	mov	a,#0x05
      00A7E9 12 7B DA         [24]  824 	lcall	_ak820_outline_0017
      00A7EC 12 BF 67         [24]  825 	lcall	__gptrget
      00A7EF 70 03            [24]  826 	jnz	00197$
      00A7F1 02 A8 6B         [24]  827 	ljmp	00117$
      00A7F4                        828 00197$:
                                    829 ;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
      00A7F4 90 0C FA         [24]  830 	mov	dptr,#(_registered_record + 0x0007)
      00A7F7 12 49 3A         [24]  831 	lcall	_ak820_outline_0176
      00A7FA 70 08            [24]  832 	jnz	00105$
      00A7FC 90 0C F0         [24]  833 	mov	dptr,#(_last_record + 0x0007)
      00A7FF 12 49 3A         [24]  834 	lcall	_ak820_outline_0176
      00A802 70 01            [24]  835 	jnz	00106$
      00A804                        836 00105$:
      00A804 22               [24]  837 	ret
      00A805                        838 00106$:
                                    839 ;	quantum/repeat_key.c:107: registered_record = last_record;
      00A805 90 0E 8C         [24]  840 	mov	dptr,#___memcpy_PARM_2
      00A808 74 E9            [12]  841 	mov	a,#_last_record
      00A80A F0               [24]  842 	movx	@dptr,a
      00A80B 74 0C            [12]  843 	mov	a,#(_last_record >> 8)
      00A80D 12 38 4A         [24]  844 	lcall	_ak820_outline_0077
      00A810 90 0E 8F         [24]  845 	mov	dptr,#___memcpy_PARM_3
      00A813 74 09            [12]  846 	mov	a,#0x09
      00A815 12 38 A8         [24]  847 	lcall	_ak820_outline_0133
      00A818 90 0C F3         [24]  848 	mov	dptr,#_registered_record
      00A81B F5 F0            [12]  849 	mov	b,a
      00A81D 12 BE 8E         [24]  850 	lcall	___memcpy
                                    851 ;	quantum/repeat_key.c:108: registered_mods = last_mods;
      00A820 90 0F 04         [24]  852 	mov	dptr,#_last_mods
      00A823 E0               [24]  853 	movx	a,@dptr
      00A824 90 0C FD         [24]  854 	mov	dptr,#_registered_mods
      00A827 F0               [24]  855 	movx	@dptr,a
                                    856 ;	quantum/repeat_key.c:110: if (alternate) {
      00A828 90 0D 05         [24]  857 	mov	dptr,#_repeat_invoke_PARM_2
      00A82B E0               [24]  858 	movx	a,@dptr
      00A82C FC               [12]  859 	mov	r4,a
      00A82D E0               [24]  860 	movx	a,@dptr
      00A82E 60 1A            [24]  861 	jz	00111$
                                    862 ;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
      00A830 C0 04            [24]  863 	push	ar4
      00A832 31 41            [24]  864 	acall	_get_alt_repeat_key_keycode
      00A834 AA 82            [24]  865 	mov	r2, dpl
      00A836 AB 83            [24]  866 	mov	r3, dph
      00A838 D0 04            [24]  867 	pop	ar4
      00A83A 90 0C FA         [24]  868 	mov	dptr,#(_registered_record + 0x0007)
      00A83D 12 49 34         [24]  869 	lcall	_ak820_outline_0167
                                    870 ;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
      00A840 EA               [12]  871 	mov	a,r2
      00A841 4B               [12]  872 	orl	a,r3
      00A842 70 01            [24]  873 	jnz	00109$
      00A844 22               [24]  874 	ret
      00A845                        875 00109$:
                                    876 ;	quantum/repeat_key.c:114: registered_mods = 0;
      00A845 90 0C FD         [24]  877 	mov	dptr,#_registered_mods
      00A848 E4               [12]  878 	clr	a
      00A849 F0               [24]  879 	movx	@dptr,a
      00A84A                        880 00111$:
                                    881 ;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
      00A84A EC               [12]  882 	mov	a,r4
      00A84B 60 04            [24]  883 	jz	00123$
      00A84D 7C FF            [12]  884 	mov	r4,#0xff
      00A84F 80 02            [24]  885 	sjmp	00124$
      00A851                        886 00123$:
      00A851 7C 01            [12]  887 	mov	r4,#0x01
      00A853                        888 00124$:
      00A853 8C 82            [24]  889 	mov	dpl, r4
      00A855 12 A7 7A         [24]  890 	lcall	_update_last_repeat_count
                                    891 ;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
      00A858 90 0C FD         [24]  892 	mov	dptr,#_registered_mods
      00A85B E0               [24]  893 	movx	a,@dptr
      00A85C F5 82            [12]  894 	mov	dpl,a
      00A85E 12 7B 62         [24]  895 	lcall	_register_weak_mods
                                    896 ;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
      00A861 90 0F 05         [24]  897 	mov	dptr,#_last_repeat_count
      00A864 E0               [24]  898 	movx	a,@dptr
      00A865 90 0C FC         [24]  899 	mov	dptr,#_registered_repeat_count
      00A868 F0               [24]  900 	movx	@dptr,a
      00A869 80 2D            [24]  901 	sjmp	00118$
      00A86B                        902 00117$:
                                    903 ;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      00A86B 90 0C FA         [24]  904 	mov	dptr,#(_registered_record + 0x0007)
      00A86E 12 49 3A         [24]  905 	lcall	_ak820_outline_0176
      00A871 60 24            [24]  906 	jz	00112$
      00A873 74 01            [12]  907 	mov	a,#0x01
      00A875 12 7B DA         [24]  908 	lcall	_ak820_outline_0017
      00A878 12 BF 67         [24]  909 	lcall	__gptrget
      00A87B FA               [12]  910 	mov	r2,a
      00A87C 90 0C F4         [24]  911 	mov	dptr,#(_registered_record + 0x0001)
      00A87F E0               [24]  912 	movx	a,@dptr
      00A880 FC               [12]  913 	mov	r4,a
      00A881 EA               [12]  914 	mov	a,r2
      00A882 B5 04 12         [24]  915 	cjne	a,ar4,00112$
                                    916 ;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
      00A885 12 72 A8         [24]  917 	lcall	_ak820_outline_0063
      00A888 12 BF 67         [24]  918 	lcall	__gptrget
      00A88B FD               [12]  919 	mov	r5,a
      00A88C 90 0C F3         [24]  920 	mov	dptr,#_registered_record
      00A88F E0               [24]  921 	movx	a,@dptr
      00A890 FF               [12]  922 	mov	r7,a
      00A891 ED               [12]  923 	mov	a,r5
      00A892 B5 07 02         [24]  924 	cjne	a,ar7,00206$
      00A895 80 01            [24]  925 	sjmp	00118$
      00A897                        926 00206$:
      00A897                        927 00112$:
      00A897 22               [24]  928 	ret
      00A898                        929 00118$:
                                    930 ;	quantum/repeat_key.c:127: registered_record.event = *event;
      00A898 90 0D 06         [24]  931 	mov	dptr,#_repeat_invoke_event_10000_182
      00A89B 12 54 6E         [24]  932 	lcall	_ak820_outline_0015
      00A89E 90 0E 8C         [24]  933 	mov	dptr,#___memcpy_PARM_2
      00A8A1 ED               [12]  934 	mov	a,r5
      00A8A2 12 38 15         [24]  935 	lcall	_ak820_outline_0020
      00A8A5 90 0E 8F         [24]  936 	mov	dptr,#___memcpy_PARM_3
      00A8A8 74 06            [12]  937 	mov	a,#0x06
      00A8AA 12 38 A8         [24]  938 	lcall	_ak820_outline_0133
      00A8AD 90 0C F3         [24]  939 	mov	dptr,#_registered_record
      00A8B0 F5 F0            [12]  940 	mov	b,a
      00A8B2 12 BE 8E         [24]  941 	lcall	___memcpy
                                    942 ;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
      00A8B5 90 0C FC         [24]  943 	mov	dptr,#_registered_repeat_count
      00A8B8 E0               [24]  944 	movx	a,@dptr
      00A8B9 90 0F 06         [24]  945 	mov	dptr,#_processing_repeat_count
      00A8BC F0               [24]  946 	movx	@dptr,a
                                    947 ;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
      00A8BD 90 0C F2         [24]  948 	mov	dptr,#_ak820_repeat_invoking
      00A8C0 74 01            [12]  949 	mov	a,#0x01
      00A8C2 F0               [24]  950 	movx	@dptr,a
                                    951 ;	quantum/repeat_key.c:132: process_record(&registered_record);
      00A8C3 90 0C F3         [24]  952 	mov	dptr,#_registered_record
      00A8C6 75 F0 00         [24]  953 	mov	b, #0x00
      00A8C9 12 75 E1         [24]  954 	lcall	_process_record
                                    955 ;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
      00A8CC 90 0C F2         [24]  956 	mov	dptr,#_ak820_repeat_invoking
      00A8CF E4               [12]  957 	clr	a
      00A8D0 F0               [24]  958 	movx	@dptr,a
                                    959 ;	quantum/repeat_key.c:136: processing_repeat_count = 0;
      00A8D1 90 0F 06         [24]  960 	mov	dptr,#_processing_repeat_count
      00A8D4 F0               [24]  961 	movx	@dptr,a
                                    962 ;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
      00A8D5 90 0C F8         [24]  963 	mov	dptr,#(_registered_record + 0x0005)
      00A8D8 E0               [24]  964 	movx	a,@dptr
      00A8D9 70 0F            [24]  965 	jnz	00121$
                                    966 ;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
      00A8DB 90 0C FD         [24]  967 	mov	dptr,#_registered_mods
      00A8DE E0               [24]  968 	movx	a,@dptr
      00A8DF F5 82            [12]  969 	mov	dpl,a
      00A8E1 12 7B 76         [24]  970 	lcall	_unregister_weak_mods
                                    971 ;	quantum/repeat_key.c:144: registered_record.keycode = 0;
      00A8E4 90 0C FA         [24]  972 	mov	dptr,#(_registered_record + 0x0007)
      00A8E7 12 49 28         [24]  973 	lcall	_ak820_outline_0150
      00A8EA                        974 00121$:
                                    975 ;	quantum/repeat_key.c:146: }
      00A8EA 22               [24]  976 	ret
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    979 ;------------------------------------------------------------
                                    980 ;event         Allocated with name '_repeat_key_invoke_event_10000_197'
                                    981 ;------------------------------------------------------------
                                    982 ;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t* event) {
                                    983 ;	-----------------------------------------
                                    984 ;	 function repeat_key_invoke
                                    985 ;	-----------------------------------------
      00A8EB                        986 _repeat_key_invoke:
      00A8EB 12 43 1B         [24]  987 	lcall	_ak820_outline_0041
      00A8EE 90 0D 09         [24]  988 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A8F1 12 38 15         [24]  989 	lcall	_ak820_outline_0020
                                    990 ;	quantum/repeat_key.c:149: repeat_invoke(event, false);
      00A8F4 90 0D 09         [24]  991 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A8F7 12 54 6E         [24]  992 	lcall	_ak820_outline_0015
      00A8FA 90 0D 05         [24]  993 	mov	dptr,#_repeat_invoke_PARM_2
      00A8FD E4               [12]  994 	clr	a
      00A8FE 12 54 77         [24]  995 	lcall	_ak820_outline_0036
                                    996 ;	quantum/repeat_key.c:150: }
      00A901 02 A7 CA         [24]  997 	ljmp	_repeat_invoke
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'find_alt_keycode'
                                   1000 ;------------------------------------------------------------
                                   1001 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                   1002 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                   1003 ;table         Allocated with name '_find_alt_keycode_table_10000_199'
                                   1004 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
                                   1005 ;i             Allocated with name '_find_alt_keycode_i_20000_201'
                                   1006 ;------------------------------------------------------------
                                   1007 ;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1008 ;	-----------------------------------------
                                   1009 ;	 function find_alt_keycode
                                   1010 ;	-----------------------------------------
      00A904                       1011 _find_alt_keycode:
      00A904 12 43 1B         [24] 1012 	lcall	_ak820_outline_0041
      00A907 90 0D 0E         [24] 1013 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A90A 12 38 15         [24] 1014 	lcall	_ak820_outline_0020
                                   1015 ;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
      00A90D 90 0D 0E         [24] 1016 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A910 12 54 6E         [24] 1017 	lcall	_ak820_outline_0015
                                   1018 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A913 7C 00            [12] 1019 	mov	r4,#0x00
      00A915                       1020 00105$:
      00A915 90 0D 0C         [24] 1021 	mov	dptr,#_find_alt_keycode_PARM_2
      00A918 E0               [24] 1022 	movx	a,@dptr
      00A919 FB               [12] 1023 	mov	r3,a
      00A91A C3               [12] 1024 	clr	c
      00A91B EC               [12] 1025 	mov	a,r4
      00A91C 9B               [12] 1026 	subb	a,r3
      00A91D 50 1E            [24] 1027 	jnc	00103$
                                   1028 ;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
      00A91F EC               [12] 1029 	mov	a,r4
      00A920 12 7B CC         [24] 1030 	lcall	_ak820_outline_0016
      00A923 12 BF 67         [24] 1031 	lcall	__gptrget
      00A926 F9               [12] 1032 	mov	r1,a
      00A927 90 0D 0D         [24] 1033 	mov	dptr,#_find_alt_keycode_PARM_3
      00A92A E0               [24] 1034 	movx	a,@dptr
      00A92B B5 01 0C         [24] 1035 	cjne	a,ar1,00106$
                                   1036 ;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
      00A92E 74 01            [12] 1037 	mov	a,#0x01
      00A930 6C               [12] 1038 	xrl	a,r4
      00A931 12 7B CC         [24] 1039 	lcall	_ak820_outline_0016
      00A934 12 BF 67         [24] 1040 	lcall	__gptrget
      00A937 F5 82            [12] 1041 	mov	dpl,a
      00A939 22               [24] 1042 	ret
      00A93A                       1043 00106$:
                                   1044 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A93A 0C               [12] 1045 	inc	r4
      00A93B 80 D8            [24] 1046 	sjmp	00105$
      00A93D                       1047 00103$:
                                   1048 ;	quantum/repeat_key.c:174: return KC_NO;
      00A93D 75 82 00         [24] 1049 	mov	dpl, #0x00
                                   1050 ;	quantum/repeat_key.c:175: }
      00A940 22               [24] 1051 	ret
                                   1052 ;------------------------------------------------------------
                                   1053 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1054 ;------------------------------------------------------------
                                   1055 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
                                   1056 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
                                   1057 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
                                   1058 ;------------------------------------------------------------
                                   1059 ;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
                                   1060 ;	-----------------------------------------
                                   1061 ;	 function get_alt_repeat_key_keycode
                                   1062 ;	-----------------------------------------
      00A941                       1063 _get_alt_repeat_key_keycode:
                                   1064 ;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
      00A941 90 0C F0         [24] 1065 	mov	dptr,#(_last_record + 0x0007)
      00A944 12 38 2D         [24] 1066 	lcall	_ak820_outline_0058
      00A947 90 0D 11         [24] 1067 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A94A 12 49 1A         [24] 1068 	lcall	_ak820_outline_0064
                                   1069 ;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
      00A94D 90 0F 04         [24] 1070 	mov	dptr,#_last_mods
      00A950 E0               [24] 1071 	movx	a,@dptr
      00A951 FD               [12] 1072 	mov	r5,a
      00A952 90 0D 13         [24] 1073 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A955 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      00A956 90 0D 19         [24] 1076 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      00A959 ED               [12] 1077 	mov	a,r5
      00A95A 12 43 46         [24] 1078 	lcall	_ak820_outline_0071
      00A95D C0 07            [24] 1079 	push	ar7
      00A95F C0 06            [24] 1080 	push	ar6
      00A961 51 6F            [12] 1081 	acall	_get_alt_repeat_key_keycode_user
      00A963 12 43 6F         [24] 1082 	lcall	_ak820_outline_0156
      00A966 D0 06            [24] 1083 	pop	ar6
      00A968 D0 07            [24] 1084 	pop	ar7
                                   1085 ;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
      00A96A 8C 02            [24] 1086 	mov	ar2,r4
      00A96C 8D 03            [24] 1087 	mov	ar3,r5
      00A96E BA 01 05         [24] 1088 	cjne	r2,#0x01,00176$
      00A971 BB 00 02         [24] 1089 	cjne	r3,#0x00,00176$
      00A974 80 04            [24] 1090 	sjmp	00102$
      00A976                       1091 00176$:
                                   1092 ;	quantum/repeat_key.c:186: return alt_keycode;
      00A976 12 38 A3         [24] 1093 	lcall	_ak820_outline_0132
      00A979 22               [24] 1094 	ret
      00A97A                       1095 00102$:
                                   1096 ;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      00A97A 90 0D 13         [24] 1097 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A97D E0               [24] 1098 	movx	a,@dptr
      00A97E 54 F0            [12] 1099 	anl	a,#0xf0
      00A980 60 02            [24] 1100 	jz	00118$
      00A982 74 10            [12] 1101 	mov	a,#0x10
      00A984                       1102 00118$:
      00A984 FD               [12] 1103 	mov	r5,a
                                   1104 ;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
      00A985 90 0D 13         [24] 1105 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A988 E0               [24] 1106 	movx	a,@dptr
      00A989 FC               [12] 1107 	mov	r4,a
      00A98A C4               [12] 1108 	swap	a
      00A98B 54 0F            [12] 1109 	anl	a,#0x0f
      00A98D 4C               [12] 1110 	orl	a,r4
      00A98E 54 0F            [12] 1111 	anl	a,#0x0f
      00A990 4D               [12] 1112 	orl	a,r5
      00A991 F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      00A992 8E 04            [24] 1115 	mov	ar4,r6
      00A994 8F 05            [24] 1116 	mov	ar5,r7
      00A996 74 FF            [12] 1117 	mov	a,#0x100 - 0x01
      00A998 2D               [12] 1118 	add	a,r5
      00A999 50 1C            [24] 1119 	jnc	00115$
      00A99B C3               [12] 1120 	clr	c
      00A99C 74 FF            [12] 1121 	mov	a,#0xff
      00A99E 9C               [12] 1122 	subb	a,r4
      00A99F 74 1F            [12] 1123 	mov	a,#0x1f
      00A9A1 9D               [12] 1124 	subb	a,r5
      00A9A2 40 13            [24] 1125 	jc	00115$
                                   1126 ;	free result
                                   1127 ;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
      00A9A4 8F 06            [24] 1128 	mov	ar6,r7
      00A9A6 53 06 1F         [24] 1129 	anl	ar6,#0x1f
      00A9A9 90 0D 13         [24] 1130 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A9AC E0               [24] 1131 	movx	a,@dptr
      00A9AD 4E               [12] 1132 	orl	a,r6
      00A9AE F0               [24] 1133 	movx	@dptr,a
                                   1134 ;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      00A9AF 7D 00            [12] 1135 	mov	r5,#0x00
      00A9B1 90 0D 11         [24] 1136 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A9B4 12 38 50         [24] 1137 	lcall	_ak820_outline_0078
                                   1138 ;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
      00A9B7                       1139 00115$:
      00A9B7 90 0D 11         [24] 1140 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A9BA 12 4D E6         [24] 1141 	lcall	_ak820_outline_0010
      00A9BD C3               [12] 1142 	clr	c
      00A9BE 74 FF            [12] 1143 	mov	a,#0xff
      00A9C0 9C               [12] 1144 	subb	a,r4
      00A9C1 E4               [12] 1145 	clr	a
      00A9C2 9D               [12] 1146 	subb	a,r5
      00A9C3 50 02            [24] 1147 	jnc	00180$
      00A9C5 41 51            [12] 1148 	ajmp	00114$
      00A9C7                       1149 00180$:
                                   1150 ;	free result
                                   1151 ;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      00A9C7 90 0D 13         [24] 1152 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A9CA E0               [24] 1153 	movx	a,@dptr
      00A9CB 54 0D            [12] 1154 	anl	a,#0x0d
      00A9CD 60 20            [24] 1155 	jz	00107$
                                   1156 ;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A9CF 8E 05            [24] 1157 	mov	ar5,r6
      00A9D1 90 0D 0C         [24] 1158 	mov	dptr,#_find_alt_keycode_PARM_2
      00A9D4 74 0A            [12] 1159 	mov	a,#0x0a
      00A9D6 F0               [24] 1160 	movx	@dptr,a
      00A9D7 90 0D 0D         [24] 1161 	mov	dptr,#_find_alt_keycode_PARM_3
      00A9DA ED               [12] 1162 	mov	a,r5
      00A9DB F0               [24] 1163 	movx	@dptr,a
      00A9DC 90 C3 2C         [24] 1164 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
      00A9DF 75 F0 80         [24] 1165 	mov	b, #0x80
      00A9E2 31 04            [24] 1166 	acall	_find_alt_keycode
      00A9E4 AD 82            [24] 1167 	mov	r5, dpl
      00A9E6 90 0D 14         [24] 1168 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A9E9 ED               [12] 1169 	mov	a,r5
      00A9EA 12 38 A8         [24] 1170 	lcall	_ak820_outline_0133
      00A9ED 80 1C            [24] 1171 	sjmp	00108$
      00A9EF                       1172 00107$:
                                   1173 ;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A9EF 90 0D 0C         [24] 1174 	mov	dptr,#_find_alt_keycode_PARM_2
      00A9F2 74 08            [12] 1175 	mov	a,#0x08
      00A9F4 F0               [24] 1176 	movx	@dptr,a
      00A9F5 90 0D 0D         [24] 1177 	mov	dptr,#_find_alt_keycode_PARM_3
      00A9F8 EE               [12] 1178 	mov	a,r6
      00A9F9 F0               [24] 1179 	movx	@dptr,a
      00A9FA 90 C3 36         [24] 1180 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      00A9FD 75 F0 80         [24] 1181 	mov	b, #0x80
      00AA00 31 04            [24] 1182 	acall	_find_alt_keycode
      00AA02 AF 82            [24] 1183 	mov	r7, dpl
      00AA04 90 0D 14         [24] 1184 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AA07 EF               [12] 1185 	mov	a,r7
      00AA08 12 38 A8         [24] 1186 	lcall	_ak820_outline_0133
      00AA0B                       1187 00108$:
                                   1188 ;	quantum/repeat_key.c:246: if (!alt_keycode) {
      00AA0B 90 0D 14         [24] 1189 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AA0E 12 48 E2         [24] 1190 	lcall	_ak820_outline_0038
      00AA11 70 21            [24] 1191 	jnz	00110$
                                   1192 ;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00AA13 90 0D 11         [24] 1193 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00AA16 E0               [24] 1194 	movx	a,@dptr
      00AA17 FF               [12] 1195 	mov	r7,a
      00AA18 90 0D 0C         [24] 1196 	mov	dptr,#_find_alt_keycode_PARM_2
      00AA1B 74 16            [12] 1197 	mov	a,#0x16
      00AA1D F0               [24] 1198 	movx	@dptr,a
      00AA1E 90 0D 0D         [24] 1199 	mov	dptr,#_find_alt_keycode_PARM_3
      00AA21 EF               [12] 1200 	mov	a,r7
      00AA22 F0               [24] 1201 	movx	@dptr,a
      00AA23 90 C3 3E         [24] 1202 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
      00AA26 75 F0 80         [24] 1203 	mov	b, #0x80
      00AA29 31 04            [24] 1204 	acall	_find_alt_keycode
      00AA2B AF 82            [24] 1205 	mov	r7, dpl
      00AA2D 90 0D 14         [24] 1206 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AA30 EF               [12] 1207 	mov	a,r7
      00AA31 12 38 A8         [24] 1208 	lcall	_ak820_outline_0133
      00AA34                       1209 00110$:
                                   1210 ;	quantum/repeat_key.c:274: if (alt_keycode) {
      00AA34 90 0D 14         [24] 1211 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AA37 12 38 2D         [24] 1212 	lcall	_ak820_outline_0058
      00AA3A 90 0D 14         [24] 1213 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00AA3D 12 48 E2         [24] 1214 	lcall	_ak820_outline_0038
      00AA40 60 0F            [24] 1215 	jz	00114$
                                   1216 ;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
      00AA42 90 0D 13         [24] 1217 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00AA45 E0               [24] 1218 	movx	a,@dptr
      00AA46 FD               [12] 1219 	mov	r5,a
      00AA47 E4               [12] 1220 	clr	a
      00AA48 42 06            [12] 1221 	orl	ar6,a
      00AA4A ED               [12] 1222 	mov	a,r5
      00AA4B 42 07            [12] 1223 	orl	ar7,a
      00AA4D 12 38 92         [24] 1224 	lcall	_ak820_outline_0124
      00AA50 22               [24] 1225 	ret
      00AA51                       1226 00114$:
                                   1227 ;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
      00AA51 90 00 00         [24] 1228 	mov	dptr,#0x0000
                                   1229 ;	quantum/repeat_key.c:281: }
      00AA54 22               [24] 1230 	ret
                                   1231 ;------------------------------------------------------------
                                   1232 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1233 ;------------------------------------------------------------
                                   1234 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
                                   1235 ;------------------------------------------------------------
                                   1236 ;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t* event) {
                                   1237 ;	-----------------------------------------
                                   1238 ;	 function alt_repeat_key_invoke
                                   1239 ;	-----------------------------------------
      00AA55                       1240 _alt_repeat_key_invoke:
      00AA55 12 43 1B         [24] 1241 	lcall	_ak820_outline_0041
      00AA58 90 0D 16         [24] 1242 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00AA5B 12 38 15         [24] 1243 	lcall	_ak820_outline_0020
                                   1244 ;	quantum/repeat_key.c:285: repeat_invoke(event, true);
      00AA5E 90 0D 16         [24] 1245 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00AA61 12 54 6E         [24] 1246 	lcall	_ak820_outline_0015
      00AA64 90 0D 05         [24] 1247 	mov	dptr,#_repeat_invoke_PARM_2
      00AA67 74 01            [12] 1248 	mov	a,#0x01
      00AA69 12 54 77         [24] 1249 	lcall	_ak820_outline_0036
                                   1250 ;	quantum/repeat_key.c:286: }
      00AA6C 02 A7 CA         [24] 1251 	ljmp	_repeat_invoke
                                   1252 ;------------------------------------------------------------
                                   1253 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1254 ;------------------------------------------------------------
                                   1255 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1256 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
                                   1257 ;------------------------------------------------------------
                                   1258 ;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1259 ;	-----------------------------------------
                                   1260 ;	 function get_alt_repeat_key_keycode_user
                                   1261 ;	-----------------------------------------
      00AA6F                       1262 _get_alt_repeat_key_keycode_user:
                                   1263 ;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
      00AA6F 90 00 01         [24] 1264 	mov	dptr,#0x0001
                                   1265 ;	quantum/repeat_key.c:291: }
      00AA72 22               [24] 1266 	ret
                                   1267 	.area CSEG    (CODE)
                                   1268 	.area CONST   (CODE)
                                   1269 	.area CONST   (CODE)
      00C32C                       1270 _get_alt_repeat_key_keycode_pairs_50000_214:
      00C32C 09                    1271 	.db #0x09	; 9
      00C32D 05                    1272 	.db #0x05	; 5
      00C32E 07                    1273 	.db #0x07	; 7
      00C32F 18                    1274 	.db #0x18	; 24
      00C330 11                    1275 	.db #0x11	; 17
      00C331 13                    1276 	.db #0x13	; 19
      00C332 04                    1277 	.db #0x04	; 4
      00C333 08                    1278 	.db #0x08	; 8
      00C334 12                    1279 	.db #0x12	; 18
      00C335 0C                    1280 	.db #0x0c	; 12
                                   1281 	.area CSEG    (CODE)
                                   1282 	.area CONST   (CODE)
      00C336                       1283 _get_alt_repeat_key_keycode_pairs_50000_215:
      00C336 0D                    1284 	.db #0x0d	; 13
      00C337 0E                    1285 	.db #0x0e	; 14
      00C338 0B                    1286 	.db #0x0b	; 11
      00C339 0F                    1287 	.db #0x0f	; 15
      00C33A 1A                    1288 	.db #0x1a	; 26
      00C33B 05                    1289 	.db #0x05	; 5
      00C33C 08                    1290 	.db #0x08	; 8
      00C33D 05                    1291 	.db #0x05	; 5
                                   1292 	.area CSEG    (CODE)
                                   1293 	.area CONST   (CODE)
      00C33E                       1294 _get_alt_repeat_key_keycode_pairs_50000_217:
      00C33E 50                    1295 	.db #0x50	; 80	'P'
      00C33F 4F                    1296 	.db #0x4f	; 79	'O'
      00C340 52                    1297 	.db #0x52	; 82	'R'
      00C341 51                    1298 	.db #0x51	; 81	'Q'
      00C342 4A                    1299 	.db #0x4a	; 74	'J'
      00C343 4D                    1300 	.db #0x4d	; 77	'M'
      00C344 4B                    1301 	.db #0x4b	; 75	'K'
      00C345 4E                    1302 	.db #0x4e	; 78	'N'
      00C346 2A                    1303 	.db #0x2a	; 42
      00C347 4C                    1304 	.db #0x4c	; 76	'L'
      00C348 2F                    1305 	.db #0x2f	; 47
      00C349 30                    1306 	.db #0x30	; 48	'0'
      00C34A B6                    1307 	.db #0xb6	; 182
      00C34B B7                    1308 	.db #0xb7	; 183
      00C34C AB                    1309 	.db #0xab	; 171
      00C34D AC                    1310 	.db #0xac	; 172
      00C34E BB                    1311 	.db #0xbb	; 187
      00C34F BC                    1312 	.db #0xbc	; 188
      00C350 A9                    1313 	.db #0xa9	; 169
      00C351 AA                    1314 	.db #0xaa	; 170
      00C352 BD                    1315 	.db #0xbd	; 189
      00C353 BE                    1316 	.db #0xbe	; 190
                                   1317 	.area CSEG    (CODE)
                                   1318 	.area XINIT   (CODE)
      00C7B6                       1319 __xinit__last_mods:
      00C7B6 00                    1320 	.db #0x00	; 0
      00C7B7                       1321 __xinit__last_repeat_count:
      00C7B7 00                    1322 	.db #0x00	;  0
      00C7B8                       1323 __xinit__processing_repeat_count:
      00C7B8 00                    1324 	.db #0x00	;  0
                                   1325 	.area CABS    (ABS,CODE)
                                   1326 
                                   1327 ; Experimental exact instruction outlining.
                                   1328 	.globl _ak820_outline_0010
                                   1329 	.globl _ak820_outline_0015
                                   1330 	.globl _ak820_outline_0016
                                   1331 	.globl _ak820_outline_0017
                                   1332 	.globl _ak820_outline_0020
                                   1333 	.globl _ak820_outline_0036
                                   1334 	.globl _ak820_outline_0038
                                   1335 	.globl _ak820_outline_0041
                                   1336 	.globl _ak820_outline_0058
                                   1337 	.globl _ak820_outline_0063
                                   1338 	.globl _ak820_outline_0064
                                   1339 	.globl _ak820_outline_0071
                                   1340 	.globl _ak820_outline_0077
                                   1341 	.globl _ak820_outline_0078
                                   1342 	.globl _ak820_outline_0111
                                   1343 	.globl _ak820_outline_0112
                                   1344 	.globl _ak820_outline_0124
                                   1345 	.globl _ak820_outline_0132
                                   1346 	.globl _ak820_outline_0133
                                   1347 	.globl _ak820_outline_0150
                                   1348 	.globl _ak820_outline_0156
                                   1349 	.globl _ak820_outline_0167
                                   1350 	.globl _ak820_outline_0176
