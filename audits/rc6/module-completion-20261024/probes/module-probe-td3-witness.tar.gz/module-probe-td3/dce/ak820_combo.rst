                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _input_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _output_sloc0_1_0:
      000001                        542 	.ds 1
      000002                        543 _ak820_combo_valid_sloc0_1_0:
      000002                        544 	.ds 1
      000003                        545 _ak820_combo_process_sloc0_1_0:
      000003                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000422                        555 _input_code_10000_594:
      000422                        556 	.ds 2
      000424                        557 _output_code_10000_596:
      000424                        558 	.ds 2
      000426                        559 _combos:
      000426                        560 	.ds 32
      000446                        561 _saved:
      000446                        562 	.ds 9
      00044F                        563 _active:
      00044F                        564 	.ds 1
      000450                        565 _ak820_combo_valid_entry_10000_598:
      000450                        566 	.ds 2
      000452                        567 _ak820_combo_reload_entry_30000_610:
      000452                        568 	.ds 10
      00045C                        569 _ak820_combo_tick_now_10000_615:
      00045C                        570 	.ds 2
      00045E                        571 _ak820_combo_process_record_10000_618:
      00045E                        572 	.ds 2
      000460                        573 _ak820_combo_process_eligible_10001_633:
      000460                        574 	.ds 1
      000461                        575 _ak820_combo_process_i_40001_636:
      000461                        576 	.ds 1
      000462                        577 _ak820_combo_process_a_50001_637:
      000462                        578 	.ds 1
      000463                        579 _ak820_combo_process_b_50001_637:
      000463                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000E9A                        589 _first:
      000E9A                        590 	.ds 1
      000E9B                        591 _second:
      000E9B                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      003468                        636 _input:
      003468 12 38 81         [24]  637 	lcall	_ak820_outline_0111
      00346B 90 04 22         [24]  638 	mov	dptr,#_input_code_10000_594
      00346E 12 38 86         [24]  639 	lcall	_ak820_outline_0112
      003471 90 04 22         [24]  640 	mov	dptr,#_input_code_10000_594
      003474 12 38 2D         [24]  641 	lcall	_ak820_outline_0058
      003477 C3               [12]  642 	clr	c
      003478 EE               [12]  643 	mov	a,r6
      003479 94 04            [12]  644 	subb	a,#0x04
      00347B EF               [12]  645 	mov	a,r7
      00347C 94 00            [12]  646 	subb	a,#0x00
      00347E 40 07            [24]  647 	jc	00103$
      003480 74 A4            [12]  648 	mov	a,#0xa4
      003482 9E               [12]  649 	subb	a,r6
      003483 E4               [12]  650 	clr	a
      003484 9F               [12]  651 	subb	a,r7
      003485 50 04            [24]  652 	jnc	00104$
                                    653 ;	free result
      003487                        654 00103$:
                                    655 ;	assignBit
      003487 C2 00            [12]  656 	clr	_input_sloc0_1_0
      003489 80 02            [24]  657 	sjmp	00105$
      00348B                        658 00104$:
                                    659 ;	assignBit
      00348B D2 00            [12]  660 	setb	_input_sloc0_1_0
      00348D                        661 00105$:
      00348D A2 00            [12]  662 	mov	c,_input_sloc0_1_0
      00348F 12 38 B7         [24]  663 	lcall	_ak820_outline_0151
      003492 22               [24]  664 	ret
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'output'
                                    667 ;------------------------------------------------------------
                                    668 ;code          Allocated with name '_output_code_10000_596'
                                    669 ;basic         Allocated with name '_output_basic_10000_597'
                                    670 ;------------------------------------------------------------
                                    671 ;	keyboards/ajazz/ak820/ak820_combo.c:16: static bool output(uint16_t code) {
                                    672 ;	-----------------------------------------
                                    673 ;	 function output
                                    674 ;	-----------------------------------------
      003493                        675 _output:
      003493 12 38 81         [24]  676 	lcall	_ak820_outline_0111
      003496 90 04 24         [24]  677 	mov	dptr,#_output_code_10000_596
      003499 12 38 86         [24]  678 	lcall	_ak820_outline_0112
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:17: uint8_t basic = code;
      00349C 90 04 24         [24]  680 	mov	dptr,#_output_code_10000_596
      00349F 12 38 2D         [24]  681 	lcall	_ak820_outline_0058
      0034A2 8E 05            [24]  682 	mov	ar5,r6
                                    683 ;	keyboards/ajazz/ak820/ak820_combo.c:18: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      0034A4 74 E0            [12]  684 	mov	a,#0x100 - 0x20
      0034A6 2F               [12]  685 	add	a,r7
      0034A7 40 1B            [24]  686 	jc	00103$
      0034A9 8D 06            [24]  687 	mov	ar6,r5
      0034AB 7F 00            [12]  688 	mov	r7,#0x00
      0034AD 12 38 92         [24]  689 	lcall	_ak820_outline_0124
      0034B0 C0 05            [24]  690 	push	ar5
      0034B2 91 68            [12]  691 	acall	_input
      0034B4 E5 82            [12]  692 	mov	a, dpl
      0034B6 D0 05            [24]  693 	pop	ar5
      0034B8 70 0E            [24]  694 	jnz	00104$
      0034BA BD E0 00         [24]  695 	cjne	r5,#0xe0,00135$
      0034BD                        696 00135$:
      0034BD 40 05            [24]  697 	jc	00103$
      0034BF ED               [12]  698 	mov	a,r5
      0034C0 24 18            [12]  699 	add	a,#0xff - 0xe7
      0034C2 50 04            [24]  700 	jnc	00104$
                                    701 ;	free result
      0034C4                        702 00103$:
                                    703 ;	assignBit
      0034C4 C2 01            [12]  704 	clr	_output_sloc0_1_0
      0034C6 80 02            [24]  705 	sjmp	00105$
      0034C8                        706 00104$:
                                    707 ;	assignBit
      0034C8 D2 01            [12]  708 	setb	_output_sloc0_1_0
      0034CA                        709 00105$:
      0034CA A2 01            [12]  710 	mov	c,_output_sloc0_1_0
      0034CC 12 38 B7         [24]  711 	lcall	_ak820_outline_0151
                                    712 ;	keyboards/ajazz/ak820/ak820_combo.c:19: }
      0034CF 22               [24]  713 	ret
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    716 ;------------------------------------------------------------
                                    717 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_598'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_combo.c:25: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_combo_valid
                                    722 ;	-----------------------------------------
      0034D0                        723 _ak820_combo_valid:
      0034D0 12 38 81         [24]  724 	lcall	_ak820_outline_0111
      0034D3 90 04 50         [24]  725 	mov	dptr,#_ak820_combo_valid_entry_10000_598
      0034D6 12 38 86         [24]  726 	lcall	_ak820_outline_0112
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[2] || entry->input[3]) return false;
      0034D9 90 04 50         [24]  728 	mov	dptr,#_ak820_combo_valid_entry_10000_598
      0034DC 12 37 ED         [24]  729 	lcall	_ak820_outline_0006
      0034DF A3               [24]  730 	inc	dptr
      0034E0 A3               [24]  731 	inc	dptr
      0034E1 A3               [24]  732 	inc	dptr
      0034E2 A3               [24]  733 	inc	dptr
      0034E3 E0               [24]  734 	movx	a,@dptr
      0034E4 FC               [12]  735 	mov	r4,a
      0034E5 A3               [24]  736 	inc	dptr
      0034E6 E0               [24]  737 	movx	a,@dptr
      0034E7 4C               [12]  738 	orl	a,r4
      0034E8 70 0C            [24]  739 	jnz	00101$
      0034EA 74 06            [12]  740 	mov	a,#0x06
      0034EC 12 38 1D         [24]  741 	lcall	_ak820_outline_0026
      0034EF E0               [24]  742 	movx	a,@dptr
      0034F0 FC               [12]  743 	mov	r4,a
      0034F1 A3               [24]  744 	inc	dptr
      0034F2 E0               [24]  745 	movx	a,@dptr
      0034F3 4C               [12]  746 	orl	a,r4
      0034F4 60 04            [24]  747 	jz	00102$
      0034F6                        748 00101$:
      0034F6 75 82 00         [24]  749 	mov	dpl, #0x00
      0034F9 22               [24]  750 	ret
      0034FA                        751 00102$:
                                    752 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      0034FA 8E 04            [24]  753 	mov	ar4,r6
      0034FC 8F 05            [24]  754 	mov	ar5,r7
      0034FE 12 38 25         [24]  755 	lcall	_ak820_outline_0035
      003501 FA               [12]  756 	mov	r2,a
      003502 A3               [24]  757 	inc	dptr
      003503 E0               [24]  758 	movx	a,@dptr
      003504 FB               [12]  759 	mov	r3,a
      003505 12 38 A3         [24]  760 	lcall	_ak820_outline_0132
      003508 12 38 44         [24]  761 	lcall	_ak820_outline_0065
      00350B EA               [12]  762 	mov	a,r2
      00350C 4C               [12]  763 	orl	a,r4
      00350D F8               [12]  764 	mov	r0,a
      00350E EB               [12]  765 	mov	a,r3
      00350F 4D               [12]  766 	orl	a,r5
      003510 48               [12]  767 	orl	a,r0
      003511 70 13            [24]  768 	jnz	00105$
      003513 74 08            [12]  769 	mov	a,#0x08
      003515 12 38 1D         [24]  770 	lcall	_ak820_outline_0026
      003518 E0               [24]  771 	movx	a,@dptr
      003519 F8               [12]  772 	mov	r0,a
      00351A A3               [24]  773 	inc	dptr
      00351B E0               [24]  774 	movx	a,@dptr
      00351C 48               [12]  775 	orl	a,r0
      00351D B4 01 00         [24]  776 	cjne	a,#0x01,00152$
      003520                        777 00152$:
      003520 92 02            [24]  778 	mov  _ak820_combo_valid_sloc0_1_0,c
      003522 12 38 B7         [24]  779 	lcall	_ak820_outline_0151
      003525 22               [24]  780 	ret
      003526                        781 00105$:
                                    782 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (entry->input[0] == entry->input[1]) return false;
      003526 EC               [12]  783 	mov	a,r4
      003527 B5 02 08         [24]  784 	cjne	a,ar2,00107$
      00352A ED               [12]  785 	mov	a,r5
      00352B B5 03 04         [24]  786 	cjne	a,ar3,00107$
      00352E 75 82 00         [24]  787 	mov	dpl, #0x00
      003531 22               [24]  788 	ret
      003532                        789 00107$:
                                    790 ;	keyboards/ajazz/ak820/ak820_combo.c:29: if (!input(entry->input[0])) return false;
      003532 12 38 A3         [24]  791 	lcall	_ak820_outline_0132
      003535 C0 07            [24]  792 	push	ar7
      003537 C0 06            [24]  793 	push	ar6
      003539 C0 03            [24]  794 	push	ar3
      00353B C0 02            [24]  795 	push	ar2
      00353D 91 68            [12]  796 	acall	_input
      00353F E5 82            [12]  797 	mov	a, dpl
      003541 D0 02            [24]  798 	pop	ar2
      003543 D0 03            [24]  799 	pop	ar3
      003545 D0 06            [24]  800 	pop	ar6
      003547 D0 07            [24]  801 	pop	ar7
      003549 70 03            [24]  802 	jnz	00109$
      00354B F5 82            [12]  803 	mov	dpl,a
      00354D 22               [24]  804 	ret
      00354E                        805 00109$:
                                    806 ;	keyboards/ajazz/ak820/ak820_combo.c:30: if (!input(entry->input[1])) return false;
      00354E 12 38 AD         [24]  807 	lcall	_ak820_outline_0134
      003551 C0 07            [24]  808 	push	ar7
      003553 C0 06            [24]  809 	push	ar6
      003555 91 68            [12]  810 	acall	_input
      003557 E5 82            [12]  811 	mov	a, dpl
      003559 D0 06            [24]  812 	pop	ar6
      00355B D0 07            [24]  813 	pop	ar7
      00355D 70 03            [24]  814 	jnz	00111$
      00355F F5 82            [12]  815 	mov	dpl,a
      003561 22               [24]  816 	ret
      003562                        817 00111$:
                                    818 ;	keyboards/ajazz/ak820/ak820_combo.c:31: return output(entry->output);
      003562 74 08            [12]  819 	mov	a,#0x08
      003564 12 38 1D         [24]  820 	lcall	_ak820_outline_0026
      003567 12 37 ED         [24]  821 	lcall	_ak820_outline_0006
                                    822 ;	keyboards/ajazz/ak820/ak820_combo.c:32: }
      00356A 81 93            [12]  823 	ajmp	_output
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    826 ;------------------------------------------------------------
                                    827 ;	keyboards/ajazz/ak820/ak820_combo.c:35: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    828 ;	-----------------------------------------
                                    829 ;	 function ak820_combo_cancel
                                    830 ;	-----------------------------------------
      00356C                        831 _ak820_combo_cancel:
      00356C 90 0E 9B         [24]  832 	mov	dptr,#_second
      00356F 74 FF            [12]  833 	mov	a,#0xff
      003571 F0               [24]  834 	movx	@dptr,a
      003572 90 0E 9A         [24]  835 	mov	dptr,#_first
      003575 F0               [24]  836 	movx	@dptr,a
      003576 90 04 4F         [24]  837 	mov	dptr,#_active
      003579 E4               [12]  838 	clr	a
      00357A F0               [24]  839 	movx	@dptr,a
      00357B 22               [24]  840 	ret
                                    841 ;------------------------------------------------------------
                                    842 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    843 ;------------------------------------------------------------
                                    844 ;i             Allocated with name '_ak820_combo_reload_i_20000_609'
                                    845 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_610'
                                    846 ;------------------------------------------------------------
                                    847 ;	keyboards/ajazz/ak820/ak820_combo.c:36: void ak820_combo_reload(void) {
                                    848 ;	-----------------------------------------
                                    849 ;	 function ak820_combo_reload
                                    850 ;	-----------------------------------------
      00357C                        851 _ak820_combo_reload:
                                    852 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00357C 7F 00            [12]  853 	mov	r7,#0x00
      00357E                        854 00105$:
      00357E BF 08 00         [24]  855 	cjne	r7,#0x08,00131$
      003581                        856 00131$:
      003581 40 01            [24]  857 	jc	00132$
      003583 22               [24]  858 	ret
      003584                        859 00132$:
                                    860 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = 0;
      003584 EF               [12]  861 	mov	a,r7
      003585 12 38 CC         [24]  862 	lcall	_ak820_outline_0195
      003588 24 26            [12]  863 	add	a, #_combos
      00358A FD               [12]  864 	mov	r5,a
      00358B 74 04            [12]  865 	mov	a,#(_combos >> 8)
      00358D 35 F0            [12]  866 	addc	a, b
      00358F FE               [12]  867 	mov	r6,a
      003590 8D 03            [24]  868 	mov	ar3,r5
      003592 8E 04            [24]  869 	mov	ar4,r6
      003594 12 38 62         [24]  870 	lcall	_ak820_outline_0098
                                    871 ;	keyboards/ajazz/ak820/ak820_combo.c:40: if (!dynamic_keymap_get_combo(i, &entry)) {
      003597 90 0B BB         [24]  872 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00359A 74 52            [12]  873 	mov	a,#_ak820_combo_reload_entry_30000_610
      00359C F0               [24]  874 	movx	@dptr,a
      00359D 74 04            [12]  875 	mov	a,#(_ak820_combo_reload_entry_30000_610 >> 8)
      00359F 12 38 4A         [24]  876 	lcall	_ak820_outline_0077
      0035A2 8F 82            [24]  877 	mov	dpl, r7
      0035A4 C0 07            [24]  878 	push	ar7
      0035A6 C0 06            [24]  879 	push	ar6
      0035A8 C0 05            [24]  880 	push	ar5
      0035AA C0 04            [24]  881 	push	ar4
      0035AC C0 03            [24]  882 	push	ar3
      0035AE 12 8B 55         [24]  883 	lcall	_dynamic_keymap_get_combo
      0035B1 12 38 97         [24]  884 	lcall	_ak820_outline_0128
      0035B4 D0 03            [24]  885 	pop	ar3
      0035B6 D0 04            [24]  886 	pop	ar4
      0035B8 D0 05            [24]  887 	pop	ar5
      0035BA D0 06            [24]  888 	pop	ar6
      0035BC D0 07            [24]  889 	pop	ar7
      0035BE 45 F0            [12]  890 	orl	a,b
      0035C0 70 28            [24]  891 	jnz	00106$
                                    892 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].a = entry.input[0];
      0035C2 90 04 52         [24]  893 	mov	dptr,#_ak820_combo_reload_entry_30000_610
      0035C5 E0               [24]  894 	movx	a,@dptr
      0035C6 12 33 FC         [24]  895 	lcall	_ak820_outline_0131
      0035C9 F0               [24]  896 	movx	@dptr,a
                                    897 ;	keyboards/ajazz/ak820/ak820_combo.c:42: combos[i].b = entry.input[1];
      0035CA 74 01            [12]  898 	mov	a,#0x01
      0035CC 2D               [12]  899 	add	a, r5
      0035CD FB               [12]  900 	mov	r3,a
      0035CE E4               [12]  901 	clr	a
      0035CF 3E               [12]  902 	addc	a, r6
      0035D0 FC               [12]  903 	mov	r4,a
      0035D1 90 04 54         [24]  904 	mov	dptr,#(_ak820_combo_reload_entry_30000_610 + 0x0002)
      0035D4 E0               [24]  905 	movx	a,@dptr
      0035D5 12 33 FC         [24]  906 	lcall	_ak820_outline_0131
      0035D8 F0               [24]  907 	movx	@dptr,a
                                    908 ;	keyboards/ajazz/ak820/ak820_combo.c:43: combos[i].output = entry.output;
      0035D9 74 02            [12]  909 	mov	a,#0x02
      0035DB 12 38 BC         [24]  910 	lcall	_ak820_outline_0165
      0035DE 90 04 5A         [24]  911 	mov	dptr,#(_ak820_combo_reload_entry_30000_610 + 0x0008)
      0035E1 12 38 7B         [24]  912 	lcall	_ak820_outline_0107
      0035E4 12 38 B2         [24]  913 	lcall	_ak820_outline_0143
      0035E7 12 38 56         [24]  914 	lcall	_ak820_outline_0084
      0035EA                        915 00106$:
                                    916 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035EA 0F               [12]  917 	inc	r7
                                    918 ;	keyboards/ajazz/ak820/ak820_combo.c:46: }
      0035EB A1 7E            [24]  919 	ajmp	00105$
                                    920 ;------------------------------------------------------------
                                    921 ;Allocation info for local variables in function 'flush'
                                    922 ;------------------------------------------------------------
                                    923 ;	keyboards/ajazz/ak820/ak820_combo.c:47: static void flush(void) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function flush
                                    926 ;	-----------------------------------------
      0035ED                        927 _flush:
                                    928 ;	keyboards/ajazz/ak820/ak820_combo.c:48: first = NONE;
      0035ED 90 0E 9A         [24]  929 	mov	dptr,#_first
      0035F0 74 FF            [12]  930 	mov	a,#0xff
      0035F2 F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_combo.c:49: process_record(&saved);
      0035F3 90 04 46         [24]  933 	mov	dptr,#_saved
      0035F6 75 F0 00         [24]  934 	mov	b, #0x00
                                    935 ;	keyboards/ajazz/ak820/ak820_combo.c:50: }
      0035F9 02 75 E1         [24]  936 	ljmp	_process_record
                                    937 ;------------------------------------------------------------
                                    938 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    939 ;------------------------------------------------------------
                                    940 ;now           Allocated with name '_ak820_combo_tick_now_10000_615'
                                    941 ;------------------------------------------------------------
                                    942 ;	keyboards/ajazz/ak820/ak820_combo.c:51: void ak820_combo_tick(uint16_t now) {
                                    943 ;	-----------------------------------------
                                    944 ;	 function ak820_combo_tick
                                    945 ;	-----------------------------------------
      0035FC                        946 _ak820_combo_tick:
      0035FC 12 38 81         [24]  947 	lcall	_ak820_outline_0111
      0035FF 90 04 5C         [24]  948 	mov	dptr,#_ak820_combo_tick_now_10000_615
      003602 12 38 86         [24]  949 	lcall	_ak820_outline_0112
                                    950 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      003605 12 38 C7         [24]  951 	lcall	_ak820_outline_0191
      003608 FF               [12]  952 	mov	r7,a
      003609 BF FF 01         [24]  953 	cjne	r7,#0xff,00128$
      00360C 22               [24]  954 	ret
      00360D                        955 00128$:
      00360D 90 04 4F         [24]  956 	mov	dptr,#_active
      003610 E0               [24]  957 	movx	a,@dptr
      003611 70 1E            [24]  958 	jnz	00105$
      003613 90 04 48         [24]  959 	mov	dptr,#(_saved + 0x0002)
      003616 12 38 2D         [24]  960 	lcall	_ak820_outline_0058
      003619 90 04 5C         [24]  961 	mov	dptr,#_ak820_combo_tick_now_10000_615
      00361C 12 38 44         [24]  962 	lcall	_ak820_outline_0065
      00361F EC               [12]  963 	mov	a,r4
      003620 C3               [12]  964 	clr	c
      003621 9E               [12]  965 	subb	a,r6
      003622 FE               [12]  966 	mov	r6,a
      003623 ED               [12]  967 	mov	a,r5
      003624 9F               [12]  968 	subb	a,r7
      003625 FF               [12]  969 	mov	r7,a
      003626 C3               [12]  970 	clr	c
      003627 EE               [12]  971 	mov	a,r6
      003628 94 28            [12]  972 	subb	a,#0x28
      00362A EF               [12]  973 	mov	a,r7
      00362B 94 00            [12]  974 	subb	a,#0x00
      00362D 40 02            [24]  975 	jc	00105$
                                    976 ;	keyboards/ajazz/ak820/ak820_combo.c:53: }
      00362F A1 ED            [24]  977 	ajmp	_flush
      003631                        978 00105$:
      003631 22               [24]  979 	ret
                                    980 ;------------------------------------------------------------
                                    981 ;Allocation info for local variables in function 'ak820_combo_process'
                                    982 ;------------------------------------------------------------
                                    983 ;record        Allocated with name '_ak820_combo_process_record_10000_618'
                                    984 ;id            Allocated with name '_ak820_combo_process_id_10000_619'
                                    985 ;code          Allocated with name '_ak820_combo_process_code_10000_619'
                                    986 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_633'
                                    987 ;previous      Allocated with name '_ak820_combo_process_previous_30001_635'
                                    988 ;i             Allocated with name '_ak820_combo_process_i_40001_636'
                                    989 ;a             Allocated with name '_ak820_combo_process_a_50001_637'
                                    990 ;b             Allocated with name '_ak820_combo_process_b_50001_637'
                                    991 ;------------------------------------------------------------
                                    992 ;	keyboards/ajazz/ak820/ak820_combo.c:54: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    993 ;	-----------------------------------------
                                    994 ;	 function ak820_combo_process
                                    995 ;	-----------------------------------------
      003632                        996 _ak820_combo_process:
      003632 12 38 81         [24]  997 	lcall	_ak820_outline_0111
      003635 90 04 5E         [24]  998 	mov	dptr,#_ak820_combo_process_record_10000_618
      003638 12 38 86         [24]  999 	lcall	_ak820_outline_0112
                                   1000 ;	keyboards/ajazz/ak820/ak820_combo.c:55: uint8_t id, code = record->keycode;
      00363B 90 04 5E         [24] 1001 	mov	dptr,#_ak820_combo_process_record_10000_618
      00363E 12 37 F7         [24] 1002 	lcall	_ak820_outline_0008
      003641 8C 03            [24] 1003 	mov	ar3,r4
                                   1004 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (IS_NOEVENT(record->event)) return true;
      003643 74 04            [12] 1005 	mov	a,#0x04
      003645 2E               [12] 1006 	add	a, r6
      003646 12 38 0B         [24] 1007 	lcall	_ak820_outline_0019
      003649 70 04            [24] 1008 	jnz	00102$
      00364B 75 82 01         [24] 1009 	mov	dpl, #0x01
      00364E 22               [24] 1010 	ret
      00364F                       1011 00102$:
                                   1012 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00364F 12 38 8B         [24] 1013 	lcall	_ak820_outline_0117
      003652 FA               [12] 1014 	mov	r2,a
      003653 BA 10 00         [24] 1015 	cjne	r2,#0x10,00300$
      003656                       1016 00300$:
      003656 50 09            [24] 1017 	jnc	00106$
      003658 12 38 69         [24] 1018 	lcall	_ak820_outline_0103
      00365B F9               [12] 1019 	mov	r1,a
      00365C B9 08 00         [24] 1020 	cjne	r1,#0x08,00302$
      00365F                       1021 00302$:
      00365F 40 15            [24] 1022 	jc	00107$
      003661                       1023 00106$:
                                   1024 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (first != NONE && !active) flush();
      003661 12 38 C7         [24] 1025 	lcall	_ak820_outline_0191
      003664 F8               [12] 1026 	mov	r0,a
      003665 B8 FF 02         [24] 1027 	cjne	r0,#0xff,00304$
      003668 80 08            [24] 1028 	sjmp	00104$
      00366A                       1029 00304$:
      00366A 90 04 4F         [24] 1030 	mov	dptr,#_active
      00366D E0               [24] 1031 	movx	a,@dptr
      00366E 70 02            [24] 1032 	jnz	00104$
      003670 B1 ED            [24] 1033 	acall	_flush
      003672                       1034 00104$:
                                   1035 ;	keyboards/ajazz/ak820/ak820_combo.c:60: return true;
      003672 75 82 01         [24] 1036 	mov	dpl, #0x01
      003675 22               [24] 1037 	ret
      003676                       1038 00107$:
                                   1039 ;	keyboards/ajazz/ak820/ak820_combo.c:62: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003676 EA               [12] 1040 	mov	a,r2
      003677 12 38 C2         [24] 1041 	lcall	_ak820_outline_0179
      00367A 29               [12] 1042 	add	a,r1
      00367B FA               [12] 1043 	mov	r2,a
                                   1044 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (active) {
      00367C 90 04 4F         [24] 1045 	mov	dptr,#_active
      00367F E0               [24] 1046 	movx	a,@dptr
      003680 60 70            [24] 1047 	jz	00123$
                                   1048 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id != first && id != second) return true;
      003682 12 38 C7         [24] 1049 	lcall	_ak820_outline_0191
      003685 F9               [12] 1050 	mov	r1,a
      003686 EA               [12] 1051 	mov	a,r2
      003687 B5 01 02         [24] 1052 	cjne	a,ar1,00307$
      00368A 80 0F            [24] 1053 	sjmp	00110$
      00368C                       1054 00307$:
      00368C 90 0E 9B         [24] 1055 	mov	dptr,#_second
      00368F E0               [24] 1056 	movx	a,@dptr
      003690 F9               [12] 1057 	mov	r1,a
      003691 EA               [12] 1058 	mov	a,r2
      003692 B5 01 02         [24] 1059 	cjne	a,ar1,00308$
      003695 80 04            [24] 1060 	sjmp	00110$
      003697                       1061 00308$:
      003697 75 82 01         [24] 1062 	mov	dpl, #0x01
      00369A 22               [24] 1063 	ret
      00369B                       1064 00110$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_combo.c:65: if (!record->event.pressed) {
      00369B 90 04 5E         [24] 1066 	mov	dptr,#_ak820_combo_process_record_10000_618
      00369E 12 38 6F         [24] 1067 	lcall	_ak820_outline_0104
      0036A1 74 05            [12] 1068 	mov	a,#0x05
      0036A3 28               [12] 1069 	add	a, r0
      0036A4 F8               [12] 1070 	mov	r0,a
      0036A5 E4               [12] 1071 	clr	a
      0036A6 39               [12] 1072 	addc	a, r1
      0036A7 F9               [12] 1073 	mov	r1,a
      0036A8 12 38 9D         [24] 1074 	lcall	_ak820_outline_0129
      0036AB 70 41            [24] 1075 	jnz	00121$
                                   1076 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (saved.event.pressed) {
      0036AD 90 04 4B         [24] 1077 	mov	dptr,#(_saved + 0x0005)
      0036B0 E0               [24] 1078 	movx	a,@dptr
      0036B1 60 11            [24] 1079 	jz	00113$
                                   1080 ;	keyboards/ajazz/ak820/ak820_combo.c:67: saved.event.pressed = false;
      0036B3 90 04 4B         [24] 1081 	mov	dptr,#(_saved + 0x0005)
      0036B6 E4               [12] 1082 	clr	a
      0036B7 F0               [24] 1083 	movx	@dptr,a
                                   1084 ;	keyboards/ajazz/ak820/ak820_combo.c:68: process_record(&saved);
      0036B8 90 04 46         [24] 1085 	mov	dptr,#_saved
      0036BB F5 F0            [12] 1086 	mov	b,a
      0036BD C0 02            [24] 1087 	push	ar2
      0036BF 12 75 E1         [24] 1088 	lcall	_process_record
      0036C2 D0 02            [24] 1089 	pop	ar2
      0036C4                       1090 00113$:
                                   1091 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (id == first) first = NONE;
      0036C4 12 38 C7         [24] 1092 	lcall	_ak820_outline_0191
      0036C7 F9               [12] 1093 	mov	r1,a
      0036C8 EA               [12] 1094 	mov	a,r2
      0036C9 B5 01 08         [24] 1095 	cjne	a,ar1,00115$
      0036CC 90 0E 9A         [24] 1096 	mov	dptr,#_first
      0036CF 74 FF            [12] 1097 	mov	a,#0xff
      0036D1 F0               [24] 1098 	movx	@dptr,a
      0036D2 80 06            [24] 1099 	sjmp	00116$
      0036D4                       1100 00115$:
                                   1101 ;	keyboards/ajazz/ak820/ak820_combo.c:71: else second = NONE;
      0036D4 90 0E 9B         [24] 1102 	mov	dptr,#_second
      0036D7 74 FF            [12] 1103 	mov	a,#0xff
      0036D9 F0               [24] 1104 	movx	@dptr,a
      0036DA                       1105 00116$:
                                   1106 ;	keyboards/ajazz/ak820/ak820_combo.c:72: if (first == NONE && second == NONE) active = false;
      0036DA 12 38 C7         [24] 1107 	lcall	_ak820_outline_0191
      0036DD F9               [12] 1108 	mov	r1,a
      0036DE B9 FF 0D         [24] 1109 	cjne	r1,#0xff,00121$
      0036E1 90 0E 9B         [24] 1110 	mov	dptr,#_second
      0036E4 E0               [24] 1111 	movx	a,@dptr
      0036E5 F9               [12] 1112 	mov	r1,a
      0036E6 B9 FF 05         [24] 1113 	cjne	r1,#0xff,00121$
      0036E9 90 04 4F         [24] 1114 	mov	dptr,#_active
      0036EC E4               [12] 1115 	clr	a
      0036ED F0               [24] 1116 	movx	@dptr,a
      0036EE                       1117 00121$:
                                   1118 ;	keyboards/ajazz/ak820/ak820_combo.c:74: return false;
      0036EE 75 82 00         [24] 1119 	mov	dpl, #0x00
      0036F1 22               [24] 1120 	ret
      0036F2                       1121 00123$:
                                   1122 ;	keyboards/ajazz/ak820/ak820_combo.c:76: bool eligible = false;
      0036F2 90 04 60         [24] 1123 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      0036F5 E4               [12] 1124 	clr	a
      0036F6 F0               [24] 1125 	movx	@dptr,a
                                   1126 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (record->event.pressed && input(record->keycode)) {
      0036F7 12 37 E0         [24] 1127 	lcall	_ak820_outline_0005
      0036FA 70 02            [24] 1128 	jnz	00317$
      0036FC E1 9F            [12] 1129 	ajmp	00134$
      0036FE                       1130 00317$:
      0036FE 12 38 A3         [24] 1131 	lcall	_ak820_outline_0132
      003701 C0 03            [24] 1132 	push	ar3
      003703 C0 02            [24] 1133 	push	ar2
      003705 91 68            [12] 1134 	acall	_input
      003707 E5 82            [12] 1135 	mov	a, dpl
      003709 D0 02            [24] 1136 	pop	ar2
      00370B D0 03            [24] 1137 	pop	ar3
      00370D 70 02            [24] 1138 	jnz	00318$
      00370F E1 9F            [12] 1139 	ajmp	00134$
      003711                       1140 00318$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t previous = saved.keycode;
      003711 90 04 4D         [24] 1142 	mov	dptr,#(_saved + 0x0007)
      003714 E0               [24] 1143 	movx	a,@dptr
      003715 FF               [12] 1144 	mov	r7,a
                                   1145 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003716 90 04 61         [24] 1146 	mov	dptr,#_ak820_combo_process_i_40001_636
      003719 E4               [12] 1147 	clr	a
      00371A F0               [24] 1148 	movx	@dptr,a
      00371B EB               [12] 1149 	mov	a,r3
      00371C B5 07 03         [24] 1150 	cjne	a,ar7,00319$
      00371F D3               [12] 1151 	setb	c
      003720 80 01            [24] 1152 	sjmp	00320$
      003722                       1153 00319$:
      003722 C3               [12] 1154 	clr	c
      003723                       1155 00320$:
      003723 92 03            [24] 1156 	mov	_ak820_combo_process_sloc0_1_0,c
      003725 7E 00            [12] 1157 	mov	r6,#0x00
      003727                       1158 00141$:
      003727 BE 08 00         [24] 1159 	cjne	r6,#0x08,00321$
      00372A                       1160 00321$:
      00372A 40 02            [24] 1161 	jc	00322$
      00372C E1 9F            [12] 1162 	ajmp	00134$
      00372E                       1163 00322$:
                                   1164 ;	keyboards/ajazz/ak820/ak820_combo.c:80: uint8_t a = combos[i].a, b = combos[i].b;
      00372E EE               [12] 1165 	mov	a,r6
      00372F 12 38 33         [24] 1166 	lcall	_ak820_outline_0060
      003732 E0               [24] 1167 	movx	a,@dptr
      003733 F9               [12] 1168 	mov	r1,a
      003734 90 04 62         [24] 1169 	mov	dptr,#_ak820_combo_process_a_50001_637
      003737 12 38 75         [24] 1170 	lcall	_ak820_outline_0106
      00373A A3               [24] 1171 	inc	dptr
      00373B E0               [24] 1172 	movx	a,@dptr
      00373C FD               [12] 1173 	mov	r5,a
      00373D 90 04 63         [24] 1174 	mov	dptr,#_ak820_combo_process_b_50001_637
      003740 F0               [24] 1175 	movx	@dptr,a
                                   1176 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (a == code || b == code) {
      003741 E9               [12] 1177 	mov	a,r1
      003742 B5 03 02         [24] 1178 	cjne	a,ar3,00323$
      003745 80 04            [24] 1179 	sjmp	00129$
      003747                       1180 00323$:
      003747 ED               [12] 1181 	mov	a,r5
      003748 B5 03 4C         [24] 1182 	cjne	a,ar3,00142$
      00374B                       1183 00129$:
                                   1184 ;	keyboards/ajazz/ak820/ak820_combo.c:82: eligible = true;
      00374B 90 04 60         [24] 1185 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      00374E 74 01            [12] 1186 	mov	a,#0x01
      003750 F0               [24] 1187 	movx	@dptr,a
                                   1188 ;	keyboards/ajazz/ak820/ak820_combo.c:83: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003751 12 38 C7         [24] 1189 	lcall	_ak820_outline_0191
      003754 FD               [12] 1190 	mov	r5,a
      003755 BD FF 02         [24] 1191 	cjne	r5,#0xff,00326$
      003758 80 3D            [24] 1192 	sjmp	00142$
      00375A                       1193 00326$:
      00375A 20 03 3A         [24] 1194 	jb	_ak820_combo_process_sloc0_1_0,00142$
      00375D 90 04 62         [24] 1195 	mov	dptr,#_ak820_combo_process_a_50001_637
      003760 E0               [24] 1196 	movx	a,@dptr
      003761 B5 07 02         [24] 1197 	cjne	a,ar7,00328$
      003764 80 07            [24] 1198 	sjmp	00124$
      003766                       1199 00328$:
      003766 90 04 63         [24] 1200 	mov	dptr,#_ak820_combo_process_b_50001_637
      003769 E0               [24] 1201 	movx	a,@dptr
      00376A B5 07 2A         [24] 1202 	cjne	a,ar7,00142$
      00376D                       1203 00124$:
                                   1204 ;	keyboards/ajazz/ak820/ak820_combo.c:84: second = id;
      00376D 90 0E 9B         [24] 1205 	mov	dptr,#_second
      003770 EA               [12] 1206 	mov	a,r2
      003771 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	keyboards/ajazz/ak820/ak820_combo.c:85: active = true;
      003772 90 04 4F         [24] 1209 	mov	dptr,#_active
      003775 74 01            [12] 1210 	mov	a,#0x01
      003777 F0               [24] 1211 	movx	@dptr,a
                                   1212 ;	keyboards/ajazz/ak820/ak820_combo.c:86: saved.keycode = combos[i].output;
      003778 90 04 61         [24] 1213 	mov	dptr,#_ak820_combo_process_i_40001_636
      00377B E0               [24] 1214 	movx	a,@dptr
      00377C 12 38 33         [24] 1215 	lcall	_ak820_outline_0060
      00377F A3               [24] 1216 	inc	dptr
      003780 A3               [24] 1217 	inc	dptr
      003781 12 38 44         [24] 1218 	lcall	_ak820_outline_0065
      003784 90 04 4D         [24] 1219 	mov	dptr,#(_saved + 0x0007)
      003787 12 38 50         [24] 1220 	lcall	_ak820_outline_0078
                                   1221 ;	keyboards/ajazz/ak820/ak820_combo.c:87: process_record(&saved);
      00378A 90 04 46         [24] 1222 	mov	dptr,#_saved
      00378D 75 F0 00         [24] 1223 	mov	b, #0x00
      003790 12 75 E1         [24] 1224 	lcall	_process_record
                                   1225 ;	keyboards/ajazz/ak820/ak820_combo.c:88: return false;
      003793 75 82 00         [24] 1226 	mov	dpl, #0x00
      003796 22               [24] 1227 	ret
      003797                       1228 00142$:
                                   1229 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003797 0E               [12] 1230 	inc	r6
      003798 90 04 61         [24] 1231 	mov	dptr,#_ak820_combo_process_i_40001_636
      00379B EE               [12] 1232 	mov	a,r6
      00379C F0               [24] 1233 	movx	@dptr,a
      00379D E1 27            [24] 1234 	ajmp	00141$
      00379F                       1235 00134$:
                                   1236 ;	keyboards/ajazz/ak820/ak820_combo.c:93: if (first != NONE) flush();
      00379F 12 38 C7         [24] 1237 	lcall	_ak820_outline_0191
      0037A2 FF               [12] 1238 	mov	r7,a
      0037A3 BF FF 02         [24] 1239 	cjne	r7,#0xff,00331$
      0037A6 80 06            [24] 1240 	sjmp	00137$
      0037A8                       1241 00331$:
      0037A8 C0 02            [24] 1242 	push	ar2
      0037AA B1 ED            [24] 1243 	acall	_flush
      0037AC D0 02            [24] 1244 	pop	ar2
      0037AE                       1245 00137$:
                                   1246 ;	keyboards/ajazz/ak820/ak820_combo.c:94: if (eligible) {
      0037AE 90 04 60         [24] 1247 	mov	dptr,#_ak820_combo_process_eligible_10001_633
      0037B1 E0               [24] 1248 	movx	a,@dptr
      0037B2 60 28            [24] 1249 	jz	00139$
                                   1250 ;	keyboards/ajazz/ak820/ak820_combo.c:95: first = id;
      0037B4 90 0E 9A         [24] 1251 	mov	dptr,#_first
      0037B7 EA               [12] 1252 	mov	a,r2
      0037B8 F0               [24] 1253 	movx	@dptr,a
                                   1254 ;	keyboards/ajazz/ak820/ak820_combo.c:96: saved = *record;
      0037B9 90 04 5E         [24] 1255 	mov	dptr,#_ak820_combo_process_record_10000_618
      0037BC 12 38 5C         [24] 1256 	lcall	_ak820_outline_0086
      0037BF 7F 00            [12] 1257 	mov	r7,#0x00
      0037C1 90 0E 8C         [24] 1258 	mov	dptr,#___memcpy_PARM_2
      0037C4 ED               [12] 1259 	mov	a,r5
      0037C5 12 38 15         [24] 1260 	lcall	_ak820_outline_0020
      0037C8 90 0E 8F         [24] 1261 	mov	dptr,#___memcpy_PARM_3
      0037CB 74 09            [12] 1262 	mov	a,#0x09
      0037CD 12 38 A8         [24] 1263 	lcall	_ak820_outline_0133
      0037D0 90 04 46         [24] 1264 	mov	dptr,#_saved
      0037D3 F5 F0            [12] 1265 	mov	b,a
      0037D5 12 BE 8E         [24] 1266 	lcall	___memcpy
                                   1267 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return false;
      0037D8 75 82 00         [24] 1268 	mov	dpl, #0x00
      0037DB 22               [24] 1269 	ret
      0037DC                       1270 00139$:
                                   1271 ;	keyboards/ajazz/ak820/ak820_combo.c:99: return true;
      0037DC 75 82 01         [24] 1272 	mov	dpl, #0x01
                                   1273 ;	keyboards/ajazz/ak820/ak820_combo.c:100: }
      0037DF 22               [24] 1274 	ret
                                   1275 	.area CSEG    (CODE)
                                   1276 	.area CONST   (CODE)
                                   1277 	.area XINIT   (CODE)
      00C74C                       1278 __xinit__first:
      00C74C FF                    1279 	.db #0xff	; 255
      00C74D                       1280 __xinit__second:
      00C74D FF                    1281 	.db #0xff	; 255
                                   1282 	.area CABS    (ABS,CODE)
                                   1283 
                                   1284 ; Experimental exact instruction outlining.
                                   1285 	.globl _ak820_outline_0005
                                   1286 	.globl _ak820_outline_0006
                                   1287 	.globl _ak820_outline_0008
                                   1288 	.globl _ak820_outline_0019
                                   1289 	.globl _ak820_outline_0020
                                   1290 	.globl _ak820_outline_0026
                                   1291 	.globl _ak820_outline_0035
                                   1292 	.globl _ak820_outline_0058
                                   1293 	.globl _ak820_outline_0060
                                   1294 	.globl _ak820_outline_0065
                                   1295 	.globl _ak820_outline_0077
                                   1296 	.globl _ak820_outline_0078
                                   1297 	.globl _ak820_outline_0084
                                   1298 	.globl _ak820_outline_0086
                                   1299 	.globl _ak820_outline_0098
                                   1300 	.globl _ak820_outline_0103
                                   1301 	.globl _ak820_outline_0104
                                   1302 	.globl _ak820_outline_0106
                                   1303 	.globl _ak820_outline_0107
                                   1304 	.globl _ak820_outline_0111
                                   1305 	.globl _ak820_outline_0112
                                   1306 	.globl _ak820_outline_0117
                                   1307 	.globl _ak820_outline_0124
                                   1308 	.globl _ak820_outline_0128
                                   1309 	.globl _ak820_outline_0129
                                   1310 	.globl _ak820_outline_0131
                                   1311 	.globl _ak820_outline_0132
                                   1312 	.globl _ak820_outline_0133
                                   1313 	.globl _ak820_outline_0134
                                   1314 	.globl _ak820_outline_0143
                                   1315 	.globl _ak820_outline_0151
                                   1316 	.globl _ak820_outline_0165
                                   1317 	.globl _ak820_outline_0179
                                   1318 	.globl _ak820_outline_0191
                                   1319 	.globl _ak820_outline_0195
                                   1320 
                                   1321 	.area CSEG (CODE)
                                   1322 ; function ak820_outline_0005
      0037E0                       1323 _ak820_outline_0005:
      0037E0 74 05            [12] 1324 	mov	a,#0x05
      0037E2 2E               [12] 1325 	add	a,r6
      0037E3 FE               [12] 1326 	mov	r6,a
      0037E4 E4               [12] 1327 	clr	a
      0037E5 3F               [12] 1328 	addc	a,r7
      0037E6 FF               [12] 1329 	mov	r7,a
      0037E7 8E 82            [24] 1330 	mov	dpl,r6
      0037E9 8F 83            [24] 1331 	mov	dph,r7
      0037EB E0               [24] 1332 	movx	a,@dptr
      0037EC 22               [24] 1333 	ret
                                   1334 
                                   1335 	.area CSEG (CODE)
                                   1336 ; function ak820_outline_0006
      0037ED                       1337 _ak820_outline_0006:
      0037ED E0               [24] 1338 	movx	a,@dptr
      0037EE FE               [12] 1339 	mov	r6,a
      0037EF A3               [24] 1340 	inc	dptr
      0037F0 E0               [24] 1341 	movx	a,@dptr
      0037F1 FF               [12] 1342 	mov	r7,a
      0037F2 8E 82            [24] 1343 	mov	dpl,r6
      0037F4 8F 83            [24] 1344 	mov	dph,r7
      0037F6 22               [24] 1345 	ret
                                   1346 
                                   1347 	.area CSEG (CODE)
                                   1348 ; function ak820_outline_0008
      0037F7                       1349 _ak820_outline_0008:
      0037F7 E0               [24] 1350 	movx	a,@dptr
      0037F8 FE               [12] 1351 	mov	r6,a
      0037F9 A3               [24] 1352 	inc	dptr
      0037FA E0               [24] 1353 	movx	a,@dptr
      0037FB FF               [12] 1354 	mov	r7,a
      0037FC 74 07            [12] 1355 	mov	a,#0x07
      0037FE 2E               [12] 1356 	add	a,r6
      0037FF F5 82            [12] 1357 	mov	dpl,a
      003801 E4               [12] 1358 	clr	a
      003802 3F               [12] 1359 	addc	a,r7
      003803 F5 83            [12] 1360 	mov	dph,a
      003805 E0               [24] 1361 	movx	a,@dptr
      003806 FC               [12] 1362 	mov	r4,a
      003807 A3               [24] 1363 	inc	dptr
      003808 E0               [24] 1364 	movx	a,@dptr
      003809 FD               [12] 1365 	mov	r5,a
      00380A 22               [24] 1366 	ret
                                   1367 
                                   1368 	.area CSEG (CODE)
                                   1369 ; function ak820_outline_0019
      00380B                       1370 _ak820_outline_0019:
      00380B F9               [12] 1371 	mov	r1,a
      00380C E4               [12] 1372 	clr	a
      00380D 3F               [12] 1373 	addc	a,r7
      00380E FA               [12] 1374 	mov	r2,a
      00380F 89 82            [24] 1375 	mov	dpl,r1
      003811 8A 83            [24] 1376 	mov	dph,r2
      003813 E0               [24] 1377 	movx	a,@dptr
      003814 22               [24] 1378 	ret
                                   1379 
                                   1380 	.area CSEG (CODE)
                                   1381 ; function ak820_outline_0020
      003815                       1382 _ak820_outline_0020:
      003815 F0               [24] 1383 	movx	@dptr,a
      003816 EE               [12] 1384 	mov	a,r6
      003817 A3               [24] 1385 	inc	dptr
      003818 F0               [24] 1386 	movx	@dptr,a
      003819 EF               [12] 1387 	mov	a,r7
      00381A A3               [24] 1388 	inc	dptr
      00381B F0               [24] 1389 	movx	@dptr,a
      00381C 22               [24] 1390 	ret
                                   1391 
                                   1392 	.area CSEG (CODE)
                                   1393 ; function ak820_outline_0026
      00381D                       1394 _ak820_outline_0026:
      00381D 2E               [12] 1395 	add	a,r6
      00381E F5 82            [12] 1396 	mov	dpl,a
      003820 E4               [12] 1397 	clr	a
      003821 3F               [12] 1398 	addc	a,r7
      003822 F5 83            [12] 1399 	mov	dph,a
      003824 22               [24] 1400 	ret
                                   1401 
                                   1402 	.area CSEG (CODE)
                                   1403 ; function ak820_outline_0035
      003825                       1404 _ak820_outline_0035:
      003825 8E 82            [24] 1405 	mov	dpl,r6
      003827 8F 83            [24] 1406 	mov	dph,r7
      003829 A3               [24] 1407 	inc	dptr
      00382A A3               [24] 1408 	inc	dptr
      00382B E0               [24] 1409 	movx	a,@dptr
      00382C 22               [24] 1410 	ret
                                   1411 
                                   1412 	.area CSEG (CODE)
                                   1413 ; function ak820_outline_0058
      00382D                       1414 _ak820_outline_0058:
      00382D E0               [24] 1415 	movx	a,@dptr
      00382E FE               [12] 1416 	mov	r6,a
      00382F A3               [24] 1417 	inc	dptr
      003830 E0               [24] 1418 	movx	a,@dptr
      003831 FF               [12] 1419 	mov	r7,a
      003832 22               [24] 1420 	ret
                                   1421 
                                   1422 	.area CSEG (CODE)
                                   1423 ; function ak820_outline_0060
      003833                       1424 _ak820_outline_0060:
      003833 75 F0 04         [24] 1425 	mov	b,#0x04
      003836 A4               [48] 1426 	mul	ab
      003837 24 26            [12] 1427 	add	a,#_combos
      003839 FC               [12] 1428 	mov	r4,a
      00383A 74 04            [12] 1429 	mov	a,#(_combos>>8)
      00383C 35 F0            [12] 1430 	addc	a,b
      00383E FD               [12] 1431 	mov	r5,a
      00383F 8C 82            [24] 1432 	mov	dpl,r4
      003841 8D 83            [24] 1433 	mov	dph,r5
      003843 22               [24] 1434 	ret
                                   1435 
                                   1436 	.area CSEG (CODE)
                                   1437 ; function ak820_outline_0065
      003844                       1438 _ak820_outline_0065:
      003844 E0               [24] 1439 	movx	a,@dptr
      003845 FC               [12] 1440 	mov	r4,a
      003846 A3               [24] 1441 	inc	dptr
      003847 E0               [24] 1442 	movx	a,@dptr
      003848 FD               [12] 1443 	mov	r5,a
      003849 22               [24] 1444 	ret
                                   1445 
                                   1446 	.area CSEG (CODE)
                                   1447 ; function ak820_outline_0077
      00384A                       1448 _ak820_outline_0077:
      00384A A3               [24] 1449 	inc	dptr
      00384B F0               [24] 1450 	movx	@dptr,a
      00384C E4               [12] 1451 	clr	a
      00384D A3               [24] 1452 	inc	dptr
      00384E F0               [24] 1453 	movx	@dptr,a
      00384F 22               [24] 1454 	ret
                                   1455 
                                   1456 	.area CSEG (CODE)
                                   1457 ; function ak820_outline_0078
      003850                       1458 _ak820_outline_0078:
      003850 EC               [12] 1459 	mov	a,r4
      003851 F0               [24] 1460 	movx	@dptr,a
      003852 ED               [12] 1461 	mov	a,r5
      003853 A3               [24] 1462 	inc	dptr
      003854 F0               [24] 1463 	movx	@dptr,a
      003855 22               [24] 1464 	ret
                                   1465 
                                   1466 	.area CSEG (CODE)
                                   1467 ; function ak820_outline_0084
      003856                       1468 _ak820_outline_0084:
      003856 EB               [12] 1469 	mov	a,r3
      003857 F0               [24] 1470 	movx	@dptr,a
      003858 EC               [12] 1471 	mov	a,r4
      003859 A3               [24] 1472 	inc	dptr
      00385A F0               [24] 1473 	movx	@dptr,a
      00385B 22               [24] 1474 	ret
                                   1475 
                                   1476 	.area CSEG (CODE)
                                   1477 ; function ak820_outline_0086
      00385C                       1478 _ak820_outline_0086:
      00385C E0               [24] 1479 	movx	a,@dptr
      00385D FD               [12] 1480 	mov	r5,a
      00385E A3               [24] 1481 	inc	dptr
      00385F E0               [24] 1482 	movx	a,@dptr
      003860 FE               [12] 1483 	mov	r6,a
      003861 22               [24] 1484 	ret
                                   1485 
                                   1486 	.area CSEG (CODE)
                                   1487 ; function ak820_outline_0098
      003862                       1488 _ak820_outline_0098:
      003862 8B 82            [24] 1489 	mov	dpl,r3
      003864 8C 83            [24] 1490 	mov	dph,r4
      003866 E4               [12] 1491 	clr	a
      003867 F0               [24] 1492 	movx	@dptr,a
      003868 22               [24] 1493 	ret
                                   1494 
                                   1495 	.area CSEG (CODE)
                                   1496 ; function ak820_outline_0103
      003869                       1497 _ak820_outline_0103:
      003869 8E 82            [24] 1498 	mov	dpl,r6
      00386B 8F 83            [24] 1499 	mov	dph,r7
      00386D E0               [24] 1500 	movx	a,@dptr
      00386E 22               [24] 1501 	ret
                                   1502 
                                   1503 	.area CSEG (CODE)
                                   1504 ; function ak820_outline_0104
      00386F                       1505 _ak820_outline_0104:
      00386F E0               [24] 1506 	movx	a,@dptr
      003870 F8               [12] 1507 	mov	r0,a
      003871 A3               [24] 1508 	inc	dptr
      003872 E0               [24] 1509 	movx	a,@dptr
      003873 F9               [12] 1510 	mov	r1,a
      003874 22               [24] 1511 	ret
                                   1512 
                                   1513 	.area CSEG (CODE)
                                   1514 ; function ak820_outline_0106
      003875                       1515 _ak820_outline_0106:
      003875 F0               [24] 1516 	movx	@dptr,a
      003876 8C 82            [24] 1517 	mov	dpl,r4
      003878 8D 83            [24] 1518 	mov	dph,r5
      00387A 22               [24] 1519 	ret
                                   1520 
                                   1521 	.area CSEG (CODE)
                                   1522 ; function ak820_outline_0107
      00387B                       1523 _ak820_outline_0107:
      00387B E0               [24] 1524 	movx	a,@dptr
      00387C FB               [12] 1525 	mov	r3,a
      00387D A3               [24] 1526 	inc	dptr
      00387E E0               [24] 1527 	movx	a,@dptr
      00387F FC               [12] 1528 	mov	r4,a
      003880 22               [24] 1529 	ret
                                   1530 
                                   1531 	.area CSEG (CODE)
                                   1532 ; function ak820_outline_0111
      003881                       1533 _ak820_outline_0111:
      003881 AF 83            [24] 1534 	mov	r7,dph
      003883 E5 82            [12] 1535 	mov	a,dpl
      003885 22               [24] 1536 	ret
                                   1537 
                                   1538 	.area CSEG (CODE)
                                   1539 ; function ak820_outline_0112
      003886                       1540 _ak820_outline_0112:
      003886 F0               [24] 1541 	movx	@dptr,a
      003887 EF               [12] 1542 	mov	a,r7
      003888 A3               [24] 1543 	inc	dptr
      003889 F0               [24] 1544 	movx	@dptr,a
      00388A 22               [24] 1545 	ret
                                   1546 
                                   1547 	.area CSEG (CODE)
                                   1548 ; function ak820_outline_0117
      00388B                       1549 _ak820_outline_0117:
      00388B 8E 82            [24] 1550 	mov	dpl,r6
      00388D 8F 83            [24] 1551 	mov	dph,r7
      00388F A3               [24] 1552 	inc	dptr
      003890 E0               [24] 1553 	movx	a,@dptr
      003891 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0124
      003892                       1558 _ak820_outline_0124:
      003892 8E 82            [24] 1559 	mov	dpl,r6
      003894 8F 83            [24] 1560 	mov	dph,r7
      003896 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0128
      003897                       1565 _ak820_outline_0128:
      003897 E5 82            [12] 1566 	mov	a,dpl
      003899 85 83 F0         [24] 1567 	mov	b,dph
      00389C 22               [24] 1568 	ret
                                   1569 
                                   1570 	.area CSEG (CODE)
                                   1571 ; function ak820_outline_0129
      00389D                       1572 _ak820_outline_0129:
      00389D 88 82            [24] 1573 	mov	dpl,r0
      00389F 89 83            [24] 1574 	mov	dph,r1
      0038A1 E0               [24] 1575 	movx	a,@dptr
      0038A2 22               [24] 1576 	ret
                                   1577 
                                   1578 	.area CSEG (CODE)
                                   1579 ; function ak820_outline_0132
      0038A3                       1580 _ak820_outline_0132:
      0038A3 8C 82            [24] 1581 	mov	dpl,r4
      0038A5 8D 83            [24] 1582 	mov	dph,r5
      0038A7 22               [24] 1583 	ret
                                   1584 
                                   1585 	.area CSEG (CODE)
                                   1586 ; function ak820_outline_0133
      0038A8                       1587 _ak820_outline_0133:
      0038A8 F0               [24] 1588 	movx	@dptr,a
      0038A9 E4               [12] 1589 	clr	a
      0038AA A3               [24] 1590 	inc	dptr
      0038AB F0               [24] 1591 	movx	@dptr,a
      0038AC 22               [24] 1592 	ret
                                   1593 
                                   1594 	.area CSEG (CODE)
                                   1595 ; function ak820_outline_0134
      0038AD                       1596 _ak820_outline_0134:
      0038AD 8A 82            [24] 1597 	mov	dpl,r2
      0038AF 8B 83            [24] 1598 	mov	dph,r3
      0038B1 22               [24] 1599 	ret
                                   1600 
                                   1601 	.area CSEG (CODE)
                                   1602 ; function ak820_outline_0143
      0038B2                       1603 _ak820_outline_0143:
      0038B2 8D 82            [24] 1604 	mov	dpl,r5
      0038B4 8E 83            [24] 1605 	mov	dph,r6
      0038B6 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0151
      0038B7                       1610 _ak820_outline_0151:
      0038B7 E4               [12] 1611 	clr	a
      0038B8 33               [12] 1612 	rlc	a
      0038B9 F5 82            [12] 1613 	mov	dpl,a
      0038BB 22               [24] 1614 	ret
                                   1615 
                                   1616 	.area CSEG (CODE)
                                   1617 ; function ak820_outline_0165
      0038BC                       1618 _ak820_outline_0165:
      0038BC 2D               [12] 1619 	add	a,r5
      0038BD FD               [12] 1620 	mov	r5,a
      0038BE E4               [12] 1621 	clr	a
      0038BF 3E               [12] 1622 	addc	a,r6
      0038C0 FE               [12] 1623 	mov	r6,a
      0038C1 22               [24] 1624 	ret
                                   1625 
                                   1626 	.area CSEG (CODE)
                                   1627 ; function ak820_outline_0179
      0038C2                       1628 _ak820_outline_0179:
      0038C2 C4               [12] 1629 	swap	a
      0038C3 03               [12] 1630 	rr	a
      0038C4 54 F8            [12] 1631 	anl	a,#0xf8
      0038C6 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0191
      0038C7                       1636 _ak820_outline_0191:
      0038C7 90 0E 9A         [24] 1637 	mov	dptr,#_first
      0038CA E0               [24] 1638 	movx	a,@dptr
      0038CB 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0195
      0038CC                       1643 _ak820_outline_0195:
      0038CC 75 F0 04         [24] 1644 	mov	b,#0x04
      0038CF A4               [48] 1645 	mul	ab
      0038D0 22               [24] 1646 	ret
