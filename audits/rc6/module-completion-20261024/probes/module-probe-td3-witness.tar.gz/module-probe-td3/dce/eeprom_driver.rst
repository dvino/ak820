                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000748                         85 _eeprom_read_word_addr_10000_91:
      000748                         86 	.ds 3
      00074B                         87 _eeprom_read_word_ret_10000_92:
      00074B                         88 	.ds 2
      00074D                         89 _eeprom_read_dword_addr_10000_93:
      00074D                         90 	.ds 3
      000750                         91 _eeprom_read_dword_ret_10000_94:
      000750                         92 	.ds 4
      000754                         93 _eeprom_write_byte_PARM_2:
      000754                         94 	.ds 1
      000755                         95 _eeprom_write_byte_addr_10000_95:
      000755                         96 	.ds 3
      000758                         97 _eeprom_write_word_PARM_2:
      000758                         98 	.ds 2
      00075A                         99 _eeprom_write_word_addr_10000_97:
      00075A                        100 	.ds 3
      00075D                        101 _eeprom_write_dword_PARM_2:
      00075D                        102 	.ds 4
      000761                        103 _eeprom_write_dword_addr_10000_99:
      000761                        104 	.ds 3
      000764                        105 _eeprom_update_byte_PARM_2:
      000764                        106 	.ds 1
      000765                        107 _eeprom_update_byte_addr_10000_107:
      000765                        108 	.ds 3
      000768                        109 _eeprom_update_word_PARM_2:
      000768                        110 	.ds 2
      00076A                        111 _eeprom_update_word_addr_10000_111:
      00076A                        112 	.ds 3
      00076D                        113 _eeprom_update_dword_PARM_2:
      00076D                        114 	.ds 4
      000771                        115 _eeprom_update_dword_addr_10000_115:
      000771                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0052B2                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0052B2 12 43 1B         [24]  170 	lcall	_ak820_outline_0041
      0052B5 90 07 48         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0052B8 12 38 15         [24]  172 	lcall	_ak820_outline_0020
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0052BB 90 07 4B         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052BE 12 49 28         [24]  175 	lcall	_ak820_outline_0150
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0052C1 90 07 48         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0052C4 12 54 6E         [24]  178 	lcall	_ak820_outline_0015
      0052C7 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0052CA ED               [12]  180 	mov	a,r5
      0052CB 12 38 15         [24]  181 	lcall	_ak820_outline_0020
      0052CE 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0052D1 12 54 AA         [24]  183 	lcall	_ak820_outline_0114
      0052D4 90 07 4B         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052D7 12 40 B7         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0052DA 90 07 4B         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052DD 12 54 A1         [24]  188 	lcall	_ak820_outline_0096
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0052E0 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0052E1                        201 _eeprom_read_dword:
      0052E1 12 43 1B         [24]  202 	lcall	_ak820_outline_0041
      0052E4 90 07 4D         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0052E7 12 38 15         [24]  204 	lcall	_ak820_outline_0020
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0052EA 90 07 50         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052ED 12 54 7F         [24]  207 	lcall	_ak820_outline_0057
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0052F0 90 07 4D         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0052F3 12 54 6E         [24]  210 	lcall	_ak820_outline_0015
      0052F6 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0052F9 ED               [12]  212 	mov	a,r5
      0052FA 12 38 15         [24]  213 	lcall	_ak820_outline_0020
      0052FD 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005300 74 04            [12]  215 	mov	a,#0x04
      005302 12 38 A8         [24]  216 	lcall	_ak820_outline_0133
      005305 90 07 50         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005308 12 40 B7         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      00530B 90 07 50         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00530E 12 54 88         [24]  221 	lcall	_ak820_outline_0061
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      005311 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      005312                        234 _eeprom_write_byte:
      005312 12 43 1B         [24]  235 	lcall	_ak820_outline_0041
      005315 90 07 55         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005318 12 38 15         [24]  237 	lcall	_ak820_outline_0020
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      00531B 90 07 55         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      00531E 12 54 57         [24]  240 	lcall	_ak820_outline_0004
      005321 74 01            [12]  241 	mov	a,#0x01
      005323 12 38 A8         [24]  242 	lcall	_ak820_outline_0133
      005326 90 07 54         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005329 02 41 43         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      00532C                        256 _eeprom_write_word:
      00532C 12 43 1B         [24]  257 	lcall	_ak820_outline_0041
      00532F 90 07 5A         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005332 12 38 15         [24]  259 	lcall	_ak820_outline_0020
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005335 90 07 5A         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005338 12 54 57         [24]  262 	lcall	_ak820_outline_0004
      00533B 12 54 AA         [24]  263 	lcall	_ak820_outline_0114
      00533E 90 07 58         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      005341 02 41 43         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005344                        277 _eeprom_write_dword:
      005344 12 43 1B         [24]  278 	lcall	_ak820_outline_0041
      005347 90 07 61         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00534A 12 38 15         [24]  280 	lcall	_ak820_outline_0020
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      00534D 90 07 61         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005350 12 54 57         [24]  283 	lcall	_ak820_outline_0004
      005353 74 04            [12]  284 	mov	a,#0x04
      005355 12 38 A8         [24]  285 	lcall	_ak820_outline_0133
      005358 90 07 5D         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      00535B 02 41 43         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00535E                        307 _eeprom_update_byte:
      00535E C0 07            [24]  308 	push	ar7
      005360 C0 06            [24]  309 	push	ar6
      005362 C0 05            [24]  310 	push	ar5
      005364 C0 04            [24]  311 	push	ar4
      005366 12 43 1B         [24]  312 	lcall	_ak820_outline_0041
      005369 90 07 65         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00536C 12 38 15         [24]  314 	lcall	_ak820_outline_0020
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00536F 90 07 65         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005372 12 54 48         [24]  317 	lcall	_ak820_outline_0001
      005375 12 40 7C         [24]  318 	lcall	_eeprom_read_byte
      005378 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      00537A 90 07 64         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      00537D E0               [24]  322 	movx	a,@dptr
      00537E FE               [12]  323 	mov	r6,a
      00537F EF               [12]  324 	mov	a,r7
      005380 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      005383 80 35            [24]  326 	sjmp	00103$
      005385                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005385 90 07 65         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005388 12 38 44         [24]  330 	lcall	_ak820_outline_0065
      00538B A3               [24]  331 	inc	dptr
      00538C E0               [24]  332 	movx	a,@dptr
      00538D FF               [12]  333 	mov	r7,a
      00538E 90 07 54         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      005391 EE               [12]  335 	mov	a,r6
      005392 12 38 75         [24]  336 	lcall	_ak820_outline_0106
      005395 8F F0            [24]  337 	mov	b, r7
      005397 C0 07            [24]  338 	push	ar7
      005399 C0 06            [24]  339 	push	ar6
      00539B C0 05            [24]  340 	push	ar5
      00539D C0 04            [24]  341 	push	ar4
      00539F C0 03            [24]  342 	push	ar3
      0053A1 C0 02            [24]  343 	push	ar2
      0053A3 C0 01            [24]  344 	push	ar1
      0053A5 C0 00            [24]  345 	push	ar0
      0053A7 12 53 12         [24]  346 	lcall	_eeprom_write_byte
      0053AA D0 00            [24]  347 	pop	ar0
      0053AC D0 01            [24]  348 	pop	ar1
      0053AE D0 02            [24]  349 	pop	ar2
      0053B0 D0 03            [24]  350 	pop	ar3
      0053B2 D0 04            [24]  351 	pop	ar4
      0053B4 D0 05            [24]  352 	pop	ar5
      0053B6 D0 06            [24]  353 	pop	ar6
      0053B8 D0 07            [24]  354 	pop	ar7
      0053BA                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      0053BA D0 04            [24]  357 	pop	ar4
      0053BC D0 05            [24]  358 	pop	ar5
      0053BE D0 06            [24]  359 	pop	ar6
      0053C0 D0 07            [24]  360 	pop	ar7
      0053C2 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      0053C3                        373 _eeprom_update_word:
      0053C3 12 43 1B         [24]  374 	lcall	_ak820_outline_0041
      0053C6 90 07 6A         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053C9 12 38 15         [24]  376 	lcall	_ak820_outline_0020
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0053CC 90 07 6A         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053CF 12 54 48         [24]  379 	lcall	_ak820_outline_0001
      0053D2 12 52 B2         [24]  380 	lcall	_eeprom_read_word
      0053D5 12 43 64         [24]  381 	lcall	_ak820_outline_0142
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0053D8 90 07 68         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      0053DB 12 38 44         [24]  384 	lcall	_ak820_outline_0065
      0053DE EE               [12]  385 	mov	a,r6
      0053DF B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0053E2 EF               [12]  387 	mov	a,r7
      0053E3 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      0053E6 22               [24]  389 	ret
      0053E7                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0053E7 90 07 6A         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053EA E0               [24]  393 	movx	a,@dptr
      0053EB FB               [12]  394 	mov	r3,a
      0053EC A3               [24]  395 	inc	dptr
      0053ED 12 38 2D         [24]  396 	lcall	_ak820_outline_0058
      0053F0 90 07 58         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0053F3 12 38 50         [24]  398 	lcall	_ak820_outline_0078
      0053F6 8B 82            [24]  399 	mov	dpl, r3
      0053F8 8E 83            [24]  400 	mov	dph, r6
      0053FA 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0053FC 02 53 2C         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0053FF                        415 _eeprom_update_dword:
      0053FF 12 43 1B         [24]  416 	lcall	_ak820_outline_0041
      005402 90 07 71         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005405 12 38 15         [24]  418 	lcall	_ak820_outline_0020
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005408 90 07 71         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00540B 12 54 48         [24]  421 	lcall	_ak820_outline_0001
      00540E 12 52 E1         [24]  422 	lcall	_eeprom_read_dword
      005411 12 54 99         [24]  423 	lcall	_ak820_outline_0062
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      005414 90 07 6D         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      005417 12 38 6F         [24]  426 	lcall	_ak820_outline_0104
      00541A A3               [24]  427 	inc	dptr
      00541B 12 43 4C         [24]  428 	lcall	_ak820_outline_0083
      00541E EC               [12]  429 	mov	a,r4
      00541F B5 00 0D         [24]  430 	cjne	a,ar0,00112$
      005422 ED               [12]  431 	mov	a,r5
      005423 B5 01 09         [24]  432 	cjne	a,ar1,00112$
      005426 EE               [12]  433 	mov	a,r6
      005427 B5 02 05         [24]  434 	cjne	a,ar2,00112$
      00542A EF               [12]  435 	mov	a,r7
      00542B B5 03 01         [24]  436 	cjne	a,ar3,00112$
      00542E 22               [24]  437 	ret
      00542F                        438 00112$:
                                    439 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      00542F 90 07 71         [24]  440 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005432 12 54 6E         [24]  441 	lcall	_ak820_outline_0015
      005435 90 07 5D         [24]  442 	mov	dptr,#_eeprom_write_dword_PARM_2
      005438 E8               [12]  443 	mov	a,r0
      005439 F0               [24]  444 	movx	@dptr,a
      00543A E9               [12]  445 	mov	a,r1
      00543B A3               [24]  446 	inc	dptr
      00543C F0               [24]  447 	movx	@dptr,a
      00543D EA               [12]  448 	mov	a,r2
      00543E A3               [24]  449 	inc	dptr
      00543F F0               [24]  450 	movx	@dptr,a
      005440 EB               [12]  451 	mov	a,r3
      005441 A3               [24]  452 	inc	dptr
      005442 12 54 77         [24]  453 	lcall	_ak820_outline_0036
                                    454 ;	drivers/eeprom/eeprom_driver.c:101: }
      005445 02 53 44         [24]  455 	ljmp	_eeprom_write_dword
                                    456 	.area CSEG    (CODE)
                                    457 	.area CONST   (CODE)
                                    458 	.area XINIT   (CODE)
                                    459 	.area CABS    (ABS,CODE)
                                    460 
                                    461 ; Experimental exact instruction outlining.
                                    462 	.globl _ak820_outline_0001
                                    463 	.globl _ak820_outline_0004
                                    464 	.globl _ak820_outline_0015
                                    465 	.globl _ak820_outline_0020
                                    466 	.globl _ak820_outline_0036
                                    467 	.globl _ak820_outline_0041
                                    468 	.globl _ak820_outline_0057
                                    469 	.globl _ak820_outline_0058
                                    470 	.globl _ak820_outline_0061
                                    471 	.globl _ak820_outline_0062
                                    472 	.globl _ak820_outline_0065
                                    473 	.globl _ak820_outline_0078
                                    474 	.globl _ak820_outline_0083
                                    475 	.globl _ak820_outline_0096
                                    476 	.globl _ak820_outline_0104
                                    477 	.globl _ak820_outline_0106
                                    478 	.globl _ak820_outline_0114
                                    479 	.globl _ak820_outline_0133
                                    480 	.globl _ak820_outline_0142
                                    481 	.globl _ak820_outline_0150
                                    482 
                                    483 	.area CSEG (CODE)
                                    484 ; function ak820_outline_0001
      005448                        485 _ak820_outline_0001:
      005448 E0               [24]  486 	movx	a,@dptr
      005449 FD               [12]  487 	mov	r5,a
      00544A A3               [24]  488 	inc	dptr
      00544B E0               [24]  489 	movx	a,@dptr
      00544C FE               [12]  490 	mov	r6,a
      00544D A3               [24]  491 	inc	dptr
      00544E E0               [24]  492 	movx	a,@dptr
      00544F FF               [12]  493 	mov	r7,a
      005450 8D 82            [24]  494 	mov	dpl,r5
      005452 8E 83            [24]  495 	mov	dph,r6
      005454 8F F0            [24]  496 	mov	b,r7
      005456 22               [24]  497 	ret
                                    498 
                                    499 	.area CSEG (CODE)
                                    500 ; function ak820_outline_0004
      005457                        501 _ak820_outline_0004:
      005457 E0               [24]  502 	movx	a,@dptr
      005458 FD               [12]  503 	mov	r5,a
      005459 A3               [24]  504 	inc	dptr
      00545A E0               [24]  505 	movx	a,@dptr
      00545B FE               [12]  506 	mov	r6,a
      00545C A3               [24]  507 	inc	dptr
      00545D E0               [24]  508 	movx	a,@dptr
      00545E FF               [12]  509 	mov	r7,a
      00545F 90 05 8E         [24]  510 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005462 ED               [12]  511 	mov	a,r5
      005463 F0               [24]  512 	movx	@dptr,a
      005464 EE               [12]  513 	mov	a,r6
      005465 A3               [24]  514 	inc	dptr
      005466 F0               [24]  515 	movx	@dptr,a
      005467 EF               [12]  516 	mov	a,r7
      005468 A3               [24]  517 	inc	dptr
      005469 F0               [24]  518 	movx	@dptr,a
      00546A 90 05 91         [24]  519 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00546D 22               [24]  520 	ret
                                    521 
                                    522 	.area CSEG (CODE)
                                    523 ; function ak820_outline_0015
      00546E                        524 _ak820_outline_0015:
      00546E E0               [24]  525 	movx	a,@dptr
      00546F FD               [12]  526 	mov	r5,a
      005470 A3               [24]  527 	inc	dptr
      005471 E0               [24]  528 	movx	a,@dptr
      005472 FE               [12]  529 	mov	r6,a
      005473 A3               [24]  530 	inc	dptr
      005474 E0               [24]  531 	movx	a,@dptr
      005475 FF               [12]  532 	mov	r7,a
      005476 22               [24]  533 	ret
                                    534 
                                    535 	.area CSEG (CODE)
                                    536 ; function ak820_outline_0036
      005477                        537 _ak820_outline_0036:
      005477 F0               [24]  538 	movx	@dptr,a
      005478 8D 82            [24]  539 	mov	dpl,r5
      00547A 8E 83            [24]  540 	mov	dph,r6
      00547C 8F F0            [24]  541 	mov	b,r7
      00547E 22               [24]  542 	ret
                                    543 
                                    544 	.area CSEG (CODE)
                                    545 ; function ak820_outline_0057
      00547F                        546 _ak820_outline_0057:
      00547F E4               [12]  547 	clr	a
      005480 F0               [24]  548 	movx	@dptr,a
      005481 A3               [24]  549 	inc	dptr
      005482 F0               [24]  550 	movx	@dptr,a
      005483 A3               [24]  551 	inc	dptr
      005484 F0               [24]  552 	movx	@dptr,a
      005485 A3               [24]  553 	inc	dptr
      005486 F0               [24]  554 	movx	@dptr,a
      005487 22               [24]  555 	ret
                                    556 
                                    557 	.area CSEG (CODE)
                                    558 ; function ak820_outline_0061
      005488                        559 _ak820_outline_0061:
      005488 E0               [24]  560 	movx	a,@dptr
      005489 FC               [12]  561 	mov	r4,a
      00548A A3               [24]  562 	inc	dptr
      00548B E0               [24]  563 	movx	a,@dptr
      00548C FD               [12]  564 	mov	r5,a
      00548D A3               [24]  565 	inc	dptr
      00548E E0               [24]  566 	movx	a,@dptr
      00548F FE               [12]  567 	mov	r6,a
      005490 A3               [24]  568 	inc	dptr
      005491 E0               [24]  569 	movx	a,@dptr
      005492 8C 82            [24]  570 	mov	dpl,r4
      005494 8D 83            [24]  571 	mov	dph,r5
      005496 8E F0            [24]  572 	mov	b,r6
      005498 22               [24]  573 	ret
                                    574 
                                    575 	.area CSEG (CODE)
                                    576 ; function ak820_outline_0062
      005499                        577 _ak820_outline_0062:
      005499 AC 82            [24]  578 	mov	r4,dpl
      00549B AD 83            [24]  579 	mov	r5,dph
      00549D AE F0            [24]  580 	mov	r6,b
      00549F FF               [12]  581 	mov	r7,a
      0054A0 22               [24]  582 	ret
                                    583 
                                    584 	.area CSEG (CODE)
                                    585 ; function ak820_outline_0096
      0054A1                        586 _ak820_outline_0096:
      0054A1 E0               [24]  587 	movx	a,@dptr
      0054A2 FE               [12]  588 	mov	r6,a
      0054A3 A3               [24]  589 	inc	dptr
      0054A4 E0               [24]  590 	movx	a,@dptr
      0054A5 8E 82            [24]  591 	mov	dpl,r6
      0054A7 F5 83            [12]  592 	mov	dph,a
      0054A9 22               [24]  593 	ret
                                    594 
                                    595 	.area CSEG (CODE)
                                    596 ; function ak820_outline_0114
      0054AA                        597 _ak820_outline_0114:
      0054AA 74 02            [12]  598 	mov	a,#0x02
      0054AC F0               [24]  599 	movx	@dptr,a
      0054AD E4               [12]  600 	clr	a
      0054AE A3               [24]  601 	inc	dptr
      0054AF F0               [24]  602 	movx	@dptr,a
      0054B0 22               [24]  603 	ret
