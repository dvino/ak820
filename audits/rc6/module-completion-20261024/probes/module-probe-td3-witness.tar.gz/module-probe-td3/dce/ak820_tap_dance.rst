                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tap_dance
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_get_tap_dance
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_tap_dance_valid
                                    258 	.globl _ak820_tap_dance_task
                                    259 	.globl _ak820_tap_dance_before
                                    260 	.globl _ak820_tap_dance_process
                                    261 	.globl _ak820_tap_dance_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
      000015                        524 _ak820_tap_dance_process_sloc0_1_0:
      000015                        525 	.ds 1
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
      00000E                        542 _ak820_tap_dance_before_sloc0_1_0:
      00000E                        543 	.ds 1
      00000F                        544 _ak820_tap_dance_process_sloc1_1_0:
      00000F                        545 	.ds 1
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      00059E                        554 _td_slots:
      00059E                        555 	.ds 32
      0005BE                        556 _td_wait:
      0005BE                        557 	.ds 2
      0005C0                        558 _td_work:
      0005C0                        559 	.ds 2
      0005C2                        560 _td_entry:
      0005C2                        561 	.ds 10
      0005CC                        562 _td_time:
      0005CC                        563 	.ds 2
      0005CE                        564 _td_map:
      0005CE                        565 	.ds 128
      00064E                        566 _td_record:
      00064E                        567 	.ds 9
      000657                        568 _ak820_tap_dance_valid_entry_10000_594:
      000657                        569 	.ds 2
      000659                        570 _ak820_tap_dance_valid_basic_30000_598:
      000659                        571 	.ds 1
      00065A                        572 _td_emit_pressed_10000_601:
      00065A                        573 	.ds 1
      00065B                        574 _td_finish_interrupted_10000_604:
      00065B                        575 	.ds 1
      00065C                        576 _td_finish_choice_10000_605:
      00065C                        577 	.ds 1
      00065D                        578 _td_finish_state_10000_605:
      00065D                        579 	.ds 1
      00065E                        580 _td_finish_extra_10000_605:
      00065E                        581 	.ds 1
      00065F                        582 _ak820_tap_dance_task_now_10000_621:
      00065F                        583 	.ds 2
      000661                        584 _ak820_tap_dance_task_term_10000_622:
      000661                        585 	.ds 2
      000663                        586 _ak820_tap_dance_before_event_10000_625:
      000663                        587 	.ds 2
      000665                        588 _ak820_tap_dance_process_record_10000_640:
      000665                        589 	.ds 2
                                    590 ;--------------------------------------------------------
                                    591 ; absolute external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XABS    (ABS,XDATA)
                                    594 ;--------------------------------------------------------
                                    595 ; initialized external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XISEG   (XDATA)
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT0 (CODE)
                                    600 	.area GSINIT1 (CODE)
                                    601 	.area GSINIT2 (CODE)
                                    602 	.area GSINIT3 (CODE)
                                    603 	.area GSINIT4 (CODE)
                                    604 	.area GSINIT5 (CODE)
                                    605 	.area GSINIT  (CODE)
                                    606 	.area GSFINAL (CODE)
                                    607 	.area CSEG    (CODE)
                                    608 ;--------------------------------------------------------
                                    609 ; global & static initialisations
                                    610 ;--------------------------------------------------------
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT  (CODE)
                                    613 	.area GSFINAL (CODE)
                                    614 	.area GSINIT  (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; Home
                                    617 ;--------------------------------------------------------
                                    618 	.area HOME    (CODE)
                                    619 	.area HOME    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; code
                                    622 ;--------------------------------------------------------
                                    623 	.area CSEG    (CODE)
                                    624 ;------------------------------------------------------------
                                    625 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    626 ;------------------------------------------------------------
                                    627 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    628 ;------------------------------------------------------------
                                    629 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    630 ;	-----------------------------------------
                           000007   631 	ar7 = 0x07
                           000006   632 	ar6 = 0x06
                           000005   633 	ar5 = 0x05
                           000004   634 	ar4 = 0x04
                           000003   635 	ar3 = 0x03
                           000002   636 	ar2 = 0x02
                           000001   637 	ar1 = 0x01
                           000000   638 	ar0 = 0x00
                                    639 ;	 function ak820_tap_dance_valid
                                    640 ;	-----------------------------------------
      00438F                        641 _ak820_tap_dance_valid:
      00438F 12 38 81         [24]  642 	lcall	_ak820_outline_0111
      004392 90 06 57         [24]  643 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      004395 12 38 86         [24]  644 	lcall	_ak820_outline_0112
                                    645 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:24: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)entry;
      004398 90 06 57         [24]  646 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      00439B 12 38 2D         [24]  647 	lcall	_ak820_outline_0058
                                    648 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:25: if (bytes[9] & 128) return false;
      00439E 74 09            [12]  649 	mov	a,#0x09
      0043A0 12 38 1D         [24]  650 	lcall	_ak820_outline_0026
      0043A3 E0               [24]  651 	movx	a,@dptr
      0043A4 30 E7 04         [24]  652 	jnb	acc.7,00130$
      0043A7 75 82 00         [24]  653 	mov	dpl, #0x00
                                    654 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      0043AA 22               [24]  655 	ret
      0043AB                        656 00130$:
      0043AB 7D 00            [12]  657 	mov	r5,#0x00
      0043AD                        658 00114$:
      0043AD BD 04 00         [24]  659 	cjne	r5,#0x04,00167$
      0043B0                        660 00167$:
      0043B0 50 38            [24]  661 	jnc	00112$
                                    662 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: uint8_t basic = bytes[0], mods = bytes[1];
      0043B2 12 38 69         [24]  663 	lcall	_ak820_outline_0103
      0043B5 FC               [12]  664 	mov	r4,a
      0043B6 90 06 59         [24]  665 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      0043B9 12 43 46         [24]  666 	lcall	_ak820_outline_0071
      0043BC A3               [24]  667 	inc	dptr
      0043BD E0               [24]  668 	movx	a,@dptr
                                    669 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: if (!(basic | mods)) continue;
      0043BE FB               [12]  670 	mov	r3,a
      0043BF 4C               [12]  671 	orl	a,r4
      0043C0 60 22            [24]  672 	jz	00111$
                                    673 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: if (mods >= 32 || !((basic >= KC_A && basic <= KC_EXSEL) ||
      0043C2 BB 20 00         [24]  674 	cjne	r3,#0x20,00170$
      0043C5                        675 00170$:
      0043C5 50 19            [24]  676 	jnc	00105$
      0043C7 BC 04 00         [24]  677 	cjne	r4,#0x04,00172$
      0043CA                        678 00172$:
      0043CA 40 05            [24]  679 	jc	00109$
      0043CC EC               [12]  680 	mov	a,r4
      0043CD 24 5B            [12]  681 	add	a,#0xff - 0xa4
      0043CF 50 13            [24]  682 	jnc	00111$
                                    683 ;	free result
      0043D1                        684 00109$:
                                    685 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:30: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI))) return false;
      0043D1 90 06 59         [24]  686 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      0043D4 E0               [24]  687 	movx	a,@dptr
      0043D5 FC               [12]  688 	mov	r4,a
      0043D6 BC E0 00         [24]  689 	cjne	r4,#0xe0,00175$
      0043D9                        690 00175$:
      0043D9 40 05            [24]  691 	jc	00105$
      0043DB EC               [12]  692 	mov	a,r4
      0043DC 24 18            [12]  693 	add	a,#0xff - 0xe7
      0043DE 50 04            [24]  694 	jnc	00111$
                                    695 ;	free result
      0043E0                        696 00105$:
      0043E0 75 82 00         [24]  697 	mov	dpl, #0x00
      0043E3 22               [24]  698 	ret
      0043E4                        699 00111$:
                                    700 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      0043E4 0D               [12]  701 	inc	r5
      0043E5 12 49 20         [24]  702 	lcall	_ak820_outline_0126
      0043E8 80 C3            [24]  703 	sjmp	00114$
      0043EA                        704 00112$:
                                    705 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:32: return true;
      0043EA 75 82 01         [24]  706 	mov	dpl, #0x01
                                    707 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:33: }
      0043ED 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'td_emit'
                                    711 ;------------------------------------------------------------
                                    712 ;pressed       Allocated with name '_td_emit_pressed_10000_601'
                                    713 ;------------------------------------------------------------
                                    714 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:36: static void td_emit(bool pressed) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function td_emit
                                    717 ;	-----------------------------------------
      0043EE                        718 _td_emit:
      0043EE E5 82            [12]  719 	mov	a,dpl
      0043F0 90 06 5A         [24]  720 	mov	dptr,#_td_emit_pressed_10000_601
      0043F3 F0               [24]  721 	movx	@dptr,a
                                    722 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:37: if (!td_record.keycode) return;
      0043F4 90 06 55         [24]  723 	mov	dptr,#(_td_record + 0x0007)
      0043F7 E0               [24]  724 	movx	a,@dptr
      0043F8 FE               [12]  725 	mov	r6,a
      0043F9 A3               [24]  726 	inc	dptr
      0043FA E0               [24]  727 	movx	a,@dptr
      0043FB 4E               [12]  728 	orl	a,r6
      0043FC 70 01            [24]  729 	jnz	00102$
      0043FE 22               [24]  730 	ret
      0043FF                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: td_record.event.key.row = td_work->source / MATRIX_COLS;
      0043FF 90 05 C0         [24]  733 	mov	dptr,#_td_work
      004402 12 37 ED         [24]  734 	lcall	_ak820_outline_0006
      004405 A3               [24]  735 	inc	dptr
      004406 A3               [24]  736 	inc	dptr
      004407 E0               [24]  737 	movx	a,@dptr
      004408 75 F0 08         [24]  738 	mov	b,#0x08
      00440B 84               [48]  739 	div	ab
      00440C 90 06 4F         [24]  740 	mov	dptr,#(_td_record + 0x0001)
      00440F F0               [24]  741 	movx	@dptr,a
                                    742 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: td_record.event.key.col = td_work->source % MATRIX_COLS;
      004410 90 05 C0         [24]  743 	mov	dptr,#_td_work
      004413 12 37 ED         [24]  744 	lcall	_ak820_outline_0006
      004416 A3               [24]  745 	inc	dptr
      004417 A3               [24]  746 	inc	dptr
      004418 E0               [24]  747 	movx	a,@dptr
      004419 FF               [12]  748 	mov	r7,a
      00441A 53 07 07         [24]  749 	anl	ar7,#0x07
      00441D 90 06 4E         [24]  750 	mov	dptr,#_td_record
      004420 EF               [12]  751 	mov	a,r7
      004421 F0               [24]  752 	movx	@dptr,a
                                    753 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: td_record.event.type = KEY_EVENT;
      004422 90 06 52         [24]  754 	mov	dptr,#(_td_record + 0x0004)
      004425 74 01            [12]  755 	mov	a,#0x01
      004427 F0               [24]  756 	movx	@dptr,a
                                    757 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: td_record.event.time = td_time;
      004428 90 05 CC         [24]  758 	mov	dptr,#_td_time
      00442B 12 38 2D         [24]  759 	lcall	_ak820_outline_0058
      00442E 90 06 50         [24]  760 	mov	dptr,#(_td_record + 0x0002)
      004431 12 49 1A         [24]  761 	lcall	_ak820_outline_0064
                                    762 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:42: td_record.event.pressed = pressed;
      004434 90 06 5A         [24]  763 	mov	dptr,#_td_emit_pressed_10000_601
      004437 E0               [24]  764 	movx	a,@dptr
      004438 90 06 53         [24]  765 	mov	dptr,#(_td_record + 0x0005)
      00443B F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: td_record.tap.count = 1;
      00443C 90 06 54         [24]  768 	mov	dptr,#(_td_record + 0x0006)
      00443F E0               [24]  769 	movx	a,@dptr
      004440 54 0F            [12]  770 	anl	a,#0x0f
      004442 44 10            [12]  771 	orl	a,#0x10
      004444 F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: process_record(&td_record);
      004445 90 06 4E         [24]  774 	mov	dptr,#_td_record
      004448 75 F0 00         [24]  775 	mov	b, #0x00
                                    776 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:45: }
      00444B 02 75 E1         [24]  777 	ljmp	_process_record
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'td_finish'
                                    780 ;------------------------------------------------------------
                                    781 ;interrupted   Allocated with name '_td_finish_interrupted_10000_604'
                                    782 ;choice        Allocated with name '_td_finish_choice_10000_605'
                                    783 ;state         Allocated with name '_td_finish_state_10000_605'
                                    784 ;extra         Allocated with name '_td_finish_extra_10000_605'
                                    785 ;------------------------------------------------------------
                                    786 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:46: static void td_finish(bool interrupted) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function td_finish
                                    789 ;	-----------------------------------------
      00444E                        790 _td_finish:
      00444E E5 82            [12]  791 	mov	a,dpl
      004450 90 06 5B         [24]  792 	mov	dptr,#_td_finish_interrupted_10000_604
      004453 F0               [24]  793 	movx	@dptr,a
                                    794 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: uint8_t choice = 0, state;
      004454 90 06 5C         [24]  795 	mov	dptr,#_td_finish_choice_10000_605
      004457 E4               [12]  796 	clr	a
      004458 F0               [24]  797 	movx	@dptr,a
                                    798 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: bool extra = false;
      004459 90 06 5E         [24]  799 	mov	dptr,#_td_finish_extra_10000_605
      00445C F0               [24]  800 	movx	@dptr,a
                                    801 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: if (!td_wait) return;
      00445D 90 05 BE         [24]  802 	mov	dptr,#_td_wait
      004460 12 38 2D         [24]  803 	lcall	_ak820_outline_0058
      004463 90 05 BE         [24]  804 	mov	dptr,#_td_wait
      004466 12 48 E2         [24]  805 	lcall	_ak820_outline_0038
      004469 70 01            [24]  806 	jnz	00102$
      00446B 22               [24]  807 	ret
      00446C                        808 00102$:
                                    809 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:50: td_work = td_wait;
      00446C 90 05 C0         [24]  810 	mov	dptr,#_td_work
      00446F 12 49 1A         [24]  811 	lcall	_ak820_outline_0064
                                    812 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: td_wait = 0;
      004472 90 05 BE         [24]  813 	mov	dptr,#_td_wait
      004475 12 49 28         [24]  814 	lcall	_ak820_outline_0150
                                    815 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: state = td_work->state;
      004478 12 48 F2         [24]  816 	lcall	_ak820_outline_0044
      00447B FD               [12]  817 	mov	r5,a
      00447C 90 06 5D         [24]  818 	mov	dptr,#_td_finish_state_10000_605
      00447F F0               [24]  819 	movx	@dptr,a
                                    820 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: td_work->state = state | TD_DONE;
      004480 43 05 08         [24]  821 	orl	ar5,#0x08
      004483 12 38 92         [24]  822 	lcall	_ak820_outline_0124
      004486 ED               [12]  823 	mov	a,r5
      004487 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: if ((state & 3) == 1) {
      004488 90 06 5D         [24]  826 	mov	dptr,#_td_finish_state_10000_605
      00448B E0               [24]  827 	movx	a,@dptr
      00448C FF               [12]  828 	mov	r7,a
      00448D FE               [12]  829 	mov	r6,a
      00448E 53 06 03         [24]  830 	anl	ar6,#0x03
      004491 BE 01 12         [24]  831 	cjne	r6,#0x01,00110$
                                    832 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: if ((state & TD_DOWN) && !interrupted) choice = 1;
      004494 EF               [12]  833 	mov	a,r7
      004495 30 E2 2B         [24]  834 	jnb	acc.2,00111$
      004498 90 06 5B         [24]  835 	mov	dptr,#_td_finish_interrupted_10000_604
      00449B E0               [24]  836 	movx	a,@dptr
      00449C 70 25            [24]  837 	jnz	00111$
      00449E 90 06 5C         [24]  838 	mov	dptr,#_td_finish_choice_10000_605
      0044A1 74 01            [12]  839 	mov	a,#0x01
      0044A3 F0               [24]  840 	movx	@dptr,a
      0044A4 80 1D            [24]  841 	sjmp	00111$
      0044A6                        842 00110$:
                                    843 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: } else if (interrupted) extra = true;
      0044A6 90 06 5B         [24]  844 	mov	dptr,#_td_finish_interrupted_10000_604
      0044A9 E0               [24]  845 	movx	a,@dptr
      0044AA 60 08            [24]  846 	jz	00107$
      0044AC 90 06 5E         [24]  847 	mov	dptr,#_td_finish_extra_10000_605
      0044AF 74 01            [12]  848 	mov	a,#0x01
      0044B1 F0               [24]  849 	movx	@dptr,a
      0044B2 80 0F            [24]  850 	sjmp	00111$
      0044B4                        851 00107$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: else choice = (state & TD_DOWN) ? 3 : 2;
      0044B4 EF               [12]  853 	mov	a,r7
      0044B5 30 E2 04         [24]  854 	jnb	acc.2,00128$
      0044B8 7F 03            [12]  855 	mov	r7,#0x03
      0044BA 80 02            [24]  856 	sjmp	00129$
      0044BC                        857 00128$:
      0044BC 7F 02            [12]  858 	mov	r7,#0x02
      0044BE                        859 00129$:
      0044BE 90 06 5C         [24]  860 	mov	dptr,#_td_finish_choice_10000_605
      0044C1 EF               [12]  861 	mov	a,r7
      0044C2 F0               [24]  862 	movx	@dptr,a
      0044C3                        863 00111$:
                                    864 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: td_work->output = ((uint16_t AK820_STATE_MEM *)&td_entry)[choice];
      0044C3 90 05 C0         [24]  865 	mov	dptr,#_td_work
      0044C6 12 38 2D         [24]  866 	lcall	_ak820_outline_0058
      0044C9 90 06 5C         [24]  867 	mov	dptr,#_td_finish_choice_10000_605
      0044CC E0               [24]  868 	movx	a,@dptr
      0044CD FD               [12]  869 	mov	r5,a
      0044CE 75 F0 02         [24]  870 	mov	b,#0x02
      0044D1 A4               [48]  871 	mul	ab
      0044D2 24 C2            [12]  872 	add	a, #_td_entry
      0044D4 F5 82            [12]  873 	mov	dpl,a
      0044D6 74 05            [12]  874 	mov	a,#(_td_entry >> 8)
      0044D8 35 F0            [12]  875 	addc	a, b
      0044DA F5 83            [12]  876 	mov	dph,a
      0044DC 12 38 7B         [24]  877 	lcall	_ak820_outline_0107
      0044DF 12 38 92         [24]  878 	lcall	_ak820_outline_0124
      0044E2 12 38 56         [24]  879 	lcall	_ak820_outline_0084
                                    880 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: if (!td_work->output) {
      0044E5 90 05 C0         [24]  881 	mov	dptr,#_td_work
      0044E8 12 37 ED         [24]  882 	lcall	_ak820_outline_0006
      0044EB 12 49 3A         [24]  883 	lcall	_ak820_outline_0176
      0044EE 70 28            [24]  884 	jnz	00115$
                                    885 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:60: if (choice >= 2) extra = true;
      0044F0 BD 02 00         [24]  886 	cjne	r5,#0x02,00247$
      0044F3                        887 00247$:
      0044F3 40 06            [24]  888 	jc	00113$
      0044F5 90 06 5E         [24]  889 	mov	dptr,#_td_finish_extra_10000_605
      0044F8 74 01            [12]  890 	mov	a,#0x01
      0044FA F0               [24]  891 	movx	@dptr,a
      0044FB                        892 00113$:
                                    893 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: td_work->output = choice == 3 && td_entry.on_hold ? td_entry.on_hold : td_entry.on_tap;
      0044FB 90 06 5C         [24]  894 	mov	dptr,#_td_finish_choice_10000_605
      0044FE E0               [24]  895 	movx	a,@dptr
      0044FF FD               [12]  896 	mov	r5,a
      004500 BD 03 09         [24]  897 	cjne	r5,#0x03,00130$
      004503 90 05 C4         [24]  898 	mov	dptr,#(_td_entry + 0x0002)
      004506 12 38 44         [24]  899 	lcall	_ak820_outline_0065
      004509 4C               [12]  900 	orl	a,r4
      00450A 70 06            [24]  901 	jnz	00131$
      00450C                        902 00130$:
      00450C 90 05 C2         [24]  903 	mov	dptr,#_td_entry
      00450F 12 38 44         [24]  904 	lcall	_ak820_outline_0065
      004512                        905 00131$:
      004512 12 38 92         [24]  906 	lcall	_ak820_outline_0124
      004515 12 38 50         [24]  907 	lcall	_ak820_outline_0078
      004518                        908 00115$:
                                    909 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:63: if (extra) {
      004518 90 06 5E         [24]  910 	mov	dptr,#_td_finish_extra_10000_605
      00451B E0               [24]  911 	movx	a,@dptr
      00451C 60 18            [24]  912 	jz	00119$
                                    913 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:64: td_record.keycode = td_entry.on_tap;
      00451E 90 05 C2         [24]  914 	mov	dptr,#_td_entry
      004521 12 48 D4         [24]  915 	lcall	_ak820_outline_0034
                                    916 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:65: td_emit(true);
      004524 75 82 01         [24]  917 	mov	dpl, #0x01
      004527 12 43 EE         [24]  918 	lcall	_td_emit
                                    919 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:66: if (!td_work->state) return;
      00452A 12 48 F2         [24]  920 	lcall	_ak820_outline_0044
      00452D 70 01            [24]  921 	jnz	00117$
      00452F 22               [24]  922 	ret
      004530                        923 00117$:
                                    924 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:67: td_emit(false);
      004530 75 82 00         [24]  925 	mov	dpl, #0x00
      004533 12 43 EE         [24]  926 	lcall	_td_emit
      004536                        927 00119$:
                                    928 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: if (!td_work->state) return;
      004536 90 05 C0         [24]  929 	mov	dptr,#_td_work
      004539 12 38 2D         [24]  930 	lcall	_ak820_outline_0058
      00453C 74 03            [12]  931 	mov	a,#0x03
      00453E 12 48 AC         [24]  932 	lcall	_ak820_outline_0013
      004541 70 01            [24]  933 	jnz	00121$
      004543 22               [24]  934 	ret
      004544                        935 00121$:
                                    936 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:70: td_record.keycode = td_work->output;
      004544 12 38 92         [24]  937 	lcall	_ak820_outline_0124
      004547 12 48 D4         [24]  938 	lcall	_ak820_outline_0034
                                    939 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: td_emit(true);
      00454A 75 82 01         [24]  940 	mov	dpl, #0x01
      00454D 12 43 EE         [24]  941 	lcall	_td_emit
                                    942 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:72: if (!td_work->state) return;
      004550 90 05 C0         [24]  943 	mov	dptr,#_td_work
      004553 12 37 ED         [24]  944 	lcall	_ak820_outline_0006
      004556 A3               [24]  945 	inc	dptr
      004557 A3               [24]  946 	inc	dptr
      004558 A3               [24]  947 	inc	dptr
      004559 E0               [24]  948 	movx	a,@dptr
      00455A FF               [12]  949 	mov	r7,a
      00455B 70 01            [24]  950 	jnz	00123$
      00455D 22               [24]  951 	ret
      00455E                        952 00123$:
                                    953 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: if (!(td_work->state & TD_DOWN)) { td_emit(false); td_work->state = 0; }
      00455E EF               [12]  954 	mov	a,r7
      00455F 20 E2 11         [24]  955 	jb	acc.2,00126$
      004562 75 82 00         [24]  956 	mov	dpl, #0x00
      004565 12 43 EE         [24]  957 	lcall	_td_emit
      004568 90 05 C0         [24]  958 	mov	dptr,#_td_work
      00456B 12 37 ED         [24]  959 	lcall	_ak820_outline_0006
      00456E A3               [24]  960 	inc	dptr
      00456F A3               [24]  961 	inc	dptr
      004570 A3               [24]  962 	inc	dptr
      004571 E4               [12]  963 	clr	a
      004572 F0               [24]  964 	movx	@dptr,a
      004573                        965 00126$:
                                    966 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: }
      004573 22               [24]  967 	ret
                                    968 ;------------------------------------------------------------
                                    969 ;Allocation info for local variables in function 'ak820_tap_dance_task'
                                    970 ;------------------------------------------------------------
                                    971 ;now           Allocated with name '_ak820_tap_dance_task_now_10000_621'
                                    972 ;term          Allocated with name '_ak820_tap_dance_task_term_10000_622'
                                    973 ;------------------------------------------------------------
                                    974 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:75: void ak820_tap_dance_task(uint16_t now) {
                                    975 ;	-----------------------------------------
                                    976 ;	 function ak820_tap_dance_task
                                    977 ;	-----------------------------------------
      004574                        978 _ak820_tap_dance_task:
      004574 12 38 81         [24]  979 	lcall	_ak820_outline_0111
      004577 90 06 5F         [24]  980 	mov	dptr,#_ak820_tap_dance_task_now_10000_621
      00457A 12 38 86         [24]  981 	lcall	_ak820_outline_0112
                                    982 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:76: uint16_t term = td_entry.custom_tapping_term;
      00457D 90 05 CA         [24]  983 	mov	dptr,#(_td_entry + 0x0008)
      004580 12 38 2D         [24]  984 	lcall	_ak820_outline_0058
      004583 90 06 61         [24]  985 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004586 12 49 1A         [24]  986 	lcall	_ak820_outline_0064
                                    987 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:77: if (!term) term = 200;
      004589 EE               [12]  988 	mov	a,r6
      00458A 4F               [12]  989 	orl	a,r7
      00458B 70 08            [24]  990 	jnz	00102$
      00458D 90 06 61         [24]  991 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004590 74 C8            [12]  992 	mov	a,#0xc8
      004592 12 38 A8         [24]  993 	lcall	_ak820_outline_0133
      004595                        994 00102$:
                                    995 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:78: if (td_wait && (uint16_t)(now - td_time) >= term) td_finish(false);
      004595 90 05 BE         [24]  996 	mov	dptr,#_td_wait
      004598 12 48 E2         [24]  997 	lcall	_ak820_outline_0038
      00459B 60 26            [24]  998 	jz	00106$
      00459D 90 05 CC         [24]  999 	mov	dptr,#_td_time
      0045A0 12 38 2D         [24] 1000 	lcall	_ak820_outline_0058
      0045A3 90 06 5F         [24] 1001 	mov	dptr,#_ak820_tap_dance_task_now_10000_621
      0045A6 12 38 44         [24] 1002 	lcall	_ak820_outline_0065
      0045A9 EC               [12] 1003 	mov	a,r4
      0045AA C3               [12] 1004 	clr	c
      0045AB 9E               [12] 1005 	subb	a,r6
      0045AC FE               [12] 1006 	mov	r6,a
      0045AD ED               [12] 1007 	mov	a,r5
      0045AE 9F               [12] 1008 	subb	a,r7
      0045AF FF               [12] 1009 	mov	r7,a
      0045B0 90 06 61         [24] 1010 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      0045B3 12 38 44         [24] 1011 	lcall	_ak820_outline_0065
      0045B6 C3               [12] 1012 	clr	c
      0045B7 EE               [12] 1013 	mov	a,r6
      0045B8 9C               [12] 1014 	subb	a,r4
      0045B9 EF               [12] 1015 	mov	a,r7
      0045BA 9D               [12] 1016 	subb	a,r5
      0045BB 40 06            [24] 1017 	jc	00106$
      0045BD 75 82 00         [24] 1018 	mov	dpl, #0x00
                                   1019 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: }
      0045C0 02 44 4E         [24] 1020 	ljmp	_td_finish
      0045C3                       1021 00106$:
      0045C3 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'ak820_tap_dance_before'
                                   1025 ;------------------------------------------------------------
                                   1026 ;event         Allocated with name '_ak820_tap_dance_before_event_10000_625'
                                   1027 ;id            Allocated with name '_ak820_tap_dance_before_id_10000_626'
                                   1028 ;index         Allocated with name '_ak820_tap_dance_before_index_10000_626'
                                   1029 ;slot          Allocated with name '_ak820_tap_dance_before_slot_10000_626'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function ak820_tap_dance_before
                                   1034 ;	-----------------------------------------
      0045C4                       1035 _ak820_tap_dance_before:
      0045C4 12 38 81         [24] 1036 	lcall	_ak820_outline_0111
      0045C7 90 06 63         [24] 1037 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      0045CA 12 38 86         [24] 1038 	lcall	_ak820_outline_0112
                                   1039 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: ak820_tap_dance_task(event->time);
      0045CD 90 06 63         [24] 1040 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      0045D0 12 37 ED         [24] 1041 	lcall	_ak820_outline_0006
      0045D3 A3               [24] 1042 	inc	dptr
      0045D4 A3               [24] 1043 	inc	dptr
      0045D5 12 38 44         [24] 1044 	lcall	_ak820_outline_0065
      0045D8 12 38 A3         [24] 1045 	lcall	_ak820_outline_0132
      0045DB C0 07            [24] 1046 	push	ar7
      0045DD C0 06            [24] 1047 	push	ar6
      0045DF 12 45 74         [24] 1048 	lcall	_ak820_tap_dance_task
      0045E2 D0 06            [24] 1049 	pop	ar6
      0045E4 D0 07            [24] 1050 	pop	ar7
                                   1051 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:84: if (IS_NOEVENT(*event)) return true;
      0045E6 74 04            [12] 1052 	mov	a,#0x04
      0045E8 12 48 AC         [24] 1053 	lcall	_ak820_outline_0013
      0045EB 70 04            [24] 1054 	jnz	00102$
      0045ED 75 82 01         [24] 1055 	mov	dpl, #0x01
      0045F0 22               [24] 1056 	ret
      0045F1                       1057 00102$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:85: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
      0045F1 12 38 8B         [24] 1059 	lcall	_ak820_outline_0117
      0045F4 FD               [12] 1060 	mov	r5,a
      0045F5 BD 10 00         [24] 1061 	cjne	r5,#0x10,00211$
      0045F8                       1062 00211$:
      0045F8 50 09            [24] 1063 	jnc	00105$
      0045FA 12 38 69         [24] 1064 	lcall	_ak820_outline_0103
      0045FD FC               [12] 1065 	mov	r4,a
      0045FE BC 08 00         [24] 1066 	cjne	r4,#0x08,00213$
      004601                       1067 00213$:
      004601 40 1D            [24] 1068 	jc	00106$
      004603                       1069 00105$:
                                   1070 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:86: if (event->pressed) td_finish(true);
      004603 90 06 63         [24] 1071 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      004606 12 43 4C         [24] 1072 	lcall	_ak820_outline_0083
      004609 74 05            [12] 1073 	mov	a,#0x05
      00460B 2A               [12] 1074 	add	a, r2
      00460C FA               [12] 1075 	mov	r2,a
      00460D E4               [12] 1076 	clr	a
      00460E 3B               [12] 1077 	addc	a, r3
      00460F FB               [12] 1078 	mov	r3,a
      004610 12 38 AD         [24] 1079 	lcall	_ak820_outline_0134
      004613 E0               [24] 1080 	movx	a,@dptr
      004614 60 06            [24] 1081 	jz	00104$
      004616 75 82 01         [24] 1082 	mov	dpl, #0x01
      004619 12 44 4E         [24] 1083 	lcall	_td_finish
      00461C                       1084 00104$:
                                   1085 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:87: return true;
      00461C 75 82 01         [24] 1086 	mov	dpl, #0x01
      00461F 22               [24] 1087 	ret
      004620                       1088 00106$:
                                   1089 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: id = event->key.row * MATRIX_COLS + event->key.col;
      004620 ED               [12] 1090 	mov	a,r5
      004621 12 38 C2         [24] 1091 	lcall	_ak820_outline_0179
                                   1092 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: index = td_map[id];
      004624 2C               [12] 1093 	add	a,r4
      004625 FD               [12] 1094 	mov	r5,a
      004626 24 CE            [12] 1095 	add	a, #_td_map
      004628 FB               [12] 1096 	mov	r3,a
      004629 E4               [12] 1097 	clr	a
      00462A 34 05            [12] 1098 	addc	a, #(_td_map >> 8)
      00462C 12 49 07         [24] 1099 	lcall	_ak820_outline_0052
                                   1100 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: if (index == TD_NONE) {
      00462F BA FF 13         [24] 1101 	cjne	r2,#0xff,00111$
                                   1102 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:92: if (!event->pressed) td_map[id] = 0;
      004632 74 05            [12] 1103 	mov	a,#0x05
      004634 2E               [12] 1104 	add	a, r6
      004635 F8               [12] 1105 	mov	r0,a
      004636 E4               [12] 1106 	clr	a
      004637 3F               [12] 1107 	addc	a, r7
      004638 F9               [12] 1108 	mov	r1,a
      004639 12 38 9D         [24] 1109 	lcall	_ak820_outline_0129
      00463C 70 03            [24] 1110 	jnz	00109$
      00463E 12 38 62         [24] 1111 	lcall	_ak820_outline_0098
      004641                       1112 00109$:
                                   1113 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: return false;
      004641 75 82 00         [24] 1114 	mov	dpl, #0x00
      004644 22               [24] 1115 	ret
      004645                       1116 00111$:
                                   1117 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:95: if (event->pressed && td_wait && (td_wait->source != id || (td_wait->state & 3) == 2)) td_finish(true);
      004645 12 37 E0         [24] 1118 	lcall	_ak820_outline_0005
      004648 60 27            [24] 1119 	jz	00113$
      00464A 90 05 BE         [24] 1120 	mov	dptr,#_td_wait
      00464D 12 38 2D         [24] 1121 	lcall	_ak820_outline_0058
      004650 4E               [12] 1122 	orl	a,r6
      004651 60 1E            [24] 1123 	jz	00113$
      004653 12 38 25         [24] 1124 	lcall	_ak820_outline_0035
      004656 B5 05 0A         [24] 1125 	cjne	a,ar5,00112$
      004659 12 48 B7         [24] 1126 	lcall	_ak820_outline_0018
      00465C FF               [12] 1127 	mov	r7,a
      00465D 53 07 03         [24] 1128 	anl	ar7,#0x03
      004660 BF 02 0E         [24] 1129 	cjne	r7,#0x02,00113$
      004663                       1130 00112$:
      004663 75 82 01         [24] 1131 	mov	dpl, #0x01
      004666 C0 05            [24] 1132 	push	ar5
      004668 C0 02            [24] 1133 	push	ar2
      00466A 12 44 4E         [24] 1134 	lcall	_td_finish
      00466D D0 02            [24] 1135 	pop	ar2
      00466F D0 05            [24] 1136 	pop	ar5
      004671                       1137 00113$:
                                   1138 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:96: slot = td_slots + index;
      004671 EA               [12] 1139 	mov	a,r2
      004672 12 38 CC         [24] 1140 	lcall	_ak820_outline_0195
      004675 24 9E            [12] 1141 	add	a, #_td_slots
      004677 FE               [12] 1142 	mov	r6,a
      004678 74 05            [12] 1143 	mov	a,#(_td_slots >> 8)
      00467A 35 F0            [12] 1144 	addc	a, b
      00467C FF               [12] 1145 	mov	r7,a
                                   1146 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:97: if (slot->state && slot->source == id) {
      00467D 74 03            [12] 1147 	mov	a,#0x03
      00467F 12 48 A1         [24] 1148 	lcall	_ak820_outline_0012
      004682 FA               [12] 1149 	mov	r2,a
      004683 60 57            [24] 1150 	jz	00122$
      004685 12 38 25         [24] 1151 	lcall	_ak820_outline_0035
      004688 B5 05 51         [24] 1152 	cjne	a,ar5,00122$
                                   1153 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: if (event->pressed) return !(slot->state & TD_DONE);
      00468B 90 06 63         [24] 1154 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      00468E E0               [24] 1155 	movx	a,@dptr
      00468F F9               [12] 1156 	mov	r1,a
      004690 A3               [24] 1157 	inc	dptr
      004691 E0               [24] 1158 	movx	a,@dptr
      004692 FD               [12] 1159 	mov	r5,a
      004693 74 05            [12] 1160 	mov	a,#0x05
      004695 29               [12] 1161 	add	a, r1
      004696 F9               [12] 1162 	mov	r1,a
      004697 E4               [12] 1163 	clr	a
      004698 3D               [12] 1164 	addc	a, r5
      004699 FD               [12] 1165 	mov	r5,a
      00469A 89 82            [24] 1166 	mov	dpl,r1
      00469C 8D 83            [24] 1167 	mov	dph,r5
      00469E E0               [24] 1168 	movx	a,@dptr
      00469F 60 0E            [24] 1169 	jz	00118$
      0046A1 EA               [12] 1170 	mov	a,r2
      0046A2 A2 E3            [12] 1171 	mov	c,acc.3
      0046A4 E4               [12] 1172 	clr	a
      0046A5 33               [12] 1173 	rlc	a
      0046A6 B4 01 00         [24] 1174 	cjne	a,#0x01,00229$
      0046A9                       1175 00229$:
      0046A9 92 0E            [24] 1176 	mov  _ak820_tap_dance_before_sloc0_1_0,c
      0046AB 12 38 B7         [24] 1177 	lcall	_ak820_outline_0151
      0046AE 22               [24] 1178 	ret
      0046AF                       1179 00118$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:99: slot->state &= ~TD_DOWN;
      0046AF 53 02 FB         [24] 1181 	anl	ar2,#0xfb
      0046B2 12 33 FC         [24] 1182 	lcall	_ak820_outline_0131
      0046B5 EA               [12] 1183 	mov	a,r2
      0046B6 F0               [24] 1184 	movx	@dptr,a
                                   1185 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: if (slot->state & TD_DONE) {
      0046B7 EA               [12] 1186 	mov	a,r2
      0046B8 30 E3 1D         [24] 1187 	jnb	acc.3,00120$
                                   1188 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:101: td_work = slot;
      0046BB 90 05 C0         [24] 1189 	mov	dptr,#_td_work
      0046BE 12 49 1A         [24] 1190 	lcall	_ak820_outline_0064
                                   1191 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: td_record.keycode = slot->output;
      0046C1 12 38 92         [24] 1192 	lcall	_ak820_outline_0124
      0046C4 12 48 D4         [24] 1193 	lcall	_ak820_outline_0034
                                   1194 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: td_emit(false);
      0046C7 75 82 00         [24] 1195 	mov	dpl, #0x00
      0046CA C0 04            [24] 1196 	push	ar4
      0046CC C0 03            [24] 1197 	push	ar3
      0046CE 12 43 EE         [24] 1198 	lcall	_td_emit
      0046D1 D0 03            [24] 1199 	pop	ar3
      0046D3 D0 04            [24] 1200 	pop	ar4
                                   1201 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: slot->state = 0;
      0046D5 12 38 62         [24] 1202 	lcall	_ak820_outline_0098
      0046D8                       1203 00120$:
                                   1204 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:106: return false;
      0046D8 75 82 00         [24] 1205 	mov	dpl, #0x00
      0046DB 22               [24] 1206 	ret
      0046DC                       1207 00122$:
                                   1208 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: return true;
      0046DC 75 82 01         [24] 1209 	mov	dpl, #0x01
                                   1210 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:109: }
      0046DF 22               [24] 1211 	ret
                                   1212 ;------------------------------------------------------------
                                   1213 ;Allocation info for local variables in function 'ak820_tap_dance_process'
                                   1214 ;------------------------------------------------------------
                                   1215 ;sloc0         Allocated with name '_ak820_tap_dance_process_sloc0_1_0'
                                   1216 ;record        Allocated with name '_ak820_tap_dance_process_record_10000_640'
                                   1217 ;index         Allocated with name '_ak820_tap_dance_process_index_10000_641'
                                   1218 ;id            Allocated with name '_ak820_tap_dance_process_id_10000_641'
                                   1219 ;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_641'
                                   1220 ;dance         Allocated with name '_ak820_tap_dance_process_dance_10000_641'
                                   1221 ;------------------------------------------------------------
                                   1222 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1223 ;	-----------------------------------------
                                   1224 ;	 function ak820_tap_dance_process
                                   1225 ;	-----------------------------------------
      0046E0                       1226 _ak820_tap_dance_process:
      0046E0 12 38 81         [24] 1227 	lcall	_ak820_outline_0111
      0046E3 90 06 65         [24] 1228 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      0046E6 12 38 86         [24] 1229 	lcall	_ak820_outline_0112
                                   1230 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:113: bool dance = (record->keycode >> 8) == (QK_TAP_DANCE >> 8);
      0046E9 90 06 65         [24] 1231 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      0046EC 12 38 2D         [24] 1232 	lcall	_ak820_outline_0058
      0046EF 74 07            [12] 1233 	mov	a,#0x07
      0046F1 12 48 AC         [24] 1234 	lcall	_ak820_outline_0013
      0046F4 A3               [24] 1235 	inc	dptr
      0046F5 E0               [24] 1236 	movx	a,@dptr
      0046F6 FA               [12] 1237 	mov	r2,a
      0046F7 E4               [12] 1238 	clr	a
      0046F8 FB               [12] 1239 	mov	r3,a
      0046F9 BA 57 04         [24] 1240 	cjne	r2,#0x57,00233$
      0046FC BB 00 01         [24] 1241 	cjne	r3,#0x00,00233$
      0046FF 04               [12] 1242 	inc	a
      004700                       1243 00233$:
      004700 F5 15            [12] 1244 	mov	_ak820_tap_dance_process_sloc0_1_0,a
                                   1245 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: if (record->event.type != KEY_EVENT || record->event.key.row >= MATRIX_ROWS ||
      004702 12 48 CB         [24] 1246 	lcall	_ak820_outline_0022
      004705 E0               [24] 1247 	movx	a,@dptr
      004706 FB               [12] 1248 	mov	r3,a
      004707 BB 01 52         [24] 1249 	cjne	r3,#0x01,00101$
      00470A 74 01            [12] 1250 	mov	a,#0x01
      00470C 12 48 C0         [24] 1251 	lcall	_ak820_outline_0021
      00470F F9               [12] 1252 	mov	r1,a
      004710 B9 10 00         [24] 1253 	cjne	r1,#0x10,00237$
      004713                       1254 00237$:
      004713 50 47            [24] 1255 	jnc	00101$
                                   1256 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:115: record->event.key.col >= MATRIX_COLS || get_repeat_key_count() || ak820_macro_primitive ||
      004715 C0 02            [24] 1257 	push	ar2
      004717 C0 03            [24] 1258 	push	ar3
      004719 8E 00            [24] 1259 	mov	ar0,r6
      00471B 8F 01            [24] 1260 	mov	ar1,r7
      00471D 12 38 9D         [24] 1261 	lcall	_ak820_outline_0129
      004720 FB               [12] 1262 	mov	r3,a
      004721 BB 08 00         [24] 1263 	cjne	r3,#0x08,00239$
      004724                       1264 00239$:
      004724 D0 03            [24] 1265 	pop	ar3
      004726 D0 02            [24] 1266 	pop	ar2
      004728 50 32            [24] 1267 	jnc	00101$
      00472A C0 07            [24] 1268 	push	ar7
      00472C C0 06            [24] 1269 	push	ar6
      00472E C0 05            [24] 1270 	push	ar5
      004730 C0 04            [24] 1271 	push	ar4
      004732 C0 03            [24] 1272 	push	ar3
      004734 C0 02            [24] 1273 	push	ar2
      004736 C0 01            [24] 1274 	push	ar1
      004738 C0 00            [24] 1275 	push	ar0
      00473A 12 A7 C3         [24] 1276 	lcall	_get_repeat_key_count
      00473D E5 82            [12] 1277 	mov	a, dpl
      00473F D0 00            [24] 1278 	pop	ar0
      004741 D0 01            [24] 1279 	pop	ar1
      004743 D0 02            [24] 1280 	pop	ar2
      004745 D0 03            [24] 1281 	pop	ar3
      004747 D0 04            [24] 1282 	pop	ar4
      004749 D0 05            [24] 1283 	pop	ar5
      00474B D0 06            [24] 1284 	pop	ar6
      00474D D0 07            [24] 1285 	pop	ar7
      00474F 70 0B            [24] 1286 	jnz	00101$
      004751 90 0A 4C         [24] 1287 	mov	dptr,#_ak820_macro_primitive
      004754 E0               [24] 1288 	movx	a,@dptr
      004755 70 05            [24] 1289 	jnz	00101$
                                   1290 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:116: !record->event.pressed) return !dance;
      004757 12 37 E0         [24] 1291 	lcall	_ak820_outline_0005
      00475A 70 0B            [24] 1292 	jnz	00102$
      00475C                       1293 00101$:
      00475C E5 15            [12] 1294 	mov	a,_ak820_tap_dance_process_sloc0_1_0
      00475E B4 01 00         [24] 1295 	cjne	a,#0x01,00244$
      004761                       1296 00244$:
      004761 92 0F            [24] 1297 	mov  _ak820_tap_dance_process_sloc1_1_0,c
      004763 12 38 B7         [24] 1298 	lcall	_ak820_outline_0151
      004766 22               [24] 1299 	ret
      004767                       1300 00102$:
                                   1301 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:117: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      004767 12 38 AD         [24] 1302 	lcall	_ak820_outline_0134
      00476A E0               [24] 1303 	movx	a,@dptr
      00476B 12 38 C2         [24] 1304 	lcall	_ak820_outline_0179
      00476E FA               [12] 1305 	mov	r2,a
      00476F 12 38 9D         [24] 1306 	lcall	_ak820_outline_0129
      004772 2A               [12] 1307 	add	a, r2
      004773 FF               [12] 1308 	mov	r7,a
                                   1309 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:118: index = (uint8_t)record->keycode;
      004774 12 43 52         [24] 1310 	lcall	_ak820_outline_0085
                                   1311 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: slot = td_slots + (index & 7);
      004777 FE               [12] 1312 	mov	r6,a
      004778 FC               [12] 1313 	mov	r4,a
      004779 53 04 07         [24] 1314 	anl	ar4,#0x07
      00477C 7D 00            [12] 1315 	mov	r5,#0x00
      00477E EC               [12] 1316 	mov	a,r4
      00477F 12 49 2D         [24] 1317 	lcall	_ak820_outline_0157
      004782 12 49 2D         [24] 1318 	lcall	_ak820_outline_0157
      004785 24 9E            [12] 1319 	add	a, #_td_slots
      004787 FC               [12] 1320 	mov	r4,a
      004788 ED               [12] 1321 	mov	a,r5
      004789 34 05            [12] 1322 	addc	a, #(_td_slots >> 8)
      00478B FD               [12] 1323 	mov	r5,a
                                   1324 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: if (td_wait && !(td_wait->state & TD_DOWN) && td_wait->source == id &&
      00478C 90 05 BE         [24] 1325 	mov	dptr,#_td_wait
      00478F 12 43 4C         [24] 1326 	lcall	_ak820_outline_0083
      004792 4A               [12] 1327 	orl	a,r2
      004793 60 3C            [24] 1328 	jz	00109$
      004795 12 38 AD         [24] 1329 	lcall	_ak820_outline_0134
      004798 A3               [24] 1330 	inc	dptr
      004799 A3               [24] 1331 	inc	dptr
      00479A A3               [24] 1332 	inc	dptr
      00479B E0               [24] 1333 	movx	a,@dptr
      00479C 20 E2 32         [24] 1334 	jb	acc.2,00109$
      00479F 12 38 AD         [24] 1335 	lcall	_ak820_outline_0134
      0047A2 A3               [24] 1336 	inc	dptr
      0047A3 A3               [24] 1337 	inc	dptr
      0047A4 E0               [24] 1338 	movx	a,@dptr
      0047A5 B5 07 29         [24] 1339 	cjne	a,ar7,00109$
                                   1340 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:122: (!dance || index >= VIAL_TAP_DANCE_ENTRIES || slot != td_wait)) td_finish(true);
      0047A8 E5 15            [12] 1341 	mov	a,_ak820_tap_dance_process_sloc0_1_0
      0047AA 60 0F            [24] 1342 	jz	00108$
      0047AC BE 08 00         [24] 1343 	cjne	r6,#0x08,00250$
      0047AF                       1344 00250$:
      0047AF 50 0A            [24] 1345 	jnc	00108$
      0047B1 EC               [12] 1346 	mov	a,r4
      0047B2 B5 02 06         [24] 1347 	cjne	a,ar2,00252$
      0047B5 ED               [12] 1348 	mov	a,r5
      0047B6 B5 03 02         [24] 1349 	cjne	a,ar3,00252$
      0047B9 80 16            [24] 1350 	sjmp	00109$
      0047BB                       1351 00252$:
      0047BB                       1352 00108$:
      0047BB 75 82 01         [24] 1353 	mov	dpl, #0x01
      0047BE C0 07            [24] 1354 	push	ar7
      0047C0 C0 06            [24] 1355 	push	ar6
      0047C2 C0 05            [24] 1356 	push	ar5
      0047C4 C0 04            [24] 1357 	push	ar4
      0047C6 12 44 4E         [24] 1358 	lcall	_td_finish
      0047C9 D0 04            [24] 1359 	pop	ar4
      0047CB D0 05            [24] 1360 	pop	ar5
      0047CD D0 06            [24] 1361 	pop	ar6
      0047CF D0 07            [24] 1362 	pop	ar7
      0047D1                       1363 00109$:
                                   1364 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:123: if (!dance) return true;
      0047D1 E5 15            [12] 1365 	mov	a,_ak820_tap_dance_process_sloc0_1_0
      0047D3 70 04            [24] 1366 	jnz	00116$
      0047D5 75 82 01         [24] 1367 	mov	dpl, #0x01
      0047D8 22               [24] 1368 	ret
      0047D9                       1369 00116$:
                                   1370 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:124: if (index >= VIAL_TAP_DANCE_ENTRIES || (slot->state && slot->source != id)) goto suppress;
      0047D9 BE 08 00         [24] 1371 	cjne	r6,#0x08,00254$
      0047DC                       1372 00254$:
      0047DC 40 03            [24] 1373 	jc	00255$
      0047DE 02 48 67         [24] 1374 	ljmp	00125$
      0047E1                       1375 00255$:
      0047E1 74 03            [12] 1376 	mov	a,#0x03
      0047E3 2C               [12] 1377 	add	a, r4
      0047E4 FA               [12] 1378 	mov	r2,a
      0047E5 E4               [12] 1379 	clr	a
      0047E6 3D               [12] 1380 	addc	a, r5
      0047E7 FB               [12] 1381 	mov	r3,a
      0047E8 12 38 AD         [24] 1382 	lcall	_ak820_outline_0134
      0047EB E0               [24] 1383 	movx	a,@dptr
      0047EC F9               [12] 1384 	mov	r1,a
      0047ED 60 0E            [24] 1385 	jz	00118$
      0047EF 12 38 A3         [24] 1386 	lcall	_ak820_outline_0132
      0047F2 A3               [24] 1387 	inc	dptr
      0047F3 A3               [24] 1388 	inc	dptr
      0047F4 E0               [24] 1389 	movx	a,@dptr
      0047F5 B5 07 02         [24] 1390 	cjne	a,ar7,00257$
      0047F8 80 03            [24] 1391 	sjmp	00258$
      0047FA                       1392 00257$:
      0047FA 02 48 67         [24] 1393 	ljmp	00125$
      0047FD                       1394 00258$:
      0047FD                       1395 00118$:
                                   1396 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: if (!slot->state) {
      0047FD E9               [12] 1397 	mov	a,r1
      0047FE 70 36            [24] 1398 	jnz	00124$
                                   1399 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:126: if (dynamic_keymap_get_tap_dance(index, &td_entry)) goto suppress;
      004800 90 0B B3         [24] 1400 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      004803 74 C2            [12] 1401 	mov	a,#_td_entry
      004805 F0               [24] 1402 	movx	@dptr,a
      004806 74 05            [12] 1403 	mov	a,#(_td_entry >> 8)
      004808 12 38 4A         [24] 1404 	lcall	_ak820_outline_0077
      00480B 8E 82            [24] 1405 	mov	dpl, r6
      00480D C0 07            [24] 1406 	push	ar7
      00480F C0 06            [24] 1407 	push	ar6
      004811 C0 05            [24] 1408 	push	ar5
      004813 C0 04            [24] 1409 	push	ar4
      004815 C0 03            [24] 1410 	push	ar3
      004817 C0 02            [24] 1411 	push	ar2
      004819 12 8A 34         [24] 1412 	lcall	_dynamic_keymap_get_tap_dance
      00481C 12 38 97         [24] 1413 	lcall	_ak820_outline_0128
      00481F D0 02            [24] 1414 	pop	ar2
      004821 D0 03            [24] 1415 	pop	ar3
      004823 D0 04            [24] 1416 	pop	ar4
      004825 D0 05            [24] 1417 	pop	ar5
      004827 D0 06            [24] 1418 	pop	ar6
      004829 D0 07            [24] 1419 	pop	ar7
      00482B 45 F0            [12] 1420 	orl	a,b
      00482D 70 38            [24] 1421 	jnz	00125$
                                   1422 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:127: slot->source = id;
      00482F 12 38 A3         [24] 1423 	lcall	_ak820_outline_0132
      004832 A3               [24] 1424 	inc	dptr
      004833 A3               [24] 1425 	inc	dptr
      004834 EF               [12] 1426 	mov	a,r7
      004835 F0               [24] 1427 	movx	@dptr,a
      004836                       1428 00124$:
                                   1429 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: slot->state = (slot->state & 3) + 1 + TD_DOWN;
      004836 12 38 AD         [24] 1430 	lcall	_ak820_outline_0134
      004839 E0               [24] 1431 	movx	a,@dptr
      00483A F9               [12] 1432 	mov	r1,a
      00483B 74 03            [12] 1433 	mov	a,#0x03
      00483D 59               [12] 1434 	anl	a,r1
      00483E 24 05            [12] 1435 	add	a, #0x05
      004840 12 38 AD         [24] 1436 	lcall	_ak820_outline_0134
      004843 F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: td_time = record->event.time;
      004844 90 06 65         [24] 1439 	mov	dptr,#_ak820_tap_dance_process_record_10000_640
      004847 12 43 4C         [24] 1440 	lcall	_ak820_outline_0083
      00484A 12 38 AD         [24] 1441 	lcall	_ak820_outline_0134
      00484D A3               [24] 1442 	inc	dptr
      00484E A3               [24] 1443 	inc	dptr
      00484F 12 43 4C         [24] 1444 	lcall	_ak820_outline_0083
      004852 90 05 CC         [24] 1445 	mov	dptr,#_td_time
      004855 12 49 34         [24] 1446 	lcall	_ak820_outline_0167
                                   1447 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: td_wait = slot;
      004858 90 05 BE         [24] 1448 	mov	dptr,#_td_wait
      00485B 12 38 50         [24] 1449 	lcall	_ak820_outline_0078
                                   1450 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:132: td_map[id] = index;
      00485E 12 49 0F         [24] 1451 	lcall	_ak820_outline_0054
      004861 EE               [12] 1452 	mov	a,r6
      004862 F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:133: return false;
      004863 75 82 00         [24] 1455 	mov	dpl, #0x00
                                   1456 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: suppress:
      004866 22               [24] 1457 	ret
      004867                       1458 00125$:
                                   1459 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: td_map[id] = TD_NONE;
      004867 12 49 0F         [24] 1460 	lcall	_ak820_outline_0054
      00486A 74 FF            [12] 1461 	mov	a,#0xff
      00486C F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: return false;
      00486D 75 82 00         [24] 1464 	mov	dpl, #0x00
                                   1465 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: }
      004870 22               [24] 1466 	ret
                                   1467 ;------------------------------------------------------------
                                   1468 ;Allocation info for local variables in function 'ak820_tap_dance_cancel'
                                   1469 ;------------------------------------------------------------
                                   1470 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_651'
                                   1471 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_652'
                                   1472 ;------------------------------------------------------------
                                   1473 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:138: void ak820_tap_dance_cancel(void) {
                                   1474 ;	-----------------------------------------
                                   1475 ;	 function ak820_tap_dance_cancel
                                   1476 ;	-----------------------------------------
      004871                       1477 _ak820_tap_dance_cancel:
                                   1478 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: td_wait = 0;
      004871 90 05 BE         [24] 1479 	mov	dptr,#_td_wait
      004874 12 49 28         [24] 1480 	lcall	_ak820_outline_0150
                                   1481 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:140: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_slots[i].state = 0;
      004877 FF               [12] 1482 	mov	r7,a
      004878                       1483 00104$:
      004878 BF 08 00         [24] 1484 	cjne	r7,#0x08,00141$
      00487B                       1485 00141$:
      00487B 50 14            [24] 1486 	jnc	00101$
      00487D EF               [12] 1487 	mov	a,r7
      00487E 12 38 CC         [24] 1488 	lcall	_ak820_outline_0195
      004881 24 9E            [12] 1489 	add	a, #_td_slots
      004883 FD               [12] 1490 	mov	r5,a
      004884 74 05            [12] 1491 	mov	a,#(_td_slots >> 8)
      004886 35 F0            [12] 1492 	addc	a, b
      004888 FE               [12] 1493 	mov	r6,a
      004889 12 48 EA         [24] 1494 	lcall	_ak820_outline_0040
      00488C E4               [12] 1495 	clr	a
      00488D F0               [24] 1496 	movx	@dptr,a
      00488E 0F               [12] 1497 	inc	r7
      00488F 80 E7            [24] 1498 	sjmp	00104$
      004891                       1499 00101$:
                                   1500 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: for (uint8_t i = 0; i < sizeof(td_map); ++i) td_map[i] = 0;
      004891 7F 00            [12] 1501 	mov	r7,#0x00
      004893                       1502 00107$:
      004893 BF 80 00         [24] 1503 	cjne	r7,#0x80,00143$
      004896                       1504 00143$:
      004896 50 08            [24] 1505 	jnc	00109$
      004898 12 49 0F         [24] 1506 	lcall	_ak820_outline_0054
      00489B E4               [12] 1507 	clr	a
      00489C F0               [24] 1508 	movx	@dptr,a
      00489D 0F               [12] 1509 	inc	r7
      00489E 80 F3            [24] 1510 	sjmp	00107$
      0048A0                       1511 00109$:
                                   1512 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:142: }
      0048A0 22               [24] 1513 	ret
                                   1514 	.area CSEG    (CODE)
                                   1515 	.area CONST   (CODE)
                                   1516 	.area XINIT   (CODE)
                                   1517 	.area CABS    (ABS,CODE)
                                   1518 
                                   1519 ; Experimental exact instruction outlining.
                                   1520 	.globl _ak820_outline_0005
                                   1521 	.globl _ak820_outline_0006
                                   1522 	.globl _ak820_outline_0012
                                   1523 	.globl _ak820_outline_0013
                                   1524 	.globl _ak820_outline_0018
                                   1525 	.globl _ak820_outline_0021
                                   1526 	.globl _ak820_outline_0022
                                   1527 	.globl _ak820_outline_0026
                                   1528 	.globl _ak820_outline_0034
                                   1529 	.globl _ak820_outline_0035
                                   1530 	.globl _ak820_outline_0038
                                   1531 	.globl _ak820_outline_0040
                                   1532 	.globl _ak820_outline_0044
                                   1533 	.globl _ak820_outline_0052
                                   1534 	.globl _ak820_outline_0054
                                   1535 	.globl _ak820_outline_0058
                                   1536 	.globl _ak820_outline_0064
                                   1537 	.globl _ak820_outline_0065
                                   1538 	.globl _ak820_outline_0071
                                   1539 	.globl _ak820_outline_0077
                                   1540 	.globl _ak820_outline_0078
                                   1541 	.globl _ak820_outline_0083
                                   1542 	.globl _ak820_outline_0084
                                   1543 	.globl _ak820_outline_0085
                                   1544 	.globl _ak820_outline_0098
                                   1545 	.globl _ak820_outline_0103
                                   1546 	.globl _ak820_outline_0107
                                   1547 	.globl _ak820_outline_0111
                                   1548 	.globl _ak820_outline_0112
                                   1549 	.globl _ak820_outline_0117
                                   1550 	.globl _ak820_outline_0124
                                   1551 	.globl _ak820_outline_0126
                                   1552 	.globl _ak820_outline_0128
                                   1553 	.globl _ak820_outline_0129
                                   1554 	.globl _ak820_outline_0131
                                   1555 	.globl _ak820_outline_0132
                                   1556 	.globl _ak820_outline_0133
                                   1557 	.globl _ak820_outline_0134
                                   1558 	.globl _ak820_outline_0150
                                   1559 	.globl _ak820_outline_0151
                                   1560 	.globl _ak820_outline_0157
                                   1561 	.globl _ak820_outline_0167
                                   1562 	.globl _ak820_outline_0176
                                   1563 	.globl _ak820_outline_0179
                                   1564 	.globl _ak820_outline_0195
                                   1565 
                                   1566 	.area CSEG (CODE)
                                   1567 ; function ak820_outline_0012
      0048A1                       1568 _ak820_outline_0012:
      0048A1 2E               [12] 1569 	add	a,r6
      0048A2 FB               [12] 1570 	mov	r3,a
      0048A3 E4               [12] 1571 	clr	a
      0048A4 3F               [12] 1572 	addc	a,r7
      0048A5 FC               [12] 1573 	mov	r4,a
      0048A6 8B 82            [24] 1574 	mov	dpl,r3
      0048A8 8C 83            [24] 1575 	mov	dph,r4
      0048AA E0               [24] 1576 	movx	a,@dptr
      0048AB 22               [24] 1577 	ret
                                   1578 
                                   1579 	.area CSEG (CODE)
                                   1580 ; function ak820_outline_0013
      0048AC                       1581 _ak820_outline_0013:
      0048AC 2E               [12] 1582 	add	a,r6
      0048AD FC               [12] 1583 	mov	r4,a
      0048AE E4               [12] 1584 	clr	a
      0048AF 3F               [12] 1585 	addc	a,r7
      0048B0 FD               [12] 1586 	mov	r5,a
      0048B1 8C 82            [24] 1587 	mov	dpl,r4
      0048B3 8D 83            [24] 1588 	mov	dph,r5
      0048B5 E0               [24] 1589 	movx	a,@dptr
      0048B6 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0018
      0048B7                       1594 _ak820_outline_0018:
      0048B7 8E 82            [24] 1595 	mov	dpl,r6
      0048B9 8F 83            [24] 1596 	mov	dph,r7
      0048BB A3               [24] 1597 	inc	dptr
      0048BC A3               [24] 1598 	inc	dptr
      0048BD A3               [24] 1599 	inc	dptr
      0048BE E0               [24] 1600 	movx	a,@dptr
      0048BF 22               [24] 1601 	ret
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0021
      0048C0                       1605 _ak820_outline_0021:
      0048C0 2E               [12] 1606 	add	a,r6
      0048C1 FA               [12] 1607 	mov	r2,a
      0048C2 E4               [12] 1608 	clr	a
      0048C3 3F               [12] 1609 	addc	a,r7
      0048C4 FB               [12] 1610 	mov	r3,a
      0048C5 8A 82            [24] 1611 	mov	dpl,r2
      0048C7 8B 83            [24] 1612 	mov	dph,r3
      0048C9 E0               [24] 1613 	movx	a,@dptr
      0048CA 22               [24] 1614 	ret
                                   1615 
                                   1616 	.area CSEG (CODE)
                                   1617 ; function ak820_outline_0022
      0048CB                       1618 _ak820_outline_0022:
      0048CB 8E 82            [24] 1619 	mov	dpl,r6
      0048CD 8F 83            [24] 1620 	mov	dph,r7
      0048CF A3               [24] 1621 	inc	dptr
      0048D0 A3               [24] 1622 	inc	dptr
      0048D1 A3               [24] 1623 	inc	dptr
      0048D2 A3               [24] 1624 	inc	dptr
      0048D3 22               [24] 1625 	ret
                                   1626 
                                   1627 	.area CSEG (CODE)
                                   1628 ; function ak820_outline_0034
      0048D4                       1629 _ak820_outline_0034:
      0048D4 E0               [24] 1630 	movx	a,@dptr
      0048D5 FE               [12] 1631 	mov	r6,a
      0048D6 A3               [24] 1632 	inc	dptr
      0048D7 E0               [24] 1633 	movx	a,@dptr
      0048D8 FF               [12] 1634 	mov	r7,a
      0048D9 90 06 55         [24] 1635 	mov	dptr,#(_td_record+0x0007)
      0048DC EE               [12] 1636 	mov	a,r6
      0048DD F0               [24] 1637 	movx	@dptr,a
      0048DE EF               [12] 1638 	mov	a,r7
      0048DF A3               [24] 1639 	inc	dptr
      0048E0 F0               [24] 1640 	movx	@dptr,a
      0048E1 22               [24] 1641 	ret
                                   1642 
                                   1643 	.area CSEG (CODE)
                                   1644 ; function ak820_outline_0038
      0048E2                       1645 _ak820_outline_0038:
      0048E2 E0               [24] 1646 	movx	a,@dptr
      0048E3 F5 F0            [12] 1647 	mov	b,a
      0048E5 A3               [24] 1648 	inc	dptr
      0048E6 E0               [24] 1649 	movx	a,@dptr
      0048E7 45 F0            [12] 1650 	orl	a,b
      0048E9 22               [24] 1651 	ret
                                   1652 
                                   1653 	.area CSEG (CODE)
                                   1654 ; function ak820_outline_0040
      0048EA                       1655 _ak820_outline_0040:
      0048EA 8D 82            [24] 1656 	mov	dpl,r5
      0048EC 8E 83            [24] 1657 	mov	dph,r6
      0048EE A3               [24] 1658 	inc	dptr
      0048EF A3               [24] 1659 	inc	dptr
      0048F0 A3               [24] 1660 	inc	dptr
      0048F1 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0044
      0048F2                       1665 _ak820_outline_0044:
      0048F2 90 05 C0         [24] 1666 	mov	dptr,#_td_work
      0048F5 E0               [24] 1667 	movx	a,@dptr
      0048F6 FE               [12] 1668 	mov	r6,a
      0048F7 A3               [24] 1669 	inc	dptr
      0048F8 E0               [24] 1670 	movx	a,@dptr
      0048F9 FF               [12] 1671 	mov	r7,a
      0048FA 74 03            [12] 1672 	mov	a,#0x03
      0048FC 2E               [12] 1673 	add	a,r6
      0048FD FE               [12] 1674 	mov	r6,a
      0048FE E4               [12] 1675 	clr	a
      0048FF 3F               [12] 1676 	addc	a,r7
      004900 FF               [12] 1677 	mov	r7,a
      004901 8E 82            [24] 1678 	mov	dpl,r6
      004903 8F 83            [24] 1679 	mov	dph,r7
      004905 E0               [24] 1680 	movx	a,@dptr
      004906 22               [24] 1681 	ret
                                   1682 
                                   1683 	.area CSEG (CODE)
                                   1684 ; function ak820_outline_0052
      004907                       1685 _ak820_outline_0052:
      004907 FC               [12] 1686 	mov	r4,a
      004908 8B 82            [24] 1687 	mov	dpl,r3
      00490A 8C 83            [24] 1688 	mov	dph,r4
      00490C E0               [24] 1689 	movx	a,@dptr
      00490D FA               [12] 1690 	mov	r2,a
      00490E 22               [24] 1691 	ret
                                   1692 
                                   1693 	.area CSEG (CODE)
                                   1694 ; function ak820_outline_0054
      00490F                       1695 _ak820_outline_0054:
      00490F EF               [12] 1696 	mov	a,r7
      004910 24 CE            [12] 1697 	add	a,#_td_map
      004912 F5 82            [12] 1698 	mov	dpl,a
      004914 E4               [12] 1699 	clr	a
      004915 34 05            [12] 1700 	addc	a,#(_td_map>>8)
      004917 F5 83            [12] 1701 	mov	dph,a
      004919 22               [24] 1702 	ret
                                   1703 
                                   1704 	.area CSEG (CODE)
                                   1705 ; function ak820_outline_0064
      00491A                       1706 _ak820_outline_0064:
      00491A EE               [12] 1707 	mov	a,r6
      00491B F0               [24] 1708 	movx	@dptr,a
      00491C EF               [12] 1709 	mov	a,r7
      00491D A3               [24] 1710 	inc	dptr
      00491E F0               [24] 1711 	movx	@dptr,a
      00491F 22               [24] 1712 	ret
                                   1713 
                                   1714 	.area CSEG (CODE)
                                   1715 ; function ak820_outline_0126
      004920                       1716 _ak820_outline_0126:
      004920 74 02            [12] 1717 	mov	a,#0x02
      004922 2E               [12] 1718 	add	a,r6
      004923 FE               [12] 1719 	mov	r6,a
      004924 E4               [12] 1720 	clr	a
      004925 3F               [12] 1721 	addc	a,r7
      004926 FF               [12] 1722 	mov	r7,a
      004927 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0150
      004928                       1727 _ak820_outline_0150:
      004928 E4               [12] 1728 	clr	a
      004929 F0               [24] 1729 	movx	@dptr,a
      00492A A3               [24] 1730 	inc	dptr
      00492B F0               [24] 1731 	movx	@dptr,a
      00492C 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0157
      00492D                       1736 _ak820_outline_0157:
      00492D 2C               [12] 1737 	add	a,r4
      00492E FC               [12] 1738 	mov	r4,a
      00492F ED               [12] 1739 	mov	a,r5
      004930 33               [12] 1740 	rlc	a
      004931 FD               [12] 1741 	mov	r5,a
      004932 EC               [12] 1742 	mov	a,r4
      004933 22               [24] 1743 	ret
                                   1744 
                                   1745 	.area CSEG (CODE)
                                   1746 ; function ak820_outline_0167
      004934                       1747 _ak820_outline_0167:
      004934 EA               [12] 1748 	mov	a,r2
      004935 F0               [24] 1749 	movx	@dptr,a
      004936 EB               [12] 1750 	mov	a,r3
      004937 A3               [24] 1751 	inc	dptr
      004938 F0               [24] 1752 	movx	@dptr,a
      004939 22               [24] 1753 	ret
                                   1754 
                                   1755 	.area CSEG (CODE)
                                   1756 ; function ak820_outline_0176
      00493A                       1757 _ak820_outline_0176:
      00493A E0               [24] 1758 	movx	a,@dptr
      00493B FB               [12] 1759 	mov	r3,a
      00493C A3               [24] 1760 	inc	dptr
      00493D E0               [24] 1761 	movx	a,@dptr
      00493E 4B               [12] 1762 	orl	a,r3
      00493F 22               [24] 1763 	ret
