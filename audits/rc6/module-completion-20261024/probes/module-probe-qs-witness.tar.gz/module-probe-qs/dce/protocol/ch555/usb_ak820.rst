                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000027                        548 _control_setup_sloc1_1_0:
      000027                        549 	.ds 1
      000028                        550 _control_setup_sloc3_1_0:
      000028                        551 	.ds 2
      00002A                        552 _control_setup_sloc4_1_0:
      00002A                        553 	.ds 2
      00002C                        554 _ak820_usb_send_sloc0_1_0:
      00002C                        555 	.ds 2
      00002E                        556 _ak820_usb_send_sloc1_1_0:
      00002E                        557 	.ds 1
      00002F                        558 _ak820_usb_raw_task_sloc0_1_0:
      00002F                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000017                        576 _control_setup_valid_interface_10000_286:
      000017                        577 	.ds 1
      000018                        578 _control_setup_zero_index_10000_286:
      000018                        579 	.ds 1
      000019                        580 _control_setup_zero_value_10000_286:
      000019                        581 	.ds 1
      00001A                        582 _control_setup_zero_length_10000_286:
      00001A                        583 	.ds 1
      00001B                        584 _control_setup_sloc0_1_0:
      00001B                        585 	.ds 1
      00001C                        586 _control_setup_sloc2_1_0:
      00001C                        587 	.ds 1
      00001D                        588 _ak820_usb_try_send_sloc0_1_0:
      00001D                        589 	.ds 1
      00001E                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        591 	.ds 1
      00001F                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001F                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      0007B8                        602 _D0SetupReqCode::
      0007B8                        603 	.ds 1
      0007B9                        604 _D0SetupLen::
      0007B9                        605 	.ds 2
      0007BB                        606 _pD0Descr::
      0007BB                        607 	.ds 3
      0007BE                        608 _D0UsbConfig::
      0007BE                        609 	.ds 1
      0007BF                        610 _USB_EnumStatus::
      0007BF                        611 	.ds 1
      0007C0                        612 _USB_SleepStatus::
      0007C0                        613 	.ds 1
      0007C1                        614 _MCU_Sleep_Operate::
      0007C1                        615 	.ds 1
      0007C2                        616 _KB_USB_UpStatus::
      0007C2                        617 	.ds 1
      0007C3                        618 _KB_USB_SetReport::
      0007C3                        619 	.ds 1
      0007C4                        620 _ak820_boot_stage::
      0007C4                        621 	.ds 1
      0007C5                        622 _ak820_main_heartbeat::
      0007C5                        623 	.ds 1
      0007C6                        624 _raw_state:
      0007C6                        625 	.ds 1
      0007C7                        626 _raw_buffer:
      0007C7                        627 	.ds 32
      0007E7                        628 _raw_reply_without_nvm:
      0007E7                        629 	.ds 1
      0007E8                        630 _keyboard_reset:
      0007E8                        631 	.ds 1
      0007E9                        632 _input_snapshot:
      0007E9                        633 	.ds 46
      000817                        634 _control_phase:
      000817                        635 	.ds 1
      000818                        636 _output_kind:
      000818                        637 	.ds 1
      000819                        638 _output_report_id:
      000819                        639 	.ds 1
      00081A                        640 _control_zlp:
      00081A                        641 	.ds 1
      00081B                        642 _control_pointer:
      00081B                        643 	.ds 2
      00081D                        644 _descriptor_select_PARM_2:
      00081D                        645 	.ds 1
      00081E                        646 _descriptor_select_PARM_3:
      00081E                        647 	.ds 2
      000820                        648 _descriptor_select_type_10000_268:
      000820                        649 	.ds 1
      000821                        650 _control_setup_length_10000_286:
      000821                        651 	.ds 2
      000823                        652 _control_setup_offset_10000_286:
      000823                        653 	.ds 1
      000824                        654 _ak820_usb_send_PARM_2:
      000824                        655 	.ds 2
      000826                        656 _ak820_usb_send_PARM_3:
      000826                        657 	.ds 1
      000827                        658 _ak820_usb_send_endpoint_10000_422:
      000827                        659 	.ds 1
      000828                        660 _ak820_usb_send_offset_10000_423:
      000828                        661 	.ds 1
      000829                        662 _ak820_usb_try_send_PARM_2:
      000829                        663 	.ds 2
      00082B                        664 _ak820_usb_try_send_PARM_3:
      00082B                        665 	.ds 1
      00082C                        666 _ak820_usb_try_send_endpoint_10000_443:
      00082C                        667 	.ds 1
      00082D                        668 _ak820_usb_try_send_sent_10000_444:
      00082D                        669 	.ds 1
      00082E                        670 _ak820_usb_raw_send_PARM_2:
      00082E                        671 	.ds 1
      00082F                        672 _ak820_usb_raw_send_report_10000_459:
      00082F                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      006037                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      006037 90 07 C6         [24]  727 	mov	dptr,#_raw_state
      00603A E0               [24]  728 	movx	a,@dptr
      00603B FF               [12]  729 	mov	r7,a
      00603C BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      00603F 80 1C            [24]  731 	sjmp	00101$
      006041                        732 00130$:
      006041 90 07 C6         [24]  733 	mov	dptr,#_raw_state
      006044 E0               [24]  734 	movx	a,@dptr
      006045 FF               [12]  735 	mov	r7,a
      006046 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      006049 80 12            [24]  737 	sjmp	00101$
      00604B                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      00604B 90 07 C6         [24]  740 	mov	dptr,#_raw_state
      00604E E0               [24]  741 	movx	a,@dptr
      00604F FF               [12]  742 	mov	r7,a
      006050 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      006053 80 08            [24]  744 	sjmp	00101$
      006055                        745 00132$:
      006055 90 07 C6         [24]  746 	mov	dptr,#_raw_state
      006058 E0               [24]  747 	movx	a,@dptr
      006059 FF               [12]  748 	mov	r7,a
      00605A BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      00605D                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      00605D 90 07 C6         [24]  752 	mov	dptr,#_raw_state
      006060 74 07            [12]  753 	mov	a,#0x07
      006062 F0               [24]  754 	movx	@dptr,a
      006063 80 05            [24]  755 	sjmp	00103$
      006065                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      006065 90 07 C6         [24]  758 	mov	dptr,#_raw_state
      006068 E4               [12]  759 	clr	a
      006069 F0               [24]  760 	movx	@dptr,a
      00606A                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      00606A 90 08 18         [24]  763 	mov	dptr,#_output_kind
      00606D E4               [12]  764 	clr	a
      00606E F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      00606F 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      006070                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      006070 90 07 C6         [24]  777 	mov	dptr,#_raw_state
      006073 E0               [24]  778 	movx	a,@dptr
      006074 FF               [12]  779 	mov	r7,a
      006075 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      006078 90 07 C6         [24]  781 	mov	dptr,#_raw_state
      00607B 74 06            [12]  782 	mov	a,#0x06
      00607D F0               [24]  783 	movx	@dptr,a
      00607E 22               [24]  784 	ret
      00607F                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      00607F 90 07 C6         [24]  787 	mov	dptr,#_raw_state
      006082 E0               [24]  788 	movx	a,@dptr
      006083 FF               [12]  789 	mov	r7,a
      006084 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      006087 90 07 C6         [24]  791 	mov	dptr,#_raw_state
      00608A E4               [12]  792 	clr	a
      00608B F0               [24]  793 	movx	@dptr,a
      00608C                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      00608C 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      00608D                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      00608D 90 22 0C         [24]  808 	mov	dptr,#0x220c
      006090 74 01            [12]  809 	mov	a,#0x01
      006092 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006093 F5 82            [12]  812 	mov	dpl,a
      006095 74 12            [12]  813 	mov	a,#0x12
      006097 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006098 A3               [24]  816 	inc	dptr
      006099 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      00609A A3               [24]  819 	inc	dptr
      00609B F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      00609C 90 22 0B         [24]  822 	mov	dptr,#0x220b
      00609F E4               [12]  823 	clr	a
      0060A0 F0               [24]  824 	movx	@dptr,a
      0060A1 15 82            [12]  825 	dec	dpl
      0060A3 F0               [24]  826 	movx	@dptr,a
      0060A4 15 82            [12]  827 	dec	dpl
      0060A6 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      0060A7 FF               [12]  830 	mov	r7,a
      0060A8                        831 00103$:
      0060A8 EF               [12]  832 	mov	a,r7
      0060A9 24 E9            [12]  833 	add	a, #_input_snapshot
      0060AB F5 82            [12]  834 	mov	dpl,a
      0060AD E4               [12]  835 	clr	a
      0060AE 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      0060B0 F5 83            [12]  837 	mov	dph,a
      0060B2 E4               [12]  838 	clr	a
      0060B3 F0               [24]  839 	movx	@dptr,a
      0060B4 0F               [12]  840 	inc	r7
      0060B5 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      0060B8                        842 00139$:
      0060B8 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      0060BA 90 07 F1         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      0060BD 74 06            [12]  846 	mov	a,#0x06
      0060BF F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      0060C0 90 08 11         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      0060C3 03               [12]  850 	rr	a
      0060C4 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      0060C5 90 08 14         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      0060C8 04               [12]  854 	inc	a
      0060C9 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      0060CA 7F 00            [12]  857 	mov	r7,#0x00
      0060CC                        858 00105$:
      0060CC 8F 06            [24]  859 	mov	ar6,r7
      0060CE 74 C0            [12]  860 	mov	a,#0xc0
      0060D0 2E               [12]  861 	add	a, r6
      0060D1 F5 82            [12]  862 	mov	dpl,a
      0060D3 74 10            [12]  863 	mov	a,#0x10
      0060D5 24 00            [12]  864 	add	a, #0x00
      0060D7 F5 83            [12]  865 	mov	dph,a
      0060D9 E4               [12]  866 	clr	a
      0060DA F0               [24]  867 	movx	@dptr,a
      0060DB 0F               [12]  868 	inc	r7
      0060DC BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      0060DF                        870 00141$:
      0060DF 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      0060E1 02 60 37         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      0060E4                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      0060E4 90 07 C6         [24]  884 	mov	dptr,#_raw_state
      0060E7 E0               [24]  885 	movx	a,@dptr
      0060E8 FF               [12]  886 	mov	r7,a
      0060E9 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      0060EC 90 07 C6         [24]  888 	mov	dptr,#_raw_state
      0060EF E4               [12]  889 	clr	a
      0060F0 F0               [24]  890 	movx	@dptr,a
      0060F1                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      0060F1 90 08 18         [24]  893 	mov	dptr,#_output_kind
      0060F4 E4               [12]  894 	clr	a
      0060F5 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      0060F6 90 08 17         [24]  897 	mov	dptr,#_control_phase
      0060F9 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      0060FA 90 07 B8         [24]  900 	mov	dptr,#_D0SetupReqCode
      0060FD 14               [12]  901 	dec	a
      0060FE F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      0060FF 90 22 00         [24]  904 	mov	dptr,#0x2200
      006102 74 CF            [12]  905 	mov	a,#0xcf
      006104 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      006105 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      006106                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      006106 90 07 B9         [24]  921 	mov	dptr,#_D0SetupLen
      006109 E0               [24]  922 	movx	a,@dptr
      00610A FE               [12]  923 	mov	r6,a
      00610B A3               [24]  924 	inc	dptr
      00610C E0               [24]  925 	movx	a,@dptr
      00610D FF               [12]  926 	mov	r7,a
      00610E C3               [12]  927 	clr	c
      00610F 74 40            [12]  928 	mov	a,#0x40
      006111 9E               [12]  929 	subb	a,r6
      006112 E4               [12]  930 	clr	a
      006113 9F               [12]  931 	subb	a,r7
      006114 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      006116 7E 40            [12]  934 	mov	r6,#0x40
      006118 80 07            [24]  935 	sjmp	00110$
      00611A                        936 00109$:
      00611A 90 07 B9         [24]  937 	mov	dptr,#_D0SetupLen
      00611D E0               [24]  938 	movx	a,@dptr
      00611E FE               [12]  939 	mov	r6,a
      00611F A3               [24]  940 	inc	dptr
      006120 E0               [24]  941 	movx	a,@dptr
      006121                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      006121 7F 00            [12]  944 	mov	r7,#0x00
      006123                        945 00105$:
      006123 C3               [12]  946 	clr	c
      006124 EF               [12]  947 	mov	a,r7
      006125 9E               [12]  948 	subb	a,r6
      006126 50 2A            [24]  949 	jnc	00101$
      006128 8F 04            [24]  950 	mov	ar4,r7
      00612A 74 10            [12]  951 	mov	a,#0x10
      00612C 24 00            [12]  952 	add	a, #0x00
      00612E FD               [12]  953 	mov	r5,a
      00612F 90 08 1B         [24]  954 	mov	dptr,#_control_pointer
      006132 E0               [24]  955 	movx	a,@dptr
      006133 FA               [12]  956 	mov	r2,a
      006134 A3               [24]  957 	inc	dptr
      006135 E0               [24]  958 	movx	a,@dptr
      006136 FB               [12]  959 	mov	r3,a
      006137 8A 82            [24]  960 	mov	dpl,r2
      006139 8B 83            [24]  961 	mov	dph,r3
      00613B E4               [12]  962 	clr	a
      00613C 93               [24]  963 	movc	a,@a+dptr
      00613D F9               [12]  964 	mov	r1,a
      00613E 90 08 1B         [24]  965 	mov	dptr,#_control_pointer
      006141 74 01            [12]  966 	mov	a,#0x01
      006143 2A               [12]  967 	add	a, r2
      006144 F0               [24]  968 	movx	@dptr,a
      006145 E4               [12]  969 	clr	a
      006146 3B               [12]  970 	addc	a, r3
      006147 A3               [24]  971 	inc	dptr
      006148 F0               [24]  972 	movx	@dptr,a
      006149 8C 82            [24]  973 	mov	dpl,r4
      00614B 8D 83            [24]  974 	mov	dph,r5
      00614D E9               [12]  975 	mov	a,r1
      00614E F0               [24]  976 	movx	@dptr,a
      00614F 0F               [12]  977 	inc	r7
      006150 80 D1            [24]  978 	sjmp	00105$
      006152                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      006152 8E 05            [24]  981 	mov	ar5,r6
      006154 7F 00            [12]  982 	mov	r7,#0x00
      006156 90 07 B9         [24]  983 	mov	dptr,#_D0SetupLen
      006159 E0               [24]  984 	movx	a,@dptr
      00615A FB               [12]  985 	mov	r3,a
      00615B A3               [24]  986 	inc	dptr
      00615C E0               [24]  987 	movx	a,@dptr
      00615D FC               [12]  988 	mov	r4,a
      00615E EB               [12]  989 	mov	a,r3
      00615F C3               [12]  990 	clr	c
      006160 9D               [12]  991 	subb	a,r5
      006161 FB               [12]  992 	mov	r3,a
      006162 EC               [12]  993 	mov	a,r4
      006163 9F               [12]  994 	subb	a,r7
      006164 FC               [12]  995 	mov	r4,a
      006165 90 07 B9         [24]  996 	mov	dptr,#_D0SetupLen
      006168 EB               [12]  997 	mov	a,r3
      006169 F0               [24]  998 	movx	@dptr,a
      00616A EC               [12]  999 	mov	a,r4
      00616B A3               [24] 1000 	inc	dptr
      00616C F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      00616D EE               [12] 1003 	mov	a,r6
      00616E 70 05            [24] 1004 	jnz	00103$
      006170 90 08 1A         [24] 1005 	mov	dptr,#_control_zlp
      006173 E4               [12] 1006 	clr	a
      006174 F0               [24] 1007 	movx	@dptr,a
      006175                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      006175 90 22 08         [24] 1010 	mov	dptr,#0x2208
      006178 EE               [12] 1011 	mov	a,r6
      006179 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      00617A 90 22 00         [24] 1014 	mov	dptr,#0x2200
      00617D E0               [24] 1015 	movx	a,@dptr
      00617E 54 C0            [12] 1016 	anl	a,#0xc0
      006180 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      006181 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      006182                       1032 _descriptor_select:
      006182 E5 82            [12] 1033 	mov	a,dpl
      006184 90 08 20         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      006187 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      006188 E0               [24] 1037 	movx	a,@dptr
      006189 FF               [12] 1038 	mov	r7,a
      00618A BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      00618D 90 08 1D         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      006190 E0               [24] 1041 	movx	a,@dptr
      006191 70 1A            [24] 1042 	jnz	00102$
      006193 90 08 1E         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      006196 E0               [24] 1044 	movx	a,@dptr
      006197 F5 F0            [12] 1045 	mov	b,a
      006199 A3               [24] 1046 	inc	dptr
      00619A E0               [24] 1047 	movx	a,@dptr
      00619B 45 F0            [12] 1048 	orl	a,b
      00619D 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      00619F 90 08 1B         [24] 1051 	mov	dptr,#_control_pointer
      0061A2 74 4E            [12] 1052 	mov	a,#_DeviceDescriptor
      0061A4 F0               [24] 1053 	movx	@dptr,a
      0061A5 74 C7            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      0061A7 A3               [24] 1055 	inc	dptr
      0061A8 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      0061A9 90 00 12         [24] 1058 	mov	dptr,#0x0012
      0061AC 22               [24] 1059 	ret
      0061AD                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      0061AD 90 08 20         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      0061B0 E0               [24] 1063 	movx	a,@dptr
      0061B1 FF               [12] 1064 	mov	r7,a
      0061B2 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      0061B5 90 08 1D         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      0061B8 E0               [24] 1067 	movx	a,@dptr
      0061B9 70 1A            [24] 1068 	jnz	00106$
      0061BB 90 08 1E         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      0061BE E0               [24] 1070 	movx	a,@dptr
      0061BF F5 F0            [12] 1071 	mov	b,a
      0061C1 A3               [24] 1072 	inc	dptr
      0061C2 E0               [24] 1073 	movx	a,@dptr
      0061C3 45 F0            [12] 1074 	orl	a,b
      0061C5 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      0061C7 90 08 1B         [24] 1077 	mov	dptr,#_control_pointer
      0061CA 74 60            [12] 1078 	mov	a,#_ConfigurationDescriptor
      0061CC F0               [24] 1079 	movx	@dptr,a
      0061CD 74 C7            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      0061CF A3               [24] 1081 	inc	dptr
      0061D0 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      0061D1 90 00 54         [24] 1084 	mov	dptr,#0x0054
      0061D4 22               [24] 1085 	ret
      0061D5                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      0061D5 90 08 20         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      0061D8 E0               [24] 1089 	movx	a,@dptr
      0061D9 FF               [12] 1090 	mov	r7,a
      0061DA BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      0061DD 80 03            [24] 1092 	sjmp	00239$
      0061DF                       1093 00238$:
      0061DF 02 62 79         [24] 1094 	ljmp	00119$
      0061E2                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      0061E2 90 08 1E         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      0061E5 E0               [24] 1098 	movx	a,@dptr
      0061E6 FD               [12] 1099 	mov	r5,a
      0061E7 A3               [24] 1100 	inc	dptr
      0061E8 E0               [24] 1101 	movx	a,@dptr
      0061E9 FE               [12] 1102 	mov	r6,a
      0061EA 90 08 1E         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      0061ED E0               [24] 1104 	movx	a,@dptr
      0061EE F5 F0            [12] 1105 	mov	b,a
      0061F0 A3               [24] 1106 	inc	dptr
      0061F1 E0               [24] 1107 	movx	a,@dptr
      0061F2 45 F0            [12] 1108 	orl	a,b
      0061F4 60 0C            [24] 1109 	jz	00110$
      0061F6 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      0061F9 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      0061FC 80 04            [24] 1112 	sjmp	00110$
      0061FE                       1113 00241$:
      0061FE 90 00 00         [24] 1114 	mov	dptr,#0x0000
      006201 22               [24] 1115 	ret
      006202                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      006202 90 08 1D         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      006205 E0               [24] 1119 	movx	a,@dptr
      006206 FE               [12] 1120 	mov  r6,a
      006207 24 FC            [12] 1121 	add	a,#0xff - 0x03
      006209 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      00620B EE               [12] 1124 	mov	a,r6
      00620C 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      00620D 90 62 11         [24] 1127 	mov	dptr,#00243$
      006210 73               [24] 1128 	jmp	@a+dptr
      006211                       1129 00243$:
      006211 80 06            [24] 1130 	sjmp	00112$
      006213 80 1B            [24] 1131 	sjmp	00113$
      006215 80 30            [24] 1132 	sjmp	00114$
      006217 80 45            [24] 1133 	sjmp	00115$
      006219                       1134 00112$:
      006219 90 08 1B         [24] 1135 	mov	dptr,#_control_pointer
      00621C 74 B4            [12] 1136 	mov	a,#_LanguageString
      00621E F0               [24] 1137 	movx	@dptr,a
      00621F 74 C7            [12] 1138 	mov	a,#(_LanguageString >> 8)
      006221 A3               [24] 1139 	inc	dptr
      006222 F0               [24] 1140 	movx	@dptr,a
      006223 90 C7 B4         [24] 1141 	mov	dptr,#_LanguageString
      006226 E4               [12] 1142 	clr	a
      006227 93               [24] 1143 	movc	a,@a+dptr
      006228 FE               [12] 1144 	mov	r6,a
      006229 7D 00            [12] 1145 	mov	r5,#0x00
      00622B 8E 82            [24] 1146 	mov	dpl, r6
      00622D 8D 83            [24] 1147 	mov	dph, r5
      00622F 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      006230                       1150 00113$:
      006230 90 08 1B         [24] 1151 	mov	dptr,#_control_pointer
      006233 74 B8            [12] 1152 	mov	a,#_ManufacturerString
      006235 F0               [24] 1153 	movx	@dptr,a
      006236 74 C7            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      006238 A3               [24] 1155 	inc	dptr
      006239 F0               [24] 1156 	movx	@dptr,a
      00623A 90 C7 B8         [24] 1157 	mov	dptr,#_ManufacturerString
      00623D E4               [12] 1158 	clr	a
      00623E 93               [24] 1159 	movc	a,@a+dptr
      00623F FE               [12] 1160 	mov	r6,a
      006240 7D 00            [12] 1161 	mov	r5,#0x00
      006242 8E 82            [24] 1162 	mov	dpl, r6
      006244 8D 83            [24] 1163 	mov	dph, r5
      006246 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      006247                       1166 00114$:
      006247 90 08 1B         [24] 1167 	mov	dptr,#_control_pointer
      00624A 74 C6            [12] 1168 	mov	a,#_ProductString
      00624C F0               [24] 1169 	movx	@dptr,a
      00624D 74 C7            [12] 1170 	mov	a,#(_ProductString >> 8)
      00624F A3               [24] 1171 	inc	dptr
      006250 F0               [24] 1172 	movx	@dptr,a
      006251 90 C7 C6         [24] 1173 	mov	dptr,#_ProductString
      006254 E4               [12] 1174 	clr	a
      006255 93               [24] 1175 	movc	a,@a+dptr
      006256 FE               [12] 1176 	mov	r6,a
      006257 7D 00            [12] 1177 	mov	r5,#0x00
      006259 8E 82            [24] 1178 	mov	dpl, r6
      00625B 8D 83            [24] 1179 	mov	dph, r5
      00625D 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      00625E                       1182 00115$:
      00625E 90 08 1B         [24] 1183 	mov	dptr,#_control_pointer
      006261 74 FE            [12] 1184 	mov	a,#_SerialNumberString
      006263 F0               [24] 1185 	movx	@dptr,a
      006264 74 C7            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      006266 A3               [24] 1187 	inc	dptr
      006267 F0               [24] 1188 	movx	@dptr,a
      006268 90 C7 FE         [24] 1189 	mov	dptr,#_SerialNumberString
      00626B E4               [12] 1190 	clr	a
      00626C 93               [24] 1191 	movc	a,@a+dptr
      00626D FE               [12] 1192 	mov	r6,a
      00626E 7D 00            [12] 1193 	mov	r5,#0x00
      006270 8E 82            [24] 1194 	mov	dpl, r6
      006272 8D 83            [24] 1195 	mov	dph, r5
      006274 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      006275                       1198 00116$:
      006275 90 00 00         [24] 1199 	mov	dptr,#0x0000
      006278 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      006279                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      006279 90 08 1D         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      00627C E0               [24] 1205 	movx	a,@dptr
      00627D 70 11            [24] 1206 	jnz	00120$
      00627F 90 08 1E         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      006282 E0               [24] 1208 	movx	a,@dptr
      006283 FD               [12] 1209 	mov	r5,a
      006284 A3               [24] 1210 	inc	dptr
      006285 E0               [24] 1211 	movx	a,@dptr
      006286 FE               [12] 1212 	mov	r6,a
      006287 C3               [12] 1213 	clr	c
      006288 ED               [12] 1214 	mov	a,r5
      006289 94 03            [12] 1215 	subb	a,#0x03
      00628B EE               [12] 1216 	mov	a,r6
      00628C 94 00            [12] 1217 	subb	a,#0x00
      00628E 40 04            [24] 1218 	jc	00121$
      006290                       1219 00120$:
      006290 90 00 00         [24] 1220 	mov	dptr,#0x0000
      006293 22               [24] 1221 	ret
      006294                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006294 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      006297 80 03            [24] 1225 	sjmp	00127$
      006299                       1226 00246$:
      006299 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      00629C                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      00629C ED               [12] 1230 	mov	a,r5
      00629D 75 F0 04         [24] 1231 	mov	b,#0x04
      0062A0 A4               [48] 1232 	mul	ab
      0062A1 24 D7            [12] 1233 	add	a, #_interface_descriptors
      0062A3 FE               [12] 1234 	mov	r6,a
      0062A4 74 C0            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      0062A6 35 F0            [12] 1236 	addc	a, b
      0062A8 FF               [12] 1237 	mov	r7,a
      0062A9 8E 82            [24] 1238 	mov	dpl,r6
      0062AB 8F 83            [24] 1239 	mov	dph,r7
      0062AD A3               [24] 1240 	inc	dptr
      0062AE A3               [24] 1241 	inc	dptr
      0062AF E4               [12] 1242 	clr	a
      0062B0 93               [24] 1243 	movc	a,@a+dptr
      0062B1 FC               [12] 1244 	mov	r4,a
      0062B2 A3               [24] 1245 	inc	dptr
      0062B3 E4               [12] 1246 	clr	a
      0062B4 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      0062B5 FD               [12] 1249 	mov	r5,a
      0062B6 4C               [12] 1250 	orl	a,r4
      0062B7 70 04            [24] 1251 	jnz	00124$
      0062B9 90 00 00         [24] 1252 	mov	dptr,#0x0000
      0062BC 22               [24] 1253 	ret
      0062BD                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      0062BD 90 08 20         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      0062C0 E0               [24] 1257 	movx	a,@dptr
      0062C1 FB               [12] 1258 	mov	r3,a
      0062C2 BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      0062C5 8E 82            [24] 1261 	mov	dpl,r6
      0062C7 8F 83            [24] 1262 	mov	dph,r7
      0062C9 E4               [12] 1263 	clr	a
      0062CA 93               [24] 1264 	movc	a,@a+dptr
      0062CB FE               [12] 1265 	mov	r6,a
      0062CC A3               [24] 1266 	inc	dptr
      0062CD E4               [12] 1267 	clr	a
      0062CE 93               [24] 1268 	movc	a,@a+dptr
      0062CF FF               [12] 1269 	mov	r7,a
      0062D0 90 08 1B         [24] 1270 	mov	dptr,#_control_pointer
      0062D3 EE               [12] 1271 	mov	a,r6
      0062D4 F0               [24] 1272 	movx	@dptr,a
      0062D5 EF               [12] 1273 	mov	a,r7
      0062D6 A3               [24] 1274 	inc	dptr
      0062D7 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      0062D8 74 07            [12] 1277 	mov	a,#0x07
      0062DA 2C               [12] 1278 	add	a, r4
      0062DB F5 82            [12] 1279 	mov	dpl,a
      0062DD E4               [12] 1280 	clr	a
      0062DE 3D               [12] 1281 	addc	a, r5
      0062DF F5 83            [12] 1282 	mov	dph,a
      0062E1 E4               [12] 1283 	clr	a
      0062E2 93               [24] 1284 	movc	a,@a+dptr
      0062E3 FE               [12] 1285 	mov	r6,a
      0062E4 A3               [24] 1286 	inc	dptr
      0062E5 E4               [12] 1287 	clr	a
      0062E6 93               [24] 1288 	movc	a,@a+dptr
      0062E7 FF               [12] 1289 	mov	r7,a
      0062E8 8E 82            [24] 1290 	mov	dpl, r6
      0062EA 8F 83            [24] 1291 	mov	dph, r7
      0062EC 22               [24] 1292 	ret
      0062ED                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      0062ED 90 08 1B         [24] 1295 	mov	dptr,#_control_pointer
      0062F0 EC               [12] 1296 	mov	a,r4
      0062F1 F0               [24] 1297 	movx	@dptr,a
      0062F2 ED               [12] 1298 	mov	a,r5
      0062F3 A3               [24] 1299 	inc	dptr
      0062F4 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      0062F5 90 00 09         [24] 1302 	mov	dptr,#0x0009
      0062F8 22               [24] 1303 	ret
      0062F9                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      0062F9 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      0062FC 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      0062FD                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      0062FD 90 10 00         [24] 1330 	mov	dptr,#0x1000
      006300 E0               [24] 1331 	movx	a,@dptr
      006301 FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006302 A3               [24] 1334 	inc	dptr
      006303 A3               [24] 1335 	inc	dptr
      006304 E0               [24] 1336 	movx	a,@dptr
      006305 FE               [12] 1337 	mov	r6,a
      006306 A3               [24] 1338 	inc	dptr
      006307 E0               [24] 1339 	movx	a,@dptr
      006308 FC               [12] 1340 	mov	r4,a
      006309 7D 00            [12] 1341 	mov	r5,#0x00
      00630B 8E 03            [24] 1342 	mov	ar3,r6
      00630D 7E 00            [12] 1343 	mov	r6,#0x00
      00630F ED               [12] 1344 	mov	a,r5
      006310 4B               [12] 1345 	orl	a,r3
      006311 FD               [12] 1346 	mov	r5,a
      006312 EC               [12] 1347 	mov	a,r4
      006313 4E               [12] 1348 	orl	a,r6
      006314 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      006315 A3               [24] 1351 	inc	dptr
      006316 E0               [24] 1352 	movx	a,@dptr
      006317 FC               [12] 1353 	mov	r4,a
      006318 A3               [24] 1354 	inc	dptr
      006319 E0               [24] 1355 	movx	a,@dptr
      00631A FA               [12] 1356 	mov	r2,a
      00631B 7B 00            [12] 1357 	mov	r3,#0x00
      00631D 8C 01            [24] 1358 	mov	ar1,r4
      00631F 7C 00            [12] 1359 	mov	r4,#0x00
      006321 EB               [12] 1360 	mov	a,r3
      006322 49               [12] 1361 	orl	a,r1
      006323 FB               [12] 1362 	mov	r3,a
      006324 EA               [12] 1363 	mov	a,r2
      006325 4C               [12] 1364 	orl	a,r4
      006326 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      006327 C3               [12] 1367 	clr	c
      006328 EB               [12] 1368 	mov	a,r3
      006329 94 03            [12] 1369 	subb	a,#0x03
      00632B EC               [12] 1370 	mov	a,r4
      00632C 94 00            [12] 1371 	subb	a,#0x00
      00632E 92 17            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      006330 EB               [12] 1374 	mov	a,r3
      006331 4C               [12] 1375 	orl	a,r4
      006332 B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      006335                       1377 01201$:
      006335 92 18            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      006337 ED               [12] 1380 	mov	a,r5
      006338 4E               [12] 1381 	orl	a,r6
      006339 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      00633C                       1383 01202$:
                                   1384 ;	assignBit
      00633C 92 1B            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      00633E 92 19            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      006340 90 08 23         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      006343 E4               [12] 1389 	clr	a
      006344 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      006345 90 07 C6         [24] 1392 	mov	dptr,#_raw_state
      006348 E0               [24] 1393 	movx	a,@dptr
      006349 FA               [12] 1394 	mov	r2,a
      00634A BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      00634D 90 07 C6         [24] 1396 	mov	dptr,#_raw_state
      006350 E4               [12] 1397 	clr	a
      006351 F0               [24] 1398 	movx	@dptr,a
      006352                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      006352 C0 07            [24] 1401 	push	ar7
      006354 90 08 18         [24] 1402 	mov	dptr,#_output_kind
      006357 E4               [12] 1403 	clr	a
      006358 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      006359 90 08 17         [24] 1406 	mov	dptr,#_control_phase
      00635C F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      00635D 90 08 1A         [24] 1409 	mov	dptr,#_control_zlp
      006360 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006361 90 10 01         [24] 1412 	mov	dptr,#0x1001
      006364 E0               [24] 1413 	movx	a,@dptr
      006365 90 07 B8         [24] 1414 	mov	dptr,#_D0SetupReqCode
      006368 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      006369 90 10 06         [24] 1417 	mov	dptr,#0x1006
      00636C E0               [24] 1418 	movx	a,@dptr
      00636D FA               [12] 1419 	mov	r2,a
      00636E A3               [24] 1420 	inc	dptr
      00636F E0               [24] 1421 	movx	a,@dptr
      006370 F9               [12] 1422 	mov	r1,a
      006371 78 00            [12] 1423 	mov	r0,#0x00
      006373 7F 00            [12] 1424 	mov	r7,#0x00
      006375 90 07 B9         [24] 1425 	mov	dptr,#_D0SetupLen
      006378 E8               [12] 1426 	mov	a,r0
      006379 4A               [12] 1427 	orl	a,r2
      00637A F0               [24] 1428 	movx	@dptr,a
      00637B E9               [12] 1429 	mov	a,r1
      00637C 4F               [12] 1430 	orl	a,r7
      00637D A3               [24] 1431 	inc	dptr
      00637E F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      00637F 90 07 B9         [24] 1434 	mov	dptr,#_D0SetupLen
      006382 E0               [24] 1435 	movx	a,@dptr
      006383 FA               [12] 1436 	mov	r2,a
      006384 A3               [24] 1437 	inc	dptr
      006385 E0               [24] 1438 	movx	a,@dptr
      006386 4A               [12] 1439 	orl	a,r2
      006387 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      00638A                       1441 01205$:
      00638A 92 1A            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00638C 90 22 00         [24] 1444 	mov	dptr,#0x2200
      00638F 74 C2            [12] 1445 	mov	a,#0xc2
      006391 F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      006392 90 22 08         [24] 1448 	mov	dptr,#0x2208
      006395 E4               [12] 1449 	clr	a
      006396 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      006397 90 07 B8         [24] 1452 	mov	dptr,#_D0SetupReqCode
      00639A E0               [24] 1453 	movx	a,@dptr
      00639B F5 27            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      00639D C3               [12] 1455 	clr	c
      00639E 74 0B            [12] 1456 	mov	a,#0x0b
      0063A0 95 27            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      0063A2 D0 07            [24] 1458 	pop	ar7
      0063A4 50 03            [24] 1459 	jnc	01206$
      0063A6 02 60 E4         [24] 1460 	ljmp	_control_stall
      0063A9                       1461 01206$:
                                   1462 ;	free result
      0063A9 E5 27            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      0063AB F5 F0            [12] 1464 	mov	b,a
      0063AD 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      0063AF 83               [24] 1466 	movc	a,@a+pc
      0063B0 F5 82            [12] 1467 	mov	dpl,a
      0063B2 E5 F0            [12] 1468 	mov	a,b
      0063B4 24 10            [12] 1469 	add	a,#(01208$-3-.)
      0063B6 83               [24] 1470 	movc	a,@a+pc
      0063B7 F5 83            [12] 1471 	mov	dph,a
      0063B9 E4               [12] 1472 	clr	a
      0063BA 73               [24] 1473 	jmp	@a+dptr
      0063BB                       1474 01207$:
      0063BB 63                    1475 	.db	00188$
      0063BC 09                    1476 	.db	00205$
      0063BD 4C                    1477 	.db	00282$
      0063BE 09                    1478 	.db	00205$
      0063BF 90                    1479 	.db	00290$
      0063C0 8D                    1480 	.db	00116$
      0063C1 D3                    1481 	.db	00103$
      0063C2 90                    1482 	.db	00290$
      0063C3 92                    1483 	.db	00150$
      0063C4 B6                    1484 	.db	00123$
      0063C5 C2                    1485 	.db	00157$
      0063C6 15                    1486 	.db	00173$
      0063C7                       1487 01208$:
      0063C7 66                    1488 	.db	00188$>>8
      0063C8 67                    1489 	.db	00205$>>8
      0063C9 6A                    1490 	.db	00282$>>8
      0063CA 67                    1491 	.db	00205$>>8
      0063CB 6A                    1492 	.db	00290$>>8
      0063CC 64                    1493 	.db	00116$>>8
      0063CD 63                    1494 	.db	00103$>>8
      0063CE 6A                    1495 	.db	00290$>>8
      0063CF 65                    1496 	.db	00150$>>8
      0063D0 64                    1497 	.db	00123$>>8
      0063D1 65                    1498 	.db	00157$>>8
      0063D2 66                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      0063D3                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      0063D3 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      0063D6 80 08            [24] 1504 	sjmp	00112$
      0063D8                       1505 01209$:
      0063D8 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      0063DB 80 03            [24] 1507 	sjmp	01211$
      0063DD                       1508 01210$:
      0063DD 02 60 E4         [24] 1509 	ljmp	_control_stall
      0063E0                       1510 01211$:
      0063E0                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      0063E0 8E 01            [24] 1513 	mov	ar1,r6
      0063E2 B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      0063E5 80 09            [24] 1515 	sjmp	00301$
      0063E7                       1516 01212$:
      0063E7 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      0063EA 80 04            [24] 1518 	sjmp	00301$
      0063EC                       1519 01213$:
                                   1520 ;	assignBit
      0063EC C2 1C            [12] 1521 	clr	_control_setup_sloc2_1_0
      0063EE 80 02            [24] 1522 	sjmp	00302$
      0063F0                       1523 00301$:
                                   1524 ;	assignBit
      0063F0 D2 1C            [12] 1525 	setb	_control_setup_sloc2_1_0
      0063F2                       1526 00302$:
      0063F2 E4               [12] 1527 	clr	a
      0063F3 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      0063F6 04               [12] 1529 	inc	a
      0063F7                       1530 01214$:
      0063F7 FA               [12] 1531 	mov	r2,a
      0063F8 A2 1C            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      0063FA E4               [12] 1533 	clr	a
      0063FB 33               [12] 1534 	rlc	a
      0063FC B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      0063FF 80 03            [24] 1536 	sjmp	00105$
      006401                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006401 02 60 E4         [24] 1539 	ljmp	_control_stall
      006404                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      006404 8E 02            [24] 1542 	mov	ar2,r6
      006406 90 08 1D         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      006409 ED               [12] 1544 	mov	a,r5
      00640A F0               [24] 1545 	movx	@dptr,a
      00640B 90 08 1E         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      00640E EB               [12] 1547 	mov	a,r3
      00640F F0               [24] 1548 	movx	@dptr,a
      006410 EC               [12] 1549 	mov	a,r4
      006411 A3               [24] 1550 	inc	dptr
      006412 F0               [24] 1551 	movx	@dptr,a
      006413 8A 82            [24] 1552 	mov	dpl, r2
      006415 12 61 82         [24] 1553 	lcall	_descriptor_select
      006418 85 82 28         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      00641B 85 83 29         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      00641E E5 28            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      006420 45 29            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006422 70 03            [24] 1559 	jnz	00107$
      006424 02 60 E4         [24] 1560 	ljmp	_control_stall
      006427                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      006427 90 07 B9         [24] 1563 	mov	dptr,#_D0SetupLen
      00642A E0               [24] 1564 	movx	a,@dptr
      00642B F8               [12] 1565 	mov	r0,a
      00642C A3               [24] 1566 	inc	dptr
      00642D E0               [24] 1567 	movx	a,@dptr
      00642E FA               [12] 1568 	mov	r2,a
      00642F C3               [12] 1569 	clr	c
      006430 E5 28            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      006432 98               [12] 1571 	subb	a,r0
      006433 E5 29            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006435 9A               [12] 1573 	subb	a,r2
      006436 50 06            [24] 1574 	jnc	00303$
      006438 E5 28            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      00643A 54 3F            [12] 1576 	anl	a,#0x3f
      00643C 60 04            [24] 1577 	jz	00304$
      00643E                       1578 00303$:
                                   1579 ;	assignBit
      00643E C2 1C            [12] 1580 	clr	_control_setup_sloc2_1_0
      006440 80 02            [24] 1581 	sjmp	00305$
      006442                       1582 00304$:
                                   1583 ;	assignBit
      006442 D2 1C            [12] 1584 	setb	_control_setup_sloc2_1_0
      006444                       1585 00305$:
      006444 90 08 1A         [24] 1586 	mov	dptr,#_control_zlp
      006447 A2 1C            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      006449 E4               [12] 1588 	clr	a
      00644A 33               [12] 1589 	rlc	a
      00644B F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      00644C 90 07 B9         [24] 1592 	mov	dptr,#_D0SetupLen
      00644F E0               [24] 1593 	movx	a,@dptr
      006450 F9               [12] 1594 	mov	r1,a
      006451 A3               [24] 1595 	inc	dptr
      006452 E0               [24] 1596 	movx	a,@dptr
      006453 FA               [12] 1597 	mov	r2,a
      006454 C3               [12] 1598 	clr	c
      006455 E5 28            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      006457 99               [12] 1600 	subb	a,r1
      006458 E5 29            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00645A 9A               [12] 1602 	subb	a,r2
      00645B 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      00645D 90 07 B9         [24] 1605 	mov	dptr,#_D0SetupLen
      006460 E5 28            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      006462 F0               [24] 1607 	movx	@dptr,a
      006463 E5 29            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006465 A3               [24] 1609 	inc	dptr
      006466 F0               [24] 1610 	movx	@dptr,a
      006467                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      006467 90 07 B9         [24] 1613 	mov	dptr,#_D0SetupLen
      00646A E0               [24] 1614 	movx	a,@dptr
      00646B F9               [12] 1615 	mov	r1,a
      00646C A3               [24] 1616 	inc	dptr
      00646D E0               [24] 1617 	movx	a,@dptr
      00646E 49               [12] 1618 	orl	a,r1
      00646F 60 04            [24] 1619 	jz	00306$
      006471 7A 01            [12] 1620 	mov	r2,#0x01
      006473 80 02            [24] 1621 	sjmp	00307$
      006475                       1622 00306$:
      006475 7A 02            [12] 1623 	mov	r2,#0x02
      006477                       1624 00307$:
      006477 90 08 17         [24] 1625 	mov	dptr,#_control_phase
      00647A EA               [12] 1626 	mov	a,r2
      00647B F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      00647C 90 07 B9         [24] 1629 	mov	dptr,#_D0SetupLen
      00647F E0               [24] 1630 	movx	a,@dptr
      006480 F9               [12] 1631 	mov	r1,a
      006481 A3               [24] 1632 	inc	dptr
      006482 E0               [24] 1633 	movx	a,@dptr
      006483 49               [12] 1634 	orl	a,r1
      006484 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      006486 02 61 06         [24] 1637 	ljmp	_control_next
      006489                       1638 00111$:
      006489 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      00648A 02 60 E4         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      00648D                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      00648D EF               [12] 1645 	mov	a,r7
      00648E 70 23            [24] 1646 	jnz	00118$
      006490 30 18 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      006493 30 1A 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      006496 8D 01            [24] 1649 	mov	ar1,r5
      006498 8E 02            [24] 1650 	mov	ar2,r6
      00649A C3               [12] 1651 	clr	c
      00649B 74 7F            [12] 1652 	mov	a,#0x7f
      00649D 99               [12] 1653 	subb	a,r1
      00649E E4               [12] 1654 	clr	a
      00649F 9A               [12] 1655 	subb	a,r2
      0064A0 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0064A2 90 07 B9         [24] 1659 	mov	dptr,#_D0SetupLen
      0064A5 ED               [12] 1660 	mov	a,r5
      0064A6 F0               [24] 1661 	movx	@dptr,a
      0064A7 EE               [12] 1662 	mov	a,r6
      0064A8 A3               [24] 1663 	inc	dptr
      0064A9 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      0064AA 90 08 17         [24] 1666 	mov	dptr,#_control_phase
      0064AD 74 03            [12] 1667 	mov	a,#0x03
      0064AF F0               [24] 1668 	movx	@dptr,a
      0064B0 02 6A 93         [24] 1669 	ljmp	00291$
      0064B3                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      0064B3 02 60 E4         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0064B6                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0064B6 EF               [12] 1676 	mov	a,r7
      0064B7 70 3C            [24] 1677 	jnz	00145$
      0064B9 30 18 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      0064BC 30 1A 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      0064BF 8D 01            [24] 1680 	mov	ar1,r5
      0064C1 8E 02            [24] 1681 	mov	ar2,r6
      0064C3 C3               [12] 1682 	clr	c
      0064C4 74 01            [12] 1683 	mov	a,#0x01
      0064C6 99               [12] 1684 	subb	a,r1
      0064C7 E4               [12] 1685 	clr	a
      0064C8 9A               [12] 1686 	subb	a,r2
      0064C9 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      0064CB C0 06            [24] 1690 	push	ar6
      0064CD C0 05            [24] 1691 	push	ar5
      0064CF 12 60 8D         [24] 1692 	lcall	_endpoints_reset
      0064D2 D0 05            [24] 1693 	pop	ar5
      0064D4 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      0064D6 90 07 BE         [24] 1696 	mov	dptr,#_D0UsbConfig
      0064D9 ED               [12] 1697 	mov	a,r5
      0064DA F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      0064DB A2 1B            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      0064DD B3               [12] 1701 	cpl	c
      0064DE 92 1C            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      0064E0 90 07 BF         [24] 1703 	mov	dptr,#_USB_EnumStatus
      0064E3 E4               [12] 1704 	clr	a
      0064E4 33               [12] 1705 	rlc	a
      0064E5 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      0064E6 90 07 E8         [24] 1708 	mov	dptr,#_keyboard_reset
      0064E9 74 01            [12] 1709 	mov	a,#0x01
      0064EB F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      0064EC 90 08 17         [24] 1712 	mov	dptr,#_control_phase
      0064EF 74 03            [12] 1713 	mov	a,#0x03
      0064F1 F0               [24] 1714 	movx	@dptr,a
      0064F2 02 6A 93         [24] 1715 	ljmp	00291$
      0064F5                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      0064F5 BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      0064F8 80 03            [24] 1719 	sjmp	01232$
      0064FA                       1720 01231$:
      0064FA 02 60 E4         [24] 1721 	ljmp	_control_stall
      0064FD                       1722 01232$:
      0064FD 90 07 BE         [24] 1723 	mov	dptr,#_D0UsbConfig
      006500 E0               [24] 1724 	movx	a,@dptr
      006501 70 03            [24] 1725 	jnz	01233$
      006503 02 60 E4         [24] 1726 	ljmp	_control_stall
      006506                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006506 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      006509 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      00650C 8D 01            [24] 1731 	mov	ar1,r5
      00650E 8E 02            [24] 1732 	mov	ar2,r6
      006510 B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      006513 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      006516 90 07 B9         [24] 1735 	mov	dptr,#_D0SetupLen
      006519 E0               [24] 1736 	movx	a,@dptr
      00651A F9               [12] 1737 	mov	r1,a
      00651B A3               [24] 1738 	inc	dptr
      00651C E0               [24] 1739 	movx	a,@dptr
      00651D FA               [12] 1740 	mov	r2,a
      00651E B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      006521 BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      006524 90 07 C6         [24] 1743 	mov	dptr,#_raw_state
      006527 E0               [24] 1744 	movx	a,@dptr
      006528 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      00652A 90 07 C6         [24] 1747 	mov	dptr,#_raw_state
      00652D 74 01            [12] 1748 	mov	a,#0x01
      00652F F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      006530 90 08 18         [24] 1751 	mov	dptr,#_output_kind
      006533 F0               [24] 1752 	movx	@dptr,a
      006534 80 52            [24] 1753 	sjmp	00136$
      006536                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006536 EB               [12] 1756 	mov	a,r3
      006537 4C               [12] 1757 	orl	a,r4
      006538 70 20            [24] 1758 	jnz	00130$
      00653A 8D 01            [24] 1759 	mov	ar1,r5
      00653C 8E 02            [24] 1760 	mov	ar2,r6
      00653E B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      006541 BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      006544 90 07 B9         [24] 1763 	mov	dptr,#_D0SetupLen
      006547 E0               [24] 1764 	movx	a,@dptr
      006548 F9               [12] 1765 	mov	r1,a
      006549 A3               [24] 1766 	inc	dptr
      00654A E0               [24] 1767 	movx	a,@dptr
      00654B FA               [12] 1768 	mov	r2,a
      00654C B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      00654F BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      006552 90 08 18         [24] 1772 	mov	dptr,#_output_kind
      006555 74 02            [12] 1773 	mov	a,#0x02
      006557 F0               [24] 1774 	movx	@dptr,a
      006558 80 2E            [24] 1775 	sjmp	00136$
      00655A                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      00655A BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      00655D BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      006560 8D 01            [24] 1780 	mov	ar1,r5
      006562 8E 02            [24] 1781 	mov	ar2,r6
      006564 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      006567 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      00656A 90 07 B9         [24] 1784 	mov	dptr,#_D0SetupLen
      00656D E0               [24] 1785 	movx	a,@dptr
      00656E F9               [12] 1786 	mov	r1,a
      00656F A3               [24] 1787 	inc	dptr
      006570 E0               [24] 1788 	movx	a,@dptr
      006571 FA               [12] 1789 	mov	r2,a
      006572 B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      006575 BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      006578 90 08 18         [24] 1793 	mov	dptr,#_output_kind
      00657B 74 03            [12] 1794 	mov	a,#0x03
      00657D F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      00657E 90 08 19         [24] 1797 	mov	dptr,#_output_report_id
      006581 23               [12] 1798 	rl	a
      006582 F0               [24] 1799 	movx	@dptr,a
      006583 80 03            [24] 1800 	sjmp	00136$
      006585                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      006585 02 60 E4         [24] 1803 	ljmp	_control_stall
      006588                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      006588 90 08 17         [24] 1806 	mov	dptr,#_control_phase
      00658B 74 04            [12] 1807 	mov	a,#0x04
      00658D F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      00658E 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      00658F 02 60 E4         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      006592                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006592 BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      006595 30 18 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      006598 30 19 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      00659B 90 07 B9         [24] 1819 	mov	dptr,#_D0SetupLen
      00659E E0               [24] 1820 	movx	a,@dptr
      00659F F9               [12] 1821 	mov	r1,a
      0065A0 A3               [24] 1822 	inc	dptr
      0065A1 E0               [24] 1823 	movx	a,@dptr
      0065A2 FA               [12] 1824 	mov	r2,a
      0065A3 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      0065A6 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0065A9 90 07 BE         [24] 1828 	mov	dptr,#_D0UsbConfig
      0065AC E0               [24] 1829 	movx	a,@dptr
      0065AD 90 10 00         [24] 1830 	mov	dptr,#0x1000
      0065B0 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      0065B1 90 22 08         [24] 1833 	mov	dptr,#0x2208
      0065B4 74 01            [12] 1834 	mov	a,#0x01
      0065B6 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0065B7 90 08 17         [24] 1837 	mov	dptr,#_control_phase
      0065BA 04               [12] 1838 	inc	a
      0065BB F0               [24] 1839 	movx	@dptr,a
      0065BC 02 6A 93         [24] 1840 	ljmp	00291$
      0065BF                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      0065BF 02 60 E4         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0065C2                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0065C2 BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      0065C5 30 17 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      0065C8 30 19 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      0065CB 90 07 B9         [24] 1850 	mov	dptr,#_D0SetupLen
      0065CE E0               [24] 1851 	movx	a,@dptr
      0065CF F9               [12] 1852 	mov	r1,a
      0065D0 A3               [24] 1853 	inc	dptr
      0065D1 E0               [24] 1854 	movx	a,@dptr
      0065D2 FA               [12] 1855 	mov	r2,a
      0065D3 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      0065D6 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      0065D9 90 07 BE         [24] 1858 	mov	dptr,#_D0UsbConfig
      0065DC E0               [24] 1859 	movx	a,@dptr
      0065DD 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      0065DF 90 10 00         [24] 1862 	mov	dptr,#0x1000
      0065E2 E4               [12] 1863 	clr	a
      0065E3 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      0065E4 90 22 08         [24] 1866 	mov	dptr,#0x2208
      0065E7 04               [12] 1867 	inc	a
      0065E8 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      0065E9 90 08 17         [24] 1870 	mov	dptr,#_control_phase
      0065EC 04               [12] 1871 	inc	a
      0065ED F0               [24] 1872 	movx	@dptr,a
      0065EE 02 6A 93         [24] 1873 	ljmp	00291$
      0065F1                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0065F1 30 17 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      0065F4 90 07 BE         [24] 1877 	mov	dptr,#_D0UsbConfig
      0065F7 E0               [24] 1878 	movx	a,@dptr
      0065F8 60 18            [24] 1879 	jz	00161$
      0065FA BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      0065FD 30 1A 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006600 EB               [12] 1883 	mov	a,r3
      006601 4C               [12] 1884 	orl	a,r4
      006602 70 05            [24] 1885 	jnz	00159$
      006604 90 06 96         [24] 1886 	mov	dptr,#_keyboard_idle
      006607 EE               [12] 1887 	mov	a,r6
      006608 F0               [24] 1888 	movx	@dptr,a
      006609                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      006609 90 08 17         [24] 1891 	mov	dptr,#_control_phase
      00660C 74 03            [12] 1892 	mov	a,#0x03
      00660E F0               [24] 1893 	movx	@dptr,a
      00660F 02 6A 93         [24] 1894 	ljmp	00291$
      006612                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      006612 02 60 E4         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006615                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006615 BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      006618 30 17 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      00661B 30 19 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      00661E 30 1A 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      006621 90 07 BE         [24] 1905 	mov	dptr,#_D0UsbConfig
      006624 E0               [24] 1906 	movx	a,@dptr
      006625 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      006627 90 08 17         [24] 1909 	mov	dptr,#_control_phase
      00662A 74 03            [12] 1910 	mov	a,#0x03
      00662C F0               [24] 1911 	movx	@dptr,a
      00662D 02 6A 93         [24] 1912 	ljmp	00291$
      006630                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006630 EB               [12] 1915 	mov	a,r3
      006631 4C               [12] 1916 	orl	a,r4
      006632 70 2C            [24] 1917 	jnz	00175$
      006634 90 07 BE         [24] 1918 	mov	dptr,#_D0UsbConfig
      006637 E0               [24] 1919 	movx	a,@dptr
      006638 60 26            [24] 1920 	jz	00175$
      00663A BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      00663D 30 1A 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      006640 8D 01            [24] 1923 	mov	ar1,r5
      006642 8E 02            [24] 1924 	mov	ar2,r6
      006644 C3               [12] 1925 	clr	c
      006645 74 01            [12] 1926 	mov	a,#0x01
      006647 99               [12] 1927 	subb	a,r1
      006648 E4               [12] 1928 	clr	a
      006649 9A               [12] 1929 	subb	a,r2
      00664A 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      00664C 90 0E 0B         [24] 1933 	mov	dptr,#_keyboard_protocol
      00664F ED               [12] 1934 	mov	a,r5
      006650 F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006651 90 07 E8         [24] 1937 	mov	dptr,#_keyboard_reset
      006654 74 01            [12] 1938 	mov	a,#0x01
      006656 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      006657 90 08 17         [24] 1941 	mov	dptr,#_control_phase
      00665A 74 03            [12] 1942 	mov	a,#0x03
      00665C F0               [24] 1943 	movx	@dptr,a
      00665D 02 6A 93         [24] 1944 	ljmp	00291$
      006660                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      006660 02 60 E4         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      006663                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      006663 20 19 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      006666 02 60 E4         [24] 1952 	ljmp	_control_stall
      006669                       1953 01283$:
      006669 90 07 B9         [24] 1954 	mov	dptr,#_D0SetupLen
      00666C E0               [24] 1955 	movx	a,@dptr
      00666D F9               [12] 1956 	mov	r1,a
      00666E A3               [24] 1957 	inc	dptr
      00666F E0               [24] 1958 	movx	a,@dptr
      006670 FA               [12] 1959 	mov	r2,a
      006671 B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      006674 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      006677 80 03            [24] 1962 	sjmp	01285$
      006679                       1963 01284$:
      006679 02 60 E4         [24] 1964 	ljmp	_control_stall
      00667C                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00667C E4               [12] 1967 	clr	a
      00667D BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      006680 04               [12] 1969 	inc	a
      006681                       1970 01286$:
      006681 FA               [12] 1971 	mov	r2,a
      006682 60 03            [24] 1972 	jz	00196$
      006684 20 18 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      006687                       1974 00196$:
      006687 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      00668A 30 17 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      00668D 90 07 BE         [24] 1977 	mov	dptr,#_D0UsbConfig
      006690 E0               [24] 1978 	movx	a,@dptr
      006691 70 29            [24] 1979 	jnz	00189$
      006693                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006693 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      006696 90 07 BE         [24] 1983 	mov	dptr,#_D0UsbConfig
      006699 E0               [24] 1984 	movx	a,@dptr
      00669A 60 6A            [24] 1985 	jz	00190$
      00669C EB               [12] 1986 	mov	a,r3
      00669D 4C               [12] 1987 	orl	a,r4
      00669E 60 1C            [24] 1988 	jz	00189$
      0066A0 8B 00            [24] 1989 	mov	ar0,r3
      0066A2 8C 01            [24] 1990 	mov	ar1,r4
      0066A4 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      0066A7 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      0066AA 80 10            [24] 1993 	sjmp	00189$
      0066AC                       1994 01298$:
      0066AC C3               [12] 1995 	clr	c
      0066AD E8               [12] 1996 	mov	a,r0
      0066AE 94 81            [12] 1997 	subb	a,#0x81
      0066B0 E9               [12] 1998 	mov	a,r1
      0066B1 94 00            [12] 1999 	subb	a,#0x00
      0066B3 40 51            [24] 2000 	jc	00190$
      0066B5 74 83            [12] 2001 	mov	a,#0x83
      0066B7 98               [12] 2002 	subb	a,r0
      0066B8 E4               [12] 2003 	clr	a
      0066B9 99               [12] 2004 	subb	a,r1
      0066BA 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      0066BC                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0066BC 8B 01            [24] 2009 	mov	ar1,r3
      0066BE 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0066C1 EA               [12] 2012 	mov	a,r2
      0066C2 60 0B            [24] 2013 	jz	00308$
      0066C4 90 07 C0         [24] 2014 	mov	dptr,#_USB_SleepStatus
      0066C7 E0               [24] 2015 	movx	a,@dptr
      0066C8 54 01            [12] 2016 	anl	a,#0x01
      0066CA 25 E0            [12] 2017 	add	a,acc
      0066CC FA               [12] 2018 	mov	r2,a
      0066CD 80 22            [24] 2019 	sjmp	00309$
      0066CF                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0066CF BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      0066D2 E9               [12] 2023 	mov	a,r1
      0066D3 60 18            [24] 2024 	jz	00310$
      0066D5 89 00            [24] 2025 	mov	ar0,r1
      0066D7 79 00            [12] 2026 	mov	r1,#0x00
      0066D9 74 22            [12] 2027 	mov	a,#0x22
      0066DB 29               [12] 2028 	add	a, r1
      0066DC F9               [12] 2029 	mov	r1,a
      0066DD 88 82            [24] 2030 	mov	dpl,r0
      0066DF 89 83            [24] 2031 	mov	dph,r1
      0066E1 E0               [24] 2032 	movx	a,@dptr
      0066E2 F9               [12] 2033 	mov	r1,a
      0066E3 53 01 03         [24] 2034 	anl	ar1,#0x03
      0066E6 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      0066E9 79 01            [12] 2036 	mov	r1,#0x01
      0066EB 80 02            [24] 2037 	sjmp	00311$
      0066ED                       2038 00310$:
      0066ED 79 00            [12] 2039 	mov	r1,#0x00
      0066EF                       2040 00311$:
      0066EF 89 02            [24] 2041 	mov	ar2,r1
      0066F1                       2042 00309$:
      0066F1 90 10 00         [24] 2043 	mov	dptr,#0x1000
      0066F4 EA               [12] 2044 	mov	a,r2
      0066F5 F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      0066F6 A3               [24] 2047 	inc	dptr
      0066F7 E4               [12] 2048 	clr	a
      0066F8 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      0066F9 90 22 08         [24] 2051 	mov	dptr,#0x2208
      0066FC 74 02            [12] 2052 	mov	a,#0x02
      0066FE F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      0066FF 90 08 17         [24] 2055 	mov	dptr,#_control_phase
      006702 F0               [24] 2056 	movx	@dptr,a
      006703 02 6A 93         [24] 2057 	ljmp	00291$
      006706                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006706 02 60 E4         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006709                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      006709 20 1A 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      00670C 02 67 9C         [24] 2065 	ljmp	00279$
      00670F                       2066 01307$:
      00670F 90 07 BE         [24] 2067 	mov	dptr,#_D0UsbConfig
      006712 E0               [24] 2068 	movx	a,@dptr
      006713 70 03            [24] 2069 	jnz	01308$
      006715 02 67 9C         [24] 2070 	ljmp	00279$
      006718                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      006718 EF               [12] 2073 	mov	a,r7
      006719 70 29            [24] 2074 	jnz	00218$
      00671B 8D 01            [24] 2075 	mov	ar1,r5
      00671D 8E 02            [24] 2076 	mov	ar2,r6
      00671F B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      006722 BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      006725 30 18 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006728 90 07 B8         [24] 2081 	mov	dptr,#_D0SetupReqCode
      00672B E0               [24] 2082 	movx	a,@dptr
      00672C FA               [12] 2083 	mov	r2,a
      00672D BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      006730 90 07 C0         [24] 2085 	mov	dptr,#_USB_SleepStatus
      006733 E0               [24] 2086 	movx	a,@dptr
      006734 43 E0 01         [24] 2087 	orl	acc,#0x01
      006737 F0               [24] 2088 	movx	@dptr,a
      006738 80 59            [24] 2089 	sjmp	00219$
      00673A                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      00673A 90 07 C0         [24] 2092 	mov	dptr,#_USB_SleepStatus
      00673D E0               [24] 2093 	movx	a,@dptr
      00673E 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      006741 F0               [24] 2095 	movx	@dptr,a
      006742 80 4F            [24] 2096 	sjmp	00219$
      006744                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006744 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      006747 30 19 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      00674A 8B 01            [24] 2101 	mov	ar1,r3
      00674C 8C 02            [24] 2102 	mov	ar2,r4
      00674E C3               [12] 2103 	clr	c
      00674F E9               [12] 2104 	mov	a,r1
      006750 94 81            [12] 2105 	subb	a,#0x81
      006752 EA               [12] 2106 	mov	a,r2
      006753 94 00            [12] 2107 	subb	a,#0x00
      006755 40 39            [24] 2108 	jc	00212$
      006757 74 83            [12] 2109 	mov	a,#0x83
      006759 99               [12] 2110 	subb	a,r1
      00675A E4               [12] 2111 	clr	a
      00675B 9A               [12] 2112 	subb	a,r2
      00675C 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      00675E 8B 02            [24] 2116 	mov	ar2,r3
      006760 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006763 8A 00            [24] 2119 	mov	ar0,r2
      006765 79 00            [12] 2120 	mov	r1,#0x00
      006767 74 22            [12] 2121 	mov	a,#0x22
      006769 29               [12] 2122 	add	a, r1
      00676A F9               [12] 2123 	mov	r1,a
      00676B 88 28            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      00676D 89 29            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      00676F 90 07 B8         [24] 2126 	mov	dptr,#_D0SetupReqCode
      006772 E0               [24] 2127 	movx	a,@dptr
      006773 F9               [12] 2128 	mov	r1,a
      006774 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006777 79 03            [12] 2130 	mov	r1,#0x03
      006779 80 02            [24] 2131 	sjmp	00319$
      00677B                       2132 00318$:
      00677B 79 02            [12] 2133 	mov	r1,#0x02
      00677D                       2134 00319$:
      00677D 43 01 10         [24] 2135 	orl	ar1,#0x10
      006780 85 28 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      006783 85 29 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006786 E9               [12] 2138 	mov	a,r1
      006787 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006788 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      00678B 12 60 70         [24] 2142 	lcall	_raw_complete
      00678E 80 03            [24] 2143 	sjmp	00219$
      006790                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      006790 02 60 E4         [24] 2146 	ljmp	_control_stall
      006793                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006793 90 08 17         [24] 2149 	mov	dptr,#_control_phase
      006796 74 03            [12] 2150 	mov	a,#0x03
      006798 F0               [24] 2151 	movx	@dptr,a
      006799 02 6A 93         [24] 2152 	ljmp	00291$
      00679C                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00679C E4               [12] 2155 	clr	a
      00679D BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      0067A0 04               [12] 2157 	inc	a
      0067A1                       2158 01324$:
      0067A1 FA               [12] 2159 	mov	r2,a
      0067A2 70 03            [24] 2160 	jnz	01326$
      0067A4 02 6A 0E         [24] 2161 	ljmp	00273$
      0067A7                       2162 01326$:
      0067A7 90 07 B8         [24] 2163 	mov	dptr,#_D0SetupReqCode
      0067AA E0               [24] 2164 	movx	a,@dptr
      0067AB F9               [12] 2165 	mov	r1,a
      0067AC B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      0067AF 80 03            [24] 2167 	sjmp	01328$
      0067B1                       2168 01327$:
      0067B1 02 6A 0E         [24] 2169 	ljmp	00273$
      0067B4                       2170 01328$:
      0067B4 90 07 BE         [24] 2171 	mov	dptr,#_D0UsbConfig
      0067B7 E0               [24] 2172 	movx	a,@dptr
      0067B8 70 03            [24] 2173 	jnz	01329$
      0067BA 02 6A 0E         [24] 2174 	ljmp	00273$
      0067BD                       2175 01329$:
      0067BD 90 07 B9         [24] 2176 	mov	dptr,#_D0SetupLen
      0067C0 E0               [24] 2177 	movx	a,@dptr
      0067C1 F8               [12] 2178 	mov	r0,a
      0067C2 A3               [24] 2179 	inc	dptr
      0067C3 E0               [24] 2180 	movx	a,@dptr
      0067C4 48               [12] 2181 	orl	a,r0
      0067C5 70 03            [24] 2182 	jnz	01330$
      0067C7 02 6A 0E         [24] 2183 	ljmp	00273$
      0067CA                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      0067CA C0 03            [24] 2186 	push	ar3
      0067CC C0 04            [24] 2187 	push	ar4
      0067CE 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0067D0 8E 00            [24] 2190 	mov	ar0,r6
      0067D2 B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      0067D5 E8               [12] 2192 	mov	a,r0
      0067D6 80 01            [24] 2193 	sjmp	01332$
      0067D8                       2194 01331$:
      0067D8 E4               [12] 2195 	clr	a
      0067D9                       2196 01332$:
      0067D9 F5 28            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      0067DB D0 04            [24] 2198 	pop	ar4
      0067DD D0 03            [24] 2199 	pop	ar3
      0067DF E5 28            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      0067E1 60 17            [24] 2201 	jz	00251$
      0067E3 EB               [12] 2202 	mov	a,r3
      0067E4 4C               [12] 2203 	orl	a,r4
      0067E5 70 13            [24] 2204 	jnz	00251$
      0067E7 E9               [12] 2205 	mov	a,r1
      0067E8 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      0067EA 90 08 21         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      0067ED 74 08            [12] 2209 	mov	a,#0x08
      0067EF F0               [24] 2210 	movx	@dptr,a
      0067F0 E4               [12] 2211 	clr	a
      0067F1 A3               [24] 2212 	inc	dptr
      0067F2 F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      0067F3 90 08 23         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      0067F6 F0               [24] 2216 	movx	@dptr,a
      0067F7 02 69 7E         [24] 2217 	ljmp	00252$
      0067FA                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0067FA E5 28            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      0067FC 60 27            [24] 2221 	jz	00245$
      0067FE BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      006801 BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006804 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      006807                       2226 01339$:
      006807 50 1C            [24] 2227 	jnc	00245$
      006809 E9               [12] 2228 	mov	a,r1
      00680A 90 C0 D0         [24] 2229 	mov	dptr,#_shared_lengths
      00680D 93               [24] 2230 	movc	a,@a+dptr
      00680E F8               [12] 2231 	mov	r0,a
      00680F 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      006811 90 08 21         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      006814 E8               [12] 2235 	mov	a,r0
      006815 F0               [24] 2236 	movx	@dptr,a
      006816 E4               [12] 2237 	clr	a
      006817 A3               [24] 2238 	inc	dptr
      006818 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      006819 E9               [12] 2241 	mov	a,r1
      00681A 90 C0 C9         [24] 2242 	mov	dptr,#_shared_offsets
      00681D 93               [24] 2243 	movc	a,@a+dptr
      00681E 90 08 23         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      006821 F0               [24] 2245 	movx	@dptr,a
      006822 02 69 7E         [24] 2246 	ljmp	00252$
      006825                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006825 E5 28            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      006827 60 7A            [24] 2250 	jz	00240$
      006829 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      00682C BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      00682F E9               [12] 2253 	mov	a,r1
      006830 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006832 90 07 B9         [24] 2256 	mov	dptr,#_D0SetupLen
      006835 E0               [24] 2257 	movx	a,@dptr
      006836 F8               [12] 2258 	mov	r0,a
      006837 A3               [24] 2259 	inc	dptr
      006838 E0               [24] 2260 	movx	a,@dptr
      006839 F9               [12] 2261 	mov	r1,a
      00683A C3               [12] 2262 	clr	c
      00683B E8               [12] 2263 	mov	a,r0
      00683C 94 20            [12] 2264 	subb	a,#0x20
      00683E E9               [12] 2265 	mov	a,r1
      00683F 94 00            [12] 2266 	subb	a,#0x00
      006841 50 0A            [24] 2267 	jnc	00320$
      006843 90 07 B9         [24] 2268 	mov	dptr,#_D0SetupLen
      006846 E0               [24] 2269 	movx	a,@dptr
      006847 F8               [12] 2270 	mov	r0,a
      006848 A3               [24] 2271 	inc	dptr
      006849 E0               [24] 2272 	movx	a,@dptr
      00684A F9               [12] 2273 	mov	r1,a
      00684B 80 04            [24] 2274 	sjmp	00321$
      00684D                       2275 00320$:
      00684D 78 20            [12] 2276 	mov	r0,#0x20
      00684F 79 00            [12] 2277 	mov	r1,#0x00
      006851                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006851 75 28 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      006854                       2281 00293$:
      006854 C0 03            [24] 2282 	push	ar3
      006856 C0 04            [24] 2283 	push	ar4
      006858 AB 28            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      00685A 7C 00            [12] 2285 	mov	r4,#0x00
      00685C C3               [12] 2286 	clr	c
      00685D EB               [12] 2287 	mov	a,r3
      00685E 98               [12] 2288 	subb	a,r0
      00685F EC               [12] 2289 	mov	a,r4
      006860 99               [12] 2290 	subb	a,r1
      006861 D0 04            [24] 2291 	pop	ar4
      006863 D0 03            [24] 2292 	pop	ar3
      006865 50 32            [24] 2293 	jnc	00222$
      006867 C0 00            [24] 2294 	push	ar0
      006869 C0 01            [24] 2295 	push	ar1
      00686B 85 28 2A         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      00686E 74 10            [12] 2297 	mov	a,#0x10
      006870 24 00            [12] 2298 	add	a, #0x00
      006872 F5 2B            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      006874 A8 28            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      006876 79 00            [12] 2301 	mov	r1,#0x00
      006878 74 C0            [12] 2302 	mov	a,#0xc0
      00687A 28               [12] 2303 	add	a, r0
      00687B F8               [12] 2304 	mov	r0,a
      00687C E4               [12] 2305 	clr	a
      00687D 39               [12] 2306 	addc	a, r1
      00687E F9               [12] 2307 	mov	r1,a
      00687F 88 82            [24] 2308 	mov	dpl,r0
      006881 74 10            [12] 2309 	mov	a,#0x10
      006883 29               [12] 2310 	add	a, r1
      006884 F5 83            [12] 2311 	mov	dph,a
      006886 E0               [24] 2312 	movx	a,@dptr
      006887 85 2A 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      00688A 85 2B 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      00688D F0               [24] 2315 	movx	@dptr,a
      00688E E5 28            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      006890 04               [12] 2317 	inc	a
      006891 F5 28            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      006893 D0 01            [24] 2319 	pop	ar1
      006895 D0 00            [24] 2320 	pop	ar0
      006897 80 BB            [24] 2321 	sjmp	00293$
      006899                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      006899 90 08 21         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      00689C E4               [12] 2325 	clr	a
      00689D F0               [24] 2326 	movx	@dptr,a
      00689E A3               [24] 2327 	inc	dptr
      00689F F0               [24] 2328 	movx	@dptr,a
      0068A0 02 69 7E         [24] 2329 	ljmp	00252$
      0068A3                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0068A3 8D 00            [24] 2332 	mov	ar0,r5
      0068A5 8E 01            [24] 2333 	mov	ar1,r6
      0068A7 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      0068AA B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      0068AD EB               [12] 2336 	mov	a,r3
      0068AE 4C               [12] 2337 	orl	a,r4
      0068AF 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0068B1 90 07 C3         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      0068B4 E0               [24] 2341 	movx	a,@dptr
      0068B5 90 10 00         [24] 2342 	mov	dptr,#0x1000
      0068B8 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      0068B9 90 08 21         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      0068BC E4               [12] 2346 	clr	a
      0068BD F0               [24] 2347 	movx	@dptr,a
      0068BE A3               [24] 2348 	inc	dptr
      0068BF F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      0068C0 90 07 B9         [24] 2351 	mov	dptr,#_D0SetupLen
      0068C3 04               [12] 2352 	inc	a
      0068C4 F0               [24] 2353 	movx	@dptr,a
      0068C5 E4               [12] 2354 	clr	a
      0068C6 A3               [24] 2355 	inc	dptr
      0068C7 F0               [24] 2356 	movx	@dptr,a
      0068C8 02 69 7E         [24] 2357 	ljmp	00252$
      0068CB                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0068CB B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      0068CE B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      0068D1 BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      0068D4 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0068D7 C0 03            [24] 2365 	push	ar3
      0068D9 C0 04            [24] 2366 	push	ar4
      0068DB 90 10 00         [24] 2367 	mov	dptr,#0x1000
      0068DE 74 06            [12] 2368 	mov	a,#0x06
      0068E0 F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0068E1 90 07 C3         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      0068E4 E0               [24] 2372 	movx	a,@dptr
      0068E5 90 10 01         [24] 2373 	mov	dptr,#0x1001
      0068E8 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      0068E9 90 08 21         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      0068EC E4               [12] 2377 	clr	a
      0068ED F0               [24] 2378 	movx	@dptr,a
      0068EE A3               [24] 2379 	inc	dptr
      0068EF F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      0068F0 90 07 B9         [24] 2382 	mov	dptr,#_D0SetupLen
      0068F3 E0               [24] 2383 	movx	a,@dptr
      0068F4 FB               [12] 2384 	mov	r3,a
      0068F5 A3               [24] 2385 	inc	dptr
      0068F6 E0               [24] 2386 	movx	a,@dptr
      0068F7 FC               [12] 2387 	mov	r4,a
      0068F8 C3               [12] 2388 	clr	c
      0068F9 74 02            [12] 2389 	mov	a,#0x02
      0068FB 9B               [12] 2390 	subb	a,r3
      0068FC E4               [12] 2391 	clr	a
      0068FD 9C               [12] 2392 	subb	a,r4
      0068FE D0 04            [24] 2393 	pop	ar4
      006900 D0 03            [24] 2394 	pop	ar3
      006902 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      006904 90 07 B9         [24] 2397 	mov	dptr,#_D0SetupLen
      006907 74 02            [12] 2398 	mov	a,#0x02
      006909 F0               [24] 2399 	movx	@dptr,a
      00690A E4               [12] 2400 	clr	a
      00690B A3               [24] 2401 	inc	dptr
      00690C F0               [24] 2402 	movx	@dptr,a
      00690D 80 6F            [24] 2403 	sjmp	00252$
      00690F                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00690F B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      006912 B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      006915 BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      006918 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      00691B 90 10 00         [24] 2411 	mov	dptr,#0x1000
      00691E 74 41            [12] 2412 	mov	a,#0x41
      006920 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      006921 A3               [24] 2415 	inc	dptr
      006922 74 4B            [12] 2416 	mov	a,#0x4b
      006924 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      006925 A3               [24] 2419 	inc	dptr
      006926 74 42            [12] 2420 	mov	a,#0x42
      006928 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      006929 A3               [24] 2423 	inc	dptr
      00692A 74 54            [12] 2424 	mov	a,#0x54
      00692C F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      00692D A3               [24] 2427 	inc	dptr
      00692E 74 01            [12] 2428 	mov	a,#0x01
      006930 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      006931 90 07 C4         [24] 2431 	mov	dptr,#_ak820_boot_stage
      006934 E0               [24] 2432 	movx	a,@dptr
      006935 90 10 05         [24] 2433 	mov	dptr,#0x1005
      006938 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006939 90 07 C5         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      00693C E0               [24] 2437 	movx	a,@dptr
      00693D 90 10 06         [24] 2438 	mov	dptr,#0x1006
      006940 F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006941 90 07 BF         [24] 2441 	mov	dptr,#_USB_EnumStatus
      006944 E0               [24] 2442 	movx	a,@dptr
      006945 60 02            [24] 2443 	jz	00322$
      006947 74 01            [12] 2444 	mov	a,#0x01
      006949                       2445 00322$:
      006949 F9               [12] 2446 	mov	r1,a
      00694A 90 07 C0         [24] 2447 	mov	dptr,#_USB_SleepStatus
      00694D E0               [24] 2448 	movx	a,@dptr
      00694E 54 02            [12] 2449 	anl	a,#0x02
      006950 F8               [12] 2450 	mov	r0,a
      006951 E9               [12] 2451 	mov	a,r1
      006952 42 00            [12] 2452 	orl	ar0,a
      006954 90 10 07         [24] 2453 	mov	dptr,#0x1007
      006957 E8               [12] 2454 	mov	a,r0
      006958 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      006959 90 08 21         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      00695C E4               [12] 2458 	clr	a
      00695D F0               [24] 2459 	movx	@dptr,a
      00695E A3               [24] 2460 	inc	dptr
      00695F F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      006960 90 07 B9         [24] 2463 	mov	dptr,#_D0SetupLen
      006963 E0               [24] 2464 	movx	a,@dptr
      006964 F8               [12] 2465 	mov	r0,a
      006965 A3               [24] 2466 	inc	dptr
      006966 E0               [24] 2467 	movx	a,@dptr
      006967 F9               [12] 2468 	mov	r1,a
      006968 C3               [12] 2469 	clr	c
      006969 74 08            [12] 2470 	mov	a,#0x08
      00696B 98               [12] 2471 	subb	a,r0
      00696C E4               [12] 2472 	clr	a
      00696D 99               [12] 2473 	subb	a,r1
      00696E 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      006970 90 07 B9         [24] 2476 	mov	dptr,#_D0SetupLen
      006973 74 08            [12] 2477 	mov	a,#0x08
      006975 F0               [24] 2478 	movx	@dptr,a
      006976 E4               [12] 2479 	clr	a
      006977 A3               [24] 2480 	inc	dptr
      006978 F0               [24] 2481 	movx	@dptr,a
      006979 80 03            [24] 2482 	sjmp	00252$
      00697B                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      00697B 02 60 E4         [24] 2485 	ljmp	_control_stall
      00697E                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      00697E 90 08 21         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      006981 E0               [24] 2489 	movx	a,@dptr
      006982 F5 2A            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      006984 A3               [24] 2491 	inc	dptr
      006985 E0               [24] 2492 	movx	a,@dptr
      006986 F5 2B            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      006988 E5 2A            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      00698A 45 2B            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      00698C 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      00698E 90 07 B9         [24] 2498 	mov	dptr,#_D0SetupLen
      006991 E0               [24] 2499 	movx	a,@dptr
      006992 F8               [12] 2500 	mov	r0,a
      006993 A3               [24] 2501 	inc	dptr
      006994 E0               [24] 2502 	movx	a,@dptr
      006995 F9               [12] 2503 	mov	r1,a
      006996 C3               [12] 2504 	clr	c
      006997 E5 2A            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      006999 98               [12] 2506 	subb	a,r0
      00699A E5 2B            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00699C 99               [12] 2508 	subb	a,r1
      00699D 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      00699F 90 07 B9         [24] 2511 	mov	dptr,#_D0SetupLen
      0069A2 E5 2A            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      0069A4 F0               [24] 2513 	movx	@dptr,a
      0069A5 E5 2B            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0069A7 A3               [24] 2515 	inc	dptr
      0069A8 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0069A9                       2518 00559$:
      0069A9 75 2A 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      0069AC                       2520 00296$:
      0069AC 90 07 B9         [24] 2521 	mov	dptr,#_D0SetupLen
      0069AF E0               [24] 2522 	movx	a,@dptr
      0069B0 F8               [12] 2523 	mov	r0,a
      0069B1 C3               [12] 2524 	clr	c
      0069B2 E5 2A            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      0069B4 98               [12] 2526 	subb	a,r0
      0069B5 50 46            [24] 2527 	jnc	00263$
      0069B7 85 2A 28         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0069BA 74 10            [12] 2529 	mov	a,#0x10
      0069BC 24 00            [12] 2530 	add	a, #0x00
      0069BE F5 29            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      0069C0 90 08 23         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      0069C3 E0               [24] 2533 	movx	a,@dptr
      0069C4 25 2A            [12] 2534 	add	a, _control_setup_sloc4_1_0
      0069C6 24 E9            [12] 2535 	add	a, #_input_snapshot
      0069C8 F5 82            [12] 2536 	mov	dpl,a
      0069CA E4               [12] 2537 	clr	a
      0069CB 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      0069CD F5 83            [12] 2539 	mov	dph,a
      0069CF E0               [24] 2540 	movx	a,@dptr
      0069D0 85 28 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      0069D3 85 29 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0069D6 F0               [24] 2543 	movx	@dptr,a
      0069D7 E5 2A            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      0069D9 04               [12] 2545 	inc	a
      0069DA F5 2A            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      0069DC 80 CE            [24] 2547 	sjmp	00296$
      0069DE                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0069DE BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      0069E1 BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      0069E4 90 07 B9         [24] 2552 	mov	dptr,#_D0SetupLen
      0069E7 E0               [24] 2553 	movx	a,@dptr
      0069E8 F8               [12] 2554 	mov	r0,a
      0069E9 A3               [24] 2555 	inc	dptr
      0069EA E0               [24] 2556 	movx	a,@dptr
      0069EB F9               [12] 2557 	mov	r1,a
      0069EC C3               [12] 2558 	clr	c
      0069ED 74 20            [12] 2559 	mov	a,#0x20
      0069EF 98               [12] 2560 	subb	a,r0
      0069F0 E4               [12] 2561 	clr	a
      0069F1 99               [12] 2562 	subb	a,r1
      0069F2 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      0069F4 90 07 B9         [24] 2565 	mov	dptr,#_D0SetupLen
      0069F7 74 20            [12] 2566 	mov	a,#0x20
      0069F9 F0               [24] 2567 	movx	@dptr,a
      0069FA E4               [12] 2568 	clr	a
      0069FB A3               [24] 2569 	inc	dptr
      0069FC F0               [24] 2570 	movx	@dptr,a
      0069FD                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      0069FD 90 07 B9         [24] 2573 	mov	dptr,#_D0SetupLen
      006A00 E0               [24] 2574 	movx	a,@dptr
      006A01 90 22 08         [24] 2575 	mov	dptr,#0x2208
      006A04 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006A05 90 08 17         [24] 2578 	mov	dptr,#_control_phase
      006A08 74 02            [12] 2579 	mov	a,#0x02
      006A0A F0               [24] 2580 	movx	@dptr,a
      006A0B 02 6A 93         [24] 2581 	ljmp	00291$
      006A0E                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006A0E EB               [12] 2584 	mov	a,r3
      006A0F 4C               [12] 2585 	orl	a,r4
      006A10 70 37            [24] 2586 	jnz	00265$
      006A12 90 07 BE         [24] 2587 	mov	dptr,#_D0UsbConfig
      006A15 E0               [24] 2588 	movx	a,@dptr
      006A16 60 31            [24] 2589 	jz	00265$
      006A18 EA               [12] 2590 	mov	a,r2
      006A19 60 2E            [24] 2591 	jz	00265$
      006A1B 90 07 B8         [24] 2592 	mov	dptr,#_D0SetupReqCode
      006A1E E0               [24] 2593 	movx	a,@dptr
      006A1F FA               [12] 2594 	mov	r2,a
      006A20 BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      006A23 30 19 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      006A26 90 07 B9         [24] 2597 	mov	dptr,#_D0SetupLen
      006A29 E0               [24] 2598 	movx	a,@dptr
      006A2A F9               [12] 2599 	mov	r1,a
      006A2B A3               [24] 2600 	inc	dptr
      006A2C E0               [24] 2601 	movx	a,@dptr
      006A2D FA               [12] 2602 	mov	r2,a
      006A2E B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      006A31 BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      006A34 90 0E 0B         [24] 2606 	mov	dptr,#_keyboard_protocol
      006A37 E0               [24] 2607 	movx	a,@dptr
      006A38 90 10 00         [24] 2608 	mov	dptr,#0x1000
      006A3B F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006A3C 90 22 08         [24] 2611 	mov	dptr,#0x2208
      006A3F 74 01            [12] 2612 	mov	a,#0x01
      006A41 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      006A42 90 08 17         [24] 2615 	mov	dptr,#_control_phase
      006A45 04               [12] 2616 	inc	a
      006A46 F0               [24] 2617 	movx	@dptr,a
      006A47 80 4A            [24] 2618 	sjmp	00291$
      006A49                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      006A49 02 60 E4         [24] 2622 	ljmp	_control_stall
      006A4C                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006A4C 30 17 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      006A4F 90 07 BE         [24] 2626 	mov	dptr,#_D0UsbConfig
      006A52 E0               [24] 2627 	movx	a,@dptr
      006A53 60 38            [24] 2628 	jz	00284$
      006A55 BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      006A58 8E 05            [24] 2630 	mov	ar5,r6
      006A5A 7E 00            [12] 2631 	mov	r6,#0x00
      006A5C ED               [12] 2632 	mov	a,r5
      006A5D 4E               [12] 2633 	orl	a,r6
      006A5E 70 2D            [24] 2634 	jnz	00284$
      006A60 90 07 B9         [24] 2635 	mov	dptr,#_D0SetupLen
      006A63 E0               [24] 2636 	movx	a,@dptr
      006A64 FE               [12] 2637 	mov	r6,a
      006A65 A3               [24] 2638 	inc	dptr
      006A66 E0               [24] 2639 	movx	a,@dptr
      006A67 FF               [12] 2640 	mov	r7,a
      006A68 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      006A6B BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006A6E EB               [12] 2644 	mov	a,r3
      006A6F 4C               [12] 2645 	orl	a,r4
      006A70 70 07            [24] 2646 	jnz	00324$
      006A72 90 06 96         [24] 2647 	mov	dptr,#_keyboard_idle
      006A75 E0               [24] 2648 	movx	a,@dptr
      006A76 FF               [12] 2649 	mov	r7,a
      006A77 80 02            [24] 2650 	sjmp	00325$
      006A79                       2651 00324$:
      006A79 7F 00            [12] 2652 	mov	r7,#0x00
      006A7B                       2653 00325$:
      006A7B 90 10 00         [24] 2654 	mov	dptr,#0x1000
      006A7E EF               [12] 2655 	mov	a,r7
      006A7F F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006A80 90 22 08         [24] 2658 	mov	dptr,#0x2208
      006A83 74 01            [12] 2659 	mov	a,#0x01
      006A85 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006A86 90 08 17         [24] 2662 	mov	dptr,#_control_phase
      006A89 04               [12] 2663 	inc	a
      006A8A F0               [24] 2664 	movx	@dptr,a
      006A8B 80 06            [24] 2665 	sjmp	00291$
      006A8D                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006A8D 02 60 E4         [24] 2669 	ljmp	_control_stall
      006A90                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006A90 02 60 E4         [24] 2672 	ljmp	_control_stall
      006A93                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006A93 90 22 00         [24] 2675 	mov	dptr,#0x2200
      006A96 74 C0            [12] 2676 	mov	a,#0xc0
      006A98 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006A99 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      006A9A                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006A9A 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      006A9D E0               [24] 2692 	movx	a,@dptr
      006A9E 20 E6 01         [24] 2693 	jb	acc.6,00102$
      006AA1 22               [24] 2694 	ret
      006AA2                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006AA2 90 08 17         [24] 2697 	mov	dptr,#_control_phase
      006AA5 E0               [24] 2698 	movx	a,@dptr
      006AA6 FF               [12] 2699 	mov	r7,a
      006AA7 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      006AAA 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      006AAD E0               [24] 2702 	movx	a,@dptr
      006AAE 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      006AB0 90 08 17         [24] 2705 	mov	dptr,#_control_phase
      006AB3 E4               [12] 2706 	clr	a
      006AB4 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006AB5 90 22 00         [24] 2709 	mov	dptr,#0x2200
      006AB8 74 02            [12] 2710 	mov	a,#0x02
      006ABA F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006ABB 22               [24] 2713 	ret
      006ABC                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006ABC BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      006ABF 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      006AC2 E0               [24] 2718 	movx	a,@dptr
      006AC3 FF               [12] 2719 	mov	r7,a
      006AC4 90 07 B9         [24] 2720 	mov	dptr,#_D0SetupLen
      006AC7 E0               [24] 2721 	movx	a,@dptr
      006AC8 FD               [12] 2722 	mov	r5,a
      006AC9 A3               [24] 2723 	inc	dptr
      006ACA E0               [24] 2724 	movx	a,@dptr
      006ACB FE               [12] 2725 	mov	r6,a
      006ACC 7C 00            [12] 2726 	mov	r4,#0x00
      006ACE EF               [12] 2727 	mov	a,r7
      006ACF B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      006AD2 EC               [12] 2729 	mov	a,r4
      006AD3 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      006AD6 80 03            [24] 2731 	sjmp	00107$
      006AD8                       2732 00209$:
      006AD8                       2733 00106$:
      006AD8 02 60 E4         [24] 2734 	ljmp	_control_stall
      006ADB                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006ADB 90 08 18         [24] 2737 	mov	dptr,#_output_kind
      006ADE E0               [24] 2738 	movx	a,@dptr
      006ADF FF               [12] 2739 	mov	r7,a
      006AE0 BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      006AE3 90 07 C6         [24] 2741 	mov	dptr,#_raw_state
      006AE6 E0               [24] 2742 	movx	a,@dptr
      006AE7 FE               [12] 2743 	mov	r6,a
      006AE8 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006AEB 7E 00            [12] 2746 	mov	r6,#0x00
      006AED                       2747 00121$:
      006AED EE               [12] 2748 	mov	a,r6
      006AEE 24 C7            [12] 2749 	add	a, #_raw_buffer
      006AF0 FC               [12] 2750 	mov	r4,a
      006AF1 E4               [12] 2751 	clr	a
      006AF2 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      006AF4 FD               [12] 2753 	mov	r5,a
      006AF5 8E 82            [24] 2754 	mov	dpl,r6
      006AF7 74 10            [12] 2755 	mov	a,#0x10
      006AF9 24 00            [12] 2756 	add	a, #0x00
      006AFB F5 83            [12] 2757 	mov	dph,a
      006AFD E0               [24] 2758 	movx	a,@dptr
      006AFE 8C 82            [24] 2759 	mov	dpl,r4
      006B00 8D 83            [24] 2760 	mov	dph,r5
      006B02 F0               [24] 2761 	movx	@dptr,a
      006B03 0E               [12] 2762 	inc	r6
      006B04 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      006B07                       2764 00214$:
      006B07 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006B09 90 07 C6         [24] 2767 	mov	dptr,#_raw_state
      006B0C 74 02            [12] 2768 	mov	a,#0x02
      006B0E F0               [24] 2769 	movx	@dptr,a
      006B0F 80 2B            [24] 2770 	sjmp	00119$
      006B11                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006B11 BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006B14 90 10 00         [24] 2775 	mov	dptr,#0x1000
      006B17 E0               [24] 2776 	movx	a,@dptr
      006B18 90 07 C3         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      006B1B F0               [24] 2778 	movx	@dptr,a
      006B1C 80 1E            [24] 2779 	sjmp	00119$
      006B1E                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006B1E BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      006B21 90 10 00         [24] 2783 	mov	dptr,#0x1000
      006B24 E0               [24] 2784 	movx	a,@dptr
      006B25 FF               [12] 2785 	mov	r7,a
      006B26 90 08 19         [24] 2786 	mov	dptr,#_output_report_id
      006B29 E0               [24] 2787 	movx	a,@dptr
      006B2A FE               [12] 2788 	mov	r6,a
      006B2B EF               [12] 2789 	mov	a,r7
      006B2C B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006B2F 90 10 01         [24] 2792 	mov	dptr,#0x1001
      006B32 E0               [24] 2793 	movx	a,@dptr
      006B33 90 07 C3         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      006B36 F0               [24] 2795 	movx	@dptr,a
      006B37 80 03            [24] 2796 	sjmp	00119$
      006B39                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006B39 02 60 E4         [24] 2799 	ljmp	_control_stall
      006B3C                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006B3C 90 08 18         [24] 2802 	mov	dptr,#_output_kind
      006B3F E4               [12] 2803 	clr	a
      006B40 F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006B41 90 07 B9         [24] 2806 	mov	dptr,#_D0SetupLen
      006B44 F0               [24] 2807 	movx	@dptr,a
      006B45 A3               [24] 2808 	inc	dptr
      006B46 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006B47 90 08 17         [24] 2811 	mov	dptr,#_control_phase
      006B4A 74 03            [12] 2812 	mov	a,#0x03
      006B4C F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006B4D 90 22 08         [24] 2815 	mov	dptr,#0x2208
      006B50 E4               [12] 2816 	clr	a
      006B51 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006B52 F5 82            [12] 2819 	mov	dpl,a
      006B54 74 48            [12] 2820 	mov	a,#0x48
      006B56 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006B57 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      006B58                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006B58 90 08 17         [24] 2833 	mov	dptr,#_control_phase
      006B5B E0               [24] 2834 	movx	a,@dptr
      006B5C FF               [12] 2835 	mov	r7,a
      006B5D BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006B60 90 07 B9         [24] 2838 	mov	dptr,#_D0SetupLen
      006B63 E0               [24] 2839 	movx	a,@dptr
      006B64 FD               [12] 2840 	mov	r5,a
      006B65 A3               [24] 2841 	inc	dptr
      006B66 E0               [24] 2842 	movx	a,@dptr
      006B67 4D               [12] 2843 	orl	a,r5
      006B68 70 06            [24] 2844 	jnz	00101$
      006B6A 90 08 1A         [24] 2845 	mov	dptr,#_control_zlp
      006B6D E0               [24] 2846 	movx	a,@dptr
      006B6E 60 0A            [24] 2847 	jz	00102$
      006B70                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006B70 90 22 00         [24] 2850 	mov	dptr,#0x2200
      006B73 E0               [24] 2851 	movx	a,@dptr
      006B74 64 40            [12] 2852 	xrl	a,#0x40
      006B76 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006B77 02 61 06         [24] 2856 	ljmp	_control_next
      006B7A                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006B7A 90 08 17         [24] 2859 	mov	dptr,#_control_phase
      006B7D 74 02            [12] 2860 	mov	a,#0x02
      006B7F F0               [24] 2861 	movx	@dptr,a
      006B80 80 18            [24] 2862 	sjmp	00110$
      006B82                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006B82 BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006B85 90 07 B8         [24] 2867 	mov	dptr,#_D0SetupReqCode
      006B88 E0               [24] 2868 	movx	a,@dptr
      006B89 FF               [12] 2869 	mov	r7,a
      006B8A BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      006B8D 90 07 B9         [24] 2871 	mov	dptr,#_D0SetupLen
      006B90 E0               [24] 2872 	movx	a,@dptr
      006B91 90 22 07         [24] 2873 	mov	dptr,#0x2207
      006B94 F0               [24] 2874 	movx	@dptr,a
      006B95                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006B95 90 08 17         [24] 2877 	mov	dptr,#_control_phase
      006B98 E4               [12] 2878 	clr	a
      006B99 F0               [24] 2879 	movx	@dptr,a
      006B9A                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B9A 90 22 00         [24] 2882 	mov	dptr,#0x2200
      006B9D 74 82            [12] 2883 	mov	a,#0x82
      006B9F F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006BA0 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      006BA1                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006BA1                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006BA1 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      006BA4 E0               [24] 2902 	movx	a,@dptr
      006BA5 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006BA8 12 60 8D         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006BAB 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006BAE E4               [12] 2908 	clr	a
      006BAF F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006BB0 90 07 C0         [24] 2911 	mov	dptr,#_USB_SleepStatus
      006BB3 F0               [24] 2912 	movx	@dptr,a
      006BB4 90 07 BF         [24] 2913 	mov	dptr,#_USB_EnumStatus
      006BB7 F0               [24] 2914 	movx	@dptr,a
      006BB8 90 07 BE         [24] 2915 	mov	dptr,#_D0UsbConfig
      006BBB F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006BBC 90 07 C3         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      006BBF F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006BC0 90 0E 0B         [24] 2921 	mov	dptr,#_keyboard_protocol
      006BC3 04               [12] 2922 	inc	a
      006BC4 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006BC5 90 06 96         [24] 2925 	mov	dptr,#_keyboard_idle
      006BC8 E4               [12] 2926 	clr	a
      006BC9 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006BCA 90 07 E8         [24] 2929 	mov	dptr,#_keyboard_reset
      006BCD 04               [12] 2930 	inc	a
      006BCE F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006BCF 90 07 B8         [24] 2933 	mov	dptr,#_D0SetupReqCode
      006BD2 74 FF            [12] 2934 	mov	a,#0xff
      006BD4 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006BD5 90 07 B9         [24] 2937 	mov	dptr,#_D0SetupLen
      006BD8 E4               [12] 2938 	clr	a
      006BD9 F0               [24] 2939 	movx	@dptr,a
      006BDA A3               [24] 2940 	inc	dptr
      006BDB F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006BDC 90 08 17         [24] 2943 	mov	dptr,#_control_phase
      006BDF F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006BE0 90 22 00         [24] 2946 	mov	dptr,#0x2200
      006BE3 74 02            [12] 2947 	mov	a,#0x02
      006BE5 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006BE6 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      006BE9 E4               [12] 2951 	clr	a
      006BEA F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006BEB 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      006BEE 04               [12] 2955 	inc	a
      006BEF F0               [24] 2956 	movx	@dptr,a
      006BF0 02 6C 86         [24] 2957 	ljmp	00130$
      006BF3                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006BF3 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      006BF6 E0               [24] 2961 	movx	a,@dptr
      006BF7 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006BFA 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      006BFD E0               [24] 2965 	movx	a,@dptr
      006BFE FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006BFF 74 07            [12] 2968 	mov	a,#0x07
      006C01 5F               [12] 2969 	anl	a,r7
      006C02 FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006C03 EF               [12] 2972 	mov	a,r7
      006C04 54 18            [12] 2973 	anl	a,#0x18
      006C06 70 08            [24] 2974 	jnz	00115$
      006C08 EE               [12] 2975 	mov	a,r6
      006C09 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006C0B 12 6A 9A         [24] 2978 	lcall	_control_out
      006C0E 80 43            [24] 2979 	sjmp	00116$
      006C10                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006C10 8F 05            [24] 2982 	mov	ar5,r7
      006C12 74 18            [12] 2983 	mov	a,#0x18
      006C14 5D               [12] 2984 	anl	a,r5
      006C15 FC               [12] 2985 	mov	r4,a
      006C16 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006C19 EE               [12] 2988 	mov	a,r6
      006C1A 70 05            [24] 2989 	jnz	00106$
      006C1C 12 6B 58         [24] 2990 	lcall	_control_in
      006C1F 80 32            [24] 2991 	sjmp	00116$
      006C21                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006C21 EE               [12] 2994 	mov	a,r6
      006C22 24 FC            [12] 2995 	add	a,#0xff - 0x03
      006C24 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006C26 8E 04            [24] 2999 	mov	ar4,r6
      006C28 7B 00            [12] 3000 	mov	r3,#0x00
      006C2A 74 22            [12] 3001 	mov	a,#0x22
      006C2C 2B               [12] 3002 	add	a, r3
      006C2D FB               [12] 3003 	mov	r3,a
      006C2E 8C 82            [24] 3004 	mov	dpl,r4
      006C30 8B 83            [24] 3005 	mov	dph,r3
      006C32 E0               [24] 3006 	movx	a,@dptr
      006C33 FA               [12] 3007 	mov	r2,a
      006C34 74 FC            [12] 3008 	mov	a,#0xfc
      006C36 5A               [12] 3009 	anl	a,r2
      006C37 44 02            [12] 3010 	orl	a,#0x02
      006C39 8C 82            [24] 3011 	mov	dpl,r4
      006C3B 8B 83            [24] 3012 	mov	dph,r3
      006C3D F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006C3E BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      006C41 12 60 70         [24] 3016 	lcall	_raw_complete
      006C44 80 0D            [24] 3017 	sjmp	00116$
      006C46                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006C46 53 05 18         [24] 3020 	anl	ar5,#0x18
      006C49 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      006C4C EF               [12] 3022 	mov	a,r7
      006C4D 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006C50 12 62 FD         [24] 3025 	lcall	_control_setup
      006C53                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006C53 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      006C56 E4               [12] 3029 	clr	a
      006C57 F0               [24] 3030 	movx	@dptr,a
      006C58 80 2C            [24] 3031 	sjmp	00130$
      006C5A                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006C5A 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      006C5D E0               [24] 3035 	movx	a,@dptr
      006C5E 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006C61 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006C64 E0               [24] 3039 	movx	a,@dptr
      006C65 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006C68 90 07 C0         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006C6B E0               [24] 3042 	movx	a,@dptr
      006C6C 43 E0 02         [24] 3043 	orl	acc,#0x02
      006C6F F0               [24] 3044 	movx	@dptr,a
      006C70 80 0E            [24] 3045 	sjmp	00120$
      006C72                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006C72 90 07 C0         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006C75 E0               [24] 3049 	movx	a,@dptr
      006C76 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006C79 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006C7A 90 07 E8         [24] 3053 	mov	dptr,#_keyboard_reset
      006C7D 74 01            [12] 3054 	mov	a,#0x01
      006C7F F0               [24] 3055 	movx	@dptr,a
      006C80                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006C80 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006C83 74 04            [12] 3059 	mov	a,#0x04
      006C85 F0               [24] 3060 	movx	@dptr,a
      006C86                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006C86 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006C89 E0               [24] 3064 	movx	a,@dptr
      006C8A 54 25            [12] 3065 	anl	a,#0x25
      006C8C 60 03            [24] 3066 	jz	00242$
      006C8E 02 6B A1         [24] 3067 	ljmp	00129$
      006C91                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006C91 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006C92                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3080 ;	assignBit
      006C92 C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006C94 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006C97 E4               [12] 3084 	clr	a
      006C98 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006C99 90 07 C6         [24] 3087 	mov	dptr,#_raw_state
      006C9C F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006C9D 12 60 8D         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006CA0 90 07 C0         [24] 3092 	mov	dptr,#_USB_SleepStatus
      006CA3 E4               [12] 3093 	clr	a
      006CA4 F0               [24] 3094 	movx	@dptr,a
      006CA5 90 07 BF         [24] 3095 	mov	dptr,#_USB_EnumStatus
      006CA8 F0               [24] 3096 	movx	@dptr,a
      006CA9 90 07 BE         [24] 3097 	mov	dptr,#_D0UsbConfig
      006CAC F0               [24] 3098 	movx	@dptr,a
      006CAD 90 22 07         [24] 3099 	mov	dptr,#0x2207
      006CB0 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006CB1 90 07 C1         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      006CB4 F0               [24] 3103 	movx	@dptr,a
      006CB5 90 07 C2         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      006CB8 F0               [24] 3105 	movx	@dptr,a
      006CB9 90 07 C3         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      006CBC F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006CBD 90 0E 0B         [24] 3109 	mov	dptr,#_keyboard_protocol
      006CC0 04               [12] 3110 	inc	a
      006CC1 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006CC2 90 06 96         [24] 3113 	mov	dptr,#_keyboard_idle
      006CC5 E4               [12] 3114 	clr	a
      006CC6 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006CC7 90 07 E8         [24] 3117 	mov	dptr,#_keyboard_reset
      006CCA F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006CCB 90 08 17         [24] 3120 	mov	dptr,#_control_phase
      006CCE F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006CCF 90 07 B8         [24] 3123 	mov	dptr,#_D0SetupReqCode
      006CD2 14               [12] 3124 	dec	a
      006CD3 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006CD4 90 07 B9         [24] 3127 	mov	dptr,#_D0SetupLen
      006CD7 E4               [12] 3128 	clr	a
      006CD8 F0               [24] 3129 	movx	@dptr,a
      006CD9 A3               [24] 3130 	inc	dptr
      006CDA F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006CDB 90 22 00         [24] 3133 	mov	dptr,#0x2200
      006CDE 74 02            [12] 3134 	mov	a,#0x02
      006CE0 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006CE1 90 22 37         [24] 3137 	mov	dptr,#0x2237
      006CE4 74 7F            [12] 3138 	mov	a,#0x7f
      006CE6 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006CE7 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      006CEA 74 FF            [12] 3142 	mov	a,#0xff
      006CEC F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006CED 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      006CF0 74 07            [12] 3146 	mov	a,#0x07
      006CF2 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006CF3 A3               [24] 3149 	inc	dptr
      006CF4 74 80            [12] 3150 	mov	a,#0x80
      006CF6 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3153 ;	assignBit
      006CF7 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006CF9 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      006CFA                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006CFA 90 07 C0         [24] 3169 	mov	dptr,#_USB_SleepStatus
      006CFD E0               [24] 3170 	movx	a,@dptr
      006CFE FF               [12] 3171 	mov	r7,a
      006CFF BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006D02 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      006D05 E0               [24] 3175 	movx	a,@dptr
      006D06 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006D07 E0               [24] 3178 	movx	a,@dptr
      006D08 FE               [12] 3179 	mov	r6,a
      006D09 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      006D0C 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      006D0F EE               [12] 3182 	mov	a,r6
      006D10 F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006D11 7E 0A            [12] 3185 	mov	r6,#0x0a
      006D13                       3186 00108$:
      006D13 EE               [12] 3187 	mov	a,r6
      006D14 60 09            [24] 3188 	jz	00105$
      006D16 90 00 01         [24] 3189 	mov	dptr,#0x0001
      006D19 12 5E D4         [24] 3190 	lcall	_mDelaymS
      006D1C 1E               [12] 3191 	dec	r6
      006D1D 80 F4            [24] 3192 	sjmp	00108$
      006D1F                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006D1F 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      006D22 EF               [12] 3196 	mov	a,r7
      006D23 F0               [24] 3197 	movx	@dptr,a
      006D24                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006D24 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      006D25                       3220 _ak820_usb_send:
      006D25 E5 82            [12] 3221 	mov	a,dpl
      006D27 90 08 27         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006D2A F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006D2B 90 08 28         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006D2E 74 2E            [12] 3226 	mov	a,#0x2e
      006D30 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006D31 90 08 27         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006D34 E0               [24] 3230 	movx	a,@dptr
      006D35 FF               [12] 3231 	mov	r7,a
      006D36 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      006D39                       3233 00306$:
      006D39 40 14            [24] 3234 	jc	00101$
      006D3B EF               [12] 3235 	mov	a,r7
      006D3C 24 FC            [12] 3236 	add	a,#0xff - 0x03
      006D3E 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      006D40 90 08 26         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      006D43 E0               [24] 3240 	movx	a,@dptr
      006D44 FE               [12] 3241 	mov  r6,a
      006D45 24 BF            [12] 3242 	add	a,#0xff - 0x40
      006D47 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      006D49 90 07 BF         [24] 3245 	mov	dptr,#_USB_EnumStatus
      006D4C E0               [24] 3246 	movx	a,@dptr
      006D4D 70 04            [24] 3247 	jnz	00102$
      006D4F                       3248 00101$:
      006D4F 75 82 00         [24] 3249 	mov	dpl, #0x00
      006D52 22               [24] 3250 	ret
      006D53                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006D53 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006D56 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      006D59 80 04            [24] 3256 	sjmp	00107$
      006D5B                       3257 00313$:
      006D5B 75 82 00         [24] 3258 	mov	dpl, #0x00
      006D5E 22               [24] 3259 	ret
      006D5F                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006D5F 90 08 28         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006D62 E4               [12] 3263 	clr	a
      006D63 F0               [24] 3264 	movx	@dptr,a
      006D64 80 3C            [24] 3265 	sjmp	00119$
      006D66                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006D66 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006D69 90 08 24         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      006D6C E0               [24] 3271 	movx	a,@dptr
      006D6D FD               [12] 3272 	mov	r5,a
      006D6E A3               [24] 3273 	inc	dptr
      006D6F E0               [24] 3274 	movx	a,@dptr
      006D70 FF               [12] 3275 	mov	r7,a
      006D71 8D 82            [24] 3276 	mov	dpl,r5
      006D73 8F 83            [24] 3277 	mov	dph,r7
      006D75 E0               [24] 3278 	movx	a,@dptr
      006D76 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006D77 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      006D7A                       3282 00316$:
      006D7A 50 0E            [24] 3283 	jnc	00108$
      006D7C EF               [12] 3284 	mov	a,r7
      006D7D 90 C0 D0         [24] 3285 	mov	dptr,#_shared_lengths
      006D80 93               [24] 3286 	movc	a,@a+dptr
      006D81 FD               [12] 3287 	mov	r5,a
      006D82 60 06            [24] 3288 	jz	00108$
      006D84 EE               [12] 3289 	mov	a,r6
      006D85 B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      006D88 80 04            [24] 3291 	sjmp	00109$
      006D8A                       3292 00319$:
      006D8A                       3293 00108$:
      006D8A 75 82 00         [24] 3294 	mov	dpl, #0x00
      006D8D 22               [24] 3295 	ret
      006D8E                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006D8E EF               [12] 3298 	mov	a,r7
      006D8F 90 C0 C9         [24] 3299 	mov	dptr,#_shared_offsets
      006D92 93               [24] 3300 	movc	a,@a+dptr
      006D93 90 08 28         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006D96 F0               [24] 3302 	movx	@dptr,a
      006D97 80 09            [24] 3303 	sjmp	00119$
      006D99                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006D99 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      006D9C 80 04            [24] 3307 	sjmp	00119$
      006D9E                       3308 00320$:
      006D9E 75 82 00         [24] 3309 	mov	dpl, #0x00
      006DA1 22               [24] 3310 	ret
      006DA2                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006DA2 90 07 C0         [24] 3313 	mov	dptr,#_USB_SleepStatus
      006DA5 E0               [24] 3314 	movx	a,@dptr
      006DA6 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      006DA9 12 6C FA         [24] 3316 	lcall	_USB_WakeUp_PC
      006DAC 75 82 00         [24] 3317 	mov	dpl, #0x00
      006DAF 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006DB0                       3320 00184$:
      006DB0 7F FA            [12] 3321 	mov	r7,#0xfa
      006DB2                       3322 00127$:
      006DB2 90 08 27         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006DB5 E0               [24] 3324 	movx	a,@dptr
      006DB6 FC               [12] 3325 	mov	r4,a
      006DB7 7D 00            [12] 3326 	mov	r5,#0x00
      006DB9 8C 02            [24] 3327 	mov	ar2,r4
      006DBB 74 22            [12] 3328 	mov	a,#0x22
      006DBD 2D               [12] 3329 	add	a, r5
      006DBE FB               [12] 3330 	mov	r3,a
      006DBF 8A 82            [24] 3331 	mov	dpl,r2
      006DC1 8B 83            [24] 3332 	mov	dph,r3
      006DC3 E0               [24] 3333 	movx	a,@dptr
      006DC4 54 03            [12] 3334 	anl	a,#0x03
      006DC6 70 14            [24] 3335 	jnz	00129$
      006DC8 8F 03            [24] 3336 	mov	ar3,r7
      006DCA 1F               [12] 3337 	dec	r7
      006DCB EB               [12] 3338 	mov	a,r3
      006DCC 60 0E            [24] 3339 	jz	00129$
      006DCE 7B 28            [12] 3340 	mov	r3,#0x28
      006DD0                       3341 00141$:
      006DD0 EB               [12] 3342 	mov	a,r3
      006DD1 60 DF            [24] 3343 	jz	00127$
      006DD3 90 00 01         [24] 3344 	mov	dptr,#0x0001
      006DD6 12 5E 90         [24] 3345 	lcall	_mDelayuS
      006DD9 1B               [12] 3346 	dec	r3
      006DDA 80 F4            [24] 3347 	sjmp	00141$
      006DDC                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006DDC A2 AF            [12] 3350 	mov	c,_EA
      006DDE E4               [12] 3351 	clr	a
      006DDF 33               [12] 3352 	rlc	a
      006DE0 FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3355 ;	assignBit
      006DE1 C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006DE3 90 07 BF         [24] 3358 	mov	dptr,#_USB_EnumStatus
      006DE6 E0               [24] 3359 	movx	a,@dptr
      006DE7 60 25            [24] 3360 	jz	00130$
      006DE9 90 08 27         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006DEC E0               [24] 3362 	movx	a,@dptr
      006DED FB               [12] 3363 	mov	r3,a
      006DEE F9               [12] 3364 	mov	r1,a
      006DEF 7A 00            [12] 3365 	mov	r2,#0x00
      006DF1 74 22            [12] 3366 	mov	a,#0x22
      006DF3 2A               [12] 3367 	add	a, r2
      006DF4 FA               [12] 3368 	mov	r2,a
      006DF5 89 82            [24] 3369 	mov	dpl,r1
      006DF7 8A 83            [24] 3370 	mov	dph,r2
      006DF9 E0               [24] 3371 	movx	a,@dptr
      006DFA FA               [12] 3372 	mov	r2,a
      006DFB 53 02 03         [24] 3373 	anl	ar2,#0x03
      006DFE BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006E01 BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      006E04 90 07 C6         [24] 3377 	mov	dptr,#_raw_state
      006E07 E0               [24] 3378 	movx	a,@dptr
      006E08 FB               [12] 3379 	mov	r3,a
      006E09 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      006E0C 80 09            [24] 3381 	sjmp	00192$
      006E0E                       3382 00331$:
      006E0E                       3383 00130$:
                                   3384 ;	assignBit
      006E0E EF               [12] 3385 	mov	a,r7
      006E0F 24 FF            [12] 3386 	add	a,#0xff
      006E11 92 AF            [24] 3387 	mov	_EA,c
      006E13 75 82 00         [24] 3388 	mov	dpl, #0x00
      006E16 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006E17                       3391 00192$:
      006E17 7B 00            [12] 3392 	mov	r3,#0x00
      006E19                       3393 00144$:
      006E19 C3               [12] 3394 	clr	c
      006E1A EB               [12] 3395 	mov	a,r3
      006E1B 9E               [12] 3396 	subb	a,r6
      006E1C 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006E1E C0 07            [24] 3399 	push	ar7
      006E20 90 08 27         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006E23 E0               [24] 3401 	movx	a,@dptr
      006E24 F9               [12] 3402 	mov	r1,a
      006E25 E4               [12] 3403 	clr	a
      006E26 C3               [12] 3404 	clr	c
      006E27 C9               [12] 3405 	xch	a,r1
      006E28 13               [12] 3406 	rrc	a
      006E29 C9               [12] 3407 	xch	a,r1
      006E2A 13               [12] 3408 	rrc	a
      006E2B A2 E0            [12] 3409 	mov	c,acc.0
      006E2D C9               [12] 3410 	xch	a,r1
      006E2E 13               [12] 3411 	rrc	a
      006E2F C9               [12] 3412 	xch	a,r1
      006E30 13               [12] 3413 	rrc	a
      006E31 C9               [12] 3414 	xch	a,r1
      006E32 FA               [12] 3415 	mov	r2,a
      006E33 8B 00            [24] 3416 	mov	ar0,r3
      006E35 7F 00            [12] 3417 	mov	r7,#0x00
      006E37 E8               [12] 3418 	mov	a,r0
      006E38 29               [12] 3419 	add	a, r1
      006E39 F9               [12] 3420 	mov	r1,a
      006E3A EF               [12] 3421 	mov	a,r7
      006E3B 3A               [12] 3422 	addc	a, r2
      006E3C 24 10            [12] 3423 	add	a,#0x10
      006E3E FA               [12] 3424 	mov	r2,a
      006E3F 90 08 24         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      006E42 E0               [24] 3426 	movx	a,@dptr
      006E43 F8               [12] 3427 	mov	r0,a
      006E44 A3               [24] 3428 	inc	dptr
      006E45 E0               [24] 3429 	movx	a,@dptr
      006E46 FF               [12] 3430 	mov	r7,a
      006E47 EB               [12] 3431 	mov	a,r3
      006E48 28               [12] 3432 	add	a, r0
      006E49 F5 2C            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      006E4B E4               [12] 3434 	clr	a
      006E4C 3F               [12] 3435 	addc	a, r7
      006E4D F5 2D            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006E4F 85 2C 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006E52 85 2D 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006E55 E0               [24] 3439 	movx	a,@dptr
      006E56 89 82            [24] 3440 	mov	dpl,r1
      006E58 8A 83            [24] 3441 	mov	dph,r2
      006E5A F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006E5B 90 08 28         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006E5E E0               [24] 3445 	movx	a,@dptr
      006E5F F5 2E            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      006E61 74 2E            [12] 3447 	mov	a,#0x2e
      006E63 B5 2E 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006E66 D0 07            [24] 3449 	pop	ar7
      006E68 80 18            [24] 3450 	sjmp	00145$
      006E6A                       3451 00333$:
      006E6A D0 07            [24] 3452 	pop	ar7
      006E6C EB               [12] 3453 	mov	a,r3
      006E6D 25 2E            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      006E6F 24 E9            [12] 3455 	add	a, #_input_snapshot
      006E71 F9               [12] 3456 	mov	r1,a
      006E72 E4               [12] 3457 	clr	a
      006E73 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      006E75 FA               [12] 3459 	mov	r2,a
      006E76 85 2C 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006E79 85 2D 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006E7C E0               [24] 3462 	movx	a,@dptr
      006E7D 89 82            [24] 3463 	mov	dpl,r1
      006E7F 8A 83            [24] 3464 	mov	dph,r2
      006E81 F0               [24] 3465 	movx	@dptr,a
      006E82                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006E82 0B               [12] 3468 	inc	r3
      006E83 80 94            [24] 3469 	sjmp	00144$
      006E85                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006E85 90 08 27         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006E88 E0               [24] 3473 	movx	a,@dptr
      006E89 FB               [12] 3474 	mov	r3,a
      006E8A F9               [12] 3475 	mov	r1,a
      006E8B 7A 00            [12] 3476 	mov	r2,#0x00
      006E8D 74 08            [12] 3477 	mov	a,#0x08
      006E8F 29               [12] 3478 	add	a, r1
      006E90 F9               [12] 3479 	mov	r1,a
      006E91 74 22            [12] 3480 	mov	a,#0x22
      006E93 3A               [12] 3481 	addc	a, r2
      006E94 FA               [12] 3482 	mov	r2,a
      006E95 89 82            [24] 3483 	mov	dpl,r1
      006E97 8A 83            [24] 3484 	mov	dph,r2
      006E99 EE               [12] 3485 	mov	a,r6
      006E9A F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006E9B BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      006E9E 90 07 C6         [24] 3489 	mov	dptr,#_raw_state
      006EA1 74 04            [12] 3490 	mov	a,#0x04
      006EA3 F0               [24] 3491 	movx	@dptr,a
      006EA4                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006EA4 74 22            [12] 3494 	mov	a,#0x22
      006EA6 2D               [12] 3495 	add	a, r5
      006EA7 FD               [12] 3496 	mov	r5,a
      006EA8 8C 82            [24] 3497 	mov	dpl,r4
      006EAA 8D 83            [24] 3498 	mov	dph,r5
      006EAC E0               [24] 3499 	movx	a,@dptr
      006EAD FE               [12] 3500 	mov	r6,a
      006EAE 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      006EB1 8C 82            [24] 3502 	mov	dpl,r4
      006EB3 8D 83            [24] 3503 	mov	dph,r5
      006EB5 EE               [12] 3504 	mov	a,r6
      006EB6 F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3507 ;	assignBit
      006EB7 EF               [12] 3508 	mov	a,r7
      006EB8 24 FF            [12] 3509 	add	a,#0xff
      006EBA 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006EBC 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006EBF 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      006EC0                       3528 _ak820_usb_try_send:
      006EC0 E5 82            [12] 3529 	mov	a,dpl
      006EC2 90 08 2C         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006EC5 F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      006EC6 A2 AF            [12] 3534 	mov	c,_EA
      006EC8 92 1D            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006ECA 90 08 2D         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006ECD E4               [12] 3538 	clr	a
      006ECE F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3541 ;	assignBit
      006ECF C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006ED1 90 08 2C         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006ED4 E0               [24] 3545 	movx	a,@dptr
      006ED5 FF               [12] 3546 	mov	r7,a
      006ED6 BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      006ED9                       3548 00152$:
      006ED9 40 4E            [24] 3549 	jc	00102$
      006EDB EF               [12] 3550 	mov	a,r7
      006EDC 24 FD            [12] 3551 	add	a,#0xff - 0x02
      006EDE 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      006EE0 90 07 BF         [24] 3554 	mov	dptr,#_USB_EnumStatus
      006EE3 E0               [24] 3555 	movx	a,@dptr
      006EE4 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006EE6 90 07 C0         [24] 3558 	mov	dptr,#_USB_SleepStatus
      006EE9 E0               [24] 3559 	movx	a,@dptr
      006EEA 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      006EED 90 07 E8         [24] 3561 	mov	dptr,#_keyboard_reset
      006EF0 E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006EF1 70 36            [24] 3564 	jnz	00102$
      006EF3 8F 06            [24] 3565 	mov	ar6,r7
      006EF5 24 22            [12] 3566 	add	a,#0x22
      006EF7 FD               [12] 3567 	mov	r5,a
      006EF8 8E 82            [24] 3568 	mov	dpl,r6
      006EFA 8D 83            [24] 3569 	mov	dph,r5
      006EFC E0               [24] 3570 	movx	a,@dptr
      006EFD FE               [12] 3571 	mov	r6,a
      006EFE 53 06 03         [24] 3572 	anl	ar6,#0x03
      006F01 BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006F04 90 08 29         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006F07 E0               [24] 3576 	movx	a,@dptr
      006F08 FD               [12] 3577 	mov	r5,a
      006F09 A3               [24] 3578 	inc	dptr
      006F0A E0               [24] 3579 	movx	a,@dptr
      006F0B FE               [12] 3580 	mov	r6,a
      006F0C 90 08 2B         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006F0F E0               [24] 3582 	movx	a,@dptr
      006F10 FC               [12] 3583 	mov	r4,a
      006F11 90 08 24         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      006F14 ED               [12] 3585 	mov	a,r5
      006F15 F0               [24] 3586 	movx	@dptr,a
      006F16 EE               [12] 3587 	mov	a,r6
      006F17 A3               [24] 3588 	inc	dptr
      006F18 F0               [24] 3589 	movx	@dptr,a
      006F19 90 08 26         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      006F1C EC               [12] 3591 	mov	a,r4
      006F1D F0               [24] 3592 	movx	@dptr,a
      006F1E 8F 82            [24] 3593 	mov	dpl, r7
      006F20 12 6D 25         [24] 3594 	lcall	_ak820_usb_send
      006F23 E5 82            [12] 3595 	mov	a, dpl
      006F25 90 08 2D         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006F28 F0               [24] 3597 	movx	@dptr,a
      006F29                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3600 ;	assignBit
      006F29 A2 1D            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006F2B 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006F2D 90 08 2D         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006F30 E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006F31 F5 82            [12] 3607 	mov	dpl,a
      006F33 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      006F34                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006F34 90 07 C7         [24] 3618 	mov	dptr,#_raw_buffer
      006F37 E0               [24] 3619 	movx	a,@dptr
      006F38 FF               [12] 3620 	mov	r7,a
      006F39 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      006F3C 80 35            [24] 3622 	sjmp	00108$
      006F3E                       3623 00302$:
      006F3E BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      006F41 80 34            [24] 3625 	sjmp	00109$
      006F43                       3626 00303$:
      006F43 BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      006F46 80 2B            [24] 3628 	sjmp	00108$
      006F48                       3629 00304$:
      006F48 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      006F4B 80 47            [24] 3631 	sjmp	00116$
      006F4D                       3632 00305$:
      006F4D BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      006F50 80 21            [24] 3634 	sjmp	00108$
      006F52                       3635 00306$:
      006F52 BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      006F55 80 1C            [24] 3637 	sjmp	00108$
      006F57                       3638 00307$:
      006F57 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      006F5A 80 17            [24] 3640 	sjmp	00108$
      006F5C                       3641 00308$:
      006F5C BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      006F5F 80 12            [24] 3643 	sjmp	00108$
      006F61                       3644 00309$:
      006F61 BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      006F64 80 0D            [24] 3646 	sjmp	00108$
      006F66                       3647 00310$:
      006F66 BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      006F69 80 08            [24] 3649 	sjmp	00108$
      006F6B                       3650 00311$:
      006F6B BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      006F6E 80 46            [24] 3652 	sjmp	00124$
      006F70                       3653 00312$:
      006F70 02 70 0B         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006F73                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006F73 75 82 01         [24] 3658 	mov	dpl, #0x01
      006F76 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006F77                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006F77 12 72 3D         [24] 3663 	lcall	_ak820_outline_0171
      006F7A BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      006F7D 80 0D            [24] 3665 	sjmp	00113$
      006F7F                       3666 00313$:
      006F7F BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      006F82 80 08            [24] 3668 	sjmp	00113$
      006F84                       3669 00314$:
      006F84 BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      006F87 80 03            [24] 3671 	sjmp	00113$
      006F89                       3672 00315$:
      006F89 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006F8C                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006F8C 75 82 01         [24] 3677 	mov	dpl, #0x01
      006F8F 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006F90                       3680 00114$:
      006F90 75 82 00         [24] 3681 	mov	dpl, #0x00
      006F93 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006F94                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006F94 12 72 3D         [24] 3686 	lcall	_ak820_outline_0171
      006F97 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      006F9A 80 12            [24] 3688 	sjmp	00121$
      006F9C                       3689 00318$:
      006F9C BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      006F9F 80 0D            [24] 3691 	sjmp	00121$
      006FA1                       3692 00319$:
      006FA1 BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      006FA4 80 08            [24] 3694 	sjmp	00121$
      006FA6                       3695 00320$:
      006FA6 BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      006FA9 80 03            [24] 3697 	sjmp	00121$
      006FAB                       3698 00321$:
      006FAB BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006FAE                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006FAE 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006FB1 22               [24] 3705 	ret
      006FB2                       3706 00122$:
      006FB2 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006FB5 22               [24] 3709 	ret
      006FB6                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006FB6 12 72 3D         [24] 3712 	lcall	_ak820_outline_0171
      006FB9 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      006FBB 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      006FBD EF               [12] 3716 	mov	a,r7
      006FBE 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      006FC0 83               [24] 3718 	movc	a,@a+pc
      006FC1 F5 82            [12] 3719 	mov	dpl,a
      006FC3 EF               [12] 3720 	mov	a,r7
      006FC4 24 12            [12] 3721 	add	a,#(00326$-3-.)
      006FC6 83               [24] 3722 	movc	a,@a+pc
      006FC7 F5 83            [12] 3723 	mov	dph,a
      006FC9 E4               [12] 3724 	clr	a
      006FCA 73               [24] 3725 	jmp	@a+dptr
      006FCB                       3726 00325$:
      006FCB E7                    3727 	.db	00134$
      006FCC E7                    3728 	.db	00134$
      006FCD E7                    3729 	.db	00134$
      006FCE E7                    3730 	.db	00134$
      006FCF 07                    3731 	.db	00142$
      006FD0 E7                    3732 	.db	00134$
      006FD1 E7                    3733 	.db	00134$
      006FD2 E7                    3734 	.db	00134$
      006FD3 E7                    3735 	.db	00134$
      006FD4 E7                    3736 	.db	00134$
      006FD5 E7                    3737 	.db	00134$
      006FD6 07                    3738 	.db	00142$
      006FD7 07                    3739 	.db	00142$
      006FD8 EB                    3740 	.db	00135$
      006FD9                       3741 00326$:
      006FD9 6F                    3742 	.db	00134$>>8
      006FDA 6F                    3743 	.db	00134$>>8
      006FDB 6F                    3744 	.db	00134$>>8
      006FDC 6F                    3745 	.db	00134$>>8
      006FDD 70                    3746 	.db	00142$>>8
      006FDE 6F                    3747 	.db	00134$>>8
      006FDF 6F                    3748 	.db	00134$>>8
      006FE0 6F                    3749 	.db	00134$>>8
      006FE1 6F                    3750 	.db	00134$>>8
      006FE2 6F                    3751 	.db	00134$>>8
      006FE3 6F                    3752 	.db	00134$>>8
      006FE4 70                    3753 	.db	00142$>>8
      006FE5 70                    3754 	.db	00142$>>8
      006FE6 6F                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006FE7                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006FE7 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006FEA 22               [24] 3761 	ret
      006FEB                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006FEB 90 07 C9         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      006FEE E0               [24] 3765 	movx	a,@dptr
      006FEF FF               [12] 3766 	mov	r7,a
      006FF0 60 0D            [24] 3767 	jz	00139$
      006FF2 BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      006FF5 80 08            [24] 3769 	sjmp	00139$
      006FF7                       3770 00328$:
      006FF7 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      006FFA 80 03            [24] 3772 	sjmp	00139$
      006FFC                       3773 00329$:
      006FFC BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006FFF                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006FFF 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      007002 22               [24] 3780 	ret
      007003                       3781 00140$:
      007003 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      007006 22               [24] 3784 	ret
      007007                       3785 00142$:
      007007 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      00700A 22               [24] 3788 	ret
      00700B                       3789 00144$:
      00700B 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      00700E 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      00700F                       3804 _ak820_usb_raw_send:
      00700F 12 43 1B         [24] 3805 	lcall	_ak820_outline_0038
      007012 90 08 2F         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      007015 12 38 26         [24] 3807 	lcall	_ak820_outline_0018
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      007018 90 08 2E         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      00701B E0               [24] 3810 	movx	a,@dptr
      00701C FF               [12] 3811 	mov	r7,a
      00701D BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      007020 C0 07            [24] 3814 	push	ar7
      007022 12 3E 32         [24] 3815 	lcall	_ak820_nvm_flush
      007025 D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      007027 90 07 E7         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      00702A E0               [24] 3819 	movx	a,@dptr
      00702B 70 07            [24] 3820 	jnz	00103$
      00702D 12 3E 23         [24] 3821 	lcall	_ak820_nvm_ok
      007030 E5 82            [12] 3822 	mov	a, dpl
      007032 60 17            [24] 3823 	jz	00106$
      007034                       3824 00103$:
      007034 90 08 2F         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      007037 12 38 67         [24] 3826 	lcall	_ak820_outline_0090
      00703A 90 08 24         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      00703D 12 43 6F         [24] 3828 	lcall	_ak820_outline_0146
      007040 90 08 26         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      007043 EF               [12] 3830 	mov	a,r7
      007044 F0               [24] 3831 	movx	@dptr,a
      007045 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      007048 02 6D 25         [24] 3834 	ljmp	_ak820_usb_send
      00704B                       3835 00106$:
      00704B 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      00704C                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      00704C A2 AF            [12] 3852 	mov	c,_EA
      00704E E4               [12] 3853 	clr	a
      00704F 33               [12] 3854 	rlc	a
      007050 FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3857 ;	assignBit
      007051 C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      007053 90 07 BF         [24] 3860 	mov	dptr,#_USB_EnumStatus
      007056 E0               [24] 3861 	movx	a,@dptr
      007057 60 0A            [24] 3862 	jz	00101$
      007059 90 07 C6         [24] 3863 	mov	dptr,#_raw_state
      00705C E0               [24] 3864 	movx	a,@dptr
      00705D FE               [12] 3865 	mov	r6,a
      00705E BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      007061 80 06            [24] 3867 	sjmp	00102$
      007063                       3868 00270$:
      007063                       3869 00101$:
                                   3870 ;	assignBit
      007063 EF               [12] 3871 	mov	a,r7
      007064 24 FF            [12] 3872 	add	a,#0xff
      007066 92 AF            [24] 3873 	mov	_EA,c
      007068 22               [24] 3874 	ret
      007069                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      007069 90 07 C6         [24] 3877 	mov	dptr,#_raw_state
      00706C 74 03            [12] 3878 	mov	a,#0x03
      00706E F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3881 ;	assignBit
      00706F EF               [12] 3882 	mov	a,r7
      007070 24 FF            [12] 3883 	add	a,#0xff
      007072 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      007074 90 07 C7         [24] 3886 	mov	dptr,#_raw_buffer
      007077 E0               [24] 3887 	movx	a,@dptr
      007078 FF               [12] 3888 	mov	r7,a
      007079 E4               [12] 3889 	clr	a
      00707A BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      00707D 04               [12] 3891 	inc	a
      00707E                       3892 00271$:
      00707E FF               [12] 3893 	mov	r7,a
      00707F 70 03            [24] 3894 	jnz	00273$
      007081 02 71 21         [24] 3895 	ljmp	00118$
      007084                       3896 00273$:
      007084 90 07 C8         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      007087 E0               [24] 3898 	movx	a,@dptr
      007088 60 03            [24] 3899 	jz	00274$
      00708A 02 71 21         [24] 3900 	ljmp	00118$
      00708D                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      00708D 90 07 C9         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      007090 E0               [24] 3904 	movx	a,@dptr
      007091 FD               [12] 3905 	mov	r5,a
      007092 7E 00            [12] 3906 	mov	r6,#0x00
      007094 90 07 CA         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      007097 E0               [24] 3908 	movx	a,@dptr
      007098 7B 00            [12] 3909 	mov	r3,#0x00
      00709A 42 06            [12] 3910 	orl	ar6,a
      00709C EB               [12] 3911 	mov	a,r3
      00709D 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      00709F 90 07 CB         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      0070A2 E0               [24] 3915 	movx	a,@dptr
      0070A3 FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0070A4 7B 05            [12] 3918 	mov	r3,#0x05
      0070A6                       3919 00128$:
      0070A6 EB               [12] 3920 	mov	a,r3
      0070A7 12 72 2B         [24] 3921 	lcall	_ak820_outline_0109
      0070AA 0B               [12] 3922 	inc	r3
      0070AB BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      0070AE                       3924 00275$:
      0070AE 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      0070B0 EC               [12] 3927 	mov	a,r4
      0070B1 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      0070B3 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      0070B5 EC               [12] 3931 	mov	a,r4
      0070B6 60 26            [24] 3932 	jz	00165$
      0070B8 8C 03            [24] 3933 	mov	ar3,r4
      0070BA 1B               [12] 3934 	dec	r3
      0070BB 7A 00            [12] 3935 	mov	r2,#0x00
      0070BD 74 FF            [12] 3936 	mov	a,#0xff
      0070BF C3               [12] 3937 	clr	c
      0070C0 9B               [12] 3938 	subb	a,r3
      0070C1 FB               [12] 3939 	mov	r3,a
      0070C2 74 FF            [12] 3940 	mov	a,#0xff
      0070C4 9A               [12] 3941 	subb	a,r2
      0070C5 FA               [12] 3942 	mov	r2,a
      0070C6 8E 00            [24] 3943 	mov	ar0,r6
      0070C8 8D 01            [24] 3944 	mov	ar1,r5
      0070CA C3               [12] 3945 	clr	c
      0070CB EB               [12] 3946 	mov	a,r3
      0070CC 98               [12] 3947 	subb	a,r0
      0070CD EA               [12] 3948 	mov	a,r2
      0070CE 99               [12] 3949 	subb	a,r1
      0070CF 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      0070D1                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      0070D1 90 07 C8         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      0070D4 74 FF            [12] 3955 	mov	a,#0xff
      0070D6 F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      0070D7 90 07 CB         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      0070DA E4               [12] 3959 	clr	a
      0070DB F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      0070DC 80 3A            [24] 3962 	sjmp	00108$
      0070DE                       3963 00165$:
      0070DE 7B 00            [12] 3964 	mov	r3,#0x00
      0070E0                       3965 00131$:
      0070E0 C3               [12] 3966 	clr	c
      0070E1 EB               [12] 3967 	mov	a,r3
      0070E2 9C               [12] 3968 	subb	a,r4
      0070E3 50 33            [24] 3969 	jnc	00108$
      0070E5 C0 04            [24] 3970 	push	ar4
      0070E7 8B 02            [24] 3971 	mov	ar2,r3
      0070E9 74 05            [12] 3972 	mov	a,#0x05
      0070EB 2A               [12] 3973 	add	a, r2
      0070EC F9               [12] 3974 	mov	r1,a
      0070ED 33               [12] 3975 	rlc	a
      0070EE 95 E0            [12] 3976 	subb	a,acc
      0070F0 FA               [12] 3977 	mov	r2,a
      0070F1 E9               [12] 3978 	mov	a,r1
      0070F2 24 C7            [12] 3979 	add	a, #_raw_buffer
      0070F4 F9               [12] 3980 	mov	r1,a
      0070F5 EA               [12] 3981 	mov	a,r2
      0070F6 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      0070F8 FA               [12] 3983 	mov	r2,a
      0070F9 8B 2F            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      0070FB 75 30 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      0070FE 8E 00            [24] 3986 	mov	ar0,r6
      007100 8D 04            [24] 3987 	mov	ar4,r5
      007102 E5 2F            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      007104 28               [12] 3989 	add	a, r0
      007105 F8               [12] 3990 	mov	r0,a
      007106 E5 30            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      007108 3C               [12] 3992 	addc	a, r4
      007109 FC               [12] 3993 	mov	r4,a
      00710A 88 82            [24] 3994 	mov	dpl,r0
      00710C 8C 83            [24] 3995 	mov	dph,r4
      00710E E4               [12] 3996 	clr	a
      00710F 93               [24] 3997 	movc	a,@a+dptr
      007110 12 72 37         [24] 3998 	lcall	_ak820_outline_0147
      007113 0B               [12] 3999 	inc	r3
      007114 D0 04            [24] 4000 	pop	ar4
      007116 80 C8            [24] 4001 	sjmp	00131$
      007118                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007118 12 72 17         [24] 4004 	lcall	_ak820_outline_0048
      00711B 12 6D 25         [24] 4005 	lcall	_ak820_usb_send
      00711E 02 71 C7         [24] 4006 	ljmp	00119$
      007121                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      007121 EF               [12] 4009 	mov	a,r7
      007122 70 03            [24] 4010 	jnz	00281$
      007124 02 71 A4         [24] 4011 	ljmp	00114$
      007127                       4012 00281$:
      007127 12 72 3D         [24] 4013 	lcall	_ak820_outline_0171
      00712A BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      00712D 80 03            [24] 4015 	sjmp	00283$
      00712F                       4016 00282$:
      00712F 02 71 A4         [24] 4017 	ljmp	00114$
      007132                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      007132 7F 02            [12] 4020 	mov	r7,#0x02
      007134                       4021 00133$:
      007134 EF               [12] 4022 	mov	a,r7
      007135 12 72 2B         [24] 4023 	lcall	_ak820_outline_0109
      007138 0F               [12] 4024 	inc	r7
      007139 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      00713C                       4026 00284$:
      00713C 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      00713E 90 07 C9         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      007141 74 01            [12] 4030 	mov	a,#0x01
      007143 F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      007144 90 07 CA         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      007147 74 A8            [12] 4034 	mov	a,#0xa8
      007149 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      00714A 90 07 CB         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      00714D 12 3B A0         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      007150 7F 00            [12] 4040 	mov	r7,#0x00
      007152                       4041 00135$:
      007152 8F 06            [24] 4042 	mov	ar6,r7
      007154 74 0B            [12] 4043 	mov	a,#0x0b
      007156 2E               [12] 4044 	add	a, r6
      007157 24 C7            [12] 4045 	add	a,#_raw_buffer
      007159 FE               [12] 4046 	mov	r6,a
      00715A E4               [12] 4047 	clr	a
      00715B 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      00715D FD               [12] 4049 	mov	r5,a
      00715E EF               [12] 4050 	mov	a,r7
      00715F 24 64            [12] 4051 	add	a, #_ak820_flash_diagnostic
      007161 F5 82            [12] 4052 	mov	dpl,a
      007163 E4               [12] 4053 	clr	a
      007164 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      007166 F5 83            [12] 4055 	mov	dph,a
      007168 E0               [24] 4056 	movx	a,@dptr
      007169 8E 82            [24] 4057 	mov	dpl,r6
      00716B 8D 83            [24] 4058 	mov	dph,r5
      00716D F0               [24] 4059 	movx	@dptr,a
      00716E 0F               [12] 4060 	inc	r7
      00716F BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      007172                       4062 00286$:
      007172 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      007174 90 0E 79         [24] 4065 	mov	dptr,#_vial_unlocked
      007177 E0               [24] 4066 	movx	a,@dptr
      007178 90 07 D8         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      00717B F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      00717C 90 0E 7A         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      00717F E0               [24] 4071 	movx	a,@dptr
      007180 90 07 D9         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      007183 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      007184 90 07 BF         [24] 4075 	mov	dptr,#_USB_EnumStatus
      007187 E0               [24] 4076 	movx	a,@dptr
      007188 90 07 DA         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      00718B F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      00718C 90 07 C0         [24] 4080 	mov	dptr,#_USB_SleepStatus
      00718F E0               [24] 4081 	movx	a,@dptr
      007190 90 07 DB         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      007193 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      007194 90 07 C6         [24] 4085 	mov	dptr,#_raw_state
      007197 E0               [24] 4086 	movx	a,@dptr
      007198 90 07 DC         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      00719B F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      00719C 12 72 17         [24] 4090 	lcall	_ak820_outline_0048
      00719F 12 6D 25         [24] 4091 	lcall	_ak820_usb_send
      0071A2 80 23            [24] 4092 	sjmp	00119$
      0071A4                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      0071A4 12 6F 34         [24] 4095 	lcall	_raw_request_is_nonpersistent
      0071A7 E5 82            [12] 4096 	mov	a, dpl
      0071A9 90 07 E7         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      0071AC F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      0071AD 12 3F 84         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      0071B0 90 0C A3         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      0071B3 74 20            [12] 4103 	mov	a,#0x20
      0071B5 F0               [24] 4104 	movx	@dptr,a
      0071B6 90 07 C7         [24] 4105 	mov	dptr,#_raw_buffer
      0071B9 75 F0 00         [24] 4106 	mov	b, #0x00
      0071BC 12 AC 2D         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      0071BF 12 3F 99         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      0071C2 90 07 E7         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      0071C5 E4               [12] 4112 	clr	a
      0071C6 F0               [24] 4113 	movx	@dptr,a
      0071C7                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4116 ;	assignBit
      0071C7 A2 AF            [12] 4117 	mov	c,_EA
      0071C9 92 1E            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4120 ;	assignBit
      0071CB C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      0071CD 12 72 43         [24] 4123 	lcall	_ak820_outline_0174
      0071D0 BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      0071D3 90 07 C6         [24] 4125 	mov	dptr,#_raw_state
      0071D6 74 05            [12] 4126 	mov	a,#0x05
      0071D8 F0               [24] 4127 	movx	@dptr,a
      0071D9 80 1B            [24] 4128 	sjmp	00127$
      0071DB                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      0071DB 12 72 43         [24] 4131 	lcall	_ak820_outline_0174
      0071DE BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      0071E1 80 0E            [24] 4133 	sjmp	00121$
      0071E3                       4134 00290$:
      0071E3 12 72 43         [24] 4135 	lcall	_ak820_outline_0174
      0071E6 BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      0071E9 80 06            [24] 4137 	sjmp	00121$
      0071EB                       4138 00291$:
      0071EB 12 72 43         [24] 4139 	lcall	_ak820_outline_0174
      0071EE BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      0071F1                       4141 00121$:
      0071F1 90 07 C6         [24] 4142 	mov	dptr,#_raw_state
      0071F4 E4               [12] 4143 	clr	a
      0071F5 F0               [24] 4144 	movx	@dptr,a
      0071F6                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4147 ;	assignBit
      0071F6 A2 1E            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      0071F8 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      0071FA 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      0071FB                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      0071FB A2 AF            [12] 4165 	mov	c,_EA
      0071FD 92 1F            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4168 ;	assignBit
      0071FF C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      007201 90 07 E8         [24] 4171 	mov	dptr,#_keyboard_reset
      007204 E0               [24] 4172 	movx	a,@dptr
      007205 FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      007206 E4               [12] 4175 	clr	a
      007207 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4178 ;	assignBit
      007208 A2 1F            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      00720A 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      00720C EF               [12] 4182 	mov	a,r7
      00720D B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      007210                       4184 00103$:
      007210 B3               [12] 4185 	cpl	c
      007211 92 1F            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      007213 12 38 BA         [24] 4187 	lcall	_ak820_outline_0159
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      007216 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00C0C9                       4193 _shared_offsets:
      00C0C9 00                    4194 	.db #0x00	; 0
      00C0CA 00                    4195 	.db #0x00	; 0
      00C0CB 28                    4196 	.db #0x28	; 40
      00C0CC 28                    4197 	.db #0x28	; 40
      00C0CD 2B                    4198 	.db #0x2b	; 43
      00C0CE 00                    4199 	.db #0x00	; 0
      00C0CF 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00C0D0                       4203 _shared_lengths:
      00C0D0 00                    4204 	.db #0x00	; 0
      00C0D1 00                    4205 	.db #0x00	; 0
      00C0D2 00                    4206 	.db #0x00	; 0
      00C0D3 03                    4207 	.db #0x03	; 3
      00C0D4 03                    4208 	.db #0x03	; 3
      00C0D5 00                    4209 	.db #0x00	; 0
      00C0D6 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00C0D7                       4213 _interface_descriptors:
      00C0D7 72 C6                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00C0D9 72 C7                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00C0DB 25 C7                 4216 	.byte _RawReport, (_RawReport >> 8)
      00C0DD 8B C7                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00C0DF B7 C6                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00C0E1 A4 C7                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0018
                                   4226 	.globl _ak820_outline_0038
                                   4227 	.globl _ak820_outline_0048
                                   4228 	.globl _ak820_outline_0090
                                   4229 	.globl _ak820_outline_0109
                                   4230 	.globl _ak820_outline_0146
                                   4231 	.globl _ak820_outline_0147
                                   4232 	.globl _ak820_outline_0159
                                   4233 	.globl _ak820_outline_0171
                                   4234 	.globl _ak820_outline_0174
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0048
      007217                       4238 _ak820_outline_0048:
      007217 90 08 24         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      00721A 74 C7            [12] 4240 	mov	a,#_raw_buffer
      00721C F0               [24] 4241 	movx	@dptr,a
      00721D 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      00721F A3               [24] 4243 	inc	dptr
      007220 F0               [24] 4244 	movx	@dptr,a
      007221 90 08 26         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      007224 74 20            [12] 4246 	mov	a,#0x20
      007226 F0               [24] 4247 	movx	@dptr,a
      007227 75 82 03         [24] 4248 	mov	dpl,#0x03
      00722A 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0109
      00722B                       4253 _ak820_outline_0109:
      00722B 24 C7            [12] 4254 	add	a,#_raw_buffer
      00722D F5 82            [12] 4255 	mov	dpl,a
      00722F E4               [12] 4256 	clr	a
      007230 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      007232 F5 83            [12] 4258 	mov	dph,a
      007234 E4               [12] 4259 	clr	a
      007235 F0               [24] 4260 	movx	@dptr,a
      007236 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0147
      007237                       4265 _ak820_outline_0147:
      007237 89 82            [24] 4266 	mov	dpl,r1
      007239 8A 83            [24] 4267 	mov	dph,r2
      00723B F0               [24] 4268 	movx	@dptr,a
      00723C 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0171
      00723D                       4273 _ak820_outline_0171:
      00723D 90 07 C8         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      007240 E0               [24] 4275 	movx	a,@dptr
      007241 FF               [12] 4276 	mov	r7,a
      007242 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0174
      007243                       4281 _ak820_outline_0174:
      007243 90 07 C6         [24] 4282 	mov	dptr,#_raw_state
      007246 E0               [24] 4283 	movx	a,@dptr
      007247 FF               [12] 4284 	mov	r7,a
      007248 22               [24] 4285 	ret
