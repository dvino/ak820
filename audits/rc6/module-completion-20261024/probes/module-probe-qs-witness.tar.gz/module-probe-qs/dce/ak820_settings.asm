;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_settings
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _clear_keyboard
	.globl ___memcpy
	.globl _memset
	.globl _memcmp
	.globl _ak820_eeprom_update_block_xdata
	.globl _ak820_eeprom_read_block_xdata
	.globl _ak820_nvm_end
	.globl _ak820_nvm_begin
	.globl _ak820_nvm_schema_fault
	.globl _ak820_nvm_ok
	.globl _ak820_settings_set_PARM_3
	.globl _ak820_settings_set_PARM_2
	.globl _ak820_settings_get_PARM_3
	.globl _ak820_settings_get_PARM_2
	.globl _ak820_settings_query_PARM_3
	.globl _ak820_settings_query_PARM_2
	.globl _ak820_settings_init
	.globl _ak820_settings_query
	.globl _ak820_settings_get
	.globl _ak820_settings_set
	.globl _ak820_settings_reset
	.globl _ak820_settings_grave_esc
	.globl _ak820_settings_combo_term
	.globl _ak820_settings_tapping_term
	.globl _ak820_settings_tap_code_delay
	.globl _ak820_settings_caps_delay
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_settings_query_sloc0_1_0:
	.ds 2
_ak820_settings_query_sloc1_1_0:
	.ds 2
_ak820_settings_query_sloc2_1_0:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_valid_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_current:
	.ds 24
_candidate:
	.ds 24
_word_p_10000_54:
	.ds 2
_put_word_PARM_2:
	.ds 2
_put_word_p_10000_56:
	.ds 2
_checksum_crc_10000_59:
	.ds 2
_ak820_settings_init_blank_zero_10000_82:
	.ds 1
_ak820_settings_init_blank_erased_10000_82:
	.ds 1
_offset_id_10000_90:
	.ds 2
_ak820_settings_query_PARM_2:
	.ds 3
_ak820_settings_query_PARM_3:
	.ds 2
_ak820_settings_query_greater_than_10000_94:
	.ds 2
_ak820_settings_query_used_10000_95:
	.ds 2
_ak820_settings_get_PARM_2:
	.ds 3
_ak820_settings_get_PARM_3:
	.ds 2
_ak820_settings_get_id_10000_100:
	.ds 2
_ak820_settings_set_PARM_2:
	.ds 3
_ak820_settings_set_PARM_3:
	.ds 2
_ak820_settings_set_id_10000_104:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'word'
;------------------------------------------------------------
;p             Allocated with name '_word_p_10000_54'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:13: static uint16_t word(const uint8_t AK820_XDATA *p) {
;	-----------------------------------------
;	 function word
;	-----------------------------------------
_word:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	lcall	_ak820_outline_0113
	mov	dptr,#_word_p_10000_54
	lcall	_ak820_outline_0114
;	keyboards/ajazz/ak820/ak820_settings.c:14: return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
	mov	dptr,#_word_p_10000_54
	lcall	_ak820_outline_0005
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
	lcall	_ak820_outline_0118
	mov	r6,a
	clr	a
	orl	ar5,a
	mov	a,r6
	orl	ar4,a
	lcall	_ak820_outline_0197
;	keyboards/ajazz/ak820/ak820_settings.c:15: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'put_word'
;------------------------------------------------------------
;v             Allocated with name '_put_word_PARM_2'
;p             Allocated with name '_put_word_p_10000_56'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:16: static void put_word(uint8_t AK820_XDATA *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
;	-----------------------------------------
;	 function put_word
;	-----------------------------------------
_put_word:
	lcall	_ak820_outline_0113
	mov	dptr,#_put_word_p_10000_56
	lcall	_ak820_outline_0114
	mov	dptr,#_put_word_p_10000_56
	lcall	_ak820_outline_0055
	mov	dptr,#_put_word_PARM_2
	lcall	_ak820_outline_0063
	mov	ar3,r4
	lcall	_ak820_outline_0124
	mov	a,r3
	lcall	_ak820_outline_0077
	inc	dptr
	mov	ar4,r5
	mov	a,r4
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'checksum'
;------------------------------------------------------------
;crc           Allocated with name '_checksum_crc_10000_59'
;i             Allocated with name '_checksum_i_10000_59'
;bit           Allocated with name '_checksum_bit_10000_59'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:17: static uint16_t checksum(void) {
;	-----------------------------------------
;	 function checksum
;	-----------------------------------------
_checksum:
;	keyboards/ajazz/ak820/ak820_settings.c:18: uint16_t crc = 0xFFFFu;
	mov	dptr,#_checksum_crc_10000_59
	mov	a,#0xff
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
	mov	r7,#0x00
00106$:
;	keyboards/ajazz/ak820/ak820_settings.c:21: crc ^= (uint16_t)candidate[i] << 8;
	lcall	_ak820_outline_0110
	mov	r5,a
	mov	r6,#0x00
	mov	dptr,#_checksum_crc_10000_59
	movx	a,@dptr
	xrl	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	xrl	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:22: for (bit = 0; bit < 8; ++bit) crc = (crc & 0x8000u) ? (crc << 1) ^ 0x1021u : (uint16_t)(crc << 1);
	mov	r6,#0x08
00105$:
	mov	dptr,#_checksum_crc_10000_59
	lcall	_ak820_outline_0063
	jnb	acc.7,00110$
	mov	a,r4
	add	a,r4
	mov	r2,a
	mov	a,r5
	rlc	a
	mov	r3,a
	xrl	ar2,#0x21
	xrl	ar3,#0x10
	sjmp	00111$
00110$:
	mov	a,r4
	add	a,r4
	mov	r2,a
	mov	a,r5
	rlc	a
	mov	r3,a
00111$:
	mov	dptr,#_checksum_crc_10000_59
	mov	a,r2
	lcall	_ak820_outline_0195
	djnz	r6,00105$
;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
	inc	r7
	cjne	r7,#0x16,00151$
00151$:
	jc	00106$
;	keyboards/ajazz/ak820/ak820_settings.c:24: return crc;
	lcall	_ak820_outline_0154
;	keyboards/ajazz/ak820/ak820_settings.c:25: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'seal'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:26: static void seal(void) { put_word(candidate + 22, checksum()); }
;	-----------------------------------------
;	 function seal
;	-----------------------------------------
_seal:
	lcall	_checksum
	lcall	_ak820_outline_0127
	mov	dptr,#_put_word_PARM_2
	lcall	_ak820_outline_0149
	mov	dptr,#(_candidate + 0x0016)
	ljmp	_put_word
;------------------------------------------------------------
;Allocation info for local variables in function 'defaults'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:27: static void defaults(void) {
;	-----------------------------------------
;	 function defaults
;	-----------------------------------------
_defaults:
;	keyboards/ajazz/ak820/ak820_settings.c:28: memset(candidate, 0, sizeof(candidate));
	mov	dptr,#_memset_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_memset_PARM_3
	lcall	_ak820_outline_0042
	mov	b,a
	lcall	_memset
;	keyboards/ajazz/ak820/ak820_settings.c:29: candidate[0] = 'Q'; candidate[1] = 'S'; candidate[2] = AK820_SETTINGS_VERSION;
	mov	dptr,#_candidate
	mov	a,#0x51
	movx	@dptr,a
	mov	dptr,#(_candidate + 0x0001)
	mov	a,#0x53
	movx	@dptr,a
	mov	dptr,#(_candidate + 0x0002)
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:30: candidate[3] = 11; candidate[4] = AK820_SETTINGS_CAPABILITIES;
	mov	dptr,#(_candidate + 0x0003)
	mov	a,#0x0b
	movx	@dptr,a
	mov	dptr,#(_candidate + 0x0004)
	mov	a,#0x3f
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:31: put_word(candidate + 14, 175);
	mov	dptr,#_put_word_PARM_2
	mov	a,#0xaf
	lcall	_ak820_outline_0131
	mov	dptr,#(_candidate + 0x000e)
	lcall	_put_word
;	keyboards/ajazz/ak820/ak820_settings.c:32: put_word(candidate + 6, 40); put_word(candidate + 8, 200); put_word(candidate + 12, 80);
	mov	dptr,#_put_word_PARM_2
	mov	a,#0x28
	lcall	_ak820_outline_0131
	mov	dptr,#(_candidate + 0x0006)
	lcall	_put_word
	mov	dptr,#_put_word_PARM_2
	mov	a,#0xc8
	lcall	_ak820_outline_0131
	mov	dptr,#(_candidate + 0x0008)
	lcall	_put_word
	mov	dptr,#_put_word_PARM_2
	mov	a,#0x50
	lcall	_ak820_outline_0131
	mov	dptr,#(_candidate + 0x000c)
	lcall	_put_word
;	keyboards/ajazz/ak820/ak820_settings.c:33: seal();
;	keyboards/ajazz/ak820/ak820_settings.c:34: }
	ljmp	_seal
;------------------------------------------------------------
;Allocation info for local variables in function 'valid'
;------------------------------------------------------------
;i             Allocated with name '_valid_i_10000_68'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:35: static bool valid(void) {
;	-----------------------------------------
;	 function valid
;	-----------------------------------------
_valid:
;	keyboards/ajazz/ak820/ak820_settings.c:37: if (candidate[0] != 'Q' || candidate[1] != 'S' || candidate[2] != AK820_SETTINGS_VERSION || candidate[3] != 11 || candidate[4] != AK820_SETTINGS_CAPABILITIES) return false;
	mov	dptr,#_candidate
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x51,00101$
	mov	dptr,#(_candidate + 0x0001)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x53,00101$
	mov	dptr,#(_candidate + 0x0002)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00101$
	mov	dptr,#(_candidate + 0x0003)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x0b,00101$
	mov	dptr,#(_candidate + 0x0004)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x3f,00226$
	sjmp	00102$
00226$:
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:38: if (candidate[5] & 0xF0u) return false;
	mov	dptr,#(_candidate + 0x0005)
	movx	a,@dptr
	anl	a,#0xf0
	jz	00108$
	mov	dpl, #0x00
	ret
00108$:
;	keyboards/ajazz/ak820/ak820_settings.c:39: if (!word(candidate + 6) || word(candidate + 6) > 1000 || !word(candidate + 8) || word(candidate + 8) > 1000) return false;
	mov	dptr,#(_candidate + 0x0006)
	lcall	_word
	lcall	_ak820_outline_0084
	jz	00109$
	mov	dptr,#(_candidate + 0x0006)
	lcall	_word
	lcall	_ak820_outline_0047
	jc	00109$
;	free result
	mov	dptr,#(_candidate + 0x0008)
	lcall	_word
	lcall	_ak820_outline_0084
	jz	00109$
	mov	dptr,#(_candidate + 0x0008)
	lcall	_word
	lcall	_ak820_outline_0047
	jnc	00110$
;	free result
00109$:
	mov	dpl, #0x00
	ret
00110$:
;	keyboards/ajazz/ak820/ak820_settings.c:40: if (!word(candidate + 14) || word(candidate + 14) > 1000) return false;
	mov	dptr,#(_candidate + 0x000e)
	lcall	_word
	lcall	_ak820_outline_0084
	jz	00114$
	mov	dptr,#(_candidate + 0x000e)
	lcall	_word
	lcall	_ak820_outline_0047
	jnc	00115$
;	free result
00114$:
	mov	dpl, #0x00
	ret
00115$:
;	keyboards/ajazz/ak820/ak820_settings.c:41: if (word(candidate + 10) > 100 || word(candidate + 12) > 100) return false;
	mov	dptr,#(_candidate + 0x000a)
	lcall	_word
	lcall	_ak820_outline_0132
	clr	c
	mov	a,#0x64
	subb	a,r6
	clr	a
	subb	a,r7
	jc	00117$
;	free result
	mov	dptr,#(_candidate + 0x000c)
	lcall	_word
	lcall	_ak820_outline_0132
	clr	c
	mov	a,#0x64
	subb	a,r6
	clr	a
	subb	a,r7
	jnc	00151$
;	free result
00117$:
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 16; i < 22; ++i) if (candidate[i]) return false;
	ret
00151$:
	mov	r7,#0x10
00123$:
	mov	a,r7
	add	a, #_candidate
	mov	r5,a
	clr	a
	addc	a, #(_candidate >> 8)
	lcall	_ak820_outline_0069
	jz	00124$
	mov	dpl, #0x00
	ret
00124$:
	inc	r7
	cjne	r7,#0x16,00237$
00237$:
	jc	00123$
;	keyboards/ajazz/ak820/ak820_settings.c:43: return word(candidate + 22) == checksum();
	mov	dptr,#(_candidate + 0x0016)
	lcall	_word
	lcall	_ak820_outline_0132
	push	ar7
	push	ar6
	lcall	_checksum
	lcall	_ak820_outline_0153
	pop	ar6
	pop	ar7
	mov	a,r6
	cjne	a,ar4,00239$
	mov	a,r7
	cjne	a,ar5,00239$
	setb	c
	sjmp	00240$
00239$:
	clr	c
00240$:
	mov  _valid_sloc0_1_0,c
	lcall	_ak820_outline_0159
;	keyboards/ajazz/ak820/ak820_settings.c:44: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'commit'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:48: static int commit(void) {
;	-----------------------------------------
;	 function commit
;	-----------------------------------------
_commit:
;	keyboards/ajazz/ak820/ak820_settings.c:49: if (!ak820_nvm_ok()) return -1;
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00102$
	mov	dptr,#0xffff
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:50: if (!memcmp(current, candidate, sizeof(current))) return 0;
	mov	dptr,#_memcmp_PARM_2
	mov	a,#_candidate
	movx	@dptr,a
	mov	a,#(_candidate >> 8)
	lcall	_ak820_outline_0070
	mov	dptr,#_memcmp_PARM_3
	mov	a,#0x18
	lcall	_ak820_outline_0131
	mov	dptr,#_current
	mov	b,a
	lcall	_memcmp
	lcall	_ak820_outline_0084
	jnz	00104$
	mov	dptr,#0x0000
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_settings.c:51: clear_keyboard();
	lcall	_clear_keyboard
;	keyboards/ajazz/ak820/ak820_settings.c:52: ak820_nvm_begin();
	lcall	_ak820_nvm_begin
;	keyboards/ajazz/ak820/ak820_settings.c:53: ak820_eeprom_update_block_xdata(candidate, (void *)AK820_SETTINGS_ADDR, sizeof(candidate));
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
	mov	a,#0xa8
	movx	@dptr,a
	mov	a,#0x06
	lcall	_ak820_outline_0070
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
	lcall	_ak820_outline_0042
	lcall	_ak820_eeprom_update_block_xdata
;	keyboards/ajazz/ak820/ak820_settings.c:54: ak820_nvm_end();
	lcall	_ak820_nvm_end
;	keyboards/ajazz/ak820/ak820_settings.c:55: if (!ak820_nvm_ok()) return -1;
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00106$
	mov	dptr,#0xffff
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_settings.c:56: memcpy(current, candidate, sizeof(current));
	lcall	_ak820_outline_0020
	lcall	___memcpy
;	keyboards/ajazz/ak820/ak820_settings.c:57: return 0;
	mov	dptr,#0x0000
;	keyboards/ajazz/ak820/ak820_settings.c:58: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_init'
;------------------------------------------------------------
;i             Allocated with name '_ak820_settings_init_i_10000_82'
;blank_zero    Allocated with name '_ak820_settings_init_blank_zero_10000_82'
;blank_erased  Allocated with name '_ak820_settings_init_blank_erased_10000_82'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:59: void ak820_settings_init(void) {
;	-----------------------------------------
;	 function ak820_settings_init
;	-----------------------------------------
_ak820_settings_init:
;	keyboards/ajazz/ak820/ak820_settings.c:61: bool blank_zero = true, blank_erased = true;
	mov	dptr,#_ak820_settings_init_blank_zero_10000_82
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#_ak820_settings_init_blank_erased_10000_82
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:62: ak820_eeprom_read_block_xdata(candidate, (const void *)AK820_SETTINGS_ADDR, sizeof(candidate));
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	mov	a,#0xa8
	movx	@dptr,a
	mov	a,#0x06
	lcall	_ak820_outline_0070
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	lcall	_ak820_outline_0042
	lcall	_ak820_eeprom_read_block_xdata
;	keyboards/ajazz/ak820/ak820_settings.c:63: if (!valid()) {
	lcall	_valid
	mov	a, dpl
;	keyboards/ajazz/ak820/ak820_settings.c:66: for (i = 0; i < sizeof(candidate); ++i) {
	jnz	00110$
	mov	r7,a
00111$:
;	keyboards/ajazz/ak820/ak820_settings.c:67: if (candidate[i]) blank_zero = false;
	mov	a,r7
	add	a, #_candidate
	mov	r5,a
	clr	a
	addc	a, #(_candidate >> 8)
	lcall	_ak820_outline_0069
	jz	00102$
	mov	dptr,#_ak820_settings_init_blank_zero_10000_82
	clr	a
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:68: if (candidate[i] != 0xFF) blank_erased = false;
	lcall	_ak820_outline_0110
	mov	r6,a
	cjne	r6,#0xff,00167$
	sjmp	00112$
00167$:
	mov	dptr,#_ak820_settings_init_blank_erased_10000_82
	clr	a
	movx	@dptr,a
00112$:
;	keyboards/ajazz/ak820/ak820_settings.c:66: for (i = 0; i < sizeof(candidate); ++i) {
	inc	r7
	cjne	r7,#0x18,00168$
00168$:
	jc	00111$
;	keyboards/ajazz/ak820/ak820_settings.c:70: if (!blank_zero && !blank_erased) ak820_nvm_schema_fault();
	mov	dptr,#_ak820_settings_init_blank_zero_10000_82
	movx	a,@dptr
	jnz	00107$
	mov	dptr,#_ak820_settings_init_blank_erased_10000_82
	movx	a,@dptr
	jnz	00107$
	lcall	_ak820_nvm_schema_fault
00107$:
;	keyboards/ajazz/ak820/ak820_settings.c:71: defaults();
	lcall	_defaults
00110$:
;	keyboards/ajazz/ak820/ak820_settings.c:73: memcpy(current, candidate, sizeof(current));
	lcall	_ak820_outline_0020
;	keyboards/ajazz/ak820/ak820_settings.c:74: }
	ljmp	___memcpy
;------------------------------------------------------------
;Allocation info for local variables in function 'offset'
;------------------------------------------------------------
;id            Allocated with name '_offset_id_10000_90'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:75: static uint8_t offset(uint16_t id) {
;	-----------------------------------------
;	 function offset
;	-----------------------------------------
_offset:
	lcall	_ak820_outline_0113
	mov	dptr,#_offset_id_10000_90
	lcall	_ak820_outline_0114
;	keyboards/ajazz/ak820/ak820_settings.c:76: switch (id) {
	mov	dptr,#_offset_id_10000_90
	lcall	_ak820_outline_0055
	cjne	r6,#0x01,00145$
	cjne	r7,#0x00,00145$
	sjmp	00101$
00145$:
	cjne	r6,#0x02,00146$
	cjne	r7,#0x00,00146$
	sjmp	00102$
00146$:
	cjne	r6,#0x07,00147$
	cjne	r7,#0x00,00147$
	sjmp	00103$
00147$:
	cjne	r6,#0x12,00148$
	cjne	r7,#0x00,00148$
	sjmp	00104$
00148$:
;	keyboards/ajazz/ak820/ak820_settings.c:77: case 1: return 5;
	cjne	r6,#0x13,00106$
	cjne	r7,#0x00,00106$
	sjmp	00105$
00101$:
	mov	dpl, #0x05
;	keyboards/ajazz/ak820/ak820_settings.c:78: case 2: return 6;
	ret
00102$:
	mov	dpl, #0x06
;	keyboards/ajazz/ak820/ak820_settings.c:82: case 7: return 8;
	ret
00103$:
	mov	dpl, #0x08
;	keyboards/ajazz/ak820/ak820_settings.c:83: case 18: return 10;
	ret
00104$:
	mov	dpl, #0x0a
;	keyboards/ajazz/ak820/ak820_settings.c:84: case 19: return 12;
	ret
00105$:
	mov	dpl, #0x0c
;	keyboards/ajazz/ak820/ak820_settings.c:85: default: return 0;
	ret
00106$:
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_settings.c:86: }
;	keyboards/ajazz/ak820/ak820_settings.c:87: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_query'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_settings_query_sloc0_1_0'
;sloc1         Allocated with name '_ak820_settings_query_sloc1_1_0'
;sloc2         Allocated with name '_ak820_settings_query_sloc2_1_0'
;buffer        Allocated with name '_ak820_settings_query_PARM_2'
;size          Allocated with name '_ak820_settings_query_PARM_3'
;greater_than  Allocated with name '_ak820_settings_query_greater_than_10000_94'
;out           Allocated with name '_ak820_settings_query_out_10000_95'
;id            Allocated with name '_ak820_settings_query_id_10000_95'
;used          Allocated with name '_ak820_settings_query_used_10000_95'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:88: void ak820_settings_query(uint16_t greater_than, void *buffer, size_t size) {
;	-----------------------------------------
;	 function ak820_settings_query
;	-----------------------------------------
_ak820_settings_query:
	lcall	_ak820_outline_0113
	mov	dptr,#_ak820_settings_query_greater_than_10000_94
	lcall	_ak820_outline_0114
;	keyboards/ajazz/ak820/ak820_settings.c:89: uint8_t *out = buffer;
	mov	dptr,#_ak820_settings_query_PARM_2
	lcall	_ak820_outline_0013
	mov	ar2,r5
	mov	ar3,r6
	mov	ar4,r7
;	keyboards/ajazz/ak820/ak820_settings.c:91: size_t used = 0;
	mov	dptr,#_ak820_settings_query_used_10000_95
	lcall	_ak820_outline_0177
;	keyboards/ajazz/ak820/ak820_settings.c:92: memset(buffer, 0xFF, size);
	mov	dptr,#_ak820_settings_query_PARM_3
	lcall	_ak820_outline_0107
	mov	dptr,#_memset_PARM_2
	mov	a,#0xff
	movx	@dptr,a
	mov	dptr,#_memset_PARM_3
	mov	a,r0
	movx	@dptr,a
	mov	a,r1
	inc	dptr
	lcall	_ak820_outline_0033
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_memset
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
;	keyboards/ajazz/ak820/ak820_settings.c:93: for (id = 1; id <= 19 && used + 2 <= size; ++id) {
	mov	dptr,#_ak820_settings_query_greater_than_10000_94
	lcall	_ak820_outline_0055
	mov	_ak820_settings_query_sloc0_1_0,#0x01
	mov	(_ak820_settings_query_sloc0_1_0 + 1),#0x00
00107$:
	push	ar6
	push	ar7
	mov	r5,_ak820_settings_query_sloc0_1_0
	mov	r7,(_ak820_settings_query_sloc0_1_0 + 1)
	clr	c
	mov	a,#0x13
	subb	a,r5
	clr	a
	subb	a,r7
	pop	ar7
	pop	ar6
	jnc	00147$
	ret
00147$:
;	free result
	push	ar6
	push	ar7
	mov	dptr,#_ak820_settings_query_used_10000_95
	movx	a,@dptr
	mov	_ak820_settings_query_sloc1_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_settings_query_sloc1_1_0 + 1),a
	mov	a,#0x02
	add	a, _ak820_settings_query_sloc1_1_0
	mov	r5,a
	clr	a
	addc	a, (_ak820_settings_query_sloc1_1_0 + 1)
	mov	r7,a
	clr	c
	mov	a,r0
	subb	a,r5
	mov	a,r1
	subb	a,r7
	pop	ar7
	pop	ar6
	jnc	00148$
	ret
00148$:
;	free result
;	keyboards/ajazz/ak820/ak820_settings.c:94: if (id > greater_than && offset(id)) { out[used++] = id; out[used++] = 0; }
	clr	c
	mov	a,r6
	subb	a,_ak820_settings_query_sloc0_1_0
	mov	a,r7
	subb	a,(_ak820_settings_query_sloc0_1_0 + 1)
	jc	00149$
	ljmp	00108$
00149$:
;	free result
	mov	dpl, _ak820_settings_query_sloc0_1_0
	mov	dph, (_ak820_settings_query_sloc0_1_0 + 1)
	push	ar7
	push	ar6
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_offset
	mov	a, dpl
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar6
	pop	ar7
	jz	00108$
	push	ar6
	push	ar7
	mov	dptr,#_ak820_settings_query_used_10000_95
	mov	a,#0x01
	add	a, _ak820_settings_query_sloc1_1_0
	movx	@dptr,a
	clr	a
	addc	a, (_ak820_settings_query_sloc1_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	a,_ak820_settings_query_sloc1_1_0
	add	a, r2
	mov	_ak820_settings_query_sloc2_1_0,a
	mov	a,(_ak820_settings_query_sloc1_1_0 + 1)
	addc	a, r3
	mov	(_ak820_settings_query_sloc2_1_0 + 1),a
	mov	(_ak820_settings_query_sloc2_1_0 + 2),r4
	mov	r7,_ak820_settings_query_sloc0_1_0
	mov	dpl,_ak820_settings_query_sloc2_1_0
	mov	dph,(_ak820_settings_query_sloc2_1_0 + 1)
	mov	b,(_ak820_settings_query_sloc2_1_0 + 2)
	mov	a,r7
	lcall	__gptrput
	mov	dptr,#_ak820_settings_query_used_10000_95
	lcall	_ak820_outline_0055
	mov	dptr,#_ak820_settings_query_used_10000_95
	mov	a,#0x01
	add	a, r6
	movx	@dptr,a
	clr	a
	addc	a, r7
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	add	a, r2
	mov	r6,a
	mov	a,r7
	addc	a, r3
	mov	r7,a
	mov	ar5,r4
	lcall	_ak820_outline_0061
	clr	a
	lcall	__gptrput
;	keyboards/ajazz/ak820/ak820_settings.c:93: for (id = 1; id <= 19 && used + 2 <= size; ++id) {
	pop	ar7
	pop	ar6
;	keyboards/ajazz/ak820/ak820_settings.c:94: if (id > greater_than && offset(id)) { out[used++] = id; out[used++] = 0; }
00108$:
;	keyboards/ajazz/ak820/ak820_settings.c:93: for (id = 1; id <= 19 && used + 2 <= size; ++id) {
	inc	_ak820_settings_query_sloc0_1_0
	clr	a
	cjne	a,_ak820_settings_query_sloc0_1_0,00151$
	inc	(_ak820_settings_query_sloc0_1_0 + 1)
00151$:
;	keyboards/ajazz/ak820/ak820_settings.c:96: }
	ljmp	00107$
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_get'
;------------------------------------------------------------
;buffer        Allocated with name '_ak820_settings_get_PARM_2'
;capacity      Allocated with name '_ak820_settings_get_PARM_3'
;id            Allocated with name '_ak820_settings_get_id_10000_100'
;out           Allocated with name '_ak820_settings_get_out_10000_101'
;pos           Allocated with name '_ak820_settings_get_pos_10000_101'
;width         Allocated with name '_ak820_settings_get_width_10000_101'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:97: int ak820_settings_get(uint16_t id, void *buffer, size_t capacity) {
;	-----------------------------------------
;	 function ak820_settings_get
;	-----------------------------------------
_ak820_settings_get:
	lcall	_ak820_outline_0113
	mov	dptr,#_ak820_settings_get_id_10000_100
	lcall	_ak820_outline_0114
;	keyboards/ajazz/ak820/ak820_settings.c:98: uint8_t *out = buffer;
	mov	dptr,#_ak820_settings_get_PARM_2
	lcall	_ak820_outline_0013
;	keyboards/ajazz/ak820/ak820_settings.c:99: uint8_t pos = offset(id), width = id == 1 ? 1 : 2;
	mov	dptr,#_ak820_settings_get_id_10000_100
	lcall	_ak820_outline_0076
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_offset
	mov	r2, dpl
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	cjne	r3,#0x01,00108$
	cjne	r4,#0x00,00108$
	mov	r4,#0x01
	sjmp	00109$
00108$:
	mov	r4,#0x02
00109$:
;	keyboards/ajazz/ak820/ak820_settings.c:100: if (!pos || capacity < width) return -1;
	mov	a,r2
	jz	00101$
	push	ar5
	push	ar6
	push	ar7
	mov	dptr,#_ak820_settings_get_PARM_3
	lcall	_ak820_outline_0080
	pop	ar7
	pop	ar6
	pop	ar5
	jnc	00102$
00101$:
	mov	dptr,#0xffff
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:101: out[0] = current[pos];
	mov	a,r2
	add	a, #_current
	mov	dpl,a
	clr	a
	addc	a, #(_current >> 8)
	mov	dph,a
	movx	a,@dptr
	lcall	_ak820_outline_0050
	lcall	__gptrput
;	keyboards/ajazz/ak820/ak820_settings.c:102: if (width == 2) out[1] = current[pos + 1];
	cjne	r4,#0x02,00105$
	inc	r5
	cjne	r5,#0x00,00137$
	inc	r6
00137$:
	inc	r2
	mov	a,r2
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	a,r2
	add	a, #_current
	mov	dpl,a
	mov	a,r4
	addc	a, #(_current >> 8)
	mov	dph,a
	movx	a,@dptr
	lcall	_ak820_outline_0050
	lcall	__gptrput
00105$:
;	keyboards/ajazz/ak820/ak820_settings.c:103: return 0;
	mov	dptr,#0x0000
;	keyboards/ajazz/ak820/ak820_settings.c:104: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_set'
;------------------------------------------------------------
;buffer        Allocated with name '_ak820_settings_set_PARM_2'
;capacity      Allocated with name '_ak820_settings_set_PARM_3'
;id            Allocated with name '_ak820_settings_set_id_10000_104'
;in            Allocated with name '_ak820_settings_set_in_10000_105'
;pos           Allocated with name '_ak820_settings_set_pos_10000_105'
;width         Allocated with name '_ak820_settings_set_width_10000_105'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:105: int ak820_settings_set(uint16_t id, const void *buffer, size_t capacity) {
;	-----------------------------------------
;	 function ak820_settings_set
;	-----------------------------------------
_ak820_settings_set:
	lcall	_ak820_outline_0113
	mov	dptr,#_ak820_settings_set_id_10000_104
	lcall	_ak820_outline_0114
;	keyboards/ajazz/ak820/ak820_settings.c:106: const uint8_t *in = buffer;
	mov	dptr,#_ak820_settings_set_PARM_2
	lcall	_ak820_outline_0013
;	keyboards/ajazz/ak820/ak820_settings.c:107: uint8_t pos = offset(id), width = id == 1 ? 1 : 2;
	mov	dptr,#_ak820_settings_set_id_10000_104
	lcall	_ak820_outline_0076
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_offset
	mov	r2, dpl
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	cjne	r3,#0x01,00111$
	cjne	r4,#0x00,00111$
	mov	r4,#0x01
	sjmp	00112$
00111$:
	mov	r4,#0x02
00112$:
;	keyboards/ajazz/ak820/ak820_settings.c:108: if (!pos || capacity < width || !ak820_nvm_ok()) return -1;
	mov	a,r2
	jz	00101$
	push	ar5
	push	ar6
	push	ar7
	mov	dptr,#_ak820_settings_set_PARM_3
	lcall	_ak820_outline_0080
	pop	ar7
	pop	ar6
	pop	ar5
	jc	00101$
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00102$
00101$:
	mov	dptr,#0xffff
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:109: memcpy(candidate, current, sizeof(candidate));
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_current
	movx	@dptr,a
	mov	a,#(_current >> 8)
	lcall	_ak820_outline_0070
	mov	dptr,#___memcpy_PARM_3
	lcall	_ak820_outline_0042
	mov	b,a
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar2
	lcall	___memcpy
	pop	ar2
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_settings.c:110: candidate[pos] = in[0];
	mov	a,r2
	add	a, #_candidate
	mov	r1,a
	clr	a
	addc	a, #(_candidate >> 8)
	mov	r3,a
	lcall	_ak820_outline_0050
	lcall	__gptrget
	mov	dpl,r1
	mov	dph,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:111: if (width == 2) candidate[pos + 1] = in[1];
	cjne	r4,#0x02,00106$
	inc	r2
	mov	a,r2
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	a,r2
	add	a, #_candidate
	mov	r2,a
	mov	a,r4
	addc	a, #(_candidate >> 8)
	mov	r4,a
	inc	r5
	cjne	r5,#0x00,00155$
	inc	r6
00155$:
	lcall	_ak820_outline_0050
	lcall	__gptrget
	mov	dpl,r2
	mov	dph,r4
	movx	@dptr,a
00106$:
;	keyboards/ajazz/ak820/ak820_settings.c:112: seal();
	lcall	_seal
;	keyboards/ajazz/ak820/ak820_settings.c:113: if (!valid()) return -1;
	lcall	_valid
	mov	a, dpl
	jnz	00108$
	mov	dptr,#0xffff
	ret
00108$:
;	keyboards/ajazz/ak820/ak820_settings.c:114: return commit();
;	keyboards/ajazz/ak820/ak820_settings.c:115: }
	ljmp	_commit
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_reset'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:116: int ak820_settings_reset(void) { defaults(); return commit(); }
;	-----------------------------------------
;	 function ak820_settings_reset
;	-----------------------------------------
_ak820_settings_reset:
	lcall	_defaults
	ljmp	_commit
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_grave_esc'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:117: uint8_t ak820_settings_grave_esc(void) { return current[5]; }
;	-----------------------------------------
;	 function ak820_settings_grave_esc
;	-----------------------------------------
_ak820_settings_grave_esc:
	mov	dptr,#(_current + 0x0005)
	movx	a,@dptr
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_combo_term'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:118: uint16_t ak820_settings_combo_term(void) { return word(current + 6); }
;	-----------------------------------------
;	 function ak820_settings_combo_term
;	-----------------------------------------
_ak820_settings_combo_term:
	mov	dptr,#(_current + 0x0006)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_tapping_term'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:119: uint16_t ak820_settings_tapping_term(void) { return word(current + 8); }
;	-----------------------------------------
;	 function ak820_settings_tapping_term
;	-----------------------------------------
_ak820_settings_tapping_term:
	mov	dptr,#(_current + 0x0008)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_tap_code_delay'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:120: uint16_t ak820_settings_tap_code_delay(void) { return word(current + 10); }
;	-----------------------------------------
;	 function ak820_settings_tap_code_delay
;	-----------------------------------------
_ak820_settings_tap_code_delay:
	mov	dptr,#(_current + 0x000a)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_caps_delay'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:121: uint16_t ak820_settings_caps_delay(void) { return word(current + 12); }
;	-----------------------------------------
;	 function ak820_settings_caps_delay
;	-----------------------------------------
_ak820_settings_caps_delay:
	mov	dptr,#(_current + 0x000c)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_autoshift_timeout'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:122: uint16_t ak820_settings_autoshift_timeout(void) { return word(current + 14); }
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0005
	.globl _ak820_outline_0013
	.globl _ak820_outline_0020
	.globl _ak820_outline_0033
	.globl _ak820_outline_0042
	.globl _ak820_outline_0047
	.globl _ak820_outline_0050
	.globl _ak820_outline_0055
	.globl _ak820_outline_0061
	.globl _ak820_outline_0063
	.globl _ak820_outline_0069
	.globl _ak820_outline_0070
	.globl _ak820_outline_0076
	.globl _ak820_outline_0077
	.globl _ak820_outline_0080
	.globl _ak820_outline_0084
	.globl _ak820_outline_0107
	.globl _ak820_outline_0110
	.globl _ak820_outline_0113
	.globl _ak820_outline_0114
	.globl _ak820_outline_0118
	.globl _ak820_outline_0124
	.globl _ak820_outline_0127
	.globl _ak820_outline_0131
	.globl _ak820_outline_0132
	.globl _ak820_outline_0149
	.globl _ak820_outline_0153
	.globl _ak820_outline_0154
	.globl _ak820_outline_0159
	.globl _ak820_outline_0177
	.globl _ak820_outline_0195
	.globl _ak820_outline_0197

	.area CSEG (CODE)
; function ak820_outline_0013
_ak820_outline_0013:
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0020
_ak820_outline_0020:
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_candidate
	movx	@dptr,a
	mov	a,#(_candidate>>8)
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_current
	mov	b,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0033
_ak820_outline_0033:
	movx	@dptr,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0042
_ak820_outline_0042:
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_candidate
	ret

	.area CSEG (CODE)
; function ak820_outline_0047
_ak820_outline_0047:
	mov	r6,dpl
	mov	r7,dph
	clr	c
	mov	a,#0xe8
	subb	a,r6
	mov	a,#0x03
	subb	a,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0050
_ak820_outline_0050:
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0061
_ak820_outline_0061:
	mov	dpl,r6
	mov	dph,r7
	mov	b,r5
	ret

	.area CSEG (CODE)
; function ak820_outline_0069
_ak820_outline_0069:
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0076
_ak820_outline_0076:
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	ret

	.area CSEG (CODE)
; function ak820_outline_0080
_ak820_outline_0080:
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	ar0,r4
	mov	r7,#0x00
	clr	c
	mov	a,r1
	subb	a,r0
	mov	a,r3
	subb	a,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0084
_ak820_outline_0084:
	mov	a,dpl
	mov	b,dph
	orl	a,b
	ret

	.area CSEG (CODE)
; function ak820_outline_0110
_ak820_outline_0110:
	mov	a,r7
	add	a,#_candidate
	mov	dpl,a
	clr	a
	addc	a,#(_candidate>>8)
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0149
_ak820_outline_0149:
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0177
_ak820_outline_0177:
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0195
_ak820_outline_0195:
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	ret
