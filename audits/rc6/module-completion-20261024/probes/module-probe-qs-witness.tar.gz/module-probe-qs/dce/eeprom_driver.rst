                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006D2                         85 _eeprom_read_word_addr_10000_91:
      0006D2                         86 	.ds 3
      0006D5                         87 _eeprom_read_word_ret_10000_92:
      0006D5                         88 	.ds 2
      0006D7                         89 _eeprom_read_dword_addr_10000_93:
      0006D7                         90 	.ds 3
      0006DA                         91 _eeprom_read_dword_ret_10000_94:
      0006DA                         92 	.ds 4
      0006DE                         93 _eeprom_write_byte_PARM_2:
      0006DE                         94 	.ds 1
      0006DF                         95 _eeprom_write_byte_addr_10000_95:
      0006DF                         96 	.ds 3
      0006E2                         97 _eeprom_write_word_PARM_2:
      0006E2                         98 	.ds 2
      0006E4                         99 _eeprom_write_word_addr_10000_97:
      0006E4                        100 	.ds 3
      0006E7                        101 _eeprom_write_dword_PARM_2:
      0006E7                        102 	.ds 4
      0006EB                        103 _eeprom_write_dword_addr_10000_99:
      0006EB                        104 	.ds 3
      0006EE                        105 _eeprom_update_byte_PARM_2:
      0006EE                        106 	.ds 1
      0006EF                        107 _eeprom_update_byte_addr_10000_107:
      0006EF                        108 	.ds 3
      0006F2                        109 _eeprom_update_word_PARM_2:
      0006F2                        110 	.ds 2
      0006F4                        111 _eeprom_update_word_addr_10000_111:
      0006F4                        112 	.ds 3
      0006F7                        113 _eeprom_update_dword_PARM_2:
      0006F7                        114 	.ds 4
      0006FB                        115 _eeprom_update_dword_addr_10000_115:
      0006FB                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      00537E                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      00537E 12 43 1B         [24]  170 	lcall	_ak820_outline_0038
      005381 90 06 D2         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005384 12 38 26         [24]  172 	lcall	_ak820_outline_0018
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005387 90 06 D5         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00538A 12 49 BF         [24]  175 	lcall	_ak820_outline_0177
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      00538D 90 06 D2         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005390 12 49 34         [24]  178 	lcall	_ak820_outline_0013
      005393 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005396 ED               [12]  180 	mov	a,r5
      005397 12 38 26         [24]  181 	lcall	_ak820_outline_0018
      00539A 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00539D 12 55 6D         [24]  183 	lcall	_ak820_outline_0116
      0053A0 90 06 D5         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0053A3 12 40 B7         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0053A6 90 06 D5         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0053A9 12 55 64         [24]  188 	lcall	_ak820_outline_0097
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0053AC 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0053AD                        201 _eeprom_read_dword:
      0053AD 12 43 1B         [24]  202 	lcall	_ak820_outline_0038
      0053B0 90 06 D7         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0053B3 12 38 26         [24]  204 	lcall	_ak820_outline_0018
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0053B6 90 06 DA         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0053B9 12 55 39         [24]  207 	lcall	_ak820_outline_0054
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0053BC 90 06 D7         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0053BF 12 49 34         [24]  210 	lcall	_ak820_outline_0013
      0053C2 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0053C5 ED               [12]  212 	mov	a,r5
      0053C6 12 38 26         [24]  213 	lcall	_ak820_outline_0018
      0053C9 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0053CC 74 04            [12]  215 	mov	a,#0x04
      0053CE 12 38 9B         [24]  216 	lcall	_ak820_outline_0131
      0053D1 90 06 DA         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0053D4 12 40 B7         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0053D7 90 06 DA         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0053DA 12 55 42         [24]  221 	lcall	_ak820_outline_0058
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0053DD 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0053DE                        234 _eeprom_write_byte:
      0053DE 12 43 1B         [24]  235 	lcall	_ak820_outline_0038
      0053E1 90 06 DF         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0053E4 12 38 26         [24]  237 	lcall	_ak820_outline_0018
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0053E7 90 06 DF         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0053EA 12 55 22         [24]  240 	lcall	_ak820_outline_0004
      0053ED 74 01            [12]  241 	mov	a,#0x01
      0053EF 12 38 9B         [24]  242 	lcall	_ak820_outline_0131
      0053F2 90 06 DE         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      0053F5 02 41 43         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      0053F8                        256 _eeprom_write_word:
      0053F8 12 43 1B         [24]  257 	lcall	_ak820_outline_0038
      0053FB 90 06 E4         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0053FE 12 38 26         [24]  259 	lcall	_ak820_outline_0018
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005401 90 06 E4         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005404 12 55 22         [24]  262 	lcall	_ak820_outline_0004
      005407 12 55 6D         [24]  263 	lcall	_ak820_outline_0116
      00540A 90 06 E2         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00540D 02 41 43         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005410                        277 _eeprom_write_dword:
      005410 12 43 1B         [24]  278 	lcall	_ak820_outline_0038
      005413 90 06 EB         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005416 12 38 26         [24]  280 	lcall	_ak820_outline_0018
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005419 90 06 EB         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00541C 12 55 22         [24]  283 	lcall	_ak820_outline_0004
      00541F 74 04            [12]  284 	mov	a,#0x04
      005421 12 38 9B         [24]  285 	lcall	_ak820_outline_0131
      005424 90 06 E7         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005427 02 41 43         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00542A                        307 _eeprom_update_byte:
      00542A C0 07            [24]  308 	push	ar7
      00542C C0 06            [24]  309 	push	ar6
      00542E C0 05            [24]  310 	push	ar5
      005430 C0 04            [24]  311 	push	ar4
      005432 12 43 1B         [24]  312 	lcall	_ak820_outline_0038
      005435 90 06 EF         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005438 12 38 26         [24]  314 	lcall	_ak820_outline_0018
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00543B 90 06 EF         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00543E 12 55 13         [24]  317 	lcall	_ak820_outline_0001
      005441 12 40 7C         [24]  318 	lcall	_eeprom_read_byte
      005444 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005446 90 06 EE         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005449 E0               [24]  322 	movx	a,@dptr
      00544A FE               [12]  323 	mov	r6,a
      00544B EF               [12]  324 	mov	a,r7
      00544C B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00544F 80 35            [24]  326 	sjmp	00103$
      005451                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005451 90 06 EF         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005454 12 38 55         [24]  330 	lcall	_ak820_outline_0063
      005457 A3               [24]  331 	inc	dptr
      005458 E0               [24]  332 	movx	a,@dptr
      005459 FF               [12]  333 	mov	r7,a
      00545A 90 06 DE         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00545D EE               [12]  335 	mov	a,r6
      00545E 12 38 95         [24]  336 	lcall	_ak820_outline_0129
      005461 8F F0            [24]  337 	mov	b, r7
      005463 C0 07            [24]  338 	push	ar7
      005465 C0 06            [24]  339 	push	ar6
      005467 C0 05            [24]  340 	push	ar5
      005469 C0 04            [24]  341 	push	ar4
      00546B C0 03            [24]  342 	push	ar3
      00546D C0 02            [24]  343 	push	ar2
      00546F C0 01            [24]  344 	push	ar1
      005471 C0 00            [24]  345 	push	ar0
      005473 12 53 DE         [24]  346 	lcall	_eeprom_write_byte
      005476 D0 00            [24]  347 	pop	ar0
      005478 D0 01            [24]  348 	pop	ar1
      00547A D0 02            [24]  349 	pop	ar2
      00547C D0 03            [24]  350 	pop	ar3
      00547E D0 04            [24]  351 	pop	ar4
      005480 D0 05            [24]  352 	pop	ar5
      005482 D0 06            [24]  353 	pop	ar6
      005484 D0 07            [24]  354 	pop	ar7
      005486                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      005486 D0 04            [24]  357 	pop	ar4
      005488 D0 05            [24]  358 	pop	ar5
      00548A D0 06            [24]  359 	pop	ar6
      00548C D0 07            [24]  360 	pop	ar7
      00548E 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      00548F                        373 _eeprom_update_word:
      00548F 12 43 1B         [24]  374 	lcall	_ak820_outline_0038
      005492 90 06 F4         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005495 12 38 26         [24]  376 	lcall	_ak820_outline_0018
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005498 90 06 F4         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00549B 12 55 13         [24]  379 	lcall	_ak820_outline_0001
      00549E 12 53 7E         [24]  380 	lcall	_eeprom_read_word
      0054A1 12 43 64         [24]  381 	lcall	_ak820_outline_0132
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0054A4 90 06 F2         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      0054A7 12 38 55         [24]  384 	lcall	_ak820_outline_0063
      0054AA EE               [12]  385 	mov	a,r6
      0054AB B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0054AE EF               [12]  387 	mov	a,r7
      0054AF B5 05 01         [24]  388 	cjne	a,ar5,00112$
      0054B2 22               [24]  389 	ret
      0054B3                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0054B3 90 06 F4         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0054B6 E0               [24]  393 	movx	a,@dptr
      0054B7 FB               [12]  394 	mov	r3,a
      0054B8 A3               [24]  395 	inc	dptr
      0054B9 12 38 3E         [24]  396 	lcall	_ak820_outline_0055
      0054BC 90 06 E2         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0054BF 12 38 61         [24]  398 	lcall	_ak820_outline_0078
      0054C2 8B 82            [24]  399 	mov	dpl, r3
      0054C4 8E 83            [24]  400 	mov	dph, r6
      0054C6 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0054C8 02 53 F8         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0054CB                        415 _eeprom_update_dword:
      0054CB 12 43 1B         [24]  416 	lcall	_ak820_outline_0038
      0054CE 90 06 FB         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0054D1 12 38 26         [24]  418 	lcall	_ak820_outline_0018
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0054D4 90 06 FB         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0054D7 12 55 13         [24]  421 	lcall	_ak820_outline_0001
      0054DA 12 53 AD         [24]  422 	lcall	_eeprom_read_dword
      0054DD 12 55 53         [24]  423 	lcall	_ak820_outline_0060
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0054E0 90 06 F7         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      0054E3 E0               [24]  426 	movx	a,@dptr
      0054E4 F8               [12]  427 	mov	r0,a
      0054E5 A3               [24]  428 	inc	dptr
      0054E6 12 55 5B         [24]  429 	lcall	_ak820_outline_0096
      0054E9 EC               [12]  430 	mov	a,r4
      0054EA B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0054ED ED               [12]  432 	mov	a,r5
      0054EE B5 01 09         [24]  433 	cjne	a,ar1,00112$
      0054F1 EE               [12]  434 	mov	a,r6
      0054F2 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      0054F5 EF               [12]  436 	mov	a,r7
      0054F6 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      0054F9 22               [24]  438 	ret
      0054FA                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0054FA 90 06 FB         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0054FD 12 49 34         [24]  442 	lcall	_ak820_outline_0013
      005500 90 06 E7         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005503 E8               [12]  444 	mov	a,r0
      005504 F0               [24]  445 	movx	@dptr,a
      005505 E9               [12]  446 	mov	a,r1
      005506 A3               [24]  447 	inc	dptr
      005507 F0               [24]  448 	movx	@dptr,a
      005508 EA               [12]  449 	mov	a,r2
      005509 A3               [24]  450 	inc	dptr
      00550A F0               [24]  451 	movx	@dptr,a
      00550B EB               [12]  452 	mov	a,r3
      00550C A3               [24]  453 	inc	dptr
      00550D 12 49 59         [24]  454 	lcall	_ak820_outline_0033
                                    455 ;	drivers/eeprom/eeprom_driver.c:101: }
      005510 02 54 10         [24]  456 	ljmp	_eeprom_write_dword
                                    457 	.area CSEG    (CODE)
                                    458 	.area CONST   (CODE)
                                    459 	.area XINIT   (CODE)
                                    460 	.area CABS    (ABS,CODE)
                                    461 
                                    462 ; Experimental exact instruction outlining.
                                    463 	.globl _ak820_outline_0001
                                    464 	.globl _ak820_outline_0004
                                    465 	.globl _ak820_outline_0013
                                    466 	.globl _ak820_outline_0018
                                    467 	.globl _ak820_outline_0033
                                    468 	.globl _ak820_outline_0038
                                    469 	.globl _ak820_outline_0054
                                    470 	.globl _ak820_outline_0055
                                    471 	.globl _ak820_outline_0058
                                    472 	.globl _ak820_outline_0060
                                    473 	.globl _ak820_outline_0063
                                    474 	.globl _ak820_outline_0078
                                    475 	.globl _ak820_outline_0096
                                    476 	.globl _ak820_outline_0097
                                    477 	.globl _ak820_outline_0116
                                    478 	.globl _ak820_outline_0129
                                    479 	.globl _ak820_outline_0131
                                    480 	.globl _ak820_outline_0132
                                    481 	.globl _ak820_outline_0177
                                    482 
                                    483 	.area CSEG (CODE)
                                    484 ; function ak820_outline_0001
      005513                        485 _ak820_outline_0001:
      005513 E0               [24]  486 	movx	a,@dptr
      005514 FD               [12]  487 	mov	r5,a
      005515 A3               [24]  488 	inc	dptr
      005516 E0               [24]  489 	movx	a,@dptr
      005517 FE               [12]  490 	mov	r6,a
      005518 A3               [24]  491 	inc	dptr
      005519 E0               [24]  492 	movx	a,@dptr
      00551A FF               [12]  493 	mov	r7,a
      00551B 8D 82            [24]  494 	mov	dpl,r5
      00551D 8E 83            [24]  495 	mov	dph,r6
      00551F 8F F0            [24]  496 	mov	b,r7
      005521 22               [24]  497 	ret
                                    498 
                                    499 	.area CSEG (CODE)
                                    500 ; function ak820_outline_0004
      005522                        501 _ak820_outline_0004:
      005522 E0               [24]  502 	movx	a,@dptr
      005523 FD               [12]  503 	mov	r5,a
      005524 A3               [24]  504 	inc	dptr
      005525 E0               [24]  505 	movx	a,@dptr
      005526 FE               [12]  506 	mov	r6,a
      005527 A3               [24]  507 	inc	dptr
      005528 E0               [24]  508 	movx	a,@dptr
      005529 FF               [12]  509 	mov	r7,a
      00552A 90 05 8E         [24]  510 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00552D ED               [12]  511 	mov	a,r5
      00552E F0               [24]  512 	movx	@dptr,a
      00552F EE               [12]  513 	mov	a,r6
      005530 A3               [24]  514 	inc	dptr
      005531 F0               [24]  515 	movx	@dptr,a
      005532 EF               [12]  516 	mov	a,r7
      005533 A3               [24]  517 	inc	dptr
      005534 F0               [24]  518 	movx	@dptr,a
      005535 90 05 91         [24]  519 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005538 22               [24]  520 	ret
                                    521 
                                    522 	.area CSEG (CODE)
                                    523 ; function ak820_outline_0054
      005539                        524 _ak820_outline_0054:
      005539 E4               [12]  525 	clr	a
      00553A F0               [24]  526 	movx	@dptr,a
      00553B A3               [24]  527 	inc	dptr
      00553C F0               [24]  528 	movx	@dptr,a
      00553D A3               [24]  529 	inc	dptr
      00553E F0               [24]  530 	movx	@dptr,a
      00553F A3               [24]  531 	inc	dptr
      005540 F0               [24]  532 	movx	@dptr,a
      005541 22               [24]  533 	ret
                                    534 
                                    535 	.area CSEG (CODE)
                                    536 ; function ak820_outline_0058
      005542                        537 _ak820_outline_0058:
      005542 E0               [24]  538 	movx	a,@dptr
      005543 FC               [12]  539 	mov	r4,a
      005544 A3               [24]  540 	inc	dptr
      005545 E0               [24]  541 	movx	a,@dptr
      005546 FD               [12]  542 	mov	r5,a
      005547 A3               [24]  543 	inc	dptr
      005548 E0               [24]  544 	movx	a,@dptr
      005549 FE               [12]  545 	mov	r6,a
      00554A A3               [24]  546 	inc	dptr
      00554B E0               [24]  547 	movx	a,@dptr
      00554C 8C 82            [24]  548 	mov	dpl,r4
      00554E 8D 83            [24]  549 	mov	dph,r5
      005550 8E F0            [24]  550 	mov	b,r6
      005552 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0060
      005553                        555 _ak820_outline_0060:
      005553 AC 82            [24]  556 	mov	r4,dpl
      005555 AD 83            [24]  557 	mov	r5,dph
      005557 AE F0            [24]  558 	mov	r6,b
      005559 FF               [12]  559 	mov	r7,a
      00555A 22               [24]  560 	ret
                                    561 
                                    562 	.area CSEG (CODE)
                                    563 ; function ak820_outline_0096
      00555B                        564 _ak820_outline_0096:
      00555B E0               [24]  565 	movx	a,@dptr
      00555C F9               [12]  566 	mov	r1,a
      00555D A3               [24]  567 	inc	dptr
      00555E E0               [24]  568 	movx	a,@dptr
      00555F FA               [12]  569 	mov	r2,a
      005560 A3               [24]  570 	inc	dptr
      005561 E0               [24]  571 	movx	a,@dptr
      005562 FB               [12]  572 	mov	r3,a
      005563 22               [24]  573 	ret
                                    574 
                                    575 	.area CSEG (CODE)
                                    576 ; function ak820_outline_0097
      005564                        577 _ak820_outline_0097:
      005564 E0               [24]  578 	movx	a,@dptr
      005565 FE               [12]  579 	mov	r6,a
      005566 A3               [24]  580 	inc	dptr
      005567 E0               [24]  581 	movx	a,@dptr
      005568 8E 82            [24]  582 	mov	dpl,r6
      00556A F5 83            [12]  583 	mov	dph,a
      00556C 22               [24]  584 	ret
                                    585 
                                    586 	.area CSEG (CODE)
                                    587 ; function ak820_outline_0116
      00556D                        588 _ak820_outline_0116:
      00556D 74 02            [12]  589 	mov	a,#0x02
      00556F F0               [24]  590 	movx	@dptr,a
      005570 E4               [12]  591 	clr	a
      005571 A3               [24]  592 	inc	dptr
      005572 F0               [24]  593 	movx	@dptr,a
      005573 22               [24]  594 	ret
