                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_tap_code_delay
                                     12 	.globl _ak820_settings_reset
                                     13 	.globl _ak820_settings_set
                                     14 	.globl _ak820_settings_get
                                     15 	.globl _ak820_settings_query
                                     16 	.globl _ak820_settings_init
                                     17 	.globl _unregister_code16
                                     18 	.globl _register_code16
                                     19 	.globl _matrix_is_on
                                     20 	.globl _dynamic_keymap_set_combo
                                     21 	.globl _dynamic_keymap_get_combo
                                     22 	.globl _dynamic_keymap_set_encoder
                                     23 	.globl _dynamic_keymap_get_encoder
                                     24 	.globl _repeat_key_cancel
                                     25 	.globl _ak820_combo_reload
                                     26 	.globl _clear_keyboard
                                     27 	.globl _ak820_action_exec
                                     28 	.globl _timer_elapsed32
                                     29 	.globl _timer_read32
                                     30 	.globl _timer_read
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _ADC_START
                                     34 	.globl _S0_R_FIFO
                                     35 	.globl _S0_T_FIFO
                                     36 	.globl _S0_FREE
                                     37 	.globl _S0_IF_BYTE
                                     38 	.globl _S0_IF_FIRST
                                     39 	.globl _S0_IF_OV
                                     40 	.globl _S0_FST_ACT
                                     41 	.globl _CP_RL2
                                     42 	.globl _C_T2
                                     43 	.globl _TR2
                                     44 	.globl _EXEN2
                                     45 	.globl _TCLK
                                     46 	.globl _RCLK
                                     47 	.globl _EXF2
                                     48 	.globl _CAP1F
                                     49 	.globl _TF2
                                     50 	.globl _RI
                                     51 	.globl _TI
                                     52 	.globl _RB8
                                     53 	.globl _TB8
                                     54 	.globl _REN
                                     55 	.globl _SM2
                                     56 	.globl _SM1
                                     57 	.globl _SM0
                                     58 	.globl _IT0
                                     59 	.globl _IE0
                                     60 	.globl _IT1
                                     61 	.globl _IE1
                                     62 	.globl _TR0
                                     63 	.globl _TF0
                                     64 	.globl _TR1
                                     65 	.globl _TF1
                                     66 	.globl _P4_0
                                     67 	.globl _P4_1
                                     68 	.globl _P4_2
                                     69 	.globl _P4_3
                                     70 	.globl _P4_4
                                     71 	.globl _P4_5
                                     72 	.globl _P4_6
                                     73 	.globl _RXD
                                     74 	.globl _TXD
                                     75 	.globl _INT0
                                     76 	.globl _INT1
                                     77 	.globl _T0
                                     78 	.globl _T1
                                     79 	.globl _MOSI1
                                     80 	.globl _MISO1
                                     81 	.globl _SCK1
                                     82 	.globl _P3_0
                                     83 	.globl _P3_1
                                     84 	.globl _P3_2
                                     85 	.globl _P3_3
                                     86 	.globl _P3_4
                                     87 	.globl _P3_5
                                     88 	.globl _P3_6
                                     89 	.globl _P3_7
                                     90 	.globl _CAP1_
                                     91 	.globl _T2_
                                     92 	.globl _CAP2_
                                     93 	.globl _T2EX_
                                     94 	.globl _RXD1
                                     95 	.globl _TXD1
                                     96 	.globl _P2_0
                                     97 	.globl _P2_1
                                     98 	.globl _P2_2
                                     99 	.globl _P2_3
                                    100 	.globl _P2_4
                                    101 	.globl _P2_5
                                    102 	.globl _P2_6
                                    103 	.globl _P2_7
                                    104 	.globl _AIN0
                                    105 	.globl _AIN1
                                    106 	.globl _AIN2
                                    107 	.globl _AIN3
                                    108 	.globl _AIN4
                                    109 	.globl _AIN5
                                    110 	.globl _AIN6
                                    111 	.globl _AIN7
                                    112 	.globl _CAP1
                                    113 	.globl _T2
                                    114 	.globl _CAP2
                                    115 	.globl _T2EX
                                    116 	.globl _INT0_
                                    117 	.globl _SCS
                                    118 	.globl _MOSI
                                    119 	.globl _MISO
                                    120 	.globl _SCK
                                    121 	.globl _RXD1_
                                    122 	.globl _TXD1_
                                    123 	.globl _P1_0
                                    124 	.globl _P1_1
                                    125 	.globl _P1_2
                                    126 	.globl _P1_3
                                    127 	.globl _P1_4
                                    128 	.globl _P1_5
                                    129 	.globl _P1_6
                                    130 	.globl _P1_7
                                    131 	.globl _AIN8
                                    132 	.globl _AIN9
                                    133 	.globl _AIN10
                                    134 	.globl _AIN11
                                    135 	.globl _AIN12
                                    136 	.globl _AIN13
                                    137 	.globl _RXD_
                                    138 	.globl _TXD_
                                    139 	.globl _SCL0
                                    140 	.globl _SDA0
                                    141 	.globl _P0_0
                                    142 	.globl _P0_1
                                    143 	.globl _P0_2
                                    144 	.globl _P0_3
                                    145 	.globl _P0_4
                                    146 	.globl _P0_5
                                    147 	.globl _P0_6
                                    148 	.globl _P0_7
                                    149 	.globl _IE_SPI0
                                    150 	.globl _IE_USB
                                    151 	.globl _IE_ADC
                                    152 	.globl _IE_UART1
                                    153 	.globl _IE_PWM_I2C
                                    154 	.globl _IE_GPIO
                                    155 	.globl _IE_WDOG
                                    156 	.globl _PX0
                                    157 	.globl _PT0
                                    158 	.globl _PX1
                                    159 	.globl _PT1
                                    160 	.globl _PS
                                    161 	.globl _PT2
                                    162 	.globl _PL_FLAG
                                    163 	.globl _PH_FLAG
                                    164 	.globl _EX0
                                    165 	.globl _ET0
                                    166 	.globl _EX1
                                    167 	.globl _ET1
                                    168 	.globl _ES
                                    169 	.globl _ET2
                                    170 	.globl _E_DIS
                                    171 	.globl _EA
                                    172 	.globl _P
                                    173 	.globl _F1
                                    174 	.globl _OV
                                    175 	.globl _RS0
                                    176 	.globl _RS1
                                    177 	.globl _F0
                                    178 	.globl _AC
                                    179 	.globl _CY
                                    180 	.globl _I2CS_INT_ST
                                    181 	.globl _I2CX_INT
                                    182 	.globl _LED_STATUS
                                    183 	.globl _LED_DMA_H
                                    184 	.globl _LED_DMA_L
                                    185 	.globl _LED_DMA
                                    186 	.globl _LED_PWM_OE
                                    187 	.globl _LED_COMMON
                                    188 	.globl _ADC_CHAN
                                    189 	.globl _ADC_DAT_H
                                    190 	.globl _ADC_DAT_L
                                    191 	.globl _ADC_DAT
                                    192 	.globl _ADC_CTRL
                                    193 	.globl _SPI1_CK_SE
                                    194 	.globl _SPI1_CTRL
                                    195 	.globl _SPI1_DATA
                                    196 	.globl _SPI1_STAT
                                    197 	.globl _SIF1
                                    198 	.globl _SBAUD1
                                    199 	.globl _SBUF1
                                    200 	.globl _SCON1
                                    201 	.globl _SPI0_SETUP
                                    202 	.globl _SPI0_CK_SE
                                    203 	.globl _SPI0_CTRL
                                    204 	.globl _SPI0_DATA
                                    205 	.globl _SPI0_STAT
                                    206 	.globl _T2CAP1H
                                    207 	.globl _T2CAP1L
                                    208 	.globl _T2CAP1
                                    209 	.globl _TH2
                                    210 	.globl _TL2
                                    211 	.globl _T2COUNT
                                    212 	.globl _RCAP2H
                                    213 	.globl _RCAP2L
                                    214 	.globl _RCAP2
                                    215 	.globl _T2MOD
                                    216 	.globl _T2CON
                                    217 	.globl _SBUF
                                    218 	.globl _SCON
                                    219 	.globl _TH1
                                    220 	.globl _TH0
                                    221 	.globl _TL1
                                    222 	.globl _TL0
                                    223 	.globl _TMOD
                                    224 	.globl _TCON
                                    225 	.globl _XBUS_AUX
                                    226 	.globl _P7
                                    227 	.globl _P6_DIR
                                    228 	.globl _P6_OUT_PU
                                    229 	.globl _P6_IN
                                    230 	.globl _P5_DIR
                                    231 	.globl _P5_OUT_PU
                                    232 	.globl _P5_IN
                                    233 	.globl _P4_LED_KEY
                                    234 	.globl _P4_DIR_PU
                                    235 	.globl _P4_MOD_OC
                                    236 	.globl _P4
                                    237 	.globl _P3_DIR_PU
                                    238 	.globl _P3_MOD_OC
                                    239 	.globl _P3
                                    240 	.globl _P2_DIR_PU
                                    241 	.globl _P2_MOD_OC
                                    242 	.globl _P2
                                    243 	.globl _P1_DIR_PU
                                    244 	.globl _P1_MOD_OC
                                    245 	.globl _P1
                                    246 	.globl _P0_DIR_PU
                                    247 	.globl _P0_MOD_OC
                                    248 	.globl _P0
                                    249 	.globl _ROM_CTRL
                                    250 	.globl _ROM_DATA_HH
                                    251 	.globl _ROM_DATA_HL
                                    252 	.globl _ROM_DATA_HI
                                    253 	.globl _ROM_ADDR_H
                                    254 	.globl _ROM_ADDR_L
                                    255 	.globl _ROM_ADDR
                                    256 	.globl _GPIO_IE
                                    257 	.globl _IP_EX
                                    258 	.globl _IE_EX
                                    259 	.globl _IP
                                    260 	.globl _IE
                                    261 	.globl _WDOG_COUNT
                                    262 	.globl _RESET_KEEP
                                    263 	.globl _WAKE_CTRL
                                    264 	.globl _CLOCK_CFG
                                    265 	.globl _POWER_CFG
                                    266 	.globl _PCON
                                    267 	.globl _GLOBAL_CFG
                                    268 	.globl _SAFE_MOD
                                    269 	.globl _DPH
                                    270 	.globl _DPL
                                    271 	.globl _SP
                                    272 	.globl _A_INV
                                    273 	.globl _B
                                    274 	.globl _ACC
                                    275 	.globl _PSW
                                    276 	.globl _vial_unlock_in_progress
                                    277 	.globl _vial_unlocked
                                    278 	.globl _g_vial_magic_keycode_override
                                    279 	.globl _vial_handle_cmd_PARM_2
                                    280 	.globl _vial_unlock_task
                                    281 	.globl _vial_init
                                    282 	.globl _vial_handle_cmd
                                    283 	.globl _vial_keycode_down
                                    284 	.globl _vial_keycode_up
                                    285 	.globl _vial_keycode_tap
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000049                        548 _vial_handle_cmd_sloc0_1_0:
      000049                        549 	.ds 2
      00004B                        550 _vial_handle_cmd_sloc1_1_0:
      00004B                        551 	.ds 2
      00004D                        552 _vial_handle_cmd_sloc2_1_0:
      00004D                        553 	.ds 2
      00004F                        554 _vial_handle_cmd_sloc3_1_0:
      00004F                        555 	.ds 2
                                    556 ;--------------------------------------------------------
                                    557 ; overlayable items in internal ram
                                    558 ;--------------------------------------------------------
                                    559 ;--------------------------------------------------------
                                    560 ; indirectly addressable internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area ISEG    (DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; absolute internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area IABS    (ABS,DATA)
                                    567 	.area IABS    (ABS,DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; bit data
                                    570 ;--------------------------------------------------------
                                    571 	.area BSEG    (BIT)
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000CA7                        580 _vial_unlock_timer:
      000CA7                        581 	.ds 4
      000CAB                        582 _vial_unlock_holding:
      000CAB                        583 	.ds 1
      000CAC                        584 _vial_keycode_firewall_in_10000_633:
      000CAC                        585 	.ds 2
      000CAE                        586 _vial_fill_packet_PARM_2:
      000CAE                        587 	.ds 1
      000CAF                        588 _vial_fill_packet_msg_10000_636:
      000CAF                        589 	.ds 2
      000CB1                        590 _vial_handle_cmd_PARM_2:
      000CB1                        591 	.ds 1
      000CB2                        592 _vial_handle_cmd_data_10000_641:
      000CB2                        593 	.ds 3
      000CB5                        594 _vial_handle_cmd_entry_70000_672:
      000CB5                        595 	.ds 10
      000CBF                        596 _vial_handle_cmd_entry_70000_673:
      000CBF                        597 	.ds 10
      000CC9                        598 _g_vial_magic_keycode_override::
      000CC9                        599 	.ds 2
      000CCB                        600 _vial_keycode_down_keycode_10000_675:
      000CCB                        601 	.ds 2
      000CCD                        602 _vial_keycode_down_dummy_event_30000_682:
      000CCD                        603 	.ds 6
      000CD3                        604 _vial_keycode_up_keycode_10000_683:
      000CD3                        605 	.ds 2
      000CD5                        606 _vial_keycode_up_dummy_event_30000_690:
      000CD5                        607 	.ds 6
      000CDB                        608 _vial_keycode_tap_keycode_10000_691:
      000CDB                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
      000E79                        618 _vial_unlocked::
      000E79                        619 	.ds 1
      000E7A                        620 _vial_unlock_in_progress::
      000E7A                        621 	.ds 1
      000E7B                        622 _vial_unlock_counter:
      000E7B                        623 	.ds 1
      000E7C                        624 _vial_unlock_combo_rows:
      000E7C                        625 	.ds 2
      000E7E                        626 _vial_unlock_combo_cols:
      000E7E                        627 	.ds 2
                                    628 	.area HOME    (CODE)
                                    629 	.area GSINIT0 (CODE)
                                    630 	.area GSINIT1 (CODE)
                                    631 	.area GSINIT2 (CODE)
                                    632 	.area GSINIT3 (CODE)
                                    633 	.area GSINIT4 (CODE)
                                    634 	.area GSINIT5 (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area CSEG    (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; global & static initialisations
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area GSINIT  (CODE)
                                    643 	.area GSFINAL (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 ;--------------------------------------------------------
                                    646 ; Home
                                    647 ;--------------------------------------------------------
                                    648 	.area HOME    (CODE)
                                    649 	.area HOME    (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; code
                                    652 ;--------------------------------------------------------
                                    653 	.area CSEG    (CODE)
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    656 ;------------------------------------------------------------
                                    657 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    658 ;------------------------------------------------------------
                                    659 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    660 ;	-----------------------------------------
                           000007   661 	ar7 = 0x07
                           000006   662 	ar6 = 0x06
                           000005   663 	ar5 = 0x05
                           000004   664 	ar4 = 0x04
                           000003   665 	ar3 = 0x03
                           000002   666 	ar2 = 0x02
                           000001   667 	ar1 = 0x01
                           000000   668 	ar0 = 0x00
                                    669 ;	 function vial_unlock_task
                                    670 ;	-----------------------------------------
      00B201                        671 _vial_unlock_task:
                                    672 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B201 90 0E 7A         [24]  673 	mov	dptr,#_vial_unlock_in_progress
      00B204 E0               [24]  674 	movx	a,@dptr
      00B205 70 01            [24]  675 	jnz	00131$
      00B207 22               [24]  676 	ret
                                    677 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B208                        678 00131$:
      00B208 7F 00            [12]  679 	mov	r7,#0x00
      00B20A                        680 00115$:
      00B20A BF 02 00         [24]  681 	cjne	r7,#0x02,00184$
      00B20D                        682 00184$:
      00B20D 50 29            [24]  683 	jnc	00105$
                                    684 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B20F EF               [12]  685 	mov	a,r7
      00B210 12 B8 CF         [24]  686 	lcall	_ak820_outline_0136
      00B213 FE               [12]  687 	mov	r6,a
      00B214 EF               [12]  688 	mov	a,r7
      00B215 12 B8 C4         [24]  689 	lcall	_ak820_outline_0135
      00B218 90 07 B2         [24]  690 	mov	dptr,#_matrix_is_on_PARM_2
      00B21B F0               [24]  691 	movx	@dptr,a
      00B21C 8E 82            [24]  692 	mov	dpl, r6
      00B21E C0 07            [24]  693 	push	ar7
      00B220 12 5F 46         [24]  694 	lcall	_matrix_is_on
      00B223 E5 82            [12]  695 	mov	a, dpl
      00B225 D0 07            [24]  696 	pop	ar7
      00B227 70 0C            [24]  697 	jnz	00116$
                                    698 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B229 90 0C AB         [24]  699 	mov	dptr,#_vial_unlock_holding
      00B22C E4               [12]  700 	clr	a
      00B22D F0               [24]  701 	movx	@dptr,a
                                    702 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B22E 90 0E 7B         [24]  703 	mov	dptr,#_vial_unlock_counter
      00B231 74 1E            [12]  704 	mov	a,#0x1e
      00B233 F0               [24]  705 	movx	@dptr,a
                                    706 ;	quantum/vial.c:69: return;
      00B234 22               [24]  707 	ret
      00B235                        708 00116$:
                                    709 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B235 0F               [12]  710 	inc	r7
      00B236 80 D2            [24]  711 	sjmp	00115$
      00B238                        712 00105$:
                                    713 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B238 90 0C AB         [24]  714 	mov	dptr,#_vial_unlock_holding
      00B23B E0               [24]  715 	movx	a,@dptr
      00B23C 70 12            [24]  716 	jnz	00107$
                                    717 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B23E 90 0C AB         [24]  718 	mov	dptr,#_vial_unlock_holding
      00B241 74 01            [12]  719 	mov	a,#0x01
      00B243 F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B244 12 4F 52         [24]  722 	lcall	_timer_read32
      00B247 12 55 53         [24]  723 	lcall	_ak820_outline_0060
      00B24A 90 0C A7         [24]  724 	mov	dptr,#_vial_unlock_timer
      00B24D 12 95 6B         [24]  725 	lcall	_ak820_outline_0006
      00B250                        726 00107$:
                                    727 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B250 90 0C A7         [24]  728 	mov	dptr,#_vial_unlock_timer
      00B253 12 55 42         [24]  729 	lcall	_ak820_outline_0058
      00B256 12 4F AB         [24]  730 	lcall	_timer_elapsed32
      00B259 12 55 53         [24]  731 	lcall	_ak820_outline_0060
                                    732 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B25C 7B 1E            [12]  733 	mov	r3,#0x1e
      00B25E                        734 00109$:
      00B25E EB               [12]  735 	mov	a,r3
      00B25F 60 22            [24]  736 	jz	00111$
      00B261 C3               [12]  737 	clr	c
      00B262 EC               [12]  738 	mov	a,r4
      00B263 94 64            [12]  739 	subb	a,#0x64
      00B265 ED               [12]  740 	mov	a,r5
      00B266 94 00            [12]  741 	subb	a,#0x00
      00B268 EE               [12]  742 	mov	a,r6
      00B269 94 00            [12]  743 	subb	a,#0x00
      00B26B EF               [12]  744 	mov	a,r7
      00B26C 94 00            [12]  745 	subb	a,#0x00
      00B26E 40 13            [24]  746 	jc	00111$
                                    747 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B270 EC               [12]  748 	mov	a,r4
      00B271 24 9C            [12]  749 	add	a,#0x9c
      00B273 FC               [12]  750 	mov	r4,a
      00B274 ED               [12]  751 	mov	a,r5
      00B275 34 FF            [12]  752 	addc	a,#0xff
      00B277 FD               [12]  753 	mov	r5,a
      00B278 EE               [12]  754 	mov	a,r6
      00B279 34 FF            [12]  755 	addc	a,#0xff
      00B27B FE               [12]  756 	mov	r6,a
      00B27C EF               [12]  757 	mov	a,r7
      00B27D 34 FF            [12]  758 	addc	a,#0xff
      00B27F FF               [12]  759 	mov	r7,a
                                    760 ;	quantum/vial.c:82: --counter;
      00B280 1B               [12]  761 	dec	r3
      00B281 80 DB            [24]  762 	sjmp	00109$
      00B283                        763 00111$:
                                    764 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B283 90 0E 7B         [24]  765 	mov	dptr,#_vial_unlock_counter
      00B286 EB               [12]  766 	mov	a,r3
      00B287 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:85: if (!counter) {
      00B288 EB               [12]  769 	mov	a,r3
      00B289 70 0A            [24]  770 	jnz	00117$
                                    771 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B28B 90 0E 7A         [24]  772 	mov	dptr,#_vial_unlock_in_progress
      00B28E E4               [12]  773 	clr	a
      00B28F F0               [24]  774 	movx	@dptr,a
                                    775 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B290 90 0E 79         [24]  776 	mov	dptr,#_vial_unlocked
      00B293 04               [12]  777 	inc	a
      00B294 F0               [24]  778 	movx	@dptr,a
      00B295                        779 00117$:
                                    780 ;	quantum/vial.c:90: }
      00B295 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'vial_init'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/vial.c:117: void vial_init(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function vial_init
                                    788 ;	-----------------------------------------
      00B296                        789 _vial_init:
                                    790 ;	quantum/vial.c:119: ak820_settings_init();
      00B296 12 45 ED         [24]  791 	lcall	_ak820_settings_init
                                    792 ;	quantum/vial.c:125: reload_combo();
                                    793 ;	quantum/vial.c:130: }
      00B299 02 35 7C         [24]  794 	ljmp	_ak820_combo_reload
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    797 ;------------------------------------------------------------
                                    798 ;in            Allocated with name '_vial_keycode_firewall_in_10000_633'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function vial_keycode_firewall
                                    803 ;	-----------------------------------------
      00B29C                        804 _vial_keycode_firewall:
      00B29C 12 38 79         [24]  805 	lcall	_ak820_outline_0113
      00B29F 90 0C AC         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_633
      00B2A2 12 38 7E         [24]  807 	lcall	_ak820_outline_0114
                                    808 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B2A5 90 0C AC         [24]  809 	mov	dptr,#_vial_keycode_firewall_in_10000_633
      00B2A8 12 4E 82         [24]  810 	lcall	_ak820_outline_0009
      00B2AB BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00B2AE BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00B2B1 90 0E 79         [24]  813 	mov	dptr,#_vial_unlocked
      00B2B4 E0               [24]  814 	movx	a,@dptr
      00B2B5 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:134: return 0;
      00B2B7 90 00 00         [24]  817 	mov	dptr,#0x0000
      00B2BA 22               [24]  818 	ret
      00B2BB                        819 00102$:
                                    820 ;	quantum/vial.c:135: return in;
      00B2BB 12 38 8A         [24]  821 	lcall	_ak820_outline_0124
                                    822 ;	quantum/vial.c:136: }
      00B2BE 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_636'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_638'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00B2BF                        835 _vial_fill_packet:
      00B2BF 12 38 79         [24]  836 	lcall	_ak820_outline_0113
      00B2C2 90 0C AF         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_636
      00B2C5 12 38 7E         [24]  838 	lcall	_ak820_outline_0114
                                    839 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B2C8 90 0C AF         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_636
      00B2CB 12 38 3E         [24]  841 	lcall	_ak820_outline_0055
      00B2CE 90 0C AE         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00B2D1 E0               [24]  843 	movx	a,@dptr
      00B2D2 FD               [12]  844 	mov	r5,a
      00B2D3 7C 00            [12]  845 	mov	r4,#0x00
      00B2D5                        846 00103$:
      00B2D5 BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00B2D8                        848 00122$:
      00B2D8 50 09            [24]  849 	jnc	00105$
      00B2DA EC               [12]  850 	mov	a,r4
      00B2DB 12 38 2E         [24]  851 	lcall	_ak820_outline_0024
      00B2DE ED               [12]  852 	mov	a,r5
      00B2DF F0               [24]  853 	movx	@dptr,a
      00B2E0 0C               [12]  854 	inc	r4
      00B2E1 80 F2            [24]  855 	sjmp	00103$
      00B2E3                        856 00105$:
                                    857 ;	quantum/vial.c:141: }
      00B2E3 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00B2E4                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:174: repeat_key_cancel();
      00B2E4 12 A6 EF         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:176: clear_keyboard();
                                    870 ;	quantum/vial.c:177: }
      00B2E7 02 7C 52         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_641'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_642'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_647'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_648'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_651'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_653'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_653'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_653'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_654'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_655'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_655'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_655'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_658'
                                    893 ;qsid_greater_than Allocated with name '_vial_handle_cmd_qsid_greater_than_40000_664'
                                    894 ;qsid          Allocated with name '_vial_handle_cmd_qsid_40000_665'
                                    895 ;qsid          Allocated with name '_vial_handle_cmd_qsid_40000_666'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_672'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_672'
                                    898 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_673'
                                    899 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_673'
                                    900 ;------------------------------------------------------------
                                    901 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    902 ;	-----------------------------------------
                                    903 ;	 function vial_handle_cmd
                                    904 ;	-----------------------------------------
      00B2EA                        905 _vial_handle_cmd:
      00B2EA 12 43 1B         [24]  906 	lcall	_ak820_outline_0038
      00B2ED 90 0C B2         [24]  907 	mov	dptr,#_vial_handle_cmd_data_10000_641
      00B2F0 12 38 26         [24]  908 	lcall	_ak820_outline_0018
                                    909 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B2F3 90 0C B2         [24]  910 	mov	dptr,#_vial_handle_cmd_data_10000_641
      00B2F6 12 38 3E         [24]  911 	lcall	_ak820_outline_0055
                                    912 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B2F9 90 0C B1         [24]  913 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B2FC E0               [24]  914 	movx	a,@dptr
      00B2FD FD               [12]  915 	mov	r5,a
      00B2FE BD 20 02         [24]  916 	cjne	r5,#0x20,00261$
      00B301 80 01            [24]  917 	sjmp	00102$
      00B303                        918 00261$:
                                    919 ;	quantum/vial.c:190: return;
      00B303 22               [24]  920 	ret
      00B304                        921 00102$:
                                    922 ;	quantum/vial.c:193: switch (msg[1]) {
      00B304 74 01            [12]  923 	mov	a,#0x01
      00B306 12 4E 8C         [24]  924 	lcall	_ak820_outline_0012
      00B309 FA               [12]  925 	mov  r2,a
      00B30A 24 F2            [12]  926 	add	a,#0xff - 0x0d
      00B30C 50 01            [24]  927 	jnc	00262$
      00B30E 22               [24]  928 	ret
      00B30F                        929 00262$:
                                    930 ;	free result
      00B30F EA               [12]  931 	mov	a,r2
      00B310 24 0A            [12]  932 	add	a,#(00263$-3-.)
      00B312 83               [24]  933 	movc	a,@a+pc
      00B313 F5 82            [12]  934 	mov	dpl,a
      00B315 EA               [12]  935 	mov	a,r2
      00B316 24 12            [12]  936 	add	a,#(00264$-3-.)
      00B318 83               [24]  937 	movc	a,@a+pc
      00B319 F5 83            [12]  938 	mov	dph,a
      00B31B E4               [12]  939 	clr	a
      00B31C 73               [24]  940 	jmp	@a+dptr
      00B31D                        941 00263$:
      00B31D 39                     942 	.db	00103$
      00B31E 82                     943 	.db	00105$
      00B31F 96                     944 	.db	00106$
      00B320 4D                     945 	.db	00112$
      00B321 C6                     946 	.db	00113$
      00B322 13                     947 	.db	00114$
      00B323 86                     948 	.db	00116$
      00B324 A1                     949 	.db	00119$
      00B325 C0                     950 	.db	00120$
      00B326 CE                     951 	.db	00121$
      00B327 F3                     952 	.db	00122$
      00B328 38                     953 	.db	00123$
      00B329 85                     954 	.db	00124$
      00B32A 98                     955 	.db	00125$
      00B32B                        956 00264$:
      00B32B B3                     957 	.db	00103$>>8
      00B32C B3                     958 	.db	00105$>>8
      00B32D B3                     959 	.db	00106$>>8
      00B32E B4                     960 	.db	00112$>>8
      00B32F B4                     961 	.db	00113$>>8
      00B330 B5                     962 	.db	00114$>>8
      00B331 B5                     963 	.db	00116$>>8
      00B332 B5                     964 	.db	00119$>>8
      00B333 B5                     965 	.db	00120$>>8
      00B334 B5                     966 	.db	00121$>>8
      00B335 B5                     967 	.db	00122$>>8
      00B336 B6                     968 	.db	00123$>>8
      00B337 B6                     969 	.db	00124$>>8
      00B338 B6                     970 	.db	00125$>>8
                                    971 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B339                        972 00103$:
                                    973 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B339 90 0C AE         [24]  974 	mov	dptr,#_vial_fill_packet_PARM_2
      00B33C E4               [12]  975 	clr	a
      00B33D 12 43 46         [24]  976 	lcall	_ak820_outline_0077
      00B340 C0 07            [24]  977 	push	ar7
      00B342 C0 06            [24]  978 	push	ar6
      00B344 12 B2 BF         [24]  979 	lcall	_vial_fill_packet
      00B347 D0 06            [24]  980 	pop	ar6
      00B349 D0 07            [24]  981 	pop	ar7
                                    982 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B34B 12 38 8A         [24]  983 	lcall	_ak820_outline_0124
      00B34E 74 06            [12]  984 	mov	a,#0x06
      00B350 12 43 46         [24]  985 	lcall	_ak820_outline_0077
                                    986 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B353 A3               [24]  987 	inc	dptr
      00B354 E4               [12]  988 	clr	a
      00B355 12 43 13         [24]  989 	lcall	_ak820_outline_0034
                                    990 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B358 12 43 13         [24]  991 	lcall	_ak820_outline_0034
                                    992 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B35B A3               [24]  993 	inc	dptr
      00B35C F0               [24]  994 	movx	@dptr,a
                                    995 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B35D FA               [12]  996 	mov	r2,a
      00B35E                        997 00134$:
      00B35E BA 08 00         [24]  998 	cjne	r2,#0x08,00265$
      00B361                        999 00265$:
      00B361 50 16            [24] 1000 	jnc	00104$
      00B363 8A 01            [24] 1001 	mov	ar1,r2
      00B365 74 04            [12] 1002 	mov	a,#0x04
      00B367 29               [12] 1003 	add	a, r1
      00B368 2E               [12] 1004 	add	a, r6
      00B369 F8               [12] 1005 	mov	r0,a
      00B36A E4               [12] 1006 	clr	a
      00B36B 3F               [12] 1007 	addc	a,r7
      00B36C F9               [12] 1008 	mov	r1,a
      00B36D EA               [12] 1009 	mov	a,r2
      00B36E 90 C6 58         [24] 1010 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_646
      00B371 93               [24] 1011 	movc	a,@a+dptr
      00B372 12 38 BF         [24] 1012 	lcall	_ak820_outline_0160
      00B375 F0               [24] 1013 	movx	@dptr,a
      00B376 0A               [12] 1014 	inc	r2
      00B377 80 E5            [24] 1015 	sjmp	00134$
      00B379                       1016 00104$:
                                   1017 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B379 74 0C            [12] 1018 	mov	a,#0x0c
      00B37B 12 38 2E         [24] 1019 	lcall	_ak820_outline_0024
      00B37E 74 01            [12] 1020 	mov	a,#0x01
      00B380 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	quantum/vial.c:207: break;
      00B381 22               [24] 1023 	ret
                                   1024 ;	quantum/vial.c:210: case vial_get_size: {
      00B382                       1025 00105$:
                                   1026 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B382 12 38 8A         [24] 1027 	lcall	_ak820_outline_0124
      00B385 74 7C            [12] 1028 	mov	a,#0x7c
      00B387 12 A2 E2         [24] 1029 	lcall	_ak820_outline_0106
                                   1030 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B38A 74 01            [12] 1031 	mov	a,#0x01
      00B38C 12 43 13         [24] 1032 	lcall	_ak820_outline_0034
                                   1033 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B38F E4               [12] 1034 	clr	a
      00B390 12 43 13         [24] 1035 	lcall	_ak820_outline_0034
                                   1036 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B393 A3               [24] 1037 	inc	dptr
      00B394 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	quantum/vial.c:216: break;
      00B395 22               [24] 1040 	ret
                                   1041 ;	quantum/vial.c:219: case vial_get_def: {
      00B396                       1042 00106$:
                                   1043 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B396 12 B1 CC         [24] 1044 	lcall	_ak820_outline_0025
      00B399 E0               [24] 1045 	movx	a,@dptr
      00B39A FA               [12] 1046 	mov	r2,a
      00B39B 12 43 09         [24] 1047 	lcall	_ak820_outline_0014
      00B39E E0               [24] 1048 	movx	a,@dptr
      00B39F 4A               [12] 1049 	orl	a,r2
      00B3A0 60 01            [24] 1050 	jz	00108$
      00B3A2 22               [24] 1051 	ret
      00B3A3                       1052 00108$:
                                   1053 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B3A3 12 38 36         [24] 1054 	lcall	_ak820_outline_0037
      00B3A6 F9               [12] 1055 	mov	r1,a
      00B3A7 7A 00            [12] 1056 	mov	r2,#0x00
      00B3A9 12 B1 C3         [24] 1057 	lcall	_ak820_outline_0019
      00B3AC F8               [12] 1058 	mov	r0,a
      00B3AD C0 06            [24] 1059 	push	ar6
      00B3AF C0 07            [24] 1060 	push	ar7
      00B3B1 88 07            [24] 1061 	mov	ar7,r0
      00B3B3 E4               [12] 1062 	clr	a
      00B3B4 49               [12] 1063 	orl	a,r1
      00B3B5 F5 49            [12] 1064 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B3B7 EF               [12] 1065 	mov	a,r7
      00B3B8 4A               [12] 1066 	orl	a,r2
      00B3B9 F5 4A            [12] 1067 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),a
                                   1068 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B3BB C3               [12] 1069 	clr	c
      00B3BC E5 49            [12] 1070 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B3BE 94 0C            [12] 1071 	subb	a,#0x0c
      00B3C0 E5 4A            [12] 1072 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B3C2 94 00            [12] 1073 	subb	a,#0x00
      00B3C4 D0 07            [24] 1074 	pop	ar7
      00B3C6 D0 06            [24] 1075 	pop	ar6
      00B3C8 40 01            [24] 1076 	jc	00110$
      00B3CA 22               [24] 1077 	ret
      00B3CB                       1078 00110$:
                                   1079 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B3CB C0 06            [24] 1080 	push	ar6
      00B3CD C0 07            [24] 1081 	push	ar7
      00B3CF A9 49            [24] 1082 	mov	r1,_vial_handle_cmd_sloc0_1_0
      00B3D1 E5 4A            [12] 1083 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B3D3 C4               [12] 1084 	swap	a
      00B3D4 23               [12] 1085 	rl	a
      00B3D5 54 E0            [12] 1086 	anl	a,#0xe0
      00B3D7 C9               [12] 1087 	xch	a,r1
      00B3D8 C4               [12] 1088 	swap	a
      00B3D9 23               [12] 1089 	rl	a
      00B3DA C9               [12] 1090 	xch	a,r1
      00B3DB 69               [12] 1091 	xrl	a,r1
      00B3DC C9               [12] 1092 	xch	a,r1
      00B3DD 54 E0            [12] 1093 	anl	a,#0xe0
      00B3DF C9               [12] 1094 	xch	a,r1
      00B3E0 69               [12] 1095 	xrl	a,r1
      00B3E1 FA               [12] 1096 	mov	r2,a
      00B3E2 89 4B            [24] 1097 	mov	_vial_handle_cmd_sloc1_1_0,r1
      00B3E4 8A 4C            [24] 1098 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),r2
                                   1099 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B3E6 74 7C            [12] 1100 	mov	a,#0x7c
      00B3E8 C3               [12] 1101 	clr	c
      00B3E9 95 4B            [12] 1102 	subb	a,_vial_handle_cmd_sloc1_1_0
      00B3EB F8               [12] 1103 	mov	r0,a
      00B3EC 74 01            [12] 1104 	mov	a,#0x01
      00B3EE 95 4C            [12] 1105 	subb	a,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3F0 FF               [12] 1106 	mov	r7,a
                                   1107 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B3F1 88 49            [24] 1108 	mov	_vial_handle_cmd_sloc0_1_0,r0
      00B3F3 8F 4A            [24] 1109 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r7
      00B3F5 C3               [12] 1110 	clr	c
      00B3F6 E5 49            [12] 1111 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B3F8 94 20            [12] 1112 	subb	a,#0x20
      00B3FA E5 4A            [12] 1113 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B3FC 94 00            [12] 1114 	subb	a,#0x00
      00B3FE D0 07            [24] 1115 	pop	ar7
      00B400 D0 06            [24] 1116 	pop	ar6
      00B402 50 04            [24] 1117 	jnc	00144$
      00B404 A8 49            [24] 1118 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B406 80 02            [24] 1119 	sjmp	00145$
      00B408                       1120 00144$:
      00B408 78 20            [12] 1121 	mov	r0,#0x20
      00B40A                       1122 00145$:
                                   1123 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B40A 75 49 00         [24] 1124 	mov	_vial_handle_cmd_sloc0_1_0,#0x00
      00B40D                       1125 00137$:
      00B40D C3               [12] 1126 	clr	c
      00B40E E5 49            [12] 1127 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B410 98               [12] 1128 	subb	a,r0
      00B411 40 01            [24] 1129 	jc	00270$
      00B413 22               [24] 1130 	ret
      00B414                       1131 00270$:
      00B414 C0 00            [24] 1132 	push	ar0
      00B416 E5 49            [12] 1133 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B418 2E               [12] 1134 	add	a, r6
      00B419 F5 4D            [12] 1135 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B41B E4               [12] 1136 	clr	a
      00B41C 3F               [12] 1137 	addc	a, r7
      00B41D F5 4E            [12] 1138 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B41F 85 49 4F         [24] 1139 	mov	_vial_handle_cmd_sloc3_1_0,_vial_handle_cmd_sloc0_1_0
      00B422 75 50 00         [24] 1140 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),#0x00
      00B425 A8 4B            [24] 1141 	mov	r0,_vial_handle_cmd_sloc1_1_0
      00B427 AA 4C            [24] 1142 	mov	r2,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B429 E5 4F            [12] 1143 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B42B 28               [12] 1144 	add	a, r0
      00B42C F8               [12] 1145 	mov	r0,a
      00B42D E5 50            [12] 1146 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B42F 3A               [12] 1147 	addc	a, r2
      00B430 FA               [12] 1148 	mov	r2,a
      00B431 E8               [12] 1149 	mov	a,r0
      00B432 24 DC            [12] 1150 	add	a, #_keyboard_definition
      00B434 F5 82            [12] 1151 	mov	dpl,a
      00B436 EA               [12] 1152 	mov	a,r2
      00B437 34 C4            [12] 1153 	addc	a, #(_keyboard_definition >> 8)
      00B439 F5 83            [12] 1154 	mov	dph,a
      00B43B E4               [12] 1155 	clr	a
      00B43C 93               [24] 1156 	movc	a,@a+dptr
      00B43D 85 4D 82         [24] 1157 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B440 85 4E 83         [24] 1158 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B443 F0               [24] 1159 	movx	@dptr,a
      00B444 E5 49            [12] 1160 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B446 04               [12] 1161 	inc	a
      00B447 F5 49            [12] 1162 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B449 D0 00            [24] 1163 	pop	ar0
                                   1164 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B44B 80 C0            [24] 1165 	sjmp	00137$
      00B44D                       1166 00112$:
                                   1167 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B44D 74 02            [12] 1168 	mov	a,#0x02
      00B44F 2E               [12] 1169 	add	a, r6
      00B450 F5 4D            [12] 1170 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B452 E4               [12] 1171 	clr	a
      00B453 3F               [12] 1172 	addc	a, r7
      00B454 F5 4E            [12] 1173 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B456 85 4D 82         [24] 1174 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B459 85 4E 83         [24] 1175 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B45C E0               [24] 1176 	movx	a,@dptr
      00B45D F5 4F            [12] 1177 	mov	_vial_handle_cmd_sloc3_1_0,a
                                   1178 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B45F 74 03            [12] 1179 	mov	a,#0x03
      00B461 2E               [12] 1180 	add	a, r6
      00B462 F5 49            [12] 1181 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B464 E4               [12] 1182 	clr	a
      00B465 3F               [12] 1183 	addc	a, r7
      00B466 F5 4A            [12] 1184 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),a
      00B468 85 49 82         [24] 1185 	mov	dpl,_vial_handle_cmd_sloc0_1_0
      00B46B 85 4A 83         [24] 1186 	mov	dph,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B46E E0               [24] 1187 	movx	a,@dptr
                                   1188 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B46F F5 4B            [12] 1189 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B471 90 0B 35         [24] 1190 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B474 F0               [24] 1191 	movx	@dptr,a
      00B475 90 0B 36         [24] 1192 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B478 E4               [12] 1193 	clr	a
      00B479 F0               [24] 1194 	movx	@dptr,a
      00B47A 85 4F 82         [24] 1195 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B47D C0 07            [24] 1196 	push	ar7
      00B47F C0 06            [24] 1197 	push	ar6
      00B481 C0 04            [24] 1198 	push	ar4
      00B483 C0 03            [24] 1199 	push	ar3
      00B485 12 8A 1B         [24] 1200 	lcall	_dynamic_keymap_get_encoder
      00B488 12 4F 08         [24] 1201 	lcall	_ak820_outline_0194
      00B48B D0 03            [24] 1202 	pop	ar3
      00B48D D0 04            [24] 1203 	pop	ar4
      00B48F D0 06            [24] 1204 	pop	ar6
      00B491 D0 07            [24] 1205 	pop	ar7
                                   1206 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B493 8A 00            [24] 1207 	mov	ar0,r2
      00B495 12 38 8A         [24] 1208 	lcall	_ak820_outline_0124
      00B498 E8               [12] 1209 	mov	a,r0
      00B499 12 A2 E2         [24] 1210 	lcall	_ak820_outline_0106
                                   1211 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B49C E9               [12] 1212 	mov	a,r1
      00B49D F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B49E 90 0B 35         [24] 1215 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B4A1 E5 4B            [12] 1216 	mov	a,_vial_handle_cmd_sloc1_1_0
      00B4A3 F0               [24] 1217 	movx	@dptr,a
      00B4A4 90 0B 36         [24] 1218 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B4A7 74 01            [12] 1219 	mov	a,#0x01
      00B4A9 F0               [24] 1220 	movx	@dptr,a
      00B4AA 85 4F 82         [24] 1221 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B4AD 12 8A 1B         [24] 1222 	lcall	_dynamic_keymap_get_encoder
      00B4B0 12 4F 08         [24] 1223 	lcall	_ak820_outline_0194
                                   1224 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B4B3 8A 00            [24] 1225 	mov	ar0,r2
      00B4B5 85 4D 82         [24] 1226 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B4B8 85 4E 83         [24] 1227 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B4BB E8               [12] 1228 	mov	a,r0
      00B4BC F0               [24] 1229 	movx	@dptr,a
                                   1230 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B4BD 85 49 82         [24] 1231 	mov	dpl,_vial_handle_cmd_sloc0_1_0
      00B4C0 85 4A 83         [24] 1232 	mov	dph,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B4C3 E9               [12] 1233 	mov	a,r1
      00B4C4 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vial.c:255: break;
      00B4C5 22               [24] 1236 	ret
                                   1237 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B4C6                       1238 00113$:
                                   1239 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B4C6 12 38 36         [24] 1240 	lcall	_ak820_outline_0037
      00B4C9 F5 4B            [12] 1241 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B4CB 12 B1 C3         [24] 1242 	lcall	_ak820_outline_0019
      00B4CE F5 4D            [12] 1243 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B4D0 12 B1 CC         [24] 1244 	lcall	_ak820_outline_0025
      00B4D3 E0               [24] 1245 	movx	a,@dptr
                                   1246 ;	assignBit
      00B4D4 24 FF            [12] 1247 	add	a,#0xff
      00B4D6 E4               [12] 1248 	clr	a
      00B4D7 33               [12] 1249 	rlc	a
      00B4D8 F5 4F            [12] 1250 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B4DA 12 43 09         [24] 1251 	lcall	_ak820_outline_0014
      00B4DD E0               [24] 1252 	movx	a,@dptr
      00B4DE F8               [12] 1253 	mov	r0,a
      00B4DF 79 00            [12] 1254 	mov	r1,#0x00
      00B4E1 88 4A            [24] 1255 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r0
      00B4E3 89 49            [24] 1256 	mov	_vial_handle_cmd_sloc0_1_0,r1
      00B4E5 74 06            [12] 1257 	mov	a,#0x06
      00B4E7 12 38 2E         [24] 1258 	lcall	_ak820_outline_0024
      00B4EA E0               [24] 1259 	movx	a,@dptr
      00B4EB F9               [12] 1260 	mov	r1,a
      00B4EC 7A 00            [12] 1261 	mov	r2,#0x00
      00B4EE E5 4A            [12] 1262 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B4F0 42 02            [12] 1263 	orl	ar2,a
      00B4F2 12 43 86         [24] 1264 	lcall	_ak820_outline_0178
      00B4F5 12 B2 9C         [24] 1265 	lcall	_vial_keycode_firewall
      00B4F8 12 4F 08         [24] 1266 	lcall	_ak820_outline_0194
      00B4FB 90 0B 38         [24] 1267 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B4FE E5 4D            [12] 1268 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B500 F0               [24] 1269 	movx	@dptr,a
      00B501 90 0B 39         [24] 1270 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B504 E5 4F            [12] 1271 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B506 F0               [24] 1272 	movx	@dptr,a
      00B507 90 0B 3A         [24] 1273 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B50A 12 4E FB         [24] 1274 	lcall	_ak820_outline_0145
      00B50D 85 4B 82         [24] 1275 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1276 ;	quantum/vial.c:259: break;
      00B510 02 8A 82         [24] 1277 	ljmp	_dynamic_keymap_set_encoder
                                   1278 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B513                       1279 00114$:
                                   1280 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B513 90 0C AE         [24] 1281 	mov	dptr,#_vial_fill_packet_PARM_2
      00B516 74 FF            [12] 1282 	mov	a,#0xff
      00B518 12 43 46         [24] 1283 	lcall	_ak820_outline_0077
      00B51B C0 07            [24] 1284 	push	ar7
      00B51D C0 06            [24] 1285 	push	ar6
      00B51F 12 B2 BF         [24] 1286 	lcall	_vial_fill_packet
      00B522 D0 06            [24] 1287 	pop	ar6
      00B524 D0 07            [24] 1288 	pop	ar7
                                   1289 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B526 90 0E 79         [24] 1290 	mov	dptr,#_vial_unlocked
      00B529 E0               [24] 1291 	movx	a,@dptr
      00B52A 12 38 8A         [24] 1292 	lcall	_ak820_outline_0124
      00B52D F0               [24] 1293 	movx	@dptr,a
                                   1294 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B52E 74 01            [12] 1295 	mov	a,#0x01
      00B530 2E               [12] 1296 	add	a, r6
      00B531 F9               [12] 1297 	mov	r1,a
      00B532 E4               [12] 1298 	clr	a
      00B533 3F               [12] 1299 	addc	a, r7
      00B534 FA               [12] 1300 	mov	r2,a
      00B535 90 0E 7A         [24] 1301 	mov	dptr,#_vial_unlock_in_progress
      00B538 E0               [24] 1302 	movx	a,@dptr
      00B539 12 72 37         [24] 1303 	lcall	_ak820_outline_0147
                                   1304 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B53C 7A 00            [12] 1305 	mov	r2,#0x00
      00B53E                       1306 00140$:
      00B53E BA 02 00         [24] 1307 	cjne	r2,#0x02,00271$
      00B541                       1308 00271$:
      00B541 40 01            [24] 1309 	jc	00272$
      00B543 22               [24] 1310 	ret
      00B544                       1311 00272$:
                                   1312 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B544 8A 00            [24] 1313 	mov	ar0,r2
      00B546 79 00            [12] 1314 	mov	r1,#0x00
      00B548 E8               [12] 1315 	mov	a,r0
      00B549 28               [12] 1316 	add	a,r0
      00B54A F5 4F            [12] 1317 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B54C E9               [12] 1318 	mov	a,r1
      00B54D 33               [12] 1319 	rlc	a
      00B54E F5 50            [12] 1320 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B550 74 02            [12] 1321 	mov	a,#0x02
      00B552 25 4F            [12] 1322 	add	a, _vial_handle_cmd_sloc3_1_0
      00B554 F8               [12] 1323 	mov	r0,a
      00B555 E4               [12] 1324 	clr	a
      00B556 35 50            [12] 1325 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B558 F9               [12] 1326 	mov	r1,a
      00B559 E8               [12] 1327 	mov	a,r0
      00B55A 2E               [12] 1328 	add	a, r6
      00B55B F5 4D            [12] 1329 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B55D E9               [12] 1330 	mov	a,r1
      00B55E 3F               [12] 1331 	addc	a, r7
      00B55F F5 4E            [12] 1332 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B561 EA               [12] 1333 	mov	a,r2
      00B562 12 B8 CF         [24] 1334 	lcall	_ak820_outline_0136
      00B565 85 4D 82         [24] 1335 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B568 85 4E 83         [24] 1336 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B56B F0               [24] 1337 	movx	@dptr,a
                                   1338 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B56C 74 03            [12] 1339 	mov	a,#0x03
      00B56E 25 4F            [12] 1340 	add	a, _vial_handle_cmd_sloc3_1_0
      00B570 F8               [12] 1341 	mov	r0,a
      00B571 E4               [12] 1342 	clr	a
      00B572 35 50            [12] 1343 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B574 F9               [12] 1344 	mov	r1,a
      00B575 E8               [12] 1345 	mov	a,r0
      00B576 2E               [12] 1346 	add	a, r6
      00B577 F8               [12] 1347 	mov	r0,a
      00B578 E9               [12] 1348 	mov	a,r1
      00B579 3F               [12] 1349 	addc	a, r7
      00B57A F9               [12] 1350 	mov	r1,a
      00B57B EA               [12] 1351 	mov	a,r2
      00B57C 12 B8 C4         [24] 1352 	lcall	_ak820_outline_0135
      00B57F 12 38 BF         [24] 1353 	lcall	_ak820_outline_0160
      00B582 F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B583 0A               [12] 1356 	inc	r2
                                   1357 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B584 80 B8            [24] 1358 	sjmp	00140$
      00B586                       1359 00116$:
                                   1360 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B586 90 0E 7A         [24] 1361 	mov	dptr,#_vial_unlock_in_progress
      00B589 E0               [24] 1362 	movx	a,@dptr
      00B58A 70 03            [24] 1363 	jnz	00118$
      00B58C 12 B2 E4         [24] 1364 	lcall	_vial_release_held_state
      00B58F                       1365 00118$:
                                   1366 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B58F 90 0E 7A         [24] 1367 	mov	dptr,#_vial_unlock_in_progress
      00B592 74 01            [12] 1368 	mov	a,#0x01
      00B594 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B595 90 0E 7B         [24] 1371 	mov	dptr,#_vial_unlock_counter
      00B598 74 1E            [12] 1372 	mov	a,#0x1e
      00B59A F0               [24] 1373 	movx	@dptr,a
                                   1374 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B59B 90 0C AB         [24] 1375 	mov	dptr,#_vial_unlock_holding
      00B59E E4               [12] 1376 	clr	a
      00B59F F0               [24] 1377 	movx	@dptr,a
                                   1378 ;	quantum/vial.c:287: break;
      00B5A0 22               [24] 1379 	ret
                                   1380 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B5A1                       1381 00119$:
                                   1382 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B5A1 90 0E 79         [24] 1383 	mov	dptr,#_vial_unlocked
      00B5A4 E0               [24] 1384 	movx	a,@dptr
      00B5A5 12 38 8A         [24] 1385 	lcall	_ak820_outline_0124
      00B5A8 F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B5A9 90 0E 7A         [24] 1388 	mov	dptr,#_vial_unlock_in_progress
      00B5AC E0               [24] 1389 	movx	a,@dptr
      00B5AD 12 33 FC         [24] 1390 	lcall	_ak820_outline_0130
      00B5B0 F0               [24] 1391 	movx	@dptr,a
                                   1392 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B5B1 74 02            [12] 1393 	mov	a,#0x02
      00B5B3 2E               [12] 1394 	add	a, r6
      00B5B4 F9               [12] 1395 	mov	r1,a
      00B5B5 E4               [12] 1396 	clr	a
      00B5B6 3F               [12] 1397 	addc	a, r7
      00B5B7 FA               [12] 1398 	mov	r2,a
      00B5B8 90 0E 7B         [24] 1399 	mov	dptr,#_vial_unlock_counter
      00B5BB E0               [24] 1400 	movx	a,@dptr
      00B5BC 12 72 37         [24] 1401 	lcall	_ak820_outline_0147
                                   1402 ;	quantum/vial.c:293: break;
      00B5BF 22               [24] 1403 	ret
                                   1404 ;	quantum/vial.c:295: case vial_lock: {
      00B5C0                       1405 00120$:
                                   1406 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B5C0 90 0E 79         [24] 1407 	mov	dptr,#_vial_unlocked
      00B5C3 E4               [12] 1408 	clr	a
      00B5C4 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B5C5 90 0E 7A         [24] 1411 	mov	dptr,#_vial_unlock_in_progress
      00B5C8 F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B5C9 90 0C AB         [24] 1414 	mov	dptr,#_vial_unlock_holding
      00B5CC F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	quantum/vial.c:301: break;
      00B5CD 22               [24] 1417 	ret
                                   1418 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B5CE                       1419 00121$:
                                   1420 ;	quantum/vial.c:305: uint16_t qsid_greater_than = msg[2] | (msg[3] << 8);
      00B5CE 12 B8 97         [24] 1421 	lcall	_ak820_outline_0007
      00B5D1 88 50            [24] 1422 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B5D3 89 4F            [24] 1423 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B5D5 8A 01            [24] 1424 	mov	ar1,r2
      00B5D7 7A 00            [12] 1425 	mov	r2,#0x00
      00B5D9 E5 50            [12] 1426 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B5DB 42 02            [12] 1427 	orl	ar2,a
                                   1428 ;	quantum/vial.c:307: ak820_settings_query(qsid_greater_than, msg, length);
      00B5DD 90 05 DA         [24] 1429 	mov	dptr,#_ak820_settings_query_PARM_2
      00B5E0 12 4E D3         [24] 1430 	lcall	_ak820_outline_0062
      00B5E3 E4               [12] 1431 	clr	a
      00B5E4 A3               [24] 1432 	inc	dptr
      00B5E5 F0               [24] 1433 	movx	@dptr,a
      00B5E6 90 05 DD         [24] 1434 	mov	dptr,#_ak820_settings_query_PARM_3
      00B5E9 ED               [12] 1435 	mov	a,r5
      00B5EA 12 38 9B         [24] 1436 	lcall	_ak820_outline_0131
      00B5ED 12 43 86         [24] 1437 	lcall	_ak820_outline_0178
                                   1438 ;	quantum/vial.c:314: break;
      00B5F0 02 46 9F         [24] 1439 	ljmp	_ak820_settings_query
                                   1440 ;	quantum/vial.c:317: case vial_qmk_settings_get: {
      00B5F3                       1441 00122$:
                                   1442 ;	quantum/vial.c:318: uint16_t qsid = msg[2] | (msg[3] << 8);
      00B5F3 12 B8 97         [24] 1443 	lcall	_ak820_outline_0007
      00B5F6 88 50            [24] 1444 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B5F8 89 4F            [24] 1445 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B5FA 8A 01            [24] 1446 	mov	ar1,r2
      00B5FC 7A 00            [12] 1447 	mov	r2,#0x00
      00B5FE E5 50            [12] 1448 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B600 42 02            [12] 1449 	orl	ar2,a
      00B602 89 4F            [24] 1450 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B604 8A 50            [24] 1451 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r2
                                   1452 ;	quantum/vial.c:320: msg[0] = ak820_settings_get(qsid, &msg[1], length - 1);
      00B606 90 05 E3         [24] 1453 	mov	dptr,#_ak820_settings_get_PARM_2
      00B609 EB               [12] 1454 	mov	a,r3
      00B60A F0               [24] 1455 	movx	@dptr,a
      00B60B EC               [12] 1456 	mov	a,r4
      00B60C 12 38 5B         [24] 1457 	lcall	_ak820_outline_0070
      00B60F 8D 00            [24] 1458 	mov	ar0,r5
      00B611 FA               [12] 1459 	mov	r2,a
      00B612 18               [12] 1460 	dec	r0
      00B613 B8 FF 01         [24] 1461 	cjne	r0,#0xff,00274$
      00B616 1A               [12] 1462 	dec	r2
      00B617                       1463 00274$:
      00B617 90 05 E6         [24] 1464 	mov	dptr,#_ak820_settings_get_PARM_3
      00B61A E8               [12] 1465 	mov	a,r0
      00B61B F0               [24] 1466 	movx	@dptr,a
      00B61C EA               [12] 1467 	mov	a,r2
      00B61D A3               [24] 1468 	inc	dptr
      00B61E F0               [24] 1469 	movx	@dptr,a
      00B61F 85 4F 82         [24] 1470 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B622 85 50 83         [24] 1471 	mov	dph, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B625 C0 07            [24] 1472 	push	ar7
      00B627 C0 06            [24] 1473 	push	ar6
      00B629 12 47 BB         [24] 1474 	lcall	_ak820_settings_get
      00B62C A9 82            [24] 1475 	mov	r1, dpl
      00B62E D0 06            [24] 1476 	pop	ar6
      00B630 D0 07            [24] 1477 	pop	ar7
      00B632 12 38 8A         [24] 1478 	lcall	_ak820_outline_0124
      00B635 E9               [12] 1479 	mov	a,r1
      00B636 F0               [24] 1480 	movx	@dptr,a
                                   1481 ;	quantum/vial.c:325: break;
      00B637 22               [24] 1482 	ret
                                   1483 ;	quantum/vial.c:327: case vial_qmk_settings_set: {
      00B638                       1484 00123$:
                                   1485 ;	quantum/vial.c:328: uint16_t qsid = msg[2] | (msg[3] << 8);
      00B638 12 B8 97         [24] 1486 	lcall	_ak820_outline_0007
      00B63B 88 50            [24] 1487 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B63D 89 4F            [24] 1488 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B63F 8A 01            [24] 1489 	mov	ar1,r2
      00B641 7A 00            [12] 1490 	mov	r2,#0x00
      00B643 E5 50            [12] 1491 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B645 42 02            [12] 1492 	orl	ar2,a
      00B647 89 4F            [24] 1493 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B649 8A 50            [24] 1494 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r2
                                   1495 ;	quantum/vial.c:330: msg[0] = ak820_settings_set(qsid, &msg[4], length - 4);
      00B64B 74 04            [12] 1496 	mov	a,#0x04
      00B64D 2E               [12] 1497 	add	a, r6
      00B64E F8               [12] 1498 	mov	r0,a
      00B64F E4               [12] 1499 	clr	a
      00B650 3F               [12] 1500 	addc	a, r7
      00B651 FA               [12] 1501 	mov	r2,a
      00B652 90 05 EA         [24] 1502 	mov	dptr,#_ak820_settings_set_PARM_2
      00B655 E8               [12] 1503 	mov	a,r0
      00B656 F0               [24] 1504 	movx	@dptr,a
      00B657 EA               [12] 1505 	mov	a,r2
      00B658 12 38 5B         [24] 1506 	lcall	_ak820_outline_0070
      00B65B FA               [12] 1507 	mov	r2,a
      00B65C ED               [12] 1508 	mov	a,r5
      00B65D 24 FC            [12] 1509 	add	a,#0xfc
      00B65F FD               [12] 1510 	mov	r5,a
      00B660 EA               [12] 1511 	mov	a,r2
      00B661 34 FF            [12] 1512 	addc	a,#0xff
      00B663 FA               [12] 1513 	mov	r2,a
      00B664 90 05 ED         [24] 1514 	mov	dptr,#_ak820_settings_set_PARM_3
      00B667 ED               [12] 1515 	mov	a,r5
      00B668 F0               [24] 1516 	movx	@dptr,a
      00B669 EA               [12] 1517 	mov	a,r2
      00B66A A3               [24] 1518 	inc	dptr
      00B66B F0               [24] 1519 	movx	@dptr,a
      00B66C 85 4F 82         [24] 1520 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B66F 85 50 83         [24] 1521 	mov	dph, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B672 C0 07            [24] 1522 	push	ar7
      00B674 C0 06            [24] 1523 	push	ar6
      00B676 12 48 44         [24] 1524 	lcall	_ak820_settings_set
      00B679 AA 82            [24] 1525 	mov	r2, dpl
      00B67B D0 06            [24] 1526 	pop	ar6
      00B67D D0 07            [24] 1527 	pop	ar7
      00B67F 12 38 8A         [24] 1528 	lcall	_ak820_outline_0124
      00B682 EA               [12] 1529 	mov	a,r2
      00B683 F0               [24] 1530 	movx	@dptr,a
                                   1531 ;	quantum/vial.c:335: break;
      00B684 22               [24] 1532 	ret
                                   1533 ;	quantum/vial.c:337: case vial_qmk_settings_reset: {
      00B685                       1534 00124$:
                                   1535 ;	quantum/vial.c:339: msg[0] = ak820_settings_reset();
      00B685 C0 07            [24] 1536 	push	ar7
      00B687 C0 06            [24] 1537 	push	ar6
      00B689 12 49 0F         [24] 1538 	lcall	_ak820_settings_reset
      00B68C AA 82            [24] 1539 	mov	r2, dpl
      00B68E D0 06            [24] 1540 	pop	ar6
      00B690 D0 07            [24] 1541 	pop	ar7
      00B692 12 38 8A         [24] 1542 	lcall	_ak820_outline_0124
      00B695 EA               [12] 1543 	mov	a,r2
      00B696 F0               [24] 1544 	movx	@dptr,a
                                   1545 ;	quantum/vial.c:343: break;
      00B697 22               [24] 1546 	ret
                                   1547 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B698                       1548 00125$:
                                   1549 ;	quantum/vial.c:347: switch (msg[2]) {
      00B698 12 38 36         [24] 1550 	lcall	_ak820_outline_0037
      00B69B FD               [12] 1551 	mov	r5,a
      00B69C 60 0C            [24] 1552 	jz	00126$
      00B69E BD 03 02         [24] 1553 	cjne	r5,#0x03,00276$
      00B6A1 80 31            [24] 1554 	sjmp	00127$
      00B6A3                       1555 00276$:
      00B6A3 BD 04 03         [24] 1556 	cjne	r5,#0x04,00277$
      00B6A6 02 B7 38         [24] 1557 	ljmp	00128$
      00B6A9                       1558 00277$:
      00B6A9 22               [24] 1559 	ret
                                   1560 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B6AA                       1561 00126$:
                                   1562 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B6AA 90 0C AE         [24] 1563 	mov	dptr,#_vial_fill_packet_PARM_2
      00B6AD E4               [12] 1564 	clr	a
      00B6AE 12 43 46         [24] 1565 	lcall	_ak820_outline_0077
      00B6B1 C0 07            [24] 1566 	push	ar7
      00B6B3 C0 06            [24] 1567 	push	ar6
      00B6B5 12 B2 BF         [24] 1568 	lcall	_vial_fill_packet
      00B6B8 D0 06            [24] 1569 	pop	ar6
      00B6BA D0 07            [24] 1570 	pop	ar7
                                   1571 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B6BC 12 38 8A         [24] 1572 	lcall	_ak820_outline_0124
      00B6BF E4               [12] 1573 	clr	a
      00B6C0 12 43 46         [24] 1574 	lcall	_ak820_outline_0077
                                   1575 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B6C3 A3               [24] 1576 	inc	dptr
      00B6C4 74 08            [12] 1577 	mov	a,#0x08
      00B6C6 12 43 13         [24] 1578 	lcall	_ak820_outline_0034
                                   1579 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B6C9 E4               [12] 1580 	clr	a
      00B6CA F0               [24] 1581 	movx	@dptr,a
                                   1582 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B6CB 74 1F            [12] 1583 	mov	a,#0x1f
      00B6CD 12 38 2E         [24] 1584 	lcall	_ak820_outline_0024
      00B6D0 74 01            [12] 1585 	mov	a,#0x01
      00B6D2 F0               [24] 1586 	movx	@dptr,a
                                   1587 ;	quantum/vial.c:356: break;
      00B6D3 22               [24] 1588 	ret
                                   1589 ;	quantum/vial.c:380: case dynamic_vial_combo_get: {
      00B6D4                       1590 00127$:
                                   1591 ;	quantum/vial.c:381: uint8_t idx = msg[3];
      00B6D4 12 B1 C3         [24] 1592 	lcall	_ak820_outline_0019
      00B6D7 FD               [12] 1593 	mov	r5,a
                                   1594 ;	quantum/vial.c:382: vial_combo_entry_t entry = { { 0 }, 0 };
      00B6D8 90 0C B5         [24] 1595 	mov	dptr,#_vial_handle_cmd_entry_70000_672
      00B6DB 12 49 BF         [24] 1596 	lcall	_ak820_outline_0177
      00B6DE 90 0C B7         [24] 1597 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0002)
      00B6E1 F0               [24] 1598 	movx	@dptr,a
      00B6E2 A3               [24] 1599 	inc	dptr
      00B6E3 F0               [24] 1600 	movx	@dptr,a
      00B6E4 90 0C B9         [24] 1601 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0004)
      00B6E7 F0               [24] 1602 	movx	@dptr,a
      00B6E8 A3               [24] 1603 	inc	dptr
      00B6E9 F0               [24] 1604 	movx	@dptr,a
      00B6EA 90 0C BB         [24] 1605 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0006)
      00B6ED F0               [24] 1606 	movx	@dptr,a
      00B6EE A3               [24] 1607 	inc	dptr
      00B6EF F0               [24] 1608 	movx	@dptr,a
      00B6F0 90 0C BD         [24] 1609 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0008)
      00B6F3 F0               [24] 1610 	movx	@dptr,a
      00B6F4 A3               [24] 1611 	inc	dptr
      00B6F5 F0               [24] 1612 	movx	@dptr,a
                                   1613 ;	quantum/vial.c:383: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B6F6 90 0B 3D         [24] 1614 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B6F9 74 B5            [12] 1615 	mov	a,#_vial_handle_cmd_entry_70000_672
      00B6FB F0               [24] 1616 	movx	@dptr,a
      00B6FC 74 0C            [12] 1617 	mov	a,#(_vial_handle_cmd_entry_70000_672 >> 8)
      00B6FE 12 38 5B         [24] 1618 	lcall	_ak820_outline_0070
      00B701 8D 82            [24] 1619 	mov	dpl, r5
      00B703 C0 07            [24] 1620 	push	ar7
      00B705 C0 06            [24] 1621 	push	ar6
      00B707 C0 04            [24] 1622 	push	ar4
      00B709 C0 03            [24] 1623 	push	ar3
      00B70B 12 8A ED         [24] 1624 	lcall	_dynamic_keymap_get_combo
      00B70E AA 82            [24] 1625 	mov	r2, dpl
      00B710 D0 03            [24] 1626 	pop	ar3
      00B712 D0 04            [24] 1627 	pop	ar4
      00B714 D0 06            [24] 1628 	pop	ar6
      00B716 D0 07            [24] 1629 	pop	ar7
      00B718 12 38 8A         [24] 1630 	lcall	_ak820_outline_0124
      00B71B EA               [12] 1631 	mov	a,r2
      00B71C F0               [24] 1632 	movx	@dptr,a
                                   1633 ;	quantum/vial.c:384: memcpy(&msg[1], &entry, sizeof(entry));
      00B71D 7D 00            [12] 1634 	mov	r5,#0x00
      00B71F 90 0D F1         [24] 1635 	mov	dptr,#___memcpy_PARM_2
      00B722 74 B5            [12] 1636 	mov	a,#_vial_handle_cmd_entry_70000_672
      00B724 F0               [24] 1637 	movx	@dptr,a
      00B725 74 0C            [12] 1638 	mov	a,#(_vial_handle_cmd_entry_70000_672 >> 8)
      00B727 12 38 5B         [24] 1639 	lcall	_ak820_outline_0070
      00B72A 90 0D F4         [24] 1640 	mov	dptr,#___memcpy_PARM_3
      00B72D 12 93 8E         [24] 1641 	lcall	_ak820_outline_0081
      00B730 12 33 FC         [24] 1642 	lcall	_ak820_outline_0130
      00B733 8D F0            [24] 1643 	mov	b, r5
                                   1644 ;	quantum/vial.c:385: break;
      00B735 02 BE 74         [24] 1645 	ljmp	___memcpy
                                   1646 ;	quantum/vial.c:387: case dynamic_vial_combo_set: {
      00B738                       1647 00128$:
                                   1648 ;	quantum/vial.c:388: uint8_t idx = msg[3];
      00B738 12 B1 C3         [24] 1649 	lcall	_ak820_outline_0019
      00B73B FD               [12] 1650 	mov	r5,a
                                   1651 ;	quantum/vial.c:390: memcpy(&entry, &msg[4], sizeof(entry));
      00B73C 74 04            [12] 1652 	mov	a,#0x04
      00B73E 12 4E F5         [24] 1653 	lcall	_ak820_outline_0143
      00B741 90 0D F1         [24] 1654 	mov	dptr,#___memcpy_PARM_2
      00B744 EB               [12] 1655 	mov	a,r3
      00B745 F0               [24] 1656 	movx	@dptr,a
      00B746 EC               [12] 1657 	mov	a,r4
      00B747 12 38 5B         [24] 1658 	lcall	_ak820_outline_0070
      00B74A 90 0D F4         [24] 1659 	mov	dptr,#___memcpy_PARM_3
      00B74D 12 93 8E         [24] 1660 	lcall	_ak820_outline_0081
      00B750 90 0C BF         [24] 1661 	mov	dptr,#_vial_handle_cmd_entry_70000_673
      00B753 F5 F0            [12] 1662 	mov	b,a
      00B755 C0 07            [24] 1663 	push	ar7
      00B757 C0 06            [24] 1664 	push	ar6
      00B759 C0 05            [24] 1665 	push	ar5
      00B75B 12 BE 74         [24] 1666 	lcall	___memcpy
                                   1667 ;	quantum/vial.c:391: entry.output = vial_keycode_firewall(entry.output);
      00B75E 90 0C C7         [24] 1668 	mov	dptr,#(_vial_handle_cmd_entry_70000_673 + 0x0008)
      00B761 12 49 8C         [24] 1669 	lcall	_ak820_outline_0076
      00B764 12 B2 9C         [24] 1670 	lcall	_vial_keycode_firewall
      00B767 AB 82            [24] 1671 	mov	r3, dpl
      00B769 AC 83            [24] 1672 	mov	r4, dph
      00B76B D0 05            [24] 1673 	pop	ar5
      00B76D 90 0C C7         [24] 1674 	mov	dptr,#(_vial_handle_cmd_entry_70000_673 + 0x0008)
      00B770 12 38 6D         [24] 1675 	lcall	_ak820_outline_0099
                                   1676 ;	quantum/vial.c:392: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B773 90 0B 41         [24] 1677 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B776 74 BF            [12] 1678 	mov	a,#_vial_handle_cmd_entry_70000_673
      00B778 F0               [24] 1679 	movx	@dptr,a
      00B779 74 0C            [12] 1680 	mov	a,#(_vial_handle_cmd_entry_70000_673 >> 8)
      00B77B 12 38 5B         [24] 1681 	lcall	_ak820_outline_0070
      00B77E 8D 82            [24] 1682 	mov	dpl, r5
      00B780 12 8B 8D         [24] 1683 	lcall	_dynamic_keymap_set_combo
      00B783 AC 82            [24] 1684 	mov	r4, dpl
      00B785 D0 06            [24] 1685 	pop	ar6
      00B787 D0 07            [24] 1686 	pop	ar7
      00B789 12 38 8A         [24] 1687 	lcall	_ak820_outline_0124
      00B78C EC               [12] 1688 	mov	a,r4
      00B78D F0               [24] 1689 	movx	@dptr,a
                                   1690 ;	quantum/vial.c:393: if (!msg[0]) reload_combo();
      00B78E EC               [12] 1691 	mov	a,r4
      00B78F 70 03            [24] 1692 	jnz	00142$
                                   1693 ;	quantum/vial.c:419: }
                                   1694 ;	quantum/vial.c:420: }
      00B791 02 35 7C         [24] 1695 	ljmp	_ak820_combo_reload
      00B794                       1696 00142$:
      00B794 22               [24] 1697 	ret
                                   1698 ;------------------------------------------------------------
                                   1699 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1700 ;------------------------------------------------------------
                                   1701 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_675'
                                   1702 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_682'
                                   1703 ;------------------------------------------------------------
                                   1704 ;	quantum/vial.c:424: void vial_keycode_down(uint16_t keycode) {
                                   1705 ;	-----------------------------------------
                                   1706 ;	 function vial_keycode_down
                                   1707 ;	-----------------------------------------
      00B795                       1708 _vial_keycode_down:
      00B795 12 38 79         [24] 1709 	lcall	_ak820_outline_0113
      00B798 90 0C CB         [24] 1710 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B79B 12 38 7E         [24] 1711 	lcall	_ak820_outline_0114
                                   1712 ;	quantum/vial.c:428: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B79E 90 0C CB         [24] 1713 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B7A1 12 4E 82         [24] 1714 	lcall	_ak820_outline_0009
      00B7A4 74 E0            [12] 1715 	mov	a,#0x100 - 0x20
      00B7A6 2D               [12] 1716 	add	a,r5
      00B7A7 50 19            [24] 1717 	jnc	00104$
      00B7A9 C3               [12] 1718 	clr	c
      00B7AA 74 FF            [12] 1719 	mov	a,#0xff
      00B7AC 9C               [12] 1720 	subb	a,r4
      00B7AD 74 4F            [12] 1721 	mov	a,#0x4f
      00B7AF 9D               [12] 1722 	subb	a,r5
      00B7B0 40 10            [24] 1723 	jc	00104$
                                   1724 ;	free result
                                   1725 ;	quantum/vial.c:429: keycode = (uint8_t)keycode;
      00B7B2 90 0C CB         [24] 1726 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B7B5 EE               [12] 1727 	mov	a,r6
      00B7B6 12 38 9B         [24] 1728 	lcall	_ak820_outline_0131
                                   1729 ;	quantum/vial.c:430: if (keycode <= KC_TRANSPARENT) return;
      00B7B9 90 0C CB         [24] 1730 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B7BC E0               [24] 1731 	movx	a,@dptr
      00B7BD 24 FE            [12] 1732 	add	a,#0xff - 0x01
      00B7BF 40 01            [24] 1733 	jc	00104$
                                   1734 ;	free result
      00B7C1 22               [24] 1735 	ret
      00B7C2                       1736 00104$:
                                   1737 ;	quantum/vial.c:433: g_vial_magic_keycode_override = keycode;
      00B7C2 90 0C CB         [24] 1738 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B7C5 12 B8 AB         [24] 1739 	lcall	_ak820_outline_0027
                                   1740 ;	quantum/vial.c:435: if (keycode <= QK_MODS_MAX) {
      00B7C8 40 06            [24] 1741 	jc	00107$
                                   1742 ;	free result
                                   1743 ;	quantum/vial.c:436: register_code16(keycode);
      00B7CA 12 38 8A         [24] 1744 	lcall	_ak820_outline_0124
      00B7CD 02 A3 13         [24] 1745 	ljmp	_register_code16
      00B7D0                       1746 00107$:
                                   1747 ;	quantum/vial.c:438: keyevent_t dummy_event = {
      00B7D0 90 0C D1         [24] 1748 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0004)
      00B7D3 74 01            [12] 1749 	mov	a,#0x01
      00B7D5 F0               [24] 1750 	movx	@dptr,a
      00B7D6 90 0C CE         [24] 1751 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0001)
      00B7D9 74 F0            [12] 1752 	mov	a,#0xf0
      00B7DB F0               [24] 1753 	movx	@dptr,a
      00B7DC 90 0C CD         [24] 1754 	mov	dptr,#_vial_keycode_down_dummy_event_30000_682
      00B7DF F0               [24] 1755 	movx	@dptr,a
      00B7E0 90 0C D2         [24] 1756 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0005)
      00B7E3 74 01            [12] 1757 	mov	a,#0x01
      00B7E5 F0               [24] 1758 	movx	@dptr,a
      00B7E6 12 4F 83         [24] 1759 	lcall	_timer_read
      00B7E9 12 43 64         [24] 1760 	lcall	_ak820_outline_0132
      00B7EC 43 06 01         [24] 1761 	orl	ar6,#0x01
      00B7EF 90 0C CF         [24] 1762 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0002)
      00B7F2 12 4E D3         [24] 1763 	lcall	_ak820_outline_0062
                                   1764 ;	quantum/vial.c:442: AK820_ACTION_EXEC(dummy_event);
      00B7F5 90 0C CD         [24] 1765 	mov	dptr,#_vial_keycode_down_dummy_event_30000_682
                                   1766 ;	quantum/vial.c:444: }
      00B7F8 02 76 5D         [24] 1767 	ljmp	_ak820_action_exec
                                   1768 ;------------------------------------------------------------
                                   1769 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1770 ;------------------------------------------------------------
                                   1771 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_683'
                                   1772 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_690'
                                   1773 ;------------------------------------------------------------
                                   1774 ;	quantum/vial.c:446: void vial_keycode_up(uint16_t keycode) {
                                   1775 ;	-----------------------------------------
                                   1776 ;	 function vial_keycode_up
                                   1777 ;	-----------------------------------------
      00B7FB                       1778 _vial_keycode_up:
      00B7FB 12 38 79         [24] 1779 	lcall	_ak820_outline_0113
      00B7FE 90 0C D3         [24] 1780 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B801 12 38 7E         [24] 1781 	lcall	_ak820_outline_0114
                                   1782 ;	quantum/vial.c:450: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B804 90 0C D3         [24] 1783 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B807 12 4E 82         [24] 1784 	lcall	_ak820_outline_0009
      00B80A 74 E0            [12] 1785 	mov	a,#0x100 - 0x20
      00B80C 2D               [12] 1786 	add	a,r5
      00B80D 50 19            [24] 1787 	jnc	00104$
      00B80F C3               [12] 1788 	clr	c
      00B810 74 FF            [12] 1789 	mov	a,#0xff
      00B812 9C               [12] 1790 	subb	a,r4
      00B813 74 4F            [12] 1791 	mov	a,#0x4f
      00B815 9D               [12] 1792 	subb	a,r5
      00B816 40 10            [24] 1793 	jc	00104$
                                   1794 ;	free result
                                   1795 ;	quantum/vial.c:451: keycode = (uint8_t)keycode;
      00B818 90 0C D3         [24] 1796 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B81B EE               [12] 1797 	mov	a,r6
      00B81C 12 38 9B         [24] 1798 	lcall	_ak820_outline_0131
                                   1799 ;	quantum/vial.c:452: if (keycode <= KC_TRANSPARENT) return;
      00B81F 90 0C D3         [24] 1800 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B822 E0               [24] 1801 	movx	a,@dptr
      00B823 24 FE            [12] 1802 	add	a,#0xff - 0x01
      00B825 40 01            [24] 1803 	jc	00104$
                                   1804 ;	free result
      00B827 22               [24] 1805 	ret
      00B828                       1806 00104$:
                                   1807 ;	quantum/vial.c:455: g_vial_magic_keycode_override = keycode;
      00B828 90 0C D3         [24] 1808 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B82B 12 B8 AB         [24] 1809 	lcall	_ak820_outline_0027
                                   1810 ;	quantum/vial.c:457: if (keycode <= QK_MODS_MAX) {
      00B82E 40 06            [24] 1811 	jc	00107$
                                   1812 ;	free result
                                   1813 ;	quantum/vial.c:458: unregister_code16(keycode);
      00B830 12 38 8A         [24] 1814 	lcall	_ak820_outline_0124
      00B833 02 A3 57         [24] 1815 	ljmp	_unregister_code16
      00B836                       1816 00107$:
                                   1817 ;	quantum/vial.c:460: keyevent_t dummy_event = {
      00B836 90 0C D9         [24] 1818 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0004)
      00B839 74 01            [12] 1819 	mov	a,#0x01
      00B83B F0               [24] 1820 	movx	@dptr,a
      00B83C 90 0C D6         [24] 1821 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0001)
      00B83F 74 F0            [12] 1822 	mov	a,#0xf0
      00B841 F0               [24] 1823 	movx	@dptr,a
      00B842 90 0C D5         [24] 1824 	mov	dptr,#_vial_keycode_up_dummy_event_30000_690
      00B845 F0               [24] 1825 	movx	@dptr,a
      00B846 90 0C DA         [24] 1826 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0005)
      00B849 E4               [12] 1827 	clr	a
      00B84A F0               [24] 1828 	movx	@dptr,a
      00B84B 12 4F 83         [24] 1829 	lcall	_timer_read
      00B84E 12 43 64         [24] 1830 	lcall	_ak820_outline_0132
      00B851 43 06 01         [24] 1831 	orl	ar6,#0x01
      00B854 90 0C D7         [24] 1832 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0002)
      00B857 12 4E D3         [24] 1833 	lcall	_ak820_outline_0062
                                   1834 ;	quantum/vial.c:464: AK820_ACTION_EXEC(dummy_event);
      00B85A 90 0C D5         [24] 1835 	mov	dptr,#_vial_keycode_up_dummy_event_30000_690
                                   1836 ;	quantum/vial.c:466: }
      00B85D 02 76 5D         [24] 1837 	ljmp	_ak820_action_exec
                                   1838 ;------------------------------------------------------------
                                   1839 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1840 ;------------------------------------------------------------
                                   1841 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_691'
                                   1842 ;i             Allocated with name '_vial_keycode_tap_i_30000_694'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/vial.c:468: void vial_keycode_tap(uint16_t keycode) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function vial_keycode_tap
                                   1847 ;	-----------------------------------------
      00B860                       1848 _vial_keycode_tap:
      00B860 12 38 79         [24] 1849 	lcall	_ak820_outline_0113
      00B863 90 0C DB         [24] 1850 	mov	dptr,#_vial_keycode_tap_keycode_10000_691
      00B866 12 38 7E         [24] 1851 	lcall	_ak820_outline_0114
                                   1852 ;	quantum/vial.c:469: vial_keycode_down(keycode);
      00B869 90 0C DB         [24] 1853 	mov	dptr,#_vial_keycode_tap_keycode_10000_691
      00B86C 12 37 F1         [24] 1854 	lcall	_ak820_outline_0005
      00B86F C0 07            [24] 1855 	push	ar7
      00B871 C0 06            [24] 1856 	push	ar6
      00B873 12 B7 95         [24] 1857 	lcall	_vial_keycode_down
                                   1858 ;	quantum/vial.c:470: qs_wait_ms(QS_tap_code_delay);
      00B876 12 49 28         [24] 1859 	lcall	_ak820_settings_tap_code_delay
      00B879 12 38 B0         [24] 1860 	lcall	_ak820_outline_0153
      00B87C D0 06            [24] 1861 	pop	ar6
      00B87E D0 07            [24] 1862 	pop	ar7
      00B880                       1863 00106$:
      00B880 EC               [12] 1864 	mov	a,r4
      00B881 4D               [12] 1865 	orl	a,r5
      00B882 60 0D            [24] 1866 	jz	00103$
      00B884 90 00 01         [24] 1867 	mov	dptr,#0x0001
      00B887 12 5E D4         [24] 1868 	lcall	_mDelaymS
      00B88A 1C               [12] 1869 	dec	r4
      00B88B BC FF 01         [24] 1870 	cjne	r4,#0xff,00128$
      00B88E 1D               [12] 1871 	dec	r5
      00B88F                       1872 00128$:
      00B88F 80 EF            [24] 1873 	sjmp	00106$
      00B891                       1874 00103$:
                                   1875 ;	quantum/vial.c:471: vial_keycode_up(keycode);
      00B891 12 38 8A         [24] 1876 	lcall	_ak820_outline_0124
                                   1877 ;	quantum/vial.c:472: }
      00B894 02 B7 FB         [24] 1878 	ljmp	_vial_keycode_up
                                   1879 ;------------------------------------------------------------
                                   1880 ;Allocation info for local variables in function 'process_record_vial'
                                   1881 ;------------------------------------------------------------
                                   1882 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1883 ;keycode       Allocated with name '_process_record_vial_keycode_10000_696'
                                   1884 ;------------------------------------------------------------
                                   1885 ;	quantum/vial.c:682: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1886 ;	-----------------------------------------
                                   1887 	.area CSEG    (CODE)
                                   1888 	.area CONST   (CODE)
                                   1889 	.area CONST   (CODE)
      00C4DC                       1890 _keyboard_definition:
      00C4DC FD                    1891 	.db #0xfd	; 253
      00C4DD 37                    1892 	.db #0x37	; 55	'7'
      00C4DE 7A                    1893 	.db #0x7a	; 122	'z'
      00C4DF 58                    1894 	.db #0x58	; 88	'X'
      00C4E0 5A                    1895 	.db #0x5a	; 90	'Z'
      00C4E1 00                    1896 	.db #0x00	; 0
      00C4E2 00                    1897 	.db #0x00	; 0
      00C4E3 04                    1898 	.db #0x04	; 4
      00C4E4 E6                    1899 	.db #0xe6	; 230
      00C4E5 D6                    1900 	.db #0xd6	; 214
      00C4E6 B4                    1901 	.db #0xb4	; 180
      00C4E7 46                    1902 	.db #0x46	; 70	'F'
      00C4E8 02                    1903 	.db #0x02	; 2
      00C4E9 00                    1904 	.db #0x00	; 0
      00C4EA 21                    1905 	.db #0x21	; 33
      00C4EB 01                    1906 	.db #0x01	; 1
      00C4EC 00                    1907 	.db #0x00	; 0
      00C4ED 00                    1908 	.db #0x00	; 0
      00C4EE 00                    1909 	.db #0x00	; 0
      00C4EF 00                    1910 	.db #0x00	; 0
      00C4F0 37                    1911 	.db #0x37	; 55	'7'
      00C4F1 27                    1912 	.db #0x27	; 39
      00C4F2 97                    1913 	.db #0x97	; 151
      00C4F3 D6                    1914 	.db #0xd6	; 214
      00C4F4 E0                    1915 	.db #0xe0	; 224
      00C4F5 03                    1916 	.db #0x03	; 3
      00C4F6 CB                    1917 	.db #0xcb	; 203
      00C4F7 01                    1918 	.db #0x01	; 1
      00C4F8 3C                    1919 	.db #0x3c	; 60
      00C4F9 00                    1920 	.db #0x00	; 0
      00C4FA 00                    1921 	.db #0x00	; 0
      00C4FB 3D                    1922 	.db #0x3d	; 61
      00C4FC 88                    1923 	.db #0x88	; 136
      00C4FD CD                    1924 	.db #0xcd	; 205
      00C4FE A5                    1925 	.db #0xa5	; 165
      00C4FF AA                    1926 	.db #0xaa	; 170
      00C500 E5                    1927 	.db #0xe5	; 229
      00C501 A8                    1928 	.db #0xa8	; 168
      00C502 76                    1929 	.db #0x76	; 118	'v'
      00C503 F6                    1930 	.db #0xf6	; 246
      00C504 43                    1931 	.db #0x43	; 67	'C'
      00C505 0E                    1932 	.db #0x0e	; 14
      00C506 D2                    1933 	.db #0xd2	; 210
      00C507 90                    1934 	.db #0x90	; 144
      00C508 7D                    1935 	.db #0x7d	; 125
      00C509 94                    1936 	.db #0x94	; 148
      00C50A 79                    1937 	.db #0x79	; 121	'y'
      00C50B 78                    1938 	.db #0x78	; 120	'x'
      00C50C EF                    1939 	.db #0xef	; 239
      00C50D 49                    1940 	.db #0x49	; 73	'I'
      00C50E 3E                    1941 	.db #0x3e	; 62
      00C50F EF                    1942 	.db #0xef	; 239
      00C510 FD                    1943 	.db #0xfd	; 253
      00C511 8F                    1944 	.db #0x8f	; 143
      00C512 EF                    1945 	.db #0xef	; 239
      00C513 00                    1946 	.db #0x00	; 0
      00C514 C6                    1947 	.db #0xc6	; 198
      00C515 D1                    1948 	.db #0xd1	; 209
      00C516 DB                    1949 	.db #0xdb	; 219
      00C517 FB                    1950 	.db #0xfb	; 251
      00C518 EB                    1951 	.db #0xeb	; 235
      00C519 DE                    1952 	.db #0xde	; 222
      00C51A 66                    1953 	.db #0x66	; 102	'f'
      00C51B 63                    1954 	.db #0x63	; 99	'c'
      00C51C 0C                    1955 	.db #0x0c	; 12
      00C51D 92                    1956 	.db #0x92	; 146
      00C51E 7B                    1957 	.db #0x7b	; 123
      00C51F F9                    1958 	.db #0xf9	; 249
      00C520 D4                    1959 	.db #0xd4	; 212
      00C521 7A                    1960 	.db #0x7a	; 122	'z'
      00C522 4F                    1961 	.db #0x4f	; 79	'O'
      00C523 83                    1962 	.db #0x83	; 131
      00C524 4B                    1963 	.db #0x4b	; 75	'K'
      00C525 86                    1964 	.db #0x86	; 134
      00C526 0E                    1965 	.db #0x0e	; 14
      00C527 6A                    1966 	.db #0x6a	; 106	'j'
      00C528 F2                    1967 	.db #0xf2	; 242
      00C529 22                    1968 	.db #0x22	; 34
      00C52A 22                    1969 	.db #0x22	; 34
      00C52B 0B                    1970 	.db #0x0b	; 11
      00C52C 03                    1971 	.db #0x03	; 3
      00C52D BA                    1972 	.db #0xba	; 186
      00C52E 67                    1973 	.db #0x67	; 103	'g'
      00C52F 9B                    1974 	.db #0x9b	; 155
      00C530 7A                    1975 	.db #0x7a	; 122	'z'
      00C531 E1                    1976 	.db #0xe1	; 225
      00C532 BC                    1977 	.db #0xbc	; 188
      00C533 37                    1978 	.db #0x37	; 55	'7'
      00C534 26                    1979 	.db #0x26	; 38
      00C535 46                    1980 	.db #0x46	; 70	'F'
      00C536 78                    1981 	.db #0x78	; 120	'x'
      00C537 05                    1982 	.db #0x05	; 5
      00C538 0D                    1983 	.db #0x0d	; 13
      00C539 95                    1984 	.db #0x95	; 149
      00C53A 02                    1985 	.db #0x02	; 2
      00C53B E4                    1986 	.db #0xe4	; 228
      00C53C 18                    1987 	.db #0x18	; 24
      00C53D CA                    1988 	.db #0xca	; 202
      00C53E 33                    1989 	.db #0x33	; 51	'3'
      00C53F EA                    1990 	.db #0xea	; 234
      00C540 24                    1991 	.db #0x24	; 36
      00C541 C8                    1992 	.db #0xc8	; 200
      00C542 81                    1993 	.db #0x81	; 129
      00C543 4E                    1994 	.db #0x4e	; 78	'N'
      00C544 47                    1995 	.db #0x47	; 71	'G'
      00C545 A8                    1996 	.db #0xa8	; 168
      00C546 44                    1997 	.db #0x44	; 68	'D'
      00C547 DD                    1998 	.db #0xdd	; 221
      00C548 91                    1999 	.db #0x91	; 145
      00C549 6D                    2000 	.db #0x6d	; 109	'm'
      00C54A 69                    2001 	.db #0x69	; 105	'i'
      00C54B DB                    2002 	.db #0xdb	; 219
      00C54C 4F                    2003 	.db #0x4f	; 79	'O'
      00C54D 3A                    2004 	.db #0x3a	; 58
      00C54E 43                    2005 	.db #0x43	; 67	'C'
      00C54F 9D                    2006 	.db #0x9d	; 157
      00C550 26                    2007 	.db #0x26	; 38
      00C551 49                    2008 	.db #0x49	; 73	'I'
      00C552 4C                    2009 	.db #0x4c	; 76	'L'
      00C553 EF                    2010 	.db #0xef	; 239
      00C554 2B                    2011 	.db #0x2b	; 43
      00C555 D8                    2012 	.db #0xd8	; 216
      00C556 55                    2013 	.db #0x55	; 85	'U'
      00C557 95                    2014 	.db #0x95	; 149
      00C558 70                    2015 	.db #0x70	; 112	'p'
      00C559 B1                    2016 	.db #0xb1	; 177
      00C55A CC                    2017 	.db #0xcc	; 204
      00C55B CF                    2018 	.db #0xcf	; 207
      00C55C 13                    2019 	.db #0x13	; 19
      00C55D 32                    2020 	.db #0x32	; 50	'2'
      00C55E 6A                    2021 	.db #0x6a	; 106	'j'
      00C55F A1                    2022 	.db #0xa1	; 161
      00C560 FF                    2023 	.db #0xff	; 255
      00C561 99                    2024 	.db #0x99	; 153
      00C562 61                    2025 	.db #0x61	; 97	'a'
      00C563 95                    2026 	.db #0x95	; 149
      00C564 B1                    2027 	.db #0xb1	; 177
      00C565 89                    2028 	.db #0x89	; 137
      00C566 9B                    2029 	.db #0x9b	; 155
      00C567 11                    2030 	.db #0x11	; 17
      00C568 D9                    2031 	.db #0xd9	; 217
      00C569 35                    2032 	.db #0x35	; 53	'5'
      00C56A 78                    2033 	.db #0x78	; 120	'x'
      00C56B ED                    2034 	.db #0xed	; 237
      00C56C CD                    2035 	.db #0xcd	; 205
      00C56D 94                    2036 	.db #0x94	; 148
      00C56E 6E                    2037 	.db #0x6e	; 110	'n'
      00C56F 60                    2038 	.db #0x60	; 96
      00C570 8E                    2039 	.db #0x8e	; 142
      00C571 63                    2040 	.db #0x63	; 99	'c'
      00C572 8B                    2041 	.db #0x8b	; 139
      00C573 FF                    2042 	.db #0xff	; 255
      00C574 4E                    2043 	.db #0x4e	; 78	'N'
      00C575 20                    2044 	.db #0x20	; 32
      00C576 7A                    2045 	.db #0x7a	; 122	'z'
      00C577 B5                    2046 	.db #0xb5	; 181
      00C578 87                    2047 	.db #0x87	; 135
      00C579 C2                    2048 	.db #0xc2	; 194
      00C57A 35                    2049 	.db #0x35	; 53	'5'
      00C57B A4                    2050 	.db #0xa4	; 164
      00C57C 6D                    2051 	.db #0x6d	; 109	'm'
      00C57D 18                    2052 	.db #0x18	; 24
      00C57E C1                    2053 	.db #0xc1	; 193
      00C57F A3                    2054 	.db #0xa3	; 163
      00C580 DB                    2055 	.db #0xdb	; 219
      00C581 53                    2056 	.db #0x53	; 83	'S'
      00C582 1D                    2057 	.db #0x1d	; 29
      00C583 EC                    2058 	.db #0xec	; 236
      00C584 F0                    2059 	.db #0xf0	; 240
      00C585 BF                    2060 	.db #0xbf	; 191
      00C586 4A                    2061 	.db #0x4a	; 74	'J'
      00C587 4C                    2062 	.db #0x4c	; 76	'L'
      00C588 4A                    2063 	.db #0x4a	; 74	'J'
      00C589 C4                    2064 	.db #0xc4	; 196
      00C58A AA                    2065 	.db #0xaa	; 170
      00C58B 37                    2066 	.db #0x37	; 55	'7'
      00C58C 19                    2067 	.db #0x19	; 25
      00C58D 34                    2068 	.db #0x34	; 52	'4'
      00C58E 3F                    2069 	.db #0x3f	; 63
      00C58F A1                    2070 	.db #0xa1	; 161
      00C590 D3                    2071 	.db #0xd3	; 211
      00C591 1A                    2072 	.db #0x1a	; 26
      00C592 5C                    2073 	.db #0x5c	; 92
      00C593 03                    2074 	.db #0x03	; 3
      00C594 4D                    2075 	.db #0x4d	; 77	'M'
      00C595 BC                    2076 	.db #0xbc	; 188
      00C596 10                    2077 	.db #0x10	; 16
      00C597 2E                    2078 	.db #0x2e	; 46
      00C598 80                    2079 	.db #0x80	; 128
      00C599 F7                    2080 	.db #0xf7	; 247
      00C59A D6                    2081 	.db #0xd6	; 214
      00C59B 82                    2082 	.db #0x82	; 130
      00C59C 24                    2083 	.db #0x24	; 36
      00C59D 4C                    2084 	.db #0x4c	; 76	'L'
      00C59E 87                    2085 	.db #0x87	; 135
      00C59F B9                    2086 	.db #0xb9	; 185
      00C5A0 F8                    2087 	.db #0xf8	; 248
      00C5A1 BE                    2088 	.db #0xbe	; 190
      00C5A2 67                    2089 	.db #0x67	; 103	'g'
      00C5A3 96                    2090 	.db #0x96	; 150
      00C5A4 89                    2091 	.db #0x89	; 137
      00C5A5 30                    2092 	.db #0x30	; 48	'0'
      00C5A6 C8                    2093 	.db #0xc8	; 200
      00C5A7 8D                    2094 	.db #0x8d	; 141
      00C5A8 2C                    2095 	.db #0x2c	; 44
      00C5A9 F5                    2096 	.db #0xf5	; 245
      00C5AA 06                    2097 	.db #0x06	; 6
      00C5AB 05                    2098 	.db #0x05	; 5
      00C5AC 7C                    2099 	.db #0x7c	; 124
      00C5AD 48                    2100 	.db #0x48	; 72	'H'
      00C5AE 1B                    2101 	.db #0x1b	; 27
      00C5AF 76                    2102 	.db #0x76	; 118	'v'
      00C5B0 AA                    2103 	.db #0xaa	; 170
      00C5B1 3D                    2104 	.db #0x3d	; 61
      00C5B2 28                    2105 	.db #0x28	; 40
      00C5B3 FC                    2106 	.db #0xfc	; 252
      00C5B4 80                    2107 	.db #0x80	; 128
      00C5B5 75                    2108 	.db #0x75	; 117	'u'
      00C5B6 EB                    2109 	.db #0xeb	; 235
      00C5B7 78                    2110 	.db #0x78	; 120	'x'
      00C5B8 D0                    2111 	.db #0xd0	; 208
      00C5B9 8A                    2112 	.db #0x8a	; 138
      00C5BA 8F                    2113 	.db #0x8f	; 143
      00C5BB 27                    2114 	.db #0x27	; 39
      00C5BC F7                    2115 	.db #0xf7	; 247
      00C5BD F2                    2116 	.db #0xf2	; 242
      00C5BE EB                    2117 	.db #0xeb	; 235
      00C5BF 58                    2118 	.db #0x58	; 88	'X'
      00C5C0 37                    2119 	.db #0x37	; 55	'7'
      00C5C1 3C                    2120 	.db #0x3c	; 60
      00C5C2 2B                    2121 	.db #0x2b	; 43
      00C5C3 6F                    2122 	.db #0x6f	; 111	'o'
      00C5C4 0E                    2123 	.db #0x0e	; 14
      00C5C5 C7                    2124 	.db #0xc7	; 199
      00C5C6 E2                    2125 	.db #0xe2	; 226
      00C5C7 A0                    2126 	.db #0xa0	; 160
      00C5C8 97                    2127 	.db #0x97	; 151
      00C5C9 EE                    2128 	.db #0xee	; 238
      00C5CA FD                    2129 	.db #0xfd	; 253
      00C5CB 9F                    2130 	.db #0x9f	; 159
      00C5CC 45                    2131 	.db #0x45	; 69	'E'
      00C5CD 17                    2132 	.db #0x17	; 23
      00C5CE 94                    2133 	.db #0x94	; 148
      00C5CF E6                    2134 	.db #0xe6	; 230
      00C5D0 E7                    2135 	.db #0xe7	; 231
      00C5D1 FA                    2136 	.db #0xfa	; 250
      00C5D2 4C                    2137 	.db #0x4c	; 76	'L'
      00C5D3 7A                    2138 	.db #0x7a	; 122	'z'
      00C5D4 D6                    2139 	.db #0xd6	; 214
      00C5D5 7A                    2140 	.db #0x7a	; 122	'z'
      00C5D6 7B                    2141 	.db #0x7b	; 123
      00C5D7 ED                    2142 	.db #0xed	; 237
      00C5D8 10                    2143 	.db #0x10	; 16
      00C5D9 C5                    2144 	.db #0xc5	; 197
      00C5DA BC                    2145 	.db #0xbc	; 188
      00C5DB E3                    2146 	.db #0xe3	; 227
      00C5DC A9                    2147 	.db #0xa9	; 169
      00C5DD 1F                    2148 	.db #0x1f	; 31
      00C5DE CF                    2149 	.db #0xcf	; 207
      00C5DF C4                    2150 	.db #0xc4	; 196
      00C5E0 9D                    2151 	.db #0x9d	; 157
      00C5E1 DC                    2152 	.db #0xdc	; 220
      00C5E2 45                    2153 	.db #0x45	; 69	'E'
      00C5E3 2A                    2154 	.db #0x2a	; 42
      00C5E4 69                    2155 	.db #0x69	; 105	'i'
      00C5E5 57                    2156 	.db #0x57	; 87	'W'
      00C5E6 8F                    2157 	.db #0x8f	; 143
      00C5E7 EC                    2158 	.db #0xec	; 236
      00C5E8 85                    2159 	.db #0x85	; 133
      00C5E9 6C                    2160 	.db #0x6c	; 108	'l'
      00C5EA 43                    2161 	.db #0x43	; 67	'C'
      00C5EB 1C                    2162 	.db #0x1c	; 28
      00C5EC BA                    2163 	.db #0xba	; 186
      00C5ED 89                    2164 	.db #0x89	; 137
      00C5EE 68                    2165 	.db #0x68	; 104	'h'
      00C5EF 4A                    2166 	.db #0x4a	; 74	'J'
      00C5F0 1C                    2167 	.db #0x1c	; 28
      00C5F1 91                    2168 	.db #0x91	; 145
      00C5F2 3F                    2169 	.db #0x3f	; 63
      00C5F3 D1                    2170 	.db #0xd1	; 209
      00C5F4 B3                    2171 	.db #0xb3	; 179
      00C5F5 96                    2172 	.db #0x96	; 150
      00C5F6 1D                    2173 	.db #0x1d	; 29
      00C5F7 7C                    2174 	.db #0x7c	; 124
      00C5F8 14                    2175 	.db #0x14	; 20
      00C5F9 77                    2176 	.db #0x77	; 119	'w'
      00C5FA 9C                    2177 	.db #0x9c	; 156
      00C5FB 74                    2178 	.db #0x74	; 116	't'
      00C5FC 36                    2179 	.db #0x36	; 54	'6'
      00C5FD FF                    2180 	.db #0xff	; 255
      00C5FE 2C                    2181 	.db #0x2c	; 44
      00C5FF 66                    2182 	.db #0x66	; 102	'f'
      00C600 AF                    2183 	.db #0xaf	; 175
      00C601 0F                    2184 	.db #0x0f	; 15
      00C602 3C                    2185 	.db #0x3c	; 60
      00C603 A2                    2186 	.db #0xa2	; 162
      00C604 23                    2187 	.db #0x23	; 35
      00C605 85                    2188 	.db #0x85	; 133
      00C606 05                    2189 	.db #0x05	; 5
      00C607 87                    2190 	.db #0x87	; 135
      00C608 DA                    2191 	.db #0xda	; 218
      00C609 61                    2192 	.db #0x61	; 97	'a'
      00C60A 5E                    2193 	.db #0x5e	; 94
      00C60B 42                    2194 	.db #0x42	; 66	'B'
      00C60C 54                    2195 	.db #0x54	; 84	'T'
      00C60D 60                    2196 	.db #0x60	; 96
      00C60E 23                    2197 	.db #0x23	; 35
      00C60F CA                    2198 	.db #0xca	; 202
      00C610 BC                    2199 	.db #0xbc	; 188
      00C611 B3                    2200 	.db #0xb3	; 179
      00C612 18                    2201 	.db #0x18	; 24
      00C613 1D                    2202 	.db #0x1d	; 29
      00C614 F8                    2203 	.db #0xf8	; 248
      00C615 0A                    2204 	.db #0x0a	; 10
      00C616 55                    2205 	.db #0x55	; 85	'U'
      00C617 CD                    2206 	.db #0xcd	; 205
      00C618 A3                    2207 	.db #0xa3	; 163
      00C619 DE                    2208 	.db #0xde	; 222
      00C61A FF                    2209 	.db #0xff	; 255
      00C61B B2                    2210 	.db #0xb2	; 178
      00C61C 2A                    2211 	.db #0x2a	; 42
      00C61D 35                    2212 	.db #0x35	; 53	'5'
      00C61E 00                    2213 	.db #0x00	; 0
      00C61F D6                    2214 	.db #0xd6	; 214
      00C620 7B                    2215 	.db #0x7b	; 123
      00C621 E8                    2216 	.db #0xe8	; 232
      00C622 F2                    2217 	.db #0xf2	; 242
      00C623 1A                    2218 	.db #0x1a	; 26
      00C624 BC                    2219 	.db #0xbc	; 188
      00C625 F5                    2220 	.db #0xf5	; 245
      00C626 7E                    2221 	.db #0x7e	; 126
      00C627 48                    2222 	.db #0x48	; 72	'H'
      00C628 72                    2223 	.db #0x72	; 114	'r'
      00C629 E0                    2224 	.db #0xe0	; 224
      00C62A E4                    2225 	.db #0xe4	; 228
      00C62B E0                    2226 	.db #0xe0	; 224
      00C62C 27                    2227 	.db #0x27	; 39
      00C62D 87                    2228 	.db #0x87	; 135
      00C62E 9A                    2229 	.db #0x9a	; 154
      00C62F 51                    2230 	.db #0x51	; 81	'Q'
      00C630 D4                    2231 	.db #0xd4	; 212
      00C631 DD                    2232 	.db #0xdd	; 221
      00C632 C3                    2233 	.db #0xc3	; 195
      00C633 AA                    2234 	.db #0xaa	; 170
      00C634 49                    2235 	.db #0x49	; 73	'I'
      00C635 5A                    2236 	.db #0x5a	; 90	'Z'
      00C636 2A                    2237 	.db #0x2a	; 42
      00C637 00                    2238 	.db #0x00	; 0
      00C638 A0                    2239 	.db #0xa0	; 160
      00C639 8C                    2240 	.db #0x8c	; 140
      00C63A FF                    2241 	.db #0xff	; 255
      00C63B 74                    2242 	.db #0x74	; 116	't'
      00C63C BF                    2243 	.db #0xbf	; 191
      00C63D EC                    2244 	.db #0xec	; 236
      00C63E 1D                    2245 	.db #0x1d	; 29
      00C63F F1                    2246 	.db #0xf1	; 241
      00C640 00                    2247 	.db #0x00	; 0
      00C641 01                    2248 	.db #0x01	; 1
      00C642 D8                    2249 	.db #0xd8	; 216
      00C643 02                    2250 	.db #0x02	; 2
      00C644 CC                    2251 	.db #0xcc	; 204
      00C645 07                    2252 	.db #0x07	; 7
      00C646 00                    2253 	.db #0x00	; 0
      00C647 00                    2254 	.db #0x00	; 0
      00C648 C4                    2255 	.db #0xc4	; 196
      00C649 5E                    2256 	.db #0x5e	; 94
      00C64A 2C                    2257 	.db #0x2c	; 44
      00C64B 7E                    2258 	.db #0x7e	; 126
      00C64C B1                    2259 	.db #0xb1	; 177
      00C64D C4                    2260 	.db #0xc4	; 196
      00C64E 67                    2261 	.db #0x67	; 103	'g'
      00C64F FB                    2262 	.db #0xfb	; 251
      00C650 02                    2263 	.db #0x02	; 2
      00C651 00                    2264 	.db #0x00	; 0
      00C652 00                    2265 	.db #0x00	; 0
      00C653 00                    2266 	.db #0x00	; 0
      00C654 00                    2267 	.db #0x00	; 0
      00C655 04                    2268 	.db #0x04	; 4
      00C656 59                    2269 	.db #0x59	; 89	'Y'
      00C657 5A                    2270 	.db #0x5a	; 90	'Z'
                                   2271 	.area CSEG    (CODE)
                                   2272 	.area CONST   (CODE)
      00C658                       2273 _vial_handle_cmd_keyboard_uid_40000_646:
      00C658 04                    2274 	.db #0x04	; 4
      00C659 70                    2275 	.db #0x70	; 112	'p'
      00C65A FF                    2276 	.db #0xff	; 255
      00C65B 90                    2277 	.db #0x90	; 144
      00C65C 01                    2278 	.db #0x01	; 1
      00C65D B9                    2279 	.db #0xb9	; 185
      00C65E 15                    2280 	.db #0x15	; 21
      00C65F D3                    2281 	.db #0xd3	; 211
                                   2282 	.area CSEG    (CODE)
                                   2283 	.area XINIT   (CODE)
      00C88E                       2284 __xinit__vial_unlocked:
      00C88E 00                    2285 	.db #0x00	;  0
      00C88F                       2286 __xinit__vial_unlock_in_progress:
      00C88F 00                    2287 	.db #0x00	;  0
      00C890                       2288 __xinit__vial_unlock_counter:
      00C890 00                    2289 	.db #0x00	; 0
      00C891                       2290 __xinit__vial_unlock_combo_rows:
      00C891 00                    2291 	.db #0x00	; 0
      00C892 00                    2292 	.db #0x00	; 0
      00C893                       2293 __xinit__vial_unlock_combo_cols:
      00C893 00                    2294 	.db #0x00	; 0
      00C894 05                    2295 	.db #0x05	; 5
                                   2296 	.area CABS    (ABS,CODE)
                                   2297 
                                   2298 ; Experimental exact instruction outlining.
                                   2299 	.globl _ak820_outline_0005
                                   2300 	.globl _ak820_outline_0006
                                   2301 	.globl _ak820_outline_0007
                                   2302 	.globl _ak820_outline_0009
                                   2303 	.globl _ak820_outline_0012
                                   2304 	.globl _ak820_outline_0014
                                   2305 	.globl _ak820_outline_0018
                                   2306 	.globl _ak820_outline_0019
                                   2307 	.globl _ak820_outline_0024
                                   2308 	.globl _ak820_outline_0025
                                   2309 	.globl _ak820_outline_0027
                                   2310 	.globl _ak820_outline_0034
                                   2311 	.globl _ak820_outline_0037
                                   2312 	.globl _ak820_outline_0038
                                   2313 	.globl _ak820_outline_0055
                                   2314 	.globl _ak820_outline_0058
                                   2315 	.globl _ak820_outline_0060
                                   2316 	.globl _ak820_outline_0062
                                   2317 	.globl _ak820_outline_0070
                                   2318 	.globl _ak820_outline_0076
                                   2319 	.globl _ak820_outline_0077
                                   2320 	.globl _ak820_outline_0081
                                   2321 	.globl _ak820_outline_0099
                                   2322 	.globl _ak820_outline_0106
                                   2323 	.globl _ak820_outline_0113
                                   2324 	.globl _ak820_outline_0114
                                   2325 	.globl _ak820_outline_0124
                                   2326 	.globl _ak820_outline_0130
                                   2327 	.globl _ak820_outline_0131
                                   2328 	.globl _ak820_outline_0132
                                   2329 	.globl _ak820_outline_0135
                                   2330 	.globl _ak820_outline_0136
                                   2331 	.globl _ak820_outline_0143
                                   2332 	.globl _ak820_outline_0145
                                   2333 	.globl _ak820_outline_0147
                                   2334 	.globl _ak820_outline_0153
                                   2335 	.globl _ak820_outline_0160
                                   2336 	.globl _ak820_outline_0177
                                   2337 	.globl _ak820_outline_0178
                                   2338 	.globl _ak820_outline_0194
                                   2339 
                                   2340 	.area CSEG (CODE)
                                   2341 ; function ak820_outline_0007
      00B897                       2342 _ak820_outline_0007:
      00B897 8E 82            [24] 2343 	mov	dpl,r6
      00B899 8F 83            [24] 2344 	mov	dph,r7
      00B89B A3               [24] 2345 	inc	dptr
      00B89C A3               [24] 2346 	inc	dptr
      00B89D E0               [24] 2347 	movx	a,@dptr
      00B89E FA               [12] 2348 	mov	r2,a
      00B89F 8E 82            [24] 2349 	mov	dpl,r6
      00B8A1 8F 83            [24] 2350 	mov	dph,r7
      00B8A3 A3               [24] 2351 	inc	dptr
      00B8A4 A3               [24] 2352 	inc	dptr
      00B8A5 A3               [24] 2353 	inc	dptr
      00B8A6 E0               [24] 2354 	movx	a,@dptr
      00B8A7 F8               [12] 2355 	mov	r0,a
      00B8A8 79 00            [12] 2356 	mov	r1,#0x00
      00B8AA 22               [24] 2357 	ret
                                   2358 
                                   2359 	.area CSEG (CODE)
                                   2360 ; function ak820_outline_0027
      00B8AB                       2361 _ak820_outline_0027:
      00B8AB E0               [24] 2362 	movx	a,@dptr
      00B8AC FE               [12] 2363 	mov	r6,a
      00B8AD A3               [24] 2364 	inc	dptr
      00B8AE E0               [24] 2365 	movx	a,@dptr
      00B8AF FF               [12] 2366 	mov	r7,a
      00B8B0 90 0C C9         [24] 2367 	mov	dptr,#_g_vial_magic_keycode_override
      00B8B3 EE               [12] 2368 	mov	a,r6
      00B8B4 F0               [24] 2369 	movx	@dptr,a
      00B8B5 EF               [12] 2370 	mov	a,r7
      00B8B6 A3               [24] 2371 	inc	dptr
      00B8B7 F0               [24] 2372 	movx	@dptr,a
      00B8B8 8E 04            [24] 2373 	mov	ar4,r6
      00B8BA 8F 05            [24] 2374 	mov	ar5,r7
      00B8BC C3               [12] 2375 	clr	c
      00B8BD 74 FF            [12] 2376 	mov	a,#0xff
      00B8BF 9C               [12] 2377 	subb	a,r4
      00B8C0 74 1F            [12] 2378 	mov	a,#0x1f
      00B8C2 9D               [12] 2379 	subb	a,r5
      00B8C3 22               [24] 2380 	ret
                                   2381 
                                   2382 	.area CSEG (CODE)
                                   2383 ; function ak820_outline_0135
      00B8C4                       2384 _ak820_outline_0135:
      00B8C4 24 7E            [12] 2385 	add	a,#_vial_unlock_combo_cols
      00B8C6 F5 82            [12] 2386 	mov	dpl,a
      00B8C8 E4               [12] 2387 	clr	a
      00B8C9 34 0E            [12] 2388 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B8CB F5 83            [12] 2389 	mov	dph,a
      00B8CD E0               [24] 2390 	movx	a,@dptr
      00B8CE 22               [24] 2391 	ret
                                   2392 
                                   2393 	.area CSEG (CODE)
                                   2394 ; function ak820_outline_0136
      00B8CF                       2395 _ak820_outline_0136:
      00B8CF 24 7C            [12] 2396 	add	a,#_vial_unlock_combo_rows
      00B8D1 F5 82            [12] 2397 	mov	dpl,a
      00B8D3 E4               [12] 2398 	clr	a
      00B8D4 34 0E            [12] 2399 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B8D6 F5 83            [12] 2400 	mov	dph,a
      00B8D8 E0               [24] 2401 	movx	a,@dptr
      00B8D9 22               [24] 2402 	ret
