                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_settings_caps_delay
                                     17 	.globl _ak820_settings_tap_code_delay
                                     18 	.globl _ak820_combo_process
                                     19 	.globl _process_repeat_key
                                     20 	.globl _process_last_key
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _mcu_reset
                                     24 	.globl _bootloader_jump
                                     25 	.globl _ak820_resolve_key
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _rgb_matrix_set_suspend_state
                                     36 	.globl _rgb_matrix_task
                                     37 	.globl _mDelaymS
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _process_record_quantum_helper_PARM_2
                                    282 	.globl _get_record_keycode_PARM_2
                                    283 	.globl _post_process_record_user_PARM_2
                                    284 	.globl _post_process_record_kb_PARM_2
                                    285 	.globl _process_record_user_PARM_2
                                    286 	.globl _process_record_kb_PARM_2
                                    287 	.globl _pre_process_record_user_PARM_2
                                    288 	.globl _pre_process_record_kb_PARM_2
                                    289 	.globl _register_code16
                                    290 	.globl _unregister_code16
                                    291 	.globl _pre_process_record_kb
                                    292 	.globl _pre_process_record_user
                                    293 	.globl _process_action_kb
                                    294 	.globl _process_record_kb
                                    295 	.globl _process_record_user
                                    296 	.globl _post_process_record_kb
                                    297 	.globl _post_process_record_user
                                    298 	.globl _reset_keyboard
                                    299 	.globl _soft_reset_keyboard
                                    300 	.globl _get_record_keycode
                                    301 	.globl _pre_process_record_quantum
                                    302 	.globl _post_process_record_quantum
                                    303 	.globl _process_record_quantum
                                    304 	.globl _process_record_quantum_helper
                                    305 	.globl _shutdown_user
                                    306 ;--------------------------------------------------------
                                    307 ; special function registers
                                    308 ;--------------------------------------------------------
                                    309 	.area RSEG    (ABS,DATA)
      000000                        310 	.org 0x0000
                           0000D0   311 _PSW	=	0x00d0
                           0000E0   312 _ACC	=	0x00e0
                           0000F0   313 _B	=	0x00f0
                           0000FD   314 _A_INV	=	0x00fd
                           000081   315 _SP	=	0x0081
                           000082   316 _DPL	=	0x0082
                           000083   317 _DPH	=	0x0083
                           0000A1   318 _SAFE_MOD	=	0x00a1
                           0000B1   319 _GLOBAL_CFG	=	0x00b1
                           000087   320 _PCON	=	0x0087
                           0000BA   321 _POWER_CFG	=	0x00ba
                           0000B9   322 _CLOCK_CFG	=	0x00b9
                           0000A9   323 _WAKE_CTRL	=	0x00a9
                           0000FE   324 _RESET_KEEP	=	0x00fe
                           0000FF   325 _WDOG_COUNT	=	0x00ff
                           0000A8   326 _IE	=	0x00a8
                           0000B8   327 _IP	=	0x00b8
                           0000E8   328 _IE_EX	=	0x00e8
                           0000E9   329 _IP_EX	=	0x00e9
                           0000B2   330 _GPIO_IE	=	0x00b2
                           008584   331 _ROM_ADDR	=	0x8584
                           000084   332 _ROM_ADDR_L	=	0x0084
                           000085   333 _ROM_ADDR_H	=	0x0085
                           008F8E   334 _ROM_DATA_HI	=	0x8f8e
                           00008E   335 _ROM_DATA_HL	=	0x008e
                           00008F   336 _ROM_DATA_HH	=	0x008f
                           000086   337 _ROM_CTRL	=	0x0086
                           000080   338 _P0	=	0x0080
                           0000C4   339 _P0_MOD_OC	=	0x00c4
                           0000C5   340 _P0_DIR_PU	=	0x00c5
                           000090   341 _P1	=	0x0090
                           000092   342 _P1_MOD_OC	=	0x0092
                           000093   343 _P1_DIR_PU	=	0x0093
                           0000A0   344 _P2	=	0x00a0
                           000094   345 _P2_MOD_OC	=	0x0094
                           000095   346 _P2_DIR_PU	=	0x0095
                           0000B0   347 _P3	=	0x00b0
                           000096   348 _P3_MOD_OC	=	0x0096
                           000097   349 _P3_DIR_PU	=	0x0097
                           0000C0   350 _P4	=	0x00c0
                           0000C2   351 _P4_MOD_OC	=	0x00c2
                           0000C3   352 _P4_DIR_PU	=	0x00c3
                           0000C1   353 _P4_LED_KEY	=	0x00c1
                           0000AA   354 _P5_IN	=	0x00aa
                           0000AB   355 _P5_OUT_PU	=	0x00ab
                           0000AC   356 _P5_DIR	=	0x00ac
                           0000AD   357 _P6_IN	=	0x00ad
                           0000AE   358 _P6_OUT_PU	=	0x00ae
                           0000AF   359 _P6_DIR	=	0x00af
                           0000F1   360 _P7	=	0x00f1
                           0000A2   361 _XBUS_AUX	=	0x00a2
                           000088   362 _TCON	=	0x0088
                           000089   363 _TMOD	=	0x0089
                           00008A   364 _TL0	=	0x008a
                           00008B   365 _TL1	=	0x008b
                           00008C   366 _TH0	=	0x008c
                           00008D   367 _TH1	=	0x008d
                           000098   368 _SCON	=	0x0098
                           000099   369 _SBUF	=	0x0099
                           0000C8   370 _T2CON	=	0x00c8
                           0000C9   371 _T2MOD	=	0x00c9
                           00CBCA   372 _RCAP2	=	0xcbca
                           0000CA   373 _RCAP2L	=	0x00ca
                           0000CB   374 _RCAP2H	=	0x00cb
                           00CDCC   375 _T2COUNT	=	0xcdcc
                           0000CC   376 _TL2	=	0x00cc
                           0000CD   377 _TH2	=	0x00cd
                           00CFCE   378 _T2CAP1	=	0xcfce
                           0000CE   379 _T2CAP1L	=	0x00ce
                           0000CF   380 _T2CAP1H	=	0x00cf
                           0000F8   381 _SPI0_STAT	=	0x00f8
                           0000F9   382 _SPI0_DATA	=	0x00f9
                           0000FA   383 _SPI0_CTRL	=	0x00fa
                           0000FB   384 _SPI0_CK_SE	=	0x00fb
                           0000FC   385 _SPI0_SETUP	=	0x00fc
                           0000BC   386 _SCON1	=	0x00bc
                           0000BD   387 _SBUF1	=	0x00bd
                           0000BE   388 _SBAUD1	=	0x00be
                           0000BF   389 _SIF1	=	0x00bf
                           0000B4   390 _SPI1_STAT	=	0x00b4
                           0000B5   391 _SPI1_DATA	=	0x00b5
                           0000B6   392 _SPI1_CTRL	=	0x00b6
                           0000B7   393 _SPI1_CK_SE	=	0x00b7
                           0000F3   394 _ADC_CTRL	=	0x00f3
                           00F5F4   395 _ADC_DAT	=	0xf5f4
                           0000F4   396 _ADC_DAT_L	=	0x00f4
                           0000F5   397 _ADC_DAT_H	=	0x00f5
                           0000F6   398 _ADC_CHAN	=	0x00f6
                           0000A6   399 _LED_COMMON	=	0x00a6
                           0000A7   400 _LED_PWM_OE	=	0x00a7
                           00C7C6   401 _LED_DMA	=	0xc7c6
                           0000C6   402 _LED_DMA_L	=	0x00c6
                           0000C7   403 _LED_DMA_H	=	0x00c7
                           0000F7   404 _LED_STATUS	=	0x00f7
                           0000B3   405 _I2CX_INT	=	0x00b3
                           0000BB   406 _I2CS_INT_ST	=	0x00bb
                                    407 ;--------------------------------------------------------
                                    408 ; special function bits
                                    409 ;--------------------------------------------------------
                                    410 	.area RSEG    (ABS,DATA)
      000000                        411 	.org 0x0000
                           0000D7   412 _CY	=	0x00d7
                           0000D6   413 _AC	=	0x00d6
                           0000D5   414 _F0	=	0x00d5
                           0000D4   415 _RS1	=	0x00d4
                           0000D3   416 _RS0	=	0x00d3
                           0000D2   417 _OV	=	0x00d2
                           0000D1   418 _F1	=	0x00d1
                           0000D0   419 _P	=	0x00d0
                           0000AF   420 _EA	=	0x00af
                           0000AE   421 _E_DIS	=	0x00ae
                           0000AD   422 _ET2	=	0x00ad
                           0000AC   423 _ES	=	0x00ac
                           0000AB   424 _ET1	=	0x00ab
                           0000AA   425 _EX1	=	0x00aa
                           0000A9   426 _ET0	=	0x00a9
                           0000A8   427 _EX0	=	0x00a8
                           0000BF   428 _PH_FLAG	=	0x00bf
                           0000BE   429 _PL_FLAG	=	0x00be
                           0000BD   430 _PT2	=	0x00bd
                           0000BC   431 _PS	=	0x00bc
                           0000BB   432 _PT1	=	0x00bb
                           0000BA   433 _PX1	=	0x00ba
                           0000B9   434 _PT0	=	0x00b9
                           0000B8   435 _PX0	=	0x00b8
                           0000EF   436 _IE_WDOG	=	0x00ef
                           0000EE   437 _IE_GPIO	=	0x00ee
                           0000ED   438 _IE_PWM_I2C	=	0x00ed
                           0000EC   439 _IE_UART1	=	0x00ec
                           0000EB   440 _IE_ADC	=	0x00eb
                           0000E9   441 _IE_USB	=	0x00e9
                           0000E8   442 _IE_SPI0	=	0x00e8
                           000087   443 _P0_7	=	0x0087
                           000086   444 _P0_6	=	0x0086
                           000085   445 _P0_5	=	0x0085
                           000084   446 _P0_4	=	0x0084
                           000083   447 _P0_3	=	0x0083
                           000082   448 _P0_2	=	0x0082
                           000081   449 _P0_1	=	0x0081
                           000080   450 _P0_0	=	0x0080
                           000081   451 _SDA0	=	0x0081
                           000080   452 _SCL0	=	0x0080
                           000083   453 _TXD_	=	0x0083
                           000082   454 _RXD_	=	0x0082
                           000085   455 _AIN13	=	0x0085
                           000084   456 _AIN12	=	0x0084
                           000083   457 _AIN11	=	0x0083
                           000082   458 _AIN10	=	0x0082
                           000081   459 _AIN9	=	0x0081
                           000080   460 _AIN8	=	0x0080
                           000097   461 _P1_7	=	0x0097
                           000096   462 _P1_6	=	0x0096
                           000095   463 _P1_5	=	0x0095
                           000094   464 _P1_4	=	0x0094
                           000093   465 _P1_3	=	0x0093
                           000092   466 _P1_2	=	0x0092
                           000091   467 _P1_1	=	0x0091
                           000090   468 _P1_0	=	0x0090
                           000097   469 _TXD1_	=	0x0097
                           000096   470 _RXD1_	=	0x0096
                           000097   471 _SCK	=	0x0097
                           000096   472 _MISO	=	0x0096
                           000095   473 _MOSI	=	0x0095
                           000094   474 _SCS	=	0x0094
                           000092   475 _INT0_	=	0x0092
                           000091   476 _T2EX	=	0x0091
                           000091   477 _CAP2	=	0x0091
                           000090   478 _T2	=	0x0090
                           000090   479 _CAP1	=	0x0090
                           000097   480 _AIN7	=	0x0097
                           000096   481 _AIN6	=	0x0096
                           000095   482 _AIN5	=	0x0095
                           000094   483 _AIN4	=	0x0094
                           000093   484 _AIN3	=	0x0093
                           000092   485 _AIN2	=	0x0092
                           000091   486 _AIN1	=	0x0091
                           000090   487 _AIN0	=	0x0090
                           0000A7   488 _P2_7	=	0x00a7
                           0000A6   489 _P2_6	=	0x00a6
                           0000A5   490 _P2_5	=	0x00a5
                           0000A4   491 _P2_4	=	0x00a4
                           0000A3   492 _P2_3	=	0x00a3
                           0000A2   493 _P2_2	=	0x00a2
                           0000A1   494 _P2_1	=	0x00a1
                           0000A0   495 _P2_0	=	0x00a0
                           0000A7   496 _TXD1	=	0x00a7
                           0000A6   497 _RXD1	=	0x00a6
                           0000A5   498 _T2EX_	=	0x00a5
                           0000A5   499 _CAP2_	=	0x00a5
                           0000A4   500 _T2_	=	0x00a4
                           0000A4   501 _CAP1_	=	0x00a4
                           0000B7   502 _P3_7	=	0x00b7
                           0000B6   503 _P3_6	=	0x00b6
                           0000B5   504 _P3_5	=	0x00b5
                           0000B4   505 _P3_4	=	0x00b4
                           0000B3   506 _P3_3	=	0x00b3
                           0000B2   507 _P3_2	=	0x00b2
                           0000B1   508 _P3_1	=	0x00b1
                           0000B0   509 _P3_0	=	0x00b0
                           0000B7   510 _SCK1	=	0x00b7
                           0000B6   511 _MISO1	=	0x00b6
                           0000B5   512 _MOSI1	=	0x00b5
                           0000B5   513 _T1	=	0x00b5
                           0000B4   514 _T0	=	0x00b4
                           0000B3   515 _INT1	=	0x00b3
                           0000B2   516 _INT0	=	0x00b2
                           0000B1   517 _TXD	=	0x00b1
                           0000B0   518 _RXD	=	0x00b0
                           0000C6   519 _P4_6	=	0x00c6
                           0000C5   520 _P4_5	=	0x00c5
                           0000C4   521 _P4_4	=	0x00c4
                           0000C3   522 _P4_3	=	0x00c3
                           0000C2   523 _P4_2	=	0x00c2
                           0000C1   524 _P4_1	=	0x00c1
                           0000C0   525 _P4_0	=	0x00c0
                           00008F   526 _TF1	=	0x008f
                           00008E   527 _TR1	=	0x008e
                           00008D   528 _TF0	=	0x008d
                           00008C   529 _TR0	=	0x008c
                           00008B   530 _IE1	=	0x008b
                           00008A   531 _IT1	=	0x008a
                           000089   532 _IE0	=	0x0089
                           000088   533 _IT0	=	0x0088
                           00009F   534 _SM0	=	0x009f
                           00009E   535 _SM1	=	0x009e
                           00009D   536 _SM2	=	0x009d
                           00009C   537 _REN	=	0x009c
                           00009B   538 _TB8	=	0x009b
                           00009A   539 _RB8	=	0x009a
                           000099   540 _TI	=	0x0099
                           000098   541 _RI	=	0x0098
                           0000CF   542 _TF2	=	0x00cf
                           0000CF   543 _CAP1F	=	0x00cf
                           0000CE   544 _EXF2	=	0x00ce
                           0000CD   545 _RCLK	=	0x00cd
                           0000CC   546 _TCLK	=	0x00cc
                           0000CB   547 _EXEN2	=	0x00cb
                           0000CA   548 _TR2	=	0x00ca
                           0000C9   549 _C_T2	=	0x00c9
                           0000C8   550 _CP_RL2	=	0x00c8
                           0000FF   551 _S0_FST_ACT	=	0x00ff
                           0000FE   552 _S0_IF_OV	=	0x00fe
                           0000FD   553 _S0_IF_FIRST	=	0x00fd
                           0000FC   554 _S0_IF_BYTE	=	0x00fc
                           0000FB   555 _S0_FREE	=	0x00fb
                           0000FA   556 _S0_T_FIFO	=	0x00fa
                           0000F8   557 _S0_R_FIFO	=	0x00f8
                           0000F7   558 _ADC_START	=	0x00f7
                                    559 ;--------------------------------------------------------
                                    560 ; overlayable register banks
                                    561 ;--------------------------------------------------------
                                    562 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        563 	.ds 8
                                    564 ;--------------------------------------------------------
                                    565 ; internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area DSEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable items in internal ram
                                    570 ;--------------------------------------------------------
                                    571 ;--------------------------------------------------------
                                    572 ; indirectly addressable internal ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area ISEG    (DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; absolute internal ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area IABS    (ABS,DATA)
                                    579 	.area IABS    (ABS,DATA)
                                    580 ;--------------------------------------------------------
                                    581 ; bit data
                                    582 ;--------------------------------------------------------
                                    583 	.area BSEG    (BIT)
      000026                        584 _get_record_keycode_sloc0_1_0:
      000026                        585 	.ds 1
      000027                        586 _pre_process_record_quantum_sloc0_1_0:
      000027                        587 	.ds 1
      000028                        588 _process_ak820_nkro_sloc0_1_0:
      000028                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; paged external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area PSEG    (PAG,XDATA)
                                    594 ;--------------------------------------------------------
                                    595 ; uninitialized external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XSEG    (XDATA)
      000C2A                        598 _extract_mod_bits_code_10000_623:
      000C2A                        599 	.ds 2
      000C2C                        600 _register_code16_code_10000_629:
      000C2C                        601 	.ds 2
      000C2E                        602 _unregister_code16_code_10000_634:
      000C2E                        603 	.ds 2
      000C30                        604 _pre_process_record_kb_PARM_2:
      000C30                        605 	.ds 3
      000C33                        606 _pre_process_record_kb_keycode_10000_648:
      000C33                        607 	.ds 2
      000C35                        608 _pre_process_record_user_PARM_2:
      000C35                        609 	.ds 3
      000C38                        610 _process_record_kb_PARM_2:
      000C38                        611 	.ds 3
      000C3B                        612 _process_record_kb_keycode_10000_654:
      000C3B                        613 	.ds 2
      000C3D                        614 _process_record_user_PARM_2:
      000C3D                        615 	.ds 3
      000C40                        616 _post_process_record_kb_PARM_2:
      000C40                        617 	.ds 3
      000C43                        618 _post_process_record_kb_keycode_10000_658:
      000C43                        619 	.ds 2
      000C45                        620 _post_process_record_user_PARM_2:
      000C45                        621 	.ds 3
      000C48                        622 _get_record_keycode_PARM_2:
      000C48                        623 	.ds 1
      000C49                        624 _get_record_keycode_record_argument_10000_672:
      000C49                        625 	.ds 3
      000C4C                        626 _pre_process_record_quantum_record_argument_10000_678:
      000C4C                        627 	.ds 3
      000C4F                        628 _post_process_record_quantum_record_10000_680:
      000C4F                        629 	.ds 3
      000C52                        630 _process_record_quantum_record_10000_682:
      000C52                        631 	.ds 3
      000C55                        632 _process_ak820_nkro_PARM_2:
      000C55                        633 	.ds 3
      000C58                        634 _process_ak820_nkro_keycode_10000_684:
      000C58                        635 	.ds 2
      000C5A                        636 _process_record_quantum_helper_PARM_2:
      000C5A                        637 	.ds 3
      000C5D                        638 _process_record_quantum_helper_keycode_10000_689:
      000C5D                        639 	.ds 2
      000C5F                        640 _get_u8_str_last_num_10000_715:
      000C5F                        641 	.ds 1
      000C60                        642 _get_u16_str_last_num_10000_719:
      000C60                        643 	.ds 2
                                    644 ;--------------------------------------------------------
                                    645 ; absolute external ram data
                                    646 ;--------------------------------------------------------
                                    647 	.area XABS    (ABS,XDATA)
                                    648 ;--------------------------------------------------------
                                    649 ; initialized external ram data
                                    650 ;--------------------------------------------------------
                                    651 	.area XISEG   (XDATA)
                                    652 	.area HOME    (CODE)
                                    653 	.area GSINIT0 (CODE)
                                    654 	.area GSINIT1 (CODE)
                                    655 	.area GSINIT2 (CODE)
                                    656 	.area GSINIT3 (CODE)
                                    657 	.area GSINIT4 (CODE)
                                    658 	.area GSINIT5 (CODE)
                                    659 	.area GSINIT  (CODE)
                                    660 	.area GSFINAL (CODE)
                                    661 	.area CSEG    (CODE)
                                    662 ;--------------------------------------------------------
                                    663 ; global & static initialisations
                                    664 ;--------------------------------------------------------
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT  (CODE)
                                    667 	.area GSFINAL (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 ;------------------------------------------------------------
                                    670 ;Allocation info for local variables in function 'get_u8_str'
                                    671 ;------------------------------------------------------------
                                    672 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    673 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_714'
                                    674 ;buf           Allocated with name '_get_u8_str_buf_10000_715'
                                    675 ;last_num      Allocated with name '_get_u8_str_last_num_10000_715'
                                    676 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_715'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/quantum.c:778: static uint8_t last_num = 0xFF;
      0030F3 90 0C 5F         [24]  679 	mov	dptr,#_get_u8_str_last_num_10000_715
      0030F6 74 FF            [12]  680 	mov	a,#0xff
      0030F8 F0               [24]  681 	movx	@dptr,a
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'get_u16_str'
                                    684 ;------------------------------------------------------------
                                    685 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    686 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_718'
                                    687 ;buf           Allocated with name '_get_u16_str_buf_10000_719'
                                    688 ;last_num      Allocated with name '_get_u16_str_last_num_10000_719'
                                    689 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_719'
                                    690 ;------------------------------------------------------------
                                    691 ;	quantum/quantum.c:798: static uint16_t last_num = 0xFF;
      0030F9 90 0C 60         [24]  692 	mov	dptr,#_get_u16_str_last_num_10000_719
      0030FC 74 FF            [12]  693 	mov	a,#0xff
      0030FE F0               [24]  694 	movx	@dptr,a
      0030FF E4               [12]  695 	clr	a
      003100 A3               [24]  696 	inc	dptr
      003101 F0               [24]  697 	movx	@dptr,a
                                    698 ;--------------------------------------------------------
                                    699 ; Home
                                    700 ;--------------------------------------------------------
                                    701 	.area HOME    (CODE)
                                    702 	.area HOME    (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; code
                                    705 ;--------------------------------------------------------
                                    706 	.area CSEG    (CODE)
                                    707 ;------------------------------------------------------------
                                    708 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    709 ;------------------------------------------------------------
                                    710 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    711 ;------------------------------------------------------------
                                    712 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    713 ;	-----------------------------------------
                           000007   714 	ar7 = 0x07
                           000006   715 	ar6 = 0x06
                           000005   716 	ar5 = 0x05
                           000004   717 	ar4 = 0x04
                           000003   718 	ar3 = 0x03
                           000002   719 	ar2 = 0x02
                           000001   720 	ar1 = 0x01
                           000000   721 	ar0 = 0x00
                                    722 ;	 function extract_mod_bits
                                    723 ;	-----------------------------------------
      00A2E8                        724 _extract_mod_bits:
      00A2E8 12 38 79         [24]  725 	lcall	_ak820_outline_0113
      00A2EB 90 0C 2A         [24]  726 	mov	dptr,#_extract_mod_bits_code_10000_623
      00A2EE 12 38 7E         [24]  727 	lcall	_ak820_outline_0114
                                    728 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A2F1 90 0C 2A         [24]  729 	mov	dptr,#_extract_mod_bits_code_10000_623
      00A2F4 E0               [24]  730 	movx	a,@dptr
      00A2F5 A3               [24]  731 	inc	dptr
      00A2F6 E0               [24]  732 	movx	a,@dptr
                                    733 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A2F7 FF               [12]  734 	mov	r7,a
      00A2F8 60 05            [24]  735 	jz	00101$
      00A2FA EF               [12]  736 	mov	a,r7
      00A2FB 24 E0            [12]  737 	add	a,#0xff - 0x1f
      00A2FD 50 04            [24]  738 	jnc	00102$
                                    739 ;	free result
      00A2FF                        740 00101$:
      00A2FF 75 82 00         [24]  741 	mov	dpl, #0x00
      00A302 22               [24]  742 	ret
      00A303                        743 00102$:
                                    744 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A303 EF               [12]  745 	mov	a,r7
      00A304 30 E4 07         [24]  746 	jnb	acc.4,00106$
      00A307 EF               [12]  747 	mov	a,r7
      00A308 C4               [12]  748 	swap	a
      00A309 54 F0            [12]  749 	anl	a,#0xf0
      00A30B FE               [12]  750 	mov	r6,a
      00A30C 80 02            [24]  751 	sjmp	00107$
      00A30E                        752 00106$:
      00A30E 8F 06            [24]  753 	mov	ar6,r7
      00A310                        754 00107$:
      00A310 8E 82            [24]  755 	mov	dpl, r6
                                    756 ;	quantum/quantum.c:143: }
      00A312 22               [24]  757 	ret
                                    758 ;------------------------------------------------------------
                                    759 ;Allocation info for local variables in function 'do_code16'
                                    760 ;------------------------------------------------------------
                                    761 ;f             Allocated with name '_do_code16_PARM_2'
                                    762 ;code          Allocated with name '_do_code16_code_10000_626'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function register_code16
                                    767 ;	-----------------------------------------
      00A313                        768 _register_code16:
      00A313 12 38 79         [24]  769 	lcall	_ak820_outline_0113
      00A316 90 0C 2C         [24]  770 	mov	dptr,#_register_code16_code_10000_629
      00A319 12 38 7E         [24]  771 	lcall	_ak820_outline_0114
                                    772 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A31C 90 0C 2C         [24]  773 	mov	dptr,#_register_code16_code_10000_629
      00A31F 12 37 F1         [24]  774 	lcall	_ak820_outline_0005
      00A322 C0 07            [24]  775 	push	ar7
      00A324 C0 06            [24]  776 	push	ar6
      00A326 51 E8            [12]  777 	acall	_extract_mod_bits
      00A328 AD 82            [24]  778 	mov	r5, dpl
      00A32A D0 06            [24]  779 	pop	ar6
      00A32C D0 07            [24]  780 	pop	ar7
                                    781 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A32E 12 A1 1C         [24]  782 	lcall	_ak820_outline_0125
      00A331 40 07            [24]  783 	jc	00105$
      00A333 74 E7            [12]  784 	mov	a,#0xe7
      00A335 9E               [12]  785 	subb	a,r6
      00A336 E4               [12]  786 	clr	a
      00A337 9F               [12]  787 	subb	a,r7
      00A338 50 08            [24]  788 	jnc	00101$
                                    789 ;	free result
      00A33A                        790 00105$:
      00A33A 90 0C 2C         [24]  791 	mov	dptr,#_register_code16_code_10000_629
      00A33D 12 73 66         [24]  792 	lcall	_ak820_outline_0041
      00A340 70 07            [24]  793 	jnz	00102$
      00A342                        794 00101$:
                                    795 ;	quantum/quantum.c:153: register_mods(mods);
      00A342 8D 82            [24]  796 	mov	dpl, r5
      00A344 12 7C 02         [24]  797 	lcall	_register_mods
      00A347 80 05            [24]  798 	sjmp	00103$
      00A349                        799 00102$:
                                    800 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A349 8D 82            [24]  801 	mov	dpl, r5
      00A34B 12 7C 2A         [24]  802 	lcall	_register_weak_mods
      00A34E                        803 00103$:
                                    804 ;	quantum/quantum.c:157: register_code(code);
      00A34E 90 0C 2C         [24]  805 	mov	dptr,#_register_code16_code_10000_629
      00A351 E0               [24]  806 	movx	a,@dptr
      00A352 F5 82            [12]  807 	mov	dpl,a
                                    808 ;	quantum/quantum.c:167: }
      00A354 02 7A D1         [24]  809 	ljmp	_register_code
                                    810 ;------------------------------------------------------------
                                    811 ;Allocation info for local variables in function 'unregister_code16'
                                    812 ;------------------------------------------------------------
                                    813 ;code          Allocated with name '_unregister_code16_code_10000_634'
                                    814 ;mods          Allocated with name '_unregister_code16_mods_10000_635'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    817 ;	-----------------------------------------
                                    818 ;	 function unregister_code16
                                    819 ;	-----------------------------------------
      00A357                        820 _unregister_code16:
      00A357 12 38 79         [24]  821 	lcall	_ak820_outline_0113
      00A35A 90 0C 2E         [24]  822 	mov	dptr,#_unregister_code16_code_10000_634
      00A35D 12 38 7E         [24]  823 	lcall	_ak820_outline_0114
                                    824 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A360 90 0C 2E         [24]  825 	mov	dptr,#_unregister_code16_code_10000_634
      00A363 12 37 F1         [24]  826 	lcall	_ak820_outline_0005
      00A366 C0 07            [24]  827 	push	ar7
      00A368 C0 06            [24]  828 	push	ar6
      00A36A 51 E8            [12]  829 	acall	_extract_mod_bits
      00A36C AD 82            [24]  830 	mov	r5, dpl
      00A36E D0 06            [24]  831 	pop	ar6
                                    832 ;	quantum/quantum.c:172: unregister_code(code);
      00A370 8E 04            [24]  833 	mov	ar4,r6
      00A372 8C 82            [24]  834 	mov	dpl, r4
      00A374 C0 06            [24]  835 	push	ar6
      00A376 C0 05            [24]  836 	push	ar5
      00A378 12 7B 3E         [24]  837 	lcall	_unregister_code
      00A37B D0 05            [24]  838 	pop	ar5
      00A37D D0 06            [24]  839 	pop	ar6
      00A37F D0 07            [24]  840 	pop	ar7
                                    841 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A381 12 A1 1C         [24]  842 	lcall	_ak820_outline_0125
      00A384 40 07            [24]  843 	jc	00105$
      00A386 74 E7            [12]  844 	mov	a,#0xe7
      00A388 9E               [12]  845 	subb	a,r6
      00A389 E4               [12]  846 	clr	a
      00A38A 9F               [12]  847 	subb	a,r7
      00A38B 50 08            [24]  848 	jnc	00101$
                                    849 ;	free result
      00A38D                        850 00105$:
      00A38D 90 0C 2E         [24]  851 	mov	dptr,#_unregister_code16_code_10000_634
      00A390 12 73 66         [24]  852 	lcall	_ak820_outline_0041
      00A393 70 05            [24]  853 	jnz	00102$
      00A395                        854 00101$:
                                    855 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A395 8D 82            [24]  856 	mov	dpl, r5
      00A397 02 7C 16         [24]  857 	ljmp	_unregister_mods
      00A39A                        858 00102$:
                                    859 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A39A 8D 82            [24]  860 	mov	dpl, r5
                                    861 ;	quantum/quantum.c:187: }
      00A39C 02 7C 3E         [24]  862 	ljmp	_unregister_weak_mods
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'tap_code16_delay'
                                    865 ;------------------------------------------------------------
                                    866 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    867 ;code          Allocated with name '_tap_code16_delay_code_10000_639'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_20000_641'
                                    869 ;i             Allocated with name '_tap_code16_delay_i_50000_644'
                                    870 ;------------------------------------------------------------
                                    871 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function pre_process_record_kb
                                    874 ;	-----------------------------------------
      00A39F                        875 _pre_process_record_kb:
      00A39F 12 38 79         [24]  876 	lcall	_ak820_outline_0113
      00A3A2 90 0C 33         [24]  877 	mov	dptr,#_pre_process_record_kb_keycode_10000_648
      00A3A5 12 38 7E         [24]  878 	lcall	_ak820_outline_0114
                                    879 ;	quantum/quantum.c:211: return pre_process_record_user(keycode, record);
      00A3A8 90 0C 33         [24]  880 	mov	dptr,#_pre_process_record_kb_keycode_10000_648
      00A3AB 12 38 3E         [24]  881 	lcall	_ak820_outline_0055
      00A3AE 90 0C 30         [24]  882 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A3B1 12 A1 13         [24]  883 	lcall	_ak820_outline_0028
      00A3B4 90 0C 35         [24]  884 	mov	dptr,#_pre_process_record_user_PARM_2
      00A3B7 12 A6 E2         [24]  885 	lcall	_ak820_outline_0011
                                    886 ;	quantum/quantum.c:212: }
      00A3BA 61 BC            [12]  887 	ajmp	_pre_process_record_user
                                    888 ;------------------------------------------------------------
                                    889 ;Allocation info for local variables in function 'pre_process_record_user'
                                    890 ;------------------------------------------------------------
                                    891 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    892 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_650'
                                    893 ;------------------------------------------------------------
                                    894 ;	quantum/quantum.c:214: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    895 ;	-----------------------------------------
                                    896 ;	 function pre_process_record_user
                                    897 ;	-----------------------------------------
      00A3BC                        898 _pre_process_record_user:
                                    899 ;	quantum/quantum.c:215: return true;
      00A3BC 75 82 01         [24]  900 	mov	dpl, #0x01
                                    901 ;	quantum/quantum.c:216: }
      00A3BF 22               [24]  902 	ret
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'process_action_kb'
                                    905 ;------------------------------------------------------------
                                    906 ;record        Allocated with name '_process_action_kb_record_10000_652'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/quantum.c:218: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function process_action_kb
                                    911 ;	-----------------------------------------
      00A3C0                        912 _process_action_kb:
                                    913 ;	quantum/quantum.c:219: return true;
      00A3C0 75 82 01         [24]  914 	mov	dpl, #0x01
                                    915 ;	quantum/quantum.c:220: }
      00A3C3 22               [24]  916 	ret
                                    917 ;------------------------------------------------------------
                                    918 ;Allocation info for local variables in function 'process_record_kb'
                                    919 ;------------------------------------------------------------
                                    920 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    921 ;keycode       Allocated with name '_process_record_kb_keycode_10000_654'
                                    922 ;------------------------------------------------------------
                                    923 ;	quantum/quantum.c:222: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function process_record_kb
                                    926 ;	-----------------------------------------
      00A3C4                        927 _process_record_kb:
      00A3C4 12 38 79         [24]  928 	lcall	_ak820_outline_0113
      00A3C7 90 0C 3B         [24]  929 	mov	dptr,#_process_record_kb_keycode_10000_654
      00A3CA 12 38 7E         [24]  930 	lcall	_ak820_outline_0114
                                    931 ;	quantum/quantum.c:223: return process_record_user(keycode, record);
      00A3CD 90 0C 3B         [24]  932 	mov	dptr,#_process_record_kb_keycode_10000_654
      00A3D0 12 38 3E         [24]  933 	lcall	_ak820_outline_0055
      00A3D3 90 0C 38         [24]  934 	mov	dptr,#_process_record_kb_PARM_2
      00A3D6 12 A1 13         [24]  935 	lcall	_ak820_outline_0028
      00A3D9 90 0C 3D         [24]  936 	mov	dptr,#_process_record_user_PARM_2
      00A3DC 12 A6 E2         [24]  937 	lcall	_ak820_outline_0011
                                    938 ;	quantum/quantum.c:224: }
      00A3DF 61 E1            [12]  939 	ajmp	_process_record_user
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'process_record_user'
                                    942 ;------------------------------------------------------------
                                    943 ;record        Allocated with name '_process_record_user_PARM_2'
                                    944 ;keycode       Allocated with name '_process_record_user_keycode_10000_656'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/quantum.c:226: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function process_record_user
                                    949 ;	-----------------------------------------
      00A3E1                        950 _process_record_user:
                                    951 ;	quantum/quantum.c:227: return true;
      00A3E1 75 82 01         [24]  952 	mov	dpl, #0x01
                                    953 ;	quantum/quantum.c:228: }
      00A3E4 22               [24]  954 	ret
                                    955 ;------------------------------------------------------------
                                    956 ;Allocation info for local variables in function 'post_process_record_kb'
                                    957 ;------------------------------------------------------------
                                    958 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    959 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_658'
                                    960 ;------------------------------------------------------------
                                    961 ;	quantum/quantum.c:230: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    962 ;	-----------------------------------------
                                    963 ;	 function post_process_record_kb
                                    964 ;	-----------------------------------------
      00A3E5                        965 _post_process_record_kb:
      00A3E5 12 38 79         [24]  966 	lcall	_ak820_outline_0113
      00A3E8 90 0C 43         [24]  967 	mov	dptr,#_post_process_record_kb_keycode_10000_658
      00A3EB 12 38 7E         [24]  968 	lcall	_ak820_outline_0114
                                    969 ;	quantum/quantum.c:231: post_process_record_user(keycode, record);
      00A3EE 90 0C 43         [24]  970 	mov	dptr,#_post_process_record_kb_keycode_10000_658
      00A3F1 12 38 3E         [24]  971 	lcall	_ak820_outline_0055
      00A3F4 90 0C 40         [24]  972 	mov	dptr,#_post_process_record_kb_PARM_2
      00A3F7 12 A1 13         [24]  973 	lcall	_ak820_outline_0028
      00A3FA 90 0C 45         [24]  974 	mov	dptr,#_post_process_record_user_PARM_2
      00A3FD 12 A6 E2         [24]  975 	lcall	_ak820_outline_0011
                                    976 ;	quantum/quantum.c:232: }
      00A400 81 02            [24]  977 	ajmp	_post_process_record_user
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'post_process_record_user'
                                    980 ;------------------------------------------------------------
                                    981 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    982 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_660'
                                    983 ;------------------------------------------------------------
                                    984 ;	quantum/quantum.c:234: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    985 ;	-----------------------------------------
                                    986 ;	 function post_process_record_user
                                    987 ;	-----------------------------------------
      00A402                        988 _post_process_record_user:
      00A402 22               [24]  989 	ret
                                    990 ;------------------------------------------------------------
                                    991 ;Allocation info for local variables in function 'shutdown_quantum'
                                    992 ;------------------------------------------------------------
                                    993 ;i             Allocated with name '_shutdown_quantum_i_30000_666'
                                    994 ;------------------------------------------------------------
                                    995 ;	quantum/quantum.c:236: void shutdown_quantum(void) {
                                    996 ;	-----------------------------------------
                                    997 ;	 function shutdown_quantum
                                    998 ;	-----------------------------------------
      00A403                        999 _shutdown_quantum:
                                   1000 ;	quantum/quantum.c:237: clear_keyboard();
      00A403 12 7C 52         [24] 1001 	lcall	_clear_keyboard
                                   1002 ;	quantum/quantum.c:252: shutdown_user();
      00A406 D1 D4            [12] 1003 	acall	_shutdown_user
                                   1004 ;	quantum/quantum.c:253: wait_ms(250);
      00A408 7F FA            [12] 1005 	mov	r7,#0xfa
      00A40A                       1006 00106$:
      00A40A EF               [12] 1007 	mov	a,r7
      00A40B 60 09            [24] 1008 	jz	00108$
      00A40D 90 00 01         [24] 1009 	mov	dptr,#0x0001
      00A410 12 5E D4         [24] 1010 	lcall	_mDelaymS
      00A413 1F               [12] 1011 	dec	r7
      00A414 80 F4            [24] 1012 	sjmp	00106$
      00A416                       1013 00108$:
                                   1014 ;	quantum/quantum.c:258: }
      00A416 22               [24] 1015 	ret
                                   1016 ;------------------------------------------------------------
                                   1017 ;Allocation info for local variables in function 'reset_keyboard'
                                   1018 ;------------------------------------------------------------
                                   1019 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                   1020 ;	-----------------------------------------
                                   1021 ;	 function reset_keyboard
                                   1022 ;	-----------------------------------------
      00A417                       1023 _reset_keyboard:
                                   1024 ;	quantum/quantum.c:261: shutdown_quantum();
      00A417 91 03            [24] 1025 	acall	_shutdown_quantum
                                   1026 ;	quantum/quantum.c:262: bootloader_jump();
                                   1027 ;	quantum/quantum.c:263: }
      00A419 02 34 0E         [24] 1028 	ljmp	_bootloader_jump
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function soft_reset_keyboard
                                   1035 ;	-----------------------------------------
      00A41C                       1036 _soft_reset_keyboard:
                                   1037 ;	quantum/quantum.c:266: shutdown_quantum();
      00A41C 91 03            [24] 1038 	acall	_shutdown_quantum
                                   1039 ;	quantum/quantum.c:267: mcu_reset();
                                   1040 ;	quantum/quantum.c:268: }
      00A41E 02 34 01         [24] 1041 	ljmp	_mcu_reset
                                   1042 ;------------------------------------------------------------
                                   1043 ;Allocation info for local variables in function 'get_record_keycode'
                                   1044 ;------------------------------------------------------------
                                   1045 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1046 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_672'
                                   1047 ;record        Allocated with name '_get_record_keycode_record_10000_673'
                                   1048 ;------------------------------------------------------------
                                   1049 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1050 ;	-----------------------------------------
                                   1051 ;	 function get_record_keycode
                                   1052 ;	-----------------------------------------
      00A421                       1053 _get_record_keycode:
      00A421 12 43 1B         [24] 1054 	lcall	_ak820_outline_0038
      00A424 90 0C 49         [24] 1055 	mov	dptr,#_get_record_keycode_record_argument_10000_672
      00A427 12 38 26         [24] 1056 	lcall	_ak820_outline_0018
                                   1057 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A42A 90 0C 49         [24] 1058 	mov	dptr,#_get_record_keycode_record_argument_10000_672
      00A42D 12 37 FB         [24] 1059 	lcall	_ak820_outline_0008
                                   1060 ;	quantum/quantum.c:278: if (record->keycode) {
      00A430 4C               [12] 1061 	orl	a,r4
      00A431 60 04            [24] 1062 	jz	00102$
                                   1063 ;	quantum/quantum.c:279: return record->keycode;
      00A433 12 38 A0         [24] 1064 	lcall	_ak820_outline_0133
      00A436 22               [24] 1065 	ret
      00A437                       1066 00102$:
                                   1067 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A437 12 7C AD         [24] 1068 	lcall	_ak820_outline_0023
      00A43A 7A 00            [12] 1069 	mov	r2,#0x00
      00A43C 12 43 75         [24] 1070 	lcall	_ak820_outline_0152
      00A43F 12 38 0F         [24] 1071 	lcall	_ak820_outline_0010
      00A442 60 06            [24] 1072 	jz	00105$
      00A444 90 0C 48         [24] 1073 	mov	dptr,#_get_record_keycode_PARM_2
      00A447 E0               [24] 1074 	movx	a,@dptr
      00A448 70 04            [24] 1075 	jnz	00106$
      00A44A                       1076 00105$:
                                   1077 ;	assignBit
      00A44A C2 26            [12] 1078 	clr	_get_record_keycode_sloc0_1_0
      00A44C 80 02            [24] 1079 	sjmp	00107$
      00A44E                       1080 00106$:
                                   1081 ;	assignBit
      00A44E D2 26            [12] 1082 	setb	_get_record_keycode_sloc0_1_0
      00A450                       1083 00107$:
      00A450 90 09 BC         [24] 1084 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A453 A2 26            [12] 1085 	mov	c,_get_record_keycode_sloc0_1_0
      00A455 E4               [12] 1086 	clr	a
      00A456 33               [12] 1087 	rlc	a
      00A457 F0               [24] 1088 	movx	@dptr,a
      00A458 12 43 90         [24] 1089 	lcall	_ak820_outline_0197
                                   1090 ;	quantum/quantum.c:287: }
      00A45B 02 80 38         [24] 1091 	ljmp	_ak820_resolve_key
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'get_event_keycode'
                                   1094 ;------------------------------------------------------------
                                   1095 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1096 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_676'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function pre_process_record_quantum
                                   1101 ;	-----------------------------------------
      00A45E                       1102 _pre_process_record_quantum:
      00A45E 12 43 1B         [24] 1103 	lcall	_ak820_outline_0038
      00A461 90 0C 4C         [24] 1104 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_678
      00A464 12 38 26         [24] 1105 	lcall	_ak820_outline_0018
                                   1106 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A467 90 0C 4C         [24] 1107 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_678
      00A46A 12 38 3E         [24] 1108 	lcall	_ak820_outline_0055
                                   1109 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A46D 8E 03            [24] 1110 	mov	ar3,r6
      00A46F 8F 04            [24] 1111 	mov	ar4,r7
      00A471 7D 00            [12] 1112 	mov	r5,#0x00
      00A473 90 0C 48         [24] 1113 	mov	dptr,#_get_record_keycode_PARM_2
      00A476 74 01            [12] 1114 	mov	a,#0x01
      00A478 12 A2 E2         [24] 1115 	lcall	_ak820_outline_0106
      00A47B 8D F0            [24] 1116 	mov	b, r5
      00A47D C0 07            [24] 1117 	push	ar7
      00A47F C0 06            [24] 1118 	push	ar6
      00A481 91 21            [24] 1119 	acall	_get_record_keycode
      00A483 12 38 B0         [24] 1120 	lcall	_ak820_outline_0153
      00A486 D0 06            [24] 1121 	pop	ar6
      00A488 D0 07            [24] 1122 	pop	ar7
                                   1123 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A48A 74 07            [12] 1124 	mov	a,#0x07
      00A48C 12 38 2E         [24] 1125 	lcall	_ak820_outline_0024
      00A48F 12 38 61         [24] 1126 	lcall	_ak820_outline_0078
                                   1127 ;	quantum/quantum.c:353: return pre_process_record_kb(keycode, record) &&
      00A492 90 0C 30         [24] 1128 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A495 12 A6 D5         [24] 1129 	lcall	_ak820_outline_0002
      00A498 C0 07            [24] 1130 	push	ar7
      00A49A C0 06            [24] 1131 	push	ar6
      00A49C 71 9F            [12] 1132 	acall	_pre_process_record_kb
      00A49E E5 82            [12] 1133 	mov	a, dpl
      00A4A0 D0 06            [24] 1134 	pop	ar6
      00A4A2 D0 07            [24] 1135 	pop	ar7
      00A4A4 60 0A            [24] 1136 	jz	00103$
                                   1137 ;	quantum/quantum.c:356: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A4A6 12 38 8A         [24] 1138 	lcall	_ak820_outline_0124
      00A4A9 12 36 41         [24] 1139 	lcall	_ak820_combo_process
      00A4AC E5 82            [12] 1140 	mov	a, dpl
      00A4AE 70 04            [24] 1141 	jnz	00104$
                                   1142 ;	quantum/quantum.c:361: true;
      00A4B0                       1143 00103$:
                                   1144 ;	assignBit
      00A4B0 C2 27            [12] 1145 	clr	_pre_process_record_quantum_sloc0_1_0
      00A4B2 80 02            [24] 1146 	sjmp	00105$
      00A4B4                       1147 00104$:
                                   1148 ;	assignBit
      00A4B4 D2 27            [12] 1149 	setb	_pre_process_record_quantum_sloc0_1_0
      00A4B6                       1150 00105$:
      00A4B6 A2 27            [12] 1151 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A4B8 12 38 BA         [24] 1152 	lcall	_ak820_outline_0159
                                   1153 ;	quantum/quantum.c:362: }
      00A4BB 22               [24] 1154 	ret
                                   1155 ;------------------------------------------------------------
                                   1156 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1157 ;------------------------------------------------------------
                                   1158 ;record        Allocated with name '_post_process_record_quantum_record_10000_680'
                                   1159 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_681'
                                   1160 ;------------------------------------------------------------
                                   1161 ;	quantum/quantum.c:365: void post_process_record_quantum(keyrecord_t *record) {
                                   1162 ;	-----------------------------------------
                                   1163 ;	 function post_process_record_quantum
                                   1164 ;	-----------------------------------------
      00A4BC                       1165 _post_process_record_quantum:
      00A4BC 12 43 1B         [24] 1166 	lcall	_ak820_outline_0038
      00A4BF 90 0C 4F         [24] 1167 	mov	dptr,#_post_process_record_quantum_record_10000_680
      00A4C2 12 38 26         [24] 1168 	lcall	_ak820_outline_0018
                                   1169 ;	quantum/quantum.c:366: uint16_t keycode = get_record_keycode(record, false);
      00A4C5 90 0C 4F         [24] 1170 	mov	dptr,#_post_process_record_quantum_record_10000_680
      00A4C8 12 49 34         [24] 1171 	lcall	_ak820_outline_0013
      00A4CB 90 0C 48         [24] 1172 	mov	dptr,#_get_record_keycode_PARM_2
      00A4CE E4               [12] 1173 	clr	a
      00A4CF 12 49 59         [24] 1174 	lcall	_ak820_outline_0033
      00A4D2 91 21            [24] 1175 	acall	_get_record_keycode
      00A4D4 12 43 64         [24] 1176 	lcall	_ak820_outline_0132
                                   1177 ;	quantum/quantum.c:367: post_process_record_kb(keycode, record);
      00A4D7 90 0C 4F         [24] 1178 	mov	dptr,#_post_process_record_quantum_record_10000_680
      00A4DA 12 A1 13         [24] 1179 	lcall	_ak820_outline_0028
      00A4DD 90 0C 40         [24] 1180 	mov	dptr,#_post_process_record_kb_PARM_2
      00A4E0 12 A6 E2         [24] 1181 	lcall	_ak820_outline_0011
                                   1182 ;	quantum/quantum.c:368: }
      00A4E3 61 E5            [12] 1183 	ajmp	_post_process_record_kb
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'process_record_quantum'
                                   1186 ;------------------------------------------------------------
                                   1187 ;record        Allocated with name '_process_record_quantum_record_10000_682'
                                   1188 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_683'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/quantum.c:370: bool process_record_quantum(keyrecord_t *record) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function process_record_quantum
                                   1193 ;	-----------------------------------------
      00A4E5                       1194 _process_record_quantum:
      00A4E5 12 43 1B         [24] 1195 	lcall	_ak820_outline_0038
      00A4E8 90 0C 52         [24] 1196 	mov	dptr,#_process_record_quantum_record_10000_682
      00A4EB 12 38 26         [24] 1197 	lcall	_ak820_outline_0018
                                   1198 ;	quantum/quantum.c:372: uint16_t keycode = get_record_keycode(record, false);
      00A4EE 90 0C 52         [24] 1199 	mov	dptr,#_process_record_quantum_record_10000_682
      00A4F1 12 49 34         [24] 1200 	lcall	_ak820_outline_0013
      00A4F4 90 0C 48         [24] 1201 	mov	dptr,#_get_record_keycode_PARM_2
      00A4F7 E4               [12] 1202 	clr	a
      00A4F8 12 49 59         [24] 1203 	lcall	_ak820_outline_0033
      00A4FB 91 21            [24] 1204 	acall	_get_record_keycode
      00A4FD 12 43 64         [24] 1205 	lcall	_ak820_outline_0132
                                   1206 ;	quantum/quantum.c:376: return process_record_quantum_helper(keycode, record);
      00A500 90 0C 52         [24] 1207 	mov	dptr,#_process_record_quantum_record_10000_682
      00A503 12 A1 13         [24] 1208 	lcall	_ak820_outline_0028
      00A506 90 0C 5A         [24] 1209 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A509 12 A6 E2         [24] 1210 	lcall	_ak820_outline_0011
                                   1211 ;	quantum/quantum.c:377: }
      00A50C A1 79            [24] 1212 	ajmp	_process_record_quantum_helper
                                   1213 ;------------------------------------------------------------
                                   1214 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1215 ;------------------------------------------------------------
                                   1216 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1217 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_684'
                                   1218 ;record        Allocated with name '_process_ak820_nkro_record_10000_685'
                                   1219 ;------------------------------------------------------------
                                   1220 ;	quantum/quantum.c:394: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1221 ;	-----------------------------------------
                                   1222 ;	 function process_ak820_nkro
                                   1223 ;	-----------------------------------------
      00A50E                       1224 _process_ak820_nkro:
      00A50E 12 38 79         [24] 1225 	lcall	_ak820_outline_0113
      00A511 90 0C 58         [24] 1226 	mov	dptr,#_process_ak820_nkro_keycode_10000_684
      00A514 12 38 7E         [24] 1227 	lcall	_ak820_outline_0114
                                   1228 ;	quantum/quantum.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A517 90 0C 55         [24] 1229 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A51A 12 38 3E         [24] 1230 	lcall	_ak820_outline_0055
                                   1231 ;	quantum/quantum.c:400: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A51D 90 0C 58         [24] 1232 	mov	dptr,#_process_ak820_nkro_keycode_10000_684
      00A520 12 38 55         [24] 1233 	lcall	_ak820_outline_0063
      00A523 C3               [12] 1234 	clr	c
      00A524 EC               [12] 1235 	mov	a,r4
      00A525 94 11            [12] 1236 	subb	a,#0x11
      00A527 ED               [12] 1237 	mov	a,r5
      00A528 94 70            [12] 1238 	subb	a,#0x70
      00A52A 40 08            [24] 1239 	jc	00101$
      00A52C 74 13            [12] 1240 	mov	a,#0x13
      00A52E 9C               [12] 1241 	subb	a,r4
      00A52F 74 70            [12] 1242 	mov	a,#0x70
      00A531 9D               [12] 1243 	subb	a,r5
      00A532 50 04            [24] 1244 	jnc	00102$
                                   1245 ;	free result
      00A534                       1246 00101$:
      00A534 75 82 01         [24] 1247 	mov	dpl, #0x01
      00A537 22               [24] 1248 	ret
      00A538                       1249 00102$:
                                   1250 ;	quantum/quantum.c:401: if (record->event.pressed) {
      00A538 12 38 0F         [24] 1251 	lcall	_ak820_outline_0010
      00A53B 60 38            [24] 1252 	jz	00105$
                                   1253 ;	quantum/quantum.c:402: clear_keyboard();
      00A53D C0 05            [24] 1254 	push	ar5
      00A53F C0 04            [24] 1255 	push	ar4
      00A541 12 7C 52         [24] 1256 	lcall	_clear_keyboard
      00A544 D0 04            [24] 1257 	pop	ar4
      00A546 D0 05            [24] 1258 	pop	ar5
                                   1259 ;	quantum/quantum.c:403: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A548 BC 13 14         [24] 1260 	cjne	r4,#0x13,00108$
      00A54B BD 70 11         [24] 1261 	cjne	r5,#0x70,00108$
      00A54E 90 0B 0E         [24] 1262 	mov	dptr,#_keymap_config
      00A551 E0               [24] 1263 	movx	a,@dptr
      00A552 23               [12] 1264 	rl	a
      00A553 54 01            [12] 1265 	anl	a,#0x01
      00A555 B4 01 00         [24] 1266 	cjne	a,#0x01,00136$
      00A558                       1267 00136$:
      00A558 92 28            [24] 1268 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A55A E4               [12] 1269 	clr	a
      00A55B 33               [12] 1270 	rlc	a
      00A55C FF               [12] 1271 	mov	r7,a
      00A55D 80 09            [24] 1272 	sjmp	00109$
      00A55F                       1273 00108$:
      00A55F E4               [12] 1274 	clr	a
      00A560 BC 11 04         [24] 1275 	cjne	r4,#0x11,00137$
      00A563 BD 70 01         [24] 1276 	cjne	r5,#0x70,00137$
      00A566 04               [12] 1277 	inc	a
      00A567                       1278 00137$:
      00A567 FF               [12] 1279 	mov	r7,a
      00A568                       1280 00109$:
                                   1281 ;	assignBit
      00A568 EF               [12] 1282 	mov	a,r7
      00A569 24 FF            [12] 1283 	add	a,#0xff
      00A56B E4               [12] 1284 	clr	a
      00A56C 33               [12] 1285 	rlc	a
      00A56D 90 0B 0E         [24] 1286 	mov	dptr,#_keymap_config
      00A570 13               [12] 1287 	rrc	a
      00A571 E0               [24] 1288 	movx	a,@dptr
      00A572 92 E7            [24] 1289 	mov	acc.7,c
      00A574 F0               [24] 1290 	movx	@dptr,a
      00A575                       1291 00105$:
                                   1292 ;	quantum/quantum.c:405: return false;
      00A575 75 82 00         [24] 1293 	mov	dpl, #0x00
                                   1294 ;	quantum/quantum.c:406: }
      00A578 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1298 ;------------------------------------------------------------
                                   1299 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1300 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_689'
                                   1301 ;record        Allocated with name '_process_record_quantum_helper_record_10000_690'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/quantum.c:409: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function process_record_quantum_helper
                                   1306 ;	-----------------------------------------
      00A579                       1307 _process_record_quantum_helper:
      00A579 12 38 79         [24] 1308 	lcall	_ak820_outline_0113
      00A57C 90 0C 5D         [24] 1309 	mov	dptr,#_process_record_quantum_helper_keycode_10000_689
      00A57F 12 38 7E         [24] 1310 	lcall	_ak820_outline_0114
                                   1311 ;	quantum/quantum.c:411: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A582 90 0C 5A         [24] 1312 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A585 12 38 3E         [24] 1313 	lcall	_ak820_outline_0055
                                   1314 ;	quantum/quantum.c:454: process_ak820_nkro(keycode, record) &&
      00A588 90 0C 5D         [24] 1315 	mov	dptr,#_process_record_quantum_helper_keycode_10000_689
      00A58B 12 38 55         [24] 1316 	lcall	_ak820_outline_0063
      00A58E 90 0C 55         [24] 1317 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A591 12 A6 D5         [24] 1318 	lcall	_ak820_outline_0002
      00A594 C0 07            [24] 1319 	push	ar7
      00A596 C0 06            [24] 1320 	push	ar6
      00A598 C0 05            [24] 1321 	push	ar5
      00A59A C0 04            [24] 1322 	push	ar4
      00A59C B1 0E            [24] 1323 	acall	_process_ak820_nkro
      00A59E E5 82            [12] 1324 	mov	a, dpl
      00A5A0 D0 04            [24] 1325 	pop	ar4
      00A5A2 D0 05            [24] 1326 	pop	ar5
      00A5A4 D0 06            [24] 1327 	pop	ar6
      00A5A6 D0 07            [24] 1328 	pop	ar7
      00A5A8 70 02            [24] 1329 	jnz	00204$
      00A5AA C1 97            [12] 1330 	ajmp	00101$
      00A5AC                       1331 00204$:
                                   1332 ;	quantum/quantum.c:465: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A5AC 90 0C 13         [24] 1333 	mov	dptr,#_process_last_key_PARM_2
      00A5AF 12 A6 D5         [24] 1334 	lcall	_ak820_outline_0002
      00A5B2 C0 07            [24] 1335 	push	ar7
      00A5B4 C0 06            [24] 1336 	push	ar6
      00A5B6 C0 05            [24] 1337 	push	ar5
      00A5B8 C0 04            [24] 1338 	push	ar4
      00A5BA 11 4E            [12] 1339 	acall	_process_last_key
      00A5BC E5 82            [12] 1340 	mov	a, dpl
      00A5BE D0 04            [24] 1341 	pop	ar4
      00A5C0 D0 05            [24] 1342 	pop	ar5
      00A5C2 D0 06            [24] 1343 	pop	ar6
      00A5C4 D0 07            [24] 1344 	pop	ar7
      00A5C6 70 02            [24] 1345 	jnz	00205$
      00A5C8 C1 97            [12] 1346 	ajmp	00101$
      00A5CA                       1347 00205$:
      00A5CA 90 0C 19         [24] 1348 	mov	dptr,#_process_repeat_key_PARM_2
      00A5CD 12 A6 D5         [24] 1349 	lcall	_ak820_outline_0002
      00A5D0 C0 07            [24] 1350 	push	ar7
      00A5D2 C0 06            [24] 1351 	push	ar6
      00A5D4 C0 05            [24] 1352 	push	ar5
      00A5D6 C0 04            [24] 1353 	push	ar4
      00A5D8 11 CA            [12] 1354 	acall	_process_repeat_key
      00A5DA E5 82            [12] 1355 	mov	a, dpl
      00A5DC D0 04            [24] 1356 	pop	ar4
      00A5DE D0 05            [24] 1357 	pop	ar5
      00A5E0 D0 06            [24] 1358 	pop	ar6
      00A5E2 D0 07            [24] 1359 	pop	ar7
      00A5E4 70 02            [24] 1360 	jnz	00206$
      00A5E6 C1 97            [12] 1361 	ajmp	00101$
      00A5E8                       1362 00206$:
                                   1363 ;	quantum/quantum.c:474: process_record_via(keycode, record) &&
      00A5E8 90 0C 9A         [24] 1364 	mov	dptr,#_process_record_via_PARM_2
      00A5EB 12 A6 D5         [24] 1365 	lcall	_ak820_outline_0002
      00A5EE C0 07            [24] 1366 	push	ar7
      00A5F0 C0 06            [24] 1367 	push	ar6
      00A5F2 C0 05            [24] 1368 	push	ar5
      00A5F4 C0 04            [24] 1369 	push	ar4
      00A5F6 12 AB DC         [24] 1370 	lcall	_process_record_via
      00A5F9 E5 82            [12] 1371 	mov	a, dpl
      00A5FB D0 04            [24] 1372 	pop	ar4
      00A5FD D0 05            [24] 1373 	pop	ar5
      00A5FF D0 06            [24] 1374 	pop	ar6
      00A601 D0 07            [24] 1375 	pop	ar7
      00A603 70 02            [24] 1376 	jnz	00207$
      00A605 C1 97            [12] 1377 	ajmp	00101$
      00A607                       1378 00207$:
                                   1379 ;	quantum/quantum.c:484: process_record_kb(keycode, record) &&
      00A607 90 0C 38         [24] 1380 	mov	dptr,#_process_record_kb_PARM_2
      00A60A 12 A6 D5         [24] 1381 	lcall	_ak820_outline_0002
      00A60D C0 07            [24] 1382 	push	ar7
      00A60F C0 06            [24] 1383 	push	ar6
      00A611 C0 05            [24] 1384 	push	ar5
      00A613 C0 04            [24] 1385 	push	ar4
      00A615 71 C4            [12] 1386 	acall	_process_record_kb
      00A617 E5 82            [12] 1387 	mov	a, dpl
      00A619 D0 04            [24] 1388 	pop	ar4
      00A61B D0 05            [24] 1389 	pop	ar5
      00A61D D0 06            [24] 1390 	pop	ar6
      00A61F D0 07            [24] 1391 	pop	ar7
      00A621 70 02            [24] 1392 	jnz	00208$
      00A623 C1 97            [12] 1393 	ajmp	00101$
      00A625                       1394 00208$:
                                   1395 ;	quantum/quantum.c:507: process_caps_word(keycode, record) &&
      00A625 90 0B FA         [24] 1396 	mov	dptr,#_process_caps_word_PARM_2
      00A628 12 A6 D5         [24] 1397 	lcall	_ak820_outline_0002
      00A62B C0 07            [24] 1398 	push	ar7
      00A62D C0 06            [24] 1399 	push	ar6
      00A62F C0 05            [24] 1400 	push	ar5
      00A631 C0 04            [24] 1401 	push	ar4
      00A633 12 9D 50         [24] 1402 	lcall	_process_caps_word
      00A636 E5 82            [12] 1403 	mov	a, dpl
      00A638 D0 04            [24] 1404 	pop	ar4
      00A63A D0 05            [24] 1405 	pop	ar5
      00A63C D0 06            [24] 1406 	pop	ar6
      00A63E D0 07            [24] 1407 	pop	ar7
      00A640 60 55            [24] 1408 	jz	00101$
                                   1409 ;	quantum/quantum.c:537: process_grave_esc(keycode, record) &&
      00A642 90 0B FF         [24] 1410 	mov	dptr,#_process_grave_esc_PARM_2
      00A645 12 A6 D5         [24] 1411 	lcall	_ak820_outline_0002
      00A648 C0 07            [24] 1412 	push	ar7
      00A64A C0 06            [24] 1413 	push	ar6
      00A64C C0 05            [24] 1414 	push	ar5
      00A64E C0 04            [24] 1415 	push	ar4
      00A650 12 9E 6D         [24] 1416 	lcall	_process_grave_esc
      00A653 E5 82            [12] 1417 	mov	a, dpl
      00A655 D0 04            [24] 1418 	pop	ar4
      00A657 D0 05            [24] 1419 	pop	ar5
      00A659 D0 06            [24] 1420 	pop	ar6
      00A65B D0 07            [24] 1421 	pop	ar7
      00A65D 60 38            [24] 1422 	jz	00101$
                                   1423 ;	quantum/quantum.c:540: process_rgb(keycode, record) &&
      00A65F 90 0C 1E         [24] 1424 	mov	dptr,#_process_rgb_PARM_2
      00A662 12 A6 D5         [24] 1425 	lcall	_ak820_outline_0002
      00A665 C0 07            [24] 1426 	push	ar7
      00A667 C0 06            [24] 1427 	push	ar6
      00A669 C0 05            [24] 1428 	push	ar5
      00A66B C0 04            [24] 1429 	push	ar4
      00A66D 31 24            [12] 1430 	acall	_process_rgb
      00A66F E5 82            [12] 1431 	mov	a, dpl
      00A671 D0 04            [24] 1432 	pop	ar4
      00A673 D0 05            [24] 1433 	pop	ar5
      00A675 D0 06            [24] 1434 	pop	ar6
      00A677 D0 07            [24] 1435 	pop	ar7
      00A679 60 1C            [24] 1436 	jz	00101$
                                   1437 ;	quantum/quantum.c:552: process_tri_layer(keycode, record) &&
      00A67B 90 0C 24         [24] 1438 	mov	dptr,#_process_tri_layer_PARM_2
      00A67E 12 A6 D5         [24] 1439 	lcall	_ak820_outline_0002
      00A681 C0 07            [24] 1440 	push	ar7
      00A683 C0 06            [24] 1441 	push	ar6
      00A685 C0 05            [24] 1442 	push	ar5
      00A687 C0 04            [24] 1443 	push	ar4
      00A689 31 D5            [12] 1444 	acall	_process_tri_layer
      00A68B E5 82            [12] 1445 	mov	a, dpl
      00A68D D0 04            [24] 1446 	pop	ar4
      00A68F D0 05            [24] 1447 	pop	ar5
      00A691 D0 06            [24] 1448 	pop	ar6
      00A693 D0 07            [24] 1449 	pop	ar7
      00A695 70 04            [24] 1450 	jnz	00102$
                                   1451 ;	quantum/quantum.c:554: true)) {
      00A697                       1452 00101$:
                                   1453 ;	quantum/quantum.c:555: return false;
      00A697 75 82 00         [24] 1454 	mov	dpl, #0x00
      00A69A 22               [24] 1455 	ret
      00A69B                       1456 00102$:
                                   1457 ;	quantum/quantum.c:558: if (record->event.pressed) {
      00A69B 12 9E 60         [24] 1458 	lcall	_ak820_outline_0102
      00A69E 60 2D            [24] 1459 	jz	00117$
                                   1460 ;	quantum/quantum.c:559: switch (keycode) {
      00A6A0 BC 00 05         [24] 1461 	cjne	r4,#0x00,00214$
      00A6A3 BD 7C 02         [24] 1462 	cjne	r5,#0x7c,00214$
      00A6A6 80 10            [24] 1463 	sjmp	00112$
      00A6A8                       1464 00214$:
      00A6A8 BC 01 05         [24] 1465 	cjne	r4,#0x01,00215$
      00A6AB BD 7C 02         [24] 1466 	cjne	r5,#0x7c,00215$
      00A6AE 80 0E            [24] 1467 	sjmp	00113$
      00A6B0                       1468 00215$:
                                   1469 ;	quantum/quantum.c:561: case QK_BOOTLOADER:
      00A6B0 BC 03 1A         [24] 1470 	cjne	r4,#0x03,00117$
      00A6B3 BD 7C 17         [24] 1471 	cjne	r5,#0x7c,00117$
      00A6B6 80 0C            [24] 1472 	sjmp	00114$
      00A6B8                       1473 00112$:
                                   1474 ;	quantum/quantum.c:562: reset_keyboard();
      00A6B8 91 17            [24] 1475 	acall	_reset_keyboard
                                   1476 ;	quantum/quantum.c:563: return false;
      00A6BA 75 82 00         [24] 1477 	mov	dpl, #0x00
                                   1478 ;	quantum/quantum.c:564: case QK_REBOOT:
      00A6BD 22               [24] 1479 	ret
      00A6BE                       1480 00113$:
                                   1481 ;	quantum/quantum.c:565: soft_reset_keyboard();
      00A6BE 91 1C            [24] 1482 	acall	_soft_reset_keyboard
                                   1483 ;	quantum/quantum.c:566: return false;
      00A6C0 75 82 00         [24] 1484 	mov	dpl, #0x00
                                   1485 ;	quantum/quantum.c:578: case QK_CLEAR_EEPROM:
      00A6C3 22               [24] 1486 	ret
      00A6C4                       1487 00114$:
                                   1488 ;	quantum/quantum.c:585: eeconfig_disable();
      00A6C4 12 94 D2         [24] 1489 	lcall	_eeconfig_disable
                                   1490 ;	quantum/quantum.c:586: soft_reset_keyboard();
      00A6C7 91 1C            [24] 1491 	acall	_soft_reset_keyboard
                                   1492 ;	quantum/quantum.c:588: return false;
      00A6C9 75 82 00         [24] 1493 	mov	dpl, #0x00
                                   1494 ;	quantum/quantum.c:643: }
      00A6CC 22               [24] 1495 	ret
      00A6CD                       1496 00117$:
                                   1497 ;	quantum/quantum.c:646: return process_action_kb(record);
      00A6CD 7D 00            [12] 1498 	mov	r5,#0x00
      00A6CF 12 49 7E         [24] 1499 	lcall	_ak820_outline_0061
                                   1500 ;	quantum/quantum.c:647: }
      00A6D2 61 C0            [12] 1501 	ajmp	_process_action_kb
                                   1502 ;------------------------------------------------------------
                                   1503 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1504 ;------------------------------------------------------------
                                   1505 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_697'
                                   1506 ;------------------------------------------------------------
                                   1507 ;	quantum/quantum.c:649: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1508 ;	-----------------------------------------
                                   1509 ;	 function shutdown_user
                                   1510 ;	-----------------------------------------
      00A6D4                       1511 _shutdown_user:
      00A6D4 22               [24] 1512 	ret
                                   1513 ;------------------------------------------------------------
                                   1514 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1515 ;------------------------------------------------------------
                                   1516 ;	quantum/quantum.c:665: void suspend_power_down_quantum(void) {
                                   1517 ;	-----------------------------------------
                                   1518 	.area CSEG    (CODE)
                                   1519 	.area CONST   (CODE)
                                   1520 	.area XINIT   (CODE)
                                   1521 	.area CABS    (ABS,CODE)
                                   1522 
                                   1523 ; Experimental exact instruction outlining.
                                   1524 	.globl _ak820_outline_0002
                                   1525 	.globl _ak820_outline_0005
                                   1526 	.globl _ak820_outline_0008
                                   1527 	.globl _ak820_outline_0010
                                   1528 	.globl _ak820_outline_0011
                                   1529 	.globl _ak820_outline_0013
                                   1530 	.globl _ak820_outline_0018
                                   1531 	.globl _ak820_outline_0023
                                   1532 	.globl _ak820_outline_0024
                                   1533 	.globl _ak820_outline_0028
                                   1534 	.globl _ak820_outline_0033
                                   1535 	.globl _ak820_outline_0038
                                   1536 	.globl _ak820_outline_0041
                                   1537 	.globl _ak820_outline_0055
                                   1538 	.globl _ak820_outline_0061
                                   1539 	.globl _ak820_outline_0063
                                   1540 	.globl _ak820_outline_0078
                                   1541 	.globl _ak820_outline_0102
                                   1542 	.globl _ak820_outline_0106
                                   1543 	.globl _ak820_outline_0113
                                   1544 	.globl _ak820_outline_0114
                                   1545 	.globl _ak820_outline_0124
                                   1546 	.globl _ak820_outline_0125
                                   1547 	.globl _ak820_outline_0132
                                   1548 	.globl _ak820_outline_0133
                                   1549 	.globl _ak820_outline_0152
                                   1550 	.globl _ak820_outline_0153
                                   1551 	.globl _ak820_outline_0159
                                   1552 	.globl _ak820_outline_0197
                                   1553 
                                   1554 	.area CSEG (CODE)
                                   1555 ; function ak820_outline_0002
      00A6D5                       1556 _ak820_outline_0002:
      00A6D5 EE               [12] 1557 	mov	a,r6
      00A6D6 F0               [24] 1558 	movx	@dptr,a
      00A6D7 EF               [12] 1559 	mov	a,r7
      00A6D8 A3               [24] 1560 	inc	dptr
      00A6D9 F0               [24] 1561 	movx	@dptr,a
      00A6DA E4               [12] 1562 	clr	a
      00A6DB A3               [24] 1563 	inc	dptr
      00A6DC F0               [24] 1564 	movx	@dptr,a
      00A6DD 8C 82            [24] 1565 	mov	dpl,r4
      00A6DF 8D 83            [24] 1566 	mov	dph,r5
      00A6E1 22               [24] 1567 	ret
                                   1568 
                                   1569 	.area CSEG (CODE)
                                   1570 ; function ak820_outline_0011
      00A6E2                       1571 _ak820_outline_0011:
      00A6E2 EB               [12] 1572 	mov	a,r3
      00A6E3 F0               [24] 1573 	movx	@dptr,a
      00A6E4 EC               [12] 1574 	mov	a,r4
      00A6E5 A3               [24] 1575 	inc	dptr
      00A6E6 F0               [24] 1576 	movx	@dptr,a
      00A6E7 ED               [12] 1577 	mov	a,r5
      00A6E8 A3               [24] 1578 	inc	dptr
      00A6E9 F0               [24] 1579 	movx	@dptr,a
      00A6EA 8E 82            [24] 1580 	mov	dpl,r6
      00A6EC 8F 83            [24] 1581 	mov	dph,r7
      00A6EE 22               [24] 1582 	ret
