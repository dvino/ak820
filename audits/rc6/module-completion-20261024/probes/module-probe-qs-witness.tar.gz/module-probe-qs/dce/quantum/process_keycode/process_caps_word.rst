                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_caps_word
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _clear_weak_mods
                                     12 	.globl _get_mods
                                     13 	.globl _send_keyboard_report
                                     14 	.globl _is_caps_word_on
                                     15 	.globl _caps_word_toggle
                                     16 	.globl _caps_word_off
                                     17 	.globl _caps_word_reset_idle_timer
                                     18 	.globl _caps_word_press_user
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _process_caps_word_PARM_2
                                    263 	.globl _process_caps_word
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
                                    542 ;--------------------------------------------------------
                                    543 ; paged external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area PSEG    (PAG,XDATA)
                                    546 ;--------------------------------------------------------
                                    547 ; uninitialized external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area XSEG    (XDATA)
      000BFA                        550 _process_caps_word_PARM_2:
      000BFA                        551 	.ds 3
      000BFD                        552 _process_caps_word_keycode_10000_248:
      000BFD                        553 	.ds 2
                                    554 ;--------------------------------------------------------
                                    555 ; absolute external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area XABS    (ABS,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; initialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XISEG   (XDATA)
                                    562 	.area HOME    (CODE)
                                    563 	.area GSINIT0 (CODE)
                                    564 	.area GSINIT1 (CODE)
                                    565 	.area GSINIT2 (CODE)
                                    566 	.area GSINIT3 (CODE)
                                    567 	.area GSINIT4 (CODE)
                                    568 	.area GSINIT5 (CODE)
                                    569 	.area GSINIT  (CODE)
                                    570 	.area GSFINAL (CODE)
                                    571 	.area CSEG    (CODE)
                                    572 ;--------------------------------------------------------
                                    573 ; global & static initialisations
                                    574 ;--------------------------------------------------------
                                    575 	.area HOME    (CODE)
                                    576 	.area GSINIT  (CODE)
                                    577 	.area GSFINAL (CODE)
                                    578 	.area GSINIT  (CODE)
                                    579 ;--------------------------------------------------------
                                    580 ; Home
                                    581 ;--------------------------------------------------------
                                    582 	.area HOME    (CODE)
                                    583 	.area HOME    (CODE)
                                    584 ;--------------------------------------------------------
                                    585 ; code
                                    586 ;--------------------------------------------------------
                                    587 	.area CSEG    (CODE)
                                    588 ;------------------------------------------------------------
                                    589 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    590 ;------------------------------------------------------------
                                    591 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    592 ;------------------------------------------------------------
                                    593 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    594 ;	-----------------------------------------
                           000007   595 	ar7 = 0x07
                           000006   596 	ar6 = 0x06
                           000005   597 	ar5 = 0x05
                           000004   598 	ar4 = 0x04
                           000003   599 	ar3 = 0x03
                           000002   600 	ar2 = 0x02
                           000001   601 	ar1 = 0x01
                           000000   602 	ar0 = 0x00
                                    603 ;	 function process_caps_word
                                    604 ;	-----------------------------------------
      009D50                        605 _process_caps_word:
      009D50 12 38 79         [24]  606 	lcall	_ak820_outline_0113
      009D53 90 0B FD         [24]  607 	mov	dptr,#_process_caps_word_keycode_10000_248
      009D56 12 38 7E         [24]  608 	lcall	_ak820_outline_0114
                                    609 ;	quantum/process_keycode/process_caps_word.c:78: keyrecord_t __xdata* record = (keyrecord_t __xdata*)event_record;
      009D59 90 0B FA         [24]  610 	mov	dptr,#_process_caps_word_PARM_2
      009D5C 12 38 3E         [24]  611 	lcall	_ak820_outline_0055
                                    612 ;	quantum/process_keycode/process_caps_word.c:82: if (keycode == QK_CAPS_WORD_TOGGLE) {
      009D5F 90 0B FD         [24]  613 	mov	dptr,#_process_caps_word_keycode_10000_248
      009D62 12 38 55         [24]  614 	lcall	_ak820_outline_0063
      009D65 BC 73 0F         [24]  615 	cjne	r4,#0x73,00104$
      009D68 BD 7C 0C         [24]  616 	cjne	r5,#0x7c,00104$
                                    617 ;	quantum/process_keycode/process_caps_word.c:83: if (record->event.pressed) {
      009D6B 12 9E 60         [24]  618 	lcall	_ak820_outline_0102
      009D6E 60 03            [24]  619 	jz	00102$
                                    620 ;	quantum/process_keycode/process_caps_word.c:84: caps_word_toggle();
      009D70 12 2F 74         [24]  621 	lcall	_caps_word_toggle
      009D73                        622 00102$:
                                    623 ;	quantum/process_keycode/process_caps_word.c:86: return false;
      009D73 75 82 00         [24]  624 	mov	dpl, #0x00
      009D76 22               [24]  625 	ret
      009D77                        626 00104$:
                                    627 ;	quantum/process_keycode/process_caps_word.c:97: const uint8_t mods = get_mods();
      009D77 12 85 ED         [24]  628 	lcall	_get_mods
      009D7A AB 82            [24]  629 	mov	r3, dpl
                                    630 ;	quantum/process_keycode/process_caps_word.c:100: if (!is_caps_word_on()) {
      009D7C C0 07            [24]  631 	push	ar7
      009D7E C0 06            [24]  632 	push	ar6
      009D80 C0 05            [24]  633 	push	ar5
      009D82 C0 04            [24]  634 	push	ar4
      009D84 C0 03            [24]  635 	push	ar3
      009D86 12 2F 80         [24]  636 	lcall	_is_caps_word_on
      009D89 E5 82            [12]  637 	mov	a, dpl
      009D8B D0 03            [24]  638 	pop	ar3
      009D8D D0 04            [24]  639 	pop	ar4
      009D8F D0 05            [24]  640 	pop	ar5
      009D91 D0 06            [24]  641 	pop	ar6
      009D93 D0 07            [24]  642 	pop	ar7
      009D95 70 04            [24]  643 	jnz	00106$
                                    644 ;	quantum/process_keycode/process_caps_word.c:147: return true;
      009D97 75 82 01         [24]  645 	mov	dpl, #0x01
      009D9A 22               [24]  646 	ret
      009D9B                        647 00106$:
                                    648 ;	quantum/process_keycode/process_caps_word.c:151: caps_word_reset_idle_timer();
      009D9B C0 07            [24]  649 	push	ar7
      009D9D C0 06            [24]  650 	push	ar6
      009D9F C0 05            [24]  651 	push	ar5
      009DA1 C0 04            [24]  652 	push	ar4
      009DA3 C0 03            [24]  653 	push	ar3
      009DA5 12 2F 28         [24]  654 	lcall	_caps_word_reset_idle_timer
      009DA8 D0 03            [24]  655 	pop	ar3
      009DAA D0 04            [24]  656 	pop	ar4
      009DAC D0 05            [24]  657 	pop	ar5
      009DAE D0 06            [24]  658 	pop	ar6
      009DB0 D0 07            [24]  659 	pop	ar7
                                    660 ;	quantum/process_keycode/process_caps_word.c:155: if (!record->event.pressed) {
      009DB2 12 38 0F         [24]  661 	lcall	_ak820_outline_0010
      009DB5 70 04            [24]  662 	jnz	00108$
                                    663 ;	quantum/process_keycode/process_caps_word.c:156: return true;
      009DB7 75 82 01         [24]  664 	mov	dpl, #0x01
      009DBA 22               [24]  665 	ret
      009DBB                        666 00108$:
                                    667 ;	quantum/process_keycode/process_caps_word.c:159: if (!(mods & ~(MOD_MASK_SHIFT | MOD_BIT(KC_RALT)))) {
      009DBB EB               [12]  668 	mov	a,r3
      009DBC 54 9D            [12]  669 	anl	a,#0x9d
      009DBE 60 02            [24]  670 	jz	00227$
      009DC0 C1 59            [24]  671 	ajmp	00127$
      009DC2                        672 00227$:
                                    673 ;	quantum/process_keycode/process_caps_word.c:162: if ( (keycode >= QK_MOMENTARY && keycode <= QK_MOMENTARY_MAX) ||
      009DC2 C3               [12]  674 	clr	c
      009DC3 EC               [12]  675 	mov	a,r4
      009DC4 94 20            [12]  676 	subb	a,#0x20
      009DC6 ED               [12]  677 	mov	a,r5
      009DC7 94 52            [12]  678 	subb	a,#0x52
      009DC9 40 08            [24]  679 	jc	00113$
      009DCB 74 3F            [12]  680 	mov	a,#0x3f
      009DCD 9C               [12]  681 	subb	a,r4
      009DCE 74 52            [12]  682 	mov	a,#0x52
      009DD0 9D               [12]  683 	subb	a,r5
      009DD1 50 66            [24]  684 	jnc	00109$
                                    685 ;	free result
      009DD3                        686 00113$:
                                    687 ;	quantum/process_keycode/process_caps_word.c:163: (keycode >= QK_TO               && keycode <= QK_TO_MAX) ||
      009DD3 74 AE            [12]  688 	mov	a,#0x100 - 0x52
      009DD5 2D               [12]  689 	add	a,r5
      009DD6 50 09            [24]  690 	jnc	00115$
      009DD8 C3               [12]  691 	clr	c
      009DD9 74 1F            [12]  692 	mov	a,#0x1f
      009DDB 9C               [12]  693 	subb	a,r4
      009DDC 74 52            [12]  694 	mov	a,#0x52
      009DDE 9D               [12]  695 	subb	a,r5
      009DDF 50 58            [24]  696 	jnc	00109$
                                    697 ;	free result
      009DE1                        698 00115$:
                                    699 ;	quantum/process_keycode/process_caps_word.c:164: (keycode >= QK_TOGGLE_LAYER     && keycode <= QK_TOGGLE_LAYER_MAX) ||
      009DE1 C3               [12]  700 	clr	c
      009DE2 EC               [12]  701 	mov	a,r4
      009DE3 94 60            [12]  702 	subb	a,#0x60
      009DE5 ED               [12]  703 	mov	a,r5
      009DE6 94 52            [12]  704 	subb	a,#0x52
      009DE8 40 08            [24]  705 	jc	00117$
      009DEA 74 7F            [12]  706 	mov	a,#0x7f
      009DEC 9C               [12]  707 	subb	a,r4
      009DED 74 52            [12]  708 	mov	a,#0x52
      009DEF 9D               [12]  709 	subb	a,r5
      009DF0 50 47            [24]  710 	jnc	00109$
                                    711 ;	free result
      009DF2                        712 00117$:
                                    713 ;	quantum/process_keycode/process_caps_word.c:165: (keycode >= QK_LAYER_TAP_TOGGLE && keycode <= QK_LAYER_TAP_TOGGLE_MAX) ||
      009DF2 C3               [12]  714 	clr	c
      009DF3 EC               [12]  715 	mov	a,r4
      009DF4 94 C0            [12]  716 	subb	a,#0xc0
      009DF6 ED               [12]  717 	mov	a,r5
      009DF7 94 52            [12]  718 	subb	a,#0x52
      009DF9 40 08            [24]  719 	jc	00119$
      009DFB 74 DF            [12]  720 	mov	a,#0xdf
      009DFD 9C               [12]  721 	subb	a,r4
      009DFE 74 52            [12]  722 	mov	a,#0x52
      009E00 9D               [12]  723 	subb	a,r5
      009E01 50 36            [24]  724 	jnc	00109$
                                    725 ;	free result
      009E03                        726 00119$:
                                    727 ;	quantum/process_keycode/process_caps_word.c:166: (keycode >= QK_ONE_SHOT_LAYER   && keycode <= QK_ONE_SHOT_LAYER_MAX) ||
      009E03 C3               [12]  728 	clr	c
      009E04 EC               [12]  729 	mov	a,r4
      009E05 94 80            [12]  730 	subb	a,#0x80
      009E07 ED               [12]  731 	mov	a,r5
      009E08 94 52            [12]  732 	subb	a,#0x52
      009E0A 40 08            [24]  733 	jc	00121$
      009E0C 74 9F            [12]  734 	mov	a,#0x9f
      009E0E 9C               [12]  735 	subb	a,r4
      009E0F 74 52            [12]  736 	mov	a,#0x52
      009E11 9D               [12]  737 	subb	a,r5
      009E12 50 25            [24]  738 	jnc	00109$
                                    739 ;	free result
      009E14                        740 00121$:
                                    741 ;	quantum/process_keycode/process_caps_word.c:167: (keycode >= QK_TRI_LAYER_LOWER  && keycode <= QK_TRI_LAYER_UPPER) ||
      009E14 C3               [12]  742 	clr	c
      009E15 EC               [12]  743 	mov	a,r4
      009E16 94 77            [12]  744 	subb	a,#0x77
      009E18 ED               [12]  745 	mov	a,r5
      009E19 94 7C            [12]  746 	subb	a,#0x7c
      009E1B 40 08            [24]  747 	jc	00122$
      009E1D 74 78            [12]  748 	mov	a,#0x78
      009E1F 9C               [12]  749 	subb	a,r4
      009E20 74 7C            [12]  750 	mov	a,#0x7c
      009E22 9D               [12]  751 	subb	a,r5
      009E23 50 14            [24]  752 	jnc	00109$
                                    753 ;	free result
      009E25                        754 00122$:
                                    755 ;	quantum/process_keycode/process_caps_word.c:169: (keycode == KC_RALT) ||
      009E25 90 0B FD         [24]  756 	mov	dptr,#_process_caps_word_keycode_10000_248
      009E28 12 4E 82         [24]  757 	lcall	_ak820_outline_0009
      009E2B BC E6 05         [24]  758 	cjne	r4,#0xe6,00240$
      009E2E BD 00 02         [24]  759 	cjne	r5,#0x00,00240$
      009E31 80 06            [24]  760 	sjmp	00109$
      009E33                        761 00240$:
                                    762 ;	quantum/process_keycode/process_caps_word.c:170: (keycode == OSM(MOD_RALT)) )
      009E33 BC B4 07         [24]  763 	cjne	r4,#0xb4,00110$
      009E36 BD 52 04         [24]  764 	cjne	r5,#0x52,00110$
      009E39                        765 00109$:
                                    766 ;	quantum/process_keycode/process_caps_word.c:171: return true;
      009E39 75 82 01         [24]  767 	mov	dpl, #0x01
      009E3C 22               [24]  768 	ret
      009E3D                        769 00110$:
                                    770 ;	quantum/process_keycode/process_caps_word.c:241: clear_weak_mods();
      009E3D C0 07            [24]  771 	push	ar7
      009E3F C0 06            [24]  772 	push	ar6
      009E41 12 86 32         [24]  773 	lcall	_clear_weak_mods
      009E44 D0 06            [24]  774 	pop	ar6
      009E46 D0 07            [24]  775 	pop	ar7
                                    776 ;	quantum/process_keycode/process_caps_word.c:243: if (caps_word_press_user(keycode)) {
      009E48 12 38 8A         [24]  777 	lcall	_ak820_outline_0124
      009E4B 12 2F 88         [24]  778 	lcall	_caps_word_press_user
      009E4E E5 82            [12]  779 	mov	a, dpl
      009E50 60 07            [24]  780 	jz	00127$
                                    781 ;	quantum/process_keycode/process_caps_word.c:249: send_keyboard_report();
      009E52 12 85 82         [24]  782 	lcall	_send_keyboard_report
                                    783 ;	quantum/process_keycode/process_caps_word.c:250: return true;
      009E55 75 82 01         [24]  784 	mov	dpl, #0x01
      009E58 22               [24]  785 	ret
      009E59                        786 00127$:
                                    787 ;	quantum/process_keycode/process_caps_word.c:254: caps_word_off();
      009E59 12 2F 59         [24]  788 	lcall	_caps_word_off
                                    789 ;	quantum/process_keycode/process_caps_word.c:258: return true;
      009E5C 75 82 01         [24]  790 	mov	dpl, #0x01
                                    791 ;	quantum/process_keycode/process_caps_word.c:259: }
      009E5F 22               [24]  792 	ret
                                    793 	.area CSEG    (CODE)
                                    794 	.area CONST   (CODE)
                                    795 	.area XINIT   (CODE)
                                    796 	.area CABS    (ABS,CODE)
                                    797 
                                    798 ; Experimental exact instruction outlining.
                                    799 	.globl _ak820_outline_0009
                                    800 	.globl _ak820_outline_0010
                                    801 	.globl _ak820_outline_0055
                                    802 	.globl _ak820_outline_0063
                                    803 	.globl _ak820_outline_0102
                                    804 	.globl _ak820_outline_0113
                                    805 	.globl _ak820_outline_0114
                                    806 	.globl _ak820_outline_0124
                                    807 
                                    808 	.area CSEG (CODE)
                                    809 ; function ak820_outline_0102
      009E60                        810 _ak820_outline_0102:
      009E60 74 05            [12]  811 	mov	a,#0x05
      009E62 2E               [12]  812 	add	a,r6
      009E63 FA               [12]  813 	mov	r2,a
      009E64 E4               [12]  814 	clr	a
      009E65 3F               [12]  815 	addc	a,r7
      009E66 FB               [12]  816 	mov	r3,a
      009E67 8A 82            [24]  817 	mov	dpl,r2
      009E69 8B 83            [24]  818 	mov	dph,r3
      009E6B E0               [24]  819 	movx	a,@dptr
      009E6C 22               [24]  820 	ret
