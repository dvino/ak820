                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      000051                        535 _fast_set_leds_sloc0_1_0:
      000051                        536 	.ds 2
      000053                        537 _fast_set_leds_sloc1_1_0:
      000053                        538 	.ds 2
      000055                        539 _vialrgb_get_value_sloc0_1_0:
      000055                        540 	.ds 2
      000057                        541 _vialrgb_get_value_sloc1_1_0:
      000057                        542 	.ds 2
      000059                        543 _vialrgb_set_value_sloc0_1_0:
      000059                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CDD                        569 _g_direct_mode_colors::
      000CDD                        570 	.ds 246
      000DD3                        571 _get_supported_PARM_2:
      000DD3                        572 	.ds 1
      000DD4                        573 _get_supported_args_10000_255:
      000DD4                        574 	.ds 2
      000DD6                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DD6                        576 	.ds 2
      000DD8                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DD8                        578 	.ds 2
      000DDA                        579 _set_mode_mode_10000_275:
      000DDA                        580 	.ds 2
      000DDC                        581 _get_matrix_pos_for_led_PARM_2:
      000DDC                        582 	.ds 2
      000DDE                        583 _get_matrix_pos_for_led_led_10000_280:
      000DDE                        584 	.ds 2
      000DE0                        585 _fast_set_leds_PARM_2:
      000DE0                        586 	.ds 1
      000DE1                        587 _fast_set_leds_args_10000_282:
      000DE1                        588 	.ds 2
      000DE3                        589 _fast_set_leds_first_index_10001_285:
      000DE3                        590 	.ds 2
      000DE5                        591 _fast_set_leds_num_leds_10001_285:
      000DE5                        592 	.ds 1
      000DE6                        593 _vialrgb_get_value_PARM_2:
      000DE6                        594 	.ds 1
      000DE7                        595 _vialrgb_get_value_data_10000_291:
      000DE7                        596 	.ds 3
      000DEA                        597 _vialrgb_set_value_PARM_2:
      000DEA                        598 	.ds 1
      000DEB                        599 _vialrgb_set_value_data_10000_302:
      000DEB                        600 	.ds 3
      000DEE                        601 _vialrgb_save_PARM_2:
      000DEE                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B8DA                        654 _get_supported:
      00B8DA 12 38 79         [24]  655 	lcall	_ak820_outline_0113
      00B8DD 90 0D D4         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B8E0 12 38 7E         [24]  657 	lcall	_ak820_outline_0114
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B8E3 90 0D D4         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B8E6 12 37 F1         [24]  660 	lcall	_ak820_outline_0005
      00B8E9 E0               [24]  661 	movx	a,@dptr
      00B8EA FD               [12]  662 	mov	r5,a
      00B8EB 7C 00            [12]  663 	mov	r4,#0x00
      00B8ED 12 38 83         [24]  664 	lcall	_ak820_outline_0118
      00B8F0 FA               [12]  665 	mov	r2,a
      00B8F1 E4               [12]  666 	clr	a
      00B8F2 12 43 75         [24]  667 	lcall	_ak820_outline_0152
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B8F5 90 0D D3         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B8F8 E0               [24]  670 	movx	a,@dptr
      00B8F9 FB               [12]  671 	mov	r3,a
      00B8FA 7A 00            [12]  672 	mov	r2,#0x00
      00B8FC                        673 00107$:
      00B8FC C3               [12]  674 	clr	c
      00B8FD EA               [12]  675 	mov	a,r2
      00B8FE 9B               [12]  676 	subb	a,r3
      00B8FF 50 0A            [24]  677 	jnc	00101$
      00B901 EA               [12]  678 	mov	a,r2
      00B902 12 38 2E         [24]  679 	lcall	_ak820_outline_0024
      00B905 74 FF            [12]  680 	mov	a,#0xff
      00B907 F0               [24]  681 	movx	@dptr,a
      00B908 0A               [12]  682 	inc	r2
      00B909 80 F1            [24]  683 	sjmp	00107$
      00B90B                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B90B 8D 06            [24]  686 	mov	ar6,r5
      00B90D 8C 07            [24]  687 	mov	ar7,r4
      00B90F 8B 05            [24]  688 	mov	ar5,r3
      00B911 90 0D D4         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B914 12 38 AA         [24]  690 	lcall	_ak820_outline_0150
      00B917 7A 00            [12]  691 	mov	r2,#0x00
      00B919                        692 00110$:
      00B919 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B91C                        694 00159$:
      00B91C 50 45            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B91E EA               [12]  697 	mov	a,r2
      00B91F 75 F0 02         [24]  698 	mov	b,#0x02
      00B922 A4               [48]  699 	mul	ab
      00B923 24 60            [12]  700 	add	a, #_supported_modes
      00B925 F5 82            [12]  701 	mov	dpl,a
      00B927 74 C6            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B929 12 5D 1D         [24]  703 	lcall	_ak820_outline_0115
      00B92C F8               [12]  704 	mov	r0,a
      00B92D 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B92F C3               [12]  707 	clr	c
      00B930 EE               [12]  708 	mov	a,r6
      00B931 98               [12]  709 	subb	a,r0
      00B932 EF               [12]  710 	mov	a,r7
      00B933 99               [12]  711 	subb	a,r1
      00B934 50 2A            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B936 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B939                        715 00162$:
      00B939 40 25            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B93B C0 06            [24]  718 	push	ar6
      00B93D C0 07            [24]  719 	push	ar7
      00B93F 88 07            [24]  720 	mov	ar7,r0
      00B941 12 33 FC         [24]  721 	lcall	_ak820_outline_0130
      00B944 EF               [12]  722 	mov	a,r7
      00B945 12 A2 E2         [24]  723 	lcall	_ak820_outline_0106
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B948 A3               [24]  725 	inc	dptr
      00B949 89 00            [24]  726 	mov	ar0,r1
      00B94B E8               [12]  727 	mov	a,r0
      00B94C F0               [24]  728 	movx	@dptr,a
                                    729 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B94D 1D               [12]  730 	dec	r5
      00B94E 1D               [12]  731 	dec	r5
                                    732 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B94F 74 02            [12]  733 	mov	a,#0x02
      00B951 2B               [12]  734 	add	a, r3
      00B952 FB               [12]  735 	mov	r3,a
      00B953 E4               [12]  736 	clr	a
      00B954 3C               [12]  737 	addc	a, r4
      00B955 FC               [12]  738 	mov	r4,a
      00B956 90 0D D4         [24]  739 	mov	dptr,#_get_supported_args_10000_255
      00B959 12 38 6D         [24]  740 	lcall	_ak820_outline_0099
                                    741 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B95C D0 07            [24]  742 	pop	ar7
      00B95E D0 06            [24]  743 	pop	ar6
                                    744 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B960                        745 00111$:
                                    746 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B960 0A               [12]  747 	inc	r2
      00B961 80 B6            [24]  748 	sjmp	00110$
      00B963                        749 00127$:
      00B963 90 0D D4         [24]  750 	mov	dptr,#_get_supported_args_10000_255
      00B966 12 38 6D         [24]  751 	lcall	_ak820_outline_0099
                                    752 ;	quantum/vialrgb.c:55: }
      00B969 22               [24]  753 	ret
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    756 ;------------------------------------------------------------
                                    757 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    758 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    759 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    760 ;------------------------------------------------------------
                                    761 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    762 ;	-----------------------------------------
                                    763 ;	 function qmk_id_to_vialrgb_id
                                    764 ;	-----------------------------------------
      00B96A                        765 _qmk_id_to_vialrgb_id:
      00B96A 12 38 79         [24]  766 	lcall	_ak820_outline_0113
      00B96D 90 0D D6         [24]  767 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B970 12 38 7E         [24]  768 	lcall	_ak820_outline_0114
                                    769 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B973 90 0D D6         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B976 12 38 3E         [24]  771 	lcall	_ak820_outline_0055
      00B979 7D 00            [12]  772 	mov	r5,#0x00
      00B97B                        773 00105$:
      00B97B BD 07 00         [24]  774 	cjne	r5,#0x07,00130$
      00B97E                        775 00130$:
      00B97E 50 19            [24]  776 	jnc	00103$
                                    777 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B980 12 BD 95         [24]  778 	lcall	_ak820_outline_0051
      00B983 A3               [24]  779 	inc	dptr
      00B984 E4               [12]  780 	clr	a
      00B985 93               [24]  781 	movc	a,@a+dptr
                                    782 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B986 7A 00            [12]  783 	mov	r2,#0x00
      00B988 B5 06 0B         [24]  784 	cjne	a,ar6,00106$
      00B98B EA               [12]  785 	mov	a,r2
      00B98C B5 07 07         [24]  786 	cjne	a,ar7,00106$
                                    787 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B98F 12 33 FC         [24]  788 	lcall	_ak820_outline_0130
      00B992 12 BD C1         [24]  789 	lcall	_ak820_outline_0155
      00B995 22               [24]  790 	ret
      00B996                        791 00106$:
                                    792 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B996 0D               [12]  793 	inc	r5
      00B997 80 E2            [24]  794 	sjmp	00105$
      00B999                        795 00103$:
                                    796 ;	quantum/vialrgb.c:63: return 0;
      00B999 90 00 00         [24]  797 	mov	dptr,#0x0000
                                    798 ;	quantum/vialrgb.c:64: }
      00B99C 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    802 ;------------------------------------------------------------
                                    803 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    804 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    805 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function vialrgb_id_to_qmk_id
                                    810 ;	-----------------------------------------
      00B99D                        811 _vialrgb_id_to_qmk_id:
      00B99D 12 38 79         [24]  812 	lcall	_ak820_outline_0113
      00B9A0 90 0D D8         [24]  813 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B9A3 12 38 7E         [24]  814 	lcall	_ak820_outline_0114
                                    815 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B9A6 90 0D D8         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B9A9 12 38 3E         [24]  817 	lcall	_ak820_outline_0055
      00B9AC 7D 00            [12]  818 	mov	r5,#0x00
      00B9AE                        819 00105$:
      00B9AE BD 07 00         [24]  820 	cjne	r5,#0x07,00130$
      00B9B1                        821 00130$:
      00B9B1 50 19            [24]  822 	jnc	00103$
                                    823 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B9B3 12 BD 95         [24]  824 	lcall	_ak820_outline_0051
      00B9B6 E4               [12]  825 	clr	a
      00B9B7 93               [24]  826 	movc	a,@a+dptr
                                    827 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B9B8 7A 00            [12]  828 	mov	r2,#0x00
      00B9BA B5 06 0C         [24]  829 	cjne	a,ar6,00106$
      00B9BD EA               [12]  830 	mov	a,r2
      00B9BE B5 07 08         [24]  831 	cjne	a,ar7,00106$
                                    832 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B9C1 12 33 FC         [24]  833 	lcall	_ak820_outline_0130
      00B9C4 A3               [24]  834 	inc	dptr
      00B9C5 12 BD C1         [24]  835 	lcall	_ak820_outline_0155
      00B9C8 22               [24]  836 	ret
      00B9C9                        837 00106$:
                                    838 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B9C9 0D               [12]  839 	inc	r5
      00B9CA 80 E2            [24]  840 	sjmp	00105$
      00B9CC                        841 00103$:
                                    842 ;	quantum/vialrgb.c:72: return 0;
      00B9CC 90 00 00         [24]  843 	mov	dptr,#0x0000
                                    844 ;	quantum/vialrgb.c:73: }
      00B9CF 22               [24]  845 	ret
                                    846 ;------------------------------------------------------------
                                    847 ;Allocation info for local variables in function 'get_mode'
                                    848 ;------------------------------------------------------------
                                    849 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    850 ;	-----------------------------------------
                                    851 ;	 function get_mode
                                    852 ;	-----------------------------------------
      00B9D0                        853 _get_mode:
                                    854 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B9D0 12 5B 20         [24]  855 	lcall	_rgb_matrix_is_enabled
      00B9D3 E5 82            [12]  856 	mov	a, dpl
      00B9D5 70 04            [24]  857 	jnz	00102$
                                    858 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B9D7 90 00 00         [24]  859 	mov	dptr,#0x0000
      00B9DA 22               [24]  860 	ret
      00B9DB                        861 00102$:
                                    862 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B9DB 12 5B 26         [24]  863 	lcall	_rgb_matrix_get_mode
      00B9DE 7E 00            [12]  864 	mov	r6,#0x00
      00B9E0 8E 83            [24]  865 	mov	dph, r6
                                    866 ;	quantum/vialrgb.c:80: }
      00B9E2 21 6A            [12]  867 	ajmp	_qmk_id_to_vialrgb_id
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'set_mode'
                                    870 ;------------------------------------------------------------
                                    871 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function set_mode
                                    876 ;	-----------------------------------------
      00B9E4                        877 _set_mode:
      00B9E4 12 38 79         [24]  878 	lcall	_ak820_outline_0113
      00B9E7 90 0D DA         [24]  879 	mov	dptr,#_set_mode_mode_10000_275
      00B9EA 12 38 7E         [24]  880 	lcall	_ak820_outline_0114
                                    881 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B9ED 90 0D DA         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00B9F0 12 38 3E         [24]  883 	lcall	_ak820_outline_0055
      00B9F3 90 0D DA         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B9F6 12 73 66         [24]  885 	lcall	_ak820_outline_0041
      00B9F9 70 03            [24]  886 	jnz	00102$
                                    887 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B9FB 02 5B 73         [24]  888 	ljmp	_rgb_matrix_disable_noeeprom
      00B9FE                        889 00102$:
                                    890 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B9FE C0 07            [24]  891 	push	ar7
      00BA00 C0 06            [24]  892 	push	ar6
      00BA02 12 5B 62         [24]  893 	lcall	_rgb_matrix_enable_noeeprom
      00BA05 D0 06            [24]  894 	pop	ar6
      00BA07 D0 07            [24]  895 	pop	ar7
                                    896 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00BA09 12 38 8A         [24]  897 	lcall	_ak820_outline_0124
      00BA0C 31 9D            [12]  898 	acall	_vialrgb_id_to_qmk_id
                                    899 ;	quantum/vialrgb.c:90: }
      00BA0E 02 5B 7C         [24]  900 	ljmp	_rgb_matrix_mode_noeeprom
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    903 ;------------------------------------------------------------
                                    904 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    905 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    906 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function get_matrix_pos_for_led
                                    911 ;	-----------------------------------------
      00BA11                        912 _get_matrix_pos_for_led:
      00BA11 12 38 79         [24]  913 	lcall	_ak820_outline_0113
      00BA14 90 0D DE         [24]  914 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BA17 12 38 7E         [24]  915 	lcall	_ak820_outline_0114
                                    916 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00BA1A 90 0D DE         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00BA1D 12 38 3E         [24]  918 	lcall	_ak820_outline_0055
      00BA20 EE               [12]  919 	mov	a,r6
      00BA21 24 67            [12]  920 	add	a, #_ak820_rgb_slots
      00BA23 F5 82            [12]  921 	mov	dpl,a
      00BA25 EF               [12]  922 	mov	a,r7
      00BA26 34 C0            [12]  923 	addc	a, #(_ak820_rgb_slots >> 8)
      00BA28 F5 83            [12]  924 	mov	dph,a
      00BA2A E4               [12]  925 	clr	a
      00BA2B 93               [24]  926 	movc	a,@a+dptr
      00BA2C FF               [12]  927 	mov	r7,a
                                    928 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00BA2D 90 0D DC         [24]  929 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BA30 12 38 67         [24]  930 	lcall	_ak820_outline_0090
      00BA33 EF               [12]  931 	mov	a,r7
      00BA34 12 5D 4D         [24]  932 	lcall	_ak820_outline_0196
      00BA37 12 86 6D         [24]  933 	lcall	_ak820_outline_0128
                                    934 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00BA3A 12 38 A5         [24]  935 	lcall	_ak820_outline_0141
      00BA3D A3               [24]  936 	inc	dptr
      00BA3E 53 07 07         [24]  937 	anl	ar7,#0x07
      00BA41 EF               [12]  938 	mov	a,r7
      00BA42 F0               [24]  939 	movx	@dptr,a
                                    940 ;	quantum/vialrgb.c:110: }
      00BA43 22               [24]  941 	ret
                                    942 ;------------------------------------------------------------
                                    943 ;Allocation info for local variables in function 'fast_set_leds'
                                    944 ;------------------------------------------------------------
                                    945 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    946 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    947 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    948 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    949 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    950 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    951 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    952 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    953 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    954 ;------------------------------------------------------------
                                    955 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    956 ;	-----------------------------------------
                                    957 ;	 function fast_set_leds
                                    958 ;	-----------------------------------------
      00BA44                        959 _fast_set_leds:
      00BA44 12 38 79         [24]  960 	lcall	_ak820_outline_0113
      00BA47 90 0D E1         [24]  961 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA4A 12 38 7E         [24]  962 	lcall	_ak820_outline_0114
                                    963 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00BA4D 90 0D E0         [24]  964 	mov	dptr,#_fast_set_leds_PARM_2
      00BA50 E0               [24]  965 	movx	a,@dptr
      00BA51 FF               [12]  966 	mov	r7,a
      00BA52 BF 03 00         [24]  967 	cjne	r7,#0x03,00159$
      00BA55                        968 00159$:
      00BA55 50 01            [24]  969 	jnc	00102$
      00BA57 22               [24]  970 	ret
      00BA58                        971 00102$:
                                    972 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BA58 90 0D E1         [24]  973 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA5B E0               [24]  974 	movx	a,@dptr
      00BA5C FD               [12]  975 	mov	r5,a
      00BA5D A3               [24]  976 	inc	dptr
      00BA5E E0               [24]  977 	movx	a,@dptr
      00BA5F 12 49 85         [24]  978 	lcall	_ak820_outline_0069
      00BA62 FC               [12]  979 	mov	r4,a
      00BA63 7B 00            [12]  980 	mov	r3,#0x00
      00BA65 12 38 A5         [24]  981 	lcall	_ak820_outline_0141
      00BA68 A3               [24]  982 	inc	dptr
      00BA69 E0               [24]  983 	movx	a,@dptr
      00BA6A FA               [12]  984 	mov	r2,a
      00BA6B 79 00            [12]  985 	mov	r1,#0x00
      00BA6D 90 0D E3         [24]  986 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BA70 E9               [12]  987 	mov	a,r1
      00BA71 4C               [12]  988 	orl	a,r4
      00BA72 F0               [24]  989 	movx	@dptr,a
      00BA73 EA               [12]  990 	mov	a,r2
      00BA74 4B               [12]  991 	orl	a,r3
      00BA75 A3               [24]  992 	inc	dptr
      00BA76 F0               [24]  993 	movx	@dptr,a
                                    994 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00BA77 12 38 A5         [24]  995 	lcall	_ak820_outline_0141
      00BA7A A3               [24]  996 	inc	dptr
      00BA7B A3               [24]  997 	inc	dptr
      00BA7C E0               [24]  998 	movx	a,@dptr
      00BA7D 90 0D E5         [24]  999 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BA80 F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	quantum/vialrgb.c:119: length -= 3;
      00BA81 EF               [12] 1002 	mov	a,r7
      00BA82 24 FD            [12] 1003 	add	a,#0xfd
      00BA84 90 0D E0         [24] 1004 	mov	dptr,#_fast_set_leds_PARM_2
      00BA87 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	quantum/vialrgb.c:120: args += 3;
      00BA88 90 0D E1         [24] 1007 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA8B 74 03            [12] 1008 	mov	a,#0x03
      00BA8D 2D               [12] 1009 	add	a, r5
      00BA8E F0               [24] 1010 	movx	@dptr,a
      00BA8F E4               [12] 1011 	clr	a
      00BA90 3E               [12] 1012 	addc	a, r6
      00BA91 A3               [24] 1013 	inc	dptr
      00BA92 F0               [24] 1014 	movx	@dptr,a
                                   1015 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00BA93 90 0D E5         [24] 1016 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BA96 E0               [24] 1017 	movx	a,@dptr
      00BA97 FF               [12] 1018 	mov	r7,a
      00BA98 75 F0 03         [24] 1019 	mov	b,#0x03
      00BA9B A4               [48] 1020 	mul	ab
      00BA9C FE               [12] 1021 	mov	r6,a
      00BA9D AD F0            [24] 1022 	mov	r5,b
      00BA9F 90 0D E0         [24] 1023 	mov	dptr,#_fast_set_leds_PARM_2
      00BAA2 E0               [24] 1024 	movx	a,@dptr
      00BAA3 FB               [12] 1025 	mov	r3,a
      00BAA4 7C 00            [12] 1026 	mov	r4,#0x00
      00BAA6 C3               [12] 1027 	clr	c
      00BAA7 EB               [12] 1028 	mov	a,r3
      00BAA8 9E               [12] 1029 	subb	a,r6
      00BAA9 EC               [12] 1030 	mov	a,r4
      00BAAA 9D               [12] 1031 	subb	a,r5
      00BAAB 40 13            [24] 1032 	jc	00103$
                                   1033 ;	free result
      00BAAD 90 0D E3         [24] 1034 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BAB0 12 38 67         [24] 1035 	lcall	_ak820_outline_0090
      00BAB3 8D 03            [24] 1036 	mov	ar3,r5
      00BAB5 8E 04            [24] 1037 	mov	ar4,r6
      00BAB7 C3               [12] 1038 	clr	c
      00BAB8 EB               [12] 1039 	mov	a,r3
      00BAB9 94 52            [12] 1040 	subb	a,#0x52
      00BABB EC               [12] 1041 	mov	a,r4
      00BABC 94 00            [12] 1042 	subb	a,#0x00
      00BABE 40 01            [24] 1043 	jc	00104$
      00BAC0                       1044 00103$:
      00BAC0 22               [24] 1045 	ret
      00BAC1                       1046 00104$:
                                   1047 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00BAC1 74 52            [12] 1048 	mov	a,#0x52
      00BAC3 C3               [12] 1049 	clr	c
      00BAC4 9D               [12] 1050 	subb	a,r5
      00BAC5 FB               [12] 1051 	mov	r3,a
      00BAC6 E4               [12] 1052 	clr	a
      00BAC7 9E               [12] 1053 	subb	a,r6
      00BAC8 FC               [12] 1054 	mov	r4,a
      00BAC9 7A 00            [12] 1055 	mov	r2,#0x00
      00BACB C3               [12] 1056 	clr	c
      00BACC EB               [12] 1057 	mov	a,r3
      00BACD 9F               [12] 1058 	subb	a,r7
      00BACE EC               [12] 1059 	mov	a,r4
      00BACF 9A               [12] 1060 	subb	a,r2
      00BAD0 50 08            [24] 1061 	jnc	00127$
                                   1062 ;	free result
      00BAD2 90 0D E5         [24] 1063 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BAD5 74 52            [12] 1064 	mov	a,#0x52
      00BAD7 C3               [12] 1065 	clr	c
      00BAD8 9D               [12] 1066 	subb	a,r5
      00BAD9 F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BADA                       1069 00127$:
      00BADA 90 0D E5         [24] 1070 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BADD E0               [24] 1071 	movx	a,@dptr
      00BADE FF               [12] 1072 	mov	r7,a
      00BADF 90 0D E3         [24] 1073 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BAE2 12 38 67         [24] 1074 	lcall	_ak820_outline_0090
      00BAE5 7C 00            [12] 1075 	mov	r4,#0x00
      00BAE7                       1076 00110$:
      00BAE7 C3               [12] 1077 	clr	c
      00BAE8 EC               [12] 1078 	mov	a,r4
      00BAE9 9F               [12] 1079 	subb	a,r7
      00BAEA 40 01            [24] 1080 	jc	00164$
      00BAEC 22               [24] 1081 	ret
      00BAED                       1082 00164$:
                                   1083 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00BAED C0 07            [24] 1084 	push	ar7
      00BAEF 90 0D FD         [24] 1085 	mov	dptr,#__mulint_PARM_2
      00BAF2 12 43 6F         [24] 1086 	lcall	_ak820_outline_0146
      00BAF5 90 00 03         [24] 1087 	mov	dptr,#0x0003
      00BAF8 C0 07            [24] 1088 	push	ar7
      00BAFA C0 06            [24] 1089 	push	ar6
      00BAFC C0 05            [24] 1090 	push	ar5
      00BAFE C0 04            [24] 1091 	push	ar4
      00BB00 12 BF 2D         [24] 1092 	lcall	__mulint
      00BB03 AA 82            [24] 1093 	mov	r2, dpl
      00BB05 AB 83            [24] 1094 	mov	r3, dph
      00BB07 D0 04            [24] 1095 	pop	ar4
      00BB09 D0 05            [24] 1096 	pop	ar5
      00BB0B D0 06            [24] 1097 	pop	ar6
      00BB0D D0 07            [24] 1098 	pop	ar7
      00BB0F 0D               [12] 1099 	inc	r5
      00BB10 BD 00 01         [24] 1100 	cjne	r5,#0x00,00165$
      00BB13 0E               [12] 1101 	inc	r6
      00BB14                       1102 00165$:
      00BB14 EA               [12] 1103 	mov	a,r2
      00BB15 24 DD            [12] 1104 	add	a, #_g_direct_mode_colors
      00BB17 FA               [12] 1105 	mov	r2,a
      00BB18 EB               [12] 1106 	mov	a,r3
      00BB19 34 0C            [12] 1107 	addc	a, #(_g_direct_mode_colors >> 8)
      00BB1B FB               [12] 1108 	mov	r3,a
                                   1109 ;	quantum/vialrgb.c:128: color->h = *args++;
      00BB1C 8A 51            [24] 1110 	mov	_fast_set_leds_sloc0_1_0,r2
      00BB1E 8B 52            [24] 1111 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00BB20 12 BD A7         [24] 1112 	lcall	_ak820_outline_0089
      00BB23 F8               [12] 1113 	mov	r0,a
      00BB24 12 BD B5         [24] 1114 	lcall	_ak820_outline_0112
      00BB27 85 51 82         [24] 1115 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BB2A 85 52 83         [24] 1116 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BB2D E8               [12] 1117 	mov	a,r0
      00BB2E F0               [24] 1118 	movx	@dptr,a
                                   1119 ;	quantum/vialrgb.c:129: color->s = *args++;
      00BB2F 74 01            [12] 1120 	mov	a,#0x01
      00BB31 2A               [12] 1121 	add	a, r2
      00BB32 F5 51            [12] 1122 	mov	_fast_set_leds_sloc0_1_0,a
      00BB34 E4               [12] 1123 	clr	a
      00BB35 3B               [12] 1124 	addc	a, r3
      00BB36 F5 52            [12] 1125 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00BB38 90 0D E1         [24] 1126 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB3B E0               [24] 1127 	movx	a,@dptr
      00BB3C F8               [12] 1128 	mov	r0,a
      00BB3D A3               [24] 1129 	inc	dptr
      00BB3E E0               [24] 1130 	movx	a,@dptr
      00BB3F FF               [12] 1131 	mov	r7,a
      00BB40 88 82            [24] 1132 	mov	dpl,r0
      00BB42 8F 83            [24] 1133 	mov	dph,r7
      00BB44 E0               [24] 1134 	movx	a,@dptr
      00BB45 F9               [12] 1135 	mov	r1,a
      00BB46 90 0D E1         [24] 1136 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB49 74 01            [12] 1137 	mov	a,#0x01
      00BB4B 28               [12] 1138 	add	a, r0
      00BB4C F0               [24] 1139 	movx	@dptr,a
      00BB4D E4               [12] 1140 	clr	a
      00BB4E 3F               [12] 1141 	addc	a, r7
      00BB4F A3               [24] 1142 	inc	dptr
      00BB50 F0               [24] 1143 	movx	@dptr,a
      00BB51 85 51 82         [24] 1144 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BB54 85 52 83         [24] 1145 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BB57 E9               [12] 1146 	mov	a,r1
      00BB58 F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00BB59 12 BD A7         [24] 1149 	lcall	_ak820_outline_0089
      00BB5C F5 51            [12] 1150 	mov	_fast_set_leds_sloc0_1_0,a
      00BB5E 12 BD B5         [24] 1151 	lcall	_ak820_outline_0112
                                   1152 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BB61 74 02            [12] 1153 	mov	a,#0x02
      00BB63 2A               [12] 1154 	add	a, r2
      00BB64 F5 53            [12] 1155 	mov	_fast_set_leds_sloc1_1_0,a
      00BB66 E4               [12] 1156 	clr	a
      00BB67 3B               [12] 1157 	addc	a, r3
      00BB68 F5 54            [12] 1158 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BB6A C3               [12] 1159 	clr	c
      00BB6B 74 A0            [12] 1160 	mov	a,#0xa0
      00BB6D 95 51            [12] 1161 	subb	a,_fast_set_leds_sloc0_1_0
      00BB6F D0 07            [24] 1162 	pop	ar7
      00BB71 50 04            [24] 1163 	jnc	00114$
                                   1164 ;	free result
      00BB73 7B A0            [12] 1165 	mov	r3,#0xa0
      00BB75 80 04            [24] 1166 	sjmp	00115$
      00BB77                       1167 00114$:
      00BB77 AA 51            [24] 1168 	mov	r2,_fast_set_leds_sloc0_1_0
      00BB79 8A 03            [24] 1169 	mov	ar3,r2
      00BB7B                       1170 00115$:
      00BB7B 85 53 82         [24] 1171 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BB7E 85 54 83         [24] 1172 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BB81 EB               [12] 1173 	mov	a,r3
      00BB82 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BB83 0C               [12] 1176 	inc	r4
                                   1177 ;	quantum/vialrgb.c:133: }
      00BB84 41 E7            [24] 1178 	ajmp	00110$
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1183 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1184 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1185 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1186 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1187 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1188 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1189 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function vialrgb_get_value
                                   1194 ;	-----------------------------------------
      00BB86                       1195 _vialrgb_get_value:
      00BB86 12 43 1B         [24] 1196 	lcall	_ak820_outline_0038
      00BB89 90 0D E7         [24] 1197 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BB8C 12 38 26         [24] 1198 	lcall	_ak820_outline_0018
                                   1199 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BB8F 90 0D E6         [24] 1200 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BB92 E0               [24] 1201 	movx	a,@dptr
      00BB93 FF               [12] 1202 	mov	r7,a
      00BB94 BF 20 02         [24] 1203 	cjne	r7,#0x20,00162$
      00BB97 80 01            [24] 1204 	sjmp	00102$
      00BB99                       1205 00162$:
      00BB99 22               [24] 1206 	ret
      00BB9A                       1207 00102$:
                                   1208 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BB9A 90 0D E7         [24] 1209 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BB9D 12 BD 81         [24] 1210 	lcall	_ak820_outline_0049
                                   1211 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1212 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BBA0 BA 40 02         [24] 1213 	cjne	r2,#0x40,00163$
      00BBA3 80 15            [24] 1214 	sjmp	00103$
      00BBA5                       1215 00163$:
      00BBA5 BA 41 02         [24] 1216 	cjne	r2,#0x41,00164$
      00BBA8 80 23            [24] 1217 	sjmp	00104$
      00BBAA                       1218 00164$:
      00BBAA BA 42 02         [24] 1219 	cjne	r2,#0x42,00165$
      00BBAD 81 5D            [12] 1220 	ajmp	00105$
      00BBAF                       1221 00165$:
      00BBAF BA 43 02         [24] 1222 	cjne	r2,#0x43,00166$
      00BBB2 81 68            [12] 1223 	ajmp	00106$
      00BBB4                       1224 00166$:
      00BBB4 BA 44 02         [24] 1225 	cjne	r2,#0x44,00167$
      00BBB7 81 74            [12] 1226 	ajmp	00107$
      00BBB9                       1227 00167$:
      00BBB9 22               [24] 1228 	ret
                                   1229 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BBBA                       1230 00103$:
                                   1231 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BBBA 12 33 FC         [24] 1232 	lcall	_ak820_outline_0130
      00BBBD 74 01            [12] 1233 	mov	a,#0x01
      00BBBF F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BBC0 12 BD 79         [24] 1236 	lcall	_ak820_outline_0040
      00BBC3 E4               [12] 1237 	clr	a
      00BBC4 F0               [24] 1238 	movx	@dptr,a
                                   1239 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BBC5 12 BD 79         [24] 1240 	lcall	_ak820_outline_0040
      00BBC8 A3               [24] 1241 	inc	dptr
      00BBC9 74 A0            [12] 1242 	mov	a,#0xa0
      00BBCB F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	quantum/vialrgb.c:147: break;
      00BBCC 22               [24] 1245 	ret
                                   1246 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BBCD                       1247 00104$:
                                   1248 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BBCD C0 06            [24] 1249 	push	ar6
      00BBCF C0 05            [24] 1250 	push	ar5
      00BBD1 C0 04            [24] 1251 	push	ar4
      00BBD3 C0 03            [24] 1252 	push	ar3
      00BBD5 31 D0            [12] 1253 	acall	_get_mode
      00BBD7 12 4F 08         [24] 1254 	lcall	_ak820_outline_0194
      00BBDA D0 03            [24] 1255 	pop	ar3
      00BBDC D0 04            [24] 1256 	pop	ar4
      00BBDE D0 05            [24] 1257 	pop	ar5
      00BBE0 D0 06            [24] 1258 	pop	ar6
                                   1259 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BBE2 89 00            [24] 1260 	mov	ar0,r1
      00BBE4 12 33 FC         [24] 1261 	lcall	_ak820_outline_0130
      00BBE7 E8               [12] 1262 	mov	a,r0
      00BBE8 F0               [24] 1263 	movx	@dptr,a
                                   1264 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BBE9 12 BD 79         [24] 1265 	lcall	_ak820_outline_0040
      00BBEC 8A 01            [24] 1266 	mov	ar1,r2
      00BBEE E9               [12] 1267 	mov	a,r1
      00BBEF F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BBF0 74 04            [12] 1270 	mov	a,#0x04
      00BBF2 12 93 C8         [24] 1271 	lcall	_ak820_outline_0142
      00BBF5 C0 06            [24] 1272 	push	ar6
      00BBF7 C0 05            [24] 1273 	push	ar5
      00BBF9 C0 02            [24] 1274 	push	ar2
      00BBFB C0 01            [24] 1275 	push	ar1
      00BBFD 12 5B 41         [24] 1276 	lcall	_rgb_matrix_get_speed
      00BC00 A8 82            [24] 1277 	mov	r0, dpl
      00BC02 D0 01            [24] 1278 	pop	ar1
      00BC04 D0 02            [24] 1279 	pop	ar2
      00BC06 D0 05            [24] 1280 	pop	ar5
      00BC08 D0 06            [24] 1281 	pop	ar6
      00BC0A 12 86 46         [24] 1282 	lcall	_ak820_outline_0066
                                   1283 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BC0D 74 05            [12] 1284 	mov	a,#0x05
      00BC0F 12 93 C8         [24] 1285 	lcall	_ak820_outline_0142
      00BC12 C0 06            [24] 1286 	push	ar6
      00BC14 C0 05            [24] 1287 	push	ar5
      00BC16 C0 02            [24] 1288 	push	ar2
      00BC18 C0 01            [24] 1289 	push	ar1
      00BC1A 12 5B 2C         [24] 1290 	lcall	_rgb_matrix_get_hue
      00BC1D A8 82            [24] 1291 	mov	r0, dpl
      00BC1F D0 01            [24] 1292 	pop	ar1
      00BC21 D0 02            [24] 1293 	pop	ar2
      00BC23 D0 05            [24] 1294 	pop	ar5
      00BC25 D0 06            [24] 1295 	pop	ar6
      00BC27 12 86 46         [24] 1296 	lcall	_ak820_outline_0066
                                   1297 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BC2A 74 06            [12] 1298 	mov	a,#0x06
      00BC2C 12 93 C8         [24] 1299 	lcall	_ak820_outline_0142
      00BC2F C0 06            [24] 1300 	push	ar6
      00BC31 C0 05            [24] 1301 	push	ar5
      00BC33 C0 02            [24] 1302 	push	ar2
      00BC35 C0 01            [24] 1303 	push	ar1
      00BC37 12 5B 33         [24] 1304 	lcall	_rgb_matrix_get_sat
      00BC3A A8 82            [24] 1305 	mov	r0, dpl
      00BC3C D0 01            [24] 1306 	pop	ar1
      00BC3E D0 02            [24] 1307 	pop	ar2
      00BC40 D0 05            [24] 1308 	pop	ar5
      00BC42 D0 06            [24] 1309 	pop	ar6
      00BC44 12 86 46         [24] 1310 	lcall	_ak820_outline_0066
                                   1311 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BC47 74 07            [12] 1312 	mov	a,#0x07
      00BC49 12 93 C8         [24] 1313 	lcall	_ak820_outline_0142
      00BC4C C0 02            [24] 1314 	push	ar2
      00BC4E C0 01            [24] 1315 	push	ar1
      00BC50 12 5B 3A         [24] 1316 	lcall	_rgb_matrix_get_val
      00BC53 A8 82            [24] 1317 	mov	r0, dpl
      00BC55 D0 01            [24] 1318 	pop	ar1
      00BC57 D0 02            [24] 1319 	pop	ar2
      00BC59 12 86 46         [24] 1320 	lcall	_ak820_outline_0066
                                   1321 ;	quantum/vialrgb.c:156: break;
      00BC5C 22               [24] 1322 	ret
                                   1323 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BC5D                       1324 00105$:
                                   1325 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BC5D EF               [12] 1326 	mov	a,r7
      00BC5E 24 FE            [12] 1327 	add	a,#0xfe
      00BC60 90 0D D3         [24] 1328 	mov	dptr,#_get_supported_PARM_2
      00BC63 12 A2 E2         [24] 1329 	lcall	_ak820_outline_0106
                                   1330 ;	quantum/vialrgb.c:160: break;
      00BC66 01 DA            [12] 1331 	ajmp	_get_supported
                                   1332 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BC68                       1333 00106$:
                                   1334 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BC68 12 33 FC         [24] 1335 	lcall	_ak820_outline_0130
      00BC6B 74 52            [12] 1336 	mov	a,#0x52
      00BC6D F0               [24] 1337 	movx	@dptr,a
                                   1338 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BC6E 12 BD 79         [24] 1339 	lcall	_ak820_outline_0040
      00BC71 E4               [12] 1340 	clr	a
      00BC72 F0               [24] 1341 	movx	@dptr,a
                                   1342 ;	quantum/vialrgb.c:166: break;
      00BC73 22               [24] 1343 	ret
                                   1344 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BC74                       1345 00107$:
                                   1346 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BC74 12 33 FC         [24] 1347 	lcall	_ak820_outline_0130
      00BC77 E0               [24] 1348 	movx	a,@dptr
      00BC78 FF               [12] 1349 	mov	r7,a
      00BC79 7A 00            [12] 1350 	mov	r2,#0x00
      00BC7B 74 03            [12] 1351 	mov	a,#0x03
      00BC7D 2D               [12] 1352 	add	a, r5
      00BC7E F8               [12] 1353 	mov	r0,a
      00BC7F E4               [12] 1354 	clr	a
      00BC80 3E               [12] 1355 	addc	a, r6
      00BC81 F9               [12] 1356 	mov	r1,a
      00BC82 C0 03            [24] 1357 	push	ar3
      00BC84 C0 04            [24] 1358 	push	ar4
      00BC86 12 38 BF         [24] 1359 	lcall	_ak820_outline_0160
      00BC89 E0               [24] 1360 	movx	a,@dptr
      00BC8A FB               [12] 1361 	mov	r3,a
      00BC8B E4               [12] 1362 	clr	a
      00BC8C 4F               [12] 1363 	orl	a,r7
      00BC8D F5 55            [12] 1364 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BC8F EB               [12] 1365 	mov	a,r3
      00BC90 4A               [12] 1366 	orl	a,r2
      00BC91 F5 56            [12] 1367 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1368 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BC93 AC 55            [24] 1369 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BC95 AF 56            [24] 1370 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BC97 C3               [12] 1371 	clr	c
      00BC98 EC               [12] 1372 	mov	a,r4
      00BC99 94 52            [12] 1373 	subb	a,#0x52
      00BC9B EF               [12] 1374 	mov	a,r7
      00BC9C 94 00            [12] 1375 	subb	a,#0x00
      00BC9E D0 04            [24] 1376 	pop	ar4
      00BCA0 D0 03            [24] 1377 	pop	ar3
      00BCA2 40 01            [24] 1378 	jc	00109$
      00BCA4 22               [24] 1379 	ret
      00BCA5                       1380 00109$:
                                   1381 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BCA5 E5 55            [12] 1382 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BCA7 25 55            [12] 1383 	add	a,_vialrgb_get_value_sloc0_1_0
      00BCA9 FA               [12] 1384 	mov	r2,a
      00BCAA E5 56            [12] 1385 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BCAC 33               [12] 1386 	rlc	a
      00BCAD FF               [12] 1387 	mov	r7,a
      00BCAE EA               [12] 1388 	mov	a,r2
      00BCAF 24 21            [12] 1389 	add	a, #_ak820_led_points
      00BCB1 F5 57            [12] 1390 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BCB3 EF               [12] 1391 	mov	a,r7
      00BCB4 34 C3            [12] 1392 	addc	a, #(_ak820_led_points >> 8)
      00BCB6 F5 58            [12] 1393 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BCB8 85 57 82         [24] 1394 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BCBB 85 58 83         [24] 1395 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BCBE E4               [12] 1396 	clr	a
      00BCBF 93               [24] 1397 	movc	a,@a+dptr
      00BCC0 12 33 FC         [24] 1398 	lcall	_ak820_outline_0130
      00BCC3 F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BCC4 85 57 82         [24] 1401 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BCC7 85 58 83         [24] 1402 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BCCA A3               [24] 1403 	inc	dptr
      00BCCB E4               [12] 1404 	clr	a
      00BCCC 93               [24] 1405 	movc	a,@a+dptr
      00BCCD 12 38 BF         [24] 1406 	lcall	_ak820_outline_0160
      00BCD0 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BCD1 12 BD 79         [24] 1409 	lcall	_ak820_outline_0040
      00BCD4 A3               [24] 1410 	inc	dptr
      00BCD5 74 04            [12] 1411 	mov	a,#0x04
      00BCD7 F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BCD8 90 0D DC         [24] 1414 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BCDB 04               [12] 1415 	inc	a
      00BCDC 2D               [12] 1416 	add	a, r5
      00BCDD F0               [24] 1417 	movx	@dptr,a
      00BCDE E4               [12] 1418 	clr	a
      00BCDF 3E               [12] 1419 	addc	a, r6
      00BCE0 A3               [24] 1420 	inc	dptr
      00BCE1 F0               [24] 1421 	movx	@dptr,a
      00BCE2 85 55 82         [24] 1422 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BCE5 85 56 83         [24] 1423 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1424 ;	quantum/vialrgb.c:187: }
                                   1425 ;	quantum/vialrgb.c:188: }
      00BCE8 41 11            [24] 1426 	ajmp	_get_matrix_pos_for_led
                                   1427 ;------------------------------------------------------------
                                   1428 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1429 ;------------------------------------------------------------
                                   1430 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1431 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1432 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1433 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1434 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1435 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1436 ;------------------------------------------------------------
                                   1437 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1438 ;	-----------------------------------------
                                   1439 ;	 function vialrgb_set_value
                                   1440 ;	-----------------------------------------
      00BCEA                       1441 _vialrgb_set_value:
      00BCEA 12 43 1B         [24] 1442 	lcall	_ak820_outline_0038
      00BCED 90 0D EB         [24] 1443 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BCF0 12 38 26         [24] 1444 	lcall	_ak820_outline_0018
                                   1445 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BCF3 90 0D EA         [24] 1446 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BCF6 E0               [24] 1447 	movx	a,@dptr
      00BCF7 FF               [12] 1448 	mov	r7,a
      00BCF8 BF 20 02         [24] 1449 	cjne	r7,#0x20,00129$
      00BCFB 80 01            [24] 1450 	sjmp	00102$
      00BCFD                       1451 00129$:
      00BCFD 22               [24] 1452 	ret
      00BCFE                       1453 00102$:
                                   1454 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BCFE 90 0D EB         [24] 1455 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BD01 12 BD 81         [24] 1456 	lcall	_ak820_outline_0049
                                   1457 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1458 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BD04 BA 41 02         [24] 1459 	cjne	r2,#0x41,00130$
      00BD07 80 06            [24] 1460 	sjmp	00103$
      00BD09                       1461 00130$:
      00BD09 BA 42 02         [24] 1462 	cjne	r2,#0x42,00131$
      00BD0C 80 5D            [24] 1463 	sjmp	00104$
      00BD0E                       1464 00131$:
      00BD0E 22               [24] 1465 	ret
                                   1466 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BD0F                       1467 00103$:
                                   1468 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BD0F 12 33 FC         [24] 1469 	lcall	_ak820_outline_0130
      00BD12 E0               [24] 1470 	movx	a,@dptr
      00BD13 FA               [12] 1471 	mov	r2,a
      00BD14 12 BD 79         [24] 1472 	lcall	_ak820_outline_0040
      00BD17 E0               [24] 1473 	movx	a,@dptr
      00BD18 F8               [12] 1474 	mov	r0,a
      00BD19 79 00            [12] 1475 	mov	r1,#0x00
      00BD1B 88 5A            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BD1D 89 59            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BD1F 8A 01            [24] 1478 	mov	ar1,r2
      00BD21 7A 00            [12] 1479 	mov	r2,#0x00
      00BD23 E5 5A            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BD25 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BD27 12 43 86         [24] 1483 	lcall	_ak820_outline_0178
      00BD2A C0 06            [24] 1484 	push	ar6
      00BD2C C0 05            [24] 1485 	push	ar5
      00BD2E 31 E4            [24] 1486 	acall	_set_mode
      00BD30 D0 05            [24] 1487 	pop	ar5
      00BD32 D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BD34 12 BD 79         [24] 1490 	lcall	_ak820_outline_0040
      00BD37 A3               [24] 1491 	inc	dptr
      00BD38 E0               [24] 1492 	movx	a,@dptr
      00BD39 F5 82            [12] 1493 	mov	dpl,a
      00BD3B C0 06            [24] 1494 	push	ar6
      00BD3D C0 05            [24] 1495 	push	ar5
      00BD3F 12 5C 0D         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00BD42 D0 05            [24] 1497 	pop	ar5
      00BD44 D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BD46 12 BD 79         [24] 1500 	lcall	_ak820_outline_0040
      00BD49 A3               [24] 1501 	inc	dptr
      00BD4A A3               [24] 1502 	inc	dptr
      00BD4B E0               [24] 1503 	movx	a,@dptr
      00BD4C F9               [12] 1504 	mov	r1,a
      00BD4D 7A 00            [12] 1505 	mov	r2,#0x00
      00BD4F 74 06            [12] 1506 	mov	a,#0x06
      00BD51 12 BD CB         [24] 1507 	lcall	_ak820_outline_0180
      00BD54 F8               [12] 1508 	mov	r0,a
      00BD55 74 07            [12] 1509 	mov	a,#0x07
      00BD57 12 BD CB         [24] 1510 	lcall	_ak820_outline_0180
      00BD5A FE               [12] 1511 	mov	r6,a
      00BD5B 90 07 83         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BD5E E8               [12] 1513 	mov	a,r0
      00BD5F F0               [24] 1514 	movx	@dptr,a
      00BD60 90 07 84         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BD63 EE               [12] 1516 	mov	a,r6
      00BD64 F0               [24] 1517 	movx	@dptr,a
      00BD65 12 43 86         [24] 1518 	lcall	_ak820_outline_0178
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BD68 02 5B DE         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BD6B                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BD6B EF               [12] 1524 	mov	a,r7
      00BD6C 24 FE            [12] 1525 	add	a,#0xfe
      00BD6E 90 0D E0         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00BD71 12 A2 E2         [24] 1527 	lcall	_ak820_outline_0106
                                   1528 ;	quantum/vialrgb.c:210: }
                                   1529 ;	quantum/vialrgb.c:211: }
      00BD74 41 44            [24] 1530 	ajmp	_fast_set_leds
                                   1531 ;------------------------------------------------------------
                                   1532 ;Allocation info for local variables in function 'vialrgb_save'
                                   1533 ;------------------------------------------------------------
                                   1534 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1535 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1538 ;	-----------------------------------------
                                   1539 ;	 function vialrgb_save
                                   1540 ;	-----------------------------------------
      00BD76                       1541 _vialrgb_save:
                                   1542 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1543 ;	quantum/vialrgb.c:218: }
      00BD76 02 56 60         [24] 1544 	ljmp	_eeconfig_update_rgb_matrix
                                   1545 	.area CSEG    (CODE)
                                   1546 	.area CONST   (CODE)
                                   1547 	.area CONST   (CODE)
      00C660                       1548 _supported_modes:
      00C660 00                    1549 	.db #0x00	; 0
      00C661 00                    1550 	.db #0x00	; 0
      00C662 01                    1551 	.db #0x01	; 1
      00C663 05                    1552 	.db #0x05	; 5
      00C664 02                    1553 	.db #0x02	; 2
      00C665 01                    1554 	.db #0x01	; 1
      00C666 06                    1555 	.db #0x06	; 6
      00C667 02                    1556 	.db #0x02	; 2
      00C668 0D                    1557 	.db #0x0d	; 13
      00C669 03                    1558 	.db #0x03	; 3
      00C66A 0E                    1559 	.db #0x0e	; 14
      00C66B 04                    1560 	.db #0x04	; 4
      00C66C 1F                    1561 	.db #0x1f	; 31
      00C66D 06                    1562 	.db #0x06	; 6
                                   1563 	.area CSEG    (CODE)
                                   1564 	.area XINIT   (CODE)
                                   1565 	.area CABS    (ABS,CODE)
                                   1566 
                                   1567 ; Experimental exact instruction outlining.
                                   1568 	.globl _ak820_outline_0005
                                   1569 	.globl _ak820_outline_0018
                                   1570 	.globl _ak820_outline_0024
                                   1571 	.globl _ak820_outline_0038
                                   1572 	.globl _ak820_outline_0040
                                   1573 	.globl _ak820_outline_0041
                                   1574 	.globl _ak820_outline_0049
                                   1575 	.globl _ak820_outline_0051
                                   1576 	.globl _ak820_outline_0055
                                   1577 	.globl _ak820_outline_0066
                                   1578 	.globl _ak820_outline_0069
                                   1579 	.globl _ak820_outline_0089
                                   1580 	.globl _ak820_outline_0090
                                   1581 	.globl _ak820_outline_0099
                                   1582 	.globl _ak820_outline_0106
                                   1583 	.globl _ak820_outline_0112
                                   1584 	.globl _ak820_outline_0113
                                   1585 	.globl _ak820_outline_0114
                                   1586 	.globl _ak820_outline_0115
                                   1587 	.globl _ak820_outline_0118
                                   1588 	.globl _ak820_outline_0124
                                   1589 	.globl _ak820_outline_0128
                                   1590 	.globl _ak820_outline_0130
                                   1591 	.globl _ak820_outline_0141
                                   1592 	.globl _ak820_outline_0142
                                   1593 	.globl _ak820_outline_0146
                                   1594 	.globl _ak820_outline_0150
                                   1595 	.globl _ak820_outline_0152
                                   1596 	.globl _ak820_outline_0155
                                   1597 	.globl _ak820_outline_0160
                                   1598 	.globl _ak820_outline_0178
                                   1599 	.globl _ak820_outline_0180
                                   1600 	.globl _ak820_outline_0194
                                   1601 	.globl _ak820_outline_0196
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0040
      00BD79                       1605 _ak820_outline_0040:
      00BD79 8D 82            [24] 1606 	mov	dpl,r5
      00BD7B 8E 83            [24] 1607 	mov	dph,r6
      00BD7D A3               [24] 1608 	inc	dptr
      00BD7E A3               [24] 1609 	inc	dptr
      00BD7F A3               [24] 1610 	inc	dptr
      00BD80 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0049
      00BD81                       1615 _ak820_outline_0049:
      00BD81 E0               [24] 1616 	movx	a,@dptr
      00BD82 FD               [12] 1617 	mov	r5,a
      00BD83 A3               [24] 1618 	inc	dptr
      00BD84 E0               [24] 1619 	movx	a,@dptr
      00BD85 FE               [12] 1620 	mov	r6,a
      00BD86 74 02            [12] 1621 	mov	a,#0x02
      00BD88 2D               [12] 1622 	add	a,r5
      00BD89 FB               [12] 1623 	mov	r3,a
      00BD8A E4               [12] 1624 	clr	a
      00BD8B 3E               [12] 1625 	addc	a,r6
      00BD8C FC               [12] 1626 	mov	r4,a
      00BD8D 8D 82            [24] 1627 	mov	dpl,r5
      00BD8F 8E 83            [24] 1628 	mov	dph,r6
      00BD91 A3               [24] 1629 	inc	dptr
      00BD92 E0               [24] 1630 	movx	a,@dptr
      00BD93 FA               [12] 1631 	mov	r2,a
      00BD94 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0051
      00BD95                       1636 _ak820_outline_0051:
      00BD95 ED               [12] 1637 	mov	a,r5
      00BD96 75 F0 02         [24] 1638 	mov	b,#0x02
      00BD99 A4               [48] 1639 	mul	ab
      00BD9A 24 60            [12] 1640 	add	a,#_supported_modes
      00BD9C FB               [12] 1641 	mov	r3,a
      00BD9D 74 C6            [12] 1642 	mov	a,#(_supported_modes>>8)
      00BD9F 35 F0            [12] 1643 	addc	a,b
      00BDA1 FC               [12] 1644 	mov	r4,a
      00BDA2 8B 82            [24] 1645 	mov	dpl,r3
      00BDA4 8C 83            [24] 1646 	mov	dph,r4
      00BDA6 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0089
      00BDA7                       1651 _ak820_outline_0089:
      00BDA7 90 0D E1         [24] 1652 	mov	dptr,#_fast_set_leds_args_10000_282
      00BDAA E0               [24] 1653 	movx	a,@dptr
      00BDAB F9               [12] 1654 	mov	r1,a
      00BDAC A3               [24] 1655 	inc	dptr
      00BDAD E0               [24] 1656 	movx	a,@dptr
      00BDAE FF               [12] 1657 	mov	r7,a
      00BDAF 89 82            [24] 1658 	mov	dpl,r1
      00BDB1 8F 83            [24] 1659 	mov	dph,r7
      00BDB3 E0               [24] 1660 	movx	a,@dptr
      00BDB4 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0112
      00BDB5                       1665 _ak820_outline_0112:
      00BDB5 90 0D E1         [24] 1666 	mov	dptr,#_fast_set_leds_args_10000_282
      00BDB8 74 01            [12] 1667 	mov	a,#0x01
      00BDBA 29               [12] 1668 	add	a,r1
      00BDBB F0               [24] 1669 	movx	@dptr,a
      00BDBC E4               [12] 1670 	clr	a
      00BDBD 3F               [12] 1671 	addc	a,r7
      00BDBE A3               [24] 1672 	inc	dptr
      00BDBF F0               [24] 1673 	movx	@dptr,a
      00BDC0 22               [24] 1674 	ret
                                   1675 
                                   1676 	.area CSEG (CODE)
                                   1677 ; function ak820_outline_0155
      00BDC1                       1678 _ak820_outline_0155:
      00BDC1 E4               [12] 1679 	clr	a
      00BDC2 93               [24] 1680 	movc	a,@a+dptr
      00BDC3 FC               [12] 1681 	mov	r4,a
      00BDC4 7B 00            [12] 1682 	mov	r3,#0x00
      00BDC6 8C 82            [24] 1683 	mov	dpl,r4
      00BDC8 8B 83            [24] 1684 	mov	dph,r3
      00BDCA 22               [24] 1685 	ret
                                   1686 
                                   1687 	.area CSEG (CODE)
                                   1688 ; function ak820_outline_0180
      00BDCB                       1689 _ak820_outline_0180:
      00BDCB 2D               [12] 1690 	add	a,r5
      00BDCC F5 82            [12] 1691 	mov	dpl,a
      00BDCE E4               [12] 1692 	clr	a
      00BDCF 3E               [12] 1693 	addc	a,r6
      00BDD0 F5 83            [12] 1694 	mov	dph,a
      00BDD2 E0               [24] 1695 	movx	a,@dptr
      00BDD3 22               [24] 1696 	ret
