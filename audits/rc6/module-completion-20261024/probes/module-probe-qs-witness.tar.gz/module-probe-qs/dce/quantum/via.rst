                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      00003F                        553 _raw_hid_receive_sloc0_1_0:
      00003F                        554 	.ds 4
      000043                        555 _raw_hid_receive_sloc1_1_0:
      000043                        556 	.ds 1
      000044                        557 _raw_hid_receive_sloc2_1_0:
      000044                        558 	.ds 1
      000045                        559 _raw_hid_receive_sloc3_1_0:
      000045                        560 	.ds 2
      000047                        561 _raw_hid_receive_sloc4_1_0:
      000047                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002A                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002A                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C95                        589 _via_eeprom_set_valid_valid_10000_609:
      000C95                        590 	.ds 1
      000C96                        591 _via_set_layout_options_value_10000_625:
      000C96                        592 	.ds 4
      000C9A                        593 _process_record_via_PARM_2:
      000C9A                        594 	.ds 3
      000C9D                        595 _process_record_via_keycode_10000_627:
      000C9D                        596 	.ds 2
      000C9F                        597 _raw_hid_receive_kb_PARM_2:
      000C9F                        598 	.ds 1
      000CA0                        599 _raw_hid_receive_kb_data_10000_633:
      000CA0                        600 	.ds 3
      000CA3                        601 _raw_hid_receive_PARM_2:
      000CA3                        602 	.ds 1
      000CA4                        603 _raw_hid_receive_packet_10000_635:
      000CA4                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AAFD                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AAFD 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AB00 75 F0 00         [24]  659 	mov	b, #0x00
      00AB03 12 40 7C         [24]  660 	lcall	_eeprom_read_byte
      00AB06 AF 82            [24]  661 	mov	r7, dpl
      00AB08 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00AB0B 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AB0E 75 F0 00         [24]  664 	mov	b, #0x00
      00AB11 12 40 7C         [24]  665 	lcall	_eeprom_read_byte
      00AB14 AF 82            [24]  666 	mov	r7, dpl
      00AB16 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AB19 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AB1C 75 F0 00         [24]  669 	mov	b, #0x00
      00AB1F 12 40 7C         [24]  670 	lcall	_eeprom_read_byte
      00AB22 AF 82            [24]  671 	mov	r7, dpl
      00AB24 BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AB27 80 04            [24]  673 	sjmp	00104$
      00AB29                        674 00126$:
      00AB29                        675 00103$:
                                    676 ;	assignBit
      00AB29 C2 2A            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AB2B 80 02            [24]  678 	sjmp	00105$
      00AB2D                        679 00104$:
                                    680 ;	assignBit
      00AB2D D2 2A            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AB2F                        682 00105$:
      00AB2F A2 2A            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AB31 12 38 BA         [24]  684 	lcall	_ak820_outline_0159
                                    685 ;	quantum/via.c:104: }
      00AB34 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AB35                        699 _via_eeprom_set_valid:
      00AB35 E5 82            [12]  700 	mov	a,dpl
      00AB37 90 0C 95         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00AB3A F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AB3B E0               [24]  704 	movx	a,@dptr
      00AB3C 60 04            [24]  705 	jz	00103$
      00AB3E 7F 03            [12]  706 	mov	r7,#0x03
      00AB40 80 02            [24]  707 	sjmp	00104$
      00AB42                        708 00103$:
      00AB42 7F FF            [12]  709 	mov	r7,#0xff
      00AB44                        710 00104$:
      00AB44 90 06 EE         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB47 EF               [12]  712 	mov	a,r7
      00AB48 F0               [24]  713 	movx	@dptr,a
      00AB49 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AB4C 75 F0 00         [24]  715 	mov	b, #0x00
      00AB4F 12 54 2A         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AB52 90 0C 95         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00AB55 E0               [24]  719 	movx	a,@dptr
      00AB56 60 04            [24]  720 	jz	00105$
      00AB58 7F 20            [12]  721 	mov	r7,#0x20
      00AB5A 80 02            [24]  722 	sjmp	00106$
      00AB5C                        723 00105$:
      00AB5C 7F FF            [12]  724 	mov	r7,#0xff
      00AB5E                        725 00106$:
      00AB5E 90 06 EE         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB61 EF               [12]  727 	mov	a,r7
      00AB62 F0               [24]  728 	movx	@dptr,a
      00AB63 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AB66 75 F0 00         [24]  730 	mov	b, #0x00
      00AB69 12 54 2A         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AB6C 90 0C 95         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00AB6F E0               [24]  734 	movx	a,@dptr
      00AB70 60 04            [24]  735 	jz	00107$
      00AB72 7F 08            [12]  736 	mov	r7,#0x08
      00AB74 80 02            [24]  737 	sjmp	00108$
      00AB76                        738 00107$:
      00AB76 7F FF            [12]  739 	mov	r7,#0xff
      00AB78                        740 00108$:
      00AB78 90 06 EE         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB7B EF               [12]  742 	mov	a,r7
      00AB7C F0               [24]  743 	movx	@dptr,a
      00AB7D 90 00 27         [24]  744 	mov	dptr,#0x0027
      00AB80 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00AB83 02 54 2A         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00AB86                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00AB86 71 A9            [12]  757 	acall	_via_get_layout_options
      00AB88 71 C1            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00AB8A 51 FD            [12]  760 	acall	_via_eeprom_is_valid
      00AB8C E5 82            [12]  761 	mov	a, dpl
      00AB8E 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00AB90 02 3E 2C         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00AB93                        766 00103$:
      00AB93 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00AB94                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00AB94 75 82 00         [24]  777 	mov	dpl, #0x00
      00AB97 71 35            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AB99 12 95 91         [24]  780 	lcall	_ak820_outline_0163
      00AB9C 71 C2            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AB9E 12 8C 2F         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00ABA1 12 90 9F         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00ABA4 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00ABA7 61 35            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00ABA9                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00ABA9 90 00 28         [24]  799 	mov	dptr,#0x0028
      00ABAC 75 F0 00         [24]  800 	mov	b, #0x00
      00ABAF 12 40 7C         [24]  801 	lcall	_eeprom_read_byte
      00ABB2 AF 82            [24]  802 	mov	r7, dpl
      00ABB4 7E 00            [12]  803 	mov	r6,#0x00
      00ABB6 7D 00            [12]  804 	mov	r5,#0x00
      00ABB8 7C 00            [12]  805 	mov	r4,#0x00
      00ABBA 12 43 7B         [24]  806 	lcall	_ak820_outline_0166
      00ABBD 8D F0            [24]  807 	mov	b, r5
      00ABBF EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00ABC0 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00ABC1                        820 _via_set_layout_options_kb:
      00ABC1 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00ABC2                        831 _via_set_layout_options:
      00ABC2 12 95 89         [24]  832 	lcall	_ak820_outline_0126
      00ABC5 90 0C 96         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00ABC8 12 95 77         [24]  834 	lcall	_ak820_outline_0046
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00ABCB 90 0C 96         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00ABCE E0               [24]  837 	movx	a,@dptr
      00ABCF 90 06 EE         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00ABD2 F0               [24]  839 	movx	@dptr,a
      00ABD3 90 00 28         [24]  840 	mov	dptr,#0x0028
      00ABD6 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00ABD9 02 54 2A         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00ABDC                        855 _process_record_via:
      00ABDC 12 38 79         [24]  856 	lcall	_ak820_outline_0113
      00ABDF 90 0C 9D         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00ABE2 12 38 7E         [24]  858 	lcall	_ak820_outline_0114
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00ABE5 90 0C 9A         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00ABE8 12 49 34         [24]  861 	lcall	_ak820_outline_0013
      00ABEB 74 05            [12]  862 	mov	a,#0x05
      00ABED 12 38 C4         [24]  863 	lcall	_ak820_outline_0168
      00ABF0 12 49 77         [24]  864 	lcall	_ak820_outline_0050
      00ABF3 12 C0 37         [24]  865 	lcall	__gptrget
      00ABF6 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00ABF8 90 0C 9D         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00ABFB 12 4E 82         [24]  869 	lcall	_ak820_outline_0009
      00ABFE 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00AC00 2D               [12]  871 	add	a,r5
      00AC01 50 12            [24]  872 	jnc	00105$
      00AC03 C3               [12]  873 	clr	c
      00AC04 74 7F            [12]  874 	mov	a,#0x7f
      00AC06 9C               [12]  875 	subb	a,r4
      00AC07 74 77            [12]  876 	mov	a,#0x77
      00AC09 9D               [12]  877 	subb	a,r5
      00AC0A 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AC0C 8E 82            [24]  882 	mov	dpl, r6
      00AC0E 12 90 C5         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AC11 75 82 00         [24]  885 	mov	dpl, #0x00
      00AC14 22               [24]  886 	ret
      00AC15                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AC15 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AC18 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AC19                        903 _raw_hid_receive_kb:
      00AC19 12 43 1B         [24]  904 	lcall	_ak820_outline_0038
      00AC1C 90 0C A0         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00AC1F 12 38 26         [24]  906 	lcall	_ak820_outline_0018
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AC22 90 0C A0         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00AC25 12 55 13         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AC28 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AC2A 02 BF 12         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AC2D                        950 _raw_hid_receive:
      00AC2D 12 43 1B         [24]  951 	lcall	_ak820_outline_0038
      00AC30 90 0C A4         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00AC33 12 38 26         [24]  953 	lcall	_ak820_outline_0018
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AC36 90 0C A4         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00AC39 12 38 3E         [24]  956 	lcall	_ak820_outline_0055
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AC3C 74 01            [12]  958 	mov	a,#0x01
      00AC3E 12 43 80         [24]  959 	lcall	_ak820_outline_0169
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AC41 90 0C A3         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AC44 E0               [24]  962 	movx	a,@dptr
      00AC45 FB               [12]  963 	mov	r3,a
      00AC46 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AC49 80 01            [24]  965 	sjmp	00102$
      00AC4B                        966 00520$:
      00AC4B 22               [24]  967 	ret
      00AC4C                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AC4C 90 0E 7A         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AC4F E0               [24]  971 	movx	a,@dptr
      00AC50 60 32            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AC52 12 38 8A         [24]  974 	lcall	_ak820_outline_0124
      00AC55 E0               [24]  975 	movx	a,@dptr
      00AC56 FA               [12]  976 	mov	r2,a
      00AC57 BA FE 02         [24]  977 	cjne	r2,#0xfe,00522$
      00AC5A 80 01            [24]  978 	sjmp	00104$
      00AC5C                        979 00522$:
                                    980 ;	quantum/via.c:252: return;
      00AC5C 22               [24]  981 	ret
      00AC5D                        982 00104$:
                                    983 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AC5D 12 43 4C         [24]  984 	lcall	_ak820_outline_0100
                                    985 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AC60 FA               [12]  986 	mov	r2,a
      00AC61 60 21            [24]  987 	jz	00114$
      00AC63 BA 01 02         [24]  988 	cjne	r2,#0x01,00524$
      00AC66 80 1C            [24]  989 	sjmp	00114$
      00AC68                        990 00524$:
      00AC68 BA 02 02         [24]  991 	cjne	r2,#0x02,00525$
      00AC6B 80 17            [24]  992 	sjmp	00114$
      00AC6D                        993 00525$:
      00AC6D BA 05 02         [24]  994 	cjne	r2,#0x05,00526$
      00AC70 80 12            [24]  995 	sjmp	00114$
      00AC72                        996 00526$:
      00AC72 BA 06 02         [24]  997 	cjne	r2,#0x06,00527$
      00AC75 80 0D            [24]  998 	sjmp	00114$
      00AC77                        999 00527$:
      00AC77 BA 07 02         [24] 1000 	cjne	r2,#0x07,00528$
      00AC7A 80 08            [24] 1001 	sjmp	00114$
      00AC7C                       1002 00528$:
      00AC7C BA 08 02         [24] 1003 	cjne	r2,#0x08,00529$
      00AC7F 80 03            [24] 1004 	sjmp	00530$
      00AC81                       1005 00529$:
      00AC81 02 B1 9F         [24] 1006 	ljmp	00171$
      00AC84                       1007 00530$:
                                   1008 ;	quantum/via.c:259: goto skip;
      00AC84                       1009 00114$:
                                   1010 ;	quantum/via.c:263: switch (*command_id) {
      00AC84 12 38 8A         [24] 1011 	lcall	_ak820_outline_0124
      00AC87 E0               [24] 1012 	movx	a,@dptr
      00AC88 FA               [12] 1013 	mov	r2,a
      00AC89 BA 01 02         [24] 1014 	cjne	r2,#0x01,00531$
      00AC8C 80 68            [24] 1015 	sjmp	00115$
      00AC8E                       1016 00531$:
      00AC8E BA 02 02         [24] 1017 	cjne	r2,#0x02,00532$
      00AC91 80 70            [24] 1018 	sjmp	00116$
      00AC93                       1019 00532$:
      00AC93 BA 03 02         [24] 1020 	cjne	r2,#0x03,00533$
      00AC96 A1 C1            [24] 1021 	ajmp	00125$
      00AC98                       1022 00533$:
      00AC98 BA 04 02         [24] 1023 	cjne	r2,#0x04,00534$
      00AC9B C1 53            [12] 1024 	ajmp	00129$
      00AC9D                       1025 00534$:
      00AC9D BA 05 02         [24] 1026 	cjne	r2,#0x05,00535$
      00ACA0 C1 8C            [12] 1027 	ajmp	00130$
      00ACA2                       1028 00535$:
      00ACA2 BA 06 02         [24] 1029 	cjne	r2,#0x06,00536$
      00ACA5 C1 F8            [12] 1030 	ajmp	00135$
      00ACA7                       1031 00536$:
      00ACA7 BA 07 02         [24] 1032 	cjne	r2,#0x07,00537$
      00ACAA E1 0A            [12] 1033 	ajmp	00136$
      00ACAC                       1034 00537$:
      00ACAC BA 08 02         [24] 1035 	cjne	r2,#0x08,00538$
      00ACAF E1 25            [12] 1036 	ajmp	00137$
      00ACB1                       1037 00538$:
      00ACB1 BA 09 03         [24] 1038 	cjne	r2,#0x09,00539$
      00ACB4 02 AF 40         [24] 1039 	ljmp	00138$
      00ACB7                       1040 00539$:
      00ACB7 BA 0B 03         [24] 1041 	cjne	r2,#0x0b,00540$
      00ACBA 02 B1 2F         [24] 1042 	ljmp	00161$
      00ACBD                       1043 00540$:
      00ACBD BA 0C 03         [24] 1044 	cjne	r2,#0x0c,00541$
      00ACC0 02 AF 5B         [24] 1045 	ljmp	00139$
      00ACC3                       1046 00541$:
      00ACC3 BA 0D 03         [24] 1047 	cjne	r2,#0x0d,00542$
      00ACC6 02 AF 7C         [24] 1048 	ljmp	00140$
      00ACC9                       1049 00542$:
      00ACC9 BA 0E 03         [24] 1050 	cjne	r2,#0x0e,00543$
      00ACCC 02 AF A4         [24] 1051 	ljmp	00141$
      00ACCF                       1052 00543$:
      00ACCF BA 0F 03         [24] 1053 	cjne	r2,#0x0f,00544$
      00ACD2 02 AF EC         [24] 1054 	ljmp	00144$
      00ACD5                       1055 00544$:
      00ACD5 BA 10 03         [24] 1056 	cjne	r2,#0x10,00545$
      00ACD8 02 B0 5A         [24] 1057 	ljmp	00151$
      00ACDB                       1058 00545$:
      00ACDB BA 11 03         [24] 1059 	cjne	r2,#0x11,00546$
      00ACDE 02 B0 72         [24] 1060 	ljmp	00154$
      00ACE1                       1061 00546$:
      00ACE1 BA 12 03         [24] 1062 	cjne	r2,#0x12,00547$
      00ACE4 02 B0 92         [24] 1063 	ljmp	00155$
      00ACE7                       1064 00547$:
      00ACE7 BA 13 03         [24] 1065 	cjne	r2,#0x13,00548$
      00ACEA 02 B0 D8         [24] 1066 	ljmp	00158$
      00ACED                       1067 00548$:
      00ACED BA FE 03         [24] 1068 	cjne	r2,#0xfe,00549$
      00ACF0 02 B1 6E         [24] 1069 	ljmp	00168$
      00ACF3                       1070 00549$:
      00ACF3 02 B1 87         [24] 1071 	ljmp	00169$
                                   1072 ;	quantum/via.c:264: case id_get_protocol_version: {
      00ACF6                       1073 00115$:
                                   1074 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00ACF6 12 38 A0         [24] 1075 	lcall	_ak820_outline_0133
      00ACF9 E4               [12] 1076 	clr	a
      00ACFA 12 43 13         [24] 1077 	lcall	_ak820_outline_0034
                                   1078 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00ACFD 74 09            [12] 1079 	mov	a,#0x09
      00ACFF F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/via.c:267: break;
      00AD00 02 B1 9F         [24] 1082 	ljmp	00171$
                                   1083 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00AD03                       1084 00116$:
                                   1085 ;	quantum/via.c:270: switch (command_data[0]) {
      00AD03 12 43 4C         [24] 1086 	lcall	_ak820_outline_0100
      00AD06 FA               [12] 1087 	mov	r2,a
      00AD07 BA 01 02         [24] 1088 	cjne	r2,#0x01,00550$
      00AD0A 80 0C            [24] 1089 	sjmp	00117$
      00AD0C                       1090 00550$:
      00AD0C BA 02 02         [24] 1091 	cjne	r2,#0x02,00551$
      00AD0F 80 32            [24] 1092 	sjmp	00118$
      00AD11                       1093 00551$:
      00AD11 BA 03 02         [24] 1094 	cjne	r2,#0x03,00552$
      00AD14 A1 7D            [24] 1095 	ajmp	00119$
      00AD16                       1096 00552$:
      00AD16 A1 A7            [24] 1097 	ajmp	00123$
                                   1098 ;	quantum/via.c:271: case id_uptime: {
      00AD18                       1099 00117$:
                                   1100 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AD18 12 4F 52         [24] 1101 	lcall	_timer_read32
      00AD1B 85 82 3F         [24] 1102 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD1E 85 83 40         [24] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD21 85 F0 41         [24] 1104 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD24 F5 42            [12] 1105 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1106 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AD26 12 38 8A         [24] 1107 	lcall	_ak820_outline_0124
      00AD29 A3               [24] 1108 	inc	dptr
      00AD2A A3               [24] 1109 	inc	dptr
      00AD2B E5 42            [12] 1110 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD2D 12 43 13         [24] 1111 	lcall	_ak820_outline_0034
                                   1112 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AD30 A3               [24] 1113 	inc	dptr
      00AD31 E5 41            [12] 1114 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD33 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AD34 12 B1 CC         [24] 1117 	lcall	_ak820_outline_0025
      00AD37 E5 40            [12] 1118 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD39 F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AD3A 12 43 09         [24] 1121 	lcall	_ak820_outline_0014
      00AD3D E5 3F            [12] 1122 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD3F F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/via.c:277: break;
      00AD40 02 B1 9F         [24] 1125 	ljmp	00171$
                                   1126 ;	quantum/via.c:279: case id_layout_options: {
      00AD43                       1127 00118$:
                                   1128 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AD43 C0 03            [24] 1129 	push	ar3
      00AD45 C0 07            [24] 1130 	push	ar7
      00AD47 C0 06            [24] 1131 	push	ar6
      00AD49 C0 03            [24] 1132 	push	ar3
      00AD4B 71 A9            [12] 1133 	acall	_via_get_layout_options
      00AD4D 85 82 3F         [24] 1134 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD50 85 83 40         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD53 85 F0 41         [24] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD56 F5 42            [12] 1137 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AD58 D0 03            [24] 1138 	pop	ar3
      00AD5A D0 06            [24] 1139 	pop	ar6
      00AD5C D0 07            [24] 1140 	pop	ar7
                                   1141 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AD5E 12 38 8A         [24] 1142 	lcall	_ak820_outline_0124
      00AD61 A3               [24] 1143 	inc	dptr
      00AD62 A3               [24] 1144 	inc	dptr
      00AD63 E5 42            [12] 1145 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD65 12 43 13         [24] 1146 	lcall	_ak820_outline_0034
                                   1147 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AD68 A3               [24] 1148 	inc	dptr
      00AD69 E5 41            [12] 1149 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD6B F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AD6C 12 B1 CC         [24] 1152 	lcall	_ak820_outline_0025
      00AD6F E5 40            [12] 1153 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD71 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AD72 12 43 09         [24] 1156 	lcall	_ak820_outline_0014
      00AD75 E5 3F            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD77 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00AD78 D0 03            [24] 1160 	pop	ar3
      00AD7A 02 B1 9F         [24] 1161 	ljmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AD7D                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00AD7D 90 0E 79         [24] 1165 	mov	dptr,#_vial_unlocked
      00AD80 E0               [24] 1166 	movx	a,@dptr
      00AD81 70 03            [24] 1167 	jnz	00553$
      00AD83 02 B1 9F         [24] 1168 	ljmp	00171$
      00AD86                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AD86 7A 01            [12] 1171 	mov	r2,#0x01
      00AD88 79 00            [12] 1172 	mov	r1,#0x00
      00AD8A                       1173 00173$:
      00AD8A B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00AD8D                       1175 00554$:
      00AD8D 40 03            [24] 1176 	jc	00555$
      00AD8F 02 B1 9F         [24] 1177 	ljmp	00171$
      00AD92                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AD92 89 82            [24] 1180 	mov	dpl, r1
      00AD94 12 5F 95         [24] 1181 	lcall	_matrix_get_row
      00AD97 A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AD99 EA               [12] 1184 	mov	a,r2
      00AD9A 2C               [12] 1185 	add	a, r4
      00AD9B F5 82            [12] 1186 	mov	dpl,a
      00AD9D E4               [12] 1187 	clr	a
      00AD9E 3D               [12] 1188 	addc	a, r5
      00AD9F F5 83            [12] 1189 	mov	dph,a
      00ADA1 0A               [12] 1190 	inc	r2
      00ADA2 E8               [12] 1191 	mov	a,r0
      00ADA3 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00ADA4 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00ADA5 80 E3            [24] 1196 	sjmp	00173$
      00ADA7                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00ADA7 12 4E D9         [24] 1199 	lcall	_ak820_outline_0082
      00ADAA 90 0C 9F         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ADAD 12 B1 D5         [24] 1201 	lcall	_ak820_outline_0043
      00ADB0 C0 07            [24] 1202 	push	ar7
      00ADB2 C0 06            [24] 1203 	push	ar6
      00ADB4 C0 03            [24] 1204 	push	ar3
      00ADB6 91 19            [24] 1205 	acall	_raw_hid_receive_kb
      00ADB8 D0 03            [24] 1206 	pop	ar3
      00ADBA D0 06            [24] 1207 	pop	ar6
      00ADBC D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00ADBE 02 B1 9F         [24] 1210 	ljmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00ADC1                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00ADC1 12 43 4C         [24] 1214 	lcall	_ak820_outline_0100
      00ADC4 FA               [12] 1215 	mov	r2,a
      00ADC5 BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00ADC8 80 02            [24] 1217 	sjmp	00557$
      00ADCA                       1218 00556$:
      00ADCA C1 39            [12] 1219 	ajmp	00127$
      00ADCC                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00ADCC C0 03            [24] 1222 	push	ar3
      00ADCE 12 38 36         [24] 1223 	lcall	_ak820_outline_0037
      00ADD1 F8               [12] 1224 	mov	r0,a
      00ADD2 79 00            [12] 1225 	mov	r1,#0x00
      00ADD4 7B 00            [12] 1226 	mov	r3,#0x00
      00ADD6 88 42            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00ADD8 8B 3F            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00ADDA 8B 40            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00ADDC 8B 41            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00ADDE 12 B1 C3         [24] 1231 	lcall	_ak820_outline_0019
      00ADE1 F8               [12] 1232 	mov	r0,a
      00ADE2 89 03            [24] 1233 	mov	ar3,r1
      00ADE4 88 02            [24] 1234 	mov	ar2,r0
      00ADE6 E4               [12] 1235 	clr	a
      00ADE7 42 3F            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00ADE9 E9               [12] 1237 	mov	a,r1
      00ADEA 42 40            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ADEC EA               [12] 1239 	mov	a,r2
      00ADED 42 41            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ADEF EB               [12] 1241 	mov	a,r3
      00ADF0 42 42            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ADF2 12 B1 CC         [24] 1243 	lcall	_ak820_outline_0025
      00ADF5 E0               [24] 1244 	movx	a,@dptr
      00ADF6 F8               [12] 1245 	mov	r0,a
      00ADF7 79 00            [12] 1246 	mov	r1,#0x00
      00ADF9 7A 00            [12] 1247 	mov	r2,#0x00
      00ADFB 8A 03            [24] 1248 	mov	ar3,r2
      00ADFD 89 02            [24] 1249 	mov	ar2,r1
      00ADFF 88 01            [24] 1250 	mov	ar1,r0
      00AE01 E4               [12] 1251 	clr	a
      00AE02 42 3F            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00AE04 E9               [12] 1253 	mov	a,r1
      00AE05 42 40            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AE07 EA               [12] 1255 	mov	a,r2
      00AE08 42 41            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AE0A EB               [12] 1257 	mov	a,r3
      00AE0B 42 42            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AE0D 12 43 09         [24] 1259 	lcall	_ak820_outline_0014
      00AE10 E0               [24] 1260 	movx	a,@dptr
      00AE11 F8               [12] 1261 	mov	r0,a
      00AE12 E4               [12] 1262 	clr	a
      00AE13 F9               [12] 1263 	mov	r1,a
      00AE14 FA               [12] 1264 	mov	r2,a
      00AE15 FB               [12] 1265 	mov	r3,a
      00AE16 E5 40            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AE18 42 01            [12] 1267 	orl	ar1,a
      00AE1A E5 41            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AE1C 42 02            [12] 1269 	orl	ar2,a
      00AE1E E5 42            [12] 1270 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AE20 42 03            [12] 1271 	orl	ar3,a
                                   1272 ;	quantum/via.c:323: via_set_layout_options(value);
      00AE22 12 4E EE         [24] 1273 	lcall	_ak820_outline_0117
      00AE25 EB               [12] 1274 	mov	a, r3
      00AE26 C0 07            [24] 1275 	push	ar7
      00AE28 C0 06            [24] 1276 	push	ar6
      00AE2A C0 03            [24] 1277 	push	ar3
      00AE2C 71 C2            [12] 1278 	acall	_via_set_layout_options
      00AE2E D0 03            [24] 1279 	pop	ar3
      00AE30 D0 06            [24] 1280 	pop	ar6
      00AE32 D0 07            [24] 1281 	pop	ar7
                                   1282 ;	quantum/via.c:324: break;
      00AE34 D0 03            [24] 1283 	pop	ar3
      00AE36 02 B1 9F         [24] 1284 	ljmp	00171$
                                   1285 ;	quantum/via.c:326: default: {
      00AE39                       1286 00127$:
                                   1287 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AE39 12 4E D9         [24] 1288 	lcall	_ak820_outline_0082
      00AE3C 90 0C 9F         [24] 1289 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AE3F 12 B1 D5         [24] 1290 	lcall	_ak820_outline_0043
      00AE42 C0 07            [24] 1291 	push	ar7
      00AE44 C0 06            [24] 1292 	push	ar6
      00AE46 C0 03            [24] 1293 	push	ar3
      00AE48 91 19            [24] 1294 	acall	_raw_hid_receive_kb
      00AE4A D0 03            [24] 1295 	pop	ar3
      00AE4C D0 06            [24] 1296 	pop	ar6
      00AE4E D0 07            [24] 1297 	pop	ar7
                                   1298 ;	quantum/via.c:331: break;
      00AE50 02 B1 9F         [24] 1299 	ljmp	00171$
                                   1300 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AE53                       1301 00129$:
                                   1302 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AE53 12 43 4C         [24] 1303 	lcall	_ak820_outline_0100
      00AE56 FA               [12] 1304 	mov	r2,a
      00AE57 12 38 36         [24] 1305 	lcall	_ak820_outline_0037
      00AE5A F9               [12] 1306 	mov	r1,a
      00AE5B 12 B1 C3         [24] 1307 	lcall	_ak820_outline_0019
      00AE5E F8               [12] 1308 	mov	r0,a
      00AE5F 90 0B 2B         [24] 1309 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AE62 E9               [12] 1310 	mov	a,r1
      00AE63 F0               [24] 1311 	movx	@dptr,a
      00AE64 90 0B 2C         [24] 1312 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AE67 E8               [12] 1313 	mov	a,r0
      00AE68 F0               [24] 1314 	movx	@dptr,a
      00AE69 8A 82            [24] 1315 	mov	dpl, r2
      00AE6B C0 07            [24] 1316 	push	ar7
      00AE6D C0 06            [24] 1317 	push	ar6
      00AE6F C0 03            [24] 1318 	push	ar3
      00AE71 12 89 5E         [24] 1319 	lcall	_dynamic_keymap_get_keycode
      00AE74 12 4F 08         [24] 1320 	lcall	_ak820_outline_0194
      00AE77 D0 03            [24] 1321 	pop	ar3
      00AE79 D0 06            [24] 1322 	pop	ar6
      00AE7B D0 07            [24] 1323 	pop	ar7
                                   1324 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AE7D 12 B1 CC         [24] 1325 	lcall	_ak820_outline_0025
      00AE80 8A 00            [24] 1326 	mov	ar0,r2
      00AE82 E8               [12] 1327 	mov	a,r0
      00AE83 F0               [24] 1328 	movx	@dptr,a
                                   1329 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AE84 12 43 09         [24] 1330 	lcall	_ak820_outline_0014
      00AE87 E9               [12] 1331 	mov	a,r1
      00AE88 F0               [24] 1332 	movx	@dptr,a
                                   1333 ;	quantum/via.c:337: break;
      00AE89 02 B1 9F         [24] 1334 	ljmp	00171$
                                   1335 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AE8C                       1336 00130$:
                                   1337 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AE8C 90 0E 79         [24] 1338 	mov	dptr,#_vial_unlocked
      00AE8F E0               [24] 1339 	movx	a,@dptr
      00AE90 70 19            [24] 1340 	jnz	00132$
      00AE92 12 B1 CC         [24] 1341 	lcall	_ak820_outline_0025
      00AE95 E0               [24] 1342 	movx	a,@dptr
      00AE96 FA               [12] 1343 	mov	r2,a
      00AE97 BA 7C 11         [24] 1344 	cjne	r2,#0x7c,00132$
      00AE9A 74 05            [12] 1345 	mov	a,#0x05
      00AE9C 2E               [12] 1346 	add	a, r6
      00AE9D 12 38 1C         [24] 1347 	lcall	_ak820_outline_0017
      00AEA0 70 09            [24] 1348 	jnz	00132$
                                   1349 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AEA2 12 38 8A         [24] 1350 	lcall	_ak820_outline_0124
      00AEA5 74 FF            [12] 1351 	mov	a,#0xff
      00AEA7 F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/via.c:345: break;
      00AEA8 02 B1 9F         [24] 1354 	ljmp	00171$
      00AEAB                       1355 00132$:
                                   1356 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AEAB C0 03            [24] 1357 	push	ar3
      00AEAD 12 43 4C         [24] 1358 	lcall	_ak820_outline_0100
      00AEB0 F5 44            [12] 1359 	mov	_raw_hid_receive_sloc2_1_0,a
      00AEB2 12 38 36         [24] 1360 	lcall	_ak820_outline_0037
      00AEB5 F5 43            [12] 1361 	mov	_raw_hid_receive_sloc1_1_0,a
      00AEB7 12 B1 C3         [24] 1362 	lcall	_ak820_outline_0019
      00AEBA F5 3F            [12] 1363 	mov	_raw_hid_receive_sloc0_1_0,a
      00AEBC 12 B1 CC         [24] 1364 	lcall	_ak820_outline_0025
      00AEBF E0               [24] 1365 	movx	a,@dptr
      00AEC0 FB               [12] 1366 	mov	r3,a
      00AEC1 78 00            [12] 1367 	mov	r0,#0x00
      00AEC3 12 43 09         [24] 1368 	lcall	_ak820_outline_0014
      00AEC6 E0               [24] 1369 	movx	a,@dptr
      00AEC7 7A 00            [12] 1370 	mov	r2,#0x00
      00AEC9 42 00            [12] 1371 	orl	ar0,a
      00AECB EA               [12] 1372 	mov	a,r2
      00AECC 42 03            [12] 1373 	orl	ar3,a
      00AECE 90 0B 2E         [24] 1374 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00AED1 E5 43            [12] 1375 	mov	a,_raw_hid_receive_sloc1_1_0
      00AED3 F0               [24] 1376 	movx	@dptr,a
      00AED4 90 0B 2F         [24] 1377 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00AED7 E5 3F            [12] 1378 	mov	a,_raw_hid_receive_sloc0_1_0
      00AED9 F0               [24] 1379 	movx	@dptr,a
      00AEDA 90 0B 30         [24] 1380 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00AEDD E8               [12] 1381 	mov	a,r0
      00AEDE 12 49 C4         [24] 1382 	lcall	_ak820_outline_0195
      00AEE1 85 44 82         [24] 1383 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00AEE4 C0 07            [24] 1384 	push	ar7
      00AEE6 C0 06            [24] 1385 	push	ar6
      00AEE8 C0 03            [24] 1386 	push	ar3
      00AEEA 12 89 AB         [24] 1387 	lcall	_dynamic_keymap_set_keycode
      00AEED D0 03            [24] 1388 	pop	ar3
      00AEEF D0 06            [24] 1389 	pop	ar6
      00AEF1 D0 07            [24] 1390 	pop	ar7
                                   1391 ;	quantum/via.c:349: break;
      00AEF3 D0 03            [24] 1392 	pop	ar3
      00AEF5 02 B1 9F         [24] 1393 	ljmp	00171$
                                   1394 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00AEF8                       1395 00135$:
                                   1396 ;	quantum/via.c:352: dynamic_keymap_reset();
      00AEF8 C0 07            [24] 1397 	push	ar7
      00AEFA C0 06            [24] 1398 	push	ar6
      00AEFC C0 03            [24] 1399 	push	ar3
      00AEFE 12 8C 2F         [24] 1400 	lcall	_dynamic_keymap_reset
      00AF01 D0 03            [24] 1401 	pop	ar3
      00AF03 D0 06            [24] 1402 	pop	ar6
      00AF05 D0 07            [24] 1403 	pop	ar7
                                   1404 ;	quantum/via.c:353: break;
      00AF07 02 B1 9F         [24] 1405 	ljmp	00171$
                                   1406 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AF0A                       1407 00136$:
                                   1408 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AF0A 12 4E D9         [24] 1409 	lcall	_ak820_outline_0082
      00AF0D 90 0D EA         [24] 1410 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AF10 12 B1 D5         [24] 1411 	lcall	_ak820_outline_0043
      00AF13 C0 07            [24] 1412 	push	ar7
      00AF15 C0 06            [24] 1413 	push	ar6
      00AF17 C0 03            [24] 1414 	push	ar3
      00AF19 12 BC EA         [24] 1415 	lcall	_vialrgb_set_value
      00AF1C D0 03            [24] 1416 	pop	ar3
      00AF1E D0 06            [24] 1417 	pop	ar6
      00AF20 D0 07            [24] 1418 	pop	ar7
                                   1419 ;	quantum/via.c:375: break;
      00AF22 02 B1 9F         [24] 1420 	ljmp	00171$
                                   1421 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AF25                       1422 00137$:
                                   1423 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AF25 12 4E D9         [24] 1424 	lcall	_ak820_outline_0082
      00AF28 90 0D E6         [24] 1425 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AF2B 12 B1 D5         [24] 1426 	lcall	_ak820_outline_0043
      00AF2E C0 07            [24] 1427 	push	ar7
      00AF30 C0 06            [24] 1428 	push	ar6
      00AF32 C0 03            [24] 1429 	push	ar3
      00AF34 12 BB 86         [24] 1430 	lcall	_vialrgb_get_value
      00AF37 D0 03            [24] 1431 	pop	ar3
      00AF39 D0 06            [24] 1432 	pop	ar6
      00AF3B D0 07            [24] 1433 	pop	ar7
                                   1434 ;	quantum/via.c:397: break;
      00AF3D 02 B1 9F         [24] 1435 	ljmp	00171$
                                   1436 ;	quantum/via.c:399: case id_lighting_save: {
      00AF40                       1437 00138$:
                                   1438 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AF40 12 4E D9         [24] 1439 	lcall	_ak820_outline_0082
      00AF43 90 0D EE         [24] 1440 	mov	dptr,#_vialrgb_save_PARM_2
      00AF46 12 B1 D5         [24] 1441 	lcall	_ak820_outline_0043
      00AF49 C0 07            [24] 1442 	push	ar7
      00AF4B C0 06            [24] 1443 	push	ar6
      00AF4D C0 03            [24] 1444 	push	ar3
      00AF4F 12 BD 76         [24] 1445 	lcall	_vialrgb_save
      00AF52 D0 03            [24] 1446 	pop	ar3
      00AF54 D0 06            [24] 1447 	pop	ar6
      00AF56 D0 07            [24] 1448 	pop	ar7
                                   1449 ;	quantum/via.c:419: break;
      00AF58 02 B1 9F         [24] 1450 	ljmp	00171$
                                   1451 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AF5B                       1452 00139$:
                                   1453 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AF5B C0 07            [24] 1454 	push	ar7
      00AF5D C0 06            [24] 1455 	push	ar6
      00AF5F C0 05            [24] 1456 	push	ar5
      00AF61 C0 04            [24] 1457 	push	ar4
      00AF63 C0 03            [24] 1458 	push	ar3
      00AF65 12 90 1A         [24] 1459 	lcall	_dynamic_keymap_macro_get_count
      00AF68 AA 82            [24] 1460 	mov	r2, dpl
      00AF6A D0 03            [24] 1461 	pop	ar3
      00AF6C D0 04            [24] 1462 	pop	ar4
      00AF6E D0 05            [24] 1463 	pop	ar5
      00AF70 D0 06            [24] 1464 	pop	ar6
      00AF72 D0 07            [24] 1465 	pop	ar7
      00AF74 12 38 A0         [24] 1466 	lcall	_ak820_outline_0133
      00AF77 EA               [12] 1467 	mov	a,r2
      00AF78 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/via.c:430: break;
      00AF79 02 B1 9F         [24] 1470 	ljmp	00171$
                                   1471 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AF7C                       1472 00140$:
                                   1473 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AF7C C0 07            [24] 1474 	push	ar7
      00AF7E C0 06            [24] 1475 	push	ar6
      00AF80 C0 05            [24] 1476 	push	ar5
      00AF82 C0 04            [24] 1477 	push	ar4
      00AF84 C0 03            [24] 1478 	push	ar3
      00AF86 12 90 1E         [24] 1479 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AF89 12 4F 08         [24] 1480 	lcall	_ak820_outline_0194
      00AF8C D0 03            [24] 1481 	pop	ar3
      00AF8E D0 04            [24] 1482 	pop	ar4
      00AF90 D0 05            [24] 1483 	pop	ar5
      00AF92 D0 06            [24] 1484 	pop	ar6
      00AF94 D0 07            [24] 1485 	pop	ar7
                                   1486 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AF96 8A 00            [24] 1487 	mov	ar0,r2
      00AF98 12 38 A0         [24] 1488 	lcall	_ak820_outline_0133
      00AF9B E8               [12] 1489 	mov	a,r0
      00AF9C 12 43 13         [24] 1490 	lcall	_ak820_outline_0034
                                   1491 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AF9F E9               [12] 1492 	mov	a,r1
      00AFA0 F0               [24] 1493 	movx	@dptr,a
                                   1494 ;	quantum/via.c:436: break;
      00AFA1 02 B1 9F         [24] 1495 	ljmp	00171$
                                   1496 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AFA4                       1497 00141$:
                                   1498 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AFA4 C0 03            [24] 1499 	push	ar3
      00AFA6 12 B1 AC         [24] 1500 	lcall	_ak820_outline_0003
      00AFA9 89 3F            [24] 1501 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AFAB 8A 40            [24] 1502 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1503 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AFAD 12 B1 C3         [24] 1504 	lcall	_ak820_outline_0019
      00AFB0 FB               [12] 1505 	mov	r3,a
                                   1506 ;	quantum/via.c:441: if (size <= 28)
      00AFB1 8B 45            [24] 1507 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AFB3 75 46 00         [24] 1508 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AFB6 C3               [12] 1509 	clr	c
      00AFB7 74 1C            [12] 1510 	mov	a,#0x1c
      00AFB9 9B               [12] 1511 	subb	a,r3
      00AFBA D0 03            [24] 1512 	pop	ar3
      00AFBC 50 03            [24] 1513 	jnc	00562$
      00AFBE 02 B1 9F         [24] 1514 	ljmp	00171$
      00AFC1                       1515 00562$:
                                   1516 ;	free result
                                   1517 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AFC1 12 B1 DE         [24] 1518 	lcall	_ak820_outline_0073
      00AFC4 90 0B 7D         [24] 1519 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AFC7 E5 45            [12] 1520 	mov	a,_raw_hid_receive_sloc3_1_0
      00AFC9 F0               [24] 1521 	movx	@dptr,a
      00AFCA E5 46            [12] 1522 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AFCC A3               [24] 1523 	inc	dptr
      00AFCD F0               [24] 1524 	movx	@dptr,a
      00AFCE 90 0B 7F         [24] 1525 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AFD1 12 B1 E8         [24] 1526 	lcall	_ak820_outline_0092
      00AFD4 85 3F 82         [24] 1527 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AFD7 85 40 83         [24] 1528 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AFDA C0 07            [24] 1529 	push	ar7
      00AFDC C0 06            [24] 1530 	push	ar6
      00AFDE C0 03            [24] 1531 	push	ar3
      00AFE0 12 90 22         [24] 1532 	lcall	_dynamic_keymap_macro_get_buffer
      00AFE3 D0 03            [24] 1533 	pop	ar3
      00AFE5 D0 06            [24] 1534 	pop	ar6
      00AFE7 D0 07            [24] 1535 	pop	ar7
                                   1536 ;	quantum/via.c:443: break;
      00AFE9 02 B1 9F         [24] 1537 	ljmp	00171$
                                   1538 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AFEC                       1539 00144$:
                                   1540 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AFEC 90 0E 79         [24] 1541 	mov	dptr,#_vial_unlocked
      00AFEF E0               [24] 1542 	movx	a,@dptr
      00AFF0 70 01            [24] 1543 	jnz	00146$
                                   1544 ;	quantum/via.c:450: return;
      00AFF2 22               [24] 1545 	ret
      00AFF3                       1546 00146$:
                                   1547 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AFF3 C0 03            [24] 1548 	push	ar3
      00AFF5 12 B1 AC         [24] 1549 	lcall	_ak820_outline_0003
      00AFF8 89 45            [24] 1550 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AFFA 8A 46            [24] 1551 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1552 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AFFC 12 B1 C3         [24] 1553 	lcall	_ak820_outline_0019
      00AFFF F5 3F            [12] 1554 	mov	_raw_hid_receive_sloc0_1_0, a
      00B001 75 40 00         [24] 1555 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1556 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00B004 85 3F 47         [24] 1557 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00B007 85 40 48         [24] 1558 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00B00A C3               [12] 1559 	clr	c
      00B00B 74 1C            [12] 1560 	mov	a,#0x1c
      00B00D 95 47            [12] 1561 	subb	a,_raw_hid_receive_sloc4_1_0
      00B00F E4               [12] 1562 	clr	a
      00B010 95 48            [12] 1563 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B012 D0 03            [24] 1564 	pop	ar3
      00B014 40 43            [24] 1565 	jc	00147$
                                   1566 ;	free result
      00B016 8B 01            [24] 1567 	mov	ar1,r3
      00B018 7A 00            [12] 1568 	mov	r2,#0x00
      00B01A E9               [12] 1569 	mov	a,r1
      00B01B 24 FC            [12] 1570 	add	a,#0xfc
      00B01D F9               [12] 1571 	mov	r1,a
      00B01E EA               [12] 1572 	mov	a,r2
      00B01F 34 FF            [12] 1573 	addc	a,#0xff
      00B021 FA               [12] 1574 	mov	r2,a
      00B022 C3               [12] 1575 	clr	c
      00B023 E9               [12] 1576 	mov	a,r1
      00B024 95 47            [12] 1577 	subb	a,_raw_hid_receive_sloc4_1_0
      00B026 EA               [12] 1578 	mov	a,r2
      00B027 95 48            [12] 1579 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B029 40 2E            [24] 1580 	jc	00147$
                                   1581 ;	free result
      00B02B 12 B1 DE         [24] 1582 	lcall	_ak820_outline_0073
      00B02E 90 0B 84         [24] 1583 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00B031 E5 3F            [12] 1584 	mov	a,_raw_hid_receive_sloc0_1_0
      00B033 F0               [24] 1585 	movx	@dptr,a
      00B034 E5 40            [12] 1586 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B036 A3               [24] 1587 	inc	dptr
      00B037 F0               [24] 1588 	movx	@dptr,a
      00B038 90 0B 86         [24] 1589 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00B03B 12 B1 E8         [24] 1590 	lcall	_ak820_outline_0092
      00B03E 85 45 82         [24] 1591 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00B041 85 46 83         [24] 1592 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00B044 C0 07            [24] 1593 	push	ar7
      00B046 C0 06            [24] 1594 	push	ar6
      00B048 C0 03            [24] 1595 	push	ar3
      00B04A 12 90 70         [24] 1596 	lcall	_dynamic_keymap_macro_set_buffer
      00B04D E5 82            [12] 1597 	mov	a, dpl
      00B04F D0 03            [24] 1598 	pop	ar3
      00B051 D0 06            [24] 1599 	pop	ar6
      00B053 D0 07            [24] 1600 	pop	ar7
      00B055 60 02            [24] 1601 	jz	00566$
      00B057 21 9F            [12] 1602 	ajmp	00171$
      00B059                       1603 00566$:
      00B059                       1604 00147$:
      00B059 22               [24] 1605 	ret
                                   1606 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B05A                       1607 00151$:
                                   1608 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B05A 90 0E 79         [24] 1609 	mov	dptr,#_vial_unlocked
      00B05D E0               [24] 1610 	movx	a,@dptr
      00B05E 70 01            [24] 1611 	jnz	00153$
      00B060 22               [24] 1612 	ret
      00B061                       1613 00153$:
                                   1614 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B061 C0 07            [24] 1615 	push	ar7
      00B063 C0 06            [24] 1616 	push	ar6
      00B065 C0 03            [24] 1617 	push	ar3
      00B067 12 90 9F         [24] 1618 	lcall	_dynamic_keymap_macro_reset
      00B06A D0 03            [24] 1619 	pop	ar3
      00B06C D0 06            [24] 1620 	pop	ar6
      00B06E D0 07            [24] 1621 	pop	ar7
                                   1622 ;	quantum/via.c:473: break;
      00B070 21 9F            [12] 1623 	ajmp	00171$
                                   1624 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B072                       1625 00154$:
                                   1626 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B072 C0 07            [24] 1627 	push	ar7
      00B074 C0 06            [24] 1628 	push	ar6
      00B076 C0 05            [24] 1629 	push	ar5
      00B078 C0 04            [24] 1630 	push	ar4
      00B07A C0 03            [24] 1631 	push	ar3
      00B07C 12 89 25         [24] 1632 	lcall	_dynamic_keymap_get_layer_count
      00B07F AA 82            [24] 1633 	mov	r2, dpl
      00B081 D0 03            [24] 1634 	pop	ar3
      00B083 D0 04            [24] 1635 	pop	ar4
      00B085 D0 05            [24] 1636 	pop	ar5
      00B087 D0 06            [24] 1637 	pop	ar6
      00B089 D0 07            [24] 1638 	pop	ar7
      00B08B 12 38 A0         [24] 1639 	lcall	_ak820_outline_0133
      00B08E EA               [12] 1640 	mov	a,r2
      00B08F F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	quantum/via.c:477: break;
      00B090 21 9F            [12] 1643 	ajmp	00171$
                                   1644 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B092                       1645 00155$:
                                   1646 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B092 C0 03            [24] 1647 	push	ar3
      00B094 12 B1 AC         [24] 1648 	lcall	_ak820_outline_0003
      00B097 89 47            [24] 1649 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B099 8A 48            [24] 1650 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1651 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B09B 12 B1 C3         [24] 1652 	lcall	_ak820_outline_0019
      00B09E FB               [12] 1653 	mov	r3,a
                                   1654 ;	quantum/via.c:482: if (size <= 28)
      00B09F 8B 45            [24] 1655 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B0A1 75 46 00         [24] 1656 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B0A4 C3               [12] 1657 	clr	c
      00B0A5 74 1C            [12] 1658 	mov	a,#0x1c
      00B0A7 9B               [12] 1659 	subb	a,r3
      00B0A8 D0 03            [24] 1660 	pop	ar3
      00B0AA 50 02            [24] 1661 	jnc	00568$
      00B0AC 21 9F            [12] 1662 	ajmp	00171$
      00B0AE                       1663 00568$:
                                   1664 ;	free result
                                   1665 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B0AE 12 B1 DE         [24] 1666 	lcall	_ak820_outline_0073
      00B0B1 90 0B 66         [24] 1667 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B0B4 E5 45            [12] 1668 	mov	a,_raw_hid_receive_sloc3_1_0
      00B0B6 F0               [24] 1669 	movx	@dptr,a
      00B0B7 E5 46            [12] 1670 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B0B9 A3               [24] 1671 	inc	dptr
      00B0BA F0               [24] 1672 	movx	@dptr,a
      00B0BB 90 0B 68         [24] 1673 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B0BE 12 B1 E8         [24] 1674 	lcall	_ak820_outline_0092
      00B0C1 85 47 82         [24] 1675 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B0C4 85 48 83         [24] 1676 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B0C7 C0 07            [24] 1677 	push	ar7
      00B0C9 C0 06            [24] 1678 	push	ar6
      00B0CB C0 03            [24] 1679 	push	ar3
      00B0CD 12 8D EB         [24] 1680 	lcall	_dynamic_keymap_get_buffer
      00B0D0 D0 03            [24] 1681 	pop	ar3
      00B0D2 D0 06            [24] 1682 	pop	ar6
      00B0D4 D0 07            [24] 1683 	pop	ar7
                                   1684 ;	quantum/via.c:484: break;
      00B0D6 21 9F            [12] 1685 	ajmp	00171$
                                   1686 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B0D8                       1687 00158$:
                                   1688 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B0D8 12 43 4C         [24] 1689 	lcall	_ak820_outline_0100
      00B0DB FD               [12] 1690 	mov	r5,a
      00B0DC 7C 00            [12] 1691 	mov	r4,#0x00
      00B0DE 12 38 36         [24] 1692 	lcall	_ak820_outline_0037
      00B0E1 7A 00            [12] 1693 	mov	r2,#0x00
      00B0E3 42 04            [12] 1694 	orl	ar4,a
      00B0E5 EA               [12] 1695 	mov	a,r2
      00B0E6 42 05            [12] 1696 	orl	ar5,a
      00B0E8 8C 47            [24] 1697 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B0EA 8D 48            [24] 1698 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1699 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B0EC 12 B1 C3         [24] 1700 	lcall	_ak820_outline_0019
      00B0EF F9               [12] 1701 	mov	r1,a
      00B0F0 7A 00            [12] 1702 	mov	r2,#0x00
                                   1703 ;	quantum/via.c:489: if (size <= 28)
      00B0F2 89 00            [24] 1704 	mov	ar0,r1
      00B0F4 E8               [12] 1705 	mov	a,r0
      00B0F5 24 E3            [12] 1706 	add	a,#0xff - 0x1c
      00B0F7 50 02            [24] 1707 	jnc	00569$
      00B0F9 21 9F            [12] 1708 	ajmp	00171$
      00B0FB                       1709 00569$:
                                   1710 ;	free result
                                   1711 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B0FB C0 03            [24] 1712 	push	ar3
      00B0FD 74 04            [12] 1713 	mov	a,#0x04
      00B0FF 2E               [12] 1714 	add	a, r6
      00B100 F8               [12] 1715 	mov	r0,a
      00B101 E4               [12] 1716 	clr	a
      00B102 3F               [12] 1717 	addc	a, r7
      00B103 FB               [12] 1718 	mov	r3,a
      00B104 7D 00            [12] 1719 	mov	r5,#0x00
      00B106 90 0B 6D         [24] 1720 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B109 12 4E FB         [24] 1721 	lcall	_ak820_outline_0145
      00B10C 90 0B 6F         [24] 1722 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B10F E8               [12] 1723 	mov	a,r0
      00B110 12 49 C4         [24] 1724 	lcall	_ak820_outline_0195
      00B113 ED               [12] 1725 	mov	a,r5
      00B114 A3               [24] 1726 	inc	dptr
      00B115 F0               [24] 1727 	movx	@dptr,a
      00B116 85 47 82         [24] 1728 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B119 85 48 83         [24] 1729 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B11C C0 07            [24] 1730 	push	ar7
      00B11E C0 06            [24] 1731 	push	ar6
      00B120 C0 03            [24] 1732 	push	ar3
      00B122 12 8E 29         [24] 1733 	lcall	_dynamic_keymap_set_buffer
      00B125 D0 03            [24] 1734 	pop	ar3
      00B127 D0 06            [24] 1735 	pop	ar6
      00B129 D0 07            [24] 1736 	pop	ar7
                                   1737 ;	quantum/via.c:491: break;
      00B12B D0 03            [24] 1738 	pop	ar3
      00B12D 21 9F            [12] 1739 	ajmp	00171$
                                   1740 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B12F                       1741 00161$:
                                   1742 ;	quantum/via.c:497: if (!vial_unlocked)
      00B12F 90 0E 79         [24] 1743 	mov	dptr,#_vial_unlocked
      00B132 E0               [24] 1744 	movx	a,@dptr
      00B133 70 02            [24] 1745 	jnz	00570$
      00B135 21 9F            [12] 1746 	ajmp	00171$
      00B137                       1747 00570$:
                                   1748 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B137 12 B1 FA         [24] 1749 	lcall	_ak820_outline_0161
      00B13A 90 06 C8         [24] 1750 	mov	dptr,#_raw_hid_send_PARM_2
      00B13D 12 B1 F1         [24] 1751 	lcall	_ak820_outline_0093
      00B140 C0 07            [24] 1752 	push	ar7
      00B142 C0 06            [24] 1753 	push	ar6
      00B144 C0 03            [24] 1754 	push	ar3
      00B146 12 51 3E         [24] 1755 	lcall	_raw_hid_send
      00B149 D0 03            [24] 1756 	pop	ar3
      00B14B D0 06            [24] 1757 	pop	ar6
      00B14D D0 07            [24] 1758 	pop	ar7
                                   1759 ;	quantum/via.c:503: wait_ms(100);
      00B14F 7D 64            [12] 1760 	mov	r5,#0x64
      00B151                       1761 00176$:
      00B151 ED               [12] 1762 	mov	a,r5
      00B152 60 09            [24] 1763 	jz	00166$
      00B154 90 00 01         [24] 1764 	mov	dptr,#0x0001
      00B157 12 5E D4         [24] 1765 	lcall	_mDelaymS
      00B15A 1D               [12] 1766 	dec	r5
      00B15B 80 F4            [24] 1767 	sjmp	00176$
      00B15D                       1768 00166$:
                                   1769 ;	quantum/via.c:504: bootloader_jump();
      00B15D C0 07            [24] 1770 	push	ar7
      00B15F C0 06            [24] 1771 	push	ar6
      00B161 C0 03            [24] 1772 	push	ar3
      00B163 12 34 0E         [24] 1773 	lcall	_bootloader_jump
      00B166 D0 03            [24] 1774 	pop	ar3
      00B168 D0 06            [24] 1775 	pop	ar6
      00B16A D0 07            [24] 1776 	pop	ar7
                                   1777 ;	quantum/via.c:505: break;
                                   1778 ;	quantum/via.c:509: case id_vial_prefix: {
      00B16C 80 31            [24] 1779 	sjmp	00171$
      00B16E                       1780 00168$:
                                   1781 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B16E 12 B1 FA         [24] 1782 	lcall	_ak820_outline_0161
      00B171 90 0C B1         [24] 1783 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B174 12 B1 F1         [24] 1784 	lcall	_ak820_outline_0093
      00B177 C0 07            [24] 1785 	push	ar7
      00B179 C0 06            [24] 1786 	push	ar6
      00B17B C0 03            [24] 1787 	push	ar3
      00B17D 51 EA            [12] 1788 	acall	_vial_handle_cmd
      00B17F D0 03            [24] 1789 	pop	ar3
      00B181 D0 06            [24] 1790 	pop	ar6
      00B183 D0 07            [24] 1791 	pop	ar7
                                   1792 ;	quantum/via.c:511: break;
                                   1793 ;	quantum/via.c:514: default: {
      00B185 80 18            [24] 1794 	sjmp	00171$
      00B187                       1795 00169$:
                                   1796 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B187 12 B1 FA         [24] 1797 	lcall	_ak820_outline_0161
      00B18A 90 0C 9F         [24] 1798 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B18D 12 B1 F1         [24] 1799 	lcall	_ak820_outline_0093
      00B190 C0 07            [24] 1800 	push	ar7
      00B192 C0 06            [24] 1801 	push	ar6
      00B194 C0 03            [24] 1802 	push	ar3
      00B196 12 AC 19         [24] 1803 	lcall	_raw_hid_receive_kb
      00B199 D0 03            [24] 1804 	pop	ar3
      00B19B D0 06            [24] 1805 	pop	ar6
      00B19D D0 07            [24] 1806 	pop	ar7
                                   1807 ;	quantum/via.c:521: skip:
      00B19F                       1808 00171$:
                                   1809 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B19F 7D 00            [12] 1810 	mov	r5,#0x00
      00B1A1 90 06 C8         [24] 1811 	mov	dptr,#_raw_hid_send_PARM_2
      00B1A4 EB               [12] 1812 	mov	a,r3
      00B1A5 F0               [24] 1813 	movx	@dptr,a
      00B1A6 12 49 7E         [24] 1814 	lcall	_ak820_outline_0061
                                   1815 ;	quantum/via.c:526: }
      00B1A9 02 51 3E         [24] 1816 	ljmp	_raw_hid_send
                                   1817 	.area CSEG    (CODE)
                                   1818 	.area CONST   (CODE)
                                   1819 	.area XINIT   (CODE)
                                   1820 	.area CABS    (ABS,CODE)
                                   1821 
                                   1822 ; Experimental exact instruction outlining.
                                   1823 	.globl _ak820_outline_0001
                                   1824 	.globl _ak820_outline_0003
                                   1825 	.globl _ak820_outline_0009
                                   1826 	.globl _ak820_outline_0013
                                   1827 	.globl _ak820_outline_0014
                                   1828 	.globl _ak820_outline_0017
                                   1829 	.globl _ak820_outline_0018
                                   1830 	.globl _ak820_outline_0019
                                   1831 	.globl _ak820_outline_0025
                                   1832 	.globl _ak820_outline_0034
                                   1833 	.globl _ak820_outline_0037
                                   1834 	.globl _ak820_outline_0038
                                   1835 	.globl _ak820_outline_0043
                                   1836 	.globl _ak820_outline_0046
                                   1837 	.globl _ak820_outline_0050
                                   1838 	.globl _ak820_outline_0055
                                   1839 	.globl _ak820_outline_0061
                                   1840 	.globl _ak820_outline_0073
                                   1841 	.globl _ak820_outline_0082
                                   1842 	.globl _ak820_outline_0092
                                   1843 	.globl _ak820_outline_0093
                                   1844 	.globl _ak820_outline_0100
                                   1845 	.globl _ak820_outline_0113
                                   1846 	.globl _ak820_outline_0114
                                   1847 	.globl _ak820_outline_0117
                                   1848 	.globl _ak820_outline_0124
                                   1849 	.globl _ak820_outline_0126
                                   1850 	.globl _ak820_outline_0133
                                   1851 	.globl _ak820_outline_0145
                                   1852 	.globl _ak820_outline_0159
                                   1853 	.globl _ak820_outline_0161
                                   1854 	.globl _ak820_outline_0163
                                   1855 	.globl _ak820_outline_0166
                                   1856 	.globl _ak820_outline_0168
                                   1857 	.globl _ak820_outline_0169
                                   1858 	.globl _ak820_outline_0194
                                   1859 	.globl _ak820_outline_0195
                                   1860 
                                   1861 	.area CSEG (CODE)
                                   1862 ; function ak820_outline_0003
      00B1AC                       1863 _ak820_outline_0003:
      00B1AC 8C 82            [24] 1864 	mov	dpl,r4
      00B1AE 8D 83            [24] 1865 	mov	dph,r5
      00B1B0 E0               [24] 1866 	movx	a,@dptr
      00B1B1 FA               [12] 1867 	mov	r2,a
      00B1B2 79 00            [12] 1868 	mov	r1,#0x00
      00B1B4 8E 82            [24] 1869 	mov	dpl,r6
      00B1B6 8F 83            [24] 1870 	mov	dph,r7
      00B1B8 A3               [24] 1871 	inc	dptr
      00B1B9 A3               [24] 1872 	inc	dptr
      00B1BA E0               [24] 1873 	movx	a,@dptr
      00B1BB 7B 00            [12] 1874 	mov	r3,#0x00
      00B1BD 42 01            [12] 1875 	orl	ar1,a
      00B1BF EB               [12] 1876 	mov	a,r3
      00B1C0 42 02            [12] 1877 	orl	ar2,a
      00B1C2 22               [24] 1878 	ret
                                   1879 
                                   1880 	.area CSEG (CODE)
                                   1881 ; function ak820_outline_0019
      00B1C3                       1882 _ak820_outline_0019:
      00B1C3 8E 82            [24] 1883 	mov	dpl,r6
      00B1C5 8F 83            [24] 1884 	mov	dph,r7
      00B1C7 A3               [24] 1885 	inc	dptr
      00B1C8 A3               [24] 1886 	inc	dptr
      00B1C9 A3               [24] 1887 	inc	dptr
      00B1CA E0               [24] 1888 	movx	a,@dptr
      00B1CB 22               [24] 1889 	ret
                                   1890 
                                   1891 	.area CSEG (CODE)
                                   1892 ; function ak820_outline_0025
      00B1CC                       1893 _ak820_outline_0025:
      00B1CC 8E 82            [24] 1894 	mov	dpl,r6
      00B1CE 8F 83            [24] 1895 	mov	dph,r7
      00B1D0 A3               [24] 1896 	inc	dptr
      00B1D1 A3               [24] 1897 	inc	dptr
      00B1D2 A3               [24] 1898 	inc	dptr
      00B1D3 A3               [24] 1899 	inc	dptr
      00B1D4 22               [24] 1900 	ret
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0043
      00B1D5                       1904 _ak820_outline_0043:
      00B1D5 EB               [12] 1905 	mov	a,r3
      00B1D6 F0               [24] 1906 	movx	@dptr,a
      00B1D7 88 82            [24] 1907 	mov	dpl,r0
      00B1D9 89 83            [24] 1908 	mov	dph,r1
      00B1DB 8A F0            [24] 1909 	mov	b,r2
      00B1DD 22               [24] 1910 	ret
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0073
      00B1DE                       1914 _ak820_outline_0073:
      00B1DE 74 04            [12] 1915 	mov	a,#0x04
      00B1E0 2E               [12] 1916 	add	a,r6
      00B1E1 F9               [12] 1917 	mov	r1,a
      00B1E2 E4               [12] 1918 	clr	a
      00B1E3 3F               [12] 1919 	addc	a,r7
      00B1E4 F8               [12] 1920 	mov	r0,a
      00B1E5 7A 00            [12] 1921 	mov	r2,#0x00
      00B1E7 22               [24] 1922 	ret
                                   1923 
                                   1924 	.area CSEG (CODE)
                                   1925 ; function ak820_outline_0092
      00B1E8                       1926 _ak820_outline_0092:
      00B1E8 E9               [12] 1927 	mov	a,r1
      00B1E9 F0               [24] 1928 	movx	@dptr,a
      00B1EA E8               [12] 1929 	mov	a,r0
      00B1EB A3               [24] 1930 	inc	dptr
      00B1EC F0               [24] 1931 	movx	@dptr,a
      00B1ED EA               [12] 1932 	mov	a,r2
      00B1EE A3               [24] 1933 	inc	dptr
      00B1EF F0               [24] 1934 	movx	@dptr,a
      00B1F0 22               [24] 1935 	ret
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0093
      00B1F1                       1939 _ak820_outline_0093:
      00B1F1 EB               [12] 1940 	mov	a,r3
      00B1F2 F0               [24] 1941 	movx	@dptr,a
      00B1F3 8A 82            [24] 1942 	mov	dpl,r2
      00B1F5 8C 83            [24] 1943 	mov	dph,r4
      00B1F7 8D F0            [24] 1944 	mov	b,r5
      00B1F9 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0161
      00B1FA                       1949 _ak820_outline_0161:
      00B1FA 8E 02            [24] 1950 	mov	ar2,r6
      00B1FC 8F 04            [24] 1951 	mov	ar4,r7
      00B1FE 7D 00            [12] 1952 	mov	r5,#0x00
      00B200 22               [24] 1953 	ret
