                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _ak820_settings_caps_delay
                                     24 	.globl _ak820_settings_tap_code_delay
                                     25 	.globl _clear_owned_usages
                                     26 	.globl _owned_usage_key
                                     27 	.globl _clear_owned_keys
                                     28 	.globl _del_owned_key
                                     29 	.globl _add_owned_key
                                     30 	.globl _clear_owned_mods
                                     31 	.globl _del_owned_weak_mods
                                     32 	.globl _add_owned_weak_mods
                                     33 	.globl _del_owned_mods
                                     34 	.globl _add_owned_mods
                                     35 	.globl _clear_weak_mods
                                     36 	.globl _clear_mods
                                     37 	.globl _send_keyboard_report
                                     38 	.globl _layer_hold_clear
                                     39 	.globl _layer_hold_off
                                     40 	.globl _layer_hold_on
                                     41 	.globl _ak820_resolve_key
                                     42 	.globl _layer_xor
                                     43 	.globl _layer_and
                                     44 	.globl _layer_or
                                     45 	.globl _layer_off
                                     46 	.globl _layer_on
                                     47 	.globl _layer_move
                                     48 	.globl _layer_clear
                                     49 	.globl _layer_state_set
                                     50 	.globl _default_layer_xor
                                     51 	.globl _default_layer_and
                                     52 	.globl _default_layer_or
                                     53 	.globl _default_layer_set
                                     54 	.globl _post_process_record_quantum
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      00001D                        590 _process_action_sloc0_1_0:
      00001D                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      000020                        608 _process_action_sloc1_1_0:
      000020                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      000861                        618 _tp_buttons::
      000861                        619 	.ds 2
      000863                        620 _action_exec_PARM_1:
      000863                        621 	.ds 6
      000869                        622 _action_exec_record_10001_648:
      000869                        623 	.ds 9
      000872                        624 _ak820_action_exec_event_10000_652:
      000872                        625 	.ds 2
      000874                        626 _ak820_action_exec_snapshot_10000_653:
      000874                        627 	.ds 6
      00087A                        628 _process_record_record_10000_656:
      00087A                        629 	.ds 3
      00087D                        630 _process_record_handler_record_argument_10000_664:
      00087D                        631 	.ds 3
      000880                        632 _process_record_handler_action_10000_665:
      000880                        633 	.ds 2
      000882                        634 _process_action_PARM_2:
      000882                        635 	.ds 2
      000884                        636 _process_action_record_argument_10000_676:
      000884                        637 	.ds 3
      000887                        638 _process_action_on_40000_699:
      000887                        639 	.ds 1
      000888                        640 _register_code_code_10000_733:
      000888                        641 	.ds 1
      000889                        642 _unregister_code_code_10000_747:
      000889                        643 	.ds 1
      00088A                        644 _tap_code_delay_PARM_2:
      00088A                        645 	.ds 2
      00088C                        646 _tap_code_delay_code_10000_760:
      00088C                        647 	.ds 1
      00088D                        648 _tap_code_code_10000_767:
      00088D                        649 	.ds 1
      00088E                        650 _register_mods_mods_10000_769:
      00088E                        651 	.ds 1
      00088F                        652 _unregister_mods_mods_10000_773:
      00088F                        653 	.ds 1
      000890                        654 _register_weak_mods_mods_10000_777:
      000890                        655 	.ds 1
      000891                        656 _unregister_weak_mods_mods_10000_781:
      000891                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000E19                        666 _disable_action_cache::
      000E19                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      0075F6                        711 _action_exec:
                                    712 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0075F6 90 08 65         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0075F9 12 37 F1         [24]  714 	lcall	_ak820_outline_0005
      0075FC 12 35 FF         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0075FF 90 08 63         [24]  717 	mov	dptr,#_action_exec_PARM_1
      007602 12 4A 8E         [24]  718 	lcall	_ak820_tapping_before
      007605 E5 82            [12]  719 	mov	a, dpl
      007607 70 01            [24]  720 	jnz	00102$
      007609 22               [24]  721 	ret
      00760A                        722 00102$:
                                    723 ;	quantum/action.c:125: if (event.pressed) {
      00760A 90 08 68         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00760D E0               [24]  725 	movx	a,@dptr
      00760E 60 03            [24]  726 	jz	00104$
                                    727 ;	quantum/action.c:127: clear_weak_mods();
      007610 12 86 32         [24]  728 	lcall	_clear_weak_mods
      007613                        729 00104$:
                                    730 ;	quantum/action.c:139: record.event = event;
      007613 90 0D F1         [24]  731 	mov	dptr,#___memcpy_PARM_2
      007616 74 63            [12]  732 	mov	a,#_action_exec_PARM_1
      007618 F0               [24]  733 	movx	@dptr,a
      007619 74 08            [12]  734 	mov	a,#(_action_exec_PARM_1 >> 8)
      00761B 12 38 5B         [24]  735 	lcall	_ak820_outline_0070
      00761E 12 7C CC         [24]  736 	lcall	_ak820_outline_0075
      007621 90 08 69         [24]  737 	mov	dptr,#_action_exec_record_10001_648
      007624 F5 F0            [12]  738 	mov	b,a
      007626 12 BE 74         [24]  739 	lcall	___memcpy
                                    740 ;	quantum/action.c:141: record.tap.count = 0;
      007629 90 08 6F         [24]  741 	mov	dptr,#(_action_exec_record_10001_648 + 0x0006)
      00762C E0               [24]  742 	movx	a,@dptr
      00762D 54 0F            [12]  743 	anl	a,#0x0f
      00762F F0               [24]  744 	movx	@dptr,a
                                    745 ;	quantum/action.c:146: record.keycode = 0;
      007630 90 08 70         [24]  746 	mov	dptr,#(_action_exec_record_10001_648 + 0x0007)
      007633 12 49 BF         [24]  747 	lcall	_ak820_outline_0177
                                    748 ;	quantum/action.c:177: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007636 90 08 6D         [24]  749 	mov	dptr,#(_action_exec_record_10001_648 + 0x0004)
      007639 E0               [24]  750 	movx	a,@dptr
      00763A 60 0D            [24]  751 	jz	00107$
      00763C 90 08 69         [24]  752 	mov	dptr,#_action_exec_record_10001_648
      00763F 75 F0 00         [24]  753 	mov	b, #0x00
      007642 12 A4 5E         [24]  754 	lcall	_pre_process_record_quantum
      007645 E5 82            [12]  755 	mov	a, dpl
      007647 60 13            [24]  756 	jz	00110$
      007649                        757 00107$:
                                    758 ;	quantum/action.c:179: if (!ak820_tapping_process(&record)) return;
      007649 90 08 69         [24]  759 	mov	dptr,#_action_exec_record_10001_648
      00764C 12 4B 96         [24]  760 	lcall	_ak820_tapping_process
      00764F E5 82            [12]  761 	mov	a, dpl
      007651 70 01            [24]  762 	jnz	00106$
      007653 22               [24]  763 	ret
      007654                        764 00106$:
                                    765 ;	quantum/action.c:184: process_record(&record);
      007654 90 08 69         [24]  766 	mov	dptr,#_action_exec_record_10001_648
      007657 75 F0 00         [24]  767 	mov	b, #0x00
                                    768 ;	quantum/action.c:199: }
      00765A C1 98            [12]  769 	ajmp	_process_record
      00765C                        770 00110$:
      00765C 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'ak820_action_exec'
                                    774 ;------------------------------------------------------------
                                    775 ;event         Allocated with name '_ak820_action_exec_event_10000_652'
                                    776 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_653'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/action.c:202: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function ak820_action_exec
                                    781 ;	-----------------------------------------
      00765D                        782 _ak820_action_exec:
      00765D 12 38 79         [24]  783 	lcall	_ak820_outline_0113
      007660 90 08 72         [24]  784 	mov	dptr,#_ak820_action_exec_event_10000_652
      007663 12 38 7E         [24]  785 	lcall	_ak820_outline_0114
                                    786 ;	quantum/action.c:205: keyevent_t snapshot = *event;
      007666 90 08 72         [24]  787 	mov	dptr,#_ak820_action_exec_event_10000_652
      007669 12 38 67         [24]  788 	lcall	_ak820_outline_0090
      00766C 7F 00            [12]  789 	mov	r7,#0x00
      00766E 90 0D F1         [24]  790 	mov	dptr,#___memcpy_PARM_2
      007671 ED               [12]  791 	mov	a,r5
      007672 12 38 26         [24]  792 	lcall	_ak820_outline_0018
      007675 12 7C CC         [24]  793 	lcall	_ak820_outline_0075
      007678 90 08 74         [24]  794 	mov	dptr,#_ak820_action_exec_snapshot_10000_653
      00767B F5 F0            [12]  795 	mov	b,a
      00767D 12 BE 74         [24]  796 	lcall	___memcpy
                                    797 ;	quantum/action.c:206: action_exec(snapshot);
      007680 90 0D F1         [24]  798 	mov	dptr,#___memcpy_PARM_2
      007683 74 74            [12]  799 	mov	a,#_ak820_action_exec_snapshot_10000_653
      007685 F0               [24]  800 	movx	@dptr,a
      007686 74 08            [12]  801 	mov	a,#(_ak820_action_exec_snapshot_10000_653 >> 8)
      007688 12 38 5B         [24]  802 	lcall	_ak820_outline_0070
      00768B 12 7C CC         [24]  803 	lcall	_ak820_outline_0075
      00768E 90 08 63         [24]  804 	mov	dptr,#_action_exec_PARM_1
      007691 F5 F0            [12]  805 	mov	b,a
      007693 12 BE 74         [24]  806 	lcall	___memcpy
                                    807 ;	quantum/action.c:207: }
      007696 A1 F6            [12]  808 	ajmp	_action_exec
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'process_record_nocache'
                                    811 ;------------------------------------------------------------
                                    812 ;record        Allocated with name '_process_record_nocache_record_10000_654'
                                    813 ;------------------------------------------------------------
                                    814 ;	quantum/action.c:292: void process_record_nocache(keyrecord_t *record) {
                                    815 ;	-----------------------------------------
                                    816 ;	 function process_record
                                    817 ;	-----------------------------------------
      007698                        818 _process_record:
      007698 12 43 1B         [24]  819 	lcall	_ak820_outline_0038
      00769B 90 08 7A         [24]  820 	mov	dptr,#_process_record_record_10000_656
      00769E 12 38 26         [24]  821 	lcall	_ak820_outline_0018
                                    822 ;	quantum/action.c:346: if (IS_NOEVENT(record->event)) {
      0076A1 90 08 7A         [24]  823 	mov	dptr,#_process_record_record_10000_656
      0076A4 12 49 34         [24]  824 	lcall	_ak820_outline_0013
      0076A7 74 04            [12]  825 	mov	a,#0x04
      0076A9 12 7C 9F         [24]  826 	lcall	_ak820_outline_0016
      0076AC 12 C0 37         [24]  827 	lcall	__gptrget
      0076AF 70 01            [24]  828 	jnz	00102$
                                    829 ;	quantum/action.c:347: return;
      0076B1 22               [24]  830 	ret
      0076B2                        831 00102$:
                                    832 ;	quantum/action.c:355: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0076B2 8D 02            [24]  833 	mov	ar2,r5
      0076B4 8E 03            [24]  834 	mov	ar3,r6
      0076B6 8F 04            [24]  835 	mov	ar4,r7
      0076B8 90 0D F1         [24]  836 	mov	dptr,#___memcpy_PARM_2
      0076BB EA               [12]  837 	mov	a,r2
      0076BC 12 49 C4         [24]  838 	lcall	_ak820_outline_0195
      0076BF EC               [12]  839 	mov	a,r4
      0076C0 A3               [24]  840 	inc	dptr
      0076C1 F0               [24]  841 	movx	@dptr,a
      0076C2 90 0D F4         [24]  842 	mov	dptr,#___memcpy_PARM_3
      0076C5 12 55 6D         [24]  843 	lcall	_ak820_outline_0116
      0076C8 90 06 77         [24]  844 	mov	dptr,#_ak820_tapping_source_PARM_1
      0076CB F5 F0            [12]  845 	mov	b,a
      0076CD C0 07            [24]  846 	push	ar7
      0076CF C0 06            [24]  847 	push	ar6
      0076D1 C0 05            [24]  848 	push	ar5
      0076D3 12 BE 74         [24]  849 	lcall	___memcpy
      0076D6 12 49 C9         [24]  850 	lcall	_ak820_tapping_source
      0076D9 AC 82            [24]  851 	mov	r4, dpl
      0076DB D0 05            [24]  852 	pop	ar5
      0076DD D0 06            [24]  853 	pop	ar6
      0076DF D0 07            [24]  854 	pop	ar7
                                    855 ;	quantum/action.c:356: bool oneshot_pressed = record->event.pressed;
      0076E1 74 05            [12]  856 	mov	a,#0x05
      0076E3 12 7C 91         [24]  857 	lcall	_ak820_outline_0015
      0076E6 12 C0 37         [24]  858 	lcall	__gptrget
      0076E9 FB               [12]  859 	mov	r3,a
                                    860 ;	quantum/action.c:357: record->keycode = get_record_keycode(record, true);
      0076EA 12 7C F8         [24]  861 	lcall	_ak820_outline_0156
      0076ED 90 0C 48         [24]  862 	mov	dptr,#_get_record_keycode_PARM_2
      0076F0 74 01            [12]  863 	mov	a,#0x01
      0076F2 12 49 59         [24]  864 	lcall	_ak820_outline_0033
      0076F5 C0 04            [24]  865 	push	ar4
      0076F7 C0 03            [24]  866 	push	ar3
      0076F9 C0 02            [24]  867 	push	ar2
      0076FB C0 01            [24]  868 	push	ar1
      0076FD C0 00            [24]  869 	push	ar0
      0076FF 12 A4 21         [24]  870 	lcall	_get_record_keycode
      007702 12 43 64         [24]  871 	lcall	_ak820_outline_0132
      007705 D0 00            [24]  872 	pop	ar0
      007707 D0 01            [24]  873 	pop	ar1
      007709 D0 02            [24]  874 	pop	ar2
      00770B D0 03            [24]  875 	pop	ar3
      00770D D0 04            [24]  876 	pop	ar4
      00770F 12 4E EE         [24]  877 	lcall	_ak820_outline_0117
      007712 EE               [12]  878 	mov	a,r6
      007713 12 BF 12         [24]  879 	lcall	__gptrput
      007716 A3               [24]  880 	inc	dptr
      007717 EF               [12]  881 	mov	a,r7
      007718 12 BF 12         [24]  882 	lcall	__gptrput
                                    883 ;	quantum/action.c:358: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00771B 90 08 7A         [24]  884 	mov	dptr,#_process_record_record_10000_656
      00771E 12 49 34         [24]  885 	lcall	_ak820_outline_0013
      007721 12 7C F8         [24]  886 	lcall	_ak820_outline_0156
      007724 12 4E EE         [24]  887 	lcall	_ak820_outline_0117
      007727 12 C0 37         [24]  888 	lcall	__gptrget
      00772A F8               [12]  889 	mov	r0,a
      00772B A3               [24]  890 	inc	dptr
      00772C 12 C0 37         [24]  891 	lcall	__gptrget
      00772F F9               [12]  892 	mov	r1,a
      007730 90 06 87         [24]  893 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007733 EC               [12]  894 	mov	a,r4
      007734 F0               [24]  895 	movx	@dptr,a
      007735 90 06 88         [24]  896 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007738 EB               [12]  897 	mov	a,r3
      007739 F0               [24]  898 	movx	@dptr,a
      00773A 12 38 BF         [24]  899 	lcall	_ak820_outline_0160
      00773D C0 07            [24]  900 	push	ar7
      00773F C0 06            [24]  901 	push	ar6
      007741 C0 05            [24]  902 	push	ar5
      007743 C0 04            [24]  903 	push	ar4
      007745 C0 03            [24]  904 	push	ar3
      007747 12 4D 46         [24]  905 	lcall	_ak820_oneshot_process
      00774A E5 82            [12]  906 	mov	a, dpl
      00774C D0 03            [24]  907 	pop	ar3
      00774E D0 04            [24]  908 	pop	ar4
      007750 D0 05            [24]  909 	pop	ar5
      007752 D0 06            [24]  910 	pop	ar6
      007754 D0 07            [24]  911 	pop	ar7
      007756 70 01            [24]  912 	jnz	00104$
      007758 22               [24]  913 	ret
      007759                        914 00104$:
                                    915 ;	quantum/action.c:360: if (!process_record_quantum(record)) {
      007759 12 49 77         [24]  916 	lcall	_ak820_outline_0050
      00775C C0 04            [24]  917 	push	ar4
      00775E C0 03            [24]  918 	push	ar3
      007760 12 A4 E5         [24]  919 	lcall	_process_record_quantum
      007763 E5 82            [12]  920 	mov	a, dpl
      007765 D0 03            [24]  921 	pop	ar3
      007767 D0 04            [24]  922 	pop	ar4
      007769 70 0A            [24]  923 	jnz	00106$
                                    924 ;	quantum/action.c:362: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00776B 90 05 9C         [24]  925 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00776E EB               [12]  926 	mov	a,r3
      00776F F0               [24]  927 	movx	@dptr,a
      007770 8C 82            [24]  928 	mov	dpl, r4
                                    929 ;	quantum/action.c:369: return;
      007772 02 2E BB         [24]  930 	ljmp	_ak820_oneshot_post
      007775                        931 00106$:
                                    932 ;	quantum/action.c:375: process_record_handler(record);
      007775 90 08 7A         [24]  933 	mov	dptr,#_process_record_record_10000_656
      007778 12 55 13         [24]  934 	lcall	_ak820_outline_0001
      00777B C0 04            [24]  935 	push	ar4
      00777D C0 03            [24]  936 	push	ar3
      00777F F1 98            [24]  937 	acall	_process_record_handler
                                    938 ;	quantum/action.c:379: post_process_record_quantum(record);
      007781 90 08 7A         [24]  939 	mov	dptr,#_process_record_record_10000_656
      007784 12 55 13         [24]  940 	lcall	_ak820_outline_0001
      007787 12 A4 BC         [24]  941 	lcall	_post_process_record_quantum
      00778A D0 03            [24]  942 	pop	ar3
      00778C D0 04            [24]  943 	pop	ar4
                                    944 ;	quantum/action.c:381: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00778E 90 05 9C         [24]  945 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007791 EB               [12]  946 	mov	a,r3
      007792 F0               [24]  947 	movx	@dptr,a
      007793 8C 82            [24]  948 	mov	dpl, r4
                                    949 ;	quantum/action.c:383: }
      007795 02 2E BB         [24]  950 	ljmp	_ak820_oneshot_post
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'process_record_handler'
                                    953 ;------------------------------------------------------------
                                    954 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_664'
                                    955 ;record        Allocated with name '_process_record_handler_record_10000_665'
                                    956 ;action        Allocated with name '_process_record_handler_action_10000_665'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/action.c:385: void process_record_handler(keyrecord_t *record_argument) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function process_record_handler
                                    961 ;	-----------------------------------------
      007798                        962 _process_record_handler:
      007798 12 43 1B         [24]  963 	lcall	_ak820_outline_0038
      00779B 90 08 7D         [24]  964 	mov	dptr,#_process_record_handler_record_argument_10000_664
      00779E 12 38 26         [24]  965 	lcall	_ak820_outline_0018
                                    966 ;	quantum/action.c:389: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0077A1 90 08 7D         [24]  967 	mov	dptr,#_process_record_handler_record_argument_10000_664
      0077A4 12 37 FB         [24]  968 	lcall	_ak820_outline_0008
                                    969 ;	quantum/action.c:396: if (record->keycode) {
      0077A7 4C               [12]  970 	orl	a,r4
      0077A8 60 19            [24]  971 	jz	00102$
                                    972 ;	quantum/action.c:397: action.code = action_for_keycode(record->keycode);
      0077AA 12 38 A0         [24]  973 	lcall	_ak820_outline_0133
      0077AD C0 07            [24]  974 	push	ar7
      0077AF C0 06            [24]  975 	push	ar6
      0077B1 12 99 E3         [24]  976 	lcall	_action_for_keycode
      0077B4 12 38 B0         [24]  977 	lcall	_ak820_outline_0153
      0077B7 D0 06            [24]  978 	pop	ar6
      0077B9 D0 07            [24]  979 	pop	ar7
      0077BB 90 08 80         [24]  980 	mov	dptr,#_process_record_handler_action_10000_665
      0077BE 12 38 61         [24]  981 	lcall	_ak820_outline_0078
      0077C1 80 2A            [24]  982 	sjmp	00104$
      0077C3                        983 00102$:
                                    984 ;	quantum/action.c:400: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0077C3 12 7C AD         [24]  985 	lcall	_ak820_outline_0023
      0077C6 7A 00            [12]  986 	mov	r2,#0x00
      0077C8 12 43 75         [24]  987 	lcall	_ak820_outline_0152
      0077CB 12 43 09         [24]  988 	lcall	_ak820_outline_0014
      0077CE E0               [24]  989 	movx	a,@dptr
      0077CF 90 09 BC         [24]  990 	mov	dptr,#_ak820_resolve_key_PARM_2
      0077D2 F0               [24]  991 	movx	@dptr,a
      0077D3 12 43 90         [24]  992 	lcall	_ak820_outline_0197
      0077D6 C0 07            [24]  993 	push	ar7
      0077D8 C0 06            [24]  994 	push	ar6
      0077DA 12 80 38         [24]  995 	lcall	_ak820_resolve_key
      0077DD 12 99 E3         [24]  996 	lcall	_action_for_keycode
      0077E0 12 38 B0         [24]  997 	lcall	_ak820_outline_0153
      0077E3 D0 06            [24]  998 	pop	ar6
      0077E5 D0 07            [24]  999 	pop	ar7
      0077E7 90 08 80         [24] 1000 	mov	dptr,#_process_record_handler_action_10000_665
      0077EA 12 38 61         [24] 1001 	lcall	_ak820_outline_0078
                                   1002 ;	quantum/action.c:409: ac_dprintf("ACTION: ");
      0077ED                       1003 00104$:
                                   1004 ;	quantum/action.c:420: process_action(record, action);
      0077ED 7D 00            [12] 1005 	mov	r5,#0x00
      0077EF 90 0D F1         [24] 1006 	mov	dptr,#___memcpy_PARM_2
      0077F2 74 80            [12] 1007 	mov	a,#_process_record_handler_action_10000_665
      0077F4 F0               [24] 1008 	movx	@dptr,a
      0077F5 74 08            [12] 1009 	mov	a,#(_process_record_handler_action_10000_665 >> 8)
      0077F7 12 38 5B         [24] 1010 	lcall	_ak820_outline_0070
      0077FA 90 0D F4         [24] 1011 	mov	dptr,#___memcpy_PARM_3
      0077FD 12 55 6D         [24] 1012 	lcall	_ak820_outline_0116
      007800 90 08 82         [24] 1013 	mov	dptr,#_process_action_PARM_2
      007803 F5 F0            [12] 1014 	mov	b,a
      007805 C0 07            [24] 1015 	push	ar7
      007807 C0 06            [24] 1016 	push	ar6
      007809 C0 05            [24] 1017 	push	ar5
      00780B 12 BE 74         [24] 1018 	lcall	___memcpy
      00780E D0 05            [24] 1019 	pop	ar5
      007810 D0 06            [24] 1020 	pop	ar6
      007812 D0 07            [24] 1021 	pop	ar7
      007814 12 49 7E         [24] 1022 	lcall	_ak820_outline_0061
                                   1023 ;	quantum/action.c:421: }
      007817 01 19            [24] 1024 	ajmp	_process_action
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'register_mouse'
                                   1027 ;------------------------------------------------------------
                                   1028 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1029 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_673'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/action.c:433: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function process_action
                                   1034 ;	-----------------------------------------
      007819                       1035 _process_action:
      007819 12 43 1B         [24] 1036 	lcall	_ak820_outline_0038
      00781C 90 08 84         [24] 1037 	mov	dptr,#_process_action_record_argument_10000_676
      00781F 12 38 26         [24] 1038 	lcall	_ak820_outline_0018
                                   1039 ;	quantum/action.c:486: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007822 90 08 84         [24] 1040 	mov	dptr,#_process_action_record_argument_10000_676
      007825 12 37 F1         [24] 1041 	lcall	_ak820_outline_0005
                                   1042 ;	quantum/action.c:492: pressed = record->event.pressed;
      007828 A3               [24] 1043 	inc	dptr
      007829 A3               [24] 1044 	inc	dptr
      00782A A3               [24] 1045 	inc	dptr
      00782B A3               [24] 1046 	inc	dptr
      00782C A3               [24] 1047 	inc	dptr
      00782D E0               [24] 1048 	movx	a,@dptr
      00782E F5 1D            [12] 1049 	mov	_process_action_sloc0_1_0,a
                                   1050 ;	quantum/action.c:516: switch (action.kind.id) {
      007830 90 08 83         [24] 1051 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007833 E0               [24] 1052 	movx	a,@dptr
      007834 C4               [12] 1053 	swap	a
      007835 54 0F            [12] 1054 	anl	a,#0x0f
      007837 FD               [12] 1055 	mov  r5,a
      007838 24 F4            [12] 1056 	add	a,#0xff - 0x0b
      00783A 50 03            [24] 1057 	jnc	00434$
      00783C 02 7A BA         [24] 1058 	ljmp	00181$
      00783F                       1059 00434$:
                                   1060 ;	free result
      00783F ED               [12] 1061 	mov	a,r5
      007840 24 0A            [12] 1062 	add	a,#(00435$-3-.)
      007842 83               [24] 1063 	movc	a,@a+pc
      007843 F5 82            [12] 1064 	mov	dpl,a
      007845 ED               [12] 1065 	mov	a,r5
      007846 24 10            [12] 1066 	add	a,#(00436$-3-.)
      007848 83               [24] 1067 	movc	a,@a+pc
      007849 F5 83            [12] 1068 	mov	dph,a
      00784B E4               [12] 1069 	clr	a
      00784C 73               [24] 1070 	jmp	@a+dptr
      00784D                       1071 00435$:
      00784D 65                    1072 	.db	00102$
      00784E 65                    1073 	.db	00102$
      00784F BA                    1074 	.db	00181$
      007850 BA                    1075 	.db	00181$
      007851 EF                    1076 	.db	00123$
      007852 BA                    1077 	.db	00181$
      007853 BA                    1078 	.db	00181$
      007854 BA                    1079 	.db	00181$
      007855 4F                    1080 	.db	00131$
      007856 21                    1081 	.db	00147$
      007857 47                    1082 	.db	00152$
      007858 47                    1083 	.db	00152$
      007859                       1084 00436$:
      007859 78                    1085 	.db	00102$>>8
      00785A 78                    1086 	.db	00102$>>8
      00785B 7A                    1087 	.db	00181$>>8
      00785C 7A                    1088 	.db	00181$>>8
      00785D 78                    1089 	.db	00123$>>8
      00785E 7A                    1090 	.db	00181$>>8
      00785F 7A                    1091 	.db	00181$>>8
      007860 7A                    1092 	.db	00181$>>8
      007861 79                    1093 	.db	00131$>>8
      007862 7A                    1094 	.db	00147$>>8
      007863 7A                    1095 	.db	00152$>>8
      007864 7A                    1096 	.db	00152$>>8
                                   1097 ;	quantum/action.c:519: case ACT_RMODS: {
      007865                       1098 00102$:
                                   1099 ;	quantum/action.c:520: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007865 90 08 83         [24] 1100 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007868 E0               [24] 1101 	movx	a,@dptr
      007869 54 F0            [12] 1102 	anl	a,#0xf0
      00786B 70 06            [24] 1103 	jnz	00194$
      00786D 12 7C E6         [24] 1104 	lcall	_ak820_outline_0119
      007870 FD               [12] 1105 	mov	r5,a
      007871 80 07            [24] 1106 	sjmp	00195$
      007873                       1107 00194$:
      007873 12 7C E6         [24] 1108 	lcall	_ak820_outline_0119
      007876 C4               [12] 1109 	swap	a
      007877 54 F0            [12] 1110 	anl	a,#0xf0
      007879 FD               [12] 1111 	mov	r5,a
      00787A                       1112 00195$:
                                   1113 ;	quantum/action.c:522: if (pressed) {
      00787A E5 1D            [12] 1114 	mov	a,_process_action_sloc0_1_0
      00787C 60 35            [24] 1115 	jz	00119$
                                   1116 ;	quantum/action.c:523: if (mods) {
      00787E ED               [12] 1117 	mov	a,r5
      00787F 60 29            [24] 1118 	jz	00110$
                                   1119 ;	quantum/action.c:524: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007881 12 7D 02         [24] 1120 	lcall	_ak820_outline_0167
      007884 FC               [12] 1121 	mov	r4,a
      007885 BC E0 00         [24] 1122 	cjne	r4,#0xe0,00440$
      007888                       1123 00440$:
      007888 40 07            [24] 1124 	jc	00108$
      00788A 12 7D 02         [24] 1125 	lcall	_ak820_outline_0167
      00788D 24 18            [12] 1126 	add	a,#0xff - 0xe7
      00788F 50 0A            [24] 1127 	jnc	00104$
                                   1128 ;	free result
      007891                       1129 00108$:
      007891 7B 82            [12] 1130 	mov	r3,#_process_action_PARM_2
      007893 7C 08            [12] 1131 	mov	r4,#(_process_action_PARM_2 >> 8)
      007895 12 33 FC         [24] 1132 	lcall	_ak820_outline_0130
      007898 E0               [24] 1133 	movx	a,@dptr
      007899 70 07            [24] 1134 	jnz	00105$
      00789B                       1135 00104$:
                                   1136 ;	quantum/action.c:528: add_owned_mods(mods);
      00789B 8D 82            [24] 1137 	mov	dpl, r5
      00789D 12 82 50         [24] 1138 	lcall	_add_owned_mods
      0078A0 80 05            [24] 1139 	sjmp	00106$
      0078A2                       1140 00105$:
                                   1141 ;	quantum/action.c:530: add_owned_weak_mods(mods);
      0078A2 8D 82            [24] 1142 	mov	dpl, r5
      0078A4 12 82 6D         [24] 1143 	lcall	_add_owned_weak_mods
      0078A7                       1144 00106$:
                                   1145 ;	quantum/action.c:532: send_keyboard_report();
      0078A7 12 85 82         [24] 1146 	lcall	_send_keyboard_report
      0078AA                       1147 00110$:
                                   1148 ;	quantum/action.c:534: register_code(action.key.code);
      0078AA 12 7C D6         [24] 1149 	lcall	_ak820_outline_0083
      0078AD 12 7A D1         [24] 1150 	lcall	_register_code
      0078B0 02 7A BA         [24] 1151 	ljmp	00181$
      0078B3                       1152 00119$:
                                   1153 ;	quantum/action.c:536: unregister_code(action.key.code);
      0078B3 12 7C D6         [24] 1154 	lcall	_ak820_outline_0083
      0078B6 C0 05            [24] 1155 	push	ar5
      0078B8 12 7B 3E         [24] 1156 	lcall	_unregister_code
      0078BB D0 05            [24] 1157 	pop	ar5
                                   1158 ;	quantum/action.c:537: if (mods) {
      0078BD ED               [12] 1159 	mov	a,r5
      0078BE 70 03            [24] 1160 	jnz	00444$
      0078C0 02 7A BA         [24] 1161 	ljmp	00181$
      0078C3                       1162 00444$:
                                   1163 ;	quantum/action.c:538: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0078C3 12 7D 02         [24] 1164 	lcall	_ak820_outline_0167
      0078C6 FC               [12] 1165 	mov	r4,a
      0078C7 BC E0 00         [24] 1166 	cjne	r4,#0xe0,00445$
      0078CA                       1167 00445$:
      0078CA 40 07            [24] 1168 	jc	00115$
      0078CC 12 7D 02         [24] 1169 	lcall	_ak820_outline_0167
      0078CF 24 18            [12] 1170 	add	a,#0xff - 0xe7
      0078D1 50 0A            [24] 1171 	jnc	00111$
                                   1172 ;	free result
      0078D3                       1173 00115$:
      0078D3 7B 82            [12] 1174 	mov	r3,#_process_action_PARM_2
      0078D5 7C 08            [12] 1175 	mov	r4,#(_process_action_PARM_2 >> 8)
      0078D7 12 33 FC         [24] 1176 	lcall	_ak820_outline_0130
      0078DA E0               [24] 1177 	movx	a,@dptr
      0078DB 70 07            [24] 1178 	jnz	00112$
      0078DD                       1179 00111$:
                                   1180 ;	quantum/action.c:539: del_owned_mods(mods);
      0078DD 8D 82            [24] 1181 	mov	dpl, r5
      0078DF 12 82 5F         [24] 1182 	lcall	_del_owned_mods
      0078E2 80 05            [24] 1183 	sjmp	00113$
      0078E4                       1184 00112$:
                                   1185 ;	quantum/action.c:541: del_owned_weak_mods(mods);
      0078E4 8D 82            [24] 1186 	mov	dpl, r5
      0078E6 12 82 7C         [24] 1187 	lcall	_del_owned_weak_mods
      0078E9                       1188 00113$:
                                   1189 ;	quantum/action.c:543: send_keyboard_report();
      0078E9 12 85 82         [24] 1190 	lcall	_send_keyboard_report
                                   1191 ;	quantum/action.c:546: } break;
      0078EC 02 7A BA         [24] 1192 	ljmp	00181$
                                   1193 ;	quantum/action.c:623: case ACT_USAGE:
      0078EF                       1194 00123$:
                                   1195 ;	quantum/action.c:629: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0078EF 74 07            [12] 1196 	mov	a,#0x07
      0078F1 12 38 2E         [24] 1197 	lcall	_ak820_outline_0024
      0078F4 12 4E 82         [24] 1198 	lcall	_ak820_outline_0009
      0078F7 C3               [12] 1199 	clr	c
      0078F8 EC               [12] 1200 	mov	a,r4
      0078F9 94 A5            [12] 1201 	subb	a,#0xa5
      0078FB ED               [12] 1202 	mov	a,r5
      0078FC 94 00            [12] 1203 	subb	a,#0x00
      0078FE 40 15            [24] 1204 	jc	00125$
      007900 74 C2            [12] 1205 	mov	a,#0xc2
      007902 9C               [12] 1206 	subb	a,r4
      007903 E4               [12] 1207 	clr	a
      007904 9D               [12] 1208 	subb	a,r5
      007905 40 0E            [24] 1209 	jc	00125$
                                   1210 ;	free result
                                   1211 ;	quantum/action.c:630: owned_usage_key((uint8_t)record->keycode, pressed);
      007907 90 0A E3         [24] 1212 	mov	dptr,#_owned_usage_key_PARM_2
      00790A E5 1D            [12] 1213 	mov	a,_process_action_sloc0_1_0
      00790C F0               [24] 1214 	movx	@dptr,a
      00790D 8E 82            [24] 1215 	mov	dpl, r6
      00790F 12 84 2F         [24] 1216 	lcall	_owned_usage_key
                                   1217 ;	quantum/action.c:631: break;
      007912 02 7A BA         [24] 1218 	ljmp	00181$
      007915                       1219 00125$:
                                   1220 ;	quantum/action.c:634: switch (action.usage.page) {
      007915 12 7C DD         [24] 1221 	lcall	_ak820_outline_0094
      007918 FF               [12] 1222 	mov	r7,a
      007919 60 08            [24] 1223 	jz	00127$
      00791B BF 01 02         [24] 1224 	cjne	r7,#0x01,00452$
      00791E 80 19            [24] 1225 	sjmp	00128$
      007920                       1226 00452$:
      007920 02 7A BA         [24] 1227 	ljmp	00181$
                                   1228 ;	quantum/action.c:635: case PAGE_SYSTEM:
      007923                       1229 00127$:
                                   1230 ;	quantum/action.c:636: host_system_send(pressed ? action.usage.code : 0);
      007923 E5 1D            [12] 1231 	mov	a,_process_action_sloc0_1_0
      007925 60 05            [24] 1232 	jz	00196$
      007927 12 7C ED         [24] 1233 	lcall	_ak820_outline_0139
      00792A 80 04            [24] 1234 	sjmp	00197$
      00792C                       1235 00196$:
      00792C 7E 00            [12] 1236 	mov	r6,#0x00
      00792E 7F 00            [12] 1237 	mov	r7,#0x00
      007930                       1238 00197$:
      007930 12 38 8A         [24] 1239 	lcall	_ak820_outline_0124
      007933 12 72 FA         [24] 1240 	lcall	_host_system_send
                                   1241 ;	quantum/action.c:637: break;
      007936 02 7A BA         [24] 1242 	ljmp	00181$
                                   1243 ;	quantum/action.c:638: case PAGE_CONSUMER:
      007939                       1244 00128$:
                                   1245 ;	quantum/action.c:639: host_consumer_send(pressed ? action.usage.code : 0);
      007939 E5 1D            [12] 1246 	mov	a,_process_action_sloc0_1_0
      00793B 60 05            [24] 1247 	jz	00198$
      00793D 12 7C ED         [24] 1248 	lcall	_ak820_outline_0139
      007940 80 04            [24] 1249 	sjmp	00199$
      007942                       1250 00198$:
      007942 7E 00            [12] 1251 	mov	r6,#0x00
      007944 7F 00            [12] 1252 	mov	r7,#0x00
      007946                       1253 00199$:
      007946 12 38 8A         [24] 1254 	lcall	_ak820_outline_0124
      007949 12 73 29         [24] 1255 	lcall	_host_consumer_send
                                   1256 ;	quantum/action.c:642: break;
      00794C 02 7A BA         [24] 1257 	ljmp	00181$
                                   1258 ;	quantum/action.c:649: case ACT_LAYER: {
      00794F                       1259 00131$:
                                   1260 ;	quantum/action.c:650: uint8_t on = action.layer_bitop.on;
      00794F 90 08 83         [24] 1261 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007952 E0               [24] 1262 	movx	a,@dptr
      007953 54 03            [12] 1263 	anl	a,#0x03
      007955 90 08 87         [24] 1264 	mov	dptr,#_process_action_on_40000_699
      007958 F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/action.c:653: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007959 E0               [24] 1267 	movx	a,@dptr
      00795A FF               [12] 1268 	mov	r7,a
      00795B 60 11            [24] 1269 	jz	00200$
      00795D E5 1D            [12] 1270 	mov	a,_process_action_sloc0_1_0
      00795F 60 07            [24] 1271 	jz	00202$
      007961 8F 06            [24] 1272 	mov	ar6,r7
      007963 53 06 01         [24] 1273 	anl	ar6,#0x01
      007966 80 10            [24] 1274 	sjmp	00201$
      007968                       1275 00202$:
      007968 74 02            [12] 1276 	mov	a,#0x02
      00796A 5F               [12] 1277 	anl	a,r7
      00796B FE               [12] 1278 	mov	r6,a
      00796C 80 0A            [24] 1279 	sjmp	00201$
      00796E                       1280 00200$:
      00796E E5 1D            [12] 1281 	mov	a,_process_action_sloc0_1_0
      007970 B4 01 00         [24] 1282 	cjne	a,#0x01,00457$
      007973                       1283 00457$:
      007973 92 20            [24] 1284 	mov  _process_action_sloc1_1_0,c
      007975 E4               [12] 1285 	clr	a
      007976 33               [12] 1286 	rlc	a
      007977 FE               [12] 1287 	mov	r6,a
      007978                       1288 00201$:
      007978 EE               [12] 1289 	mov	a,r6
      007979 70 03            [24] 1290 	jnz	00458$
      00797B 02 7A BA         [24] 1291 	ljmp	00181$
      00797E                       1292 00458$:
                                   1293 ;	quantum/action.c:654: uint8_t shift = action.layer_bitop.part * 4;
      00797E 12 7D 02         [24] 1294 	lcall	_ak820_outline_0167
      007981 C4               [12] 1295 	swap	a
      007982 03               [12] 1296 	rr	a
      007983 54 07            [12] 1297 	anl	a,#0x07
      007985 25 E0            [12] 1298 	add	a,acc
      007987 25 E0            [12] 1299 	add	a,acc
      007989 FF               [12] 1300 	mov	r7,a
                                   1301 ;	quantum/action.c:655: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00798A 12 7D 02         [24] 1302 	lcall	_ak820_outline_0167
      00798D 54 0F            [12] 1303 	anl	a,#0x0f
      00798F FE               [12] 1304 	mov	r6,a
      007990 8F F0            [24] 1305 	mov	b,r7
      007992 05 F0            [12] 1306 	inc	b
      007994 EE               [12] 1307 	mov	a,r6
      007995 80 02            [24] 1308 	sjmp	00460$
      007997                       1309 00459$:
      007997 25 E0            [12] 1310 	add	a,acc
      007999                       1311 00460$:
      007999 D5 F0 FB         [24] 1312 	djnz	b,00459$
      00799C FE               [12] 1313 	mov	r6,a
                                   1314 ;	quantum/action.c:656: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00799D 12 7D 02         [24] 1315 	lcall	_ak820_outline_0167
      0079A0 30 E4 11         [24] 1316 	jnb	acc.4,00204$
      0079A3 8F F0            [24] 1317 	mov	b,r7
      0079A5 05 F0            [12] 1318 	inc	b
      0079A7 74 0F            [12] 1319 	mov	a,#0x0f
      0079A9 80 02            [24] 1320 	sjmp	00463$
      0079AB                       1321 00462$:
      0079AB 25 E0            [12] 1322 	add	a,acc
      0079AD                       1323 00463$:
      0079AD D5 F0 FB         [24] 1324 	djnz	b,00462$
      0079B0 F4               [12] 1325 	cpl	a
      0079B1 FF               [12] 1326 	mov	r7,a
      0079B2 80 02            [24] 1327 	sjmp	00205$
      0079B4                       1328 00204$:
      0079B4 7F 00            [12] 1329 	mov	r7,#0x00
      0079B6                       1330 00205$:
                                   1331 ;	quantum/action.c:657: bits |= mask;
      0079B6 EE               [12] 1332 	mov	a,r6
      0079B7 42 07            [12] 1333 	orl	ar7,a
                                   1334 ;	quantum/action.c:658: if (!on) {
      0079B9 90 08 87         [24] 1335 	mov	dptr,#_process_action_on_40000_699
      0079BC E0               [24] 1336 	movx	a,@dptr
      0079BD 70 31            [24] 1337 	jnz	00143$
                                   1338 ;	quantum/action.c:659: switch (action.layer_bitop.op) {
      0079BF 12 7C DD         [24] 1339 	lcall	_ak820_outline_0094
      0079C2 FE               [12] 1340 	mov	r6,a
      0079C3 2E               [12] 1341 	add	a,r6
                                   1342 ;	quantum/action.c:660: case OP_BIT_AND: default_layer_and(bits); break;
      0079C4 90 79 C8         [24] 1343 	mov	dptr,#00465$
      0079C7 73               [24] 1344 	jmp	@a+dptr
      0079C8                       1345 00465$:
      0079C8 80 06            [24] 1346 	sjmp	00132$
      0079CA 80 0C            [24] 1347 	sjmp	00133$
      0079CC 80 12            [24] 1348 	sjmp	00134$
      0079CE 80 18            [24] 1349 	sjmp	00135$
      0079D0                       1350 00132$:
      0079D0 8F 82            [24] 1351 	mov	dpl, r7
      0079D2 12 7D 58         [24] 1352 	lcall	_default_layer_and
      0079D5 02 7A BA         [24] 1353 	ljmp	00181$
                                   1354 ;	quantum/action.c:661: case OP_BIT_OR: default_layer_or(bits); break;
      0079D8                       1355 00133$:
      0079D8 8F 82            [24] 1356 	mov	dpl, r7
      0079DA 12 7D 48         [24] 1357 	lcall	_default_layer_or
      0079DD 02 7A BA         [24] 1358 	ljmp	00181$
                                   1359 ;	quantum/action.c:662: case OP_BIT_XOR: default_layer_xor(bits); break;
      0079E0                       1360 00134$:
      0079E0 8F 82            [24] 1361 	mov	dpl, r7
      0079E2 12 7D 6D         [24] 1362 	lcall	_default_layer_xor
      0079E5 02 7A BA         [24] 1363 	ljmp	00181$
                                   1364 ;	quantum/action.c:663: case OP_BIT_SET: default_layer_set(bits); break;
      0079E8                       1365 00135$:
      0079E8 8F 82            [24] 1366 	mov	dpl, r7
      0079EA 12 7D 3E         [24] 1367 	lcall	_default_layer_set
                                   1368 ;	quantum/action.c:664: }
      0079ED 02 7A BA         [24] 1369 	ljmp	00181$
      0079F0                       1370 00143$:
                                   1371 ;	quantum/action.c:666: switch (action.layer_bitop.op) {
      0079F0 12 7C DD         [24] 1372 	lcall	_ak820_outline_0094
      0079F3 FE               [12] 1373 	mov	r6,a
      0079F4 2E               [12] 1374 	add	a,r6
                                   1375 ;	quantum/action.c:667: case OP_BIT_AND: layer_and(bits); break;
      0079F5 90 79 F9         [24] 1376 	mov	dptr,#00466$
      0079F8 73               [24] 1377 	jmp	@a+dptr
      0079F9                       1378 00466$:
      0079F9 80 06            [24] 1379 	sjmp	00137$
      0079FB 80 0C            [24] 1380 	sjmp	00138$
      0079FD 80 12            [24] 1381 	sjmp	00139$
      0079FF 80 18            [24] 1382 	sjmp	00140$
      007A01                       1383 00137$:
      007A01 8F 82            [24] 1384 	mov	dpl, r7
      007A03 12 7E E3         [24] 1385 	lcall	_layer_and
      007A06 02 7A BA         [24] 1386 	ljmp	00181$
                                   1387 ;	quantum/action.c:668: case OP_BIT_OR: layer_or(bits); break;
      007A09                       1388 00138$:
      007A09 8F 82            [24] 1389 	mov	dpl, r7
      007A0B 12 7E D3         [24] 1390 	lcall	_layer_or
      007A0E 02 7A BA         [24] 1391 	ljmp	00181$
                                   1392 ;	quantum/action.c:669: case OP_BIT_XOR: layer_xor(bits); break;
      007A11                       1393 00139$:
      007A11 8F 82            [24] 1394 	mov	dpl, r7
      007A13 12 7E F8         [24] 1395 	lcall	_layer_xor
      007A16 02 7A BA         [24] 1396 	ljmp	00181$
                                   1397 ;	quantum/action.c:670: case OP_BIT_SET: layer_state_set(bits); break;
      007A19                       1398 00140$:
      007A19 8F 82            [24] 1399 	mov	dpl, r7
      007A1B 12 7E 75         [24] 1400 	lcall	_layer_state_set
                                   1401 ;	quantum/action.c:674: break;
      007A1E 02 7A BA         [24] 1402 	ljmp	00181$
                                   1403 ;	quantum/action.c:676: case ACT_LAYER_MODS:
      007A21                       1404 00147$:
                                   1405 ;	quantum/action.c:677: if (pressed) {
      007A21 E5 1D            [12] 1406 	mov	a,_process_action_sloc0_1_0
      007A23 60 11            [24] 1407 	jz	00149$
                                   1408 ;	quantum/action.c:678: layer_hold_on(action.layer_mods.layer);
      007A25 12 7C E6         [24] 1409 	lcall	_ak820_outline_0119
      007A28 F5 82            [12] 1410 	mov	dpl,a
      007A2A 12 7D D9         [24] 1411 	lcall	_layer_hold_on
                                   1412 ;	quantum/action.c:679: register_mods(action.layer_mods.mods);
      007A2D 12 7C D6         [24] 1413 	lcall	_ak820_outline_0083
      007A30 12 7C 02         [24] 1414 	lcall	_register_mods
      007A33 02 7A BA         [24] 1415 	ljmp	00181$
      007A36                       1416 00149$:
                                   1417 ;	quantum/action.c:681: unregister_mods(action.layer_mods.mods);
      007A36 12 7C D6         [24] 1418 	lcall	_ak820_outline_0083
      007A39 12 7C 16         [24] 1419 	lcall	_unregister_mods
                                   1420 ;	quantum/action.c:682: layer_hold_off(action.layer_mods.layer);
      007A3C 12 7C E6         [24] 1421 	lcall	_ak820_outline_0119
      007A3F F5 82            [12] 1422 	mov	dpl,a
      007A41 12 7E 10         [24] 1423 	lcall	_layer_hold_off
                                   1424 ;	quantum/action.c:684: break;
      007A44 02 7A BA         [24] 1425 	ljmp	00181$
                                   1426 ;	quantum/action.c:686: case ACT_LAYER_TAP_EXT:
      007A47                       1427 00152$:
                                   1428 ;	quantum/action.c:687: switch (action.layer_tap.code) {
      007A47 12 7D 02         [24] 1429 	lcall	_ak820_outline_0167
      007A4A FF               [12] 1430 	mov	r7,a
      007A4B BF F1 02         [24] 1431 	cjne	r7,#0xf1,00468$
      007A4E 80 0A            [24] 1432 	sjmp	00154$
      007A50                       1433 00468$:
      007A50 BF F2 02         [24] 1434 	cjne	r7,#0xf2,00469$
      007A53 80 19            [24] 1435 	sjmp	00155$
      007A55                       1436 00469$:
                                   1437 ;	quantum/action.c:703: momentary_layer_action:
      007A55 BF F3 3B         [24] 1438 	cjne	r7,#0xf3,00160$
      007A58 80 28            [24] 1439 	sjmp	00156$
      007A5A                       1440 00154$:
                                   1441 ;	quantum/action.c:704: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007A5A E5 1D            [12] 1442 	mov	a,_process_action_sloc0_1_0
      007A5C 60 08            [24] 1443 	jz	00206$
      007A5E 12 7C BC         [24] 1444 	lcall	_ak820_outline_0044
      007A61 12 7D D9         [24] 1445 	lcall	_layer_hold_on
      007A64 80 54            [24] 1446 	sjmp	00181$
      007A66                       1447 00206$:
      007A66 12 7C BC         [24] 1448 	lcall	_ak820_outline_0044
      007A69 12 7E 10         [24] 1449 	lcall	_layer_hold_off
                                   1450 ;	quantum/action.c:705: break;
                                   1451 ;	quantum/action.c:706: case OP_OFF_ON:
      007A6C 80 4C            [24] 1452 	sjmp	00181$
      007A6E                       1453 00155$:
                                   1454 ;	quantum/action.c:707: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007A6E E5 1D            [12] 1455 	mov	a,_process_action_sloc0_1_0
      007A70 60 08            [24] 1456 	jz	00208$
      007A72 12 7C BC         [24] 1457 	lcall	_ak820_outline_0044
      007A75 12 7E B6         [24] 1458 	lcall	_layer_off
      007A78 80 40            [24] 1459 	sjmp	00181$
      007A7A                       1460 00208$:
      007A7A 12 7C BC         [24] 1461 	lcall	_ak820_outline_0044
      007A7D 12 7E 9C         [24] 1462 	lcall	_layer_on
                                   1463 ;	quantum/action.c:708: break;
                                   1464 ;	quantum/action.c:709: case OP_SET_CLEAR:
      007A80 80 38            [24] 1465 	sjmp	00181$
      007A82                       1466 00156$:
                                   1467 ;	quantum/action.c:710: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007A82 E5 1D            [12] 1468 	mov	a,_process_action_sloc0_1_0
      007A84 60 08            [24] 1469 	jz	00210$
      007A86 12 7C BC         [24] 1470 	lcall	_ak820_outline_0044
      007A89 12 7E 87         [24] 1471 	lcall	_layer_move
      007A8C 80 2C            [24] 1472 	sjmp	00181$
      007A8E                       1473 00210$:
      007A8E 12 7E 82         [24] 1474 	lcall	_layer_clear
                                   1475 ;	quantum/action.c:711: break;
                                   1476 ;	quantum/action.c:757: default:
      007A91 80 27            [24] 1477 	sjmp	00181$
      007A93                       1478 00160$:
                                   1479 ;	quantum/action.c:764: if (pressed) {
      007A93 E5 1D            [12] 1480 	mov	a,_process_action_sloc0_1_0
      007A95 60 08            [24] 1481 	jz	00163$
                                   1482 ;	quantum/action.c:766: register_code(action.layer_tap.code);
      007A97 12 7C D6         [24] 1483 	lcall	_ak820_outline_0083
      007A9A 12 7A D1         [24] 1484 	lcall	_register_code
                                   1485 ;	quantum/action.c:768: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007A9D 80 1B            [24] 1486 	sjmp	00181$
      007A9F                       1487 00163$:
                                   1488 ;	quantum/action.c:769: if (action.layer_tap.code == KC_CAPS) {
      007A9F 12 7D 02         [24] 1489 	lcall	_ak820_outline_0167
      007AA2 FF               [12] 1490 	mov	r7,a
      007AA3 BF 39 0E         [24] 1491 	cjne	r7,#0x39,00175$
                                   1492 ;	quantum/action.c:770: wait_ms(TAP_HOLD_CAPS_DELAY);
      007AA6 7F 50            [12] 1493 	mov	r7,#0x50
      007AA8                       1494 00187$:
      007AA8 EF               [12] 1495 	mov	a,r7
      007AA9 60 09            [24] 1496 	jz	00175$
      007AAB 90 00 01         [24] 1497 	mov	dptr,#0x0001
      007AAE 12 5E D4         [24] 1498 	lcall	_mDelaymS
      007AB1 1F               [12] 1499 	dec	r7
                                   1500 ;	quantum/action.c:772: wait_ms(TAP_CODE_DELAY);
      007AB2 80 F4            [24] 1501 	sjmp	00187$
      007AB4                       1502 00175$:
                                   1503 ;	quantum/action.c:774: unregister_code(action.layer_tap.code);
      007AB4 12 7C D6         [24] 1504 	lcall	_ak820_outline_0083
      007AB7 12 7B 3E         [24] 1505 	lcall	_unregister_code
                                   1506 ;	quantum/action.c:857: }
      007ABA                       1507 00181$:
                                   1508 ;	quantum/action.c:878: switch (action.kind.id) {
      007ABA 90 08 83         [24] 1509 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007ABD E0               [24] 1510 	movx	a,@dptr
      007ABE C4               [12] 1511 	swap	a
      007ABF 54 0F            [12] 1512 	anl	a,#0x0f
      007AC1 FF               [12] 1513 	mov	r7,a
      007AC2 BF 08 02         [24] 1514 	cjne	r7,#0x08,00478$
      007AC5 80 03            [24] 1515 	sjmp	00183$
      007AC7                       1516 00478$:
      007AC7 BF 09 06         [24] 1517 	cjne	r7,#0x09,00192$
                                   1518 ;	quantum/action.c:880: case ACT_LAYER_MODS:
      007ACA                       1519 00183$:
                                   1520 ;	quantum/action.c:885: led_set(host_keyboard_leds());
      007ACA 12 72 5F         [24] 1521 	lcall	_host_keyboard_leds
                                   1522 ;	quantum/action.c:889: }
                                   1523 ;	quantum/action.c:942: }
      007ACD 02 9C 96         [24] 1524 	ljmp	_led_set
      007AD0                       1525 00192$:
      007AD0 22               [24] 1526 	ret
                                   1527 ;------------------------------------------------------------
                                   1528 ;Allocation info for local variables in function 'register_code'
                                   1529 ;------------------------------------------------------------
                                   1530 ;code          Allocated with name '_register_code_code_10000_733'
                                   1531 ;------------------------------------------------------------
                                   1532 ;	quantum/action.c:948: __attribute__((weak)) void register_code(uint8_t code) {
                                   1533 ;	-----------------------------------------
                                   1534 ;	 function register_code
                                   1535 ;	-----------------------------------------
      007AD1                       1536 _register_code:
      007AD1 E5 82            [12] 1537 	mov	a,dpl
      007AD3 90 08 88         [24] 1538 	mov	dptr,#_register_code_code_10000_733
      007AD6 F0               [24] 1539 	movx	@dptr,a
                                   1540 ;	quantum/action.c:949: if (code == KC_NO) {
      007AD7 E0               [24] 1541 	movx	a,@dptr
      007AD8 FF               [12] 1542 	mov	r7,a
      007AD9 70 01            [24] 1543 	jnz	00123$
                                   1544 ;	quantum/action.c:950: return;
      007ADB 22               [24] 1545 	ret
      007ADC                       1546 00123$:
                                   1547 ;	quantum/action.c:985: } else if (IS_BASIC_KEYCODE(code)) {
      007ADC BF 04 00         [24] 1548 	cjne	r7,#0x04,00186$
      007ADF                       1549 00186$:
      007ADF 40 12            [24] 1550 	jc	00119$
      007AE1 EF               [12] 1551 	mov	a,r7
      007AE2 24 5B            [12] 1552 	add	a,#0xff - 0xa4
      007AE4 40 0D            [24] 1553 	jc	00119$
                                   1554 ;	free result
                                   1555 ;	quantum/action.c:990: if (!add_owned_key(code)) return;
      007AE6 8F 82            [24] 1556 	mov	dpl, r7
      007AE8 12 82 F0         [24] 1557 	lcall	_add_owned_key
      007AEB E5 82            [12] 1558 	mov	a, dpl
      007AED 70 01            [24] 1559 	jnz	00104$
      007AEF 22               [24] 1560 	ret
      007AF0                       1561 00104$:
                                   1562 ;	quantum/action.c:1004: send_keyboard_report();
      007AF0 02 85 82         [24] 1563 	ljmp	_send_keyboard_report
      007AF3                       1564 00119$:
                                   1565 ;	quantum/action.c:1005: } else if (IS_MODIFIER_KEYCODE(code)) {
      007AF3 12 7D 07         [24] 1566 	lcall	_ak820_outline_0175
      007AF6 BF E0 00         [24] 1567 	cjne	r7,#0xe0,00190$
      007AF9                       1568 00190$:
      007AF9 40 1A            [24] 1569 	jc	00115$
      007AFB EF               [12] 1570 	mov	a,r7
      007AFC 24 18            [12] 1571 	add	a,#0xff - 0xe7
      007AFE 40 15            [24] 1572 	jc	00115$
                                   1573 ;	free result
                                   1574 ;	quantum/action.c:1006: add_owned_mods(MOD_BIT(code));
      007B00 74 07            [12] 1575 	mov	a,#0x07
      007B02 5F               [12] 1576 	anl	a,r7
      007B03 12 7C C5         [24] 1577 	lcall	_ak820_outline_0065
      007B06 80 02            [24] 1578 	sjmp	00194$
      007B08                       1579 00193$:
      007B08 25 E0            [12] 1580 	add	a,acc
      007B0A                       1581 00194$:
      007B0A D5 F0 FB         [24] 1582 	djnz	b,00193$
      007B0D F5 82            [12] 1583 	mov	dpl,a
      007B0F 12 82 50         [24] 1584 	lcall	_add_owned_mods
                                   1585 ;	quantum/action.c:1007: send_keyboard_report();
      007B12 02 85 82         [24] 1586 	ljmp	_send_keyboard_report
      007B15                       1587 00115$:
                                   1588 ;	quantum/action.c:1010: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007B15 12 7D 07         [24] 1589 	lcall	_ak820_outline_0175
      007B18 BF A5 00         [24] 1590 	cjne	r7,#0xa5,00195$
      007B1B                       1591 00195$:
      007B1B 40 05            [24] 1592 	jc	00113$
      007B1D EF               [12] 1593 	mov	a,r7
      007B1E 24 58            [12] 1594 	add	a,#0xff - 0xa7
      007B20 50 0D            [24] 1595 	jnc	00108$
                                   1596 ;	free result
      007B22                       1597 00113$:
      007B22 12 7D 07         [24] 1598 	lcall	_ak820_outline_0175
      007B25 BF A8 00         [24] 1599 	cjne	r7,#0xa8,00198$
      007B28                       1600 00198$:
      007B28 40 13            [24] 1601 	jc	00125$
      007B2A EF               [12] 1602 	mov	a,r7
      007B2B 24 3D            [12] 1603 	add	a,#0xff - 0xc2
      007B2D 40 0E            [24] 1604 	jc	00125$
                                   1605 ;	free result
      007B2F                       1606 00108$:
                                   1607 ;	quantum/action.c:1012: owned_usage_key(code, true);
      007B2F 12 7D 07         [24] 1608 	lcall	_ak820_outline_0175
      007B32 90 0A E3         [24] 1609 	mov	dptr,#_owned_usage_key_PARM_2
      007B35 74 01            [12] 1610 	mov	a,#0x01
      007B37 F0               [24] 1611 	movx	@dptr,a
      007B38 8F 82            [24] 1612 	mov	dpl, r7
                                   1613 ;	quantum/action.c:1020: register_mouse(code, true);
                                   1614 ;	quantum/action.c:1022: }
      007B3A 02 84 2F         [24] 1615 	ljmp	_owned_usage_key
      007B3D                       1616 00125$:
      007B3D 22               [24] 1617 	ret
                                   1618 ;------------------------------------------------------------
                                   1619 ;Allocation info for local variables in function 'unregister_code'
                                   1620 ;------------------------------------------------------------
                                   1621 ;code          Allocated with name '_unregister_code_code_10000_747'
                                   1622 ;------------------------------------------------------------
                                   1623 ;	quantum/action.c:1028: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1624 ;	-----------------------------------------
                                   1625 ;	 function unregister_code
                                   1626 ;	-----------------------------------------
      007B3E                       1627 _unregister_code:
      007B3E E5 82            [12] 1628 	mov	a,dpl
      007B40 90 08 89         [24] 1629 	mov	dptr,#_unregister_code_code_10000_747
      007B43 F0               [24] 1630 	movx	@dptr,a
                                   1631 ;	quantum/action.c:1029: if (code == KC_NO) {
      007B44 E0               [24] 1632 	movx	a,@dptr
      007B45 FF               [12] 1633 	mov	r7,a
      007B46 70 01            [24] 1634 	jnz	00121$
                                   1635 ;	quantum/action.c:1030: return;
      007B48 22               [24] 1636 	ret
      007B49                       1637 00121$:
                                   1638 ;	quantum/action.c:1062: } else if (IS_BASIC_KEYCODE(code)) {
      007B49 BF 04 00         [24] 1639 	cjne	r7,#0x04,00184$
      007B4C                       1640 00184$:
      007B4C 40 12            [24] 1641 	jc	00117$
      007B4E EF               [12] 1642 	mov	a,r7
      007B4F 24 5B            [12] 1643 	add	a,#0xff - 0xa4
      007B51 40 0D            [24] 1644 	jc	00117$
                                   1645 ;	free result
                                   1646 ;	quantum/action.c:1064: if (!del_owned_key(code)) return;
      007B53 8F 82            [24] 1647 	mov	dpl, r7
      007B55 12 83 69         [24] 1648 	lcall	_del_owned_key
      007B58 E5 82            [12] 1649 	mov	a, dpl
      007B5A 70 01            [24] 1650 	jnz	00102$
      007B5C 22               [24] 1651 	ret
      007B5D                       1652 00102$:
                                   1653 ;	quantum/action.c:1071: send_keyboard_report();
      007B5D 02 85 82         [24] 1654 	ljmp	_send_keyboard_report
      007B60                       1655 00117$:
                                   1656 ;	quantum/action.c:1072: } else if (IS_MODIFIER_KEYCODE(code)) {
      007B60 12 7D 0D         [24] 1657 	lcall	_ak820_outline_0176
      007B63 BF E0 00         [24] 1658 	cjne	r7,#0xe0,00188$
      007B66                       1659 00188$:
      007B66 40 1A            [24] 1660 	jc	00113$
      007B68 EF               [12] 1661 	mov	a,r7
      007B69 24 18            [12] 1662 	add	a,#0xff - 0xe7
      007B6B 40 15            [24] 1663 	jc	00113$
                                   1664 ;	free result
                                   1665 ;	quantum/action.c:1073: del_owned_mods(MOD_BIT(code));
      007B6D 74 07            [12] 1666 	mov	a,#0x07
      007B6F 5F               [12] 1667 	anl	a,r7
      007B70 12 7C C5         [24] 1668 	lcall	_ak820_outline_0065
      007B73 80 02            [24] 1669 	sjmp	00192$
      007B75                       1670 00191$:
      007B75 25 E0            [12] 1671 	add	a,acc
      007B77                       1672 00192$:
      007B77 D5 F0 FB         [24] 1673 	djnz	b,00191$
      007B7A F5 82            [12] 1674 	mov	dpl,a
      007B7C 12 82 5F         [24] 1675 	lcall	_del_owned_mods
                                   1676 ;	quantum/action.c:1074: send_keyboard_report();
      007B7F 02 85 82         [24] 1677 	ljmp	_send_keyboard_report
      007B82                       1678 00113$:
                                   1679 ;	quantum/action.c:1077: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007B82 12 7D 0D         [24] 1680 	lcall	_ak820_outline_0176
      007B85 BF A5 00         [24] 1681 	cjne	r7,#0xa5,00193$
      007B88                       1682 00193$:
      007B88 40 05            [24] 1683 	jc	00111$
      007B8A EF               [12] 1684 	mov	a,r7
      007B8B 24 58            [12] 1685 	add	a,#0xff - 0xa7
      007B8D 50 0D            [24] 1686 	jnc	00106$
                                   1687 ;	free result
      007B8F                       1688 00111$:
      007B8F 12 7D 0D         [24] 1689 	lcall	_ak820_outline_0176
      007B92 BF A8 00         [24] 1690 	cjne	r7,#0xa8,00196$
      007B95                       1691 00196$:
      007B95 40 12            [24] 1692 	jc	00123$
      007B97 EF               [12] 1693 	mov	a,r7
      007B98 24 3D            [12] 1694 	add	a,#0xff - 0xc2
      007B9A 40 0D            [24] 1695 	jc	00123$
                                   1696 ;	free result
      007B9C                       1697 00106$:
                                   1698 ;	quantum/action.c:1079: owned_usage_key(code, false);
      007B9C 12 7D 0D         [24] 1699 	lcall	_ak820_outline_0176
      007B9F 90 0A E3         [24] 1700 	mov	dptr,#_owned_usage_key_PARM_2
      007BA2 E4               [12] 1701 	clr	a
      007BA3 F0               [24] 1702 	movx	@dptr,a
      007BA4 8F 82            [24] 1703 	mov	dpl, r7
                                   1704 ;	quantum/action.c:1087: register_mouse(code, false);
                                   1705 ;	quantum/action.c:1089: }
      007BA6 02 84 2F         [24] 1706 	ljmp	_owned_usage_key
      007BA9                       1707 00123$:
      007BA9 22               [24] 1708 	ret
                                   1709 ;------------------------------------------------------------
                                   1710 ;Allocation info for local variables in function 'tap_code_delay'
                                   1711 ;------------------------------------------------------------
                                   1712 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1713 ;code          Allocated with name '_tap_code_delay_code_10000_760'
                                   1714 ;i             Allocated with name '_tap_code_delay_i_20000_762'
                                   1715 ;i             Allocated with name '_tap_code_delay_i_50000_765'
                                   1716 ;------------------------------------------------------------
                                   1717 ;	quantum/action.c:1096: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1718 ;	-----------------------------------------
                                   1719 ;	 function tap_code_delay
                                   1720 ;	-----------------------------------------
      007BAA                       1721 _tap_code_delay:
      007BAA E5 82            [12] 1722 	mov	a,dpl
      007BAC 90 08 8C         [24] 1723 	mov	dptr,#_tap_code_delay_code_10000_760
      007BAF F0               [24] 1724 	movx	@dptr,a
                                   1725 ;	quantum/action.c:1097: register_code(code);
      007BB0 E0               [24] 1726 	movx	a,@dptr
      007BB1 FF               [12] 1727 	mov	r7,a
      007BB2 F5 82            [12] 1728 	mov	dpl,a
      007BB4 C0 07            [24] 1729 	push	ar7
      007BB6 51 D1            [12] 1730 	acall	_register_code
      007BB8 D0 07            [24] 1731 	pop	ar7
                                   1732 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007BBA 90 08 8A         [24] 1733 	mov	dptr,#_tap_code_delay_PARM_2
      007BBD 12 38 67         [24] 1734 	lcall	_ak820_outline_0090
      007BC0                       1735 00110$:
      007BC0 ED               [12] 1736 	mov	a,r5
      007BC1 4E               [12] 1737 	orl	a,r6
      007BC2 60 0D            [24] 1738 	jz	00105$
                                   1739 ;	quantum/action.c:1099: wait_ms(1);
      007BC4 90 00 01         [24] 1740 	mov	dptr,#0x0001
      007BC7 12 5E D4         [24] 1741 	lcall	_mDelaymS
                                   1742 ;	quantum/action.c:1098: for (uint16_t i = delay; i > 0; i--) {
      007BCA 1D               [12] 1743 	dec	r5
      007BCB BD FF 01         [24] 1744 	cjne	r5,#0xff,00141$
      007BCE 1E               [12] 1745 	dec	r6
      007BCF                       1746 00141$:
      007BCF 80 EF            [24] 1747 	sjmp	00110$
      007BD1                       1748 00105$:
                                   1749 ;	quantum/action.c:1101: unregister_code(code);
      007BD1 8F 82            [24] 1750 	mov	dpl, r7
                                   1751 ;	quantum/action.c:1102: }
      007BD3 61 3E            [12] 1752 	ajmp	_unregister_code
                                   1753 ;------------------------------------------------------------
                                   1754 ;Allocation info for local variables in function 'tap_code'
                                   1755 ;------------------------------------------------------------
                                   1756 ;code          Allocated with name '_tap_code_code_10000_767'
                                   1757 ;------------------------------------------------------------
                                   1758 ;	quantum/action.c:1108: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1759 ;	-----------------------------------------
                                   1760 ;	 function tap_code
                                   1761 ;	-----------------------------------------
      007BD5                       1762 _tap_code:
      007BD5 E5 82            [12] 1763 	mov	a,dpl
      007BD7 90 08 8D         [24] 1764 	mov	dptr,#_tap_code_code_10000_767
      007BDA F0               [24] 1765 	movx	@dptr,a
                                   1766 ;	quantum/action.c:1109: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007BDB E0               [24] 1767 	movx	a,@dptr
      007BDC FF               [12] 1768 	mov	r7,a
      007BDD BF 39 0D         [24] 1769 	cjne	r7,#0x39,00103$
      007BE0 C0 07            [24] 1770 	push	ar7
      007BE2 12 49 2E         [24] 1771 	lcall	_ak820_settings_caps_delay
      007BE5 AD 82            [24] 1772 	mov	r5, dpl
      007BE7 AE 83            [24] 1773 	mov	r6, dph
      007BE9 D0 07            [24] 1774 	pop	ar7
      007BEB 80 0B            [24] 1775 	sjmp	00104$
      007BED                       1776 00103$:
      007BED C0 07            [24] 1777 	push	ar7
      007BEF 12 49 28         [24] 1778 	lcall	_ak820_settings_tap_code_delay
      007BF2 AD 82            [24] 1779 	mov	r5, dpl
      007BF4 AE 83            [24] 1780 	mov	r6, dph
      007BF6 D0 07            [24] 1781 	pop	ar7
      007BF8                       1782 00104$:
      007BF8 90 08 8A         [24] 1783 	mov	dptr,#_tap_code_delay_PARM_2
      007BFB 12 43 6F         [24] 1784 	lcall	_ak820_outline_0146
      007BFE 8F 82            [24] 1785 	mov	dpl, r7
                                   1786 ;	quantum/action.c:1110: }
      007C00 61 AA            [12] 1787 	ajmp	_tap_code_delay
                                   1788 ;------------------------------------------------------------
                                   1789 ;Allocation info for local variables in function 'register_mods'
                                   1790 ;------------------------------------------------------------
                                   1791 ;mods          Allocated with name '_register_mods_mods_10000_769'
                                   1792 ;------------------------------------------------------------
                                   1793 ;	quantum/action.c:1116: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1794 ;	-----------------------------------------
                                   1795 ;	 function register_mods
                                   1796 ;	-----------------------------------------
      007C02                       1797 _register_mods:
      007C02 E5 82            [12] 1798 	mov	a,dpl
      007C04 90 08 8E         [24] 1799 	mov	dptr,#_register_mods_mods_10000_769
      007C07 F0               [24] 1800 	movx	@dptr,a
                                   1801 ;	quantum/action.c:1117: if (mods) {
      007C08 E0               [24] 1802 	movx	a,@dptr
      007C09 FF               [12] 1803 	mov	r7,a
      007C0A E0               [24] 1804 	movx	a,@dptr
      007C0B 60 08            [24] 1805 	jz	00103$
                                   1806 ;	quantum/action.c:1118: add_owned_mods(mods);
      007C0D 8F 82            [24] 1807 	mov	dpl, r7
      007C0F 12 82 50         [24] 1808 	lcall	_add_owned_mods
                                   1809 ;	quantum/action.c:1119: send_keyboard_report();
                                   1810 ;	quantum/action.c:1121: }
      007C12 02 85 82         [24] 1811 	ljmp	_send_keyboard_report
      007C15                       1812 00103$:
      007C15 22               [24] 1813 	ret
                                   1814 ;------------------------------------------------------------
                                   1815 ;Allocation info for local variables in function 'unregister_mods'
                                   1816 ;------------------------------------------------------------
                                   1817 ;mods          Allocated with name '_unregister_mods_mods_10000_773'
                                   1818 ;------------------------------------------------------------
                                   1819 ;	quantum/action.c:1127: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1820 ;	-----------------------------------------
                                   1821 ;	 function unregister_mods
                                   1822 ;	-----------------------------------------
      007C16                       1823 _unregister_mods:
      007C16 E5 82            [12] 1824 	mov	a,dpl
      007C18 90 08 8F         [24] 1825 	mov	dptr,#_unregister_mods_mods_10000_773
      007C1B F0               [24] 1826 	movx	@dptr,a
                                   1827 ;	quantum/action.c:1128: if (mods) {
      007C1C E0               [24] 1828 	movx	a,@dptr
      007C1D FF               [12] 1829 	mov	r7,a
      007C1E E0               [24] 1830 	movx	a,@dptr
      007C1F 60 08            [24] 1831 	jz	00103$
                                   1832 ;	quantum/action.c:1129: del_owned_mods(mods);
      007C21 8F 82            [24] 1833 	mov	dpl, r7
      007C23 12 82 5F         [24] 1834 	lcall	_del_owned_mods
                                   1835 ;	quantum/action.c:1130: send_keyboard_report();
                                   1836 ;	quantum/action.c:1132: }
      007C26 02 85 82         [24] 1837 	ljmp	_send_keyboard_report
      007C29                       1838 00103$:
      007C29 22               [24] 1839 	ret
                                   1840 ;------------------------------------------------------------
                                   1841 ;Allocation info for local variables in function 'register_weak_mods'
                                   1842 ;------------------------------------------------------------
                                   1843 ;mods          Allocated with name '_register_weak_mods_mods_10000_777'
                                   1844 ;------------------------------------------------------------
                                   1845 ;	quantum/action.c:1138: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1846 ;	-----------------------------------------
                                   1847 ;	 function register_weak_mods
                                   1848 ;	-----------------------------------------
      007C2A                       1849 _register_weak_mods:
      007C2A E5 82            [12] 1850 	mov	a,dpl
      007C2C 90 08 90         [24] 1851 	mov	dptr,#_register_weak_mods_mods_10000_777
      007C2F F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action.c:1139: if (mods) {
      007C30 E0               [24] 1854 	movx	a,@dptr
      007C31 FF               [12] 1855 	mov	r7,a
      007C32 E0               [24] 1856 	movx	a,@dptr
      007C33 60 08            [24] 1857 	jz	00103$
                                   1858 ;	quantum/action.c:1140: add_owned_weak_mods(mods);
      007C35 8F 82            [24] 1859 	mov	dpl, r7
      007C37 12 82 6D         [24] 1860 	lcall	_add_owned_weak_mods
                                   1861 ;	quantum/action.c:1141: send_keyboard_report();
                                   1862 ;	quantum/action.c:1143: }
      007C3A 02 85 82         [24] 1863 	ljmp	_send_keyboard_report
      007C3D                       1864 00103$:
      007C3D 22               [24] 1865 	ret
                                   1866 ;------------------------------------------------------------
                                   1867 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1868 ;------------------------------------------------------------
                                   1869 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_781'
                                   1870 ;------------------------------------------------------------
                                   1871 ;	quantum/action.c:1149: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1872 ;	-----------------------------------------
                                   1873 ;	 function unregister_weak_mods
                                   1874 ;	-----------------------------------------
      007C3E                       1875 _unregister_weak_mods:
      007C3E E5 82            [12] 1876 	mov	a,dpl
      007C40 90 08 91         [24] 1877 	mov	dptr,#_unregister_weak_mods_mods_10000_781
      007C43 F0               [24] 1878 	movx	@dptr,a
                                   1879 ;	quantum/action.c:1150: if (mods) {
      007C44 E0               [24] 1880 	movx	a,@dptr
      007C45 FF               [12] 1881 	mov	r7,a
      007C46 E0               [24] 1882 	movx	a,@dptr
      007C47 60 08            [24] 1883 	jz	00103$
                                   1884 ;	quantum/action.c:1151: del_owned_weak_mods(mods);
      007C49 8F 82            [24] 1885 	mov	dpl, r7
      007C4B 12 82 7C         [24] 1886 	lcall	_del_owned_weak_mods
                                   1887 ;	quantum/action.c:1152: send_keyboard_report();
                                   1888 ;	quantum/action.c:1154: }
      007C4E 02 85 82         [24] 1889 	ljmp	_send_keyboard_report
      007C51                       1890 00103$:
      007C51 22               [24] 1891 	ret
                                   1892 ;------------------------------------------------------------
                                   1893 ;Allocation info for local variables in function 'clear_keyboard'
                                   1894 ;------------------------------------------------------------
                                   1895 ;	quantum/action.c:1160: void clear_keyboard(void) {
                                   1896 ;	-----------------------------------------
                                   1897 ;	 function clear_keyboard
                                   1898 ;	-----------------------------------------
      007C52                       1899 _clear_keyboard:
                                   1900 ;	quantum/action.c:1161: clear_mods();
      007C52 12 85 FD         [24] 1901 	lcall	_clear_mods
                                   1902 ;	quantum/action.c:1162: clear_keyboard_but_mods();
                                   1903 ;	quantum/action.c:1163: }
      007C55 81 57            [12] 1904 	ajmp	_clear_keyboard_but_mods
                                   1905 ;------------------------------------------------------------
                                   1906 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1907 ;------------------------------------------------------------
                                   1908 ;	quantum/action.c:1169: void clear_keyboard_but_mods(void) {
                                   1909 ;	-----------------------------------------
                                   1910 ;	 function clear_keyboard_but_mods
                                   1911 ;	-----------------------------------------
      007C57                       1912 _clear_keyboard_but_mods:
                                   1913 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007C57 90 0E 1E         [24] 1914 	mov	dptr,#_actual_keyboard_report
      007C5A 12 75 20         [24] 1915 	lcall	_clear_keys_from_report
                                   1916 ;	quantum/action.c:1171: clear_keyboard_but_mods_and_keys();
                                   1917 ;	quantum/action.c:1172: }
      007C5D 81 5F            [12] 1918 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	quantum/action.c:1178: void clear_keyboard_but_mods_and_keys(void) {
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function clear_keyboard_but_mods_and_keys
                                   1925 ;	-----------------------------------------
      007C5F                       1926 _clear_keyboard_but_mods_and_keys:
                                   1927 ;	quantum/action.c:1180: ak820_tapping_cancel();
      007C5F 12 4D 25         [24] 1928 	lcall	_ak820_tapping_cancel
                                   1929 ;	quantum/action.c:1197: ak820_oneshot_cancel();
      007C62 12 2E F0         [24] 1930 	lcall	_ak820_oneshot_cancel
                                   1931 ;	quantum/action.c:1200: ak820_combo_cancel();
      007C65 12 35 6C         [24] 1932 	lcall	_ak820_combo_cancel
                                   1933 ;	quantum/action.c:1203: repeat_key_cancel();
      007C68 12 A6 EF         [24] 1934 	lcall	_repeat_key_cancel
                                   1935 ;	quantum/action.c:1205: clear_owned_mods();
      007C6B 12 82 8B         [24] 1936 	lcall	_clear_owned_mods
                                   1937 ;	quantum/action.c:1206: clear_owned_keys();
      007C6E 12 82 C3         [24] 1938 	lcall	_clear_owned_keys
                                   1939 ;	quantum/action.c:1207: clear_owned_usages();
      007C71 12 83 F7         [24] 1940 	lcall	_clear_owned_usages
                                   1941 ;	quantum/action.c:1208: layer_hold_clear();
      007C74 D1 48            [12] 1942 	acall	_layer_hold_clear
                                   1943 ;	quantum/action.c:1210: clear_macro_tri_layer();
      007C76 12 A1 CA         [24] 1944 	lcall	_clear_macro_tri_layer
                                   1945 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007C79 90 0E 1E         [24] 1946 	mov	dptr,#_actual_keyboard_report
      007C7C 12 75 20         [24] 1947 	lcall	_clear_keys_from_report
                                   1948 ;	quantum/action.c:1215: host_system_send(0);
      007C7F 90 00 00         [24] 1949 	mov	dptr,#0x0000
      007C82 12 72 FA         [24] 1950 	lcall	_host_system_send
                                   1951 ;	quantum/action.c:1216: host_consumer_send(0);
      007C85 90 00 00         [24] 1952 	mov	dptr,#0x0000
      007C88 12 73 29         [24] 1953 	lcall	_host_consumer_send
                                   1954 ;	quantum/action.c:1218: clear_weak_mods();
      007C8B 12 86 32         [24] 1955 	lcall	_clear_weak_mods
                                   1956 ;	quantum/action.c:1219: send_keyboard_report();
                                   1957 ;	quantum/action.c:1227: }
      007C8E 02 85 82         [24] 1958 	ljmp	_send_keyboard_report
                                   1959 ;------------------------------------------------------------
                                   1960 ;Allocation info for local variables in function 'is_tap_record'
                                   1961 ;------------------------------------------------------------
                                   1962 ;record        Allocated with name '_is_tap_record_record_10000_797'
                                   1963 ;action        Allocated with name '_is_tap_record_action_10001_801'
                                   1964 ;------------------------------------------------------------
                                   1965 ;	quantum/action.c:1233: bool is_tap_record(keyrecord_t *record) {
                                   1966 ;	-----------------------------------------
                                   1967 	.area CSEG    (CODE)
                                   1968 	.area CONST   (CODE)
                                   1969 	.area XINIT   (CODE)
      00C82E                       1970 __xinit__disable_action_cache:
      00C82E 00                    1971 	.db #0x00	;  0
                                   1972 	.area CABS    (ABS,CODE)
                                   1973 
                                   1974 ; Experimental exact instruction outlining.
                                   1975 	.globl _ak820_outline_0001
                                   1976 	.globl _ak820_outline_0005
                                   1977 	.globl _ak820_outline_0008
                                   1978 	.globl _ak820_outline_0009
                                   1979 	.globl _ak820_outline_0013
                                   1980 	.globl _ak820_outline_0014
                                   1981 	.globl _ak820_outline_0015
                                   1982 	.globl _ak820_outline_0016
                                   1983 	.globl _ak820_outline_0018
                                   1984 	.globl _ak820_outline_0023
                                   1985 	.globl _ak820_outline_0024
                                   1986 	.globl _ak820_outline_0033
                                   1987 	.globl _ak820_outline_0038
                                   1988 	.globl _ak820_outline_0044
                                   1989 	.globl _ak820_outline_0050
                                   1990 	.globl _ak820_outline_0061
                                   1991 	.globl _ak820_outline_0065
                                   1992 	.globl _ak820_outline_0070
                                   1993 	.globl _ak820_outline_0075
                                   1994 	.globl _ak820_outline_0078
                                   1995 	.globl _ak820_outline_0083
                                   1996 	.globl _ak820_outline_0090
                                   1997 	.globl _ak820_outline_0094
                                   1998 	.globl _ak820_outline_0113
                                   1999 	.globl _ak820_outline_0114
                                   2000 	.globl _ak820_outline_0116
                                   2001 	.globl _ak820_outline_0117
                                   2002 	.globl _ak820_outline_0119
                                   2003 	.globl _ak820_outline_0124
                                   2004 	.globl _ak820_outline_0130
                                   2005 	.globl _ak820_outline_0132
                                   2006 	.globl _ak820_outline_0133
                                   2007 	.globl _ak820_outline_0139
                                   2008 	.globl _ak820_outline_0146
                                   2009 	.globl _ak820_outline_0152
                                   2010 	.globl _ak820_outline_0153
                                   2011 	.globl _ak820_outline_0156
                                   2012 	.globl _ak820_outline_0160
                                   2013 	.globl _ak820_outline_0167
                                   2014 	.globl _ak820_outline_0175
                                   2015 	.globl _ak820_outline_0176
                                   2016 	.globl _ak820_outline_0177
                                   2017 	.globl _ak820_outline_0195
                                   2018 	.globl _ak820_outline_0197
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0015
      007C91                       2022 _ak820_outline_0015:
      007C91 2D               [12] 2023 	add	a,r5
      007C92 F9               [12] 2024 	mov	r1,a
      007C93 E4               [12] 2025 	clr	a
      007C94 3E               [12] 2026 	addc	a,r6
      007C95 FA               [12] 2027 	mov	r2,a
      007C96 8F 03            [24] 2028 	mov	ar3,r7
      007C98 89 82            [24] 2029 	mov	dpl,r1
      007C9A 8A 83            [24] 2030 	mov	dph,r2
      007C9C 8B F0            [24] 2031 	mov	b,r3
      007C9E 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0016
      007C9F                       2036 _ak820_outline_0016:
      007C9F 2D               [12] 2037 	add	a,r5
      007CA0 FA               [12] 2038 	mov	r2,a
      007CA1 E4               [12] 2039 	clr	a
      007CA2 3E               [12] 2040 	addc	a,r6
      007CA3 FB               [12] 2041 	mov	r3,a
      007CA4 8F 04            [24] 2042 	mov	ar4,r7
      007CA6 8A 82            [24] 2043 	mov	dpl,r2
      007CA8 8B 83            [24] 2044 	mov	dph,r3
      007CAA 8C F0            [24] 2045 	mov	b,r4
      007CAC 22               [24] 2046 	ret
                                   2047 
                                   2048 	.area CSEG (CODE)
                                   2049 ; function ak820_outline_0023
      007CAD                       2050 _ak820_outline_0023:
      007CAD 8E 82            [24] 2051 	mov	dpl,r6
      007CAF 8F 83            [24] 2052 	mov	dph,r7
      007CB1 A3               [24] 2053 	inc	dptr
      007CB2 E0               [24] 2054 	movx	a,@dptr
      007CB3 FC               [12] 2055 	mov	r4,a
      007CB4 7D 00            [12] 2056 	mov	r5,#0x00
      007CB6 8E 82            [24] 2057 	mov	dpl,r6
      007CB8 8F 83            [24] 2058 	mov	dph,r7
      007CBA E0               [24] 2059 	movx	a,@dptr
      007CBB 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0044
      007CBC                       2064 _ak820_outline_0044:
      007CBC 90 08 83         [24] 2065 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007CBF E0               [24] 2066 	movx	a,@dptr
      007CC0 54 1F            [12] 2067 	anl	a,#0x1f
      007CC2 F5 82            [12] 2068 	mov	dpl,a
      007CC4 22               [24] 2069 	ret
                                   2070 
                                   2071 	.area CSEG (CODE)
                                   2072 ; function ak820_outline_0065
      007CC5                       2073 _ak820_outline_0065:
      007CC5 F5 F0            [12] 2074 	mov	b,a
      007CC7 05 F0            [12] 2075 	inc	b
      007CC9 74 01            [12] 2076 	mov	a,#0x01
      007CCB 22               [24] 2077 	ret
                                   2078 
                                   2079 	.area CSEG (CODE)
                                   2080 ; function ak820_outline_0075
      007CCC                       2081 _ak820_outline_0075:
      007CCC 90 0D F4         [24] 2082 	mov	dptr,#___memcpy_PARM_3
      007CCF 74 06            [12] 2083 	mov	a,#0x06
      007CD1 F0               [24] 2084 	movx	@dptr,a
      007CD2 E4               [12] 2085 	clr	a
      007CD3 A3               [24] 2086 	inc	dptr
      007CD4 F0               [24] 2087 	movx	@dptr,a
      007CD5 22               [24] 2088 	ret
                                   2089 
                                   2090 	.area CSEG (CODE)
                                   2091 ; function ak820_outline_0083
      007CD6                       2092 _ak820_outline_0083:
      007CD6 90 08 82         [24] 2093 	mov	dptr,#_process_action_PARM_2
      007CD9 E0               [24] 2094 	movx	a,@dptr
      007CDA F5 82            [12] 2095 	mov	dpl,a
      007CDC 22               [24] 2096 	ret
                                   2097 
                                   2098 	.area CSEG (CODE)
                                   2099 ; function ak820_outline_0094
      007CDD                       2100 _ak820_outline_0094:
      007CDD 90 08 83         [24] 2101 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007CE0 E0               [24] 2102 	movx	a,@dptr
      007CE1 03               [12] 2103 	rr	a
      007CE2 03               [12] 2104 	rr	a
      007CE3 54 03            [12] 2105 	anl	a,#0x03
      007CE5 22               [24] 2106 	ret
                                   2107 
                                   2108 	.area CSEG (CODE)
                                   2109 ; function ak820_outline_0119
      007CE6                       2110 _ak820_outline_0119:
      007CE6 90 08 83         [24] 2111 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007CE9 E0               [24] 2112 	movx	a,@dptr
      007CEA 54 0F            [12] 2113 	anl	a,#0x0f
      007CEC 22               [24] 2114 	ret
                                   2115 
                                   2116 	.area CSEG (CODE)
                                   2117 ; function ak820_outline_0139
      007CED                       2118 _ak820_outline_0139:
      007CED 90 08 82         [24] 2119 	mov	dptr,#_process_action_PARM_2
      007CF0 E0               [24] 2120 	movx	a,@dptr
      007CF1 FE               [12] 2121 	mov	r6,a
      007CF2 A3               [24] 2122 	inc	dptr
      007CF3 E0               [24] 2123 	movx	a,@dptr
      007CF4 54 03            [12] 2124 	anl	a,#0x03
      007CF6 FF               [12] 2125 	mov	r7,a
      007CF7 22               [24] 2126 	ret
                                   2127 
                                   2128 	.area CSEG (CODE)
                                   2129 ; function ak820_outline_0156
      007CF8                       2130 _ak820_outline_0156:
      007CF8 74 07            [12] 2131 	mov	a,#0x07
      007CFA 2D               [12] 2132 	add	a,r5
      007CFB F8               [12] 2133 	mov	r0,a
      007CFC E4               [12] 2134 	clr	a
      007CFD 3E               [12] 2135 	addc	a,r6
      007CFE F9               [12] 2136 	mov	r1,a
      007CFF 8F 02            [24] 2137 	mov	ar2,r7
      007D01 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0167
      007D02                       2142 _ak820_outline_0167:
      007D02 90 08 82         [24] 2143 	mov	dptr,#_process_action_PARM_2
      007D05 E0               [24] 2144 	movx	a,@dptr
      007D06 22               [24] 2145 	ret
                                   2146 
                                   2147 	.area CSEG (CODE)
                                   2148 ; function ak820_outline_0175
      007D07                       2149 _ak820_outline_0175:
      007D07 90 08 88         [24] 2150 	mov	dptr,#_register_code_code_10000_733
      007D0A E0               [24] 2151 	movx	a,@dptr
      007D0B FF               [12] 2152 	mov	r7,a
      007D0C 22               [24] 2153 	ret
                                   2154 
                                   2155 	.area CSEG (CODE)
                                   2156 ; function ak820_outline_0176
      007D0D                       2157 _ak820_outline_0176:
      007D0D 90 08 89         [24] 2158 	mov	dptr,#_unregister_code_code_10000_747
      007D10 E0               [24] 2159 	movx	a,@dptr
      007D11 FF               [12] 2160 	mov	r7,a
      007D12 22               [24] 2161 	ret
