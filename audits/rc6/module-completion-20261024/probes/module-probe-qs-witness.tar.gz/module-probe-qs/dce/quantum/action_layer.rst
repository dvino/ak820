                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _ak820_keycode_at
                                     14 	.globl _action_for_keycode
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _layer_state
                                    259 	.globl _default_layer_state
                                    260 	.globl _ak820_resolve_key_PARM_2
                                    261 	.globl _ak820_cache_layer_PARM_2
                                    262 	.globl _ak820_cache_keycode_PARM_2
                                    263 	.globl _default_layer_state_set_user
                                    264 	.globl _default_layer_state_set_kb
                                    265 	.globl _default_layer_set
                                    266 	.globl _default_layer_or
                                    267 	.globl _default_layer_and
                                    268 	.globl _default_layer_xor
                                    269 	.globl _ak820_layer_refresh
                                    270 	.globl _layer_hold_on
                                    271 	.globl _layer_hold_off
                                    272 	.globl _layer_hold_clear
                                    273 	.globl _layer_state_set_user
                                    274 	.globl _layer_state_set_kb
                                    275 	.globl _layer_state_set
                                    276 	.globl _layer_clear
                                    277 	.globl _layer_move
                                    278 	.globl _layer_on
                                    279 	.globl _layer_off
                                    280 	.globl _layer_or
                                    281 	.globl _layer_and
                                    282 	.globl _layer_xor
                                    283 	.globl _ak820_cache_keycode
                                    284 	.globl _ak820_cache_layer
                                    285 	.globl _ak820_cached_key
                                    286 	.globl _ak820_resolve_key
                                    287 	.globl _ak820_layer_for_key
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
                                    566 ;--------------------------------------------------------
                                    567 ; paged external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area PSEG    (PAG,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; uninitialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XSEG    (XDATA)
      000892                        574 _default_layer_state_set_user_state_10000_317:
      000892                        575 	.ds 1
      000893                        576 _default_layer_state_set_kb_state_10000_319:
      000893                        577 	.ds 1
      000894                        578 _default_layer_state_set_state_10000_321:
      000894                        579 	.ds 1
      000895                        580 _default_layer_set_state_10000_326:
      000895                        581 	.ds 1
      000896                        582 _default_layer_or_state_10000_328:
      000896                        583 	.ds 1
      000897                        584 _default_layer_and_state_10000_330:
      000897                        585 	.ds 1
      000898                        586 _default_layer_xor_state_10000_332:
      000898                        587 	.ds 1
      000899                        588 _persistent_layers:
      000899                        589 	.ds 1
      00089A                        590 _layer_refs:
      00089A                        591 	.ds 6
      0008A0                        592 _macro_layers:
      0008A0                        593 	.ds 1
      0008A1                        594 _ak820_layer_refresh_state_10000_335:
      0008A1                        595 	.ds 1
      0008A2                        596 _layer_hold_on_layer_10000_338:
      0008A2                        597 	.ds 1
      0008A3                        598 _layer_hold_off_layer_10000_342:
      0008A3                        599 	.ds 1
      0008A4                        600 _layer_state_set_user_state_10000_349:
      0008A4                        601 	.ds 1
      0008A5                        602 _layer_state_set_kb_state_10000_351:
      0008A5                        603 	.ds 1
      0008A6                        604 _layer_state_set_state_10000_353:
      0008A6                        605 	.ds 1
      0008A7                        606 _layer_move_layer_10000_366:
      0008A7                        607 	.ds 1
      0008A8                        608 _layer_on_layer_10000_368:
      0008A8                        609 	.ds 1
      0008A9                        610 _layer_off_layer_10000_370:
      0008A9                        611 	.ds 1
      0008AA                        612 _layer_or_state_10000_374:
      0008AA                        613 	.ds 1
      0008AB                        614 _layer_and_state_10000_376:
      0008AB                        615 	.ds 1
      0008AC                        616 _layer_xor_state_10000_378:
      0008AC                        617 	.ds 1
      0008AD                        618 _source_keycodes_cache:
      0008AD                        619 	.ds 256
      0009AD                        620 _encoder_source_keycodes_cache:
      0009AD                        621 	.ds 4
      0009B1                        622 _source_keycode_cache_slot_position_10000_380:
      0009B1                        623 	.ds 2
      0009B3                        624 _ak820_cache_keycode_PARM_2:
      0009B3                        625 	.ds 2
      0009B5                        626 _ak820_cache_keycode_position_10000_386:
      0009B5                        627 	.ds 2
      0009B7                        628 _ak820_cache_layer_PARM_2:
      0009B7                        629 	.ds 1
      0009B8                        630 _ak820_cache_layer_position_10000_389:
      0009B8                        631 	.ds 2
      0009BA                        632 _ak820_cached_key_position_10000_392:
      0009BA                        633 	.ds 2
      0009BC                        634 _ak820_resolve_key_PARM_2:
      0009BC                        635 	.ds 1
      0009BD                        636 _ak820_resolve_key_position_10000_403:
      0009BD                        637 	.ds 2
      0009BF                        638 _ak820_layer_for_key_position_10000_410:
      0009BF                        639 	.ds 2
      0009C1                        640 _ak820_layer_for_key_layers_10000_411:
      0009C1                        641 	.ds 1
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
      000E1A                        650 _default_layer_state::
      000E1A                        651 	.ds 1
      000E1B                        652 _layer_state::
      000E1B                        653 	.ds 1
                                    654 	.area HOME    (CODE)
                                    655 	.area GSINIT0 (CODE)
                                    656 	.area GSINIT1 (CODE)
                                    657 	.area GSINIT2 (CODE)
                                    658 	.area GSINIT3 (CODE)
                                    659 	.area GSINIT4 (CODE)
                                    660 	.area GSINIT5 (CODE)
                                    661 	.area GSINIT  (CODE)
                                    662 	.area GSFINAL (CODE)
                                    663 	.area CSEG    (CODE)
                                    664 ;--------------------------------------------------------
                                    665 ; global & static initialisations
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; Home
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area HOME    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; code
                                    678 ;--------------------------------------------------------
                                    679 	.area CSEG    (CODE)
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    682 ;------------------------------------------------------------
                                    683 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_190'
                                    684 ;------------------------------------------------------------
                                    685 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    686 ;	-----------------------------------------
                           000007   687 	ar7 = 0x07
                           000006   688 	ar6 = 0x06
                           000005   689 	ar5 = 0x05
                           000004   690 	ar4 = 0x04
                           000003   691 	ar3 = 0x03
                           000002   692 	ar2 = 0x02
                           000001   693 	ar1 = 0x01
                           000000   694 	ar0 = 0x00
                                    695 ;	 function default_layer_state_set_user
                                    696 ;	-----------------------------------------
      007D13                        697 _default_layer_state_set_user:
      007D13 E5 82            [12]  698 	mov	a,dpl
      007D15 90 08 92         [24]  699 	mov	dptr,#_default_layer_state_set_user_state_10000_317
      007D18 12 5D 31         [24]  700 	lcall	_ak820_outline_0179
                                    701 ;	quantum/action_layer.c:32: return state;
                                    702 ;	quantum/action_layer.c:33: }
      007D1B 22               [24]  703 	ret
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    706 ;------------------------------------------------------------
                                    707 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_319'
                                    708 ;------------------------------------------------------------
                                    709 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    710 ;	-----------------------------------------
                                    711 ;	 function default_layer_state_set_kb
                                    712 ;	-----------------------------------------
      007D1C                        713 _default_layer_state_set_kb:
      007D1C E5 82            [12]  714 	mov	a,dpl
      007D1E 90 08 93         [24]  715 	mov	dptr,#_default_layer_state_set_kb_state_10000_319
      007D21 12 5D 31         [24]  716 	lcall	_ak820_outline_0179
                                    717 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    718 ;	quantum/action_layer.c:41: }
      007D24 A1 13            [12]  719 	ajmp	_default_layer_state_set_user
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'default_layer_state_set'
                                    722 ;------------------------------------------------------------
                                    723 ;state         Allocated with name '_default_layer_state_set_state_10000_321'
                                    724 ;------------------------------------------------------------
                                    725 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    726 ;	-----------------------------------------
                                    727 ;	 function default_layer_state_set
                                    728 ;	-----------------------------------------
      007D26                        729 _default_layer_state_set:
      007D26 E5 82            [12]  730 	mov	a,dpl
      007D28 90 08 94         [24]  731 	mov	dptr,#_default_layer_state_set_state_10000_321
      007D2B 12 5D 31         [24]  732 	lcall	_ak820_outline_0179
                                    733 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      007D2E B1 1C            [12]  734 	acall	_default_layer_state_set_kb
      007D30 AF 82            [24]  735 	mov	r7, dpl
      007D32 90 08 94         [24]  736 	mov	dptr,#_default_layer_state_set_state_10000_321
      007D35 EF               [12]  737 	mov	a,r7
      007D36 F0               [24]  738 	movx	@dptr,a
                                    739 ;	quantum/action_layer.c:52: default_layer_state = state;
      007D37 90 0E 1A         [24]  740 	mov	dptr,#_default_layer_state
      007D3A EF               [12]  741 	mov	a,r7
      007D3B F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    744 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    745 ;	quantum/action_layer.c:63: }
      007D3C A1 7F            [12]  746 	ajmp	_ak820_layer_refresh
                                    747 ;------------------------------------------------------------
                                    748 ;Allocation info for local variables in function 'default_layer_set'
                                    749 ;------------------------------------------------------------
                                    750 ;state         Allocated with name '_default_layer_set_state_10000_326'
                                    751 ;------------------------------------------------------------
                                    752 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function default_layer_set
                                    755 ;	-----------------------------------------
      007D3E                        756 _default_layer_set:
      007D3E E5 82            [12]  757 	mov	a,dpl
      007D40 90 08 95         [24]  758 	mov	dptr,#_default_layer_set_state_10000_326
      007D43 12 5D 31         [24]  759 	lcall	_ak820_outline_0179
                                    760 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    761 ;	quantum/action_layer.c:81: }
      007D46 A1 26            [12]  762 	ajmp	_default_layer_state_set
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'default_layer_or'
                                    765 ;------------------------------------------------------------
                                    766 ;state         Allocated with name '_default_layer_or_state_10000_328'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function default_layer_or
                                    771 ;	-----------------------------------------
      007D48                        772 _default_layer_or:
      007D48 E5 82            [12]  773 	mov	a,dpl
      007D4A 90 08 96         [24]  774 	mov	dptr,#_default_layer_or_state_10000_328
      007D4D F0               [24]  775 	movx	@dptr,a
                                    776 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      007D4E E0               [24]  777 	movx	a,@dptr
      007D4F FF               [12]  778 	mov	r7,a
      007D50 90 0E 1A         [24]  779 	mov	dptr,#_default_layer_state
      007D53 12 81 00         [24]  780 	lcall	_ak820_outline_0151
                                    781 ;	quantum/action_layer.c:90: }
      007D56 A1 26            [12]  782 	ajmp	_default_layer_state_set
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'default_layer_and'
                                    785 ;------------------------------------------------------------
                                    786 ;state         Allocated with name '_default_layer_and_state_10000_330'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function default_layer_and
                                    791 ;	-----------------------------------------
      007D58                        792 _default_layer_and:
      007D58 E5 82            [12]  793 	mov	a,dpl
      007D5A 90 08 97         [24]  794 	mov	dptr,#_default_layer_and_state_10000_330
      007D5D F0               [24]  795 	movx	@dptr,a
                                    796 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      007D5E 90 0E 1A         [24]  797 	mov	dptr,#_default_layer_state
      007D61 E0               [24]  798 	movx	a,@dptr
      007D62 FF               [12]  799 	mov	r7,a
      007D63 90 08 97         [24]  800 	mov	dptr,#_default_layer_and_state_10000_330
      007D66 E0               [24]  801 	movx	a,@dptr
      007D67 52 07            [12]  802 	anl	ar7,a
      007D69 8F 82            [24]  803 	mov	dpl, r7
                                    804 ;	quantum/action_layer.c:97: }
      007D6B A1 26            [12]  805 	ajmp	_default_layer_state_set
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'default_layer_xor'
                                    808 ;------------------------------------------------------------
                                    809 ;state         Allocated with name '_default_layer_xor_state_10000_332'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function default_layer_xor
                                    814 ;	-----------------------------------------
      007D6D                        815 _default_layer_xor:
      007D6D E5 82            [12]  816 	mov	a,dpl
      007D6F 90 08 98         [24]  817 	mov	dptr,#_default_layer_xor_state_10000_332
      007D72 F0               [24]  818 	movx	@dptr,a
                                    819 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      007D73 E0               [24]  820 	movx	a,@dptr
      007D74 FF               [12]  821 	mov	r7,a
      007D75 90 0E 1A         [24]  822 	mov	dptr,#_default_layer_state
      007D78 E0               [24]  823 	movx	a,@dptr
      007D79 62 07            [12]  824 	xrl	ar7,a
      007D7B 8F 82            [24]  825 	mov	dpl, r7
                                    826 ;	quantum/action_layer.c:104: }
      007D7D A1 26            [12]  827 	ajmp	_default_layer_state_set
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    830 ;------------------------------------------------------------
                                    831 ;state         Allocated with name '_ak820_layer_refresh_state_10000_335'
                                    832 ;i             Allocated with name '_ak820_layer_refresh_i_20000_336'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function ak820_layer_refresh
                                    837 ;	-----------------------------------------
      007D7F                        838 _ak820_layer_refresh:
                                    839 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      007D7F 90 08 99         [24]  840 	mov	dptr,#_persistent_layers
      007D82 E0               [24]  841 	movx	a,@dptr
      007D83 90 08 A1         [24]  842 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007D86 F0               [24]  843 	movx	@dptr,a
                                    844 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      007D87 7F 00            [12]  845 	mov	r7,#0x00
      007D89                        846 00105$:
      007D89 BF 06 00         [24]  847 	cjne	r7,#0x06,00131$
      007D8C                        848 00131$:
      007D8C 50 23            [24]  849 	jnc	00103$
      007D8E EF               [12]  850 	mov	a,r7
      007D8F 24 9A            [12]  851 	add	a, #_layer_refs
      007D91 FD               [12]  852 	mov	r5,a
      007D92 E4               [12]  853 	clr	a
      007D93 34 08            [12]  854 	addc	a, #(_layer_refs >> 8)
      007D95 12 49 85         [24]  855 	lcall	_ak820_outline_0069
      007D98 60 14            [24]  856 	jz	00106$
      007D9A 8F F0            [24]  857 	mov	b,r7
      007D9C 05 F0            [12]  858 	inc	b
      007D9E 74 01            [12]  859 	mov	a,#0x01
      007DA0 80 02            [24]  860 	sjmp	00135$
      007DA2                        861 00134$:
      007DA2 25 E0            [12]  862 	add	a,acc
      007DA4                        863 00135$:
      007DA4 D5 F0 FB         [24]  864 	djnz	b,00134$
      007DA7 FE               [12]  865 	mov	r6,a
      007DA8 90 08 A1         [24]  866 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007DAB E0               [24]  867 	movx	a,@dptr
      007DAC 4E               [12]  868 	orl	a,r6
      007DAD F0               [24]  869 	movx	@dptr,a
      007DAE                        870 00106$:
      007DAE 0F               [12]  871 	inc	r7
      007DAF 80 D8            [24]  872 	sjmp	00105$
      007DB1                        873 00103$:
                                    874 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      007DB1 90 0E 1A         [24]  875 	mov	dptr,#_default_layer_state
      007DB4 E0               [24]  876 	movx	a,@dptr
      007DB5 FF               [12]  877 	mov	r7,a
      007DB6 90 08 A1         [24]  878 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007DB9 E0               [24]  879 	movx	a,@dptr
      007DBA FE               [12]  880 	mov	r6,a
      007DBB 42 07            [12]  881 	orl	ar7,a
      007DBD 8F 82            [24]  882 	mov	dpl, r7
      007DBF C0 06            [24]  883 	push	ar6
      007DC1 12 AA D0         [24]  884 	lcall	_ak820_tri_layer_derived
      007DC4 AF 82            [24]  885 	mov	r7, dpl
      007DC6 D0 06            [24]  886 	pop	ar6
      007DC8 90 08 A1         [24]  887 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007DCB EF               [12]  888 	mov	a,r7
      007DCC 4E               [12]  889 	orl	a,r6
      007DCD 12 5D 31         [24]  890 	lcall	_ak820_outline_0179
                                    891 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      007DD0 D1 6B            [24]  892 	acall	_layer_state_set_kb
      007DD2 E5 82            [12]  893 	mov	a, dpl
      007DD4 90 0E 1B         [24]  894 	mov	dptr,#_layer_state
      007DD7 F0               [24]  895 	movx	@dptr,a
                                    896 ;	quantum/action_layer.c:121: }
      007DD8 22               [24]  897 	ret
                                    898 ;------------------------------------------------------------
                                    899 ;Allocation info for local variables in function 'layer_hold_on'
                                    900 ;------------------------------------------------------------
                                    901 ;layer         Allocated with name '_layer_hold_on_layer_10000_338'
                                    902 ;------------------------------------------------------------
                                    903 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    904 ;	-----------------------------------------
                                    905 ;	 function layer_hold_on
                                    906 ;	-----------------------------------------
      007DD9                        907 _layer_hold_on:
      007DD9 E5 82            [12]  908 	mov	a,dpl
      007DDB 90 08 A2         [24]  909 	mov	dptr,#_layer_hold_on_layer_10000_338
      007DDE F0               [24]  910 	movx	@dptr,a
      007DDF E0               [24]  911 	movx	a,@dptr
      007DE0 FF               [12]  912 	mov	r7,a
      007DE1 BF 06 00         [24]  913 	cjne	r7,#0x06,00120$
      007DE4                        914 00120$:
      007DE4 50 29            [24]  915 	jnc	00104$
      007DE6 12 81 0C         [24]  916 	lcall	_ak820_outline_0185
      007DE9 74 01            [12]  917 	mov	a,#0x01
      007DEB F0               [24]  918 	movx	@dptr,a
      007DEC 90 08 A0         [24]  919 	mov	dptr,#_macro_layers
      007DEF C0 07            [24]  920 	push	ar7
      007DF1 12 81 15         [24]  921 	lcall	_ak820_macro_change
      007DF4 E5 82            [12]  922 	mov	a, dpl
      007DF6 D0 07            [24]  923 	pop	ar7
      007DF8 60 15            [24]  924 	jz	00104$
      007DFA EF               [12]  925 	mov	a,r7
      007DFB 24 9A            [12]  926 	add	a, #_layer_refs
      007DFD FF               [12]  927 	mov	r7,a
      007DFE E4               [12]  928 	clr	a
      007DFF 34 08            [12]  929 	addc	a, #(_layer_refs >> 8)
      007E01 FE               [12]  930 	mov	r6,a
      007E02 12 43 7B         [24]  931 	lcall	_ak820_outline_0166
      007E05 E0               [24]  932 	movx	a,@dptr
      007E06 FD               [12]  933 	mov	r5,a
      007E07 0D               [12]  934 	inc	r5
      007E08 12 43 7B         [24]  935 	lcall	_ak820_outline_0166
      007E0B ED               [12]  936 	mov	a,r5
      007E0C F0               [24]  937 	movx	@dptr,a
      007E0D A1 7F            [12]  938 	ajmp	_ak820_layer_refresh
      007E0F                        939 00104$:
      007E0F 22               [24]  940 	ret
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'layer_hold_off'
                                    943 ;------------------------------------------------------------
                                    944 ;layer         Allocated with name '_layer_hold_off_layer_10000_342'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    947 ;	-----------------------------------------
                                    948 ;	 function layer_hold_off
                                    949 ;	-----------------------------------------
      007E10                        950 _layer_hold_off:
      007E10 E5 82            [12]  951 	mov	a,dpl
      007E12 90 08 A3         [24]  952 	mov	dptr,#_layer_hold_off_layer_10000_342
      007E15 F0               [24]  953 	movx	@dptr,a
      007E16 E0               [24]  954 	movx	a,@dptr
      007E17 FF               [12]  955 	mov	r7,a
      007E18 BF 06 00         [24]  956 	cjne	r7,#0x06,00128$
      007E1B                        957 00128$:
      007E1B 50 2A            [24]  958 	jnc	00105$
      007E1D 12 81 0C         [24]  959 	lcall	_ak820_outline_0185
      007E20 E4               [12]  960 	clr	a
      007E21 F0               [24]  961 	movx	@dptr,a
      007E22 90 08 A0         [24]  962 	mov	dptr,#_macro_layers
      007E25 C0 07            [24]  963 	push	ar7
      007E27 12 81 15         [24]  964 	lcall	_ak820_macro_change
      007E2A E5 82            [12]  965 	mov	a, dpl
      007E2C D0 07            [24]  966 	pop	ar7
      007E2E 60 17            [24]  967 	jz	00105$
      007E30 EF               [12]  968 	mov	a,r7
      007E31 24 9A            [12]  969 	add	a, #_layer_refs
      007E33 FE               [12]  970 	mov	r6,a
      007E34 E4               [12]  971 	clr	a
      007E35 34 08            [12]  972 	addc	a, #(_layer_refs >> 8)
      007E37 FF               [12]  973 	mov	r7,a
      007E38 12 38 8A         [24]  974 	lcall	_ak820_outline_0124
      007E3B E0               [24]  975 	movx	a,@dptr
      007E3C FD               [12]  976 	mov	r5,a
      007E3D 60 08            [24]  977 	jz	00105$
      007E3F 1D               [12]  978 	dec	r5
      007E40 12 38 8A         [24]  979 	lcall	_ak820_outline_0124
      007E43 ED               [12]  980 	mov	a,r5
      007E44 F0               [24]  981 	movx	@dptr,a
      007E45 A1 7F            [12]  982 	ajmp	_ak820_layer_refresh
      007E47                        983 00105$:
      007E47 22               [24]  984 	ret
                                    985 ;------------------------------------------------------------
                                    986 ;Allocation info for local variables in function 'layer_hold_clear'
                                    987 ;------------------------------------------------------------
                                    988 ;i             Allocated with name '_layer_hold_clear_i_20000_348'
                                    989 ;------------------------------------------------------------
                                    990 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                    991 ;	-----------------------------------------
                                    992 ;	 function layer_hold_clear
                                    993 ;	-----------------------------------------
      007E48                        994 _layer_hold_clear:
      007E48 90 08 A0         [24]  995 	mov	dptr,#_macro_layers
      007E4B E4               [12]  996 	clr	a
      007E4C F0               [24]  997 	movx	@dptr,a
      007E4D FF               [12]  998 	mov	r7,a
      007E4E                        999 00103$:
      007E4E BF 06 00         [24] 1000 	cjne	r7,#0x06,00122$
      007E51                       1001 00122$:
      007E51 50 0D            [24] 1002 	jnc	00101$
      007E53 EF               [12] 1003 	mov	a,r7
      007E54 24 9A            [12] 1004 	add	a, #_layer_refs
      007E56 F5 82            [12] 1005 	mov	dpl,a
      007E58 E4               [12] 1006 	clr	a
      007E59 34 08            [12] 1007 	addc	a, #(_layer_refs >> 8)
      007E5B 12 81 06         [24] 1008 	lcall	_ak820_outline_0170
      007E5E 80 EE            [24] 1009 	sjmp	00103$
      007E60                       1010 00101$:
      007E60 A1 7F            [12] 1011 	ajmp	_ak820_layer_refresh
                                   1012 ;------------------------------------------------------------
                                   1013 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1014 ;------------------------------------------------------------
                                   1015 ;state         Allocated with name '_layer_state_set_user_state_10000_349'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function layer_state_set_user
                                   1020 ;	-----------------------------------------
      007E62                       1021 _layer_state_set_user:
      007E62 E5 82            [12] 1022 	mov	a,dpl
      007E64 90 08 A4         [24] 1023 	mov	dptr,#_layer_state_set_user_state_10000_349
      007E67 12 5D 31         [24] 1024 	lcall	_ak820_outline_0179
                                   1025 ;	quantum/action_layer.c:132: return state;
                                   1026 ;	quantum/action_layer.c:133: }
      007E6A 22               [24] 1027 	ret
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1030 ;------------------------------------------------------------
                                   1031 ;state         Allocated with name '_layer_state_set_kb_state_10000_351'
                                   1032 ;------------------------------------------------------------
                                   1033 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1034 ;	-----------------------------------------
                                   1035 ;	 function layer_state_set_kb
                                   1036 ;	-----------------------------------------
      007E6B                       1037 _layer_state_set_kb:
      007E6B E5 82            [12] 1038 	mov	a,dpl
      007E6D 90 08 A5         [24] 1039 	mov	dptr,#_layer_state_set_kb_state_10000_351
      007E70 12 5D 31         [24] 1040 	lcall	_ak820_outline_0179
                                   1041 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1042 ;	quantum/action_layer.c:141: }
      007E73 C1 62            [24] 1043 	ajmp	_layer_state_set_user
                                   1044 ;------------------------------------------------------------
                                   1045 ;Allocation info for local variables in function 'layer_state_set'
                                   1046 ;------------------------------------------------------------
                                   1047 ;state         Allocated with name '_layer_state_set_state_10000_353'
                                   1048 ;------------------------------------------------------------
                                   1049 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1050 ;	-----------------------------------------
                                   1051 ;	 function layer_state_set
                                   1052 ;	-----------------------------------------
      007E75                       1053 _layer_state_set:
      007E75 E5 82            [12] 1054 	mov	a,dpl
      007E77 90 08 A6         [24] 1055 	mov	dptr,#_layer_state_set_state_10000_353
      007E7A F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	quantum/action_layer.c:149: persistent_layers = state;
      007E7B E0               [24] 1058 	movx	a,@dptr
      007E7C 90 08 99         [24] 1059 	mov	dptr,#_persistent_layers
      007E7F F0               [24] 1060 	movx	@dptr,a
                                   1061 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1062 ;	quantum/action_layer.c:151: return;
                                   1063 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1064 ;	quantum/action_layer.c:165: }
      007E80 A1 7F            [12] 1065 	ajmp	_ak820_layer_refresh
                                   1066 ;------------------------------------------------------------
                                   1067 ;Allocation info for local variables in function 'layer_clear'
                                   1068 ;------------------------------------------------------------
                                   1069 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1070 ;	-----------------------------------------
                                   1071 ;	 function layer_clear
                                   1072 ;	-----------------------------------------
      007E82                       1073 _layer_clear:
                                   1074 ;	quantum/action_layer.c:172: layer_state_set(0);
      007E82 75 82 00         [24] 1075 	mov	dpl, #0x00
                                   1076 ;	quantum/action_layer.c:173: }
      007E85 C1 75            [24] 1077 	ajmp	_layer_state_set
                                   1078 ;------------------------------------------------------------
                                   1079 ;Allocation info for local variables in function 'layer_state_is'
                                   1080 ;------------------------------------------------------------
                                   1081 ;layer         Allocated with name '_layer_state_is_layer_10000_360'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function layer_move
                                   1086 ;	-----------------------------------------
      007E87                       1087 _layer_move:
      007E87 E5 82            [12] 1088 	mov	a,dpl
      007E89 90 08 A7         [24] 1089 	mov	dptr,#_layer_move_layer_10000_366
      007E8C F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      007E8D E0               [24] 1092 	movx	a,@dptr
      007E8E 12 7C C5         [24] 1093 	lcall	_ak820_outline_0065
      007E91 80 02            [24] 1094 	sjmp	00104$
      007E93                       1095 00103$:
      007E93 25 E0            [12] 1096 	add	a,acc
      007E95                       1097 00104$:
      007E95 D5 F0 FB         [24] 1098 	djnz	b,00103$
      007E98 F5 82            [12] 1099 	mov	dpl,a
                                   1100 ;	quantum/action_layer.c:200: }
      007E9A C1 75            [24] 1101 	ajmp	_layer_state_set
                                   1102 ;------------------------------------------------------------
                                   1103 ;Allocation info for local variables in function 'layer_on'
                                   1104 ;------------------------------------------------------------
                                   1105 ;layer         Allocated with name '_layer_on_layer_10000_368'
                                   1106 ;------------------------------------------------------------
                                   1107 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1108 ;	-----------------------------------------
                                   1109 ;	 function layer_on
                                   1110 ;	-----------------------------------------
      007E9C                       1111 _layer_on:
      007E9C E5 82            [12] 1112 	mov	a,dpl
      007E9E 90 08 A8         [24] 1113 	mov	dptr,#_layer_on_layer_10000_368
      007EA1 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      007EA2 E0               [24] 1116 	movx	a,@dptr
      007EA3 12 7C C5         [24] 1117 	lcall	_ak820_outline_0065
      007EA6 80 02            [24] 1118 	sjmp	00104$
      007EA8                       1119 00103$:
      007EA8 25 E0            [12] 1120 	add	a,acc
      007EAA                       1121 00104$:
      007EAA D5 F0 FB         [24] 1122 	djnz	b,00103$
      007EAD FF               [12] 1123 	mov	r7,a
      007EAE 90 08 99         [24] 1124 	mov	dptr,#_persistent_layers
      007EB1 12 81 00         [24] 1125 	lcall	_ak820_outline_0151
                                   1126 ;	quantum/action_layer.c:214: }
      007EB4 C1 75            [24] 1127 	ajmp	_layer_state_set
                                   1128 ;------------------------------------------------------------
                                   1129 ;Allocation info for local variables in function 'layer_off'
                                   1130 ;------------------------------------------------------------
                                   1131 ;layer         Allocated with name '_layer_off_layer_10000_370'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function layer_off
                                   1136 ;	-----------------------------------------
      007EB6                       1137 _layer_off:
      007EB6 E5 82            [12] 1138 	mov	a,dpl
      007EB8 90 08 A9         [24] 1139 	mov	dptr,#_layer_off_layer_10000_370
      007EBB F0               [24] 1140 	movx	@dptr,a
                                   1141 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      007EBC E0               [24] 1142 	movx	a,@dptr
      007EBD 12 7C C5         [24] 1143 	lcall	_ak820_outline_0065
      007EC0 80 02            [24] 1144 	sjmp	00104$
      007EC2                       1145 00103$:
      007EC2 25 E0            [12] 1146 	add	a,acc
      007EC4                       1147 00104$:
      007EC4 D5 F0 FB         [24] 1148 	djnz	b,00103$
      007EC7 F4               [12] 1149 	cpl	a
      007EC8 FF               [12] 1150 	mov	r7,a
      007EC9 90 08 99         [24] 1151 	mov	dptr,#_persistent_layers
      007ECC E0               [24] 1152 	movx	a,@dptr
      007ECD 52 07            [12] 1153 	anl	ar7,a
      007ECF 8F 82            [24] 1154 	mov	dpl, r7
                                   1155 ;	quantum/action_layer.c:228: }
      007ED1 C1 75            [24] 1156 	ajmp	_layer_state_set
                                   1157 ;------------------------------------------------------------
                                   1158 ;Allocation info for local variables in function 'layer_invert'
                                   1159 ;------------------------------------------------------------
                                   1160 ;layer         Allocated with name '_layer_invert_layer_10000_372'
                                   1161 ;------------------------------------------------------------
                                   1162 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1163 ;	-----------------------------------------
                                   1164 ;	 function layer_or
                                   1165 ;	-----------------------------------------
      007ED3                       1166 _layer_or:
      007ED3 E5 82            [12] 1167 	mov	a,dpl
      007ED5 90 08 AA         [24] 1168 	mov	dptr,#_layer_or_state_10000_374
      007ED8 F0               [24] 1169 	movx	@dptr,a
                                   1170 ;	quantum/action_layer.c:255: state);
      007ED9 E0               [24] 1171 	movx	a,@dptr
      007EDA FF               [12] 1172 	mov	r7,a
      007EDB 90 08 99         [24] 1173 	mov	dptr,#_persistent_layers
      007EDE 12 81 00         [24] 1174 	lcall	_ak820_outline_0151
                                   1175 ;	quantum/action_layer.c:256: }
      007EE1 C1 75            [24] 1176 	ajmp	_layer_state_set
                                   1177 ;------------------------------------------------------------
                                   1178 ;Allocation info for local variables in function 'layer_and'
                                   1179 ;------------------------------------------------------------
                                   1180 ;state         Allocated with name '_layer_and_state_10000_376'
                                   1181 ;------------------------------------------------------------
                                   1182 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1183 ;	-----------------------------------------
                                   1184 ;	 function layer_and
                                   1185 ;	-----------------------------------------
      007EE3                       1186 _layer_and:
      007EE3 E5 82            [12] 1187 	mov	a,dpl
      007EE5 90 08 AB         [24] 1188 	mov	dptr,#_layer_and_state_10000_376
      007EE8 F0               [24] 1189 	movx	@dptr,a
                                   1190 ;	quantum/action_layer.c:268: state);
      007EE9 90 08 99         [24] 1191 	mov	dptr,#_persistent_layers
      007EEC E0               [24] 1192 	movx	a,@dptr
      007EED FF               [12] 1193 	mov	r7,a
      007EEE 90 08 AB         [24] 1194 	mov	dptr,#_layer_and_state_10000_376
      007EF1 E0               [24] 1195 	movx	a,@dptr
      007EF2 52 07            [12] 1196 	anl	ar7,a
      007EF4 8F 82            [24] 1197 	mov	dpl, r7
                                   1198 ;	quantum/action_layer.c:269: }
      007EF6 C1 75            [24] 1199 	ajmp	_layer_state_set
                                   1200 ;------------------------------------------------------------
                                   1201 ;Allocation info for local variables in function 'layer_xor'
                                   1202 ;------------------------------------------------------------
                                   1203 ;state         Allocated with name '_layer_xor_state_10000_378'
                                   1204 ;------------------------------------------------------------
                                   1205 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1206 ;	-----------------------------------------
                                   1207 ;	 function layer_xor
                                   1208 ;	-----------------------------------------
      007EF8                       1209 _layer_xor:
      007EF8 E5 82            [12] 1210 	mov	a,dpl
      007EFA 90 08 AC         [24] 1211 	mov	dptr,#_layer_xor_state_10000_378
      007EFD F0               [24] 1212 	movx	@dptr,a
                                   1213 ;	quantum/action_layer.c:281: state);
      007EFE E0               [24] 1214 	movx	a,@dptr
      007EFF FF               [12] 1215 	mov	r7,a
      007F00 90 08 99         [24] 1216 	mov	dptr,#_persistent_layers
      007F03 E0               [24] 1217 	movx	a,@dptr
      007F04 62 07            [12] 1218 	xrl	ar7,a
      007F06 8F 82            [24] 1219 	mov	dpl, r7
                                   1220 ;	quantum/action_layer.c:282: }
      007F08 C1 75            [24] 1221 	ajmp	_layer_state_set
                                   1222 ;------------------------------------------------------------
                                   1223 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1224 ;------------------------------------------------------------
                                   1225 ;position      Allocated with name '_source_keycode_cache_slot_position_10000_380'
                                   1226 ;row           Allocated with name '_source_keycode_cache_slot_row_10000_381'
                                   1227 ;col           Allocated with name '_source_keycode_cache_slot_col_10000_381'
                                   1228 ;------------------------------------------------------------
                                   1229 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(uint16_t position) {
                                   1230 ;	-----------------------------------------
                                   1231 ;	 function source_keycode_cache_slot
                                   1232 ;	-----------------------------------------
      007F0A                       1233 _source_keycode_cache_slot:
      007F0A 12 38 79         [24] 1234 	lcall	_ak820_outline_0113
      007F0D 90 09 B1         [24] 1235 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007F10 12 38 7E         [24] 1236 	lcall	_ak820_outline_0114
                                   1237 ;	quantum/action_layer.c:325: uint8_t row = position >> 8, col = position;
      007F13 90 09 B1         [24] 1238 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007F16 E0               [24] 1239 	movx	a,@dptr
      007F17 FE               [12] 1240 	mov	r6,a
      007F18 A3               [24] 1241 	inc	dptr
      007F19 E0               [24] 1242 	movx	a,@dptr
      007F1A FD               [12] 1243 	mov	r5,a
                                   1244 ;	quantum/action_layer.c:326: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
      007F1B BD 10 00         [24] 1245 	cjne	r5,#0x10,00147$
      007F1E                       1246 00147$:
      007F1E 50 21            [24] 1247 	jnc	00102$
      007F20 BE 08 00         [24] 1248 	cjne	r6,#0x08,00149$
      007F23                       1249 00149$:
      007F23 50 1C            [24] 1250 	jnc	00102$
                                   1251 ;	quantum/action_layer.c:327: return &source_keycodes_cache[(uint8_t)(row * MATRIX_COLS + col)];
      007F25 8D 07            [24] 1252 	mov	ar7,r5
      007F27 EF               [12] 1253 	mov	a,r7
      007F28 12 38 CF         [24] 1254 	lcall	_ak820_outline_0199
      007F2B FF               [12] 1255 	mov	r7,a
      007F2C 8E 04            [24] 1256 	mov	ar4,r6
      007F2E EC               [12] 1257 	mov	a,r4
      007F2F 2F               [12] 1258 	add	a, r7
      007F30 75 F0 02         [24] 1259 	mov	b,#0x02
      007F33 A4               [48] 1260 	mul	ab
      007F34 24 AD            [12] 1261 	add	a, #_source_keycodes_cache
      007F36 FC               [12] 1262 	mov	r4,a
      007F37 74 08            [12] 1263 	mov	a,#(_source_keycodes_cache >> 8)
      007F39 35 F0            [12] 1264 	addc	a, b
      007F3B FF               [12] 1265 	mov	r7,a
      007F3C 8C 82            [24] 1266 	mov	dpl, r4
      007F3E 8F 83            [24] 1267 	mov	dph, r7
      007F40 22               [24] 1268 	ret
      007F41                       1269 00102$:
                                   1270 ;	quantum/action_layer.c:330: if ((row == KEYLOC_ENCODER_CW || row == KEYLOC_ENCODER_CCW) && col < NUM_ENCODERS) {
      007F41 BD FD 02         [24] 1271 	cjne	r5,#0xfd,00151$
      007F44 80 03            [24] 1272 	sjmp	00107$
      007F46                       1273 00151$:
      007F46 BD FC 2E         [24] 1274 	cjne	r5,#0xfc,00105$
      007F49                       1275 00107$:
      007F49 BE 01 00         [24] 1276 	cjne	r6,#0x01,00154$
      007F4C                       1277 00154$:
      007F4C 50 29            [24] 1278 	jnc	00105$
                                   1279 ;	quantum/action_layer.c:331: return &encoder_source_keycodes_cache[col + (row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      007F4E BD FC 04         [24] 1280 	cjne	r5,#0xfc,00110$
      007F51 7F 01            [12] 1281 	mov	r7,#0x01
      007F53 80 02            [24] 1282 	sjmp	00111$
      007F55                       1283 00110$:
      007F55 7F 00            [12] 1284 	mov	r7,#0x00
      007F57                       1285 00111$:
      007F57 C2 D5            [12] 1286 	clr	F0
      007F59 75 F0 02         [24] 1287 	mov	b,#0x02
      007F5C EF               [12] 1288 	mov	a,r7
      007F5D 30 E7 04         [24] 1289 	jnb	acc.7,00158$
      007F60 B2 D5            [12] 1290 	cpl	F0
      007F62 F4               [12] 1291 	cpl	a
      007F63 04               [12] 1292 	inc	a
      007F64                       1293 00158$:
      007F64 A4               [48] 1294 	mul	ab
      007F65 30 D5 03         [24] 1295 	jnb	F0,00159$
      007F68 12 75 7F         [24] 1296 	lcall	_ak820_outline_0138
      007F6B                       1297 00159$:
      007F6B 24 AD            [12] 1298 	add	a, #_encoder_source_keycodes_cache
      007F6D FE               [12] 1299 	mov	r6,a
      007F6E 74 09            [12] 1300 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      007F70 35 F0            [12] 1301 	addc	a, b
      007F72 FF               [12] 1302 	mov	r7,a
      007F73 12 38 8A         [24] 1303 	lcall	_ak820_outline_0124
      007F76 22               [24] 1304 	ret
      007F77                       1305 00105$:
                                   1306 ;	quantum/action_layer.c:334: return 0;
      007F77 90 00 00         [24] 1307 	mov	dptr,#0x0000
                                   1308 ;	quantum/action_layer.c:335: }
      007F7A 22               [24] 1309 	ret
                                   1310 ;------------------------------------------------------------
                                   1311 ;Allocation info for local variables in function 'ak820_cache_keycode'
                                   1312 ;------------------------------------------------------------
                                   1313 ;keycode       Allocated with name '_ak820_cache_keycode_PARM_2'
                                   1314 ;position      Allocated with name '_ak820_cache_keycode_position_10000_386'
                                   1315 ;slot          Allocated with name '_ak820_cache_keycode_slot_10000_387'
                                   1316 ;------------------------------------------------------------
                                   1317 ;	quantum/action_layer.c:339: bool ak820_cache_keycode(uint16_t position, uint16_t keycode) {
                                   1318 ;	-----------------------------------------
                                   1319 ;	 function ak820_cache_keycode
                                   1320 ;	-----------------------------------------
      007F7B                       1321 _ak820_cache_keycode:
      007F7B 12 38 79         [24] 1322 	lcall	_ak820_outline_0113
      007F7E 90 09 B5         [24] 1323 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007F81 12 38 7E         [24] 1324 	lcall	_ak820_outline_0114
                                   1325 ;	quantum/action_layer.c:340: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007F84 90 09 B5         [24] 1326 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007F87 12 37 F1         [24] 1327 	lcall	_ak820_outline_0005
      007F8A F1 0A            [24] 1328 	acall	_source_keycode_cache_slot
      007F8C 12 43 64         [24] 1329 	lcall	_ak820_outline_0132
                                   1330 ;	quantum/action_layer.c:341: if (!slot) return false;
      007F8F EE               [12] 1331 	mov	a,r6
      007F90 4F               [12] 1332 	orl	a,r7
      007F91 70 03            [24] 1333 	jnz	00102$
      007F93 F5 82            [12] 1334 	mov	dpl,a
      007F95 22               [24] 1335 	ret
      007F96                       1336 00102$:
                                   1337 ;	quantum/action_layer.c:342: *slot = keycode;
      007F96 90 09 B3         [24] 1338 	mov	dptr,#_ak820_cache_keycode_PARM_2
      007F99 12 38 55         [24] 1339 	lcall	_ak820_outline_0063
      007F9C 12 38 8A         [24] 1340 	lcall	_ak820_outline_0124
      007F9F 12 38 61         [24] 1341 	lcall	_ak820_outline_0078
                                   1342 ;	quantum/action_layer.c:343: return true;
      007FA2 75 82 01         [24] 1343 	mov	dpl, #0x01
                                   1344 ;	quantum/action_layer.c:344: }
      007FA5 22               [24] 1345 	ret
                                   1346 ;------------------------------------------------------------
                                   1347 ;Allocation info for local variables in function 'ak820_cache_layer'
                                   1348 ;------------------------------------------------------------
                                   1349 ;layer         Allocated with name '_ak820_cache_layer_PARM_2'
                                   1350 ;position      Allocated with name '_ak820_cache_layer_position_10000_389'
                                   1351 ;slot          Allocated with name '_ak820_cache_layer_slot_10000_390'
                                   1352 ;------------------------------------------------------------
                                   1353 ;	quantum/action_layer.c:346: void ak820_cache_layer(uint16_t position, uint8_t layer) {
                                   1354 ;	-----------------------------------------
                                   1355 ;	 function ak820_cache_layer
                                   1356 ;	-----------------------------------------
      007FA6                       1357 _ak820_cache_layer:
      007FA6 12 38 79         [24] 1358 	lcall	_ak820_outline_0113
      007FA9 90 09 B8         [24] 1359 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007FAC 12 38 7E         [24] 1360 	lcall	_ak820_outline_0114
                                   1361 ;	quantum/action_layer.c:347: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007FAF 90 09 B8         [24] 1362 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007FB2 12 37 F1         [24] 1363 	lcall	_ak820_outline_0005
      007FB5 C0 07            [24] 1364 	push	ar7
      007FB7 C0 06            [24] 1365 	push	ar6
      007FB9 12 7F 0A         [24] 1366 	lcall	_source_keycode_cache_slot
      007FBC 12 38 B0         [24] 1367 	lcall	_ak820_outline_0153
      007FBF D0 06            [24] 1368 	pop	ar6
      007FC1 D0 07            [24] 1369 	pop	ar7
                                   1370 ;	quantum/action_layer.c:348: if (!slot) return;
      007FC3 EC               [12] 1371 	mov	a,r4
      007FC4 4D               [12] 1372 	orl	a,r5
      007FC5 70 01            [24] 1373 	jnz	00102$
      007FC7 22               [24] 1374 	ret
      007FC8                       1375 00102$:
                                   1376 ;	quantum/action_layer.c:349: layer &= (1u << MAX_LAYER_BITS) - 1;
      007FC8 90 09 B7         [24] 1377 	mov	dptr,#_ak820_cache_layer_PARM_2
      007FCB E0               [24] 1378 	movx	a,@dptr
      007FCC 53 E0 07         [24] 1379 	anl	acc,#0x07
      007FCF F0               [24] 1380 	movx	@dptr,a
                                   1381 ;	quantum/action_layer.c:361: *slot = ak820_keycode_at(layer, position);
      007FD0 90 09 B7         [24] 1382 	mov	dptr,#_ak820_cache_layer_PARM_2
      007FD3 E0               [24] 1383 	movx	a,@dptr
      007FD4 FB               [12] 1384 	mov	r3,a
      007FD5 90 0B E8         [24] 1385 	mov	dptr,#_ak820_keycode_at_PARM_2
      007FD8 12 4E D3         [24] 1386 	lcall	_ak820_outline_0062
      007FDB 8B 82            [24] 1387 	mov	dpl, r3
      007FDD C0 05            [24] 1388 	push	ar5
      007FDF C0 04            [24] 1389 	push	ar4
      007FE1 12 9B 47         [24] 1390 	lcall	_ak820_keycode_at
      007FE4 12 43 64         [24] 1391 	lcall	_ak820_outline_0132
      007FE7 D0 04            [24] 1392 	pop	ar4
      007FE9 D0 05            [24] 1393 	pop	ar5
      007FEB 12 38 A0         [24] 1394 	lcall	_ak820_outline_0133
      007FEE 12 4E D3         [24] 1395 	lcall	_ak820_outline_0062
                                   1396 ;	quantum/action_layer.c:362: }
      007FF1 22               [24] 1397 	ret
                                   1398 ;------------------------------------------------------------
                                   1399 ;Allocation info for local variables in function 'ak820_cached_key'
                                   1400 ;------------------------------------------------------------
                                   1401 ;position      Allocated with name '_ak820_cached_key_position_10000_392'
                                   1402 ;slot          Allocated with name '_ak820_cached_key_slot_10001_396'
                                   1403 ;------------------------------------------------------------
                                   1404 ;	quantum/action_layer.c:383: uint16_t ak820_cached_key(uint16_t position) {
                                   1405 ;	-----------------------------------------
                                   1406 ;	 function ak820_cached_key
                                   1407 ;	-----------------------------------------
      007FF2                       1408 _ak820_cached_key:
      007FF2 12 38 79         [24] 1409 	lcall	_ak820_outline_0113
      007FF5 90 09 BA         [24] 1410 	mov	dptr,#_ak820_cached_key_position_10000_392
      007FF8 12 38 7E         [24] 1411 	lcall	_ak820_outline_0114
                                   1412 ;	quantum/action_layer.c:386: if (vial_unlock_in_progress) return KC_NO;
      007FFB 90 0E 7A         [24] 1413 	mov	dptr,#_vial_unlock_in_progress
      007FFE E0               [24] 1414 	movx	a,@dptr
      007FFF 60 04            [24] 1415 	jz	00102$
      008001 90 00 00         [24] 1416 	mov	dptr,#0x0000
      008004 22               [24] 1417 	ret
      008005                       1418 00102$:
                                   1419 ;	quantum/action_layer.c:387: if (position == (((uint16_t)VIAL_MATRIX_MAGIC << 8) | VIAL_MATRIX_MAGIC)) return g_vial_magic_keycode_override;
      008005 90 09 BA         [24] 1420 	mov	dptr,#_ak820_cached_key_position_10000_392
      008008 12 38 3E         [24] 1421 	lcall	_ak820_outline_0055
      00800B BE F0 0D         [24] 1422 	cjne	r6,#0xf0,00104$
      00800E BF F0 0A         [24] 1423 	cjne	r7,#0xf0,00104$
      008011 90 0C C9         [24] 1424 	mov	dptr,#_g_vial_magic_keycode_override
      008014 12 38 55         [24] 1425 	lcall	_ak820_outline_0063
      008017 12 38 A0         [24] 1426 	lcall	_ak820_outline_0133
      00801A 22               [24] 1427 	ret
      00801B                       1428 00104$:
                                   1429 ;	quantum/action_layer.c:389: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      00801B 12 38 8A         [24] 1430 	lcall	_ak820_outline_0124
      00801E 12 7F 0A         [24] 1431 	lcall	_source_keycode_cache_slot
      008021 12 43 64         [24] 1432 	lcall	_ak820_outline_0132
                                   1433 ;	quantum/action_layer.c:390: return slot ? *slot : KC_NO;
      008024 EE               [12] 1434 	mov	a,r6
      008025 4F               [12] 1435 	orl	a,r7
      008026 60 08            [24] 1436 	jz	00107$
      008028 12 38 8A         [24] 1437 	lcall	_ak820_outline_0124
      00802B 12 38 3E         [24] 1438 	lcall	_ak820_outline_0055
      00802E 80 04            [24] 1439 	sjmp	00108$
      008030                       1440 00107$:
      008030 7E 00            [12] 1441 	mov	r6,#0x00
      008032 7F 00            [12] 1442 	mov	r7,#0x00
      008034                       1443 00108$:
      008034 12 38 8A         [24] 1444 	lcall	_ak820_outline_0124
                                   1445 ;	quantum/action_layer.c:391: }
      008037 22               [24] 1446 	ret
                                   1447 ;------------------------------------------------------------
                                   1448 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1449 ;------------------------------------------------------------
                                   1450 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1451 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_397'
                                   1452 ;------------------------------------------------------------
                                   1453 ;	quantum/action_layer.c:394: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1454 ;	-----------------------------------------
                                   1455 ;	 function ak820_resolve_key
                                   1456 ;	-----------------------------------------
      008038                       1457 _ak820_resolve_key:
      008038 12 38 79         [24] 1458 	lcall	_ak820_outline_0113
      00803B 90 09 BD         [24] 1459 	mov	dptr,#_ak820_resolve_key_position_10000_403
      00803E 12 38 7E         [24] 1460 	lcall	_ak820_outline_0114
                                   1461 ;	quantum/action_layer.c:493: if (disable_action_cache) {
      008041 90 0E 19         [24] 1462 	mov	dptr,#_disable_action_cache
      008044 E0               [24] 1463 	movx	a,@dptr
      008045 60 1D            [24] 1464 	jz	00102$
                                   1465 ;	quantum/action_layer.c:494: return ak820_keycode_at(ak820_layer_for_key(position), position);
      008047 90 09 BD         [24] 1466 	mov	dptr,#_ak820_resolve_key_position_10000_403
      00804A 12 37 F1         [24] 1467 	lcall	_ak820_outline_0005
      00804D C0 07            [24] 1468 	push	ar7
      00804F C0 06            [24] 1469 	push	ar6
      008051 11 8E            [12] 1470 	acall	_ak820_layer_for_key
      008053 AD 82            [24] 1471 	mov	r5, dpl
      008055 D0 06            [24] 1472 	pop	ar6
      008057 D0 07            [24] 1473 	pop	ar7
      008059 90 0B E8         [24] 1474 	mov	dptr,#_ak820_keycode_at_PARM_2
      00805C 12 4E D3         [24] 1475 	lcall	_ak820_outline_0062
      00805F 8D 82            [24] 1476 	mov	dpl, r5
      008061 02 9B 47         [24] 1477 	ljmp	_ak820_keycode_at
      008064                       1478 00102$:
                                   1479 ;	quantum/action_layer.c:496: if (cache_press) ak820_cache_layer(position, ak820_layer_for_key(position));
      008064 90 09 BC         [24] 1480 	mov	dptr,#_ak820_resolve_key_PARM_2
      008067 E0               [24] 1481 	movx	a,@dptr
      008068 60 1B            [24] 1482 	jz	00104$
      00806A 90 09 BD         [24] 1483 	mov	dptr,#_ak820_resolve_key_position_10000_403
      00806D 12 37 F1         [24] 1484 	lcall	_ak820_outline_0005
      008070 C0 07            [24] 1485 	push	ar7
      008072 C0 06            [24] 1486 	push	ar6
      008074 11 8E            [12] 1487 	acall	_ak820_layer_for_key
      008076 E5 82            [12] 1488 	mov	a, dpl
      008078 D0 06            [24] 1489 	pop	ar6
      00807A D0 07            [24] 1490 	pop	ar7
      00807C 90 09 B7         [24] 1491 	mov	dptr,#_ak820_cache_layer_PARM_2
      00807F 12 43 46         [24] 1492 	lcall	_ak820_outline_0077
      008082 12 7F A6         [24] 1493 	lcall	_ak820_cache_layer
      008085                       1494 00104$:
                                   1495 ;	quantum/action_layer.c:497: return ak820_cached_key(position);
      008085 90 09 BD         [24] 1496 	mov	dptr,#_ak820_resolve_key_position_10000_403
      008088 12 37 F1         [24] 1497 	lcall	_ak820_outline_0005
                                   1498 ;	quantum/action_layer.c:498: }
      00808B 02 7F F2         [24] 1499 	ljmp	_ak820_cached_key
                                   1500 ;------------------------------------------------------------
                                   1501 ;Allocation info for local variables in function 'store_or_get_action'
                                   1502 ;------------------------------------------------------------
                                   1503 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1504 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_408'
                                   1505 ;------------------------------------------------------------
                                   1506 ;	quantum/action_layer.c:499: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1507 ;	-----------------------------------------
                                   1508 ;	 function ak820_layer_for_key
                                   1509 ;	-----------------------------------------
      00808E                       1510 _ak820_layer_for_key:
      00808E 12 38 79         [24] 1511 	lcall	_ak820_outline_0113
      008091 90 09 BF         [24] 1512 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      008094 12 38 7E         [24] 1513 	lcall	_ak820_outline_0114
                                   1514 ;	quantum/action_layer.c:539: layer_state_t layers = layer_state | default_layer_state;
      008097 90 0E 1A         [24] 1515 	mov	dptr,#_default_layer_state
      00809A E0               [24] 1516 	movx	a,@dptr
      00809B FF               [12] 1517 	mov	r7,a
      00809C 90 0E 1B         [24] 1518 	mov	dptr,#_layer_state
      00809F E0               [24] 1519 	movx	a,@dptr
      0080A0 90 09 C1         [24] 1520 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      0080A3 4F               [12] 1521 	orl	a,r7
      0080A4 F0               [24] 1522 	movx	@dptr,a
                                   1523 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      0080A5 90 09 BF         [24] 1524 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      0080A8 12 38 3E         [24] 1525 	lcall	_ak820_outline_0055
      0080AB 7D 05            [12] 1526 	mov	r5,#0x05
      0080AD                       1527 00107$:
      0080AD ED               [12] 1528 	mov	a,r5
      0080AE 20 E7 4B         [24] 1529 	jb	acc.7,00105$
                                   1530 ;	quantum/action_layer.c:542: if (layers & ((layer_state_t)1 << i)) {
      0080B1 8D F0            [24] 1531 	mov	b,r5
      0080B3 05 F0            [12] 1532 	inc	b
      0080B5 7B 01            [12] 1533 	mov	r3,#0x01
      0080B7 7C 00            [12] 1534 	mov	r4,#0x00
      0080B9 80 06            [24] 1535 	sjmp	00141$
      0080BB                       1536 00140$:
      0080BB EB               [12] 1537 	mov	a,r3
      0080BC 2B               [12] 1538 	add	a,r3
      0080BD FB               [12] 1539 	mov	r3,a
      0080BE EC               [12] 1540 	mov	a,r4
      0080BF 33               [12] 1541 	rlc	a
      0080C0 FC               [12] 1542 	mov	r4,a
      0080C1                       1543 00141$:
      0080C1 D5 F0 F7         [24] 1544 	djnz	b,00140$
      0080C4 90 09 C1         [24] 1545 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      0080C7 E0               [24] 1546 	movx	a,@dptr
      0080C8 7A 00            [12] 1547 	mov	r2,#0x00
      0080CA 52 03            [12] 1548 	anl	ar3,a
      0080CC EA               [12] 1549 	mov	a,r2
      0080CD 52 04            [12] 1550 	anl	ar4,a
      0080CF EB               [12] 1551 	mov	a,r3
      0080D0 4C               [12] 1552 	orl	a,r4
      0080D1 60 26            [24] 1553 	jz	00108$
                                   1554 ;	quantum/action_layer.c:546: if (ak820_keycode_at(i, position) != KC_TRANSPARENT) {
      0080D3 90 0B E8         [24] 1555 	mov	dptr,#_ak820_keycode_at_PARM_2
      0080D6 12 4E D3         [24] 1556 	lcall	_ak820_outline_0062
      0080D9 8D 82            [24] 1557 	mov	dpl, r5
      0080DB C0 07            [24] 1558 	push	ar7
      0080DD C0 06            [24] 1559 	push	ar6
      0080DF C0 05            [24] 1560 	push	ar5
      0080E1 12 9B 47         [24] 1561 	lcall	_ak820_keycode_at
      0080E4 AB 82            [24] 1562 	mov	r3, dpl
      0080E6 AC 83            [24] 1563 	mov	r4, dph
      0080E8 D0 05            [24] 1564 	pop	ar5
      0080EA D0 06            [24] 1565 	pop	ar6
      0080EC D0 07            [24] 1566 	pop	ar7
      0080EE BB 01 05         [24] 1567 	cjne	r3,#0x01,00143$
      0080F1 BC 00 02         [24] 1568 	cjne	r4,#0x00,00143$
      0080F4 80 03            [24] 1569 	sjmp	00108$
      0080F6                       1570 00143$:
                                   1571 ;	quantum/action_layer.c:555: return i;
      0080F6 8D 82            [24] 1572 	mov	dpl, r5
      0080F8 22               [24] 1573 	ret
      0080F9                       1574 00108$:
                                   1575 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      0080F9 1D               [12] 1576 	dec	r5
      0080FA 80 B1            [24] 1577 	sjmp	00107$
      0080FC                       1578 00105$:
                                   1579 ;	quantum/action_layer.c:560: return 0;
      0080FC 75 82 00         [24] 1580 	mov	dpl, #0x00
                                   1581 ;	quantum/action_layer.c:565: }
      0080FF 22               [24] 1582 	ret
                                   1583 ;------------------------------------------------------------
                                   1584 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1585 ;------------------------------------------------------------
                                   1586 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1587 ;------------------------------------------------------------
                                   1588 ;	quantum/action_layer.c:567: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1589 ;	-----------------------------------------
                                   1590 	.area CSEG    (CODE)
                                   1591 	.area CONST   (CODE)
                                   1592 	.area XINIT   (CODE)
      00C82F                       1593 __xinit__default_layer_state:
      00C82F 00                    1594 	.db #0x00	; 0
      00C830                       1595 __xinit__layer_state:
      00C830 00                    1596 	.db #0x00	; 0
                                   1597 	.area CABS    (ABS,CODE)
                                   1598 
                                   1599 ; Experimental exact instruction outlining.
                                   1600 	.globl _ak820_outline_0005
                                   1601 	.globl _ak820_outline_0055
                                   1602 	.globl _ak820_outline_0062
                                   1603 	.globl _ak820_outline_0063
                                   1604 	.globl _ak820_outline_0065
                                   1605 	.globl _ak820_outline_0069
                                   1606 	.globl _ak820_outline_0077
                                   1607 	.globl _ak820_outline_0078
                                   1608 	.globl _ak820_outline_0113
                                   1609 	.globl _ak820_outline_0114
                                   1610 	.globl _ak820_outline_0124
                                   1611 	.globl _ak820_outline_0132
                                   1612 	.globl _ak820_outline_0133
                                   1613 	.globl _ak820_outline_0138
                                   1614 	.globl _ak820_outline_0151
                                   1615 	.globl _ak820_outline_0153
                                   1616 	.globl _ak820_outline_0166
                                   1617 	.globl _ak820_outline_0170
                                   1618 	.globl _ak820_outline_0179
                                   1619 	.globl _ak820_outline_0185
                                   1620 	.globl _ak820_outline_0199
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0151
      008100                       1624 _ak820_outline_0151:
      008100 E0               [24] 1625 	movx	a,@dptr
      008101 42 07            [12] 1626 	orl	ar7,a
      008103 8F 82            [24] 1627 	mov	dpl,r7
      008105 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0170
      008106                       1632 _ak820_outline_0170:
      008106 F5 83            [12] 1633 	mov	dph,a
      008108 E4               [12] 1634 	clr	a
      008109 F0               [24] 1635 	movx	@dptr,a
      00810A 0F               [12] 1636 	inc	r7
      00810B 22               [24] 1637 	ret
                                   1638 
                                   1639 	.area CSEG (CODE)
                                   1640 ; function ak820_outline_0185
      00810C                       1641 _ak820_outline_0185:
      00810C 90 09 D8         [24] 1642 	mov	dptr,#_ak820_macro_change_PARM_2
      00810F EF               [12] 1643 	mov	a,r7
      008110 F0               [24] 1644 	movx	@dptr,a
      008111 90 09 D9         [24] 1645 	mov	dptr,#_ak820_macro_change_PARM_3
      008114 22               [24] 1646 	ret
