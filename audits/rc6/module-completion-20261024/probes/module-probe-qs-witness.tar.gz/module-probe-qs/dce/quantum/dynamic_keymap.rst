                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_settings_reset
                                     14 	.globl _ak820_eeprom_write_block_xdata
                                     15 	.globl _ak820_eeprom_read_block_xdata
                                     16 	.globl _ak820_nvm_flush
                                     17 	.globl _ak820_nvm_ok
                                     18 	.globl _ak820_macro_reset
                                     19 	.globl _ak820_macro_write
                                     20 	.globl _ak820_macro_length
                                     21 	.globl _ak820_macro_ready
                                     22 	.globl _send_char
                                     23 	.globl _keycode_at_encodermap_location_raw
                                     24 	.globl _keycode_at_keymap_location_raw
                                     25 	.globl _vial_keycode_tap
                                     26 	.globl _vial_keycode_up
                                     27 	.globl _vial_keycode_down
                                     28 	.globl _clear_keyboard
                                     29 	.globl _tap_code
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _mDelaymS
                                     33 	.globl ___memcpy
                                     34 	.globl _memset
                                     35 	.globl _eeprom_update_byte
                                     36 	.globl _eeprom_read_byte
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    284 	.globl _keycode_at_encodermap_location_PARM_3
                                    285 	.globl _keycode_at_encodermap_location_PARM_2
                                    286 	.globl _keycode_at_keymap_location_PARM_3
                                    287 	.globl _keycode_at_keymap_location_PARM_2
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    292 	.globl _dynamic_keymap_set_combo_PARM_2
                                    293 	.globl _dynamic_keymap_get_combo_PARM_2
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    296 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    298 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    299 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    302 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    304 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    306 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    307 	.globl _dynamic_keymap_get_layer_count
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address
                                    309 	.globl _dynamic_keymap_get_keycode
                                    310 	.globl _dynamic_keymap_set_keycode
                                    311 	.globl _dynamic_keymap_get_encoder
                                    312 	.globl _dynamic_keymap_set_encoder
                                    313 	.globl _dynamic_keymap_get_combo
                                    314 	.globl _dynamic_keymap_set_combo
                                    315 	.globl _dynamic_keymap_reset
                                    316 	.globl _dynamic_keymap_get_buffer
                                    317 	.globl _dynamic_keymap_set_buffer
                                    318 	.globl _keycode_at_keymap_location
                                    319 	.globl _keycode_at_encodermap_location
                                    320 	.globl _dynamic_keymap_macro_get_count
                                    321 	.globl _dynamic_keymap_macro_get_buffer_size
                                    322 	.globl _dynamic_keymap_macro_get_buffer
                                    323 	.globl _dynamic_keymap_macro_set_buffer
                                    324 	.globl _dynamic_keymap_macro_reset
                                    325 	.globl _dynamic_keymap_macro_send
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000031                        588 _dynamic_keymap_set_encoder_sloc0_1_0:
      000031                        589 	.ds 2
      000033                        590 _dynamic_keymap_get_combo_sloc0_1_0:
      000033                        591 	.ds 1
      000034                        592 _ak820_dynamic_read_buffer_sloc0_1_0:
      000034                        593 	.ds 1
      000035                        594 _dynamic_keymap_set_buffer_sloc0_1_0:
      000035                        595 	.ds 2
      000037                        596 _dynamic_keymap_set_buffer_sloc1_1_0:
      000037                        597 	.ds 2
      000039                        598 _dynamic_keymap_set_buffer_sloc2_1_0:
      000039                        599 	.ds 1
      00003A                        600 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      00003A                        601 	.ds 2
                                    602 ;--------------------------------------------------------
                                    603 ; overlayable items in internal ram
                                    604 ;--------------------------------------------------------
                                    605 ;--------------------------------------------------------
                                    606 ; indirectly addressable internal ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area ISEG    (DATA)
                                    609 ;--------------------------------------------------------
                                    610 ; absolute internal ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area IABS    (ABS,DATA)
                                    613 	.area IABS    (ABS,DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; bit data
                                    616 ;--------------------------------------------------------
                                    617 	.area BSEG    (BIT)
      000025                        618 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        619 	.ds 1
                                    620 ;--------------------------------------------------------
                                    621 ; paged external ram data
                                    622 ;--------------------------------------------------------
                                    623 	.area PSEG    (PAG,XDATA)
                                    624 ;--------------------------------------------------------
                                    625 ; uninitialized external ram data
                                    626 ;--------------------------------------------------------
                                    627 	.area XSEG    (XDATA)
      000B28                        628 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B28                        629 	.ds 1
      000B29                        630 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B29                        631 	.ds 1
      000B2A                        632 _dynamic_keymap_key_to_eeprom_address_layer_10000_375:
      000B2A                        633 	.ds 1
      000B2B                        634 _dynamic_keymap_get_keycode_PARM_2:
      000B2B                        635 	.ds 1
      000B2C                        636 _dynamic_keymap_get_keycode_PARM_3:
      000B2C                        637 	.ds 1
      000B2D                        638 _dynamic_keymap_get_keycode_layer_10000_377:
      000B2D                        639 	.ds 1
      000B2E                        640 _dynamic_keymap_set_keycode_PARM_2:
      000B2E                        641 	.ds 1
      000B2F                        642 _dynamic_keymap_set_keycode_PARM_3:
      000B2F                        643 	.ds 1
      000B30                        644 _dynamic_keymap_set_keycode_PARM_4:
      000B30                        645 	.ds 2
      000B32                        646 _dynamic_keymap_set_keycode_layer_10000_381:
      000B32                        647 	.ds 1
      000B33                        648 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B33                        649 	.ds 1
      000B34                        650 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_385:
      000B34                        651 	.ds 1
      000B35                        652 _dynamic_keymap_get_encoder_PARM_2:
      000B35                        653 	.ds 1
      000B36                        654 _dynamic_keymap_get_encoder_PARM_3:
      000B36                        655 	.ds 1
      000B37                        656 _dynamic_keymap_get_encoder_layer_10000_387:
      000B37                        657 	.ds 1
      000B38                        658 _dynamic_keymap_set_encoder_PARM_2:
      000B38                        659 	.ds 1
      000B39                        660 _dynamic_keymap_set_encoder_PARM_3:
      000B39                        661 	.ds 1
      000B3A                        662 _dynamic_keymap_set_encoder_PARM_4:
      000B3A                        663 	.ds 2
      000B3C                        664 _dynamic_keymap_set_encoder_layer_10000_391:
      000B3C                        665 	.ds 1
      000B3D                        666 _dynamic_keymap_get_combo_PARM_2:
      000B3D                        667 	.ds 3
      000B40                        668 _dynamic_keymap_get_combo_index_10000_395:
      000B40                        669 	.ds 1
      000B41                        670 _dynamic_keymap_set_combo_PARM_2:
      000B41                        671 	.ds 3
      000B44                        672 _dynamic_keymap_set_combo_index_10000_401:
      000B44                        673 	.ds 1
      000B45                        674 _dynamic_keymap_set_combo_stored_10002_406:
      000B45                        675 	.ds 10
      000B4F                        676 _dynamic_keymap_reset_vial_unlocked_prev_10000_409:
      000B4F                        677 	.ds 1
      000B50                        678 _dynamic_keymap_reset_combo_10001_418:
      000B50                        679 	.ds 10
      000B5A                        680 _ak820_dynamic_read_buffer_PARM_2:
      000B5A                        681 	.ds 2
      000B5C                        682 _ak820_dynamic_read_buffer_PARM_3:
      000B5C                        683 	.ds 2
      000B5E                        684 _ak820_dynamic_read_buffer_PARM_4:
      000B5E                        685 	.ds 2
      000B60                        686 _ak820_dynamic_read_buffer_PARM_5:
      000B60                        687 	.ds 3
      000B63                        688 _ak820_dynamic_read_buffer_base_10000_420:
      000B63                        689 	.ds 2
      000B65                        690 _ak820_dynamic_read_buffer_available_10000_421:
      000B65                        691 	.ds 1
      000B66                        692 _dynamic_keymap_get_buffer_PARM_2:
      000B66                        693 	.ds 2
      000B68                        694 _dynamic_keymap_get_buffer_PARM_3:
      000B68                        695 	.ds 3
      000B6B                        696 _dynamic_keymap_get_buffer_offset_10000_427:
      000B6B                        697 	.ds 2
      000B6D                        698 _dynamic_keymap_set_buffer_PARM_2:
      000B6D                        699 	.ds 2
      000B6F                        700 _dynamic_keymap_set_buffer_PARM_3:
      000B6F                        701 	.ds 3
      000B72                        702 _dynamic_keymap_set_buffer_offset_10000_429:
      000B72                        703 	.ds 2
      000B74                        704 _dynamic_keymap_set_buffer_chk_offset_30001_436:
      000B74                        705 	.ds 1
      000B75                        706 _dynamic_keymap_set_buffer_chk_sz_30001_436:
      000B75                        707 	.ds 1
      000B76                        708 _dynamic_keymap_set_buffer_i_40001_443:
      000B76                        709 	.ds 1
      000B77                        710 _keycode_at_keymap_location_PARM_2:
      000B77                        711 	.ds 1
      000B78                        712 _keycode_at_keymap_location_PARM_3:
      000B78                        713 	.ds 1
      000B79                        714 _keycode_at_keymap_location_layer_num_10000_447:
      000B79                        715 	.ds 1
      000B7A                        716 _keycode_at_encodermap_location_PARM_2:
      000B7A                        717 	.ds 1
      000B7B                        718 _keycode_at_encodermap_location_PARM_3:
      000B7B                        719 	.ds 1
      000B7C                        720 _keycode_at_encodermap_location_layer_num_10000_451:
      000B7C                        721 	.ds 1
      000B7D                        722 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B7D                        723 	.ds 2
      000B7F                        724 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B7F                        725 	.ds 3
      000B82                        726 _dynamic_keymap_macro_get_buffer_offset_10000_459:
      000B82                        727 	.ds 2
      000B84                        728 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B84                        729 	.ds 2
      000B86                        730 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B86                        731 	.ds 3
      000B89                        732 _dynamic_keymap_macro_set_buffer_offset_10000_461:
      000B89                        733 	.ds 2
      000B8B                        734 _decode_keycode_kc_10000_465:
      000B8B                        735 	.ds 2
      000B8D                        736 _dynamic_keymap_macro_send_id_10000_468:
      000B8D                        737 	.ds 1
      000B8E                        738 _dynamic_keymap_macro_send_sending_10000_469:
      000B8E                        739 	.ds 1
      000B8F                        740 _dynamic_keymap_macro_send_p_10001_474:
      000B8F                        741 	.ds 2
      000B91                        742 _dynamic_keymap_macro_send_data_10003_481:
      000B91                        743 	.ds 4
                                    744 ;--------------------------------------------------------
                                    745 ; absolute external ram data
                                    746 ;--------------------------------------------------------
                                    747 	.area XABS    (ABS,XDATA)
                                    748 ;--------------------------------------------------------
                                    749 ; initialized external ram data
                                    750 ;--------------------------------------------------------
                                    751 	.area XISEG   (XDATA)
                                    752 	.area HOME    (CODE)
                                    753 	.area GSINIT0 (CODE)
                                    754 	.area GSINIT1 (CODE)
                                    755 	.area GSINIT2 (CODE)
                                    756 	.area GSINIT3 (CODE)
                                    757 	.area GSINIT4 (CODE)
                                    758 	.area GSINIT5 (CODE)
                                    759 	.area GSINIT  (CODE)
                                    760 	.area GSFINAL (CODE)
                                    761 	.area CSEG    (CODE)
                                    762 ;--------------------------------------------------------
                                    763 ; global & static initialisations
                                    764 ;--------------------------------------------------------
                                    765 	.area HOME    (CODE)
                                    766 	.area GSINIT  (CODE)
                                    767 	.area GSFINAL (CODE)
                                    768 	.area GSINIT  (CODE)
                                    769 ;--------------------------------------------------------
                                    770 ; Home
                                    771 ;--------------------------------------------------------
                                    772 	.area HOME    (CODE)
                                    773 	.area HOME    (CODE)
                                    774 ;--------------------------------------------------------
                                    775 ; code
                                    776 ;--------------------------------------------------------
                                    777 	.area CSEG    (CODE)
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    780 ;------------------------------------------------------------
                                    781 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_241'
                                    782 ;------------------------------------------------------------
                                    783 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    784 ;	-----------------------------------------
                           000007   785 	ar7 = 0x07
                           000006   786 	ar6 = 0x06
                           000005   787 	ar5 = 0x05
                           000004   788 	ar4 = 0x04
                           000003   789 	ar3 = 0x03
                           000002   790 	ar2 = 0x02
                           000001   791 	ar1 = 0x01
                           000000   792 	ar0 = 0x00
                                    793 ;	 function dynamic_keymap_get_layer_count
                                    794 ;	-----------------------------------------
      008925                        795 _dynamic_keymap_get_layer_count:
                                    796 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008925 75 82 06         [24]  797 	mov	dpl, #0x06
                                    798 ;	quantum/dynamic_keymap.c:201: }
      008928 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    802 ;------------------------------------------------------------
                                    803 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    804 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    805 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_375'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function dynamic_keymap_key_to_eeprom_address
                                    810 ;	-----------------------------------------
      008929                        811 _dynamic_keymap_key_to_eeprom_address:
      008929 E5 82            [12]  812 	mov	a,dpl
      00892B 90 0B 2A         [24]  813 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_375
      00892E F0               [24]  814 	movx	@dptr,a
                                    815 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00892F E0               [24]  816 	movx	a,@dptr
      008930 FF               [12]  817 	mov	r7,a
      008931 7E 00            [12]  818 	mov	r6,#0x00
      008933 74 40            [12]  819 	mov	a,#0x40
      008935 12 43 69         [24]  820 	lcall	_ak820_outline_0144
      008938 7D 00            [12]  821 	mov	r5,#0x00
      00893A 90 0B 28         [24]  822 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00893D E0               [24]  823 	movx	a,@dptr
      00893E 75 F0 10         [24]  824 	mov	b,#0x10
      008941 A4               [48]  825 	mul	ab
      008942 2E               [12]  826 	add	a, r6
      008943 FE               [12]  827 	mov	r6,a
      008944 EF               [12]  828 	mov	a,r7
      008945 35 F0            [12]  829 	addc	a, b
      008947 FF               [12]  830 	mov	r7,a
      008948 90 0B 29         [24]  831 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00894B E0               [24]  832 	movx	a,@dptr
      00894C 7C 00            [12]  833 	mov	r4,#0x00
      00894E 25 E0            [12]  834 	add	a,acc
      008950 FB               [12]  835 	mov	r3,a
      008951 EC               [12]  836 	mov	a,r4
      008952 33               [12]  837 	rlc	a
      008953 FC               [12]  838 	mov	r4,a
      008954 EB               [12]  839 	mov	a,r3
      008955 2E               [12]  840 	add	a, r6
      008956 FE               [12]  841 	mov	r6,a
      008957 EC               [12]  842 	mov	a,r4
      008958 3F               [12]  843 	addc	a, r7
      008959 FF               [12]  844 	mov	r7,a
      00895A 12 49 7E         [24]  845 	lcall	_ak820_outline_0061
                                    846 ;	quantum/dynamic_keymap.c:206: }
      00895D 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_377'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_380'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_380'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      00895E                        861 _dynamic_keymap_get_keycode:
      00895E E5 82            [12]  862 	mov	a,dpl
      008960 90 0B 2D         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_377
      008963 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008964 E0               [24]  866 	movx	a,@dptr
      008965 FF               [12]  867 	mov	r7,a
      008966 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008969                        869 00121$:
      008969 50 14            [24]  870 	jnc	00101$
      00896B 90 0B 2B         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00896E E0               [24]  872 	movx	a,@dptr
      00896F FE               [12]  873 	mov	r6,a
      008970 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      008973                        875 00123$:
      008973 50 0A            [24]  876 	jnc	00101$
      008975 90 0B 2C         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008978 E0               [24]  878 	movx	a,@dptr
      008979 FD               [12]  879 	mov	r5,a
      00897A BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      00897D                        881 00125$:
      00897D 40 04            [24]  882 	jc	00102$
      00897F                        883 00101$:
      00897F 90 00 00         [24]  884 	mov	dptr,#0x0000
      008982 22               [24]  885 	ret
      008983                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008983 12 93 A9         [24]  888 	lcall	_ak820_outline_0104
      008986 31 29            [12]  889 	acall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008988 12 93 B6         [24]  891 	lcall	_ak820_outline_0122
      00898B 12 40 7C         [24]  892 	lcall	_eeprom_read_byte
      00898E AB 82            [24]  893 	mov	r3,dpl
      008990 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008992 0D               [12]  896 	inc	r5
      008993 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008996 0E               [12]  898 	inc	r6
      008997                        899 00127$:
      008997 12 49 77         [24]  900 	lcall	_ak820_outline_0050
      00899A 12 40 7C         [24]  901 	lcall	_eeprom_read_byte
      00899D AF 82            [24]  902 	mov	r7, dpl
      00899F 7E 00            [12]  903 	mov	r6,#0x00
      0089A1 EF               [12]  904 	mov	a,r7
      0089A2 42 04            [12]  905 	orl	ar4,a
      0089A4 EE               [12]  906 	mov	a,r6
      0089A5 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      0089A7 12 43 8B         [24]  909 	lcall	_ak820_outline_0191
                                    910 ;	quantum/dynamic_keymap.c:215: }
      0089AA 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_381'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_384'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      0089AB                        925 _dynamic_keymap_set_keycode:
      0089AB E5 82            [12]  926 	mov	a,dpl
      0089AD 90 0B 32         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_381
      0089B0 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0089B1 E0               [24]  930 	movx	a,@dptr
      0089B2 FF               [12]  931 	mov	r7,a
      0089B3 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      0089B6                        933 00121$:
      0089B6 50 14            [24]  934 	jnc	00101$
      0089B8 90 0B 2E         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0089BB E0               [24]  936 	movx	a,@dptr
      0089BC FE               [12]  937 	mov	r6,a
      0089BD BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      0089C0                        939 00123$:
      0089C0 50 0A            [24]  940 	jnc	00101$
      0089C2 90 0B 2F         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0089C5 E0               [24]  942 	movx	a,@dptr
      0089C6 FD               [12]  943 	mov	r5,a
      0089C7 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      0089CA                        945 00125$:
      0089CA 40 01            [24]  946 	jc	00102$
      0089CC                        947 00101$:
      0089CC 22               [24]  948 	ret
      0089CD                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0089CD 12 93 A9         [24]  951 	lcall	_ak820_outline_0104
      0089D0 31 29            [12]  952 	acall	_dynamic_keymap_key_to_eeprom_address
      0089D2 12 93 B6         [24]  953 	lcall	_ak820_outline_0122
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0089D5 90 0B 30         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0089D8 E0               [24]  956 	movx	a,@dptr
      0089D9 FB               [12]  957 	mov	r3,a
      0089DA A3               [24]  958 	inc	dptr
      0089DB E0               [24]  959 	movx	a,@dptr
      0089DC 90 06 EE         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089DF 12 49 59         [24]  961 	lcall	_ak820_outline_0033
      0089E2 12 54 2A         [24]  962 	lcall	_eeprom_update_byte
                                    963 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0089E5 0D               [12]  964 	inc	r5
      0089E6 BD 00 01         [24]  965 	cjne	r5,#0x00,00127$
      0089E9 0E               [12]  966 	inc	r6
      0089EA                        967 00127$:
      0089EA 90 06 EE         [24]  968 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089ED EB               [12]  969 	mov	a,r3
      0089EE 12 49 59         [24]  970 	lcall	_ak820_outline_0033
                                    971 ;	quantum/dynamic_keymap.c:223: }
      0089F1 02 54 2A         [24]  972 	ljmp	_eeprom_update_byte
                                    973 ;------------------------------------------------------------
                                    974 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    975 ;------------------------------------------------------------
                                    976 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    977 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_385'
                                    978 ;------------------------------------------------------------
                                    979 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    982 ;	-----------------------------------------
      0089F4                        983 _dynamic_keymap_encoder_to_eeprom_address:
      0089F4 E5 82            [12]  984 	mov	a,dpl
      0089F6 90 0B 34         [24]  985 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_385
      0089F9 F0               [24]  986 	movx	@dptr,a
                                    987 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0089FA E0               [24]  988 	movx	a,@dptr
      0089FB 75 F0 04         [24]  989 	mov	b,#0x04
      0089FE A4               [48]  990 	mul	ab
      0089FF 24 40            [12]  991 	add	a, #0x40
      008A01 FD               [12]  992 	mov	r5,a
      008A02 74 06            [12]  993 	mov	a,#0x06
      008A04 35 F0            [12]  994 	addc	a, b
      008A06 FE               [12]  995 	mov	r6,a
      008A07 7F 00            [12]  996 	mov	r7,#0x00
      008A09 90 0B 33         [24]  997 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008A0C E0               [24]  998 	movx	a,@dptr
      008A0D 75 F0 04         [24]  999 	mov	b,#0x04
      008A10 A4               [48] 1000 	mul	ab
      008A11 2D               [12] 1001 	add	a, r5
      008A12 FD               [12] 1002 	mov	r5,a
      008A13 EE               [12] 1003 	mov	a,r6
      008A14 35 F0            [12] 1004 	addc	a, b
      008A16 FE               [12] 1005 	mov	r6,a
      008A17 12 49 77         [24] 1006 	lcall	_ak820_outline_0050
                                   1007 ;	quantum/dynamic_keymap.c:228: }
      008A1A 22               [24] 1008 	ret
                                   1009 ;------------------------------------------------------------
                                   1010 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1011 ;------------------------------------------------------------
                                   1012 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1013 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1014 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_387'
                                   1015 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_390'
                                   1016 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_390'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function dynamic_keymap_get_encoder
                                   1021 ;	-----------------------------------------
      008A1B                       1022 _dynamic_keymap_get_encoder:
      008A1B E5 82            [12] 1023 	mov	a,dpl
      008A1D 90 0B 37         [24] 1024 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_387
      008A20 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008A21 E0               [24] 1027 	movx	a,@dptr
      008A22 FF               [12] 1028 	mov	r7,a
      008A23 BF 06 00         [24] 1029 	cjne	r7,#0x06,00131$
      008A26                       1030 00131$:
      008A26 50 0A            [24] 1031 	jnc	00101$
      008A28 90 0B 35         [24] 1032 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008A2B E0               [24] 1033 	movx	a,@dptr
      008A2C FE               [12] 1034 	mov	r6,a
      008A2D BE 01 00         [24] 1035 	cjne	r6,#0x01,00133$
      008A30                       1036 00133$:
      008A30 40 04            [24] 1037 	jc	00102$
      008A32                       1038 00101$:
      008A32 90 00 00         [24] 1039 	mov	dptr,#0x0000
      008A35 22               [24] 1040 	ret
      008A36                       1041 00102$:
                                   1042 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008A36 90 0B 33         [24] 1043 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008A39 E4               [12] 1044 	clr	a
      008A3A F0               [24] 1045 	movx	@dptr,a
      008A3B 8F 82            [24] 1046 	mov	dpl, r7
      008A3D 31 F4            [12] 1047 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008A3F 12 93 B6         [24] 1048 	lcall	_ak820_outline_0122
                                   1049 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008A42 90 0B 36         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008A45 E0               [24] 1051 	movx	a,@dptr
      008A46 FC               [12] 1052 	mov	r4,a
      008A47 E0               [24] 1053 	movx	a,@dptr
      008A48 60 04            [24] 1054 	jz	00106$
      008A4A 7B 00            [12] 1055 	mov	r3,#0x00
      008A4C 80 02            [24] 1056 	sjmp	00107$
      008A4E                       1057 00106$:
      008A4E 7B 02            [12] 1058 	mov	r3,#0x02
      008A50                       1059 00107$:
      008A50 EB               [12] 1060 	mov	a,r3
      008A51 12 7C 91         [24] 1061 	lcall	_ak820_outline_0015
      008A54 12 40 7C         [24] 1062 	lcall	_eeprom_read_byte
      008A57 AA 82            [24] 1063 	mov	r2,dpl
      008A59 7B 00            [12] 1064 	mov	r3,#0x00
                                   1065 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008A5B EC               [12] 1066 	mov	a,r4
      008A5C 60 04            [24] 1067 	jz	00108$
      008A5E 7C 00            [12] 1068 	mov	r4,#0x00
      008A60 80 02            [24] 1069 	sjmp	00109$
      008A62                       1070 00108$:
      008A62 7C 02            [12] 1071 	mov	r4,#0x02
      008A64                       1072 00109$:
      008A64 EC               [12] 1073 	mov	a,r4
      008A65 12 38 C4         [24] 1074 	lcall	_ak820_outline_0168
      008A68 0D               [12] 1075 	inc	r5
      008A69 BD 00 01         [24] 1076 	cjne	r5,#0x00,00137$
      008A6C 0E               [12] 1077 	inc	r6
      008A6D                       1078 00137$:
      008A6D 12 49 77         [24] 1079 	lcall	_ak820_outline_0050
      008A70 12 40 7C         [24] 1080 	lcall	_eeprom_read_byte
      008A73 AF 82            [24] 1081 	mov	r7, dpl
      008A75 7E 00            [12] 1082 	mov	r6,#0x00
      008A77 EF               [12] 1083 	mov	a,r7
      008A78 42 03            [12] 1084 	orl	ar3,a
      008A7A EE               [12] 1085 	mov	a,r6
      008A7B 42 02            [12] 1086 	orl	ar2,a
                                   1087 ;	quantum/dynamic_keymap.c:236: return keycode;
      008A7D 8B 82            [24] 1088 	mov	dpl, r3
      008A7F 8A 83            [24] 1089 	mov	dph, r2
                                   1090 ;	quantum/dynamic_keymap.c:237: }
      008A81 22               [24] 1091 	ret
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1094 ;------------------------------------------------------------
                                   1095 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1096 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1097 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1098 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1099 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_391'
                                   1100 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_394'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function dynamic_keymap_set_encoder
                                   1105 ;	-----------------------------------------
      008A82                       1106 _dynamic_keymap_set_encoder:
      008A82 E5 82            [12] 1107 	mov	a,dpl
      008A84 90 0B 3C         [24] 1108 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_391
      008A87 F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008A88 E0               [24] 1111 	movx	a,@dptr
      008A89 FF               [12] 1112 	mov	r7,a
      008A8A BF 06 00         [24] 1113 	cjne	r7,#0x06,00131$
      008A8D                       1114 00131$:
      008A8D 50 0A            [24] 1115 	jnc	00101$
      008A8F 90 0B 38         [24] 1116 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008A92 E0               [24] 1117 	movx	a,@dptr
      008A93 FE               [12] 1118 	mov	r6,a
      008A94 BE 01 00         [24] 1119 	cjne	r6,#0x01,00133$
      008A97                       1120 00133$:
      008A97 40 01            [24] 1121 	jc	00102$
      008A99                       1122 00101$:
      008A99 22               [24] 1123 	ret
      008A9A                       1124 00102$:
                                   1125 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008A9A 90 0B 33         [24] 1126 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008A9D E4               [12] 1127 	clr	a
      008A9E F0               [24] 1128 	movx	@dptr,a
      008A9F 8F 82            [24] 1129 	mov	dpl, r7
      008AA1 31 F4            [12] 1130 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008AA3 12 93 B6         [24] 1131 	lcall	_ak820_outline_0122
                                   1132 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008AA6 90 0B 39         [24] 1133 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008AA9 E0               [24] 1134 	movx	a,@dptr
      008AAA FC               [12] 1135 	mov	r4,a
      008AAB E0               [24] 1136 	movx	a,@dptr
      008AAC 60 04            [24] 1137 	jz	00106$
      008AAE 7B 00            [12] 1138 	mov	r3,#0x00
      008AB0 80 02            [24] 1139 	sjmp	00107$
      008AB2                       1140 00106$:
      008AB2 7B 02            [12] 1141 	mov	r3,#0x02
      008AB4                       1142 00107$:
      008AB4 EB               [12] 1143 	mov	a,r3
      008AB5 12 93 C8         [24] 1144 	lcall	_ak820_outline_0142
      008AB8 8F 03            [24] 1145 	mov	ar3,r7
      008ABA 90 0B 3A         [24] 1146 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008ABD E0               [24] 1147 	movx	a,@dptr
      008ABE F5 31            [12] 1148 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008AC0 A3               [24] 1149 	inc	dptr
      008AC1 E0               [24] 1150 	movx	a,@dptr
      008AC2 F5 32            [12] 1151 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008AC4 90 06 EE         [24] 1152 	mov	dptr,#_eeprom_update_byte_PARM_2
      008AC7 F0               [24] 1153 	movx	@dptr,a
      008AC8 12 43 86         [24] 1154 	lcall	_ak820_outline_0178
      008ACB 8B F0            [24] 1155 	mov	b, r3
      008ACD 12 54 2A         [24] 1156 	lcall	_eeprom_update_byte
                                   1157 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008AD0 EC               [12] 1158 	mov	a,r4
      008AD1 60 04            [24] 1159 	jz	00108$
      008AD3 7C 00            [12] 1160 	mov	r4,#0x00
      008AD5 80 02            [24] 1161 	sjmp	00109$
      008AD7                       1162 00108$:
      008AD7 7C 02            [12] 1163 	mov	r4,#0x02
      008AD9                       1164 00109$:
      008AD9 EC               [12] 1165 	mov	a,r4
      008ADA 12 38 C4         [24] 1166 	lcall	_ak820_outline_0168
      008ADD 0D               [12] 1167 	inc	r5
      008ADE BD 00 01         [24] 1168 	cjne	r5,#0x00,00137$
      008AE1 0E               [12] 1169 	inc	r6
      008AE2                       1170 00137$:
      008AE2 90 06 EE         [24] 1171 	mov	dptr,#_eeprom_update_byte_PARM_2
      008AE5 E5 31            [12] 1172 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008AE7 12 49 59         [24] 1173 	lcall	_ak820_outline_0033
                                   1174 ;	quantum/dynamic_keymap.c:245: }
      008AEA 02 54 2A         [24] 1175 	ljmp	_eeprom_update_byte
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1178 ;------------------------------------------------------------
                                   1179 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1180 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1181 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_395'
                                   1182 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_396'
                                   1183 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_398'
                                   1184 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_399'
                                   1185 ;------------------------------------------------------------
                                   1186 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1187 ;	-----------------------------------------
                                   1188 ;	 function dynamic_keymap_get_combo
                                   1189 ;	-----------------------------------------
      008AED                       1190 _dynamic_keymap_get_combo:
      008AED E5 82            [12] 1191 	mov	a,dpl
      008AEF 90 0B 40         [24] 1192 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_395
      008AF2 F0               [24] 1193 	movx	@dptr,a
                                   1194 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008AF3 90 0B 3D         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008AF6 12 38 3E         [24] 1196 	lcall	_ak820_outline_0055
                                   1197 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008AF9 90 0B 40         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_395
      008AFC E0               [24] 1199 	movx	a,@dptr
      008AFD FD               [12] 1200 	mov	r5,a
      008AFE BD 08 00         [24] 1201 	cjne	r5,#0x08,00132$
      008B01                       1202 00132$:
      008B01 40 04            [24] 1203 	jc	00102$
                                   1204 ;	quantum/dynamic_keymap.c:315: return -1;
      008B03 90 FF FF         [24] 1205 	mov	dptr,#0xffff
      008B06 22               [24] 1206 	ret
      008B07                       1207 00102$:
                                   1208 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B07 12 93 95         [24] 1209 	lcall	_ak820_outline_0086
                                   1210 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008B0A 8E 02            [24] 1211 	mov	ar2,r6
      008B0C 8F 03            [24] 1212 	mov	ar3,r7
      008B0E 90 05 85         [24] 1213 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008B11 EC               [12] 1214 	mov	a,r4
      008B12 F0               [24] 1215 	movx	@dptr,a
      008B13 ED               [12] 1216 	mov	a,r5
      008B14 12 38 5B         [24] 1217 	lcall	_ak820_outline_0070
      008B17 90 05 88         [24] 1218 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008B1A 12 93 8E         [24] 1219 	lcall	_ak820_outline_0081
      008B1D 12 38 B5         [24] 1220 	lcall	_ak820_outline_0154
      008B20 C0 07            [24] 1221 	push	ar7
      008B22 C0 06            [24] 1222 	push	ar6
      008B24 12 40 B7         [24] 1223 	lcall	_ak820_eeprom_read_block_xdata
      008B27 D0 06            [24] 1224 	pop	ar6
      008B29 D0 07            [24] 1225 	pop	ar7
                                   1226 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008B2B 74 04            [12] 1227 	mov	a,#0x04
      008B2D 12 4E C0         [24] 1228 	lcall	_ak820_outline_0035
      008B30 FA               [12] 1229 	mov	r2,a
      008B31 A3               [24] 1230 	inc	dptr
      008B32 E0               [24] 1231 	movx	a,@dptr
      008B33 FB               [12] 1232 	mov	r3,a
      008B34 BA 20 13         [24] 1233 	cjne	r2,#0x20,00108$
      008B37 BB 08 10         [24] 1234 	cjne	r3,#0x08,00108$
      008B3A 74 06            [12] 1235 	mov	a,#0x06
      008B3C 12 38 2E         [24] 1236 	lcall	_ak820_outline_0024
      008B3F 12 43 52         [24] 1237 	lcall	_ak820_outline_0108
      008B42 BA 01 05         [24] 1238 	cjne	r2,#0x01,00136$
      008B45 BB 00 02         [24] 1239 	cjne	r3,#0x00,00136$
      008B48 80 05            [24] 1240 	sjmp	00109$
      008B4A                       1241 00136$:
      008B4A                       1242 00108$:
      008B4A 75 33 00         [24] 1243 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008B4D 80 03            [24] 1244 	sjmp	00110$
      008B4F                       1245 00109$:
      008B4F 75 33 01         [24] 1246 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008B52                       1247 00110$:
                                   1248 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008B52 74 06            [12] 1249 	mov	a,#0x06
      008B54 12 38 2E         [24] 1250 	lcall	_ak820_outline_0024
      008B57 E4               [12] 1251 	clr	a
      008B58 F0               [24] 1252 	movx	@dptr,a
      008B59 A3               [24] 1253 	inc	dptr
      008B5A 12 38 95         [24] 1254 	lcall	_ak820_outline_0129
      008B5D F0               [24] 1255 	movx	@dptr,a
      008B5E A3               [24] 1256 	inc	dptr
      008B5F F0               [24] 1257 	movx	@dptr,a
                                   1258 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008B60 E5 33            [12] 1259 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008B62 60 12            [24] 1260 	jz	00103$
      008B64 12 38 8A         [24] 1261 	lcall	_ak820_outline_0124
      008B67 C0 07            [24] 1262 	push	ar7
      008B69 C0 06            [24] 1263 	push	ar6
      008B6B 12 34 D0         [24] 1264 	lcall	_ak820_combo_valid
      008B6E E5 82            [12] 1265 	mov	a, dpl
      008B70 D0 06            [24] 1266 	pop	ar6
      008B72 D0 07            [24] 1267 	pop	ar7
      008B74 70 13            [24] 1268 	jnz	00104$
      008B76                       1269 00103$:
      008B76 7D 00            [12] 1270 	mov	r5,#0x00
      008B78 90 0D F9         [24] 1271 	mov	dptr,#_memset_PARM_2
      008B7B E4               [12] 1272 	clr	a
      008B7C F0               [24] 1273 	movx	@dptr,a
      008B7D 90 0D FA         [24] 1274 	mov	dptr,#_memset_PARM_3
      008B80 12 93 8E         [24] 1275 	lcall	_ak820_outline_0081
      008B83 12 49 7E         [24] 1276 	lcall	_ak820_outline_0061
      008B86 12 BE EA         [24] 1277 	lcall	_memset
      008B89                       1278 00104$:
                                   1279 ;	quantum/dynamic_keymap.c:329: return 0;
      008B89 90 00 00         [24] 1280 	mov	dptr,#0x0000
                                   1281 ;	quantum/dynamic_keymap.c:330: }
      008B8C 22               [24] 1282 	ret
                                   1283 ;------------------------------------------------------------
                                   1284 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1285 ;------------------------------------------------------------
                                   1286 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1287 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_401'
                                   1288 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_402'
                                   1289 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_405'
                                   1290 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_406'
                                   1291 ;------------------------------------------------------------
                                   1292 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1293 ;	-----------------------------------------
                                   1294 ;	 function dynamic_keymap_set_combo
                                   1295 ;	-----------------------------------------
      008B8D                       1296 _dynamic_keymap_set_combo:
      008B8D E5 82            [12] 1297 	mov	a,dpl
      008B8F 90 0B 44         [24] 1298 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_401
      008B92 F0               [24] 1299 	movx	@dptr,a
                                   1300 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B93 90 0B 41         [24] 1301 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008B96 12 37 F1         [24] 1302 	lcall	_ak820_outline_0005
                                   1303 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008B99 C0 07            [24] 1304 	push	ar7
      008B9B C0 06            [24] 1305 	push	ar6
      008B9D 12 34 D0         [24] 1306 	lcall	_ak820_combo_valid
      008BA0 E5 82            [12] 1307 	mov	a, dpl
      008BA2 D0 06            [24] 1308 	pop	ar6
      008BA4 D0 07            [24] 1309 	pop	ar7
      008BA6 60 07            [24] 1310 	jz	00101$
      008BA8 12 3E 23         [24] 1311 	lcall	_ak820_nvm_ok
      008BAB E5 82            [12] 1312 	mov	a, dpl
      008BAD 70 04            [24] 1313 	jnz	00102$
      008BAF                       1314 00101$:
      008BAF 90 FF FF         [24] 1315 	mov	dptr,#0xffff
      008BB2 22               [24] 1316 	ret
      008BB3                       1317 00102$:
                                   1318 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008BB3 90 0B 44         [24] 1319 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_401
      008BB6 E0               [24] 1320 	movx	a,@dptr
      008BB7 FD               [12] 1321 	mov	r5,a
      008BB8 BD 08 00         [24] 1322 	cjne	r5,#0x08,00133$
      008BBB                       1323 00133$:
      008BBB 40 04            [24] 1324 	jc	00105$
                                   1325 ;	quantum/dynamic_keymap.c:342: return -1;
      008BBD 90 FF FF         [24] 1326 	mov	dptr,#0xffff
      008BC0 22               [24] 1327 	ret
      008BC1                       1328 00105$:
                                   1329 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008BC1 12 93 95         [24] 1330 	lcall	_ak820_outline_0086
                                   1331 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008BC4 C0 07            [24] 1332 	push	ar7
      008BC6 C0 06            [24] 1333 	push	ar6
      008BC8 C0 05            [24] 1334 	push	ar5
      008BCA C0 04            [24] 1335 	push	ar4
      008BCC 12 7C 52         [24] 1336 	lcall	_clear_keyboard
      008BCF D0 04            [24] 1337 	pop	ar4
      008BD1 D0 05            [24] 1338 	pop	ar5
      008BD3 D0 06            [24] 1339 	pop	ar6
      008BD5 D0 07            [24] 1340 	pop	ar7
                                   1341 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008BD7 90 0D F1         [24] 1342 	mov	dptr,#___memcpy_PARM_2
      008BDA 12 4E D3         [24] 1343 	lcall	_ak820_outline_0062
      008BDD E4               [12] 1344 	clr	a
      008BDE A3               [24] 1345 	inc	dptr
      008BDF F0               [24] 1346 	movx	@dptr,a
      008BE0 90 0D F4         [24] 1347 	mov	dptr,#___memcpy_PARM_3
      008BE3 12 93 8E         [24] 1348 	lcall	_ak820_outline_0081
      008BE6 90 0B 45         [24] 1349 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_406
      008BE9 F5 F0            [12] 1350 	mov	b,a
      008BEB C0 05            [24] 1351 	push	ar5
      008BED C0 04            [24] 1352 	push	ar4
      008BEF 12 BE 74         [24] 1353 	lcall	___memcpy
      008BF2 D0 04            [24] 1354 	pop	ar4
      008BF4 D0 05            [24] 1355 	pop	ar5
                                   1356 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008BF6 90 0B 49         [24] 1357 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_406 + 0x0004)
      008BF9 74 20            [12] 1358 	mov	a,#0x20
      008BFB F0               [24] 1359 	movx	@dptr,a
      008BFC 74 08            [12] 1360 	mov	a,#0x08
      008BFE A3               [24] 1361 	inc	dptr
      008BFF F0               [24] 1362 	movx	@dptr,a
                                   1363 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008C00 90 0B 4B         [24] 1364 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_406 + 0x0006)
      008C03 74 01            [12] 1365 	mov	a,#0x01
      008C05 12 38 9B         [24] 1366 	lcall	_ak820_outline_0131
                                   1367 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008C08 90 05 8E         [24] 1368 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008C0B EC               [12] 1369 	mov	a,r4
      008C0C F0               [24] 1370 	movx	@dptr,a
      008C0D ED               [12] 1371 	mov	a,r5
      008C0E 12 38 5B         [24] 1372 	lcall	_ak820_outline_0070
      008C11 90 05 91         [24] 1373 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008C14 12 93 8E         [24] 1374 	lcall	_ak820_outline_0081
      008C17 90 0B 45         [24] 1375 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_406
      008C1A 12 41 43         [24] 1376 	lcall	_ak820_eeprom_write_block_xdata
                                   1377 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008C1D 12 3E 32         [24] 1378 	lcall	_ak820_nvm_flush
                                   1379 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008C20 12 3E 23         [24] 1380 	lcall	_ak820_nvm_ok
      008C23 E5 82            [12] 1381 	mov	a, dpl
      008C25 70 04            [24] 1382 	jnz	00107$
      008C27 90 FF FF         [24] 1383 	mov	dptr,#0xffff
      008C2A 22               [24] 1384 	ret
      008C2B                       1385 00107$:
                                   1386 ;	quantum/dynamic_keymap.c:360: return 0;
      008C2B 90 00 00         [24] 1387 	mov	dptr,#0x0000
                                   1388 ;	quantum/dynamic_keymap.c:361: }
      008C2E 22               [24] 1389 	ret
                                   1390 ;------------------------------------------------------------
                                   1391 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1392 ;------------------------------------------------------------
                                   1393 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_409'
                                   1394 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_410'
                                   1395 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_412'
                                   1396 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_414'
                                   1397 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_416'
                                   1398 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_418'
                                   1399 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_419'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function dynamic_keymap_reset
                                   1404 ;	-----------------------------------------
      008C2F                       1405 _dynamic_keymap_reset:
                                   1406 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008C2F 90 0E 79         [24] 1407 	mov	dptr,#_vial_unlocked
      008C32 E0               [24] 1408 	movx	a,@dptr
      008C33 90 0B 4F         [24] 1409 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_409
      008C36 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008C37 90 0E 79         [24] 1412 	mov	dptr,#_vial_unlocked
      008C3A 74 01            [12] 1413 	mov	a,#0x01
      008C3C F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008C3D 7F 00            [12] 1416 	mov	r7,#0x00
      008C3F                       1417 00116$:
      008C3F BF 06 00         [24] 1418 	cjne	r7,#0x06,00198$
      008C42                       1419 00198$:
      008C42 40 02            [24] 1420 	jc	00199$
      008C44 81 ED            [12] 1421 	ajmp	00104$
      008C46                       1422 00199$:
                                   1423 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C46 7E 00            [12] 1424 	mov	r6,#0x00
      008C48                       1425 00110$:
      008C48 BE 10 00         [24] 1426 	cjne	r6,#0x10,00200$
      008C4B                       1427 00200$:
      008C4B 50 4C            [24] 1428 	jnc	00102$
                                   1429 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C4D 7D 00            [12] 1430 	mov	r5,#0x00
      008C4F                       1431 00107$:
      008C4F BD 08 00         [24] 1432 	cjne	r5,#0x08,00202$
      008C52                       1433 00202$:
      008C52 50 42            [24] 1434 	jnc	00111$
                                   1435 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008C54 90 0B EB         [24] 1436 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008C57 EE               [12] 1437 	mov	a,r6
      008C58 F0               [24] 1438 	movx	@dptr,a
      008C59 90 0B EC         [24] 1439 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008C5C ED               [12] 1440 	mov	a,r5
      008C5D F0               [24] 1441 	movx	@dptr,a
      008C5E 8F 82            [24] 1442 	mov	dpl, r7
      008C60 C0 07            [24] 1443 	push	ar7
      008C62 C0 06            [24] 1444 	push	ar6
      008C64 C0 05            [24] 1445 	push	ar5
      008C66 12 9B C6         [24] 1446 	lcall	_keycode_at_keymap_location_raw
      008C69 AB 82            [24] 1447 	mov	r3, dpl
      008C6B AC 83            [24] 1448 	mov	r4, dph
      008C6D D0 05            [24] 1449 	pop	ar5
      008C6F D0 06            [24] 1450 	pop	ar6
      008C71 D0 07            [24] 1451 	pop	ar7
      008C73 90 0B 2E         [24] 1452 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008C76 EE               [12] 1453 	mov	a,r6
      008C77 F0               [24] 1454 	movx	@dptr,a
      008C78 90 0B 2F         [24] 1455 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008C7B ED               [12] 1456 	mov	a,r5
      008C7C F0               [24] 1457 	movx	@dptr,a
      008C7D 90 0B 30         [24] 1458 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008C80 12 38 6D         [24] 1459 	lcall	_ak820_outline_0099
      008C83 8F 82            [24] 1460 	mov	dpl, r7
      008C85 C0 07            [24] 1461 	push	ar7
      008C87 C0 06            [24] 1462 	push	ar6
      008C89 C0 05            [24] 1463 	push	ar5
      008C8B 31 AB            [12] 1464 	acall	_dynamic_keymap_set_keycode
      008C8D D0 05            [24] 1465 	pop	ar5
      008C8F D0 06            [24] 1466 	pop	ar6
      008C91 D0 07            [24] 1467 	pop	ar7
                                   1468 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C93 0D               [12] 1469 	inc	r5
      008C94 80 B9            [24] 1470 	sjmp	00107$
      008C96                       1471 00111$:
                                   1472 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C96 0E               [12] 1473 	inc	r6
      008C97 80 AF            [24] 1474 	sjmp	00110$
      008C99                       1475 00102$:
                                   1476 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C99 7E 00            [12] 1477 	mov	r6,#0x00
      008C9B                       1478 00113$:
      008C9B BE 01 00         [24] 1479 	cjne	r6,#0x01,00204$
      008C9E                       1480 00204$:
      008C9E 50 4A            [24] 1481 	jnc	00117$
                                   1482 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008CA0 12 93 E4         [24] 1483 	lcall	_ak820_outline_0187
      008CA3 04               [12] 1484 	inc	a
      008CA4 F0               [24] 1485 	movx	@dptr,a
      008CA5 8F 82            [24] 1486 	mov	dpl, r7
      008CA7 C0 07            [24] 1487 	push	ar7
      008CA9 12 9C 0B         [24] 1488 	lcall	_keycode_at_encodermap_location_raw
      008CAC 12 38 B0         [24] 1489 	lcall	_ak820_outline_0153
      008CAF D0 07            [24] 1490 	pop	ar7
      008CB1 12 93 DB         [24] 1491 	lcall	_ak820_outline_0186
      008CB4 04               [12] 1492 	inc	a
      008CB5 F0               [24] 1493 	movx	@dptr,a
      008CB6 90 0B 3A         [24] 1494 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008CB9 12 38 61         [24] 1495 	lcall	_ak820_outline_0078
      008CBC 8F 82            [24] 1496 	mov	dpl, r7
      008CBE C0 07            [24] 1497 	push	ar7
      008CC0 51 82            [24] 1498 	acall	_dynamic_keymap_set_encoder
      008CC2 D0 07            [24] 1499 	pop	ar7
                                   1500 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008CC4 12 93 E4         [24] 1501 	lcall	_ak820_outline_0187
      008CC7 F0               [24] 1502 	movx	@dptr,a
      008CC8 8F 82            [24] 1503 	mov	dpl, r7
      008CCA C0 07            [24] 1504 	push	ar7
      008CCC 12 9C 0B         [24] 1505 	lcall	_keycode_at_encodermap_location_raw
      008CCF 12 38 B0         [24] 1506 	lcall	_ak820_outline_0153
      008CD2 D0 07            [24] 1507 	pop	ar7
      008CD4 12 93 DB         [24] 1508 	lcall	_ak820_outline_0186
      008CD7 F0               [24] 1509 	movx	@dptr,a
      008CD8 90 0B 3A         [24] 1510 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008CDB 12 38 61         [24] 1511 	lcall	_ak820_outline_0078
      008CDE 8F 82            [24] 1512 	mov	dpl, r7
      008CE0 C0 07            [24] 1513 	push	ar7
      008CE2 51 82            [24] 1514 	acall	_dynamic_keymap_set_encoder
      008CE4 D0 07            [24] 1515 	pop	ar7
                                   1516 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008CE6 7E 01            [12] 1517 	mov	r6,#0x01
      008CE8 80 B1            [24] 1518 	sjmp	00113$
      008CEA                       1519 00117$:
                                   1520 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008CEA 0F               [12] 1521 	inc	r7
      008CEB 81 3F            [12] 1522 	ajmp	00116$
      008CED                       1523 00104$:
                                   1524 ;	quantum/dynamic_keymap.c:435: ak820_settings_reset();
      008CED 12 49 0F         [24] 1525 	lcall	_ak820_settings_reset
                                   1526 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008CF0 90 0B 50         [24] 1527 	mov	dptr,#_dynamic_keymap_reset_combo_10001_418
      008CF3 12 49 BF         [24] 1528 	lcall	_ak820_outline_0177
      008CF6 90 0B 52         [24] 1529 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0002)
      008CF9 F0               [24] 1530 	movx	@dptr,a
      008CFA A3               [24] 1531 	inc	dptr
      008CFB F0               [24] 1532 	movx	@dptr,a
      008CFC 90 0B 54         [24] 1533 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0004)
      008CFF F0               [24] 1534 	movx	@dptr,a
      008D00 A3               [24] 1535 	inc	dptr
      008D01 F0               [24] 1536 	movx	@dptr,a
      008D02 90 0B 56         [24] 1537 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0006)
      008D05 F0               [24] 1538 	movx	@dptr,a
      008D06 A3               [24] 1539 	inc	dptr
      008D07 F0               [24] 1540 	movx	@dptr,a
      008D08 90 0B 58         [24] 1541 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0008)
      008D0B F0               [24] 1542 	movx	@dptr,a
      008D0C A3               [24] 1543 	inc	dptr
      008D0D F0               [24] 1544 	movx	@dptr,a
                                   1545 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008D0E FF               [12] 1546 	mov	r7,a
      008D0F                       1547 00119$:
      008D0F BF 08 00         [24] 1548 	cjne	r7,#0x08,00206$
      008D12                       1549 00206$:
      008D12 50 18            [24] 1550 	jnc	00105$
                                   1551 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008D14 8F 06            [24] 1552 	mov	ar6,r7
      008D16 90 0B 41         [24] 1553 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008D19 74 50            [12] 1554 	mov	a,#_dynamic_keymap_reset_combo_10001_418
      008D1B F0               [24] 1555 	movx	@dptr,a
      008D1C 74 0B            [12] 1556 	mov	a,#(_dynamic_keymap_reset_combo_10001_418 >> 8)
      008D1E 12 38 5B         [24] 1557 	lcall	_ak820_outline_0070
      008D21 8E 82            [24] 1558 	mov	dpl, r6
      008D23 C0 07            [24] 1559 	push	ar7
      008D25 71 8D            [24] 1560 	acall	_dynamic_keymap_set_combo
      008D27 D0 07            [24] 1561 	pop	ar7
                                   1562 ;	quantum/dynamic_keymap.c:450: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008D29 0F               [12] 1563 	inc	r7
      008D2A 80 E3            [24] 1564 	sjmp	00119$
      008D2C                       1565 00105$:
                                   1566 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008D2C 90 0B 4F         [24] 1567 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_409
      008D2F E0               [24] 1568 	movx	a,@dptr
      008D30 90 0E 79         [24] 1569 	mov	dptr,#_vial_unlocked
      008D33 F0               [24] 1570 	movx	@dptr,a
                                   1571 ;	quantum/dynamic_keymap.c:468: }
      008D34 22               [24] 1572 	ret
                                   1573 ;------------------------------------------------------------
                                   1574 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1575 ;------------------------------------------------------------
                                   1576 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1577 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1578 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1579 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1580 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1581 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_420'
                                   1582 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_421'
                                   1583 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_421'
                                   1584 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_424'
                                   1585 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_426'
                                   1586 ;------------------------------------------------------------
                                   1587 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1588 ;	-----------------------------------------
                                   1589 ;	 function ak820_dynamic_read_buffer
                                   1590 ;	-----------------------------------------
      008D35                       1591 _ak820_dynamic_read_buffer:
      008D35 12 38 79         [24] 1592 	lcall	_ak820_outline_0113
      008D38 90 0B 63         [24] 1593 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_420
      008D3B 12 38 7E         [24] 1594 	lcall	_ak820_outline_0114
                                   1595 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008D3E 90 0B 60         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D41 12 38 3E         [24] 1597 	lcall	_ak820_outline_0055
                                   1598 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008D44 90 0B 65         [24] 1599 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008D47 E4               [12] 1600 	clr	a
      008D48 F0               [24] 1601 	movx	@dptr,a
                                   1602 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008D49 90 0B 5E         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D4C 12 38 55         [24] 1604 	lcall	_ak820_outline_0063
      008D4F 8C 02            [24] 1605 	mov	ar2,r4
      008D51 8D 03            [24] 1606 	mov	ar3,r5
      008D53 C3               [12] 1607 	clr	c
      008D54 74 1C            [12] 1608 	mov	a,#0x1c
      008D56 9A               [12] 1609 	subb	a,r2
      008D57 E4               [12] 1610 	clr	a
      008D58 9B               [12] 1611 	subb	a,r3
      008D59 50 01            [24] 1612 	jnc	00102$
                                   1613 ;	free result
      008D5B 22               [24] 1614 	ret
      008D5C                       1615 00102$:
                                   1616 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008D5C 90 0B 5C         [24] 1617 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008D5F 12 43 52         [24] 1618 	lcall	_ak820_outline_0108
      008D62 90 0B 5A         [24] 1619 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008D65 12 38 73         [24] 1620 	lcall	_ak820_outline_0107
      008D68 C3               [12] 1621 	clr	c
      008D69 EA               [12] 1622 	mov	a,r2
      008D6A 98               [12] 1623 	subb	a,r0
      008D6B EB               [12] 1624 	mov	a,r3
      008D6C 99               [12] 1625 	subb	a,r1
      008D6D 50 17            [24] 1626 	jnc	00104$
                                   1627 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008D6F E8               [12] 1628 	mov	a,r0
      008D70 C3               [12] 1629 	clr	c
      008D71 9A               [12] 1630 	subb	a,r2
      008D72 F8               [12] 1631 	mov	r0,a
      008D73 E9               [12] 1632 	mov	a,r1
      008D74 9B               [12] 1633 	subb	a,r3
      008D75 F9               [12] 1634 	mov	r1,a
                                   1635 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008D76 C3               [12] 1636 	clr	c
      008D77 E8               [12] 1637 	mov	a,r0
      008D78 9C               [12] 1638 	subb	a,r4
      008D79 E9               [12] 1639 	mov	a,r1
      008D7A 9D               [12] 1640 	subb	a,r5
      008D7B 40 04            [24] 1641 	jc	00114$
      008D7D 8C 00            [24] 1642 	mov	ar0,r4
      008D7F 8D 01            [24] 1643 	mov	ar1,r5
      008D81                       1644 00114$:
      008D81 90 0B 65         [24] 1645 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008D84 E8               [12] 1646 	mov	a,r0
      008D85 F0               [24] 1647 	movx	@dptr,a
      008D86                       1648 00104$:
                                   1649 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D86 90 0B 65         [24] 1650 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008D89 E0               [24] 1651 	movx	a,@dptr
      008D8A F5 34            [12] 1652 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008D8C E0               [24] 1653 	movx	a,@dptr
      008D8D 60 42            [24] 1654 	jz	00106$
      008D8F C0 04            [24] 1655 	push	ar4
      008D91 C0 05            [24] 1656 	push	ar5
      008D93 8E 00            [24] 1657 	mov	ar0,r6
      008D95 8F 05            [24] 1658 	mov	ar5,r7
      008D97 90 0B 63         [24] 1659 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_420
      008D9A E0               [24] 1660 	movx	a,@dptr
      008D9B F9               [12] 1661 	mov	r1,a
      008D9C A3               [24] 1662 	inc	dptr
      008D9D E0               [24] 1663 	movx	a,@dptr
      008D9E FC               [12] 1664 	mov	r4,a
      008D9F EA               [12] 1665 	mov	a,r2
      008DA0 29               [12] 1666 	add	a, r1
      008DA1 FA               [12] 1667 	mov	r2,a
      008DA2 EB               [12] 1668 	mov	a,r3
      008DA3 3C               [12] 1669 	addc	a, r4
      008DA4 FB               [12] 1670 	mov	r3,a
      008DA5 90 05 85         [24] 1671 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008DA8 EA               [12] 1672 	mov	a,r2
      008DA9 F0               [24] 1673 	movx	@dptr,a
      008DAA EB               [12] 1674 	mov	a,r3
      008DAB 12 38 5B         [24] 1675 	lcall	_ak820_outline_0070
      008DAE 90 05 88         [24] 1676 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008DB1 E5 34            [12] 1677 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008DB3 12 38 9B         [24] 1678 	lcall	_ak820_outline_0131
      008DB6 88 82            [24] 1679 	mov	dpl, r0
      008DB8 8D 83            [24] 1680 	mov	dph, r5
      008DBA C0 07            [24] 1681 	push	ar7
      008DBC C0 06            [24] 1682 	push	ar6
      008DBE C0 05            [24] 1683 	push	ar5
      008DC0 C0 04            [24] 1684 	push	ar4
      008DC2 12 40 B7         [24] 1685 	lcall	_ak820_eeprom_read_block_xdata
      008DC5 D0 04            [24] 1686 	pop	ar4
      008DC7 D0 05            [24] 1687 	pop	ar5
      008DC9 D0 06            [24] 1688 	pop	ar6
      008DCB D0 07            [24] 1689 	pop	ar7
                                   1690 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008DCD D0 05            [24] 1691 	pop	ar5
      008DCF D0 04            [24] 1692 	pop	ar4
                                   1693 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008DD1                       1694 00106$:
                                   1695 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008DD1 90 0B 65         [24] 1696 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008DD4 E0               [24] 1697 	movx	a,@dptr
      008DD5 FB               [12] 1698 	mov	r3,a
      008DD6                       1699 00109$:
      008DD6 8B 01            [24] 1700 	mov	ar1,r3
      008DD8 7A 00            [12] 1701 	mov	r2,#0x00
      008DDA C3               [12] 1702 	clr	c
      008DDB E9               [12] 1703 	mov	a,r1
      008DDC 9C               [12] 1704 	subb	a,r4
      008DDD EA               [12] 1705 	mov	a,r2
      008DDE 9D               [12] 1706 	subb	a,r5
      008DDF 50 09            [24] 1707 	jnc	00111$
      008DE1 EB               [12] 1708 	mov	a,r3
      008DE2 12 38 2E         [24] 1709 	lcall	_ak820_outline_0024
      008DE5 E4               [12] 1710 	clr	a
      008DE6 F0               [24] 1711 	movx	@dptr,a
      008DE7 0B               [12] 1712 	inc	r3
      008DE8 80 EC            [24] 1713 	sjmp	00109$
      008DEA                       1714 00111$:
                                   1715 ;	quantum/dynamic_keymap.c:483: }
      008DEA 22               [24] 1716 	ret
                                   1717 ;------------------------------------------------------------
                                   1718 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1719 ;------------------------------------------------------------
                                   1720 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1721 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1722 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_427'
                                   1723 ;------------------------------------------------------------
                                   1724 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1725 ;	-----------------------------------------
                                   1726 ;	 function dynamic_keymap_get_buffer
                                   1727 ;	-----------------------------------------
      008DEB                       1728 _dynamic_keymap_get_buffer:
      008DEB 12 38 79         [24] 1729 	lcall	_ak820_outline_0113
      008DEE 90 0B 6B         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_427
      008DF1 12 38 7E         [24] 1731 	lcall	_ak820_outline_0114
                                   1732 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008DF4 90 0B 6B         [24] 1733 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_427
      008DF7 12 38 3E         [24] 1734 	lcall	_ak820_outline_0055
      008DFA 90 0B 66         [24] 1735 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008DFD 12 38 55         [24] 1736 	lcall	_ak820_outline_0063
      008E00 90 0B 68         [24] 1737 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008E03 12 55 5B         [24] 1738 	lcall	_ak820_outline_0096
      008E06 90 0B 5A         [24] 1739 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008E09 E4               [12] 1740 	clr	a
      008E0A F0               [24] 1741 	movx	@dptr,a
      008E0B 74 06            [12] 1742 	mov	a,#0x06
      008E0D A3               [24] 1743 	inc	dptr
      008E0E F0               [24] 1744 	movx	@dptr,a
      008E0F 90 0B 5C         [24] 1745 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008E12 12 4E D3         [24] 1746 	lcall	_ak820_outline_0062
      008E15 90 0B 5E         [24] 1747 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008E18 12 38 61         [24] 1748 	lcall	_ak820_outline_0078
      008E1B 90 0B 60         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008E1E 12 4E FB         [24] 1750 	lcall	_ak820_outline_0145
      008E21 EB               [12] 1751 	mov	a,r3
      008E22 A3               [24] 1752 	inc	dptr
      008E23 F0               [24] 1753 	movx	@dptr,a
      008E24 90 00 40         [24] 1754 	mov	dptr,#0x0040
                                   1755 ;	quantum/dynamic_keymap.c:511: }
      008E27 A1 35            [12] 1756 	ajmp	_ak820_dynamic_read_buffer
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1759 ;------------------------------------------------------------
                                   1760 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1761 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1762 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1763 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1764 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1765 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_429'
                                   1766 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_430'
                                   1767 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_430'
                                   1768 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_430'
                                   1769 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_433'
                                   1770 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_436'
                                   1771 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_436'
                                   1772 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_438'
                                   1773 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_441'
                                   1774 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_443'
                                   1775 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_444'
                                   1776 ;------------------------------------------------------------
                                   1777 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1778 ;	-----------------------------------------
                                   1779 ;	 function dynamic_keymap_set_buffer
                                   1780 ;	-----------------------------------------
      008E29                       1781 _dynamic_keymap_set_buffer:
      008E29 12 38 79         [24] 1782 	lcall	_ak820_outline_0113
      008E2C 90 0B 72         [24] 1783 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008E2F 12 38 7E         [24] 1784 	lcall	_ak820_outline_0114
                                   1785 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008E32 90 0B 72         [24] 1786 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008E35 12 4E 82         [24] 1787 	lcall	_ak820_outline_0009
      008E38 74 40            [12] 1788 	mov	a,#0x40
      008E3A 2C               [12] 1789 	add	a, r4
      008E3B FA               [12] 1790 	mov	r2,a
      008E3C E4               [12] 1791 	clr	a
      008E3D 3D               [12] 1792 	addc	a, r5
      008E3E FB               [12] 1793 	mov	r3,a
                                   1794 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008E3F 90 0B 6F         [24] 1795 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008E42 12 38 73         [24] 1796 	lcall	_ak820_outline_0107
                                   1797 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008E45 90 0B 6D         [24] 1798 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008E48 E0               [24] 1799 	movx	a,@dptr
      008E49 F5 35            [12] 1800 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008E4B A3               [24] 1801 	inc	dptr
      008E4C E0               [24] 1802 	movx	a,@dptr
      008E4D F5 36            [12] 1803 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008E4F E5 35            [12] 1804 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E51 45 36            [12] 1805 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E53 70 01            [24] 1806 	jnz	00102$
      008E55 22               [24] 1807 	ret
      008E56                       1808 00102$:
                                   1809 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008E56 85 35 37         [24] 1810 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008E59 85 36 38         [24] 1811 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E5C C3               [12] 1812 	clr	c
      008E5D 74 1C            [12] 1813 	mov	a,#0x1c
      008E5F 95 37            [12] 1814 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E61 E4               [12] 1815 	clr	a
      008E62 95 38            [12] 1816 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E64 50 01            [24] 1817 	jnc	00104$
                                   1818 ;	free result
      008E66 22               [24] 1819 	ret
      008E67                       1820 00104$:
                                   1821 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008E67 85 35 39         [24] 1822 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1823 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008E6A 74 FA            [12] 1824 	mov	a,#0x100 - 0x06
      008E6C 2F               [12] 1825 	add	a,r7
      008E6D 40 11            [24] 1826 	jc	00105$
      008E6F E4               [12] 1827 	clr	a
      008E70 C3               [12] 1828 	clr	c
      008E71 9E               [12] 1829 	subb	a,r6
      008E72 FE               [12] 1830 	mov	r6,a
      008E73 74 06            [12] 1831 	mov	a,#0x06
      008E75 9F               [12] 1832 	subb	a,r7
      008E76 FF               [12] 1833 	mov	r7,a
      008E77 C3               [12] 1834 	clr	c
      008E78 EE               [12] 1835 	mov	a,r6
      008E79 95 35            [12] 1836 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E7B EF               [12] 1837 	mov	a,r7
      008E7C 95 36            [12] 1838 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E7E 50 01            [24] 1839 	jnc	00106$
      008E80                       1840 00105$:
                                   1841 ;	quantum/dynamic_keymap.c:529: return;
      008E80 22               [24] 1842 	ret
      008E81                       1843 00106$:
                                   1844 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008E81 90 0E 79         [24] 1845 	mov	dptr,#_vial_unlocked
      008E84 E0               [24] 1846 	movx	a,@dptr
      008E85 60 02            [24] 1847 	jz	00207$
      008E87 E1 93            [12] 1848 	ajmp	00120$
      008E89                       1849 00207$:
                                   1850 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008E89 90 0B 74         [24] 1851 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_436
      008E8C E4               [12] 1852 	clr	a
      008E8D F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008E8E 90 0B 75         [24] 1855 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_436
      008E91 E5 39            [12] 1856 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E93 F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008E94 EC               [12] 1859 	mov	a,r4
      008E95 30 E0 31         [24] 1860 	jnb	acc.0,00111$
                                   1861 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008E98 EA               [12] 1862 	mov	a,r2
      008E99 24 FF            [12] 1863 	add	a,#0xff
      008E9B FE               [12] 1864 	mov	r6,a
      008E9C EB               [12] 1865 	mov	a,r3
      008E9D 34 FF            [12] 1866 	addc	a,#0xff
      008E9F FF               [12] 1867 	mov	r7,a
      008EA0 7D 00            [12] 1868 	mov	r5,#0x00
      008EA2 12 49 7E         [24] 1869 	lcall	_ak820_outline_0061
      008EA5 12 40 7C         [24] 1870 	lcall	_eeprom_read_byte
      008EA8 AE 82            [24] 1871 	mov	r6,dpl
      008EAA 7F 00            [12] 1872 	mov	r7,#0x00
      008EAC 12 38 BF         [24] 1873 	lcall	_ak820_outline_0160
      008EAF E0               [24] 1874 	movx	a,@dptr
      008EB0 7C 00            [12] 1875 	mov	r4,#0x00
      008EB2 42 07            [12] 1876 	orl	ar7,a
      008EB4 EC               [12] 1877 	mov	a,r4
      008EB5 42 06            [12] 1878 	orl	ar6,a
                                   1879 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008EB7 BF 00 09         [24] 1880 	cjne	r7,#0x00,00109$
      008EBA BE 7C 06         [24] 1881 	cjne	r6,#0x7c,00109$
                                   1882 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008EBD 12 38 BF         [24] 1883 	lcall	_ak820_outline_0160
      008EC0 74 FF            [12] 1884 	mov	a,#0xff
      008EC2 F0               [24] 1885 	movx	@dptr,a
      008EC3                       1886 00109$:
                                   1887 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008EC3 90 0B 74         [24] 1888 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_436
      008EC6 74 01            [12] 1889 	mov	a,#0x01
      008EC8 F0               [24] 1890 	movx	@dptr,a
      008EC9                       1891 00111$:
                                   1892 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008EC9 90 0B 72         [24] 1893 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008ECC 12 38 3E         [24] 1894 	lcall	_ak820_outline_0055
      008ECF E5 35            [12] 1895 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008ED1 2E               [12] 1896 	add	a, r6
      008ED2 FE               [12] 1897 	mov	r6,a
      008ED3 E5 36            [12] 1898 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008ED5 3F               [12] 1899 	addc	a, r7
      008ED6 EE               [12] 1900 	mov	a,r6
      008ED7 30 E0 5A         [24] 1901 	jnb	acc.0,00115$
                                   1902 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008EDA AE 39            [24] 1903 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008EDC 7F 00            [12] 1904 	mov	r7,#0x00
      008EDE EE               [12] 1905 	mov	a,r6
      008EDF 24 FF            [12] 1906 	add	a,#0xff
      008EE1 FC               [12] 1907 	mov	r4,a
      008EE2 EF               [12] 1908 	mov	a,r7
      008EE3 34 FF            [12] 1909 	addc	a,#0xff
      008EE5 FD               [12] 1910 	mov	r5,a
      008EE6 EC               [12] 1911 	mov	a,r4
      008EE7 28               [12] 1912 	add	a, r0
      008EE8 F5 82            [12] 1913 	mov	dpl,a
      008EEA ED               [12] 1914 	mov	a,r5
      008EEB 39               [12] 1915 	addc	a, r1
      008EEC F5 83            [12] 1916 	mov	dph,a
      008EEE E0               [24] 1917 	movx	a,@dptr
      008EEF FC               [12] 1918 	mov	r4,a
      008EF0 7D 00            [12] 1919 	mov	r5,#0x00
      008EF2 E5 39            [12] 1920 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008EF4 2A               [12] 1921 	add	a, r2
      008EF5 FA               [12] 1922 	mov	r2,a
      008EF6 E4               [12] 1923 	clr	a
      008EF7 3B               [12] 1924 	addc	a, r3
      008EF8 FB               [12] 1925 	mov	r3,a
      008EF9 C0 00            [24] 1926 	push	ar0
      008EFB C0 01            [24] 1927 	push	ar1
      008EFD 8B 01            [24] 1928 	mov	ar1,r3
      008EFF 7B 00            [12] 1929 	mov	r3,#0x00
      008F01 8A 82            [24] 1930 	mov	dpl, r2
      008F03 89 83            [24] 1931 	mov	dph, r1
      008F05 8B F0            [24] 1932 	mov	b, r3
      008F07 12 40 7C         [24] 1933 	lcall	_eeprom_read_byte
      008F0A AB 82            [24] 1934 	mov	r3, dpl
      008F0C 7A 00            [12] 1935 	mov	r2,#0x00
      008F0E EB               [12] 1936 	mov	a,r3
      008F0F 12 43 75         [24] 1937 	lcall	_ak820_outline_0152
                                   1938 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008F12 BD 00 05         [24] 1939 	cjne	r5,#0x00,00212$
      008F15 BC 7C 02         [24] 1940 	cjne	r4,#0x7c,00212$
      008F18 80 06            [24] 1941 	sjmp	00213$
      008F1A                       1942 00212$:
      008F1A D0 01            [24] 1943 	pop	ar1
      008F1C D0 00            [24] 1944 	pop	ar0
      008F1E 80 0D            [24] 1945 	sjmp	00113$
      008F20                       1946 00213$:
      008F20 D0 01            [24] 1947 	pop	ar1
      008F22 D0 00            [24] 1948 	pop	ar0
                                   1949 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008F24 1E               [12] 1950 	dec	r6
      008F25 BE FF 01         [24] 1951 	cjne	r6,#0xff,00214$
      008F28 1F               [12] 1952 	dec	r7
      008F29                       1953 00214$:
      008F29 EE               [12] 1954 	mov	a,r6
      008F2A 12 93 BD         [24] 1955 	lcall	_ak820_outline_0137
      008F2D                       1956 00113$:
                                   1957 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008F2D E5 39            [12] 1958 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F2F 14               [12] 1959 	dec	a
      008F30 90 0B 75         [24] 1960 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_436
      008F33 F0               [24] 1961 	movx	@dptr,a
      008F34                       1962 00115$:
                                   1963 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F34 90 0B 74         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_436
      008F37 E0               [24] 1965 	movx	a,@dptr
      008F38 90 0B 76         [24] 1966 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_443
      008F3B F0               [24] 1967 	movx	@dptr,a
      008F3C                       1968 00122$:
      008F3C 90 0B 76         [24] 1969 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_443
      008F3F E0               [24] 1970 	movx	a,@dptr
      008F40 FF               [12] 1971 	mov	r7,a
      008F41 90 0B 75         [24] 1972 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_436
      008F44 E0               [24] 1973 	movx	a,@dptr
      008F45 FE               [12] 1974 	mov	r6,a
      008F46 C3               [12] 1975 	clr	c
      008F47 EF               [12] 1976 	mov	a,r7
      008F48 9E               [12] 1977 	subb	a,r6
      008F49 50 48            [24] 1978 	jnc	00120$
                                   1979 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008F4B EF               [12] 1980 	mov	a,r7
      008F4C 28               [12] 1981 	add	a, r0
      008F4D FD               [12] 1982 	mov	r5,a
      008F4E E4               [12] 1983 	clr	a
      008F4F 39               [12] 1984 	addc	a, r1
      008F50 12 49 85         [24] 1985 	lcall	_ak820_outline_0069
      008F53 FC               [12] 1986 	mov	r4,a
      008F54 7B 00            [12] 1987 	mov	r3,#0x00
      008F56 8C 36            [24] 1988 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008F58 8B 35            [24] 1989 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008F5A 8F 02            [24] 1990 	mov	ar2,r7
      008F5C 7F 00            [12] 1991 	mov	r7,#0x00
      008F5E 74 01            [12] 1992 	mov	a,#0x01
      008F60 2A               [12] 1993 	add	a, r2
      008F61 FB               [12] 1994 	mov	r3,a
      008F62 E4               [12] 1995 	clr	a
      008F63 3F               [12] 1996 	addc	a, r7
      008F64 FC               [12] 1997 	mov	r4,a
      008F65 EB               [12] 1998 	mov	a,r3
      008F66 28               [12] 1999 	add	a, r0
      008F67 F5 82            [12] 2000 	mov	dpl,a
      008F69 EC               [12] 2001 	mov	a,r4
      008F6A 39               [12] 2002 	addc	a, r1
      008F6B F5 83            [12] 2003 	mov	dph,a
      008F6D E0               [24] 2004 	movx	a,@dptr
      008F6E FC               [12] 2005 	mov	r4,a
      008F6F 7B 00            [12] 2006 	mov	r3,#0x00
      008F71 E5 36            [12] 2007 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F73 42 03            [12] 2008 	orl	ar3,a
                                   2009 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008F75 BC 00 12         [24] 2010 	cjne	r4,#0x00,00123$
      008F78 BB 7C 0F         [24] 2011 	cjne	r3,#0x7c,00123$
                                   2012 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008F7B 12 38 A5         [24] 2013 	lcall	_ak820_outline_0141
      008F7E 74 FF            [12] 2014 	mov	a,#0xff
      008F80 F0               [24] 2015 	movx	@dptr,a
                                   2016 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008F81 0A               [12] 2017 	inc	r2
      008F82 BA 00 01         [24] 2018 	cjne	r2,#0x00,00218$
      008F85 0F               [12] 2019 	inc	r7
      008F86                       2020 00218$:
      008F86 EA               [12] 2021 	mov	a,r2
      008F87 12 93 BD         [24] 2022 	lcall	_ak820_outline_0137
      008F8A                       2023 00123$:
                                   2024 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F8A 90 0B 76         [24] 2025 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_443
      008F8D E0               [24] 2026 	movx	a,@dptr
      008F8E 24 02            [12] 2027 	add	a,#0x02
      008F90 F0               [24] 2028 	movx	@dptr,a
      008F91 80 A9            [24] 2029 	sjmp	00122$
      008F93                       2030 00120$:
                                   2031 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008F93 90 0B 72         [24] 2032 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008F96 12 38 3E         [24] 2033 	lcall	_ak820_outline_0055
      008F99 74 40            [12] 2034 	mov	a,#0x40
      008F9B 12 43 69         [24] 2035 	lcall	_ak820_outline_0144
      008F9E 90 05 8E         [24] 2036 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008FA1 12 4E D3         [24] 2037 	lcall	_ak820_outline_0062
      008FA4 E4               [12] 2038 	clr	a
      008FA5 A3               [24] 2039 	inc	dptr
      008FA6 F0               [24] 2040 	movx	@dptr,a
      008FA7 90 05 91         [24] 2041 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008FAA E5 37            [12] 2042 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008FAC F0               [24] 2043 	movx	@dptr,a
      008FAD E5 38            [12] 2044 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008FAF A3               [24] 2045 	inc	dptr
      008FB0 F0               [24] 2046 	movx	@dptr,a
      008FB1 12 38 BF         [24] 2047 	lcall	_ak820_outline_0160
                                   2048 ;	quantum/dynamic_keymap.c:584: }
      008FB4 02 41 43         [24] 2049 	ljmp	_ak820_eeprom_write_block_xdata
                                   2050 ;------------------------------------------------------------
                                   2051 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2052 ;------------------------------------------------------------
                                   2053 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2054 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2055 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_447'
                                   2056 ;------------------------------------------------------------
                                   2057 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2058 ;	-----------------------------------------
                                   2059 ;	 function keycode_at_keymap_location
                                   2060 ;	-----------------------------------------
      008FB7                       2061 _keycode_at_keymap_location:
      008FB7 E5 82            [12] 2062 	mov	a,dpl
      008FB9 90 0B 79         [24] 2063 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_447
      008FBC F0               [24] 2064 	movx	@dptr,a
                                   2065 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008FBD E0               [24] 2066 	movx	a,@dptr
      008FBE FF               [12] 2067 	mov	r7,a
      008FBF BF 06 00         [24] 2068 	cjne	r7,#0x06,00128$
      008FC2                       2069 00128$:
      008FC2 50 23            [24] 2070 	jnc	00102$
      008FC4 90 0B 77         [24] 2071 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008FC7 E0               [24] 2072 	movx	a,@dptr
      008FC8 FE               [12] 2073 	mov	r6,a
      008FC9 BE 10 00         [24] 2074 	cjne	r6,#0x10,00130$
      008FCC                       2075 00130$:
      008FCC 50 19            [24] 2076 	jnc	00102$
      008FCE 90 0B 78         [24] 2077 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008FD1 E0               [24] 2078 	movx	a,@dptr
      008FD2 FD               [12] 2079 	mov	r5,a
      008FD3 BD 08 00         [24] 2080 	cjne	r5,#0x08,00132$
      008FD6                       2081 00132$:
      008FD6 50 0F            [24] 2082 	jnc	00102$
                                   2083 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008FD8 90 0B 2B         [24] 2084 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008FDB EE               [12] 2085 	mov	a,r6
      008FDC F0               [24] 2086 	movx	@dptr,a
      008FDD 90 0B 2C         [24] 2087 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008FE0 ED               [12] 2088 	mov	a,r5
      008FE1 F0               [24] 2089 	movx	@dptr,a
      008FE2 8F 82            [24] 2090 	mov	dpl, r7
      008FE4 02 89 5E         [24] 2091 	ljmp	_dynamic_keymap_get_keycode
      008FE7                       2092 00102$:
                                   2093 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008FE7 90 00 00         [24] 2094 	mov	dptr,#0x0000
                                   2095 ;	quantum/dynamic_keymap.c:591: }
      008FEA 22               [24] 2096 	ret
                                   2097 ;------------------------------------------------------------
                                   2098 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2099 ;------------------------------------------------------------
                                   2100 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2101 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2102 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_451'
                                   2103 ;------------------------------------------------------------
                                   2104 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2105 ;	-----------------------------------------
                                   2106 ;	 function keycode_at_encodermap_location
                                   2107 ;	-----------------------------------------
      008FEB                       2108 _keycode_at_encodermap_location:
      008FEB E5 82            [12] 2109 	mov	a,dpl
      008FED 90 0B 7C         [24] 2110 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_451
      008FF0 F0               [24] 2111 	movx	@dptr,a
                                   2112 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008FF1 E0               [24] 2113 	movx	a,@dptr
      008FF2 FF               [12] 2114 	mov	r7,a
      008FF3 BF 06 00         [24] 2115 	cjne	r7,#0x06,00120$
      008FF6                       2116 00120$:
      008FF6 50 1E            [24] 2117 	jnc	00102$
      008FF8 90 0B 7A         [24] 2118 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008FFB E0               [24] 2119 	movx	a,@dptr
      008FFC FE               [12] 2120 	mov	r6,a
      008FFD BE 01 00         [24] 2121 	cjne	r6,#0x01,00122$
      009000                       2122 00122$:
      009000 50 14            [24] 2123 	jnc	00102$
                                   2124 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      009002 90 0B 7B         [24] 2125 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      009005 E0               [24] 2126 	movx	a,@dptr
      009006 FE               [12] 2127 	mov	r6,a
      009007 90 0B 35         [24] 2128 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00900A E4               [12] 2129 	clr	a
      00900B F0               [24] 2130 	movx	@dptr,a
      00900C 90 0B 36         [24] 2131 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00900F EE               [12] 2132 	mov	a,r6
      009010 F0               [24] 2133 	movx	@dptr,a
      009011 8F 82            [24] 2134 	mov	dpl, r7
      009013 02 8A 1B         [24] 2135 	ljmp	_dynamic_keymap_get_encoder
      009016                       2136 00102$:
                                   2137 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      009016 90 00 00         [24] 2138 	mov	dptr,#0x0000
                                   2139 ;	quantum/dynamic_keymap.c:599: }
      009019 22               [24] 2140 	ret
                                   2141 ;------------------------------------------------------------
                                   2142 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2143 ;------------------------------------------------------------
                                   2144 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2145 ;	-----------------------------------------
                                   2146 ;	 function dynamic_keymap_macro_get_count
                                   2147 ;	-----------------------------------------
      00901A                       2148 _dynamic_keymap_macro_get_count:
                                   2149 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      00901A 75 82 10         [24] 2150 	mov	dpl, #0x10
                                   2151 ;	quantum/dynamic_keymap.c:604: }
      00901D 22               [24] 2152 	ret
                                   2153 ;------------------------------------------------------------
                                   2154 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2155 ;------------------------------------------------------------
                                   2156 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2157 ;	-----------------------------------------
                                   2158 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2159 ;	-----------------------------------------
      00901E                       2160 _dynamic_keymap_macro_get_buffer_size:
                                   2161 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      00901E 90 20 00         [24] 2162 	mov	dptr,#0x2000
                                   2163 ;	quantum/dynamic_keymap.c:608: }
      009021 22               [24] 2164 	ret
                                   2165 ;------------------------------------------------------------
                                   2166 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2167 ;------------------------------------------------------------
                                   2168 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2169 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2170 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2171 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_459'
                                   2172 ;------------------------------------------------------------
                                   2173 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2174 ;	-----------------------------------------
                                   2175 ;	 function dynamic_keymap_macro_get_buffer
                                   2176 ;	-----------------------------------------
      009022                       2177 _dynamic_keymap_macro_get_buffer:
      009022 12 38 79         [24] 2178 	lcall	_ak820_outline_0113
      009025 90 0B 82         [24] 2179 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_459
      009028 12 38 7E         [24] 2180 	lcall	_ak820_outline_0114
                                   2181 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      00902B 12 2B 2B         [24] 2182 	lcall	_ak820_macro_length
      00902E 12 43 64         [24] 2183 	lcall	_ak820_outline_0132
      009031 90 0B 82         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_459
      009034 12 38 55         [24] 2185 	lcall	_ak820_outline_0063
      009037 90 0B 7D         [24] 2186 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00903A E0               [24] 2187 	movx	a,@dptr
      00903B F5 3A            [12] 2188 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      00903D A3               [24] 2189 	inc	dptr
      00903E E0               [24] 2190 	movx	a,@dptr
      00903F F5 3B            [12] 2191 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      009041 90 0B 7F         [24] 2192 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      009044 12 38 73         [24] 2193 	lcall	_ak820_outline_0107
      009047 A3               [24] 2194 	inc	dptr
      009048 E0               [24] 2195 	movx	a,@dptr
      009049 FB               [12] 2196 	mov	r3,a
      00904A 90 0B 5A         [24] 2197 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00904D 12 4E D3         [24] 2198 	lcall	_ak820_outline_0062
      009050 90 0B 5C         [24] 2199 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009053 12 38 61         [24] 2200 	lcall	_ak820_outline_0078
      009056 90 0B 5E         [24] 2201 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009059 E5 3A            [12] 2202 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      00905B F0               [24] 2203 	movx	@dptr,a
      00905C E5 3B            [12] 2204 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      00905E A3               [24] 2205 	inc	dptr
      00905F F0               [24] 2206 	movx	@dptr,a
      009060 90 0B 60         [24] 2207 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009063 E8               [12] 2208 	mov	a,r0
      009064 F0               [24] 2209 	movx	@dptr,a
      009065 E9               [12] 2210 	mov	a,r1
      009066 A3               [24] 2211 	inc	dptr
      009067 12 49 C4         [24] 2212 	lcall	_ak820_outline_0195
      00906A 90 08 00         [24] 2213 	mov	dptr,#0x0800
                                   2214 ;	quantum/dynamic_keymap.c:635: }
      00906D 02 8D 35         [24] 2215 	ljmp	_ak820_dynamic_read_buffer
                                   2216 ;------------------------------------------------------------
                                   2217 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2218 ;------------------------------------------------------------
                                   2219 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2220 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2221 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_461'
                                   2222 ;------------------------------------------------------------
                                   2223 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2224 ;	-----------------------------------------
                                   2225 ;	 function dynamic_keymap_macro_set_buffer
                                   2226 ;	-----------------------------------------
      009070                       2227 _dynamic_keymap_macro_set_buffer:
      009070 12 38 79         [24] 2228 	lcall	_ak820_outline_0113
      009073 90 0B 89         [24] 2229 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_461
      009076 12 38 7E         [24] 2230 	lcall	_ak820_outline_0114
                                   2231 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009079 90 0B 89         [24] 2232 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_461
      00907C 12 38 3E         [24] 2233 	lcall	_ak820_outline_0055
      00907F 90 0B 84         [24] 2234 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      009082 12 38 55         [24] 2235 	lcall	_ak820_outline_0063
      009085 90 0B 86         [24] 2236 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009088 12 55 5B         [24] 2237 	lcall	_ak820_outline_0096
      00908B 90 05 14         [24] 2238 	mov	dptr,#_ak820_macro_write_PARM_2
      00908E 12 38 61         [24] 2239 	lcall	_ak820_outline_0078
      009091 90 05 16         [24] 2240 	mov	dptr,#_ak820_macro_write_PARM_3
      009094 12 4E FB         [24] 2241 	lcall	_ak820_outline_0145
      009097 EB               [12] 2242 	mov	a,r3
      009098 A3               [24] 2243 	inc	dptr
      009099 12 43 46         [24] 2244 	lcall	_ak820_outline_0077
                                   2245 ;	quantum/dynamic_keymap.c:640: }
      00909C 02 2B 45         [24] 2246 	ljmp	_ak820_macro_write
                                   2247 ;------------------------------------------------------------
                                   2248 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2249 ;------------------------------------------------------------
                                   2250 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2251 ;	-----------------------------------------
                                   2252 ;	 function dynamic_keymap_macro_reset
                                   2253 ;	-----------------------------------------
      00909F                       2254 _dynamic_keymap_macro_reset:
                                   2255 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2256 ;	quantum/dynamic_keymap.c:666: }
      00909F 02 2E 64         [24] 2257 	ljmp	_ak820_macro_reset
                                   2258 ;------------------------------------------------------------
                                   2259 ;Allocation info for local variables in function 'decode_keycode'
                                   2260 ;------------------------------------------------------------
                                   2261 ;kc            Allocated with name '_decode_keycode_kc_10000_465'
                                   2262 ;------------------------------------------------------------
                                   2263 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2264 ;	-----------------------------------------
                                   2265 ;	 function decode_keycode
                                   2266 ;	-----------------------------------------
      0090A2                       2267 _decode_keycode:
      0090A2 12 38 79         [24] 2268 	lcall	_ak820_outline_0113
      0090A5 90 0B 8B         [24] 2269 	mov	dptr,#_decode_keycode_kc_10000_465
      0090A8 12 38 7E         [24] 2270 	lcall	_ak820_outline_0114
                                   2271 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      0090AB 90 0B 8B         [24] 2272 	mov	dptr,#_decode_keycode_kc_10000_465
      0090AE 12 4E 82         [24] 2273 	lcall	_ak820_outline_0009
      0090B1 C3               [12] 2274 	clr	c
      0090B2 E4               [12] 2275 	clr	a
      0090B3 9C               [12] 2276 	subb	a,r4
      0090B4 74 FF            [12] 2277 	mov	a,#0xff
      0090B6 9D               [12] 2278 	subb	a,r5
      0090B7 50 08            [24] 2279 	jnc	00102$
                                   2280 ;	free result
                                   2281 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      0090B9 8C 05            [24] 2282 	mov	ar5,r4
      0090BB 7C 00            [12] 2283 	mov	r4,#0x00
      0090BD 12 38 A0         [24] 2284 	lcall	_ak820_outline_0133
      0090C0 22               [24] 2285 	ret
      0090C1                       2286 00102$:
                                   2287 ;	quantum/dynamic_keymap.c:672: return kc;
      0090C1 12 38 8A         [24] 2288 	lcall	_ak820_outline_0124
                                   2289 ;	quantum/dynamic_keymap.c:673: }
      0090C4 22               [24] 2290 	ret
                                   2291 ;------------------------------------------------------------
                                   2292 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2293 ;------------------------------------------------------------
                                   2294 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_468'
                                   2295 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_469'
                                   2296 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_474'
                                   2297 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_475'
                                   2298 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_481'
                                   2299 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_499'
                                   2300 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_503'
                                   2301 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_503'
                                   2302 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_505'
                                   2303 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_507'
                                   2304 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_511'
                                   2305 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_513'
                                   2306 ;------------------------------------------------------------
                                   2307 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2308 ;	-----------------------------------------
                                   2309 ;	 function dynamic_keymap_macro_send
                                   2310 ;	-----------------------------------------
      0090C5                       2311 _dynamic_keymap_macro_send:
      0090C5 E5 82            [12] 2312 	mov	a,dpl
      0090C7 90 0B 8D         [24] 2313 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_468
      0090CA F0               [24] 2314 	movx	@dptr,a
                                   2315 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0090CB 90 0B 8E         [24] 2316 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_469
      0090CE E0               [24] 2317 	movx	a,@dptr
      0090CF 60 01            [24] 2318 	jz	00102$
      0090D1 22               [24] 2319 	ret
      0090D2                       2320 00102$:
                                   2321 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0090D2 90 0B 8D         [24] 2322 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_468
      0090D5 E0               [24] 2323 	movx	a,@dptr
      0090D6 FF               [12] 2324 	mov	r7,a
      0090D7 BF 10 00         [24] 2325 	cjne	r7,#0x10,00422$
      0090DA                       2326 00422$:
      0090DA 40 01            [24] 2327 	jc	00104$
                                   2328 ;	quantum/dynamic_keymap.c:683: return;
      0090DC 22               [24] 2329 	ret
      0090DD                       2330 00104$:
                                   2331 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      0090DD C0 07            [24] 2332 	push	ar7
      0090DF 12 2A F2         [24] 2333 	lcall	_ak820_macro_ready
      0090E2 E5 82            [12] 2334 	mov	a, dpl
      0090E4 D0 07            [24] 2335 	pop	ar7
      0090E6 70 01            [24] 2336 	jnz	00106$
      0090E8 22               [24] 2337 	ret
      0090E9                       2338 00106$:
                                   2339 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0090E9 90 0B 8F         [24] 2340 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      0090EC E4               [12] 2341 	clr	a
      0090ED F0               [24] 2342 	movx	@dptr,a
      0090EE 74 08            [12] 2343 	mov	a,#0x08
      0090F0 A3               [24] 2344 	inc	dptr
      0090F1 F0               [24] 2345 	movx	@dptr,a
                                   2346 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0090F2 C0 07            [24] 2347 	push	ar7
      0090F4 12 2B 2B         [24] 2348 	lcall	_ak820_macro_length
      0090F7 AD 82            [24] 2349 	mov	r5, dpl
      0090F9 AE 83            [24] 2350 	mov	r6, dph
      0090FB D0 07            [24] 2351 	pop	ar7
      0090FD 74 08            [12] 2352 	mov	a,#0x08
      0090FF 2E               [12] 2353 	add	a, r6
      009100 FE               [12] 2354 	mov	r6,a
                                   2355 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      009101 7B 00            [12] 2356 	mov	r3,#0x00
      009103 7C 08            [12] 2357 	mov	r4,#0x08
      009105                       2358 00111$:
      009105 EF               [12] 2359 	mov	a,r7
      009106 60 31            [24] 2360 	jz	00113$
                                   2361 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      009108 EB               [12] 2362 	mov	a,r3
      009109 B5 05 05         [24] 2363 	cjne	a,ar5,00108$
      00910C EC               [12] 2364 	mov	a,r4
      00910D B5 06 01         [24] 2365 	cjne	a,ar6,00108$
                                   2366 ;	quantum/dynamic_keymap.c:717: return;
      009110 22               [24] 2367 	ret
      009111                       2368 00108$:
                                   2369 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      009111 8B 01            [24] 2370 	mov	ar1,r3
      009113 8C 02            [24] 2371 	mov	ar2,r4
      009115 8A 00            [24] 2372 	mov	ar0,r2
      009117 7A 00            [12] 2373 	mov	r2,#0x00
      009119 89 82            [24] 2374 	mov	dpl, r1
      00911B 88 83            [24] 2375 	mov	dph, r0
      00911D 8A F0            [24] 2376 	mov	b, r2
      00911F 12 40 7C         [24] 2377 	lcall	_eeprom_read_byte
      009122 E5 82            [12] 2378 	mov	a, dpl
      009124 70 06            [24] 2379 	jnz	00110$
                                   2380 ;	quantum/dynamic_keymap.c:720: --id;
      009126 1F               [12] 2381 	dec	r7
      009127 90 0B 8D         [24] 2382 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_468
      00912A EF               [12] 2383 	mov	a,r7
      00912B F0               [24] 2384 	movx	@dptr,a
      00912C                       2385 00110$:
                                   2386 ;	quantum/dynamic_keymap.c:722: ++p;
      00912C 0B               [12] 2387 	inc	r3
      00912D BB 00 01         [24] 2388 	cjne	r3,#0x00,00429$
      009130 0C               [12] 2389 	inc	r4
      009131                       2390 00429$:
      009131 90 0B 8F         [24] 2391 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      009134 12 38 6D         [24] 2392 	lcall	_ak820_outline_0099
      009137 80 CC            [24] 2393 	sjmp	00111$
      009139                       2394 00113$:
                                   2395 ;	quantum/dynamic_keymap.c:728: sending = true;
      009139 90 0B 8E         [24] 2396 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_469
      00913C 74 01            [12] 2397 	mov	a,#0x01
      00913E F0               [24] 2398 	movx	@dptr,a
                                   2399 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      00913F 12 93 D5         [24] 2400 	lcall	_ak820_outline_0172
      009142 90 09 D7         [24] 2401 	mov	dptr,#_ak820_macro_cancelled
      009145 F0               [24] 2402 	movx	@dptr,a
                                   2403 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      009146 90 0B 91         [24] 2404 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      009149 F0               [24] 2405 	movx	@dptr,a
      00914A 90 0B 92         [24] 2406 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      00914D F0               [24] 2407 	movx	@dptr,a
      00914E 90 0B 93         [24] 2408 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0002)
      009151 F0               [24] 2409 	movx	@dptr,a
      009152 90 0B 94         [24] 2410 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0003)
      009155 F0               [24] 2411 	movx	@dptr,a
                                   2412 ;	quantum/dynamic_keymap.c:738: while (p < end
      009156                       2413 00167$:
                                   2414 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      009156 90 0B 8F         [24] 2415 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      009159 E0               [24] 2416 	movx	a,@dptr
      00915A FC               [12] 2417 	mov	r4,a
      00915B A3               [24] 2418 	inc	dptr
      00915C E0               [24] 2419 	movx	a,@dptr
      00915D FF               [12] 2420 	mov	r7,a
      00915E C3               [12] 2421 	clr	c
      00915F EC               [12] 2422 	mov	a,r4
      009160 9D               [12] 2423 	subb	a,r5
      009161 EF               [12] 2424 	mov	a,r7
      009162 9E               [12] 2425 	subb	a,r6
      009163 40 02            [24] 2426 	jc	00430$
      009165 61 6A            [12] 2427 	ajmp	00169$
      009167                       2428 00430$:
      009167 90 09 D7         [24] 2429 	mov	dptr,#_ak820_macro_cancelled
      00916A E0               [24] 2430 	movx	a,@dptr
      00916B 60 02            [24] 2431 	jz	00431$
      00916D 61 6A            [12] 2432 	ajmp	00169$
      00916F                       2433 00431$:
                                   2434 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00916F 8C 02            [24] 2435 	mov	ar2,r4
      009171 8F 03            [24] 2436 	mov	ar3,r7
      009173 90 0B 8F         [24] 2437 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      009176 74 01            [12] 2438 	mov	a,#0x01
      009178 2C               [12] 2439 	add	a, r4
      009179 F0               [24] 2440 	movx	@dptr,a
      00917A E4               [12] 2441 	clr	a
      00917B 3F               [12] 2442 	addc	a, r7
      00917C A3               [24] 2443 	inc	dptr
      00917D F0               [24] 2444 	movx	@dptr,a
      00917E 7F 00            [12] 2445 	mov	r7,#0x00
      009180 12 38 B5         [24] 2446 	lcall	_ak820_outline_0154
      009183 8F F0            [24] 2447 	mov	b, r7
      009185 12 40 7C         [24] 2448 	lcall	_eeprom_read_byte
      009188 AF 82            [24] 2449 	mov	r7, dpl
      00918A 90 0B 91         [24] 2450 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      00918D EF               [12] 2451 	mov	a,r7
      00918E F0               [24] 2452 	movx	@dptr,a
                                   2453 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      00918F 90 0B 92         [24] 2454 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      009192 E4               [12] 2455 	clr	a
      009193 F0               [24] 2456 	movx	@dptr,a
                                   2457 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      009194 90 0B 91         [24] 2458 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      009197 E0               [24] 2459 	movx	a,@dptr
      009198 70 02            [24] 2460 	jnz	00432$
      00919A 61 6A            [12] 2461 	ajmp	00169$
      00919C                       2462 00432$:
                                   2463 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      00919C 90 0B 91         [24] 2464 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      00919F E0               [24] 2465 	movx	a,@dptr
      0091A0 FF               [12] 2466 	mov	r7,a
      0091A1 BF 01 02         [24] 2467 	cjne	r7,#0x01,00433$
      0091A4 80 02            [24] 2468 	sjmp	00434$
      0091A6                       2469 00433$:
      0091A6 61 4D            [12] 2470 	ajmp	00164$
      0091A8                       2471 00434$:
                                   2472 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091A8 12 93 72         [24] 2473 	lcall	_ak820_outline_0000
      0091AB 12 40 7C         [24] 2474 	lcall	_eeprom_read_byte
      0091AE AF 82            [24] 2475 	mov	r7, dpl
      0091B0 90 0B 92         [24] 2476 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      0091B3 EF               [12] 2477 	mov	a,r7
      0091B4 F0               [24] 2478 	movx	@dptr,a
                                   2479 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      0091B5 EF               [12] 2480 	mov	a,r7
      0091B6 70 02            [24] 2481 	jnz	00435$
      0091B8 61 6A            [12] 2482 	ajmp	00169$
      0091BA                       2483 00435$:
                                   2484 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      0091BA 12 93 A3         [24] 2485 	lcall	_ak820_outline_0098
      0091BD BF 01 02         [24] 2486 	cjne	r7,#0x01,00436$
      0091C0 80 12            [24] 2487 	sjmp	00151$
      0091C2                       2488 00436$:
      0091C2 12 93 A3         [24] 2489 	lcall	_ak820_outline_0098
      0091C5 BF 02 02         [24] 2490 	cjne	r7,#0x02,00437$
      0091C8 80 0A            [24] 2491 	sjmp	00151$
      0091CA                       2492 00437$:
      0091CA 12 93 A3         [24] 2493 	lcall	_ak820_outline_0098
      0091CD BF 03 02         [24] 2494 	cjne	r7,#0x03,00438$
      0091D0 80 02            [24] 2495 	sjmp	00439$
      0091D2                       2496 00438$:
      0091D2 41 33            [12] 2497 	ajmp	00152$
      0091D4                       2498 00439$:
      0091D4                       2499 00151$:
                                   2500 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091D4 12 93 72         [24] 2501 	lcall	_ak820_outline_0000
      0091D7 12 40 7C         [24] 2502 	lcall	_eeprom_read_byte
      0091DA 12 93 ED         [24] 2503 	lcall	_ak820_outline_0190
                                   2504 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      0091DD 70 02            [24] 2505 	jnz	00440$
      0091DF 21 56            [12] 2506 	ajmp	00167$
      0091E1                       2507 00440$:
                                   2508 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0091E1 12 93 A3         [24] 2509 	lcall	_ak820_outline_0098
      0091E4 BF 01 03         [24] 2510 	cjne	r7,#0x01,00441$
      0091E7 D3               [12] 2511 	setb	c
      0091E8 80 01            [24] 2512 	sjmp	00442$
      0091EA                       2513 00441$:
      0091EA C3               [12] 2514 	clr	c
      0091EB                       2515 00442$:
      0091EB 92 25            [24] 2516 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0091ED 90 09 D6         [24] 2517 	mov	dptr,#_ak820_macro_primitive
      0091F0 B3               [12] 2518 	cpl	c
      0091F1 E4               [12] 2519 	clr	a
      0091F2 33               [12] 2520 	rlc	a
      0091F3 F0               [24] 2521 	movx	@dptr,a
                                   2522 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0091F4 12 93 A3         [24] 2523 	lcall	_ak820_outline_0098
      0091F7 BF 01 10         [24] 2524 	cjne	r7,#0x01,00122$
      0091FA 12 93 CE         [24] 2525 	lcall	_ak820_outline_0162
      0091FD C0 06            [24] 2526 	push	ar6
      0091FF C0 05            [24] 2527 	push	ar5
      009201 12 7B D5         [24] 2528 	lcall	_tap_code
      009204 D0 05            [24] 2529 	pop	ar5
      009206 D0 06            [24] 2530 	pop	ar6
      009208 80 24            [24] 2531 	sjmp	00123$
      00920A                       2532 00122$:
                                   2533 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      00920A 12 93 A3         [24] 2534 	lcall	_ak820_outline_0098
      00920D BF 02 10         [24] 2535 	cjne	r7,#0x02,00119$
      009210 12 93 CE         [24] 2536 	lcall	_ak820_outline_0162
      009213 C0 06            [24] 2537 	push	ar6
      009215 C0 05            [24] 2538 	push	ar5
      009217 12 7A D1         [24] 2539 	lcall	_register_code
      00921A D0 05            [24] 2540 	pop	ar5
      00921C D0 06            [24] 2541 	pop	ar6
      00921E 80 0E            [24] 2542 	sjmp	00123$
      009220                       2543 00119$:
                                   2544 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      009220 12 93 CE         [24] 2545 	lcall	_ak820_outline_0162
      009223 C0 06            [24] 2546 	push	ar6
      009225 C0 05            [24] 2547 	push	ar5
      009227 12 7B 3E         [24] 2548 	lcall	_unregister_code
      00922A D0 05            [24] 2549 	pop	ar5
      00922C D0 06            [24] 2550 	pop	ar6
      00922E                       2551 00123$:
                                   2552 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      00922E 12 93 D5         [24] 2553 	lcall	_ak820_outline_0172
      009231 21 56            [12] 2554 	ajmp	00167$
      009233                       2555 00152$:
                                   2556 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      009233 12 93 A3         [24] 2557 	lcall	_ak820_outline_0098
      009236 BF 05 02         [24] 2558 	cjne	r7,#0x05,00447$
      009239 80 12            [24] 2559 	sjmp	00146$
      00923B                       2560 00447$:
      00923B 12 93 A3         [24] 2561 	lcall	_ak820_outline_0098
      00923E BF 06 02         [24] 2562 	cjne	r7,#0x06,00448$
      009241 80 0A            [24] 2563 	sjmp	00146$
      009243                       2564 00448$:
      009243 12 93 A3         [24] 2565 	lcall	_ak820_outline_0098
      009246 BF 07 02         [24] 2566 	cjne	r7,#0x07,00449$
      009249 80 02            [24] 2567 	sjmp	00450$
      00924B                       2568 00449$:
      00924B 41 EF            [12] 2569 	ajmp	00147$
      00924D                       2570 00450$:
      00924D                       2571 00146$:
                                   2572 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00924D 12 93 72         [24] 2573 	lcall	_ak820_outline_0000
      009250 12 40 7C         [24] 2574 	lcall	_eeprom_read_byte
      009253 12 93 ED         [24] 2575 	lcall	_ak820_outline_0190
                                   2576 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      009256 70 02            [24] 2577 	jnz	00451$
      009258 21 56            [12] 2578 	ajmp	00167$
      00925A                       2579 00451$:
                                   2580 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00925A 12 93 72         [24] 2581 	lcall	_ak820_outline_0000
      00925D 12 40 7C         [24] 2582 	lcall	_eeprom_read_byte
      009260 AF 82            [24] 2583 	mov	r7, dpl
      009262 90 0B 94         [24] 2584 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0003)
      009265 EF               [12] 2585 	mov	a,r7
      009266 F0               [24] 2586 	movx	@dptr,a
                                   2587 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      009267 EF               [12] 2588 	mov	a,r7
      009268 70 02            [24] 2589 	jnz	00452$
      00926A 21 56            [12] 2590 	ajmp	00167$
      00926C                       2591 00452$:
                                   2592 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      00926C 90 0B 93         [24] 2593 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0002)
      00926F E0               [24] 2594 	movx	a,@dptr
      009270 FF               [12] 2595 	mov	r7,a
      009271 90 0B 94         [24] 2596 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0003)
      009274 E0               [24] 2597 	movx	a,@dptr
      009275 FB               [12] 2598 	mov	r3,a
      009276 E4               [12] 2599 	clr	a
      009277 FC               [12] 2600 	mov	r4,a
      009278 FA               [12] 2601 	mov	r2,a
      009279 EF               [12] 2602 	mov	a,r7
      00927A 42 04            [12] 2603 	orl	ar4,a
      00927C EA               [12] 2604 	mov	a,r2
      00927D 42 03            [12] 2605 	orl	ar3,a
                                   2606 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      00927F 12 43 8B         [24] 2607 	lcall	_ak820_outline_0191
      009282 C0 06            [24] 2608 	push	ar6
      009284 C0 05            [24] 2609 	push	ar5
      009286 11 A2            [12] 2610 	acall	_decode_keycode
      009288 AC 82            [24] 2611 	mov	r4, dpl
      00928A AF 83            [24] 2612 	mov	r7, dph
      00928C D0 05            [24] 2613 	pop	ar5
      00928E D0 06            [24] 2614 	pop	ar6
                                   2615 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      009290 90 0B 92         [24] 2616 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      009293 E0               [24] 2617 	movx	a,@dptr
      009294 FB               [12] 2618 	mov	r3,a
      009295 BB 05 03         [24] 2619 	cjne	r3,#0x05,00453$
      009298 D3               [12] 2620 	setb	c
      009299 80 01            [24] 2621 	sjmp	00454$
      00929B                       2622 00453$:
      00929B C3               [12] 2623 	clr	c
      00929C                       2624 00454$:
      00929C 92 25            [24] 2625 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00929E 90 09 D6         [24] 2626 	mov	dptr,#_ak820_macro_primitive
      0092A1 B3               [12] 2627 	cpl	c
      0092A2 E4               [12] 2628 	clr	a
      0092A3 33               [12] 2629 	rlc	a
      0092A4 F0               [24] 2630 	movx	@dptr,a
                                   2631 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      0092A5 90 0B 92         [24] 2632 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      0092A8 E0               [24] 2633 	movx	a,@dptr
      0092A9 FB               [12] 2634 	mov	r3,a
      0092AA BB 05 02         [24] 2635 	cjne	r3,#0x05,00455$
      0092AD 80 0A            [24] 2636 	sjmp	00126$
      0092AF                       2637 00455$:
      0092AF BB 06 02         [24] 2638 	cjne	r3,#0x06,00456$
      0092B2 80 16            [24] 2639 	sjmp	00127$
      0092B4                       2640 00456$:
                                   2641 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      0092B4 BB 07 33         [24] 2642 	cjne	r3,#0x07,00129$
      0092B7 80 22            [24] 2643 	sjmp	00128$
      0092B9                       2644 00126$:
                                   2645 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      0092B9 8C 82            [24] 2646 	mov	dpl, r4
      0092BB 8F 83            [24] 2647 	mov	dph, r7
      0092BD C0 06            [24] 2648 	push	ar6
      0092BF C0 05            [24] 2649 	push	ar5
      0092C1 12 B8 60         [24] 2650 	lcall	_vial_keycode_tap
      0092C4 D0 05            [24] 2651 	pop	ar5
      0092C6 D0 06            [24] 2652 	pop	ar6
                                   2653 ;	quantum/dynamic_keymap.c:795: break;
                                   2654 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      0092C8 80 20            [24] 2655 	sjmp	00129$
      0092CA                       2656 00127$:
                                   2657 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      0092CA 8C 82            [24] 2658 	mov	dpl, r4
      0092CC 8F 83            [24] 2659 	mov	dph, r7
      0092CE C0 06            [24] 2660 	push	ar6
      0092D0 C0 05            [24] 2661 	push	ar5
      0092D2 12 B7 95         [24] 2662 	lcall	_vial_keycode_down
      0092D5 D0 05            [24] 2663 	pop	ar5
      0092D7 D0 06            [24] 2664 	pop	ar6
                                   2665 ;	quantum/dynamic_keymap.c:798: break;
                                   2666 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0092D9 80 0F            [24] 2667 	sjmp	00129$
      0092DB                       2668 00128$:
                                   2669 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      0092DB 8C 82            [24] 2670 	mov	dpl, r4
      0092DD 8F 83            [24] 2671 	mov	dph, r7
      0092DF C0 06            [24] 2672 	push	ar6
      0092E1 C0 05            [24] 2673 	push	ar5
      0092E3 12 B7 FB         [24] 2674 	lcall	_vial_keycode_up
      0092E6 D0 05            [24] 2675 	pop	ar5
      0092E8 D0 06            [24] 2676 	pop	ar6
                                   2677 ;	quantum/dynamic_keymap.c:802: }
      0092EA                       2678 00129$:
                                   2679 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0092EA 12 93 D5         [24] 2680 	lcall	_ak820_outline_0172
      0092ED 21 56            [12] 2681 	ajmp	00167$
      0092EF                       2682 00147$:
                                   2683 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0092EF 12 93 A3         [24] 2684 	lcall	_ak820_outline_0098
      0092F2 BF 04 02         [24] 2685 	cjne	r7,#0x04,00458$
      0092F5 80 02            [24] 2686 	sjmp	00459$
      0092F7                       2687 00458$:
      0092F7 21 56            [12] 2688 	ajmp	00167$
      0092F9                       2689 00459$:
                                   2690 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092F9 12 93 72         [24] 2691 	lcall	_ak820_outline_0000
      0092FC 12 40 7C         [24] 2692 	lcall	_eeprom_read_byte
      0092FF AF 82            [24] 2693 	mov	r7, dpl
                                   2694 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009301 90 0B 8F         [24] 2695 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      009304 12 38 AA         [24] 2696 	lcall	_ak820_outline_0150
      009307 90 0B 8F         [24] 2697 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      00930A 74 01            [12] 2698 	mov	a,#0x01
      00930C 2B               [12] 2699 	add	a, r3
      00930D F0               [24] 2700 	movx	@dptr,a
      00930E E4               [12] 2701 	clr	a
      00930F 3C               [12] 2702 	addc	a, r4
      009310 A3               [24] 2703 	inc	dptr
      009311 F0               [24] 2704 	movx	@dptr,a
      009312 7A 00            [12] 2705 	mov	r2,#0x00
      009314 12 33 FC         [24] 2706 	lcall	_ak820_outline_0130
      009317 8A F0            [24] 2707 	mov	b, r2
      009319 12 40 7C         [24] 2708 	lcall	_eeprom_read_byte
      00931C AC 82            [24] 2709 	mov	r4, dpl
                                   2710 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      00931E EF               [12] 2711 	mov	a,r7
      00931F 60 49            [24] 2712 	jz	00169$
      009321 EC               [12] 2713 	mov	a,r4
      009322 60 46            [24] 2714 	jz	00169$
                                   2715 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009324 1F               [12] 2716 	dec	r7
      009325 1C               [12] 2717 	dec	r4
      009326 EC               [12] 2718 	mov	a,r4
      009327 75 F0 FF         [24] 2719 	mov	b,#0xff
      00932A A4               [48] 2720 	mul	ab
      00932B FC               [12] 2721 	mov	r4,a
      00932C AB F0            [24] 2722 	mov	r3,b
      00932E 7A 00            [12] 2723 	mov	r2,#0x00
      009330 EC               [12] 2724 	mov	a,r4
      009331 2F               [12] 2725 	add	a, r7
      009332 FC               [12] 2726 	mov	r4,a
      009333 EB               [12] 2727 	mov	a,r3
      009334 3A               [12] 2728 	addc	a, r2
      009335 FB               [12] 2729 	mov	r3,a
                                   2730 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      009336                       2731 00141$:
      009336 8C 02            [24] 2732 	mov	ar2,r4
      009338 8B 07            [24] 2733 	mov	ar7,r3
      00933A 1C               [12] 2734 	dec	r4
      00933B BC FF 01         [24] 2735 	cjne	r4,#0xff,00462$
      00933E 1B               [12] 2736 	dec	r3
      00933F                       2737 00462$:
      00933F EA               [12] 2738 	mov	a,r2
      009340 4F               [12] 2739 	orl	a,r7
      009341 70 02            [24] 2740 	jnz	00463$
      009343 21 56            [12] 2741 	ajmp	00167$
      009345                       2742 00463$:
      009345 90 00 01         [24] 2743 	mov	dptr,#0x0001
      009348 12 5E D4         [24] 2744 	lcall	_mDelaymS
      00934B 80 E9            [24] 2745 	sjmp	00141$
      00934D                       2746 00164$:
                                   2747 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      00934D 90 0B 91         [24] 2748 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      009350 E0               [24] 2749 	movx	a,@dptr
      009351 FF               [12] 2750 	mov	r7,a
      009352 BF 80 00         [24] 2751 	cjne	r7,#0x80,00464$
      009355                       2752 00464$:
      009355 50 13            [24] 2753 	jnc	00169$
                                   2754 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      009357 90 0B 91         [24] 2755 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      00935A E0               [24] 2756 	movx	a,@dptr
      00935B F5 82            [12] 2757 	mov	dpl,a
      00935D C0 06            [24] 2758 	push	ar6
      00935F C0 05            [24] 2759 	push	ar5
      009361 12 AA 3A         [24] 2760 	lcall	_send_char
      009364 D0 05            [24] 2761 	pop	ar5
      009366 D0 06            [24] 2762 	pop	ar6
                                   2763 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009368 21 56            [12] 2764 	ajmp	00167$
      00936A                       2765 00169$:
                                   2766 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      00936A 12 93 D5         [24] 2767 	lcall	_ak820_outline_0172
                                   2768 ;	quantum/dynamic_keymap.c:837: sending = false;
      00936D 90 0B 8E         [24] 2769 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_469
      009370 F0               [24] 2770 	movx	@dptr,a
                                   2771 ;	quantum/dynamic_keymap.c:839: }
      009371 22               [24] 2772 	ret
                                   2773 	.area CSEG    (CODE)
                                   2774 	.area CONST   (CODE)
                                   2775 	.area XINIT   (CODE)
                                   2776 	.area CABS    (ABS,CODE)
                                   2777 
                                   2778 ; Experimental exact instruction outlining.
                                   2779 	.globl _ak820_outline_0000
                                   2780 	.globl _ak820_outline_0005
                                   2781 	.globl _ak820_outline_0009
                                   2782 	.globl _ak820_outline_0015
                                   2783 	.globl _ak820_outline_0024
                                   2784 	.globl _ak820_outline_0033
                                   2785 	.globl _ak820_outline_0035
                                   2786 	.globl _ak820_outline_0050
                                   2787 	.globl _ak820_outline_0055
                                   2788 	.globl _ak820_outline_0061
                                   2789 	.globl _ak820_outline_0062
                                   2790 	.globl _ak820_outline_0063
                                   2791 	.globl _ak820_outline_0069
                                   2792 	.globl _ak820_outline_0070
                                   2793 	.globl _ak820_outline_0077
                                   2794 	.globl _ak820_outline_0078
                                   2795 	.globl _ak820_outline_0081
                                   2796 	.globl _ak820_outline_0086
                                   2797 	.globl _ak820_outline_0096
                                   2798 	.globl _ak820_outline_0098
                                   2799 	.globl _ak820_outline_0099
                                   2800 	.globl _ak820_outline_0104
                                   2801 	.globl _ak820_outline_0107
                                   2802 	.globl _ak820_outline_0108
                                   2803 	.globl _ak820_outline_0113
                                   2804 	.globl _ak820_outline_0114
                                   2805 	.globl _ak820_outline_0122
                                   2806 	.globl _ak820_outline_0124
                                   2807 	.globl _ak820_outline_0129
                                   2808 	.globl _ak820_outline_0130
                                   2809 	.globl _ak820_outline_0131
                                   2810 	.globl _ak820_outline_0132
                                   2811 	.globl _ak820_outline_0133
                                   2812 	.globl _ak820_outline_0137
                                   2813 	.globl _ak820_outline_0141
                                   2814 	.globl _ak820_outline_0142
                                   2815 	.globl _ak820_outline_0144
                                   2816 	.globl _ak820_outline_0145
                                   2817 	.globl _ak820_outline_0150
                                   2818 	.globl _ak820_outline_0152
                                   2819 	.globl _ak820_outline_0153
                                   2820 	.globl _ak820_outline_0154
                                   2821 	.globl _ak820_outline_0160
                                   2822 	.globl _ak820_outline_0162
                                   2823 	.globl _ak820_outline_0168
                                   2824 	.globl _ak820_outline_0172
                                   2825 	.globl _ak820_outline_0177
                                   2826 	.globl _ak820_outline_0178
                                   2827 	.globl _ak820_outline_0186
                                   2828 	.globl _ak820_outline_0187
                                   2829 	.globl _ak820_outline_0190
                                   2830 	.globl _ak820_outline_0191
                                   2831 	.globl _ak820_outline_0195
                                   2832 
                                   2833 	.area CSEG (CODE)
                                   2834 ; function ak820_outline_0000
      009372                       2835 _ak820_outline_0000:
      009372 90 0B 8F         [24] 2836 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      009375 E0               [24] 2837 	movx	a,@dptr
      009376 FC               [12] 2838 	mov	r4,a
      009377 A3               [24] 2839 	inc	dptr
      009378 E0               [24] 2840 	movx	a,@dptr
      009379 FF               [12] 2841 	mov	r7,a
      00937A 90 0B 8F         [24] 2842 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      00937D 74 01            [12] 2843 	mov	a,#0x01
      00937F 2C               [12] 2844 	add	a,r4
      009380 F0               [24] 2845 	movx	@dptr,a
      009381 E4               [12] 2846 	clr	a
      009382 3F               [12] 2847 	addc	a,r7
      009383 A3               [24] 2848 	inc	dptr
      009384 F0               [24] 2849 	movx	@dptr,a
      009385 7B 00            [12] 2850 	mov	r3,#0x00
      009387 8C 82            [24] 2851 	mov	dpl,r4
      009389 8F 83            [24] 2852 	mov	dph,r7
      00938B 8B F0            [24] 2853 	mov	b,r3
      00938D 22               [24] 2854 	ret
                                   2855 
                                   2856 	.area CSEG (CODE)
                                   2857 ; function ak820_outline_0081
      00938E                       2858 _ak820_outline_0081:
      00938E 74 0A            [12] 2859 	mov	a,#0x0a
      009390 F0               [24] 2860 	movx	@dptr,a
      009391 E4               [12] 2861 	clr	a
      009392 A3               [24] 2862 	inc	dptr
      009393 F0               [24] 2863 	movx	@dptr,a
      009394 22               [24] 2864 	ret
                                   2865 
                                   2866 	.area CSEG (CODE)
                                   2867 ; function ak820_outline_0086
      009395                       2868 _ak820_outline_0086:
      009395 ED               [12] 2869 	mov	a,r5
      009396 75 F0 0A         [24] 2870 	mov	b,#0x0a
      009399 A4               [48] 2871 	mul	ab
      00939A 24 58            [12] 2872 	add	a,#0x58
      00939C FC               [12] 2873 	mov	r4,a
      00939D 74 06            [12] 2874 	mov	a,#0x06
      00939F 35 F0            [12] 2875 	addc	a,b
      0093A1 FD               [12] 2876 	mov	r5,a
      0093A2 22               [24] 2877 	ret
                                   2878 
                                   2879 	.area CSEG (CODE)
                                   2880 ; function ak820_outline_0098
      0093A3                       2881 _ak820_outline_0098:
      0093A3 90 0B 92         [24] 2882 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481+0x0001)
      0093A6 E0               [24] 2883 	movx	a,@dptr
      0093A7 FF               [12] 2884 	mov	r7,a
      0093A8 22               [24] 2885 	ret
                                   2886 
                                   2887 	.area CSEG (CODE)
                                   2888 ; function ak820_outline_0104
      0093A9                       2889 _ak820_outline_0104:
      0093A9 90 0B 28         [24] 2890 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0093AC EE               [12] 2891 	mov	a,r6
      0093AD F0               [24] 2892 	movx	@dptr,a
      0093AE 90 0B 29         [24] 2893 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0093B1 ED               [12] 2894 	mov	a,r5
      0093B2 F0               [24] 2895 	movx	@dptr,a
      0093B3 8F 82            [24] 2896 	mov	dpl,r7
      0093B5 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0122
      0093B6                       2901 _ak820_outline_0122:
      0093B6 AD 82            [24] 2902 	mov	r5,dpl
      0093B8 AE 83            [24] 2903 	mov	r6,dph
      0093BA AF F0            [24] 2904 	mov	r7,b
      0093BC 22               [24] 2905 	ret
                                   2906 
                                   2907 	.area CSEG (CODE)
                                   2908 ; function ak820_outline_0137
      0093BD                       2909 _ak820_outline_0137:
      0093BD 28               [12] 2910 	add	a,r0
      0093BE F5 82            [12] 2911 	mov	dpl,a
      0093C0 EF               [12] 2912 	mov	a,r7
      0093C1 39               [12] 2913 	addc	a,r1
      0093C2 F5 83            [12] 2914 	mov	dph,a
      0093C4 74 FF            [12] 2915 	mov	a,#0xff
      0093C6 F0               [24] 2916 	movx	@dptr,a
      0093C7 22               [24] 2917 	ret
                                   2918 
                                   2919 	.area CSEG (CODE)
                                   2920 ; function ak820_outline_0142
      0093C8                       2921 _ak820_outline_0142:
      0093C8 2D               [12] 2922 	add	a,r5
      0093C9 F9               [12] 2923 	mov	r1,a
      0093CA E4               [12] 2924 	clr	a
      0093CB 3E               [12] 2925 	addc	a,r6
      0093CC FA               [12] 2926 	mov	r2,a
      0093CD 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0162
      0093CE                       2931 _ak820_outline_0162:
      0093CE 90 0B 93         [24] 2932 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481+0x0002)
      0093D1 E0               [24] 2933 	movx	a,@dptr
      0093D2 F5 82            [12] 2934 	mov	dpl,a
      0093D4 22               [24] 2935 	ret
                                   2936 
                                   2937 	.area CSEG (CODE)
                                   2938 ; function ak820_outline_0172
      0093D5                       2939 _ak820_outline_0172:
      0093D5 90 09 D6         [24] 2940 	mov	dptr,#_ak820_macro_primitive
      0093D8 E4               [12] 2941 	clr	a
      0093D9 F0               [24] 2942 	movx	@dptr,a
      0093DA 22               [24] 2943 	ret
                                   2944 
                                   2945 	.area CSEG (CODE)
                                   2946 ; function ak820_outline_0186
      0093DB                       2947 _ak820_outline_0186:
      0093DB 90 0B 38         [24] 2948 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0093DE E4               [12] 2949 	clr	a
      0093DF F0               [24] 2950 	movx	@dptr,a
      0093E0 90 0B 39         [24] 2951 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0093E3 22               [24] 2952 	ret
                                   2953 
                                   2954 	.area CSEG (CODE)
                                   2955 ; function ak820_outline_0187
      0093E4                       2956 _ak820_outline_0187:
      0093E4 90 0B EE         [24] 2957 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0093E7 E4               [12] 2958 	clr	a
      0093E8 F0               [24] 2959 	movx	@dptr,a
      0093E9 90 0B EF         [24] 2960 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0093EC 22               [24] 2961 	ret
                                   2962 
                                   2963 	.area CSEG (CODE)
                                   2964 ; function ak820_outline_0190
      0093ED                       2965 _ak820_outline_0190:
      0093ED AF 82            [24] 2966 	mov	r7,dpl
      0093EF 90 0B 93         [24] 2967 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481+0x0002)
      0093F2 EF               [12] 2968 	mov	a,r7
      0093F3 F0               [24] 2969 	movx	@dptr,a
      0093F4 EF               [12] 2970 	mov	a,r7
      0093F5 22               [24] 2971 	ret
