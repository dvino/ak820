                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_settings
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _clear_keyboard
                                     12 	.globl ___memcpy
                                     13 	.globl _memset
                                     14 	.globl _memcmp
                                     15 	.globl _ak820_eeprom_update_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_end
                                     18 	.globl _ak820_nvm_begin
                                     19 	.globl _ak820_nvm_schema_fault
                                     20 	.globl _ak820_nvm_ok
                                     21 	.globl _ak820_settings_set_PARM_3
                                     22 	.globl _ak820_settings_set_PARM_2
                                     23 	.globl _ak820_settings_get_PARM_3
                                     24 	.globl _ak820_settings_get_PARM_2
                                     25 	.globl _ak820_settings_query_PARM_3
                                     26 	.globl _ak820_settings_query_PARM_2
                                     27 	.globl _ak820_settings_init
                                     28 	.globl _ak820_settings_query
                                     29 	.globl _ak820_settings_get
                                     30 	.globl _ak820_settings_set
                                     31 	.globl _ak820_settings_reset
                                     32 	.globl _ak820_settings_grave_esc
                                     33 	.globl _ak820_settings_combo_term
                                     34 	.globl _ak820_settings_tapping_term
                                     35 	.globl _ak820_settings_tap_code_delay
                                     36 	.globl _ak820_settings_caps_delay
                                     37 ;--------------------------------------------------------
                                     38 ; special function registers
                                     39 ;--------------------------------------------------------
                                     40 	.area RSEG    (ABS,DATA)
      000000                         41 	.org 0x0000
                                     42 ;--------------------------------------------------------
                                     43 ; special function bits
                                     44 ;--------------------------------------------------------
                                     45 	.area RSEG    (ABS,DATA)
      000000                         46 	.org 0x0000
                                     47 ;--------------------------------------------------------
                                     48 ; overlayable register banks
                                     49 ;--------------------------------------------------------
                                     50 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         51 	.ds 8
                                     52 ;--------------------------------------------------------
                                     53 ; internal ram data
                                     54 ;--------------------------------------------------------
                                     55 	.area DSEG    (DATA)
      000015                         56 _ak820_settings_query_sloc0_1_0:
      000015                         57 	.ds 2
      000017                         58 _ak820_settings_query_sloc1_1_0:
      000017                         59 	.ds 2
      000019                         60 _ak820_settings_query_sloc2_1_0:
      000019                         61 	.ds 3
                                     62 ;--------------------------------------------------------
                                     63 ; overlayable items in internal ram
                                     64 ;--------------------------------------------------------
                                     65 ;--------------------------------------------------------
                                     66 ; indirectly addressable internal ram data
                                     67 ;--------------------------------------------------------
                                     68 	.area ISEG    (DATA)
                                     69 ;--------------------------------------------------------
                                     70 ; absolute internal ram data
                                     71 ;--------------------------------------------------------
                                     72 	.area IABS    (ABS,DATA)
                                     73 	.area IABS    (ABS,DATA)
                                     74 ;--------------------------------------------------------
                                     75 ; bit data
                                     76 ;--------------------------------------------------------
                                     77 	.area BSEG    (BIT)
      00000E                         78 _valid_sloc0_1_0:
      00000E                         79 	.ds 1
                                     80 ;--------------------------------------------------------
                                     81 ; paged external ram data
                                     82 ;--------------------------------------------------------
                                     83 	.area PSEG    (PAG,XDATA)
                                     84 ;--------------------------------------------------------
                                     85 ; uninitialized external ram data
                                     86 ;--------------------------------------------------------
                                     87 	.area XSEG    (XDATA)
      00059E                         88 _current:
      00059E                         89 	.ds 24
      0005B6                         90 _candidate:
      0005B6                         91 	.ds 24
      0005CE                         92 _word_p_10000_54:
      0005CE                         93 	.ds 2
      0005D0                         94 _put_word_PARM_2:
      0005D0                         95 	.ds 2
      0005D2                         96 _put_word_p_10000_56:
      0005D2                         97 	.ds 2
      0005D4                         98 _checksum_crc_10000_59:
      0005D4                         99 	.ds 2
      0005D6                        100 _ak820_settings_init_blank_zero_10000_82:
      0005D6                        101 	.ds 1
      0005D7                        102 _ak820_settings_init_blank_erased_10000_82:
      0005D7                        103 	.ds 1
      0005D8                        104 _offset_id_10000_90:
      0005D8                        105 	.ds 2
      0005DA                        106 _ak820_settings_query_PARM_2:
      0005DA                        107 	.ds 3
      0005DD                        108 _ak820_settings_query_PARM_3:
      0005DD                        109 	.ds 2
      0005DF                        110 _ak820_settings_query_greater_than_10000_94:
      0005DF                        111 	.ds 2
      0005E1                        112 _ak820_settings_query_used_10000_95:
      0005E1                        113 	.ds 2
      0005E3                        114 _ak820_settings_get_PARM_2:
      0005E3                        115 	.ds 3
      0005E6                        116 _ak820_settings_get_PARM_3:
      0005E6                        117 	.ds 2
      0005E8                        118 _ak820_settings_get_id_10000_100:
      0005E8                        119 	.ds 2
      0005EA                        120 _ak820_settings_set_PARM_2:
      0005EA                        121 	.ds 3
      0005ED                        122 _ak820_settings_set_PARM_3:
      0005ED                        123 	.ds 2
      0005EF                        124 _ak820_settings_set_id_10000_104:
      0005EF                        125 	.ds 2
                                    126 ;--------------------------------------------------------
                                    127 ; absolute external ram data
                                    128 ;--------------------------------------------------------
                                    129 	.area XABS    (ABS,XDATA)
                                    130 ;--------------------------------------------------------
                                    131 ; initialized external ram data
                                    132 ;--------------------------------------------------------
                                    133 	.area XISEG   (XDATA)
                                    134 	.area HOME    (CODE)
                                    135 	.area GSINIT0 (CODE)
                                    136 	.area GSINIT1 (CODE)
                                    137 	.area GSINIT2 (CODE)
                                    138 	.area GSINIT3 (CODE)
                                    139 	.area GSINIT4 (CODE)
                                    140 	.area GSINIT5 (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 	.area GSFINAL (CODE)
                                    143 	.area CSEG    (CODE)
                                    144 ;--------------------------------------------------------
                                    145 ; global & static initialisations
                                    146 ;--------------------------------------------------------
                                    147 	.area HOME    (CODE)
                                    148 	.area GSINIT  (CODE)
                                    149 	.area GSFINAL (CODE)
                                    150 	.area GSINIT  (CODE)
                                    151 ;--------------------------------------------------------
                                    152 ; Home
                                    153 ;--------------------------------------------------------
                                    154 	.area HOME    (CODE)
                                    155 	.area HOME    (CODE)
                                    156 ;--------------------------------------------------------
                                    157 ; code
                                    158 ;--------------------------------------------------------
                                    159 	.area CSEG    (CODE)
                                    160 ;------------------------------------------------------------
                                    161 ;Allocation info for local variables in function 'word'
                                    162 ;------------------------------------------------------------
                                    163 ;p             Allocated with name '_word_p_10000_54'
                                    164 ;------------------------------------------------------------
                                    165 ;	keyboards/ajazz/ak820/ak820_settings.c:13: static uint16_t word(const uint8_t AK820_XDATA *p) {
                                    166 ;	-----------------------------------------
                                    167 ;	 function word
                                    168 ;	-----------------------------------------
      004395                        169 _word:
                           000007   170 	ar7 = 0x07
                           000006   171 	ar6 = 0x06
                           000005   172 	ar5 = 0x05
                           000004   173 	ar4 = 0x04
                           000003   174 	ar3 = 0x03
                           000002   175 	ar2 = 0x02
                           000001   176 	ar1 = 0x01
                           000000   177 	ar0 = 0x00
      004395 12 38 79         [24]  178 	lcall	_ak820_outline_0113
      004398 90 05 CE         [24]  179 	mov	dptr,#_word_p_10000_54
      00439B 12 38 7E         [24]  180 	lcall	_ak820_outline_0114
                                    181 ;	keyboards/ajazz/ak820/ak820_settings.c:14: return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
      00439E 90 05 CE         [24]  182 	mov	dptr,#_word_p_10000_54
      0043A1 12 37 F1         [24]  183 	lcall	_ak820_outline_0005
      0043A4 E0               [24]  184 	movx	a,@dptr
      0043A5 FD               [12]  185 	mov	r5,a
      0043A6 7C 00            [12]  186 	mov	r4,#0x00
      0043A8 12 38 83         [24]  187 	lcall	_ak820_outline_0118
      0043AB FE               [12]  188 	mov	r6,a
      0043AC E4               [12]  189 	clr	a
      0043AD 42 05            [12]  190 	orl	ar5,a
      0043AF EE               [12]  191 	mov	a,r6
      0043B0 42 04            [12]  192 	orl	ar4,a
      0043B2 12 43 90         [24]  193 	lcall	_ak820_outline_0197
                                    194 ;	keyboards/ajazz/ak820/ak820_settings.c:15: }
      0043B5 22               [24]  195 	ret
                                    196 ;------------------------------------------------------------
                                    197 ;Allocation info for local variables in function 'put_word'
                                    198 ;------------------------------------------------------------
                                    199 ;v             Allocated with name '_put_word_PARM_2'
                                    200 ;p             Allocated with name '_put_word_p_10000_56'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_settings.c:16: static void put_word(uint8_t AK820_XDATA *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
                                    203 ;	-----------------------------------------
                                    204 ;	 function put_word
                                    205 ;	-----------------------------------------
      0043B6                        206 _put_word:
      0043B6 12 38 79         [24]  207 	lcall	_ak820_outline_0113
      0043B9 90 05 D2         [24]  208 	mov	dptr,#_put_word_p_10000_56
      0043BC 12 38 7E         [24]  209 	lcall	_ak820_outline_0114
      0043BF 90 05 D2         [24]  210 	mov	dptr,#_put_word_p_10000_56
      0043C2 12 38 3E         [24]  211 	lcall	_ak820_outline_0055
      0043C5 90 05 D0         [24]  212 	mov	dptr,#_put_word_PARM_2
      0043C8 12 38 55         [24]  213 	lcall	_ak820_outline_0063
      0043CB 8C 03            [24]  214 	mov	ar3,r4
      0043CD 12 38 8A         [24]  215 	lcall	_ak820_outline_0124
      0043D0 EB               [12]  216 	mov	a,r3
      0043D1 12 43 46         [24]  217 	lcall	_ak820_outline_0077
      0043D4 A3               [24]  218 	inc	dptr
      0043D5 8D 04            [24]  219 	mov	ar4,r5
      0043D7 EC               [12]  220 	mov	a,r4
      0043D8 F0               [24]  221 	movx	@dptr,a
      0043D9 22               [24]  222 	ret
                                    223 ;------------------------------------------------------------
                                    224 ;Allocation info for local variables in function 'checksum'
                                    225 ;------------------------------------------------------------
                                    226 ;crc           Allocated with name '_checksum_crc_10000_59'
                                    227 ;i             Allocated with name '_checksum_i_10000_59'
                                    228 ;bit           Allocated with name '_checksum_bit_10000_59'
                                    229 ;------------------------------------------------------------
                                    230 ;	keyboards/ajazz/ak820/ak820_settings.c:17: static uint16_t checksum(void) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function checksum
                                    233 ;	-----------------------------------------
      0043DA                        234 _checksum:
                                    235 ;	keyboards/ajazz/ak820/ak820_settings.c:18: uint16_t crc = 0xFFFFu;
      0043DA 90 05 D4         [24]  236 	mov	dptr,#_checksum_crc_10000_59
      0043DD 74 FF            [12]  237 	mov	a,#0xff
      0043DF F0               [24]  238 	movx	@dptr,a
      0043E0 A3               [24]  239 	inc	dptr
      0043E1 F0               [24]  240 	movx	@dptr,a
                                    241 ;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
      0043E2 7F 00            [12]  242 	mov	r7,#0x00
      0043E4                        243 00106$:
                                    244 ;	keyboards/ajazz/ak820/ak820_settings.c:21: crc ^= (uint16_t)candidate[i] << 8;
      0043E4 12 49 AD         [24]  245 	lcall	_ak820_outline_0110
      0043E7 FD               [12]  246 	mov	r5,a
      0043E8 7E 00            [12]  247 	mov	r6,#0x00
      0043EA 90 05 D4         [24]  248 	mov	dptr,#_checksum_crc_10000_59
      0043ED E0               [24]  249 	movx	a,@dptr
      0043EE 6E               [12]  250 	xrl	a,r6
      0043EF F0               [24]  251 	movx	@dptr,a
      0043F0 A3               [24]  252 	inc	dptr
      0043F1 E0               [24]  253 	movx	a,@dptr
      0043F2 6D               [12]  254 	xrl	a,r5
      0043F3 F0               [24]  255 	movx	@dptr,a
                                    256 ;	keyboards/ajazz/ak820/ak820_settings.c:22: for (bit = 0; bit < 8; ++bit) crc = (crc & 0x8000u) ? (crc << 1) ^ 0x1021u : (uint16_t)(crc << 1);
      0043F4 7E 08            [12]  257 	mov	r6,#0x08
      0043F6                        258 00105$:
      0043F6 90 05 D4         [24]  259 	mov	dptr,#_checksum_crc_10000_59
      0043F9 12 38 55         [24]  260 	lcall	_ak820_outline_0063
      0043FC 30 E7 0E         [24]  261 	jnb	acc.7,00110$
      0043FF EC               [12]  262 	mov	a,r4
      004400 2C               [12]  263 	add	a,r4
      004401 FA               [12]  264 	mov	r2,a
      004402 ED               [12]  265 	mov	a,r5
      004403 33               [12]  266 	rlc	a
      004404 FB               [12]  267 	mov	r3,a
      004405 63 02 21         [24]  268 	xrl	ar2,#0x21
      004408 63 03 10         [24]  269 	xrl	ar3,#0x10
      00440B 80 06            [24]  270 	sjmp	00111$
      00440D                        271 00110$:
      00440D EC               [12]  272 	mov	a,r4
      00440E 2C               [12]  273 	add	a,r4
      00440F FA               [12]  274 	mov	r2,a
      004410 ED               [12]  275 	mov	a,r5
      004411 33               [12]  276 	rlc	a
      004412 FB               [12]  277 	mov	r3,a
      004413                        278 00111$:
      004413 90 05 D4         [24]  279 	mov	dptr,#_checksum_crc_10000_59
      004416 EA               [12]  280 	mov	a,r2
      004417 12 49 C4         [24]  281 	lcall	_ak820_outline_0195
      00441A DE DA            [24]  282 	djnz	r6,00105$
                                    283 ;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
      00441C 0F               [12]  284 	inc	r7
      00441D BF 16 00         [24]  285 	cjne	r7,#0x16,00151$
      004420                        286 00151$:
      004420 40 C2            [24]  287 	jc	00106$
                                    288 ;	keyboards/ajazz/ak820/ak820_settings.c:24: return crc;
      004422 12 38 B5         [24]  289 	lcall	_ak820_outline_0154
                                    290 ;	keyboards/ajazz/ak820/ak820_settings.c:25: }
      004425 22               [24]  291 	ret
                                    292 ;------------------------------------------------------------
                                    293 ;Allocation info for local variables in function 'seal'
                                    294 ;------------------------------------------------------------
                                    295 ;	keyboards/ajazz/ak820/ak820_settings.c:26: static void seal(void) { put_word(candidate + 22, checksum()); }
                                    296 ;	-----------------------------------------
                                    297 ;	 function seal
                                    298 ;	-----------------------------------------
      004426                        299 _seal:
      004426 12 43 DA         [24]  300 	lcall	_checksum
      004429 12 38 8F         [24]  301 	lcall	_ak820_outline_0127
      00442C 90 05 D0         [24]  302 	mov	dptr,#_put_word_PARM_2
      00442F 12 49 B9         [24]  303 	lcall	_ak820_outline_0149
      004432 90 05 CC         [24]  304 	mov	dptr,#(_candidate + 0x0016)
      004435 02 43 B6         [24]  305 	ljmp	_put_word
                                    306 ;------------------------------------------------------------
                                    307 ;Allocation info for local variables in function 'defaults'
                                    308 ;------------------------------------------------------------
                                    309 ;	keyboards/ajazz/ak820/ak820_settings.c:27: static void defaults(void) {
                                    310 ;	-----------------------------------------
                                    311 ;	 function defaults
                                    312 ;	-----------------------------------------
      004438                        313 _defaults:
                                    314 ;	keyboards/ajazz/ak820/ak820_settings.c:28: memset(candidate, 0, sizeof(candidate));
      004438 90 0D F9         [24]  315 	mov	dptr,#_memset_PARM_2
      00443B E4               [12]  316 	clr	a
      00443C F0               [24]  317 	movx	@dptr,a
      00443D 90 0D FA         [24]  318 	mov	dptr,#_memset_PARM_3
      004440 12 49 61         [24]  319 	lcall	_ak820_outline_0042
      004443 F5 F0            [12]  320 	mov	b,a
      004445 12 BE EA         [24]  321 	lcall	_memset
                                    322 ;	keyboards/ajazz/ak820/ak820_settings.c:29: candidate[0] = 'Q'; candidate[1] = 'S'; candidate[2] = AK820_SETTINGS_VERSION;
      004448 90 05 B6         [24]  323 	mov	dptr,#_candidate
      00444B 74 51            [12]  324 	mov	a,#0x51
      00444D F0               [24]  325 	movx	@dptr,a
      00444E 90 05 B7         [24]  326 	mov	dptr,#(_candidate + 0x0001)
      004451 74 53            [12]  327 	mov	a,#0x53
      004453 F0               [24]  328 	movx	@dptr,a
      004454 90 05 B8         [24]  329 	mov	dptr,#(_candidate + 0x0002)
      004457 74 01            [12]  330 	mov	a,#0x01
      004459 F0               [24]  331 	movx	@dptr,a
                                    332 ;	keyboards/ajazz/ak820/ak820_settings.c:30: candidate[3] = 11; candidate[4] = AK820_SETTINGS_CAPABILITIES;
      00445A 90 05 B9         [24]  333 	mov	dptr,#(_candidate + 0x0003)
      00445D 74 0B            [12]  334 	mov	a,#0x0b
      00445F F0               [24]  335 	movx	@dptr,a
      004460 90 05 BA         [24]  336 	mov	dptr,#(_candidate + 0x0004)
      004463 74 3F            [12]  337 	mov	a,#0x3f
      004465 F0               [24]  338 	movx	@dptr,a
                                    339 ;	keyboards/ajazz/ak820/ak820_settings.c:31: put_word(candidate + 14, 175);
      004466 90 05 D0         [24]  340 	mov	dptr,#_put_word_PARM_2
      004469 74 AF            [12]  341 	mov	a,#0xaf
      00446B 12 38 9B         [24]  342 	lcall	_ak820_outline_0131
      00446E 90 05 C4         [24]  343 	mov	dptr,#(_candidate + 0x000e)
      004471 12 43 B6         [24]  344 	lcall	_put_word
                                    345 ;	keyboards/ajazz/ak820/ak820_settings.c:32: put_word(candidate + 6, 40); put_word(candidate + 8, 200); put_word(candidate + 12, 80);
      004474 90 05 D0         [24]  346 	mov	dptr,#_put_word_PARM_2
      004477 74 28            [12]  347 	mov	a,#0x28
      004479 12 38 9B         [24]  348 	lcall	_ak820_outline_0131
      00447C 90 05 BC         [24]  349 	mov	dptr,#(_candidate + 0x0006)
      00447F 12 43 B6         [24]  350 	lcall	_put_word
      004482 90 05 D0         [24]  351 	mov	dptr,#_put_word_PARM_2
      004485 74 C8            [12]  352 	mov	a,#0xc8
      004487 12 38 9B         [24]  353 	lcall	_ak820_outline_0131
      00448A 90 05 BE         [24]  354 	mov	dptr,#(_candidate + 0x0008)
      00448D 12 43 B6         [24]  355 	lcall	_put_word
      004490 90 05 D0         [24]  356 	mov	dptr,#_put_word_PARM_2
      004493 74 50            [12]  357 	mov	a,#0x50
      004495 12 38 9B         [24]  358 	lcall	_ak820_outline_0131
      004498 90 05 C2         [24]  359 	mov	dptr,#(_candidate + 0x000c)
      00449B 12 43 B6         [24]  360 	lcall	_put_word
                                    361 ;	keyboards/ajazz/ak820/ak820_settings.c:33: seal();
                                    362 ;	keyboards/ajazz/ak820/ak820_settings.c:34: }
      00449E 02 44 26         [24]  363 	ljmp	_seal
                                    364 ;------------------------------------------------------------
                                    365 ;Allocation info for local variables in function 'valid'
                                    366 ;------------------------------------------------------------
                                    367 ;i             Allocated with name '_valid_i_10000_68'
                                    368 ;------------------------------------------------------------
                                    369 ;	keyboards/ajazz/ak820/ak820_settings.c:35: static bool valid(void) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function valid
                                    372 ;	-----------------------------------------
      0044A1                        373 _valid:
                                    374 ;	keyboards/ajazz/ak820/ak820_settings.c:37: if (candidate[0] != 'Q' || candidate[1] != 'S' || candidate[2] != AK820_SETTINGS_VERSION || candidate[3] != 11 || candidate[4] != AK820_SETTINGS_CAPABILITIES) return false;
      0044A1 90 05 B6         [24]  375 	mov	dptr,#_candidate
      0044A4 E0               [24]  376 	movx	a,@dptr
      0044A5 FF               [12]  377 	mov	r7,a
      0044A6 BF 51 22         [24]  378 	cjne	r7,#0x51,00101$
      0044A9 90 05 B7         [24]  379 	mov	dptr,#(_candidate + 0x0001)
      0044AC E0               [24]  380 	movx	a,@dptr
      0044AD FF               [12]  381 	mov	r7,a
      0044AE BF 53 1A         [24]  382 	cjne	r7,#0x53,00101$
      0044B1 90 05 B8         [24]  383 	mov	dptr,#(_candidate + 0x0002)
      0044B4 E0               [24]  384 	movx	a,@dptr
      0044B5 FF               [12]  385 	mov	r7,a
      0044B6 BF 01 12         [24]  386 	cjne	r7,#0x01,00101$
      0044B9 90 05 B9         [24]  387 	mov	dptr,#(_candidate + 0x0003)
      0044BC E0               [24]  388 	movx	a,@dptr
      0044BD FF               [12]  389 	mov	r7,a
      0044BE BF 0B 0A         [24]  390 	cjne	r7,#0x0b,00101$
      0044C1 90 05 BA         [24]  391 	mov	dptr,#(_candidate + 0x0004)
      0044C4 E0               [24]  392 	movx	a,@dptr
      0044C5 FF               [12]  393 	mov	r7,a
      0044C6 BF 3F 02         [24]  394 	cjne	r7,#0x3f,00226$
      0044C9 80 04            [24]  395 	sjmp	00102$
      0044CB                        396 00226$:
      0044CB                        397 00101$:
      0044CB 75 82 00         [24]  398 	mov	dpl, #0x00
      0044CE 22               [24]  399 	ret
      0044CF                        400 00102$:
                                    401 ;	keyboards/ajazz/ak820/ak820_settings.c:38: if (candidate[5] & 0xF0u) return false;
      0044CF 90 05 BB         [24]  402 	mov	dptr,#(_candidate + 0x0005)
      0044D2 E0               [24]  403 	movx	a,@dptr
      0044D3 54 F0            [12]  404 	anl	a,#0xf0
      0044D5 60 04            [24]  405 	jz	00108$
      0044D7 75 82 00         [24]  406 	mov	dpl, #0x00
      0044DA 22               [24]  407 	ret
      0044DB                        408 00108$:
                                    409 ;	keyboards/ajazz/ak820/ak820_settings.c:39: if (!word(candidate + 6) || word(candidate + 6) > 1000 || !word(candidate + 8) || word(candidate + 8) > 1000) return false;
      0044DB 90 05 BC         [24]  410 	mov	dptr,#(_candidate + 0x0006)
      0044DE 12 43 95         [24]  411 	lcall	_word
      0044E1 12 49 A5         [24]  412 	lcall	_ak820_outline_0084
      0044E4 60 21            [24]  413 	jz	00109$
      0044E6 90 05 BC         [24]  414 	mov	dptr,#(_candidate + 0x0006)
      0044E9 12 43 95         [24]  415 	lcall	_word
      0044EC 12 49 6B         [24]  416 	lcall	_ak820_outline_0047
      0044EF 40 16            [24]  417 	jc	00109$
                                    418 ;	free result
      0044F1 90 05 BE         [24]  419 	mov	dptr,#(_candidate + 0x0008)
      0044F4 12 43 95         [24]  420 	lcall	_word
      0044F7 12 49 A5         [24]  421 	lcall	_ak820_outline_0084
      0044FA 60 0B            [24]  422 	jz	00109$
      0044FC 90 05 BE         [24]  423 	mov	dptr,#(_candidate + 0x0008)
      0044FF 12 43 95         [24]  424 	lcall	_word
      004502 12 49 6B         [24]  425 	lcall	_ak820_outline_0047
      004505 50 04            [24]  426 	jnc	00110$
                                    427 ;	free result
      004507                        428 00109$:
      004507 75 82 00         [24]  429 	mov	dpl, #0x00
      00450A 22               [24]  430 	ret
      00450B                        431 00110$:
                                    432 ;	keyboards/ajazz/ak820/ak820_settings.c:40: if (!word(candidate + 14) || word(candidate + 14) > 1000) return false;
      00450B 90 05 C4         [24]  433 	mov	dptr,#(_candidate + 0x000e)
      00450E 12 43 95         [24]  434 	lcall	_word
      004511 12 49 A5         [24]  435 	lcall	_ak820_outline_0084
      004514 60 0B            [24]  436 	jz	00114$
      004516 90 05 C4         [24]  437 	mov	dptr,#(_candidate + 0x000e)
      004519 12 43 95         [24]  438 	lcall	_word
      00451C 12 49 6B         [24]  439 	lcall	_ak820_outline_0047
      00451F 50 04            [24]  440 	jnc	00115$
                                    441 ;	free result
      004521                        442 00114$:
      004521 75 82 00         [24]  443 	mov	dpl, #0x00
      004524 22               [24]  444 	ret
      004525                        445 00115$:
                                    446 ;	keyboards/ajazz/ak820/ak820_settings.c:41: if (word(candidate + 10) > 100 || word(candidate + 12) > 100) return false;
      004525 90 05 C0         [24]  447 	mov	dptr,#(_candidate + 0x000a)
      004528 12 43 95         [24]  448 	lcall	_word
      00452B 12 43 64         [24]  449 	lcall	_ak820_outline_0132
      00452E C3               [12]  450 	clr	c
      00452F 74 64            [12]  451 	mov	a,#0x64
      004531 9E               [12]  452 	subb	a,r6
      004532 E4               [12]  453 	clr	a
      004533 9F               [12]  454 	subb	a,r7
      004534 40 11            [24]  455 	jc	00117$
                                    456 ;	free result
      004536 90 05 C2         [24]  457 	mov	dptr,#(_candidate + 0x000c)
      004539 12 43 95         [24]  458 	lcall	_word
      00453C 12 43 64         [24]  459 	lcall	_ak820_outline_0132
      00453F C3               [12]  460 	clr	c
      004540 74 64            [12]  461 	mov	a,#0x64
      004542 9E               [12]  462 	subb	a,r6
      004543 E4               [12]  463 	clr	a
      004544 9F               [12]  464 	subb	a,r7
      004545 50 04            [24]  465 	jnc	00151$
                                    466 ;	free result
      004547                        467 00117$:
      004547 75 82 00         [24]  468 	mov	dpl, #0x00
                                    469 ;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 16; i < 22; ++i) if (candidate[i]) return false;
      00454A 22               [24]  470 	ret
      00454B                        471 00151$:
      00454B 7F 10            [12]  472 	mov	r7,#0x10
      00454D                        473 00123$:
      00454D EF               [12]  474 	mov	a,r7
      00454E 24 B6            [12]  475 	add	a, #_candidate
      004550 FD               [12]  476 	mov	r5,a
      004551 E4               [12]  477 	clr	a
      004552 34 05            [12]  478 	addc	a, #(_candidate >> 8)
      004554 12 49 85         [24]  479 	lcall	_ak820_outline_0069
      004557 60 04            [24]  480 	jz	00124$
      004559 75 82 00         [24]  481 	mov	dpl, #0x00
      00455C 22               [24]  482 	ret
      00455D                        483 00124$:
      00455D 0F               [12]  484 	inc	r7
      00455E BF 16 00         [24]  485 	cjne	r7,#0x16,00237$
      004561                        486 00237$:
      004561 40 EA            [24]  487 	jc	00123$
                                    488 ;	keyboards/ajazz/ak820/ak820_settings.c:43: return word(candidate + 22) == checksum();
      004563 90 05 CC         [24]  489 	mov	dptr,#(_candidate + 0x0016)
      004566 12 43 95         [24]  490 	lcall	_word
      004569 12 43 64         [24]  491 	lcall	_ak820_outline_0132
      00456C C0 07            [24]  492 	push	ar7
      00456E C0 06            [24]  493 	push	ar6
      004570 12 43 DA         [24]  494 	lcall	_checksum
      004573 12 38 B0         [24]  495 	lcall	_ak820_outline_0153
      004576 D0 06            [24]  496 	pop	ar6
      004578 D0 07            [24]  497 	pop	ar7
      00457A EE               [12]  498 	mov	a,r6
      00457B B5 04 07         [24]  499 	cjne	a,ar4,00239$
      00457E EF               [12]  500 	mov	a,r7
      00457F B5 05 03         [24]  501 	cjne	a,ar5,00239$
      004582 D3               [12]  502 	setb	c
      004583 80 01            [24]  503 	sjmp	00240$
      004585                        504 00239$:
      004585 C3               [12]  505 	clr	c
      004586                        506 00240$:
      004586 92 0E            [24]  507 	mov  _valid_sloc0_1_0,c
      004588 12 38 BA         [24]  508 	lcall	_ak820_outline_0159
                                    509 ;	keyboards/ajazz/ak820/ak820_settings.c:44: }
      00458B 22               [24]  510 	ret
                                    511 ;------------------------------------------------------------
                                    512 ;Allocation info for local variables in function 'commit'
                                    513 ;------------------------------------------------------------
                                    514 ;	keyboards/ajazz/ak820/ak820_settings.c:48: static int commit(void) {
                                    515 ;	-----------------------------------------
                                    516 ;	 function commit
                                    517 ;	-----------------------------------------
      00458C                        518 _commit:
                                    519 ;	keyboards/ajazz/ak820/ak820_settings.c:49: if (!ak820_nvm_ok()) return -1;
      00458C 12 3E 23         [24]  520 	lcall	_ak820_nvm_ok
      00458F E5 82            [12]  521 	mov	a, dpl
      004591 70 04            [24]  522 	jnz	00102$
      004593 90 FF FF         [24]  523 	mov	dptr,#0xffff
      004596 22               [24]  524 	ret
      004597                        525 00102$:
                                    526 ;	keyboards/ajazz/ak820/ak820_settings.c:50: if (!memcmp(current, candidate, sizeof(current))) return 0;
      004597 90 0D FF         [24]  527 	mov	dptr,#_memcmp_PARM_2
      00459A 74 B6            [12]  528 	mov	a,#_candidate
      00459C F0               [24]  529 	movx	@dptr,a
      00459D 74 05            [12]  530 	mov	a,#(_candidate >> 8)
      00459F 12 38 5B         [24]  531 	lcall	_ak820_outline_0070
      0045A2 90 0E 02         [24]  532 	mov	dptr,#_memcmp_PARM_3
      0045A5 74 18            [12]  533 	mov	a,#0x18
      0045A7 12 38 9B         [24]  534 	lcall	_ak820_outline_0131
      0045AA 90 05 9E         [24]  535 	mov	dptr,#_current
      0045AD F5 F0            [12]  536 	mov	b,a
      0045AF 12 BF 4D         [24]  537 	lcall	_memcmp
      0045B2 12 49 A5         [24]  538 	lcall	_ak820_outline_0084
      0045B5 70 04            [24]  539 	jnz	00104$
      0045B7 90 00 00         [24]  540 	mov	dptr,#0x0000
      0045BA 22               [24]  541 	ret
      0045BB                        542 00104$:
                                    543 ;	keyboards/ajazz/ak820/ak820_settings.c:51: clear_keyboard();
      0045BB 12 7C 52         [24]  544 	lcall	_clear_keyboard
                                    545 ;	keyboards/ajazz/ak820/ak820_settings.c:52: ak820_nvm_begin();
      0045BE 12 3F 84         [24]  546 	lcall	_ak820_nvm_begin
                                    547 ;	keyboards/ajazz/ak820/ak820_settings.c:53: ak820_eeprom_update_block_xdata(candidate, (void *)AK820_SETTINGS_ADDR, sizeof(candidate));
      0045C1 90 05 95         [24]  548 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0045C4 74 A8            [12]  549 	mov	a,#0xa8
      0045C6 F0               [24]  550 	movx	@dptr,a
      0045C7 74 06            [12]  551 	mov	a,#0x06
      0045C9 12 38 5B         [24]  552 	lcall	_ak820_outline_0070
      0045CC 90 05 98         [24]  553 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0045CF 12 49 61         [24]  554 	lcall	_ak820_outline_0042
      0045D2 12 42 26         [24]  555 	lcall	_ak820_eeprom_update_block_xdata
                                    556 ;	keyboards/ajazz/ak820/ak820_settings.c:54: ak820_nvm_end();
      0045D5 12 3F 99         [24]  557 	lcall	_ak820_nvm_end
                                    558 ;	keyboards/ajazz/ak820/ak820_settings.c:55: if (!ak820_nvm_ok()) return -1;
      0045D8 12 3E 23         [24]  559 	lcall	_ak820_nvm_ok
      0045DB E5 82            [12]  560 	mov	a, dpl
      0045DD 70 04            [24]  561 	jnz	00106$
      0045DF 90 FF FF         [24]  562 	mov	dptr,#0xffff
      0045E2 22               [24]  563 	ret
      0045E3                        564 00106$:
                                    565 ;	keyboards/ajazz/ak820/ak820_settings.c:56: memcpy(current, candidate, sizeof(current));
      0045E3 12 49 3D         [24]  566 	lcall	_ak820_outline_0020
      0045E6 12 BE 74         [24]  567 	lcall	___memcpy
                                    568 ;	keyboards/ajazz/ak820/ak820_settings.c:57: return 0;
      0045E9 90 00 00         [24]  569 	mov	dptr,#0x0000
                                    570 ;	keyboards/ajazz/ak820/ak820_settings.c:58: }
      0045EC 22               [24]  571 	ret
                                    572 ;------------------------------------------------------------
                                    573 ;Allocation info for local variables in function 'ak820_settings_init'
                                    574 ;------------------------------------------------------------
                                    575 ;i             Allocated with name '_ak820_settings_init_i_10000_82'
                                    576 ;blank_zero    Allocated with name '_ak820_settings_init_blank_zero_10000_82'
                                    577 ;blank_erased  Allocated with name '_ak820_settings_init_blank_erased_10000_82'
                                    578 ;------------------------------------------------------------
                                    579 ;	keyboards/ajazz/ak820/ak820_settings.c:59: void ak820_settings_init(void) {
                                    580 ;	-----------------------------------------
                                    581 ;	 function ak820_settings_init
                                    582 ;	-----------------------------------------
      0045ED                        583 _ak820_settings_init:
                                    584 ;	keyboards/ajazz/ak820/ak820_settings.c:61: bool blank_zero = true, blank_erased = true;
      0045ED 90 05 D6         [24]  585 	mov	dptr,#_ak820_settings_init_blank_zero_10000_82
      0045F0 74 01            [12]  586 	mov	a,#0x01
      0045F2 F0               [24]  587 	movx	@dptr,a
      0045F3 90 05 D7         [24]  588 	mov	dptr,#_ak820_settings_init_blank_erased_10000_82
      0045F6 F0               [24]  589 	movx	@dptr,a
                                    590 ;	keyboards/ajazz/ak820/ak820_settings.c:62: ak820_eeprom_read_block_xdata(candidate, (const void *)AK820_SETTINGS_ADDR, sizeof(candidate));
      0045F7 90 05 85         [24]  591 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0045FA 74 A8            [12]  592 	mov	a,#0xa8
      0045FC F0               [24]  593 	movx	@dptr,a
      0045FD 74 06            [12]  594 	mov	a,#0x06
      0045FF 12 38 5B         [24]  595 	lcall	_ak820_outline_0070
      004602 90 05 88         [24]  596 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004605 12 49 61         [24]  597 	lcall	_ak820_outline_0042
      004608 12 40 B7         [24]  598 	lcall	_ak820_eeprom_read_block_xdata
                                    599 ;	keyboards/ajazz/ak820/ak820_settings.c:63: if (!valid()) {
      00460B 12 44 A1         [24]  600 	lcall	_valid
      00460E E5 82            [12]  601 	mov	a, dpl
                                    602 ;	keyboards/ajazz/ak820/ak820_settings.c:66: for (i = 0; i < sizeof(candidate); ++i) {
      004610 70 38            [24]  603 	jnz	00110$
      004612 FF               [12]  604 	mov	r7,a
      004613                        605 00111$:
                                    606 ;	keyboards/ajazz/ak820/ak820_settings.c:67: if (candidate[i]) blank_zero = false;
      004613 EF               [12]  607 	mov	a,r7
      004614 24 B6            [12]  608 	add	a, #_candidate
      004616 FD               [12]  609 	mov	r5,a
      004617 E4               [12]  610 	clr	a
      004618 34 05            [12]  611 	addc	a, #(_candidate >> 8)
      00461A 12 49 85         [24]  612 	lcall	_ak820_outline_0069
      00461D 60 05            [24]  613 	jz	00102$
      00461F 90 05 D6         [24]  614 	mov	dptr,#_ak820_settings_init_blank_zero_10000_82
      004622 E4               [12]  615 	clr	a
      004623 F0               [24]  616 	movx	@dptr,a
      004624                        617 00102$:
                                    618 ;	keyboards/ajazz/ak820/ak820_settings.c:68: if (candidate[i] != 0xFF) blank_erased = false;
      004624 12 49 AD         [24]  619 	lcall	_ak820_outline_0110
      004627 FE               [12]  620 	mov	r6,a
      004628 BE FF 02         [24]  621 	cjne	r6,#0xff,00167$
      00462B 80 05            [24]  622 	sjmp	00112$
      00462D                        623 00167$:
      00462D 90 05 D7         [24]  624 	mov	dptr,#_ak820_settings_init_blank_erased_10000_82
      004630 E4               [12]  625 	clr	a
      004631 F0               [24]  626 	movx	@dptr,a
      004632                        627 00112$:
                                    628 ;	keyboards/ajazz/ak820/ak820_settings.c:66: for (i = 0; i < sizeof(candidate); ++i) {
      004632 0F               [12]  629 	inc	r7
      004633 BF 18 00         [24]  630 	cjne	r7,#0x18,00168$
      004636                        631 00168$:
      004636 40 DB            [24]  632 	jc	00111$
                                    633 ;	keyboards/ajazz/ak820/ak820_settings.c:70: if (!blank_zero && !blank_erased) ak820_nvm_schema_fault();
      004638 90 05 D6         [24]  634 	mov	dptr,#_ak820_settings_init_blank_zero_10000_82
      00463B E0               [24]  635 	movx	a,@dptr
      00463C 70 09            [24]  636 	jnz	00107$
      00463E 90 05 D7         [24]  637 	mov	dptr,#_ak820_settings_init_blank_erased_10000_82
      004641 E0               [24]  638 	movx	a,@dptr
      004642 70 03            [24]  639 	jnz	00107$
      004644 12 3E 2C         [24]  640 	lcall	_ak820_nvm_schema_fault
      004647                        641 00107$:
                                    642 ;	keyboards/ajazz/ak820/ak820_settings.c:71: defaults();
      004647 12 44 38         [24]  643 	lcall	_defaults
      00464A                        644 00110$:
                                    645 ;	keyboards/ajazz/ak820/ak820_settings.c:73: memcpy(current, candidate, sizeof(current));
      00464A 12 49 3D         [24]  646 	lcall	_ak820_outline_0020
                                    647 ;	keyboards/ajazz/ak820/ak820_settings.c:74: }
      00464D 02 BE 74         [24]  648 	ljmp	___memcpy
                                    649 ;------------------------------------------------------------
                                    650 ;Allocation info for local variables in function 'offset'
                                    651 ;------------------------------------------------------------
                                    652 ;id            Allocated with name '_offset_id_10000_90'
                                    653 ;------------------------------------------------------------
                                    654 ;	keyboards/ajazz/ak820/ak820_settings.c:75: static uint8_t offset(uint16_t id) {
                                    655 ;	-----------------------------------------
                                    656 ;	 function offset
                                    657 ;	-----------------------------------------
      004650                        658 _offset:
      004650 12 38 79         [24]  659 	lcall	_ak820_outline_0113
      004653 90 05 D8         [24]  660 	mov	dptr,#_offset_id_10000_90
      004656 12 38 7E         [24]  661 	lcall	_ak820_outline_0114
                                    662 ;	keyboards/ajazz/ak820/ak820_settings.c:76: switch (id) {
      004659 90 05 D8         [24]  663 	mov	dptr,#_offset_id_10000_90
      00465C 12 38 3E         [24]  664 	lcall	_ak820_outline_0055
      00465F BE 01 05         [24]  665 	cjne	r6,#0x01,00145$
      004662 BF 00 02         [24]  666 	cjne	r7,#0x00,00145$
      004665 80 20            [24]  667 	sjmp	00101$
      004667                        668 00145$:
      004667 BE 02 05         [24]  669 	cjne	r6,#0x02,00146$
      00466A BF 00 02         [24]  670 	cjne	r7,#0x00,00146$
      00466D 80 1C            [24]  671 	sjmp	00102$
      00466F                        672 00146$:
      00466F BE 07 05         [24]  673 	cjne	r6,#0x07,00147$
      004672 BF 00 02         [24]  674 	cjne	r7,#0x00,00147$
      004675 80 18            [24]  675 	sjmp	00103$
      004677                        676 00147$:
      004677 BE 12 05         [24]  677 	cjne	r6,#0x12,00148$
      00467A BF 00 02         [24]  678 	cjne	r7,#0x00,00148$
      00467D 80 14            [24]  679 	sjmp	00104$
      00467F                        680 00148$:
                                    681 ;	keyboards/ajazz/ak820/ak820_settings.c:77: case 1: return 5;
      00467F BE 13 19         [24]  682 	cjne	r6,#0x13,00106$
      004682 BF 00 16         [24]  683 	cjne	r7,#0x00,00106$
      004685 80 10            [24]  684 	sjmp	00105$
      004687                        685 00101$:
      004687 75 82 05         [24]  686 	mov	dpl, #0x05
                                    687 ;	keyboards/ajazz/ak820/ak820_settings.c:78: case 2: return 6;
      00468A 22               [24]  688 	ret
      00468B                        689 00102$:
      00468B 75 82 06         [24]  690 	mov	dpl, #0x06
                                    691 ;	keyboards/ajazz/ak820/ak820_settings.c:82: case 7: return 8;
      00468E 22               [24]  692 	ret
      00468F                        693 00103$:
      00468F 75 82 08         [24]  694 	mov	dpl, #0x08
                                    695 ;	keyboards/ajazz/ak820/ak820_settings.c:83: case 18: return 10;
      004692 22               [24]  696 	ret
      004693                        697 00104$:
      004693 75 82 0A         [24]  698 	mov	dpl, #0x0a
                                    699 ;	keyboards/ajazz/ak820/ak820_settings.c:84: case 19: return 12;
      004696 22               [24]  700 	ret
      004697                        701 00105$:
      004697 75 82 0C         [24]  702 	mov	dpl, #0x0c
                                    703 ;	keyboards/ajazz/ak820/ak820_settings.c:85: default: return 0;
      00469A 22               [24]  704 	ret
      00469B                        705 00106$:
      00469B 75 82 00         [24]  706 	mov	dpl, #0x00
                                    707 ;	keyboards/ajazz/ak820/ak820_settings.c:86: }
                                    708 ;	keyboards/ajazz/ak820/ak820_settings.c:87: }
      00469E 22               [24]  709 	ret
                                    710 ;------------------------------------------------------------
                                    711 ;Allocation info for local variables in function 'ak820_settings_query'
                                    712 ;------------------------------------------------------------
                                    713 ;sloc0         Allocated with name '_ak820_settings_query_sloc0_1_0'
                                    714 ;sloc1         Allocated with name '_ak820_settings_query_sloc1_1_0'
                                    715 ;sloc2         Allocated with name '_ak820_settings_query_sloc2_1_0'
                                    716 ;buffer        Allocated with name '_ak820_settings_query_PARM_2'
                                    717 ;size          Allocated with name '_ak820_settings_query_PARM_3'
                                    718 ;greater_than  Allocated with name '_ak820_settings_query_greater_than_10000_94'
                                    719 ;out           Allocated with name '_ak820_settings_query_out_10000_95'
                                    720 ;id            Allocated with name '_ak820_settings_query_id_10000_95'
                                    721 ;used          Allocated with name '_ak820_settings_query_used_10000_95'
                                    722 ;------------------------------------------------------------
                                    723 ;	keyboards/ajazz/ak820/ak820_settings.c:88: void ak820_settings_query(uint16_t greater_than, void *buffer, size_t size) {
                                    724 ;	-----------------------------------------
                                    725 ;	 function ak820_settings_query
                                    726 ;	-----------------------------------------
      00469F                        727 _ak820_settings_query:
      00469F 12 38 79         [24]  728 	lcall	_ak820_outline_0113
      0046A2 90 05 DF         [24]  729 	mov	dptr,#_ak820_settings_query_greater_than_10000_94
      0046A5 12 38 7E         [24]  730 	lcall	_ak820_outline_0114
                                    731 ;	keyboards/ajazz/ak820/ak820_settings.c:89: uint8_t *out = buffer;
      0046A8 90 05 DA         [24]  732 	mov	dptr,#_ak820_settings_query_PARM_2
      0046AB 12 49 34         [24]  733 	lcall	_ak820_outline_0013
      0046AE 8D 02            [24]  734 	mov	ar2,r5
      0046B0 8E 03            [24]  735 	mov	ar3,r6
      0046B2 8F 04            [24]  736 	mov	ar4,r7
                                    737 ;	keyboards/ajazz/ak820/ak820_settings.c:91: size_t used = 0;
      0046B4 90 05 E1         [24]  738 	mov	dptr,#_ak820_settings_query_used_10000_95
      0046B7 12 49 BF         [24]  739 	lcall	_ak820_outline_0177
                                    740 ;	keyboards/ajazz/ak820/ak820_settings.c:92: memset(buffer, 0xFF, size);
      0046BA 90 05 DD         [24]  741 	mov	dptr,#_ak820_settings_query_PARM_3
      0046BD 12 38 73         [24]  742 	lcall	_ak820_outline_0107
      0046C0 90 0D F9         [24]  743 	mov	dptr,#_memset_PARM_2
      0046C3 74 FF            [12]  744 	mov	a,#0xff
      0046C5 F0               [24]  745 	movx	@dptr,a
      0046C6 90 0D FA         [24]  746 	mov	dptr,#_memset_PARM_3
      0046C9 E8               [12]  747 	mov	a,r0
      0046CA F0               [24]  748 	movx	@dptr,a
      0046CB E9               [12]  749 	mov	a,r1
      0046CC A3               [24]  750 	inc	dptr
      0046CD 12 49 59         [24]  751 	lcall	_ak820_outline_0033
      0046D0 C0 04            [24]  752 	push	ar4
      0046D2 C0 03            [24]  753 	push	ar3
      0046D4 C0 02            [24]  754 	push	ar2
      0046D6 C0 01            [24]  755 	push	ar1
      0046D8 C0 00            [24]  756 	push	ar0
      0046DA 12 BE EA         [24]  757 	lcall	_memset
      0046DD D0 00            [24]  758 	pop	ar0
      0046DF D0 01            [24]  759 	pop	ar1
      0046E1 D0 02            [24]  760 	pop	ar2
      0046E3 D0 03            [24]  761 	pop	ar3
      0046E5 D0 04            [24]  762 	pop	ar4
                                    763 ;	keyboards/ajazz/ak820/ak820_settings.c:93: for (id = 1; id <= 19 && used + 2 <= size; ++id) {
      0046E7 90 05 DF         [24]  764 	mov	dptr,#_ak820_settings_query_greater_than_10000_94
      0046EA 12 38 3E         [24]  765 	lcall	_ak820_outline_0055
      0046ED 75 15 01         [24]  766 	mov	_ak820_settings_query_sloc0_1_0,#0x01
      0046F0 75 16 00         [24]  767 	mov	(_ak820_settings_query_sloc0_1_0 + 1),#0x00
      0046F3                        768 00107$:
      0046F3 C0 06            [24]  769 	push	ar6
      0046F5 C0 07            [24]  770 	push	ar7
      0046F7 AD 15            [24]  771 	mov	r5,_ak820_settings_query_sloc0_1_0
      0046F9 AF 16            [24]  772 	mov	r7,(_ak820_settings_query_sloc0_1_0 + 1)
      0046FB C3               [12]  773 	clr	c
      0046FC 74 13            [12]  774 	mov	a,#0x13
      0046FE 9D               [12]  775 	subb	a,r5
      0046FF E4               [12]  776 	clr	a
      004700 9F               [12]  777 	subb	a,r7
      004701 D0 07            [24]  778 	pop	ar7
      004703 D0 06            [24]  779 	pop	ar6
      004705 50 01            [24]  780 	jnc	00147$
      004707 22               [24]  781 	ret
      004708                        782 00147$:
                                    783 ;	free result
      004708 C0 06            [24]  784 	push	ar6
      00470A C0 07            [24]  785 	push	ar7
      00470C 90 05 E1         [24]  786 	mov	dptr,#_ak820_settings_query_used_10000_95
      00470F E0               [24]  787 	movx	a,@dptr
      004710 F5 17            [12]  788 	mov	_ak820_settings_query_sloc1_1_0,a
      004712 A3               [24]  789 	inc	dptr
      004713 E0               [24]  790 	movx	a,@dptr
      004714 F5 18            [12]  791 	mov	(_ak820_settings_query_sloc1_1_0 + 1),a
      004716 74 02            [12]  792 	mov	a,#0x02
      004718 25 17            [12]  793 	add	a, _ak820_settings_query_sloc1_1_0
      00471A FD               [12]  794 	mov	r5,a
      00471B E4               [12]  795 	clr	a
      00471C 35 18            [12]  796 	addc	a, (_ak820_settings_query_sloc1_1_0 + 1)
      00471E FF               [12]  797 	mov	r7,a
      00471F C3               [12]  798 	clr	c
      004720 E8               [12]  799 	mov	a,r0
      004721 9D               [12]  800 	subb	a,r5
      004722 E9               [12]  801 	mov	a,r1
      004723 9F               [12]  802 	subb	a,r7
      004724 D0 07            [24]  803 	pop	ar7
      004726 D0 06            [24]  804 	pop	ar6
      004728 50 01            [24]  805 	jnc	00148$
      00472A 22               [24]  806 	ret
      00472B                        807 00148$:
                                    808 ;	free result
                                    809 ;	keyboards/ajazz/ak820/ak820_settings.c:94: if (id > greater_than && offset(id)) { out[used++] = id; out[used++] = 0; }
      00472B C3               [12]  810 	clr	c
      00472C EE               [12]  811 	mov	a,r6
      00472D 95 15            [12]  812 	subb	a,_ak820_settings_query_sloc0_1_0
      00472F EF               [12]  813 	mov	a,r7
      004730 95 16            [12]  814 	subb	a,(_ak820_settings_query_sloc0_1_0 + 1)
      004732 40 03            [24]  815 	jc	00149$
      004734 02 47 B0         [24]  816 	ljmp	00108$
      004737                        817 00149$:
                                    818 ;	free result
      004737 85 15 82         [24]  819 	mov	dpl, _ak820_settings_query_sloc0_1_0
      00473A 85 16 83         [24]  820 	mov	dph, (_ak820_settings_query_sloc0_1_0 + 1)
      00473D C0 07            [24]  821 	push	ar7
      00473F C0 06            [24]  822 	push	ar6
      004741 C0 04            [24]  823 	push	ar4
      004743 C0 03            [24]  824 	push	ar3
      004745 C0 02            [24]  825 	push	ar2
      004747 C0 01            [24]  826 	push	ar1
      004749 C0 00            [24]  827 	push	ar0
      00474B 12 46 50         [24]  828 	lcall	_offset
      00474E E5 82            [12]  829 	mov	a, dpl
      004750 D0 00            [24]  830 	pop	ar0
      004752 D0 01            [24]  831 	pop	ar1
      004754 D0 02            [24]  832 	pop	ar2
      004756 D0 03            [24]  833 	pop	ar3
      004758 D0 04            [24]  834 	pop	ar4
      00475A D0 06            [24]  835 	pop	ar6
      00475C D0 07            [24]  836 	pop	ar7
      00475E 60 50            [24]  837 	jz	00108$
      004760 C0 06            [24]  838 	push	ar6
      004762 C0 07            [24]  839 	push	ar7
      004764 90 05 E1         [24]  840 	mov	dptr,#_ak820_settings_query_used_10000_95
      004767 74 01            [12]  841 	mov	a,#0x01
      004769 25 17            [12]  842 	add	a, _ak820_settings_query_sloc1_1_0
      00476B F0               [24]  843 	movx	@dptr,a
      00476C E4               [12]  844 	clr	a
      00476D 35 18            [12]  845 	addc	a, (_ak820_settings_query_sloc1_1_0 + 1)
      00476F A3               [24]  846 	inc	dptr
      004770 F0               [24]  847 	movx	@dptr,a
      004771 E5 17            [12]  848 	mov	a,_ak820_settings_query_sloc1_1_0
      004773 2A               [12]  849 	add	a, r2
      004774 F5 19            [12]  850 	mov	_ak820_settings_query_sloc2_1_0,a
      004776 E5 18            [12]  851 	mov	a,(_ak820_settings_query_sloc1_1_0 + 1)
      004778 3B               [12]  852 	addc	a, r3
      004779 F5 1A            [12]  853 	mov	(_ak820_settings_query_sloc2_1_0 + 1),a
      00477B 8C 1B            [24]  854 	mov	(_ak820_settings_query_sloc2_1_0 + 2),r4
      00477D AF 15            [24]  855 	mov	r7,_ak820_settings_query_sloc0_1_0
      00477F 85 19 82         [24]  856 	mov	dpl,_ak820_settings_query_sloc2_1_0
      004782 85 1A 83         [24]  857 	mov	dph,(_ak820_settings_query_sloc2_1_0 + 1)
      004785 85 1B F0         [24]  858 	mov	b,(_ak820_settings_query_sloc2_1_0 + 2)
      004788 EF               [12]  859 	mov	a,r7
      004789 12 BF 12         [24]  860 	lcall	__gptrput
      00478C 90 05 E1         [24]  861 	mov	dptr,#_ak820_settings_query_used_10000_95
      00478F 12 38 3E         [24]  862 	lcall	_ak820_outline_0055
      004792 90 05 E1         [24]  863 	mov	dptr,#_ak820_settings_query_used_10000_95
      004795 74 01            [12]  864 	mov	a,#0x01
      004797 2E               [12]  865 	add	a, r6
      004798 F0               [24]  866 	movx	@dptr,a
      004799 E4               [12]  867 	clr	a
      00479A 3F               [12]  868 	addc	a, r7
      00479B A3               [24]  869 	inc	dptr
      00479C F0               [24]  870 	movx	@dptr,a
      00479D EE               [12]  871 	mov	a,r6
      00479E 2A               [12]  872 	add	a, r2
      00479F FE               [12]  873 	mov	r6,a
      0047A0 EF               [12]  874 	mov	a,r7
      0047A1 3B               [12]  875 	addc	a, r3
      0047A2 FF               [12]  876 	mov	r7,a
      0047A3 8C 05            [24]  877 	mov	ar5,r4
      0047A5 12 49 7E         [24]  878 	lcall	_ak820_outline_0061
      0047A8 E4               [12]  879 	clr	a
      0047A9 12 BF 12         [24]  880 	lcall	__gptrput
                                    881 ;	keyboards/ajazz/ak820/ak820_settings.c:93: for (id = 1; id <= 19 && used + 2 <= size; ++id) {
      0047AC D0 07            [24]  882 	pop	ar7
      0047AE D0 06            [24]  883 	pop	ar6
                                    884 ;	keyboards/ajazz/ak820/ak820_settings.c:94: if (id > greater_than && offset(id)) { out[used++] = id; out[used++] = 0; }
      0047B0                        885 00108$:
                                    886 ;	keyboards/ajazz/ak820/ak820_settings.c:93: for (id = 1; id <= 19 && used + 2 <= size; ++id) {
      0047B0 05 15            [12]  887 	inc	_ak820_settings_query_sloc0_1_0
      0047B2 E4               [12]  888 	clr	a
      0047B3 B5 15 02         [24]  889 	cjne	a,_ak820_settings_query_sloc0_1_0,00151$
      0047B6 05 16            [12]  890 	inc	(_ak820_settings_query_sloc0_1_0 + 1)
      0047B8                        891 00151$:
                                    892 ;	keyboards/ajazz/ak820/ak820_settings.c:96: }
      0047B8 02 46 F3         [24]  893 	ljmp	00107$
                                    894 ;------------------------------------------------------------
                                    895 ;Allocation info for local variables in function 'ak820_settings_get'
                                    896 ;------------------------------------------------------------
                                    897 ;buffer        Allocated with name '_ak820_settings_get_PARM_2'
                                    898 ;capacity      Allocated with name '_ak820_settings_get_PARM_3'
                                    899 ;id            Allocated with name '_ak820_settings_get_id_10000_100'
                                    900 ;out           Allocated with name '_ak820_settings_get_out_10000_101'
                                    901 ;pos           Allocated with name '_ak820_settings_get_pos_10000_101'
                                    902 ;width         Allocated with name '_ak820_settings_get_width_10000_101'
                                    903 ;------------------------------------------------------------
                                    904 ;	keyboards/ajazz/ak820/ak820_settings.c:97: int ak820_settings_get(uint16_t id, void *buffer, size_t capacity) {
                                    905 ;	-----------------------------------------
                                    906 ;	 function ak820_settings_get
                                    907 ;	-----------------------------------------
      0047BB                        908 _ak820_settings_get:
      0047BB 12 38 79         [24]  909 	lcall	_ak820_outline_0113
      0047BE 90 05 E8         [24]  910 	mov	dptr,#_ak820_settings_get_id_10000_100
      0047C1 12 38 7E         [24]  911 	lcall	_ak820_outline_0114
                                    912 ;	keyboards/ajazz/ak820/ak820_settings.c:98: uint8_t *out = buffer;
      0047C4 90 05 E3         [24]  913 	mov	dptr,#_ak820_settings_get_PARM_2
      0047C7 12 49 34         [24]  914 	lcall	_ak820_outline_0013
                                    915 ;	keyboards/ajazz/ak820/ak820_settings.c:99: uint8_t pos = offset(id), width = id == 1 ? 1 : 2;
      0047CA 90 05 E8         [24]  916 	mov	dptr,#_ak820_settings_get_id_10000_100
      0047CD 12 49 8C         [24]  917 	lcall	_ak820_outline_0076
      0047D0 C0 07            [24]  918 	push	ar7
      0047D2 C0 06            [24]  919 	push	ar6
      0047D4 C0 05            [24]  920 	push	ar5
      0047D6 C0 04            [24]  921 	push	ar4
      0047D8 C0 03            [24]  922 	push	ar3
      0047DA 12 46 50         [24]  923 	lcall	_offset
      0047DD AA 82            [24]  924 	mov	r2, dpl
      0047DF D0 03            [24]  925 	pop	ar3
      0047E1 D0 04            [24]  926 	pop	ar4
      0047E3 D0 05            [24]  927 	pop	ar5
      0047E5 D0 06            [24]  928 	pop	ar6
      0047E7 D0 07            [24]  929 	pop	ar7
      0047E9 BB 01 07         [24]  930 	cjne	r3,#0x01,00108$
      0047EC BC 00 04         [24]  931 	cjne	r4,#0x00,00108$
      0047EF 7C 01            [12]  932 	mov	r4,#0x01
      0047F1 80 02            [24]  933 	sjmp	00109$
      0047F3                        934 00108$:
      0047F3 7C 02            [12]  935 	mov	r4,#0x02
      0047F5                        936 00109$:
                                    937 ;	keyboards/ajazz/ak820/ak820_settings.c:100: if (!pos || capacity < width) return -1;
      0047F5 EA               [12]  938 	mov	a,r2
      0047F6 60 14            [24]  939 	jz	00101$
      0047F8 C0 05            [24]  940 	push	ar5
      0047FA C0 06            [24]  941 	push	ar6
      0047FC C0 07            [24]  942 	push	ar7
      0047FE 90 05 E6         [24]  943 	mov	dptr,#_ak820_settings_get_PARM_3
      004801 12 49 96         [24]  944 	lcall	_ak820_outline_0080
      004804 D0 07            [24]  945 	pop	ar7
      004806 D0 06            [24]  946 	pop	ar6
      004808 D0 05            [24]  947 	pop	ar5
      00480A 50 04            [24]  948 	jnc	00102$
      00480C                        949 00101$:
      00480C 90 FF FF         [24]  950 	mov	dptr,#0xffff
      00480F 22               [24]  951 	ret
      004810                        952 00102$:
                                    953 ;	keyboards/ajazz/ak820/ak820_settings.c:101: out[0] = current[pos];
      004810 EA               [12]  954 	mov	a,r2
      004811 24 9E            [12]  955 	add	a, #_current
      004813 F5 82            [12]  956 	mov	dpl,a
      004815 E4               [12]  957 	clr	a
      004816 34 05            [12]  958 	addc	a, #(_current >> 8)
      004818 F5 83            [12]  959 	mov	dph,a
      00481A E0               [24]  960 	movx	a,@dptr
      00481B 12 49 77         [24]  961 	lcall	_ak820_outline_0050
      00481E 12 BF 12         [24]  962 	lcall	__gptrput
                                    963 ;	keyboards/ajazz/ak820/ak820_settings.c:102: if (width == 2) out[1] = current[pos + 1];
      004821 BC 02 1C         [24]  964 	cjne	r4,#0x02,00105$
      004824 0D               [12]  965 	inc	r5
      004825 BD 00 01         [24]  966 	cjne	r5,#0x00,00137$
      004828 0E               [12]  967 	inc	r6
      004829                        968 00137$:
      004829 0A               [12]  969 	inc	r2
      00482A EA               [12]  970 	mov	a,r2
      00482B 33               [12]  971 	rlc	a
      00482C 95 E0            [12]  972 	subb	a,acc
      00482E FC               [12]  973 	mov	r4,a
      00482F EA               [12]  974 	mov	a,r2
      004830 24 9E            [12]  975 	add	a, #_current
      004832 F5 82            [12]  976 	mov	dpl,a
      004834 EC               [12]  977 	mov	a,r4
      004835 34 05            [12]  978 	addc	a, #(_current >> 8)
      004837 F5 83            [12]  979 	mov	dph,a
      004839 E0               [24]  980 	movx	a,@dptr
      00483A 12 49 77         [24]  981 	lcall	_ak820_outline_0050
      00483D 12 BF 12         [24]  982 	lcall	__gptrput
      004840                        983 00105$:
                                    984 ;	keyboards/ajazz/ak820/ak820_settings.c:103: return 0;
      004840 90 00 00         [24]  985 	mov	dptr,#0x0000
                                    986 ;	keyboards/ajazz/ak820/ak820_settings.c:104: }
      004843 22               [24]  987 	ret
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'ak820_settings_set'
                                    990 ;------------------------------------------------------------
                                    991 ;buffer        Allocated with name '_ak820_settings_set_PARM_2'
                                    992 ;capacity      Allocated with name '_ak820_settings_set_PARM_3'
                                    993 ;id            Allocated with name '_ak820_settings_set_id_10000_104'
                                    994 ;in            Allocated with name '_ak820_settings_set_in_10000_105'
                                    995 ;pos           Allocated with name '_ak820_settings_set_pos_10000_105'
                                    996 ;width         Allocated with name '_ak820_settings_set_width_10000_105'
                                    997 ;------------------------------------------------------------
                                    998 ;	keyboards/ajazz/ak820/ak820_settings.c:105: int ak820_settings_set(uint16_t id, const void *buffer, size_t capacity) {
                                    999 ;	-----------------------------------------
                                   1000 ;	 function ak820_settings_set
                                   1001 ;	-----------------------------------------
      004844                       1002 _ak820_settings_set:
      004844 12 38 79         [24] 1003 	lcall	_ak820_outline_0113
      004847 90 05 EF         [24] 1004 	mov	dptr,#_ak820_settings_set_id_10000_104
      00484A 12 38 7E         [24] 1005 	lcall	_ak820_outline_0114
                                   1006 ;	keyboards/ajazz/ak820/ak820_settings.c:106: const uint8_t *in = buffer;
      00484D 90 05 EA         [24] 1007 	mov	dptr,#_ak820_settings_set_PARM_2
      004850 12 49 34         [24] 1008 	lcall	_ak820_outline_0013
                                   1009 ;	keyboards/ajazz/ak820/ak820_settings.c:107: uint8_t pos = offset(id), width = id == 1 ? 1 : 2;
      004853 90 05 EF         [24] 1010 	mov	dptr,#_ak820_settings_set_id_10000_104
      004856 12 49 8C         [24] 1011 	lcall	_ak820_outline_0076
      004859 C0 07            [24] 1012 	push	ar7
      00485B C0 06            [24] 1013 	push	ar6
      00485D C0 05            [24] 1014 	push	ar5
      00485F C0 04            [24] 1015 	push	ar4
      004861 C0 03            [24] 1016 	push	ar3
      004863 12 46 50         [24] 1017 	lcall	_offset
      004866 AA 82            [24] 1018 	mov	r2, dpl
      004868 D0 03            [24] 1019 	pop	ar3
      00486A D0 04            [24] 1020 	pop	ar4
      00486C D0 05            [24] 1021 	pop	ar5
      00486E D0 06            [24] 1022 	pop	ar6
      004870 D0 07            [24] 1023 	pop	ar7
      004872 BB 01 07         [24] 1024 	cjne	r3,#0x01,00111$
      004875 BC 00 04         [24] 1025 	cjne	r4,#0x00,00111$
      004878 7C 01            [12] 1026 	mov	r4,#0x01
      00487A 80 02            [24] 1027 	sjmp	00112$
      00487C                       1028 00111$:
      00487C 7C 02            [12] 1029 	mov	r4,#0x02
      00487E                       1030 00112$:
                                   1031 ;	keyboards/ajazz/ak820/ak820_settings.c:108: if (!pos || capacity < width || !ak820_nvm_ok()) return -1;
      00487E EA               [12] 1032 	mov	a,r2
      00487F 60 1B            [24] 1033 	jz	00101$
      004881 C0 05            [24] 1034 	push	ar5
      004883 C0 06            [24] 1035 	push	ar6
      004885 C0 07            [24] 1036 	push	ar7
      004887 90 05 ED         [24] 1037 	mov	dptr,#_ak820_settings_set_PARM_3
      00488A 12 49 96         [24] 1038 	lcall	_ak820_outline_0080
      00488D D0 07            [24] 1039 	pop	ar7
      00488F D0 06            [24] 1040 	pop	ar6
      004891 D0 05            [24] 1041 	pop	ar5
      004893 40 07            [24] 1042 	jc	00101$
      004895 12 3E 23         [24] 1043 	lcall	_ak820_nvm_ok
      004898 E5 82            [12] 1044 	mov	a, dpl
      00489A 70 04            [24] 1045 	jnz	00102$
      00489C                       1046 00101$:
      00489C 90 FF FF         [24] 1047 	mov	dptr,#0xffff
      00489F 22               [24] 1048 	ret
      0048A0                       1049 00102$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_settings.c:109: memcpy(candidate, current, sizeof(candidate));
      0048A0 90 0D F1         [24] 1051 	mov	dptr,#___memcpy_PARM_2
      0048A3 74 9E            [12] 1052 	mov	a,#_current
      0048A5 F0               [24] 1053 	movx	@dptr,a
      0048A6 74 05            [12] 1054 	mov	a,#(_current >> 8)
      0048A8 12 38 5B         [24] 1055 	lcall	_ak820_outline_0070
      0048AB 90 0D F4         [24] 1056 	mov	dptr,#___memcpy_PARM_3
      0048AE 12 49 61         [24] 1057 	lcall	_ak820_outline_0042
      0048B1 F5 F0            [12] 1058 	mov	b,a
      0048B3 C0 07            [24] 1059 	push	ar7
      0048B5 C0 06            [24] 1060 	push	ar6
      0048B7 C0 05            [24] 1061 	push	ar5
      0048B9 C0 04            [24] 1062 	push	ar4
      0048BB C0 02            [24] 1063 	push	ar2
      0048BD 12 BE 74         [24] 1064 	lcall	___memcpy
      0048C0 D0 02            [24] 1065 	pop	ar2
      0048C2 D0 04            [24] 1066 	pop	ar4
      0048C4 D0 05            [24] 1067 	pop	ar5
      0048C6 D0 06            [24] 1068 	pop	ar6
      0048C8 D0 07            [24] 1069 	pop	ar7
                                   1070 ;	keyboards/ajazz/ak820/ak820_settings.c:110: candidate[pos] = in[0];
      0048CA EA               [12] 1071 	mov	a,r2
      0048CB 24 B6            [12] 1072 	add	a, #_candidate
      0048CD F9               [12] 1073 	mov	r1,a
      0048CE E4               [12] 1074 	clr	a
      0048CF 34 05            [12] 1075 	addc	a, #(_candidate >> 8)
      0048D1 FB               [12] 1076 	mov	r3,a
      0048D2 12 49 77         [24] 1077 	lcall	_ak820_outline_0050
      0048D5 12 C0 37         [24] 1078 	lcall	__gptrget
      0048D8 89 82            [24] 1079 	mov	dpl,r1
      0048DA 8B 83            [24] 1080 	mov	dph,r3
      0048DC F0               [24] 1081 	movx	@dptr,a
                                   1082 ;	keyboards/ajazz/ak820/ak820_settings.c:111: if (width == 2) candidate[pos + 1] = in[1];
      0048DD BC 02 1E         [24] 1083 	cjne	r4,#0x02,00106$
      0048E0 0A               [12] 1084 	inc	r2
      0048E1 EA               [12] 1085 	mov	a,r2
      0048E2 33               [12] 1086 	rlc	a
      0048E3 95 E0            [12] 1087 	subb	a,acc
      0048E5 FC               [12] 1088 	mov	r4,a
      0048E6 EA               [12] 1089 	mov	a,r2
      0048E7 24 B6            [12] 1090 	add	a, #_candidate
      0048E9 FA               [12] 1091 	mov	r2,a
      0048EA EC               [12] 1092 	mov	a,r4
      0048EB 34 05            [12] 1093 	addc	a, #(_candidate >> 8)
      0048ED FC               [12] 1094 	mov	r4,a
      0048EE 0D               [12] 1095 	inc	r5
      0048EF BD 00 01         [24] 1096 	cjne	r5,#0x00,00155$
      0048F2 0E               [12] 1097 	inc	r6
      0048F3                       1098 00155$:
      0048F3 12 49 77         [24] 1099 	lcall	_ak820_outline_0050
      0048F6 12 C0 37         [24] 1100 	lcall	__gptrget
      0048F9 8A 82            [24] 1101 	mov	dpl,r2
      0048FB 8C 83            [24] 1102 	mov	dph,r4
      0048FD F0               [24] 1103 	movx	@dptr,a
      0048FE                       1104 00106$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_settings.c:112: seal();
      0048FE 12 44 26         [24] 1106 	lcall	_seal
                                   1107 ;	keyboards/ajazz/ak820/ak820_settings.c:113: if (!valid()) return -1;
      004901 12 44 A1         [24] 1108 	lcall	_valid
      004904 E5 82            [12] 1109 	mov	a, dpl
      004906 70 04            [24] 1110 	jnz	00108$
      004908 90 FF FF         [24] 1111 	mov	dptr,#0xffff
      00490B 22               [24] 1112 	ret
      00490C                       1113 00108$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_settings.c:114: return commit();
                                   1115 ;	keyboards/ajazz/ak820/ak820_settings.c:115: }
      00490C 02 45 8C         [24] 1116 	ljmp	_commit
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'ak820_settings_reset'
                                   1119 ;------------------------------------------------------------
                                   1120 ;	keyboards/ajazz/ak820/ak820_settings.c:116: int ak820_settings_reset(void) { defaults(); return commit(); }
                                   1121 ;	-----------------------------------------
                                   1122 ;	 function ak820_settings_reset
                                   1123 ;	-----------------------------------------
      00490F                       1124 _ak820_settings_reset:
      00490F 12 44 38         [24] 1125 	lcall	_defaults
      004912 02 45 8C         [24] 1126 	ljmp	_commit
                                   1127 ;------------------------------------------------------------
                                   1128 ;Allocation info for local variables in function 'ak820_settings_grave_esc'
                                   1129 ;------------------------------------------------------------
                                   1130 ;	keyboards/ajazz/ak820/ak820_settings.c:117: uint8_t ak820_settings_grave_esc(void) { return current[5]; }
                                   1131 ;	-----------------------------------------
                                   1132 ;	 function ak820_settings_grave_esc
                                   1133 ;	-----------------------------------------
      004915                       1134 _ak820_settings_grave_esc:
      004915 90 05 A3         [24] 1135 	mov	dptr,#(_current + 0x0005)
      004918 E0               [24] 1136 	movx	a,@dptr
      004919 F5 82            [12] 1137 	mov	dpl,a
      00491B 22               [24] 1138 	ret
                                   1139 ;------------------------------------------------------------
                                   1140 ;Allocation info for local variables in function 'ak820_settings_combo_term'
                                   1141 ;------------------------------------------------------------
                                   1142 ;	keyboards/ajazz/ak820/ak820_settings.c:118: uint16_t ak820_settings_combo_term(void) { return word(current + 6); }
                                   1143 ;	-----------------------------------------
                                   1144 ;	 function ak820_settings_combo_term
                                   1145 ;	-----------------------------------------
      00491C                       1146 _ak820_settings_combo_term:
      00491C 90 05 A4         [24] 1147 	mov	dptr,#(_current + 0x0006)
      00491F 02 43 95         [24] 1148 	ljmp	_word
                                   1149 ;------------------------------------------------------------
                                   1150 ;Allocation info for local variables in function 'ak820_settings_tapping_term'
                                   1151 ;------------------------------------------------------------
                                   1152 ;	keyboards/ajazz/ak820/ak820_settings.c:119: uint16_t ak820_settings_tapping_term(void) { return word(current + 8); }
                                   1153 ;	-----------------------------------------
                                   1154 ;	 function ak820_settings_tapping_term
                                   1155 ;	-----------------------------------------
      004922                       1156 _ak820_settings_tapping_term:
      004922 90 05 A6         [24] 1157 	mov	dptr,#(_current + 0x0008)
      004925 02 43 95         [24] 1158 	ljmp	_word
                                   1159 ;------------------------------------------------------------
                                   1160 ;Allocation info for local variables in function 'ak820_settings_tap_code_delay'
                                   1161 ;------------------------------------------------------------
                                   1162 ;	keyboards/ajazz/ak820/ak820_settings.c:120: uint16_t ak820_settings_tap_code_delay(void) { return word(current + 10); }
                                   1163 ;	-----------------------------------------
                                   1164 ;	 function ak820_settings_tap_code_delay
                                   1165 ;	-----------------------------------------
      004928                       1166 _ak820_settings_tap_code_delay:
      004928 90 05 A8         [24] 1167 	mov	dptr,#(_current + 0x000a)
      00492B 02 43 95         [24] 1168 	ljmp	_word
                                   1169 ;------------------------------------------------------------
                                   1170 ;Allocation info for local variables in function 'ak820_settings_caps_delay'
                                   1171 ;------------------------------------------------------------
                                   1172 ;	keyboards/ajazz/ak820/ak820_settings.c:121: uint16_t ak820_settings_caps_delay(void) { return word(current + 12); }
                                   1173 ;	-----------------------------------------
                                   1174 ;	 function ak820_settings_caps_delay
                                   1175 ;	-----------------------------------------
      00492E                       1176 _ak820_settings_caps_delay:
      00492E 90 05 AA         [24] 1177 	mov	dptr,#(_current + 0x000c)
      004931 02 43 95         [24] 1178 	ljmp	_word
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'ak820_settings_autoshift_timeout'
                                   1181 ;------------------------------------------------------------
                                   1182 ;	keyboards/ajazz/ak820/ak820_settings.c:122: uint16_t ak820_settings_autoshift_timeout(void) { return word(current + 14); }
                                   1183 ;	-----------------------------------------
                                   1184 	.area CSEG    (CODE)
                                   1185 	.area CONST   (CODE)
                                   1186 	.area XINIT   (CODE)
                                   1187 	.area CABS    (ABS,CODE)
                                   1188 
                                   1189 ; Experimental exact instruction outlining.
                                   1190 	.globl _ak820_outline_0005
                                   1191 	.globl _ak820_outline_0013
                                   1192 	.globl _ak820_outline_0020
                                   1193 	.globl _ak820_outline_0033
                                   1194 	.globl _ak820_outline_0042
                                   1195 	.globl _ak820_outline_0047
                                   1196 	.globl _ak820_outline_0050
                                   1197 	.globl _ak820_outline_0055
                                   1198 	.globl _ak820_outline_0061
                                   1199 	.globl _ak820_outline_0063
                                   1200 	.globl _ak820_outline_0069
                                   1201 	.globl _ak820_outline_0070
                                   1202 	.globl _ak820_outline_0076
                                   1203 	.globl _ak820_outline_0077
                                   1204 	.globl _ak820_outline_0080
                                   1205 	.globl _ak820_outline_0084
                                   1206 	.globl _ak820_outline_0107
                                   1207 	.globl _ak820_outline_0110
                                   1208 	.globl _ak820_outline_0113
                                   1209 	.globl _ak820_outline_0114
                                   1210 	.globl _ak820_outline_0118
                                   1211 	.globl _ak820_outline_0124
                                   1212 	.globl _ak820_outline_0127
                                   1213 	.globl _ak820_outline_0131
                                   1214 	.globl _ak820_outline_0132
                                   1215 	.globl _ak820_outline_0149
                                   1216 	.globl _ak820_outline_0153
                                   1217 	.globl _ak820_outline_0154
                                   1218 	.globl _ak820_outline_0159
                                   1219 	.globl _ak820_outline_0177
                                   1220 	.globl _ak820_outline_0195
                                   1221 	.globl _ak820_outline_0197
                                   1222 
                                   1223 	.area CSEG (CODE)
                                   1224 ; function ak820_outline_0013
      004934                       1225 _ak820_outline_0013:
      004934 E0               [24] 1226 	movx	a,@dptr
      004935 FD               [12] 1227 	mov	r5,a
      004936 A3               [24] 1228 	inc	dptr
      004937 E0               [24] 1229 	movx	a,@dptr
      004938 FE               [12] 1230 	mov	r6,a
      004939 A3               [24] 1231 	inc	dptr
      00493A E0               [24] 1232 	movx	a,@dptr
      00493B FF               [12] 1233 	mov	r7,a
      00493C 22               [24] 1234 	ret
                                   1235 
                                   1236 	.area CSEG (CODE)
                                   1237 ; function ak820_outline_0020
      00493D                       1238 _ak820_outline_0020:
      00493D 90 0D F1         [24] 1239 	mov	dptr,#___memcpy_PARM_2
      004940 74 B6            [12] 1240 	mov	a,#_candidate
      004942 F0               [24] 1241 	movx	@dptr,a
      004943 74 05            [12] 1242 	mov	a,#(_candidate>>8)
      004945 A3               [24] 1243 	inc	dptr
      004946 F0               [24] 1244 	movx	@dptr,a
      004947 E4               [12] 1245 	clr	a
      004948 A3               [24] 1246 	inc	dptr
      004949 F0               [24] 1247 	movx	@dptr,a
      00494A 90 0D F4         [24] 1248 	mov	dptr,#___memcpy_PARM_3
      00494D 74 18            [12] 1249 	mov	a,#0x18
      00494F F0               [24] 1250 	movx	@dptr,a
      004950 E4               [12] 1251 	clr	a
      004951 A3               [24] 1252 	inc	dptr
      004952 F0               [24] 1253 	movx	@dptr,a
      004953 90 05 9E         [24] 1254 	mov	dptr,#_current
      004956 F5 F0            [12] 1255 	mov	b,a
      004958 22               [24] 1256 	ret
                                   1257 
                                   1258 	.area CSEG (CODE)
                                   1259 ; function ak820_outline_0033
      004959                       1260 _ak820_outline_0033:
      004959 F0               [24] 1261 	movx	@dptr,a
      00495A 8D 82            [24] 1262 	mov	dpl,r5
      00495C 8E 83            [24] 1263 	mov	dph,r6
      00495E 8F F0            [24] 1264 	mov	b,r7
      004960 22               [24] 1265 	ret
                                   1266 
                                   1267 	.area CSEG (CODE)
                                   1268 ; function ak820_outline_0042
      004961                       1269 _ak820_outline_0042:
      004961 74 18            [12] 1270 	mov	a,#0x18
      004963 F0               [24] 1271 	movx	@dptr,a
      004964 E4               [12] 1272 	clr	a
      004965 A3               [24] 1273 	inc	dptr
      004966 F0               [24] 1274 	movx	@dptr,a
      004967 90 05 B6         [24] 1275 	mov	dptr,#_candidate
      00496A 22               [24] 1276 	ret
                                   1277 
                                   1278 	.area CSEG (CODE)
                                   1279 ; function ak820_outline_0047
      00496B                       1280 _ak820_outline_0047:
      00496B AE 82            [24] 1281 	mov	r6,dpl
      00496D AF 83            [24] 1282 	mov	r7,dph
      00496F C3               [12] 1283 	clr	c
      004970 74 E8            [12] 1284 	mov	a,#0xe8
      004972 9E               [12] 1285 	subb	a,r6
      004973 74 03            [12] 1286 	mov	a,#0x03
      004975 9F               [12] 1287 	subb	a,r7
      004976 22               [24] 1288 	ret
                                   1289 
                                   1290 	.area CSEG (CODE)
                                   1291 ; function ak820_outline_0050
      004977                       1292 _ak820_outline_0050:
      004977 8D 82            [24] 1293 	mov	dpl,r5
      004979 8E 83            [24] 1294 	mov	dph,r6
      00497B 8F F0            [24] 1295 	mov	b,r7
      00497D 22               [24] 1296 	ret
                                   1297 
                                   1298 	.area CSEG (CODE)
                                   1299 ; function ak820_outline_0061
      00497E                       1300 _ak820_outline_0061:
      00497E 8E 82            [24] 1301 	mov	dpl,r6
      004980 8F 83            [24] 1302 	mov	dph,r7
      004982 8D F0            [24] 1303 	mov	b,r5
      004984 22               [24] 1304 	ret
                                   1305 
                                   1306 	.area CSEG (CODE)
                                   1307 ; function ak820_outline_0069
      004985                       1308 _ak820_outline_0069:
      004985 FE               [12] 1309 	mov	r6,a
      004986 8D 82            [24] 1310 	mov	dpl,r5
      004988 8E 83            [24] 1311 	mov	dph,r6
      00498A E0               [24] 1312 	movx	a,@dptr
      00498B 22               [24] 1313 	ret
                                   1314 
                                   1315 	.area CSEG (CODE)
                                   1316 ; function ak820_outline_0076
      00498C                       1317 _ak820_outline_0076:
      00498C E0               [24] 1318 	movx	a,@dptr
      00498D FB               [12] 1319 	mov	r3,a
      00498E A3               [24] 1320 	inc	dptr
      00498F E0               [24] 1321 	movx	a,@dptr
      004990 FC               [12] 1322 	mov	r4,a
      004991 8B 82            [24] 1323 	mov	dpl,r3
      004993 8C 83            [24] 1324 	mov	dph,r4
      004995 22               [24] 1325 	ret
                                   1326 
                                   1327 	.area CSEG (CODE)
                                   1328 ; function ak820_outline_0080
      004996                       1329 _ak820_outline_0080:
      004996 E0               [24] 1330 	movx	a,@dptr
      004997 F9               [12] 1331 	mov	r1,a
      004998 A3               [24] 1332 	inc	dptr
      004999 E0               [24] 1333 	movx	a,@dptr
      00499A FB               [12] 1334 	mov	r3,a
      00499B 8C 00            [24] 1335 	mov	ar0,r4
      00499D 7F 00            [12] 1336 	mov	r7,#0x00
      00499F C3               [12] 1337 	clr	c
      0049A0 E9               [12] 1338 	mov	a,r1
      0049A1 98               [12] 1339 	subb	a,r0
      0049A2 EB               [12] 1340 	mov	a,r3
      0049A3 9F               [12] 1341 	subb	a,r7
      0049A4 22               [24] 1342 	ret
                                   1343 
                                   1344 	.area CSEG (CODE)
                                   1345 ; function ak820_outline_0084
      0049A5                       1346 _ak820_outline_0084:
      0049A5 E5 82            [12] 1347 	mov	a,dpl
      0049A7 85 83 F0         [24] 1348 	mov	b,dph
      0049AA 45 F0            [12] 1349 	orl	a,b
      0049AC 22               [24] 1350 	ret
                                   1351 
                                   1352 	.area CSEG (CODE)
                                   1353 ; function ak820_outline_0110
      0049AD                       1354 _ak820_outline_0110:
      0049AD EF               [12] 1355 	mov	a,r7
      0049AE 24 B6            [12] 1356 	add	a,#_candidate
      0049B0 F5 82            [12] 1357 	mov	dpl,a
      0049B2 E4               [12] 1358 	clr	a
      0049B3 34 05            [12] 1359 	addc	a,#(_candidate>>8)
      0049B5 F5 83            [12] 1360 	mov	dph,a
      0049B7 E0               [24] 1361 	movx	a,@dptr
      0049B8 22               [24] 1362 	ret
                                   1363 
                                   1364 	.area CSEG (CODE)
                                   1365 ; function ak820_outline_0149
      0049B9                       1366 _ak820_outline_0149:
      0049B9 F0               [24] 1367 	movx	@dptr,a
      0049BA E5 F0            [12] 1368 	mov	a,b
      0049BC A3               [24] 1369 	inc	dptr
      0049BD F0               [24] 1370 	movx	@dptr,a
      0049BE 22               [24] 1371 	ret
                                   1372 
                                   1373 	.area CSEG (CODE)
                                   1374 ; function ak820_outline_0177
      0049BF                       1375 _ak820_outline_0177:
      0049BF E4               [12] 1376 	clr	a
      0049C0 F0               [24] 1377 	movx	@dptr,a
      0049C1 A3               [24] 1378 	inc	dptr
      0049C2 F0               [24] 1379 	movx	@dptr,a
      0049C3 22               [24] 1380 	ret
                                   1381 
                                   1382 	.area CSEG (CODE)
                                   1383 ; function ak820_outline_0195
      0049C4                       1384 _ak820_outline_0195:
      0049C4 F0               [24] 1385 	movx	@dptr,a
      0049C5 EB               [12] 1386 	mov	a,r3
      0049C6 A3               [24] 1387 	inc	dptr
      0049C7 F0               [24] 1388 	movx	@dptr,a
      0049C8 22               [24] 1389 	ret
