                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_tapping_term
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_mods
                                     14 	.globl _add_owned_mods
                                     15 	.globl _send_keyboard_report
                                     16 	.globl _layer_hold_off
                                     17 	.globl _layer_hold_on
                                     18 	.globl _unregister_mods
                                     19 	.globl _register_mods
                                     20 	.globl _process_record
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_oneshot_target
                                    265 	.globl _ak820_oneshot_process_PARM_3
                                    266 	.globl _ak820_oneshot_process_PARM_2
                                    267 	.globl _ak820_oneshot_consumed
                                    268 	.globl _ak820_oneshot_mods
                                    269 	.globl _ak820_tapping_source_PARM_1
                                    270 	.globl _ak820_tapping_source
                                    271 	.globl _ak820_tapping_before
                                    272 	.globl _ak820_tapping_process
                                    273 	.globl _ak820_tapping_cancel
                                    274 	.globl _ak820_oneshot_process
                                    275 ;--------------------------------------------------------
                                    276 ; special function registers
                                    277 ;--------------------------------------------------------
                                    278 	.area RSEG    (ABS,DATA)
      000000                        279 	.org 0x0000
                           0000D0   280 _PSW	=	0x00d0
                           0000E0   281 _ACC	=	0x00e0
                           0000F0   282 _B	=	0x00f0
                           0000FD   283 _A_INV	=	0x00fd
                           000081   284 _SP	=	0x0081
                           000082   285 _DPL	=	0x0082
                           000083   286 _DPH	=	0x0083
                           0000A1   287 _SAFE_MOD	=	0x00a1
                           0000B1   288 _GLOBAL_CFG	=	0x00b1
                           000087   289 _PCON	=	0x0087
                           0000BA   290 _POWER_CFG	=	0x00ba
                           0000B9   291 _CLOCK_CFG	=	0x00b9
                           0000A9   292 _WAKE_CTRL	=	0x00a9
                           0000FE   293 _RESET_KEEP	=	0x00fe
                           0000FF   294 _WDOG_COUNT	=	0x00ff
                           0000A8   295 _IE	=	0x00a8
                           0000B8   296 _IP	=	0x00b8
                           0000E8   297 _IE_EX	=	0x00e8
                           0000E9   298 _IP_EX	=	0x00e9
                           0000B2   299 _GPIO_IE	=	0x00b2
                           008584   300 _ROM_ADDR	=	0x8584
                           000084   301 _ROM_ADDR_L	=	0x0084
                           000085   302 _ROM_ADDR_H	=	0x0085
                           008F8E   303 _ROM_DATA_HI	=	0x8f8e
                           00008E   304 _ROM_DATA_HL	=	0x008e
                           00008F   305 _ROM_DATA_HH	=	0x008f
                           000086   306 _ROM_CTRL	=	0x0086
                           000080   307 _P0	=	0x0080
                           0000C4   308 _P0_MOD_OC	=	0x00c4
                           0000C5   309 _P0_DIR_PU	=	0x00c5
                           000090   310 _P1	=	0x0090
                           000092   311 _P1_MOD_OC	=	0x0092
                           000093   312 _P1_DIR_PU	=	0x0093
                           0000A0   313 _P2	=	0x00a0
                           000094   314 _P2_MOD_OC	=	0x0094
                           000095   315 _P2_DIR_PU	=	0x0095
                           0000B0   316 _P3	=	0x00b0
                           000096   317 _P3_MOD_OC	=	0x0096
                           000097   318 _P3_DIR_PU	=	0x0097
                           0000C0   319 _P4	=	0x00c0
                           0000C2   320 _P4_MOD_OC	=	0x00c2
                           0000C3   321 _P4_DIR_PU	=	0x00c3
                           0000C1   322 _P4_LED_KEY	=	0x00c1
                           0000AA   323 _P5_IN	=	0x00aa
                           0000AB   324 _P5_OUT_PU	=	0x00ab
                           0000AC   325 _P5_DIR	=	0x00ac
                           0000AD   326 _P6_IN	=	0x00ad
                           0000AE   327 _P6_OUT_PU	=	0x00ae
                           0000AF   328 _P6_DIR	=	0x00af
                           0000F1   329 _P7	=	0x00f1
                           0000A2   330 _XBUS_AUX	=	0x00a2
                           000088   331 _TCON	=	0x0088
                           000089   332 _TMOD	=	0x0089
                           00008A   333 _TL0	=	0x008a
                           00008B   334 _TL1	=	0x008b
                           00008C   335 _TH0	=	0x008c
                           00008D   336 _TH1	=	0x008d
                           000098   337 _SCON	=	0x0098
                           000099   338 _SBUF	=	0x0099
                           0000C8   339 _T2CON	=	0x00c8
                           0000C9   340 _T2MOD	=	0x00c9
                           00CBCA   341 _RCAP2	=	0xcbca
                           0000CA   342 _RCAP2L	=	0x00ca
                           0000CB   343 _RCAP2H	=	0x00cb
                           00CDCC   344 _T2COUNT	=	0xcdcc
                           0000CC   345 _TL2	=	0x00cc
                           0000CD   346 _TH2	=	0x00cd
                           00CFCE   347 _T2CAP1	=	0xcfce
                           0000CE   348 _T2CAP1L	=	0x00ce
                           0000CF   349 _T2CAP1H	=	0x00cf
                           0000F8   350 _SPI0_STAT	=	0x00f8
                           0000F9   351 _SPI0_DATA	=	0x00f9
                           0000FA   352 _SPI0_CTRL	=	0x00fa
                           0000FB   353 _SPI0_CK_SE	=	0x00fb
                           0000FC   354 _SPI0_SETUP	=	0x00fc
                           0000BC   355 _SCON1	=	0x00bc
                           0000BD   356 _SBUF1	=	0x00bd
                           0000BE   357 _SBAUD1	=	0x00be
                           0000BF   358 _SIF1	=	0x00bf
                           0000B4   359 _SPI1_STAT	=	0x00b4
                           0000B5   360 _SPI1_DATA	=	0x00b5
                           0000B6   361 _SPI1_CTRL	=	0x00b6
                           0000B7   362 _SPI1_CK_SE	=	0x00b7
                           0000F3   363 _ADC_CTRL	=	0x00f3
                           00F5F4   364 _ADC_DAT	=	0xf5f4
                           0000F4   365 _ADC_DAT_L	=	0x00f4
                           0000F5   366 _ADC_DAT_H	=	0x00f5
                           0000F6   367 _ADC_CHAN	=	0x00f6
                           0000A6   368 _LED_COMMON	=	0x00a6
                           0000A7   369 _LED_PWM_OE	=	0x00a7
                           00C7C6   370 _LED_DMA	=	0xc7c6
                           0000C6   371 _LED_DMA_L	=	0x00c6
                           0000C7   372 _LED_DMA_H	=	0x00c7
                           0000F7   373 _LED_STATUS	=	0x00f7
                           0000B3   374 _I2CX_INT	=	0x00b3
                           0000BB   375 _I2CS_INT_ST	=	0x00bb
                                    376 ;--------------------------------------------------------
                                    377 ; special function bits
                                    378 ;--------------------------------------------------------
                                    379 	.area RSEG    (ABS,DATA)
      000000                        380 	.org 0x0000
                           0000D7   381 _CY	=	0x00d7
                           0000D6   382 _AC	=	0x00d6
                           0000D5   383 _F0	=	0x00d5
                           0000D4   384 _RS1	=	0x00d4
                           0000D3   385 _RS0	=	0x00d3
                           0000D2   386 _OV	=	0x00d2
                           0000D1   387 _F1	=	0x00d1
                           0000D0   388 _P	=	0x00d0
                           0000AF   389 _EA	=	0x00af
                           0000AE   390 _E_DIS	=	0x00ae
                           0000AD   391 _ET2	=	0x00ad
                           0000AC   392 _ES	=	0x00ac
                           0000AB   393 _ET1	=	0x00ab
                           0000AA   394 _EX1	=	0x00aa
                           0000A9   395 _ET0	=	0x00a9
                           0000A8   396 _EX0	=	0x00a8
                           0000BF   397 _PH_FLAG	=	0x00bf
                           0000BE   398 _PL_FLAG	=	0x00be
                           0000BD   399 _PT2	=	0x00bd
                           0000BC   400 _PS	=	0x00bc
                           0000BB   401 _PT1	=	0x00bb
                           0000BA   402 _PX1	=	0x00ba
                           0000B9   403 _PT0	=	0x00b9
                           0000B8   404 _PX0	=	0x00b8
                           0000EF   405 _IE_WDOG	=	0x00ef
                           0000EE   406 _IE_GPIO	=	0x00ee
                           0000ED   407 _IE_PWM_I2C	=	0x00ed
                           0000EC   408 _IE_UART1	=	0x00ec
                           0000EB   409 _IE_ADC	=	0x00eb
                           0000E9   410 _IE_USB	=	0x00e9
                           0000E8   411 _IE_SPI0	=	0x00e8
                           000087   412 _P0_7	=	0x0087
                           000086   413 _P0_6	=	0x0086
                           000085   414 _P0_5	=	0x0085
                           000084   415 _P0_4	=	0x0084
                           000083   416 _P0_3	=	0x0083
                           000082   417 _P0_2	=	0x0082
                           000081   418 _P0_1	=	0x0081
                           000080   419 _P0_0	=	0x0080
                           000081   420 _SDA0	=	0x0081
                           000080   421 _SCL0	=	0x0080
                           000083   422 _TXD_	=	0x0083
                           000082   423 _RXD_	=	0x0082
                           000085   424 _AIN13	=	0x0085
                           000084   425 _AIN12	=	0x0084
                           000083   426 _AIN11	=	0x0083
                           000082   427 _AIN10	=	0x0082
                           000081   428 _AIN9	=	0x0081
                           000080   429 _AIN8	=	0x0080
                           000097   430 _P1_7	=	0x0097
                           000096   431 _P1_6	=	0x0096
                           000095   432 _P1_5	=	0x0095
                           000094   433 _P1_4	=	0x0094
                           000093   434 _P1_3	=	0x0093
                           000092   435 _P1_2	=	0x0092
                           000091   436 _P1_1	=	0x0091
                           000090   437 _P1_0	=	0x0090
                           000097   438 _TXD1_	=	0x0097
                           000096   439 _RXD1_	=	0x0096
                           000097   440 _SCK	=	0x0097
                           000096   441 _MISO	=	0x0096
                           000095   442 _MOSI	=	0x0095
                           000094   443 _SCS	=	0x0094
                           000092   444 _INT0_	=	0x0092
                           000091   445 _T2EX	=	0x0091
                           000091   446 _CAP2	=	0x0091
                           000090   447 _T2	=	0x0090
                           000090   448 _CAP1	=	0x0090
                           000097   449 _AIN7	=	0x0097
                           000096   450 _AIN6	=	0x0096
                           000095   451 _AIN5	=	0x0095
                           000094   452 _AIN4	=	0x0094
                           000093   453 _AIN3	=	0x0093
                           000092   454 _AIN2	=	0x0092
                           000091   455 _AIN1	=	0x0091
                           000090   456 _AIN0	=	0x0090
                           0000A7   457 _P2_7	=	0x00a7
                           0000A6   458 _P2_6	=	0x00a6
                           0000A5   459 _P2_5	=	0x00a5
                           0000A4   460 _P2_4	=	0x00a4
                           0000A3   461 _P2_3	=	0x00a3
                           0000A2   462 _P2_2	=	0x00a2
                           0000A1   463 _P2_1	=	0x00a1
                           0000A0   464 _P2_0	=	0x00a0
                           0000A7   465 _TXD1	=	0x00a7
                           0000A6   466 _RXD1	=	0x00a6
                           0000A5   467 _T2EX_	=	0x00a5
                           0000A5   468 _CAP2_	=	0x00a5
                           0000A4   469 _T2_	=	0x00a4
                           0000A4   470 _CAP1_	=	0x00a4
                           0000B7   471 _P3_7	=	0x00b7
                           0000B6   472 _P3_6	=	0x00b6
                           0000B5   473 _P3_5	=	0x00b5
                           0000B4   474 _P3_4	=	0x00b4
                           0000B3   475 _P3_3	=	0x00b3
                           0000B2   476 _P3_2	=	0x00b2
                           0000B1   477 _P3_1	=	0x00b1
                           0000B0   478 _P3_0	=	0x00b0
                           0000B7   479 _SCK1	=	0x00b7
                           0000B6   480 _MISO1	=	0x00b6
                           0000B5   481 _MOSI1	=	0x00b5
                           0000B5   482 _T1	=	0x00b5
                           0000B4   483 _T0	=	0x00b4
                           0000B3   484 _INT1	=	0x00b3
                           0000B2   485 _INT0	=	0x00b2
                           0000B1   486 _TXD	=	0x00b1
                           0000B0   487 _RXD	=	0x00b0
                           0000C6   488 _P4_6	=	0x00c6
                           0000C5   489 _P4_5	=	0x00c5
                           0000C4   490 _P4_4	=	0x00c4
                           0000C3   491 _P4_3	=	0x00c3
                           0000C2   492 _P4_2	=	0x00c2
                           0000C1   493 _P4_1	=	0x00c1
                           0000C0   494 _P4_0	=	0x00c0
                           00008F   495 _TF1	=	0x008f
                           00008E   496 _TR1	=	0x008e
                           00008D   497 _TF0	=	0x008d
                           00008C   498 _TR0	=	0x008c
                           00008B   499 _IE1	=	0x008b
                           00008A   500 _IT1	=	0x008a
                           000089   501 _IE0	=	0x0089
                           000088   502 _IT0	=	0x0088
                           00009F   503 _SM0	=	0x009f
                           00009E   504 _SM1	=	0x009e
                           00009D   505 _SM2	=	0x009d
                           00009C   506 _REN	=	0x009c
                           00009B   507 _TB8	=	0x009b
                           00009A   508 _RB8	=	0x009a
                           000099   509 _TI	=	0x0099
                           000098   510 _RI	=	0x0098
                           0000CF   511 _TF2	=	0x00cf
                           0000CF   512 _CAP1F	=	0x00cf
                           0000CE   513 _EXF2	=	0x00ce
                           0000CD   514 _RCLK	=	0x00cd
                           0000CC   515 _TCLK	=	0x00cc
                           0000CB   516 _EXEN2	=	0x00cb
                           0000CA   517 _TR2	=	0x00ca
                           0000C9   518 _C_T2	=	0x00c9
                           0000C8   519 _CP_RL2	=	0x00c8
                           0000FF   520 _S0_FST_ACT	=	0x00ff
                           0000FE   521 _S0_IF_OV	=	0x00fe
                           0000FD   522 _S0_IF_FIRST	=	0x00fd
                           0000FC   523 _S0_IF_BYTE	=	0x00fc
                           0000FB   524 _S0_FREE	=	0x00fb
                           0000FA   525 _S0_T_FIFO	=	0x00fa
                           0000F8   526 _S0_R_FIFO	=	0x00f8
                           0000F7   527 _ADC_START	=	0x00f7
                                    528 ;--------------------------------------------------------
                                    529 ; overlayable register banks
                                    530 ;--------------------------------------------------------
                                    531 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        532 	.ds 8
                                    533 ;--------------------------------------------------------
                                    534 ; internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area DSEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; overlayable items in internal ram
                                    539 ;--------------------------------------------------------
                                    540 ;--------------------------------------------------------
                                    541 ; indirectly addressable internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area ISEG    (DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; absolute internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area IABS    (ABS,DATA)
                                    548 	.area IABS    (ABS,DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; bit data
                                    551 ;--------------------------------------------------------
                                    552 	.area BSEG    (BIT)
      00000F                        553 _ak820_tapping_before_sloc0_1_0:
      00000F                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; paged external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area PSEG    (PAG,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; uninitialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XSEG    (XDATA)
      0005F1                        563 _source_state:
      0005F1                        564 	.ds 130
      000673                        565 _pending_time:
      000673                        566 	.ds 2
      000675                        567 _pending_code:
      000675                        568 	.ds 2
      000677                        569 _ak820_tapping_source_PARM_1:
      000677                        570 	.ds 2
      000679                        571 _hold_PARM_2:
      000679                        572 	.ds 1
      00067A                        573 _hold_code_10000_625:
      00067A                        574 	.ds 2
      00067C                        575 _hold_mods_30000_628:
      00067C                        576 	.ds 1
      00067D                        577 _commit_pending_id_10000_634:
      00067D                        578 	.ds 1
      00067E                        579 _ak820_tapping_before_event_10000_635:
      00067E                        580 	.ds 2
      000680                        581 _ak820_tapping_process_record_10000_646:
      000680                        582 	.ds 2
      000682                        583 _ak820_tapping_process_code_10000_647:
      000682                        584 	.ds 2
      000684                        585 _ak820_tapping_process_sc_mods_10000_647:
      000684                        586 	.ds 1
      000685                        587 _ak820_oneshot_mods::
      000685                        588 	.ds 1
      000686                        589 _ak820_oneshot_consumed::
      000686                        590 	.ds 1
      000687                        591 _ak820_oneshot_process_PARM_2:
      000687                        592 	.ds 1
      000688                        593 _ak820_oneshot_process_PARM_3:
      000688                        594 	.ds 1
      000689                        595 _ak820_oneshot_process_code_10000_672:
      000689                        596 	.ds 2
      00068B                        597 _ak820_oneshot_process_mods_10000_673:
      00068B                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; absolute external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XABS    (ABS,XDATA)
                                    603 ;--------------------------------------------------------
                                    604 ; initialized external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XISEG   (XDATA)
      000E09                        607 _pending:
      000E09                        608 	.ds 1
      000E0A                        609 _ak820_oneshot_target::
      000E0A                        610 	.ds 1
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function ak820_tapping_source
                                    653 ;	-----------------------------------------
      0049C9                        654 _ak820_tapping_source:
                                    655 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0049C9 90 06 78         [24]  656 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0049CC E0               [24]  657 	movx	a,@dptr
      0049CD FF               [12]  658 	mov	r7,a
      0049CE BF 10 00         [24]  659 	cjne	r7,#0x10,00147$
      0049D1                        660 00147$:
      0049D1 50 14            [24]  661 	jnc	00102$
      0049D3 90 06 77         [24]  662 	mov	dptr,#_ak820_tapping_source_PARM_1
      0049D6 E0               [24]  663 	movx	a,@dptr
      0049D7 FE               [12]  664 	mov	r6,a
      0049D8 BE 08 00         [24]  665 	cjne	r6,#0x08,00149$
      0049DB                        666 00149$:
      0049DB 50 0A            [24]  667 	jnc	00102$
      0049DD 8F 05            [24]  668 	mov	ar5,r7
      0049DF ED               [12]  669 	mov	a,r5
      0049E0 12 38 CF         [24]  670 	lcall	_ak820_outline_0199
      0049E3 2E               [12]  671 	add	a,r6
      0049E4 F5 82            [12]  672 	mov	dpl,a
      0049E6 22               [24]  673 	ret
      0049E7                        674 00102$:
                                    675 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0049E7 90 06 77         [24]  676 	mov	dptr,#_ak820_tapping_source_PARM_1
      0049EA E0               [24]  677 	movx	a,@dptr
      0049EB FE               [12]  678 	mov	r6,a
      0049EC BE 01 00         [24]  679 	cjne	r6,#0x01,00151$
      0049EF                        680 00151$:
      0049EF 50 0E            [24]  681 	jnc	00109$
                                    682 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0049F1 BF FD 04         [24]  683 	cjne	r7,#0xfd,00105$
      0049F4 75 82 80         [24]  684 	mov	dpl, #0x80
      0049F7 22               [24]  685 	ret
      0049F8                        686 00105$:
                                    687 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0049F8 BF FC 04         [24]  688 	cjne	r7,#0xfc,00109$
      0049FB 75 82 81         [24]  689 	mov	dpl, #0x81
      0049FE 22               [24]  690 	ret
      0049FF                        691 00109$:
                                    692 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0049FF 75 82 FF         [24]  693 	mov	dpl, #0xff
                                    694 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004A02 22               [24]  695 	ret
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'hold'
                                    698 ;------------------------------------------------------------
                                    699 ;pressed       Allocated with name '_hold_PARM_2'
                                    700 ;code          Allocated with name '_hold_code_10000_625'
                                    701 ;mods          Allocated with name '_hold_mods_30000_628'
                                    702 ;layer         Allocated with name '_hold_layer_30000_631'
                                    703 ;------------------------------------------------------------
                                    704 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    705 ;	-----------------------------------------
                                    706 ;	 function hold
                                    707 ;	-----------------------------------------
      004A03                        708 _hold:
      004A03 12 38 79         [24]  709 	lcall	_ak820_outline_0113
      004A06 90 06 7A         [24]  710 	mov	dptr,#_hold_code_10000_625
      004A09 12 38 7E         [24]  711 	lcall	_ak820_outline_0114
                                    712 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004A0C 90 06 7A         [24]  713 	mov	dptr,#_hold_code_10000_625
      004A0F 12 4E 82         [24]  714 	lcall	_ak820_outline_0009
      004A12 74 C0            [12]  715 	mov	a,#0x100 - 0x40
      004A14 2D               [12]  716 	add	a,r5
      004A15 40 2E            [24]  717 	jc	00110$
                                    718 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004A17 8F 05            [24]  719 	mov	ar5,r7
      004A19 53 05 1F         [24]  720 	anl	ar5,#0x1f
      004A1C 90 06 7C         [24]  721 	mov	dptr,#_hold_mods_30000_628
      004A1F ED               [12]  722 	mov	a,r5
      004A20 F0               [24]  723 	movx	@dptr,a
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004A21 ED               [12]  725 	mov	a,r5
      004A22 30 E4 08         [24]  726 	jnb	acc.4,00102$
      004A25 ED               [12]  727 	mov	a,r5
      004A26 C4               [12]  728 	swap	a
      004A27 54 F0            [12]  729 	anl	a,#0xf0
      004A29 90 06 7C         [24]  730 	mov	dptr,#_hold_mods_30000_628
      004A2C F0               [24]  731 	movx	@dptr,a
      004A2D                        732 00102$:
                                    733 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004A2D 90 06 79         [24]  734 	mov	dptr,#_hold_PARM_2
      004A30 E0               [24]  735 	movx	a,@dptr
      004A31 60 09            [24]  736 	jz	00104$
      004A33 90 06 7C         [24]  737 	mov	dptr,#_hold_mods_30000_628
      004A36 E0               [24]  738 	movx	a,@dptr
      004A37 F5 82            [12]  739 	mov	dpl,a
      004A39 02 7C 02         [24]  740 	ljmp	_register_mods
      004A3C                        741 00104$:
                                    742 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004A3C 90 06 7C         [24]  743 	mov	dptr,#_hold_mods_30000_628
      004A3F E0               [24]  744 	movx	a,@dptr
      004A40 F5 82            [12]  745 	mov	dpl,a
      004A42 02 7C 16         [24]  746 	ljmp	_unregister_mods
      004A45                        747 00110$:
                                    748 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004A45 8F 06            [24]  749 	mov	ar6,r7
      004A47 74 0F            [12]  750 	mov	a,#0x0f
      004A49 5E               [12]  751 	anl	a,r6
      004A4A FF               [12]  752 	mov	r7,a
                                    753 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004A4B 90 06 79         [24]  754 	mov	dptr,#_hold_PARM_2
      004A4E E0               [24]  755 	movx	a,@dptr
      004A4F 60 05            [24]  756 	jz	00107$
      004A51 8F 82            [24]  757 	mov	dpl, r7
      004A53 02 7D D9         [24]  758 	ljmp	_layer_hold_on
      004A56                        759 00107$:
                                    760 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004A56 8F 82            [24]  761 	mov	dpl, r7
                                    762 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004A58 02 7E 10         [24]  763 	ljmp	_layer_hold_off
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'commit_pending'
                                    766 ;------------------------------------------------------------
                                    767 ;id            Allocated with name '_commit_pending_id_10000_634'
                                    768 ;------------------------------------------------------------
                                    769 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function commit_pending
                                    772 ;	-----------------------------------------
      004A5B                        773 _commit_pending:
                                    774 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004A5B 90 0E 09         [24]  775 	mov	dptr,#_pending
      004A5E E0               [24]  776 	movx	a,@dptr
      004A5F 90 06 7D         [24]  777 	mov	dptr,#_commit_pending_id_10000_634
      004A62 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004A63 12 4F 01         [24]  780 	lcall	_ak820_outline_0165
                                    781 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004A66 90 06 7D         [24]  782 	mov	dptr,#_commit_pending_id_10000_634
      004A69 E0               [24]  783 	movx	a,@dptr
      004A6A 24 F1            [12]  784 	add	a,#_source_state
      004A6C FF               [12]  785 	mov	r7,a
      004A6D E4               [12]  786 	clr	a
      004A6E 34 05            [12]  787 	addc	a, #(_source_state >> 8)
      004A70 FE               [12]  788 	mov	r6,a
      004A71 12 43 7B         [24]  789 	lcall	_ak820_outline_0166
      004A74 E0               [24]  790 	movx	a,@dptr
      004A75 FD               [12]  791 	mov	r5,a
      004A76 43 05 04         [24]  792 	orl	ar5,#0x04
      004A79 12 43 7B         [24]  793 	lcall	_ak820_outline_0166
      004A7C ED               [12]  794 	mov	a,r5
      004A7D F0               [24]  795 	movx	@dptr,a
                                    796 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004A7E 90 06 75         [24]  797 	mov	dptr,#_pending_code
      004A81 12 38 3E         [24]  798 	lcall	_ak820_outline_0055
      004A84 90 06 79         [24]  799 	mov	dptr,#_hold_PARM_2
      004A87 74 01            [12]  800 	mov	a,#0x01
      004A89 12 43 46         [24]  801 	lcall	_ak820_outline_0077
                                    802 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004A8C 41 03            [12]  803 	ajmp	_hold
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    806 ;------------------------------------------------------------
                                    807 ;event         Allocated with name '_ak820_tapping_before_event_10000_635'
                                    808 ;id            Allocated with name '_ak820_tapping_before_id_10000_636'
                                    809 ;------------------------------------------------------------
                                    810 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function ak820_tapping_before
                                    813 ;	-----------------------------------------
      004A8E                        814 _ak820_tapping_before:
      004A8E 12 38 79         [24]  815 	lcall	_ak820_outline_0113
      004A91 90 06 7E         [24]  816 	mov	dptr,#_ak820_tapping_before_event_10000_635
      004A94 12 38 7E         [24]  817 	lcall	_ak820_outline_0114
                                    818 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004A97 90 06 7E         [24]  819 	mov	dptr,#_ak820_tapping_before_event_10000_635
      004A9A 12 4E 82         [24]  820 	lcall	_ak820_outline_0009
      004A9D 12 4E A6         [24]  821 	lcall	_ak820_outline_0026
      004AA0 C0 07            [24]  822 	push	ar7
      004AA2 C0 06            [24]  823 	push	ar6
      004AA4 12 BE 74         [24]  824 	lcall	___memcpy
      004AA7 31 C9            [12]  825 	acall	_ak820_tapping_source
      004AA9 AD 82            [24]  826 	mov	r5, dpl
      004AAB D0 06            [24]  827 	pop	ar6
      004AAD D0 07            [24]  828 	pop	ar7
                                    829 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004AAF 90 0E 7A         [24]  830 	mov	dptr,#_vial_unlock_in_progress
      004AB2 E0               [24]  831 	movx	a,@dptr
      004AB3 60 29            [24]  832 	jz	00106$
                                    833 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004AB5 74 04            [12]  834 	mov	a,#0x04
      004AB7 12 4E 8C         [24]  835 	lcall	_ak820_outline_0012
      004ABA 60 1E            [24]  836 	jz	00102$
      004ABC BD FF 02         [24]  837 	cjne	r5,#0xff,00218$
      004ABF 80 19            [24]  838 	sjmp	00102$
      004AC1                        839 00218$:
      004AC1 74 05            [12]  840 	mov	a,#0x05
      004AC3 12 4E 8C         [24]  841 	lcall	_ak820_outline_0012
      004AC6 70 12            [24]  842 	jnz	00102$
      004AC8 ED               [12]  843 	mov	a,r5
      004AC9 24 F1            [12]  844 	add	a, #_source_state
      004ACB FB               [12]  845 	mov	r3,a
      004ACC E4               [12]  846 	clr	a
      004ACD 34 05            [12]  847 	addc	a, #(_source_state >> 8)
      004ACF 12 4E CB         [24]  848 	lcall	_ak820_outline_0059
      004AD2 53 02 FD         [24]  849 	anl	ar2,#0xfd
      004AD5 12 33 FC         [24]  850 	lcall	_ak820_outline_0130
      004AD8 EA               [12]  851 	mov	a,r2
      004AD9 F0               [24]  852 	movx	@dptr,a
      004ADA                        853 00102$:
                                    854 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004ADA 75 82 00         [24]  855 	mov	dpl, #0x00
      004ADD 22               [24]  856 	ret
      004ADE                        857 00106$:
                                    858 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004ADE 90 0E 09         [24]  859 	mov	dptr,#_pending
      004AE1 E0               [24]  860 	movx	a,@dptr
      004AE2 FC               [12]  861 	mov	r4,a
      004AE3 BC FF 02         [24]  862 	cjne	r4,#0xff,00220$
      004AE6 80 58            [24]  863 	sjmp	00108$
      004AE8                        864 00220$:
      004AE8 12 38 36         [24]  865 	lcall	_ak820_outline_0037
      004AEB FB               [12]  866 	mov	r3,a
      004AEC A3               [24]  867 	inc	dptr
      004AED E0               [24]  868 	movx	a,@dptr
      004AEE FC               [12]  869 	mov	r4,a
      004AEF 90 06 73         [24]  870 	mov	dptr,#_pending_time
      004AF2 E0               [24]  871 	movx	a,@dptr
      004AF3 F9               [12]  872 	mov	r1,a
      004AF4 A3               [24]  873 	inc	dptr
      004AF5 E0               [24]  874 	movx	a,@dptr
      004AF6 FA               [12]  875 	mov	r2,a
      004AF7 EB               [12]  876 	mov	a,r3
      004AF8 C3               [12]  877 	clr	c
      004AF9 99               [12]  878 	subb	a,r1
      004AFA FB               [12]  879 	mov	r3,a
      004AFB EC               [12]  880 	mov	a,r4
      004AFC 9A               [12]  881 	subb	a,r2
      004AFD FC               [12]  882 	mov	r4,a
      004AFE C0 07            [24]  883 	push	ar7
      004B00 C0 06            [24]  884 	push	ar6
      004B02 C0 05            [24]  885 	push	ar5
      004B04 C0 04            [24]  886 	push	ar4
      004B06 C0 03            [24]  887 	push	ar3
      004B08 31 22            [12]  888 	acall	_ak820_settings_tapping_term
      004B0A 12 4F 08         [24]  889 	lcall	_ak820_outline_0194
      004B0D D0 03            [24]  890 	pop	ar3
      004B0F D0 04            [24]  891 	pop	ar4
      004B11 D0 05            [24]  892 	pop	ar5
      004B13 D0 06            [24]  893 	pop	ar6
      004B15 D0 07            [24]  894 	pop	ar7
      004B17 C3               [12]  895 	clr	c
      004B18 EB               [12]  896 	mov	a,r3
      004B19 99               [12]  897 	subb	a,r1
      004B1A EC               [12]  898 	mov	a,r4
      004B1B 9A               [12]  899 	subb	a,r2
      004B1C 50 1C            [24]  900 	jnc	00107$
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004B1E 74 04            [12]  902 	mov	a,#0x04
      004B20 12 4E 8C         [24]  903 	lcall	_ak820_outline_0012
      004B23 60 1B            [24]  904 	jz	00108$
      004B25 12 38 0F         [24]  905 	lcall	_ak820_outline_0010
      004B28 60 16            [24]  906 	jz	00108$
      004B2A BD FF 02         [24]  907 	cjne	r5,#0xff,00224$
      004B2D 80 0B            [24]  908 	sjmp	00107$
      004B2F                        909 00224$:
      004B2F 90 0E 09         [24]  910 	mov	dptr,#_pending
      004B32 E0               [24]  911 	movx	a,@dptr
      004B33 FF               [12]  912 	mov	r7,a
      004B34 ED               [12]  913 	mov	a,r5
      004B35 B5 07 02         [24]  914 	cjne	a,ar7,00225$
      004B38 80 06            [24]  915 	sjmp	00108$
      004B3A                        916 00225$:
      004B3A                        917 00107$:
      004B3A C0 05            [24]  918 	push	ar5
      004B3C 51 5B            [12]  919 	acall	_commit_pending
      004B3E D0 05            [24]  920 	pop	ar5
      004B40                        921 00108$:
                                    922 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004B40 90 06 7E         [24]  923 	mov	dptr,#_ak820_tapping_before_event_10000_635
      004B43 12 38 3E         [24]  924 	lcall	_ak820_outline_0055
      004B46 74 04            [12]  925 	mov	a,#0x04
      004B48 12 4E 8C         [24]  926 	lcall	_ak820_outline_0012
      004B4B 60 03            [24]  927 	jz	00114$
      004B4D BD FF 04         [24]  928 	cjne	r5,#0xff,00115$
      004B50                        929 00114$:
      004B50 75 82 01         [24]  930 	mov	dpl, #0x01
      004B53 22               [24]  931 	ret
      004B54                        932 00115$:
                                    933 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004B54 ED               [12]  934 	mov	a,r5
      004B55 12 4E E0         [24]  935 	lcall	_ak820_outline_0085
      004B58 30 E1 13         [24]  936 	jnb	acc.1,00120$
                                    937 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004B5B 74 05            [12]  938 	mov	a,#0x05
      004B5D 2E               [12]  939 	add	a, r6
      004B5E 12 38 1C         [24]  940 	lcall	_ak820_outline_0017
      004B61 70 07            [24]  941 	jnz	00118$
      004B63 74 FD            [12]  942 	mov	a,#0xfd
      004B65 5B               [12]  943 	anl	a,r3
      004B66 12 38 A0         [24]  944 	lcall	_ak820_outline_0133
      004B69 F0               [24]  945 	movx	@dptr,a
      004B6A                        946 00118$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004B6A 75 82 00         [24]  948 	mov	dpl, #0x00
      004B6D 22               [24]  949 	ret
      004B6E                        950 00120$:
                                    951 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004B6E 12 43 09         [24]  952 	lcall	_ak820_outline_0014
      004B71 E0               [24]  953 	movx	a,@dptr
      004B72 FF               [12]  954 	mov	r7,a
      004B73 8B 06            [24]  955 	mov	ar6,r3
      004B75 53 06 01         [24]  956 	anl	ar6,#0x01
      004B78 EE               [12]  957 	mov	a,r6
      004B79 B4 01 00         [24]  958 	cjne	a,#0x01,00231$
      004B7C                        959 00231$:
      004B7C B3               [12]  960 	cpl	c
      004B7D 92 0F            [24]  961 	mov	_ak820_tapping_before_sloc0_1_0,c
      004B7F 8F F0            [24]  962 	mov	b,r7
      004B81 E4               [12]  963 	clr	a
      004B82 33               [12]  964 	rlc	a
      004B83 B5 F0 04         [24]  965 	cjne	a,b,00122$
      004B86 75 82 00         [24]  966 	mov	dpl, #0x00
      004B89 22               [24]  967 	ret
      004B8A                        968 00122$:
                                    969 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004B8A 63 03 01         [24]  970 	xrl	ar3,#0x01
      004B8D 12 38 A0         [24]  971 	lcall	_ak820_outline_0133
      004B90 EB               [12]  972 	mov	a,r3
      004B91 F0               [24]  973 	movx	@dptr,a
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004B92 75 82 01         [24]  975 	mov	dpl, #0x01
                                    976 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004B95 22               [24]  977 	ret
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    980 ;------------------------------------------------------------
                                    981 ;record        Allocated with name '_ak820_tapping_process_record_10000_646'
                                    982 ;id            Allocated with name '_ak820_tapping_process_id_10000_647'
                                    983 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_647'
                                    984 ;code          Allocated with name '_ak820_tapping_process_code_10000_647'
                                    985 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_647'
                                    986 ;------------------------------------------------------------
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    988 ;	-----------------------------------------
                                    989 ;	 function ak820_tapping_process
                                    990 ;	-----------------------------------------
      004B96                        991 _ak820_tapping_process:
      004B96 12 38 79         [24]  992 	lcall	_ak820_outline_0113
      004B99 90 06 80         [24]  993 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004B9C 12 38 7E         [24]  994 	lcall	_ak820_outline_0114
                                    995 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004B9F 90 06 84         [24]  996 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004BA2 E4               [12]  997 	clr	a
      004BA3 F0               [24]  998 	movx	@dptr,a
                                    999 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004BA4 90 06 80         [24] 1000 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004BA7 12 38 3E         [24] 1001 	lcall	_ak820_outline_0055
      004BAA 74 04            [12] 1002 	mov	a,#0x04
      004BAC 12 4E C0         [24] 1003 	lcall	_ak820_outline_0035
      004BAF 70 04            [24] 1004 	jnz	00102$
      004BB1 75 82 01         [24] 1005 	mov	dpl, #0x01
      004BB4 22               [24] 1006 	ret
      004BB5                       1007 00102$:
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004BB5 8E 04            [24] 1009 	mov	ar4,r6
      004BB7 8F 05            [24] 1010 	mov	ar5,r7
      004BB9 12 4E A6         [24] 1011 	lcall	_ak820_outline_0026
      004BBC C0 07            [24] 1012 	push	ar7
      004BBE C0 06            [24] 1013 	push	ar6
      004BC0 12 BE 74         [24] 1014 	lcall	___memcpy
      004BC3 31 C9            [12] 1015 	acall	_ak820_tapping_source
      004BC5 AD 82            [24] 1016 	mov	r5, dpl
      004BC7 D0 06            [24] 1017 	pop	ar6
      004BC9 D0 07            [24] 1018 	pop	ar7
                                   1019 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004BCB BD FF 04         [24] 1020 	cjne	r5,#0xff,00104$
      004BCE 75 82 01         [24] 1021 	mov	dpl, #0x01
      004BD1 22               [24] 1022 	ret
      004BD2                       1023 00104$:
                                   1024 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004BD2 74 07            [12] 1025 	mov	a,#0x07
      004BD4 12 38 2E         [24] 1026 	lcall	_ak820_outline_0024
      004BD7 12 38 3E         [24] 1027 	lcall	_ak820_outline_0055
      004BDA 90 06 82         [24] 1028 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004BDD 12 4E D3         [24] 1029 	lcall	_ak820_outline_0062
                                   1030 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004BE0 BE 1A 15         [24] 1031 	cjne	r6,#0x1a,00111$
      004BE3 BF 7C 12         [24] 1032 	cjne	r7,#0x7c,00111$
      004BE6 90 06 82         [24] 1033 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004BE9 74 26            [12] 1034 	mov	a,#0x26
      004BEB F0               [24] 1035 	movx	@dptr,a
      004BEC 74 22            [12] 1036 	mov	a,#0x22
      004BEE A3               [24] 1037 	inc	dptr
      004BEF F0               [24] 1038 	movx	@dptr,a
      004BF0 90 06 84         [24] 1039 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004BF3 74 02            [12] 1040 	mov	a,#0x02
      004BF5 F0               [24] 1041 	movx	@dptr,a
      004BF6 80 28            [24] 1042 	sjmp	00112$
      004BF8                       1043 00111$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004BF8 BE 1B 15         [24] 1045 	cjne	r6,#0x1b,00108$
      004BFB BF 7C 12         [24] 1046 	cjne	r7,#0x7c,00108$
      004BFE 90 06 82         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004C01 74 27            [12] 1048 	mov	a,#0x27
      004C03 F0               [24] 1049 	movx	@dptr,a
      004C04 74 32            [12] 1050 	mov	a,#0x32
      004C06 A3               [24] 1051 	inc	dptr
      004C07 F0               [24] 1052 	movx	@dptr,a
      004C08 90 06 84         [24] 1053 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004C0B 74 20            [12] 1054 	mov	a,#0x20
      004C0D F0               [24] 1055 	movx	@dptr,a
      004C0E 80 10            [24] 1056 	sjmp	00112$
      004C10                       1057 00108$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004C10 BE 1E 0D         [24] 1059 	cjne	r6,#0x1e,00112$
      004C13 BF 7C 0A         [24] 1060 	cjne	r7,#0x7c,00112$
      004C16 90 06 82         [24] 1061 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004C19 74 28            [12] 1062 	mov	a,#0x28
      004C1B F0               [24] 1063 	movx	@dptr,a
      004C1C 74 32            [12] 1064 	mov	a,#0x32
      004C1E A3               [24] 1065 	inc	dptr
      004C1F F0               [24] 1066 	movx	@dptr,a
      004C20                       1067 00112$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004C20 90 06 82         [24] 1069 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004C23 E0               [24] 1070 	movx	a,@dptr
      004C24 A3               [24] 1071 	inc	dptr
      004C25 E0               [24] 1072 	movx	a,@dptr
      004C26 FF               [12] 1073 	mov	r7,a
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004C27 BF 20 00         [24] 1075 	cjne	r7,#0x20,00242$
      004C2A                       1076 00242$:
      004C2A 40 05            [24] 1077 	jc	00113$
      004C2C BF 50 00         [24] 1078 	cjne	r7,#0x50,00244$
      004C2F                       1079 00244$:
      004C2F 40 04            [24] 1080 	jc	00114$
      004C31                       1081 00113$:
      004C31 75 82 01         [24] 1082 	mov	dpl, #0x01
      004C34 22               [24] 1083 	ret
      004C35                       1084 00114$:
                                   1085 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004C35 BF 40 00         [24] 1086 	cjne	r7,#0x40,00246$
      004C38                       1087 00246$:
      004C38 40 0C            [24] 1088 	jc	00117$
      004C3A 53 07 0F         [24] 1089 	anl	ar7,#0x0f
      004C3D BF 06 00         [24] 1090 	cjne	r7,#0x06,00248$
      004C40                       1091 00248$:
      004C40 40 04            [24] 1092 	jc	00117$
      004C42 75 82 00         [24] 1093 	mov	dpl, #0x00
      004C45 22               [24] 1094 	ret
      004C46                       1095 00117$:
                                   1096 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004C46 90 06 80         [24] 1097 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004C49 12 38 3E         [24] 1098 	lcall	_ak820_outline_0055
      004C4C 74 05            [12] 1099 	mov	a,#0x05
      004C4E 12 4E 8C         [24] 1100 	lcall	_ak820_outline_0012
      004C51 60 1E            [24] 1101 	jz	00131$
                                   1102 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004C53 90 0E 09         [24] 1103 	mov	dptr,#_pending
      004C56 ED               [12] 1104 	mov	a,r5
      004C57 12 43 13         [24] 1105 	lcall	_ak820_outline_0034
                                   1106 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004C5A 12 38 3E         [24] 1107 	lcall	_ak820_outline_0055
      004C5D 90 06 73         [24] 1108 	mov	dptr,#_pending_time
      004C60 12 4E D3         [24] 1109 	lcall	_ak820_outline_0062
                                   1110 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004C63 90 06 82         [24] 1111 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004C66 12 38 3E         [24] 1112 	lcall	_ak820_outline_0055
      004C69 90 06 75         [24] 1113 	mov	dptr,#_pending_code
      004C6C 12 4E D3         [24] 1114 	lcall	_ak820_outline_0062
      004C6F A1 21            [12] 1115 	ajmp	00132$
      004C71                       1116 00131$:
                                   1117 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004C71 90 0E 09         [24] 1118 	mov	dptr,#_pending
      004C74 E0               [24] 1119 	movx	a,@dptr
      004C75 FF               [12] 1120 	mov	r7,a
      004C76 ED               [12] 1121 	mov	a,r5
      004C77 B5 07 02         [24] 1122 	cjne	a,ar7,00251$
      004C7A 80 02            [24] 1123 	sjmp	00252$
      004C7C                       1124 00251$:
      004C7C 81 FA            [12] 1125 	ajmp	00128$
      004C7E                       1126 00252$:
                                   1127 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004C7E 12 4F 01         [24] 1128 	lcall	_ak820_outline_0165
                                   1129 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004C81 90 06 84         [24] 1130 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004C84 E0               [24] 1131 	movx	a,@dptr
      004C85 FF               [12] 1132 	mov	r7,a
      004C86 E0               [24] 1133 	movx	a,@dptr
      004C87 60 05            [24] 1134 	jz	00120$
      004C89 8F 82            [24] 1135 	mov	dpl, r7
      004C8B 12 82 50         [24] 1136 	lcall	_add_owned_mods
      004C8E                       1137 00120$:
                                   1138 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004C8E 90 06 80         [24] 1139 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004C91 12 38 3E         [24] 1140 	lcall	_ak820_outline_0055
      004C94 74 07            [12] 1141 	mov	a,#0x07
      004C96 12 4E F5         [24] 1142 	lcall	_ak820_outline_0143
      004C99 90 06 82         [24] 1143 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004C9C E0               [24] 1144 	movx	a,@dptr
      004C9D F9               [12] 1145 	mov	r1,a
      004C9E 7A 00            [12] 1146 	mov	r2,#0x00
      004CA0 12 33 FC         [24] 1147 	lcall	_ak820_outline_0130
      004CA3 12 4E FB         [24] 1148 	lcall	_ak820_outline_0145
                                   1149 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004CA6 C3               [12] 1150 	clr	c
      004CA7 04               [12] 1151 	inc	a
      004CA8 99               [12] 1152 	subb	a,r1
      004CA9 50 3D            [24] 1153 	jnc	00122$
                                   1154 ;	free result
                                   1155 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004CAB 74 06            [12] 1156 	mov	a,#0x06
      004CAD 12 38 2E         [24] 1157 	lcall	_ak820_outline_0024
      004CB0 E0               [24] 1158 	movx	a,@dptr
      004CB1 54 0F            [12] 1159 	anl	a,#0x0f
      004CB3 44 10            [12] 1160 	orl	a,#0x10
      004CB5 F0               [24] 1161 	movx	@dptr,a
                                   1162 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004CB6 74 05            [12] 1163 	mov	a,#0x05
      004CB8 12 4E F5         [24] 1164 	lcall	_ak820_outline_0143
      004CBB 12 33 FC         [24] 1165 	lcall	_ak820_outline_0130
      004CBE 74 01            [12] 1166 	mov	a,#0x01
      004CC0 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004CC1 12 4E D9         [24] 1169 	lcall	_ak820_outline_0082
      004CC4 12 4E EE         [24] 1170 	lcall	_ak820_outline_0117
      004CC7 C0 07            [24] 1171 	push	ar7
      004CC9 C0 06            [24] 1172 	push	ar6
      004CCB C0 04            [24] 1173 	push	ar4
      004CCD C0 03            [24] 1174 	push	ar3
      004CCF 12 76 98         [24] 1175 	lcall	_process_record
      004CD2 D0 03            [24] 1176 	pop	ar3
      004CD4 D0 04            [24] 1177 	pop	ar4
      004CD6 D0 06            [24] 1178 	pop	ar6
      004CD8 D0 07            [24] 1179 	pop	ar7
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004CDA 12 33 FC         [24] 1181 	lcall	_ak820_outline_0130
      004CDD E4               [12] 1182 	clr	a
      004CDE F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004CDF FC               [12] 1185 	mov	r4,a
      004CE0 12 38 8A         [24] 1186 	lcall	_ak820_outline_0124
      004CE3 8C F0            [24] 1187 	mov	b, r4
      004CE5 12 76 98         [24] 1188 	lcall	_process_record
      004CE8                       1189 00122$:
                                   1190 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004CE8 90 06 84         [24] 1191 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004CEB E0               [24] 1192 	movx	a,@dptr
      004CEC FF               [12] 1193 	mov	r7,a
      004CED E0               [24] 1194 	movx	a,@dptr
      004CEE 60 31            [24] 1195 	jz	00132$
                                   1196 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004CF0 8F 82            [24] 1197 	mov	dpl, r7
      004CF2 12 82 5F         [24] 1198 	lcall	_del_owned_mods
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004CF5 12 85 82         [24] 1200 	lcall	_send_keyboard_report
      004CF8 80 27            [24] 1201 	sjmp	00132$
      004CFA                       1202 00128$:
                                   1203 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004CFA ED               [12] 1204 	mov	a,r5
      004CFB 24 F1            [12] 1205 	add	a, #_source_state
      004CFD FE               [12] 1206 	mov	r6,a
      004CFE E4               [12] 1207 	clr	a
      004CFF 34 05            [12] 1208 	addc	a, #(_source_state >> 8)
      004D01 FF               [12] 1209 	mov	r7,a
      004D02 12 38 8A         [24] 1210 	lcall	_ak820_outline_0124
      004D05 E0               [24] 1211 	movx	a,@dptr
      004D06 FD               [12] 1212 	mov	r5,a
      004D07 30 E2 17         [24] 1213 	jnb	acc.2,00132$
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004D0A 53 05 FB         [24] 1215 	anl	ar5,#0xfb
      004D0D 12 38 8A         [24] 1216 	lcall	_ak820_outline_0124
      004D10 ED               [12] 1217 	mov	a,r5
      004D11 F0               [24] 1218 	movx	@dptr,a
                                   1219 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004D12 90 06 82         [24] 1220 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004D15 12 38 3E         [24] 1221 	lcall	_ak820_outline_0055
      004D18 90 06 79         [24] 1222 	mov	dptr,#_hold_PARM_2
      004D1B E4               [12] 1223 	clr	a
      004D1C 12 43 46         [24] 1224 	lcall	_ak820_outline_0077
      004D1F 51 03            [12] 1225 	acall	_hold
      004D21                       1226 00132$:
                                   1227 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004D21 75 82 00         [24] 1228 	mov	dpl, #0x00
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004D24 22               [24] 1230 	ret
                                   1231 ;------------------------------------------------------------
                                   1232 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1233 ;------------------------------------------------------------
                                   1234 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_670'
                                   1235 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_671'
                                   1236 ;------------------------------------------------------------
                                   1237 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1238 ;	-----------------------------------------
                                   1239 ;	 function ak820_tapping_cancel
                                   1240 ;	-----------------------------------------
      004D25                       1241 _ak820_tapping_cancel:
                                   1242 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004D25 12 4F 01         [24] 1243 	lcall	_ak820_outline_0165
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004D28 7F 00            [12] 1245 	mov	r7,#0x00
      004D2A                       1246 00103$:
      004D2A BF 82 00         [24] 1247 	cjne	r7,#0x82,00122$
      004D2D                       1248 00122$:
      004D2D 50 16            [24] 1249 	jnc	00105$
                                   1250 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004D2F 12 4E 97         [24] 1251 	lcall	_ak820_outline_0022
                                   1252 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004D32 74 02            [12] 1253 	mov	a,#0x02
      004D34 5C               [12] 1254 	anl	a,r4
      004D35 FB               [12] 1255 	mov	r3,a
      004D36 53 04 01         [24] 1256 	anl	ar4,#0x01
      004D39 EC               [12] 1257 	mov	a,r4
      004D3A 2C               [12] 1258 	add	a,r4
      004D3B 42 03            [12] 1259 	orl	ar3,a
      004D3D 12 38 A5         [24] 1260 	lcall	_ak820_outline_0141
      004D40 EB               [12] 1261 	mov	a,r3
      004D41 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004D42 0F               [12] 1264 	inc	r7
      004D43 80 E5            [24] 1265 	sjmp	00103$
      004D45                       1266 00105$:
                                   1267 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004D45 22               [24] 1268 	ret
                                   1269 ;------------------------------------------------------------
                                   1270 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1271 ;------------------------------------------------------------
                                   1272 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1273 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1274 ;code          Allocated with name '_ak820_oneshot_process_code_10000_672'
                                   1275 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_673'
                                   1276 ;i             Allocated with name '_ak820_oneshot_process_i_40000_687'
                                   1277 ;------------------------------------------------------------
                                   1278 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1279 ;	-----------------------------------------
                                   1280 ;	 function ak820_oneshot_process
                                   1281 ;	-----------------------------------------
      004D46                       1282 _ak820_oneshot_process:
      004D46 12 38 79         [24] 1283 	lcall	_ak820_outline_0113
      004D49 90 06 89         [24] 1284 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004D4C 12 38 7E         [24] 1285 	lcall	_ak820_outline_0114
                                   1286 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004D4F 90 06 87         [24] 1287 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004D52 E0               [24] 1288 	movx	a,@dptr
      004D53 FF               [12] 1289 	mov	r7,a
      004D54 BF FF 02         [24] 1290 	cjne	r7,#0xff,00248$
      004D57 80 0B            [24] 1291 	sjmp	00101$
      004D59                       1292 00248$:
      004D59 C0 07            [24] 1293 	push	ar7
      004D5B 12 A7 83         [24] 1294 	lcall	_get_repeat_key_count
      004D5E E5 82            [12] 1295 	mov	a, dpl
      004D60 D0 07            [24] 1296 	pop	ar7
      004D62 60 04            [24] 1297 	jz	00102$
      004D64                       1298 00101$:
      004D64 75 82 01         [24] 1299 	mov	dpl, #0x01
      004D67 22               [24] 1300 	ret
      004D68                       1301 00102$:
                                   1302 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004D68 90 06 89         [24] 1303 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004D6B E0               [24] 1304 	movx	a,@dptr
      004D6C FD               [12] 1305 	mov	r5,a
      004D6D A3               [24] 1306 	inc	dptr
      004D6E E0               [24] 1307 	movx	a,@dptr
      004D6F FB               [12] 1308 	mov	r3,a
      004D70 BB 52 02         [24] 1309 	cjne	r3,#0x52,00250$
      004D73 80 02            [24] 1310 	sjmp	00251$
      004D75                       1311 00250$:
      004D75 C1 1C            [12] 1312 	ajmp	00116$
      004D77                       1313 00251$:
      004D77 8D 04            [24] 1314 	mov	ar4,r5
      004D79 53 04 E0         [24] 1315 	anl	ar4,#0xe0
      004D7C BC A0 02         [24] 1316 	cjne	r4,#0xa0,00252$
      004D7F 80 02            [24] 1317 	sjmp	00253$
      004D81                       1318 00252$:
      004D81 C1 1C            [12] 1319 	ajmp	00116$
      004D83                       1320 00253$:
                                   1321 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004D83 8D 04            [24] 1322 	mov	ar4,r5
      004D85 53 04 0F         [24] 1323 	anl	ar4,#0x0f
      004D88 90 06 8B         [24] 1324 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004D8B EC               [12] 1325 	mov	a,r4
      004D8C F0               [24] 1326 	movx	@dptr,a
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004D8D ED               [12] 1328 	mov	a,r5
      004D8E 30 E4 08         [24] 1329 	jnb	acc.4,00105$
      004D91 EC               [12] 1330 	mov	a,r4
      004D92 C4               [12] 1331 	swap	a
      004D93 54 F0            [12] 1332 	anl	a,#0xf0
      004D95 90 06 8B         [24] 1333 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004D98 F0               [24] 1334 	movx	@dptr,a
      004D99                       1335 00105$:
                                   1336 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004D99 90 06 88         [24] 1337 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004D9C E0               [24] 1338 	movx	a,@dptr
      004D9D 60 2F            [24] 1339 	jz	00113$
                                   1340 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004D9F 12 4E 97         [24] 1341 	lcall	_ak820_outline_0022
      004DA2 43 04 08         [24] 1342 	orl	ar4,#0x08
      004DA5 12 43 3F         [24] 1343 	lcall	_ak820_outline_0067
                                   1344 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004DA8 53 04 EF         [24] 1345 	anl	ar4,#0xef
      004DAB 12 43 3F         [24] 1346 	lcall	_ak820_outline_0067
                                   1347 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004DAE 90 0E 0A         [24] 1348 	mov	dptr,#_ak820_oneshot_target
      004DB1 E0               [24] 1349 	movx	a,@dptr
      004DB2 FC               [12] 1350 	mov	r4,a
      004DB3 BC FF 02         [24] 1351 	cjne	r4,#0xff,00256$
      004DB6 80 0B            [24] 1352 	sjmp	00107$
      004DB8                       1353 00256$:
      004DB8 12 38 A5         [24] 1354 	lcall	_ak820_outline_0141
      004DBB E0               [24] 1355 	movx	a,@dptr
      004DBC FC               [12] 1356 	mov	r4,a
      004DBD 43 04 10         [24] 1357 	orl	ar4,#0x10
      004DC0 12 43 3F         [24] 1358 	lcall	_ak820_outline_0067
      004DC3                       1359 00107$:
                                   1360 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004DC3 90 06 8B         [24] 1361 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004DC6 E0               [24] 1362 	movx	a,@dptr
      004DC7 F5 82            [12] 1363 	mov	dpl,a
      004DC9 12 7C 02         [24] 1364 	lcall	_register_mods
      004DCC 80 4A            [24] 1365 	sjmp	00114$
      004DCE                       1366 00113$:
                                   1367 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004DCE 12 4E 97         [24] 1368 	lcall	_ak820_outline_0022
      004DD1 30 E3 44         [24] 1369 	jnb	acc.3,00114$
                                   1370 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004DD4 EC               [12] 1371 	mov	a,r4
      004DD5 20 E4 24         [24] 1372 	jb	acc.4,00109$
                                   1373 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004DD8 90 06 85         [24] 1374 	mov	dptr,#_ak820_oneshot_mods
      004DDB E0               [24] 1375 	movx	a,@dptr
      004DDC F4               [12] 1376 	cpl	a
      004DDD FC               [12] 1377 	mov	r4,a
      004DDE 90 06 8B         [24] 1378 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004DE1 E0               [24] 1379 	movx	a,@dptr
      004DE2 FB               [12] 1380 	mov	r3,a
      004DE3 52 04            [12] 1381 	anl	ar4,a
      004DE5 8C 82            [24] 1382 	mov	dpl, r4
      004DE7 C0 06            [24] 1383 	push	ar6
      004DE9 C0 05            [24] 1384 	push	ar5
      004DEB C0 03            [24] 1385 	push	ar3
      004DED 12 82 50         [24] 1386 	lcall	_add_owned_mods
      004DF0 D0 03            [24] 1387 	pop	ar3
      004DF2 D0 05            [24] 1388 	pop	ar5
      004DF4 D0 06            [24] 1389 	pop	ar6
                                   1390 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004DF6 90 06 85         [24] 1391 	mov	dptr,#_ak820_oneshot_mods
      004DF9 E0               [24] 1392 	movx	a,@dptr
      004DFA 4B               [12] 1393 	orl	a,r3
      004DFB F0               [24] 1394 	movx	@dptr,a
      004DFC                       1395 00109$:
                                   1396 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004DFC 90 06 8B         [24] 1397 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004DFF E0               [24] 1398 	movx	a,@dptr
      004E00 F5 82            [12] 1399 	mov	dpl,a
      004E02 C0 06            [24] 1400 	push	ar6
      004E04 C0 05            [24] 1401 	push	ar5
      004E06 12 7C 16         [24] 1402 	lcall	_unregister_mods
      004E09 D0 05            [24] 1403 	pop	ar5
      004E0B D0 06            [24] 1404 	pop	ar6
                                   1405 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004E0D 12 38 A5         [24] 1406 	lcall	_ak820_outline_0141
      004E10 E0               [24] 1407 	movx	a,@dptr
      004E11 FC               [12] 1408 	mov	r4,a
      004E12 53 04 E7         [24] 1409 	anl	ar4,#0xe7
      004E15 12 43 3F         [24] 1410 	lcall	_ak820_outline_0067
      004E18                       1411 00114$:
                                   1412 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004E18 75 82 00         [24] 1413 	mov	dpl, #0x00
      004E1B 22               [24] 1414 	ret
      004E1C                       1415 00116$:
                                   1416 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004E1C 90 06 88         [24] 1417 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004E1F E0               [24] 1418 	movx	a,@dptr
      004E20 60 5C            [24] 1419 	jz	00124$
      004E22 90 06 89         [24] 1420 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004E25 12 38 67         [24] 1421 	lcall	_ak820_outline_0090
      004E28 C3               [12] 1422 	clr	c
      004E29 74 01            [12] 1423 	mov	a,#0x01
      004E2B 9D               [12] 1424 	subb	a,r5
      004E2C E4               [12] 1425 	clr	a
      004E2D 9E               [12] 1426 	subb	a,r6
      004E2E 50 4E            [24] 1427 	jnc	00124$
                                   1428 ;	free result
                                   1429 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004E30 C3               [12] 1430 	clr	c
      004E31 ED               [12] 1431 	mov	a,r5
      004E32 94 E0            [12] 1432 	subb	a,#0xe0
      004E34 EE               [12] 1433 	mov	a,r6
      004E35 94 00            [12] 1434 	subb	a,#0x00
      004E37 40 07            [24] 1435 	jc	00129$
      004E39 74 E7            [12] 1436 	mov	a,#0xe7
      004E3B 9D               [12] 1437 	subb	a,r5
      004E3C E4               [12] 1438 	clr	a
      004E3D 9E               [12] 1439 	subb	a,r6
      004E3E 50 3E            [24] 1440 	jnc	00124$
                                   1441 ;	free result
      004E40                       1442 00129$:
                                   1443 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004E40 74 AE            [12] 1444 	mov	a,#0x100 - 0x52
      004E42 2E               [12] 1445 	add	a,r6
      004E43 50 09            [24] 1446 	jnc	00165$
      004E45 C3               [12] 1447 	clr	c
      004E46 74 DF            [12] 1448 	mov	a,#0xdf
      004E48 9D               [12] 1449 	subb	a,r5
      004E49 74 52            [12] 1450 	mov	a,#0x52
      004E4B 9E               [12] 1451 	subb	a,r6
      004E4C 50 30            [24] 1452 	jnc	00124$
                                   1453 ;	free result
                                   1454 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004E4E                       1455 00165$:
      004E4E 7E 00            [12] 1456 	mov	r6,#0x00
      004E50                       1457 00131$:
      004E50 BE 82 00         [24] 1458 	cjne	r6,#0x82,00265$
      004E53                       1459 00265$:
      004E53 50 12            [24] 1460 	jnc	00120$
                                   1461 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004E55 EE               [12] 1462 	mov	a,r6
      004E56 12 4E E0         [24] 1463 	lcall	_ak820_outline_0085
      004E59 30 E3 08         [24] 1464 	jnb	acc.3,00132$
      004E5C 43 03 10         [24] 1465 	orl	ar3,#0x10
      004E5F 12 38 A0         [24] 1466 	lcall	_ak820_outline_0133
      004E62 EB               [12] 1467 	mov	a,r3
      004E63 F0               [24] 1468 	movx	@dptr,a
      004E64                       1469 00132$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004E64 0E               [12] 1471 	inc	r6
      004E65 80 E9            [24] 1472 	sjmp	00131$
      004E67                       1473 00120$:
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004E67 90 06 85         [24] 1475 	mov	dptr,#_ak820_oneshot_mods
      004E6A E0               [24] 1476 	movx	a,@dptr
      004E6B FE               [12] 1477 	mov	r6,a
      004E6C E0               [24] 1478 	movx	a,@dptr
      004E6D 60 0F            [24] 1479 	jz	00124$
                                   1480 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004E6F 90 06 86         [24] 1481 	mov	dptr,#_ak820_oneshot_consumed
      004E72 EE               [12] 1482 	mov	a,r6
      004E73 F0               [24] 1483 	movx	@dptr,a
                                   1484 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004E74 90 0E 0A         [24] 1485 	mov	dptr,#_ak820_oneshot_target
      004E77 EF               [12] 1486 	mov	a,r7
      004E78 F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004E79 90 06 85         [24] 1489 	mov	dptr,#_ak820_oneshot_mods
      004E7C E4               [12] 1490 	clr	a
      004E7D F0               [24] 1491 	movx	@dptr,a
      004E7E                       1492 00124$:
                                   1493 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004E7E 75 82 01         [24] 1494 	mov	dpl, #0x01
                                   1495 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004E81 22               [24] 1496 	ret
                                   1497 	.area CSEG    (CODE)
                                   1498 	.area CONST   (CODE)
                                   1499 	.area XINIT   (CODE)
      00C81E                       1500 __xinit__pending:
      00C81E FF                    1501 	.db #0xff	; 255
      00C81F                       1502 __xinit__ak820_oneshot_target:
      00C81F FF                    1503 	.db #0xff	; 255
                                   1504 	.area CABS    (ABS,CODE)
                                   1505 
                                   1506 ; Experimental exact instruction outlining.
                                   1507 	.globl _ak820_outline_0009
                                   1508 	.globl _ak820_outline_0010
                                   1509 	.globl _ak820_outline_0012
                                   1510 	.globl _ak820_outline_0014
                                   1511 	.globl _ak820_outline_0017
                                   1512 	.globl _ak820_outline_0022
                                   1513 	.globl _ak820_outline_0024
                                   1514 	.globl _ak820_outline_0026
                                   1515 	.globl _ak820_outline_0034
                                   1516 	.globl _ak820_outline_0035
                                   1517 	.globl _ak820_outline_0037
                                   1518 	.globl _ak820_outline_0055
                                   1519 	.globl _ak820_outline_0059
                                   1520 	.globl _ak820_outline_0062
                                   1521 	.globl _ak820_outline_0067
                                   1522 	.globl _ak820_outline_0077
                                   1523 	.globl _ak820_outline_0082
                                   1524 	.globl _ak820_outline_0085
                                   1525 	.globl _ak820_outline_0090
                                   1526 	.globl _ak820_outline_0113
                                   1527 	.globl _ak820_outline_0114
                                   1528 	.globl _ak820_outline_0117
                                   1529 	.globl _ak820_outline_0124
                                   1530 	.globl _ak820_outline_0130
                                   1531 	.globl _ak820_outline_0133
                                   1532 	.globl _ak820_outline_0141
                                   1533 	.globl _ak820_outline_0143
                                   1534 	.globl _ak820_outline_0145
                                   1535 	.globl _ak820_outline_0165
                                   1536 	.globl _ak820_outline_0166
                                   1537 	.globl _ak820_outline_0194
                                   1538 	.globl _ak820_outline_0199
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0009
      004E82                       1542 _ak820_outline_0009:
      004E82 E0               [24] 1543 	movx	a,@dptr
      004E83 FE               [12] 1544 	mov	r6,a
      004E84 A3               [24] 1545 	inc	dptr
      004E85 E0               [24] 1546 	movx	a,@dptr
      004E86 FF               [12] 1547 	mov	r7,a
      004E87 8E 04            [24] 1548 	mov	ar4,r6
      004E89 8F 05            [24] 1549 	mov	ar5,r7
      004E8B 22               [24] 1550 	ret
                                   1551 
                                   1552 	.area CSEG (CODE)
                                   1553 ; function ak820_outline_0012
      004E8C                       1554 _ak820_outline_0012:
      004E8C 2E               [12] 1555 	add	a,r6
      004E8D FB               [12] 1556 	mov	r3,a
      004E8E E4               [12] 1557 	clr	a
      004E8F 3F               [12] 1558 	addc	a,r7
      004E90 FC               [12] 1559 	mov	r4,a
      004E91 8B 82            [24] 1560 	mov	dpl,r3
      004E93 8C 83            [24] 1561 	mov	dph,r4
      004E95 E0               [24] 1562 	movx	a,@dptr
      004E96 22               [24] 1563 	ret
                                   1564 
                                   1565 	.area CSEG (CODE)
                                   1566 ; function ak820_outline_0022
      004E97                       1567 _ak820_outline_0022:
      004E97 EF               [12] 1568 	mov	a,r7
      004E98 24 F1            [12] 1569 	add	a,#_source_state
      004E9A FD               [12] 1570 	mov	r5,a
      004E9B E4               [12] 1571 	clr	a
      004E9C 34 05            [12] 1572 	addc	a,#(_source_state>>8)
      004E9E FE               [12] 1573 	mov	r6,a
      004E9F 8D 82            [24] 1574 	mov	dpl,r5
      004EA1 8E 83            [24] 1575 	mov	dph,r6
      004EA3 E0               [24] 1576 	movx	a,@dptr
      004EA4 FC               [12] 1577 	mov	r4,a
      004EA5 22               [24] 1578 	ret
                                   1579 
                                   1580 	.area CSEG (CODE)
                                   1581 ; function ak820_outline_0026
      004EA6                       1582 _ak820_outline_0026:
      004EA6 90 0D F1         [24] 1583 	mov	dptr,#___memcpy_PARM_2
      004EA9 EC               [12] 1584 	mov	a,r4
      004EAA F0               [24] 1585 	movx	@dptr,a
      004EAB ED               [12] 1586 	mov	a,r5
      004EAC A3               [24] 1587 	inc	dptr
      004EAD F0               [24] 1588 	movx	@dptr,a
      004EAE E4               [12] 1589 	clr	a
      004EAF A3               [24] 1590 	inc	dptr
      004EB0 F0               [24] 1591 	movx	@dptr,a
      004EB1 90 0D F4         [24] 1592 	mov	dptr,#___memcpy_PARM_3
      004EB4 74 02            [12] 1593 	mov	a,#0x02
      004EB6 F0               [24] 1594 	movx	@dptr,a
      004EB7 E4               [12] 1595 	clr	a
      004EB8 A3               [24] 1596 	inc	dptr
      004EB9 F0               [24] 1597 	movx	@dptr,a
      004EBA 90 06 77         [24] 1598 	mov	dptr,#_ak820_tapping_source_PARM_1
      004EBD F5 F0            [12] 1599 	mov	b,a
      004EBF 22               [24] 1600 	ret
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0035
      004EC0                       1604 _ak820_outline_0035:
      004EC0 2E               [12] 1605 	add	a,r6
      004EC1 FC               [12] 1606 	mov	r4,a
      004EC2 E4               [12] 1607 	clr	a
      004EC3 3F               [12] 1608 	addc	a,r7
      004EC4 FD               [12] 1609 	mov	r5,a
      004EC5 8C 82            [24] 1610 	mov	dpl,r4
      004EC7 8D 83            [24] 1611 	mov	dph,r5
      004EC9 E0               [24] 1612 	movx	a,@dptr
      004ECA 22               [24] 1613 	ret
                                   1614 
                                   1615 	.area CSEG (CODE)
                                   1616 ; function ak820_outline_0059
      004ECB                       1617 _ak820_outline_0059:
      004ECB FC               [12] 1618 	mov	r4,a
      004ECC 8B 82            [24] 1619 	mov	dpl,r3
      004ECE 8C 83            [24] 1620 	mov	dph,r4
      004ED0 E0               [24] 1621 	movx	a,@dptr
      004ED1 FA               [12] 1622 	mov	r2,a
      004ED2 22               [24] 1623 	ret
                                   1624 
                                   1625 	.area CSEG (CODE)
                                   1626 ; function ak820_outline_0062
      004ED3                       1627 _ak820_outline_0062:
      004ED3 EE               [12] 1628 	mov	a,r6
      004ED4 F0               [24] 1629 	movx	@dptr,a
      004ED5 EF               [12] 1630 	mov	a,r7
      004ED6 A3               [24] 1631 	inc	dptr
      004ED7 F0               [24] 1632 	movx	@dptr,a
      004ED8 22               [24] 1633 	ret
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0082
      004ED9                       1637 _ak820_outline_0082:
      004ED9 8E 00            [24] 1638 	mov	ar0,r6
      004EDB 8F 01            [24] 1639 	mov	ar1,r7
      004EDD 7A 00            [12] 1640 	mov	r2,#0x00
      004EDF 22               [24] 1641 	ret
                                   1642 
                                   1643 	.area CSEG (CODE)
                                   1644 ; function ak820_outline_0085
      004EE0                       1645 _ak820_outline_0085:
      004EE0 24 F1            [12] 1646 	add	a,#_source_state
      004EE2 FC               [12] 1647 	mov	r4,a
      004EE3 E4               [12] 1648 	clr	a
      004EE4 34 05            [12] 1649 	addc	a,#(_source_state>>8)
      004EE6 FD               [12] 1650 	mov	r5,a
      004EE7 8C 82            [24] 1651 	mov	dpl,r4
      004EE9 8D 83            [24] 1652 	mov	dph,r5
      004EEB E0               [24] 1653 	movx	a,@dptr
      004EEC FB               [12] 1654 	mov	r3,a
      004EED 22               [24] 1655 	ret
                                   1656 
                                   1657 	.area CSEG (CODE)
                                   1658 ; function ak820_outline_0117
      004EEE                       1659 _ak820_outline_0117:
      004EEE 88 82            [24] 1660 	mov	dpl,r0
      004EF0 89 83            [24] 1661 	mov	dph,r1
      004EF2 8A F0            [24] 1662 	mov	b,r2
      004EF4 22               [24] 1663 	ret
                                   1664 
                                   1665 	.area CSEG (CODE)
                                   1666 ; function ak820_outline_0143
      004EF5                       1667 _ak820_outline_0143:
      004EF5 2E               [12] 1668 	add	a,r6
      004EF6 FB               [12] 1669 	mov	r3,a
      004EF7 E4               [12] 1670 	clr	a
      004EF8 3F               [12] 1671 	addc	a,r7
      004EF9 FC               [12] 1672 	mov	r4,a
      004EFA 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0145
      004EFB                       1677 _ak820_outline_0145:
      004EFB E9               [12] 1678 	mov	a,r1
      004EFC F0               [24] 1679 	movx	@dptr,a
      004EFD EA               [12] 1680 	mov	a,r2
      004EFE A3               [24] 1681 	inc	dptr
      004EFF F0               [24] 1682 	movx	@dptr,a
      004F00 22               [24] 1683 	ret
                                   1684 
                                   1685 	.area CSEG (CODE)
                                   1686 ; function ak820_outline_0165
      004F01                       1687 _ak820_outline_0165:
      004F01 90 0E 09         [24] 1688 	mov	dptr,#_pending
      004F04 74 FF            [12] 1689 	mov	a,#0xff
      004F06 F0               [24] 1690 	movx	@dptr,a
      004F07 22               [24] 1691 	ret
                                   1692 
                                   1693 	.area CSEG (CODE)
                                   1694 ; function ak820_outline_0194
      004F08                       1695 _ak820_outline_0194:
      004F08 A9 82            [24] 1696 	mov	r1,dpl
      004F0A AA 83            [24] 1697 	mov	r2,dph
      004F0C 22               [24] 1698 	ret
