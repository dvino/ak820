                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B8C                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B8C E5 82            [12]  215 	mov	a,dpl
      003B8E 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B91 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B92 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003B95 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B98 E0               [24]  221 	movx	a,@dptr
      003B99 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003B9C F0               [24]  223 	movx	@dptr,a
      003B9D                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B9D D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B9F 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003BA0                        239 _ak820_nvm_diagnostic:
      003BA0 12 38 79         [24]  240 	lcall	_ak820_outline_0113
      003BA3 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BA6 12 38 7E         [24]  242 	lcall	_ak820_outline_0114
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BA9 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BAC 12 38 3E         [24]  245 	lcall	_ak820_outline_0055
      003BAF A2 0B            [12]  246 	mov	c,_storage_failed
      003BB1 E4               [12]  247 	clr	a
      003BB2 33               [12]  248 	rlc	a
      003BB3 12 38 8A         [24]  249 	lcall	_ak820_outline_0124
      003BB6 12 43 46         [24]  250 	lcall	_ak820_outline_0077
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BB9 A3               [24]  252 	inc	dptr
      003BBA A2 09            [12]  253 	mov	c,_page_valid
      003BBC E4               [12]  254 	clr	a
      003BBD 33               [12]  255 	rlc	a
      003BBE 12 43 13         [24]  256 	lcall	_ak820_outline_0034
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BC1 A2 0A            [12]  258 	mov	c,_page_dirty
      003BC3 E4               [12]  259 	clr	a
      003BC4 33               [12]  260 	rlc	a
      003BC5 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BC6 74 03            [12]  263 	mov	a,#0x03
      003BC8 12 43 80         [24]  264 	lcall	_ak820_outline_0169
      003BCB 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003BCE E0               [24]  266 	movx	a,@dptr
      003BCF 12 38 A0         [24]  267 	lcall	_ak820_outline_0133
      003BD2 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BD3 74 04            [12]  270 	mov	a,#0x04
      003BD5 12 43 80         [24]  271 	lcall	_ak820_outline_0169
      003BD8 90 05 5D         [24]  272 	mov	dptr,#_cached_page
      003BDB E0               [24]  273 	movx	a,@dptr
      003BDC 12 38 A0         [24]  274 	lcall	_ak820_outline_0133
      003BDF F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BE0 12 43 09         [24]  277 	lcall	_ak820_outline_0014
      003BE3 E4               [12]  278 	clr	a
      003BE4 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BE5 74 06            [12]  281 	mov	a,#0x06
      003BE7 12 43 69         [24]  282 	lcall	_ak820_outline_0144
      003BEA 90 05 5F         [24]  283 	mov	dptr,#_first_failure_stage
      003BED E0               [24]  284 	movx	a,@dptr
      003BEE 12 38 8A         [24]  285 	lcall	_ak820_outline_0124
      003BF1 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BF2 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003BF3                        300 _crc_byte:
      003BF3 12 38 79         [24]  301 	lcall	_ak820_outline_0113
      003BF6 90 05 64         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003BF9 12 38 7E         [24]  303 	lcall	_ak820_outline_0114
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BFC 90 05 63         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003BFF E0               [24]  306 	movx	a,@dptr
      003C00 FF               [12]  307 	mov	r7,a
      003C01 7E 00            [12]  308 	mov	r6,#0x00
      003C03 90 05 64         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003C06 E0               [24]  310 	movx	a,@dptr
      003C07 6E               [12]  311 	xrl	a,r6
      003C08 F0               [24]  312 	movx	@dptr,a
      003C09 A3               [24]  313 	inc	dptr
      003C0A E0               [24]  314 	movx	a,@dptr
      003C0B 6F               [12]  315 	xrl	a,r7
      003C0C F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C0D 7F 00            [12]  318 	mov	r7,#0x00
      003C0F                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C0F 90 05 64         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C12 12 38 67         [24]  322 	lcall	_ak820_outline_0090
      003C15 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C18 ED               [12]  324 	mov	a,r5
      003C19 2D               [12]  325 	add	a,r5
      003C1A FB               [12]  326 	mov	r3,a
      003C1B EE               [12]  327 	mov	a,r6
      003C1C 33               [12]  328 	rlc	a
      003C1D FC               [12]  329 	mov	r4,a
      003C1E 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C21 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C24 80 06            [24]  332 	sjmp	00107$
      003C26                        333 00106$:
      003C26 ED               [12]  334 	mov	a,r5
      003C27 2D               [12]  335 	add	a,r5
      003C28 FB               [12]  336 	mov	r3,a
      003C29 EE               [12]  337 	mov	a,r6
      003C2A 33               [12]  338 	rlc	a
      003C2B FC               [12]  339 	mov	r4,a
      003C2C                        340 00107$:
      003C2C 90 05 64         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C2F 12 38 6D         [24]  342 	lcall	_ak820_outline_0099
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C32 0F               [12]  344 	inc	r7
      003C33 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C36 12 33 FC         [24]  347 	lcall	_ak820_outline_0130
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C39 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C3A                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C3A 90 05 66         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C3D 74 FF            [12]  363 	mov	a,#0xff
      003C3F F0               [24]  364 	movx	@dptr,a
      003C40 A3               [24]  365 	inc	dptr
      003C41 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C42 7F 00            [12]  368 	mov	r7,#0x00
      003C44                        369 00102$:
      003C44 90 05 66         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C47 12 38 67         [24]  371 	lcall	_ak820_outline_0090
      003C4A 12 43 58         [24]  372 	lcall	_ak820_outline_0111
      003C4D 90 05 63         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C50 F0               [24]  374 	movx	@dptr,a
      003C51 12 38 A5         [24]  375 	lcall	_ak820_outline_0141
      003C54 C0 07            [24]  376 	push	ar7
      003C56 12 3B F3         [24]  377 	lcall	_crc_byte
      003C59 AD 82            [24]  378 	mov	r5, dpl
      003C5B AE 83            [24]  379 	mov	r6, dph
      003C5D D0 07            [24]  380 	pop	ar7
      003C5F 90 05 66         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C62 12 43 6F         [24]  382 	lcall	_ak820_outline_0146
      003C65 0F               [12]  383 	inc	r7
      003C66 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C69 12 38 A5         [24]  386 	lcall	_ak820_outline_0141
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C6C 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C6D                        399 _write_page:
      003C6D 12 38 79         [24]  400 	lcall	_ak820_outline_0113
      003C70 90 05 68         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C73 12 38 7E         [24]  402 	lcall	_ak820_outline_0114
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C76 90 05 68         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C79 12 37 F1         [24]  405 	lcall	_ak820_outline_0005
      003C7C C0 07            [24]  406 	push	ar7
      003C7E C0 06            [24]  407 	push	ar6
      003C80 12 3A 05         [24]  408 	lcall	_ak820_flash_erase
      003C83 E5 82            [12]  409 	mov	a, dpl
      003C85 D0 06            [24]  410 	pop	ar6
      003C87 D0 07            [24]  411 	pop	ar7
      003C89 70 03            [24]  412 	jnz	00102$
      003C8B F5 82            [12]  413 	mov	dpl,a
      003C8D 22               [24]  414 	ret
      003C8E                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C8E 90 04 F9         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C91 74 1D            [12]  418 	mov	a,#_page_data
      003C93 F0               [24]  419 	movx	@dptr,a
      003C94 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003C96 A3               [24]  421 	inc	dptr
      003C97 12 43 46         [24]  422 	lcall	_ak820_outline_0077
      003C9A 12 3B 19         [24]  423 	lcall	_ak820_flash_program_page
      003C9D E5 82            [12]  424 	mov	a, dpl
      003C9F 70 03            [24]  425 	jnz	00120$
      003CA1 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CA3 22               [24]  428 	ret
      003CA4                        429 00120$:
      003CA4 7F 00            [12]  430 	mov	r7,#0x00
      003CA6                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003CA6 8F 05            [24]  433 	mov	ar5,r7
      003CA8 7E 00            [12]  434 	mov	r6,#0x00
      003CAA 90 05 68         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003CAD 12 38 AA         [24]  436 	lcall	_ak820_outline_0150
      003CB0 ED               [12]  437 	mov	a,r5
      003CB1 2B               [12]  438 	add	a, r3
      003CB2 FB               [12]  439 	mov	r3,a
      003CB3 EE               [12]  440 	mov	a,r6
      003CB4 3C               [12]  441 	addc	a, r4
      003CB5 FC               [12]  442 	mov	r4,a
      003CB6 12 33 FC         [24]  443 	lcall	_ak820_outline_0130
      003CB9 12 38 F8         [24]  444 	lcall	_ak820_flash_read
      003CBC AE 82            [24]  445 	mov	r6, dpl
      003CBE 12 43 58         [24]  446 	lcall	_ak820_outline_0111
      003CC1 FD               [12]  447 	mov	r5,a
      003CC2 EE               [12]  448 	mov	a,r6
      003CC3 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003CC6 80 04            [24]  450 	sjmp	00109$
      003CC8                        451 00149$:
      003CC8 75 82 00         [24]  452 	mov	dpl, #0x00
      003CCB 22               [24]  453 	ret
      003CCC                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CCC 0F               [12]  456 	inc	r7
      003CCD BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CD0 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CD3 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003CD4                        472 _journal_header_valid:
      003CD4 12 38 79         [24]  473 	lcall	_ak820_outline_0113
      003CD7 90 05 6A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003CDA 12 38 7E         [24]  475 	lcall	_ak820_outline_0114
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CDD 90 05 6A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003CE0 12 37 F1         [24]  478 	lcall	_ak820_outline_0005
      003CE3 E0               [24]  479 	movx	a,@dptr
      003CE4 FD               [12]  480 	mov	r5,a
      003CE5 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003CE8 80 04            [24]  482 	sjmp	00116$
      003CEA                        483 00138$:
      003CEA 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CED 22               [24]  486 	ret
      003CEE                        487 00116$:
      003CEE 7D 01            [12]  488 	mov	r5,#0x01
      003CF0                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CF0 ED               [12]  491 	mov	a,r5
      003CF1 12 38 2E         [24]  492 	lcall	_ak820_outline_0024
      003CF4 E0               [24]  493 	movx	a,@dptr
      003CF5 FC               [12]  494 	mov	r4,a
      003CF6 8D 02            [24]  495 	mov	ar2,r5
      003CF8 7B 00            [12]  496 	mov	r3,#0x00
      003CFA 74 04            [12]  497 	mov	a,#0x04
      003CFC 2A               [12]  498 	add	a, r2
      003CFD FA               [12]  499 	mov	r2,a
      003CFE E4               [12]  500 	clr	a
      003CFF 3B               [12]  501 	addc	a, r3
      003D00 FB               [12]  502 	mov	r3,a
      003D01 EA               [12]  503 	mov	a,r2
      003D02 2E               [12]  504 	add	a, r6
      003D03 F5 82            [12]  505 	mov	dpl,a
      003D05 EB               [12]  506 	mov	a,r3
      003D06 3F               [12]  507 	addc	a, r7
      003D07 F5 83            [12]  508 	mov	dph,a
      003D09 E0               [24]  509 	movx	a,@dptr
      003D0A 62 04            [12]  510 	xrl	ar4,a
      003D0C BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003D0F 80 04            [24]  512 	sjmp	00107$
      003D11                        513 00139$:
      003D11 75 82 00         [24]  514 	mov	dpl, #0x00
      003D14 22               [24]  515 	ret
      003D15                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D15 0D               [12]  518 	inc	r5
      003D16 BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D19 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D1C 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003D1D                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D1D 7F 00            [12]  538 	mov	r7,#0x00
      003D1F                        539 00115$:
      003D1F EF               [12]  540 	mov	a,r7
      003D20 24 6C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003D22 FD               [12]  542 	mov	r5,a
      003D23 E4               [12]  543 	clr	a
      003D24 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D26 FE               [12]  545 	mov	r6,a
      003D27 8F 04            [24]  546 	mov	ar4,r7
      003D29 7B 00            [12]  547 	mov	r3,#0x00
      003D2B 74 40            [12]  548 	mov	a,#0x40
      003D2D 2C               [12]  549 	add	a, r4
      003D2E FC               [12]  550 	mov	r4,a
      003D2F 74 EF            [12]  551 	mov	a,#0xef
      003D31 3B               [12]  552 	addc	a, r3
      003D32 FB               [12]  553 	mov	r3,a
      003D33 12 43 8B         [24]  554 	lcall	_ak820_outline_0191
      003D36 12 38 F8         [24]  555 	lcall	_ak820_flash_read
      003D39 AC 82            [24]  556 	mov	r4, dpl
      003D3B 12 43 3F         [24]  557 	lcall	_ak820_outline_0067
      003D3E 0F               [12]  558 	inc	r7
      003D3F BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D42 90 05 6C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003D45 12 3C D4         [24]  562 	lcall	_journal_header_valid
      003D48 E5 82            [12]  563 	mov	a, dpl
      003D4A 70 01            [24]  564 	jnz	00103$
      003D4C 22               [24]  565 	ret
      003D4D                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D4D 90 05 6D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D50 E0               [24]  569 	movx	a,@dptr
      003D51 FF               [12]  570 	mov	r7,a
      003D52 7E 00            [12]  571 	mov	r6,#0x00
      003D54 90 05 6E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D57 E0               [24]  573 	movx	a,@dptr
      003D58 FC               [12]  574 	mov	r4,a
      003D59 E4               [12]  575 	clr	a
      003D5A 42 07            [12]  576 	orl	ar7,a
      003D5C EC               [12]  577 	mov	a,r4
      003D5D 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D5F 90 05 6F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D62 E0               [24]  581 	movx	a,@dptr
      003D63 FD               [12]  582 	mov	r5,a
      003D64 7C 00            [12]  583 	mov	r4,#0x00
      003D66 90 05 70         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D69 E0               [24]  585 	movx	a,@dptr
      003D6A FA               [12]  586 	mov	r2,a
      003D6B E4               [12]  587 	clr	a
      003D6C 12 43 75         [24]  588 	lcall	_ak820_outline_0152
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D6F C3               [12]  590 	clr	c
      003D70 EF               [12]  591 	mov	a,r7
      003D71 94 A0            [12]  592 	subb	a,#0xa0
      003D73 EE               [12]  593 	mov	a,r6
      003D74 94 00            [12]  594 	subb	a,#0x00
      003D76 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D78 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D7B 02 3B 8C         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D7E                        601 00134$:
      003D7E 7B 00            [12]  602 	mov	r3,#0x00
      003D80                        603 00117$:
      003D80 C0 05            [24]  604 	push	ar5
      003D82 C0 04            [24]  605 	push	ar4
      003D84 EB               [12]  606 	mov	a,r3
      003D85 24 1D            [12]  607 	add	a, #_page_data
      003D87 F9               [12]  608 	mov	r1,a
      003D88 E4               [12]  609 	clr	a
      003D89 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003D8B FA               [12]  611 	mov	r2,a
      003D8C 8B 00            [24]  612 	mov	ar0,r3
      003D8E 7D 00            [12]  613 	mov	r5,#0x00
      003D90 74 EF            [12]  614 	mov	a,#0xef
      003D92 2D               [12]  615 	add	a, r5
      003D93 FD               [12]  616 	mov	r5,a
      003D94 88 82            [24]  617 	mov	dpl, r0
      003D96 8D 83            [24]  618 	mov	dph, r5
      003D98 12 38 F8         [24]  619 	lcall	_ak820_flash_read
      003D9B AD 82            [24]  620 	mov	r5, dpl
      003D9D 12 43 86         [24]  621 	lcall	_ak820_outline_0178
      003DA0 ED               [12]  622 	mov	a,r5
      003DA1 F0               [24]  623 	movx	@dptr,a
      003DA2 0B               [12]  624 	inc	r3
      003DA3 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003DA6 80 06            [24]  626 	sjmp	00191$
      003DA8                        627 00190$:
      003DA8 D0 04            [24]  628 	pop	ar4
      003DAA D0 05            [24]  629 	pop	ar5
      003DAC 80 D2            [24]  630 	sjmp	00117$
      003DAE                        631 00191$:
      003DAE D0 04            [24]  632 	pop	ar4
      003DB0 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DB2 C0 07            [24]  635 	push	ar7
      003DB4 C0 06            [24]  636 	push	ar6
      003DB6 C0 05            [24]  637 	push	ar5
      003DB8 C0 04            [24]  638 	push	ar4
      003DBA 12 3C 3A         [24]  639 	lcall	_page_crc
      003DBD AA 82            [24]  640 	mov	r2, dpl
      003DBF AB 83            [24]  641 	mov	r3, dph
      003DC1 D0 04            [24]  642 	pop	ar4
      003DC3 D0 05            [24]  643 	pop	ar5
      003DC5 D0 06            [24]  644 	pop	ar6
      003DC7 D0 07            [24]  645 	pop	ar7
      003DC9 EA               [12]  646 	mov	a,r2
      003DCA B5 05 06         [24]  647 	cjne	a,ar5,00192$
      003DCD EB               [12]  648 	mov	a,r3
      003DCE B5 04 02         [24]  649 	cjne	a,ar4,00192$
      003DD1 80 06            [24]  650 	sjmp	00113$
      003DD3                        651 00192$:
      003DD3 75 82 02         [24]  652 	mov	dpl, #0x02
      003DD6 02 3B 8C         [24]  653 	ljmp	_nvm_fail
      003DD9                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DD9 EE               [12]  656 	mov	a,r6
      003DDA 54 03            [12]  657 	anl	a,#0x03
      003DDC A2 E0            [12]  658 	mov	c,acc.0
      003DDE CF               [12]  659 	xch	a,r7
      003DDF 13               [12]  660 	rrc	a
      003DE0 CF               [12]  661 	xch	a,r7
      003DE1 13               [12]  662 	rrc	a
      003DE2 A2 E0            [12]  663 	mov	c,acc.0
      003DE4 CF               [12]  664 	xch	a,r7
      003DE5 13               [12]  665 	rrc	a
      003DE6 CF               [12]  666 	xch	a,r7
      003DE7 13               [12]  667 	rrc	a
      003DE8 CF               [12]  668 	xch	a,r7
      003DE9 24 C7            [12]  669 	add	a,#0xc7
      003DEB FE               [12]  670 	mov	r6,a
      003DEC 12 43 7B         [24]  671 	lcall	_ak820_outline_0166
      003DEF 12 3C 6D         [24]  672 	lcall	_write_page
      003DF2 E5 82            [12]  673 	mov	a, dpl
      003DF4 70 06            [24]  674 	jnz	00110$
      003DF6 75 82 03         [24]  675 	mov	dpl, #0x03
      003DF9 02 3B 8C         [24]  676 	ljmp	_nvm_fail
      003DFC                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DFC 90 EF 40         [24]  679 	mov	dptr,#0xef40
      003DFF 12 3A 05         [24]  680 	lcall	_ak820_flash_erase
      003E02 E5 82            [12]  681 	mov	a, dpl
      003E04 70 06            [24]  682 	jnz	00119$
      003E06 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E09 02 3B 8C         [24]  685 	ljmp	_nvm_fail
      003E0C                        686 00119$:
      003E0C 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      003E0D                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      003E0D C2 0B            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E0F 90 05 5F         [24]  700 	mov	dptr,#_first_failure_stage
      003E12 E4               [12]  701 	clr	a
      003E13 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      003E14 C2 0A            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      003E16 C2 09            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E18 90 05 5E         [24]  709 	mov	dptr,#_batch_depth
      003E1B E4               [12]  710 	clr	a
      003E1C F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E1D 12 3D 1D         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E20 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      003E23                        724 _ak820_nvm_ok:
      003E23 A2 0B            [12]  725 	mov	c,_storage_failed
      003E25 B3               [12]  726 	cpl	c
      003E26 92 0C            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E28 12 38 BA         [24]  728 	lcall	_ak820_outline_0159
      003E2B 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      003E2C                        737 _ak820_nvm_schema_fault:
      003E2C 75 82 10         [24]  738 	mov	dpl, #0x10
      003E2F 02 3B 8C         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      003E32                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E32 30 0A 03         [24]  754 	jnb	_page_dirty,00101$
      003E35 30 0B 01         [24]  755 	jnb	_storage_failed,00102$
      003E38                        756 00101$:
      003E38 22               [24]  757 	ret
      003E39                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E39 12 3C 3A         [24]  760 	lcall	_page_crc
      003E3C 12 43 64         [24]  761 	lcall	_ak820_outline_0132
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E3F 90 05 75         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E42 74 A5            [12]  764 	mov	a,#0xa5
      003E44 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E45 90 05 5D         [24]  767 	mov	dptr,#_cached_page
      003E48 E0               [24]  768 	movx	a,@dptr
      003E49 90 05 76         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E4C F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E4D 90 05 77         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E50 E4               [12]  773 	clr	a
      003E51 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E52 8E 05            [24]  776 	mov	ar5,r6
      003E54 90 05 78         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E57 ED               [12]  778 	mov	a,r5
      003E58 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E59 8F 06            [24]  781 	mov	ar6,r7
      003E5B 90 05 79         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E5E EE               [12]  783 	mov	a,r6
      003E5F F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E60 7F 01            [12]  786 	mov	r7,#0x01
      003E62                        787 00128$:
      003E62 8F 06            [24]  788 	mov	ar6,r7
      003E64 EE               [12]  789 	mov	a,r6
      003E65 24 04            [12]  790 	add	a,#0x04
      003E67 FE               [12]  791 	mov	r6,a
      003E68 33               [12]  792 	rlc	a
      003E69 95 E0            [12]  793 	subb	a,acc
      003E6B FD               [12]  794 	mov	r5,a
      003E6C EE               [12]  795 	mov	a,r6
      003E6D 24 75            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      003E6F FE               [12]  797 	mov	r6,a
      003E70 ED               [12]  798 	mov	a,r5
      003E71 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E73 FD               [12]  800 	mov	r5,a
      003E74 12 43 22         [24]  801 	lcall	_ak820_outline_0045
      003E77 FC               [12]  802 	mov	r4,a
      003E78 63 04 FF         [24]  803 	xrl	ar4,#0xff
      003E7B 8E 82            [24]  804 	mov	dpl,r6
      003E7D 8D 83            [24]  805 	mov	dph,r5
      003E7F EC               [12]  806 	mov	a,r4
      003E80 F0               [24]  807 	movx	@dptr,a
      003E81 0F               [12]  808 	inc	r7
      003E82 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E85 90 05 7E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E88 74 05            [12]  812 	mov	a,#0x05
      003E8A F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E8B 90 EF 40         [24]  815 	mov	dptr,#0xef40
      003E8E 12 3A 05         [24]  816 	lcall	_ak820_flash_erase
      003E91 E5 82            [12]  817 	mov	a, dpl
      003E93 70 03            [24]  818 	jnz	00269$
      003E95 02 3F 7B         [24]  819 	ljmp	00127$
      003E98                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E98 90 05 7E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E9B 74 06            [12]  823 	mov	a,#0x06
      003E9D F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E9E 7F 00            [12]  826 	mov	r7,#0x00
      003EA0                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003EA0 12 43 2E         [24]  829 	lcall	_ak820_outline_0056
      003EA3 12 38 F8         [24]  830 	lcall	_ak820_flash_read
      003EA6 E5 82            [12]  831 	mov	a, dpl
      003EA8 60 03            [24]  832 	jz	00270$
      003EAA 02 3F 7B         [24]  833 	ljmp	00127$
      003EAD                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EAD 0F               [12]  836 	inc	r7
      003EAE BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003EB1 90 05 7E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB4 74 07            [12]  840 	mov	a,#0x07
      003EB6 F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EB7 90 EF 00         [24]  843 	mov	dptr,#0xef00
      003EBA 12 3C 6D         [24]  844 	lcall	_write_page
      003EBD E5 82            [12]  845 	mov	a, dpl
      003EBF 70 03            [24]  846 	jnz	00273$
      003EC1 02 3F 7B         [24]  847 	ljmp	00127$
      003EC4                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EC4 90 05 7E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EC7 74 08            [12]  851 	mov	a,#0x08
      003EC9 F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003ECA 7F 01            [12]  854 	mov	r7,#0x01
      003ECC                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003ECC 12 43 22         [24]  857 	lcall	_ak820_outline_0045
      003ECF FE               [12]  858 	mov	r6,a
      003ED0 60 22            [24]  859 	jz	00133$
      003ED2 8F 05            [24]  860 	mov	ar5,r7
      003ED4 7C 00            [12]  861 	mov	r4,#0x00
      003ED6 74 40            [12]  862 	mov	a,#0x40
      003ED8 2D               [12]  863 	add	a, r5
      003ED9 FD               [12]  864 	mov	r5,a
      003EDA 74 EF            [12]  865 	mov	a,#0xef
      003EDC 3C               [12]  866 	addc	a, r4
      003EDD FC               [12]  867 	mov	r4,a
      003EDE 90 04 F6         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      003EE1 EE               [12]  869 	mov	a,r6
      003EE2 F0               [24]  870 	movx	@dptr,a
      003EE3 12 43 90         [24]  871 	lcall	_ak820_outline_0197
      003EE6 C0 07            [24]  872 	push	ar7
      003EE8 12 3A 65         [24]  873 	lcall	_ak820_flash_program
      003EEB E5 82            [12]  874 	mov	a, dpl
      003EED D0 07            [24]  875 	pop	ar7
      003EEF 70 03            [24]  876 	jnz	00275$
      003EF1 02 3F 7B         [24]  877 	ljmp	00127$
      003EF4                        878 00275$:
      003EF4                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EF4 0F               [12]  881 	inc	r7
      003EF5 BF 09 D4         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EF8 90 05 7E         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EFB 74 09            [12]  885 	mov	a,#0x09
      003EFD F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EFE 7F 01            [12]  888 	mov	r7,#0x01
      003F00                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F00 12 43 2E         [24]  891 	lcall	_ak820_outline_0056
      003F03 12 38 F8         [24]  892 	lcall	_ak820_flash_read
      003F06 AE 82            [24]  893 	mov	r6, dpl
      003F08 12 43 22         [24]  894 	lcall	_ak820_outline_0045
      003F0B FD               [12]  895 	mov	r5,a
      003F0C EE               [12]  896 	mov	a,r6
      003F0D B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F10 0F               [12]  899 	inc	r7
      003F11 BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F14 90 05 7E         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F17 74 0A            [12]  903 	mov	a,#0x0a
      003F19 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F1A 90 05 75         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F1D E0               [24]  907 	movx	a,@dptr
      003F1E 90 04 F6         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      003F21 F0               [24]  909 	movx	@dptr,a
      003F22 90 EF 40         [24]  910 	mov	dptr,#0xef40
      003F25 12 3A 65         [24]  911 	lcall	_ak820_flash_program
      003F28 E5 82            [12]  912 	mov	a, dpl
      003F2A 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F2C 90 05 7E         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F2F 74 0B            [12]  916 	mov	a,#0x0b
      003F31 F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F32 90 EF 40         [24]  919 	mov	dptr,#0xef40
      003F35 12 38 F8         [24]  920 	lcall	_ak820_flash_read
      003F38 AF 82            [24]  921 	mov	r7, dpl
      003F3A 90 05 75         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F3D E0               [24]  923 	movx	a,@dptr
      003F3E FE               [12]  924 	mov	r6,a
      003F3F EF               [12]  925 	mov	a,r7
      003F40 B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F43 90 05 7E         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F46 74 0C            [12]  929 	mov	a,#0x0c
      003F48 F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F49 90 05 5D         [24]  932 	mov	dptr,#_cached_page
      003F4C E0               [24]  933 	movx	a,@dptr
      003F4D FE               [12]  934 	mov	r6,a
      003F4E E4               [12]  935 	clr	a
      003F4F C3               [12]  936 	clr	c
      003F50 CE               [12]  937 	xch	a,r6
      003F51 13               [12]  938 	rrc	a
      003F52 CE               [12]  939 	xch	a,r6
      003F53 13               [12]  940 	rrc	a
      003F54 A2 E0            [12]  941 	mov	c,acc.0
      003F56 CE               [12]  942 	xch	a,r6
      003F57 13               [12]  943 	rrc	a
      003F58 CE               [12]  944 	xch	a,r6
      003F59 13               [12]  945 	rrc	a
      003F5A CE               [12]  946 	xch	a,r6
      003F5B 24 C7            [12]  947 	add	a,#0xc7
      003F5D FF               [12]  948 	mov	r7,a
      003F5E 12 38 8A         [24]  949 	lcall	_ak820_outline_0124
      003F61 12 3C 6D         [24]  950 	lcall	_write_page
      003F64 E5 82            [12]  951 	mov	a, dpl
      003F66 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F68 90 05 7E         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F6B 74 0D            [12]  955 	mov	a,#0x0d
      003F6D F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F6E 90 EF 40         [24]  958 	mov	dptr,#0xef40
      003F71 12 3A 05         [24]  959 	lcall	_ak820_flash_erase
      003F74 E5 82            [12]  960 	mov	a, dpl
      003F76 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      003F78 C2 0A            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F7A 22               [24]  967 	ret
      003F7B                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F7B 90 05 7E         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F7E E0               [24]  971 	movx	a,@dptr
      003F7F F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F81 02 3B 8C         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      003F84                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F84 90 05 5E         [24]  984 	mov	dptr,#_batch_depth
      003F87 E0               [24]  985 	movx	a,@dptr
      003F88 FF               [12]  986 	mov	r7,a
      003F89 BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      003F8C 75 82 0F         [24]  988 	mov	dpl, #0x0f
      003F8F 02 3B 8C         [24]  989 	ljmp	_nvm_fail
      003F92                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F92 90 05 5E         [24]  992 	mov	dptr,#_batch_depth
      003F95 EF               [12]  993 	mov	a,r7
      003F96 04               [12]  994 	inc	a
      003F97 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F98 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      003F99                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F99 90 05 5E         [24] 1007 	mov	dptr,#_batch_depth
      003F9C E0               [24] 1008 	movx	a,@dptr
      003F9D FF               [12] 1009 	mov	r7,a
      003F9E E0               [24] 1010 	movx	a,@dptr
      003F9F 60 06            [24] 1011 	jz	00102$
      003FA1 EF               [12] 1012 	mov	a,r7
      003FA2 14               [12] 1013 	dec	a
      003FA3 90 05 5E         [24] 1014 	mov	dptr,#_batch_depth
      003FA6 F0               [24] 1015 	movx	@dptr,a
      003FA7                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003FA7 90 05 5E         [24] 1018 	mov	dptr,#_batch_depth
      003FAA E0               [24] 1019 	movx	a,@dptr
      003FAB 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FAD 02 3E 32         [24] 1022 	ljmp	_ak820_nvm_flush
      003FB0                       1023 00105$:
      003FB0 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      003FB1                       1035 _load_page:
      003FB1 E5 82            [12] 1036 	mov	a,dpl
      003FB3 90 05 7F         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      003FB6 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FB7 30 09 17         [24] 1040 	jnb	_page_valid,00102$
      003FBA 90 05 5D         [24] 1041 	mov	dptr,#_cached_page
      003FBD E0               [24] 1042 	movx	a,@dptr
      003FBE FF               [12] 1043 	mov	r7,a
      003FBF 90 05 7F         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      003FC2 E0               [24] 1045 	movx	a,@dptr
      003FC3 FE               [12] 1046 	mov	r6,a
      003FC4 EF               [12] 1047 	mov	a,r7
      003FC5 B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      003FC8 A2 0B            [12] 1049 	mov	c,_storage_failed
      003FCA B3               [12] 1050 	cpl	c
      003FCB 92 0D            [24] 1051 	mov  _load_page_sloc0_1_0,c
      003FCD 12 38 BA         [24] 1052 	lcall	_ak820_outline_0159
      003FD0 22               [24] 1053 	ret
      003FD1                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FD1 12 3E 32         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FD4 30 0B 04         [24] 1058 	jnb	_storage_failed,00119$
      003FD7 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FDA 22               [24] 1061 	ret
      003FDB                       1062 00119$:
      003FDB 7F 00            [12] 1063 	mov	r7,#0x00
      003FDD                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FDD EF               [12] 1066 	mov	a,r7
      003FDE 24 1D            [12] 1067 	add	a, #_page_data
      003FE0 FD               [12] 1068 	mov	r5,a
      003FE1 E4               [12] 1069 	clr	a
      003FE2 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      003FE4 FE               [12] 1071 	mov	r6,a
      003FE5 90 05 7F         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      003FE8 E0               [24] 1073 	movx	a,@dptr
      003FE9 FC               [12] 1074 	mov	r4,a
      003FEA FA               [12] 1075 	mov	r2,a
      003FEB E4               [12] 1076 	clr	a
      003FEC C3               [12] 1077 	clr	c
      003FED CA               [12] 1078 	xch	a,r2
      003FEE 13               [12] 1079 	rrc	a
      003FEF CA               [12] 1080 	xch	a,r2
      003FF0 13               [12] 1081 	rrc	a
      003FF1 A2 E0            [12] 1082 	mov	c,acc.0
      003FF3 CA               [12] 1083 	xch	a,r2
      003FF4 13               [12] 1084 	rrc	a
      003FF5 CA               [12] 1085 	xch	a,r2
      003FF6 13               [12] 1086 	rrc	a
      003FF7 CA               [12] 1087 	xch	a,r2
      003FF8 24 C7            [12] 1088 	add	a,#0xc7
      003FFA FB               [12] 1089 	mov	r3,a
      003FFB 8F 01            [24] 1090 	mov	ar1,r7
      003FFD 89 00            [24] 1091 	mov	ar0,r1
      003FFF 79 00            [12] 1092 	mov	r1,#0x00
      004001 E8               [12] 1093 	mov	a,r0
      004002 2A               [12] 1094 	add	a, r2
      004003 FA               [12] 1095 	mov	r2,a
      004004 E9               [12] 1096 	mov	a,r1
      004005 3B               [12] 1097 	addc	a, r3
      004006 FB               [12] 1098 	mov	r3,a
      004007 12 38 B5         [24] 1099 	lcall	_ak820_outline_0154
      00400A 12 38 F8         [24] 1100 	lcall	_ak820_flash_read
      00400D AB 82            [24] 1101 	mov	r3, dpl
      00400F 12 38 A5         [24] 1102 	lcall	_ak820_outline_0141
      004012 EB               [12] 1103 	mov	a,r3
      004013 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004014 0F               [12] 1106 	inc	r7
      004015 BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004018 90 05 5D         [24] 1109 	mov	dptr,#_cached_page
      00401B EC               [12] 1110 	mov	a,r4
      00401C F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      00401D D2 09            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00401F 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004022 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004023                       1128 _read_offset:
      004023 12 38 79         [24] 1129 	lcall	_ak820_outline_0113
      004026 90 05 80         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      004029 12 38 7E         [24] 1131 	lcall	_ak820_outline_0114
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00402C 90 05 80         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      00402F 12 38 3E         [24] 1134 	lcall	_ak820_outline_0055
      004032 C3               [12] 1135 	clr	c
      004033 94 28            [12] 1136 	subb	a,#0x28
      004035 40 04            [24] 1137 	jc	00102$
      004037 75 82 00         [24] 1138 	mov	dpl, #0x00
      00403A 22               [24] 1139 	ret
      00403B                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00403B 30 09 34         [24] 1142 	jnb	_page_valid,00104$
      00403E 8E 04            [24] 1143 	mov	ar4,r6
      004040 EF               [12] 1144 	mov	a,r7
      004041 A2 E7            [12] 1145 	mov	c,acc.7
      004043 CC               [12] 1146 	xch	a,r4
      004044 33               [12] 1147 	rlc	a
      004045 CC               [12] 1148 	xch	a,r4
      004046 33               [12] 1149 	rlc	a
      004047 A2 E7            [12] 1150 	mov	c,acc.7
      004049 CC               [12] 1151 	xch	a,r4
      00404A 33               [12] 1152 	rlc	a
      00404B CC               [12] 1153 	xch	a,r4
      00404C 33               [12] 1154 	rlc	a
      00404D CC               [12] 1155 	xch	a,r4
      00404E 54 03            [12] 1156 	anl	a,#0x03
      004050 FD               [12] 1157 	mov	r5,a
      004051 90 05 5D         [24] 1158 	mov	dptr,#_cached_page
      004054 E0               [24] 1159 	movx	a,@dptr
      004055 FA               [12] 1160 	mov	r2,a
      004056 7B 00            [12] 1161 	mov	r3,#0x00
      004058 EC               [12] 1162 	mov	a,r4
      004059 B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      00405C ED               [12] 1164 	mov	a,r5
      00405D B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004060 74 3F            [12] 1167 	mov	a,#0x3f
      004062 5E               [12] 1168 	anl	a,r6
      004063 7D 00            [12] 1169 	mov	r5,#0x00
      004065 24 1D            [12] 1170 	add	a, #_page_data
      004067 F5 82            [12] 1171 	mov	dpl,a
      004069 ED               [12] 1172 	mov	a,r5
      00406A 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      00406C F5 83            [12] 1174 	mov	dph,a
      00406E E0               [24] 1175 	movx	a,@dptr
      00406F F5 82            [12] 1176 	mov	dpl,a
      004071 22               [24] 1177 	ret
      004072                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004072 74 C7            [12] 1180 	mov	a,#0xc7
      004074 2F               [12] 1181 	add	a, r7
      004075 FF               [12] 1182 	mov	r7,a
      004076 12 38 8A         [24] 1183 	lcall	_ak820_outline_0124
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004079 02 38 F8         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      00407C                       1195 _eeprom_read_byte:
      00407C C0 07            [24] 1196 	push	ar7
      00407E C0 06            [24] 1197 	push	ar6
      004080 12 43 1B         [24] 1198 	lcall	_ak820_outline_0038
      004083 90 05 82         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004086 12 38 26         [24] 1200 	lcall	_ak820_outline_0018
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004089 90 05 82         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00408C 12 37 F1         [24] 1203 	lcall	_ak820_outline_0005
      00408F C0 06            [24] 1204 	push	ar6
      004091 C0 05            [24] 1205 	push	ar5
      004093 C0 04            [24] 1206 	push	ar4
      004095 C0 03            [24] 1207 	push	ar3
      004097 C0 02            [24] 1208 	push	ar2
      004099 C0 01            [24] 1209 	push	ar1
      00409B C0 00            [24] 1210 	push	ar0
      00409D 12 40 23         [24] 1211 	lcall	_read_offset
      0040A0 AF 82            [24] 1212 	mov	r7, dpl
      0040A2 D0 00            [24] 1213 	pop	ar0
      0040A4 D0 01            [24] 1214 	pop	ar1
      0040A6 D0 02            [24] 1215 	pop	ar2
      0040A8 D0 03            [24] 1216 	pop	ar3
      0040AA D0 04            [24] 1217 	pop	ar4
      0040AC D0 05            [24] 1218 	pop	ar5
      0040AE D0 06            [24] 1219 	pop	ar6
      0040B0 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040B2 D0 06            [24] 1222 	pop	ar6
      0040B4 D0 07            [24] 1223 	pop	ar7
      0040B6 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      0040B7                       1238 _ak820_eeprom_read_block_xdata:
      0040B7 12 38 79         [24] 1239 	lcall	_ak820_outline_0113
      0040BA 90 05 8A         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040BD 12 38 7E         [24] 1241 	lcall	_ak820_outline_0114
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040C0 90 05 85         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040C3 12 38 3E         [24] 1244 	lcall	_ak820_outline_0055
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040C6 90 05 8A         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040C9 12 38 55         [24] 1247 	lcall	_ak820_outline_0063
      0040CC 90 05 8C         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040CF 12 38 61         [24] 1249 	lcall	_ak820_outline_0078
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040D2 90 05 88         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040D5 12 38 55         [24] 1252 	lcall	_ak820_outline_0063
      0040D8                       1253 00103$:
      0040D8 8C 02            [24] 1254 	mov	ar2,r4
      0040DA 8D 03            [24] 1255 	mov	ar3,r5
      0040DC 1C               [12] 1256 	dec	r4
      0040DD BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      0040E0 1D               [12] 1258 	dec	r5
      0040E1                       1259 00130$:
      0040E1 EA               [12] 1260 	mov	a,r2
      0040E2 4B               [12] 1261 	orl	a,r3
      0040E3 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040E5 8E 02            [24] 1264 	mov	ar2,r6
      0040E7 8F 03            [24] 1265 	mov	ar3,r7
      0040E9 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      0040EB 2B               [12] 1267 	add	a,r3
      0040EC 50 17            [24] 1268 	jnc	00102$
      0040EE 90 05 8C         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F1 12 43 52         [24] 1270 	lcall	_ak820_outline_0108
      0040F4 12 38 B5         [24] 1271 	lcall	_ak820_outline_0154
      0040F7 E4               [12] 1272 	clr	a
      0040F8 F0               [24] 1273 	movx	@dptr,a
      0040F9 90 05 8C         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040FC 04               [12] 1275 	inc	a
      0040FD 2A               [12] 1276 	add	a, r2
      0040FE F0               [24] 1277 	movx	@dptr,a
      0040FF E4               [12] 1278 	clr	a
      004100 3B               [12] 1279 	addc	a, r3
      004101 A3               [24] 1280 	inc	dptr
      004102 F0               [24] 1281 	movx	@dptr,a
      004103 80 D3            [24] 1282 	sjmp	00103$
      004105                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004105 90 05 8C         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004108 12 43 52         [24] 1286 	lcall	_ak820_outline_0108
      00410B 12 38 8A         [24] 1287 	lcall	_ak820_outline_0124
      00410E C0 07            [24] 1288 	push	ar7
      004110 C0 06            [24] 1289 	push	ar6
      004112 C0 05            [24] 1290 	push	ar5
      004114 C0 04            [24] 1291 	push	ar4
      004116 C0 03            [24] 1292 	push	ar3
      004118 C0 02            [24] 1293 	push	ar2
      00411A 12 40 23         [24] 1294 	lcall	_read_offset
      00411D A9 82            [24] 1295 	mov	r1, dpl
      00411F D0 02            [24] 1296 	pop	ar2
      004121 D0 03            [24] 1297 	pop	ar3
      004123 D0 04            [24] 1298 	pop	ar4
      004125 D0 05            [24] 1299 	pop	ar5
      004127 D0 06            [24] 1300 	pop	ar6
      004129 D0 07            [24] 1301 	pop	ar7
      00412B 12 38 B5         [24] 1302 	lcall	_ak820_outline_0154
      00412E E9               [12] 1303 	mov	a,r1
      00412F F0               [24] 1304 	movx	@dptr,a
      004130 90 05 8C         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004133 74 01            [12] 1306 	mov	a,#0x01
      004135 2A               [12] 1307 	add	a, r2
      004136 F0               [24] 1308 	movx	@dptr,a
      004137 E4               [12] 1309 	clr	a
      004138 3B               [12] 1310 	addc	a, r3
      004139 A3               [24] 1311 	inc	dptr
      00413A F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00413B 0E               [12] 1314 	inc	r6
      00413C BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      00413F 0F               [12] 1316 	inc	r7
      004140 80 96            [24] 1317 	sjmp	00103$
      004142                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004142 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      004143                       1336 _ak820_eeprom_write_block_xdata:
      004143 12 38 79         [24] 1337 	lcall	_ak820_outline_0113
      004146 90 05 93         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004149 12 38 7E         [24] 1339 	lcall	_ak820_outline_0114
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00414C 90 05 8E         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00414F 12 38 3E         [24] 1342 	lcall	_ak820_outline_0055
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004152 90 05 93         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004155 12 38 55         [24] 1345 	lcall	_ak820_outline_0063
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004158 8E 02            [24] 1347 	mov	ar2,r6
      00415A 8F 03            [24] 1348 	mov	ar3,r7
      00415C C3               [12] 1349 	clr	c
      00415D E4               [12] 1350 	clr	a
      00415E 9A               [12] 1351 	subb	a,r2
      00415F 74 28            [12] 1352 	mov	a,#0x28
      004161 9B               [12] 1353 	subb	a,r3
      004162 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      004164 E4               [12] 1356 	clr	a
      004165 C3               [12] 1357 	clr	c
      004166 9E               [12] 1358 	subb	a,r6
      004167 FA               [12] 1359 	mov	r2,a
      004168 74 28            [12] 1360 	mov	a,#0x28
      00416A 9F               [12] 1361 	subb	a,r7
      00416B FB               [12] 1362 	mov	r3,a
      00416C 90 05 91         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00416F 12 38 73         [24] 1364 	lcall	_ak820_outline_0107
      004172 C3               [12] 1365 	clr	c
      004173 EA               [12] 1366 	mov	a,r2
      004174 98               [12] 1367 	subb	a,r0
      004175 EB               [12] 1368 	mov	a,r3
      004176 99               [12] 1369 	subb	a,r1
      004177 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      004179                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004179 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00417C 02 3B 8C         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      00417F                       1378 00125$:
      00417F 90 05 91         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004182 12 43 52         [24] 1380 	lcall	_ak820_outline_0108
      004185                       1381 00108$:
      004185 8A 00            [24] 1382 	mov	ar0,r2
      004187 8B 01            [24] 1383 	mov	ar1,r3
      004189 1A               [12] 1384 	dec	r2
      00418A BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      00418D 1B               [12] 1386 	dec	r3
      00418E                       1387 00159$:
      00418E E8               [12] 1388 	mov	a,r0
      00418F 49               [12] 1389 	orl	a,r1
      004190 70 03            [24] 1390 	jnz	00160$
      004192 02 42 1C         [24] 1391 	ljmp	00110$
      004195                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004195 C0 02            [24] 1394 	push	ar2
      004197 C0 03            [24] 1395 	push	ar3
      004199 12 43 4C         [24] 1396 	lcall	_ak820_outline_0100
      00419C F9               [12] 1397 	mov	r1,a
      00419D A3               [24] 1398 	inc	dptr
      00419E 12 38 B0         [24] 1399 	lcall	_ak820_outline_0153
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0041A1 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0041A3 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0041A5 A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041A7 E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041A9 A2 E7            [12] 1405 	mov	c,acc.7
      0041AB C8               [12] 1406 	xch	a,r0
      0041AC 33               [12] 1407 	rlc	a
      0041AD C8               [12] 1408 	xch	a,r0
      0041AE 33               [12] 1409 	rlc	a
      0041AF A2 E7            [12] 1410 	mov	c,acc.7
      0041B1 C8               [12] 1411 	xch	a,r0
      0041B2 33               [12] 1412 	rlc	a
      0041B3 C8               [12] 1413 	xch	a,r0
      0041B4 33               [12] 1414 	rlc	a
      0041B5 C8               [12] 1415 	xch	a,r0
      0041B6 54 03            [12] 1416 	anl	a,#0x03
      0041B8 FB               [12] 1417 	mov	r3,a
      0041B9 88 82            [24] 1418 	mov	dpl, r0
      0041BB C0 07            [24] 1419 	push	ar7
      0041BD C0 06            [24] 1420 	push	ar6
      0041BF C0 05            [24] 1421 	push	ar5
      0041C1 C0 04            [24] 1422 	push	ar4
      0041C3 C0 03            [24] 1423 	push	ar3
      0041C5 C0 02            [24] 1424 	push	ar2
      0041C7 C0 01            [24] 1425 	push	ar1
      0041C9 12 3F B1         [24] 1426 	lcall	_load_page
      0041CC E5 82            [12] 1427 	mov	a, dpl
      0041CE D0 01            [24] 1428 	pop	ar1
      0041D0 D0 02            [24] 1429 	pop	ar2
      0041D2 D0 03            [24] 1430 	pop	ar3
      0041D4 D0 04            [24] 1431 	pop	ar4
      0041D6 D0 05            [24] 1432 	pop	ar5
      0041D8 D0 06            [24] 1433 	pop	ar6
      0041DA D0 07            [24] 1434 	pop	ar7
      0041DC D0 03            [24] 1435 	pop	ar3
      0041DE D0 02            [24] 1436 	pop	ar2
      0041E0 70 01            [24] 1437 	jnz	00105$
      0041E2 22               [24] 1438 	ret
      0041E3                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041E3 C0 06            [24] 1441 	push	ar6
      0041E5 C0 07            [24] 1442 	push	ar7
      0041E7 74 3F            [12] 1443 	mov	a,#0x3f
      0041E9 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041EB 7F 00            [12] 1445 	mov	r7,#0x00
      0041ED 24 1D            [12] 1446 	add	a, #_page_data
      0041EF F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041F1 EF               [12] 1448 	mov	a,r7
      0041F2 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      0041F4 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041F6 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041F9 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041FC E0               [24] 1453 	movx	a,@dptr
      0041FD B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      004200 D0 07            [24] 1455 	pop	ar7
      004202 D0 06            [24] 1456 	pop	ar6
      004204 80 0E            [24] 1457 	sjmp	00107$
      004206                       1458 00162$:
      004206 D0 07            [24] 1459 	pop	ar7
      004208 D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00420A 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00420D 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004210 E9               [12] 1464 	mov	a,r1
      004211 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004212 D2 0A            [12] 1468 	setb	_page_dirty
      004214                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004214 0E               [12] 1471 	inc	r6
      004215 BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      004218 0F               [12] 1473 	inc	r7
      004219                       1474 00163$:
      004219 02 41 85         [24] 1475 	ljmp	00108$
      00421C                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00421C 90 05 5E         [24] 1478 	mov	dptr,#_batch_depth
      00421F E0               [24] 1479 	movx	a,@dptr
      004220 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004222 02 3E 32         [24] 1482 	ljmp	_ak820_nvm_flush
      004225                       1483 00113$:
      004225 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      004226                       1502 _ak820_eeprom_update_block_xdata:
      004226 12 38 79         [24] 1503 	lcall	_ak820_outline_0113
      004229 90 05 9A         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00422C 12 38 7E         [24] 1505 	lcall	_ak820_outline_0114
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00422F 90 05 9A         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004232 12 38 3E         [24] 1508 	lcall	_ak820_outline_0055
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004235 90 05 95         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004238 E0               [24] 1511 	movx	a,@dptr
      004239 F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00423B A3               [24] 1513 	inc	dptr
      00423C E0               [24] 1514 	movx	a,@dptr
      00423D F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00423F A3               [24] 1516 	inc	dptr
      004240 E0               [24] 1517 	movx	a,@dptr
      004241 F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004243 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004245 AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004247 E4               [12] 1522 	clr	a
      004248 F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00424A F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00424C                       1525 00105$:
      00424C 90 05 98         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00424F E0               [24] 1527 	movx	a,@dptr
      004250 F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004252 A3               [24] 1529 	inc	dptr
      004253 E0               [24] 1530 	movx	a,@dptr
      004254 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004256 C3               [12] 1532 	clr	c
      004257 E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004259 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00425B E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00425D 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00425F 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004261 89 00            [24] 1539 	mov	ar0,r1
      004263 8A 05            [24] 1540 	mov	ar5,r2
      004265 E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004267 28               [12] 1542 	add	a, r0
      004268 F8               [12] 1543 	mov	r0,a
      004269 E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00426B 3D               [12] 1545 	addc	a, r5
      00426C FD               [12] 1546 	mov	r5,a
      00426D 88 82            [24] 1547 	mov	dpl, r0
      00426F 8D 83            [24] 1548 	mov	dph, r5
      004271 C0 07            [24] 1549 	push	ar7
      004273 C0 06            [24] 1550 	push	ar6
      004275 C0 02            [24] 1551 	push	ar2
      004277 C0 01            [24] 1552 	push	ar1
      004279 12 40 23         [24] 1553 	lcall	_read_offset
      00427C AD 82            [24] 1554 	mov	r5, dpl
      00427E D0 01            [24] 1555 	pop	ar1
      004280 D0 02            [24] 1556 	pop	ar2
      004282 D0 06            [24] 1557 	pop	ar6
      004284 D0 07            [24] 1558 	pop	ar7
      004286 E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004288 2E               [12] 1560 	add	a, r6
      004289 F5 82            [12] 1561 	mov	dpl,a
      00428B E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00428D 3F               [12] 1563 	addc	a, r7
      00428E F5 83            [12] 1564 	mov	dph,a
      004290 E0               [24] 1565 	movx	a,@dptr
      004291 FC               [12] 1566 	mov	r4,a
      004292 ED               [12] 1567 	mov	a,r5
      004293 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      004296 80 27            [24] 1569 	sjmp	00106$
      004298                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004298 90 05 9A         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00429B E0               [24] 1573 	movx	a,@dptr
      00429C F8               [12] 1574 	mov	r0,a
      00429D A3               [24] 1575 	inc	dptr
      00429E E0               [24] 1576 	movx	a,@dptr
      00429F FD               [12] 1577 	mov	r5,a
      0042A0 90 05 8E         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0042A3 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042A5 F0               [24] 1580 	movx	@dptr,a
      0042A6 E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0042A8 A3               [24] 1582 	inc	dptr
      0042A9 F0               [24] 1583 	movx	@dptr,a
      0042AA E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042AC A3               [24] 1585 	inc	dptr
      0042AD F0               [24] 1586 	movx	@dptr,a
      0042AE 90 05 91         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042B1 E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042B3 F0               [24] 1589 	movx	@dptr,a
      0042B4 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042B6 A3               [24] 1591 	inc	dptr
      0042B7 F0               [24] 1592 	movx	@dptr,a
      0042B8 88 82            [24] 1593 	mov	dpl, r0
      0042BA 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042BC 02 41 43         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      0042BF                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042BF 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042C1 E4               [12] 1600 	clr	a
      0042C2 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042C5 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042C7 80 83            [24] 1603 	sjmp	00105$
      0042C9                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042C9 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      0042CA                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042CA 12 3E 32         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042CD 7F 00            [12] 1621 	mov	r7,#0x00
      0042CF                       1622 00111$:
      0042CF BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      0042D2 22               [24] 1624 	ret
      0042D3                       1625 00165$:
      0042D3 20 0B 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042D6 8F 82            [24] 1628 	mov	dpl, r7
      0042D8 C0 07            [24] 1629 	push	ar7
      0042DA 12 3F B1         [24] 1630 	lcall	_load_page
      0042DD E5 82            [12] 1631 	mov	a, dpl
      0042DF D0 07            [24] 1632 	pop	ar7
      0042E1 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042E3 22               [24] 1635 	ret
      0042E4                       1636 00126$:
      0042E4 7E 00            [12] 1637 	mov	r6,#0x00
      0042E6                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042E6 EE               [12] 1640 	mov	a,r6
      0042E7 24 1D            [12] 1641 	add	a, #_page_data
      0042E9 FC               [12] 1642 	mov	r4,a
      0042EA E4               [12] 1643 	clr	a
      0042EB 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      0042ED FD               [12] 1645 	mov	r5,a
      0042EE 12 43 4C         [24] 1646 	lcall	_ak820_outline_0100
      0042F1 60 07            [24] 1647 	jz	00108$
      0042F3 12 38 A0         [24] 1648 	lcall	_ak820_outline_0133
      0042F6 E4               [12] 1649 	clr	a
      0042F7 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      0042F8 D2 0A            [12] 1652 	setb	_page_dirty
      0042FA                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042FA 0E               [12] 1655 	inc	r6
      0042FB BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042FE C0 07            [24] 1658 	push	ar7
      004300 12 3E 32         [24] 1659 	lcall	_ak820_nvm_flush
      004303 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004305 0F               [12] 1662 	inc	r7
      004306 80 C7            [24] 1663 	sjmp	00111$
      004308                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004308 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0005
                                   1674 	.globl _ak820_outline_0014
                                   1675 	.globl _ak820_outline_0018
                                   1676 	.globl _ak820_outline_0024
                                   1677 	.globl _ak820_outline_0034
                                   1678 	.globl _ak820_outline_0038
                                   1679 	.globl _ak820_outline_0045
                                   1680 	.globl _ak820_outline_0055
                                   1681 	.globl _ak820_outline_0056
                                   1682 	.globl _ak820_outline_0063
                                   1683 	.globl _ak820_outline_0067
                                   1684 	.globl _ak820_outline_0077
                                   1685 	.globl _ak820_outline_0078
                                   1686 	.globl _ak820_outline_0090
                                   1687 	.globl _ak820_outline_0099
                                   1688 	.globl _ak820_outline_0100
                                   1689 	.globl _ak820_outline_0107
                                   1690 	.globl _ak820_outline_0108
                                   1691 	.globl _ak820_outline_0111
                                   1692 	.globl _ak820_outline_0113
                                   1693 	.globl _ak820_outline_0114
                                   1694 	.globl _ak820_outline_0124
                                   1695 	.globl _ak820_outline_0130
                                   1696 	.globl _ak820_outline_0132
                                   1697 	.globl _ak820_outline_0133
                                   1698 	.globl _ak820_outline_0141
                                   1699 	.globl _ak820_outline_0144
                                   1700 	.globl _ak820_outline_0146
                                   1701 	.globl _ak820_outline_0150
                                   1702 	.globl _ak820_outline_0152
                                   1703 	.globl _ak820_outline_0153
                                   1704 	.globl _ak820_outline_0154
                                   1705 	.globl _ak820_outline_0159
                                   1706 	.globl _ak820_outline_0166
                                   1707 	.globl _ak820_outline_0169
                                   1708 	.globl _ak820_outline_0178
                                   1709 	.globl _ak820_outline_0191
                                   1710 	.globl _ak820_outline_0197
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0014
      004309                       1714 _ak820_outline_0014:
      004309 8E 82            [24] 1715 	mov	dpl,r6
      00430B 8F 83            [24] 1716 	mov	dph,r7
      00430D A3               [24] 1717 	inc	dptr
      00430E A3               [24] 1718 	inc	dptr
      00430F A3               [24] 1719 	inc	dptr
      004310 A3               [24] 1720 	inc	dptr
      004311 A3               [24] 1721 	inc	dptr
      004312 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0034
      004313                       1726 _ak820_outline_0034:
      004313 F0               [24] 1727 	movx	@dptr,a
      004314 8E 82            [24] 1728 	mov	dpl,r6
      004316 8F 83            [24] 1729 	mov	dph,r7
      004318 A3               [24] 1730 	inc	dptr
      004319 A3               [24] 1731 	inc	dptr
      00431A 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0038
      00431B                       1736 _ak820_outline_0038:
      00431B AF F0            [24] 1737 	mov	r7,b
      00431D AE 83            [24] 1738 	mov	r6,dph
      00431F E5 82            [12] 1739 	mov	a,dpl
      004321 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0045
      004322                       1744 _ak820_outline_0045:
      004322 EF               [12] 1745 	mov	a,r7
      004323 24 75            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004325 F5 82            [12] 1747 	mov	dpl,a
      004327 E4               [12] 1748 	clr	a
      004328 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00432A F5 83            [12] 1750 	mov	dph,a
      00432C E0               [24] 1751 	movx	a,@dptr
      00432D 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0056
      00432E                       1756 _ak820_outline_0056:
      00432E 8F 06            [24] 1757 	mov	ar6,r7
      004330 7D 00            [12] 1758 	mov	r5,#0x00
      004332 74 40            [12] 1759 	mov	a,#0x40
      004334 2E               [12] 1760 	add	a,r6
      004335 FE               [12] 1761 	mov	r6,a
      004336 74 EF            [12] 1762 	mov	a,#0xef
      004338 3D               [12] 1763 	addc	a,r5
      004339 FD               [12] 1764 	mov	r5,a
      00433A 8E 82            [24] 1765 	mov	dpl,r6
      00433C 8D 83            [24] 1766 	mov	dph,r5
      00433E 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0067
      00433F                       1771 _ak820_outline_0067:
      00433F 8D 82            [24] 1772 	mov	dpl,r5
      004341 8E 83            [24] 1773 	mov	dph,r6
      004343 EC               [12] 1774 	mov	a,r4
      004344 F0               [24] 1775 	movx	@dptr,a
      004345 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0077
      004346                       1780 _ak820_outline_0077:
      004346 F0               [24] 1781 	movx	@dptr,a
      004347 8E 82            [24] 1782 	mov	dpl,r6
      004349 8F 83            [24] 1783 	mov	dph,r7
      00434B 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0100
      00434C                       1788 _ak820_outline_0100:
      00434C 8C 82            [24] 1789 	mov	dpl,r4
      00434E 8D 83            [24] 1790 	mov	dph,r5
      004350 E0               [24] 1791 	movx	a,@dptr
      004351 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0108
      004352                       1796 _ak820_outline_0108:
      004352 E0               [24] 1797 	movx	a,@dptr
      004353 FA               [12] 1798 	mov	r2,a
      004354 A3               [24] 1799 	inc	dptr
      004355 E0               [24] 1800 	movx	a,@dptr
      004356 FB               [12] 1801 	mov	r3,a
      004357 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0111
      004358                       1806 _ak820_outline_0111:
      004358 EF               [12] 1807 	mov	a,r7
      004359 24 1D            [12] 1808 	add	a,#_page_data
      00435B F5 82            [12] 1809 	mov	dpl,a
      00435D E4               [12] 1810 	clr	a
      00435E 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      004360 F5 83            [12] 1812 	mov	dph,a
      004362 E0               [24] 1813 	movx	a,@dptr
      004363 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0132
      004364                       1818 _ak820_outline_0132:
      004364 AE 82            [24] 1819 	mov	r6,dpl
      004366 AF 83            [24] 1820 	mov	r7,dph
      004368 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0144
      004369                       1825 _ak820_outline_0144:
      004369 2E               [12] 1826 	add	a,r6
      00436A FE               [12] 1827 	mov	r6,a
      00436B E4               [12] 1828 	clr	a
      00436C 3F               [12] 1829 	addc	a,r7
      00436D FF               [12] 1830 	mov	r7,a
      00436E 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0146
      00436F                       1835 _ak820_outline_0146:
      00436F ED               [12] 1836 	mov	a,r5
      004370 F0               [24] 1837 	movx	@dptr,a
      004371 EE               [12] 1838 	mov	a,r6
      004372 A3               [24] 1839 	inc	dptr
      004373 F0               [24] 1840 	movx	@dptr,a
      004374 22               [24] 1841 	ret
                                   1842 
                                   1843 	.area CSEG (CODE)
                                   1844 ; function ak820_outline_0152
      004375                       1845 _ak820_outline_0152:
      004375 42 05            [12] 1846 	orl	ar5,a
      004377 EA               [12] 1847 	mov	a,r2
      004378 42 04            [12] 1848 	orl	ar4,a
      00437A 22               [24] 1849 	ret
                                   1850 
                                   1851 	.area CSEG (CODE)
                                   1852 ; function ak820_outline_0166
      00437B                       1853 _ak820_outline_0166:
      00437B 8F 82            [24] 1854 	mov	dpl,r7
      00437D 8E 83            [24] 1855 	mov	dph,r6
      00437F 22               [24] 1856 	ret
                                   1857 
                                   1858 	.area CSEG (CODE)
                                   1859 ; function ak820_outline_0169
      004380                       1860 _ak820_outline_0169:
      004380 2E               [12] 1861 	add	a,r6
      004381 FC               [12] 1862 	mov	r4,a
      004382 E4               [12] 1863 	clr	a
      004383 3F               [12] 1864 	addc	a,r7
      004384 FD               [12] 1865 	mov	r5,a
      004385 22               [24] 1866 	ret
                                   1867 
                                   1868 	.area CSEG (CODE)
                                   1869 ; function ak820_outline_0178
      004386                       1870 _ak820_outline_0178:
      004386 89 82            [24] 1871 	mov	dpl,r1
      004388 8A 83            [24] 1872 	mov	dph,r2
      00438A 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0191
      00438B                       1877 _ak820_outline_0191:
      00438B 8C 82            [24] 1878 	mov	dpl,r4
      00438D 8B 83            [24] 1879 	mov	dph,r3
      00438F 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0197
      004390                       1884 _ak820_outline_0197:
      004390 8D 82            [24] 1885 	mov	dpl,r5
      004392 8C 83            [24] 1886 	mov	dph,r4
      004394 22               [24] 1887 	ret
