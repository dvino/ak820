                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B3F                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B3F E5 82            [12]  215 	mov	a,dpl
      003B41 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B44 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B45 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B48 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B4B E0               [24]  221 	movx	a,@dptr
      003B4C 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B4F F0               [24]  223 	movx	@dptr,a
      003B50                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B50 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B52 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B53                        239 _ak820_nvm_diagnostic:
      003B53 12 38 4E         [24]  240 	lcall	_ak820_outline_0109
      003B56 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B59 12 38 49         [24]  242 	lcall	_ak820_outline_0108
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B5C 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B5F 12 37 FB         [24]  245 	lcall	_ak820_outline_0058
      003B62 A2 09            [12]  246 	mov	c,_storage_failed
      003B64 E4               [12]  247 	clr	a
      003B65 33               [12]  248 	rlc	a
      003B66 12 43 17         [24]  249 	lcall	_ak820_outline_0119
      003B69 12 42 F2         [24]  250 	lcall	_ak820_outline_0066
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B6C A3               [24]  252 	inc	dptr
      003B6D A2 07            [12]  253 	mov	c,_page_valid
      003B6F E4               [12]  254 	clr	a
      003B70 33               [12]  255 	rlc	a
      003B71 12 42 C6         [24]  256 	lcall	_ak820_outline_0037
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B74 A2 08            [12]  258 	mov	c,_page_dirty
      003B76 E4               [12]  259 	clr	a
      003B77 33               [12]  260 	rlc	a
      003B78 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B79 74 03            [12]  263 	mov	a,#0x03
      003B7B 12 43 41         [24]  264 	lcall	_ak820_outline_0164
      003B7E 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B81 E0               [24]  266 	movx	a,@dptr
      003B82 12 43 1C         [24]  267 	lcall	_ak820_outline_0125
                                    268 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B85 74 04            [12]  269 	mov	a,#0x04
      003B87 12 43 41         [24]  270 	lcall	_ak820_outline_0164
      003B8A 90 05 59         [24]  271 	mov	dptr,#_cached_page
      003B8D E0               [24]  272 	movx	a,@dptr
      003B8E 12 43 1C         [24]  273 	lcall	_ak820_outline_0125
                                    274 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003B91 12 42 BC         [24]  275 	lcall	_ak820_outline_0012
      003B94 E4               [12]  276 	clr	a
      003B95 F0               [24]  277 	movx	@dptr,a
                                    278 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003B96 74 06            [12]  279 	mov	a,#0x06
      003B98 2E               [12]  280 	add	a, r6
      003B99 FE               [12]  281 	mov	r6,a
      003B9A E4               [12]  282 	clr	a
      003B9B 3F               [12]  283 	addc	a, r7
      003B9C FF               [12]  284 	mov	r7,a
      003B9D 90 05 5B         [24]  285 	mov	dptr,#_first_failure_stage
      003BA0 E0               [24]  286 	movx	a,@dptr
      003BA1 12 43 17         [24]  287 	lcall	_ak820_outline_0119
      003BA4 F0               [24]  288 	movx	@dptr,a
                                    289 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BA5 22               [24]  290 	ret
                                    291 ;------------------------------------------------------------
                                    292 ;Allocation info for local variables in function 'crc_byte'
                                    293 ;------------------------------------------------------------
                                    294 ;value         Allocated with name '_crc_byte_PARM_2'
                                    295 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    296 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    297 ;------------------------------------------------------------
                                    298 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    299 ;	-----------------------------------------
                                    300 ;	 function crc_byte
                                    301 ;	-----------------------------------------
      003BA6                        302 _crc_byte:
      003BA6 12 38 4E         [24]  303 	lcall	_ak820_outline_0109
      003BA9 90 05 60         [24]  304 	mov	dptr,#_crc_byte_crc_10000_25
      003BAC 12 38 49         [24]  305 	lcall	_ak820_outline_0108
                                    306 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BAF 90 05 5F         [24]  307 	mov	dptr,#_crc_byte_PARM_2
      003BB2 E0               [24]  308 	movx	a,@dptr
      003BB3 FF               [12]  309 	mov	r7,a
      003BB4 7E 00            [12]  310 	mov	r6,#0x00
      003BB6 90 05 60         [24]  311 	mov	dptr,#_crc_byte_crc_10000_25
      003BB9 E0               [24]  312 	movx	a,@dptr
      003BBA 6E               [12]  313 	xrl	a,r6
      003BBB F0               [24]  314 	movx	@dptr,a
      003BBC A3               [24]  315 	inc	dptr
      003BBD E0               [24]  316 	movx	a,@dptr
      003BBE 6F               [12]  317 	xrl	a,r7
      003BBF F0               [24]  318 	movx	@dptr,a
                                    319 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BC0 7F 00            [12]  320 	mov	r7,#0x00
      003BC2                        321 00102$:
                                    322 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BC2 90 05 60         [24]  323 	mov	dptr,#_crc_byte_crc_10000_25
      003BC5 12 38 2A         [24]  324 	lcall	_ak820_outline_0082
      003BC8 30 E7 0E         [24]  325 	jnb	acc.7,00106$
      003BCB ED               [12]  326 	mov	a,r5
      003BCC 2D               [12]  327 	add	a,r5
      003BCD FB               [12]  328 	mov	r3,a
      003BCE EE               [12]  329 	mov	a,r6
      003BCF 33               [12]  330 	rlc	a
      003BD0 FC               [12]  331 	mov	r4,a
      003BD1 63 03 21         [24]  332 	xrl	ar3,#0x21
      003BD4 63 04 10         [24]  333 	xrl	ar4,#0x10
      003BD7 80 06            [24]  334 	sjmp	00107$
      003BD9                        335 00106$:
      003BD9 ED               [12]  336 	mov	a,r5
      003BDA 2D               [12]  337 	add	a,r5
      003BDB FB               [12]  338 	mov	r3,a
      003BDC EE               [12]  339 	mov	a,r6
      003BDD 33               [12]  340 	rlc	a
      003BDE FC               [12]  341 	mov	r4,a
      003BDF                        342 00107$:
      003BDF 90 05 60         [24]  343 	mov	dptr,#_crc_byte_crc_10000_25
      003BE2 12 38 24         [24]  344 	lcall	_ak820_outline_0080
                                    345 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BE5 0F               [12]  346 	inc	r7
      003BE6 BF 08 D9         [24]  347 	cjne	r7,#0x08,00102$
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BE9 12 33 FC         [24]  349 	lcall	_ak820_outline_0123
                                    350 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BEC 22               [24]  351 	ret
                                    352 ;------------------------------------------------------------
                                    353 ;Allocation info for local variables in function 'page_crc'
                                    354 ;------------------------------------------------------------
                                    355 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    356 ;i             Allocated with name '_page_crc_i_10000_30'
                                    357 ;------------------------------------------------------------
                                    358 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    359 ;	-----------------------------------------
                                    360 ;	 function page_crc
                                    361 ;	-----------------------------------------
      003BED                        362 _page_crc:
                                    363 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BED 90 05 62         [24]  364 	mov	dptr,#_page_crc_crc_10000_30
      003BF0 74 FF            [12]  365 	mov	a,#0xff
      003BF2 F0               [24]  366 	movx	@dptr,a
      003BF3 A3               [24]  367 	inc	dptr
      003BF4 F0               [24]  368 	movx	@dptr,a
                                    369 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003BF5 7F 00            [12]  370 	mov	r7,#0x00
      003BF7                        371 00102$:
      003BF7 90 05 62         [24]  372 	mov	dptr,#_page_crc_crc_10000_30
      003BFA 12 38 2A         [24]  373 	lcall	_ak820_outline_0082
      003BFD 12 43 0B         [24]  374 	lcall	_ak820_outline_0106
      003C00 90 05 5F         [24]  375 	mov	dptr,#_crc_byte_PARM_2
      003C03 F0               [24]  376 	movx	@dptr,a
      003C04 12 38 63         [24]  377 	lcall	_ak820_outline_0138
      003C07 C0 07            [24]  378 	push	ar7
      003C09 12 3B A6         [24]  379 	lcall	_crc_byte
      003C0C AD 82            [24]  380 	mov	r5, dpl
      003C0E AE 83            [24]  381 	mov	r6, dph
      003C10 D0 07            [24]  382 	pop	ar7
      003C12 90 05 62         [24]  383 	mov	dptr,#_page_crc_crc_10000_30
      003C15 12 43 47         [24]  384 	lcall	_ak820_outline_0165
      003C18 0F               [12]  385 	inc	r7
      003C19 BF 40 DB         [24]  386 	cjne	r7,#0x40,00102$
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C1C 12 38 63         [24]  388 	lcall	_ak820_outline_0138
                                    389 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C1F 22               [24]  390 	ret
                                    391 ;------------------------------------------------------------
                                    392 ;Allocation info for local variables in function 'write_page'
                                    393 ;------------------------------------------------------------
                                    394 ;address       Allocated with name '_write_page_address_10000_32'
                                    395 ;i             Allocated with name '_write_page_i_10000_33'
                                    396 ;------------------------------------------------------------
                                    397 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    398 ;	-----------------------------------------
                                    399 ;	 function write_page
                                    400 ;	-----------------------------------------
      003C20                        401 _write_page:
      003C20 12 38 4E         [24]  402 	lcall	_ak820_outline_0109
      003C23 90 05 64         [24]  403 	mov	dptr,#_write_page_address_10000_32
      003C26 12 38 49         [24]  404 	lcall	_ak820_outline_0108
                                    405 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C29 90 05 64         [24]  406 	mov	dptr,#_write_page_address_10000_32
      003C2C 12 37 AC         [24]  407 	lcall	_ak820_outline_0006
      003C2F C0 07            [24]  408 	push	ar7
      003C31 C0 06            [24]  409 	push	ar6
      003C33 12 39 B8         [24]  410 	lcall	_ak820_flash_erase
      003C36 E5 82            [12]  411 	mov	a, dpl
      003C38 D0 06            [24]  412 	pop	ar6
      003C3A D0 07            [24]  413 	pop	ar7
      003C3C 70 03            [24]  414 	jnz	00102$
      003C3E F5 82            [12]  415 	mov	dpl,a
      003C40 22               [24]  416 	ret
      003C41                        417 00102$:
                                    418 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C41 90 04 F5         [24]  419 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C44 74 19            [12]  420 	mov	a,#_page_data
      003C46 F0               [24]  421 	movx	@dptr,a
      003C47 74 05            [12]  422 	mov	a,#(_page_data >> 8)
      003C49 A3               [24]  423 	inc	dptr
      003C4A 12 42 F2         [24]  424 	lcall	_ak820_outline_0066
      003C4D 12 3A CC         [24]  425 	lcall	_ak820_flash_program_page
      003C50 E5 82            [12]  426 	mov	a, dpl
      003C52 70 03            [24]  427 	jnz	00120$
      003C54 F5 82            [12]  428 	mov	dpl,a
                                    429 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C56 22               [24]  430 	ret
      003C57                        431 00120$:
      003C57 7F 00            [12]  432 	mov	r7,#0x00
      003C59                        433 00108$:
                                    434 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C59 8F 05            [24]  435 	mov	ar5,r7
      003C5B 7E 00            [12]  436 	mov	r6,#0x00
      003C5D 90 05 64         [24]  437 	mov	dptr,#_write_page_address_10000_32
      003C60 12 38 43         [24]  438 	lcall	_ak820_outline_0103
      003C63 ED               [12]  439 	mov	a,r5
      003C64 2B               [12]  440 	add	a, r3
      003C65 FB               [12]  441 	mov	r3,a
      003C66 EE               [12]  442 	mov	a,r6
      003C67 3C               [12]  443 	addc	a, r4
      003C68 FC               [12]  444 	mov	r4,a
      003C69 12 33 FC         [24]  445 	lcall	_ak820_outline_0123
      003C6C 12 38 AB         [24]  446 	lcall	_ak820_flash_read
      003C6F AE 82            [24]  447 	mov	r6, dpl
      003C71 12 43 0B         [24]  448 	lcall	_ak820_outline_0106
      003C74 FD               [12]  449 	mov	r5,a
      003C75 EE               [12]  450 	mov	a,r6
      003C76 B5 05 02         [24]  451 	cjne	a,ar5,00149$
      003C79 80 04            [24]  452 	sjmp	00109$
      003C7B                        453 00149$:
      003C7B 75 82 00         [24]  454 	mov	dpl, #0x00
      003C7E 22               [24]  455 	ret
      003C7F                        456 00109$:
                                    457 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C7F 0F               [12]  458 	inc	r7
      003C80 BF 40 D6         [24]  459 	cjne	r7,#0x40,00108$
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C83 75 82 01         [24]  461 	mov	dpl, #0x01
                                    462 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C86 22               [24]  463 	ret
                                    464 ;------------------------------------------------------------
                                    465 ;Allocation info for local variables in function 'journal_header_valid'
                                    466 ;------------------------------------------------------------
                                    467 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    468 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    469 ;------------------------------------------------------------
                                    470 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    471 ;	-----------------------------------------
                                    472 ;	 function journal_header_valid
                                    473 ;	-----------------------------------------
      003C87                        474 _journal_header_valid:
      003C87 12 38 4E         [24]  475 	lcall	_ak820_outline_0109
      003C8A 90 05 66         [24]  476 	mov	dptr,#_journal_header_valid_header_10000_39
      003C8D 12 38 49         [24]  477 	lcall	_ak820_outline_0108
                                    478 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C90 90 05 66         [24]  479 	mov	dptr,#_journal_header_valid_header_10000_39
      003C93 12 37 AC         [24]  480 	lcall	_ak820_outline_0006
      003C96 E0               [24]  481 	movx	a,@dptr
      003C97 FD               [12]  482 	mov	r5,a
      003C98 BD A5 02         [24]  483 	cjne	r5,#0xa5,00138$
      003C9B 80 04            [24]  484 	sjmp	00116$
      003C9D                        485 00138$:
      003C9D 75 82 00         [24]  486 	mov	dpl, #0x00
                                    487 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CA0 22               [24]  488 	ret
      003CA1                        489 00116$:
      003CA1 7D 01            [12]  490 	mov	r5,#0x01
      003CA3                        491 00106$:
                                    492 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CA3 ED               [12]  493 	mov	a,r5
      003CA4 12 37 DA         [24]  494 	lcall	_ak820_outline_0018
      003CA7 FC               [12]  495 	mov	r4,a
      003CA8 8D 02            [24]  496 	mov	ar2,r5
      003CAA 7B 00            [12]  497 	mov	r3,#0x00
      003CAC 74 04            [12]  498 	mov	a,#0x04
      003CAE 2A               [12]  499 	add	a, r2
      003CAF FA               [12]  500 	mov	r2,a
      003CB0 E4               [12]  501 	clr	a
      003CB1 3B               [12]  502 	addc	a, r3
      003CB2 FB               [12]  503 	mov	r3,a
      003CB3 EA               [12]  504 	mov	a,r2
      003CB4 2E               [12]  505 	add	a, r6
      003CB5 F5 82            [12]  506 	mov	dpl,a
      003CB7 EB               [12]  507 	mov	a,r3
      003CB8 3F               [12]  508 	addc	a, r7
      003CB9 F5 83            [12]  509 	mov	dph,a
      003CBB E0               [24]  510 	movx	a,@dptr
      003CBC 62 04            [12]  511 	xrl	ar4,a
      003CBE BC FF 02         [24]  512 	cjne	r4,#0xff,00139$
      003CC1 80 04            [24]  513 	sjmp	00107$
      003CC3                        514 00139$:
      003CC3 75 82 00         [24]  515 	mov	dpl, #0x00
      003CC6 22               [24]  516 	ret
      003CC7                        517 00107$:
                                    518 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CC7 0D               [12]  519 	inc	r5
      003CC8 BD 05 D8         [24]  520 	cjne	r5,#0x05,00106$
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CCB 75 82 01         [24]  522 	mov	dpl, #0x01
                                    523 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CCE 22               [24]  524 	ret
                                    525 ;------------------------------------------------------------
                                    526 ;Allocation info for local variables in function 'recover_journal'
                                    527 ;------------------------------------------------------------
                                    528 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    529 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    530 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    531 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    532 ;------------------------------------------------------------
                                    533 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    534 ;	-----------------------------------------
                                    535 ;	 function recover_journal
                                    536 ;	-----------------------------------------
      003CCF                        537 _recover_journal:
                                    538 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CCF 7F 00            [12]  539 	mov	r7,#0x00
      003CD1                        540 00115$:
      003CD1 EF               [12]  541 	mov	a,r7
      003CD2 24 68            [12]  542 	add	a, #_recover_journal_header_10000_46
      003CD4 FD               [12]  543 	mov	r5,a
      003CD5 E4               [12]  544 	clr	a
      003CD6 34 05            [12]  545 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CD8 FE               [12]  546 	mov	r6,a
      003CD9 8F 04            [24]  547 	mov	ar4,r7
      003CDB 7B 00            [12]  548 	mov	r3,#0x00
      003CDD 74 40            [12]  549 	mov	a,#0x40
      003CDF 2C               [12]  550 	add	a, r4
      003CE0 FC               [12]  551 	mov	r4,a
      003CE1 74 EF            [12]  552 	mov	a,#0xef
      003CE3 3B               [12]  553 	addc	a, r3
      003CE4 FB               [12]  554 	mov	r3,a
      003CE5 12 43 4D         [24]  555 	lcall	_ak820_outline_0185
      003CE8 12 38 AB         [24]  556 	lcall	_ak820_flash_read
      003CEB AC 82            [24]  557 	mov	r4, dpl
      003CED 12 42 F8         [24]  558 	lcall	_ak820_outline_0069
      003CF0 0F               [12]  559 	inc	r7
      003CF1 BF 09 DD         [24]  560 	cjne	r7,#0x09,00115$
                                    561 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003CF4 90 05 68         [24]  562 	mov	dptr,#_recover_journal_header_10000_46
      003CF7 12 3C 87         [24]  563 	lcall	_journal_header_valid
      003CFA E5 82            [12]  564 	mov	a, dpl
      003CFC 70 01            [24]  565 	jnz	00103$
      003CFE 22               [24]  566 	ret
      003CFF                        567 00103$:
                                    568 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003CFF 90 05 69         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D02 E0               [24]  570 	movx	a,@dptr
      003D03 FF               [12]  571 	mov	r7,a
      003D04 7E 00            [12]  572 	mov	r6,#0x00
      003D06 90 05 6A         [24]  573 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D09 E0               [24]  574 	movx	a,@dptr
      003D0A FC               [12]  575 	mov	r4,a
      003D0B E4               [12]  576 	clr	a
      003D0C 42 07            [12]  577 	orl	ar7,a
      003D0E EC               [12]  578 	mov	a,r4
      003D0F 42 06            [12]  579 	orl	ar6,a
                                    580 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D11 90 05 6B         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D14 E0               [24]  582 	movx	a,@dptr
      003D15 FD               [12]  583 	mov	r5,a
      003D16 7C 00            [12]  584 	mov	r4,#0x00
      003D18 90 05 6C         [24]  585 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D1B E0               [24]  586 	movx	a,@dptr
      003D1C FA               [12]  587 	mov	r2,a
      003D1D E4               [12]  588 	clr	a
      003D1E 12 43 2C         [24]  589 	lcall	_ak820_outline_0143
                                    590 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D21 C3               [12]  591 	clr	c
      003D22 EF               [12]  592 	mov	a,r7
      003D23 94 A0            [12]  593 	subb	a,#0xa0
      003D25 EE               [12]  594 	mov	a,r6
      003D26 94 00            [12]  595 	subb	a,#0x00
      003D28 40 06            [24]  596 	jc	00134$
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D2A 75 82 01         [24]  598 	mov	dpl, #0x01
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D2D 02 3B 3F         [24]  600 	ljmp	_nvm_fail
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D30                        602 00134$:
      003D30 7B 00            [12]  603 	mov	r3,#0x00
      003D32                        604 00117$:
      003D32 C0 05            [24]  605 	push	ar5
      003D34 C0 04            [24]  606 	push	ar4
      003D36 EB               [12]  607 	mov	a,r3
      003D37 24 19            [12]  608 	add	a, #_page_data
      003D39 F9               [12]  609 	mov	r1,a
      003D3A E4               [12]  610 	clr	a
      003D3B 34 05            [12]  611 	addc	a, #(_page_data >> 8)
      003D3D FA               [12]  612 	mov	r2,a
      003D3E 8B 00            [24]  613 	mov	ar0,r3
      003D40 7D 00            [12]  614 	mov	r5,#0x00
      003D42 74 EF            [12]  615 	mov	a,#0xef
      003D44 2D               [12]  616 	add	a, r5
      003D45 FD               [12]  617 	mov	r5,a
      003D46 88 82            [24]  618 	mov	dpl, r0
      003D48 8D 83            [24]  619 	mov	dph, r5
      003D4A 12 38 AB         [24]  620 	lcall	_ak820_flash_read
      003D4D AD 82            [24]  621 	mov	r5, dpl
      003D4F 12 43 32         [24]  622 	lcall	_ak820_outline_0151
      003D52 ED               [12]  623 	mov	a,r5
      003D53 F0               [24]  624 	movx	@dptr,a
      003D54 0B               [12]  625 	inc	r3
      003D55 BB 40 02         [24]  626 	cjne	r3,#0x40,00190$
      003D58 80 06            [24]  627 	sjmp	00191$
      003D5A                        628 00190$:
      003D5A D0 04            [24]  629 	pop	ar4
      003D5C D0 05            [24]  630 	pop	ar5
      003D5E 80 D2            [24]  631 	sjmp	00117$
      003D60                        632 00191$:
      003D60 D0 04            [24]  633 	pop	ar4
      003D62 D0 05            [24]  634 	pop	ar5
                                    635 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D64 C0 07            [24]  636 	push	ar7
      003D66 C0 06            [24]  637 	push	ar6
      003D68 C0 05            [24]  638 	push	ar5
      003D6A C0 04            [24]  639 	push	ar4
      003D6C 12 3B ED         [24]  640 	lcall	_page_crc
      003D6F AA 82            [24]  641 	mov	r2, dpl
      003D71 AB 83            [24]  642 	mov	r3, dph
      003D73 D0 04            [24]  643 	pop	ar4
      003D75 D0 05            [24]  644 	pop	ar5
      003D77 D0 06            [24]  645 	pop	ar6
      003D79 D0 07            [24]  646 	pop	ar7
      003D7B EA               [12]  647 	mov	a,r2
      003D7C B5 05 06         [24]  648 	cjne	a,ar5,00192$
      003D7F EB               [12]  649 	mov	a,r3
      003D80 B5 04 02         [24]  650 	cjne	a,ar4,00192$
      003D83 80 06            [24]  651 	sjmp	00113$
      003D85                        652 00192$:
      003D85 75 82 02         [24]  653 	mov	dpl, #0x02
      003D88 02 3B 3F         [24]  654 	ljmp	_nvm_fail
      003D8B                        655 00113$:
                                    656 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D8B EE               [12]  657 	mov	a,r6
      003D8C 54 03            [12]  658 	anl	a,#0x03
      003D8E A2 E0            [12]  659 	mov	c,acc.0
      003D90 CF               [12]  660 	xch	a,r7
      003D91 13               [12]  661 	rrc	a
      003D92 CF               [12]  662 	xch	a,r7
      003D93 13               [12]  663 	rrc	a
      003D94 A2 E0            [12]  664 	mov	c,acc.0
      003D96 CF               [12]  665 	xch	a,r7
      003D97 13               [12]  666 	rrc	a
      003D98 CF               [12]  667 	xch	a,r7
      003D99 13               [12]  668 	rrc	a
      003D9A CF               [12]  669 	xch	a,r7
      003D9B 24 C7            [12]  670 	add	a,#0xc7
      003D9D FE               [12]  671 	mov	r6,a
      003D9E 12 43 3C         [24]  672 	lcall	_ak820_outline_0160
      003DA1 12 3C 20         [24]  673 	lcall	_write_page
      003DA4 E5 82            [12]  674 	mov	a, dpl
      003DA6 70 06            [24]  675 	jnz	00110$
      003DA8 75 82 03         [24]  676 	mov	dpl, #0x03
      003DAB 02 3B 3F         [24]  677 	ljmp	_nvm_fail
      003DAE                        678 00110$:
                                    679 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DAE 90 EF 40         [24]  680 	mov	dptr,#0xef40
      003DB1 12 39 B8         [24]  681 	lcall	_ak820_flash_erase
      003DB4 E5 82            [12]  682 	mov	a, dpl
      003DB6 70 06            [24]  683 	jnz	00119$
      003DB8 75 82 04         [24]  684 	mov	dpl, #0x04
                                    685 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DBB 02 3B 3F         [24]  686 	ljmp	_nvm_fail
      003DBE                        687 00119$:
      003DBE 22               [24]  688 	ret
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    691 ;------------------------------------------------------------
                                    692 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function eeprom_driver_init
                                    695 ;	-----------------------------------------
      003DBF                        696 _eeprom_driver_init:
                                    697 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    698 ;	assignBit
      003DBF C2 09            [12]  699 	clr	_storage_failed
                                    700 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DC1 90 05 5B         [24]  701 	mov	dptr,#_first_failure_stage
      003DC4 E4               [12]  702 	clr	a
      003DC5 F0               [24]  703 	movx	@dptr,a
                                    704 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    705 ;	assignBit
      003DC6 C2 08            [12]  706 	clr	_page_dirty
                                    707 ;	assignBit
      003DC8 C2 07            [12]  708 	clr	_page_valid
                                    709 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DCA 90 05 5A         [24]  710 	mov	dptr,#_batch_depth
      003DCD E4               [12]  711 	clr	a
      003DCE F0               [24]  712 	movx	@dptr,a
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DCF 12 3C CF         [24]  714 	lcall	_recover_journal
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DD2 02 2A B7         [24]  717 	ljmp	_ak820_macro_init
                                    718 ;------------------------------------------------------------
                                    719 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    720 ;------------------------------------------------------------
                                    721 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    722 ;	-----------------------------------------
                                    723 ;	 function ak820_nvm_ok
                                    724 ;	-----------------------------------------
      003DD5                        725 _ak820_nvm_ok:
      003DD5 A2 09            [12]  726 	mov	c,_storage_failed
      003DD7 B3               [12]  727 	cpl	c
      003DD8 92 0A            [24]  728 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DDA 12 38 68         [24]  729 	lcall	_ak820_outline_0150
      003DDD 22               [24]  730 	ret
                                    731 ;------------------------------------------------------------
                                    732 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    733 ;------------------------------------------------------------
                                    734 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    735 ;	-----------------------------------------
                                    736 ;	 function ak820_nvm_schema_fault
                                    737 ;	-----------------------------------------
      003DDE                        738 _ak820_nvm_schema_fault:
      003DDE 75 82 10         [24]  739 	mov	dpl, #0x10
      003DE1 02 3B 3F         [24]  740 	ljmp	_nvm_fail
                                    741 ;------------------------------------------------------------
                                    742 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    743 ;------------------------------------------------------------
                                    744 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    745 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    746 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    747 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    748 ;------------------------------------------------------------
                                    749 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    750 ;	-----------------------------------------
                                    751 ;	 function ak820_nvm_flush
                                    752 ;	-----------------------------------------
      003DE4                        753 _ak820_nvm_flush:
                                    754 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DE4 30 08 03         [24]  755 	jnb	_page_dirty,00101$
      003DE7 30 09 01         [24]  756 	jnb	_storage_failed,00102$
      003DEA                        757 00101$:
      003DEA 22               [24]  758 	ret
      003DEB                        759 00102$:
                                    760 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DEB 12 3B ED         [24]  761 	lcall	_page_crc
      003DEE 12 43 27         [24]  762 	lcall	_ak820_outline_0137
                                    763 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003DF1 90 05 71         [24]  764 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003DF4 74 A5            [12]  765 	mov	a,#0xa5
      003DF6 F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003DF7 90 05 59         [24]  768 	mov	dptr,#_cached_page
      003DFA E0               [24]  769 	movx	a,@dptr
      003DFB 90 05 72         [24]  770 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003DFE F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003DFF 90 05 73         [24]  773 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E02 E4               [12]  774 	clr	a
      003E03 F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E04 8E 05            [24]  777 	mov	ar5,r6
      003E06 90 05 74         [24]  778 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E09 ED               [12]  779 	mov	a,r5
      003E0A F0               [24]  780 	movx	@dptr,a
                                    781 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E0B 8F 06            [24]  782 	mov	ar6,r7
      003E0D 90 05 75         [24]  783 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E10 EE               [12]  784 	mov	a,r6
      003E11 F0               [24]  785 	movx	@dptr,a
                                    786 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E12 7F 01            [12]  787 	mov	r7,#0x01
      003E14                        788 00128$:
      003E14 8F 06            [24]  789 	mov	ar6,r7
      003E16 EE               [12]  790 	mov	a,r6
      003E17 24 04            [12]  791 	add	a,#0x04
      003E19 FE               [12]  792 	mov	r6,a
      003E1A 33               [12]  793 	rlc	a
      003E1B 95 E0            [12]  794 	subb	a,acc
      003E1D FD               [12]  795 	mov	r5,a
      003E1E EE               [12]  796 	mov	a,r6
      003E1F 24 71            [12]  797 	add	a, #_ak820_nvm_flush_header_10000_62
      003E21 FE               [12]  798 	mov	r6,a
      003E22 ED               [12]  799 	mov	a,r5
      003E23 34 05            [12]  800 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E25 FD               [12]  801 	mov	r5,a
      003E26 12 42 D5         [24]  802 	lcall	_ak820_outline_0046
      003E29 FC               [12]  803 	mov	r4,a
      003E2A 63 04 FF         [24]  804 	xrl	ar4,#0xff
      003E2D 8E 82            [24]  805 	mov	dpl,r6
      003E2F 8D 83            [24]  806 	mov	dph,r5
      003E31 EC               [12]  807 	mov	a,r4
      003E32 F0               [24]  808 	movx	@dptr,a
      003E33 0F               [12]  809 	inc	r7
      003E34 BF 05 DD         [24]  810 	cjne	r7,#0x05,00128$
                                    811 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E37 90 05 7A         [24]  812 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E3A 74 05            [12]  813 	mov	a,#0x05
      003E3C F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E3D 90 EF 40         [24]  816 	mov	dptr,#0xef40
      003E40 12 39 B8         [24]  817 	lcall	_ak820_flash_erase
      003E43 E5 82            [12]  818 	mov	a, dpl
      003E45 70 03            [24]  819 	jnz	00269$
      003E47 02 3F 2E         [24]  820 	ljmp	00127$
      003E4A                        821 00269$:
                                    822 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E4A 90 05 7A         [24]  823 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E4D 74 06            [12]  824 	mov	a,#0x06
      003E4F F0               [24]  825 	movx	@dptr,a
                                    826 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E50 7F 00            [12]  827 	mov	r7,#0x00
      003E52                        828 00130$:
                                    829 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E52 12 42 E1         [24]  830 	lcall	_ak820_outline_0059
      003E55 12 38 AB         [24]  831 	lcall	_ak820_flash_read
      003E58 E5 82            [12]  832 	mov	a, dpl
      003E5A 60 03            [24]  833 	jz	00270$
      003E5C 02 3F 2E         [24]  834 	ljmp	00127$
      003E5F                        835 00270$:
                                    836 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E5F 0F               [12]  837 	inc	r7
      003E60 BF 40 EF         [24]  838 	cjne	r7,#0x40,00130$
                                    839 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E63 90 05 7A         [24]  840 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E66 74 07            [12]  841 	mov	a,#0x07
      003E68 F0               [24]  842 	movx	@dptr,a
                                    843 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E69 90 EF 00         [24]  844 	mov	dptr,#0xef00
      003E6C 12 3C 20         [24]  845 	lcall	_write_page
      003E6F E5 82            [12]  846 	mov	a, dpl
      003E71 70 03            [24]  847 	jnz	00273$
      003E73 02 3F 2E         [24]  848 	ljmp	00127$
      003E76                        849 00273$:
                                    850 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E76 90 05 7A         [24]  851 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E79 74 08            [12]  852 	mov	a,#0x08
      003E7B F0               [24]  853 	movx	@dptr,a
                                    854 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E7C 7F 01            [12]  855 	mov	r7,#0x01
      003E7E                        856 00132$:
                                    857 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E7E 12 42 D5         [24]  858 	lcall	_ak820_outline_0046
      003E81 FE               [12]  859 	mov	r6,a
      003E82 60 23            [24]  860 	jz	00133$
      003E84 8F 05            [24]  861 	mov	ar5,r7
      003E86 7C 00            [12]  862 	mov	r4,#0x00
      003E88 74 40            [12]  863 	mov	a,#0x40
      003E8A 2D               [12]  864 	add	a, r5
      003E8B FD               [12]  865 	mov	r5,a
      003E8C 74 EF            [12]  866 	mov	a,#0xef
      003E8E 3C               [12]  867 	addc	a, r4
      003E8F FC               [12]  868 	mov	r4,a
      003E90 90 04 F2         [24]  869 	mov	dptr,#_ak820_flash_program_PARM_2
      003E93 EE               [12]  870 	mov	a,r6
      003E94 F0               [24]  871 	movx	@dptr,a
      003E95 8D 82            [24]  872 	mov	dpl, r5
      003E97 8C 83            [24]  873 	mov	dph, r4
      003E99 C0 07            [24]  874 	push	ar7
      003E9B 12 3A 18         [24]  875 	lcall	_ak820_flash_program
      003E9E E5 82            [12]  876 	mov	a, dpl
      003EA0 D0 07            [24]  877 	pop	ar7
      003EA2 70 03            [24]  878 	jnz	00275$
      003EA4 02 3F 2E         [24]  879 	ljmp	00127$
      003EA7                        880 00275$:
      003EA7                        881 00133$:
                                    882 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EA7 0F               [12]  883 	inc	r7
      003EA8 BF 09 D3         [24]  884 	cjne	r7,#0x09,00132$
                                    885 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EAB 90 05 7A         [24]  886 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EAE 74 09            [12]  887 	mov	a,#0x09
      003EB0 F0               [24]  888 	movx	@dptr,a
                                    889 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EB1 7F 01            [12]  890 	mov	r7,#0x01
      003EB3                        891 00134$:
                                    892 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EB3 12 42 E1         [24]  893 	lcall	_ak820_outline_0059
      003EB6 12 38 AB         [24]  894 	lcall	_ak820_flash_read
      003EB9 AE 82            [24]  895 	mov	r6, dpl
      003EBB 12 42 D5         [24]  896 	lcall	_ak820_outline_0046
      003EBE FD               [12]  897 	mov	r5,a
      003EBF EE               [12]  898 	mov	a,r6
      003EC0 B5 05 6B         [24]  899 	cjne	a,ar5,00127$
                                    900 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EC3 0F               [12]  901 	inc	r7
      003EC4 BF 09 EC         [24]  902 	cjne	r7,#0x09,00134$
                                    903 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003EC7 90 05 7A         [24]  904 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ECA 74 0A            [12]  905 	mov	a,#0x0a
      003ECC F0               [24]  906 	movx	@dptr,a
                                    907 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003ECD 90 05 71         [24]  908 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003ED0 E0               [24]  909 	movx	a,@dptr
      003ED1 90 04 F2         [24]  910 	mov	dptr,#_ak820_flash_program_PARM_2
      003ED4 F0               [24]  911 	movx	@dptr,a
      003ED5 90 EF 40         [24]  912 	mov	dptr,#0xef40
      003ED8 12 3A 18         [24]  913 	lcall	_ak820_flash_program
      003EDB E5 82            [12]  914 	mov	a, dpl
      003EDD 60 4F            [24]  915 	jz	00127$
                                    916 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EDF 90 05 7A         [24]  917 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE2 74 0B            [12]  918 	mov	a,#0x0b
      003EE4 F0               [24]  919 	movx	@dptr,a
                                    920 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EE5 90 EF 40         [24]  921 	mov	dptr,#0xef40
      003EE8 12 38 AB         [24]  922 	lcall	_ak820_flash_read
      003EEB AF 82            [24]  923 	mov	r7, dpl
      003EED 90 05 71         [24]  924 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EF0 E0               [24]  925 	movx	a,@dptr
      003EF1 FE               [12]  926 	mov	r6,a
      003EF2 EF               [12]  927 	mov	a,r7
      003EF3 B5 06 38         [24]  928 	cjne	a,ar6,00127$
                                    929 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003EF6 90 05 7A         [24]  930 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF9 74 0C            [12]  931 	mov	a,#0x0c
      003EFB F0               [24]  932 	movx	@dptr,a
                                    933 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003EFC 90 05 59         [24]  934 	mov	dptr,#_cached_page
      003EFF E0               [24]  935 	movx	a,@dptr
      003F00 FE               [12]  936 	mov	r6,a
      003F01 E4               [12]  937 	clr	a
      003F02 C3               [12]  938 	clr	c
      003F03 CE               [12]  939 	xch	a,r6
      003F04 13               [12]  940 	rrc	a
      003F05 CE               [12]  941 	xch	a,r6
      003F06 13               [12]  942 	rrc	a
      003F07 A2 E0            [12]  943 	mov	c,acc.0
      003F09 CE               [12]  944 	xch	a,r6
      003F0A 13               [12]  945 	rrc	a
      003F0B CE               [12]  946 	xch	a,r6
      003F0C 13               [12]  947 	rrc	a
      003F0D CE               [12]  948 	xch	a,r6
      003F0E 24 C7            [12]  949 	add	a,#0xc7
      003F10 FF               [12]  950 	mov	r7,a
      003F11 12 43 17         [24]  951 	lcall	_ak820_outline_0119
      003F14 12 3C 20         [24]  952 	lcall	_write_page
      003F17 E5 82            [12]  953 	mov	a, dpl
      003F19 60 13            [24]  954 	jz	00127$
                                    955 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F1B 90 05 7A         [24]  956 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F1E 74 0D            [12]  957 	mov	a,#0x0d
      003F20 F0               [24]  958 	movx	@dptr,a
                                    959 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F21 90 EF 40         [24]  960 	mov	dptr,#0xef40
      003F24 12 39 B8         [24]  961 	lcall	_ak820_flash_erase
      003F27 E5 82            [12]  962 	mov	a, dpl
      003F29 60 03            [24]  963 	jz	00127$
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    965 ;	assignBit
      003F2B C2 08            [12]  966 	clr	_page_dirty
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F2D 22               [24]  969 	ret
      003F2E                        970 00127$:
                                    971 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F2E 90 05 7A         [24]  972 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F31 E0               [24]  973 	movx	a,@dptr
      003F32 F5 82            [12]  974 	mov	dpl,a
                                    975 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F34 02 3B 3F         [24]  976 	ljmp	_nvm_fail
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    979 ;------------------------------------------------------------
                                    980 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    981 ;	-----------------------------------------
                                    982 ;	 function ak820_nvm_begin
                                    983 ;	-----------------------------------------
      003F37                        984 _ak820_nvm_begin:
                                    985 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F37 90 05 5A         [24]  986 	mov	dptr,#_batch_depth
      003F3A E0               [24]  987 	movx	a,@dptr
      003F3B FF               [12]  988 	mov	r7,a
      003F3C BF FF 06         [24]  989 	cjne	r7,#0xff,00102$
      003F3F 75 82 0F         [24]  990 	mov	dpl, #0x0f
      003F42 02 3B 3F         [24]  991 	ljmp	_nvm_fail
      003F45                        992 00102$:
                                    993 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F45 90 05 5A         [24]  994 	mov	dptr,#_batch_depth
      003F48 EF               [12]  995 	mov	a,r7
      003F49 04               [12]  996 	inc	a
      003F4A F0               [24]  997 	movx	@dptr,a
                                    998 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F4B 22               [24]  999 	ret
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1002 ;------------------------------------------------------------
                                   1003 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1004 ;	-----------------------------------------
                                   1005 ;	 function ak820_nvm_end
                                   1006 ;	-----------------------------------------
      003F4C                       1007 _ak820_nvm_end:
                                   1008 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F4C 90 05 5A         [24] 1009 	mov	dptr,#_batch_depth
      003F4F E0               [24] 1010 	movx	a,@dptr
      003F50 FF               [12] 1011 	mov	r7,a
      003F51 E0               [24] 1012 	movx	a,@dptr
      003F52 60 06            [24] 1013 	jz	00102$
      003F54 EF               [12] 1014 	mov	a,r7
      003F55 14               [12] 1015 	dec	a
      003F56 90 05 5A         [24] 1016 	mov	dptr,#_batch_depth
      003F59 F0               [24] 1017 	movx	@dptr,a
      003F5A                       1018 00102$:
                                   1019 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F5A 90 05 5A         [24] 1020 	mov	dptr,#_batch_depth
      003F5D E0               [24] 1021 	movx	a,@dptr
      003F5E 70 03            [24] 1022 	jnz	00105$
                                   1023 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F60 02 3D E4         [24] 1024 	ljmp	_ak820_nvm_flush
      003F63                       1025 00105$:
      003F63 22               [24] 1026 	ret
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'load_page'
                                   1029 ;------------------------------------------------------------
                                   1030 ;page          Allocated with name '_load_page_page_10000_87'
                                   1031 ;i             Allocated with name '_load_page_i_10000_88'
                                   1032 ;------------------------------------------------------------
                                   1033 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1034 ;	-----------------------------------------
                                   1035 ;	 function load_page
                                   1036 ;	-----------------------------------------
      003F64                       1037 _load_page:
      003F64 E5 82            [12] 1038 	mov	a,dpl
      003F66 90 05 7B         [24] 1039 	mov	dptr,#_load_page_page_10000_87
      003F69 F0               [24] 1040 	movx	@dptr,a
                                   1041 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F6A 30 07 17         [24] 1042 	jnb	_page_valid,00102$
      003F6D 90 05 59         [24] 1043 	mov	dptr,#_cached_page
      003F70 E0               [24] 1044 	movx	a,@dptr
      003F71 FF               [12] 1045 	mov	r7,a
      003F72 90 05 7B         [24] 1046 	mov	dptr,#_load_page_page_10000_87
      003F75 E0               [24] 1047 	movx	a,@dptr
      003F76 FE               [12] 1048 	mov	r6,a
      003F77 EF               [12] 1049 	mov	a,r7
      003F78 B5 06 09         [24] 1050 	cjne	a,ar6,00102$
      003F7B A2 09            [12] 1051 	mov	c,_storage_failed
      003F7D B3               [12] 1052 	cpl	c
      003F7E 92 0B            [24] 1053 	mov  _load_page_sloc0_1_0,c
      003F80 12 38 68         [24] 1054 	lcall	_ak820_outline_0150
      003F83 22               [24] 1055 	ret
      003F84                       1056 00102$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F84 12 3D E4         [24] 1058 	lcall	_ak820_nvm_flush
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F87 30 09 04         [24] 1060 	jnb	_storage_failed,00119$
      003F8A 75 82 00         [24] 1061 	mov	dpl, #0x00
                                   1062 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F8D 22               [24] 1063 	ret
      003F8E                       1064 00119$:
      003F8E 7F 00            [12] 1065 	mov	r7,#0x00
      003F90                       1066 00107$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003F90 EF               [12] 1068 	mov	a,r7
      003F91 24 19            [12] 1069 	add	a, #_page_data
      003F93 FD               [12] 1070 	mov	r5,a
      003F94 E4               [12] 1071 	clr	a
      003F95 34 05            [12] 1072 	addc	a, #(_page_data >> 8)
      003F97 FE               [12] 1073 	mov	r6,a
      003F98 90 05 7B         [24] 1074 	mov	dptr,#_load_page_page_10000_87
      003F9B E0               [24] 1075 	movx	a,@dptr
      003F9C FC               [12] 1076 	mov	r4,a
      003F9D FA               [12] 1077 	mov	r2,a
      003F9E E4               [12] 1078 	clr	a
      003F9F C3               [12] 1079 	clr	c
      003FA0 CA               [12] 1080 	xch	a,r2
      003FA1 13               [12] 1081 	rrc	a
      003FA2 CA               [12] 1082 	xch	a,r2
      003FA3 13               [12] 1083 	rrc	a
      003FA4 A2 E0            [12] 1084 	mov	c,acc.0
      003FA6 CA               [12] 1085 	xch	a,r2
      003FA7 13               [12] 1086 	rrc	a
      003FA8 CA               [12] 1087 	xch	a,r2
      003FA9 13               [12] 1088 	rrc	a
      003FAA CA               [12] 1089 	xch	a,r2
      003FAB 24 C7            [12] 1090 	add	a,#0xc7
      003FAD FB               [12] 1091 	mov	r3,a
      003FAE 8F 01            [24] 1092 	mov	ar1,r7
      003FB0 89 00            [24] 1093 	mov	ar0,r1
      003FB2 79 00            [12] 1094 	mov	r1,#0x00
      003FB4 E8               [12] 1095 	mov	a,r0
      003FB5 2A               [12] 1096 	add	a, r2
      003FB6 FA               [12] 1097 	mov	r2,a
      003FB7 E9               [12] 1098 	mov	a,r1
      003FB8 3B               [12] 1099 	addc	a, r3
      003FB9 FB               [12] 1100 	mov	r3,a
      003FBA 12 43 22         [24] 1101 	lcall	_ak820_outline_0136
      003FBD 12 38 AB         [24] 1102 	lcall	_ak820_flash_read
      003FC0 AB 82            [24] 1103 	mov	r3, dpl
      003FC2 12 38 63         [24] 1104 	lcall	_ak820_outline_0138
      003FC5 EB               [12] 1105 	mov	a,r3
      003FC6 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FC7 0F               [12] 1108 	inc	r7
      003FC8 BF 40 C5         [24] 1109 	cjne	r7,#0x40,00107$
                                   1110 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FCB 90 05 59         [24] 1111 	mov	dptr,#_cached_page
      003FCE EC               [12] 1112 	mov	a,r4
      003FCF F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1115 ;	assignBit
      003FD0 D2 07            [12] 1116 	setb	_page_valid
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FD2 75 82 01         [24] 1118 	mov	dpl, #0x01
                                   1119 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FD5 22               [24] 1120 	ret
                                   1121 ;------------------------------------------------------------
                                   1122 ;Allocation info for local variables in function 'read_offset'
                                   1123 ;------------------------------------------------------------
                                   1124 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1125 ;------------------------------------------------------------
                                   1126 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1127 ;	-----------------------------------------
                                   1128 ;	 function read_offset
                                   1129 ;	-----------------------------------------
      003FD6                       1130 _read_offset:
      003FD6 12 38 4E         [24] 1131 	lcall	_ak820_outline_0109
      003FD9 90 05 7C         [24] 1132 	mov	dptr,#_read_offset_offset_10000_93
      003FDC 12 38 49         [24] 1133 	lcall	_ak820_outline_0108
                                   1134 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FDF 90 05 7C         [24] 1135 	mov	dptr,#_read_offset_offset_10000_93
      003FE2 12 37 FB         [24] 1136 	lcall	_ak820_outline_0058
      003FE5 C3               [12] 1137 	clr	c
      003FE6 94 28            [12] 1138 	subb	a,#0x28
      003FE8 40 04            [24] 1139 	jc	00102$
      003FEA 75 82 00         [24] 1140 	mov	dpl, #0x00
      003FED 22               [24] 1141 	ret
      003FEE                       1142 00102$:
                                   1143 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FEE 30 07 34         [24] 1144 	jnb	_page_valid,00104$
      003FF1 8E 04            [24] 1145 	mov	ar4,r6
      003FF3 EF               [12] 1146 	mov	a,r7
      003FF4 A2 E7            [12] 1147 	mov	c,acc.7
      003FF6 CC               [12] 1148 	xch	a,r4
      003FF7 33               [12] 1149 	rlc	a
      003FF8 CC               [12] 1150 	xch	a,r4
      003FF9 33               [12] 1151 	rlc	a
      003FFA A2 E7            [12] 1152 	mov	c,acc.7
      003FFC CC               [12] 1153 	xch	a,r4
      003FFD 33               [12] 1154 	rlc	a
      003FFE CC               [12] 1155 	xch	a,r4
      003FFF 33               [12] 1156 	rlc	a
      004000 CC               [12] 1157 	xch	a,r4
      004001 54 03            [12] 1158 	anl	a,#0x03
      004003 FD               [12] 1159 	mov	r5,a
      004004 90 05 59         [24] 1160 	mov	dptr,#_cached_page
      004007 E0               [24] 1161 	movx	a,@dptr
      004008 FA               [12] 1162 	mov	r2,a
      004009 7B 00            [12] 1163 	mov	r3,#0x00
      00400B EC               [12] 1164 	mov	a,r4
      00400C B5 02 16         [24] 1165 	cjne	a,ar2,00104$
      00400F ED               [12] 1166 	mov	a,r5
      004010 B5 03 12         [24] 1167 	cjne	a,ar3,00104$
                                   1168 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004013 74 3F            [12] 1169 	mov	a,#0x3f
      004015 5E               [12] 1170 	anl	a,r6
      004016 7D 00            [12] 1171 	mov	r5,#0x00
      004018 24 19            [12] 1172 	add	a, #_page_data
      00401A F5 82            [12] 1173 	mov	dpl,a
      00401C ED               [12] 1174 	mov	a,r5
      00401D 34 05            [12] 1175 	addc	a, #(_page_data >> 8)
      00401F F5 83            [12] 1176 	mov	dph,a
      004021 E0               [24] 1177 	movx	a,@dptr
      004022 F5 82            [12] 1178 	mov	dpl,a
      004024 22               [24] 1179 	ret
      004025                       1180 00104$:
                                   1181 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004025 74 C7            [12] 1182 	mov	a,#0xc7
      004027 2F               [12] 1183 	add	a, r7
      004028 FF               [12] 1184 	mov	r7,a
      004029 12 43 17         [24] 1185 	lcall	_ak820_outline_0119
                                   1186 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00402C 02 38 AB         [24] 1187 	ljmp	_ak820_flash_read
                                   1188 ;------------------------------------------------------------
                                   1189 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1190 ;------------------------------------------------------------
                                   1191 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function eeprom_read_byte
                                   1196 ;	-----------------------------------------
      00402F                       1197 _eeprom_read_byte:
      00402F C0 07            [24] 1198 	push	ar7
      004031 C0 06            [24] 1199 	push	ar6
      004033 12 42 CE         [24] 1200 	lcall	_ak820_outline_0042
      004036 90 05 7E         [24] 1201 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004039 12 37 E3         [24] 1202 	lcall	_ak820_outline_0019
                                   1203 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00403C 90 05 7E         [24] 1204 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00403F 12 37 AC         [24] 1205 	lcall	_ak820_outline_0006
      004042 C0 06            [24] 1206 	push	ar6
      004044 C0 05            [24] 1207 	push	ar5
      004046 C0 04            [24] 1208 	push	ar4
      004048 C0 03            [24] 1209 	push	ar3
      00404A C0 02            [24] 1210 	push	ar2
      00404C C0 01            [24] 1211 	push	ar1
      00404E C0 00            [24] 1212 	push	ar0
      004050 12 3F D6         [24] 1213 	lcall	_read_offset
      004053 AF 82            [24] 1214 	mov	r7, dpl
      004055 D0 00            [24] 1215 	pop	ar0
      004057 D0 01            [24] 1216 	pop	ar1
      004059 D0 02            [24] 1217 	pop	ar2
      00405B D0 03            [24] 1218 	pop	ar3
      00405D D0 04            [24] 1219 	pop	ar4
      00405F D0 05            [24] 1220 	pop	ar5
      004061 D0 06            [24] 1221 	pop	ar6
      004063 8F 82            [24] 1222 	mov	dpl, r7
                                   1223 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004065 D0 06            [24] 1224 	pop	ar6
      004067 D0 07            [24] 1225 	pop	ar7
      004069 22               [24] 1226 	ret
                                   1227 ;------------------------------------------------------------
                                   1228 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1229 ;------------------------------------------------------------
                                   1230 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1231 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1232 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1233 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1234 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1235 ;------------------------------------------------------------
                                   1236 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1237 ;	-----------------------------------------
                                   1238 ;	 function ak820_eeprom_read_block_xdata
                                   1239 ;	-----------------------------------------
      00406A                       1240 _ak820_eeprom_read_block_xdata:
      00406A 12 38 4E         [24] 1241 	lcall	_ak820_outline_0109
      00406D 90 05 86         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004070 12 38 49         [24] 1243 	lcall	_ak820_outline_0108
                                   1244 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004073 90 05 81         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004076 12 37 FB         [24] 1246 	lcall	_ak820_outline_0058
                                   1247 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004079 90 05 86         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00407C 12 38 12         [24] 1249 	lcall	_ak820_outline_0064
      00407F 90 05 88         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004082 12 38 1E         [24] 1251 	lcall	_ak820_outline_0077
                                   1252 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004085 90 05 84         [24] 1253 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004088 12 38 12         [24] 1254 	lcall	_ak820_outline_0064
      00408B                       1255 00103$:
      00408B 8C 02            [24] 1256 	mov	ar2,r4
      00408D 8D 03            [24] 1257 	mov	ar3,r5
      00408F 1C               [12] 1258 	dec	r4
      004090 BC FF 01         [24] 1259 	cjne	r4,#0xff,00130$
      004093 1D               [12] 1260 	dec	r5
      004094                       1261 00130$:
      004094 EA               [12] 1262 	mov	a,r2
      004095 4B               [12] 1263 	orl	a,r3
      004096 60 5D            [24] 1264 	jz	00106$
                                   1265 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004098 8E 02            [24] 1266 	mov	ar2,r6
      00409A 8F 03            [24] 1267 	mov	ar3,r7
      00409C 74 D8            [12] 1268 	mov	a,#0x100 - 0x28
      00409E 2B               [12] 1269 	add	a,r3
      00409F 50 17            [24] 1270 	jnc	00102$
      0040A1 90 05 88         [24] 1271 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040A4 12 42 FF         [24] 1272 	lcall	_ak820_outline_0081
      0040A7 12 43 22         [24] 1273 	lcall	_ak820_outline_0136
      0040AA E4               [12] 1274 	clr	a
      0040AB F0               [24] 1275 	movx	@dptr,a
      0040AC 90 05 88         [24] 1276 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040AF 04               [12] 1277 	inc	a
      0040B0 2A               [12] 1278 	add	a, r2
      0040B1 F0               [24] 1279 	movx	@dptr,a
      0040B2 E4               [12] 1280 	clr	a
      0040B3 3B               [12] 1281 	addc	a, r3
      0040B4 A3               [24] 1282 	inc	dptr
      0040B5 F0               [24] 1283 	movx	@dptr,a
      0040B6 80 D3            [24] 1284 	sjmp	00103$
      0040B8                       1285 00102$:
                                   1286 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040B8 90 05 88         [24] 1287 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040BB 12 42 FF         [24] 1288 	lcall	_ak820_outline_0081
      0040BE 12 43 17         [24] 1289 	lcall	_ak820_outline_0119
      0040C1 C0 07            [24] 1290 	push	ar7
      0040C3 C0 06            [24] 1291 	push	ar6
      0040C5 C0 05            [24] 1292 	push	ar5
      0040C7 C0 04            [24] 1293 	push	ar4
      0040C9 C0 03            [24] 1294 	push	ar3
      0040CB C0 02            [24] 1295 	push	ar2
      0040CD 12 3F D6         [24] 1296 	lcall	_read_offset
      0040D0 A9 82            [24] 1297 	mov	r1, dpl
      0040D2 D0 02            [24] 1298 	pop	ar2
      0040D4 D0 03            [24] 1299 	pop	ar3
      0040D6 D0 04            [24] 1300 	pop	ar4
      0040D8 D0 05            [24] 1301 	pop	ar5
      0040DA D0 06            [24] 1302 	pop	ar6
      0040DC D0 07            [24] 1303 	pop	ar7
      0040DE 12 43 22         [24] 1304 	lcall	_ak820_outline_0136
      0040E1 E9               [12] 1305 	mov	a,r1
      0040E2 F0               [24] 1306 	movx	@dptr,a
      0040E3 90 05 88         [24] 1307 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040E6 74 01            [12] 1308 	mov	a,#0x01
      0040E8 2A               [12] 1309 	add	a, r2
      0040E9 F0               [24] 1310 	movx	@dptr,a
      0040EA E4               [12] 1311 	clr	a
      0040EB 3B               [12] 1312 	addc	a, r3
      0040EC A3               [24] 1313 	inc	dptr
      0040ED F0               [24] 1314 	movx	@dptr,a
                                   1315 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040EE 0E               [12] 1316 	inc	r6
      0040EF BE 00 99         [24] 1317 	cjne	r6,#0x00,00103$
      0040F2 0F               [12] 1318 	inc	r7
      0040F3 80 96            [24] 1319 	sjmp	00103$
      0040F5                       1320 00106$:
                                   1321 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0040F5 22               [24] 1322 	ret
                                   1323 ;------------------------------------------------------------
                                   1324 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1325 ;------------------------------------------------------------
                                   1326 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1327 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1328 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1329 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1330 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1331 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1332 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1333 ;------------------------------------------------------------
                                   1334 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1335 ;	-----------------------------------------
                                   1336 ;	 function ak820_eeprom_write_block_xdata
                                   1337 ;	-----------------------------------------
      0040F6                       1338 _ak820_eeprom_write_block_xdata:
      0040F6 12 38 4E         [24] 1339 	lcall	_ak820_outline_0109
      0040F9 90 05 8F         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0040FC 12 38 49         [24] 1341 	lcall	_ak820_outline_0108
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040FF 90 05 8A         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004102 12 37 FB         [24] 1344 	lcall	_ak820_outline_0058
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004105 90 05 8F         [24] 1346 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004108 12 38 12         [24] 1347 	lcall	_ak820_outline_0064
                                   1348 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00410B 8E 02            [24] 1349 	mov	ar2,r6
      00410D 8F 03            [24] 1350 	mov	ar3,r7
      00410F C3               [12] 1351 	clr	c
      004110 E4               [12] 1352 	clr	a
      004111 9A               [12] 1353 	subb	a,r2
      004112 74 28            [12] 1354 	mov	a,#0x28
      004114 9B               [12] 1355 	subb	a,r3
      004115 40 15            [24] 1356 	jc	00101$
                                   1357 ;	free result
      004117 E4               [12] 1358 	clr	a
      004118 C3               [12] 1359 	clr	c
      004119 9E               [12] 1360 	subb	a,r6
      00411A FA               [12] 1361 	mov	r2,a
      00411B 74 28            [12] 1362 	mov	a,#0x28
      00411D 9F               [12] 1363 	subb	a,r7
      00411E FB               [12] 1364 	mov	r3,a
      00411F 90 05 8D         [24] 1365 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004122 12 38 3D         [24] 1366 	lcall	_ak820_outline_0102
      004125 C3               [12] 1367 	clr	c
      004126 EA               [12] 1368 	mov	a,r2
      004127 98               [12] 1369 	subb	a,r0
      004128 EB               [12] 1370 	mov	a,r3
      004129 99               [12] 1371 	subb	a,r1
      00412A 50 06            [24] 1372 	jnc	00125$
                                   1373 ;	free result
      00412C                       1374 00101$:
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00412C 75 82 0E         [24] 1376 	mov	dpl, #0x0e
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00412F 02 3B 3F         [24] 1378 	ljmp	_nvm_fail
                                   1379 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004132                       1380 00125$:
      004132 90 05 8D         [24] 1381 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004135 12 42 FF         [24] 1382 	lcall	_ak820_outline_0081
      004138                       1383 00108$:
      004138 8A 00            [24] 1384 	mov	ar0,r2
      00413A 8B 01            [24] 1385 	mov	ar1,r3
      00413C 1A               [12] 1386 	dec	r2
      00413D BA FF 01         [24] 1387 	cjne	r2,#0xff,00159$
      004140 1B               [12] 1388 	dec	r3
      004141                       1389 00159$:
      004141 E8               [12] 1390 	mov	a,r0
      004142 49               [12] 1391 	orl	a,r1
      004143 70 03            [24] 1392 	jnz	00160$
      004145 02 41 CF         [24] 1393 	ljmp	00110$
      004148                       1394 00160$:
                                   1395 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004148 C0 02            [24] 1396 	push	ar2
      00414A C0 03            [24] 1397 	push	ar3
      00414C 12 43 05         [24] 1398 	lcall	_ak820_outline_0098
      00414F F9               [12] 1399 	mov	r1,a
      004150 A3               [24] 1400 	inc	dptr
      004151 12 43 37         [24] 1401 	lcall	_ak820_outline_0152
                                   1402 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004154 8E 0C            [24] 1403 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004156 8F 0D            [24] 1404 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004158 A8 0C            [24] 1405 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00415A E5 0D            [12] 1406 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00415C A2 E7            [12] 1407 	mov	c,acc.7
      00415E C8               [12] 1408 	xch	a,r0
      00415F 33               [12] 1409 	rlc	a
      004160 C8               [12] 1410 	xch	a,r0
      004161 33               [12] 1411 	rlc	a
      004162 A2 E7            [12] 1412 	mov	c,acc.7
      004164 C8               [12] 1413 	xch	a,r0
      004165 33               [12] 1414 	rlc	a
      004166 C8               [12] 1415 	xch	a,r0
      004167 33               [12] 1416 	rlc	a
      004168 C8               [12] 1417 	xch	a,r0
      004169 54 03            [12] 1418 	anl	a,#0x03
      00416B FB               [12] 1419 	mov	r3,a
      00416C 88 82            [24] 1420 	mov	dpl, r0
      00416E C0 07            [24] 1421 	push	ar7
      004170 C0 06            [24] 1422 	push	ar6
      004172 C0 05            [24] 1423 	push	ar5
      004174 C0 04            [24] 1424 	push	ar4
      004176 C0 03            [24] 1425 	push	ar3
      004178 C0 02            [24] 1426 	push	ar2
      00417A C0 01            [24] 1427 	push	ar1
      00417C 12 3F 64         [24] 1428 	lcall	_load_page
      00417F E5 82            [12] 1429 	mov	a, dpl
      004181 D0 01            [24] 1430 	pop	ar1
      004183 D0 02            [24] 1431 	pop	ar2
      004185 D0 03            [24] 1432 	pop	ar3
      004187 D0 04            [24] 1433 	pop	ar4
      004189 D0 05            [24] 1434 	pop	ar5
      00418B D0 06            [24] 1435 	pop	ar6
      00418D D0 07            [24] 1436 	pop	ar7
      00418F D0 03            [24] 1437 	pop	ar3
      004191 D0 02            [24] 1438 	pop	ar2
      004193 70 01            [24] 1439 	jnz	00105$
      004195 22               [24] 1440 	ret
      004196                       1441 00105$:
                                   1442 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004196 C0 06            [24] 1443 	push	ar6
      004198 C0 07            [24] 1444 	push	ar7
      00419A 74 3F            [12] 1445 	mov	a,#0x3f
      00419C 55 0C            [12] 1446 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00419E 7F 00            [12] 1447 	mov	r7,#0x00
      0041A0 24 19            [12] 1448 	add	a, #_page_data
      0041A2 F5 0C            [12] 1449 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041A4 EF               [12] 1450 	mov	a,r7
      0041A5 34 05            [12] 1451 	addc	a, #(_page_data >> 8)
      0041A7 F5 0D            [12] 1452 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041A9 85 0C 82         [24] 1453 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041AC 85 0D 83         [24] 1454 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041AF E0               [24] 1455 	movx	a,@dptr
      0041B0 B5 01 06         [24] 1456 	cjne	a,ar1,00162$
      0041B3 D0 07            [24] 1457 	pop	ar7
      0041B5 D0 06            [24] 1458 	pop	ar6
      0041B7 80 0E            [24] 1459 	sjmp	00107$
      0041B9                       1460 00162$:
      0041B9 D0 07            [24] 1461 	pop	ar7
      0041BB D0 06            [24] 1462 	pop	ar6
                                   1463 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041BD 85 0C 82         [24] 1464 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041C0 85 0D 83         [24] 1465 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041C3 E9               [12] 1466 	mov	a,r1
      0041C4 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1469 ;	assignBit
      0041C5 D2 08            [12] 1470 	setb	_page_dirty
      0041C7                       1471 00107$:
                                   1472 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041C7 0E               [12] 1473 	inc	r6
      0041C8 BE 00 01         [24] 1474 	cjne	r6,#0x00,00163$
      0041CB 0F               [12] 1475 	inc	r7
      0041CC                       1476 00163$:
      0041CC 02 41 38         [24] 1477 	ljmp	00108$
      0041CF                       1478 00110$:
                                   1479 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041CF 90 05 5A         [24] 1480 	mov	dptr,#_batch_depth
      0041D2 E0               [24] 1481 	movx	a,@dptr
      0041D3 70 03            [24] 1482 	jnz	00113$
                                   1483 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041D5 02 3D E4         [24] 1484 	ljmp	_ak820_nvm_flush
      0041D8                       1485 00113$:
      0041D8 22               [24] 1486 	ret
                                   1487 ;------------------------------------------------------------
                                   1488 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1489 ;------------------------------------------------------------
                                   1490 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1491 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1492 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1493 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1494 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1495 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1496 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1497 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1498 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1499 ;------------------------------------------------------------
                                   1500 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1501 ;	-----------------------------------------
                                   1502 ;	 function ak820_eeprom_update_block_xdata
                                   1503 ;	-----------------------------------------
      0041D9                       1504 _ak820_eeprom_update_block_xdata:
      0041D9 12 38 4E         [24] 1505 	lcall	_ak820_outline_0109
      0041DC 90 05 96         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041DF 12 38 49         [24] 1507 	lcall	_ak820_outline_0108
                                   1508 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041E2 90 05 96         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E5 12 37 FB         [24] 1510 	lcall	_ak820_outline_0058
                                   1511 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041E8 90 05 91         [24] 1512 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041EB E0               [24] 1513 	movx	a,@dptr
      0041EC F5 12            [12] 1514 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041EE A3               [24] 1515 	inc	dptr
      0041EF E0               [24] 1516 	movx	a,@dptr
      0041F0 F5 13            [12] 1517 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0041F2 A3               [24] 1518 	inc	dptr
      0041F3 E0               [24] 1519 	movx	a,@dptr
      0041F4 F5 14            [12] 1520 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0041F6 A9 12            [24] 1521 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0041F8 AA 13            [24] 1522 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1523 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0041FA E4               [12] 1524 	clr	a
      0041FB F5 0E            [12] 1525 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0041FD F5 0F            [12] 1526 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0041FF                       1527 00105$:
      0041FF 90 05 94         [24] 1528 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004202 E0               [24] 1529 	movx	a,@dptr
      004203 F5 10            [12] 1530 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004205 A3               [24] 1531 	inc	dptr
      004206 E0               [24] 1532 	movx	a,@dptr
      004207 F5 11            [12] 1533 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004209 C3               [12] 1534 	clr	c
      00420A E5 0E            [12] 1535 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00420C 95 10            [12] 1536 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00420E E5 0F            [12] 1537 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004210 95 11            [12] 1538 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004212 50 68            [24] 1539 	jnc	00107$
                                   1540 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004214 89 00            [24] 1541 	mov	ar0,r1
      004216 8A 05            [24] 1542 	mov	ar5,r2
      004218 E5 0E            [12] 1543 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00421A 28               [12] 1544 	add	a, r0
      00421B F8               [12] 1545 	mov	r0,a
      00421C E5 0F            [12] 1546 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00421E 3D               [12] 1547 	addc	a, r5
      00421F FD               [12] 1548 	mov	r5,a
      004220 88 82            [24] 1549 	mov	dpl, r0
      004222 8D 83            [24] 1550 	mov	dph, r5
      004224 C0 07            [24] 1551 	push	ar7
      004226 C0 06            [24] 1552 	push	ar6
      004228 C0 02            [24] 1553 	push	ar2
      00422A C0 01            [24] 1554 	push	ar1
      00422C 12 3F D6         [24] 1555 	lcall	_read_offset
      00422F AD 82            [24] 1556 	mov	r5, dpl
      004231 D0 01            [24] 1557 	pop	ar1
      004233 D0 02            [24] 1558 	pop	ar2
      004235 D0 06            [24] 1559 	pop	ar6
      004237 D0 07            [24] 1560 	pop	ar7
      004239 E5 0E            [12] 1561 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00423B 2E               [12] 1562 	add	a, r6
      00423C F5 82            [12] 1563 	mov	dpl,a
      00423E E5 0F            [12] 1564 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004240 3F               [12] 1565 	addc	a, r7
      004241 F5 83            [12] 1566 	mov	dph,a
      004243 E0               [24] 1567 	movx	a,@dptr
      004244 FC               [12] 1568 	mov	r4,a
      004245 ED               [12] 1569 	mov	a,r5
      004246 B5 04 02         [24] 1570 	cjne	a,ar4,00131$
      004249 80 27            [24] 1571 	sjmp	00106$
      00424B                       1572 00131$:
                                   1573 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00424B 90 05 96         [24] 1574 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00424E E0               [24] 1575 	movx	a,@dptr
      00424F F8               [12] 1576 	mov	r0,a
      004250 A3               [24] 1577 	inc	dptr
      004251 E0               [24] 1578 	movx	a,@dptr
      004252 FD               [12] 1579 	mov	r5,a
      004253 90 05 8A         [24] 1580 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004256 E5 12            [12] 1581 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004258 F0               [24] 1582 	movx	@dptr,a
      004259 E5 13            [12] 1583 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00425B A3               [24] 1584 	inc	dptr
      00425C F0               [24] 1585 	movx	@dptr,a
      00425D E5 14            [12] 1586 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00425F A3               [24] 1587 	inc	dptr
      004260 F0               [24] 1588 	movx	@dptr,a
      004261 90 05 8D         [24] 1589 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004264 E5 10            [12] 1590 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004266 F0               [24] 1591 	movx	@dptr,a
      004267 E5 11            [12] 1592 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004269 A3               [24] 1593 	inc	dptr
      00426A F0               [24] 1594 	movx	@dptr,a
      00426B 88 82            [24] 1595 	mov	dpl, r0
      00426D 8D 83            [24] 1596 	mov	dph, r5
                                   1597 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      00426F 02 40 F6         [24] 1598 	ljmp	_ak820_eeprom_write_block_xdata
      004272                       1599 00106$:
                                   1600 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004272 05 0E            [12] 1601 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004274 E4               [12] 1602 	clr	a
      004275 B5 0E 87         [24] 1603 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004278 05 0F            [12] 1604 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00427A 80 83            [24] 1605 	sjmp	00105$
      00427C                       1606 00107$:
                                   1607 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00427C 22               [24] 1608 	ret
                                   1609 ;------------------------------------------------------------
                                   1610 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1611 ;------------------------------------------------------------
                                   1612 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1613 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function eeprom_driver_erase
                                   1618 ;	-----------------------------------------
      00427D                       1619 _eeprom_driver_erase:
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00427D 12 3D E4         [24] 1621 	lcall	_ak820_nvm_flush
                                   1622 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004280 7F 00            [12] 1623 	mov	r7,#0x00
      004282                       1624 00111$:
      004282 BF A0 01         [24] 1625 	cjne	r7,#0xa0,00165$
      004285 22               [24] 1626 	ret
      004286                       1627 00165$:
      004286 20 09 32         [24] 1628 	jb	_storage_failed,00113$
                                   1629 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004289 8F 82            [24] 1630 	mov	dpl, r7
      00428B C0 07            [24] 1631 	push	ar7
      00428D 12 3F 64         [24] 1632 	lcall	_load_page
      004290 E5 82            [12] 1633 	mov	a, dpl
      004292 D0 07            [24] 1634 	pop	ar7
      004294 70 01            [24] 1635 	jnz	00126$
                                   1636 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004296 22               [24] 1637 	ret
      004297                       1638 00126$:
      004297 7E 00            [12] 1639 	mov	r6,#0x00
      004299                       1640 00107$:
                                   1641 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004299 EE               [12] 1642 	mov	a,r6
      00429A 24 19            [12] 1643 	add	a, #_page_data
      00429C FC               [12] 1644 	mov	r4,a
      00429D E4               [12] 1645 	clr	a
      00429E 34 05            [12] 1646 	addc	a, #(_page_data >> 8)
      0042A0 FD               [12] 1647 	mov	r5,a
      0042A1 12 43 05         [24] 1648 	lcall	_ak820_outline_0098
      0042A4 60 07            [24] 1649 	jz	00108$
      0042A6 12 38 59         [24] 1650 	lcall	_ak820_outline_0127
      0042A9 E4               [12] 1651 	clr	a
      0042AA F0               [24] 1652 	movx	@dptr,a
                                   1653 ;	assignBit
      0042AB D2 08            [12] 1654 	setb	_page_dirty
      0042AD                       1655 00108$:
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042AD 0E               [12] 1657 	inc	r6
      0042AE BE 40 E8         [24] 1658 	cjne	r6,#0x40,00107$
                                   1659 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042B1 C0 07            [24] 1660 	push	ar7
      0042B3 12 3D E4         [24] 1661 	lcall	_ak820_nvm_flush
      0042B6 D0 07            [24] 1662 	pop	ar7
                                   1663 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042B8 0F               [12] 1664 	inc	r7
      0042B9 80 C7            [24] 1665 	sjmp	00111$
      0042BB                       1666 00113$:
                                   1667 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042BB 22               [24] 1668 	ret
                                   1669 	.area CSEG    (CODE)
                                   1670 	.area CONST   (CODE)
                                   1671 	.area XINIT   (CODE)
                                   1672 	.area CABS    (ABS,CODE)
                                   1673 
                                   1674 ; Experimental exact instruction outlining.
                                   1675 	.globl _ak820_outline_0006
                                   1676 	.globl _ak820_outline_0012
                                   1677 	.globl _ak820_outline_0018
                                   1678 	.globl _ak820_outline_0019
                                   1679 	.globl _ak820_outline_0037
                                   1680 	.globl _ak820_outline_0042
                                   1681 	.globl _ak820_outline_0046
                                   1682 	.globl _ak820_outline_0058
                                   1683 	.globl _ak820_outline_0059
                                   1684 	.globl _ak820_outline_0064
                                   1685 	.globl _ak820_outline_0066
                                   1686 	.globl _ak820_outline_0069
                                   1687 	.globl _ak820_outline_0077
                                   1688 	.globl _ak820_outline_0080
                                   1689 	.globl _ak820_outline_0081
                                   1690 	.globl _ak820_outline_0082
                                   1691 	.globl _ak820_outline_0098
                                   1692 	.globl _ak820_outline_0102
                                   1693 	.globl _ak820_outline_0103
                                   1694 	.globl _ak820_outline_0106
                                   1695 	.globl _ak820_outline_0108
                                   1696 	.globl _ak820_outline_0109
                                   1697 	.globl _ak820_outline_0119
                                   1698 	.globl _ak820_outline_0123
                                   1699 	.globl _ak820_outline_0125
                                   1700 	.globl _ak820_outline_0127
                                   1701 	.globl _ak820_outline_0136
                                   1702 	.globl _ak820_outline_0137
                                   1703 	.globl _ak820_outline_0138
                                   1704 	.globl _ak820_outline_0143
                                   1705 	.globl _ak820_outline_0150
                                   1706 	.globl _ak820_outline_0151
                                   1707 	.globl _ak820_outline_0152
                                   1708 	.globl _ak820_outline_0160
                                   1709 	.globl _ak820_outline_0164
                                   1710 	.globl _ak820_outline_0165
                                   1711 	.globl _ak820_outline_0185
                                   1712 
                                   1713 	.area CSEG (CODE)
                                   1714 ; function ak820_outline_0012
      0042BC                       1715 _ak820_outline_0012:
      0042BC 8E 82            [24] 1716 	mov	dpl,r6
      0042BE 8F 83            [24] 1717 	mov	dph,r7
      0042C0 A3               [24] 1718 	inc	dptr
      0042C1 A3               [24] 1719 	inc	dptr
      0042C2 A3               [24] 1720 	inc	dptr
      0042C3 A3               [24] 1721 	inc	dptr
      0042C4 A3               [24] 1722 	inc	dptr
      0042C5 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0037
      0042C6                       1727 _ak820_outline_0037:
      0042C6 F0               [24] 1728 	movx	@dptr,a
      0042C7 8E 82            [24] 1729 	mov	dpl,r6
      0042C9 8F 83            [24] 1730 	mov	dph,r7
      0042CB A3               [24] 1731 	inc	dptr
      0042CC A3               [24] 1732 	inc	dptr
      0042CD 22               [24] 1733 	ret
                                   1734 
                                   1735 	.area CSEG (CODE)
                                   1736 ; function ak820_outline_0042
      0042CE                       1737 _ak820_outline_0042:
      0042CE AF F0            [24] 1738 	mov	r7,b
      0042D0 AE 83            [24] 1739 	mov	r6,dph
      0042D2 E5 82            [12] 1740 	mov	a,dpl
      0042D4 22               [24] 1741 	ret
                                   1742 
                                   1743 	.area CSEG (CODE)
                                   1744 ; function ak820_outline_0046
      0042D5                       1745 _ak820_outline_0046:
      0042D5 EF               [12] 1746 	mov	a,r7
      0042D6 24 71            [12] 1747 	add	a,#_ak820_nvm_flush_header_10000_62
      0042D8 F5 82            [12] 1748 	mov	dpl,a
      0042DA E4               [12] 1749 	clr	a
      0042DB 34 05            [12] 1750 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042DD F5 83            [12] 1751 	mov	dph,a
      0042DF E0               [24] 1752 	movx	a,@dptr
      0042E0 22               [24] 1753 	ret
                                   1754 
                                   1755 	.area CSEG (CODE)
                                   1756 ; function ak820_outline_0059
      0042E1                       1757 _ak820_outline_0059:
      0042E1 8F 06            [24] 1758 	mov	ar6,r7
      0042E3 7D 00            [12] 1759 	mov	r5,#0x00
      0042E5 74 40            [12] 1760 	mov	a,#0x40
      0042E7 2E               [12] 1761 	add	a,r6
      0042E8 FE               [12] 1762 	mov	r6,a
      0042E9 74 EF            [12] 1763 	mov	a,#0xef
      0042EB 3D               [12] 1764 	addc	a,r5
      0042EC FD               [12] 1765 	mov	r5,a
      0042ED 8E 82            [24] 1766 	mov	dpl,r6
      0042EF 8D 83            [24] 1767 	mov	dph,r5
      0042F1 22               [24] 1768 	ret
                                   1769 
                                   1770 	.area CSEG (CODE)
                                   1771 ; function ak820_outline_0066
      0042F2                       1772 _ak820_outline_0066:
      0042F2 F0               [24] 1773 	movx	@dptr,a
      0042F3 8E 82            [24] 1774 	mov	dpl,r6
      0042F5 8F 83            [24] 1775 	mov	dph,r7
      0042F7 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0069
      0042F8                       1780 _ak820_outline_0069:
      0042F8 8D 82            [24] 1781 	mov	dpl,r5
      0042FA 8E 83            [24] 1782 	mov	dph,r6
      0042FC EC               [12] 1783 	mov	a,r4
      0042FD F0               [24] 1784 	movx	@dptr,a
      0042FE 22               [24] 1785 	ret
                                   1786 
                                   1787 	.area CSEG (CODE)
                                   1788 ; function ak820_outline_0081
      0042FF                       1789 _ak820_outline_0081:
      0042FF E0               [24] 1790 	movx	a,@dptr
      004300 FA               [12] 1791 	mov	r2,a
      004301 A3               [24] 1792 	inc	dptr
      004302 E0               [24] 1793 	movx	a,@dptr
      004303 FB               [12] 1794 	mov	r3,a
      004304 22               [24] 1795 	ret
                                   1796 
                                   1797 	.area CSEG (CODE)
                                   1798 ; function ak820_outline_0098
      004305                       1799 _ak820_outline_0098:
      004305 8C 82            [24] 1800 	mov	dpl,r4
      004307 8D 83            [24] 1801 	mov	dph,r5
      004309 E0               [24] 1802 	movx	a,@dptr
      00430A 22               [24] 1803 	ret
                                   1804 
                                   1805 	.area CSEG (CODE)
                                   1806 ; function ak820_outline_0106
      00430B                       1807 _ak820_outline_0106:
      00430B EF               [12] 1808 	mov	a,r7
      00430C 24 19            [12] 1809 	add	a,#_page_data
      00430E F5 82            [12] 1810 	mov	dpl,a
      004310 E4               [12] 1811 	clr	a
      004311 34 05            [12] 1812 	addc	a,#(_page_data>>8)
      004313 F5 83            [12] 1813 	mov	dph,a
      004315 E0               [24] 1814 	movx	a,@dptr
      004316 22               [24] 1815 	ret
                                   1816 
                                   1817 	.area CSEG (CODE)
                                   1818 ; function ak820_outline_0119
      004317                       1819 _ak820_outline_0119:
      004317 8E 82            [24] 1820 	mov	dpl,r6
      004319 8F 83            [24] 1821 	mov	dph,r7
      00431B 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0125
      00431C                       1826 _ak820_outline_0125:
      00431C 8C 82            [24] 1827 	mov	dpl,r4
      00431E 8D 83            [24] 1828 	mov	dph,r5
      004320 F0               [24] 1829 	movx	@dptr,a
      004321 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0136
      004322                       1834 _ak820_outline_0136:
      004322 8A 82            [24] 1835 	mov	dpl,r2
      004324 8B 83            [24] 1836 	mov	dph,r3
      004326 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0137
      004327                       1841 _ak820_outline_0137:
      004327 AE 82            [24] 1842 	mov	r6,dpl
      004329 AF 83            [24] 1843 	mov	r7,dph
      00432B 22               [24] 1844 	ret
                                   1845 
                                   1846 	.area CSEG (CODE)
                                   1847 ; function ak820_outline_0143
      00432C                       1848 _ak820_outline_0143:
      00432C 42 05            [12] 1849 	orl	ar5,a
      00432E EA               [12] 1850 	mov	a,r2
      00432F 42 04            [12] 1851 	orl	ar4,a
      004331 22               [24] 1852 	ret
                                   1853 
                                   1854 	.area CSEG (CODE)
                                   1855 ; function ak820_outline_0151
      004332                       1856 _ak820_outline_0151:
      004332 89 82            [24] 1857 	mov	dpl,r1
      004334 8A 83            [24] 1858 	mov	dph,r2
      004336 22               [24] 1859 	ret
                                   1860 
                                   1861 	.area CSEG (CODE)
                                   1862 ; function ak820_outline_0152
      004337                       1863 _ak820_outline_0152:
      004337 AC 82            [24] 1864 	mov	r4,dpl
      004339 AD 83            [24] 1865 	mov	r5,dph
      00433B 22               [24] 1866 	ret
                                   1867 
                                   1868 	.area CSEG (CODE)
                                   1869 ; function ak820_outline_0160
      00433C                       1870 _ak820_outline_0160:
      00433C 8F 82            [24] 1871 	mov	dpl,r7
      00433E 8E 83            [24] 1872 	mov	dph,r6
      004340 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0164
      004341                       1877 _ak820_outline_0164:
      004341 2E               [12] 1878 	add	a,r6
      004342 FC               [12] 1879 	mov	r4,a
      004343 E4               [12] 1880 	clr	a
      004344 3F               [12] 1881 	addc	a,r7
      004345 FD               [12] 1882 	mov	r5,a
      004346 22               [24] 1883 	ret
                                   1884 
                                   1885 	.area CSEG (CODE)
                                   1886 ; function ak820_outline_0165
      004347                       1887 _ak820_outline_0165:
      004347 ED               [12] 1888 	mov	a,r5
      004348 F0               [24] 1889 	movx	@dptr,a
      004349 EE               [12] 1890 	mov	a,r6
      00434A A3               [24] 1891 	inc	dptr
      00434B F0               [24] 1892 	movx	@dptr,a
      00434C 22               [24] 1893 	ret
                                   1894 
                                   1895 	.area CSEG (CODE)
                                   1896 ; function ak820_outline_0185
      00434D                       1897 _ak820_outline_0185:
      00434D 8C 82            [24] 1898 	mov	dpl,r4
      00434F 8B 83            [24] 1899 	mov	dph,r3
      004351 22               [24] 1900 	ret
