                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000F                        552 _ak820_tapping_before_sloc0_1_0:
      00000F                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      000664                        562 _source_state:
      000664                        563 	.ds 130
      0006E6                        564 _pending_time:
      0006E6                        565 	.ds 2
      0006E8                        566 _pending_code:
      0006E8                        567 	.ds 2
      0006EA                        568 _ak820_tapping_source_PARM_1:
      0006EA                        569 	.ds 2
      0006EC                        570 _hold_PARM_2:
      0006EC                        571 	.ds 1
      0006ED                        572 _hold_code_10000_603:
      0006ED                        573 	.ds 2
      0006EF                        574 _hold_mods_30000_606:
      0006EF                        575 	.ds 1
      0006F0                        576 _commit_pending_id_10000_612:
      0006F0                        577 	.ds 1
      0006F1                        578 _ak820_tapping_before_event_10000_613:
      0006F1                        579 	.ds 2
      0006F3                        580 _ak820_tapping_process_record_10000_624:
      0006F3                        581 	.ds 2
      0006F5                        582 _ak820_tapping_process_code_10000_625:
      0006F5                        583 	.ds 2
      0006F7                        584 _ak820_tapping_process_sc_mods_10000_625:
      0006F7                        585 	.ds 1
      0006F8                        586 _ak820_oneshot_mods::
      0006F8                        587 	.ds 1
      0006F9                        588 _ak820_oneshot_consumed::
      0006F9                        589 	.ds 1
      0006FA                        590 _ak820_oneshot_process_PARM_2:
      0006FA                        591 	.ds 1
      0006FB                        592 _ak820_oneshot_process_PARM_3:
      0006FB                        593 	.ds 1
      0006FC                        594 _ak820_oneshot_process_code_10000_650:
      0006FC                        595 	.ds 2
      0006FE                        596 _ak820_oneshot_process_mods_10000_651:
      0006FE                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E77                        606 _pending:
      000E77                        607 	.ds 1
      000E78                        608 _ak820_oneshot_target::
      000E78                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0048F2                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0048F2 90 06 EB         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0048F5 E0               [24]  656 	movx	a,@dptr
      0048F6 FF               [12]  657 	mov	r7,a
      0048F7 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0048FA                        659 00147$:
      0048FA 50 14            [24]  660 	jnc	00102$
      0048FC 90 06 EA         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0048FF E0               [24]  662 	movx	a,@dptr
      004900 FE               [12]  663 	mov	r6,a
      004901 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004904                        665 00149$:
      004904 50 0A            [24]  666 	jnc	00102$
      004906 8F 05            [24]  667 	mov	ar5,r7
      004908 ED               [12]  668 	mov	a,r5
      004909 12 38 72         [24]  669 	lcall	_ak820_outline_0162
      00490C 2E               [12]  670 	add	a,r6
      00490D F5 82            [12]  671 	mov	dpl,a
      00490F 22               [24]  672 	ret
      004910                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004910 90 06 EA         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004913 E0               [24]  676 	movx	a,@dptr
      004914 FE               [12]  677 	mov	r6,a
      004915 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004918                        679 00151$:
      004918 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      00491A BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      00491D 75 82 80         [24]  683 	mov	dpl, #0x80
      004920 22               [24]  684 	ret
      004921                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004921 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004924 75 82 81         [24]  688 	mov	dpl, #0x81
      004927 22               [24]  689 	ret
      004928                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004928 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00492B 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      00492C                        707 _hold:
      00492C 12 38 4E         [24]  708 	lcall	_ak820_outline_0109
      00492F 90 06 ED         [24]  709 	mov	dptr,#_hold_code_10000_603
      004932 12 38 49         [24]  710 	lcall	_ak820_outline_0108
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004935 90 06 ED         [24]  712 	mov	dptr,#_hold_code_10000_603
      004938 12 37 C6         [24]  713 	lcall	_ak820_outline_0010
      00493B 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      00493D 2D               [12]  715 	add	a,r5
      00493E 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004940 8F 05            [24]  718 	mov	ar5,r7
      004942 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004945 90 06 EF         [24]  720 	mov	dptr,#_hold_mods_30000_606
      004948 ED               [12]  721 	mov	a,r5
      004949 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      00494A ED               [12]  724 	mov	a,r5
      00494B 30 E4 08         [24]  725 	jnb	acc.4,00102$
      00494E ED               [12]  726 	mov	a,r5
      00494F C4               [12]  727 	swap	a
      004950 54 F0            [12]  728 	anl	a,#0xf0
      004952 90 06 EF         [24]  729 	mov	dptr,#_hold_mods_30000_606
      004955 F0               [24]  730 	movx	@dptr,a
      004956                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004956 90 06 EC         [24]  733 	mov	dptr,#_hold_PARM_2
      004959 E0               [24]  734 	movx	a,@dptr
      00495A 60 09            [24]  735 	jz	00104$
      00495C 90 06 EF         [24]  736 	mov	dptr,#_hold_mods_30000_606
      00495F E0               [24]  737 	movx	a,@dptr
      004960 F5 82            [12]  738 	mov	dpl,a
      004962 02 7A 9D         [24]  739 	ljmp	_register_mods
      004965                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004965 90 06 EF         [24]  742 	mov	dptr,#_hold_mods_30000_606
      004968 E0               [24]  743 	movx	a,@dptr
      004969 F5 82            [12]  744 	mov	dpl,a
      00496B 02 7A B1         [24]  745 	ljmp	_unregister_mods
      00496E                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      00496E 8F 06            [24]  748 	mov	ar6,r7
      004970 74 0F            [12]  749 	mov	a,#0x0f
      004972 5E               [12]  750 	anl	a,r6
      004973 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004974 90 06 EC         [24]  753 	mov	dptr,#_hold_PARM_2
      004977 E0               [24]  754 	movx	a,@dptr
      004978 60 05            [24]  755 	jz	00107$
      00497A 8F 82            [24]  756 	mov	dpl, r7
      00497C 02 7C 59         [24]  757 	ljmp	_layer_hold_on
      00497F                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      00497F 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004981 02 7C 8F         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004984                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004984 90 0E 77         [24]  774 	mov	dptr,#_pending
      004987 E0               [24]  775 	movx	a,@dptr
      004988 90 06 F0         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      00498B F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      00498C 12 4D BD         [24]  779 	lcall	_ak820_outline_0157
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      00498F 90 06 F0         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004992 E0               [24]  782 	movx	a,@dptr
      004993 24 64            [12]  783 	add	a,#_source_state
      004995 FF               [12]  784 	mov	r7,a
      004996 E4               [12]  785 	clr	a
      004997 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      004999 FE               [12]  787 	mov	r6,a
      00499A 12 43 3C         [24]  788 	lcall	_ak820_outline_0160
      00499D E0               [24]  789 	movx	a,@dptr
      00499E FD               [12]  790 	mov	r5,a
      00499F 43 05 04         [24]  791 	orl	ar5,#0x04
      0049A2 12 43 3C         [24]  792 	lcall	_ak820_outline_0160
      0049A5 ED               [12]  793 	mov	a,r5
      0049A6 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      0049A7 90 06 E8         [24]  796 	mov	dptr,#_pending_code
      0049AA 12 37 FB         [24]  797 	lcall	_ak820_outline_0058
      0049AD 90 06 EC         [24]  798 	mov	dptr,#_hold_PARM_2
      0049B0 74 01            [12]  799 	mov	a,#0x01
      0049B2 12 42 F2         [24]  800 	lcall	_ak820_outline_0066
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      0049B5 21 2C            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      0049B7                        813 _ak820_tapping_before:
      0049B7 12 38 4E         [24]  814 	lcall	_ak820_outline_0109
      0049BA 90 06 F1         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_613
      0049BD 12 38 49         [24]  816 	lcall	_ak820_outline_0108
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      0049C0 90 06 F1         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_613
      0049C3 12 37 C6         [24]  819 	lcall	_ak820_outline_0010
      0049C6 12 4D 8E         [24]  820 	lcall	_ak820_outline_0024
      0049C9 C0 07            [24]  821 	push	ar7
      0049CB C0 06            [24]  822 	push	ar6
      0049CD 12 BC D2         [24]  823 	lcall	___memcpy
      0049D0 11 F2            [12]  824 	acall	_ak820_tapping_source
      0049D2 AD 82            [24]  825 	mov	r5, dpl
      0049D4 D0 06            [24]  826 	pop	ar6
      0049D6 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      0049D8 90 0E E8         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0049DB E0               [24]  830 	movx	a,@dptr
      0049DC 60 29            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0049DE 74 04            [12]  833 	mov	a,#0x04
      0049E0 12 4D 74         [24]  834 	lcall	_ak820_outline_0015
      0049E3 60 1E            [24]  835 	jz	00102$
      0049E5 BD FF 02         [24]  836 	cjne	r5,#0xff,00218$
      0049E8 80 19            [24]  837 	sjmp	00102$
      0049EA                        838 00218$:
      0049EA 74 05            [12]  839 	mov	a,#0x05
      0049EC 12 4D 74         [24]  840 	lcall	_ak820_outline_0015
      0049EF 70 12            [24]  841 	jnz	00102$
      0049F1 ED               [12]  842 	mov	a,r5
      0049F2 24 64            [12]  843 	add	a, #_source_state
      0049F4 FB               [12]  844 	mov	r3,a
      0049F5 E4               [12]  845 	clr	a
      0049F6 34 06            [12]  846 	addc	a, #(_source_state >> 8)
      0049F8 12 48 B6         [24]  847 	lcall	_ak820_outline_0051
      0049FB 53 02 FD         [24]  848 	anl	ar2,#0xfd
      0049FE 12 33 FC         [24]  849 	lcall	_ak820_outline_0123
      004A01 EA               [12]  850 	mov	a,r2
      004A02 F0               [24]  851 	movx	@dptr,a
      004A03                        852 00102$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004A03 75 82 00         [24]  854 	mov	dpl, #0x00
      004A06 22               [24]  855 	ret
      004A07                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004A07 90 0E 77         [24]  858 	mov	dptr,#_pending
      004A0A E0               [24]  859 	movx	a,@dptr
      004A0B FC               [12]  860 	mov	r4,a
      004A0C BC FF 02         [24]  861 	cjne	r4,#0xff,00220$
      004A0F 80 3B            [24]  862 	sjmp	00108$
      004A11                        863 00220$:
      004A11 12 37 EB         [24]  864 	lcall	_ak820_outline_0035
      004A14 FA               [12]  865 	mov	r2,a
      004A15 A3               [24]  866 	inc	dptr
      004A16 E0               [24]  867 	movx	a,@dptr
      004A17 FB               [12]  868 	mov	r3,a
      004A18 90 06 E6         [24]  869 	mov	dptr,#_pending_time
      004A1B 12 38 3D         [24]  870 	lcall	_ak820_outline_0102
      004A1E EA               [12]  871 	mov	a,r2
      004A1F C3               [12]  872 	clr	c
      004A20 98               [12]  873 	subb	a,r0
      004A21 FA               [12]  874 	mov	r2,a
      004A22 EB               [12]  875 	mov	a,r3
      004A23 99               [12]  876 	subb	a,r1
      004A24 FB               [12]  877 	mov	r3,a
      004A25 C3               [12]  878 	clr	c
      004A26 EA               [12]  879 	mov	a,r2
      004A27 94 C8            [12]  880 	subb	a,#0xc8
      004A29 EB               [12]  881 	mov	a,r3
      004A2A 94 00            [12]  882 	subb	a,#0x00
      004A2C 50 18            [24]  883 	jnc	00107$
                                    884 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004A2E 74 04            [12]  885 	mov	a,#0x04
      004A30 2E               [12]  886 	add	a, r6
      004A31 12 48 9C         [24]  887 	lcall	_ak820_outline_0034
      004A34 60 16            [24]  888 	jz	00108$
      004A36 12 37 9F         [24]  889 	lcall	_ak820_outline_0002
      004A39 60 11            [24]  890 	jz	00108$
      004A3B BD FF 02         [24]  891 	cjne	r5,#0xff,00224$
      004A3E 80 06            [24]  892 	sjmp	00107$
      004A40                        893 00224$:
      004A40 ED               [12]  894 	mov	a,r5
      004A41 B5 04 02         [24]  895 	cjne	a,ar4,00225$
      004A44 80 06            [24]  896 	sjmp	00108$
      004A46                        897 00225$:
      004A46                        898 00107$:
      004A46 C0 05            [24]  899 	push	ar5
      004A48 31 84            [12]  900 	acall	_commit_pending
      004A4A D0 05            [24]  901 	pop	ar5
      004A4C                        902 00108$:
                                    903 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004A4C 90 06 F1         [24]  904 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A4F 12 37 FB         [24]  905 	lcall	_ak820_outline_0058
      004A52 74 04            [12]  906 	mov	a,#0x04
      004A54 12 4D 74         [24]  907 	lcall	_ak820_outline_0015
      004A57 60 03            [24]  908 	jz	00114$
      004A59 BD FF 04         [24]  909 	cjne	r5,#0xff,00115$
      004A5C                        910 00114$:
      004A5C 75 82 01         [24]  911 	mov	dpl, #0x01
      004A5F 22               [24]  912 	ret
      004A60                        913 00115$:
                                    914 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004A60 ED               [12]  915 	mov	a,r5
      004A61 12 4D AF         [24]  916 	lcall	_ak820_outline_0083
      004A64 30 E1 12         [24]  917 	jnb	acc.1,00120$
                                    918 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004A67 74 05            [12]  919 	mov	a,#0x05
      004A69 2E               [12]  920 	add	a, r6
      004A6A 12 37 D0         [24]  921 	lcall	_ak820_outline_0017
      004A6D 70 06            [24]  922 	jnz	00118$
      004A6F 74 FD            [12]  923 	mov	a,#0xfd
      004A71 5B               [12]  924 	anl	a,r3
      004A72 12 43 1C         [24]  925 	lcall	_ak820_outline_0125
      004A75                        926 00118$:
                                    927 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004A75 75 82 00         [24]  928 	mov	dpl, #0x00
      004A78 22               [24]  929 	ret
      004A79                        930 00120$:
                                    931 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004A79 12 42 BC         [24]  932 	lcall	_ak820_outline_0012
      004A7C E0               [24]  933 	movx	a,@dptr
      004A7D FF               [12]  934 	mov	r7,a
      004A7E 8B 06            [24]  935 	mov	ar6,r3
      004A80 53 06 01         [24]  936 	anl	ar6,#0x01
      004A83 EE               [12]  937 	mov	a,r6
      004A84 B4 01 00         [24]  938 	cjne	a,#0x01,00231$
      004A87                        939 00231$:
      004A87 B3               [12]  940 	cpl	c
      004A88 92 0F            [24]  941 	mov	_ak820_tapping_before_sloc0_1_0,c
      004A8A 8F F0            [24]  942 	mov	b,r7
      004A8C E4               [12]  943 	clr	a
      004A8D 33               [12]  944 	rlc	a
      004A8E B5 F0 04         [24]  945 	cjne	a,b,00122$
      004A91 75 82 00         [24]  946 	mov	dpl, #0x00
      004A94 22               [24]  947 	ret
      004A95                        948 00122$:
                                    949 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004A95 63 03 01         [24]  950 	xrl	ar3,#0x01
      004A98 12 38 59         [24]  951 	lcall	_ak820_outline_0127
      004A9B EB               [12]  952 	mov	a,r3
      004A9C F0               [24]  953 	movx	@dptr,a
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004A9D 75 82 01         [24]  955 	mov	dpl, #0x01
                                    956 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004AA0 22               [24]  957 	ret
                                    958 ;------------------------------------------------------------
                                    959 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    960 ;------------------------------------------------------------
                                    961 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    962 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    963 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    964 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    965 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    966 ;------------------------------------------------------------
                                    967 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    968 ;	-----------------------------------------
                                    969 ;	 function ak820_tapping_process
                                    970 ;	-----------------------------------------
      004AA1                        971 _ak820_tapping_process:
      004AA1 12 38 4E         [24]  972 	lcall	_ak820_outline_0109
      004AA4 90 06 F3         [24]  973 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004AA7 12 38 49         [24]  974 	lcall	_ak820_outline_0108
                                    975 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004AAA 90 06 F7         [24]  976 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004AAD E4               [12]  977 	clr	a
      004AAE F0               [24]  978 	movx	@dptr,a
                                    979 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004AAF 90 06 F3         [24]  980 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004AB2 12 48 69         [24]  981 	lcall	_ak820_outline_0013
      004AB5 70 04            [24]  982 	jnz	00102$
      004AB7 75 82 01         [24]  983 	mov	dpl, #0x01
      004ABA 22               [24]  984 	ret
      004ABB                        985 00102$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004ABB 8E 04            [24]  987 	mov	ar4,r6
      004ABD 8F 05            [24]  988 	mov	ar5,r7
      004ABF 12 4D 8E         [24]  989 	lcall	_ak820_outline_0024
      004AC2 C0 07            [24]  990 	push	ar7
      004AC4 C0 06            [24]  991 	push	ar6
      004AC6 12 BC D2         [24]  992 	lcall	___memcpy
      004AC9 11 F2            [12]  993 	acall	_ak820_tapping_source
      004ACB AD 82            [24]  994 	mov	r5, dpl
      004ACD D0 06            [24]  995 	pop	ar6
      004ACF D0 07            [24]  996 	pop	ar7
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004AD1 BD FF 04         [24]  998 	cjne	r5,#0xff,00104$
      004AD4 75 82 01         [24]  999 	mov	dpl, #0x01
      004AD7 22               [24] 1000 	ret
      004AD8                       1001 00104$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004AD8 74 07            [12] 1003 	mov	a,#0x07
      004ADA 12 37 DA         [24] 1004 	lcall	_ak820_outline_0018
      004ADD FE               [12] 1005 	mov	r6,a
      004ADE A3               [24] 1006 	inc	dptr
      004ADF E0               [24] 1007 	movx	a,@dptr
      004AE0 FF               [12] 1008 	mov	r7,a
      004AE1 90 06 F5         [24] 1009 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004AE4 12 48 C5         [24] 1010 	lcall	_ak820_outline_0065
                                   1011 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004AE7 BE 1A 15         [24] 1012 	cjne	r6,#0x1a,00111$
      004AEA BF 7C 12         [24] 1013 	cjne	r7,#0x7c,00111$
      004AED 90 06 F5         [24] 1014 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004AF0 74 26            [12] 1015 	mov	a,#0x26
      004AF2 F0               [24] 1016 	movx	@dptr,a
      004AF3 74 22            [12] 1017 	mov	a,#0x22
      004AF5 A3               [24] 1018 	inc	dptr
      004AF6 F0               [24] 1019 	movx	@dptr,a
      004AF7 90 06 F7         [24] 1020 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004AFA 74 02            [12] 1021 	mov	a,#0x02
      004AFC F0               [24] 1022 	movx	@dptr,a
      004AFD 80 28            [24] 1023 	sjmp	00112$
      004AFF                       1024 00111$:
                                   1025 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004AFF BE 1B 15         [24] 1026 	cjne	r6,#0x1b,00108$
      004B02 BF 7C 12         [24] 1027 	cjne	r7,#0x7c,00108$
      004B05 90 06 F5         [24] 1028 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B08 74 27            [12] 1029 	mov	a,#0x27
      004B0A F0               [24] 1030 	movx	@dptr,a
      004B0B 74 32            [12] 1031 	mov	a,#0x32
      004B0D A3               [24] 1032 	inc	dptr
      004B0E F0               [24] 1033 	movx	@dptr,a
      004B0F 90 06 F7         [24] 1034 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B12 74 20            [12] 1035 	mov	a,#0x20
      004B14 F0               [24] 1036 	movx	@dptr,a
      004B15 80 10            [24] 1037 	sjmp	00112$
      004B17                       1038 00108$:
                                   1039 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004B17 BE 1E 0D         [24] 1040 	cjne	r6,#0x1e,00112$
      004B1A BF 7C 0A         [24] 1041 	cjne	r7,#0x7c,00112$
      004B1D 90 06 F5         [24] 1042 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B20 74 28            [12] 1043 	mov	a,#0x28
      004B22 F0               [24] 1044 	movx	@dptr,a
      004B23 74 32            [12] 1045 	mov	a,#0x32
      004B25 A3               [24] 1046 	inc	dptr
      004B26 F0               [24] 1047 	movx	@dptr,a
      004B27                       1048 00112$:
                                   1049 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004B27 90 06 F5         [24] 1050 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B2A E0               [24] 1051 	movx	a,@dptr
      004B2B A3               [24] 1052 	inc	dptr
      004B2C E0               [24] 1053 	movx	a,@dptr
      004B2D FF               [12] 1054 	mov	r7,a
                                   1055 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004B2E BF 20 00         [24] 1056 	cjne	r7,#0x20,00242$
      004B31                       1057 00242$:
      004B31 40 05            [24] 1058 	jc	00113$
      004B33 BF 50 00         [24] 1059 	cjne	r7,#0x50,00244$
      004B36                       1060 00244$:
      004B36 40 04            [24] 1061 	jc	00114$
      004B38                       1062 00113$:
      004B38 75 82 01         [24] 1063 	mov	dpl, #0x01
      004B3B 22               [24] 1064 	ret
      004B3C                       1065 00114$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004B3C BF 40 00         [24] 1067 	cjne	r7,#0x40,00246$
      004B3F                       1068 00246$:
      004B3F 40 0C            [24] 1069 	jc	00117$
      004B41 53 07 0F         [24] 1070 	anl	ar7,#0x0f
      004B44 BF 06 00         [24] 1071 	cjne	r7,#0x06,00248$
      004B47                       1072 00248$:
      004B47 40 04            [24] 1073 	jc	00117$
      004B49 75 82 00         [24] 1074 	mov	dpl, #0x00
      004B4C 22               [24] 1075 	ret
      004B4D                       1076 00117$:
                                   1077 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004B4D 90 06 F3         [24] 1078 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B50 12 37 FB         [24] 1079 	lcall	_ak820_outline_0058
      004B53 74 05            [12] 1080 	mov	a,#0x05
      004B55 12 4D 74         [24] 1081 	lcall	_ak820_outline_0015
      004B58 60 20            [24] 1082 	jz	00131$
                                   1083 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004B5A 90 0E 77         [24] 1084 	mov	dptr,#_pending
      004B5D ED               [12] 1085 	mov	a,r5
      004B5E F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004B5F 12 37 EB         [24] 1088 	lcall	_ak820_outline_0035
      004B62 FE               [12] 1089 	mov	r6,a
      004B63 A3               [24] 1090 	inc	dptr
      004B64 E0               [24] 1091 	movx	a,@dptr
      004B65 FF               [12] 1092 	mov	r7,a
      004B66 90 06 E6         [24] 1093 	mov	dptr,#_pending_time
      004B69 12 48 C5         [24] 1094 	lcall	_ak820_outline_0065
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004B6C 90 06 F5         [24] 1096 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B6F 12 37 FB         [24] 1097 	lcall	_ak820_outline_0058
      004B72 90 06 E8         [24] 1098 	mov	dptr,#_pending_code
      004B75 12 48 C5         [24] 1099 	lcall	_ak820_outline_0065
      004B78 81 17            [12] 1100 	ajmp	00132$
      004B7A                       1101 00131$:
                                   1102 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004B7A 90 0E 77         [24] 1103 	mov	dptr,#_pending
      004B7D E0               [24] 1104 	movx	a,@dptr
      004B7E FF               [12] 1105 	mov	r7,a
      004B7F ED               [12] 1106 	mov	a,r5
      004B80 B5 07 02         [24] 1107 	cjne	a,ar7,00251$
      004B83 80 02            [24] 1108 	sjmp	00252$
      004B85                       1109 00251$:
      004B85 61 F1            [24] 1110 	ajmp	00128$
      004B87                       1111 00252$:
                                   1112 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004B87 12 4D BD         [24] 1113 	lcall	_ak820_outline_0157
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004B8A 90 06 F7         [24] 1115 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B8D E0               [24] 1116 	movx	a,@dptr
      004B8E FF               [12] 1117 	mov	r7,a
      004B8F E0               [24] 1118 	movx	a,@dptr
      004B90 60 05            [24] 1119 	jz	00120$
      004B92 8F 82            [24] 1120 	mov	dpl, r7
      004B94 12 80 C8         [24] 1121 	lcall	_add_owned_mods
      004B97                       1122 00120$:
                                   1123 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004B97 90 06 F3         [24] 1124 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B9A 12 37 FB         [24] 1125 	lcall	_ak820_outline_0058
      004B9D 74 07            [12] 1126 	mov	a,#0x07
      004B9F 2E               [12] 1127 	add	a, r6
      004BA0 FB               [12] 1128 	mov	r3,a
      004BA1 E4               [12] 1129 	clr	a
      004BA2 3F               [12] 1130 	addc	a, r7
      004BA3 FC               [12] 1131 	mov	r4,a
      004BA4 90 06 F5         [24] 1132 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BA7 E0               [24] 1133 	movx	a,@dptr
      004BA8 F9               [12] 1134 	mov	r1,a
      004BA9 7A 00            [12] 1135 	mov	r2,#0x00
      004BAB 12 33 FC         [24] 1136 	lcall	_ak820_outline_0123
      004BAE E9               [12] 1137 	mov	a,r1
      004BAF F0               [24] 1138 	movx	@dptr,a
      004BB0 EA               [12] 1139 	mov	a,r2
      004BB1 A3               [24] 1140 	inc	dptr
      004BB2 F0               [24] 1141 	movx	@dptr,a
                                   1142 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004BB3 C3               [12] 1143 	clr	c
      004BB4 04               [12] 1144 	inc	a
      004BB5 99               [12] 1145 	subb	a,r1
      004BB6 50 27            [24] 1146 	jnc	00122$
                                   1147 ;	free result
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004BB8 74 06            [12] 1149 	mov	a,#0x06
      004BBA 12 37 DA         [24] 1150 	lcall	_ak820_outline_0018
      004BBD 54 0F            [12] 1151 	anl	a,#0x0f
      004BBF 44 10            [12] 1152 	orl	a,#0x10
      004BC1 F0               [24] 1153 	movx	@dptr,a
                                   1154 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004BC2 12 42 BC         [24] 1155 	lcall	_ak820_outline_0012
      004BC5 74 01            [12] 1156 	mov	a,#0x01
      004BC7 12 42 F2         [24] 1157 	lcall	_ak820_outline_0066
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004BCA 12 75 6D         [24] 1159 	lcall	_process_record
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004BCD 90 06 F3         [24] 1161 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004BD0 12 37 AC         [24] 1162 	lcall	_ak820_outline_0006
      004BD3 A3               [24] 1163 	inc	dptr
      004BD4 A3               [24] 1164 	inc	dptr
      004BD5 A3               [24] 1165 	inc	dptr
      004BD6 A3               [24] 1166 	inc	dptr
      004BD7 A3               [24] 1167 	inc	dptr
      004BD8 E4               [12] 1168 	clr	a
      004BD9 12 42 F2         [24] 1169 	lcall	_ak820_outline_0066
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004BDC 12 75 6D         [24] 1171 	lcall	_process_record
      004BDF                       1172 00122$:
                                   1173 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004BDF 90 06 F7         [24] 1174 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004BE2 E0               [24] 1175 	movx	a,@dptr
      004BE3 FF               [12] 1176 	mov	r7,a
      004BE4 E0               [24] 1177 	movx	a,@dptr
      004BE5 60 30            [24] 1178 	jz	00132$
                                   1179 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004BE7 8F 82            [24] 1180 	mov	dpl, r7
      004BE9 12 80 D8         [24] 1181 	lcall	_del_owned_mods
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004BEC 12 84 01         [24] 1183 	lcall	_send_keyboard_report
      004BEF 80 26            [24] 1184 	sjmp	00132$
      004BF1                       1185 00128$:
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004BF1 ED               [12] 1187 	mov	a,r5
      004BF2 24 64            [12] 1188 	add	a, #_source_state
      004BF4 FE               [12] 1189 	mov	r6,a
      004BF5 E4               [12] 1190 	clr	a
      004BF6 34 06            [12] 1191 	addc	a, #(_source_state >> 8)
      004BF8 FF               [12] 1192 	mov	r7,a
      004BF9 12 38 30         [24] 1193 	lcall	_ak820_outline_0094
      004BFC FD               [12] 1194 	mov	r5,a
      004BFD 30 E2 17         [24] 1195 	jnb	acc.2,00132$
                                   1196 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004C00 53 05 FB         [24] 1197 	anl	ar5,#0xfb
      004C03 12 43 17         [24] 1198 	lcall	_ak820_outline_0119
      004C06 ED               [12] 1199 	mov	a,r5
      004C07 F0               [24] 1200 	movx	@dptr,a
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004C08 90 06 F5         [24] 1202 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C0B 12 37 FB         [24] 1203 	lcall	_ak820_outline_0058
      004C0E 90 06 EC         [24] 1204 	mov	dptr,#_hold_PARM_2
      004C11 E4               [12] 1205 	clr	a
      004C12 12 42 F2         [24] 1206 	lcall	_ak820_outline_0066
      004C15 31 2C            [12] 1207 	acall	_hold
      004C17                       1208 00132$:
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004C17 75 82 00         [24] 1210 	mov	dpl, #0x00
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004C1A 22               [24] 1212 	ret
                                   1213 ;------------------------------------------------------------
                                   1214 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1215 ;------------------------------------------------------------
                                   1216 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1217 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1218 ;------------------------------------------------------------
                                   1219 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1220 ;	-----------------------------------------
                                   1221 ;	 function ak820_tapping_cancel
                                   1222 ;	-----------------------------------------
      004C1B                       1223 _ak820_tapping_cancel:
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004C1B 12 4D BD         [24] 1225 	lcall	_ak820_outline_0157
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004C1E 7F 00            [12] 1227 	mov	r7,#0x00
      004C20                       1228 00103$:
      004C20 BF 82 00         [24] 1229 	cjne	r7,#0x82,00122$
      004C23                       1230 00122$:
      004C23 50 16            [24] 1231 	jnc	00105$
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004C25 12 4D 7F         [24] 1233 	lcall	_ak820_outline_0021
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004C28 74 02            [12] 1235 	mov	a,#0x02
      004C2A 5C               [12] 1236 	anl	a,r4
      004C2B FB               [12] 1237 	mov	r3,a
      004C2C 53 04 01         [24] 1238 	anl	ar4,#0x01
      004C2F EC               [12] 1239 	mov	a,r4
      004C30 2C               [12] 1240 	add	a,r4
      004C31 42 03            [12] 1241 	orl	ar3,a
      004C33 12 38 63         [24] 1242 	lcall	_ak820_outline_0138
      004C36 EB               [12] 1243 	mov	a,r3
      004C37 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004C38 0F               [12] 1246 	inc	r7
      004C39 80 E5            [24] 1247 	sjmp	00103$
      004C3B                       1248 00105$:
                                   1249 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004C3B 22               [24] 1250 	ret
                                   1251 ;------------------------------------------------------------
                                   1252 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1253 ;------------------------------------------------------------
                                   1254 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1255 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1256 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1257 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1258 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1259 ;------------------------------------------------------------
                                   1260 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1261 ;	-----------------------------------------
                                   1262 ;	 function ak820_oneshot_process
                                   1263 ;	-----------------------------------------
      004C3C                       1264 _ak820_oneshot_process:
      004C3C 12 38 4E         [24] 1265 	lcall	_ak820_outline_0109
      004C3F 90 06 FC         [24] 1266 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004C42 12 38 49         [24] 1267 	lcall	_ak820_outline_0108
                                   1268 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004C45 90 06 FA         [24] 1269 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004C48 E0               [24] 1270 	movx	a,@dptr
      004C49 FF               [12] 1271 	mov	r7,a
      004C4A BF FF 02         [24] 1272 	cjne	r7,#0xff,00248$
      004C4D 80 0B            [24] 1273 	sjmp	00101$
      004C4F                       1274 00248$:
      004C4F C0 07            [24] 1275 	push	ar7
      004C51 12 A6 44         [24] 1276 	lcall	_get_repeat_key_count
      004C54 E5 82            [12] 1277 	mov	a, dpl
      004C56 D0 07            [24] 1278 	pop	ar7
      004C58 60 04            [24] 1279 	jz	00102$
      004C5A                       1280 00101$:
      004C5A 75 82 01         [24] 1281 	mov	dpl, #0x01
      004C5D 22               [24] 1282 	ret
      004C5E                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004C5E 90 06 FC         [24] 1285 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004C61 E0               [24] 1286 	movx	a,@dptr
      004C62 FD               [12] 1287 	mov	r5,a
      004C63 A3               [24] 1288 	inc	dptr
      004C64 E0               [24] 1289 	movx	a,@dptr
      004C65 FB               [12] 1290 	mov	r3,a
      004C66 BB 52 02         [24] 1291 	cjne	r3,#0x52,00250$
      004C69 80 02            [24] 1292 	sjmp	00251$
      004C6B                       1293 00250$:
      004C6B A1 0E            [12] 1294 	ajmp	00116$
      004C6D                       1295 00251$:
      004C6D 8D 04            [24] 1296 	mov	ar4,r5
      004C6F 53 04 E0         [24] 1297 	anl	ar4,#0xe0
      004C72 BC A0 02         [24] 1298 	cjne	r4,#0xa0,00252$
      004C75 80 02            [24] 1299 	sjmp	00253$
      004C77                       1300 00252$:
      004C77 A1 0E            [12] 1301 	ajmp	00116$
      004C79                       1302 00253$:
                                   1303 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004C79 8D 04            [24] 1304 	mov	ar4,r5
      004C7B 53 04 0F         [24] 1305 	anl	ar4,#0x0f
      004C7E 90 06 FE         [24] 1306 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C81 EC               [12] 1307 	mov	a,r4
      004C82 F0               [24] 1308 	movx	@dptr,a
                                   1309 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004C83 ED               [12] 1310 	mov	a,r5
      004C84 30 E4 08         [24] 1311 	jnb	acc.4,00105$
      004C87 EC               [12] 1312 	mov	a,r4
      004C88 C4               [12] 1313 	swap	a
      004C89 54 F0            [12] 1314 	anl	a,#0xf0
      004C8B 90 06 FE         [24] 1315 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C8E F0               [24] 1316 	movx	@dptr,a
      004C8F                       1317 00105$:
                                   1318 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004C8F 90 06 FB         [24] 1319 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004C92 E0               [24] 1320 	movx	a,@dptr
      004C93 60 2D            [24] 1321 	jz	00113$
                                   1322 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004C95 12 4D 7F         [24] 1323 	lcall	_ak820_outline_0021
      004C98 43 04 08         [24] 1324 	orl	ar4,#0x08
      004C9B 12 42 F8         [24] 1325 	lcall	_ak820_outline_0069
                                   1326 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004C9E 53 04 EF         [24] 1327 	anl	ar4,#0xef
      004CA1 12 42 F8         [24] 1328 	lcall	_ak820_outline_0069
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004CA4 90 0E 78         [24] 1330 	mov	dptr,#_ak820_oneshot_target
      004CA7 E0               [24] 1331 	movx	a,@dptr
      004CA8 FC               [12] 1332 	mov	r4,a
      004CA9 BC FF 02         [24] 1333 	cjne	r4,#0xff,00256$
      004CAC 80 09            [24] 1334 	sjmp	00107$
      004CAE                       1335 00256$:
      004CAE 12 4D A8         [24] 1336 	lcall	_ak820_outline_0078
      004CB1 43 04 10         [24] 1337 	orl	ar4,#0x10
      004CB4 12 42 F8         [24] 1338 	lcall	_ak820_outline_0069
      004CB7                       1339 00107$:
                                   1340 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004CB7 90 06 FE         [24] 1341 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CBA E0               [24] 1342 	movx	a,@dptr
      004CBB F5 82            [12] 1343 	mov	dpl,a
      004CBD 12 7A 9D         [24] 1344 	lcall	_register_mods
      004CC0 80 48            [24] 1345 	sjmp	00114$
      004CC2                       1346 00113$:
                                   1347 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004CC2 12 4D 7F         [24] 1348 	lcall	_ak820_outline_0021
      004CC5 30 E3 42         [24] 1349 	jnb	acc.3,00114$
                                   1350 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004CC8 EC               [12] 1351 	mov	a,r4
      004CC9 20 E4 24         [24] 1352 	jb	acc.4,00109$
                                   1353 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004CCC 90 06 F8         [24] 1354 	mov	dptr,#_ak820_oneshot_mods
      004CCF E0               [24] 1355 	movx	a,@dptr
      004CD0 F4               [12] 1356 	cpl	a
      004CD1 FC               [12] 1357 	mov	r4,a
      004CD2 90 06 FE         [24] 1358 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CD5 E0               [24] 1359 	movx	a,@dptr
      004CD6 FB               [12] 1360 	mov	r3,a
      004CD7 52 04            [12] 1361 	anl	ar4,a
      004CD9 8C 82            [24] 1362 	mov	dpl, r4
      004CDB C0 06            [24] 1363 	push	ar6
      004CDD C0 05            [24] 1364 	push	ar5
      004CDF C0 03            [24] 1365 	push	ar3
      004CE1 12 80 C8         [24] 1366 	lcall	_add_owned_mods
      004CE4 D0 03            [24] 1367 	pop	ar3
      004CE6 D0 05            [24] 1368 	pop	ar5
      004CE8 D0 06            [24] 1369 	pop	ar6
                                   1370 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004CEA 90 06 F8         [24] 1371 	mov	dptr,#_ak820_oneshot_mods
      004CED E0               [24] 1372 	movx	a,@dptr
      004CEE 4B               [12] 1373 	orl	a,r3
      004CEF F0               [24] 1374 	movx	@dptr,a
      004CF0                       1375 00109$:
                                   1376 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004CF0 90 06 FE         [24] 1377 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CF3 E0               [24] 1378 	movx	a,@dptr
      004CF4 F5 82            [12] 1379 	mov	dpl,a
      004CF6 C0 06            [24] 1380 	push	ar6
      004CF8 C0 05            [24] 1381 	push	ar5
      004CFA 12 7A B1         [24] 1382 	lcall	_unregister_mods
      004CFD D0 05            [24] 1383 	pop	ar5
      004CFF D0 06            [24] 1384 	pop	ar6
                                   1385 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004D01 12 4D A8         [24] 1386 	lcall	_ak820_outline_0078
      004D04 53 04 E7         [24] 1387 	anl	ar4,#0xe7
      004D07 12 42 F8         [24] 1388 	lcall	_ak820_outline_0069
      004D0A                       1389 00114$:
                                   1390 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004D0A 75 82 00         [24] 1391 	mov	dpl, #0x00
      004D0D 22               [24] 1392 	ret
      004D0E                       1393 00116$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004D0E 90 06 FB         [24] 1395 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004D11 E0               [24] 1396 	movx	a,@dptr
      004D12 60 5C            [24] 1397 	jz	00124$
      004D14 90 06 FC         [24] 1398 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004D17 12 38 2A         [24] 1399 	lcall	_ak820_outline_0082
      004D1A C3               [12] 1400 	clr	c
      004D1B 74 01            [12] 1401 	mov	a,#0x01
      004D1D 9D               [12] 1402 	subb	a,r5
      004D1E E4               [12] 1403 	clr	a
      004D1F 9E               [12] 1404 	subb	a,r6
      004D20 50 4E            [24] 1405 	jnc	00124$
                                   1406 ;	free result
                                   1407 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004D22 C3               [12] 1408 	clr	c
      004D23 ED               [12] 1409 	mov	a,r5
      004D24 94 E0            [12] 1410 	subb	a,#0xe0
      004D26 EE               [12] 1411 	mov	a,r6
      004D27 94 00            [12] 1412 	subb	a,#0x00
      004D29 40 07            [24] 1413 	jc	00129$
      004D2B 74 E7            [12] 1414 	mov	a,#0xe7
      004D2D 9D               [12] 1415 	subb	a,r5
      004D2E E4               [12] 1416 	clr	a
      004D2F 9E               [12] 1417 	subb	a,r6
      004D30 50 3E            [24] 1418 	jnc	00124$
                                   1419 ;	free result
      004D32                       1420 00129$:
                                   1421 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004D32 74 AE            [12] 1422 	mov	a,#0x100 - 0x52
      004D34 2E               [12] 1423 	add	a,r6
      004D35 50 09            [24] 1424 	jnc	00165$
      004D37 C3               [12] 1425 	clr	c
      004D38 74 DF            [12] 1426 	mov	a,#0xdf
      004D3A 9D               [12] 1427 	subb	a,r5
      004D3B 74 52            [12] 1428 	mov	a,#0x52
      004D3D 9E               [12] 1429 	subb	a,r6
      004D3E 50 30            [24] 1430 	jnc	00124$
                                   1431 ;	free result
                                   1432 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004D40                       1433 00165$:
      004D40 7E 00            [12] 1434 	mov	r6,#0x00
      004D42                       1435 00131$:
      004D42 BE 82 00         [24] 1436 	cjne	r6,#0x82,00265$
      004D45                       1437 00265$:
      004D45 50 12            [24] 1438 	jnc	00120$
                                   1439 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004D47 EE               [12] 1440 	mov	a,r6
      004D48 12 4D AF         [24] 1441 	lcall	_ak820_outline_0083
      004D4B 30 E3 08         [24] 1442 	jnb	acc.3,00132$
      004D4E 43 03 10         [24] 1443 	orl	ar3,#0x10
      004D51 12 38 59         [24] 1444 	lcall	_ak820_outline_0127
      004D54 EB               [12] 1445 	mov	a,r3
      004D55 F0               [24] 1446 	movx	@dptr,a
      004D56                       1447 00132$:
                                   1448 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004D56 0E               [12] 1449 	inc	r6
      004D57 80 E9            [24] 1450 	sjmp	00131$
      004D59                       1451 00120$:
                                   1452 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004D59 90 06 F8         [24] 1453 	mov	dptr,#_ak820_oneshot_mods
      004D5C E0               [24] 1454 	movx	a,@dptr
      004D5D FE               [12] 1455 	mov	r6,a
      004D5E E0               [24] 1456 	movx	a,@dptr
      004D5F 60 0F            [24] 1457 	jz	00124$
                                   1458 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004D61 90 06 F9         [24] 1459 	mov	dptr,#_ak820_oneshot_consumed
      004D64 EE               [12] 1460 	mov	a,r6
      004D65 F0               [24] 1461 	movx	@dptr,a
                                   1462 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004D66 90 0E 78         [24] 1463 	mov	dptr,#_ak820_oneshot_target
      004D69 EF               [12] 1464 	mov	a,r7
      004D6A F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004D6B 90 06 F8         [24] 1467 	mov	dptr,#_ak820_oneshot_mods
      004D6E E4               [12] 1468 	clr	a
      004D6F F0               [24] 1469 	movx	@dptr,a
      004D70                       1470 00124$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004D70 75 82 01         [24] 1472 	mov	dpl, #0x01
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004D73 22               [24] 1474 	ret
                                   1475 	.area CSEG    (CODE)
                                   1476 	.area CONST   (CODE)
                                   1477 	.area XINIT   (CODE)
      00C592                       1478 __xinit__pending:
      00C592 FF                    1479 	.db #0xff	; 255
      00C593                       1480 __xinit__ak820_oneshot_target:
      00C593 FF                    1481 	.db #0xff	; 255
                                   1482 	.area CABS    (ABS,CODE)
                                   1483 
                                   1484 ; Experimental exact instruction outlining.
                                   1485 	.globl _ak820_outline_0002
                                   1486 	.globl _ak820_outline_0006
                                   1487 	.globl _ak820_outline_0010
                                   1488 	.globl _ak820_outline_0012
                                   1489 	.globl _ak820_outline_0013
                                   1490 	.globl _ak820_outline_0015
                                   1491 	.globl _ak820_outline_0017
                                   1492 	.globl _ak820_outline_0018
                                   1493 	.globl _ak820_outline_0021
                                   1494 	.globl _ak820_outline_0024
                                   1495 	.globl _ak820_outline_0034
                                   1496 	.globl _ak820_outline_0035
                                   1497 	.globl _ak820_outline_0051
                                   1498 	.globl _ak820_outline_0058
                                   1499 	.globl _ak820_outline_0065
                                   1500 	.globl _ak820_outline_0066
                                   1501 	.globl _ak820_outline_0069
                                   1502 	.globl _ak820_outline_0078
                                   1503 	.globl _ak820_outline_0082
                                   1504 	.globl _ak820_outline_0083
                                   1505 	.globl _ak820_outline_0094
                                   1506 	.globl _ak820_outline_0102
                                   1507 	.globl _ak820_outline_0108
                                   1508 	.globl _ak820_outline_0109
                                   1509 	.globl _ak820_outline_0119
                                   1510 	.globl _ak820_outline_0123
                                   1511 	.globl _ak820_outline_0125
                                   1512 	.globl _ak820_outline_0127
                                   1513 	.globl _ak820_outline_0138
                                   1514 	.globl _ak820_outline_0157
                                   1515 	.globl _ak820_outline_0160
                                   1516 	.globl _ak820_outline_0162
                                   1517 
                                   1518 	.area CSEG (CODE)
                                   1519 ; function ak820_outline_0015
      004D74                       1520 _ak820_outline_0015:
      004D74 2E               [12] 1521 	add	a,r6
      004D75 FB               [12] 1522 	mov	r3,a
      004D76 E4               [12] 1523 	clr	a
      004D77 3F               [12] 1524 	addc	a,r7
      004D78 FC               [12] 1525 	mov	r4,a
      004D79 8B 82            [24] 1526 	mov	dpl,r3
      004D7B 8C 83            [24] 1527 	mov	dph,r4
      004D7D E0               [24] 1528 	movx	a,@dptr
      004D7E 22               [24] 1529 	ret
                                   1530 
                                   1531 	.area CSEG (CODE)
                                   1532 ; function ak820_outline_0021
      004D7F                       1533 _ak820_outline_0021:
      004D7F EF               [12] 1534 	mov	a,r7
      004D80 24 64            [12] 1535 	add	a,#_source_state
      004D82 FD               [12] 1536 	mov	r5,a
      004D83 E4               [12] 1537 	clr	a
      004D84 34 06            [12] 1538 	addc	a,#(_source_state>>8)
      004D86 FE               [12] 1539 	mov	r6,a
      004D87 8D 82            [24] 1540 	mov	dpl,r5
      004D89 8E 83            [24] 1541 	mov	dph,r6
      004D8B E0               [24] 1542 	movx	a,@dptr
      004D8C FC               [12] 1543 	mov	r4,a
      004D8D 22               [24] 1544 	ret
                                   1545 
                                   1546 	.area CSEG (CODE)
                                   1547 ; function ak820_outline_0024
      004D8E                       1548 _ak820_outline_0024:
      004D8E 90 0E 67         [24] 1549 	mov	dptr,#___memcpy_PARM_2
      004D91 EC               [12] 1550 	mov	a,r4
      004D92 F0               [24] 1551 	movx	@dptr,a
      004D93 ED               [12] 1552 	mov	a,r5
      004D94 A3               [24] 1553 	inc	dptr
      004D95 F0               [24] 1554 	movx	@dptr,a
      004D96 E4               [12] 1555 	clr	a
      004D97 A3               [24] 1556 	inc	dptr
      004D98 F0               [24] 1557 	movx	@dptr,a
      004D99 90 0E 6A         [24] 1558 	mov	dptr,#___memcpy_PARM_3
      004D9C 74 02            [12] 1559 	mov	a,#0x02
      004D9E F0               [24] 1560 	movx	@dptr,a
      004D9F E4               [12] 1561 	clr	a
      004DA0 A3               [24] 1562 	inc	dptr
      004DA1 F0               [24] 1563 	movx	@dptr,a
      004DA2 90 06 EA         [24] 1564 	mov	dptr,#_ak820_tapping_source_PARM_1
      004DA5 F5 F0            [12] 1565 	mov	b,a
      004DA7 22               [24] 1566 	ret
                                   1567 
                                   1568 	.area CSEG (CODE)
                                   1569 ; function ak820_outline_0078
      004DA8                       1570 _ak820_outline_0078:
      004DA8 8D 82            [24] 1571 	mov	dpl,r5
      004DAA 8E 83            [24] 1572 	mov	dph,r6
      004DAC E0               [24] 1573 	movx	a,@dptr
      004DAD FC               [12] 1574 	mov	r4,a
      004DAE 22               [24] 1575 	ret
                                   1576 
                                   1577 	.area CSEG (CODE)
                                   1578 ; function ak820_outline_0083
      004DAF                       1579 _ak820_outline_0083:
      004DAF 24 64            [12] 1580 	add	a,#_source_state
      004DB1 FC               [12] 1581 	mov	r4,a
      004DB2 E4               [12] 1582 	clr	a
      004DB3 34 06            [12] 1583 	addc	a,#(_source_state>>8)
      004DB5 FD               [12] 1584 	mov	r5,a
      004DB6 8C 82            [24] 1585 	mov	dpl,r4
      004DB8 8D 83            [24] 1586 	mov	dph,r5
      004DBA E0               [24] 1587 	movx	a,@dptr
      004DBB FB               [12] 1588 	mov	r3,a
      004DBC 22               [24] 1589 	ret
                                   1590 
                                   1591 	.area CSEG (CODE)
                                   1592 ; function ak820_outline_0157
      004DBD                       1593 _ak820_outline_0157:
      004DBD 90 0E 77         [24] 1594 	mov	dptr,#_pending
      004DC0 74 FF            [12] 1595 	mov	a,#0xff
      004DC2 F0               [24] 1596 	movx	@dptr,a
      004DC3 22               [24] 1597 	ret
