                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _ak820_combo_valid_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _ak820_combo_process_sloc0_1_0:
      000001                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000422                        551 _combos:
      000422                        552 	.ds 32
      000442                        553 _saved:
      000442                        554 	.ds 9
      00044B                        555 _active:
      00044B                        556 	.ds 1
      00044C                        557 _ak820_combo_valid_entry_10000_594:
      00044C                        558 	.ds 2
      00044E                        559 _ak820_combo_reload_entry_30000_606:
      00044E                        560 	.ds 10
      000458                        561 _ak820_combo_tick_now_10000_611:
      000458                        562 	.ds 2
      00045A                        563 _ak820_combo_process_record_10000_614:
      00045A                        564 	.ds 2
      00045C                        565 _ak820_combo_process_eligible_10001_629:
      00045C                        566 	.ds 1
      00045D                        567 _ak820_combo_process_i_40001_632:
      00045D                        568 	.ds 1
      00045E                        569 _ak820_combo_process_a_50001_633:
      00045E                        570 	.ds 1
      00045F                        571 _ak820_combo_process_b_50001_633:
      00045F                        572 	.ds 1
                                    573 ;--------------------------------------------------------
                                    574 ; absolute external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area XABS    (ABS,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; initialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XISEG   (XDATA)
      000E75                        581 _first:
      000E75                        582 	.ds 1
      000E76                        583 _second:
      000E76                        584 	.ds 1
                                    585 	.area HOME    (CODE)
                                    586 	.area GSINIT0 (CODE)
                                    587 	.area GSINIT1 (CODE)
                                    588 	.area GSINIT2 (CODE)
                                    589 	.area GSINIT3 (CODE)
                                    590 	.area GSINIT4 (CODE)
                                    591 	.area GSINIT5 (CODE)
                                    592 	.area GSINIT  (CODE)
                                    593 	.area GSFINAL (CODE)
                                    594 	.area CSEG    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; global & static initialisations
                                    597 ;--------------------------------------------------------
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; Home
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area HOME    (CODE)
                                    607 ;--------------------------------------------------------
                                    608 ; code
                                    609 ;--------------------------------------------------------
                                    610 	.area CSEG    (CODE)
                                    611 ;------------------------------------------------------------
                                    612 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    613 ;------------------------------------------------------------
                                    614 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    615 ;------------------------------------------------------------
                                    616 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    617 ;	-----------------------------------------
                           000007   618 	ar7 = 0x07
                           000006   619 	ar6 = 0x06
                           000005   620 	ar5 = 0x05
                           000004   621 	ar4 = 0x04
                           000003   622 	ar3 = 0x03
                           000002   623 	ar2 = 0x02
                           000001   624 	ar1 = 0x01
                           000000   625 	ar0 = 0x00
                                    626 ;	 function ak820_combo_valid
                                    627 ;	-----------------------------------------
      003468                        628 _ak820_combo_valid:
      003468 12 38 4E         [24]  629 	lcall	_ak820_outline_0109
      00346B 90 04 4C         [24]  630 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      00346E 12 38 49         [24]  631 	lcall	_ak820_outline_0108
                                    632 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (entry->input[2] || entry->input[3]) return false;
      003471 90 04 4C         [24]  633 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      003474 12 37 AC         [24]  634 	lcall	_ak820_outline_0006
      003477 A3               [24]  635 	inc	dptr
      003478 A3               [24]  636 	inc	dptr
      003479 A3               [24]  637 	inc	dptr
      00347A A3               [24]  638 	inc	dptr
      00347B E0               [24]  639 	movx	a,@dptr
      00347C FC               [12]  640 	mov	r4,a
      00347D A3               [24]  641 	inc	dptr
      00347E E0               [24]  642 	movx	a,@dptr
      00347F 4C               [12]  643 	orl	a,r4
      003480 70 0B            [24]  644 	jnz	00101$
      003482 74 06            [12]  645 	mov	a,#0x06
      003484 12 37 DA         [24]  646 	lcall	_ak820_outline_0018
      003487 FC               [12]  647 	mov	r4,a
      003488 A3               [24]  648 	inc	dptr
      003489 E0               [24]  649 	movx	a,@dptr
      00348A 4C               [12]  650 	orl	a,r4
      00348B 60 04            [24]  651 	jz	00102$
      00348D                        652 00101$:
      00348D 75 82 00         [24]  653 	mov	dpl, #0x00
      003490 22               [24]  654 	ret
      003491                        655 00102$:
                                    656 ;	keyboards/ajazz/ak820/ak820_combo.c:25: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      003491 8E 04            [24]  657 	mov	ar4,r6
      003493 8F 05            [24]  658 	mov	ar5,r7
      003495 12 37 EB         [24]  659 	lcall	_ak820_outline_0035
      003498 FA               [12]  660 	mov	r2,a
      003499 A3               [24]  661 	inc	dptr
      00349A E0               [24]  662 	movx	a,@dptr
      00349B FB               [12]  663 	mov	r3,a
      00349C 12 38 59         [24]  664 	lcall	_ak820_outline_0127
      00349F 12 38 12         [24]  665 	lcall	_ak820_outline_0064
      0034A2 EA               [12]  666 	mov	a,r2
      0034A3 4C               [12]  667 	orl	a,r4
      0034A4 F8               [12]  668 	mov	r0,a
      0034A5 EB               [12]  669 	mov	a,r3
      0034A6 4D               [12]  670 	orl	a,r5
      0034A7 48               [12]  671 	orl	a,r0
      0034A8 70 12            [24]  672 	jnz	00105$
      0034AA 74 08            [12]  673 	mov	a,#0x08
      0034AC 12 37 DA         [24]  674 	lcall	_ak820_outline_0018
      0034AF F8               [12]  675 	mov	r0,a
      0034B0 A3               [24]  676 	inc	dptr
      0034B1 E0               [24]  677 	movx	a,@dptr
      0034B2 48               [12]  678 	orl	a,r0
      0034B3 B4 01 00         [24]  679 	cjne	a,#0x01,00187$
      0034B6                        680 00187$:
      0034B6 92 00            [24]  681 	mov  _ak820_combo_valid_sloc0_1_0,c
      0034B8 12 38 68         [24]  682 	lcall	_ak820_outline_0150
      0034BB 22               [24]  683 	ret
      0034BC                        684 00105$:
                                    685 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[0] == entry->input[1]) return false;
      0034BC EC               [12]  686 	mov	a,r4
      0034BD B5 02 08         [24]  687 	cjne	a,ar2,00107$
      0034C0 ED               [12]  688 	mov	a,r5
      0034C1 B5 03 04         [24]  689 	cjne	a,ar3,00107$
      0034C4 75 82 00         [24]  690 	mov	dpl, #0x00
      0034C7 22               [24]  691 	ret
      0034C8                        692 00107$:
                                    693 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!COMBO_INPUT(entry->input[0])) return false;
      0034C8 C3               [12]  694 	clr	c
      0034C9 EC               [12]  695 	mov	a,r4
      0034CA 94 04            [12]  696 	subb	a,#0x04
      0034CC ED               [12]  697 	mov	a,r5
      0034CD 94 00            [12]  698 	subb	a,#0x00
      0034CF 40 07            [24]  699 	jc	00108$
      0034D1 74 A4            [12]  700 	mov	a,#0xa4
      0034D3 9C               [12]  701 	subb	a,r4
      0034D4 E4               [12]  702 	clr	a
      0034D5 9D               [12]  703 	subb	a,r5
      0034D6 50 04            [24]  704 	jnc	00109$
                                    705 ;	free result
      0034D8                        706 00108$:
      0034D8 75 82 00         [24]  707 	mov	dpl, #0x00
      0034DB 22               [24]  708 	ret
      0034DC                        709 00109$:
                                    710 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (!COMBO_INPUT(entry->input[1])) return false;
      0034DC C3               [12]  711 	clr	c
      0034DD EA               [12]  712 	mov	a,r2
      0034DE 94 04            [12]  713 	subb	a,#0x04
      0034E0 EB               [12]  714 	mov	a,r3
      0034E1 94 00            [12]  715 	subb	a,#0x00
      0034E3 40 07            [24]  716 	jc	00111$
      0034E5 74 A4            [12]  717 	mov	a,#0xa4
      0034E7 9A               [12]  718 	subb	a,r2
      0034E8 E4               [12]  719 	clr	a
      0034E9 9B               [12]  720 	subb	a,r3
      0034EA 50 04            [24]  721 	jnc	00112$
                                    722 ;	free result
      0034EC                        723 00111$:
      0034EC 75 82 00         [24]  724 	mov	dpl, #0x00
      0034EF 22               [24]  725 	ret
      0034F0                        726 00112$:
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:29: return COMBO_OUTPUT(entry->output);
      0034F0 74 08            [12]  728 	mov	a,#0x08
      0034F2 12 37 F3         [24]  729 	lcall	_ak820_outline_0036
      0034F5 12 37 C6         [24]  730 	lcall	_ak820_outline_0010
      0034F8 74 E0            [12]  731 	mov	a,#0x100 - 0x20
      0034FA 2D               [12]  732 	add	a,r5
      0034FB 40 20            [24]  733 	jc	00116$
      0034FD BE 04 00         [24]  734 	cjne	r6,#0x04,00195$
      003500                        735 00195$:
      003500 40 05            [24]  736 	jc	00124$
      003502 EE               [12]  737 	mov	a,r6
      003503 24 5B            [12]  738 	add	a,#0xff - 0xa4
      003505 50 1A            [24]  739 	jnc	00117$
                                    740 ;	free result
      003507                        741 00124$:
      003507 90 04 4C         [24]  742 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      00350A 12 37 FB         [24]  743 	lcall	_ak820_outline_0058
      00350D 74 08            [12]  744 	mov	a,#0x08
      00350F 12 37 DA         [24]  745 	lcall	_ak820_outline_0018
      003512 FF               [12]  746 	mov	r7,a
      003513 BF E0 00         [24]  747 	cjne	r7,#0xe0,00198$
      003516                        748 00198$:
      003516 40 05            [24]  749 	jc	00116$
      003518 EF               [12]  750 	mov	a,r7
      003519 24 18            [12]  751 	add	a,#0xff - 0xe7
      00351B 50 04            [24]  752 	jnc	00117$
                                    753 ;	free result
      00351D                        754 00116$:
                                    755 ;	assignBit
      00351D C2 00            [12]  756 	clr	_ak820_combo_valid_sloc0_1_0
      00351F 80 02            [24]  757 	sjmp	00118$
      003521                        758 00117$:
                                    759 ;	assignBit
      003521 D2 00            [12]  760 	setb	_ak820_combo_valid_sloc0_1_0
      003523                        761 00118$:
      003523 A2 00            [12]  762 	mov	c,_ak820_combo_valid_sloc0_1_0
      003525 12 38 68         [24]  763 	lcall	_ak820_outline_0150
                                    764 ;	keyboards/ajazz/ak820/ak820_combo.c:30: }
      003528 22               [24]  765 	ret
                                    766 ;------------------------------------------------------------
                                    767 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    768 ;------------------------------------------------------------
                                    769 ;	keyboards/ajazz/ak820/ak820_combo.c:33: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    770 ;	-----------------------------------------
                                    771 ;	 function ak820_combo_cancel
                                    772 ;	-----------------------------------------
      003529                        773 _ak820_combo_cancel:
      003529 90 0E 76         [24]  774 	mov	dptr,#_second
      00352C 74 FF            [12]  775 	mov	a,#0xff
      00352E F0               [24]  776 	movx	@dptr,a
      00352F 90 0E 75         [24]  777 	mov	dptr,#_first
      003532 F0               [24]  778 	movx	@dptr,a
      003533 90 04 4B         [24]  779 	mov	dptr,#_active
      003536 E4               [12]  780 	clr	a
      003537 F0               [24]  781 	movx	@dptr,a
      003538 22               [24]  782 	ret
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    785 ;------------------------------------------------------------
                                    786 ;i             Allocated with name '_ak820_combo_reload_i_20000_605'
                                    787 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_606'
                                    788 ;------------------------------------------------------------
                                    789 ;	keyboards/ajazz/ak820/ak820_combo.c:34: void ak820_combo_reload(void) {
                                    790 ;	-----------------------------------------
                                    791 ;	 function ak820_combo_reload
                                    792 ;	-----------------------------------------
      003539                        793 _ak820_combo_reload:
                                    794 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003539 7F 00            [12]  795 	mov	r7,#0x00
      00353B                        796 00105$:
      00353B BF 08 00         [24]  797 	cjne	r7,#0x08,00131$
      00353E                        798 00131$:
      00353E 40 01            [24]  799 	jc	00132$
      003540 22               [24]  800 	ret
      003541                        801 00132$:
                                    802 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].a = 0;
      003541 EF               [12]  803 	mov	a,r7
      003542 12 38 82         [24]  804 	lcall	_ak820_outline_0191
      003545 24 22            [12]  805 	add	a, #_combos
      003547 FD               [12]  806 	mov	r5,a
      003548 74 04            [12]  807 	mov	a,#(_combos >> 8)
      00354A 35 F0            [12]  808 	addc	a, b
      00354C FE               [12]  809 	mov	r6,a
      00354D 8D 03            [24]  810 	mov	ar3,r5
      00354F 8E 04            [24]  811 	mov	ar4,r6
      003551 12 33 FC         [24]  812 	lcall	_ak820_outline_0123
      003554 E4               [12]  813 	clr	a
      003555 F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_combo.c:38: if (!dynamic_keymap_get_combo(i, &entry)) {
      003556 90 0B B5         [24]  816 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003559 74 4E            [12]  817 	mov	a,#_ak820_combo_reload_entry_30000_606
      00355B F0               [24]  818 	movx	@dptr,a
      00355C 74 04            [12]  819 	mov	a,#(_ak820_combo_reload_entry_30000_606 >> 8)
      00355E 12 38 18         [24]  820 	lcall	_ak820_outline_0075
      003561 8F 82            [24]  821 	mov	dpl, r7
      003563 C0 07            [24]  822 	push	ar7
      003565 C0 06            [24]  823 	push	ar6
      003567 C0 05            [24]  824 	push	ar5
      003569 C0 04            [24]  825 	push	ar4
      00356B C0 03            [24]  826 	push	ar3
      00356D 12 8A 8E         [24]  827 	lcall	_dynamic_keymap_get_combo
      003570 12 38 53         [24]  828 	lcall	_ak820_outline_0124
      003573 D0 03            [24]  829 	pop	ar3
      003575 D0 04            [24]  830 	pop	ar4
      003577 D0 05            [24]  831 	pop	ar5
      003579 D0 06            [24]  832 	pop	ar6
      00357B D0 07            [24]  833 	pop	ar7
      00357D 45 F0            [12]  834 	orl	a,b
      00357F 70 28            [24]  835 	jnz	00106$
                                    836 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = entry.input[0];
      003581 90 04 4E         [24]  837 	mov	dptr,#_ak820_combo_reload_entry_30000_606
      003584 E0               [24]  838 	movx	a,@dptr
      003585 12 33 FC         [24]  839 	lcall	_ak820_outline_0123
      003588 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_combo.c:40: combos[i].b = entry.input[1];
      003589 74 01            [12]  842 	mov	a,#0x01
      00358B 2D               [12]  843 	add	a, r5
      00358C FB               [12]  844 	mov	r3,a
      00358D E4               [12]  845 	clr	a
      00358E 3E               [12]  846 	addc	a, r6
      00358F FC               [12]  847 	mov	r4,a
      003590 90 04 50         [24]  848 	mov	dptr,#(_ak820_combo_reload_entry_30000_606 + 0x0002)
      003593 E0               [24]  849 	movx	a,@dptr
      003594 12 33 FC         [24]  850 	lcall	_ak820_outline_0123
      003597 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].output = entry.output;
      003598 74 02            [12]  853 	mov	a,#0x02
      00359A 12 38 77         [24]  854 	lcall	_ak820_outline_0163
      00359D 90 04 56         [24]  855 	mov	dptr,#(_ak820_combo_reload_entry_30000_606 + 0x0008)
      0035A0 12 38 43         [24]  856 	lcall	_ak820_outline_0103
      0035A3 12 38 63         [24]  857 	lcall	_ak820_outline_0138
      0035A6 12 38 24         [24]  858 	lcall	_ak820_outline_0080
      0035A9                        859 00106$:
                                    860 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035A9 0F               [12]  861 	inc	r7
                                    862 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0035AA A1 3B            [12]  863 	ajmp	00105$
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'flush'
                                    866 ;------------------------------------------------------------
                                    867 ;	keyboards/ajazz/ak820/ak820_combo.c:45: static void flush(void) {
                                    868 ;	-----------------------------------------
                                    869 ;	 function flush
                                    870 ;	-----------------------------------------
      0035AC                        871 _flush:
                                    872 ;	keyboards/ajazz/ak820/ak820_combo.c:46: first = NONE;
      0035AC 90 0E 75         [24]  873 	mov	dptr,#_first
      0035AF 74 FF            [12]  874 	mov	a,#0xff
      0035B1 F0               [24]  875 	movx	@dptr,a
                                    876 ;	keyboards/ajazz/ak820/ak820_combo.c:47: process_record(&saved);
      0035B2 90 04 42         [24]  877 	mov	dptr,#_saved
                                    878 ;	keyboards/ajazz/ak820/ak820_combo.c:48: }
      0035B5 02 75 6D         [24]  879 	ljmp	_process_record
                                    880 ;------------------------------------------------------------
                                    881 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    882 ;------------------------------------------------------------
                                    883 ;now           Allocated with name '_ak820_combo_tick_now_10000_611'
                                    884 ;------------------------------------------------------------
                                    885 ;	keyboards/ajazz/ak820/ak820_combo.c:49: void ak820_combo_tick(uint16_t now) {
                                    886 ;	-----------------------------------------
                                    887 ;	 function ak820_combo_tick
                                    888 ;	-----------------------------------------
      0035B8                        889 _ak820_combo_tick:
      0035B8 12 38 4E         [24]  890 	lcall	_ak820_outline_0109
      0035BB 90 04 58         [24]  891 	mov	dptr,#_ak820_combo_tick_now_10000_611
      0035BE 12 38 49         [24]  892 	lcall	_ak820_outline_0108
                                    893 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      0035C1 12 38 7D         [24]  894 	lcall	_ak820_outline_0187
      0035C4 FF               [12]  895 	mov	r7,a
      0035C5 BF FF 01         [24]  896 	cjne	r7,#0xff,00128$
      0035C8 22               [24]  897 	ret
      0035C9                        898 00128$:
      0035C9 90 04 4B         [24]  899 	mov	dptr,#_active
      0035CC E0               [24]  900 	movx	a,@dptr
      0035CD 70 1E            [24]  901 	jnz	00105$
      0035CF 90 04 44         [24]  902 	mov	dptr,#(_saved + 0x0002)
      0035D2 12 37 FB         [24]  903 	lcall	_ak820_outline_0058
      0035D5 90 04 58         [24]  904 	mov	dptr,#_ak820_combo_tick_now_10000_611
      0035D8 12 38 12         [24]  905 	lcall	_ak820_outline_0064
      0035DB EC               [12]  906 	mov	a,r4
      0035DC C3               [12]  907 	clr	c
      0035DD 9E               [12]  908 	subb	a,r6
      0035DE FE               [12]  909 	mov	r6,a
      0035DF ED               [12]  910 	mov	a,r5
      0035E0 9F               [12]  911 	subb	a,r7
      0035E1 FF               [12]  912 	mov	r7,a
      0035E2 C3               [12]  913 	clr	c
      0035E3 EE               [12]  914 	mov	a,r6
      0035E4 94 28            [12]  915 	subb	a,#0x28
      0035E6 EF               [12]  916 	mov	a,r7
      0035E7 94 00            [12]  917 	subb	a,#0x00
      0035E9 40 02            [24]  918 	jc	00105$
                                    919 ;	keyboards/ajazz/ak820/ak820_combo.c:51: }
      0035EB A1 AC            [24]  920 	ajmp	_flush
      0035ED                        921 00105$:
      0035ED 22               [24]  922 	ret
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'ak820_combo_process'
                                    925 ;------------------------------------------------------------
                                    926 ;record        Allocated with name '_ak820_combo_process_record_10000_614'
                                    927 ;id            Allocated with name '_ak820_combo_process_id_10000_615'
                                    928 ;code          Allocated with name '_ak820_combo_process_code_10000_615'
                                    929 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_629'
                                    930 ;previous      Allocated with name '_ak820_combo_process_previous_30001_631'
                                    931 ;i             Allocated with name '_ak820_combo_process_i_40001_632'
                                    932 ;a             Allocated with name '_ak820_combo_process_a_50001_633'
                                    933 ;b             Allocated with name '_ak820_combo_process_b_50001_633'
                                    934 ;------------------------------------------------------------
                                    935 ;	keyboards/ajazz/ak820/ak820_combo.c:52: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    936 ;	-----------------------------------------
                                    937 ;	 function ak820_combo_process
                                    938 ;	-----------------------------------------
      0035EE                        939 _ak820_combo_process:
      0035EE 12 38 4E         [24]  940 	lcall	_ak820_outline_0109
      0035F1 90 04 5A         [24]  941 	mov	dptr,#_ak820_combo_process_record_10000_614
      0035F4 12 38 49         [24]  942 	lcall	_ak820_outline_0108
                                    943 ;	keyboards/ajazz/ak820/ak820_combo.c:53: uint8_t id, code = record->keycode;
      0035F7 90 04 5A         [24]  944 	mov	dptr,#_ak820_combo_process_record_10000_614
      0035FA 12 37 B6         [24]  945 	lcall	_ak820_outline_0008
      0035FD FC               [12]  946 	mov	r4,a
      0035FE A3               [24]  947 	inc	dptr
      0035FF E0               [24]  948 	movx	a,@dptr
      003600 FD               [12]  949 	mov	r5,a
      003601 8C 03            [24]  950 	mov	ar3,r4
                                    951 ;	keyboards/ajazz/ak820/ak820_combo.c:54: if (IS_NOEVENT(record->event)) return true;
      003603 74 04            [12]  952 	mov	a,#0x04
      003605 2E               [12]  953 	add	a, r6
      003606 12 37 D0         [24]  954 	lcall	_ak820_outline_0017
      003609 70 04            [24]  955 	jnz	00102$
      00360B 75 82 01         [24]  956 	mov	dpl, #0x01
      00360E 22               [24]  957 	ret
      00360F                        958 00102$:
                                    959 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00360F 12 38 36         [24]  960 	lcall	_ak820_outline_0097
      003612 FA               [12]  961 	mov	r2,a
      003613 BA 10 00         [24]  962 	cjne	r2,#0x10,00308$
      003616                        963 00308$:
      003616 50 09            [24]  964 	jnc	00106$
      003618 12 38 30         [24]  965 	lcall	_ak820_outline_0094
      00361B F9               [12]  966 	mov	r1,a
      00361C B9 08 00         [24]  967 	cjne	r1,#0x08,00310$
      00361F                        968 00310$:
      00361F 40 15            [24]  969 	jc	00107$
      003621                        970 00106$:
                                    971 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (first != NONE && !active) flush();
      003621 12 38 7D         [24]  972 	lcall	_ak820_outline_0187
      003624 F8               [12]  973 	mov	r0,a
      003625 B8 FF 02         [24]  974 	cjne	r0,#0xff,00312$
      003628 80 08            [24]  975 	sjmp	00104$
      00362A                        976 00312$:
      00362A 90 04 4B         [24]  977 	mov	dptr,#_active
      00362D E0               [24]  978 	movx	a,@dptr
      00362E 70 02            [24]  979 	jnz	00104$
      003630 B1 AC            [24]  980 	acall	_flush
      003632                        981 00104$:
                                    982 ;	keyboards/ajazz/ak820/ak820_combo.c:58: return true;
      003632 75 82 01         [24]  983 	mov	dpl, #0x01
      003635 22               [24]  984 	ret
      003636                        985 00107$:
                                    986 ;	keyboards/ajazz/ak820/ak820_combo.c:60: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003636 EA               [12]  987 	mov	a,r2
      003637 12 38 72         [24]  988 	lcall	_ak820_outline_0162
      00363A 29               [12]  989 	add	a,r1
      00363B FA               [12]  990 	mov	r2,a
                                    991 ;	keyboards/ajazz/ak820/ak820_combo.c:61: if (active) {
      00363C 90 04 4B         [24]  992 	mov	dptr,#_active
      00363F E0               [24]  993 	movx	a,@dptr
      003640 60 6F            [24]  994 	jz	00123$
                                    995 ;	keyboards/ajazz/ak820/ak820_combo.c:62: if (id != first && id != second) return true;
      003642 12 38 7D         [24]  996 	lcall	_ak820_outline_0187
      003645 F9               [12]  997 	mov	r1,a
      003646 EA               [12]  998 	mov	a,r2
      003647 B5 01 02         [24]  999 	cjne	a,ar1,00315$
      00364A 80 0F            [24] 1000 	sjmp	00110$
      00364C                       1001 00315$:
      00364C 90 0E 76         [24] 1002 	mov	dptr,#_second
      00364F E0               [24] 1003 	movx	a,@dptr
      003650 F9               [12] 1004 	mov	r1,a
      003651 EA               [12] 1005 	mov	a,r2
      003652 B5 01 02         [24] 1006 	cjne	a,ar1,00316$
      003655 80 04            [24] 1007 	sjmp	00110$
      003657                       1008 00316$:
      003657 75 82 01         [24] 1009 	mov	dpl, #0x01
      00365A 22               [24] 1010 	ret
      00365B                       1011 00110$:
                                   1012 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (!record->event.pressed) {
      00365B 90 04 5A         [24] 1013 	mov	dptr,#_ak820_combo_process_record_10000_614
      00365E 12 38 3D         [24] 1014 	lcall	_ak820_outline_0102
      003661 74 05            [12] 1015 	mov	a,#0x05
      003663 28               [12] 1016 	add	a, r0
      003664 F8               [12] 1017 	mov	r0,a
      003665 E4               [12] 1018 	clr	a
      003666 39               [12] 1019 	addc	a, r1
      003667 F9               [12] 1020 	mov	r1,a
      003668 12 38 6D         [24] 1021 	lcall	_ak820_outline_0159
      00366B E0               [24] 1022 	movx	a,@dptr
      00366C 70 3F            [24] 1023 	jnz	00121$
                                   1024 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (saved.event.pressed) {
      00366E 90 04 47         [24] 1025 	mov	dptr,#(_saved + 0x0005)
      003671 E0               [24] 1026 	movx	a,@dptr
      003672 60 0F            [24] 1027 	jz	00113$
                                   1028 ;	keyboards/ajazz/ak820/ak820_combo.c:65: saved.event.pressed = false;
      003674 90 04 47         [24] 1029 	mov	dptr,#(_saved + 0x0005)
      003677 E4               [12] 1030 	clr	a
      003678 F0               [24] 1031 	movx	@dptr,a
                                   1032 ;	keyboards/ajazz/ak820/ak820_combo.c:66: process_record(&saved);
      003679 90 04 42         [24] 1033 	mov	dptr,#_saved
      00367C C0 02            [24] 1034 	push	ar2
      00367E 12 75 6D         [24] 1035 	lcall	_process_record
      003681 D0 02            [24] 1036 	pop	ar2
      003683                       1037 00113$:
                                   1038 ;	keyboards/ajazz/ak820/ak820_combo.c:68: if (id == first) first = NONE;
      003683 12 38 7D         [24] 1039 	lcall	_ak820_outline_0187
      003686 F9               [12] 1040 	mov	r1,a
      003687 EA               [12] 1041 	mov	a,r2
      003688 B5 01 08         [24] 1042 	cjne	a,ar1,00115$
      00368B 90 0E 75         [24] 1043 	mov	dptr,#_first
      00368E 74 FF            [12] 1044 	mov	a,#0xff
      003690 F0               [24] 1045 	movx	@dptr,a
      003691 80 06            [24] 1046 	sjmp	00116$
      003693                       1047 00115$:
                                   1048 ;	keyboards/ajazz/ak820/ak820_combo.c:69: else second = NONE;
      003693 90 0E 76         [24] 1049 	mov	dptr,#_second
      003696 74 FF            [12] 1050 	mov	a,#0xff
      003698 F0               [24] 1051 	movx	@dptr,a
      003699                       1052 00116$:
                                   1053 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (first == NONE && second == NONE) active = false;
      003699 12 38 7D         [24] 1054 	lcall	_ak820_outline_0187
      00369C F9               [12] 1055 	mov	r1,a
      00369D B9 FF 0D         [24] 1056 	cjne	r1,#0xff,00121$
      0036A0 90 0E 76         [24] 1057 	mov	dptr,#_second
      0036A3 E0               [24] 1058 	movx	a,@dptr
      0036A4 F9               [12] 1059 	mov	r1,a
      0036A5 B9 FF 05         [24] 1060 	cjne	r1,#0xff,00121$
      0036A8 90 04 4B         [24] 1061 	mov	dptr,#_active
      0036AB E4               [12] 1062 	clr	a
      0036AC F0               [24] 1063 	movx	@dptr,a
      0036AD                       1064 00121$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_combo.c:72: return false;
      0036AD 75 82 00         [24] 1066 	mov	dpl, #0x00
      0036B0 22               [24] 1067 	ret
      0036B1                       1068 00123$:
                                   1069 ;	keyboards/ajazz/ak820/ak820_combo.c:74: bool eligible = false;
      0036B1 90 04 5C         [24] 1070 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      0036B4 E4               [12] 1071 	clr	a
      0036B5 F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (record->event.pressed && COMBO_INPUT(record->keycode)) {
      0036B6 12 37 9F         [24] 1074 	lcall	_ak820_outline_0002
      0036B9 70 02            [24] 1075 	jnz	00325$
      0036BB E1 5E            [24] 1076 	ajmp	00134$
      0036BD                       1077 00325$:
      0036BD C3               [12] 1078 	clr	c
      0036BE EC               [12] 1079 	mov	a,r4
      0036BF 94 04            [12] 1080 	subb	a,#0x04
      0036C1 ED               [12] 1081 	mov	a,r5
      0036C2 94 00            [12] 1082 	subb	a,#0x00
      0036C4 50 02            [24] 1083 	jnc	00326$
      0036C6 E1 5E            [24] 1084 	ajmp	00134$
      0036C8                       1085 00326$:
      0036C8 C3               [12] 1086 	clr	c
      0036C9 74 A4            [12] 1087 	mov	a,#0xa4
      0036CB 9C               [12] 1088 	subb	a,r4
      0036CC E4               [12] 1089 	clr	a
      0036CD 9D               [12] 1090 	subb	a,r5
      0036CE 50 02            [24] 1091 	jnc	00327$
      0036D0 E1 5E            [24] 1092 	ajmp	00134$
      0036D2                       1093 00327$:
                                   1094 ;	free result
                                   1095 ;	keyboards/ajazz/ak820/ak820_combo.c:76: uint8_t previous = saved.keycode;
      0036D2 90 04 49         [24] 1096 	mov	dptr,#(_saved + 0x0007)
      0036D5 E0               [24] 1097 	movx	a,@dptr
      0036D6 FF               [12] 1098 	mov	r7,a
                                   1099 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0036D7 90 04 5D         [24] 1100 	mov	dptr,#_ak820_combo_process_i_40001_632
      0036DA E4               [12] 1101 	clr	a
      0036DB F0               [24] 1102 	movx	@dptr,a
      0036DC EB               [12] 1103 	mov	a,r3
      0036DD B5 07 03         [24] 1104 	cjne	a,ar7,00328$
      0036E0 D3               [12] 1105 	setb	c
      0036E1 80 01            [24] 1106 	sjmp	00329$
      0036E3                       1107 00328$:
      0036E3 C3               [12] 1108 	clr	c
      0036E4                       1109 00329$:
      0036E4 92 01            [24] 1110 	mov	_ak820_combo_process_sloc0_1_0,c
      0036E6 7E 00            [12] 1111 	mov	r6,#0x00
      0036E8                       1112 00142$:
      0036E8 BE 08 00         [24] 1113 	cjne	r6,#0x08,00330$
      0036EB                       1114 00330$:
      0036EB 40 02            [24] 1115 	jc	00331$
      0036ED E1 5E            [24] 1116 	ajmp	00134$
      0036EF                       1117 00331$:
                                   1118 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t a = combos[i].a, b = combos[i].b;
      0036EF EE               [12] 1119 	mov	a,r6
      0036F0 12 38 01         [24] 1120 	lcall	_ak820_outline_0060
      0036F3 E0               [24] 1121 	movx	a,@dptr
      0036F4 F9               [12] 1122 	mov	r1,a
      0036F5 90 04 5E         [24] 1123 	mov	dptr,#_ak820_combo_process_a_50001_633
      0036F8 F0               [24] 1124 	movx	@dptr,a
      0036F9 12 38 59         [24] 1125 	lcall	_ak820_outline_0127
      0036FC A3               [24] 1126 	inc	dptr
      0036FD E0               [24] 1127 	movx	a,@dptr
      0036FE FD               [12] 1128 	mov	r5,a
      0036FF 90 04 5F         [24] 1129 	mov	dptr,#_ak820_combo_process_b_50001_633
      003702 F0               [24] 1130 	movx	@dptr,a
                                   1131 ;	keyboards/ajazz/ak820/ak820_combo.c:79: if (a == code || b == code) {
      003703 E9               [12] 1132 	mov	a,r1
      003704 B5 03 02         [24] 1133 	cjne	a,ar3,00332$
      003707 80 04            [24] 1134 	sjmp	00129$
      003709                       1135 00332$:
      003709 ED               [12] 1136 	mov	a,r5
      00370A B5 03 49         [24] 1137 	cjne	a,ar3,00143$
      00370D                       1138 00129$:
                                   1139 ;	keyboards/ajazz/ak820/ak820_combo.c:80: eligible = true;
      00370D 90 04 5C         [24] 1140 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      003710 74 01            [12] 1141 	mov	a,#0x01
      003712 F0               [24] 1142 	movx	@dptr,a
                                   1143 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003713 12 38 7D         [24] 1144 	lcall	_ak820_outline_0187
      003716 FD               [12] 1145 	mov	r5,a
      003717 BD FF 02         [24] 1146 	cjne	r5,#0xff,00335$
      00371A 80 3A            [24] 1147 	sjmp	00143$
      00371C                       1148 00335$:
      00371C 20 01 37         [24] 1149 	jb	_ak820_combo_process_sloc0_1_0,00143$
      00371F 90 04 5E         [24] 1150 	mov	dptr,#_ak820_combo_process_a_50001_633
      003722 E0               [24] 1151 	movx	a,@dptr
      003723 B5 07 02         [24] 1152 	cjne	a,ar7,00337$
      003726 80 07            [24] 1153 	sjmp	00124$
      003728                       1154 00337$:
      003728 90 04 5F         [24] 1155 	mov	dptr,#_ak820_combo_process_b_50001_633
      00372B E0               [24] 1156 	movx	a,@dptr
      00372C B5 07 27         [24] 1157 	cjne	a,ar7,00143$
      00372F                       1158 00124$:
                                   1159 ;	keyboards/ajazz/ak820/ak820_combo.c:82: second = id;
      00372F 90 0E 76         [24] 1160 	mov	dptr,#_second
      003732 EA               [12] 1161 	mov	a,r2
      003733 F0               [24] 1162 	movx	@dptr,a
                                   1163 ;	keyboards/ajazz/ak820/ak820_combo.c:83: active = true;
      003734 90 04 4B         [24] 1164 	mov	dptr,#_active
      003737 74 01            [12] 1165 	mov	a,#0x01
      003739 F0               [24] 1166 	movx	@dptr,a
                                   1167 ;	keyboards/ajazz/ak820/ak820_combo.c:84: saved.keycode = combos[i].output;
      00373A 90 04 5D         [24] 1168 	mov	dptr,#_ak820_combo_process_i_40001_632
      00373D E0               [24] 1169 	movx	a,@dptr
      00373E 12 38 01         [24] 1170 	lcall	_ak820_outline_0060
      003741 A3               [24] 1171 	inc	dptr
      003742 A3               [24] 1172 	inc	dptr
      003743 12 38 12         [24] 1173 	lcall	_ak820_outline_0064
      003746 90 04 49         [24] 1174 	mov	dptr,#(_saved + 0x0007)
      003749 12 38 1E         [24] 1175 	lcall	_ak820_outline_0077
                                   1176 ;	keyboards/ajazz/ak820/ak820_combo.c:85: process_record(&saved);
      00374C 90 04 42         [24] 1177 	mov	dptr,#_saved
      00374F 12 75 6D         [24] 1178 	lcall	_process_record
                                   1179 ;	keyboards/ajazz/ak820/ak820_combo.c:86: return false;
      003752 75 82 00         [24] 1180 	mov	dpl, #0x00
      003755 22               [24] 1181 	ret
      003756                       1182 00143$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003756 0E               [12] 1184 	inc	r6
      003757 90 04 5D         [24] 1185 	mov	dptr,#_ak820_combo_process_i_40001_632
      00375A EE               [12] 1186 	mov	a,r6
      00375B F0               [24] 1187 	movx	@dptr,a
      00375C C1 E8            [24] 1188 	ajmp	00142$
      00375E                       1189 00134$:
                                   1190 ;	keyboards/ajazz/ak820/ak820_combo.c:91: if (first != NONE) flush();
      00375E 12 38 7D         [24] 1191 	lcall	_ak820_outline_0187
      003761 FF               [12] 1192 	mov	r7,a
      003762 BF FF 02         [24] 1193 	cjne	r7,#0xff,00340$
      003765 80 06            [24] 1194 	sjmp	00138$
      003767                       1195 00340$:
      003767 C0 02            [24] 1196 	push	ar2
      003769 B1 AC            [24] 1197 	acall	_flush
      00376B D0 02            [24] 1198 	pop	ar2
      00376D                       1199 00138$:
                                   1200 ;	keyboards/ajazz/ak820/ak820_combo.c:92: if (eligible) {
      00376D 90 04 5C         [24] 1201 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      003770 E0               [24] 1202 	movx	a,@dptr
      003771 60 28            [24] 1203 	jz	00140$
                                   1204 ;	keyboards/ajazz/ak820/ak820_combo.c:93: first = id;
      003773 90 0E 75         [24] 1205 	mov	dptr,#_first
      003776 EA               [12] 1206 	mov	a,r2
      003777 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	keyboards/ajazz/ak820/ak820_combo.c:94: saved = *record;
      003778 90 04 5A         [24] 1209 	mov	dptr,#_ak820_combo_process_record_10000_614
      00377B 12 38 2A         [24] 1210 	lcall	_ak820_outline_0082
      00377E 7F 00            [12] 1211 	mov	r7,#0x00
      003780 90 0E 67         [24] 1212 	mov	dptr,#___memcpy_PARM_2
      003783 ED               [12] 1213 	mov	a,r5
      003784 12 37 E3         [24] 1214 	lcall	_ak820_outline_0019
      003787 90 0E 6A         [24] 1215 	mov	dptr,#___memcpy_PARM_3
      00378A 74 09            [12] 1216 	mov	a,#0x09
      00378C 12 38 5E         [24] 1217 	lcall	_ak820_outline_0128
      00378F 90 04 42         [24] 1218 	mov	dptr,#_saved
      003792 F5 F0            [12] 1219 	mov	b,a
      003794 12 BC D2         [24] 1220 	lcall	___memcpy
                                   1221 ;	keyboards/ajazz/ak820/ak820_combo.c:95: return false;
      003797 75 82 00         [24] 1222 	mov	dpl, #0x00
      00379A 22               [24] 1223 	ret
      00379B                       1224 00140$:
                                   1225 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return true;
      00379B 75 82 01         [24] 1226 	mov	dpl, #0x01
                                   1227 ;	keyboards/ajazz/ak820/ak820_combo.c:98: }
      00379E 22               [24] 1228 	ret
                                   1229 	.area CSEG    (CODE)
                                   1230 	.area CONST   (CODE)
                                   1231 	.area XINIT   (CODE)
      00C590                       1232 __xinit__first:
      00C590 FF                    1233 	.db #0xff	; 255
      00C591                       1234 __xinit__second:
      00C591 FF                    1235 	.db #0xff	; 255
                                   1236 	.area CABS    (ABS,CODE)
                                   1237 
                                   1238 ; Experimental exact instruction outlining.
                                   1239 	.globl _ak820_outline_0002
                                   1240 	.globl _ak820_outline_0006
                                   1241 	.globl _ak820_outline_0008
                                   1242 	.globl _ak820_outline_0010
                                   1243 	.globl _ak820_outline_0017
                                   1244 	.globl _ak820_outline_0018
                                   1245 	.globl _ak820_outline_0019
                                   1246 	.globl _ak820_outline_0035
                                   1247 	.globl _ak820_outline_0036
                                   1248 	.globl _ak820_outline_0058
                                   1249 	.globl _ak820_outline_0060
                                   1250 	.globl _ak820_outline_0064
                                   1251 	.globl _ak820_outline_0075
                                   1252 	.globl _ak820_outline_0077
                                   1253 	.globl _ak820_outline_0080
                                   1254 	.globl _ak820_outline_0082
                                   1255 	.globl _ak820_outline_0094
                                   1256 	.globl _ak820_outline_0097
                                   1257 	.globl _ak820_outline_0102
                                   1258 	.globl _ak820_outline_0103
                                   1259 	.globl _ak820_outline_0108
                                   1260 	.globl _ak820_outline_0109
                                   1261 	.globl _ak820_outline_0123
                                   1262 	.globl _ak820_outline_0124
                                   1263 	.globl _ak820_outline_0127
                                   1264 	.globl _ak820_outline_0128
                                   1265 	.globl _ak820_outline_0138
                                   1266 	.globl _ak820_outline_0150
                                   1267 	.globl _ak820_outline_0159
                                   1268 	.globl _ak820_outline_0162
                                   1269 	.globl _ak820_outline_0163
                                   1270 	.globl _ak820_outline_0187
                                   1271 	.globl _ak820_outline_0191
                                   1272 
                                   1273 	.area CSEG (CODE)
                                   1274 ; function ak820_outline_0002
      00379F                       1275 _ak820_outline_0002:
      00379F 74 05            [12] 1276 	mov	a,#0x05
      0037A1 2E               [12] 1277 	add	a,r6
      0037A2 FE               [12] 1278 	mov	r6,a
      0037A3 E4               [12] 1279 	clr	a
      0037A4 3F               [12] 1280 	addc	a,r7
      0037A5 FF               [12] 1281 	mov	r7,a
      0037A6 8E 82            [24] 1282 	mov	dpl,r6
      0037A8 8F 83            [24] 1283 	mov	dph,r7
      0037AA E0               [24] 1284 	movx	a,@dptr
      0037AB 22               [24] 1285 	ret
                                   1286 
                                   1287 	.area CSEG (CODE)
                                   1288 ; function ak820_outline_0006
      0037AC                       1289 _ak820_outline_0006:
      0037AC E0               [24] 1290 	movx	a,@dptr
      0037AD FE               [12] 1291 	mov	r6,a
      0037AE A3               [24] 1292 	inc	dptr
      0037AF E0               [24] 1293 	movx	a,@dptr
      0037B0 FF               [12] 1294 	mov	r7,a
      0037B1 8E 82            [24] 1295 	mov	dpl,r6
      0037B3 8F 83            [24] 1296 	mov	dph,r7
      0037B5 22               [24] 1297 	ret
                                   1298 
                                   1299 	.area CSEG (CODE)
                                   1300 ; function ak820_outline_0008
      0037B6                       1301 _ak820_outline_0008:
      0037B6 E0               [24] 1302 	movx	a,@dptr
      0037B7 FE               [12] 1303 	mov	r6,a
      0037B8 A3               [24] 1304 	inc	dptr
      0037B9 E0               [24] 1305 	movx	a,@dptr
      0037BA FF               [12] 1306 	mov	r7,a
      0037BB 74 07            [12] 1307 	mov	a,#0x07
      0037BD 2E               [12] 1308 	add	a,r6
      0037BE F5 82            [12] 1309 	mov	dpl,a
      0037C0 E4               [12] 1310 	clr	a
      0037C1 3F               [12] 1311 	addc	a,r7
      0037C2 F5 83            [12] 1312 	mov	dph,a
      0037C4 E0               [24] 1313 	movx	a,@dptr
      0037C5 22               [24] 1314 	ret
                                   1315 
                                   1316 	.area CSEG (CODE)
                                   1317 ; function ak820_outline_0010
      0037C6                       1318 _ak820_outline_0010:
      0037C6 E0               [24] 1319 	movx	a,@dptr
      0037C7 FE               [12] 1320 	mov	r6,a
      0037C8 A3               [24] 1321 	inc	dptr
      0037C9 E0               [24] 1322 	movx	a,@dptr
      0037CA FF               [12] 1323 	mov	r7,a
      0037CB 8E 04            [24] 1324 	mov	ar4,r6
      0037CD 8F 05            [24] 1325 	mov	ar5,r7
      0037CF 22               [24] 1326 	ret
                                   1327 
                                   1328 	.area CSEG (CODE)
                                   1329 ; function ak820_outline_0017
      0037D0                       1330 _ak820_outline_0017:
      0037D0 F9               [12] 1331 	mov	r1,a
      0037D1 E4               [12] 1332 	clr	a
      0037D2 3F               [12] 1333 	addc	a,r7
      0037D3 FA               [12] 1334 	mov	r2,a
      0037D4 89 82            [24] 1335 	mov	dpl,r1
      0037D6 8A 83            [24] 1336 	mov	dph,r2
      0037D8 E0               [24] 1337 	movx	a,@dptr
      0037D9 22               [24] 1338 	ret
                                   1339 
                                   1340 	.area CSEG (CODE)
                                   1341 ; function ak820_outline_0018
      0037DA                       1342 _ak820_outline_0018:
      0037DA 2E               [12] 1343 	add	a,r6
      0037DB F5 82            [12] 1344 	mov	dpl,a
      0037DD E4               [12] 1345 	clr	a
      0037DE 3F               [12] 1346 	addc	a,r7
      0037DF F5 83            [12] 1347 	mov	dph,a
      0037E1 E0               [24] 1348 	movx	a,@dptr
      0037E2 22               [24] 1349 	ret
                                   1350 
                                   1351 	.area CSEG (CODE)
                                   1352 ; function ak820_outline_0019
      0037E3                       1353 _ak820_outline_0019:
      0037E3 F0               [24] 1354 	movx	@dptr,a
      0037E4 EE               [12] 1355 	mov	a,r6
      0037E5 A3               [24] 1356 	inc	dptr
      0037E6 F0               [24] 1357 	movx	@dptr,a
      0037E7 EF               [12] 1358 	mov	a,r7
      0037E8 A3               [24] 1359 	inc	dptr
      0037E9 F0               [24] 1360 	movx	@dptr,a
      0037EA 22               [24] 1361 	ret
                                   1362 
                                   1363 	.area CSEG (CODE)
                                   1364 ; function ak820_outline_0035
      0037EB                       1365 _ak820_outline_0035:
      0037EB 8E 82            [24] 1366 	mov	dpl,r6
      0037ED 8F 83            [24] 1367 	mov	dph,r7
      0037EF A3               [24] 1368 	inc	dptr
      0037F0 A3               [24] 1369 	inc	dptr
      0037F1 E0               [24] 1370 	movx	a,@dptr
      0037F2 22               [24] 1371 	ret
                                   1372 
                                   1373 	.area CSEG (CODE)
                                   1374 ; function ak820_outline_0036
      0037F3                       1375 _ak820_outline_0036:
      0037F3 2E               [12] 1376 	add	a,r6
      0037F4 F5 82            [12] 1377 	mov	dpl,a
      0037F6 E4               [12] 1378 	clr	a
      0037F7 3F               [12] 1379 	addc	a,r7
      0037F8 F5 83            [12] 1380 	mov	dph,a
      0037FA 22               [24] 1381 	ret
                                   1382 
                                   1383 	.area CSEG (CODE)
                                   1384 ; function ak820_outline_0058
      0037FB                       1385 _ak820_outline_0058:
      0037FB E0               [24] 1386 	movx	a,@dptr
      0037FC FE               [12] 1387 	mov	r6,a
      0037FD A3               [24] 1388 	inc	dptr
      0037FE E0               [24] 1389 	movx	a,@dptr
      0037FF FF               [12] 1390 	mov	r7,a
      003800 22               [24] 1391 	ret
                                   1392 
                                   1393 	.area CSEG (CODE)
                                   1394 ; function ak820_outline_0060
      003801                       1395 _ak820_outline_0060:
      003801 75 F0 04         [24] 1396 	mov	b,#0x04
      003804 A4               [48] 1397 	mul	ab
      003805 24 22            [12] 1398 	add	a,#_combos
      003807 FC               [12] 1399 	mov	r4,a
      003808 74 04            [12] 1400 	mov	a,#(_combos>>8)
      00380A 35 F0            [12] 1401 	addc	a,b
      00380C FD               [12] 1402 	mov	r5,a
      00380D 8C 82            [24] 1403 	mov	dpl,r4
      00380F 8D 83            [24] 1404 	mov	dph,r5
      003811 22               [24] 1405 	ret
                                   1406 
                                   1407 	.area CSEG (CODE)
                                   1408 ; function ak820_outline_0064
      003812                       1409 _ak820_outline_0064:
      003812 E0               [24] 1410 	movx	a,@dptr
      003813 FC               [12] 1411 	mov	r4,a
      003814 A3               [24] 1412 	inc	dptr
      003815 E0               [24] 1413 	movx	a,@dptr
      003816 FD               [12] 1414 	mov	r5,a
      003817 22               [24] 1415 	ret
                                   1416 
                                   1417 	.area CSEG (CODE)
                                   1418 ; function ak820_outline_0075
      003818                       1419 _ak820_outline_0075:
      003818 A3               [24] 1420 	inc	dptr
      003819 F0               [24] 1421 	movx	@dptr,a
      00381A E4               [12] 1422 	clr	a
      00381B A3               [24] 1423 	inc	dptr
      00381C F0               [24] 1424 	movx	@dptr,a
      00381D 22               [24] 1425 	ret
                                   1426 
                                   1427 	.area CSEG (CODE)
                                   1428 ; function ak820_outline_0077
      00381E                       1429 _ak820_outline_0077:
      00381E EC               [12] 1430 	mov	a,r4
      00381F F0               [24] 1431 	movx	@dptr,a
      003820 ED               [12] 1432 	mov	a,r5
      003821 A3               [24] 1433 	inc	dptr
      003822 F0               [24] 1434 	movx	@dptr,a
      003823 22               [24] 1435 	ret
                                   1436 
                                   1437 	.area CSEG (CODE)
                                   1438 ; function ak820_outline_0080
      003824                       1439 _ak820_outline_0080:
      003824 EB               [12] 1440 	mov	a,r3
      003825 F0               [24] 1441 	movx	@dptr,a
      003826 EC               [12] 1442 	mov	a,r4
      003827 A3               [24] 1443 	inc	dptr
      003828 F0               [24] 1444 	movx	@dptr,a
      003829 22               [24] 1445 	ret
                                   1446 
                                   1447 	.area CSEG (CODE)
                                   1448 ; function ak820_outline_0082
      00382A                       1449 _ak820_outline_0082:
      00382A E0               [24] 1450 	movx	a,@dptr
      00382B FD               [12] 1451 	mov	r5,a
      00382C A3               [24] 1452 	inc	dptr
      00382D E0               [24] 1453 	movx	a,@dptr
      00382E FE               [12] 1454 	mov	r6,a
      00382F 22               [24] 1455 	ret
                                   1456 
                                   1457 	.area CSEG (CODE)
                                   1458 ; function ak820_outline_0094
      003830                       1459 _ak820_outline_0094:
      003830 8E 82            [24] 1460 	mov	dpl,r6
      003832 8F 83            [24] 1461 	mov	dph,r7
      003834 E0               [24] 1462 	movx	a,@dptr
      003835 22               [24] 1463 	ret
                                   1464 
                                   1465 	.area CSEG (CODE)
                                   1466 ; function ak820_outline_0097
      003836                       1467 _ak820_outline_0097:
      003836 8E 82            [24] 1468 	mov	dpl,r6
      003838 8F 83            [24] 1469 	mov	dph,r7
      00383A A3               [24] 1470 	inc	dptr
      00383B E0               [24] 1471 	movx	a,@dptr
      00383C 22               [24] 1472 	ret
                                   1473 
                                   1474 	.area CSEG (CODE)
                                   1475 ; function ak820_outline_0102
      00383D                       1476 _ak820_outline_0102:
      00383D E0               [24] 1477 	movx	a,@dptr
      00383E F8               [12] 1478 	mov	r0,a
      00383F A3               [24] 1479 	inc	dptr
      003840 E0               [24] 1480 	movx	a,@dptr
      003841 F9               [12] 1481 	mov	r1,a
      003842 22               [24] 1482 	ret
                                   1483 
                                   1484 	.area CSEG (CODE)
                                   1485 ; function ak820_outline_0103
      003843                       1486 _ak820_outline_0103:
      003843 E0               [24] 1487 	movx	a,@dptr
      003844 FB               [12] 1488 	mov	r3,a
      003845 A3               [24] 1489 	inc	dptr
      003846 E0               [24] 1490 	movx	a,@dptr
      003847 FC               [12] 1491 	mov	r4,a
      003848 22               [24] 1492 	ret
                                   1493 
                                   1494 	.area CSEG (CODE)
                                   1495 ; function ak820_outline_0108
      003849                       1496 _ak820_outline_0108:
      003849 F0               [24] 1497 	movx	@dptr,a
      00384A EF               [12] 1498 	mov	a,r7
      00384B A3               [24] 1499 	inc	dptr
      00384C F0               [24] 1500 	movx	@dptr,a
      00384D 22               [24] 1501 	ret
                                   1502 
                                   1503 	.area CSEG (CODE)
                                   1504 ; function ak820_outline_0109
      00384E                       1505 _ak820_outline_0109:
      00384E AF 83            [24] 1506 	mov	r7,dph
      003850 E5 82            [12] 1507 	mov	a,dpl
      003852 22               [24] 1508 	ret
                                   1509 
                                   1510 	.area CSEG (CODE)
                                   1511 ; function ak820_outline_0124
      003853                       1512 _ak820_outline_0124:
      003853 E5 82            [12] 1513 	mov	a,dpl
      003855 85 83 F0         [24] 1514 	mov	b,dph
      003858 22               [24] 1515 	ret
                                   1516 
                                   1517 	.area CSEG (CODE)
                                   1518 ; function ak820_outline_0127
      003859                       1519 _ak820_outline_0127:
      003859 8C 82            [24] 1520 	mov	dpl,r4
      00385B 8D 83            [24] 1521 	mov	dph,r5
      00385D 22               [24] 1522 	ret
                                   1523 
                                   1524 	.area CSEG (CODE)
                                   1525 ; function ak820_outline_0128
      00385E                       1526 _ak820_outline_0128:
      00385E F0               [24] 1527 	movx	@dptr,a
      00385F E4               [12] 1528 	clr	a
      003860 A3               [24] 1529 	inc	dptr
      003861 F0               [24] 1530 	movx	@dptr,a
      003862 22               [24] 1531 	ret
                                   1532 
                                   1533 	.area CSEG (CODE)
                                   1534 ; function ak820_outline_0138
      003863                       1535 _ak820_outline_0138:
      003863 8D 82            [24] 1536 	mov	dpl,r5
      003865 8E 83            [24] 1537 	mov	dph,r6
      003867 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0150
      003868                       1542 _ak820_outline_0150:
      003868 E4               [12] 1543 	clr	a
      003869 33               [12] 1544 	rlc	a
      00386A F5 82            [12] 1545 	mov	dpl,a
      00386C 22               [24] 1546 	ret
                                   1547 
                                   1548 	.area CSEG (CODE)
                                   1549 ; function ak820_outline_0159
      00386D                       1550 _ak820_outline_0159:
      00386D 88 82            [24] 1551 	mov	dpl,r0
      00386F 89 83            [24] 1552 	mov	dph,r1
      003871 22               [24] 1553 	ret
                                   1554 
                                   1555 	.area CSEG (CODE)
                                   1556 ; function ak820_outline_0162
      003872                       1557 _ak820_outline_0162:
      003872 C4               [12] 1558 	swap	a
      003873 03               [12] 1559 	rr	a
      003874 54 F8            [12] 1560 	anl	a,#0xf8
      003876 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0163
      003877                       1565 _ak820_outline_0163:
      003877 2D               [12] 1566 	add	a,r5
      003878 FD               [12] 1567 	mov	r5,a
      003879 E4               [12] 1568 	clr	a
      00387A 3E               [12] 1569 	addc	a,r6
      00387B FE               [12] 1570 	mov	r6,a
      00387C 22               [24] 1571 	ret
                                   1572 
                                   1573 	.area CSEG (CODE)
                                   1574 ; function ak820_outline_0187
      00387D                       1575 _ak820_outline_0187:
      00387D 90 0E 75         [24] 1576 	mov	dptr,#_first
      003880 E0               [24] 1577 	movx	a,@dptr
      003881 22               [24] 1578 	ret
                                   1579 
                                   1580 	.area CSEG (CODE)
                                   1581 ; function ak820_outline_0191
      003882                       1582 _ak820_outline_0191:
      003882 75 F0 04         [24] 1583 	mov	b,#0x04
      003885 A4               [48] 1584 	mul	ab
      003886 22               [24] 1585 	ret
