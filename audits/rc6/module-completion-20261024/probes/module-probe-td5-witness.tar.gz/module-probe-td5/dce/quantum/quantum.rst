                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_tap_dance_process
                                     18 	.globl _process_repeat_key
                                     19 	.globl _process_last_key
                                     20 	.globl _process_caps_word
                                     21 	.globl _process_record_via
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _register_code16
                                    283 	.globl _unregister_code16
                                    284 	.globl _reset_keyboard
                                    285 	.globl _soft_reset_keyboard
                                    286 	.globl _get_record_keycode
                                    287 	.globl _pre_process_record_quantum
                                    288 	.globl _process_record_quantum
                                    289 	.globl _process_record_quantum_helper
                                    290 	.globl _shutdown_user
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
                                    553 ;--------------------------------------------------------
                                    554 ; overlayable items in internal ram
                                    555 ;--------------------------------------------------------
                                    556 ;--------------------------------------------------------
                                    557 ; indirectly addressable internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area ISEG    (DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; absolute internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area IABS    (ABS,DATA)
                                    564 	.area IABS    (ABS,DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; bit data
                                    567 ;--------------------------------------------------------
                                    568 	.area BSEG    (BIT)
      000026                        569 _get_record_keycode_sloc0_1_0:
      000026                        570 	.ds 1
      000027                        571 _pre_process_record_quantum_sloc0_1_0:
      000027                        572 	.ds 1
      000028                        573 _process_ak820_nkro_sloc0_1_0:
      000028                        574 	.ds 1
                                    575 ;--------------------------------------------------------
                                    576 ; paged external ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area PSEG    (PAG,XDATA)
                                    579 ;--------------------------------------------------------
                                    580 ; uninitialized external ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area XSEG    (XDATA)
      000CAB                        583 _extract_mod_bits_code_10000_606:
      000CAB                        584 	.ds 2
      000CAD                        585 _register_code16_code_10000_612:
      000CAD                        586 	.ds 2
      000CAF                        587 _unregister_code16_code_10000_617:
      000CAF                        588 	.ds 2
      000CB1                        589 _get_record_keycode_PARM_2:
      000CB1                        590 	.ds 1
      000CB2                        591 _get_record_keycode_record_argument_10000_655:
      000CB2                        592 	.ds 2
      000CB4                        593 _pre_process_record_quantum_record_argument_10000_661:
      000CB4                        594 	.ds 2
      000CB6                        595 _process_record_quantum_record_10000_666:
      000CB6                        596 	.ds 2
      000CB8                        597 _process_ak820_nkro_PARM_2:
      000CB8                        598 	.ds 3
      000CBB                        599 _process_ak820_nkro_keycode_10000_668:
      000CBB                        600 	.ds 2
      000CBD                        601 _process_record_quantum_helper_PARM_2:
      000CBD                        602 	.ds 2
      000CBF                        603 _process_record_quantum_helper_keycode_10000_673:
      000CBF                        604 	.ds 2
      000CC1                        605 _get_u8_str_last_num_10000_699:
      000CC1                        606 	.ds 1
      000CC2                        607 _get_u16_str_last_num_10000_703:
      000CC2                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
                                    617 	.area HOME    (CODE)
                                    618 	.area GSINIT0 (CODE)
                                    619 	.area GSINIT1 (CODE)
                                    620 	.area GSINIT2 (CODE)
                                    621 	.area GSINIT3 (CODE)
                                    622 	.area GSINIT4 (CODE)
                                    623 	.area GSINIT5 (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area CSEG    (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; global & static initialisations
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area GSINIT  (CODE)
                                    632 	.area GSFINAL (CODE)
                                    633 	.area GSINIT  (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'get_u8_str'
                                    636 ;------------------------------------------------------------
                                    637 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    638 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_698'
                                    639 ;buf           Allocated with name '_get_u8_str_buf_10000_699'
                                    640 ;last_num      Allocated with name '_get_u8_str_last_num_10000_699'
                                    641 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_699'
                                    642 ;------------------------------------------------------------
                                    643 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0C C1         [24]  644 	mov	dptr,#_get_u8_str_last_num_10000_699
      0030F6 74 FF            [12]  645 	mov	a,#0xff
      0030F8 F0               [24]  646 	movx	@dptr,a
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'get_u16_str'
                                    649 ;------------------------------------------------------------
                                    650 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    651 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_702'
                                    652 ;buf           Allocated with name '_get_u16_str_buf_10000_703'
                                    653 ;last_num      Allocated with name '_get_u16_str_last_num_10000_703'
                                    654 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_703'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0C C2         [24]  657 	mov	dptr,#_get_u16_str_last_num_10000_703
      0030FC 74 FF            [12]  658 	mov	a,#0xff
      0030FE F0               [24]  659 	movx	@dptr,a
      0030FF E4               [12]  660 	clr	a
      003100 A3               [24]  661 	inc	dptr
      003101 F0               [24]  662 	movx	@dptr,a
                                    663 ;--------------------------------------------------------
                                    664 ; Home
                                    665 ;--------------------------------------------------------
                                    666 	.area HOME    (CODE)
                                    667 	.area HOME    (CODE)
                                    668 ;--------------------------------------------------------
                                    669 ; code
                                    670 ;--------------------------------------------------------
                                    671 	.area CSEG    (CODE)
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    674 ;------------------------------------------------------------
                                    675 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    678 ;	-----------------------------------------
                           000007   679 	ar7 = 0x07
                           000006   680 	ar6 = 0x06
                           000005   681 	ar5 = 0x05
                           000004   682 	ar4 = 0x04
                           000003   683 	ar3 = 0x03
                           000002   684 	ar2 = 0x02
                           000001   685 	ar1 = 0x01
                           000000   686 	ar0 = 0x00
                                    687 ;	 function extract_mod_bits
                                    688 ;	-----------------------------------------
      00A260                        689 _extract_mod_bits:
      00A260 12 38 4E         [24]  690 	lcall	_ak820_outline_0109
      00A263 90 0C AB         [24]  691 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A266 12 38 49         [24]  692 	lcall	_ak820_outline_0108
                                    693 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A269 90 0C AB         [24]  694 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A26C E0               [24]  695 	movx	a,@dptr
      00A26D A3               [24]  696 	inc	dptr
      00A26E E0               [24]  697 	movx	a,@dptr
                                    698 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A26F FF               [12]  699 	mov	r7,a
      00A270 60 05            [24]  700 	jz	00101$
      00A272 EF               [12]  701 	mov	a,r7
      00A273 24 E0            [12]  702 	add	a,#0xff - 0x1f
      00A275 50 04            [24]  703 	jnc	00102$
                                    704 ;	free result
      00A277                        705 00101$:
      00A277 75 82 00         [24]  706 	mov	dpl, #0x00
      00A27A 22               [24]  707 	ret
      00A27B                        708 00102$:
                                    709 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A27B EF               [12]  710 	mov	a,r7
      00A27C 30 E4 07         [24]  711 	jnb	acc.4,00106$
      00A27F EF               [12]  712 	mov	a,r7
      00A280 C4               [12]  713 	swap	a
      00A281 54 F0            [12]  714 	anl	a,#0xf0
      00A283 FE               [12]  715 	mov	r6,a
      00A284 80 02            [24]  716 	sjmp	00107$
      00A286                        717 00106$:
      00A286 8F 06            [24]  718 	mov	ar6,r7
      00A288                        719 00107$:
      00A288 8E 82            [24]  720 	mov	dpl, r6
                                    721 ;	quantum/quantum.c:143: }
      00A28A 22               [24]  722 	ret
                                    723 ;------------------------------------------------------------
                                    724 ;Allocation info for local variables in function 'do_code16'
                                    725 ;------------------------------------------------------------
                                    726 ;f             Allocated with name '_do_code16_PARM_2'
                                    727 ;code          Allocated with name '_do_code16_code_10000_609'
                                    728 ;------------------------------------------------------------
                                    729 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    730 ;	-----------------------------------------
                                    731 ;	 function register_code16
                                    732 ;	-----------------------------------------
      00A28B                        733 _register_code16:
      00A28B 12 38 4E         [24]  734 	lcall	_ak820_outline_0109
      00A28E 90 0C AD         [24]  735 	mov	dptr,#_register_code16_code_10000_612
      00A291 12 38 49         [24]  736 	lcall	_ak820_outline_0108
                                    737 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A294 90 0C AD         [24]  738 	mov	dptr,#_register_code16_code_10000_612
      00A297 12 37 AC         [24]  739 	lcall	_ak820_outline_0006
      00A29A C0 07            [24]  740 	push	ar7
      00A29C C0 06            [24]  741 	push	ar6
      00A29E 51 60            [12]  742 	acall	_extract_mod_bits
      00A2A0 AD 82            [24]  743 	mov	r5, dpl
      00A2A2 D0 06            [24]  744 	pop	ar6
      00A2A4 D0 07            [24]  745 	pop	ar7
                                    746 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A2A6 12 A0 99         [24]  747 	lcall	_ak820_outline_0120
      00A2A9 40 07            [24]  748 	jc	00105$
      00A2AB 74 E7            [12]  749 	mov	a,#0xe7
      00A2AD 9E               [12]  750 	subb	a,r6
      00A2AE E4               [12]  751 	clr	a
      00A2AF 9F               [12]  752 	subb	a,r7
      00A2B0 50 08            [24]  753 	jnc	00101$
                                    754 ;	free result
      00A2B2                        755 00105$:
      00A2B2 90 0C AD         [24]  756 	mov	dptr,#_register_code16_code_10000_612
      00A2B5 12 48 A6         [24]  757 	lcall	_ak820_outline_0038
      00A2B8 70 07            [24]  758 	jnz	00102$
      00A2BA                        759 00101$:
                                    760 ;	quantum/quantum.c:153: register_mods(mods);
      00A2BA 8D 82            [24]  761 	mov	dpl, r5
      00A2BC 12 7A 9D         [24]  762 	lcall	_register_mods
      00A2BF 80 05            [24]  763 	sjmp	00103$
      00A2C1                        764 00102$:
                                    765 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A2C1 8D 82            [24]  766 	mov	dpl, r5
      00A2C3 12 7A C5         [24]  767 	lcall	_register_weak_mods
      00A2C6                        768 00103$:
                                    769 ;	quantum/quantum.c:157: register_code(code);
      00A2C6 90 0C AD         [24]  770 	mov	dptr,#_register_code16_code_10000_612
      00A2C9 E0               [24]  771 	movx	a,@dptr
      00A2CA F5 82            [12]  772 	mov	dpl,a
                                    773 ;	quantum/quantum.c:167: }
      00A2CC 02 79 7D         [24]  774 	ljmp	_register_code
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'unregister_code16'
                                    777 ;------------------------------------------------------------
                                    778 ;code          Allocated with name '_unregister_code16_code_10000_617'
                                    779 ;mods          Allocated with name '_unregister_code16_mods_10000_618'
                                    780 ;------------------------------------------------------------
                                    781 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function unregister_code16
                                    784 ;	-----------------------------------------
      00A2CF                        785 _unregister_code16:
      00A2CF 12 38 4E         [24]  786 	lcall	_ak820_outline_0109
      00A2D2 90 0C AF         [24]  787 	mov	dptr,#_unregister_code16_code_10000_617
      00A2D5 12 38 49         [24]  788 	lcall	_ak820_outline_0108
                                    789 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A2D8 90 0C AF         [24]  790 	mov	dptr,#_unregister_code16_code_10000_617
      00A2DB 12 37 AC         [24]  791 	lcall	_ak820_outline_0006
      00A2DE C0 07            [24]  792 	push	ar7
      00A2E0 C0 06            [24]  793 	push	ar6
      00A2E2 51 60            [12]  794 	acall	_extract_mod_bits
      00A2E4 AD 82            [24]  795 	mov	r5, dpl
      00A2E6 D0 06            [24]  796 	pop	ar6
                                    797 ;	quantum/quantum.c:172: unregister_code(code);
      00A2E8 8E 04            [24]  798 	mov	ar4,r6
      00A2EA 8C 82            [24]  799 	mov	dpl, r4
      00A2EC C0 06            [24]  800 	push	ar6
      00A2EE C0 05            [24]  801 	push	ar5
      00A2F0 12 79 EA         [24]  802 	lcall	_unregister_code
      00A2F3 D0 05            [24]  803 	pop	ar5
      00A2F5 D0 06            [24]  804 	pop	ar6
      00A2F7 D0 07            [24]  805 	pop	ar7
                                    806 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A2F9 12 A0 99         [24]  807 	lcall	_ak820_outline_0120
      00A2FC 40 07            [24]  808 	jc	00105$
      00A2FE 74 E7            [12]  809 	mov	a,#0xe7
      00A300 9E               [12]  810 	subb	a,r6
      00A301 E4               [12]  811 	clr	a
      00A302 9F               [12]  812 	subb	a,r7
      00A303 50 08            [24]  813 	jnc	00101$
                                    814 ;	free result
      00A305                        815 00105$:
      00A305 90 0C AF         [24]  816 	mov	dptr,#_unregister_code16_code_10000_617
      00A308 12 48 A6         [24]  817 	lcall	_ak820_outline_0038
      00A30B 70 05            [24]  818 	jnz	00102$
      00A30D                        819 00101$:
                                    820 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A30D 8D 82            [24]  821 	mov	dpl, r5
      00A30F 02 7A B1         [24]  822 	ljmp	_unregister_mods
      00A312                        823 00102$:
                                    824 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A312 8D 82            [24]  825 	mov	dpl, r5
                                    826 ;	quantum/quantum.c:187: }
      00A314 02 7A D9         [24]  827 	ljmp	_unregister_weak_mods
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'tap_code16_delay'
                                    830 ;------------------------------------------------------------
                                    831 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    832 ;code          Allocated with name '_tap_code16_delay_code_10000_622'
                                    833 ;i             Allocated with name '_tap_code16_delay_i_20000_624'
                                    834 ;i             Allocated with name '_tap_code16_delay_i_50000_627'
                                    835 ;------------------------------------------------------------
                                    836 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    837 ;	-----------------------------------------
                                    838 ;	 function shutdown_quantum
                                    839 ;	-----------------------------------------
      00A317                        840 _shutdown_quantum:
                                    841 ;	quantum/quantum.c:237: clear_keyboard();
      00A317 12 7A ED         [24]  842 	lcall	_clear_keyboard
                                    843 ;	quantum/quantum.c:252: shutdown_user();
      00A31A B1 A2            [12]  844 	acall	_shutdown_user
                                    845 ;	quantum/quantum.c:253: wait_ms(250);
      00A31C 7F FA            [12]  846 	mov	r7,#0xfa
      00A31E                        847 00106$:
      00A31E EF               [12]  848 	mov	a,r7
      00A31F 60 09            [24]  849 	jz	00108$
      00A321 90 00 01         [24]  850 	mov	dptr,#0x0001
      00A324 12 5D 9F         [24]  851 	lcall	_mDelaymS
      00A327 1F               [12]  852 	dec	r7
      00A328 80 F4            [24]  853 	sjmp	00106$
      00A32A                        854 00108$:
                                    855 ;	quantum/quantum.c:258: }
      00A32A 22               [24]  856 	ret
                                    857 ;------------------------------------------------------------
                                    858 ;Allocation info for local variables in function 'reset_keyboard'
                                    859 ;------------------------------------------------------------
                                    860 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    861 ;	-----------------------------------------
                                    862 ;	 function reset_keyboard
                                    863 ;	-----------------------------------------
      00A32B                        864 _reset_keyboard:
                                    865 ;	quantum/quantum.c:261: shutdown_quantum();
      00A32B 71 17            [12]  866 	acall	_shutdown_quantum
                                    867 ;	quantum/quantum.c:262: bootloader_jump();
                                    868 ;	quantum/quantum.c:263: }
      00A32D 02 34 0E         [24]  869 	ljmp	_bootloader_jump
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function soft_reset_keyboard
                                    876 ;	-----------------------------------------
      00A330                        877 _soft_reset_keyboard:
                                    878 ;	quantum/quantum.c:266: shutdown_quantum();
      00A330 71 17            [12]  879 	acall	_shutdown_quantum
                                    880 ;	quantum/quantum.c:267: mcu_reset();
                                    881 ;	quantum/quantum.c:268: }
      00A332 02 34 01         [24]  882 	ljmp	_mcu_reset
                                    883 ;------------------------------------------------------------
                                    884 ;Allocation info for local variables in function 'get_record_keycode'
                                    885 ;------------------------------------------------------------
                                    886 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    887 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_655'
                                    888 ;record        Allocated with name '_get_record_keycode_record_10000_656'
                                    889 ;------------------------------------------------------------
                                    890 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function get_record_keycode
                                    893 ;	-----------------------------------------
      00A335                        894 _get_record_keycode:
      00A335 12 38 4E         [24]  895 	lcall	_ak820_outline_0109
      00A338 90 0C B2         [24]  896 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A33B 12 38 49         [24]  897 	lcall	_ak820_outline_0108
                                    898 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A33E 90 0C B2         [24]  899 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A341 12 37 B6         [24]  900 	lcall	_ak820_outline_0008
                                    901 ;	quantum/quantum.c:278: if (record->keycode) {
      00A344 FC               [12]  902 	mov	r4,a
      00A345 A3               [24]  903 	inc	dptr
      00A346 E0               [24]  904 	movx	a,@dptr
      00A347 FD               [12]  905 	mov	r5,a
      00A348 4C               [12]  906 	orl	a,r4
      00A349 60 04            [24]  907 	jz	00102$
                                    908 ;	quantum/quantum.c:279: return record->keycode;
      00A34B 12 38 59         [24]  909 	lcall	_ak820_outline_0127
      00A34E 22               [24]  910 	ret
      00A34F                        911 00102$:
                                    912 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A34F 12 7B 2F         [24]  913 	lcall	_ak820_outline_0022
      00A352 7A 00            [12]  914 	mov	r2,#0x00
      00A354 12 43 2C         [24]  915 	lcall	_ak820_outline_0143
      00A357 12 37 9F         [24]  916 	lcall	_ak820_outline_0002
      00A35A 60 06            [24]  917 	jz	00105$
      00A35C 90 0C B1         [24]  918 	mov	dptr,#_get_record_keycode_PARM_2
      00A35F E0               [24]  919 	movx	a,@dptr
      00A360 70 04            [24]  920 	jnz	00106$
      00A362                        921 00105$:
                                    922 ;	assignBit
      00A362 C2 26            [12]  923 	clr	_get_record_keycode_sloc0_1_0
      00A364 80 02            [24]  924 	sjmp	00107$
      00A366                        925 00106$:
                                    926 ;	assignBit
      00A366 D2 26            [12]  927 	setb	_get_record_keycode_sloc0_1_0
      00A368                        928 00107$:
      00A368 90 0A 2C         [24]  929 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A36B A2 26            [12]  930 	mov	c,_get_record_keycode_sloc0_1_0
      00A36D E4               [12]  931 	clr	a
      00A36E 33               [12]  932 	rlc	a
      00A36F F0               [24]  933 	movx	@dptr,a
      00A370 8D 82            [24]  934 	mov	dpl, r5
      00A372 8C 83            [24]  935 	mov	dph, r4
                                    936 ;	quantum/quantum.c:287: }
      00A374 02 7E B2         [24]  937 	ljmp	_ak820_resolve_key
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'get_event_keycode'
                                    940 ;------------------------------------------------------------
                                    941 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    942 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_659'
                                    943 ;------------------------------------------------------------
                                    944 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    945 ;	-----------------------------------------
                                    946 ;	 function pre_process_record_quantum
                                    947 ;	-----------------------------------------
      00A377                        948 _pre_process_record_quantum:
      00A377 12 38 4E         [24]  949 	lcall	_ak820_outline_0109
      00A37A 90 0C B4         [24]  950 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A37D 12 38 49         [24]  951 	lcall	_ak820_outline_0108
                                    952 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A380 90 0C B4         [24]  953 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A383 12 37 FB         [24]  954 	lcall	_ak820_outline_0058
                                    955 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A386 90 0C B1         [24]  956 	mov	dptr,#_get_record_keycode_PARM_2
      00A389 74 01            [12]  957 	mov	a,#0x01
      00A38B 12 42 F2         [24]  958 	lcall	_ak820_outline_0066
      00A38E C0 07            [24]  959 	push	ar7
      00A390 C0 06            [24]  960 	push	ar6
      00A392 71 35            [12]  961 	acall	_get_record_keycode
      00A394 12 43 37         [24]  962 	lcall	_ak820_outline_0152
      00A397 D0 06            [24]  963 	pop	ar6
      00A399 D0 07            [24]  964 	pop	ar7
                                    965 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A39B 74 07            [12]  966 	mov	a,#0x07
      00A39D 12 37 F3         [24]  967 	lcall	_ak820_outline_0036
      00A3A0 EC               [12]  968 	mov	a,r4
      00A3A1 F0               [24]  969 	movx	@dptr,a
      00A3A2 ED               [12]  970 	mov	a,r5
      00A3A3 A3               [24]  971 	inc	dptr
      00A3A4 12 42 F2         [24]  972 	lcall	_ak820_outline_0066
                                    973 ;	quantum/quantum.c:351: if (!ak820_tap_dance_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      00A3A7 C0 07            [24]  974 	push	ar7
      00A3A9 C0 06            [24]  975 	push	ar6
      00A3AB 12 46 AA         [24]  976 	lcall	_ak820_tap_dance_process
      00A3AE E5 82            [12]  977 	mov	a, dpl
      00A3B0 D0 06            [24]  978 	pop	ar6
      00A3B2 D0 07            [24]  979 	pop	ar7
      00A3B4 70 03            [24]  980 	jnz	00102$
      00A3B6 F5 82            [12]  981 	mov	dpl,a
      00A3B8 22               [24]  982 	ret
      00A3B9                        983 00102$:
                                    984 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A3B9 12 43 17         [24]  985 	lcall	_ak820_outline_0119
      00A3BC 12 35 EE         [24]  986 	lcall	_ak820_combo_process
      00A3BF E5 82            [12]  987 	mov	a, dpl
      00A3C1 70 04            [24]  988 	jnz	00106$
                                    989 ;	quantum/quantum.c:366: true;
                                    990 ;	assignBit
      00A3C3 C2 27            [12]  991 	clr	_pre_process_record_quantum_sloc0_1_0
      00A3C5 80 02            [24]  992 	sjmp	00107$
      00A3C7                        993 00106$:
                                    994 ;	assignBit
      00A3C7 D2 27            [12]  995 	setb	_pre_process_record_quantum_sloc0_1_0
      00A3C9                        996 00107$:
      00A3C9 A2 27            [12]  997 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A3CB 12 38 68         [24]  998 	lcall	_ak820_outline_0150
                                    999 ;	quantum/quantum.c:367: }
      00A3CE 22               [24] 1000 	ret
                                   1001 ;------------------------------------------------------------
                                   1002 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1003 ;------------------------------------------------------------
                                   1004 ;record        Allocated with name '_post_process_record_quantum_record_10000_664'
                                   1005 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_665'
                                   1006 ;------------------------------------------------------------
                                   1007 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1008 ;	-----------------------------------------
                                   1009 ;	 function process_record_quantum
                                   1010 ;	-----------------------------------------
      00A3CF                       1011 _process_record_quantum:
      00A3CF 12 38 4E         [24] 1012 	lcall	_ak820_outline_0109
      00A3D2 90 0C B6         [24] 1013 	mov	dptr,#_process_record_quantum_record_10000_666
      00A3D5 12 38 49         [24] 1014 	lcall	_ak820_outline_0108
                                   1015 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      00A3D8 90 0C B6         [24] 1016 	mov	dptr,#_process_record_quantum_record_10000_666
      00A3DB 12 37 FB         [24] 1017 	lcall	_ak820_outline_0058
      00A3DE 90 0C B1         [24] 1018 	mov	dptr,#_get_record_keycode_PARM_2
      00A3E1 E4               [12] 1019 	clr	a
      00A3E2 12 42 F2         [24] 1020 	lcall	_ak820_outline_0066
      00A3E5 71 35            [12] 1021 	acall	_get_record_keycode
      00A3E7 12 43 27         [24] 1022 	lcall	_ak820_outline_0137
                                   1023 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      00A3EA 90 0C B6         [24] 1024 	mov	dptr,#_process_record_quantum_record_10000_666
      00A3ED 12 38 12         [24] 1025 	lcall	_ak820_outline_0064
      00A3F0 90 0C BD         [24] 1026 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A3F3 EC               [12] 1027 	mov	a,r4
      00A3F4 F0               [24] 1028 	movx	@dptr,a
      00A3F5 ED               [12] 1029 	mov	a,r5
      00A3F6 A3               [24] 1030 	inc	dptr
      00A3F7 12 42 F2         [24] 1031 	lcall	_ak820_outline_0066
                                   1032 ;	quantum/quantum.c:382: }
      00A3FA 81 67            [24] 1033 	ajmp	_process_record_quantum_helper
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1036 ;------------------------------------------------------------
                                   1037 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1038 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_668'
                                   1039 ;record        Allocated with name '_process_ak820_nkro_record_10000_669'
                                   1040 ;------------------------------------------------------------
                                   1041 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1042 ;	-----------------------------------------
                                   1043 ;	 function process_ak820_nkro
                                   1044 ;	-----------------------------------------
      00A3FC                       1045 _process_ak820_nkro:
      00A3FC 12 38 4E         [24] 1046 	lcall	_ak820_outline_0109
      00A3FF 90 0C BB         [24] 1047 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A402 12 38 49         [24] 1048 	lcall	_ak820_outline_0108
                                   1049 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A405 90 0C B8         [24] 1050 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A408 12 37 FB         [24] 1051 	lcall	_ak820_outline_0058
                                   1052 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A40B 90 0C BB         [24] 1053 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A40E 12 38 12         [24] 1054 	lcall	_ak820_outline_0064
      00A411 C3               [12] 1055 	clr	c
      00A412 EC               [12] 1056 	mov	a,r4
      00A413 94 11            [12] 1057 	subb	a,#0x11
      00A415 ED               [12] 1058 	mov	a,r5
      00A416 94 70            [12] 1059 	subb	a,#0x70
      00A418 40 08            [24] 1060 	jc	00101$
      00A41A 74 13            [12] 1061 	mov	a,#0x13
      00A41C 9C               [12] 1062 	subb	a,r4
      00A41D 74 70            [12] 1063 	mov	a,#0x70
      00A41F 9D               [12] 1064 	subb	a,r5
      00A420 50 04            [24] 1065 	jnc	00102$
                                   1066 ;	free result
      00A422                       1067 00101$:
      00A422 75 82 01         [24] 1068 	mov	dpl, #0x01
      00A425 22               [24] 1069 	ret
      00A426                       1070 00102$:
                                   1071 ;	quantum/quantum.c:406: if (record->event.pressed) {
      00A426 12 37 9F         [24] 1072 	lcall	_ak820_outline_0002
      00A429 60 38            [24] 1073 	jz	00105$
                                   1074 ;	quantum/quantum.c:407: clear_keyboard();
      00A42B C0 05            [24] 1075 	push	ar5
      00A42D C0 04            [24] 1076 	push	ar4
      00A42F 12 7A ED         [24] 1077 	lcall	_clear_keyboard
      00A432 D0 04            [24] 1078 	pop	ar4
      00A434 D0 05            [24] 1079 	pop	ar5
                                   1080 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A436 BC 13 14         [24] 1081 	cjne	r4,#0x13,00108$
      00A439 BD 70 11         [24] 1082 	cjne	r5,#0x70,00108$
      00A43C 90 0B 7E         [24] 1083 	mov	dptr,#_keymap_config
      00A43F E0               [24] 1084 	movx	a,@dptr
      00A440 23               [12] 1085 	rl	a
      00A441 54 01            [12] 1086 	anl	a,#0x01
      00A443 B4 01 00         [24] 1087 	cjne	a,#0x01,00136$
      00A446                       1088 00136$:
      00A446 92 28            [24] 1089 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A448 E4               [12] 1090 	clr	a
      00A449 33               [12] 1091 	rlc	a
      00A44A FF               [12] 1092 	mov	r7,a
      00A44B 80 09            [24] 1093 	sjmp	00109$
      00A44D                       1094 00108$:
      00A44D E4               [12] 1095 	clr	a
      00A44E BC 11 04         [24] 1096 	cjne	r4,#0x11,00137$
      00A451 BD 70 01         [24] 1097 	cjne	r5,#0x70,00137$
      00A454 04               [12] 1098 	inc	a
      00A455                       1099 00137$:
      00A455 FF               [12] 1100 	mov	r7,a
      00A456                       1101 00109$:
                                   1102 ;	assignBit
      00A456 EF               [12] 1103 	mov	a,r7
      00A457 24 FF            [12] 1104 	add	a,#0xff
      00A459 E4               [12] 1105 	clr	a
      00A45A 33               [12] 1106 	rlc	a
      00A45B 90 0B 7E         [24] 1107 	mov	dptr,#_keymap_config
      00A45E 13               [12] 1108 	rrc	a
      00A45F E0               [24] 1109 	movx	a,@dptr
      00A460 92 E7            [24] 1110 	mov	acc.7,c
      00A462 F0               [24] 1111 	movx	@dptr,a
      00A463                       1112 00105$:
                                   1113 ;	quantum/quantum.c:410: return false;
      00A463 75 82 00         [24] 1114 	mov	dpl, #0x00
                                   1115 ;	quantum/quantum.c:411: }
      00A466 22               [24] 1116 	ret
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1119 ;------------------------------------------------------------
                                   1120 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1121 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_673'
                                   1122 ;record        Allocated with name '_process_record_quantum_helper_record_10000_674'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function process_record_quantum_helper
                                   1127 ;	-----------------------------------------
      00A467                       1128 _process_record_quantum_helper:
      00A467 12 38 4E         [24] 1129 	lcall	_ak820_outline_0109
      00A46A 90 0C BF         [24] 1130 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A46D 12 38 49         [24] 1131 	lcall	_ak820_outline_0108
                                   1132 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A470 90 0C BD         [24] 1133 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A473 12 37 FB         [24] 1134 	lcall	_ak820_outline_0058
                                   1135 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      00A476 90 0C BF         [24] 1136 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A479 12 38 12         [24] 1137 	lcall	_ak820_outline_0064
      00A47C 90 0C B8         [24] 1138 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A47F 12 A5 A3         [24] 1139 	lcall	_ak820_outline_0003
      00A482 C0 07            [24] 1140 	push	ar7
      00A484 C0 06            [24] 1141 	push	ar6
      00A486 C0 05            [24] 1142 	push	ar5
      00A488 C0 04            [24] 1143 	push	ar4
      00A48A 71 FC            [24] 1144 	acall	_process_ak820_nkro
      00A48C E5 82            [12] 1145 	mov	a, dpl
      00A48E D0 04            [24] 1146 	pop	ar4
      00A490 D0 05            [24] 1147 	pop	ar5
      00A492 D0 06            [24] 1148 	pop	ar6
      00A494 D0 07            [24] 1149 	pop	ar7
      00A496 70 02            [24] 1150 	jnz	00196$
      00A498 A1 68            [12] 1151 	ajmp	00101$
      00A49A                       1152 00196$:
                                   1153 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A49A 90 0C 94         [24] 1154 	mov	dptr,#_process_last_key_PARM_2
      00A49D 12 A5 A3         [24] 1155 	lcall	_ak820_outline_0003
      00A4A0 C0 07            [24] 1156 	push	ar7
      00A4A2 C0 06            [24] 1157 	push	ar6
      00A4A4 C0 05            [24] 1158 	push	ar5
      00A4A6 C0 04            [24] 1159 	push	ar4
      00A4A8 12 9F C4         [24] 1160 	lcall	_process_last_key
      00A4AB E5 82            [12] 1161 	mov	a, dpl
      00A4AD D0 04            [24] 1162 	pop	ar4
      00A4AF D0 05            [24] 1163 	pop	ar5
      00A4B1 D0 06            [24] 1164 	pop	ar6
      00A4B3 D0 07            [24] 1165 	pop	ar7
      00A4B5 70 02            [24] 1166 	jnz	00197$
      00A4B7 A1 68            [12] 1167 	ajmp	00101$
      00A4B9                       1168 00197$:
      00A4B9 90 0C 9A         [24] 1169 	mov	dptr,#_process_repeat_key_PARM_2
      00A4BC 12 A5 A3         [24] 1170 	lcall	_ak820_outline_0003
      00A4BF C0 07            [24] 1171 	push	ar7
      00A4C1 C0 06            [24] 1172 	push	ar6
      00A4C3 C0 05            [24] 1173 	push	ar5
      00A4C5 C0 04            [24] 1174 	push	ar4
      00A4C7 11 40            [12] 1175 	acall	_process_repeat_key
      00A4C9 E5 82            [12] 1176 	mov	a, dpl
      00A4CB D0 04            [24] 1177 	pop	ar4
      00A4CD D0 05            [24] 1178 	pop	ar5
      00A4CF D0 06            [24] 1179 	pop	ar6
      00A4D1 D0 07            [24] 1180 	pop	ar7
      00A4D3 70 02            [24] 1181 	jnz	00198$
      00A4D5 A1 68            [12] 1182 	ajmp	00101$
      00A4D7                       1183 00198$:
                                   1184 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A4D7 90 0C FC         [24] 1185 	mov	dptr,#_process_record_via_PARM_2
      00A4DA 12 A5 A3         [24] 1186 	lcall	_ak820_outline_0003
      00A4DD C0 07            [24] 1187 	push	ar7
      00A4DF C0 06            [24] 1188 	push	ar6
      00A4E1 C0 05            [24] 1189 	push	ar5
      00A4E3 C0 04            [24] 1190 	push	ar4
      00A4E5 12 AA 97         [24] 1191 	lcall	_process_record_via
      00A4E8 E5 82            [12] 1192 	mov	a, dpl
      00A4EA D0 04            [24] 1193 	pop	ar4
      00A4EC D0 05            [24] 1194 	pop	ar5
      00A4EE D0 06            [24] 1195 	pop	ar6
      00A4F0 D0 07            [24] 1196 	pop	ar7
      00A4F2 70 02            [24] 1197 	jnz	00199$
      00A4F4 A1 68            [12] 1198 	ajmp	00101$
      00A4F6                       1199 00199$:
                                   1200 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A4F6 90 0C 7C         [24] 1201 	mov	dptr,#_process_caps_word_PARM_2
      00A4F9 12 A5 A3         [24] 1202 	lcall	_ak820_outline_0003
      00A4FC C0 07            [24] 1203 	push	ar7
      00A4FE C0 06            [24] 1204 	push	ar6
      00A500 C0 05            [24] 1205 	push	ar5
      00A502 C0 04            [24] 1206 	push	ar4
      00A504 12 9D 4D         [24] 1207 	lcall	_process_caps_word
      00A507 E5 82            [12] 1208 	mov	a, dpl
      00A509 D0 04            [24] 1209 	pop	ar4
      00A50B D0 05            [24] 1210 	pop	ar5
      00A50D D0 06            [24] 1211 	pop	ar6
      00A50F D0 07            [24] 1212 	pop	ar7
      00A511 60 55            [24] 1213 	jz	00101$
                                   1214 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A513 90 0C 81         [24] 1215 	mov	dptr,#_process_grave_esc_PARM_2
      00A516 12 A5 A3         [24] 1216 	lcall	_ak820_outline_0003
      00A519 C0 07            [24] 1217 	push	ar7
      00A51B C0 06            [24] 1218 	push	ar6
      00A51D C0 05            [24] 1219 	push	ar5
      00A51F C0 04            [24] 1220 	push	ar4
      00A521 12 9E 60         [24] 1221 	lcall	_process_grave_esc
      00A524 E5 82            [12] 1222 	mov	a, dpl
      00A526 D0 04            [24] 1223 	pop	ar4
      00A528 D0 05            [24] 1224 	pop	ar5
      00A52A D0 06            [24] 1225 	pop	ar6
      00A52C D0 07            [24] 1226 	pop	ar7
      00A52E 60 38            [24] 1227 	jz	00101$
                                   1228 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A530 90 0C 9F         [24] 1229 	mov	dptr,#_process_rgb_PARM_2
      00A533 12 A5 A3         [24] 1230 	lcall	_ak820_outline_0003
      00A536 C0 07            [24] 1231 	push	ar7
      00A538 C0 06            [24] 1232 	push	ar6
      00A53A C0 05            [24] 1233 	push	ar5
      00A53C C0 04            [24] 1234 	push	ar4
      00A53E 11 A1            [12] 1235 	acall	_process_rgb
      00A540 E5 82            [12] 1236 	mov	a, dpl
      00A542 D0 04            [24] 1237 	pop	ar4
      00A544 D0 05            [24] 1238 	pop	ar5
      00A546 D0 06            [24] 1239 	pop	ar6
      00A548 D0 07            [24] 1240 	pop	ar7
      00A54A 60 1C            [24] 1241 	jz	00101$
                                   1242 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A54C 90 0C A5         [24] 1243 	mov	dptr,#_process_tri_layer_PARM_2
      00A54F 12 A5 A3         [24] 1244 	lcall	_ak820_outline_0003
      00A552 C0 07            [24] 1245 	push	ar7
      00A554 C0 06            [24] 1246 	push	ar6
      00A556 C0 05            [24] 1247 	push	ar5
      00A558 C0 04            [24] 1248 	push	ar4
      00A55A 31 52            [12] 1249 	acall	_process_tri_layer
      00A55C E5 82            [12] 1250 	mov	a, dpl
      00A55E D0 04            [24] 1251 	pop	ar4
      00A560 D0 05            [24] 1252 	pop	ar5
      00A562 D0 06            [24] 1253 	pop	ar6
      00A564 D0 07            [24] 1254 	pop	ar7
      00A566 70 04            [24] 1255 	jnz	00102$
                                   1256 ;	quantum/quantum.c:561: true)) {
      00A568                       1257 00101$:
                                   1258 ;	quantum/quantum.c:562: return false;
      00A568 75 82 00         [24] 1259 	mov	dpl, #0x00
      00A56B 22               [24] 1260 	ret
      00A56C                       1261 00102$:
                                   1262 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A56C 12 37 9F         [24] 1263 	lcall	_ak820_outline_0002
      00A56F 60 2D            [24] 1264 	jz	00116$
                                   1265 ;	quantum/quantum.c:566: switch (keycode) {
      00A571 BC 00 05         [24] 1266 	cjne	r4,#0x00,00205$
      00A574 BD 7C 02         [24] 1267 	cjne	r5,#0x7c,00205$
      00A577 80 10            [24] 1268 	sjmp	00111$
      00A579                       1269 00205$:
      00A579 BC 01 05         [24] 1270 	cjne	r4,#0x01,00206$
      00A57C BD 7C 02         [24] 1271 	cjne	r5,#0x7c,00206$
      00A57F 80 0E            [24] 1272 	sjmp	00112$
      00A581                       1273 00206$:
                                   1274 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A581 BC 03 1A         [24] 1275 	cjne	r4,#0x03,00116$
      00A584 BD 7C 17         [24] 1276 	cjne	r5,#0x7c,00116$
      00A587 80 0C            [24] 1277 	sjmp	00113$
      00A589                       1278 00111$:
                                   1279 ;	quantum/quantum.c:569: reset_keyboard();
      00A589 71 2B            [12] 1280 	acall	_reset_keyboard
                                   1281 ;	quantum/quantum.c:570: return false;
      00A58B 75 82 00         [24] 1282 	mov	dpl, #0x00
                                   1283 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A58E 22               [24] 1284 	ret
      00A58F                       1285 00112$:
                                   1286 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A58F 71 30            [12] 1287 	acall	_soft_reset_keyboard
                                   1288 ;	quantum/quantum.c:573: return false;
      00A591 75 82 00         [24] 1289 	mov	dpl, #0x00
                                   1290 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A594 22               [24] 1291 	ret
      00A595                       1292 00113$:
                                   1293 ;	quantum/quantum.c:592: eeconfig_disable();
      00A595 12 94 D2         [24] 1294 	lcall	_eeconfig_disable
                                   1295 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A598 71 30            [12] 1296 	acall	_soft_reset_keyboard
                                   1297 ;	quantum/quantum.c:595: return false;
      00A59A 75 82 00         [24] 1298 	mov	dpl, #0x00
                                   1299 ;	quantum/quantum.c:650: }
      00A59D 22               [24] 1300 	ret
      00A59E                       1301 00116$:
                                   1302 ;	quantum/quantum.c:654: return true;
      00A59E 75 82 01         [24] 1303 	mov	dpl, #0x01
                                   1304 ;	quantum/quantum.c:658: }
      00A5A1 22               [24] 1305 	ret
                                   1306 ;------------------------------------------------------------
                                   1307 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1308 ;------------------------------------------------------------
                                   1309 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_681'
                                   1310 ;------------------------------------------------------------
                                   1311 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1312 ;	-----------------------------------------
                                   1313 ;	 function shutdown_user
                                   1314 ;	-----------------------------------------
      00A5A2                       1315 _shutdown_user:
      00A5A2 22               [24] 1316 	ret
                                   1317 ;------------------------------------------------------------
                                   1318 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1319 ;------------------------------------------------------------
                                   1320 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1321 ;	-----------------------------------------
                                   1322 	.area CSEG    (CODE)
                                   1323 	.area CONST   (CODE)
                                   1324 	.area XINIT   (CODE)
                                   1325 	.area CABS    (ABS,CODE)
                                   1326 
                                   1327 ; Experimental exact instruction outlining.
                                   1328 	.globl _ak820_outline_0002
                                   1329 	.globl _ak820_outline_0003
                                   1330 	.globl _ak820_outline_0006
                                   1331 	.globl _ak820_outline_0008
                                   1332 	.globl _ak820_outline_0022
                                   1333 	.globl _ak820_outline_0036
                                   1334 	.globl _ak820_outline_0038
                                   1335 	.globl _ak820_outline_0058
                                   1336 	.globl _ak820_outline_0064
                                   1337 	.globl _ak820_outline_0066
                                   1338 	.globl _ak820_outline_0108
                                   1339 	.globl _ak820_outline_0109
                                   1340 	.globl _ak820_outline_0119
                                   1341 	.globl _ak820_outline_0120
                                   1342 	.globl _ak820_outline_0127
                                   1343 	.globl _ak820_outline_0137
                                   1344 	.globl _ak820_outline_0143
                                   1345 	.globl _ak820_outline_0150
                                   1346 	.globl _ak820_outline_0152
                                   1347 
                                   1348 	.area CSEG (CODE)
                                   1349 ; function ak820_outline_0003
      00A5A3                       1350 _ak820_outline_0003:
      00A5A3 EE               [12] 1351 	mov	a,r6
      00A5A4 F0               [24] 1352 	movx	@dptr,a
      00A5A5 EF               [12] 1353 	mov	a,r7
      00A5A6 A3               [24] 1354 	inc	dptr
      00A5A7 F0               [24] 1355 	movx	@dptr,a
      00A5A8 E4               [12] 1356 	clr	a
      00A5A9 A3               [24] 1357 	inc	dptr
      00A5AA F0               [24] 1358 	movx	@dptr,a
      00A5AB 8C 82            [24] 1359 	mov	dpl,r4
      00A5AD 8D 83            [24] 1360 	mov	dph,r5
      00A5AF 22               [24] 1361 	ret
