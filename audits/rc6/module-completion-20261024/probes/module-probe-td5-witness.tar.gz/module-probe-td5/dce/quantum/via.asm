;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module via
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _raw_hid_receive_kb
	.globl _vialrgb_save
	.globl _vialrgb_set_value
	.globl _vialrgb_get_value
	.globl _ak820_nvm_schema_fault
	.globl _raw_hid_send
	.globl _dynamic_keymap_macro_send
	.globl _dynamic_keymap_macro_reset
	.globl _dynamic_keymap_macro_set_buffer
	.globl _dynamic_keymap_macro_get_buffer
	.globl _dynamic_keymap_macro_get_buffer_size
	.globl _dynamic_keymap_macro_get_count
	.globl _dynamic_keymap_set_buffer
	.globl _dynamic_keymap_get_buffer
	.globl _dynamic_keymap_reset
	.globl _dynamic_keymap_set_keycode
	.globl _dynamic_keymap_get_keycode
	.globl _dynamic_keymap_get_layer_count
	.globl _vial_handle_cmd
	.globl _eeprom_update_byte
	.globl _eeprom_read_byte
	.globl _bootloader_jump
	.globl _timer_read32
	.globl _matrix_get_row
	.globl _mDelaymS
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _raw_hid_receive_PARM_2
	.globl _raw_hid_receive_kb_PARM_2
	.globl _process_record_via_PARM_2
	.globl _via_eeprom_is_valid
	.globl _via_eeprom_set_valid
	.globl _via_init
	.globl _eeconfig_init_via
	.globl _via_get_layout_options
	.globl _via_set_layout_options_kb
	.globl _via_set_layout_options
	.globl _process_record_via
	.globl _raw_hid_receive
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_raw_hid_receive_sloc0_1_0:
	.ds 4
_raw_hid_receive_sloc1_1_0:
	.ds 1
_raw_hid_receive_sloc2_1_0:
	.ds 1
_raw_hid_receive_sloc3_1_0:
	.ds 2
_raw_hid_receive_sloc4_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_via_eeprom_is_valid_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_via_eeprom_set_valid_valid_10000_611:
	.ds 1
_via_set_layout_options_value_10000_627:
	.ds 4
_process_record_via_PARM_2:
	.ds 3
_process_record_via_keycode_10000_629:
	.ds 2
_raw_hid_receive_kb_PARM_2:
	.ds 1
_raw_hid_receive_kb_data_10000_635:
	.ds 3
_raw_hid_receive_PARM_2:
	.ds 1
_raw_hid_receive_packet_10000_637:
	.ds 3
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function via_eeprom_is_valid
;	-----------------------------------------
_via_eeprom_is_valid:
;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
	mov	dptr,#0x0025
	mov	b, #0x00
	lcall	_eeprom_read_byte
	mov	r7, dpl
	cjne	r7,#0x03,00103$
	mov	dptr,#0x0026
	mov	b, #0x00
	lcall	_eeprom_read_byte
	mov	r7, dpl
	cjne	r7,#0x20,00103$
	mov	dptr,#0x0027
	mov	b, #0x00
	lcall	_eeprom_read_byte
	mov	r7, dpl
	cjne	r7,#0x08,00126$
	sjmp	00104$
00126$:
00103$:
;	assignBit
	clr	_via_eeprom_is_valid_sloc0_1_0
	sjmp	00105$
00104$:
;	assignBit
	setb	_via_eeprom_is_valid_sloc0_1_0
00105$:
	mov	c,_via_eeprom_is_valid_sloc0_1_0
	lcall	_ak820_outline_0150
;	quantum/via.c:104: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'via_eeprom_set_valid'
;------------------------------------------------------------
;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
;------------------------------------------------------------
;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
;	-----------------------------------------
;	 function via_eeprom_set_valid
;	-----------------------------------------
_via_eeprom_set_valid:
	mov	a,dpl
	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
	movx	@dptr,a
;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
	movx	a,@dptr
	jz	00103$
	mov	r7,#0x03
	sjmp	00104$
00103$:
	mov	r7,#0xff
00104$:
	mov	dptr,#_eeprom_update_byte_PARM_2
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#0x0025
	mov	b, #0x00
	lcall	_eeprom_update_byte
;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
	movx	a,@dptr
	jz	00105$
	mov	r7,#0x20
	sjmp	00106$
00105$:
	mov	r7,#0xff
00106$:
	mov	dptr,#_eeprom_update_byte_PARM_2
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#0x0026
	mov	b, #0x00
	lcall	_eeprom_update_byte
;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
	movx	a,@dptr
	jz	00107$
	mov	r7,#0x08
	sjmp	00108$
00107$:
	mov	r7,#0xff
00108$:
	mov	dptr,#_eeprom_update_byte_PARM_2
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#0x0027
	mov	b, #0x00
;	quantum/via.c:123: }
	ljmp	_eeprom_update_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'via_init_kb'
;------------------------------------------------------------
;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
;	-----------------------------------------
;	 function via_init
;	-----------------------------------------
_via_init:
;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
	acall	_via_get_layout_options
	acall	_via_set_layout_options_kb
;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
	acall	_via_eeprom_is_valid
	mov	a, dpl
	jnz	00103$
;	quantum/via.c:147: ak820_nvm_schema_fault();
;	quantum/via.c:152: }
	ljmp	_ak820_nvm_schema_fault
00103$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_init_via'
;------------------------------------------------------------
;	quantum/via.c:154: void eeconfig_init_via(void) {
;	-----------------------------------------
;	 function eeconfig_init_via
;	-----------------------------------------
_eeconfig_init_via:
;	quantum/via.c:156: via_eeprom_set_valid(false);
	mov	dpl, #0x00
	acall	_via_eeprom_set_valid
;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
	lcall	_ak820_outline_0155
	acall	_via_set_layout_options
;	quantum/via.c:160: dynamic_keymap_reset();
	lcall	_dynamic_keymap_reset
;	quantum/via.c:162: dynamic_keymap_macro_reset();
	lcall	_dynamic_keymap_macro_reset
;	quantum/via.c:164: via_eeprom_set_valid(true);
	mov	dpl, #0x01
;	quantum/via.c:165: }
	ajmp	_via_eeprom_set_valid
;------------------------------------------------------------
;Allocation info for local variables in function 'via_get_layout_options'
;------------------------------------------------------------
;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
;	-----------------------------------------
;	 function via_get_layout_options
;	-----------------------------------------
_via_get_layout_options:
;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
	mov	dptr,#0x0028
	mov	b, #0x00
	lcall	_eeprom_read_byte
	mov	r7, dpl
	mov	r6,#0x00
	mov	r5,#0x00
	mov	r4,#0x00
	lcall	_ak820_outline_0160
	mov	b, r5
	mov	a, r4
;	quantum/via.c:185: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'via_set_layout_options_kb'
;------------------------------------------------------------
;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
;------------------------------------------------------------
;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
;	-----------------------------------------
;	 function via_set_layout_options_kb
;	-----------------------------------------
_via_set_layout_options_kb:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'via_set_layout_options'
;------------------------------------------------------------
;value         Allocated with name '_via_set_layout_options_value_10000_627'
;------------------------------------------------------------
;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
;	-----------------------------------------
;	 function via_set_layout_options
;	-----------------------------------------
_via_set_layout_options:
	lcall	_ak820_outline_0122
	mov	dptr,#_via_set_layout_options_value_10000_627
	lcall	_ak820_outline_0047
;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
	mov	dptr,#_via_set_layout_options_value_10000_627
	movx	a,@dptr
	mov	dptr,#_eeprom_update_byte_PARM_2
	movx	@dptr,a
	mov	dptr,#0x0028
	mov	b, #0x00
;	quantum/via.c:202: }
	ljmp	_eeprom_update_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_via'
;------------------------------------------------------------
;record        Allocated with name '_process_record_via_PARM_2'
;keycode       Allocated with name '_process_record_via_keycode_10000_629'
;id            Allocated with name '_process_record_via_id_50000_634'
;------------------------------------------------------------
;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
;	-----------------------------------------
;	 function process_record_via
;	-----------------------------------------
_process_record_via:
	lcall	_ak820_outline_0109
	mov	dptr,#_process_record_via_keycode_10000_629
	lcall	_ak820_outline_0108
;	quantum/via.c:207: if (record->event.pressed) {
	mov	dptr,#_process_record_via_PARM_2
	lcall	_ak820_outline_0014
	mov	a,#0x05
	lcall	_ak820_outline_0163
	lcall	_ak820_outline_0050
	lcall	__gptrget
	jz	00105$
;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
	mov	dptr,#_process_record_via_keycode_10000_629
	lcall	_ak820_outline_0010
	mov	a,#0x100 - 0x77
	add	a,r5
	jnc	00105$
	clr	c
	mov	a,#0x7f
	subb	a,r4
	mov	a,#0x77
	subb	a,r5
	jc	00105$
;	free result
;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
;	quantum/via.c:210: dynamic_keymap_macro_send(id);
	mov	dpl, r6
	lcall	_dynamic_keymap_macro_send
;	quantum/via.c:211: return false;
	mov	dpl, #0x00
	ret
00105$:
;	quantum/via.c:215: return true;
	mov	dpl, #0x01
;	quantum/via.c:216: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'raw_hid_receive_kb'
;------------------------------------------------------------
;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
;------------------------------------------------------------
;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
;	-----------------------------------------
;	 function raw_hid_receive_kb
;	-----------------------------------------
_raw_hid_receive_kb:
	lcall	_ak820_outline_0042
	mov	dptr,#_raw_hid_receive_kb_data_10000_635
	lcall	_ak820_outline_0019
;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
	mov	dptr,#_raw_hid_receive_kb_data_10000_635
	lcall	_ak820_outline_0001
;	quantum/via.c:223: *command_id         = id_unhandled;
	mov	a,#0xff
;	quantum/via.c:224: }
	ljmp	__gptrput
;------------------------------------------------------------
;Allocation info for local variables in function 'raw_hid_receive'
;------------------------------------------------------------
;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
;length        Allocated with name '_raw_hid_receive_PARM_2'
;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
;data          Allocated with name '_raw_hid_receive_data_10000_638'
;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
;value         Allocated with name '_raw_hid_receive_value_70000_652'
;value         Allocated with name '_raw_hid_receive_value_70000_653'
;i             Allocated with name '_raw_hid_receive_i_70001_656'
;row           Allocated with name '_raw_hid_receive_row_80001_657'
;value         Allocated with name '_raw_hid_receive_value_90001_658'
;value         Allocated with name '_raw_hid_receive_value_70000_663'
;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
;size          Allocated with name '_raw_hid_receive_size_40000_674'
;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
;size          Allocated with name '_raw_hid_receive_size_40000_675'
;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
;size          Allocated with name '_raw_hid_receive_size_40001_680'
;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
;size          Allocated with name '_raw_hid_receive_size_40000_685'
;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
;size          Allocated with name '_raw_hid_receive_size_40000_687'
;i             Allocated with name '_raw_hid_receive_i_60000_692'
;------------------------------------------------------------
;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
;	-----------------------------------------
;	 function raw_hid_receive
;	-----------------------------------------
_raw_hid_receive:
	lcall	_ak820_outline_0042
	mov	dptr,#_raw_hid_receive_packet_10000_637
	lcall	_ak820_outline_0019
;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
	mov	dptr,#_raw_hid_receive_packet_10000_637
	lcall	_ak820_outline_0058
;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
	mov	a,#0x01
	lcall	_ak820_outline_0164
;	quantum/via.c:245: if (length != 32) return;
	mov	dptr,#_raw_hid_receive_PARM_2
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x20,00520$
	sjmp	00102$
00520$:
	ret
00102$:
;	quantum/via.c:249: if (vial_unlock_in_progress) {
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jz	00114$
;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
	lcall	_ak820_outline_0094
	mov	r2,a
	cjne	r2,#0xfe,00522$
	sjmp	00104$
00522$:
;	quantum/via.c:252: return;
	ret
00104$:
;	quantum/via.c:257: uint8_t cmd = data[1];
	lcall	_ak820_outline_0098
;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
	mov	r2,a
	jz	00114$
	cjne	r2,#0x01,00524$
	sjmp	00114$
00524$:
	cjne	r2,#0x02,00525$
	sjmp	00114$
00525$:
	cjne	r2,#0x05,00526$
	sjmp	00114$
00526$:
	cjne	r2,#0x06,00527$
	sjmp	00114$
00527$:
	cjne	r2,#0x07,00528$
	sjmp	00114$
00528$:
	cjne	r2,#0x08,00529$
	sjmp	00530$
00529$:
	ljmp	00171$
00530$:
;	quantum/via.c:259: goto skip;
00114$:
;	quantum/via.c:263: switch (*command_id) {
	lcall	_ak820_outline_0094
	mov	r2,a
	cjne	r2,#0x01,00531$
	sjmp	00115$
00531$:
	cjne	r2,#0x02,00532$
	sjmp	00116$
00532$:
	cjne	r2,#0x03,00533$
	ajmp	00125$
00533$:
	cjne	r2,#0x04,00534$
	ajmp	00129$
00534$:
	cjne	r2,#0x05,00535$
	ajmp	00130$
00535$:
	cjne	r2,#0x06,00536$
	ajmp	00135$
00536$:
	cjne	r2,#0x07,00537$
	ajmp	00136$
00537$:
	cjne	r2,#0x08,00538$
	ajmp	00137$
00538$:
	cjne	r2,#0x09,00539$
	ajmp	00138$
00539$:
	cjne	r2,#0x0b,00540$
	ljmp	00161$
00540$:
	cjne	r2,#0x0c,00541$
	ajmp	00139$
00541$:
	cjne	r2,#0x0d,00542$
	ajmp	00140$
00542$:
	cjne	r2,#0x0e,00543$
	ajmp	00141$
00543$:
	cjne	r2,#0x0f,00544$
	ajmp	00144$
00544$:
	cjne	r2,#0x10,00545$
	ajmp	00151$
00545$:
	cjne	r2,#0x11,00546$
	ajmp	00154$
00546$:
	cjne	r2,#0x12,00547$
	ljmp	00155$
00547$:
	cjne	r2,#0x13,00548$
	ljmp	00158$
00548$:
	cjne	r2,#0xfe,00549$
	ljmp	00168$
00549$:
	ljmp	00169$
;	quantum/via.c:264: case id_get_protocol_version: {
00115$:
;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
	lcall	_ak820_outline_0127
	clr	a
	lcall	_ak820_outline_0037
;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
	mov	a,#0x09
	movx	@dptr,a
;	quantum/via.c:267: break;
	ljmp	00171$
;	quantum/via.c:269: case id_get_keyboard_value: {
00116$:
;	quantum/via.c:270: switch (command_data[0]) {
	lcall	_ak820_outline_0098
	mov	r2,a
	cjne	r2,#0x01,00550$
	sjmp	00117$
00550$:
	cjne	r2,#0x02,00551$
	sjmp	00118$
00551$:
	cjne	r2,#0x03,00552$
	ajmp	00119$
00552$:
	ajmp	00123$
;	quantum/via.c:271: case id_uptime: {
00117$:
;	quantum/via.c:272: uint32_t value  = timer_read32();
	lcall	_timer_read32
	mov	_raw_hid_receive_sloc0_1_0,dpl
	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
	lcall	_ak820_outline_0119
	inc	dptr
	inc	dptr
	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
	lcall	_ak820_outline_0037
;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
	inc	dptr
	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
	movx	@dptr,a
;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
	lcall	_ak820_outline_0023
	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
	movx	@dptr,a
;	quantum/via.c:276: command_data[4] = value & 0xFF;
	lcall	_ak820_outline_0012
	mov	a,_raw_hid_receive_sloc0_1_0
	movx	@dptr,a
;	quantum/via.c:277: break;
	ljmp	00171$
;	quantum/via.c:279: case id_layout_options: {
00118$:
;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
	push	ar3
	push	ar7
	push	ar6
	push	ar3
	acall	_via_get_layout_options
	mov	_raw_hid_receive_sloc0_1_0,dpl
	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
	lcall	_ak820_outline_0119
	inc	dptr
	inc	dptr
	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
	lcall	_ak820_outline_0037
;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
	inc	dptr
	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
	movx	@dptr,a
;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
	lcall	_ak820_outline_0023
	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
	movx	@dptr,a
;	quantum/via.c:284: command_data[4] = value & 0xFF;
	lcall	_ak820_outline_0012
	mov	a,_raw_hid_receive_sloc0_1_0
	movx	@dptr,a
;	quantum/via.c:285: break;
	pop	ar3
	ljmp	00171$
;	quantum/via.c:287: case id_switch_matrix_state: {
00119$:
;	quantum/via.c:290: if (!vial_unlocked)
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	jnz	00553$
	ljmp	00171$
00553$:
;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
	mov	r2,#0x01
	mov	r1,#0x00
00173$:
	cjne	r1,#0x10,00554$
00554$:
	jc	00555$
	ljmp	00171$
00555$:
;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
	mov	dpl, r1
	lcall	_matrix_get_row
	mov	r0, dpl
;	quantum/via.c:307: command_data[i++] = value & 0xFF;
	mov	a,r2
	add	a, r4
	mov	dpl,a
	clr	a
	addc	a, r5
	mov	dph,a
	inc	r2
	mov	a,r0
	movx	@dptr,a
;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
	inc	r1
;	quantum/via.c:312: default: {
	sjmp	00173$
00123$:
;	quantum/via.c:313: raw_hid_receive_kb(data, length);
	lcall	_ak820_outline_0096
	mov	dptr,#_raw_hid_receive_kb_PARM_2
	lcall	_ak820_outline_0044
	push	ar7
	push	ar6
	push	ar3
	acall	_raw_hid_receive_kb
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:317: break;
	ljmp	00171$
;	quantum/via.c:319: case id_set_keyboard_value: {
00125$:
;	quantum/via.c:320: switch (command_data[0]) {
	lcall	_ak820_outline_0098
	mov	r2,a
	cjne	r2,#0x02,00556$
	sjmp	00557$
00556$:
	ajmp	00127$
00557$:
;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
	push	ar3
	lcall	_ak820_outline_0035
	mov	r0,a
	mov	r1,#0x00
	mov	r3,#0x00
	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
	mov	_raw_hid_receive_sloc0_1_0,r3
	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
	lcall	_ak820_outline_0016
	mov	r0,a
	mov	ar3,r1
	mov	ar2,r0
	clr	a
	orl	_raw_hid_receive_sloc0_1_0,a
	mov	a,r1
	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
	mov	a,r2
	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
	mov	a,r3
	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
	lcall	_ak820_outline_0023
	movx	a,@dptr
	mov	r0,a
	mov	r1,#0x00
	mov	r2,#0x00
	mov	ar3,r2
	mov	ar2,r1
	mov	ar1,r0
	clr	a
	orl	_raw_hid_receive_sloc0_1_0,a
	mov	a,r1
	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
	mov	a,r2
	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
	mov	a,r3
	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
	lcall	_ak820_outline_0012
	movx	a,@dptr
	mov	r0,a
	clr	a
	mov	r1,a
	mov	r2,a
	mov	r3,a
	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
	orl	ar1,a
	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
	orl	ar2,a
	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
	orl	ar3,a
;	quantum/via.c:323: via_set_layout_options(value);
	lcall	_ak820_outline_0159
	mov	b, r2
	mov	a, r3
	push	ar7
	push	ar6
	push	ar3
	acall	_via_set_layout_options
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:324: break;
	pop	ar3
	ljmp	00171$
;	quantum/via.c:326: default: {
00127$:
;	quantum/via.c:327: raw_hid_receive_kb(data, length);
	lcall	_ak820_outline_0096
	mov	dptr,#_raw_hid_receive_kb_PARM_2
	lcall	_ak820_outline_0044
	push	ar7
	push	ar6
	push	ar3
	acall	_raw_hid_receive_kb
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:331: break;
	ljmp	00171$
;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
00129$:
;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
	lcall	_ak820_outline_0098
	mov	r2,a
	lcall	_ak820_outline_0035
	mov	r1,a
	lcall	_ak820_outline_0016
	mov	r0,a
	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
	mov	a,r1
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
	mov	a,r0
	movx	@dptr,a
	mov	dpl, r2
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_get_keycode
	mov	r1, dpl
	mov	r2, dph
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:335: command_data[3]  = keycode >> 8;
	lcall	_ak820_outline_0023
	mov	ar0,r2
	mov	a,r0
	movx	@dptr,a
;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
	lcall	_ak820_outline_0012
	mov	a,r1
	movx	@dptr,a
;	quantum/via.c:337: break;
	ljmp	00171$
;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
00130$:
;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	jnz	00132$
	lcall	_ak820_outline_0023
	movx	a,@dptr
	mov	r2,a
	cjne	r2,#0x7c,00132$
	mov	a,#0x05
	add	a, r6
	lcall	_ak820_outline_0017
	jnz	00132$
;	quantum/via.c:344: *command_id = id_unhandled;
	lcall	_ak820_outline_0119
	mov	a,#0xff
	movx	@dptr,a
;	quantum/via.c:345: break;
	ljmp	00171$
00132$:
;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
	push	ar3
	lcall	_ak820_outline_0098
	mov	_raw_hid_receive_sloc2_1_0,a
	lcall	_ak820_outline_0035
	mov	_raw_hid_receive_sloc1_1_0,a
	lcall	_ak820_outline_0016
	mov	_raw_hid_receive_sloc0_1_0,a
	lcall	_ak820_outline_0023
	movx	a,@dptr
	mov	r3,a
	mov	r0,#0x00
	lcall	_ak820_outline_0012
	movx	a,@dptr
	mov	r2,#0x00
	orl	ar0,a
	mov	a,r2
	orl	ar3,a
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
	mov	a,_raw_hid_receive_sloc1_1_0
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
	mov	a,_raw_hid_receive_sloc0_1_0
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
	mov	a,r0
	lcall	_ak820_outline_0189
	mov	dpl, _raw_hid_receive_sloc2_1_0
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_set_keycode
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:349: break;
	pop	ar3
	ljmp	00171$
;	quantum/via.c:351: case id_dynamic_keymap_reset: {
00135$:
;	quantum/via.c:352: dynamic_keymap_reset();
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_reset
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:353: break;
	ljmp	00171$
;	quantum/via.c:355: case id_lighting_set_value: {
00136$:
;	quantum/via.c:363: vialrgb_set_value(data, length);
	lcall	_ak820_outline_0096
	mov	dptr,#_vialrgb_set_value_PARM_2
	lcall	_ak820_outline_0044
	push	ar7
	push	ar6
	push	ar3
	lcall	_vialrgb_set_value
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:375: break;
	ljmp	00171$
;	quantum/via.c:377: case id_lighting_get_value: {
00137$:
;	quantum/via.c:385: vialrgb_get_value(data, length);
	lcall	_ak820_outline_0096
	mov	dptr,#_vialrgb_get_value_PARM_2
	lcall	_ak820_outline_0044
	push	ar7
	push	ar6
	push	ar3
	lcall	_vialrgb_get_value
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:397: break;
	ljmp	00171$
;	quantum/via.c:399: case id_lighting_save: {
00138$:
;	quantum/via.c:407: vialrgb_save(data, length);
	lcall	_ak820_outline_0096
	mov	dptr,#_vialrgb_save_PARM_2
	lcall	_ak820_outline_0044
	push	ar7
	push	ar6
	push	ar3
	lcall	_vialrgb_save
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:419: break;
	ljmp	00171$
;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
00139$:
;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_dynamic_keymap_macro_get_count
	mov	r2, dpl
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	lcall	_ak820_outline_0127
	mov	a,r2
	movx	@dptr,a
;	quantum/via.c:430: break;
	ljmp	00171$
;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
00140$:
;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_dynamic_keymap_macro_get_buffer_size
	mov	r1, dpl
	mov	r2, dph
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/via.c:434: command_data[0] = size >> 8;
	mov	ar0,r2
	lcall	_ak820_outline_0127
	mov	a,r0
	lcall	_ak820_outline_0037
;	quantum/via.c:435: command_data[1] = size & 0xFF;
	mov	a,r1
	movx	@dptr,a
;	quantum/via.c:436: break;
	ljmp	00171$
;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
00141$:
;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
	push	ar3
	lcall	_ak820_outline_0004
	mov	_raw_hid_receive_sloc0_1_0,r1
	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
	lcall	_ak820_outline_0016
	mov	r3,a
;	quantum/via.c:441: if (size <= 28)
	mov	_raw_hid_receive_sloc3_1_0,r3
	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
	clr	c
	mov	a,#0x1c
	subb	a,r3
	pop	ar3
	jnc	00562$
	ljmp	00171$
00562$:
;	free result
;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
	lcall	_ak820_outline_0073
	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
	mov	a,_raw_hid_receive_sloc3_1_0
	movx	@dptr,a
	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
	lcall	_ak820_outline_0089
	mov	dpl, _raw_hid_receive_sloc0_1_0
	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_macro_get_buffer
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:443: break;
	ljmp	00171$
;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
00144$:
;	quantum/via.c:448: if (!vial_unlocked) {
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	jnz	00146$
;	quantum/via.c:450: return;
	ret
00146$:
;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
	push	ar3
	lcall	_ak820_outline_0004
	mov	_raw_hid_receive_sloc3_1_0,r1
	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
	lcall	_ak820_outline_0016
	mov	_raw_hid_receive_sloc0_1_0, a
	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
	clr	c
	mov	a,#0x1c
	subb	a,_raw_hid_receive_sloc4_1_0
	clr	a
	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
	pop	ar3
	jc	00147$
;	free result
	mov	ar1,r3
	mov	r2,#0x00
	mov	a,r1
	add	a,#0xfc
	mov	r1,a
	mov	a,r2
	addc	a,#0xff
	mov	r2,a
	clr	c
	mov	a,r1
	subb	a,_raw_hid_receive_sloc4_1_0
	mov	a,r2
	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
	jc	00147$
;	free result
	lcall	_ak820_outline_0073
	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
	mov	a,_raw_hid_receive_sloc0_1_0
	movx	@dptr,a
	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
	lcall	_ak820_outline_0089
	mov	dpl, _raw_hid_receive_sloc3_1_0
	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_macro_set_buffer
	mov	a, dpl
	pop	ar3
	pop	ar6
	pop	ar7
	jz	00566$
	ljmp	00171$
00566$:
00147$:
	ret
;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
00151$:
;	quantum/via.c:470: if (!vial_unlocked) return;
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	jnz	00153$
	ret
00153$:
;	quantum/via.c:472: dynamic_keymap_macro_reset();
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_macro_reset
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:473: break;
	ljmp	00171$
;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
00154$:
;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_dynamic_keymap_get_layer_count
	mov	r2, dpl
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	lcall	_ak820_outline_0127
	mov	a,r2
	movx	@dptr,a
;	quantum/via.c:477: break;
	ljmp	00171$
;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
00155$:
;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
	push	ar3
	lcall	_ak820_outline_0004
	mov	_raw_hid_receive_sloc4_1_0,r1
	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
	lcall	_ak820_outline_0016
	mov	r3,a
;	quantum/via.c:482: if (size <= 28)
	mov	_raw_hid_receive_sloc3_1_0,r3
	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
	clr	c
	mov	a,#0x1c
	subb	a,r3
	pop	ar3
	jnc	00568$
	ljmp	00171$
00568$:
;	free result
;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
	lcall	_ak820_outline_0073
	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
	mov	a,_raw_hid_receive_sloc3_1_0
	movx	@dptr,a
	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
	lcall	_ak820_outline_0089
	mov	dpl, _raw_hid_receive_sloc4_1_0
	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_get_buffer
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:484: break;
	ljmp	00171$
;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
00158$:
;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
	lcall	_ak820_outline_0098
	mov	r5,a
	mov	r4,#0x00
	lcall	_ak820_outline_0035
	mov	r2,#0x00
	orl	ar4,a
	mov	a,r2
	orl	ar5,a
	mov	_raw_hid_receive_sloc4_1_0,r4
	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
	lcall	_ak820_outline_0016
	mov	r1,a
	mov	r2,#0x00
;	quantum/via.c:489: if (size <= 28)
	mov	ar0,r1
	mov	a,r0
	add	a,#0xff - 0x1c
	jnc	00569$
	ljmp	00171$
00569$:
;	free result
;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
	push	ar3
	mov	a,#0x04
	add	a, r6
	mov	r0,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	r5,#0x00
	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
	mov	a,r0
	lcall	_ak820_outline_0189
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dpl, _raw_hid_receive_sloc4_1_0
	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
	push	ar7
	push	ar6
	push	ar3
	lcall	_dynamic_keymap_set_buffer
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:491: break;
	pop	ar3
	ljmp	00171$
;	quantum/via.c:495: case id_bootloader_jump: {
00161$:
;	quantum/via.c:497: if (!vial_unlocked)
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	jnz	00570$
	ljmp	00171$
00570$:
;	quantum/via.c:501: raw_hid_send(data, length);
	lcall	_ak820_outline_0153
	mov	dptr,#_raw_hid_send_PARM_2
	lcall	_ak820_outline_0090
	push	ar7
	push	ar6
	push	ar3
	lcall	_raw_hid_send
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:503: wait_ms(100);
	mov	r5,#0x64
00176$:
	mov	a,r5
	jz	00166$
	mov	dptr,#0x0001
	lcall	_mDelaymS
	dec	r5
	sjmp	00176$
00166$:
;	quantum/via.c:504: bootloader_jump();
	push	ar7
	push	ar6
	push	ar3
	lcall	_bootloader_jump
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:505: break;
;	quantum/via.c:509: case id_vial_prefix: {
	sjmp	00171$
00168$:
;	quantum/via.c:510: vial_handle_cmd(data, length);
	lcall	_ak820_outline_0153
	mov	dptr,#_vial_handle_cmd_PARM_2
	lcall	_ak820_outline_0090
	push	ar7
	push	ar6
	push	ar3
	acall	_vial_handle_cmd
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:511: break;
;	quantum/via.c:514: default: {
	sjmp	00171$
00169$:
;	quantum/via.c:516: raw_hid_receive_kb(data, length);
	lcall	_ak820_outline_0153
	mov	dptr,#_raw_hid_receive_kb_PARM_2
	lcall	_ak820_outline_0090
	push	ar7
	push	ar6
	push	ar3
	lcall	_raw_hid_receive_kb
	pop	ar3
	pop	ar6
	pop	ar7
;	quantum/via.c:521: skip:
00171$:
;	quantum/via.c:525: raw_hid_send(data, length);
	mov	r5,#0x00
	mov	dptr,#_raw_hid_send_PARM_2
	mov	a,r3
	lcall	_ak820_outline_0066
	mov	b, r5
;	quantum/via.c:526: }
	ljmp	_raw_hid_send
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0001
	.globl _ak820_outline_0004
	.globl _ak820_outline_0010
	.globl _ak820_outline_0012
	.globl _ak820_outline_0014
	.globl _ak820_outline_0016
	.globl _ak820_outline_0017
	.globl _ak820_outline_0019
	.globl _ak820_outline_0023
	.globl _ak820_outline_0035
	.globl _ak820_outline_0037
	.globl _ak820_outline_0042
	.globl _ak820_outline_0044
	.globl _ak820_outline_0047
	.globl _ak820_outline_0050
	.globl _ak820_outline_0058
	.globl _ak820_outline_0066
	.globl _ak820_outline_0073
	.globl _ak820_outline_0089
	.globl _ak820_outline_0090
	.globl _ak820_outline_0094
	.globl _ak820_outline_0096
	.globl _ak820_outline_0098
	.globl _ak820_outline_0108
	.globl _ak820_outline_0109
	.globl _ak820_outline_0119
	.globl _ak820_outline_0122
	.globl _ak820_outline_0127
	.globl _ak820_outline_0150
	.globl _ak820_outline_0153
	.globl _ak820_outline_0155
	.globl _ak820_outline_0159
	.globl _ak820_outline_0160
	.globl _ak820_outline_0163
	.globl _ak820_outline_0164
	.globl _ak820_outline_0189

	.area CSEG (CODE)
; function ak820_outline_0004
_ak820_outline_0004:
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r2,a
	mov	r1,#0x00
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r3,#0x00
	orl	ar1,a
	mov	a,r3
	orl	ar2,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0023
_ak820_outline_0023:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0044
_ak820_outline_0044:
	mov	a,r3
	movx	@dptr,a
	mov	dpl,r0
	mov	dph,r1
	mov	b,r2
	ret

	.area CSEG (CODE)
; function ak820_outline_0073
_ak820_outline_0073:
	mov	a,#0x04
	add	a,r6
	mov	r1,a
	clr	a
	addc	a,r7
	mov	r0,a
	mov	r2,#0x00
	ret

	.area CSEG (CODE)
; function ak820_outline_0089
_ak820_outline_0089:
	mov	a,r1
	movx	@dptr,a
	mov	a,r0
	inc	dptr
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0090
_ak820_outline_0090:
	mov	a,r3
	movx	@dptr,a
	mov	dpl,r2
	mov	dph,r4
	mov	b,r5
	ret

	.area CSEG (CODE)
; function ak820_outline_0096
_ak820_outline_0096:
	mov	ar0,r6
	mov	ar1,r7
	mov	r2,#0x00
	ret

	.area CSEG (CODE)
; function ak820_outline_0153
_ak820_outline_0153:
	mov	ar2,r6
	mov	ar4,r7
	mov	r5,#0x00
	ret
