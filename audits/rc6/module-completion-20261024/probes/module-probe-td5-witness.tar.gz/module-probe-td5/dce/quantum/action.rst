                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_tap_dance_cancel
                                     21 	.globl _ak820_tap_dance_task
                                     22 	.globl _ak820_tap_dance_before
                                     23 	.globl _pre_process_record_quantum
                                     24 	.globl _get_record_keycode
                                     25 	.globl _repeat_key_cancel
                                     26 	.globl _clear_owned_usages
                                     27 	.globl _owned_usage_key
                                     28 	.globl _clear_owned_keys
                                     29 	.globl _del_owned_key
                                     30 	.globl _add_owned_key
                                     31 	.globl _clear_owned_mods
                                     32 	.globl _del_owned_weak_mods
                                     33 	.globl _add_owned_weak_mods
                                     34 	.globl _del_owned_mods
                                     35 	.globl _add_owned_mods
                                     36 	.globl _clear_weak_mods
                                     37 	.globl _clear_mods
                                     38 	.globl _send_keyboard_report
                                     39 	.globl _layer_hold_clear
                                     40 	.globl _layer_hold_off
                                     41 	.globl _layer_hold_on
                                     42 	.globl _ak820_resolve_key
                                     43 	.globl _layer_xor
                                     44 	.globl _layer_and
                                     45 	.globl _layer_or
                                     46 	.globl _layer_off
                                     47 	.globl _layer_on
                                     48 	.globl _layer_move
                                     49 	.globl _layer_clear
                                     50 	.globl _layer_state_set
                                     51 	.globl _default_layer_xor
                                     52 	.globl _default_layer_and
                                     53 	.globl _default_layer_or
                                     54 	.globl _default_layer_set
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      000027                        590 _process_action_sloc0_1_0:
      000027                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      000020                        608 _process_action_sloc1_1_0:
      000020                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      0008D4                        618 _tp_buttons::
      0008D4                        619 	.ds 2
      0008D6                        620 _action_exec_PARM_1:
      0008D6                        621 	.ds 6
      0008DC                        622 _action_exec_record_10001_632:
      0008DC                        623 	.ds 9
      0008E5                        624 _ak820_action_exec_event_10000_636:
      0008E5                        625 	.ds 2
      0008E7                        626 _ak820_action_exec_snapshot_10000_637:
      0008E7                        627 	.ds 6
      0008ED                        628 _process_record_record_argument_10000_640:
      0008ED                        629 	.ds 2
      0008EF                        630 _process_record_handler_record_argument_10000_648:
      0008EF                        631 	.ds 2
      0008F1                        632 _process_record_handler_action_10000_649:
      0008F1                        633 	.ds 2
      0008F3                        634 _process_action_PARM_2:
      0008F3                        635 	.ds 2
      0008F5                        636 _process_action_record_argument_10000_660:
      0008F5                        637 	.ds 2
      0008F7                        638 _process_action_on_40000_683:
      0008F7                        639 	.ds 1
      0008F8                        640 _register_code_code_10000_717:
      0008F8                        641 	.ds 1
      0008F9                        642 _unregister_code_code_10000_731:
      0008F9                        643 	.ds 1
      0008FA                        644 _tap_code_delay_PARM_2:
      0008FA                        645 	.ds 2
      0008FC                        646 _tap_code_delay_code_10000_744:
      0008FC                        647 	.ds 1
      0008FD                        648 _tap_code_code_10000_751:
      0008FD                        649 	.ds 1
      0008FE                        650 _register_mods_mods_10000_753:
      0008FE                        651 	.ds 1
      0008FF                        652 _unregister_mods_mods_10000_757:
      0008FF                        653 	.ds 1
      000900                        654 _register_weak_mods_mods_10000_761:
      000900                        655 	.ds 1
      000901                        656 _unregister_weak_mods_mods_10000_765:
      000901                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000E87                        666 _disable_action_cache::
      000E87                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      0074BA                        711 _action_exec:
                                    712 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0074BA 90 08 D8         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0074BD 12 37 AC         [24]  714 	lcall	_ak820_outline_0006
      0074C0 12 35 B8         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0074C3 90 08 D6         [24]  717 	mov	dptr,#_action_exec_PARM_1
      0074C6 12 49 B7         [24]  718 	lcall	_ak820_tapping_before
      0074C9 E5 82            [12]  719 	mov	a, dpl
      0074CB 70 01            [24]  720 	jnz	00102$
      0074CD 22               [24]  721 	ret
      0074CE                        722 00102$:
                                    723 ;	quantum/action.c:106: ak820_tap_dance_task(event.time);
      0074CE 90 08 D8         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0074D1 12 37 AC         [24]  725 	lcall	_ak820_outline_0006
      0074D4 12 45 46         [24]  726 	lcall	_ak820_tap_dance_task
                                    727 ;	quantum/action.c:107: if (!ak820_tap_dance_before(&event)) return;
      0074D7 90 08 D6         [24]  728 	mov	dptr,#_action_exec_PARM_1
      0074DA 12 45 96         [24]  729 	lcall	_ak820_tap_dance_before
      0074DD E5 82            [12]  730 	mov	a, dpl
      0074DF 70 01            [24]  731 	jnz	00104$
      0074E1 22               [24]  732 	ret
      0074E2                        733 00104$:
                                    734 ;	quantum/action.c:126: if (event.pressed) {
      0074E2 90 08 DB         [24]  735 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0074E5 E0               [24]  736 	movx	a,@dptr
      0074E6 60 03            [24]  737 	jz	00106$
                                    738 ;	quantum/action.c:128: clear_weak_mods();
      0074E8 12 84 B1         [24]  739 	lcall	_clear_weak_mods
      0074EB                        740 00106$:
                                    741 ;	quantum/action.c:140: record.event = event;
      0074EB 90 0E 67         [24]  742 	mov	dptr,#___memcpy_PARM_2
      0074EE 74 D6            [12]  743 	mov	a,#_action_exec_PARM_1
      0074F0 F0               [24]  744 	movx	@dptr,a
      0074F1 74 08            [12]  745 	mov	a,#(_action_exec_PARM_1 >> 8)
      0074F3 12 7B 47         [24]  746 	lcall	_ak820_outline_0057
      0074F6 12 7B 67         [24]  747 	lcall	_ak820_outline_0112
      0074F9 90 08 DC         [24]  748 	mov	dptr,#_action_exec_record_10001_632
      0074FC F5 F0            [12]  749 	mov	b,a
      0074FE 12 BC D2         [24]  750 	lcall	___memcpy
                                    751 ;	quantum/action.c:142: record.tap.count = 0;
      007501 90 08 E2         [24]  752 	mov	dptr,#(_action_exec_record_10001_632 + 0x0006)
      007504 E0               [24]  753 	movx	a,@dptr
      007505 54 0F            [12]  754 	anl	a,#0x0f
      007507 F0               [24]  755 	movx	@dptr,a
                                    756 ;	quantum/action.c:147: record.keycode = 0;
      007508 90 08 E3         [24]  757 	mov	dptr,#(_action_exec_record_10001_632 + 0x0007)
      00750B 12 48 D3         [24]  758 	lcall	_ak820_outline_0144
                                    759 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00750E 90 08 E0         [24]  760 	mov	dptr,#(_action_exec_record_10001_632 + 0x0004)
      007511 E0               [24]  761 	movx	a,@dptr
      007512 60 0A            [24]  762 	jz	00109$
      007514 90 08 DC         [24]  763 	mov	dptr,#_action_exec_record_10001_632
      007517 12 A3 77         [24]  764 	lcall	_pre_process_record_quantum
      00751A E5 82            [12]  765 	mov	a, dpl
      00751C 60 10            [24]  766 	jz	00112$
      00751E                        767 00109$:
                                    768 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      00751E 90 08 DC         [24]  769 	mov	dptr,#_action_exec_record_10001_632
      007521 12 4A A1         [24]  770 	lcall	_ak820_tapping_process
      007524 E5 82            [12]  771 	mov	a, dpl
      007526 70 01            [24]  772 	jnz	00108$
      007528 22               [24]  773 	ret
      007529                        774 00108$:
                                    775 ;	quantum/action.c:185: process_record(&record);
      007529 90 08 DC         [24]  776 	mov	dptr,#_action_exec_record_10001_632
                                    777 ;	quantum/action.c:200: }
      00752C A1 6D            [12]  778 	ajmp	_process_record
      00752E                        779 00112$:
      00752E 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'ak820_action_exec'
                                    783 ;------------------------------------------------------------
                                    784 ;event         Allocated with name '_ak820_action_exec_event_10000_636'
                                    785 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_637'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_action_exec
                                    790 ;	-----------------------------------------
      00752F                        791 _ak820_action_exec:
      00752F 12 38 4E         [24]  792 	lcall	_ak820_outline_0109
      007532 90 08 E5         [24]  793 	mov	dptr,#_ak820_action_exec_event_10000_636
      007535 12 38 49         [24]  794 	lcall	_ak820_outline_0108
                                    795 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007538 90 08 E5         [24]  796 	mov	dptr,#_ak820_action_exec_event_10000_636
      00753B 12 38 2A         [24]  797 	lcall	_ak820_outline_0082
      00753E 7F 00            [12]  798 	mov	r7,#0x00
      007540 90 0E 67         [24]  799 	mov	dptr,#___memcpy_PARM_2
      007543 ED               [12]  800 	mov	a,r5
      007544 12 37 E3         [24]  801 	lcall	_ak820_outline_0019
      007547 90 0E 6A         [24]  802 	mov	dptr,#___memcpy_PARM_3
      00754A 12 7B 67         [24]  803 	lcall	_ak820_outline_0112
      00754D 90 08 E7         [24]  804 	mov	dptr,#_ak820_action_exec_snapshot_10000_637
      007550 F5 F0            [12]  805 	mov	b,a
      007552 12 BC D2         [24]  806 	lcall	___memcpy
                                    807 ;	quantum/action.c:207: action_exec(snapshot);
      007555 90 0E 67         [24]  808 	mov	dptr,#___memcpy_PARM_2
      007558 74 E7            [12]  809 	mov	a,#_ak820_action_exec_snapshot_10000_637
      00755A F0               [24]  810 	movx	@dptr,a
      00755B 74 08            [12]  811 	mov	a,#(_ak820_action_exec_snapshot_10000_637 >> 8)
      00755D 12 7B 47         [24]  812 	lcall	_ak820_outline_0057
      007560 12 7B 67         [24]  813 	lcall	_ak820_outline_0112
      007563 90 08 D6         [24]  814 	mov	dptr,#_action_exec_PARM_1
      007566 F5 F0            [12]  815 	mov	b,a
      007568 12 BC D2         [24]  816 	lcall	___memcpy
                                    817 ;	quantum/action.c:208: }
      00756B 81 BA            [12]  818 	ajmp	_action_exec
                                    819 ;------------------------------------------------------------
                                    820 ;Allocation info for local variables in function 'process_record_nocache'
                                    821 ;------------------------------------------------------------
                                    822 ;record        Allocated with name '_process_record_nocache_record_10000_638'
                                    823 ;------------------------------------------------------------
                                    824 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    825 ;	-----------------------------------------
                                    826 ;	 function process_record
                                    827 ;	-----------------------------------------
      00756D                        828 _process_record:
      00756D 12 38 4E         [24]  829 	lcall	_ak820_outline_0109
      007570 90 08 ED         [24]  830 	mov	dptr,#_process_record_record_argument_10000_640
      007573 12 38 49         [24]  831 	lcall	_ak820_outline_0108
                                    832 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007576 90 08 ED         [24]  833 	mov	dptr,#_process_record_record_argument_10000_640
      007579 12 48 69         [24]  834 	lcall	_ak820_outline_0013
                                    835 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      00757C 70 01            [24]  836 	jnz	00102$
                                    837 ;	quantum/action.c:354: return;
      00757E 22               [24]  838 	ret
      00757F                        839 00102$:
                                    840 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00757F 8E 04            [24]  841 	mov	ar4,r6
      007581 8F 05            [24]  842 	mov	ar5,r7
      007583 90 0E 67         [24]  843 	mov	dptr,#___memcpy_PARM_2
      007586 EC               [12]  844 	mov	a,r4
      007587 F0               [24]  845 	movx	@dptr,a
      007588 ED               [12]  846 	mov	a,r5
      007589 12 7B 47         [24]  847 	lcall	_ak820_outline_0057
      00758C 12 54 2B         [24]  848 	lcall	_ak820_outline_0111
      00758F 90 06 EA         [24]  849 	mov	dptr,#_ak820_tapping_source_PARM_1
      007592 F5 F0            [12]  850 	mov	b,a
      007594 C0 07            [24]  851 	push	ar7
      007596 C0 06            [24]  852 	push	ar6
      007598 12 BC D2         [24]  853 	lcall	___memcpy
      00759B 12 48 F2         [24]  854 	lcall	_ak820_tapping_source
      00759E AD 82            [24]  855 	mov	r5, dpl
      0075A0 D0 06            [24]  856 	pop	ar6
      0075A2 D0 07            [24]  857 	pop	ar7
                                    858 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0075A4 12 42 BC         [24]  859 	lcall	_ak820_outline_0012
      0075A7 E0               [24]  860 	movx	a,@dptr
      0075A8 FC               [12]  861 	mov	r4,a
                                    862 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0075A9 74 07            [12]  863 	mov	a,#0x07
      0075AB 2E               [12]  864 	add	a, r6
      0075AC FA               [12]  865 	mov	r2,a
      0075AD E4               [12]  866 	clr	a
      0075AE 3F               [12]  867 	addc	a, r7
      0075AF FB               [12]  868 	mov	r3,a
      0075B0 90 0C B1         [24]  869 	mov	dptr,#_get_record_keycode_PARM_2
      0075B3 74 01            [12]  870 	mov	a,#0x01
      0075B5 12 42 F2         [24]  871 	lcall	_ak820_outline_0066
      0075B8 C0 07            [24]  872 	push	ar7
      0075BA C0 06            [24]  873 	push	ar6
      0075BC C0 05            [24]  874 	push	ar5
      0075BE C0 04            [24]  875 	push	ar4
      0075C0 C0 03            [24]  876 	push	ar3
      0075C2 C0 02            [24]  877 	push	ar2
      0075C4 12 A3 35         [24]  878 	lcall	_get_record_keycode
      0075C7 A8 82            [24]  879 	mov	r0, dpl
      0075C9 A9 83            [24]  880 	mov	r1, dph
      0075CB D0 02            [24]  881 	pop	ar2
      0075CD D0 03            [24]  882 	pop	ar3
      0075CF D0 04            [24]  883 	pop	ar4
      0075D1 D0 05            [24]  884 	pop	ar5
      0075D3 D0 06            [24]  885 	pop	ar6
      0075D5 D0 07            [24]  886 	pop	ar7
      0075D7 12 43 22         [24]  887 	lcall	_ak820_outline_0136
      0075DA E8               [12]  888 	mov	a,r0
      0075DB F0               [24]  889 	movx	@dptr,a
      0075DC E9               [12]  890 	mov	a,r1
      0075DD A3               [24]  891 	inc	dptr
      0075DE F0               [24]  892 	movx	@dptr,a
                                    893 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0075DF 74 07            [12]  894 	mov	a,#0x07
      0075E1 12 37 DA         [24]  895 	lcall	_ak820_outline_0018
      0075E4 FA               [12]  896 	mov	r2,a
      0075E5 A3               [24]  897 	inc	dptr
      0075E6 E0               [24]  898 	movx	a,@dptr
      0075E7 FB               [12]  899 	mov	r3,a
      0075E8 90 06 FA         [24]  900 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0075EB ED               [12]  901 	mov	a,r5
      0075EC F0               [24]  902 	movx	@dptr,a
      0075ED 90 06 FB         [24]  903 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0075F0 EC               [12]  904 	mov	a,r4
      0075F1 F0               [24]  905 	movx	@dptr,a
      0075F2 12 43 22         [24]  906 	lcall	_ak820_outline_0136
      0075F5 C0 07            [24]  907 	push	ar7
      0075F7 C0 06            [24]  908 	push	ar6
      0075F9 C0 05            [24]  909 	push	ar5
      0075FB C0 04            [24]  910 	push	ar4
      0075FD 12 4C 3C         [24]  911 	lcall	_ak820_oneshot_process
      007600 E5 82            [12]  912 	mov	a, dpl
      007602 D0 04            [24]  913 	pop	ar4
      007604 D0 05            [24]  914 	pop	ar5
      007606 D0 06            [24]  915 	pop	ar6
      007608 D0 07            [24]  916 	pop	ar7
      00760A 70 01            [24]  917 	jnz	00104$
      00760C 22               [24]  918 	ret
      00760D                        919 00104$:
                                    920 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00760D 12 43 17         [24]  921 	lcall	_ak820_outline_0119
      007610 C0 07            [24]  922 	push	ar7
      007612 C0 06            [24]  923 	push	ar6
      007614 C0 05            [24]  924 	push	ar5
      007616 C0 04            [24]  925 	push	ar4
      007618 12 A3 CF         [24]  926 	lcall	_process_record_quantum
      00761B E5 82            [12]  927 	mov	a, dpl
      00761D D0 04            [24]  928 	pop	ar4
      00761F D0 05            [24]  929 	pop	ar5
      007621 D0 06            [24]  930 	pop	ar6
      007623 D0 07            [24]  931 	pop	ar7
      007625 70 0A            [24]  932 	jnz	00106$
                                    933 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007627 90 05 98         [24]  934 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00762A EC               [12]  935 	mov	a,r4
      00762B F0               [24]  936 	movx	@dptr,a
      00762C 8D 82            [24]  937 	mov	dpl, r5
                                    938 ;	quantum/action.c:376: return;
      00762E 02 2E BB         [24]  939 	ljmp	_ak820_oneshot_post
      007631                        940 00106$:
                                    941 ;	quantum/action.c:382: process_record_handler(record);
      007631 12 43 17         [24]  942 	lcall	_ak820_outline_0119
      007634 C0 05            [24]  943 	push	ar5
      007636 C0 04            [24]  944 	push	ar4
      007638 D1 48            [24]  945 	acall	_process_record_handler
      00763A D0 04            [24]  946 	pop	ar4
      00763C D0 05            [24]  947 	pop	ar5
                                    948 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00763E 90 05 98         [24]  949 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007641 EC               [12]  950 	mov	a,r4
      007642 F0               [24]  951 	movx	@dptr,a
      007643 8D 82            [24]  952 	mov	dpl, r5
                                    953 ;	quantum/action.c:392: }
      007645 02 2E BB         [24]  954 	ljmp	_ak820_oneshot_post
                                    955 ;------------------------------------------------------------
                                    956 ;Allocation info for local variables in function 'process_record_handler'
                                    957 ;------------------------------------------------------------
                                    958 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_648'
                                    959 ;record        Allocated with name '_process_record_handler_record_10000_649'
                                    960 ;action        Allocated with name '_process_record_handler_action_10000_649'
                                    961 ;------------------------------------------------------------
                                    962 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    963 ;	-----------------------------------------
                                    964 ;	 function process_record_handler
                                    965 ;	-----------------------------------------
      007648                        966 _process_record_handler:
      007648 12 38 4E         [24]  967 	lcall	_ak820_outline_0109
      00764B 90 08 EF         [24]  968 	mov	dptr,#_process_record_handler_record_argument_10000_648
      00764E 12 38 49         [24]  969 	lcall	_ak820_outline_0108
                                    970 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007651 90 08 EF         [24]  971 	mov	dptr,#_process_record_handler_record_argument_10000_648
      007654 12 37 B6         [24]  972 	lcall	_ak820_outline_0008
                                    973 ;	quantum/action.c:405: if (record->keycode) {
      007657 FC               [12]  974 	mov	r4,a
      007658 A3               [24]  975 	inc	dptr
      007659 E0               [24]  976 	movx	a,@dptr
      00765A FD               [12]  977 	mov	r5,a
      00765B 4C               [12]  978 	orl	a,r4
      00765C 60 19            [24]  979 	jz	00102$
                                    980 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00765E 12 38 59         [24]  981 	lcall	_ak820_outline_0127
      007661 C0 07            [24]  982 	push	ar7
      007663 C0 06            [24]  983 	push	ar6
      007665 12 99 E2         [24]  984 	lcall	_action_for_keycode
      007668 12 43 37         [24]  985 	lcall	_ak820_outline_0152
      00766B D0 06            [24]  986 	pop	ar6
      00766D D0 07            [24]  987 	pop	ar7
      00766F 90 08 F1         [24]  988 	mov	dptr,#_process_record_handler_action_10000_649
      007672 12 38 1E         [24]  989 	lcall	_ak820_outline_0077
      007675 80 2B            [24]  990 	sjmp	00104$
      007677                        991 00102$:
                                    992 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007677 12 7B 2F         [24]  993 	lcall	_ak820_outline_0022
      00767A 7A 00            [12]  994 	mov	r2,#0x00
      00767C 12 43 2C         [24]  995 	lcall	_ak820_outline_0143
      00767F 12 42 BC         [24]  996 	lcall	_ak820_outline_0012
      007682 E0               [24]  997 	movx	a,@dptr
      007683 90 0A 2C         [24]  998 	mov	dptr,#_ak820_resolve_key_PARM_2
      007686 F0               [24]  999 	movx	@dptr,a
      007687 8D 82            [24] 1000 	mov	dpl, r5
      007689 8C 83            [24] 1001 	mov	dph, r4
      00768B C0 07            [24] 1002 	push	ar7
      00768D C0 06            [24] 1003 	push	ar6
      00768F 12 7E B2         [24] 1004 	lcall	_ak820_resolve_key
      007692 12 99 E2         [24] 1005 	lcall	_action_for_keycode
      007695 12 43 37         [24] 1006 	lcall	_ak820_outline_0152
      007698 D0 06            [24] 1007 	pop	ar6
      00769A D0 07            [24] 1008 	pop	ar7
      00769C 90 08 F1         [24] 1009 	mov	dptr,#_process_record_handler_action_10000_649
      00769F 12 38 1E         [24] 1010 	lcall	_ak820_outline_0077
                                   1011 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0076A2                       1012 00104$:
                                   1013 ;	quantum/action.c:429: process_action(record, action);
      0076A2 90 0E 67         [24] 1014 	mov	dptr,#___memcpy_PARM_2
      0076A5 74 F1            [12] 1015 	mov	a,#_process_record_handler_action_10000_649
      0076A7 F0               [24] 1016 	movx	@dptr,a
      0076A8 74 08            [12] 1017 	mov	a,#(_process_record_handler_action_10000_649 >> 8)
      0076AA 12 7B 47         [24] 1018 	lcall	_ak820_outline_0057
      0076AD 12 54 2B         [24] 1019 	lcall	_ak820_outline_0111
      0076B0 90 08 F3         [24] 1020 	mov	dptr,#_process_action_PARM_2
      0076B3 F5 F0            [12] 1021 	mov	b,a
      0076B5 C0 07            [24] 1022 	push	ar7
      0076B7 C0 06            [24] 1023 	push	ar6
      0076B9 12 BC D2         [24] 1024 	lcall	___memcpy
      0076BC D0 06            [24] 1025 	pop	ar6
      0076BE D0 07            [24] 1026 	pop	ar7
      0076C0 12 43 17         [24] 1027 	lcall	_ak820_outline_0119
                                   1028 ;	quantum/action.c:430: }
      0076C3 C1 C5            [24] 1029 	ajmp	_process_action
                                   1030 ;------------------------------------------------------------
                                   1031 ;Allocation info for local variables in function 'register_mouse'
                                   1032 ;------------------------------------------------------------
                                   1033 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1034 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_657'
                                   1035 ;------------------------------------------------------------
                                   1036 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1037 ;	-----------------------------------------
                                   1038 ;	 function process_action
                                   1039 ;	-----------------------------------------
      0076C5                       1040 _process_action:
      0076C5 12 38 4E         [24] 1041 	lcall	_ak820_outline_0109
      0076C8 90 08 F5         [24] 1042 	mov	dptr,#_process_action_record_argument_10000_660
      0076CB 12 38 49         [24] 1043 	lcall	_ak820_outline_0108
                                   1044 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0076CE 90 08 F5         [24] 1045 	mov	dptr,#_process_action_record_argument_10000_660
      0076D1 12 37 AC         [24] 1046 	lcall	_ak820_outline_0006
                                   1047 ;	quantum/action.c:501: pressed = record->event.pressed;
      0076D4 A3               [24] 1048 	inc	dptr
      0076D5 A3               [24] 1049 	inc	dptr
      0076D6 A3               [24] 1050 	inc	dptr
      0076D7 A3               [24] 1051 	inc	dptr
      0076D8 A3               [24] 1052 	inc	dptr
      0076D9 E0               [24] 1053 	movx	a,@dptr
      0076DA F5 27            [12] 1054 	mov	_process_action_sloc0_1_0,a
                                   1055 ;	quantum/action.c:525: switch (action.kind.id) {
      0076DC 90 08 F4         [24] 1056 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076DF E0               [24] 1057 	movx	a,@dptr
      0076E0 C4               [12] 1058 	swap	a
      0076E1 54 0F            [12] 1059 	anl	a,#0x0f
      0076E3 FD               [12] 1060 	mov  r5,a
      0076E4 24 F4            [12] 1061 	add	a,#0xff - 0x0b
      0076E6 50 03            [24] 1062 	jnc	00434$
      0076E8 02 79 66         [24] 1063 	ljmp	00181$
      0076EB                       1064 00434$:
                                   1065 ;	free result
      0076EB ED               [12] 1066 	mov	a,r5
      0076EC 24 0A            [12] 1067 	add	a,#(00435$-3-.)
      0076EE 83               [24] 1068 	movc	a,@a+pc
      0076EF F5 82            [12] 1069 	mov	dpl,a
      0076F1 ED               [12] 1070 	mov	a,r5
      0076F2 24 10            [12] 1071 	add	a,#(00436$-3-.)
      0076F4 83               [24] 1072 	movc	a,@a+pc
      0076F5 F5 83            [12] 1073 	mov	dph,a
      0076F7 E4               [12] 1074 	clr	a
      0076F8 73               [24] 1075 	jmp	@a+dptr
      0076F9                       1076 00435$:
      0076F9 11                    1077 	.db	00102$
      0076FA 11                    1078 	.db	00102$
      0076FB 66                    1079 	.db	00181$
      0076FC 66                    1080 	.db	00181$
      0076FD 9B                    1081 	.db	00123$
      0076FE 66                    1082 	.db	00181$
      0076FF 66                    1083 	.db	00181$
      007700 66                    1084 	.db	00181$
      007701 FB                    1085 	.db	00131$
      007702 CD                    1086 	.db	00147$
      007703 F3                    1087 	.db	00152$
      007704 F3                    1088 	.db	00152$
      007705                       1089 00436$:
      007705 77                    1090 	.db	00102$>>8
      007706 77                    1091 	.db	00102$>>8
      007707 79                    1092 	.db	00181$>>8
      007708 79                    1093 	.db	00181$>>8
      007709 77                    1094 	.db	00123$>>8
      00770A 79                    1095 	.db	00181$>>8
      00770B 79                    1096 	.db	00181$>>8
      00770C 79                    1097 	.db	00181$>>8
      00770D 77                    1098 	.db	00131$>>8
      00770E 78                    1099 	.db	00147$>>8
      00770F 78                    1100 	.db	00152$>>8
      007710 78                    1101 	.db	00152$>>8
                                   1102 ;	quantum/action.c:528: case ACT_RMODS: {
      007711                       1103 00102$:
                                   1104 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007711 90 08 F4         [24] 1105 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007714 E0               [24] 1106 	movx	a,@dptr
      007715 54 F0            [12] 1107 	anl	a,#0xf0
      007717 70 06            [24] 1108 	jnz	00194$
      007719 12 7B 6E         [24] 1109 	lcall	_ak820_outline_0114
      00771C FD               [12] 1110 	mov	r5,a
      00771D 80 07            [24] 1111 	sjmp	00195$
      00771F                       1112 00194$:
      00771F 12 7B 6E         [24] 1113 	lcall	_ak820_outline_0114
      007722 C4               [12] 1114 	swap	a
      007723 54 F0            [12] 1115 	anl	a,#0xf0
      007725 FD               [12] 1116 	mov	r5,a
      007726                       1117 00195$:
                                   1118 ;	quantum/action.c:531: if (pressed) {
      007726 E5 27            [12] 1119 	mov	a,_process_action_sloc0_1_0
      007728 60 35            [24] 1120 	jz	00119$
                                   1121 ;	quantum/action.c:532: if (mods) {
      00772A ED               [12] 1122 	mov	a,r5
      00772B 60 29            [24] 1123 	jz	00110$
                                   1124 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00772D 12 7B 80         [24] 1125 	lcall	_ak820_outline_0161
      007730 FC               [12] 1126 	mov	r4,a
      007731 BC E0 00         [24] 1127 	cjne	r4,#0xe0,00440$
      007734                       1128 00440$:
      007734 40 07            [24] 1129 	jc	00108$
      007736 12 7B 80         [24] 1130 	lcall	_ak820_outline_0161
      007739 24 18            [12] 1131 	add	a,#0xff - 0xe7
      00773B 50 0A            [24] 1132 	jnc	00104$
                                   1133 ;	free result
      00773D                       1134 00108$:
      00773D 7B F3            [12] 1135 	mov	r3,#_process_action_PARM_2
      00773F 7C 08            [12] 1136 	mov	r4,#(_process_action_PARM_2 >> 8)
      007741 12 33 FC         [24] 1137 	lcall	_ak820_outline_0123
      007744 E0               [24] 1138 	movx	a,@dptr
      007745 70 07            [24] 1139 	jnz	00105$
      007747                       1140 00104$:
                                   1141 ;	quantum/action.c:537: add_owned_mods(mods);
      007747 8D 82            [24] 1142 	mov	dpl, r5
      007749 12 80 C8         [24] 1143 	lcall	_add_owned_mods
      00774C 80 05            [24] 1144 	sjmp	00106$
      00774E                       1145 00105$:
                                   1146 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00774E 8D 82            [24] 1147 	mov	dpl, r5
      007750 12 80 E7         [24] 1148 	lcall	_add_owned_weak_mods
      007753                       1149 00106$:
                                   1150 ;	quantum/action.c:541: send_keyboard_report();
      007753 12 84 01         [24] 1151 	lcall	_send_keyboard_report
      007756                       1152 00110$:
                                   1153 ;	quantum/action.c:543: register_code(action.key.code);
      007756 12 7B 57         [24] 1154 	lcall	_ak820_outline_0079
      007759 12 79 7D         [24] 1155 	lcall	_register_code
      00775C 02 79 66         [24] 1156 	ljmp	00181$
      00775F                       1157 00119$:
                                   1158 ;	quantum/action.c:545: unregister_code(action.key.code);
      00775F 12 7B 57         [24] 1159 	lcall	_ak820_outline_0079
      007762 C0 05            [24] 1160 	push	ar5
      007764 12 79 EA         [24] 1161 	lcall	_unregister_code
      007767 D0 05            [24] 1162 	pop	ar5
                                   1163 ;	quantum/action.c:546: if (mods) {
      007769 ED               [12] 1164 	mov	a,r5
      00776A 70 03            [24] 1165 	jnz	00444$
      00776C 02 79 66         [24] 1166 	ljmp	00181$
      00776F                       1167 00444$:
                                   1168 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00776F 12 7B 80         [24] 1169 	lcall	_ak820_outline_0161
      007772 FC               [12] 1170 	mov	r4,a
      007773 BC E0 00         [24] 1171 	cjne	r4,#0xe0,00445$
      007776                       1172 00445$:
      007776 40 07            [24] 1173 	jc	00115$
      007778 12 7B 80         [24] 1174 	lcall	_ak820_outline_0161
      00777B 24 18            [12] 1175 	add	a,#0xff - 0xe7
      00777D 50 0A            [24] 1176 	jnc	00111$
                                   1177 ;	free result
      00777F                       1178 00115$:
      00777F 7B F3            [12] 1179 	mov	r3,#_process_action_PARM_2
      007781 7C 08            [12] 1180 	mov	r4,#(_process_action_PARM_2 >> 8)
      007783 12 33 FC         [24] 1181 	lcall	_ak820_outline_0123
      007786 E0               [24] 1182 	movx	a,@dptr
      007787 70 07            [24] 1183 	jnz	00112$
      007789                       1184 00111$:
                                   1185 ;	quantum/action.c:548: del_owned_mods(mods);
      007789 8D 82            [24] 1186 	mov	dpl, r5
      00778B 12 80 D8         [24] 1187 	lcall	_del_owned_mods
      00778E 80 05            [24] 1188 	sjmp	00113$
      007790                       1189 00112$:
                                   1190 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      007790 8D 82            [24] 1191 	mov	dpl, r5
      007792 12 80 F7         [24] 1192 	lcall	_del_owned_weak_mods
      007795                       1193 00113$:
                                   1194 ;	quantum/action.c:552: send_keyboard_report();
      007795 12 84 01         [24] 1195 	lcall	_send_keyboard_report
                                   1196 ;	quantum/action.c:555: } break;
      007798 02 79 66         [24] 1197 	ljmp	00181$
                                   1198 ;	quantum/action.c:632: case ACT_USAGE:
      00779B                       1199 00123$:
                                   1200 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00779B 74 07            [12] 1201 	mov	a,#0x07
      00779D 12 37 F3         [24] 1202 	lcall	_ak820_outline_0036
      0077A0 12 37 C6         [24] 1203 	lcall	_ak820_outline_0010
      0077A3 C3               [12] 1204 	clr	c
      0077A4 EC               [12] 1205 	mov	a,r4
      0077A5 94 A5            [12] 1206 	subb	a,#0xa5
      0077A7 ED               [12] 1207 	mov	a,r5
      0077A8 94 00            [12] 1208 	subb	a,#0x00
      0077AA 40 15            [24] 1209 	jc	00125$
      0077AC 74 C2            [12] 1210 	mov	a,#0xc2
      0077AE 9C               [12] 1211 	subb	a,r4
      0077AF E4               [12] 1212 	clr	a
      0077B0 9D               [12] 1213 	subb	a,r5
      0077B1 40 0E            [24] 1214 	jc	00125$
                                   1215 ;	free result
                                   1216 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0077B3 90 0B 53         [24] 1217 	mov	dptr,#_owned_usage_key_PARM_2
      0077B6 E5 27            [12] 1218 	mov	a,_process_action_sloc0_1_0
      0077B8 F0               [24] 1219 	movx	@dptr,a
      0077B9 8E 82            [24] 1220 	mov	dpl, r6
      0077BB 12 82 AD         [24] 1221 	lcall	_owned_usage_key
                                   1222 ;	quantum/action.c:640: break;
      0077BE 02 79 66         [24] 1223 	ljmp	00181$
      0077C1                       1224 00125$:
                                   1225 ;	quantum/action.c:643: switch (action.usage.page) {
      0077C1 12 7B 5E         [24] 1226 	lcall	_ak820_outline_0091
      0077C4 FF               [12] 1227 	mov	r7,a
      0077C5 60 08            [24] 1228 	jz	00127$
      0077C7 BF 01 02         [24] 1229 	cjne	r7,#0x01,00452$
      0077CA 80 19            [24] 1230 	sjmp	00128$
      0077CC                       1231 00452$:
      0077CC 02 79 66         [24] 1232 	ljmp	00181$
                                   1233 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0077CF                       1234 00127$:
                                   1235 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0077CF E5 27            [12] 1236 	mov	a,_process_action_sloc0_1_0
      0077D1 60 05            [24] 1237 	jz	00196$
      0077D3 12 7B 75         [24] 1238 	lcall	_ak820_outline_0134
      0077D6 80 04            [24] 1239 	sjmp	00197$
      0077D8                       1240 00196$:
      0077D8 7E 00            [12] 1241 	mov	r6,#0x00
      0077DA 7F 00            [12] 1242 	mov	r7,#0x00
      0077DC                       1243 00197$:
      0077DC 12 43 17         [24] 1244 	lcall	_ak820_outline_0119
      0077DF 12 71 C5         [24] 1245 	lcall	_host_system_send
                                   1246 ;	quantum/action.c:646: break;
      0077E2 02 79 66         [24] 1247 	ljmp	00181$
                                   1248 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0077E5                       1249 00128$:
                                   1250 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0077E5 E5 27            [12] 1251 	mov	a,_process_action_sloc0_1_0
      0077E7 60 05            [24] 1252 	jz	00198$
      0077E9 12 7B 75         [24] 1253 	lcall	_ak820_outline_0134
      0077EC 80 04            [24] 1254 	sjmp	00199$
      0077EE                       1255 00198$:
      0077EE 7E 00            [12] 1256 	mov	r6,#0x00
      0077F0 7F 00            [12] 1257 	mov	r7,#0x00
      0077F2                       1258 00199$:
      0077F2 12 43 17         [24] 1259 	lcall	_ak820_outline_0119
      0077F5 12 71 F4         [24] 1260 	lcall	_host_consumer_send
                                   1261 ;	quantum/action.c:651: break;
      0077F8 02 79 66         [24] 1262 	ljmp	00181$
                                   1263 ;	quantum/action.c:658: case ACT_LAYER: {
      0077FB                       1264 00131$:
                                   1265 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0077FB 90 08 F4         [24] 1266 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077FE E0               [24] 1267 	movx	a,@dptr
      0077FF 54 03            [12] 1268 	anl	a,#0x03
      007801 90 08 F7         [24] 1269 	mov	dptr,#_process_action_on_40000_683
      007804 F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007805 E0               [24] 1272 	movx	a,@dptr
      007806 FF               [12] 1273 	mov	r7,a
      007807 60 11            [24] 1274 	jz	00200$
      007809 E5 27            [12] 1275 	mov	a,_process_action_sloc0_1_0
      00780B 60 07            [24] 1276 	jz	00202$
      00780D 8F 06            [24] 1277 	mov	ar6,r7
      00780F 53 06 01         [24] 1278 	anl	ar6,#0x01
      007812 80 10            [24] 1279 	sjmp	00201$
      007814                       1280 00202$:
      007814 74 02            [12] 1281 	mov	a,#0x02
      007816 5F               [12] 1282 	anl	a,r7
      007817 FE               [12] 1283 	mov	r6,a
      007818 80 0A            [24] 1284 	sjmp	00201$
      00781A                       1285 00200$:
      00781A E5 27            [12] 1286 	mov	a,_process_action_sloc0_1_0
      00781C B4 01 00         [24] 1287 	cjne	a,#0x01,00457$
      00781F                       1288 00457$:
      00781F 92 20            [24] 1289 	mov  _process_action_sloc1_1_0,c
      007821 E4               [12] 1290 	clr	a
      007822 33               [12] 1291 	rlc	a
      007823 FE               [12] 1292 	mov	r6,a
      007824                       1293 00201$:
      007824 EE               [12] 1294 	mov	a,r6
      007825 70 03            [24] 1295 	jnz	00458$
      007827 02 79 66         [24] 1296 	ljmp	00181$
      00782A                       1297 00458$:
                                   1298 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      00782A 12 7B 80         [24] 1299 	lcall	_ak820_outline_0161
      00782D C4               [12] 1300 	swap	a
      00782E 03               [12] 1301 	rr	a
      00782F 54 07            [12] 1302 	anl	a,#0x07
      007831 25 E0            [12] 1303 	add	a,acc
      007833 25 E0            [12] 1304 	add	a,acc
      007835 FF               [12] 1305 	mov	r7,a
                                   1306 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007836 12 7B 80         [24] 1307 	lcall	_ak820_outline_0161
      007839 54 0F            [12] 1308 	anl	a,#0x0f
      00783B FE               [12] 1309 	mov	r6,a
      00783C 8F F0            [24] 1310 	mov	b,r7
      00783E 05 F0            [12] 1311 	inc	b
      007840 EE               [12] 1312 	mov	a,r6
      007841 80 02            [24] 1313 	sjmp	00460$
      007843                       1314 00459$:
      007843 25 E0            [12] 1315 	add	a,acc
      007845                       1316 00460$:
      007845 D5 F0 FB         [24] 1317 	djnz	b,00459$
      007848 FE               [12] 1318 	mov	r6,a
                                   1319 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007849 12 7B 80         [24] 1320 	lcall	_ak820_outline_0161
      00784C 30 E4 11         [24] 1321 	jnb	acc.4,00204$
      00784F 8F F0            [24] 1322 	mov	b,r7
      007851 05 F0            [12] 1323 	inc	b
      007853 74 0F            [12] 1324 	mov	a,#0x0f
      007855 80 02            [24] 1325 	sjmp	00463$
      007857                       1326 00462$:
      007857 25 E0            [12] 1327 	add	a,acc
      007859                       1328 00463$:
      007859 D5 F0 FB         [24] 1329 	djnz	b,00462$
      00785C F4               [12] 1330 	cpl	a
      00785D FF               [12] 1331 	mov	r7,a
      00785E 80 02            [24] 1332 	sjmp	00205$
      007860                       1333 00204$:
      007860 7F 00            [12] 1334 	mov	r7,#0x00
      007862                       1335 00205$:
                                   1336 ;	quantum/action.c:666: bits |= mask;
      007862 EE               [12] 1337 	mov	a,r6
      007863 42 07            [12] 1338 	orl	ar7,a
                                   1339 ;	quantum/action.c:667: if (!on) {
      007865 90 08 F7         [24] 1340 	mov	dptr,#_process_action_on_40000_683
      007868 E0               [24] 1341 	movx	a,@dptr
      007869 70 31            [24] 1342 	jnz	00143$
                                   1343 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      00786B 12 7B 5E         [24] 1344 	lcall	_ak820_outline_0091
      00786E FE               [12] 1345 	mov	r6,a
      00786F 2E               [12] 1346 	add	a,r6
                                   1347 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      007870 90 78 74         [24] 1348 	mov	dptr,#00465$
      007873 73               [24] 1349 	jmp	@a+dptr
      007874                       1350 00465$:
      007874 80 06            [24] 1351 	sjmp	00132$
      007876 80 0C            [24] 1352 	sjmp	00133$
      007878 80 12            [24] 1353 	sjmp	00134$
      00787A 80 18            [24] 1354 	sjmp	00135$
      00787C                       1355 00132$:
      00787C 8F 82            [24] 1356 	mov	dpl, r7
      00787E 12 7B D6         [24] 1357 	lcall	_default_layer_and
      007881 02 79 66         [24] 1358 	ljmp	00181$
                                   1359 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007884                       1360 00133$:
      007884 8F 82            [24] 1361 	mov	dpl, r7
      007886 12 7B C6         [24] 1362 	lcall	_default_layer_or
      007889 02 79 66         [24] 1363 	ljmp	00181$
                                   1364 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      00788C                       1365 00134$:
      00788C 8F 82            [24] 1366 	mov	dpl, r7
      00788E 12 7B EB         [24] 1367 	lcall	_default_layer_xor
      007891 02 79 66         [24] 1368 	ljmp	00181$
                                   1369 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007894                       1370 00135$:
      007894 8F 82            [24] 1371 	mov	dpl, r7
      007896 12 7B BC         [24] 1372 	lcall	_default_layer_set
                                   1373 ;	quantum/action.c:673: }
      007899 02 79 66         [24] 1374 	ljmp	00181$
      00789C                       1375 00143$:
                                   1376 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      00789C 12 7B 5E         [24] 1377 	lcall	_ak820_outline_0091
      00789F FE               [12] 1378 	mov	r6,a
      0078A0 2E               [12] 1379 	add	a,r6
                                   1380 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0078A1 90 78 A5         [24] 1381 	mov	dptr,#00466$
      0078A4 73               [24] 1382 	jmp	@a+dptr
      0078A5                       1383 00466$:
      0078A5 80 06            [24] 1384 	sjmp	00137$
      0078A7 80 0C            [24] 1385 	sjmp	00138$
      0078A9 80 12            [24] 1386 	sjmp	00139$
      0078AB 80 18            [24] 1387 	sjmp	00140$
      0078AD                       1388 00137$:
      0078AD 8F 82            [24] 1389 	mov	dpl, r7
      0078AF 12 7D 60         [24] 1390 	lcall	_layer_and
      0078B2 02 79 66         [24] 1391 	ljmp	00181$
                                   1392 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0078B5                       1393 00138$:
      0078B5 8F 82            [24] 1394 	mov	dpl, r7
      0078B7 12 7D 50         [24] 1395 	lcall	_layer_or
      0078BA 02 79 66         [24] 1396 	ljmp	00181$
                                   1397 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0078BD                       1398 00139$:
      0078BD 8F 82            [24] 1399 	mov	dpl, r7
      0078BF 12 7D 75         [24] 1400 	lcall	_layer_xor
      0078C2 02 79 66         [24] 1401 	ljmp	00181$
                                   1402 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0078C5                       1403 00140$:
      0078C5 8F 82            [24] 1404 	mov	dpl, r7
      0078C7 12 7C F2         [24] 1405 	lcall	_layer_state_set
                                   1406 ;	quantum/action.c:683: break;
      0078CA 02 79 66         [24] 1407 	ljmp	00181$
                                   1408 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0078CD                       1409 00147$:
                                   1410 ;	quantum/action.c:686: if (pressed) {
      0078CD E5 27            [12] 1411 	mov	a,_process_action_sloc0_1_0
      0078CF 60 11            [24] 1412 	jz	00149$
                                   1413 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0078D1 12 7B 6E         [24] 1414 	lcall	_ak820_outline_0114
      0078D4 F5 82            [12] 1415 	mov	dpl,a
      0078D6 12 7C 59         [24] 1416 	lcall	_layer_hold_on
                                   1417 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0078D9 12 7B 57         [24] 1418 	lcall	_ak820_outline_0079
      0078DC 12 7A 9D         [24] 1419 	lcall	_register_mods
      0078DF 02 79 66         [24] 1420 	ljmp	00181$
      0078E2                       1421 00149$:
                                   1422 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0078E2 12 7B 57         [24] 1423 	lcall	_ak820_outline_0079
      0078E5 12 7A B1         [24] 1424 	lcall	_unregister_mods
                                   1425 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0078E8 12 7B 6E         [24] 1426 	lcall	_ak820_outline_0114
      0078EB F5 82            [12] 1427 	mov	dpl,a
      0078ED 12 7C 8F         [24] 1428 	lcall	_layer_hold_off
                                   1429 ;	quantum/action.c:693: break;
      0078F0 02 79 66         [24] 1430 	ljmp	00181$
                                   1431 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0078F3                       1432 00152$:
                                   1433 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0078F3 12 7B 80         [24] 1434 	lcall	_ak820_outline_0161
      0078F6 FF               [12] 1435 	mov	r7,a
      0078F7 BF F1 02         [24] 1436 	cjne	r7,#0xf1,00468$
      0078FA 80 0A            [24] 1437 	sjmp	00154$
      0078FC                       1438 00468$:
      0078FC BF F2 02         [24] 1439 	cjne	r7,#0xf2,00469$
      0078FF 80 19            [24] 1440 	sjmp	00155$
      007901                       1441 00469$:
                                   1442 ;	quantum/action.c:712: momentary_layer_action:
      007901 BF F3 3B         [24] 1443 	cjne	r7,#0xf3,00160$
      007904 80 28            [24] 1444 	sjmp	00156$
      007906                       1445 00154$:
                                   1446 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007906 E5 27            [12] 1447 	mov	a,_process_action_sloc0_1_0
      007908 60 08            [24] 1448 	jz	00206$
      00790A 12 7B 3E         [24] 1449 	lcall	_ak820_outline_0045
      00790D 12 7C 59         [24] 1450 	lcall	_layer_hold_on
      007910 80 54            [24] 1451 	sjmp	00181$
      007912                       1452 00206$:
      007912 12 7B 3E         [24] 1453 	lcall	_ak820_outline_0045
      007915 12 7C 8F         [24] 1454 	lcall	_layer_hold_off
                                   1455 ;	quantum/action.c:714: break;
                                   1456 ;	quantum/action.c:715: case OP_OFF_ON:
      007918 80 4C            [24] 1457 	sjmp	00181$
      00791A                       1458 00155$:
                                   1459 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00791A E5 27            [12] 1460 	mov	a,_process_action_sloc0_1_0
      00791C 60 08            [24] 1461 	jz	00208$
      00791E 12 7B 3E         [24] 1462 	lcall	_ak820_outline_0045
      007921 12 7D 33         [24] 1463 	lcall	_layer_off
      007924 80 40            [24] 1464 	sjmp	00181$
      007926                       1465 00208$:
      007926 12 7B 3E         [24] 1466 	lcall	_ak820_outline_0045
      007929 12 7D 19         [24] 1467 	lcall	_layer_on
                                   1468 ;	quantum/action.c:717: break;
                                   1469 ;	quantum/action.c:718: case OP_SET_CLEAR:
      00792C 80 38            [24] 1470 	sjmp	00181$
      00792E                       1471 00156$:
                                   1472 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00792E E5 27            [12] 1473 	mov	a,_process_action_sloc0_1_0
      007930 60 08            [24] 1474 	jz	00210$
      007932 12 7B 3E         [24] 1475 	lcall	_ak820_outline_0045
      007935 12 7D 04         [24] 1476 	lcall	_layer_move
      007938 80 2C            [24] 1477 	sjmp	00181$
      00793A                       1478 00210$:
      00793A 12 7C FF         [24] 1479 	lcall	_layer_clear
                                   1480 ;	quantum/action.c:720: break;
                                   1481 ;	quantum/action.c:766: default:
      00793D 80 27            [24] 1482 	sjmp	00181$
      00793F                       1483 00160$:
                                   1484 ;	quantum/action.c:773: if (pressed) {
      00793F E5 27            [12] 1485 	mov	a,_process_action_sloc0_1_0
      007941 60 08            [24] 1486 	jz	00163$
                                   1487 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007943 12 7B 57         [24] 1488 	lcall	_ak820_outline_0079
      007946 12 79 7D         [24] 1489 	lcall	_register_code
                                   1490 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007949 80 1B            [24] 1491 	sjmp	00181$
      00794B                       1492 00163$:
                                   1493 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      00794B 12 7B 80         [24] 1494 	lcall	_ak820_outline_0161
      00794E FF               [12] 1495 	mov	r7,a
      00794F BF 39 0E         [24] 1496 	cjne	r7,#0x39,00175$
                                   1497 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007952 7F 50            [12] 1498 	mov	r7,#0x50
      007954                       1499 00187$:
      007954 EF               [12] 1500 	mov	a,r7
      007955 60 09            [24] 1501 	jz	00175$
      007957 90 00 01         [24] 1502 	mov	dptr,#0x0001
      00795A 12 5D 9F         [24] 1503 	lcall	_mDelaymS
      00795D 1F               [12] 1504 	dec	r7
                                   1505 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00795E 80 F4            [24] 1506 	sjmp	00187$
      007960                       1507 00175$:
                                   1508 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007960 12 7B 57         [24] 1509 	lcall	_ak820_outline_0079
      007963 12 79 EA         [24] 1510 	lcall	_unregister_code
                                   1511 ;	quantum/action.c:866: }
      007966                       1512 00181$:
                                   1513 ;	quantum/action.c:887: switch (action.kind.id) {
      007966 90 08 F4         [24] 1514 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007969 E0               [24] 1515 	movx	a,@dptr
      00796A C4               [12] 1516 	swap	a
      00796B 54 0F            [12] 1517 	anl	a,#0x0f
      00796D FF               [12] 1518 	mov	r7,a
      00796E BF 08 02         [24] 1519 	cjne	r7,#0x08,00478$
      007971 80 03            [24] 1520 	sjmp	00183$
      007973                       1521 00478$:
      007973 BF 09 06         [24] 1522 	cjne	r7,#0x09,00192$
                                   1523 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007976                       1524 00183$:
                                   1525 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007976 12 71 2A         [24] 1526 	lcall	_host_keyboard_leds
                                   1527 ;	quantum/action.c:898: }
                                   1528 ;	quantum/action.c:951: }
      007979 02 9C 93         [24] 1529 	ljmp	_led_set
      00797C                       1530 00192$:
      00797C 22               [24] 1531 	ret
                                   1532 ;------------------------------------------------------------
                                   1533 ;Allocation info for local variables in function 'register_code'
                                   1534 ;------------------------------------------------------------
                                   1535 ;code          Allocated with name '_register_code_code_10000_717'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1538 ;	-----------------------------------------
                                   1539 ;	 function register_code
                                   1540 ;	-----------------------------------------
      00797D                       1541 _register_code:
      00797D E5 82            [12] 1542 	mov	a,dpl
      00797F 90 08 F8         [24] 1543 	mov	dptr,#_register_code_code_10000_717
      007982 F0               [24] 1544 	movx	@dptr,a
                                   1545 ;	quantum/action.c:958: if (code == KC_NO) {
      007983 E0               [24] 1546 	movx	a,@dptr
      007984 FF               [12] 1547 	mov	r7,a
      007985 70 01            [24] 1548 	jnz	00123$
                                   1549 ;	quantum/action.c:959: return;
      007987 22               [24] 1550 	ret
      007988                       1551 00123$:
                                   1552 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007988 BF 04 00         [24] 1553 	cjne	r7,#0x04,00186$
      00798B                       1554 00186$:
      00798B 40 12            [24] 1555 	jc	00119$
      00798D EF               [12] 1556 	mov	a,r7
      00798E 24 5B            [12] 1557 	add	a,#0xff - 0xa4
      007990 40 0D            [24] 1558 	jc	00119$
                                   1559 ;	free result
                                   1560 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      007992 8F 82            [24] 1561 	mov	dpl, r7
      007994 12 81 6C         [24] 1562 	lcall	_add_owned_key
      007997 E5 82            [12] 1563 	mov	a, dpl
      007999 70 01            [24] 1564 	jnz	00104$
      00799B 22               [24] 1565 	ret
      00799C                       1566 00104$:
                                   1567 ;	quantum/action.c:1013: send_keyboard_report();
      00799C 02 84 01         [24] 1568 	ljmp	_send_keyboard_report
      00799F                       1569 00119$:
                                   1570 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00799F 12 7B 85         [24] 1571 	lcall	_ak820_outline_0170
      0079A2 BF E0 00         [24] 1572 	cjne	r7,#0xe0,00190$
      0079A5                       1573 00190$:
      0079A5 40 1A            [24] 1574 	jc	00115$
      0079A7 EF               [12] 1575 	mov	a,r7
      0079A8 24 18            [12] 1576 	add	a,#0xff - 0xe7
      0079AA 40 15            [24] 1577 	jc	00115$
                                   1578 ;	free result
                                   1579 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0079AC 74 07            [12] 1580 	mov	a,#0x07
      0079AE 5F               [12] 1581 	anl	a,r7
      0079AF 12 7B 50         [24] 1582 	lcall	_ak820_outline_0068
      0079B2 80 02            [24] 1583 	sjmp	00194$
      0079B4                       1584 00193$:
      0079B4 25 E0            [12] 1585 	add	a,acc
      0079B6                       1586 00194$:
      0079B6 D5 F0 FB         [24] 1587 	djnz	b,00193$
      0079B9 F5 82            [12] 1588 	mov	dpl,a
      0079BB 12 80 C8         [24] 1589 	lcall	_add_owned_mods
                                   1590 ;	quantum/action.c:1016: send_keyboard_report();
      0079BE 02 84 01         [24] 1591 	ljmp	_send_keyboard_report
      0079C1                       1592 00115$:
                                   1593 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0079C1 12 7B 85         [24] 1594 	lcall	_ak820_outline_0170
      0079C4 BF A5 00         [24] 1595 	cjne	r7,#0xa5,00195$
      0079C7                       1596 00195$:
      0079C7 40 05            [24] 1597 	jc	00113$
      0079C9 EF               [12] 1598 	mov	a,r7
      0079CA 24 58            [12] 1599 	add	a,#0xff - 0xa7
      0079CC 50 0D            [24] 1600 	jnc	00108$
                                   1601 ;	free result
      0079CE                       1602 00113$:
      0079CE 12 7B 85         [24] 1603 	lcall	_ak820_outline_0170
      0079D1 BF A8 00         [24] 1604 	cjne	r7,#0xa8,00198$
      0079D4                       1605 00198$:
      0079D4 40 13            [24] 1606 	jc	00125$
      0079D6 EF               [12] 1607 	mov	a,r7
      0079D7 24 3D            [12] 1608 	add	a,#0xff - 0xc2
      0079D9 40 0E            [24] 1609 	jc	00125$
                                   1610 ;	free result
      0079DB                       1611 00108$:
                                   1612 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0079DB 12 7B 85         [24] 1613 	lcall	_ak820_outline_0170
      0079DE 90 0B 53         [24] 1614 	mov	dptr,#_owned_usage_key_PARM_2
      0079E1 74 01            [12] 1615 	mov	a,#0x01
      0079E3 F0               [24] 1616 	movx	@dptr,a
      0079E4 8F 82            [24] 1617 	mov	dpl, r7
                                   1618 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1619 ;	quantum/action.c:1031: }
      0079E6 02 82 AD         [24] 1620 	ljmp	_owned_usage_key
      0079E9                       1621 00125$:
      0079E9 22               [24] 1622 	ret
                                   1623 ;------------------------------------------------------------
                                   1624 ;Allocation info for local variables in function 'unregister_code'
                                   1625 ;------------------------------------------------------------
                                   1626 ;code          Allocated with name '_unregister_code_code_10000_731'
                                   1627 ;------------------------------------------------------------
                                   1628 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1629 ;	-----------------------------------------
                                   1630 ;	 function unregister_code
                                   1631 ;	-----------------------------------------
      0079EA                       1632 _unregister_code:
      0079EA E5 82            [12] 1633 	mov	a,dpl
      0079EC 90 08 F9         [24] 1634 	mov	dptr,#_unregister_code_code_10000_731
      0079EF F0               [24] 1635 	movx	@dptr,a
                                   1636 ;	quantum/action.c:1038: if (code == KC_NO) {
      0079F0 E0               [24] 1637 	movx	a,@dptr
      0079F1 FF               [12] 1638 	mov	r7,a
      0079F2 70 01            [24] 1639 	jnz	00121$
                                   1640 ;	quantum/action.c:1039: return;
      0079F4 22               [24] 1641 	ret
      0079F5                       1642 00121$:
                                   1643 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0079F5 BF 04 00         [24] 1644 	cjne	r7,#0x04,00184$
      0079F8                       1645 00184$:
      0079F8 40 12            [24] 1646 	jc	00117$
      0079FA EF               [12] 1647 	mov	a,r7
      0079FB 24 5B            [12] 1648 	add	a,#0xff - 0xa4
      0079FD 40 0D            [24] 1649 	jc	00117$
                                   1650 ;	free result
                                   1651 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0079FF 8F 82            [24] 1652 	mov	dpl, r7
      007A01 12 81 E6         [24] 1653 	lcall	_del_owned_key
      007A04 E5 82            [12] 1654 	mov	a, dpl
      007A06 70 01            [24] 1655 	jnz	00102$
      007A08 22               [24] 1656 	ret
      007A09                       1657 00102$:
                                   1658 ;	quantum/action.c:1080: send_keyboard_report();
      007A09 02 84 01         [24] 1659 	ljmp	_send_keyboard_report
      007A0C                       1660 00117$:
                                   1661 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A0C 12 7B 8B         [24] 1662 	lcall	_ak820_outline_0171
      007A0F BF E0 00         [24] 1663 	cjne	r7,#0xe0,00188$
      007A12                       1664 00188$:
      007A12 40 1A            [24] 1665 	jc	00113$
      007A14 EF               [12] 1666 	mov	a,r7
      007A15 24 18            [12] 1667 	add	a,#0xff - 0xe7
      007A17 40 15            [24] 1668 	jc	00113$
                                   1669 ;	free result
                                   1670 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007A19 74 07            [12] 1671 	mov	a,#0x07
      007A1B 5F               [12] 1672 	anl	a,r7
      007A1C 12 7B 50         [24] 1673 	lcall	_ak820_outline_0068
      007A1F 80 02            [24] 1674 	sjmp	00192$
      007A21                       1675 00191$:
      007A21 25 E0            [12] 1676 	add	a,acc
      007A23                       1677 00192$:
      007A23 D5 F0 FB         [24] 1678 	djnz	b,00191$
      007A26 F5 82            [12] 1679 	mov	dpl,a
      007A28 12 80 D8         [24] 1680 	lcall	_del_owned_mods
                                   1681 ;	quantum/action.c:1083: send_keyboard_report();
      007A2B 02 84 01         [24] 1682 	ljmp	_send_keyboard_report
      007A2E                       1683 00113$:
                                   1684 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A2E 12 7B 8B         [24] 1685 	lcall	_ak820_outline_0171
      007A31 BF A5 00         [24] 1686 	cjne	r7,#0xa5,00193$
      007A34                       1687 00193$:
      007A34 40 05            [24] 1688 	jc	00111$
      007A36 EF               [12] 1689 	mov	a,r7
      007A37 24 58            [12] 1690 	add	a,#0xff - 0xa7
      007A39 50 0D            [24] 1691 	jnc	00106$
                                   1692 ;	free result
      007A3B                       1693 00111$:
      007A3B 12 7B 8B         [24] 1694 	lcall	_ak820_outline_0171
      007A3E BF A8 00         [24] 1695 	cjne	r7,#0xa8,00196$
      007A41                       1696 00196$:
      007A41 40 12            [24] 1697 	jc	00123$
      007A43 EF               [12] 1698 	mov	a,r7
      007A44 24 3D            [12] 1699 	add	a,#0xff - 0xc2
      007A46 40 0D            [24] 1700 	jc	00123$
                                   1701 ;	free result
      007A48                       1702 00106$:
                                   1703 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007A48 12 7B 8B         [24] 1704 	lcall	_ak820_outline_0171
      007A4B 90 0B 53         [24] 1705 	mov	dptr,#_owned_usage_key_PARM_2
      007A4E E4               [12] 1706 	clr	a
      007A4F F0               [24] 1707 	movx	@dptr,a
      007A50 8F 82            [24] 1708 	mov	dpl, r7
                                   1709 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1710 ;	quantum/action.c:1098: }
      007A52 02 82 AD         [24] 1711 	ljmp	_owned_usage_key
      007A55                       1712 00123$:
      007A55 22               [24] 1713 	ret
                                   1714 ;------------------------------------------------------------
                                   1715 ;Allocation info for local variables in function 'tap_code_delay'
                                   1716 ;------------------------------------------------------------
                                   1717 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1718 ;code          Allocated with name '_tap_code_delay_code_10000_744'
                                   1719 ;i             Allocated with name '_tap_code_delay_i_20000_746'
                                   1720 ;i             Allocated with name '_tap_code_delay_i_50000_749'
                                   1721 ;------------------------------------------------------------
                                   1722 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1723 ;	-----------------------------------------
                                   1724 ;	 function tap_code_delay
                                   1725 ;	-----------------------------------------
      007A56                       1726 _tap_code_delay:
      007A56 E5 82            [12] 1727 	mov	a,dpl
      007A58 90 08 FC         [24] 1728 	mov	dptr,#_tap_code_delay_code_10000_744
      007A5B F0               [24] 1729 	movx	@dptr,a
                                   1730 ;	quantum/action.c:1106: register_code(code);
      007A5C E0               [24] 1731 	movx	a,@dptr
      007A5D FF               [12] 1732 	mov	r7,a
      007A5E F5 82            [12] 1733 	mov	dpl,a
      007A60 C0 07            [24] 1734 	push	ar7
      007A62 31 7D            [12] 1735 	acall	_register_code
      007A64 D0 07            [24] 1736 	pop	ar7
                                   1737 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007A66 90 08 FA         [24] 1738 	mov	dptr,#_tap_code_delay_PARM_2
      007A69 12 38 2A         [24] 1739 	lcall	_ak820_outline_0082
      007A6C                       1740 00110$:
      007A6C ED               [12] 1741 	mov	a,r5
      007A6D 4E               [12] 1742 	orl	a,r6
      007A6E 60 0D            [24] 1743 	jz	00105$
                                   1744 ;	quantum/action.c:1108: wait_ms(1);
      007A70 90 00 01         [24] 1745 	mov	dptr,#0x0001
      007A73 12 5D 9F         [24] 1746 	lcall	_mDelaymS
                                   1747 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007A76 1D               [12] 1748 	dec	r5
      007A77 BD FF 01         [24] 1749 	cjne	r5,#0xff,00141$
      007A7A 1E               [12] 1750 	dec	r6
      007A7B                       1751 00141$:
      007A7B 80 EF            [24] 1752 	sjmp	00110$
      007A7D                       1753 00105$:
                                   1754 ;	quantum/action.c:1110: unregister_code(code);
      007A7D 8F 82            [24] 1755 	mov	dpl, r7
                                   1756 ;	quantum/action.c:1111: }
      007A7F 21 EA            [12] 1757 	ajmp	_unregister_code
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'tap_code'
                                   1760 ;------------------------------------------------------------
                                   1761 ;code          Allocated with name '_tap_code_code_10000_751'
                                   1762 ;------------------------------------------------------------
                                   1763 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1764 ;	-----------------------------------------
                                   1765 ;	 function tap_code
                                   1766 ;	-----------------------------------------
      007A81                       1767 _tap_code:
      007A81 E5 82            [12] 1768 	mov	a,dpl
      007A83 90 08 FD         [24] 1769 	mov	dptr,#_tap_code_code_10000_751
      007A86 F0               [24] 1770 	movx	@dptr,a
                                   1771 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A87 E0               [24] 1772 	movx	a,@dptr
      007A88 FF               [12] 1773 	mov	r7,a
      007A89 BF 39 04         [24] 1774 	cjne	r7,#0x39,00103$
      007A8C 7E 50            [12] 1775 	mov	r6,#0x50
      007A8E 80 02            [24] 1776 	sjmp	00104$
      007A90                       1777 00103$:
      007A90 7E 00            [12] 1778 	mov	r6,#0x00
      007A92                       1779 00104$:
      007A92 90 08 FA         [24] 1780 	mov	dptr,#_tap_code_delay_PARM_2
      007A95 EE               [12] 1781 	mov	a,r6
      007A96 12 38 5E         [24] 1782 	lcall	_ak820_outline_0128
      007A99 8F 82            [24] 1783 	mov	dpl, r7
                                   1784 ;	quantum/action.c:1119: }
      007A9B 41 56            [12] 1785 	ajmp	_tap_code_delay
                                   1786 ;------------------------------------------------------------
                                   1787 ;Allocation info for local variables in function 'register_mods'
                                   1788 ;------------------------------------------------------------
                                   1789 ;mods          Allocated with name '_register_mods_mods_10000_753'
                                   1790 ;------------------------------------------------------------
                                   1791 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1792 ;	-----------------------------------------
                                   1793 ;	 function register_mods
                                   1794 ;	-----------------------------------------
      007A9D                       1795 _register_mods:
      007A9D E5 82            [12] 1796 	mov	a,dpl
      007A9F 90 08 FE         [24] 1797 	mov	dptr,#_register_mods_mods_10000_753
      007AA2 F0               [24] 1798 	movx	@dptr,a
                                   1799 ;	quantum/action.c:1126: if (mods) {
      007AA3 E0               [24] 1800 	movx	a,@dptr
      007AA4 FF               [12] 1801 	mov	r7,a
      007AA5 E0               [24] 1802 	movx	a,@dptr
      007AA6 60 08            [24] 1803 	jz	00103$
                                   1804 ;	quantum/action.c:1127: add_owned_mods(mods);
      007AA8 8F 82            [24] 1805 	mov	dpl, r7
      007AAA 12 80 C8         [24] 1806 	lcall	_add_owned_mods
                                   1807 ;	quantum/action.c:1128: send_keyboard_report();
                                   1808 ;	quantum/action.c:1130: }
      007AAD 02 84 01         [24] 1809 	ljmp	_send_keyboard_report
      007AB0                       1810 00103$:
      007AB0 22               [24] 1811 	ret
                                   1812 ;------------------------------------------------------------
                                   1813 ;Allocation info for local variables in function 'unregister_mods'
                                   1814 ;------------------------------------------------------------
                                   1815 ;mods          Allocated with name '_unregister_mods_mods_10000_757'
                                   1816 ;------------------------------------------------------------
                                   1817 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1818 ;	-----------------------------------------
                                   1819 ;	 function unregister_mods
                                   1820 ;	-----------------------------------------
      007AB1                       1821 _unregister_mods:
      007AB1 E5 82            [12] 1822 	mov	a,dpl
      007AB3 90 08 FF         [24] 1823 	mov	dptr,#_unregister_mods_mods_10000_757
      007AB6 F0               [24] 1824 	movx	@dptr,a
                                   1825 ;	quantum/action.c:1137: if (mods) {
      007AB7 E0               [24] 1826 	movx	a,@dptr
      007AB8 FF               [12] 1827 	mov	r7,a
      007AB9 E0               [24] 1828 	movx	a,@dptr
      007ABA 60 08            [24] 1829 	jz	00103$
                                   1830 ;	quantum/action.c:1138: del_owned_mods(mods);
      007ABC 8F 82            [24] 1831 	mov	dpl, r7
      007ABE 12 80 D8         [24] 1832 	lcall	_del_owned_mods
                                   1833 ;	quantum/action.c:1139: send_keyboard_report();
                                   1834 ;	quantum/action.c:1141: }
      007AC1 02 84 01         [24] 1835 	ljmp	_send_keyboard_report
      007AC4                       1836 00103$:
      007AC4 22               [24] 1837 	ret
                                   1838 ;------------------------------------------------------------
                                   1839 ;Allocation info for local variables in function 'register_weak_mods'
                                   1840 ;------------------------------------------------------------
                                   1841 ;mods          Allocated with name '_register_weak_mods_mods_10000_761'
                                   1842 ;------------------------------------------------------------
                                   1843 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1844 ;	-----------------------------------------
                                   1845 ;	 function register_weak_mods
                                   1846 ;	-----------------------------------------
      007AC5                       1847 _register_weak_mods:
      007AC5 E5 82            [12] 1848 	mov	a,dpl
      007AC7 90 09 00         [24] 1849 	mov	dptr,#_register_weak_mods_mods_10000_761
      007ACA F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/action.c:1148: if (mods) {
      007ACB E0               [24] 1852 	movx	a,@dptr
      007ACC FF               [12] 1853 	mov	r7,a
      007ACD E0               [24] 1854 	movx	a,@dptr
      007ACE 60 08            [24] 1855 	jz	00103$
                                   1856 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007AD0 8F 82            [24] 1857 	mov	dpl, r7
      007AD2 12 80 E7         [24] 1858 	lcall	_add_owned_weak_mods
                                   1859 ;	quantum/action.c:1150: send_keyboard_report();
                                   1860 ;	quantum/action.c:1152: }
      007AD5 02 84 01         [24] 1861 	ljmp	_send_keyboard_report
      007AD8                       1862 00103$:
      007AD8 22               [24] 1863 	ret
                                   1864 ;------------------------------------------------------------
                                   1865 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1866 ;------------------------------------------------------------
                                   1867 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_765'
                                   1868 ;------------------------------------------------------------
                                   1869 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1870 ;	-----------------------------------------
                                   1871 ;	 function unregister_weak_mods
                                   1872 ;	-----------------------------------------
      007AD9                       1873 _unregister_weak_mods:
      007AD9 E5 82            [12] 1874 	mov	a,dpl
      007ADB 90 09 01         [24] 1875 	mov	dptr,#_unregister_weak_mods_mods_10000_765
      007ADE F0               [24] 1876 	movx	@dptr,a
                                   1877 ;	quantum/action.c:1159: if (mods) {
      007ADF E0               [24] 1878 	movx	a,@dptr
      007AE0 FF               [12] 1879 	mov	r7,a
      007AE1 E0               [24] 1880 	movx	a,@dptr
      007AE2 60 08            [24] 1881 	jz	00103$
                                   1882 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007AE4 8F 82            [24] 1883 	mov	dpl, r7
      007AE6 12 80 F7         [24] 1884 	lcall	_del_owned_weak_mods
                                   1885 ;	quantum/action.c:1161: send_keyboard_report();
                                   1886 ;	quantum/action.c:1163: }
      007AE9 02 84 01         [24] 1887 	ljmp	_send_keyboard_report
      007AEC                       1888 00103$:
      007AEC 22               [24] 1889 	ret
                                   1890 ;------------------------------------------------------------
                                   1891 ;Allocation info for local variables in function 'clear_keyboard'
                                   1892 ;------------------------------------------------------------
                                   1893 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1894 ;	-----------------------------------------
                                   1895 ;	 function clear_keyboard
                                   1896 ;	-----------------------------------------
      007AED                       1897 _clear_keyboard:
                                   1898 ;	quantum/action.c:1170: clear_mods();
      007AED 12 84 7C         [24] 1899 	lcall	_clear_mods
                                   1900 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1901 ;	quantum/action.c:1172: }
      007AF0 41 F2            [12] 1902 	ajmp	_clear_keyboard_but_mods
                                   1903 ;------------------------------------------------------------
                                   1904 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1905 ;------------------------------------------------------------
                                   1906 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1907 ;	-----------------------------------------
                                   1908 ;	 function clear_keyboard_but_mods
                                   1909 ;	-----------------------------------------
      007AF2                       1910 _clear_keyboard_but_mods:
                                   1911 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007AF2 90 0E 8C         [24] 1912 	mov	dptr,#_actual_keyboard_report
      007AF5 12 73 DA         [24] 1913 	lcall	_clear_keys_from_report
                                   1914 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1915 ;	quantum/action.c:1181: }
      007AF8 41 FA            [12] 1916 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1917 ;------------------------------------------------------------
                                   1918 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1919 ;------------------------------------------------------------
                                   1920 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1921 ;	-----------------------------------------
                                   1922 ;	 function clear_keyboard_but_mods_and_keys
                                   1923 ;	-----------------------------------------
      007AFA                       1924 _clear_keyboard_but_mods_and_keys:
                                   1925 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007AFA 12 4C 1B         [24] 1926 	lcall	_ak820_tapping_cancel
                                   1927 ;	quantum/action.c:1191: ak820_tap_dance_cancel();
      007AFD 12 48 23         [24] 1928 	lcall	_ak820_tap_dance_cancel
                                   1929 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007B00 12 2E F0         [24] 1930 	lcall	_ak820_oneshot_cancel
                                   1931 ;	quantum/action.c:1209: ak820_combo_cancel();
      007B03 12 35 29         [24] 1932 	lcall	_ak820_combo_cancel
                                   1933 ;	quantum/action.c:1212: repeat_key_cancel();
      007B06 12 A5 B0         [24] 1934 	lcall	_repeat_key_cancel
                                   1935 ;	quantum/action.c:1214: clear_owned_mods();
      007B09 12 81 07         [24] 1936 	lcall	_clear_owned_mods
                                   1937 ;	quantum/action.c:1215: clear_owned_keys();
      007B0C 12 81 3F         [24] 1938 	lcall	_clear_owned_keys
                                   1939 ;	quantum/action.c:1216: clear_owned_usages();
      007B0F 12 82 75         [24] 1940 	lcall	_clear_owned_usages
                                   1941 ;	quantum/action.c:1217: layer_hold_clear();
      007B12 91 C5            [12] 1942 	acall	_layer_hold_clear
                                   1943 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007B14 12 A1 47         [24] 1944 	lcall	_clear_macro_tri_layer
                                   1945 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B17 90 0E 8C         [24] 1946 	mov	dptr,#_actual_keyboard_report
      007B1A 12 73 DA         [24] 1947 	lcall	_clear_keys_from_report
                                   1948 ;	quantum/action.c:1224: host_system_send(0);
      007B1D 90 00 00         [24] 1949 	mov	dptr,#0x0000
      007B20 12 71 C5         [24] 1950 	lcall	_host_system_send
                                   1951 ;	quantum/action.c:1225: host_consumer_send(0);
      007B23 90 00 00         [24] 1952 	mov	dptr,#0x0000
      007B26 12 71 F4         [24] 1953 	lcall	_host_consumer_send
                                   1954 ;	quantum/action.c:1227: clear_weak_mods();
      007B29 12 84 B1         [24] 1955 	lcall	_clear_weak_mods
                                   1956 ;	quantum/action.c:1228: send_keyboard_report();
                                   1957 ;	quantum/action.c:1236: }
      007B2C 02 84 01         [24] 1958 	ljmp	_send_keyboard_report
                                   1959 ;------------------------------------------------------------
                                   1960 ;Allocation info for local variables in function 'is_tap_record'
                                   1961 ;------------------------------------------------------------
                                   1962 ;record        Allocated with name '_is_tap_record_record_10000_781'
                                   1963 ;action        Allocated with name '_is_tap_record_action_10001_785'
                                   1964 ;------------------------------------------------------------
                                   1965 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1966 ;	-----------------------------------------
                                   1967 	.area CSEG    (CODE)
                                   1968 	.area CONST   (CODE)
                                   1969 	.area XINIT   (CODE)
      00C5A2                       1970 __xinit__disable_action_cache:
      00C5A2 00                    1971 	.db #0x00	;  0
                                   1972 	.area CABS    (ABS,CODE)
                                   1973 
                                   1974 ; Experimental exact instruction outlining.
                                   1975 	.globl _ak820_outline_0006
                                   1976 	.globl _ak820_outline_0008
                                   1977 	.globl _ak820_outline_0010
                                   1978 	.globl _ak820_outline_0012
                                   1979 	.globl _ak820_outline_0013
                                   1980 	.globl _ak820_outline_0018
                                   1981 	.globl _ak820_outline_0019
                                   1982 	.globl _ak820_outline_0022
                                   1983 	.globl _ak820_outline_0036
                                   1984 	.globl _ak820_outline_0045
                                   1985 	.globl _ak820_outline_0057
                                   1986 	.globl _ak820_outline_0066
                                   1987 	.globl _ak820_outline_0068
                                   1988 	.globl _ak820_outline_0077
                                   1989 	.globl _ak820_outline_0079
                                   1990 	.globl _ak820_outline_0082
                                   1991 	.globl _ak820_outline_0091
                                   1992 	.globl _ak820_outline_0108
                                   1993 	.globl _ak820_outline_0109
                                   1994 	.globl _ak820_outline_0111
                                   1995 	.globl _ak820_outline_0112
                                   1996 	.globl _ak820_outline_0114
                                   1997 	.globl _ak820_outline_0119
                                   1998 	.globl _ak820_outline_0123
                                   1999 	.globl _ak820_outline_0127
                                   2000 	.globl _ak820_outline_0128
                                   2001 	.globl _ak820_outline_0134
                                   2002 	.globl _ak820_outline_0136
                                   2003 	.globl _ak820_outline_0143
                                   2004 	.globl _ak820_outline_0144
                                   2005 	.globl _ak820_outline_0152
                                   2006 	.globl _ak820_outline_0161
                                   2007 	.globl _ak820_outline_0170
                                   2008 	.globl _ak820_outline_0171
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0022
      007B2F                       2012 _ak820_outline_0022:
      007B2F 8E 82            [24] 2013 	mov	dpl,r6
      007B31 8F 83            [24] 2014 	mov	dph,r7
      007B33 A3               [24] 2015 	inc	dptr
      007B34 E0               [24] 2016 	movx	a,@dptr
      007B35 FC               [12] 2017 	mov	r4,a
      007B36 7D 00            [12] 2018 	mov	r5,#0x00
      007B38 8E 82            [24] 2019 	mov	dpl,r6
      007B3A 8F 83            [24] 2020 	mov	dph,r7
      007B3C E0               [24] 2021 	movx	a,@dptr
      007B3D 22               [24] 2022 	ret
                                   2023 
                                   2024 	.area CSEG (CODE)
                                   2025 ; function ak820_outline_0045
      007B3E                       2026 _ak820_outline_0045:
      007B3E 90 08 F4         [24] 2027 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B41 E0               [24] 2028 	movx	a,@dptr
      007B42 54 1F            [12] 2029 	anl	a,#0x1f
      007B44 F5 82            [12] 2030 	mov	dpl,a
      007B46 22               [24] 2031 	ret
                                   2032 
                                   2033 	.area CSEG (CODE)
                                   2034 ; function ak820_outline_0057
      007B47                       2035 _ak820_outline_0057:
      007B47 A3               [24] 2036 	inc	dptr
      007B48 F0               [24] 2037 	movx	@dptr,a
      007B49 E4               [12] 2038 	clr	a
      007B4A A3               [24] 2039 	inc	dptr
      007B4B F0               [24] 2040 	movx	@dptr,a
      007B4C 90 0E 6A         [24] 2041 	mov	dptr,#___memcpy_PARM_3
      007B4F 22               [24] 2042 	ret
                                   2043 
                                   2044 	.area CSEG (CODE)
                                   2045 ; function ak820_outline_0068
      007B50                       2046 _ak820_outline_0068:
      007B50 F5 F0            [12] 2047 	mov	b,a
      007B52 05 F0            [12] 2048 	inc	b
      007B54 74 01            [12] 2049 	mov	a,#0x01
      007B56 22               [24] 2050 	ret
                                   2051 
                                   2052 	.area CSEG (CODE)
                                   2053 ; function ak820_outline_0079
      007B57                       2054 _ak820_outline_0079:
      007B57 90 08 F3         [24] 2055 	mov	dptr,#_process_action_PARM_2
      007B5A E0               [24] 2056 	movx	a,@dptr
      007B5B F5 82            [12] 2057 	mov	dpl,a
      007B5D 22               [24] 2058 	ret
                                   2059 
                                   2060 	.area CSEG (CODE)
                                   2061 ; function ak820_outline_0091
      007B5E                       2062 _ak820_outline_0091:
      007B5E 90 08 F4         [24] 2063 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B61 E0               [24] 2064 	movx	a,@dptr
      007B62 03               [12] 2065 	rr	a
      007B63 03               [12] 2066 	rr	a
      007B64 54 03            [12] 2067 	anl	a,#0x03
      007B66 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0112
      007B67                       2072 _ak820_outline_0112:
      007B67 74 06            [12] 2073 	mov	a,#0x06
      007B69 F0               [24] 2074 	movx	@dptr,a
      007B6A E4               [12] 2075 	clr	a
      007B6B A3               [24] 2076 	inc	dptr
      007B6C F0               [24] 2077 	movx	@dptr,a
      007B6D 22               [24] 2078 	ret
                                   2079 
                                   2080 	.area CSEG (CODE)
                                   2081 ; function ak820_outline_0114
      007B6E                       2082 _ak820_outline_0114:
      007B6E 90 08 F4         [24] 2083 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B71 E0               [24] 2084 	movx	a,@dptr
      007B72 54 0F            [12] 2085 	anl	a,#0x0f
      007B74 22               [24] 2086 	ret
                                   2087 
                                   2088 	.area CSEG (CODE)
                                   2089 ; function ak820_outline_0134
      007B75                       2090 _ak820_outline_0134:
      007B75 90 08 F3         [24] 2091 	mov	dptr,#_process_action_PARM_2
      007B78 E0               [24] 2092 	movx	a,@dptr
      007B79 FE               [12] 2093 	mov	r6,a
      007B7A A3               [24] 2094 	inc	dptr
      007B7B E0               [24] 2095 	movx	a,@dptr
      007B7C 54 03            [12] 2096 	anl	a,#0x03
      007B7E FF               [12] 2097 	mov	r7,a
      007B7F 22               [24] 2098 	ret
                                   2099 
                                   2100 	.area CSEG (CODE)
                                   2101 ; function ak820_outline_0161
      007B80                       2102 _ak820_outline_0161:
      007B80 90 08 F3         [24] 2103 	mov	dptr,#_process_action_PARM_2
      007B83 E0               [24] 2104 	movx	a,@dptr
      007B84 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0170
      007B85                       2109 _ak820_outline_0170:
      007B85 90 08 F8         [24] 2110 	mov	dptr,#_register_code_code_10000_717
      007B88 E0               [24] 2111 	movx	a,@dptr
      007B89 FF               [12] 2112 	mov	r7,a
      007B8A 22               [24] 2113 	ret
                                   2114 
                                   2115 	.area CSEG (CODE)
                                   2116 ; function ak820_outline_0171
      007B8B                       2117 _ak820_outline_0171:
      007B8B 90 08 F9         [24] 2118 	mov	dptr,#_unregister_code_code_10000_731
      007B8E E0               [24] 2119 	movx	a,@dptr
      007B8F FF               [12] 2120 	mov	r7,a
      007B90 22               [24] 2121 	ret
