                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002A                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002A                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000CF7                        589 _via_eeprom_set_valid_valid_10000_611:
      000CF7                        590 	.ds 1
      000CF8                        591 _via_set_layout_options_value_10000_627:
      000CF8                        592 	.ds 4
      000CFC                        593 _process_record_via_PARM_2:
      000CFC                        594 	.ds 3
      000CFF                        595 _process_record_via_keycode_10000_629:
      000CFF                        596 	.ds 2
      000D01                        597 _raw_hid_receive_kb_PARM_2:
      000D01                        598 	.ds 1
      000D02                        599 _raw_hid_receive_kb_data_10000_635:
      000D02                        600 	.ds 3
      000D05                        601 _raw_hid_receive_PARM_2:
      000D05                        602 	.ds 1
      000D06                        603 _raw_hid_receive_packet_10000_637:
      000D06                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A9B8                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A9B8 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A9BB 75 F0 00         [24]  659 	mov	b, #0x00
      00A9BE 12 40 2F         [24]  660 	lcall	_eeprom_read_byte
      00A9C1 AF 82            [24]  661 	mov	r7, dpl
      00A9C3 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00A9C6 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A9C9 75 F0 00         [24]  664 	mov	b, #0x00
      00A9CC 12 40 2F         [24]  665 	lcall	_eeprom_read_byte
      00A9CF AF 82            [24]  666 	mov	r7, dpl
      00A9D1 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A9D4 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A9D7 75 F0 00         [24]  669 	mov	b, #0x00
      00A9DA 12 40 2F         [24]  670 	lcall	_eeprom_read_byte
      00A9DD AF 82            [24]  671 	mov	r7, dpl
      00A9DF BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A9E2 80 04            [24]  673 	sjmp	00104$
      00A9E4                        674 00126$:
      00A9E4                        675 00103$:
                                    676 ;	assignBit
      00A9E4 C2 2A            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A9E6 80 02            [24]  678 	sjmp	00105$
      00A9E8                        679 00104$:
                                    680 ;	assignBit
      00A9E8 D2 2A            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A9EA                        682 00105$:
      00A9EA A2 2A            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A9EC 12 38 68         [24]  684 	lcall	_ak820_outline_0150
                                    685 ;	quantum/via.c:104: }
      00A9EF 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_611'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_612'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_612'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_612'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A9F0                        699 _via_eeprom_set_valid:
      00A9F0 E5 82            [12]  700 	mov	a,dpl
      00A9F2 90 0C F7         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00A9F5 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A9F6 E0               [24]  704 	movx	a,@dptr
      00A9F7 60 04            [24]  705 	jz	00103$
      00A9F9 7F 03            [12]  706 	mov	r7,#0x03
      00A9FB 80 02            [24]  707 	sjmp	00104$
      00A9FD                        708 00103$:
      00A9FD 7F FF            [12]  709 	mov	r7,#0xff
      00A9FF                        710 00104$:
      00A9FF 90 07 61         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AA02 EF               [12]  712 	mov	a,r7
      00AA03 F0               [24]  713 	movx	@dptr,a
      00AA04 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AA07 75 F0 00         [24]  715 	mov	b, #0x00
      00AA0A 12 52 E1         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AA0D 90 0C F7         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AA10 E0               [24]  719 	movx	a,@dptr
      00AA11 60 04            [24]  720 	jz	00105$
      00AA13 7F 20            [12]  721 	mov	r7,#0x20
      00AA15 80 02            [24]  722 	sjmp	00106$
      00AA17                        723 00105$:
      00AA17 7F FF            [12]  724 	mov	r7,#0xff
      00AA19                        725 00106$:
      00AA19 90 07 61         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AA1C EF               [12]  727 	mov	a,r7
      00AA1D F0               [24]  728 	movx	@dptr,a
      00AA1E 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AA21 75 F0 00         [24]  730 	mov	b, #0x00
      00AA24 12 52 E1         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AA27 90 0C F7         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_611
      00AA2A E0               [24]  734 	movx	a,@dptr
      00AA2B 60 04            [24]  735 	jz	00107$
      00AA2D 7F 08            [12]  736 	mov	r7,#0x08
      00AA2F 80 02            [24]  737 	sjmp	00108$
      00AA31                        738 00107$:
      00AA31 7F FF            [12]  739 	mov	r7,#0xff
      00AA33                        740 00108$:
      00AA33 90 07 61         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AA36 EF               [12]  742 	mov	a,r7
      00AA37 F0               [24]  743 	movx	@dptr,a
      00AA38 90 00 27         [24]  744 	mov	dptr,#0x0027
      00AA3B 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00AA3E 02 52 E1         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00AA41                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00AA41 51 64            [12]  757 	acall	_via_get_layout_options
      00AA43 51 7C            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00AA45 31 B8            [12]  760 	acall	_via_eeprom_is_valid
      00AA47 E5 82            [12]  761 	mov	a, dpl
      00AA49 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00AA4B 02 3D DE         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00AA4E                        766 00103$:
      00AA4E 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00AA4F                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00AA4F 75 82 00         [24]  777 	mov	dpl, #0x00
      00AA52 31 F0            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AA54 12 95 91         [24]  780 	lcall	_ak820_outline_0155
      00AA57 51 7D            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AA59 12 8B C5         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00AA5C 12 90 74         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00AA5F 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00AA62 21 F0            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00AA64                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00AA64 90 00 28         [24]  799 	mov	dptr,#0x0028
      00AA67 75 F0 00         [24]  800 	mov	b, #0x00
      00AA6A 12 40 2F         [24]  801 	lcall	_eeprom_read_byte
      00AA6D AF 82            [24]  802 	mov	r7, dpl
      00AA6F 7E 00            [12]  803 	mov	r6,#0x00
      00AA71 7D 00            [12]  804 	mov	r5,#0x00
      00AA73 7C 00            [12]  805 	mov	r4,#0x00
      00AA75 12 43 3C         [24]  806 	lcall	_ak820_outline_0160
      00AA78 8D F0            [24]  807 	mov	b, r5
      00AA7A EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00AA7B 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_624'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00AA7C                        820 _via_set_layout_options_kb:
      00AA7C 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_627'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00AA7D                        831 _via_set_layout_options:
      00AA7D 12 95 89         [24]  832 	lcall	_ak820_outline_0122
      00AA80 90 0C F8         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AA83 12 95 77         [24]  834 	lcall	_ak820_outline_0047
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00AA86 90 0C F8         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_627
      00AA89 E0               [24]  837 	movx	a,@dptr
      00AA8A 90 07 61         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AA8D F0               [24]  839 	movx	@dptr,a
      00AA8E 90 00 28         [24]  840 	mov	dptr,#0x0028
      00AA91 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00AA94 02 52 E1         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_629'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_634'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00AA97                        855 _process_record_via:
      00AA97 12 38 4E         [24]  856 	lcall	_ak820_outline_0109
      00AA9A 90 0C FF         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_629
      00AA9D 12 38 49         [24]  858 	lcall	_ak820_outline_0108
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00AAA0 90 0C FC         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00AAA3 12 53 F0         [24]  861 	lcall	_ak820_outline_0014
      00AAA6 74 05            [12]  862 	mov	a,#0x05
      00AAA8 12 38 77         [24]  863 	lcall	_ak820_outline_0163
      00AAAB 12 53 F9         [24]  864 	lcall	_ak820_outline_0050
      00AAAE 12 BD AB         [24]  865 	lcall	__gptrget
      00AAB1 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00AAB3 90 0C FF         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_629
      00AAB6 12 37 C6         [24]  869 	lcall	_ak820_outline_0010
      00AAB9 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00AABB 2D               [12]  871 	add	a,r5
      00AABC 50 12            [24]  872 	jnc	00105$
      00AABE C3               [12]  873 	clr	c
      00AABF 74 7F            [12]  874 	mov	a,#0x7f
      00AAC1 9C               [12]  875 	subb	a,r4
      00AAC2 74 77            [12]  876 	mov	a,#0x77
      00AAC4 9D               [12]  877 	subb	a,r5
      00AAC5 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AAC7 8E 82            [24]  882 	mov	dpl, r6
      00AAC9 12 90 9A         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AACC 75 82 00         [24]  885 	mov	dpl, #0x00
      00AACF 22               [24]  886 	ret
      00AAD0                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AAD0 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AAD3 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_635'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_636'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AAD4                        903 _raw_hid_receive_kb:
      00AAD4 12 42 CE         [24]  904 	lcall	_ak820_outline_0042
      00AAD7 90 0D 02         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AADA 12 37 E3         [24]  906 	lcall	_ak820_outline_0019
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AADD 90 0D 02         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_635
      00AAE0 12 53 CA         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AAE3 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AAE5 02 BD 70         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_637'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_638'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_638'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_638'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_644'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_652'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_653'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_656'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_657'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_658'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_663'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_665'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_674'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_675'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_675'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_680'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_680'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_687'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_687'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_692'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AAE8                        950 _raw_hid_receive:
      00AAE8 12 42 CE         [24]  951 	lcall	_ak820_outline_0042
      00AAEB 90 0D 06         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AAEE 12 37 E3         [24]  953 	lcall	_ak820_outline_0019
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AAF1 90 0D 06         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_637
      00AAF4 12 37 FB         [24]  956 	lcall	_ak820_outline_0058
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AAF7 74 01            [12]  958 	mov	a,#0x01
      00AAF9 12 43 41         [24]  959 	lcall	_ak820_outline_0164
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AAFC 90 0D 05         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AAFF E0               [24]  962 	movx	a,@dptr
      00AB00 FB               [12]  963 	mov	r3,a
      00AB01 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AB04 80 01            [24]  965 	sjmp	00102$
      00AB06                        966 00520$:
      00AB06 22               [24]  967 	ret
      00AB07                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AB07 90 0E E8         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AB0A E0               [24]  971 	movx	a,@dptr
      00AB0B 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AB0D 12 38 30         [24]  974 	lcall	_ak820_outline_0094
      00AB10 FA               [12]  975 	mov	r2,a
      00AB11 BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00AB14 80 01            [24]  977 	sjmp	00104$
      00AB16                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00AB16 22               [24]  980 	ret
      00AB17                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AB17 12 43 05         [24]  983 	lcall	_ak820_outline_0098
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AB1A FA               [12]  985 	mov	r2,a
      00AB1B 60 21            [24]  986 	jz	00114$
      00AB1D BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00AB20 80 1C            [24]  988 	sjmp	00114$
      00AB22                        989 00524$:
      00AB22 BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00AB25 80 17            [24]  991 	sjmp	00114$
      00AB27                        992 00525$:
      00AB27 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00AB2A 80 12            [24]  994 	sjmp	00114$
      00AB2C                        995 00526$:
      00AB2C BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00AB2F 80 0D            [24]  997 	sjmp	00114$
      00AB31                        998 00527$:
      00AB31 BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00AB34 80 08            [24] 1000 	sjmp	00114$
      00AB36                       1001 00528$:
      00AB36 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00AB39 80 03            [24] 1003 	sjmp	00530$
      00AB3B                       1004 00529$:
      00AB3B 02 B0 5F         [24] 1005 	ljmp	00171$
      00AB3E                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00AB3E                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00AB3E 12 38 30         [24] 1010 	lcall	_ak820_outline_0094
      00AB41 FA               [12] 1011 	mov	r2,a
      00AB42 BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00AB45 80 61            [24] 1013 	sjmp	00115$
      00AB47                       1014 00531$:
      00AB47 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00AB4A 80 69            [24] 1016 	sjmp	00116$
      00AB4C                       1017 00532$:
      00AB4C BA 03 02         [24] 1018 	cjne	r2,#0x03,00533$
      00AB4F 81 73            [24] 1019 	ajmp	00125$
      00AB51                       1020 00533$:
      00AB51 BA 04 02         [24] 1021 	cjne	r2,#0x04,00534$
      00AB54 A1 07            [12] 1022 	ajmp	00129$
      00AB56                       1023 00534$:
      00AB56 BA 05 02         [24] 1024 	cjne	r2,#0x05,00535$
      00AB59 A1 41            [12] 1025 	ajmp	00130$
      00AB5B                       1026 00535$:
      00AB5B BA 06 02         [24] 1027 	cjne	r2,#0x06,00536$
      00AB5E A1 AD            [12] 1028 	ajmp	00135$
      00AB60                       1029 00536$:
      00AB60 BA 07 02         [24] 1030 	cjne	r2,#0x07,00537$
      00AB63 A1 BF            [12] 1031 	ajmp	00136$
      00AB65                       1032 00537$:
      00AB65 BA 08 02         [24] 1033 	cjne	r2,#0x08,00538$
      00AB68 A1 DA            [12] 1034 	ajmp	00137$
      00AB6A                       1035 00538$:
      00AB6A BA 09 02         [24] 1036 	cjne	r2,#0x09,00539$
      00AB6D A1 F5            [12] 1037 	ajmp	00138$
      00AB6F                       1038 00539$:
      00AB6F BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00AB72 02 AF EE         [24] 1040 	ljmp	00161$
      00AB75                       1041 00540$:
      00AB75 BA 0C 02         [24] 1042 	cjne	r2,#0x0c,00541$
      00AB78 C1 10            [12] 1043 	ajmp	00139$
      00AB7A                       1044 00541$:
      00AB7A BA 0D 02         [24] 1045 	cjne	r2,#0x0d,00542$
      00AB7D C1 31            [12] 1046 	ajmp	00140$
      00AB7F                       1047 00542$:
      00AB7F BA 0E 02         [24] 1048 	cjne	r2,#0x0e,00543$
      00AB82 C1 5A            [12] 1049 	ajmp	00141$
      00AB84                       1050 00543$:
      00AB84 BA 0F 02         [24] 1051 	cjne	r2,#0x0f,00544$
      00AB87 C1 A2            [12] 1052 	ajmp	00144$
      00AB89                       1053 00544$:
      00AB89 BA 10 02         [24] 1054 	cjne	r2,#0x10,00545$
      00AB8C E1 11            [12] 1055 	ajmp	00151$
      00AB8E                       1056 00545$:
      00AB8E BA 11 02         [24] 1057 	cjne	r2,#0x11,00546$
      00AB91 E1 2A            [12] 1058 	ajmp	00154$
      00AB93                       1059 00546$:
      00AB93 BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00AB96 02 AF 4B         [24] 1061 	ljmp	00155$
      00AB99                       1062 00547$:
      00AB99 BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00AB9C 02 AF 93         [24] 1064 	ljmp	00158$
      00AB9F                       1065 00548$:
      00AB9F BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00ABA2 02 B0 2E         [24] 1067 	ljmp	00168$
      00ABA5                       1068 00549$:
      00ABA5 02 B0 47         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00ABA8                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00ABA8 12 38 59         [24] 1073 	lcall	_ak820_outline_0127
      00ABAB E4               [12] 1074 	clr	a
      00ABAC 12 42 C6         [24] 1075 	lcall	_ak820_outline_0037
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00ABAF 74 09            [12] 1077 	mov	a,#0x09
      00ABB1 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00ABB2 02 B0 5F         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00ABB5                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00ABB5 12 43 05         [24] 1084 	lcall	_ak820_outline_0098
      00ABB8 FA               [12] 1085 	mov	r2,a
      00ABB9 BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00ABBC 80 0C            [24] 1087 	sjmp	00117$
      00ABBE                       1088 00550$:
      00ABBE BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00ABC1 80 32            [24] 1090 	sjmp	00118$
      00ABC3                       1091 00551$:
      00ABC3 BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00ABC6 81 2F            [24] 1093 	ajmp	00119$
      00ABC8                       1094 00552$:
      00ABC8 81 59            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00ABCA                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00ABCA 12 4E 09         [24] 1099 	lcall	_timer_read32
      00ABCD 85 82 38         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00ABD0 85 83 39         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00ABD3 85 F0 3A         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00ABD6 F5 3B            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00ABD8 12 43 17         [24] 1105 	lcall	_ak820_outline_0119
      00ABDB A3               [24] 1106 	inc	dptr
      00ABDC A3               [24] 1107 	inc	dptr
      00ABDD E5 3B            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ABDF 12 42 C6         [24] 1109 	lcall	_ak820_outline_0037
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00ABE2 A3               [24] 1111 	inc	dptr
      00ABE3 E5 3A            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ABE5 F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00ABE6 12 B0 84         [24] 1115 	lcall	_ak820_outline_0023
      00ABE9 E5 39            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ABEB F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00ABEC 12 42 BC         [24] 1119 	lcall	_ak820_outline_0012
      00ABEF E5 38            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00ABF1 F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00ABF2 02 B0 5F         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00ABF5                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00ABF5 C0 03            [24] 1127 	push	ar3
      00ABF7 C0 07            [24] 1128 	push	ar7
      00ABF9 C0 06            [24] 1129 	push	ar6
      00ABFB C0 03            [24] 1130 	push	ar3
      00ABFD 51 64            [12] 1131 	acall	_via_get_layout_options
      00ABFF 85 82 38         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AC02 85 83 39         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AC05 85 F0 3A         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AC08 F5 3B            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AC0A D0 03            [24] 1136 	pop	ar3
      00AC0C D0 06            [24] 1137 	pop	ar6
      00AC0E D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AC10 12 43 17         [24] 1140 	lcall	_ak820_outline_0119
      00AC13 A3               [24] 1141 	inc	dptr
      00AC14 A3               [24] 1142 	inc	dptr
      00AC15 E5 3B            [12] 1143 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AC17 12 42 C6         [24] 1144 	lcall	_ak820_outline_0037
                                   1145 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AC1A A3               [24] 1146 	inc	dptr
      00AC1B E5 3A            [12] 1147 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AC1D F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AC1E 12 B0 84         [24] 1150 	lcall	_ak820_outline_0023
      00AC21 E5 39            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AC23 F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AC24 12 42 BC         [24] 1154 	lcall	_ak820_outline_0012
      00AC27 E5 38            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00AC29 F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00AC2A D0 03            [24] 1158 	pop	ar3
      00AC2C 02 B0 5F         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AC2F                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00AC2F 90 0E E7         [24] 1163 	mov	dptr,#_vial_unlocked
      00AC32 E0               [24] 1164 	movx	a,@dptr
      00AC33 70 03            [24] 1165 	jnz	00553$
      00AC35 02 B0 5F         [24] 1166 	ljmp	00171$
      00AC38                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AC38 7A 01            [12] 1169 	mov	r2,#0x01
      00AC3A 79 00            [12] 1170 	mov	r1,#0x00
      00AC3C                       1171 00173$:
      00AC3C B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00AC3F                       1173 00554$:
      00AC3F 40 03            [24] 1174 	jc	00555$
      00AC41 02 B0 5F         [24] 1175 	ljmp	00171$
      00AC44                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AC44 89 82            [24] 1178 	mov	dpl, r1
      00AC46 12 5E 60         [24] 1179 	lcall	_matrix_get_row
      00AC49 A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AC4B EA               [12] 1182 	mov	a,r2
      00AC4C 2C               [12] 1183 	add	a, r4
      00AC4D F5 82            [12] 1184 	mov	dpl,a
      00AC4F E4               [12] 1185 	clr	a
      00AC50 3D               [12] 1186 	addc	a, r5
      00AC51 F5 83            [12] 1187 	mov	dph,a
      00AC53 0A               [12] 1188 	inc	r2
      00AC54 E8               [12] 1189 	mov	a,r0
      00AC55 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AC56 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00AC57 80 E3            [24] 1194 	sjmp	00173$
      00AC59                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AC59 12 B0 B2         [24] 1197 	lcall	_ak820_outline_0096
      00AC5C 90 0D 01         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AC5F 12 B0 8D         [24] 1199 	lcall	_ak820_outline_0044
      00AC62 C0 07            [24] 1200 	push	ar7
      00AC64 C0 06            [24] 1201 	push	ar6
      00AC66 C0 03            [24] 1202 	push	ar3
      00AC68 51 D4            [24] 1203 	acall	_raw_hid_receive_kb
      00AC6A D0 03            [24] 1204 	pop	ar3
      00AC6C D0 06            [24] 1205 	pop	ar6
      00AC6E D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00AC70 02 B0 5F         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AC73                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00AC73 12 43 05         [24] 1212 	lcall	_ak820_outline_0098
      00AC76 FA               [12] 1213 	mov	r2,a
      00AC77 BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00AC7A 80 02            [24] 1215 	sjmp	00557$
      00AC7C                       1216 00556$:
      00AC7C 81 ED            [12] 1217 	ajmp	00127$
      00AC7E                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AC7E C0 03            [24] 1220 	push	ar3
      00AC80 12 37 EB         [24] 1221 	lcall	_ak820_outline_0035
      00AC83 F8               [12] 1222 	mov	r0,a
      00AC84 79 00            [12] 1223 	mov	r1,#0x00
      00AC86 7B 00            [12] 1224 	mov	r3,#0x00
      00AC88 88 3B            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AC8A 8B 38            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AC8C 8B 39            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AC8E 8B 3A            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AC90 12 48 7B         [24] 1229 	lcall	_ak820_outline_0016
      00AC93 F8               [12] 1230 	mov	r0,a
      00AC94 89 03            [24] 1231 	mov	ar3,r1
      00AC96 88 02            [24] 1232 	mov	ar2,r0
      00AC98 E4               [12] 1233 	clr	a
      00AC99 42 38            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00AC9B E9               [12] 1235 	mov	a,r1
      00AC9C 42 39            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AC9E EA               [12] 1237 	mov	a,r2
      00AC9F 42 3A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ACA1 EB               [12] 1239 	mov	a,r3
      00ACA2 42 3B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ACA4 12 B0 84         [24] 1241 	lcall	_ak820_outline_0023
      00ACA7 E0               [24] 1242 	movx	a,@dptr
      00ACA8 F8               [12] 1243 	mov	r0,a
      00ACA9 79 00            [12] 1244 	mov	r1,#0x00
      00ACAB 7A 00            [12] 1245 	mov	r2,#0x00
      00ACAD 8A 03            [24] 1246 	mov	ar3,r2
      00ACAF 89 02            [24] 1247 	mov	ar2,r1
      00ACB1 88 01            [24] 1248 	mov	ar1,r0
      00ACB3 E4               [12] 1249 	clr	a
      00ACB4 42 38            [12] 1250 	orl	_raw_hid_receive_sloc0_1_0,a
      00ACB6 E9               [12] 1251 	mov	a,r1
      00ACB7 42 39            [12] 1252 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ACB9 EA               [12] 1253 	mov	a,r2
      00ACBA 42 3A            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ACBC EB               [12] 1255 	mov	a,r3
      00ACBD 42 3B            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ACBF 12 42 BC         [24] 1257 	lcall	_ak820_outline_0012
      00ACC2 E0               [24] 1258 	movx	a,@dptr
      00ACC3 F8               [12] 1259 	mov	r0,a
      00ACC4 E4               [12] 1260 	clr	a
      00ACC5 F9               [12] 1261 	mov	r1,a
      00ACC6 FA               [12] 1262 	mov	r2,a
      00ACC7 FB               [12] 1263 	mov	r3,a
      00ACC8 E5 39            [12] 1264 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ACCA 42 01            [12] 1265 	orl	ar1,a
      00ACCC E5 3A            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ACCE 42 02            [12] 1267 	orl	ar2,a
      00ACD0 E5 3B            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ACD2 42 03            [12] 1269 	orl	ar3,a
                                   1270 ;	quantum/via.c:323: via_set_layout_options(value);
      00ACD4 12 38 6D         [24] 1271 	lcall	_ak820_outline_0159
      00ACD7 8A F0            [24] 1272 	mov	b, r2
      00ACD9 EB               [12] 1273 	mov	a, r3
      00ACDA C0 07            [24] 1274 	push	ar7
      00ACDC C0 06            [24] 1275 	push	ar6
      00ACDE C0 03            [24] 1276 	push	ar3
      00ACE0 51 7D            [12] 1277 	acall	_via_set_layout_options
      00ACE2 D0 03            [24] 1278 	pop	ar3
      00ACE4 D0 06            [24] 1279 	pop	ar6
      00ACE6 D0 07            [24] 1280 	pop	ar7
                                   1281 ;	quantum/via.c:324: break;
      00ACE8 D0 03            [24] 1282 	pop	ar3
      00ACEA 02 B0 5F         [24] 1283 	ljmp	00171$
                                   1284 ;	quantum/via.c:326: default: {
      00ACED                       1285 00127$:
                                   1286 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00ACED 12 B0 B2         [24] 1287 	lcall	_ak820_outline_0096
      00ACF0 90 0D 01         [24] 1288 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ACF3 12 B0 8D         [24] 1289 	lcall	_ak820_outline_0044
      00ACF6 C0 07            [24] 1290 	push	ar7
      00ACF8 C0 06            [24] 1291 	push	ar6
      00ACFA C0 03            [24] 1292 	push	ar3
      00ACFC 51 D4            [24] 1293 	acall	_raw_hid_receive_kb
      00ACFE D0 03            [24] 1294 	pop	ar3
      00AD00 D0 06            [24] 1295 	pop	ar6
      00AD02 D0 07            [24] 1296 	pop	ar7
                                   1297 ;	quantum/via.c:331: break;
      00AD04 02 B0 5F         [24] 1298 	ljmp	00171$
                                   1299 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AD07                       1300 00129$:
                                   1301 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AD07 12 43 05         [24] 1302 	lcall	_ak820_outline_0098
      00AD0A FA               [12] 1303 	mov	r2,a
      00AD0B 12 37 EB         [24] 1304 	lcall	_ak820_outline_0035
      00AD0E F9               [12] 1305 	mov	r1,a
      00AD0F 12 48 7B         [24] 1306 	lcall	_ak820_outline_0016
      00AD12 F8               [12] 1307 	mov	r0,a
      00AD13 90 0B 9B         [24] 1308 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AD16 E9               [12] 1309 	mov	a,r1
      00AD17 F0               [24] 1310 	movx	@dptr,a
      00AD18 90 0B 9C         [24] 1311 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AD1B E8               [12] 1312 	mov	a,r0
      00AD1C F0               [24] 1313 	movx	@dptr,a
      00AD1D 8A 82            [24] 1314 	mov	dpl, r2
      00AD1F C0 07            [24] 1315 	push	ar7
      00AD21 C0 06            [24] 1316 	push	ar6
      00AD23 C0 03            [24] 1317 	push	ar3
      00AD25 12 87 DB         [24] 1318 	lcall	_dynamic_keymap_get_keycode
      00AD28 A9 82            [24] 1319 	mov	r1, dpl
      00AD2A AA 83            [24] 1320 	mov	r2, dph
      00AD2C D0 03            [24] 1321 	pop	ar3
      00AD2E D0 06            [24] 1322 	pop	ar6
      00AD30 D0 07            [24] 1323 	pop	ar7
                                   1324 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AD32 12 B0 84         [24] 1325 	lcall	_ak820_outline_0023
      00AD35 8A 00            [24] 1326 	mov	ar0,r2
      00AD37 E8               [12] 1327 	mov	a,r0
      00AD38 F0               [24] 1328 	movx	@dptr,a
                                   1329 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AD39 12 42 BC         [24] 1330 	lcall	_ak820_outline_0012
      00AD3C E9               [12] 1331 	mov	a,r1
      00AD3D F0               [24] 1332 	movx	@dptr,a
                                   1333 ;	quantum/via.c:337: break;
      00AD3E 02 B0 5F         [24] 1334 	ljmp	00171$
                                   1335 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AD41                       1336 00130$:
                                   1337 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AD41 90 0E E7         [24] 1338 	mov	dptr,#_vial_unlocked
      00AD44 E0               [24] 1339 	movx	a,@dptr
      00AD45 70 19            [24] 1340 	jnz	00132$
      00AD47 12 B0 84         [24] 1341 	lcall	_ak820_outline_0023
      00AD4A E0               [24] 1342 	movx	a,@dptr
      00AD4B FA               [12] 1343 	mov	r2,a
      00AD4C BA 7C 11         [24] 1344 	cjne	r2,#0x7c,00132$
      00AD4F 74 05            [12] 1345 	mov	a,#0x05
      00AD51 2E               [12] 1346 	add	a, r6
      00AD52 12 37 D0         [24] 1347 	lcall	_ak820_outline_0017
      00AD55 70 09            [24] 1348 	jnz	00132$
                                   1349 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AD57 12 43 17         [24] 1350 	lcall	_ak820_outline_0119
      00AD5A 74 FF            [12] 1351 	mov	a,#0xff
      00AD5C F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/via.c:345: break;
      00AD5D 02 B0 5F         [24] 1354 	ljmp	00171$
      00AD60                       1355 00132$:
                                   1356 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AD60 C0 03            [24] 1357 	push	ar3
      00AD62 12 43 05         [24] 1358 	lcall	_ak820_outline_0098
      00AD65 F5 3D            [12] 1359 	mov	_raw_hid_receive_sloc2_1_0,a
      00AD67 12 37 EB         [24] 1360 	lcall	_ak820_outline_0035
      00AD6A F5 3C            [12] 1361 	mov	_raw_hid_receive_sloc1_1_0,a
      00AD6C 12 48 7B         [24] 1362 	lcall	_ak820_outline_0016
      00AD6F F5 38            [12] 1363 	mov	_raw_hid_receive_sloc0_1_0,a
      00AD71 12 B0 84         [24] 1364 	lcall	_ak820_outline_0023
      00AD74 E0               [24] 1365 	movx	a,@dptr
      00AD75 FB               [12] 1366 	mov	r3,a
      00AD76 78 00            [12] 1367 	mov	r0,#0x00
      00AD78 12 42 BC         [24] 1368 	lcall	_ak820_outline_0012
      00AD7B E0               [24] 1369 	movx	a,@dptr
      00AD7C 7A 00            [12] 1370 	mov	r2,#0x00
      00AD7E 42 00            [12] 1371 	orl	ar0,a
      00AD80 EA               [12] 1372 	mov	a,r2
      00AD81 42 03            [12] 1373 	orl	ar3,a
      00AD83 90 0B 9E         [24] 1374 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00AD86 E5 3C            [12] 1375 	mov	a,_raw_hid_receive_sloc1_1_0
      00AD88 F0               [24] 1376 	movx	@dptr,a
      00AD89 90 0B 9F         [24] 1377 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00AD8C E5 38            [12] 1378 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD8E F0               [24] 1379 	movx	@dptr,a
      00AD8F 90 0B A0         [24] 1380 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00AD92 E8               [12] 1381 	mov	a,r0
      00AD93 12 48 ED         [24] 1382 	lcall	_ak820_outline_0189
      00AD96 85 3D 82         [24] 1383 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00AD99 C0 07            [24] 1384 	push	ar7
      00AD9B C0 06            [24] 1385 	push	ar6
      00AD9D C0 03            [24] 1386 	push	ar3
      00AD9F 12 88 29         [24] 1387 	lcall	_dynamic_keymap_set_keycode
      00ADA2 D0 03            [24] 1388 	pop	ar3
      00ADA4 D0 06            [24] 1389 	pop	ar6
      00ADA6 D0 07            [24] 1390 	pop	ar7
                                   1391 ;	quantum/via.c:349: break;
      00ADA8 D0 03            [24] 1392 	pop	ar3
      00ADAA 02 B0 5F         [24] 1393 	ljmp	00171$
                                   1394 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00ADAD                       1395 00135$:
                                   1396 ;	quantum/via.c:352: dynamic_keymap_reset();
      00ADAD C0 07            [24] 1397 	push	ar7
      00ADAF C0 06            [24] 1398 	push	ar6
      00ADB1 C0 03            [24] 1399 	push	ar3
      00ADB3 12 8B C5         [24] 1400 	lcall	_dynamic_keymap_reset
      00ADB6 D0 03            [24] 1401 	pop	ar3
      00ADB8 D0 06            [24] 1402 	pop	ar6
      00ADBA D0 07            [24] 1403 	pop	ar7
                                   1404 ;	quantum/via.c:353: break;
      00ADBC 02 B0 5F         [24] 1405 	ljmp	00171$
                                   1406 ;	quantum/via.c:355: case id_lighting_set_value: {
      00ADBF                       1407 00136$:
                                   1408 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00ADBF 12 B0 B2         [24] 1409 	lcall	_ak820_outline_0096
      00ADC2 90 0E 60         [24] 1410 	mov	dptr,#_vialrgb_set_value_PARM_2
      00ADC5 12 B0 8D         [24] 1411 	lcall	_ak820_outline_0044
      00ADC8 C0 07            [24] 1412 	push	ar7
      00ADCA C0 06            [24] 1413 	push	ar6
      00ADCC C0 03            [24] 1414 	push	ar3
      00ADCE 12 BB 4F         [24] 1415 	lcall	_vialrgb_set_value
      00ADD1 D0 03            [24] 1416 	pop	ar3
      00ADD3 D0 06            [24] 1417 	pop	ar6
      00ADD5 D0 07            [24] 1418 	pop	ar7
                                   1419 ;	quantum/via.c:375: break;
      00ADD7 02 B0 5F         [24] 1420 	ljmp	00171$
                                   1421 ;	quantum/via.c:377: case id_lighting_get_value: {
      00ADDA                       1422 00137$:
                                   1423 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00ADDA 12 B0 B2         [24] 1424 	lcall	_ak820_outline_0096
      00ADDD 90 0E 5C         [24] 1425 	mov	dptr,#_vialrgb_get_value_PARM_2
      00ADE0 12 B0 8D         [24] 1426 	lcall	_ak820_outline_0044
      00ADE3 C0 07            [24] 1427 	push	ar7
      00ADE5 C0 06            [24] 1428 	push	ar6
      00ADE7 C0 03            [24] 1429 	push	ar3
      00ADE9 12 B9 E8         [24] 1430 	lcall	_vialrgb_get_value
      00ADEC D0 03            [24] 1431 	pop	ar3
      00ADEE D0 06            [24] 1432 	pop	ar6
      00ADF0 D0 07            [24] 1433 	pop	ar7
                                   1434 ;	quantum/via.c:397: break;
      00ADF2 02 B0 5F         [24] 1435 	ljmp	00171$
                                   1436 ;	quantum/via.c:399: case id_lighting_save: {
      00ADF5                       1437 00138$:
                                   1438 ;	quantum/via.c:407: vialrgb_save(data, length);
      00ADF5 12 B0 B2         [24] 1439 	lcall	_ak820_outline_0096
      00ADF8 90 0E 64         [24] 1440 	mov	dptr,#_vialrgb_save_PARM_2
      00ADFB 12 B0 8D         [24] 1441 	lcall	_ak820_outline_0044
      00ADFE C0 07            [24] 1442 	push	ar7
      00AE00 C0 06            [24] 1443 	push	ar6
      00AE02 C0 03            [24] 1444 	push	ar3
      00AE04 12 BB DC         [24] 1445 	lcall	_vialrgb_save
      00AE07 D0 03            [24] 1446 	pop	ar3
      00AE09 D0 06            [24] 1447 	pop	ar6
      00AE0B D0 07            [24] 1448 	pop	ar7
                                   1449 ;	quantum/via.c:419: break;
      00AE0D 02 B0 5F         [24] 1450 	ljmp	00171$
                                   1451 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AE10                       1452 00139$:
                                   1453 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AE10 C0 07            [24] 1454 	push	ar7
      00AE12 C0 06            [24] 1455 	push	ar6
      00AE14 C0 05            [24] 1456 	push	ar5
      00AE16 C0 04            [24] 1457 	push	ar4
      00AE18 C0 03            [24] 1458 	push	ar3
      00AE1A 12 8F ED         [24] 1459 	lcall	_dynamic_keymap_macro_get_count
      00AE1D AA 82            [24] 1460 	mov	r2, dpl
      00AE1F D0 03            [24] 1461 	pop	ar3
      00AE21 D0 04            [24] 1462 	pop	ar4
      00AE23 D0 05            [24] 1463 	pop	ar5
      00AE25 D0 06            [24] 1464 	pop	ar6
      00AE27 D0 07            [24] 1465 	pop	ar7
      00AE29 12 38 59         [24] 1466 	lcall	_ak820_outline_0127
      00AE2C EA               [12] 1467 	mov	a,r2
      00AE2D F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/via.c:430: break;
      00AE2E 02 B0 5F         [24] 1470 	ljmp	00171$
                                   1471 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AE31                       1472 00140$:
                                   1473 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AE31 C0 07            [24] 1474 	push	ar7
      00AE33 C0 06            [24] 1475 	push	ar6
      00AE35 C0 05            [24] 1476 	push	ar5
      00AE37 C0 04            [24] 1477 	push	ar4
      00AE39 C0 03            [24] 1478 	push	ar3
      00AE3B 12 8F F1         [24] 1479 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AE3E A9 82            [24] 1480 	mov	r1, dpl
      00AE40 AA 83            [24] 1481 	mov	r2, dph
      00AE42 D0 03            [24] 1482 	pop	ar3
      00AE44 D0 04            [24] 1483 	pop	ar4
      00AE46 D0 05            [24] 1484 	pop	ar5
      00AE48 D0 06            [24] 1485 	pop	ar6
      00AE4A D0 07            [24] 1486 	pop	ar7
                                   1487 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AE4C 8A 00            [24] 1488 	mov	ar0,r2
      00AE4E 12 38 59         [24] 1489 	lcall	_ak820_outline_0127
      00AE51 E8               [12] 1490 	mov	a,r0
      00AE52 12 42 C6         [24] 1491 	lcall	_ak820_outline_0037
                                   1492 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AE55 E9               [12] 1493 	mov	a,r1
      00AE56 F0               [24] 1494 	movx	@dptr,a
                                   1495 ;	quantum/via.c:436: break;
      00AE57 02 B0 5F         [24] 1496 	ljmp	00171$
                                   1497 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AE5A                       1498 00141$:
                                   1499 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AE5A C0 03            [24] 1500 	push	ar3
      00AE5C 12 B0 6D         [24] 1501 	lcall	_ak820_outline_0004
      00AE5F 89 38            [24] 1502 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AE61 8A 39            [24] 1503 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1504 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AE63 12 48 7B         [24] 1505 	lcall	_ak820_outline_0016
      00AE66 FB               [12] 1506 	mov	r3,a
                                   1507 ;	quantum/via.c:441: if (size <= 28)
      00AE67 8B 3E            [24] 1508 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AE69 75 3F 00         [24] 1509 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AE6C C3               [12] 1510 	clr	c
      00AE6D 74 1C            [12] 1511 	mov	a,#0x1c
      00AE6F 9B               [12] 1512 	subb	a,r3
      00AE70 D0 03            [24] 1513 	pop	ar3
      00AE72 50 03            [24] 1514 	jnc	00562$
      00AE74 02 B0 5F         [24] 1515 	ljmp	00171$
      00AE77                       1516 00562$:
                                   1517 ;	free result
                                   1518 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AE77 12 B0 96         [24] 1519 	lcall	_ak820_outline_0073
      00AE7A 90 0B FF         [24] 1520 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AE7D E5 3E            [12] 1521 	mov	a,_raw_hid_receive_sloc3_1_0
      00AE7F F0               [24] 1522 	movx	@dptr,a
      00AE80 E5 3F            [12] 1523 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AE82 A3               [24] 1524 	inc	dptr
      00AE83 F0               [24] 1525 	movx	@dptr,a
      00AE84 90 0C 01         [24] 1526 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AE87 12 B0 A0         [24] 1527 	lcall	_ak820_outline_0089
      00AE8A 85 38 82         [24] 1528 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AE8D 85 39 83         [24] 1529 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AE90 C0 07            [24] 1530 	push	ar7
      00AE92 C0 06            [24] 1531 	push	ar6
      00AE94 C0 03            [24] 1532 	push	ar3
      00AE96 12 8F F5         [24] 1533 	lcall	_dynamic_keymap_macro_get_buffer
      00AE99 D0 03            [24] 1534 	pop	ar3
      00AE9B D0 06            [24] 1535 	pop	ar6
      00AE9D D0 07            [24] 1536 	pop	ar7
                                   1537 ;	quantum/via.c:443: break;
      00AE9F 02 B0 5F         [24] 1538 	ljmp	00171$
                                   1539 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AEA2                       1540 00144$:
                                   1541 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AEA2 90 0E E7         [24] 1542 	mov	dptr,#_vial_unlocked
      00AEA5 E0               [24] 1543 	movx	a,@dptr
      00AEA6 70 01            [24] 1544 	jnz	00146$
                                   1545 ;	quantum/via.c:450: return;
      00AEA8 22               [24] 1546 	ret
      00AEA9                       1547 00146$:
                                   1548 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AEA9 C0 03            [24] 1549 	push	ar3
      00AEAB 12 B0 6D         [24] 1550 	lcall	_ak820_outline_0004
      00AEAE 89 3E            [24] 1551 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AEB0 8A 3F            [24] 1552 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1553 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AEB2 12 48 7B         [24] 1554 	lcall	_ak820_outline_0016
      00AEB5 F5 38            [12] 1555 	mov	_raw_hid_receive_sloc0_1_0, a
      00AEB7 75 39 00         [24] 1556 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1557 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AEBA 85 38 40         [24] 1558 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AEBD 85 39 41         [24] 1559 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00AEC0 C3               [12] 1560 	clr	c
      00AEC1 74 1C            [12] 1561 	mov	a,#0x1c
      00AEC3 95 40            [12] 1562 	subb	a,_raw_hid_receive_sloc4_1_0
      00AEC5 E4               [12] 1563 	clr	a
      00AEC6 95 41            [12] 1564 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AEC8 D0 03            [24] 1565 	pop	ar3
      00AECA 40 44            [24] 1566 	jc	00147$
                                   1567 ;	free result
      00AECC 8B 01            [24] 1568 	mov	ar1,r3
      00AECE 7A 00            [12] 1569 	mov	r2,#0x00
      00AED0 E9               [12] 1570 	mov	a,r1
      00AED1 24 FC            [12] 1571 	add	a,#0xfc
      00AED3 F9               [12] 1572 	mov	r1,a
      00AED4 EA               [12] 1573 	mov	a,r2
      00AED5 34 FF            [12] 1574 	addc	a,#0xff
      00AED7 FA               [12] 1575 	mov	r2,a
      00AED8 C3               [12] 1576 	clr	c
      00AED9 E9               [12] 1577 	mov	a,r1
      00AEDA 95 40            [12] 1578 	subb	a,_raw_hid_receive_sloc4_1_0
      00AEDC EA               [12] 1579 	mov	a,r2
      00AEDD 95 41            [12] 1580 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AEDF 40 2F            [24] 1581 	jc	00147$
                                   1582 ;	free result
      00AEE1 12 B0 96         [24] 1583 	lcall	_ak820_outline_0073
      00AEE4 90 0C 06         [24] 1584 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AEE7 E5 38            [12] 1585 	mov	a,_raw_hid_receive_sloc0_1_0
      00AEE9 F0               [24] 1586 	movx	@dptr,a
      00AEEA E5 39            [12] 1587 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AEEC A3               [24] 1588 	inc	dptr
      00AEED F0               [24] 1589 	movx	@dptr,a
      00AEEE 90 0C 08         [24] 1590 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AEF1 12 B0 A0         [24] 1591 	lcall	_ak820_outline_0089
      00AEF4 85 3E 82         [24] 1592 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AEF7 85 3F 83         [24] 1593 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AEFA C0 07            [24] 1594 	push	ar7
      00AEFC C0 06            [24] 1595 	push	ar6
      00AEFE C0 03            [24] 1596 	push	ar3
      00AF00 12 90 43         [24] 1597 	lcall	_dynamic_keymap_macro_set_buffer
      00AF03 E5 82            [12] 1598 	mov	a, dpl
      00AF05 D0 03            [24] 1599 	pop	ar3
      00AF07 D0 06            [24] 1600 	pop	ar6
      00AF09 D0 07            [24] 1601 	pop	ar7
      00AF0B 60 03            [24] 1602 	jz	00566$
      00AF0D 02 B0 5F         [24] 1603 	ljmp	00171$
      00AF10                       1604 00566$:
      00AF10                       1605 00147$:
      00AF10 22               [24] 1606 	ret
                                   1607 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AF11                       1608 00151$:
                                   1609 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AF11 90 0E E7         [24] 1610 	mov	dptr,#_vial_unlocked
      00AF14 E0               [24] 1611 	movx	a,@dptr
      00AF15 70 01            [24] 1612 	jnz	00153$
      00AF17 22               [24] 1613 	ret
      00AF18                       1614 00153$:
                                   1615 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AF18 C0 07            [24] 1616 	push	ar7
      00AF1A C0 06            [24] 1617 	push	ar6
      00AF1C C0 03            [24] 1618 	push	ar3
      00AF1E 12 90 74         [24] 1619 	lcall	_dynamic_keymap_macro_reset
      00AF21 D0 03            [24] 1620 	pop	ar3
      00AF23 D0 06            [24] 1621 	pop	ar6
      00AF25 D0 07            [24] 1622 	pop	ar7
                                   1623 ;	quantum/via.c:473: break;
      00AF27 02 B0 5F         [24] 1624 	ljmp	00171$
                                   1625 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AF2A                       1626 00154$:
                                   1627 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AF2A C0 07            [24] 1628 	push	ar7
      00AF2C C0 06            [24] 1629 	push	ar6
      00AF2E C0 05            [24] 1630 	push	ar5
      00AF30 C0 04            [24] 1631 	push	ar4
      00AF32 C0 03            [24] 1632 	push	ar3
      00AF34 12 87 9E         [24] 1633 	lcall	_dynamic_keymap_get_layer_count
      00AF37 AA 82            [24] 1634 	mov	r2, dpl
      00AF39 D0 03            [24] 1635 	pop	ar3
      00AF3B D0 04            [24] 1636 	pop	ar4
      00AF3D D0 05            [24] 1637 	pop	ar5
      00AF3F D0 06            [24] 1638 	pop	ar6
      00AF41 D0 07            [24] 1639 	pop	ar7
      00AF43 12 38 59         [24] 1640 	lcall	_ak820_outline_0127
      00AF46 EA               [12] 1641 	mov	a,r2
      00AF47 F0               [24] 1642 	movx	@dptr,a
                                   1643 ;	quantum/via.c:477: break;
      00AF48 02 B0 5F         [24] 1644 	ljmp	00171$
                                   1645 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AF4B                       1646 00155$:
                                   1647 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AF4B C0 03            [24] 1648 	push	ar3
      00AF4D 12 B0 6D         [24] 1649 	lcall	_ak820_outline_0004
      00AF50 89 40            [24] 1650 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AF52 8A 41            [24] 1651 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1652 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00AF54 12 48 7B         [24] 1653 	lcall	_ak820_outline_0016
      00AF57 FB               [12] 1654 	mov	r3,a
                                   1655 ;	quantum/via.c:482: if (size <= 28)
      00AF58 8B 3E            [24] 1656 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AF5A 75 3F 00         [24] 1657 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AF5D C3               [12] 1658 	clr	c
      00AF5E 74 1C            [12] 1659 	mov	a,#0x1c
      00AF60 9B               [12] 1660 	subb	a,r3
      00AF61 D0 03            [24] 1661 	pop	ar3
      00AF63 50 03            [24] 1662 	jnc	00568$
      00AF65 02 B0 5F         [24] 1663 	ljmp	00171$
      00AF68                       1664 00568$:
                                   1665 ;	free result
                                   1666 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AF68 12 B0 96         [24] 1667 	lcall	_ak820_outline_0073
      00AF6B 90 0B E8         [24] 1668 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AF6E E5 3E            [12] 1669 	mov	a,_raw_hid_receive_sloc3_1_0
      00AF70 F0               [24] 1670 	movx	@dptr,a
      00AF71 E5 3F            [12] 1671 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AF73 A3               [24] 1672 	inc	dptr
      00AF74 F0               [24] 1673 	movx	@dptr,a
      00AF75 90 0B EA         [24] 1674 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AF78 12 B0 A0         [24] 1675 	lcall	_ak820_outline_0089
      00AF7B 85 40 82         [24] 1676 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AF7E 85 41 83         [24] 1677 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AF81 C0 07            [24] 1678 	push	ar7
      00AF83 C0 06            [24] 1679 	push	ar6
      00AF85 C0 03            [24] 1680 	push	ar3
      00AF87 12 8D B8         [24] 1681 	lcall	_dynamic_keymap_get_buffer
      00AF8A D0 03            [24] 1682 	pop	ar3
      00AF8C D0 06            [24] 1683 	pop	ar6
      00AF8E D0 07            [24] 1684 	pop	ar7
                                   1685 ;	quantum/via.c:484: break;
      00AF90 02 B0 5F         [24] 1686 	ljmp	00171$
                                   1687 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00AF93                       1688 00158$:
                                   1689 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AF93 12 43 05         [24] 1690 	lcall	_ak820_outline_0098
      00AF96 FD               [12] 1691 	mov	r5,a
      00AF97 7C 00            [12] 1692 	mov	r4,#0x00
      00AF99 12 37 EB         [24] 1693 	lcall	_ak820_outline_0035
      00AF9C 7A 00            [12] 1694 	mov	r2,#0x00
      00AF9E 42 04            [12] 1695 	orl	ar4,a
      00AFA0 EA               [12] 1696 	mov	a,r2
      00AFA1 42 05            [12] 1697 	orl	ar5,a
      00AFA3 8C 40            [24] 1698 	mov	_raw_hid_receive_sloc4_1_0,r4
      00AFA5 8D 41            [24] 1699 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1700 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00AFA7 12 48 7B         [24] 1701 	lcall	_ak820_outline_0016
      00AFAA F9               [12] 1702 	mov	r1,a
      00AFAB 7A 00            [12] 1703 	mov	r2,#0x00
                                   1704 ;	quantum/via.c:489: if (size <= 28)
      00AFAD 89 00            [24] 1705 	mov	ar0,r1
      00AFAF E8               [12] 1706 	mov	a,r0
      00AFB0 24 E3            [12] 1707 	add	a,#0xff - 0x1c
      00AFB2 50 03            [24] 1708 	jnc	00569$
      00AFB4 02 B0 5F         [24] 1709 	ljmp	00171$
      00AFB7                       1710 00569$:
                                   1711 ;	free result
                                   1712 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00AFB7 C0 03            [24] 1713 	push	ar3
      00AFB9 74 04            [12] 1714 	mov	a,#0x04
      00AFBB 2E               [12] 1715 	add	a, r6
      00AFBC F8               [12] 1716 	mov	r0,a
      00AFBD E4               [12] 1717 	clr	a
      00AFBE 3F               [12] 1718 	addc	a, r7
      00AFBF FB               [12] 1719 	mov	r3,a
      00AFC0 7D 00            [12] 1720 	mov	r5,#0x00
      00AFC2 90 0B EF         [24] 1721 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00AFC5 E9               [12] 1722 	mov	a,r1
      00AFC6 F0               [24] 1723 	movx	@dptr,a
      00AFC7 EA               [12] 1724 	mov	a,r2
      00AFC8 A3               [24] 1725 	inc	dptr
      00AFC9 F0               [24] 1726 	movx	@dptr,a
      00AFCA 90 0B F1         [24] 1727 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00AFCD E8               [12] 1728 	mov	a,r0
      00AFCE 12 48 ED         [24] 1729 	lcall	_ak820_outline_0189
      00AFD1 ED               [12] 1730 	mov	a,r5
      00AFD2 A3               [24] 1731 	inc	dptr
      00AFD3 F0               [24] 1732 	movx	@dptr,a
      00AFD4 85 40 82         [24] 1733 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AFD7 85 41 83         [24] 1734 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AFDA C0 07            [24] 1735 	push	ar7
      00AFDC C0 06            [24] 1736 	push	ar6
      00AFDE C0 03            [24] 1737 	push	ar3
      00AFE0 12 8D F8         [24] 1738 	lcall	_dynamic_keymap_set_buffer
      00AFE3 D0 03            [24] 1739 	pop	ar3
      00AFE5 D0 06            [24] 1740 	pop	ar6
      00AFE7 D0 07            [24] 1741 	pop	ar7
                                   1742 ;	quantum/via.c:491: break;
      00AFE9 D0 03            [24] 1743 	pop	ar3
      00AFEB 02 B0 5F         [24] 1744 	ljmp	00171$
                                   1745 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AFEE                       1746 00161$:
                                   1747 ;	quantum/via.c:497: if (!vial_unlocked)
      00AFEE 90 0E E7         [24] 1748 	mov	dptr,#_vial_unlocked
      00AFF1 E0               [24] 1749 	movx	a,@dptr
      00AFF2 70 03            [24] 1750 	jnz	00570$
      00AFF4 02 B0 5F         [24] 1751 	ljmp	00171$
      00AFF7                       1752 00570$:
                                   1753 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AFF7 12 B0 B9         [24] 1754 	lcall	_ak820_outline_0153
      00AFFA 90 07 3B         [24] 1755 	mov	dptr,#_raw_hid_send_PARM_2
      00AFFD 12 B0 A9         [24] 1756 	lcall	_ak820_outline_0090
      00B000 C0 07            [24] 1757 	push	ar7
      00B002 C0 06            [24] 1758 	push	ar6
      00B004 C0 03            [24] 1759 	push	ar3
      00B006 12 4F F5         [24] 1760 	lcall	_raw_hid_send
      00B009 D0 03            [24] 1761 	pop	ar3
      00B00B D0 06            [24] 1762 	pop	ar6
      00B00D D0 07            [24] 1763 	pop	ar7
                                   1764 ;	quantum/via.c:503: wait_ms(100);
      00B00F 7D 64            [12] 1765 	mov	r5,#0x64
      00B011                       1766 00176$:
      00B011 ED               [12] 1767 	mov	a,r5
      00B012 60 09            [24] 1768 	jz	00166$
      00B014 90 00 01         [24] 1769 	mov	dptr,#0x0001
      00B017 12 5D 9F         [24] 1770 	lcall	_mDelaymS
      00B01A 1D               [12] 1771 	dec	r5
      00B01B 80 F4            [24] 1772 	sjmp	00176$
      00B01D                       1773 00166$:
                                   1774 ;	quantum/via.c:504: bootloader_jump();
      00B01D C0 07            [24] 1775 	push	ar7
      00B01F C0 06            [24] 1776 	push	ar6
      00B021 C0 03            [24] 1777 	push	ar3
      00B023 12 34 0E         [24] 1778 	lcall	_bootloader_jump
      00B026 D0 03            [24] 1779 	pop	ar3
      00B028 D0 06            [24] 1780 	pop	ar6
      00B02A D0 07            [24] 1781 	pop	ar7
                                   1782 ;	quantum/via.c:505: break;
                                   1783 ;	quantum/via.c:509: case id_vial_prefix: {
      00B02C 80 31            [24] 1784 	sjmp	00171$
      00B02E                       1785 00168$:
                                   1786 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B02E 12 B0 B9         [24] 1787 	lcall	_ak820_outline_0153
      00B031 90 0D 13         [24] 1788 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B034 12 B0 A9         [24] 1789 	lcall	_ak820_outline_0090
      00B037 C0 07            [24] 1790 	push	ar7
      00B039 C0 06            [24] 1791 	push	ar6
      00B03B C0 03            [24] 1792 	push	ar3
      00B03D 31 A6            [12] 1793 	acall	_vial_handle_cmd
      00B03F D0 03            [24] 1794 	pop	ar3
      00B041 D0 06            [24] 1795 	pop	ar6
      00B043 D0 07            [24] 1796 	pop	ar7
                                   1797 ;	quantum/via.c:511: break;
                                   1798 ;	quantum/via.c:514: default: {
      00B045 80 18            [24] 1799 	sjmp	00171$
      00B047                       1800 00169$:
                                   1801 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B047 12 B0 B9         [24] 1802 	lcall	_ak820_outline_0153
      00B04A 90 0D 01         [24] 1803 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B04D 12 B0 A9         [24] 1804 	lcall	_ak820_outline_0090
      00B050 C0 07            [24] 1805 	push	ar7
      00B052 C0 06            [24] 1806 	push	ar6
      00B054 C0 03            [24] 1807 	push	ar3
      00B056 12 AA D4         [24] 1808 	lcall	_raw_hid_receive_kb
      00B059 D0 03            [24] 1809 	pop	ar3
      00B05B D0 06            [24] 1810 	pop	ar6
      00B05D D0 07            [24] 1811 	pop	ar7
                                   1812 ;	quantum/via.c:521: skip:
      00B05F                       1813 00171$:
                                   1814 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B05F 7D 00            [12] 1815 	mov	r5,#0x00
      00B061 90 07 3B         [24] 1816 	mov	dptr,#_raw_hid_send_PARM_2
      00B064 EB               [12] 1817 	mov	a,r3
      00B065 12 42 F2         [24] 1818 	lcall	_ak820_outline_0066
      00B068 8D F0            [24] 1819 	mov	b, r5
                                   1820 ;	quantum/via.c:526: }
      00B06A 02 4F F5         [24] 1821 	ljmp	_raw_hid_send
                                   1822 	.area CSEG    (CODE)
                                   1823 	.area CONST   (CODE)
                                   1824 	.area XINIT   (CODE)
                                   1825 	.area CABS    (ABS,CODE)
                                   1826 
                                   1827 ; Experimental exact instruction outlining.
                                   1828 	.globl _ak820_outline_0001
                                   1829 	.globl _ak820_outline_0004
                                   1830 	.globl _ak820_outline_0010
                                   1831 	.globl _ak820_outline_0012
                                   1832 	.globl _ak820_outline_0014
                                   1833 	.globl _ak820_outline_0016
                                   1834 	.globl _ak820_outline_0017
                                   1835 	.globl _ak820_outline_0019
                                   1836 	.globl _ak820_outline_0023
                                   1837 	.globl _ak820_outline_0035
                                   1838 	.globl _ak820_outline_0037
                                   1839 	.globl _ak820_outline_0042
                                   1840 	.globl _ak820_outline_0044
                                   1841 	.globl _ak820_outline_0047
                                   1842 	.globl _ak820_outline_0050
                                   1843 	.globl _ak820_outline_0058
                                   1844 	.globl _ak820_outline_0066
                                   1845 	.globl _ak820_outline_0073
                                   1846 	.globl _ak820_outline_0089
                                   1847 	.globl _ak820_outline_0090
                                   1848 	.globl _ak820_outline_0094
                                   1849 	.globl _ak820_outline_0096
                                   1850 	.globl _ak820_outline_0098
                                   1851 	.globl _ak820_outline_0108
                                   1852 	.globl _ak820_outline_0109
                                   1853 	.globl _ak820_outline_0119
                                   1854 	.globl _ak820_outline_0122
                                   1855 	.globl _ak820_outline_0127
                                   1856 	.globl _ak820_outline_0150
                                   1857 	.globl _ak820_outline_0153
                                   1858 	.globl _ak820_outline_0155
                                   1859 	.globl _ak820_outline_0159
                                   1860 	.globl _ak820_outline_0160
                                   1861 	.globl _ak820_outline_0163
                                   1862 	.globl _ak820_outline_0164
                                   1863 	.globl _ak820_outline_0189
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0004
      00B06D                       1867 _ak820_outline_0004:
      00B06D 8C 82            [24] 1868 	mov	dpl,r4
      00B06F 8D 83            [24] 1869 	mov	dph,r5
      00B071 E0               [24] 1870 	movx	a,@dptr
      00B072 FA               [12] 1871 	mov	r2,a
      00B073 79 00            [12] 1872 	mov	r1,#0x00
      00B075 8E 82            [24] 1873 	mov	dpl,r6
      00B077 8F 83            [24] 1874 	mov	dph,r7
      00B079 A3               [24] 1875 	inc	dptr
      00B07A A3               [24] 1876 	inc	dptr
      00B07B E0               [24] 1877 	movx	a,@dptr
      00B07C 7B 00            [12] 1878 	mov	r3,#0x00
      00B07E 42 01            [12] 1879 	orl	ar1,a
      00B080 EB               [12] 1880 	mov	a,r3
      00B081 42 02            [12] 1881 	orl	ar2,a
      00B083 22               [24] 1882 	ret
                                   1883 
                                   1884 	.area CSEG (CODE)
                                   1885 ; function ak820_outline_0023
      00B084                       1886 _ak820_outline_0023:
      00B084 8E 82            [24] 1887 	mov	dpl,r6
      00B086 8F 83            [24] 1888 	mov	dph,r7
      00B088 A3               [24] 1889 	inc	dptr
      00B089 A3               [24] 1890 	inc	dptr
      00B08A A3               [24] 1891 	inc	dptr
      00B08B A3               [24] 1892 	inc	dptr
      00B08C 22               [24] 1893 	ret
                                   1894 
                                   1895 	.area CSEG (CODE)
                                   1896 ; function ak820_outline_0044
      00B08D                       1897 _ak820_outline_0044:
      00B08D EB               [12] 1898 	mov	a,r3
      00B08E F0               [24] 1899 	movx	@dptr,a
      00B08F 88 82            [24] 1900 	mov	dpl,r0
      00B091 89 83            [24] 1901 	mov	dph,r1
      00B093 8A F0            [24] 1902 	mov	b,r2
      00B095 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0073
      00B096                       1907 _ak820_outline_0073:
      00B096 74 04            [12] 1908 	mov	a,#0x04
      00B098 2E               [12] 1909 	add	a,r6
      00B099 F9               [12] 1910 	mov	r1,a
      00B09A E4               [12] 1911 	clr	a
      00B09B 3F               [12] 1912 	addc	a,r7
      00B09C F8               [12] 1913 	mov	r0,a
      00B09D 7A 00            [12] 1914 	mov	r2,#0x00
      00B09F 22               [24] 1915 	ret
                                   1916 
                                   1917 	.area CSEG (CODE)
                                   1918 ; function ak820_outline_0089
      00B0A0                       1919 _ak820_outline_0089:
      00B0A0 E9               [12] 1920 	mov	a,r1
      00B0A1 F0               [24] 1921 	movx	@dptr,a
      00B0A2 E8               [12] 1922 	mov	a,r0
      00B0A3 A3               [24] 1923 	inc	dptr
      00B0A4 F0               [24] 1924 	movx	@dptr,a
      00B0A5 EA               [12] 1925 	mov	a,r2
      00B0A6 A3               [24] 1926 	inc	dptr
      00B0A7 F0               [24] 1927 	movx	@dptr,a
      00B0A8 22               [24] 1928 	ret
                                   1929 
                                   1930 	.area CSEG (CODE)
                                   1931 ; function ak820_outline_0090
      00B0A9                       1932 _ak820_outline_0090:
      00B0A9 EB               [12] 1933 	mov	a,r3
      00B0AA F0               [24] 1934 	movx	@dptr,a
      00B0AB 8A 82            [24] 1935 	mov	dpl,r2
      00B0AD 8C 83            [24] 1936 	mov	dph,r4
      00B0AF 8D F0            [24] 1937 	mov	b,r5
      00B0B1 22               [24] 1938 	ret
                                   1939 
                                   1940 	.area CSEG (CODE)
                                   1941 ; function ak820_outline_0096
      00B0B2                       1942 _ak820_outline_0096:
      00B0B2 8E 00            [24] 1943 	mov	ar0,r6
      00B0B4 8F 01            [24] 1944 	mov	ar1,r7
      00B0B6 7A 00            [12] 1945 	mov	r2,#0x00
      00B0B8 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0153
      00B0B9                       1950 _ak820_outline_0153:
      00B0B9 8E 02            [24] 1951 	mov	ar2,r6
      00B0BB 8F 04            [24] 1952 	mov	ar4,r7
      00B0BD 7D 00            [12] 1953 	mov	r5,#0x00
      00B0BF 22               [24] 1954 	ret
