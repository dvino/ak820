                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_tap_dance_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_combo_PARM_2
                                    294 	.globl _dynamic_keymap_get_combo_PARM_2
                                    295 	.globl _dynamic_keymap_set_tap_dance_PARM_2
                                    296 	.globl _dynamic_keymap_get_tap_dance_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_tap_dance
                                    317 	.globl _dynamic_keymap_set_tap_dance
                                    318 	.globl _dynamic_keymap_get_combo
                                    319 	.globl _dynamic_keymap_set_combo
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000029                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        594 	.ds 2
      00002B                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        596 	.ds 1
      00002C                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        598 	.ds 1
      00002D                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        600 	.ds 2
      00002F                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        602 	.ds 2
      000031                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        604 	.ds 1
      000032                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000025                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B98                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B98                        634 	.ds 1
      000B99                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B99                        636 	.ds 1
      000B9A                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_371:
      000B9A                        638 	.ds 1
      000B9B                        639 _dynamic_keymap_get_keycode_PARM_2:
      000B9B                        640 	.ds 1
      000B9C                        641 _dynamic_keymap_get_keycode_PARM_3:
      000B9C                        642 	.ds 1
      000B9D                        643 _dynamic_keymap_get_keycode_layer_10000_373:
      000B9D                        644 	.ds 1
      000B9E                        645 _dynamic_keymap_set_keycode_PARM_2:
      000B9E                        646 	.ds 1
      000B9F                        647 _dynamic_keymap_set_keycode_PARM_3:
      000B9F                        648 	.ds 1
      000BA0                        649 _dynamic_keymap_set_keycode_PARM_4:
      000BA0                        650 	.ds 2
      000BA2                        651 _dynamic_keymap_set_keycode_layer_10000_377:
      000BA2                        652 	.ds 1
      000BA3                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000BA3                        654 	.ds 1
      000BA4                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_381:
      000BA4                        656 	.ds 1
      000BA5                        657 _dynamic_keymap_get_encoder_PARM_2:
      000BA5                        658 	.ds 1
      000BA6                        659 _dynamic_keymap_get_encoder_PARM_3:
      000BA6                        660 	.ds 1
      000BA7                        661 _dynamic_keymap_get_encoder_layer_10000_383:
      000BA7                        662 	.ds 1
      000BA8                        663 _dynamic_keymap_set_encoder_PARM_2:
      000BA8                        664 	.ds 1
      000BA9                        665 _dynamic_keymap_set_encoder_PARM_3:
      000BA9                        666 	.ds 1
      000BAA                        667 _dynamic_keymap_set_encoder_PARM_4:
      000BAA                        668 	.ds 2
      000BAC                        669 _dynamic_keymap_set_encoder_layer_10000_387:
      000BAC                        670 	.ds 1
      000BAD                        671 _dynamic_keymap_get_tap_dance_PARM_2:
      000BAD                        672 	.ds 3
      000BB0                        673 _dynamic_keymap_get_tap_dance_index_10000_391:
      000BB0                        674 	.ds 1
      000BB1                        675 _dynamic_keymap_set_tap_dance_PARM_2:
      000BB1                        676 	.ds 3
      000BB4                        677 _dynamic_keymap_set_tap_dance_index_10000_395:
      000BB4                        678 	.ds 1
      000BB5                        679 _dynamic_keymap_get_combo_PARM_2:
      000BB5                        680 	.ds 3
      000BB8                        681 _dynamic_keymap_get_combo_index_10000_398:
      000BB8                        682 	.ds 1
      000BB9                        683 _dynamic_keymap_set_combo_PARM_2:
      000BB9                        684 	.ds 3
      000BBC                        685 _dynamic_keymap_set_combo_index_10000_404:
      000BBC                        686 	.ds 1
      000BBD                        687 _dynamic_keymap_set_combo_stored_10002_409:
      000BBD                        688 	.ds 10
      000BC7                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_412:
      000BC7                        690 	.ds 1
      000BC8                        691 _dynamic_keymap_reset_td_10001_421:
      000BC8                        692 	.ds 10
      000BD2                        693 _dynamic_keymap_reset_combo_10002_424:
      000BD2                        694 	.ds 10
      000BDC                        695 _ak820_dynamic_read_buffer_PARM_2:
      000BDC                        696 	.ds 2
      000BDE                        697 _ak820_dynamic_read_buffer_PARM_3:
      000BDE                        698 	.ds 2
      000BE0                        699 _ak820_dynamic_read_buffer_PARM_4:
      000BE0                        700 	.ds 2
      000BE2                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BE2                        702 	.ds 3
      000BE5                        703 _ak820_dynamic_read_buffer_base_10000_426:
      000BE5                        704 	.ds 2
      000BE7                        705 _ak820_dynamic_read_buffer_available_10000_427:
      000BE7                        706 	.ds 1
      000BE8                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BE8                        708 	.ds 2
      000BEA                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BEA                        710 	.ds 3
      000BED                        711 _dynamic_keymap_get_buffer_offset_10000_433:
      000BED                        712 	.ds 2
      000BEF                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BEF                        714 	.ds 2
      000BF1                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BF1                        716 	.ds 3
      000BF4                        717 _dynamic_keymap_set_buffer_offset_10000_435:
      000BF4                        718 	.ds 2
      000BF6                        719 _dynamic_keymap_set_buffer_chk_offset_30001_442:
      000BF6                        720 	.ds 1
      000BF7                        721 _dynamic_keymap_set_buffer_chk_sz_30001_442:
      000BF7                        722 	.ds 1
      000BF8                        723 _dynamic_keymap_set_buffer_i_40001_449:
      000BF8                        724 	.ds 1
      000BF9                        725 _keycode_at_keymap_location_PARM_2:
      000BF9                        726 	.ds 1
      000BFA                        727 _keycode_at_keymap_location_PARM_3:
      000BFA                        728 	.ds 1
      000BFB                        729 _keycode_at_keymap_location_layer_num_10000_453:
      000BFB                        730 	.ds 1
      000BFC                        731 _keycode_at_encodermap_location_PARM_2:
      000BFC                        732 	.ds 1
      000BFD                        733 _keycode_at_encodermap_location_PARM_3:
      000BFD                        734 	.ds 1
      000BFE                        735 _keycode_at_encodermap_location_layer_num_10000_457:
      000BFE                        736 	.ds 1
      000BFF                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000BFF                        738 	.ds 2
      000C01                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000C01                        740 	.ds 3
      000C04                        741 _dynamic_keymap_macro_get_buffer_offset_10000_465:
      000C04                        742 	.ds 2
      000C06                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000C06                        744 	.ds 2
      000C08                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000C08                        746 	.ds 3
      000C0B                        747 _dynamic_keymap_macro_set_buffer_offset_10000_467:
      000C0B                        748 	.ds 2
      000C0D                        749 _decode_keycode_kc_10000_471:
      000C0D                        750 	.ds 2
      000C0F                        751 _dynamic_keymap_macro_send_id_10000_474:
      000C0F                        752 	.ds 1
      000C10                        753 _dynamic_keymap_macro_send_sending_10000_475:
      000C10                        754 	.ds 1
      000C11                        755 _dynamic_keymap_macro_send_p_10001_480:
      000C11                        756 	.ds 2
      000C13                        757 _dynamic_keymap_macro_send_data_10003_487:
      000C13                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      00879E                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00879E 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      0087A1 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_371'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      0087A2                        826 _dynamic_keymap_key_to_eeprom_address:
      0087A2 E5 82            [12]  827 	mov	a,dpl
      0087A4 90 0B 9A         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_371
      0087A7 F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0087A8 E0               [24]  831 	movx	a,@dptr
      0087A9 FF               [12]  832 	mov	r7,a
      0087AA 7E 00            [12]  833 	mov	r6,#0x00
      0087AC 74 40            [12]  834 	mov	a,#0x40
      0087AE 2E               [12]  835 	add	a, r6
      0087AF FE               [12]  836 	mov	r6,a
      0087B0 E4               [12]  837 	clr	a
      0087B1 3F               [12]  838 	addc	a, r7
      0087B2 FF               [12]  839 	mov	r7,a
      0087B3 7D 00            [12]  840 	mov	r5,#0x00
      0087B5 90 0B 98         [24]  841 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0087B8 E0               [24]  842 	movx	a,@dptr
      0087B9 75 F0 10         [24]  843 	mov	b,#0x10
      0087BC A4               [48]  844 	mul	ab
      0087BD 2E               [12]  845 	add	a, r6
      0087BE FE               [12]  846 	mov	r6,a
      0087BF EF               [12]  847 	mov	a,r7
      0087C0 35 F0            [12]  848 	addc	a, b
      0087C2 FF               [12]  849 	mov	r7,a
      0087C3 90 0B 99         [24]  850 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0087C6 E0               [24]  851 	movx	a,@dptr
      0087C7 7C 00            [12]  852 	mov	r4,#0x00
      0087C9 25 E0            [12]  853 	add	a,acc
      0087CB FB               [12]  854 	mov	r3,a
      0087CC EC               [12]  855 	mov	a,r4
      0087CD 33               [12]  856 	rlc	a
      0087CE FC               [12]  857 	mov	r4,a
      0087CF EB               [12]  858 	mov	a,r3
      0087D0 2E               [12]  859 	add	a, r6
      0087D1 FE               [12]  860 	mov	r6,a
      0087D2 EC               [12]  861 	mov	a,r4
      0087D3 3F               [12]  862 	addc	a, r7
      0087D4 FF               [12]  863 	mov	r7,a
      0087D5 12 43 17         [24]  864 	lcall	_ak820_outline_0119
      0087D8 8D F0            [24]  865 	mov	b, r5
                                    866 ;	quantum/dynamic_keymap.c:206: }
      0087DA 22               [24]  867 	ret
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    870 ;------------------------------------------------------------
                                    871 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    872 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    873 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_373'
                                    874 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_376'
                                    875 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_376'
                                    876 ;------------------------------------------------------------
                                    877 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function dynamic_keymap_get_keycode
                                    880 ;	-----------------------------------------
      0087DB                        881 _dynamic_keymap_get_keycode:
      0087DB E5 82            [12]  882 	mov	a,dpl
      0087DD 90 0B 9D         [24]  883 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_373
      0087E0 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0087E1 E0               [24]  886 	movx	a,@dptr
      0087E2 FF               [12]  887 	mov	r7,a
      0087E3 BF 06 00         [24]  888 	cjne	r7,#0x06,00121$
      0087E6                        889 00121$:
      0087E6 50 14            [24]  890 	jnc	00101$
      0087E8 90 0B 9B         [24]  891 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0087EB E0               [24]  892 	movx	a,@dptr
      0087EC FE               [12]  893 	mov	r6,a
      0087ED BE 10 00         [24]  894 	cjne	r6,#0x10,00123$
      0087F0                        895 00123$:
      0087F0 50 0A            [24]  896 	jnc	00101$
      0087F2 90 0B 9C         [24]  897 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0087F5 E0               [24]  898 	movx	a,@dptr
      0087F6 FD               [12]  899 	mov	r5,a
      0087F7 BD 08 00         [24]  900 	cjne	r5,#0x08,00125$
      0087FA                        901 00125$:
      0087FA 40 04            [24]  902 	jc	00102$
      0087FC                        903 00101$:
      0087FC 90 00 00         [24]  904 	mov	dptr,#0x0000
      0087FF 22               [24]  905 	ret
      008800                        906 00102$:
                                    907 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008800 12 93 A2         [24]  908 	lcall	_ak820_outline_0101
      008803 12 87 A2         [24]  909 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    910 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008806 12 93 B6         [24]  911 	lcall	_ak820_outline_0117
      008809 12 40 2F         [24]  912 	lcall	_eeprom_read_byte
      00880C AB 82            [24]  913 	mov	r3,dpl
      00880E 7C 00            [12]  914 	mov	r4,#0x00
                                    915 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008810 0D               [12]  916 	inc	r5
      008811 BD 00 01         [24]  917 	cjne	r5,#0x00,00127$
      008814 0E               [12]  918 	inc	r6
      008815                        919 00127$:
      008815 12 53 F9         [24]  920 	lcall	_ak820_outline_0050
      008818 12 40 2F         [24]  921 	lcall	_eeprom_read_byte
      00881B AF 82            [24]  922 	mov	r7, dpl
      00881D 7E 00            [12]  923 	mov	r6,#0x00
      00881F EF               [12]  924 	mov	a,r7
      008820 42 04            [12]  925 	orl	ar4,a
      008822 EE               [12]  926 	mov	a,r6
      008823 42 03            [12]  927 	orl	ar3,a
                                    928 ;	quantum/dynamic_keymap.c:214: return keycode;
      008825 12 43 4D         [24]  929 	lcall	_ak820_outline_0185
                                    930 ;	quantum/dynamic_keymap.c:215: }
      008828 22               [24]  931 	ret
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    934 ;------------------------------------------------------------
                                    935 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    936 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    937 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    938 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_377'
                                    939 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_380'
                                    940 ;------------------------------------------------------------
                                    941 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    942 ;	-----------------------------------------
                                    943 ;	 function dynamic_keymap_set_keycode
                                    944 ;	-----------------------------------------
      008829                        945 _dynamic_keymap_set_keycode:
      008829 E5 82            [12]  946 	mov	a,dpl
      00882B 90 0B A2         [24]  947 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_377
      00882E F0               [24]  948 	movx	@dptr,a
                                    949 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00882F E0               [24]  950 	movx	a,@dptr
      008830 FF               [12]  951 	mov	r7,a
      008831 BF 06 00         [24]  952 	cjne	r7,#0x06,00121$
      008834                        953 00121$:
      008834 50 14            [24]  954 	jnc	00101$
      008836 90 0B 9E         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008839 E0               [24]  956 	movx	a,@dptr
      00883A FE               [12]  957 	mov	r6,a
      00883B BE 10 00         [24]  958 	cjne	r6,#0x10,00123$
      00883E                        959 00123$:
      00883E 50 0A            [24]  960 	jnc	00101$
      008840 90 0B 9F         [24]  961 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008843 E0               [24]  962 	movx	a,@dptr
      008844 FD               [12]  963 	mov	r5,a
      008845 BD 08 00         [24]  964 	cjne	r5,#0x08,00125$
      008848                        965 00125$:
      008848 40 01            [24]  966 	jc	00102$
      00884A                        967 00101$:
      00884A 22               [24]  968 	ret
      00884B                        969 00102$:
                                    970 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00884B 12 93 A2         [24]  971 	lcall	_ak820_outline_0101
      00884E 12 87 A2         [24]  972 	lcall	_dynamic_keymap_key_to_eeprom_address
      008851 12 93 B6         [24]  973 	lcall	_ak820_outline_0117
                                    974 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008854 90 0B A0         [24]  975 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008857 E0               [24]  976 	movx	a,@dptr
      008858 FB               [12]  977 	mov	r3,a
      008859 A3               [24]  978 	inc	dptr
      00885A E0               [24]  979 	movx	a,@dptr
      00885B 90 07 61         [24]  980 	mov	dptr,#_eeprom_update_byte_PARM_2
      00885E F0               [24]  981 	movx	@dptr,a
      00885F 12 53 F9         [24]  982 	lcall	_ak820_outline_0050
      008862 12 52 E1         [24]  983 	lcall	_eeprom_update_byte
                                    984 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008865 0D               [12]  985 	inc	r5
      008866 BD 00 01         [24]  986 	cjne	r5,#0x00,00127$
      008869 0E               [12]  987 	inc	r6
      00886A                        988 00127$:
      00886A 90 07 61         [24]  989 	mov	dptr,#_eeprom_update_byte_PARM_2
      00886D EB               [12]  990 	mov	a,r3
      00886E F0               [24]  991 	movx	@dptr,a
      00886F 12 53 F9         [24]  992 	lcall	_ak820_outline_0050
                                    993 ;	quantum/dynamic_keymap.c:223: }
      008872 02 52 E1         [24]  994 	ljmp	_eeprom_update_byte
                                    995 ;------------------------------------------------------------
                                    996 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    997 ;------------------------------------------------------------
                                    998 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    999 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                   1004 ;	-----------------------------------------
      008875                       1005 _dynamic_keymap_encoder_to_eeprom_address:
      008875 E5 82            [12] 1006 	mov	a,dpl
      008877 90 0B A4         [24] 1007 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381
      00887A F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00887B E0               [24] 1010 	movx	a,@dptr
      00887C 12 38 82         [24] 1011 	lcall	_ak820_outline_0191
      00887F 24 40            [12] 1012 	add	a, #0x40
      008881 FD               [12] 1013 	mov	r5,a
      008882 74 06            [12] 1014 	mov	a,#0x06
      008884 35 F0            [12] 1015 	addc	a, b
      008886 FE               [12] 1016 	mov	r6,a
      008887 7F 00            [12] 1017 	mov	r7,#0x00
      008889 90 0B A3         [24] 1018 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00888C E0               [24] 1019 	movx	a,@dptr
      00888D 12 38 82         [24] 1020 	lcall	_ak820_outline_0191
      008890 2D               [12] 1021 	add	a, r5
      008891 FD               [12] 1022 	mov	r5,a
      008892 EE               [12] 1023 	mov	a,r6
      008893 35 F0            [12] 1024 	addc	a, b
      008895 FE               [12] 1025 	mov	r6,a
      008896 12 53 F9         [24] 1026 	lcall	_ak820_outline_0050
                                   1027 ;	quantum/dynamic_keymap.c:228: }
      008899 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1031 ;------------------------------------------------------------
                                   1032 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1033 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1034 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_383'
                                   1035 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_386'
                                   1036 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_386'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function dynamic_keymap_get_encoder
                                   1041 ;	-----------------------------------------
      00889A                       1042 _dynamic_keymap_get_encoder:
      00889A E5 82            [12] 1043 	mov	a,dpl
      00889C 90 0B A7         [24] 1044 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_383
      00889F F0               [24] 1045 	movx	@dptr,a
                                   1046 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0088A0 E0               [24] 1047 	movx	a,@dptr
      0088A1 FF               [12] 1048 	mov	r7,a
      0088A2 BF 06 00         [24] 1049 	cjne	r7,#0x06,00131$
      0088A5                       1050 00131$:
      0088A5 50 0A            [24] 1051 	jnc	00101$
      0088A7 90 0B A5         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0088AA E0               [24] 1053 	movx	a,@dptr
      0088AB FE               [12] 1054 	mov	r6,a
      0088AC BE 01 00         [24] 1055 	cjne	r6,#0x01,00133$
      0088AF                       1056 00133$:
      0088AF 40 04            [24] 1057 	jc	00102$
      0088B1                       1058 00101$:
      0088B1 90 00 00         [24] 1059 	mov	dptr,#0x0000
      0088B4 22               [24] 1060 	ret
      0088B5                       1061 00102$:
                                   1062 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0088B5 90 0B A3         [24] 1063 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0088B8 E4               [12] 1064 	clr	a
      0088B9 F0               [24] 1065 	movx	@dptr,a
      0088BA 8F 82            [24] 1066 	mov	dpl, r7
      0088BC 11 75            [12] 1067 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0088BE 12 93 B6         [24] 1068 	lcall	_ak820_outline_0117
                                   1069 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0088C1 90 0B A6         [24] 1070 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0088C4 E0               [24] 1071 	movx	a,@dptr
      0088C5 FC               [12] 1072 	mov	r4,a
      0088C6 E0               [24] 1073 	movx	a,@dptr
      0088C7 60 04            [24] 1074 	jz	00106$
      0088C9 7B 00            [12] 1075 	mov	r3,#0x00
      0088CB 80 02            [24] 1076 	sjmp	00107$
      0088CD                       1077 00106$:
      0088CD 7B 02            [12] 1078 	mov	r3,#0x02
      0088CF                       1079 00107$:
      0088CF EB               [12] 1080 	mov	a,r3
      0088D0 12 93 60         [24] 1081 	lcall	_ak820_outline_0026
      0088D3 12 40 2F         [24] 1082 	lcall	_eeprom_read_byte
      0088D6 AA 82            [24] 1083 	mov	r2,dpl
      0088D8 7B 00            [12] 1084 	mov	r3,#0x00
                                   1085 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0088DA EC               [12] 1086 	mov	a,r4
      0088DB 60 04            [24] 1087 	jz	00108$
      0088DD 7C 00            [12] 1088 	mov	r4,#0x00
      0088DF 80 02            [24] 1089 	sjmp	00109$
      0088E1                       1090 00108$:
      0088E1 7C 02            [12] 1091 	mov	r4,#0x02
      0088E3                       1092 00109$:
      0088E3 EC               [12] 1093 	mov	a,r4
      0088E4 12 38 77         [24] 1094 	lcall	_ak820_outline_0163
      0088E7 0D               [12] 1095 	inc	r5
      0088E8 BD 00 01         [24] 1096 	cjne	r5,#0x00,00137$
      0088EB 0E               [12] 1097 	inc	r6
      0088EC                       1098 00137$:
      0088EC 12 53 F9         [24] 1099 	lcall	_ak820_outline_0050
      0088EF 12 40 2F         [24] 1100 	lcall	_eeprom_read_byte
      0088F2 AF 82            [24] 1101 	mov	r7, dpl
      0088F4 7E 00            [12] 1102 	mov	r6,#0x00
      0088F6 EF               [12] 1103 	mov	a,r7
      0088F7 42 03            [12] 1104 	orl	ar3,a
      0088F9 EE               [12] 1105 	mov	a,r6
      0088FA 42 02            [12] 1106 	orl	ar2,a
                                   1107 ;	quantum/dynamic_keymap.c:236: return keycode;
      0088FC 8B 82            [24] 1108 	mov	dpl, r3
      0088FE 8A 83            [24] 1109 	mov	dph, r2
                                   1110 ;	quantum/dynamic_keymap.c:237: }
      008900 22               [24] 1111 	ret
                                   1112 ;------------------------------------------------------------
                                   1113 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1114 ;------------------------------------------------------------
                                   1115 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1116 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1117 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1118 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1119 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_387'
                                   1120 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_390'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function dynamic_keymap_set_encoder
                                   1125 ;	-----------------------------------------
      008901                       1126 _dynamic_keymap_set_encoder:
      008901 E5 82            [12] 1127 	mov	a,dpl
      008903 90 0B AC         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_387
      008906 F0               [24] 1129 	movx	@dptr,a
                                   1130 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008907 E0               [24] 1131 	movx	a,@dptr
      008908 FF               [12] 1132 	mov	r7,a
      008909 BF 06 00         [24] 1133 	cjne	r7,#0x06,00131$
      00890C                       1134 00131$:
      00890C 50 0A            [24] 1135 	jnc	00101$
      00890E 90 0B A8         [24] 1136 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008911 E0               [24] 1137 	movx	a,@dptr
      008912 FE               [12] 1138 	mov	r6,a
      008913 BE 01 00         [24] 1139 	cjne	r6,#0x01,00133$
      008916                       1140 00133$:
      008916 40 01            [24] 1141 	jc	00102$
      008918                       1142 00101$:
      008918 22               [24] 1143 	ret
      008919                       1144 00102$:
                                   1145 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008919 90 0B A3         [24] 1146 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00891C E4               [12] 1147 	clr	a
      00891D F0               [24] 1148 	movx	@dptr,a
      00891E 8F 82            [24] 1149 	mov	dpl, r7
      008920 11 75            [12] 1150 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008922 12 93 B6         [24] 1151 	lcall	_ak820_outline_0117
                                   1152 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008925 90 0B A9         [24] 1153 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008928 E0               [24] 1154 	movx	a,@dptr
      008929 FC               [12] 1155 	mov	r4,a
      00892A E0               [24] 1156 	movx	a,@dptr
      00892B 60 04            [24] 1157 	jz	00106$
      00892D 7B 00            [12] 1158 	mov	r3,#0x00
      00892F 80 02            [24] 1159 	sjmp	00107$
      008931                       1160 00106$:
      008931 7B 02            [12] 1161 	mov	r3,#0x02
      008933                       1162 00107$:
      008933 EB               [12] 1163 	mov	a,r3
      008934 12 93 C8         [24] 1164 	lcall	_ak820_outline_0139
      008937 8F 03            [24] 1165 	mov	ar3,r7
      008939 90 0B AA         [24] 1166 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00893C E0               [24] 1167 	movx	a,@dptr
      00893D F5 29            [12] 1168 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      00893F A3               [24] 1169 	inc	dptr
      008940 E0               [24] 1170 	movx	a,@dptr
      008941 F5 2A            [12] 1171 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008943 90 07 61         [24] 1172 	mov	dptr,#_eeprom_update_byte_PARM_2
      008946 F0               [24] 1173 	movx	@dptr,a
      008947 12 43 32         [24] 1174 	lcall	_ak820_outline_0151
      00894A 8B F0            [24] 1175 	mov	b, r3
      00894C 12 52 E1         [24] 1176 	lcall	_eeprom_update_byte
                                   1177 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      00894F EC               [12] 1178 	mov	a,r4
      008950 60 04            [24] 1179 	jz	00108$
      008952 7C 00            [12] 1180 	mov	r4,#0x00
      008954 80 02            [24] 1181 	sjmp	00109$
      008956                       1182 00108$:
      008956 7C 02            [12] 1183 	mov	r4,#0x02
      008958                       1184 00109$:
      008958 EC               [12] 1185 	mov	a,r4
      008959 12 38 77         [24] 1186 	lcall	_ak820_outline_0163
      00895C 0D               [12] 1187 	inc	r5
      00895D BD 00 01         [24] 1188 	cjne	r5,#0x00,00137$
      008960 0E               [12] 1189 	inc	r6
      008961                       1190 00137$:
      008961 90 07 61         [24] 1191 	mov	dptr,#_eeprom_update_byte_PARM_2
      008964 E5 29            [12] 1192 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008966 F0               [24] 1193 	movx	@dptr,a
      008967 12 53 F9         [24] 1194 	lcall	_ak820_outline_0050
                                   1195 ;	quantum/dynamic_keymap.c:245: }
      00896A 02 52 E1         [24] 1196 	ljmp	_eeprom_update_byte
                                   1197 ;------------------------------------------------------------
                                   1198 ;Allocation info for local variables in function 'dynamic_keymap_get_tap_dance'
                                   1199 ;------------------------------------------------------------
                                   1200 ;buffer        Allocated with name '_dynamic_keymap_get_tap_dance_PARM_2'
                                   1201 ;index         Allocated with name '_dynamic_keymap_get_tap_dance_index_10000_391'
                                   1202 ;entry         Allocated with name '_dynamic_keymap_get_tap_dance_entry_10000_392'
                                   1203 ;------------------------------------------------------------
                                   1204 ;	quantum/dynamic_keymap.c:268: int dynamic_keymap_get_tap_dance(uint8_t index, vial_tap_dance_entry_t *buffer) {
                                   1205 ;	-----------------------------------------
                                   1206 ;	 function dynamic_keymap_get_tap_dance
                                   1207 ;	-----------------------------------------
      00896D                       1208 _dynamic_keymap_get_tap_dance:
      00896D E5 82            [12] 1209 	mov	a,dpl
      00896F 90 0B B0         [24] 1210 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      008972 F0               [24] 1211 	movx	@dptr,a
                                   1212 ;	quantum/dynamic_keymap.c:269: vial_tap_dance_entry_t AK820_STATE_MEM *entry = (vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      008973 90 0B AD         [24] 1213 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      008976 12 37 FB         [24] 1214 	lcall	_ak820_outline_0058
                                   1215 ;	quantum/dynamic_keymap.c:270: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      008979 90 0B B0         [24] 1216 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      00897C E0               [24] 1217 	movx	a,@dptr
      00897D FD               [12] 1218 	mov	r5,a
      00897E BD 08 00         [24] 1219 	cjne	r5,#0x08,00130$
      008981                       1220 00130$:
      008981 40 04            [24] 1221 	jc	00102$
      008983 90 FF FF         [24] 1222 	mov	dptr,#0xffff
      008986 22               [24] 1223 	ret
      008987                       1224 00102$:
                                   1225 ;	quantum/dynamic_keymap.c:271: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008987 8E 03            [24] 1226 	mov	ar3,r6
      008989 8F 04            [24] 1227 	mov	ar4,r7
      00898B BD 06 00         [24] 1228 	cjne	r5,#0x06,00132$
      00898E                       1229 00132$:
      00898E 50 0C            [24] 1230 	jnc	00107$
      008990 8D 02            [24] 1231 	mov	ar2,r5
      008992 EA               [12] 1232 	mov	a,r2
      008993 75 F0 0A         [24] 1233 	mov	b,#0x0a
      008996 A4               [48] 1234 	mul	ab
      008997 F9               [12] 1235 	mov	r1,a
      008998 7A 00            [12] 1236 	mov	r2,#0x00
      00899A 80 11            [24] 1237 	sjmp	00108$
      00899C                       1238 00107$:
      00899C ED               [12] 1239 	mov	a,r5
      00899D 24 FA            [12] 1240 	add	a,#0xfa
      00899F 75 F0 0A         [24] 1241 	mov	b,#0x0a
      0089A2 A4               [48] 1242 	mul	ab
      0089A3 F8               [12] 1243 	mov	r0,a
      0089A4 7D 00            [12] 1244 	mov	r5,#0x00
      0089A6 74 40            [12] 1245 	mov	a,#0x40
      0089A8 28               [12] 1246 	add	a, r0
      0089A9 F9               [12] 1247 	mov	r1,a
      0089AA E4               [12] 1248 	clr	a
      0089AB 3D               [12] 1249 	addc	a, r5
      0089AC FA               [12] 1250 	mov	r2,a
      0089AD                       1251 00108$:
      0089AD 74 C0            [12] 1252 	mov	a,#0xc0
      0089AF 29               [12] 1253 	add	a, r1
      0089B0 F9               [12] 1254 	mov	r1,a
      0089B1 74 06            [12] 1255 	mov	a,#0x06
      0089B3 3A               [12] 1256 	addc	a, r2
      0089B4 FA               [12] 1257 	mov	r2,a
      0089B5 90 05 81         [24] 1258 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0089B8 E9               [12] 1259 	mov	a,r1
      0089B9 F0               [24] 1260 	movx	@dptr,a
      0089BA EA               [12] 1261 	mov	a,r2
      0089BB 12 38 18         [24] 1262 	lcall	_ak820_outline_0075
      0089BE 90 05 84         [24] 1263 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0089C1 12 93 AF         [24] 1264 	lcall	_ak820_outline_0113
      0089C4 12 33 FC         [24] 1265 	lcall	_ak820_outline_0123
      0089C7 C0 07            [24] 1266 	push	ar7
      0089C9 C0 06            [24] 1267 	push	ar6
      0089CB 12 40 6A         [24] 1268 	lcall	_ak820_eeprom_read_block_xdata
      0089CE D0 06            [24] 1269 	pop	ar6
      0089D0 D0 07            [24] 1270 	pop	ar7
                                   1271 ;	quantum/dynamic_keymap.c:272: if (!ak820_tap_dance_valid(entry)) memset(entry, 0, sizeof(*entry));
      0089D2 12 43 17         [24] 1272 	lcall	_ak820_outline_0119
      0089D5 C0 07            [24] 1273 	push	ar7
      0089D7 C0 06            [24] 1274 	push	ar6
      0089D9 12 43 52         [24] 1275 	lcall	_ak820_tap_dance_valid
      0089DC E5 82            [12] 1276 	mov	a, dpl
      0089DE D0 06            [24] 1277 	pop	ar6
      0089E0 D0 07            [24] 1278 	pop	ar7
      0089E2 70 07            [24] 1279 	jnz	00104$
      0089E4 FD               [12] 1280 	mov	r5,a
      0089E5 12 93 6E         [24] 1281 	lcall	_ak820_outline_0043
      0089E8 12 BD 48         [24] 1282 	lcall	_memset
      0089EB                       1283 00104$:
                                   1284 ;	quantum/dynamic_keymap.c:273: return 0;
      0089EB 90 00 00         [24] 1285 	mov	dptr,#0x0000
                                   1286 ;	quantum/dynamic_keymap.c:274: }
      0089EE 22               [24] 1287 	ret
                                   1288 ;------------------------------------------------------------
                                   1289 ;Allocation info for local variables in function 'dynamic_keymap_set_tap_dance'
                                   1290 ;------------------------------------------------------------
                                   1291 ;buffer        Allocated with name '_dynamic_keymap_set_tap_dance_PARM_2'
                                   1292 ;index         Allocated with name '_dynamic_keymap_set_tap_dance_index_10000_395'
                                   1293 ;entry         Allocated with name '_dynamic_keymap_set_tap_dance_entry_10000_396'
                                   1294 ;------------------------------------------------------------
                                   1295 ;	quantum/dynamic_keymap.c:275: int dynamic_keymap_set_tap_dance(uint8_t index, const vial_tap_dance_entry_t *buffer) {
                                   1296 ;	-----------------------------------------
                                   1297 ;	 function dynamic_keymap_set_tap_dance
                                   1298 ;	-----------------------------------------
      0089EF                       1299 _dynamic_keymap_set_tap_dance:
      0089EF E5 82            [12] 1300 	mov	a,dpl
      0089F1 90 0B B4         [24] 1301 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      0089F4 F0               [24] 1302 	movx	@dptr,a
                                   1303 ;	quantum/dynamic_keymap.c:276: const vial_tap_dance_entry_t AK820_STATE_MEM *entry = (const vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      0089F5 90 0B B1         [24] 1304 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      0089F8 12 37 FB         [24] 1305 	lcall	_ak820_outline_0058
                                   1306 ;	quantum/dynamic_keymap.c:277: if (index >= AK820_EXTENSION_ENTRIES || !ak820_tap_dance_valid(entry) || !ak820_nvm_ok()) return -1;
      0089FB 90 0B B4         [24] 1307 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      0089FE E0               [24] 1308 	movx	a,@dptr
      0089FF FD               [12] 1309 	mov	r5,a
      008A00 BD 08 00         [24] 1310 	cjne	r5,#0x08,00139$
      008A03                       1311 00139$:
      008A03 50 1D            [24] 1312 	jnc	00101$
      008A05 12 43 17         [24] 1313 	lcall	_ak820_outline_0119
      008A08 C0 07            [24] 1314 	push	ar7
      008A0A C0 06            [24] 1315 	push	ar6
      008A0C C0 05            [24] 1316 	push	ar5
      008A0E 12 43 52         [24] 1317 	lcall	_ak820_tap_dance_valid
      008A11 E5 82            [12] 1318 	mov	a, dpl
      008A13 D0 05            [24] 1319 	pop	ar5
      008A15 D0 06            [24] 1320 	pop	ar6
      008A17 D0 07            [24] 1321 	pop	ar7
      008A19 60 07            [24] 1322 	jz	00101$
      008A1B 12 3D D5         [24] 1323 	lcall	_ak820_nvm_ok
      008A1E E5 82            [12] 1324 	mov	a, dpl
      008A20 70 04            [24] 1325 	jnz	00102$
      008A22                       1326 00101$:
      008A22 90 FF FF         [24] 1327 	mov	dptr,#0xffff
      008A25 22               [24] 1328 	ret
      008A26                       1329 00102$:
                                   1330 ;	quantum/dynamic_keymap.c:278: clear_keyboard();
      008A26 C0 07            [24] 1331 	push	ar7
      008A28 C0 06            [24] 1332 	push	ar6
      008A2A C0 05            [24] 1333 	push	ar5
      008A2C 12 7A ED         [24] 1334 	lcall	_clear_keyboard
      008A2F D0 05            [24] 1335 	pop	ar5
      008A31 D0 06            [24] 1336 	pop	ar6
      008A33 D0 07            [24] 1337 	pop	ar7
                                   1338 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008A35 BD 06 00         [24] 1339 	cjne	r5,#0x06,00143$
      008A38                       1340 00143$:
      008A38 50 0C            [24] 1341 	jnc	00107$
      008A3A 8D 04            [24] 1342 	mov	ar4,r5
      008A3C EC               [12] 1343 	mov	a,r4
      008A3D 75 F0 0A         [24] 1344 	mov	b,#0x0a
      008A40 A4               [48] 1345 	mul	ab
      008A41 FB               [12] 1346 	mov	r3,a
      008A42 7C 00            [12] 1347 	mov	r4,#0x00
      008A44 80 11            [24] 1348 	sjmp	00108$
      008A46                       1349 00107$:
      008A46 ED               [12] 1350 	mov	a,r5
      008A47 24 FA            [12] 1351 	add	a,#0xfa
      008A49 75 F0 0A         [24] 1352 	mov	b,#0x0a
      008A4C A4               [48] 1353 	mul	ab
      008A4D FD               [12] 1354 	mov	r5,a
      008A4E 7A 00            [12] 1355 	mov	r2,#0x00
      008A50 74 40            [12] 1356 	mov	a,#0x40
      008A52 2D               [12] 1357 	add	a, r5
      008A53 FB               [12] 1358 	mov	r3,a
      008A54 E4               [12] 1359 	clr	a
      008A55 3A               [12] 1360 	addc	a, r2
      008A56 FC               [12] 1361 	mov	r4,a
      008A57                       1362 00108$:
      008A57 74 C0            [12] 1363 	mov	a,#0xc0
      008A59 2B               [12] 1364 	add	a, r3
      008A5A FB               [12] 1365 	mov	r3,a
      008A5B 74 06            [12] 1366 	mov	a,#0x06
      008A5D 3C               [12] 1367 	addc	a, r4
      008A5E FC               [12] 1368 	mov	r4,a
      008A5F 90 05 91         [24] 1369 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008A62 EB               [12] 1370 	mov	a,r3
      008A63 F0               [24] 1371 	movx	@dptr,a
      008A64 EC               [12] 1372 	mov	a,r4
      008A65 12 38 18         [24] 1373 	lcall	_ak820_outline_0075
      008A68 90 05 94         [24] 1374 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008A6B 74 0A            [12] 1375 	mov	a,#0x0a
      008A6D F0               [24] 1376 	movx	@dptr,a
      008A6E E4               [12] 1377 	clr	a
      008A6F A3               [24] 1378 	inc	dptr
      008A70 12 42 F2         [24] 1379 	lcall	_ak820_outline_0066
      008A73 12 41 D9         [24] 1380 	lcall	_ak820_eeprom_update_block_xdata
                                   1381 ;	quantum/dynamic_keymap.c:280: ak820_nvm_flush();
      008A76 12 3D E4         [24] 1382 	lcall	_ak820_nvm_flush
                                   1383 ;	quantum/dynamic_keymap.c:281: return ak820_nvm_ok() ? 0 : -1;
      008A79 12 3D D5         [24] 1384 	lcall	_ak820_nvm_ok
      008A7C E5 82            [12] 1385 	mov	a, dpl
      008A7E 60 06            [24] 1386 	jz	00109$
      008A80 7E 00            [12] 1387 	mov	r6,#0x00
      008A82 7F 00            [12] 1388 	mov	r7,#0x00
      008A84 80 04            [24] 1389 	sjmp	00110$
      008A86                       1390 00109$:
      008A86 7E FF            [12] 1391 	mov	r6,#0xff
      008A88 7F FF            [12] 1392 	mov	r7,#0xff
      008A8A                       1393 00110$:
      008A8A 12 43 17         [24] 1394 	lcall	_ak820_outline_0119
                                   1395 ;	quantum/dynamic_keymap.c:282: }
      008A8D 22               [24] 1396 	ret
                                   1397 ;------------------------------------------------------------
                                   1398 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1399 ;------------------------------------------------------------
                                   1400 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1401 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1402 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_398'
                                   1403 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_399'
                                   1404 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_401'
                                   1405 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_402'
                                   1406 ;------------------------------------------------------------
                                   1407 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1408 ;	-----------------------------------------
                                   1409 ;	 function dynamic_keymap_get_combo
                                   1410 ;	-----------------------------------------
      008A8E                       1411 _dynamic_keymap_get_combo:
      008A8E E5 82            [12] 1412 	mov	a,dpl
      008A90 90 0B B8         [24] 1413 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008A93 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A94 90 0B B5         [24] 1416 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008A97 12 37 FB         [24] 1417 	lcall	_ak820_outline_0058
                                   1418 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008A9A 90 0B B8         [24] 1419 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008A9D E0               [24] 1420 	movx	a,@dptr
      008A9E FD               [12] 1421 	mov	r5,a
      008A9F BD 08 00         [24] 1422 	cjne	r5,#0x08,00132$
      008AA2                       1423 00132$:
      008AA2 40 04            [24] 1424 	jc	00102$
                                   1425 ;	quantum/dynamic_keymap.c:315: return -1;
      008AA4 90 FF FF         [24] 1426 	mov	dptr,#0xffff
      008AA7 22               [24] 1427 	ret
      008AA8                       1428 00102$:
                                   1429 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008AA8 12 93 8E         [24] 1430 	lcall	_ak820_outline_0084
                                   1431 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008AAB 8E 02            [24] 1432 	mov	ar2,r6
      008AAD 8F 03            [24] 1433 	mov	ar3,r7
      008AAF 90 05 81         [24] 1434 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008AB2 EC               [12] 1435 	mov	a,r4
      008AB3 F0               [24] 1436 	movx	@dptr,a
      008AB4 ED               [12] 1437 	mov	a,r5
      008AB5 12 38 18         [24] 1438 	lcall	_ak820_outline_0075
      008AB8 90 05 84         [24] 1439 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008ABB 12 93 AF         [24] 1440 	lcall	_ak820_outline_0113
      008ABE 12 43 22         [24] 1441 	lcall	_ak820_outline_0136
      008AC1 C0 07            [24] 1442 	push	ar7
      008AC3 C0 06            [24] 1443 	push	ar6
      008AC5 12 40 6A         [24] 1444 	lcall	_ak820_eeprom_read_block_xdata
      008AC8 D0 06            [24] 1445 	pop	ar6
      008ACA D0 07            [24] 1446 	pop	ar7
                                   1447 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008ACC 74 04            [12] 1448 	mov	a,#0x04
      008ACE 12 93 83         [24] 1449 	lcall	_ak820_outline_0053
      008AD1 FA               [12] 1450 	mov	r2,a
      008AD2 A3               [24] 1451 	inc	dptr
      008AD3 E0               [24] 1452 	movx	a,@dptr
      008AD4 FB               [12] 1453 	mov	r3,a
      008AD5 BA 20 14         [24] 1454 	cjne	r2,#0x20,00108$
      008AD8 BB 08 11         [24] 1455 	cjne	r3,#0x08,00108$
      008ADB 74 06            [12] 1456 	mov	a,#0x06
      008ADD 12 37 DA         [24] 1457 	lcall	_ak820_outline_0018
      008AE0 FA               [12] 1458 	mov	r2,a
      008AE1 A3               [24] 1459 	inc	dptr
      008AE2 E0               [24] 1460 	movx	a,@dptr
      008AE3 FB               [12] 1461 	mov	r3,a
      008AE4 BA 01 05         [24] 1462 	cjne	r2,#0x01,00136$
      008AE7 BB 00 02         [24] 1463 	cjne	r3,#0x00,00136$
      008AEA 80 05            [24] 1464 	sjmp	00109$
      008AEC                       1465 00136$:
      008AEC                       1466 00108$:
      008AEC 75 2B 00         [24] 1467 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008AEF 80 03            [24] 1468 	sjmp	00110$
      008AF1                       1469 00109$:
      008AF1 75 2B 01         [24] 1470 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008AF4                       1471 00110$:
                                   1472 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008AF4 74 06            [12] 1473 	mov	a,#0x06
      008AF6 12 37 F3         [24] 1474 	lcall	_ak820_outline_0036
      008AF9 12 48 D3         [24] 1475 	lcall	_ak820_outline_0144
      008AFC 12 43 1C         [24] 1476 	lcall	_ak820_outline_0125
      008AFF A3               [24] 1477 	inc	dptr
      008B00 F0               [24] 1478 	movx	@dptr,a
                                   1479 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008B01 E5 2B            [12] 1480 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008B03 60 12            [24] 1481 	jz	00103$
      008B05 12 43 17         [24] 1482 	lcall	_ak820_outline_0119
      008B08 C0 07            [24] 1483 	push	ar7
      008B0A C0 06            [24] 1484 	push	ar6
      008B0C 12 34 68         [24] 1485 	lcall	_ak820_combo_valid
      008B0F E5 82            [12] 1486 	mov	a, dpl
      008B11 D0 06            [24] 1487 	pop	ar6
      008B13 D0 07            [24] 1488 	pop	ar7
      008B15 70 08            [24] 1489 	jnz	00104$
      008B17                       1490 00103$:
      008B17 7D 00            [12] 1491 	mov	r5,#0x00
      008B19 12 93 6E         [24] 1492 	lcall	_ak820_outline_0043
      008B1C 12 BD 48         [24] 1493 	lcall	_memset
      008B1F                       1494 00104$:
                                   1495 ;	quantum/dynamic_keymap.c:329: return 0;
      008B1F 90 00 00         [24] 1496 	mov	dptr,#0x0000
                                   1497 ;	quantum/dynamic_keymap.c:330: }
      008B22 22               [24] 1498 	ret
                                   1499 ;------------------------------------------------------------
                                   1500 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1501 ;------------------------------------------------------------
                                   1502 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1503 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_404'
                                   1504 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_405'
                                   1505 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_408'
                                   1506 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_409'
                                   1507 ;------------------------------------------------------------
                                   1508 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1509 ;	-----------------------------------------
                                   1510 ;	 function dynamic_keymap_set_combo
                                   1511 ;	-----------------------------------------
      008B23                       1512 _dynamic_keymap_set_combo:
      008B23 E5 82            [12] 1513 	mov	a,dpl
      008B25 90 0B BC         [24] 1514 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008B28 F0               [24] 1515 	movx	@dptr,a
                                   1516 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B29 90 0B B9         [24] 1517 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008B2C 12 37 AC         [24] 1518 	lcall	_ak820_outline_0006
                                   1519 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008B2F C0 07            [24] 1520 	push	ar7
      008B31 C0 06            [24] 1521 	push	ar6
      008B33 12 34 68         [24] 1522 	lcall	_ak820_combo_valid
      008B36 E5 82            [12] 1523 	mov	a, dpl
      008B38 D0 06            [24] 1524 	pop	ar6
      008B3A D0 07            [24] 1525 	pop	ar7
      008B3C 60 07            [24] 1526 	jz	00101$
      008B3E 12 3D D5         [24] 1527 	lcall	_ak820_nvm_ok
      008B41 E5 82            [12] 1528 	mov	a, dpl
      008B43 70 04            [24] 1529 	jnz	00102$
      008B45                       1530 00101$:
      008B45 90 FF FF         [24] 1531 	mov	dptr,#0xffff
      008B48 22               [24] 1532 	ret
      008B49                       1533 00102$:
                                   1534 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008B49 90 0B BC         [24] 1535 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008B4C E0               [24] 1536 	movx	a,@dptr
      008B4D FD               [12] 1537 	mov	r5,a
      008B4E BD 08 00         [24] 1538 	cjne	r5,#0x08,00133$
      008B51                       1539 00133$:
      008B51 40 04            [24] 1540 	jc	00105$
                                   1541 ;	quantum/dynamic_keymap.c:342: return -1;
      008B53 90 FF FF         [24] 1542 	mov	dptr,#0xffff
      008B56 22               [24] 1543 	ret
      008B57                       1544 00105$:
                                   1545 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B57 12 93 8E         [24] 1546 	lcall	_ak820_outline_0084
                                   1547 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008B5A C0 07            [24] 1548 	push	ar7
      008B5C C0 06            [24] 1549 	push	ar6
      008B5E C0 05            [24] 1550 	push	ar5
      008B60 C0 04            [24] 1551 	push	ar4
      008B62 12 7A ED         [24] 1552 	lcall	_clear_keyboard
      008B65 D0 04            [24] 1553 	pop	ar4
      008B67 D0 05            [24] 1554 	pop	ar5
      008B69 D0 06            [24] 1555 	pop	ar6
      008B6B D0 07            [24] 1556 	pop	ar7
                                   1557 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008B6D 90 0E 67         [24] 1558 	mov	dptr,#___memcpy_PARM_2
      008B70 12 48 C5         [24] 1559 	lcall	_ak820_outline_0065
      008B73 E4               [12] 1560 	clr	a
      008B74 A3               [24] 1561 	inc	dptr
      008B75 F0               [24] 1562 	movx	@dptr,a
      008B76 90 0E 6A         [24] 1563 	mov	dptr,#___memcpy_PARM_3
      008B79 12 93 AF         [24] 1564 	lcall	_ak820_outline_0113
      008B7C 90 0B BD         [24] 1565 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008B7F F5 F0            [12] 1566 	mov	b,a
      008B81 C0 05            [24] 1567 	push	ar5
      008B83 C0 04            [24] 1568 	push	ar4
      008B85 12 BC D2         [24] 1569 	lcall	___memcpy
      008B88 D0 04            [24] 1570 	pop	ar4
      008B8A D0 05            [24] 1571 	pop	ar5
                                   1572 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008B8C 90 0B C1         [24] 1573 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0004)
      008B8F 74 20            [12] 1574 	mov	a,#0x20
      008B91 F0               [24] 1575 	movx	@dptr,a
      008B92 74 08            [12] 1576 	mov	a,#0x08
      008B94 A3               [24] 1577 	inc	dptr
      008B95 F0               [24] 1578 	movx	@dptr,a
                                   1579 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008B96 90 0B C3         [24] 1580 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0006)
      008B99 74 01            [12] 1581 	mov	a,#0x01
      008B9B 12 38 5E         [24] 1582 	lcall	_ak820_outline_0128
                                   1583 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008B9E 90 05 8A         [24] 1584 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008BA1 EC               [12] 1585 	mov	a,r4
      008BA2 F0               [24] 1586 	movx	@dptr,a
      008BA3 ED               [12] 1587 	mov	a,r5
      008BA4 12 38 18         [24] 1588 	lcall	_ak820_outline_0075
      008BA7 90 05 8D         [24] 1589 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008BAA 12 93 AF         [24] 1590 	lcall	_ak820_outline_0113
      008BAD 90 0B BD         [24] 1591 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008BB0 12 40 F6         [24] 1592 	lcall	_ak820_eeprom_write_block_xdata
                                   1593 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008BB3 12 3D E4         [24] 1594 	lcall	_ak820_nvm_flush
                                   1595 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008BB6 12 3D D5         [24] 1596 	lcall	_ak820_nvm_ok
      008BB9 E5 82            [12] 1597 	mov	a, dpl
      008BBB 70 04            [24] 1598 	jnz	00107$
      008BBD 90 FF FF         [24] 1599 	mov	dptr,#0xffff
      008BC0 22               [24] 1600 	ret
      008BC1                       1601 00107$:
                                   1602 ;	quantum/dynamic_keymap.c:360: return 0;
      008BC1 90 00 00         [24] 1603 	mov	dptr,#0x0000
                                   1604 ;	quantum/dynamic_keymap.c:361: }
      008BC4 22               [24] 1605 	ret
                                   1606 ;------------------------------------------------------------
                                   1607 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1608 ;------------------------------------------------------------
                                   1609 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_412'
                                   1610 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_413'
                                   1611 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_415'
                                   1612 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_417'
                                   1613 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_419'
                                   1614 ;td            Allocated with name '_dynamic_keymap_reset_td_10001_421'
                                   1615 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_422'
                                   1616 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10002_424'
                                   1617 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_425'
                                   1618 ;------------------------------------------------------------
                                   1619 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1620 ;	-----------------------------------------
                                   1621 ;	 function dynamic_keymap_reset
                                   1622 ;	-----------------------------------------
      008BC5                       1623 _dynamic_keymap_reset:
                                   1624 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008BC5 90 0E E7         [24] 1625 	mov	dptr,#_vial_unlocked
      008BC8 E0               [24] 1626 	movx	a,@dptr
      008BC9 90 0B C7         [24] 1627 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008BCC F0               [24] 1628 	movx	@dptr,a
                                   1629 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008BCD 90 0E E7         [24] 1630 	mov	dptr,#_vial_unlocked
      008BD0 74 01            [12] 1631 	mov	a,#0x01
      008BD2 F0               [24] 1632 	movx	@dptr,a
                                   1633 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008BD3 7F 00            [12] 1634 	mov	r7,#0x00
      008BD5                       1635 00117$:
      008BD5 BF 06 00         [24] 1636 	cjne	r7,#0x06,00217$
      008BD8                       1637 00217$:
      008BD8 40 02            [24] 1638 	jc	00218$
      008BDA 81 83            [12] 1639 	ajmp	00104$
      008BDC                       1640 00218$:
                                   1641 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008BDC 7E 00            [12] 1642 	mov	r6,#0x00
      008BDE                       1643 00111$:
      008BDE BE 10 00         [24] 1644 	cjne	r6,#0x10,00219$
      008BE1                       1645 00219$:
      008BE1 50 4C            [24] 1646 	jnc	00102$
                                   1647 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008BE3 7D 00            [12] 1648 	mov	r5,#0x00
      008BE5                       1649 00108$:
      008BE5 BD 08 00         [24] 1650 	cjne	r5,#0x08,00221$
      008BE8                       1651 00221$:
      008BE8 50 42            [24] 1652 	jnc	00112$
                                   1653 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008BEA 90 0C 6D         [24] 1654 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008BED EE               [12] 1655 	mov	a,r6
      008BEE F0               [24] 1656 	movx	@dptr,a
      008BEF 90 0C 6E         [24] 1657 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008BF2 ED               [12] 1658 	mov	a,r5
      008BF3 F0               [24] 1659 	movx	@dptr,a
      008BF4 8F 82            [24] 1660 	mov	dpl, r7
      008BF6 C0 07            [24] 1661 	push	ar7
      008BF8 C0 06            [24] 1662 	push	ar6
      008BFA C0 05            [24] 1663 	push	ar5
      008BFC 12 9B C4         [24] 1664 	lcall	_keycode_at_keymap_location_raw
      008BFF AB 82            [24] 1665 	mov	r3, dpl
      008C01 AC 83            [24] 1666 	mov	r4, dph
      008C03 D0 05            [24] 1667 	pop	ar5
      008C05 D0 06            [24] 1668 	pop	ar6
      008C07 D0 07            [24] 1669 	pop	ar7
      008C09 90 0B 9E         [24] 1670 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008C0C EE               [12] 1671 	mov	a,r6
      008C0D F0               [24] 1672 	movx	@dptr,a
      008C0E 90 0B 9F         [24] 1673 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008C11 ED               [12] 1674 	mov	a,r5
      008C12 F0               [24] 1675 	movx	@dptr,a
      008C13 90 0B A0         [24] 1676 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008C16 12 38 24         [24] 1677 	lcall	_ak820_outline_0080
      008C19 8F 82            [24] 1678 	mov	dpl, r7
      008C1B C0 07            [24] 1679 	push	ar7
      008C1D C0 06            [24] 1680 	push	ar6
      008C1F C0 05            [24] 1681 	push	ar5
      008C21 11 29            [12] 1682 	acall	_dynamic_keymap_set_keycode
      008C23 D0 05            [24] 1683 	pop	ar5
      008C25 D0 06            [24] 1684 	pop	ar6
      008C27 D0 07            [24] 1685 	pop	ar7
                                   1686 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C29 0D               [12] 1687 	inc	r5
      008C2A 80 B9            [24] 1688 	sjmp	00108$
      008C2C                       1689 00112$:
                                   1690 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C2C 0E               [12] 1691 	inc	r6
      008C2D 80 AF            [24] 1692 	sjmp	00111$
      008C2F                       1693 00102$:
                                   1694 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C2F 7E 00            [12] 1695 	mov	r6,#0x00
      008C31                       1696 00114$:
      008C31 BE 01 00         [24] 1697 	cjne	r6,#0x01,00223$
      008C34                       1698 00223$:
      008C34 50 4A            [24] 1699 	jnc	00118$
                                   1700 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008C36 12 93 E4         [24] 1701 	lcall	_ak820_outline_0181
      008C39 04               [12] 1702 	inc	a
      008C3A F0               [24] 1703 	movx	@dptr,a
      008C3B 8F 82            [24] 1704 	mov	dpl, r7
      008C3D C0 07            [24] 1705 	push	ar7
      008C3F 12 9C 09         [24] 1706 	lcall	_keycode_at_encodermap_location_raw
      008C42 12 43 37         [24] 1707 	lcall	_ak820_outline_0152
      008C45 D0 07            [24] 1708 	pop	ar7
      008C47 12 93 DB         [24] 1709 	lcall	_ak820_outline_0180
      008C4A 04               [12] 1710 	inc	a
      008C4B F0               [24] 1711 	movx	@dptr,a
      008C4C 90 0B AA         [24] 1712 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C4F 12 38 1E         [24] 1713 	lcall	_ak820_outline_0077
      008C52 8F 82            [24] 1714 	mov	dpl, r7
      008C54 C0 07            [24] 1715 	push	ar7
      008C56 31 01            [24] 1716 	acall	_dynamic_keymap_set_encoder
      008C58 D0 07            [24] 1717 	pop	ar7
                                   1718 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008C5A 12 93 E4         [24] 1719 	lcall	_ak820_outline_0181
      008C5D F0               [24] 1720 	movx	@dptr,a
      008C5E 8F 82            [24] 1721 	mov	dpl, r7
      008C60 C0 07            [24] 1722 	push	ar7
      008C62 12 9C 09         [24] 1723 	lcall	_keycode_at_encodermap_location_raw
      008C65 12 43 37         [24] 1724 	lcall	_ak820_outline_0152
      008C68 D0 07            [24] 1725 	pop	ar7
      008C6A 12 93 DB         [24] 1726 	lcall	_ak820_outline_0180
      008C6D F0               [24] 1727 	movx	@dptr,a
      008C6E 90 0B AA         [24] 1728 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C71 12 38 1E         [24] 1729 	lcall	_ak820_outline_0077
      008C74 8F 82            [24] 1730 	mov	dpl, r7
      008C76 C0 07            [24] 1731 	push	ar7
      008C78 31 01            [24] 1732 	acall	_dynamic_keymap_set_encoder
      008C7A D0 07            [24] 1733 	pop	ar7
                                   1734 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C7C 7E 01            [12] 1735 	mov	r6,#0x01
      008C7E 80 B1            [24] 1736 	sjmp	00114$
      008C80                       1737 00118$:
                                   1738 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008C80 0F               [12] 1739 	inc	r7
      008C81 61 D5            [12] 1740 	ajmp	00117$
      008C83                       1741 00104$:
                                   1742 ;	quantum/dynamic_keymap.c:442: vial_tap_dance_entry_t td = { KC_NO, KC_NO, KC_NO, KC_NO, TAPPING_TERM };
      008C83 90 0B C8         [24] 1743 	mov	dptr,#_dynamic_keymap_reset_td_10001_421
      008C86 12 48 D3         [24] 1744 	lcall	_ak820_outline_0144
      008C89 90 0B CA         [24] 1745 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0002)
      008C8C F0               [24] 1746 	movx	@dptr,a
      008C8D A3               [24] 1747 	inc	dptr
      008C8E F0               [24] 1748 	movx	@dptr,a
      008C8F 90 0B CC         [24] 1749 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0004)
      008C92 F0               [24] 1750 	movx	@dptr,a
      008C93 A3               [24] 1751 	inc	dptr
      008C94 F0               [24] 1752 	movx	@dptr,a
      008C95 90 0B CE         [24] 1753 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0006)
      008C98 F0               [24] 1754 	movx	@dptr,a
      008C99 A3               [24] 1755 	inc	dptr
      008C9A F0               [24] 1756 	movx	@dptr,a
      008C9B 90 0B D0         [24] 1757 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0008)
      008C9E 74 C8            [12] 1758 	mov	a,#0xc8
      008CA0 12 38 5E         [24] 1759 	lcall	_ak820_outline_0128
                                   1760 ;	quantum/dynamic_keymap.c:443: for (reset_index_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008CA3 FF               [12] 1761 	mov	r7,a
      008CA4                       1762 00120$:
      008CA4 BF 08 00         [24] 1763 	cjne	r7,#0x08,00225$
      008CA7                       1764 00225$:
      008CA7 50 16            [24] 1765 	jnc	00105$
                                   1766 ;	quantum/dynamic_keymap.c:444: dynamic_keymap_set_tap_dance(i, &td);
      008CA9 90 0B B1         [24] 1767 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      008CAC 74 C8            [12] 1768 	mov	a,#_dynamic_keymap_reset_td_10001_421
      008CAE F0               [24] 1769 	movx	@dptr,a
      008CAF 74 0B            [12] 1770 	mov	a,#(_dynamic_keymap_reset_td_10001_421 >> 8)
      008CB1 12 38 18         [24] 1771 	lcall	_ak820_outline_0075
      008CB4 8F 82            [24] 1772 	mov	dpl, r7
      008CB6 C0 07            [24] 1773 	push	ar7
      008CB8 31 EF            [24] 1774 	acall	_dynamic_keymap_set_tap_dance
      008CBA D0 07            [24] 1775 	pop	ar7
                                   1776 ;	quantum/dynamic_keymap.c:443: for (reset_index_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008CBC 0F               [12] 1777 	inc	r7
      008CBD 80 E5            [24] 1778 	sjmp	00120$
      008CBF                       1779 00105$:
                                   1780 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008CBF 90 0B D2         [24] 1781 	mov	dptr,#_dynamic_keymap_reset_combo_10002_424
      008CC2 12 48 D3         [24] 1782 	lcall	_ak820_outline_0144
      008CC5 90 0B D4         [24] 1783 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0002)
      008CC8 F0               [24] 1784 	movx	@dptr,a
      008CC9 A3               [24] 1785 	inc	dptr
      008CCA F0               [24] 1786 	movx	@dptr,a
      008CCB 90 0B D6         [24] 1787 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0004)
      008CCE F0               [24] 1788 	movx	@dptr,a
      008CCF A3               [24] 1789 	inc	dptr
      008CD0 F0               [24] 1790 	movx	@dptr,a
      008CD1 90 0B D8         [24] 1791 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0006)
      008CD4 F0               [24] 1792 	movx	@dptr,a
      008CD5 A3               [24] 1793 	inc	dptr
      008CD6 F0               [24] 1794 	movx	@dptr,a
      008CD7 90 0B DA         [24] 1795 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0008)
      008CDA F0               [24] 1796 	movx	@dptr,a
      008CDB A3               [24] 1797 	inc	dptr
      008CDC F0               [24] 1798 	movx	@dptr,a
                                   1799 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CDD FF               [12] 1800 	mov	r7,a
      008CDE                       1801 00123$:
      008CDE BF 08 00         [24] 1802 	cjne	r7,#0x08,00227$
      008CE1                       1803 00227$:
      008CE1 50 16            [24] 1804 	jnc	00106$
                                   1805 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008CE3 90 0B B9         [24] 1806 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008CE6 74 D2            [12] 1807 	mov	a,#_dynamic_keymap_reset_combo_10002_424
      008CE8 F0               [24] 1808 	movx	@dptr,a
      008CE9 74 0B            [12] 1809 	mov	a,#(_dynamic_keymap_reset_combo_10002_424 >> 8)
      008CEB 12 38 18         [24] 1810 	lcall	_ak820_outline_0075
      008CEE 8F 82            [24] 1811 	mov	dpl, r7
      008CF0 C0 07            [24] 1812 	push	ar7
      008CF2 71 23            [12] 1813 	acall	_dynamic_keymap_set_combo
      008CF4 D0 07            [24] 1814 	pop	ar7
                                   1815 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CF6 0F               [12] 1816 	inc	r7
      008CF7 80 E5            [24] 1817 	sjmp	00123$
      008CF9                       1818 00106$:
                                   1819 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008CF9 90 0B C7         [24] 1820 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008CFC E0               [24] 1821 	movx	a,@dptr
      008CFD 90 0E E7         [24] 1822 	mov	dptr,#_vial_unlocked
      008D00 F0               [24] 1823 	movx	@dptr,a
                                   1824 ;	quantum/dynamic_keymap.c:468: }
      008D01 22               [24] 1825 	ret
                                   1826 ;------------------------------------------------------------
                                   1827 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1828 ;------------------------------------------------------------
                                   1829 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1830 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1831 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1832 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1833 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1834 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_426'
                                   1835 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_427'
                                   1836 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_427'
                                   1837 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_430'
                                   1838 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_432'
                                   1839 ;------------------------------------------------------------
                                   1840 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1841 ;	-----------------------------------------
                                   1842 ;	 function ak820_dynamic_read_buffer
                                   1843 ;	-----------------------------------------
      008D02                       1844 _ak820_dynamic_read_buffer:
      008D02 12 38 4E         [24] 1845 	lcall	_ak820_outline_0109
      008D05 90 0B E5         [24] 1846 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008D08 12 38 49         [24] 1847 	lcall	_ak820_outline_0108
                                   1848 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008D0B 90 0B E2         [24] 1849 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D0E 12 37 FB         [24] 1850 	lcall	_ak820_outline_0058
                                   1851 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008D11 90 0B E7         [24] 1852 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008D14 E4               [12] 1853 	clr	a
      008D15 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008D16 90 0B E0         [24] 1856 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D19 12 38 12         [24] 1857 	lcall	_ak820_outline_0064
      008D1C 8C 02            [24] 1858 	mov	ar2,r4
      008D1E 8D 03            [24] 1859 	mov	ar3,r5
      008D20 C3               [12] 1860 	clr	c
      008D21 74 1C            [12] 1861 	mov	a,#0x1c
      008D23 9A               [12] 1862 	subb	a,r2
      008D24 E4               [12] 1863 	clr	a
      008D25 9B               [12] 1864 	subb	a,r3
      008D26 50 01            [24] 1865 	jnc	00102$
                                   1866 ;	free result
      008D28 22               [24] 1867 	ret
      008D29                       1868 00102$:
                                   1869 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008D29 90 0B DE         [24] 1870 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008D2C 12 42 FF         [24] 1871 	lcall	_ak820_outline_0081
      008D2F 90 0B DC         [24] 1872 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008D32 12 38 3D         [24] 1873 	lcall	_ak820_outline_0102
      008D35 C3               [12] 1874 	clr	c
      008D36 EA               [12] 1875 	mov	a,r2
      008D37 98               [12] 1876 	subb	a,r0
      008D38 EB               [12] 1877 	mov	a,r3
      008D39 99               [12] 1878 	subb	a,r1
      008D3A 50 17            [24] 1879 	jnc	00104$
                                   1880 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008D3C E8               [12] 1881 	mov	a,r0
      008D3D C3               [12] 1882 	clr	c
      008D3E 9A               [12] 1883 	subb	a,r2
      008D3F F8               [12] 1884 	mov	r0,a
      008D40 E9               [12] 1885 	mov	a,r1
      008D41 9B               [12] 1886 	subb	a,r3
      008D42 F9               [12] 1887 	mov	r1,a
                                   1888 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008D43 C3               [12] 1889 	clr	c
      008D44 E8               [12] 1890 	mov	a,r0
      008D45 9C               [12] 1891 	subb	a,r4
      008D46 E9               [12] 1892 	mov	a,r1
      008D47 9D               [12] 1893 	subb	a,r5
      008D48 40 04            [24] 1894 	jc	00114$
      008D4A 8C 00            [24] 1895 	mov	ar0,r4
      008D4C 8D 01            [24] 1896 	mov	ar1,r5
      008D4E                       1897 00114$:
      008D4E 90 0B E7         [24] 1898 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008D51 E8               [12] 1899 	mov	a,r0
      008D52 F0               [24] 1900 	movx	@dptr,a
      008D53                       1901 00104$:
                                   1902 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D53 90 0B E7         [24] 1903 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008D56 E0               [24] 1904 	movx	a,@dptr
      008D57 F5 2C            [12] 1905 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008D59 E0               [24] 1906 	movx	a,@dptr
      008D5A 60 42            [24] 1907 	jz	00106$
      008D5C C0 04            [24] 1908 	push	ar4
      008D5E C0 05            [24] 1909 	push	ar5
      008D60 8E 00            [24] 1910 	mov	ar0,r6
      008D62 8F 05            [24] 1911 	mov	ar5,r7
      008D64 90 0B E5         [24] 1912 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008D67 E0               [24] 1913 	movx	a,@dptr
      008D68 F9               [12] 1914 	mov	r1,a
      008D69 A3               [24] 1915 	inc	dptr
      008D6A E0               [24] 1916 	movx	a,@dptr
      008D6B FC               [12] 1917 	mov	r4,a
      008D6C EA               [12] 1918 	mov	a,r2
      008D6D 29               [12] 1919 	add	a, r1
      008D6E FA               [12] 1920 	mov	r2,a
      008D6F EB               [12] 1921 	mov	a,r3
      008D70 3C               [12] 1922 	addc	a, r4
      008D71 FB               [12] 1923 	mov	r3,a
      008D72 90 05 81         [24] 1924 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008D75 EA               [12] 1925 	mov	a,r2
      008D76 F0               [24] 1926 	movx	@dptr,a
      008D77 EB               [12] 1927 	mov	a,r3
      008D78 12 38 18         [24] 1928 	lcall	_ak820_outline_0075
      008D7B 90 05 84         [24] 1929 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008D7E E5 2C            [12] 1930 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008D80 12 38 5E         [24] 1931 	lcall	_ak820_outline_0128
      008D83 88 82            [24] 1932 	mov	dpl, r0
      008D85 8D 83            [24] 1933 	mov	dph, r5
      008D87 C0 07            [24] 1934 	push	ar7
      008D89 C0 06            [24] 1935 	push	ar6
      008D8B C0 05            [24] 1936 	push	ar5
      008D8D C0 04            [24] 1937 	push	ar4
      008D8F 12 40 6A         [24] 1938 	lcall	_ak820_eeprom_read_block_xdata
      008D92 D0 04            [24] 1939 	pop	ar4
      008D94 D0 05            [24] 1940 	pop	ar5
      008D96 D0 06            [24] 1941 	pop	ar6
      008D98 D0 07            [24] 1942 	pop	ar7
                                   1943 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008D9A D0 05            [24] 1944 	pop	ar5
      008D9C D0 04            [24] 1945 	pop	ar4
                                   1946 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D9E                       1947 00106$:
                                   1948 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008D9E 90 0B E7         [24] 1949 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008DA1 E0               [24] 1950 	movx	a,@dptr
      008DA2 FB               [12] 1951 	mov	r3,a
      008DA3                       1952 00109$:
      008DA3 8B 01            [24] 1953 	mov	ar1,r3
      008DA5 7A 00            [12] 1954 	mov	r2,#0x00
      008DA7 C3               [12] 1955 	clr	c
      008DA8 E9               [12] 1956 	mov	a,r1
      008DA9 9C               [12] 1957 	subb	a,r4
      008DAA EA               [12] 1958 	mov	a,r2
      008DAB 9D               [12] 1959 	subb	a,r5
      008DAC 50 09            [24] 1960 	jnc	00111$
      008DAE EB               [12] 1961 	mov	a,r3
      008DAF 12 37 F3         [24] 1962 	lcall	_ak820_outline_0036
      008DB2 E4               [12] 1963 	clr	a
      008DB3 F0               [24] 1964 	movx	@dptr,a
      008DB4 0B               [12] 1965 	inc	r3
      008DB5 80 EC            [24] 1966 	sjmp	00109$
      008DB7                       1967 00111$:
                                   1968 ;	quantum/dynamic_keymap.c:483: }
      008DB7 22               [24] 1969 	ret
                                   1970 ;------------------------------------------------------------
                                   1971 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1972 ;------------------------------------------------------------
                                   1973 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1974 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1975 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_433'
                                   1976 ;------------------------------------------------------------
                                   1977 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1978 ;	-----------------------------------------
                                   1979 ;	 function dynamic_keymap_get_buffer
                                   1980 ;	-----------------------------------------
      008DB8                       1981 _dynamic_keymap_get_buffer:
      008DB8 12 38 4E         [24] 1982 	lcall	_ak820_outline_0109
      008DBB 90 0B ED         [24] 1983 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008DBE 12 38 49         [24] 1984 	lcall	_ak820_outline_0108
                                   1985 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008DC1 90 0B ED         [24] 1986 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008DC4 12 37 FB         [24] 1987 	lcall	_ak820_outline_0058
      008DC7 90 0B E8         [24] 1988 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008DCA 12 38 12         [24] 1989 	lcall	_ak820_outline_0064
      008DCD 90 0B EA         [24] 1990 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008DD0 E0               [24] 1991 	movx	a,@dptr
      008DD1 F9               [12] 1992 	mov	r1,a
      008DD2 A3               [24] 1993 	inc	dptr
      008DD3 12 42 FF         [24] 1994 	lcall	_ak820_outline_0081
      008DD6 90 0B DC         [24] 1995 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008DD9 E4               [12] 1996 	clr	a
      008DDA F0               [24] 1997 	movx	@dptr,a
      008DDB 74 06            [12] 1998 	mov	a,#0x06
      008DDD A3               [24] 1999 	inc	dptr
      008DDE F0               [24] 2000 	movx	@dptr,a
      008DDF 90 0B DE         [24] 2001 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008DE2 12 48 C5         [24] 2002 	lcall	_ak820_outline_0065
      008DE5 90 0B E0         [24] 2003 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008DE8 12 38 1E         [24] 2004 	lcall	_ak820_outline_0077
      008DEB 90 0B E2         [24] 2005 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008DEE E9               [12] 2006 	mov	a,r1
      008DEF 12 54 32         [24] 2007 	lcall	_ak820_outline_0158
      008DF2 F0               [24] 2008 	movx	@dptr,a
      008DF3 90 00 40         [24] 2009 	mov	dptr,#0x0040
                                   2010 ;	quantum/dynamic_keymap.c:511: }
      008DF6 A1 02            [12] 2011 	ajmp	_ak820_dynamic_read_buffer
                                   2012 ;------------------------------------------------------------
                                   2013 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2014 ;------------------------------------------------------------
                                   2015 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2016 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2017 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2018 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2019 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2020 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_435'
                                   2021 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_436'
                                   2022 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_436'
                                   2023 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_436'
                                   2024 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_439'
                                   2025 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_442'
                                   2026 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_442'
                                   2027 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_444'
                                   2028 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_447'
                                   2029 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_449'
                                   2030 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_450'
                                   2031 ;------------------------------------------------------------
                                   2032 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2033 ;	-----------------------------------------
                                   2034 ;	 function dynamic_keymap_set_buffer
                                   2035 ;	-----------------------------------------
      008DF8                       2036 _dynamic_keymap_set_buffer:
      008DF8 12 38 4E         [24] 2037 	lcall	_ak820_outline_0109
      008DFB 90 0B F4         [24] 2038 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008DFE 12 38 49         [24] 2039 	lcall	_ak820_outline_0108
                                   2040 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008E01 90 0B F4         [24] 2041 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008E04 12 37 C6         [24] 2042 	lcall	_ak820_outline_0010
      008E07 74 40            [12] 2043 	mov	a,#0x40
      008E09 2C               [12] 2044 	add	a, r4
      008E0A FA               [12] 2045 	mov	r2,a
      008E0B E4               [12] 2046 	clr	a
      008E0C 3D               [12] 2047 	addc	a, r5
      008E0D FB               [12] 2048 	mov	r3,a
                                   2049 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008E0E 90 0B F1         [24] 2050 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008E11 12 38 3D         [24] 2051 	lcall	_ak820_outline_0102
                                   2052 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008E14 90 0B EF         [24] 2053 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008E17 E0               [24] 2054 	movx	a,@dptr
      008E18 F5 2D            [12] 2055 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008E1A A3               [24] 2056 	inc	dptr
      008E1B E0               [24] 2057 	movx	a,@dptr
      008E1C F5 2E            [12] 2058 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008E1E E5 2D            [12] 2059 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E20 45 2E            [12] 2060 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E22 70 01            [24] 2061 	jnz	00102$
      008E24 22               [24] 2062 	ret
      008E25                       2063 00102$:
                                   2064 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008E25 85 2D 2F         [24] 2065 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008E28 85 2E 30         [24] 2066 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E2B C3               [12] 2067 	clr	c
      008E2C 74 1C            [12] 2068 	mov	a,#0x1c
      008E2E 95 2F            [12] 2069 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E30 E4               [12] 2070 	clr	a
      008E31 95 30            [12] 2071 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E33 50 01            [24] 2072 	jnc	00104$
                                   2073 ;	free result
      008E35 22               [24] 2074 	ret
      008E36                       2075 00104$:
                                   2076 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008E36 85 2D 31         [24] 2077 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2078 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008E39 74 FA            [12] 2079 	mov	a,#0x100 - 0x06
      008E3B 2F               [12] 2080 	add	a,r7
      008E3C 40 11            [24] 2081 	jc	00105$
      008E3E E4               [12] 2082 	clr	a
      008E3F C3               [12] 2083 	clr	c
      008E40 9E               [12] 2084 	subb	a,r6
      008E41 FE               [12] 2085 	mov	r6,a
      008E42 74 06            [12] 2086 	mov	a,#0x06
      008E44 9F               [12] 2087 	subb	a,r7
      008E45 FF               [12] 2088 	mov	r7,a
      008E46 C3               [12] 2089 	clr	c
      008E47 EE               [12] 2090 	mov	a,r6
      008E48 95 2D            [12] 2091 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E4A EF               [12] 2092 	mov	a,r7
      008E4B 95 2E            [12] 2093 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E4D 50 01            [24] 2094 	jnc	00106$
      008E4F                       2095 00105$:
                                   2096 ;	quantum/dynamic_keymap.c:529: return;
      008E4F 22               [24] 2097 	ret
      008E50                       2098 00106$:
                                   2099 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008E50 90 0E E7         [24] 2100 	mov	dptr,#_vial_unlocked
      008E53 E0               [24] 2101 	movx	a,@dptr
      008E54 60 02            [24] 2102 	jz	00207$
      008E56 E1 64            [12] 2103 	ajmp	00120$
      008E58                       2104 00207$:
                                   2105 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008E58 90 0B F6         [24] 2106 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008E5B E4               [12] 2107 	clr	a
      008E5C F0               [24] 2108 	movx	@dptr,a
                                   2109 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008E5D 90 0B F7         [24] 2110 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008E60 E5 31            [12] 2111 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E62 F0               [24] 2112 	movx	@dptr,a
                                   2113 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008E63 EC               [12] 2114 	mov	a,r4
      008E64 30 E0 33         [24] 2115 	jnb	acc.0,00111$
                                   2116 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008E67 EA               [12] 2117 	mov	a,r2
      008E68 24 FF            [12] 2118 	add	a,#0xff
      008E6A FE               [12] 2119 	mov	r6,a
      008E6B EB               [12] 2120 	mov	a,r3
      008E6C 34 FF            [12] 2121 	addc	a,#0xff
      008E6E FF               [12] 2122 	mov	r7,a
      008E6F 7D 00            [12] 2123 	mov	r5,#0x00
      008E71 12 43 17         [24] 2124 	lcall	_ak820_outline_0119
      008E74 8D F0            [24] 2125 	mov	b, r5
      008E76 12 40 2F         [24] 2126 	lcall	_eeprom_read_byte
      008E79 AE 82            [24] 2127 	mov	r6,dpl
      008E7B 7F 00            [12] 2128 	mov	r7,#0x00
      008E7D 12 38 6D         [24] 2129 	lcall	_ak820_outline_0159
      008E80 E0               [24] 2130 	movx	a,@dptr
      008E81 7C 00            [12] 2131 	mov	r4,#0x00
      008E83 42 07            [12] 2132 	orl	ar7,a
      008E85 EC               [12] 2133 	mov	a,r4
      008E86 42 06            [12] 2134 	orl	ar6,a
                                   2135 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008E88 BF 00 09         [24] 2136 	cjne	r7,#0x00,00109$
      008E8B BE 7C 06         [24] 2137 	cjne	r6,#0x7c,00109$
                                   2138 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008E8E 12 38 6D         [24] 2139 	lcall	_ak820_outline_0159
      008E91 74 FF            [12] 2140 	mov	a,#0xff
      008E93 F0               [24] 2141 	movx	@dptr,a
      008E94                       2142 00109$:
                                   2143 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008E94 90 0B F6         [24] 2144 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008E97 74 01            [12] 2145 	mov	a,#0x01
      008E99 F0               [24] 2146 	movx	@dptr,a
      008E9A                       2147 00111$:
                                   2148 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008E9A 90 0B F4         [24] 2149 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008E9D 12 37 FB         [24] 2150 	lcall	_ak820_outline_0058
      008EA0 E5 2D            [12] 2151 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008EA2 2E               [12] 2152 	add	a, r6
      008EA3 FE               [12] 2153 	mov	r6,a
      008EA4 E5 2E            [12] 2154 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008EA6 3F               [12] 2155 	addc	a, r7
      008EA7 EE               [12] 2156 	mov	a,r6
      008EA8 30 E0 5A         [24] 2157 	jnb	acc.0,00115$
                                   2158 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008EAB AE 31            [24] 2159 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008EAD 7F 00            [12] 2160 	mov	r7,#0x00
      008EAF EE               [12] 2161 	mov	a,r6
      008EB0 24 FF            [12] 2162 	add	a,#0xff
      008EB2 FC               [12] 2163 	mov	r4,a
      008EB3 EF               [12] 2164 	mov	a,r7
      008EB4 34 FF            [12] 2165 	addc	a,#0xff
      008EB6 FD               [12] 2166 	mov	r5,a
      008EB7 EC               [12] 2167 	mov	a,r4
      008EB8 28               [12] 2168 	add	a, r0
      008EB9 F5 82            [12] 2169 	mov	dpl,a
      008EBB ED               [12] 2170 	mov	a,r5
      008EBC 39               [12] 2171 	addc	a, r1
      008EBD F5 83            [12] 2172 	mov	dph,a
      008EBF E0               [24] 2173 	movx	a,@dptr
      008EC0 FC               [12] 2174 	mov	r4,a
      008EC1 7D 00            [12] 2175 	mov	r5,#0x00
      008EC3 E5 31            [12] 2176 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008EC5 2A               [12] 2177 	add	a, r2
      008EC6 FA               [12] 2178 	mov	r2,a
      008EC7 E4               [12] 2179 	clr	a
      008EC8 3B               [12] 2180 	addc	a, r3
      008EC9 FB               [12] 2181 	mov	r3,a
      008ECA C0 00            [24] 2182 	push	ar0
      008ECC C0 01            [24] 2183 	push	ar1
      008ECE 8B 01            [24] 2184 	mov	ar1,r3
      008ED0 7B 00            [12] 2185 	mov	r3,#0x00
      008ED2 8A 82            [24] 2186 	mov	dpl, r2
      008ED4 89 83            [24] 2187 	mov	dph, r1
      008ED6 8B F0            [24] 2188 	mov	b, r3
      008ED8 12 40 2F         [24] 2189 	lcall	_eeprom_read_byte
      008EDB AB 82            [24] 2190 	mov	r3, dpl
      008EDD 7A 00            [12] 2191 	mov	r2,#0x00
      008EDF EB               [12] 2192 	mov	a,r3
      008EE0 12 43 2C         [24] 2193 	lcall	_ak820_outline_0143
                                   2194 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008EE3 BD 00 05         [24] 2195 	cjne	r5,#0x00,00212$
      008EE6 BC 7C 02         [24] 2196 	cjne	r4,#0x7c,00212$
      008EE9 80 06            [24] 2197 	sjmp	00213$
      008EEB                       2198 00212$:
      008EEB D0 01            [24] 2199 	pop	ar1
      008EED D0 00            [24] 2200 	pop	ar0
      008EEF 80 0D            [24] 2201 	sjmp	00113$
      008EF1                       2202 00213$:
      008EF1 D0 01            [24] 2203 	pop	ar1
      008EF3 D0 00            [24] 2204 	pop	ar0
                                   2205 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008EF5 1E               [12] 2206 	dec	r6
      008EF6 BE FF 01         [24] 2207 	cjne	r6,#0xff,00214$
      008EF9 1F               [12] 2208 	dec	r7
      008EFA                       2209 00214$:
      008EFA EE               [12] 2210 	mov	a,r6
      008EFB 12 93 BD         [24] 2211 	lcall	_ak820_outline_0132
      008EFE                       2212 00113$:
                                   2213 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008EFE E5 31            [12] 2214 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F00 14               [12] 2215 	dec	a
      008F01 90 0B F7         [24] 2216 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008F04 F0               [24] 2217 	movx	@dptr,a
      008F05                       2218 00115$:
                                   2219 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F05 90 0B F6         [24] 2220 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008F08 E0               [24] 2221 	movx	a,@dptr
      008F09 90 0B F8         [24] 2222 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F0C F0               [24] 2223 	movx	@dptr,a
      008F0D                       2224 00122$:
      008F0D 90 0B F8         [24] 2225 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F10 E0               [24] 2226 	movx	a,@dptr
      008F11 FF               [12] 2227 	mov	r7,a
      008F12 90 0B F7         [24] 2228 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008F15 E0               [24] 2229 	movx	a,@dptr
      008F16 FE               [12] 2230 	mov	r6,a
      008F17 C3               [12] 2231 	clr	c
      008F18 EF               [12] 2232 	mov	a,r7
      008F19 9E               [12] 2233 	subb	a,r6
      008F1A 50 48            [24] 2234 	jnc	00120$
                                   2235 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008F1C EF               [12] 2236 	mov	a,r7
      008F1D 28               [12] 2237 	add	a, r0
      008F1E FD               [12] 2238 	mov	r5,a
      008F1F E4               [12] 2239 	clr	a
      008F20 39               [12] 2240 	addc	a, r1
      008F21 FE               [12] 2241 	mov	r6,a
      008F22 12 4D A8         [24] 2242 	lcall	_ak820_outline_0078
      008F25 7B 00            [12] 2243 	mov	r3,#0x00
      008F27 8C 2E            [24] 2244 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008F29 8B 2D            [24] 2245 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008F2B 8F 02            [24] 2246 	mov	ar2,r7
      008F2D 7F 00            [12] 2247 	mov	r7,#0x00
      008F2F 74 01            [12] 2248 	mov	a,#0x01
      008F31 2A               [12] 2249 	add	a, r2
      008F32 FB               [12] 2250 	mov	r3,a
      008F33 E4               [12] 2251 	clr	a
      008F34 3F               [12] 2252 	addc	a, r7
      008F35 FC               [12] 2253 	mov	r4,a
      008F36 EB               [12] 2254 	mov	a,r3
      008F37 28               [12] 2255 	add	a, r0
      008F38 F5 82            [12] 2256 	mov	dpl,a
      008F3A EC               [12] 2257 	mov	a,r4
      008F3B 39               [12] 2258 	addc	a, r1
      008F3C F5 83            [12] 2259 	mov	dph,a
      008F3E E0               [24] 2260 	movx	a,@dptr
      008F3F FC               [12] 2261 	mov	r4,a
      008F40 7B 00            [12] 2262 	mov	r3,#0x00
      008F42 E5 2E            [12] 2263 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F44 42 03            [12] 2264 	orl	ar3,a
                                   2265 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008F46 BC 00 12         [24] 2266 	cjne	r4,#0x00,00123$
      008F49 BB 7C 0F         [24] 2267 	cjne	r3,#0x7c,00123$
                                   2268 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008F4C 12 38 63         [24] 2269 	lcall	_ak820_outline_0138
      008F4F 74 FF            [12] 2270 	mov	a,#0xff
      008F51 F0               [24] 2271 	movx	@dptr,a
                                   2272 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008F52 0A               [12] 2273 	inc	r2
      008F53 BA 00 01         [24] 2274 	cjne	r2,#0x00,00218$
      008F56 0F               [12] 2275 	inc	r7
      008F57                       2276 00218$:
      008F57 EA               [12] 2277 	mov	a,r2
      008F58 12 93 BD         [24] 2278 	lcall	_ak820_outline_0132
      008F5B                       2279 00123$:
                                   2280 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F5B 90 0B F8         [24] 2281 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F5E E0               [24] 2282 	movx	a,@dptr
      008F5F 24 02            [12] 2283 	add	a,#0x02
      008F61 F0               [24] 2284 	movx	@dptr,a
      008F62 80 A9            [24] 2285 	sjmp	00122$
      008F64                       2286 00120$:
                                   2287 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008F64 90 0B F4         [24] 2288 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008F67 12 37 FB         [24] 2289 	lcall	_ak820_outline_0058
      008F6A 74 40            [12] 2290 	mov	a,#0x40
      008F6C 2E               [12] 2291 	add	a, r6
      008F6D FE               [12] 2292 	mov	r6,a
      008F6E E4               [12] 2293 	clr	a
      008F6F 3F               [12] 2294 	addc	a, r7
      008F70 FF               [12] 2295 	mov	r7,a
      008F71 90 05 8A         [24] 2296 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008F74 12 48 C5         [24] 2297 	lcall	_ak820_outline_0065
      008F77 E4               [12] 2298 	clr	a
      008F78 A3               [24] 2299 	inc	dptr
      008F79 F0               [24] 2300 	movx	@dptr,a
      008F7A 90 05 8D         [24] 2301 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008F7D E5 2F            [12] 2302 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008F7F F0               [24] 2303 	movx	@dptr,a
      008F80 E5 30            [12] 2304 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008F82 A3               [24] 2305 	inc	dptr
      008F83 F0               [24] 2306 	movx	@dptr,a
      008F84 12 38 6D         [24] 2307 	lcall	_ak820_outline_0159
                                   2308 ;	quantum/dynamic_keymap.c:584: }
      008F87 02 40 F6         [24] 2309 	ljmp	_ak820_eeprom_write_block_xdata
                                   2310 ;------------------------------------------------------------
                                   2311 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2312 ;------------------------------------------------------------
                                   2313 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2314 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2315 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_453'
                                   2316 ;------------------------------------------------------------
                                   2317 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2318 ;	-----------------------------------------
                                   2319 ;	 function keycode_at_keymap_location
                                   2320 ;	-----------------------------------------
      008F8A                       2321 _keycode_at_keymap_location:
      008F8A E5 82            [12] 2322 	mov	a,dpl
      008F8C 90 0B FB         [24] 2323 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_453
      008F8F F0               [24] 2324 	movx	@dptr,a
                                   2325 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008F90 E0               [24] 2326 	movx	a,@dptr
      008F91 FF               [12] 2327 	mov	r7,a
      008F92 BF 06 00         [24] 2328 	cjne	r7,#0x06,00128$
      008F95                       2329 00128$:
      008F95 50 23            [24] 2330 	jnc	00102$
      008F97 90 0B F9         [24] 2331 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008F9A E0               [24] 2332 	movx	a,@dptr
      008F9B FE               [12] 2333 	mov	r6,a
      008F9C BE 10 00         [24] 2334 	cjne	r6,#0x10,00130$
      008F9F                       2335 00130$:
      008F9F 50 19            [24] 2336 	jnc	00102$
      008FA1 90 0B FA         [24] 2337 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008FA4 E0               [24] 2338 	movx	a,@dptr
      008FA5 FD               [12] 2339 	mov	r5,a
      008FA6 BD 08 00         [24] 2340 	cjne	r5,#0x08,00132$
      008FA9                       2341 00132$:
      008FA9 50 0F            [24] 2342 	jnc	00102$
                                   2343 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008FAB 90 0B 9B         [24] 2344 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008FAE EE               [12] 2345 	mov	a,r6
      008FAF F0               [24] 2346 	movx	@dptr,a
      008FB0 90 0B 9C         [24] 2347 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008FB3 ED               [12] 2348 	mov	a,r5
      008FB4 F0               [24] 2349 	movx	@dptr,a
      008FB5 8F 82            [24] 2350 	mov	dpl, r7
      008FB7 02 87 DB         [24] 2351 	ljmp	_dynamic_keymap_get_keycode
      008FBA                       2352 00102$:
                                   2353 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008FBA 90 00 00         [24] 2354 	mov	dptr,#0x0000
                                   2355 ;	quantum/dynamic_keymap.c:591: }
      008FBD 22               [24] 2356 	ret
                                   2357 ;------------------------------------------------------------
                                   2358 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2359 ;------------------------------------------------------------
                                   2360 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2361 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2362 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_457'
                                   2363 ;------------------------------------------------------------
                                   2364 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2365 ;	-----------------------------------------
                                   2366 ;	 function keycode_at_encodermap_location
                                   2367 ;	-----------------------------------------
      008FBE                       2368 _keycode_at_encodermap_location:
      008FBE E5 82            [12] 2369 	mov	a,dpl
      008FC0 90 0B FE         [24] 2370 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_457
      008FC3 F0               [24] 2371 	movx	@dptr,a
                                   2372 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008FC4 E0               [24] 2373 	movx	a,@dptr
      008FC5 FF               [12] 2374 	mov	r7,a
      008FC6 BF 06 00         [24] 2375 	cjne	r7,#0x06,00120$
      008FC9                       2376 00120$:
      008FC9 50 1E            [24] 2377 	jnc	00102$
      008FCB 90 0B FC         [24] 2378 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008FCE E0               [24] 2379 	movx	a,@dptr
      008FCF FE               [12] 2380 	mov	r6,a
      008FD0 BE 01 00         [24] 2381 	cjne	r6,#0x01,00122$
      008FD3                       2382 00122$:
      008FD3 50 14            [24] 2383 	jnc	00102$
                                   2384 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008FD5 90 0B FD         [24] 2385 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008FD8 E0               [24] 2386 	movx	a,@dptr
      008FD9 FE               [12] 2387 	mov	r6,a
      008FDA 90 0B A5         [24] 2388 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008FDD E4               [12] 2389 	clr	a
      008FDE F0               [24] 2390 	movx	@dptr,a
      008FDF 90 0B A6         [24] 2391 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008FE2 EE               [12] 2392 	mov	a,r6
      008FE3 F0               [24] 2393 	movx	@dptr,a
      008FE4 8F 82            [24] 2394 	mov	dpl, r7
      008FE6 02 88 9A         [24] 2395 	ljmp	_dynamic_keymap_get_encoder
      008FE9                       2396 00102$:
                                   2397 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008FE9 90 00 00         [24] 2398 	mov	dptr,#0x0000
                                   2399 ;	quantum/dynamic_keymap.c:599: }
      008FEC 22               [24] 2400 	ret
                                   2401 ;------------------------------------------------------------
                                   2402 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2403 ;------------------------------------------------------------
                                   2404 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2405 ;	-----------------------------------------
                                   2406 ;	 function dynamic_keymap_macro_get_count
                                   2407 ;	-----------------------------------------
      008FED                       2408 _dynamic_keymap_macro_get_count:
                                   2409 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008FED 75 82 10         [24] 2410 	mov	dpl, #0x10
                                   2411 ;	quantum/dynamic_keymap.c:604: }
      008FF0 22               [24] 2412 	ret
                                   2413 ;------------------------------------------------------------
                                   2414 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2415 ;------------------------------------------------------------
                                   2416 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2417 ;	-----------------------------------------
                                   2418 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2419 ;	-----------------------------------------
      008FF1                       2420 _dynamic_keymap_macro_get_buffer_size:
                                   2421 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008FF1 90 20 00         [24] 2422 	mov	dptr,#0x2000
                                   2423 ;	quantum/dynamic_keymap.c:608: }
      008FF4 22               [24] 2424 	ret
                                   2425 ;------------------------------------------------------------
                                   2426 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2427 ;------------------------------------------------------------
                                   2428 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2429 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2430 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2431 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_465'
                                   2432 ;------------------------------------------------------------
                                   2433 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2434 ;	-----------------------------------------
                                   2435 ;	 function dynamic_keymap_macro_get_buffer
                                   2436 ;	-----------------------------------------
      008FF5                       2437 _dynamic_keymap_macro_get_buffer:
      008FF5 12 38 4E         [24] 2438 	lcall	_ak820_outline_0109
      008FF8 90 0C 04         [24] 2439 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      008FFB 12 38 49         [24] 2440 	lcall	_ak820_outline_0108
                                   2441 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008FFE 12 2B 2B         [24] 2442 	lcall	_ak820_macro_length
      009001 12 43 27         [24] 2443 	lcall	_ak820_outline_0137
      009004 90 0C 04         [24] 2444 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      009007 12 38 12         [24] 2445 	lcall	_ak820_outline_0064
      00900A 90 0B FF         [24] 2446 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00900D E0               [24] 2447 	movx	a,@dptr
      00900E F5 32            [12] 2448 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      009010 A3               [24] 2449 	inc	dptr
      009011 E0               [24] 2450 	movx	a,@dptr
      009012 F5 33            [12] 2451 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      009014 90 0C 01         [24] 2452 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      009017 12 38 3D         [24] 2453 	lcall	_ak820_outline_0102
      00901A A3               [24] 2454 	inc	dptr
      00901B E0               [24] 2455 	movx	a,@dptr
      00901C FB               [12] 2456 	mov	r3,a
      00901D 90 0B DC         [24] 2457 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009020 12 48 C5         [24] 2458 	lcall	_ak820_outline_0065
      009023 90 0B DE         [24] 2459 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009026 12 38 1E         [24] 2460 	lcall	_ak820_outline_0077
      009029 90 0B E0         [24] 2461 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00902C E5 32            [12] 2462 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      00902E F0               [24] 2463 	movx	@dptr,a
      00902F E5 33            [12] 2464 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      009031 A3               [24] 2465 	inc	dptr
      009032 F0               [24] 2466 	movx	@dptr,a
      009033 90 0B E2         [24] 2467 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009036 E8               [12] 2468 	mov	a,r0
      009037 F0               [24] 2469 	movx	@dptr,a
      009038 E9               [12] 2470 	mov	a,r1
      009039 A3               [24] 2471 	inc	dptr
      00903A 12 48 ED         [24] 2472 	lcall	_ak820_outline_0189
      00903D 90 08 00         [24] 2473 	mov	dptr,#0x0800
                                   2474 ;	quantum/dynamic_keymap.c:635: }
      009040 02 8D 02         [24] 2475 	ljmp	_ak820_dynamic_read_buffer
                                   2476 ;------------------------------------------------------------
                                   2477 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2478 ;------------------------------------------------------------
                                   2479 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2480 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2481 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_467'
                                   2482 ;------------------------------------------------------------
                                   2483 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2484 ;	-----------------------------------------
                                   2485 ;	 function dynamic_keymap_macro_set_buffer
                                   2486 ;	-----------------------------------------
      009043                       2487 _dynamic_keymap_macro_set_buffer:
      009043 12 38 4E         [24] 2488 	lcall	_ak820_outline_0109
      009046 90 0C 0B         [24] 2489 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      009049 12 38 49         [24] 2490 	lcall	_ak820_outline_0108
                                   2491 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      00904C 90 0C 0B         [24] 2492 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      00904F 12 37 FB         [24] 2493 	lcall	_ak820_outline_0058
      009052 90 0C 06         [24] 2494 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      009055 12 38 12         [24] 2495 	lcall	_ak820_outline_0064
      009058 90 0C 08         [24] 2496 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00905B E0               [24] 2497 	movx	a,@dptr
      00905C F9               [12] 2498 	mov	r1,a
      00905D A3               [24] 2499 	inc	dptr
      00905E 12 42 FF         [24] 2500 	lcall	_ak820_outline_0081
      009061 90 05 10         [24] 2501 	mov	dptr,#_ak820_macro_write_PARM_2
      009064 12 38 1E         [24] 2502 	lcall	_ak820_outline_0077
      009067 90 05 12         [24] 2503 	mov	dptr,#_ak820_macro_write_PARM_3
      00906A E9               [12] 2504 	mov	a,r1
      00906B 12 54 32         [24] 2505 	lcall	_ak820_outline_0158
      00906E 12 42 F2         [24] 2506 	lcall	_ak820_outline_0066
                                   2507 ;	quantum/dynamic_keymap.c:640: }
      009071 02 2B 45         [24] 2508 	ljmp	_ak820_macro_write
                                   2509 ;------------------------------------------------------------
                                   2510 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2511 ;------------------------------------------------------------
                                   2512 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2513 ;	-----------------------------------------
                                   2514 ;	 function dynamic_keymap_macro_reset
                                   2515 ;	-----------------------------------------
      009074                       2516 _dynamic_keymap_macro_reset:
                                   2517 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2518 ;	quantum/dynamic_keymap.c:666: }
      009074 02 2E 64         [24] 2519 	ljmp	_ak820_macro_reset
                                   2520 ;------------------------------------------------------------
                                   2521 ;Allocation info for local variables in function 'decode_keycode'
                                   2522 ;------------------------------------------------------------
                                   2523 ;kc            Allocated with name '_decode_keycode_kc_10000_471'
                                   2524 ;------------------------------------------------------------
                                   2525 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2526 ;	-----------------------------------------
                                   2527 ;	 function decode_keycode
                                   2528 ;	-----------------------------------------
      009077                       2529 _decode_keycode:
      009077 12 38 4E         [24] 2530 	lcall	_ak820_outline_0109
      00907A 90 0C 0D         [24] 2531 	mov	dptr,#_decode_keycode_kc_10000_471
      00907D 12 38 49         [24] 2532 	lcall	_ak820_outline_0108
                                   2533 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      009080 90 0C 0D         [24] 2534 	mov	dptr,#_decode_keycode_kc_10000_471
      009083 12 37 C6         [24] 2535 	lcall	_ak820_outline_0010
      009086 C3               [12] 2536 	clr	c
      009087 E4               [12] 2537 	clr	a
      009088 9C               [12] 2538 	subb	a,r4
      009089 74 FF            [12] 2539 	mov	a,#0xff
      00908B 9D               [12] 2540 	subb	a,r5
      00908C 50 08            [24] 2541 	jnc	00102$
                                   2542 ;	free result
                                   2543 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      00908E 8C 05            [24] 2544 	mov	ar5,r4
      009090 7C 00            [12] 2545 	mov	r4,#0x00
      009092 12 38 59         [24] 2546 	lcall	_ak820_outline_0127
      009095 22               [24] 2547 	ret
      009096                       2548 00102$:
                                   2549 ;	quantum/dynamic_keymap.c:672: return kc;
      009096 12 43 17         [24] 2550 	lcall	_ak820_outline_0119
                                   2551 ;	quantum/dynamic_keymap.c:673: }
      009099 22               [24] 2552 	ret
                                   2553 ;------------------------------------------------------------
                                   2554 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2555 ;------------------------------------------------------------
                                   2556 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_474'
                                   2557 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_475'
                                   2558 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_480'
                                   2559 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_481'
                                   2560 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_487'
                                   2561 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_505'
                                   2562 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_509'
                                   2563 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_509'
                                   2564 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_511'
                                   2565 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_513'
                                   2566 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_517'
                                   2567 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_519'
                                   2568 ;------------------------------------------------------------
                                   2569 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2570 ;	-----------------------------------------
                                   2571 ;	 function dynamic_keymap_macro_send
                                   2572 ;	-----------------------------------------
      00909A                       2573 _dynamic_keymap_macro_send:
      00909A E5 82            [12] 2574 	mov	a,dpl
      00909C 90 0C 0F         [24] 2575 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      00909F F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0090A0 90 0C 10         [24] 2578 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      0090A3 E0               [24] 2579 	movx	a,@dptr
      0090A4 60 01            [24] 2580 	jz	00102$
      0090A6 22               [24] 2581 	ret
      0090A7                       2582 00102$:
                                   2583 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0090A7 90 0C 0F         [24] 2584 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      0090AA E0               [24] 2585 	movx	a,@dptr
      0090AB FF               [12] 2586 	mov	r7,a
      0090AC BF 10 00         [24] 2587 	cjne	r7,#0x10,00422$
      0090AF                       2588 00422$:
      0090AF 40 01            [24] 2589 	jc	00104$
                                   2590 ;	quantum/dynamic_keymap.c:683: return;
      0090B1 22               [24] 2591 	ret
      0090B2                       2592 00104$:
                                   2593 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      0090B2 C0 07            [24] 2594 	push	ar7
      0090B4 12 2A F2         [24] 2595 	lcall	_ak820_macro_ready
      0090B7 E5 82            [12] 2596 	mov	a, dpl
      0090B9 D0 07            [24] 2597 	pop	ar7
      0090BB 70 01            [24] 2598 	jnz	00106$
      0090BD 22               [24] 2599 	ret
      0090BE                       2600 00106$:
                                   2601 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0090BE 90 0C 11         [24] 2602 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0090C1 E4               [12] 2603 	clr	a
      0090C2 F0               [24] 2604 	movx	@dptr,a
      0090C3 74 08            [12] 2605 	mov	a,#0x08
      0090C5 A3               [24] 2606 	inc	dptr
      0090C6 F0               [24] 2607 	movx	@dptr,a
                                   2608 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0090C7 C0 07            [24] 2609 	push	ar7
      0090C9 12 2B 2B         [24] 2610 	lcall	_ak820_macro_length
      0090CC AD 82            [24] 2611 	mov	r5, dpl
      0090CE AE 83            [24] 2612 	mov	r6, dph
      0090D0 D0 07            [24] 2613 	pop	ar7
      0090D2 74 08            [12] 2614 	mov	a,#0x08
      0090D4 2E               [12] 2615 	add	a, r6
      0090D5 FE               [12] 2616 	mov	r6,a
                                   2617 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      0090D6 7B 00            [12] 2618 	mov	r3,#0x00
      0090D8 7C 08            [12] 2619 	mov	r4,#0x08
      0090DA                       2620 00111$:
      0090DA EF               [12] 2621 	mov	a,r7
      0090DB 60 31            [24] 2622 	jz	00113$
                                   2623 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      0090DD EB               [12] 2624 	mov	a,r3
      0090DE B5 05 05         [24] 2625 	cjne	a,ar5,00108$
      0090E1 EC               [12] 2626 	mov	a,r4
      0090E2 B5 06 01         [24] 2627 	cjne	a,ar6,00108$
                                   2628 ;	quantum/dynamic_keymap.c:717: return;
      0090E5 22               [24] 2629 	ret
      0090E6                       2630 00108$:
                                   2631 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0090E6 8B 01            [24] 2632 	mov	ar1,r3
      0090E8 8C 02            [24] 2633 	mov	ar2,r4
      0090EA 8A 00            [24] 2634 	mov	ar0,r2
      0090EC 7A 00            [12] 2635 	mov	r2,#0x00
      0090EE 89 82            [24] 2636 	mov	dpl, r1
      0090F0 88 83            [24] 2637 	mov	dph, r0
      0090F2 8A F0            [24] 2638 	mov	b, r2
      0090F4 12 40 2F         [24] 2639 	lcall	_eeprom_read_byte
      0090F7 E5 82            [12] 2640 	mov	a, dpl
      0090F9 70 06            [24] 2641 	jnz	00110$
                                   2642 ;	quantum/dynamic_keymap.c:720: --id;
      0090FB 1F               [12] 2643 	dec	r7
      0090FC 90 0C 0F         [24] 2644 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      0090FF EF               [12] 2645 	mov	a,r7
      009100 F0               [24] 2646 	movx	@dptr,a
      009101                       2647 00110$:
                                   2648 ;	quantum/dynamic_keymap.c:722: ++p;
      009101 0B               [12] 2649 	inc	r3
      009102 BB 00 01         [24] 2650 	cjne	r3,#0x00,00429$
      009105 0C               [12] 2651 	inc	r4
      009106                       2652 00429$:
      009106 90 0C 11         [24] 2653 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009109 12 38 24         [24] 2654 	lcall	_ak820_outline_0080
      00910C 80 CC            [24] 2655 	sjmp	00111$
      00910E                       2656 00113$:
                                   2657 ;	quantum/dynamic_keymap.c:728: sending = true;
      00910E 90 0C 10         [24] 2658 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009111 74 01            [12] 2659 	mov	a,#0x01
      009113 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      009114 12 93 D5         [24] 2662 	lcall	_ak820_outline_0168
      009117 90 0A 47         [24] 2663 	mov	dptr,#_ak820_macro_cancelled
      00911A F0               [24] 2664 	movx	@dptr,a
                                   2665 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      00911B 90 0C 13         [24] 2666 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00911E F0               [24] 2667 	movx	@dptr,a
      00911F 90 0C 14         [24] 2668 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009122 F0               [24] 2669 	movx	@dptr,a
      009123 90 0C 15         [24] 2670 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      009126 F0               [24] 2671 	movx	@dptr,a
      009127 90 0C 16         [24] 2672 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      00912A F0               [24] 2673 	movx	@dptr,a
                                   2674 ;	quantum/dynamic_keymap.c:738: while (p < end
      00912B                       2675 00167$:
                                   2676 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      00912B 90 0C 11         [24] 2677 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00912E E0               [24] 2678 	movx	a,@dptr
      00912F FC               [12] 2679 	mov	r4,a
      009130 A3               [24] 2680 	inc	dptr
      009131 E0               [24] 2681 	movx	a,@dptr
      009132 FF               [12] 2682 	mov	r7,a
      009133 C3               [12] 2683 	clr	c
      009134 EC               [12] 2684 	mov	a,r4
      009135 9D               [12] 2685 	subb	a,r5
      009136 EF               [12] 2686 	mov	a,r7
      009137 9E               [12] 2687 	subb	a,r6
      009138 40 02            [24] 2688 	jc	00430$
      00913A 61 3C            [12] 2689 	ajmp	00169$
      00913C                       2690 00430$:
      00913C 90 0A 47         [24] 2691 	mov	dptr,#_ak820_macro_cancelled
      00913F E0               [24] 2692 	movx	a,@dptr
      009140 60 02            [24] 2693 	jz	00431$
      009142 61 3C            [12] 2694 	ajmp	00169$
      009144                       2695 00431$:
                                   2696 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009144 8C 02            [24] 2697 	mov	ar2,r4
      009146 8F 03            [24] 2698 	mov	ar3,r7
      009148 90 0C 11         [24] 2699 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00914B 74 01            [12] 2700 	mov	a,#0x01
      00914D 2C               [12] 2701 	add	a, r4
      00914E F0               [24] 2702 	movx	@dptr,a
      00914F E4               [12] 2703 	clr	a
      009150 3F               [12] 2704 	addc	a, r7
      009151 A3               [24] 2705 	inc	dptr
      009152 F0               [24] 2706 	movx	@dptr,a
      009153 7F 00            [12] 2707 	mov	r7,#0x00
      009155 12 43 22         [24] 2708 	lcall	_ak820_outline_0136
      009158 8F F0            [24] 2709 	mov	b, r7
      00915A 12 40 2F         [24] 2710 	lcall	_eeprom_read_byte
      00915D AF 82            [24] 2711 	mov	r7, dpl
      00915F 90 0C 13         [24] 2712 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009162 EF               [12] 2713 	mov	a,r7
      009163 F0               [24] 2714 	movx	@dptr,a
                                   2715 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      009164 90 0C 14         [24] 2716 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009167 E4               [12] 2717 	clr	a
      009168 F0               [24] 2718 	movx	@dptr,a
                                   2719 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      009169 90 0C 13         [24] 2720 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00916C E0               [24] 2721 	movx	a,@dptr
      00916D 70 02            [24] 2722 	jnz	00432$
      00916F 61 3C            [12] 2723 	ajmp	00169$
      009171                       2724 00432$:
                                   2725 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      009171 90 0C 13         [24] 2726 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009174 E0               [24] 2727 	movx	a,@dptr
      009175 FF               [12] 2728 	mov	r7,a
      009176 BF 01 02         [24] 2729 	cjne	r7,#0x01,00433$
      009179 80 02            [24] 2730 	sjmp	00434$
      00917B                       2731 00433$:
      00917B 61 1F            [12] 2732 	ajmp	00164$
      00917D                       2733 00434$:
                                   2734 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00917D 12 93 44         [24] 2735 	lcall	_ak820_outline_0000
      009180 12 40 2F         [24] 2736 	lcall	_eeprom_read_byte
      009183 AF 82            [24] 2737 	mov	r7, dpl
      009185 90 0C 14         [24] 2738 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009188 EF               [12] 2739 	mov	a,r7
      009189 F0               [24] 2740 	movx	@dptr,a
                                   2741 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      00918A EF               [12] 2742 	mov	a,r7
      00918B 70 02            [24] 2743 	jnz	00435$
      00918D 61 3C            [12] 2744 	ajmp	00169$
      00918F                       2745 00435$:
                                   2746 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      00918F 12 93 9C         [24] 2747 	lcall	_ak820_outline_0095
      009192 BF 01 02         [24] 2748 	cjne	r7,#0x01,00436$
      009195 80 12            [24] 2749 	sjmp	00151$
      009197                       2750 00436$:
      009197 12 93 9C         [24] 2751 	lcall	_ak820_outline_0095
      00919A BF 02 02         [24] 2752 	cjne	r7,#0x02,00437$
      00919D 80 0A            [24] 2753 	sjmp	00151$
      00919F                       2754 00437$:
      00919F 12 93 9C         [24] 2755 	lcall	_ak820_outline_0095
      0091A2 BF 03 02         [24] 2756 	cjne	r7,#0x03,00438$
      0091A5 80 02            [24] 2757 	sjmp	00439$
      0091A7                       2758 00438$:
      0091A7 41 08            [12] 2759 	ajmp	00152$
      0091A9                       2760 00439$:
      0091A9                       2761 00151$:
                                   2762 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091A9 12 93 44         [24] 2763 	lcall	_ak820_outline_0000
      0091AC 12 40 2F         [24] 2764 	lcall	_eeprom_read_byte
      0091AF 12 93 ED         [24] 2765 	lcall	_ak820_outline_0184
                                   2766 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      0091B2 70 02            [24] 2767 	jnz	00440$
      0091B4 21 2B            [12] 2768 	ajmp	00167$
      0091B6                       2769 00440$:
                                   2770 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0091B6 12 93 9C         [24] 2771 	lcall	_ak820_outline_0095
      0091B9 BF 01 03         [24] 2772 	cjne	r7,#0x01,00441$
      0091BC D3               [12] 2773 	setb	c
      0091BD 80 01            [24] 2774 	sjmp	00442$
      0091BF                       2775 00441$:
      0091BF C3               [12] 2776 	clr	c
      0091C0                       2777 00442$:
      0091C0 92 25            [24] 2778 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0091C2 90 0A 46         [24] 2779 	mov	dptr,#_ak820_macro_primitive
      0091C5 B3               [12] 2780 	cpl	c
      0091C6 E4               [12] 2781 	clr	a
      0091C7 33               [12] 2782 	rlc	a
      0091C8 F0               [24] 2783 	movx	@dptr,a
                                   2784 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0091C9 12 93 9C         [24] 2785 	lcall	_ak820_outline_0095
      0091CC BF 01 10         [24] 2786 	cjne	r7,#0x01,00122$
      0091CF 12 93 CE         [24] 2787 	lcall	_ak820_outline_0154
      0091D2 C0 06            [24] 2788 	push	ar6
      0091D4 C0 05            [24] 2789 	push	ar5
      0091D6 12 7A 81         [24] 2790 	lcall	_tap_code
      0091D9 D0 05            [24] 2791 	pop	ar5
      0091DB D0 06            [24] 2792 	pop	ar6
      0091DD 80 24            [24] 2793 	sjmp	00123$
      0091DF                       2794 00122$:
                                   2795 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0091DF 12 93 9C         [24] 2796 	lcall	_ak820_outline_0095
      0091E2 BF 02 10         [24] 2797 	cjne	r7,#0x02,00119$
      0091E5 12 93 CE         [24] 2798 	lcall	_ak820_outline_0154
      0091E8 C0 06            [24] 2799 	push	ar6
      0091EA C0 05            [24] 2800 	push	ar5
      0091EC 12 79 7D         [24] 2801 	lcall	_register_code
      0091EF D0 05            [24] 2802 	pop	ar5
      0091F1 D0 06            [24] 2803 	pop	ar6
      0091F3 80 0E            [24] 2804 	sjmp	00123$
      0091F5                       2805 00119$:
                                   2806 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      0091F5 12 93 CE         [24] 2807 	lcall	_ak820_outline_0154
      0091F8 C0 06            [24] 2808 	push	ar6
      0091FA C0 05            [24] 2809 	push	ar5
      0091FC 12 79 EA         [24] 2810 	lcall	_unregister_code
      0091FF D0 05            [24] 2811 	pop	ar5
      009201 D0 06            [24] 2812 	pop	ar6
      009203                       2813 00123$:
                                   2814 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      009203 12 93 D5         [24] 2815 	lcall	_ak820_outline_0168
      009206 21 2B            [12] 2816 	ajmp	00167$
      009208                       2817 00152$:
                                   2818 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      009208 12 93 9C         [24] 2819 	lcall	_ak820_outline_0095
      00920B BF 05 02         [24] 2820 	cjne	r7,#0x05,00447$
      00920E 80 12            [24] 2821 	sjmp	00146$
      009210                       2822 00447$:
      009210 12 93 9C         [24] 2823 	lcall	_ak820_outline_0095
      009213 BF 06 02         [24] 2824 	cjne	r7,#0x06,00448$
      009216 80 0A            [24] 2825 	sjmp	00146$
      009218                       2826 00448$:
      009218 12 93 9C         [24] 2827 	lcall	_ak820_outline_0095
      00921B BF 07 02         [24] 2828 	cjne	r7,#0x07,00449$
      00921E 80 02            [24] 2829 	sjmp	00450$
      009220                       2830 00449$:
      009220 41 C1            [12] 2831 	ajmp	00147$
      009222                       2832 00450$:
      009222                       2833 00146$:
                                   2834 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009222 12 93 44         [24] 2835 	lcall	_ak820_outline_0000
      009225 12 40 2F         [24] 2836 	lcall	_eeprom_read_byte
      009228 12 93 ED         [24] 2837 	lcall	_ak820_outline_0184
                                   2838 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      00922B 70 02            [24] 2839 	jnz	00451$
      00922D 21 2B            [12] 2840 	ajmp	00167$
      00922F                       2841 00451$:
                                   2842 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00922F 12 93 44         [24] 2843 	lcall	_ak820_outline_0000
      009232 12 40 2F         [24] 2844 	lcall	_eeprom_read_byte
      009235 AF 82            [24] 2845 	mov	r7, dpl
      009237 90 0C 16         [24] 2846 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      00923A EF               [12] 2847 	mov	a,r7
      00923B F0               [24] 2848 	movx	@dptr,a
                                   2849 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      00923C EF               [12] 2850 	mov	a,r7
      00923D 70 02            [24] 2851 	jnz	00452$
      00923F 21 2B            [12] 2852 	ajmp	00167$
      009241                       2853 00452$:
                                   2854 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009241 90 0C 15         [24] 2855 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      009244 E0               [24] 2856 	movx	a,@dptr
      009245 FF               [12] 2857 	mov	r7,a
      009246 90 0C 16         [24] 2858 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      009249 E0               [24] 2859 	movx	a,@dptr
      00924A FB               [12] 2860 	mov	r3,a
      00924B E4               [12] 2861 	clr	a
      00924C FC               [12] 2862 	mov	r4,a
      00924D FA               [12] 2863 	mov	r2,a
      00924E EF               [12] 2864 	mov	a,r7
      00924F 42 04            [12] 2865 	orl	ar4,a
      009251 EA               [12] 2866 	mov	a,r2
      009252 42 03            [12] 2867 	orl	ar3,a
                                   2868 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      009254 12 43 4D         [24] 2869 	lcall	_ak820_outline_0185
      009257 C0 06            [24] 2870 	push	ar6
      009259 C0 05            [24] 2871 	push	ar5
      00925B 11 77            [12] 2872 	acall	_decode_keycode
      00925D AC 82            [24] 2873 	mov	r4, dpl
      00925F AF 83            [24] 2874 	mov	r7, dph
      009261 D0 05            [24] 2875 	pop	ar5
      009263 D0 06            [24] 2876 	pop	ar6
                                   2877 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      009265 90 0C 14         [24] 2878 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009268 E0               [24] 2879 	movx	a,@dptr
      009269 FB               [12] 2880 	mov	r3,a
      00926A BB 05 03         [24] 2881 	cjne	r3,#0x05,00453$
      00926D D3               [12] 2882 	setb	c
      00926E 80 01            [24] 2883 	sjmp	00454$
      009270                       2884 00453$:
      009270 C3               [12] 2885 	clr	c
      009271                       2886 00454$:
      009271 92 25            [24] 2887 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009273 90 0A 46         [24] 2888 	mov	dptr,#_ak820_macro_primitive
      009276 B3               [12] 2889 	cpl	c
      009277 E4               [12] 2890 	clr	a
      009278 33               [12] 2891 	rlc	a
      009279 F0               [24] 2892 	movx	@dptr,a
                                   2893 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      00927A 90 0C 14         [24] 2894 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      00927D E0               [24] 2895 	movx	a,@dptr
      00927E FB               [12] 2896 	mov	r3,a
      00927F BB 05 02         [24] 2897 	cjne	r3,#0x05,00455$
      009282 80 0A            [24] 2898 	sjmp	00126$
      009284                       2899 00455$:
      009284 BB 06 02         [24] 2900 	cjne	r3,#0x06,00456$
      009287 80 15            [24] 2901 	sjmp	00127$
      009289                       2902 00456$:
                                   2903 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      009289 BB 07 30         [24] 2904 	cjne	r3,#0x07,00129$
      00928C 80 20            [24] 2905 	sjmp	00128$
      00928E                       2906 00126$:
                                   2907 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      00928E 12 48 E8         [24] 2908 	lcall	_ak820_outline_0186
      009291 C0 06            [24] 2909 	push	ar6
      009293 C0 05            [24] 2910 	push	ar5
      009295 12 B6 E0         [24] 2911 	lcall	_vial_keycode_tap
      009298 D0 05            [24] 2912 	pop	ar5
      00929A D0 06            [24] 2913 	pop	ar6
                                   2914 ;	quantum/dynamic_keymap.c:795: break;
                                   2915 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      00929C 80 1E            [24] 2916 	sjmp	00129$
      00929E                       2917 00127$:
                                   2918 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      00929E 12 48 E8         [24] 2919 	lcall	_ak820_outline_0186
      0092A1 C0 06            [24] 2920 	push	ar6
      0092A3 C0 05            [24] 2921 	push	ar5
      0092A5 12 B6 15         [24] 2922 	lcall	_vial_keycode_down
      0092A8 D0 05            [24] 2923 	pop	ar5
      0092AA D0 06            [24] 2924 	pop	ar6
                                   2925 ;	quantum/dynamic_keymap.c:798: break;
                                   2926 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0092AC 80 0E            [24] 2927 	sjmp	00129$
      0092AE                       2928 00128$:
                                   2929 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      0092AE 12 48 E8         [24] 2930 	lcall	_ak820_outline_0186
      0092B1 C0 06            [24] 2931 	push	ar6
      0092B3 C0 05            [24] 2932 	push	ar5
      0092B5 12 B6 7B         [24] 2933 	lcall	_vial_keycode_up
      0092B8 D0 05            [24] 2934 	pop	ar5
      0092BA D0 06            [24] 2935 	pop	ar6
                                   2936 ;	quantum/dynamic_keymap.c:802: }
      0092BC                       2937 00129$:
                                   2938 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0092BC 12 93 D5         [24] 2939 	lcall	_ak820_outline_0168
      0092BF 21 2B            [12] 2940 	ajmp	00167$
      0092C1                       2941 00147$:
                                   2942 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0092C1 12 93 9C         [24] 2943 	lcall	_ak820_outline_0095
      0092C4 BF 04 02         [24] 2944 	cjne	r7,#0x04,00458$
      0092C7 80 02            [24] 2945 	sjmp	00459$
      0092C9                       2946 00458$:
      0092C9 21 2B            [12] 2947 	ajmp	00167$
      0092CB                       2948 00459$:
                                   2949 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092CB 12 93 44         [24] 2950 	lcall	_ak820_outline_0000
      0092CE 12 40 2F         [24] 2951 	lcall	_eeprom_read_byte
      0092D1 AF 82            [24] 2952 	mov	r7, dpl
                                   2953 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092D3 90 0C 11         [24] 2954 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0092D6 12 38 43         [24] 2955 	lcall	_ak820_outline_0103
      0092D9 90 0C 11         [24] 2956 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0092DC 74 01            [12] 2957 	mov	a,#0x01
      0092DE 2B               [12] 2958 	add	a, r3
      0092DF F0               [24] 2959 	movx	@dptr,a
      0092E0 E4               [12] 2960 	clr	a
      0092E1 3C               [12] 2961 	addc	a, r4
      0092E2 A3               [24] 2962 	inc	dptr
      0092E3 F0               [24] 2963 	movx	@dptr,a
      0092E4 7A 00            [12] 2964 	mov	r2,#0x00
      0092E6 12 33 FC         [24] 2965 	lcall	_ak820_outline_0123
      0092E9 8A F0            [24] 2966 	mov	b, r2
      0092EB 12 40 2F         [24] 2967 	lcall	_eeprom_read_byte
      0092EE AC 82            [24] 2968 	mov	r4, dpl
                                   2969 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      0092F0 EF               [12] 2970 	mov	a,r7
      0092F1 60 49            [24] 2971 	jz	00169$
      0092F3 EC               [12] 2972 	mov	a,r4
      0092F4 60 46            [24] 2973 	jz	00169$
                                   2974 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0092F6 1F               [12] 2975 	dec	r7
      0092F7 1C               [12] 2976 	dec	r4
      0092F8 EC               [12] 2977 	mov	a,r4
      0092F9 75 F0 FF         [24] 2978 	mov	b,#0xff
      0092FC A4               [48] 2979 	mul	ab
      0092FD FC               [12] 2980 	mov	r4,a
      0092FE AB F0            [24] 2981 	mov	r3,b
      009300 7A 00            [12] 2982 	mov	r2,#0x00
      009302 EC               [12] 2983 	mov	a,r4
      009303 2F               [12] 2984 	add	a, r7
      009304 FC               [12] 2985 	mov	r4,a
      009305 EB               [12] 2986 	mov	a,r3
      009306 3A               [12] 2987 	addc	a, r2
      009307 FB               [12] 2988 	mov	r3,a
                                   2989 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      009308                       2990 00141$:
      009308 8C 02            [24] 2991 	mov	ar2,r4
      00930A 8B 07            [24] 2992 	mov	ar7,r3
      00930C 1C               [12] 2993 	dec	r4
      00930D BC FF 01         [24] 2994 	cjne	r4,#0xff,00462$
      009310 1B               [12] 2995 	dec	r3
      009311                       2996 00462$:
      009311 EA               [12] 2997 	mov	a,r2
      009312 4F               [12] 2998 	orl	a,r7
      009313 70 02            [24] 2999 	jnz	00463$
      009315 21 2B            [12] 3000 	ajmp	00167$
      009317                       3001 00463$:
      009317 90 00 01         [24] 3002 	mov	dptr,#0x0001
      00931A 12 5D 9F         [24] 3003 	lcall	_mDelaymS
      00931D 80 E9            [24] 3004 	sjmp	00141$
      00931F                       3005 00164$:
                                   3006 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      00931F 90 0C 13         [24] 3007 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009322 E0               [24] 3008 	movx	a,@dptr
      009323 FF               [12] 3009 	mov	r7,a
      009324 BF 80 00         [24] 3010 	cjne	r7,#0x80,00464$
      009327                       3011 00464$:
      009327 50 13            [24] 3012 	jnc	00169$
                                   3013 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      009329 90 0C 13         [24] 3014 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00932C E0               [24] 3015 	movx	a,@dptr
      00932D F5 82            [12] 3016 	mov	dpl,a
      00932F C0 06            [24] 3017 	push	ar6
      009331 C0 05            [24] 3018 	push	ar5
      009333 12 A8 F5         [24] 3019 	lcall	_send_char
      009336 D0 05            [24] 3020 	pop	ar5
      009338 D0 06            [24] 3021 	pop	ar6
                                   3022 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      00933A 21 2B            [12] 3023 	ajmp	00167$
      00933C                       3024 00169$:
                                   3025 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      00933C 12 93 D5         [24] 3026 	lcall	_ak820_outline_0168
                                   3027 ;	quantum/dynamic_keymap.c:837: sending = false;
      00933F 90 0C 10         [24] 3028 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009342 F0               [24] 3029 	movx	@dptr,a
                                   3030 ;	quantum/dynamic_keymap.c:839: }
      009343 22               [24] 3031 	ret
                                   3032 	.area CSEG    (CODE)
                                   3033 	.area CONST   (CODE)
                                   3034 	.area XINIT   (CODE)
                                   3035 	.area CABS    (ABS,CODE)
                                   3036 
                                   3037 ; Experimental exact instruction outlining.
                                   3038 	.globl _ak820_outline_0000
                                   3039 	.globl _ak820_outline_0006
                                   3040 	.globl _ak820_outline_0010
                                   3041 	.globl _ak820_outline_0018
                                   3042 	.globl _ak820_outline_0026
                                   3043 	.globl _ak820_outline_0036
                                   3044 	.globl _ak820_outline_0043
                                   3045 	.globl _ak820_outline_0050
                                   3046 	.globl _ak820_outline_0053
                                   3047 	.globl _ak820_outline_0058
                                   3048 	.globl _ak820_outline_0064
                                   3049 	.globl _ak820_outline_0065
                                   3050 	.globl _ak820_outline_0066
                                   3051 	.globl _ak820_outline_0075
                                   3052 	.globl _ak820_outline_0077
                                   3053 	.globl _ak820_outline_0078
                                   3054 	.globl _ak820_outline_0080
                                   3055 	.globl _ak820_outline_0081
                                   3056 	.globl _ak820_outline_0084
                                   3057 	.globl _ak820_outline_0095
                                   3058 	.globl _ak820_outline_0101
                                   3059 	.globl _ak820_outline_0102
                                   3060 	.globl _ak820_outline_0103
                                   3061 	.globl _ak820_outline_0108
                                   3062 	.globl _ak820_outline_0109
                                   3063 	.globl _ak820_outline_0113
                                   3064 	.globl _ak820_outline_0117
                                   3065 	.globl _ak820_outline_0119
                                   3066 	.globl _ak820_outline_0123
                                   3067 	.globl _ak820_outline_0125
                                   3068 	.globl _ak820_outline_0127
                                   3069 	.globl _ak820_outline_0128
                                   3070 	.globl _ak820_outline_0132
                                   3071 	.globl _ak820_outline_0136
                                   3072 	.globl _ak820_outline_0137
                                   3073 	.globl _ak820_outline_0138
                                   3074 	.globl _ak820_outline_0139
                                   3075 	.globl _ak820_outline_0143
                                   3076 	.globl _ak820_outline_0144
                                   3077 	.globl _ak820_outline_0151
                                   3078 	.globl _ak820_outline_0152
                                   3079 	.globl _ak820_outline_0154
                                   3080 	.globl _ak820_outline_0158
                                   3081 	.globl _ak820_outline_0159
                                   3082 	.globl _ak820_outline_0163
                                   3083 	.globl _ak820_outline_0168
                                   3084 	.globl _ak820_outline_0180
                                   3085 	.globl _ak820_outline_0181
                                   3086 	.globl _ak820_outline_0184
                                   3087 	.globl _ak820_outline_0185
                                   3088 	.globl _ak820_outline_0186
                                   3089 	.globl _ak820_outline_0189
                                   3090 	.globl _ak820_outline_0191
                                   3091 
                                   3092 	.area CSEG (CODE)
                                   3093 ; function ak820_outline_0000
      009344                       3094 _ak820_outline_0000:
      009344 90 0C 11         [24] 3095 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009347 E0               [24] 3096 	movx	a,@dptr
      009348 FC               [12] 3097 	mov	r4,a
      009349 A3               [24] 3098 	inc	dptr
      00934A E0               [24] 3099 	movx	a,@dptr
      00934B FF               [12] 3100 	mov	r7,a
      00934C 90 0C 11         [24] 3101 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00934F 74 01            [12] 3102 	mov	a,#0x01
      009351 2C               [12] 3103 	add	a,r4
      009352 F0               [24] 3104 	movx	@dptr,a
      009353 E4               [12] 3105 	clr	a
      009354 3F               [12] 3106 	addc	a,r7
      009355 A3               [24] 3107 	inc	dptr
      009356 F0               [24] 3108 	movx	@dptr,a
      009357 7B 00            [12] 3109 	mov	r3,#0x00
      009359 8C 82            [24] 3110 	mov	dpl,r4
      00935B 8F 83            [24] 3111 	mov	dph,r7
      00935D 8B F0            [24] 3112 	mov	b,r3
      00935F 22               [24] 3113 	ret
                                   3114 
                                   3115 	.area CSEG (CODE)
                                   3116 ; function ak820_outline_0026
      009360                       3117 _ak820_outline_0026:
      009360 2D               [12] 3118 	add	a,r5
      009361 F9               [12] 3119 	mov	r1,a
      009362 E4               [12] 3120 	clr	a
      009363 3E               [12] 3121 	addc	a,r6
      009364 FA               [12] 3122 	mov	r2,a
      009365 8F 03            [24] 3123 	mov	ar3,r7
      009367 89 82            [24] 3124 	mov	dpl,r1
      009369 8A 83            [24] 3125 	mov	dph,r2
      00936B 8B F0            [24] 3126 	mov	b,r3
      00936D 22               [24] 3127 	ret
                                   3128 
                                   3129 	.area CSEG (CODE)
                                   3130 ; function ak820_outline_0043
      00936E                       3131 _ak820_outline_0043:
      00936E 90 0E 6F         [24] 3132 	mov	dptr,#_memset_PARM_2
      009371 E4               [12] 3133 	clr	a
      009372 F0               [24] 3134 	movx	@dptr,a
      009373 90 0E 70         [24] 3135 	mov	dptr,#_memset_PARM_3
      009376 74 0A            [12] 3136 	mov	a,#0x0a
      009378 F0               [24] 3137 	movx	@dptr,a
      009379 E4               [12] 3138 	clr	a
      00937A A3               [24] 3139 	inc	dptr
      00937B F0               [24] 3140 	movx	@dptr,a
      00937C 8E 82            [24] 3141 	mov	dpl,r6
      00937E 8F 83            [24] 3142 	mov	dph,r7
      009380 8D F0            [24] 3143 	mov	b,r5
      009382 22               [24] 3144 	ret
                                   3145 
                                   3146 	.area CSEG (CODE)
                                   3147 ; function ak820_outline_0053
      009383                       3148 _ak820_outline_0053:
      009383 2E               [12] 3149 	add	a,r6
      009384 FC               [12] 3150 	mov	r4,a
      009385 E4               [12] 3151 	clr	a
      009386 3F               [12] 3152 	addc	a,r7
      009387 FD               [12] 3153 	mov	r5,a
      009388 8C 82            [24] 3154 	mov	dpl,r4
      00938A 8D 83            [24] 3155 	mov	dph,r5
      00938C E0               [24] 3156 	movx	a,@dptr
      00938D 22               [24] 3157 	ret
                                   3158 
                                   3159 	.area CSEG (CODE)
                                   3160 ; function ak820_outline_0084
      00938E                       3161 _ak820_outline_0084:
      00938E ED               [12] 3162 	mov	a,r5
      00938F 75 F0 0A         [24] 3163 	mov	b,#0x0a
      009392 A4               [48] 3164 	mul	ab
      009393 24 58            [12] 3165 	add	a,#0x58
      009395 FC               [12] 3166 	mov	r4,a
      009396 74 06            [12] 3167 	mov	a,#0x06
      009398 35 F0            [12] 3168 	addc	a,b
      00939A FD               [12] 3169 	mov	r5,a
      00939B 22               [24] 3170 	ret
                                   3171 
                                   3172 	.area CSEG (CODE)
                                   3173 ; function ak820_outline_0095
      00939C                       3174 _ak820_outline_0095:
      00939C 90 0C 14         [24] 3175 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0001)
      00939F E0               [24] 3176 	movx	a,@dptr
      0093A0 FF               [12] 3177 	mov	r7,a
      0093A1 22               [24] 3178 	ret
                                   3179 
                                   3180 	.area CSEG (CODE)
                                   3181 ; function ak820_outline_0101
      0093A2                       3182 _ak820_outline_0101:
      0093A2 90 0B 98         [24] 3183 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0093A5 EE               [12] 3184 	mov	a,r6
      0093A6 F0               [24] 3185 	movx	@dptr,a
      0093A7 90 0B 99         [24] 3186 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0093AA ED               [12] 3187 	mov	a,r5
      0093AB F0               [24] 3188 	movx	@dptr,a
      0093AC 8F 82            [24] 3189 	mov	dpl,r7
      0093AE 22               [24] 3190 	ret
                                   3191 
                                   3192 	.area CSEG (CODE)
                                   3193 ; function ak820_outline_0113
      0093AF                       3194 _ak820_outline_0113:
      0093AF 74 0A            [12] 3195 	mov	a,#0x0a
      0093B1 F0               [24] 3196 	movx	@dptr,a
      0093B2 E4               [12] 3197 	clr	a
      0093B3 A3               [24] 3198 	inc	dptr
      0093B4 F0               [24] 3199 	movx	@dptr,a
      0093B5 22               [24] 3200 	ret
                                   3201 
                                   3202 	.area CSEG (CODE)
                                   3203 ; function ak820_outline_0117
      0093B6                       3204 _ak820_outline_0117:
      0093B6 AD 82            [24] 3205 	mov	r5,dpl
      0093B8 AE 83            [24] 3206 	mov	r6,dph
      0093BA AF F0            [24] 3207 	mov	r7,b
      0093BC 22               [24] 3208 	ret
                                   3209 
                                   3210 	.area CSEG (CODE)
                                   3211 ; function ak820_outline_0132
      0093BD                       3212 _ak820_outline_0132:
      0093BD 28               [12] 3213 	add	a,r0
      0093BE F5 82            [12] 3214 	mov	dpl,a
      0093C0 EF               [12] 3215 	mov	a,r7
      0093C1 39               [12] 3216 	addc	a,r1
      0093C2 F5 83            [12] 3217 	mov	dph,a
      0093C4 74 FF            [12] 3218 	mov	a,#0xff
      0093C6 F0               [24] 3219 	movx	@dptr,a
      0093C7 22               [24] 3220 	ret
                                   3221 
                                   3222 	.area CSEG (CODE)
                                   3223 ; function ak820_outline_0139
      0093C8                       3224 _ak820_outline_0139:
      0093C8 2D               [12] 3225 	add	a,r5
      0093C9 F9               [12] 3226 	mov	r1,a
      0093CA E4               [12] 3227 	clr	a
      0093CB 3E               [12] 3228 	addc	a,r6
      0093CC FA               [12] 3229 	mov	r2,a
      0093CD 22               [24] 3230 	ret
                                   3231 
                                   3232 	.area CSEG (CODE)
                                   3233 ; function ak820_outline_0154
      0093CE                       3234 _ak820_outline_0154:
      0093CE 90 0C 15         [24] 3235 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      0093D1 E0               [24] 3236 	movx	a,@dptr
      0093D2 F5 82            [12] 3237 	mov	dpl,a
      0093D4 22               [24] 3238 	ret
                                   3239 
                                   3240 	.area CSEG (CODE)
                                   3241 ; function ak820_outline_0168
      0093D5                       3242 _ak820_outline_0168:
      0093D5 90 0A 46         [24] 3243 	mov	dptr,#_ak820_macro_primitive
      0093D8 E4               [12] 3244 	clr	a
      0093D9 F0               [24] 3245 	movx	@dptr,a
      0093DA 22               [24] 3246 	ret
                                   3247 
                                   3248 	.area CSEG (CODE)
                                   3249 ; function ak820_outline_0180
      0093DB                       3250 _ak820_outline_0180:
      0093DB 90 0B A8         [24] 3251 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0093DE E4               [12] 3252 	clr	a
      0093DF F0               [24] 3253 	movx	@dptr,a
      0093E0 90 0B A9         [24] 3254 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0093E3 22               [24] 3255 	ret
                                   3256 
                                   3257 	.area CSEG (CODE)
                                   3258 ; function ak820_outline_0181
      0093E4                       3259 _ak820_outline_0181:
      0093E4 90 0C 70         [24] 3260 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0093E7 E4               [12] 3261 	clr	a
      0093E8 F0               [24] 3262 	movx	@dptr,a
      0093E9 90 0C 71         [24] 3263 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0093EC 22               [24] 3264 	ret
                                   3265 
                                   3266 	.area CSEG (CODE)
                                   3267 ; function ak820_outline_0184
      0093ED                       3268 _ak820_outline_0184:
      0093ED AF 82            [24] 3269 	mov	r7,dpl
      0093EF 90 0C 15         [24] 3270 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      0093F2 EF               [12] 3271 	mov	a,r7
      0093F3 F0               [24] 3272 	movx	@dptr,a
      0093F4 EF               [12] 3273 	mov	a,r7
      0093F5 22               [24] 3274 	ret
