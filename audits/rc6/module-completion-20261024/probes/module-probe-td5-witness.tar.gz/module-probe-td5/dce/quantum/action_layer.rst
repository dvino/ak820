                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _ak820_keycode_at
                                     14 	.globl _action_for_keycode
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _layer_state
                                    259 	.globl _default_layer_state
                                    260 	.globl _ak820_resolve_key_PARM_2
                                    261 	.globl _ak820_cache_layer_PARM_2
                                    262 	.globl _ak820_cache_keycode_PARM_2
                                    263 	.globl _default_layer_state_set_user
                                    264 	.globl _default_layer_state_set_kb
                                    265 	.globl _default_layer_set
                                    266 	.globl _default_layer_or
                                    267 	.globl _default_layer_and
                                    268 	.globl _default_layer_xor
                                    269 	.globl _ak820_layer_refresh
                                    270 	.globl _layer_hold_on
                                    271 	.globl _layer_hold_off
                                    272 	.globl _layer_hold_clear
                                    273 	.globl _layer_state_set_user
                                    274 	.globl _layer_state_set_kb
                                    275 	.globl _layer_state_set
                                    276 	.globl _layer_clear
                                    277 	.globl _layer_move
                                    278 	.globl _layer_on
                                    279 	.globl _layer_off
                                    280 	.globl _layer_or
                                    281 	.globl _layer_and
                                    282 	.globl _layer_xor
                                    283 	.globl _ak820_cache_keycode
                                    284 	.globl _ak820_cache_layer
                                    285 	.globl _ak820_cached_key
                                    286 	.globl _ak820_resolve_key
                                    287 	.globl _ak820_layer_for_key
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
                                    566 ;--------------------------------------------------------
                                    567 ; paged external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area PSEG    (PAG,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; uninitialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XSEG    (XDATA)
      000902                        574 _default_layer_state_set_user_state_10000_317:
      000902                        575 	.ds 1
      000903                        576 _default_layer_state_set_kb_state_10000_319:
      000903                        577 	.ds 1
      000904                        578 _default_layer_state_set_state_10000_321:
      000904                        579 	.ds 1
      000905                        580 _default_layer_set_state_10000_326:
      000905                        581 	.ds 1
      000906                        582 _default_layer_or_state_10000_328:
      000906                        583 	.ds 1
      000907                        584 _default_layer_and_state_10000_330:
      000907                        585 	.ds 1
      000908                        586 _default_layer_xor_state_10000_332:
      000908                        587 	.ds 1
      000909                        588 _persistent_layers:
      000909                        589 	.ds 1
      00090A                        590 _layer_refs:
      00090A                        591 	.ds 6
      000910                        592 _macro_layers:
      000910                        593 	.ds 1
      000911                        594 _ak820_layer_refresh_state_10000_335:
      000911                        595 	.ds 1
      000912                        596 _layer_hold_on_layer_10000_338:
      000912                        597 	.ds 1
      000913                        598 _layer_hold_off_layer_10000_342:
      000913                        599 	.ds 1
      000914                        600 _layer_state_set_user_state_10000_349:
      000914                        601 	.ds 1
      000915                        602 _layer_state_set_kb_state_10000_351:
      000915                        603 	.ds 1
      000916                        604 _layer_state_set_state_10000_353:
      000916                        605 	.ds 1
      000917                        606 _layer_move_layer_10000_366:
      000917                        607 	.ds 1
      000918                        608 _layer_on_layer_10000_368:
      000918                        609 	.ds 1
      000919                        610 _layer_off_layer_10000_370:
      000919                        611 	.ds 1
      00091A                        612 _layer_or_state_10000_374:
      00091A                        613 	.ds 1
      00091B                        614 _layer_and_state_10000_376:
      00091B                        615 	.ds 1
      00091C                        616 _layer_xor_state_10000_378:
      00091C                        617 	.ds 1
      00091D                        618 _source_keycodes_cache:
      00091D                        619 	.ds 256
      000A1D                        620 _encoder_source_keycodes_cache:
      000A1D                        621 	.ds 4
      000A21                        622 _source_keycode_cache_slot_position_10000_380:
      000A21                        623 	.ds 2
      000A23                        624 _ak820_cache_keycode_PARM_2:
      000A23                        625 	.ds 2
      000A25                        626 _ak820_cache_keycode_position_10000_386:
      000A25                        627 	.ds 2
      000A27                        628 _ak820_cache_layer_PARM_2:
      000A27                        629 	.ds 1
      000A28                        630 _ak820_cache_layer_position_10000_389:
      000A28                        631 	.ds 2
      000A2A                        632 _ak820_cached_key_position_10000_392:
      000A2A                        633 	.ds 2
      000A2C                        634 _ak820_resolve_key_PARM_2:
      000A2C                        635 	.ds 1
      000A2D                        636 _ak820_resolve_key_position_10000_403:
      000A2D                        637 	.ds 2
      000A2F                        638 _ak820_layer_for_key_position_10000_410:
      000A2F                        639 	.ds 2
      000A31                        640 _ak820_layer_for_key_layers_10000_411:
      000A31                        641 	.ds 1
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
      000E88                        650 _default_layer_state::
      000E88                        651 	.ds 1
      000E89                        652 _layer_state::
      000E89                        653 	.ds 1
                                    654 	.area HOME    (CODE)
                                    655 	.area GSINIT0 (CODE)
                                    656 	.area GSINIT1 (CODE)
                                    657 	.area GSINIT2 (CODE)
                                    658 	.area GSINIT3 (CODE)
                                    659 	.area GSINIT4 (CODE)
                                    660 	.area GSINIT5 (CODE)
                                    661 	.area GSINIT  (CODE)
                                    662 	.area GSFINAL (CODE)
                                    663 	.area CSEG    (CODE)
                                    664 ;--------------------------------------------------------
                                    665 ; global & static initialisations
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; Home
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area HOME    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; code
                                    678 ;--------------------------------------------------------
                                    679 	.area CSEG    (CODE)
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    682 ;------------------------------------------------------------
                                    683 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_190'
                                    684 ;------------------------------------------------------------
                                    685 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    686 ;	-----------------------------------------
                           000007   687 	ar7 = 0x07
                           000006   688 	ar6 = 0x06
                           000005   689 	ar5 = 0x05
                           000004   690 	ar4 = 0x04
                           000003   691 	ar3 = 0x03
                           000002   692 	ar2 = 0x02
                           000001   693 	ar1 = 0x01
                           000000   694 	ar0 = 0x00
                                    695 ;	 function default_layer_state_set_user
                                    696 ;	-----------------------------------------
      007B91                        697 _default_layer_state_set_user:
      007B91 E5 82            [12]  698 	mov	a,dpl
      007B93 90 09 02         [24]  699 	mov	dptr,#_default_layer_state_set_user_state_10000_317
      007B96 12 5B FC         [24]  700 	lcall	_ak820_outline_0174
                                    701 ;	quantum/action_layer.c:32: return state;
                                    702 ;	quantum/action_layer.c:33: }
      007B99 22               [24]  703 	ret
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    706 ;------------------------------------------------------------
                                    707 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_319'
                                    708 ;------------------------------------------------------------
                                    709 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    710 ;	-----------------------------------------
                                    711 ;	 function default_layer_state_set_kb
                                    712 ;	-----------------------------------------
      007B9A                        713 _default_layer_state_set_kb:
      007B9A E5 82            [12]  714 	mov	a,dpl
      007B9C 90 09 03         [24]  715 	mov	dptr,#_default_layer_state_set_kb_state_10000_319
      007B9F 12 5B FC         [24]  716 	lcall	_ak820_outline_0174
                                    717 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    718 ;	quantum/action_layer.c:41: }
      007BA2 61 91            [12]  719 	ajmp	_default_layer_state_set_user
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'default_layer_state_set'
                                    722 ;------------------------------------------------------------
                                    723 ;state         Allocated with name '_default_layer_state_set_state_10000_321'
                                    724 ;------------------------------------------------------------
                                    725 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    726 ;	-----------------------------------------
                                    727 ;	 function default_layer_state_set
                                    728 ;	-----------------------------------------
      007BA4                        729 _default_layer_state_set:
      007BA4 E5 82            [12]  730 	mov	a,dpl
      007BA6 90 09 04         [24]  731 	mov	dptr,#_default_layer_state_set_state_10000_321
      007BA9 12 5B FC         [24]  732 	lcall	_ak820_outline_0174
                                    733 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      007BAC 71 9A            [12]  734 	acall	_default_layer_state_set_kb
      007BAE AF 82            [24]  735 	mov	r7, dpl
      007BB0 90 09 04         [24]  736 	mov	dptr,#_default_layer_state_set_state_10000_321
      007BB3 EF               [12]  737 	mov	a,r7
      007BB4 F0               [24]  738 	movx	@dptr,a
                                    739 ;	quantum/action_layer.c:52: default_layer_state = state;
      007BB5 90 0E 88         [24]  740 	mov	dptr,#_default_layer_state
      007BB8 EF               [12]  741 	mov	a,r7
      007BB9 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    744 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    745 ;	quantum/action_layer.c:63: }
      007BBA 61 FD            [12]  746 	ajmp	_ak820_layer_refresh
                                    747 ;------------------------------------------------------------
                                    748 ;Allocation info for local variables in function 'default_layer_set'
                                    749 ;------------------------------------------------------------
                                    750 ;state         Allocated with name '_default_layer_set_state_10000_326'
                                    751 ;------------------------------------------------------------
                                    752 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function default_layer_set
                                    755 ;	-----------------------------------------
      007BBC                        756 _default_layer_set:
      007BBC E5 82            [12]  757 	mov	a,dpl
      007BBE 90 09 05         [24]  758 	mov	dptr,#_default_layer_set_state_10000_326
      007BC1 12 5B FC         [24]  759 	lcall	_ak820_outline_0174
                                    760 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    761 ;	quantum/action_layer.c:81: }
      007BC4 61 A4            [12]  762 	ajmp	_default_layer_state_set
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'default_layer_or'
                                    765 ;------------------------------------------------------------
                                    766 ;state         Allocated with name '_default_layer_or_state_10000_328'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function default_layer_or
                                    771 ;	-----------------------------------------
      007BC6                        772 _default_layer_or:
      007BC6 E5 82            [12]  773 	mov	a,dpl
      007BC8 90 09 06         [24]  774 	mov	dptr,#_default_layer_or_state_10000_328
      007BCB F0               [24]  775 	movx	@dptr,a
                                    776 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      007BCC E0               [24]  777 	movx	a,@dptr
      007BCD FF               [12]  778 	mov	r7,a
      007BCE 90 0E 88         [24]  779 	mov	dptr,#_default_layer_state
      007BD1 12 7F 78         [24]  780 	lcall	_ak820_outline_0142
                                    781 ;	quantum/action_layer.c:90: }
      007BD4 61 A4            [12]  782 	ajmp	_default_layer_state_set
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'default_layer_and'
                                    785 ;------------------------------------------------------------
                                    786 ;state         Allocated with name '_default_layer_and_state_10000_330'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function default_layer_and
                                    791 ;	-----------------------------------------
      007BD6                        792 _default_layer_and:
      007BD6 E5 82            [12]  793 	mov	a,dpl
      007BD8 90 09 07         [24]  794 	mov	dptr,#_default_layer_and_state_10000_330
      007BDB F0               [24]  795 	movx	@dptr,a
                                    796 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      007BDC 90 0E 88         [24]  797 	mov	dptr,#_default_layer_state
      007BDF E0               [24]  798 	movx	a,@dptr
      007BE0 FF               [12]  799 	mov	r7,a
      007BE1 90 09 07         [24]  800 	mov	dptr,#_default_layer_and_state_10000_330
      007BE4 E0               [24]  801 	movx	a,@dptr
      007BE5 52 07            [12]  802 	anl	ar7,a
      007BE7 8F 82            [24]  803 	mov	dpl, r7
                                    804 ;	quantum/action_layer.c:97: }
      007BE9 61 A4            [12]  805 	ajmp	_default_layer_state_set
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'default_layer_xor'
                                    808 ;------------------------------------------------------------
                                    809 ;state         Allocated with name '_default_layer_xor_state_10000_332'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function default_layer_xor
                                    814 ;	-----------------------------------------
      007BEB                        815 _default_layer_xor:
      007BEB E5 82            [12]  816 	mov	a,dpl
      007BED 90 09 08         [24]  817 	mov	dptr,#_default_layer_xor_state_10000_332
      007BF0 F0               [24]  818 	movx	@dptr,a
                                    819 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      007BF1 E0               [24]  820 	movx	a,@dptr
      007BF2 FF               [12]  821 	mov	r7,a
      007BF3 90 0E 88         [24]  822 	mov	dptr,#_default_layer_state
      007BF6 E0               [24]  823 	movx	a,@dptr
      007BF7 62 07            [12]  824 	xrl	ar7,a
      007BF9 8F 82            [24]  825 	mov	dpl, r7
                                    826 ;	quantum/action_layer.c:104: }
      007BFB 61 A4            [12]  827 	ajmp	_default_layer_state_set
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    830 ;------------------------------------------------------------
                                    831 ;state         Allocated with name '_ak820_layer_refresh_state_10000_335'
                                    832 ;i             Allocated with name '_ak820_layer_refresh_i_20000_336'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function ak820_layer_refresh
                                    837 ;	-----------------------------------------
      007BFD                        838 _ak820_layer_refresh:
                                    839 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      007BFD 90 09 09         [24]  840 	mov	dptr,#_persistent_layers
      007C00 E0               [24]  841 	movx	a,@dptr
      007C01 90 09 11         [24]  842 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007C04 F0               [24]  843 	movx	@dptr,a
                                    844 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      007C05 7F 00            [12]  845 	mov	r7,#0x00
      007C07                        846 00105$:
      007C07 BF 06 00         [24]  847 	cjne	r7,#0x06,00131$
      007C0A                        848 00131$:
      007C0A 50 25            [24]  849 	jnc	00103$
      007C0C EF               [12]  850 	mov	a,r7
      007C0D 24 0A            [12]  851 	add	a, #_layer_refs
      007C0F FD               [12]  852 	mov	r5,a
      007C10 E4               [12]  853 	clr	a
      007C11 34 09            [12]  854 	addc	a, #(_layer_refs >> 8)
      007C13 FE               [12]  855 	mov	r6,a
      007C14 12 38 63         [24]  856 	lcall	_ak820_outline_0138
      007C17 E0               [24]  857 	movx	a,@dptr
      007C18 60 14            [24]  858 	jz	00106$
      007C1A 8F F0            [24]  859 	mov	b,r7
      007C1C 05 F0            [12]  860 	inc	b
      007C1E 74 01            [12]  861 	mov	a,#0x01
      007C20 80 02            [24]  862 	sjmp	00135$
      007C22                        863 00134$:
      007C22 25 E0            [12]  864 	add	a,acc
      007C24                        865 00135$:
      007C24 D5 F0 FB         [24]  866 	djnz	b,00134$
      007C27 FE               [12]  867 	mov	r6,a
      007C28 90 09 11         [24]  868 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007C2B E0               [24]  869 	movx	a,@dptr
      007C2C 4E               [12]  870 	orl	a,r6
      007C2D F0               [24]  871 	movx	@dptr,a
      007C2E                        872 00106$:
      007C2E 0F               [12]  873 	inc	r7
      007C2F 80 D6            [24]  874 	sjmp	00105$
      007C31                        875 00103$:
                                    876 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      007C31 90 0E 88         [24]  877 	mov	dptr,#_default_layer_state
      007C34 E0               [24]  878 	movx	a,@dptr
      007C35 FF               [12]  879 	mov	r7,a
      007C36 90 09 11         [24]  880 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007C39 E0               [24]  881 	movx	a,@dptr
      007C3A FE               [12]  882 	mov	r6,a
      007C3B 42 07            [12]  883 	orl	ar7,a
      007C3D 8F 82            [24]  884 	mov	dpl, r7
      007C3F C0 06            [24]  885 	push	ar6
      007C41 12 A9 8B         [24]  886 	lcall	_ak820_tri_layer_derived
      007C44 AF 82            [24]  887 	mov	r7, dpl
      007C46 D0 06            [24]  888 	pop	ar6
      007C48 90 09 11         [24]  889 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007C4B EF               [12]  890 	mov	a,r7
      007C4C 4E               [12]  891 	orl	a,r6
      007C4D 12 5B FC         [24]  892 	lcall	_ak820_outline_0174
                                    893 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      007C50 91 E8            [24]  894 	acall	_layer_state_set_kb
      007C52 E5 82            [12]  895 	mov	a, dpl
      007C54 90 0E 89         [24]  896 	mov	dptr,#_layer_state
      007C57 F0               [24]  897 	movx	@dptr,a
                                    898 ;	quantum/action_layer.c:121: }
      007C58 22               [24]  899 	ret
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'layer_hold_on'
                                    902 ;------------------------------------------------------------
                                    903 ;layer         Allocated with name '_layer_hold_on_layer_10000_338'
                                    904 ;------------------------------------------------------------
                                    905 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    906 ;	-----------------------------------------
                                    907 ;	 function layer_hold_on
                                    908 ;	-----------------------------------------
      007C59                        909 _layer_hold_on:
      007C59 E5 82            [12]  910 	mov	a,dpl
      007C5B 90 09 12         [24]  911 	mov	dptr,#_layer_hold_on_layer_10000_338
      007C5E F0               [24]  912 	movx	@dptr,a
      007C5F E0               [24]  913 	movx	a,@dptr
      007C60 FF               [12]  914 	mov	r7,a
      007C61 BF 06 00         [24]  915 	cjne	r7,#0x06,00120$
      007C64                        916 00120$:
      007C64 50 28            [24]  917 	jnc	00104$
      007C66 12 7F 84         [24]  918 	lcall	_ak820_outline_0179
      007C69 74 01            [12]  919 	mov	a,#0x01
      007C6B F0               [24]  920 	movx	@dptr,a
      007C6C 90 09 10         [24]  921 	mov	dptr,#_macro_layers
      007C6F C0 07            [24]  922 	push	ar7
      007C71 F1 8D            [12]  923 	acall	_ak820_macro_change
      007C73 E5 82            [12]  924 	mov	a, dpl
      007C75 D0 07            [24]  925 	pop	ar7
      007C77 60 15            [24]  926 	jz	00104$
      007C79 EF               [12]  927 	mov	a,r7
      007C7A 24 0A            [12]  928 	add	a, #_layer_refs
      007C7C FF               [12]  929 	mov	r7,a
      007C7D E4               [12]  930 	clr	a
      007C7E 34 09            [12]  931 	addc	a, #(_layer_refs >> 8)
      007C80 FE               [12]  932 	mov	r6,a
      007C81 12 43 3C         [24]  933 	lcall	_ak820_outline_0160
      007C84 E0               [24]  934 	movx	a,@dptr
      007C85 FD               [12]  935 	mov	r5,a
      007C86 0D               [12]  936 	inc	r5
      007C87 12 43 3C         [24]  937 	lcall	_ak820_outline_0160
      007C8A ED               [12]  938 	mov	a,r5
      007C8B F0               [24]  939 	movx	@dptr,a
      007C8C 61 FD            [12]  940 	ajmp	_ak820_layer_refresh
      007C8E                        941 00104$:
      007C8E 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'layer_hold_off'
                                    945 ;------------------------------------------------------------
                                    946 ;layer         Allocated with name '_layer_hold_off_layer_10000_342'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    949 ;	-----------------------------------------
                                    950 ;	 function layer_hold_off
                                    951 ;	-----------------------------------------
      007C8F                        952 _layer_hold_off:
      007C8F E5 82            [12]  953 	mov	a,dpl
      007C91 90 09 13         [24]  954 	mov	dptr,#_layer_hold_off_layer_10000_342
      007C94 F0               [24]  955 	movx	@dptr,a
      007C95 E0               [24]  956 	movx	a,@dptr
      007C96 FF               [12]  957 	mov	r7,a
      007C97 BF 06 00         [24]  958 	cjne	r7,#0x06,00128$
      007C9A                        959 00128$:
      007C9A 50 28            [24]  960 	jnc	00105$
      007C9C 12 7F 84         [24]  961 	lcall	_ak820_outline_0179
      007C9F E4               [12]  962 	clr	a
      007CA0 F0               [24]  963 	movx	@dptr,a
      007CA1 90 09 10         [24]  964 	mov	dptr,#_macro_layers
      007CA4 C0 07            [24]  965 	push	ar7
      007CA6 F1 8D            [12]  966 	acall	_ak820_macro_change
      007CA8 E5 82            [12]  967 	mov	a, dpl
      007CAA D0 07            [24]  968 	pop	ar7
      007CAC 60 16            [24]  969 	jz	00105$
      007CAE EF               [12]  970 	mov	a,r7
      007CAF 24 0A            [12]  971 	add	a, #_layer_refs
      007CB1 FE               [12]  972 	mov	r6,a
      007CB2 E4               [12]  973 	clr	a
      007CB3 34 09            [12]  974 	addc	a, #(_layer_refs >> 8)
      007CB5 FF               [12]  975 	mov	r7,a
      007CB6 12 38 30         [24]  976 	lcall	_ak820_outline_0094
      007CB9 FD               [12]  977 	mov	r5,a
      007CBA 60 08            [24]  978 	jz	00105$
      007CBC 1D               [12]  979 	dec	r5
      007CBD 12 43 17         [24]  980 	lcall	_ak820_outline_0119
      007CC0 ED               [12]  981 	mov	a,r5
      007CC1 F0               [24]  982 	movx	@dptr,a
      007CC2 61 FD            [12]  983 	ajmp	_ak820_layer_refresh
      007CC4                        984 00105$:
      007CC4 22               [24]  985 	ret
                                    986 ;------------------------------------------------------------
                                    987 ;Allocation info for local variables in function 'layer_hold_clear'
                                    988 ;------------------------------------------------------------
                                    989 ;i             Allocated with name '_layer_hold_clear_i_20000_348'
                                    990 ;------------------------------------------------------------
                                    991 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                    992 ;	-----------------------------------------
                                    993 ;	 function layer_hold_clear
                                    994 ;	-----------------------------------------
      007CC5                        995 _layer_hold_clear:
      007CC5 90 09 10         [24]  996 	mov	dptr,#_macro_layers
      007CC8 E4               [12]  997 	clr	a
      007CC9 F0               [24]  998 	movx	@dptr,a
      007CCA FF               [12]  999 	mov	r7,a
      007CCB                       1000 00103$:
      007CCB BF 06 00         [24] 1001 	cjne	r7,#0x06,00122$
      007CCE                       1002 00122$:
      007CCE 50 0D            [24] 1003 	jnc	00101$
      007CD0 EF               [12] 1004 	mov	a,r7
      007CD1 24 0A            [12] 1005 	add	a, #_layer_refs
      007CD3 F5 82            [12] 1006 	mov	dpl,a
      007CD5 E4               [12] 1007 	clr	a
      007CD6 34 09            [12] 1008 	addc	a, #(_layer_refs >> 8)
      007CD8 12 7F 7E         [24] 1009 	lcall	_ak820_outline_0166
      007CDB 80 EE            [24] 1010 	sjmp	00103$
      007CDD                       1011 00101$:
      007CDD 61 FD            [12] 1012 	ajmp	_ak820_layer_refresh
                                   1013 ;------------------------------------------------------------
                                   1014 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1015 ;------------------------------------------------------------
                                   1016 ;state         Allocated with name '_layer_state_set_user_state_10000_349'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function layer_state_set_user
                                   1021 ;	-----------------------------------------
      007CDF                       1022 _layer_state_set_user:
      007CDF E5 82            [12] 1023 	mov	a,dpl
      007CE1 90 09 14         [24] 1024 	mov	dptr,#_layer_state_set_user_state_10000_349
      007CE4 12 5B FC         [24] 1025 	lcall	_ak820_outline_0174
                                   1026 ;	quantum/action_layer.c:132: return state;
                                   1027 ;	quantum/action_layer.c:133: }
      007CE7 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1031 ;------------------------------------------------------------
                                   1032 ;state         Allocated with name '_layer_state_set_kb_state_10000_351'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function layer_state_set_kb
                                   1037 ;	-----------------------------------------
      007CE8                       1038 _layer_state_set_kb:
      007CE8 E5 82            [12] 1039 	mov	a,dpl
      007CEA 90 09 15         [24] 1040 	mov	dptr,#_layer_state_set_kb_state_10000_351
      007CED 12 5B FC         [24] 1041 	lcall	_ak820_outline_0174
                                   1042 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1043 ;	quantum/action_layer.c:141: }
      007CF0 81 DF            [24] 1044 	ajmp	_layer_state_set_user
                                   1045 ;------------------------------------------------------------
                                   1046 ;Allocation info for local variables in function 'layer_state_set'
                                   1047 ;------------------------------------------------------------
                                   1048 ;state         Allocated with name '_layer_state_set_state_10000_353'
                                   1049 ;------------------------------------------------------------
                                   1050 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1051 ;	-----------------------------------------
                                   1052 ;	 function layer_state_set
                                   1053 ;	-----------------------------------------
      007CF2                       1054 _layer_state_set:
      007CF2 E5 82            [12] 1055 	mov	a,dpl
      007CF4 90 09 16         [24] 1056 	mov	dptr,#_layer_state_set_state_10000_353
      007CF7 F0               [24] 1057 	movx	@dptr,a
                                   1058 ;	quantum/action_layer.c:149: persistent_layers = state;
      007CF8 E0               [24] 1059 	movx	a,@dptr
      007CF9 90 09 09         [24] 1060 	mov	dptr,#_persistent_layers
      007CFC F0               [24] 1061 	movx	@dptr,a
                                   1062 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1063 ;	quantum/action_layer.c:151: return;
                                   1064 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1065 ;	quantum/action_layer.c:165: }
      007CFD 61 FD            [12] 1066 	ajmp	_ak820_layer_refresh
                                   1067 ;------------------------------------------------------------
                                   1068 ;Allocation info for local variables in function 'layer_clear'
                                   1069 ;------------------------------------------------------------
                                   1070 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1071 ;	-----------------------------------------
                                   1072 ;	 function layer_clear
                                   1073 ;	-----------------------------------------
      007CFF                       1074 _layer_clear:
                                   1075 ;	quantum/action_layer.c:172: layer_state_set(0);
      007CFF 75 82 00         [24] 1076 	mov	dpl, #0x00
                                   1077 ;	quantum/action_layer.c:173: }
      007D02 81 F2            [24] 1078 	ajmp	_layer_state_set
                                   1079 ;------------------------------------------------------------
                                   1080 ;Allocation info for local variables in function 'layer_state_is'
                                   1081 ;------------------------------------------------------------
                                   1082 ;layer         Allocated with name '_layer_state_is_layer_10000_360'
                                   1083 ;------------------------------------------------------------
                                   1084 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1085 ;	-----------------------------------------
                                   1086 ;	 function layer_move
                                   1087 ;	-----------------------------------------
      007D04                       1088 _layer_move:
      007D04 E5 82            [12] 1089 	mov	a,dpl
      007D06 90 09 17         [24] 1090 	mov	dptr,#_layer_move_layer_10000_366
      007D09 F0               [24] 1091 	movx	@dptr,a
                                   1092 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      007D0A E0               [24] 1093 	movx	a,@dptr
      007D0B 12 7B 50         [24] 1094 	lcall	_ak820_outline_0068
      007D0E 80 02            [24] 1095 	sjmp	00104$
      007D10                       1096 00103$:
      007D10 25 E0            [12] 1097 	add	a,acc
      007D12                       1098 00104$:
      007D12 D5 F0 FB         [24] 1099 	djnz	b,00103$
      007D15 F5 82            [12] 1100 	mov	dpl,a
                                   1101 ;	quantum/action_layer.c:200: }
      007D17 81 F2            [24] 1102 	ajmp	_layer_state_set
                                   1103 ;------------------------------------------------------------
                                   1104 ;Allocation info for local variables in function 'layer_on'
                                   1105 ;------------------------------------------------------------
                                   1106 ;layer         Allocated with name '_layer_on_layer_10000_368'
                                   1107 ;------------------------------------------------------------
                                   1108 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1109 ;	-----------------------------------------
                                   1110 ;	 function layer_on
                                   1111 ;	-----------------------------------------
      007D19                       1112 _layer_on:
      007D19 E5 82            [12] 1113 	mov	a,dpl
      007D1B 90 09 18         [24] 1114 	mov	dptr,#_layer_on_layer_10000_368
      007D1E F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      007D1F E0               [24] 1117 	movx	a,@dptr
      007D20 12 7B 50         [24] 1118 	lcall	_ak820_outline_0068
      007D23 80 02            [24] 1119 	sjmp	00104$
      007D25                       1120 00103$:
      007D25 25 E0            [12] 1121 	add	a,acc
      007D27                       1122 00104$:
      007D27 D5 F0 FB         [24] 1123 	djnz	b,00103$
      007D2A FF               [12] 1124 	mov	r7,a
      007D2B 90 09 09         [24] 1125 	mov	dptr,#_persistent_layers
      007D2E 12 7F 78         [24] 1126 	lcall	_ak820_outline_0142
                                   1127 ;	quantum/action_layer.c:214: }
      007D31 81 F2            [24] 1128 	ajmp	_layer_state_set
                                   1129 ;------------------------------------------------------------
                                   1130 ;Allocation info for local variables in function 'layer_off'
                                   1131 ;------------------------------------------------------------
                                   1132 ;layer         Allocated with name '_layer_off_layer_10000_370'
                                   1133 ;------------------------------------------------------------
                                   1134 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1135 ;	-----------------------------------------
                                   1136 ;	 function layer_off
                                   1137 ;	-----------------------------------------
      007D33                       1138 _layer_off:
      007D33 E5 82            [12] 1139 	mov	a,dpl
      007D35 90 09 19         [24] 1140 	mov	dptr,#_layer_off_layer_10000_370
      007D38 F0               [24] 1141 	movx	@dptr,a
                                   1142 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      007D39 E0               [24] 1143 	movx	a,@dptr
      007D3A 12 7B 50         [24] 1144 	lcall	_ak820_outline_0068
      007D3D 80 02            [24] 1145 	sjmp	00104$
      007D3F                       1146 00103$:
      007D3F 25 E0            [12] 1147 	add	a,acc
      007D41                       1148 00104$:
      007D41 D5 F0 FB         [24] 1149 	djnz	b,00103$
      007D44 F4               [12] 1150 	cpl	a
      007D45 FF               [12] 1151 	mov	r7,a
      007D46 90 09 09         [24] 1152 	mov	dptr,#_persistent_layers
      007D49 E0               [24] 1153 	movx	a,@dptr
      007D4A 52 07            [12] 1154 	anl	ar7,a
      007D4C 8F 82            [24] 1155 	mov	dpl, r7
                                   1156 ;	quantum/action_layer.c:228: }
      007D4E 81 F2            [24] 1157 	ajmp	_layer_state_set
                                   1158 ;------------------------------------------------------------
                                   1159 ;Allocation info for local variables in function 'layer_invert'
                                   1160 ;------------------------------------------------------------
                                   1161 ;layer         Allocated with name '_layer_invert_layer_10000_372'
                                   1162 ;------------------------------------------------------------
                                   1163 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1164 ;	-----------------------------------------
                                   1165 ;	 function layer_or
                                   1166 ;	-----------------------------------------
      007D50                       1167 _layer_or:
      007D50 E5 82            [12] 1168 	mov	a,dpl
      007D52 90 09 1A         [24] 1169 	mov	dptr,#_layer_or_state_10000_374
      007D55 F0               [24] 1170 	movx	@dptr,a
                                   1171 ;	quantum/action_layer.c:255: state);
      007D56 E0               [24] 1172 	movx	a,@dptr
      007D57 FF               [12] 1173 	mov	r7,a
      007D58 90 09 09         [24] 1174 	mov	dptr,#_persistent_layers
      007D5B 12 7F 78         [24] 1175 	lcall	_ak820_outline_0142
                                   1176 ;	quantum/action_layer.c:256: }
      007D5E 81 F2            [24] 1177 	ajmp	_layer_state_set
                                   1178 ;------------------------------------------------------------
                                   1179 ;Allocation info for local variables in function 'layer_and'
                                   1180 ;------------------------------------------------------------
                                   1181 ;state         Allocated with name '_layer_and_state_10000_376'
                                   1182 ;------------------------------------------------------------
                                   1183 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1184 ;	-----------------------------------------
                                   1185 ;	 function layer_and
                                   1186 ;	-----------------------------------------
      007D60                       1187 _layer_and:
      007D60 E5 82            [12] 1188 	mov	a,dpl
      007D62 90 09 1B         [24] 1189 	mov	dptr,#_layer_and_state_10000_376
      007D65 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/action_layer.c:268: state);
      007D66 90 09 09         [24] 1192 	mov	dptr,#_persistent_layers
      007D69 E0               [24] 1193 	movx	a,@dptr
      007D6A FF               [12] 1194 	mov	r7,a
      007D6B 90 09 1B         [24] 1195 	mov	dptr,#_layer_and_state_10000_376
      007D6E E0               [24] 1196 	movx	a,@dptr
      007D6F 52 07            [12] 1197 	anl	ar7,a
      007D71 8F 82            [24] 1198 	mov	dpl, r7
                                   1199 ;	quantum/action_layer.c:269: }
      007D73 81 F2            [24] 1200 	ajmp	_layer_state_set
                                   1201 ;------------------------------------------------------------
                                   1202 ;Allocation info for local variables in function 'layer_xor'
                                   1203 ;------------------------------------------------------------
                                   1204 ;state         Allocated with name '_layer_xor_state_10000_378'
                                   1205 ;------------------------------------------------------------
                                   1206 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1207 ;	-----------------------------------------
                                   1208 ;	 function layer_xor
                                   1209 ;	-----------------------------------------
      007D75                       1210 _layer_xor:
      007D75 E5 82            [12] 1211 	mov	a,dpl
      007D77 90 09 1C         [24] 1212 	mov	dptr,#_layer_xor_state_10000_378
      007D7A F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/action_layer.c:281: state);
      007D7B E0               [24] 1215 	movx	a,@dptr
      007D7C FF               [12] 1216 	mov	r7,a
      007D7D 90 09 09         [24] 1217 	mov	dptr,#_persistent_layers
      007D80 E0               [24] 1218 	movx	a,@dptr
      007D81 62 07            [12] 1219 	xrl	ar7,a
      007D83 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	quantum/action_layer.c:282: }
      007D85 81 F2            [24] 1222 	ajmp	_layer_state_set
                                   1223 ;------------------------------------------------------------
                                   1224 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1225 ;------------------------------------------------------------
                                   1226 ;position      Allocated with name '_source_keycode_cache_slot_position_10000_380'
                                   1227 ;row           Allocated with name '_source_keycode_cache_slot_row_10000_381'
                                   1228 ;col           Allocated with name '_source_keycode_cache_slot_col_10000_381'
                                   1229 ;------------------------------------------------------------
                                   1230 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(uint16_t position) {
                                   1231 ;	-----------------------------------------
                                   1232 ;	 function source_keycode_cache_slot
                                   1233 ;	-----------------------------------------
      007D87                       1234 _source_keycode_cache_slot:
      007D87 12 38 4E         [24] 1235 	lcall	_ak820_outline_0109
      007D8A 90 0A 21         [24] 1236 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007D8D 12 38 49         [24] 1237 	lcall	_ak820_outline_0108
                                   1238 ;	quantum/action_layer.c:325: uint8_t row = position >> 8, col = position;
      007D90 90 0A 21         [24] 1239 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007D93 E0               [24] 1240 	movx	a,@dptr
      007D94 FE               [12] 1241 	mov	r6,a
      007D95 A3               [24] 1242 	inc	dptr
      007D96 E0               [24] 1243 	movx	a,@dptr
      007D97 FD               [12] 1244 	mov	r5,a
                                   1245 ;	quantum/action_layer.c:326: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
      007D98 BD 10 00         [24] 1246 	cjne	r5,#0x10,00147$
      007D9B                       1247 00147$:
      007D9B 50 20            [24] 1248 	jnc	00102$
      007D9D BE 08 00         [24] 1249 	cjne	r6,#0x08,00149$
      007DA0                       1250 00149$:
      007DA0 50 1B            [24] 1251 	jnc	00102$
                                   1252 ;	quantum/action_layer.c:327: return &source_keycodes_cache[(uint8_t)(row * MATRIX_COLS + col)];
      007DA2 8D 07            [24] 1253 	mov	ar7,r5
      007DA4 EF               [12] 1254 	mov	a,r7
      007DA5 12 38 72         [24] 1255 	lcall	_ak820_outline_0162
      007DA8 FF               [12] 1256 	mov	r7,a
      007DA9 8E 04            [24] 1257 	mov	ar4,r6
      007DAB EC               [12] 1258 	mov	a,r4
      007DAC 2F               [12] 1259 	add	a, r7
      007DAD 75 F0 02         [24] 1260 	mov	b,#0x02
      007DB0 A4               [48] 1261 	mul	ab
      007DB1 24 1D            [12] 1262 	add	a, #_source_keycodes_cache
      007DB3 FC               [12] 1263 	mov	r4,a
      007DB4 74 09            [12] 1264 	mov	a,#(_source_keycodes_cache >> 8)
      007DB6 35 F0            [12] 1265 	addc	a, b
      007DB8 FF               [12] 1266 	mov	r7,a
      007DB9 12 48 E8         [24] 1267 	lcall	_ak820_outline_0186
      007DBC 22               [24] 1268 	ret
      007DBD                       1269 00102$:
                                   1270 ;	quantum/action_layer.c:330: if ((row == KEYLOC_ENCODER_CW || row == KEYLOC_ENCODER_CCW) && col < NUM_ENCODERS) {
      007DBD BD FD 02         [24] 1271 	cjne	r5,#0xfd,00151$
      007DC0 80 03            [24] 1272 	sjmp	00107$
      007DC2                       1273 00151$:
      007DC2 BD FC 2E         [24] 1274 	cjne	r5,#0xfc,00105$
      007DC5                       1275 00107$:
      007DC5 BE 01 00         [24] 1276 	cjne	r6,#0x01,00154$
      007DC8                       1277 00154$:
      007DC8 50 29            [24] 1278 	jnc	00105$
                                   1279 ;	quantum/action_layer.c:331: return &encoder_source_keycodes_cache[col + (row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      007DCA BD FC 04         [24] 1280 	cjne	r5,#0xfc,00110$
      007DCD 7F 01            [12] 1281 	mov	r7,#0x01
      007DCF 80 02            [24] 1282 	sjmp	00111$
      007DD1                       1283 00110$:
      007DD1 7F 00            [12] 1284 	mov	r7,#0x00
      007DD3                       1285 00111$:
      007DD3 C2 D5            [12] 1286 	clr	F0
      007DD5 75 F0 02         [24] 1287 	mov	b,#0x02
      007DD8 EF               [12] 1288 	mov	a,r7
      007DD9 30 E7 04         [24] 1289 	jnb	acc.7,00158$
      007DDC B2 D5            [12] 1290 	cpl	F0
      007DDE F4               [12] 1291 	cpl	a
      007DDF 04               [12] 1292 	inc	a
      007DE0                       1293 00158$:
      007DE0 A4               [48] 1294 	mul	ab
      007DE1 30 D5 03         [24] 1295 	jnb	F0,00159$
      007DE4 12 74 39         [24] 1296 	lcall	_ak820_outline_0133
      007DE7                       1297 00159$:
      007DE7 24 1D            [12] 1298 	add	a, #_encoder_source_keycodes_cache
      007DE9 FE               [12] 1299 	mov	r6,a
      007DEA 74 0A            [12] 1300 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      007DEC 35 F0            [12] 1301 	addc	a, b
      007DEE FF               [12] 1302 	mov	r7,a
      007DEF 12 43 17         [24] 1303 	lcall	_ak820_outline_0119
      007DF2 22               [24] 1304 	ret
      007DF3                       1305 00105$:
                                   1306 ;	quantum/action_layer.c:334: return 0;
      007DF3 90 00 00         [24] 1307 	mov	dptr,#0x0000
                                   1308 ;	quantum/action_layer.c:335: }
      007DF6 22               [24] 1309 	ret
                                   1310 ;------------------------------------------------------------
                                   1311 ;Allocation info for local variables in function 'ak820_cache_keycode'
                                   1312 ;------------------------------------------------------------
                                   1313 ;keycode       Allocated with name '_ak820_cache_keycode_PARM_2'
                                   1314 ;position      Allocated with name '_ak820_cache_keycode_position_10000_386'
                                   1315 ;slot          Allocated with name '_ak820_cache_keycode_slot_10000_387'
                                   1316 ;------------------------------------------------------------
                                   1317 ;	quantum/action_layer.c:339: bool ak820_cache_keycode(uint16_t position, uint16_t keycode) {
                                   1318 ;	-----------------------------------------
                                   1319 ;	 function ak820_cache_keycode
                                   1320 ;	-----------------------------------------
      007DF7                       1321 _ak820_cache_keycode:
      007DF7 12 38 4E         [24] 1322 	lcall	_ak820_outline_0109
      007DFA 90 0A 25         [24] 1323 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007DFD 12 38 49         [24] 1324 	lcall	_ak820_outline_0108
                                   1325 ;	quantum/action_layer.c:340: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007E00 90 0A 25         [24] 1326 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007E03 12 37 AC         [24] 1327 	lcall	_ak820_outline_0006
      007E06 B1 87            [24] 1328 	acall	_source_keycode_cache_slot
      007E08 12 43 27         [24] 1329 	lcall	_ak820_outline_0137
                                   1330 ;	quantum/action_layer.c:341: if (!slot) return false;
      007E0B EE               [12] 1331 	mov	a,r6
      007E0C 4F               [12] 1332 	orl	a,r7
      007E0D 70 03            [24] 1333 	jnz	00102$
      007E0F F5 82            [12] 1334 	mov	dpl,a
      007E11 22               [24] 1335 	ret
      007E12                       1336 00102$:
                                   1337 ;	quantum/action_layer.c:342: *slot = keycode;
      007E12 90 0A 23         [24] 1338 	mov	dptr,#_ak820_cache_keycode_PARM_2
      007E15 12 38 12         [24] 1339 	lcall	_ak820_outline_0064
      007E18 12 43 17         [24] 1340 	lcall	_ak820_outline_0119
      007E1B 12 38 1E         [24] 1341 	lcall	_ak820_outline_0077
                                   1342 ;	quantum/action_layer.c:343: return true;
      007E1E 75 82 01         [24] 1343 	mov	dpl, #0x01
                                   1344 ;	quantum/action_layer.c:344: }
      007E21 22               [24] 1345 	ret
                                   1346 ;------------------------------------------------------------
                                   1347 ;Allocation info for local variables in function 'ak820_cache_layer'
                                   1348 ;------------------------------------------------------------
                                   1349 ;layer         Allocated with name '_ak820_cache_layer_PARM_2'
                                   1350 ;position      Allocated with name '_ak820_cache_layer_position_10000_389'
                                   1351 ;slot          Allocated with name '_ak820_cache_layer_slot_10000_390'
                                   1352 ;------------------------------------------------------------
                                   1353 ;	quantum/action_layer.c:346: void ak820_cache_layer(uint16_t position, uint8_t layer) {
                                   1354 ;	-----------------------------------------
                                   1355 ;	 function ak820_cache_layer
                                   1356 ;	-----------------------------------------
      007E22                       1357 _ak820_cache_layer:
      007E22 12 38 4E         [24] 1358 	lcall	_ak820_outline_0109
      007E25 90 0A 28         [24] 1359 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007E28 12 38 49         [24] 1360 	lcall	_ak820_outline_0108
                                   1361 ;	quantum/action_layer.c:347: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007E2B 90 0A 28         [24] 1362 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007E2E 12 37 AC         [24] 1363 	lcall	_ak820_outline_0006
      007E31 C0 07            [24] 1364 	push	ar7
      007E33 C0 06            [24] 1365 	push	ar6
      007E35 B1 87            [24] 1366 	acall	_source_keycode_cache_slot
      007E37 12 43 37         [24] 1367 	lcall	_ak820_outline_0152
      007E3A D0 06            [24] 1368 	pop	ar6
      007E3C D0 07            [24] 1369 	pop	ar7
                                   1370 ;	quantum/action_layer.c:348: if (!slot) return;
      007E3E EC               [12] 1371 	mov	a,r4
      007E3F 4D               [12] 1372 	orl	a,r5
      007E40 70 01            [24] 1373 	jnz	00102$
      007E42 22               [24] 1374 	ret
      007E43                       1375 00102$:
                                   1376 ;	quantum/action_layer.c:349: layer &= (1u << MAX_LAYER_BITS) - 1;
      007E43 90 0A 27         [24] 1377 	mov	dptr,#_ak820_cache_layer_PARM_2
      007E46 E0               [24] 1378 	movx	a,@dptr
      007E47 53 E0 07         [24] 1379 	anl	acc,#0x07
      007E4A F0               [24] 1380 	movx	@dptr,a
                                   1381 ;	quantum/action_layer.c:361: *slot = ak820_keycode_at(layer, position);
      007E4B 90 0A 27         [24] 1382 	mov	dptr,#_ak820_cache_layer_PARM_2
      007E4E E0               [24] 1383 	movx	a,@dptr
      007E4F FB               [12] 1384 	mov	r3,a
      007E50 90 0C 6A         [24] 1385 	mov	dptr,#_ak820_keycode_at_PARM_2
      007E53 12 48 C5         [24] 1386 	lcall	_ak820_outline_0065
      007E56 8B 82            [24] 1387 	mov	dpl, r3
      007E58 C0 05            [24] 1388 	push	ar5
      007E5A C0 04            [24] 1389 	push	ar4
      007E5C 12 9B 46         [24] 1390 	lcall	_ak820_keycode_at
      007E5F 12 43 27         [24] 1391 	lcall	_ak820_outline_0137
      007E62 D0 04            [24] 1392 	pop	ar4
      007E64 D0 05            [24] 1393 	pop	ar5
      007E66 12 38 59         [24] 1394 	lcall	_ak820_outline_0127
      007E69 12 48 C5         [24] 1395 	lcall	_ak820_outline_0065
                                   1396 ;	quantum/action_layer.c:362: }
      007E6C 22               [24] 1397 	ret
                                   1398 ;------------------------------------------------------------
                                   1399 ;Allocation info for local variables in function 'ak820_cached_key'
                                   1400 ;------------------------------------------------------------
                                   1401 ;position      Allocated with name '_ak820_cached_key_position_10000_392'
                                   1402 ;slot          Allocated with name '_ak820_cached_key_slot_10001_396'
                                   1403 ;------------------------------------------------------------
                                   1404 ;	quantum/action_layer.c:383: uint16_t ak820_cached_key(uint16_t position) {
                                   1405 ;	-----------------------------------------
                                   1406 ;	 function ak820_cached_key
                                   1407 ;	-----------------------------------------
      007E6D                       1408 _ak820_cached_key:
      007E6D 12 38 4E         [24] 1409 	lcall	_ak820_outline_0109
      007E70 90 0A 2A         [24] 1410 	mov	dptr,#_ak820_cached_key_position_10000_392
      007E73 12 38 49         [24] 1411 	lcall	_ak820_outline_0108
                                   1412 ;	quantum/action_layer.c:386: if (vial_unlock_in_progress) return KC_NO;
      007E76 90 0E E8         [24] 1413 	mov	dptr,#_vial_unlock_in_progress
      007E79 E0               [24] 1414 	movx	a,@dptr
      007E7A 60 04            [24] 1415 	jz	00102$
      007E7C 90 00 00         [24] 1416 	mov	dptr,#0x0000
      007E7F 22               [24] 1417 	ret
      007E80                       1418 00102$:
                                   1419 ;	quantum/action_layer.c:387: if (position == (((uint16_t)VIAL_MATRIX_MAGIC << 8) | VIAL_MATRIX_MAGIC)) return g_vial_magic_keycode_override;
      007E80 90 0A 2A         [24] 1420 	mov	dptr,#_ak820_cached_key_position_10000_392
      007E83 12 37 FB         [24] 1421 	lcall	_ak820_outline_0058
      007E86 BE F0 0D         [24] 1422 	cjne	r6,#0xf0,00104$
      007E89 BF F0 0A         [24] 1423 	cjne	r7,#0xf0,00104$
      007E8C 90 0D 3F         [24] 1424 	mov	dptr,#_g_vial_magic_keycode_override
      007E8F 12 38 12         [24] 1425 	lcall	_ak820_outline_0064
      007E92 12 38 59         [24] 1426 	lcall	_ak820_outline_0127
      007E95 22               [24] 1427 	ret
      007E96                       1428 00104$:
                                   1429 ;	quantum/action_layer.c:389: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007E96 12 43 17         [24] 1430 	lcall	_ak820_outline_0119
      007E99 B1 87            [24] 1431 	acall	_source_keycode_cache_slot
      007E9B 12 43 27         [24] 1432 	lcall	_ak820_outline_0137
                                   1433 ;	quantum/action_layer.c:390: return slot ? *slot : KC_NO;
      007E9E EE               [12] 1434 	mov	a,r6
      007E9F 4F               [12] 1435 	orl	a,r7
      007EA0 60 08            [24] 1436 	jz	00107$
      007EA2 12 43 17         [24] 1437 	lcall	_ak820_outline_0119
      007EA5 12 37 FB         [24] 1438 	lcall	_ak820_outline_0058
      007EA8 80 04            [24] 1439 	sjmp	00108$
      007EAA                       1440 00107$:
      007EAA 7E 00            [12] 1441 	mov	r6,#0x00
      007EAC 7F 00            [12] 1442 	mov	r7,#0x00
      007EAE                       1443 00108$:
      007EAE 12 43 17         [24] 1444 	lcall	_ak820_outline_0119
                                   1445 ;	quantum/action_layer.c:391: }
      007EB1 22               [24] 1446 	ret
                                   1447 ;------------------------------------------------------------
                                   1448 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1449 ;------------------------------------------------------------
                                   1450 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1451 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_397'
                                   1452 ;------------------------------------------------------------
                                   1453 ;	quantum/action_layer.c:394: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1454 ;	-----------------------------------------
                                   1455 ;	 function ak820_resolve_key
                                   1456 ;	-----------------------------------------
      007EB2                       1457 _ak820_resolve_key:
      007EB2 12 38 4E         [24] 1458 	lcall	_ak820_outline_0109
      007EB5 90 0A 2D         [24] 1459 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007EB8 12 38 49         [24] 1460 	lcall	_ak820_outline_0108
                                   1461 ;	quantum/action_layer.c:493: if (disable_action_cache) {
      007EBB 90 0E 87         [24] 1462 	mov	dptr,#_disable_action_cache
      007EBE E0               [24] 1463 	movx	a,@dptr
      007EBF 60 1D            [24] 1464 	jz	00102$
                                   1465 ;	quantum/action_layer.c:494: return ak820_keycode_at(ak820_layer_for_key(position), position);
      007EC1 90 0A 2D         [24] 1466 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007EC4 12 37 AC         [24] 1467 	lcall	_ak820_outline_0006
      007EC7 C0 07            [24] 1468 	push	ar7
      007EC9 C0 06            [24] 1469 	push	ar6
      007ECB F1 06            [12] 1470 	acall	_ak820_layer_for_key
      007ECD AD 82            [24] 1471 	mov	r5, dpl
      007ECF D0 06            [24] 1472 	pop	ar6
      007ED1 D0 07            [24] 1473 	pop	ar7
      007ED3 90 0C 6A         [24] 1474 	mov	dptr,#_ak820_keycode_at_PARM_2
      007ED6 12 48 C5         [24] 1475 	lcall	_ak820_outline_0065
      007ED9 8D 82            [24] 1476 	mov	dpl, r5
      007EDB 02 9B 46         [24] 1477 	ljmp	_ak820_keycode_at
      007EDE                       1478 00102$:
                                   1479 ;	quantum/action_layer.c:496: if (cache_press) ak820_cache_layer(position, ak820_layer_for_key(position));
      007EDE 90 0A 2C         [24] 1480 	mov	dptr,#_ak820_resolve_key_PARM_2
      007EE1 E0               [24] 1481 	movx	a,@dptr
      007EE2 60 1A            [24] 1482 	jz	00104$
      007EE4 90 0A 2D         [24] 1483 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007EE7 12 37 AC         [24] 1484 	lcall	_ak820_outline_0006
      007EEA C0 07            [24] 1485 	push	ar7
      007EEC C0 06            [24] 1486 	push	ar6
      007EEE F1 06            [12] 1487 	acall	_ak820_layer_for_key
      007EF0 E5 82            [12] 1488 	mov	a, dpl
      007EF2 D0 06            [24] 1489 	pop	ar6
      007EF4 D0 07            [24] 1490 	pop	ar7
      007EF6 90 0A 27         [24] 1491 	mov	dptr,#_ak820_cache_layer_PARM_2
      007EF9 12 42 F2         [24] 1492 	lcall	_ak820_outline_0066
      007EFC D1 22            [24] 1493 	acall	_ak820_cache_layer
      007EFE                       1494 00104$:
                                   1495 ;	quantum/action_layer.c:497: return ak820_cached_key(position);
      007EFE 90 0A 2D         [24] 1496 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007F01 12 37 AC         [24] 1497 	lcall	_ak820_outline_0006
                                   1498 ;	quantum/action_layer.c:498: }
      007F04 C1 6D            [24] 1499 	ajmp	_ak820_cached_key
                                   1500 ;------------------------------------------------------------
                                   1501 ;Allocation info for local variables in function 'store_or_get_action'
                                   1502 ;------------------------------------------------------------
                                   1503 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1504 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_408'
                                   1505 ;------------------------------------------------------------
                                   1506 ;	quantum/action_layer.c:499: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1507 ;	-----------------------------------------
                                   1508 ;	 function ak820_layer_for_key
                                   1509 ;	-----------------------------------------
      007F06                       1510 _ak820_layer_for_key:
      007F06 12 38 4E         [24] 1511 	lcall	_ak820_outline_0109
      007F09 90 0A 2F         [24] 1512 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      007F0C 12 38 49         [24] 1513 	lcall	_ak820_outline_0108
                                   1514 ;	quantum/action_layer.c:539: layer_state_t layers = layer_state | default_layer_state;
      007F0F 90 0E 88         [24] 1515 	mov	dptr,#_default_layer_state
      007F12 E0               [24] 1516 	movx	a,@dptr
      007F13 FF               [12] 1517 	mov	r7,a
      007F14 90 0E 89         [24] 1518 	mov	dptr,#_layer_state
      007F17 E0               [24] 1519 	movx	a,@dptr
      007F18 90 0A 31         [24] 1520 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      007F1B 4F               [12] 1521 	orl	a,r7
      007F1C F0               [24] 1522 	movx	@dptr,a
                                   1523 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007F1D 90 0A 2F         [24] 1524 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      007F20 12 37 FB         [24] 1525 	lcall	_ak820_outline_0058
      007F23 7D 05            [12] 1526 	mov	r5,#0x05
      007F25                       1527 00107$:
      007F25 ED               [12] 1528 	mov	a,r5
      007F26 20 E7 4B         [24] 1529 	jb	acc.7,00105$
                                   1530 ;	quantum/action_layer.c:542: if (layers & ((layer_state_t)1 << i)) {
      007F29 8D F0            [24] 1531 	mov	b,r5
      007F2B 05 F0            [12] 1532 	inc	b
      007F2D 7B 01            [12] 1533 	mov	r3,#0x01
      007F2F 7C 00            [12] 1534 	mov	r4,#0x00
      007F31 80 06            [24] 1535 	sjmp	00141$
      007F33                       1536 00140$:
      007F33 EB               [12] 1537 	mov	a,r3
      007F34 2B               [12] 1538 	add	a,r3
      007F35 FB               [12] 1539 	mov	r3,a
      007F36 EC               [12] 1540 	mov	a,r4
      007F37 33               [12] 1541 	rlc	a
      007F38 FC               [12] 1542 	mov	r4,a
      007F39                       1543 00141$:
      007F39 D5 F0 F7         [24] 1544 	djnz	b,00140$
      007F3C 90 0A 31         [24] 1545 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      007F3F E0               [24] 1546 	movx	a,@dptr
      007F40 7A 00            [12] 1547 	mov	r2,#0x00
      007F42 52 03            [12] 1548 	anl	ar3,a
      007F44 EA               [12] 1549 	mov	a,r2
      007F45 52 04            [12] 1550 	anl	ar4,a
      007F47 EB               [12] 1551 	mov	a,r3
      007F48 4C               [12] 1552 	orl	a,r4
      007F49 60 26            [24] 1553 	jz	00108$
                                   1554 ;	quantum/action_layer.c:546: if (ak820_keycode_at(i, position) != KC_TRANSPARENT) {
      007F4B 90 0C 6A         [24] 1555 	mov	dptr,#_ak820_keycode_at_PARM_2
      007F4E 12 48 C5         [24] 1556 	lcall	_ak820_outline_0065
      007F51 8D 82            [24] 1557 	mov	dpl, r5
      007F53 C0 07            [24] 1558 	push	ar7
      007F55 C0 06            [24] 1559 	push	ar6
      007F57 C0 05            [24] 1560 	push	ar5
      007F59 12 9B 46         [24] 1561 	lcall	_ak820_keycode_at
      007F5C AB 82            [24] 1562 	mov	r3, dpl
      007F5E AC 83            [24] 1563 	mov	r4, dph
      007F60 D0 05            [24] 1564 	pop	ar5
      007F62 D0 06            [24] 1565 	pop	ar6
      007F64 D0 07            [24] 1566 	pop	ar7
      007F66 BB 01 05         [24] 1567 	cjne	r3,#0x01,00143$
      007F69 BC 00 02         [24] 1568 	cjne	r4,#0x00,00143$
      007F6C 80 03            [24] 1569 	sjmp	00108$
      007F6E                       1570 00143$:
                                   1571 ;	quantum/action_layer.c:555: return i;
      007F6E 8D 82            [24] 1572 	mov	dpl, r5
      007F70 22               [24] 1573 	ret
      007F71                       1574 00108$:
                                   1575 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007F71 1D               [12] 1576 	dec	r5
      007F72 80 B1            [24] 1577 	sjmp	00107$
      007F74                       1578 00105$:
                                   1579 ;	quantum/action_layer.c:560: return 0;
      007F74 75 82 00         [24] 1580 	mov	dpl, #0x00
                                   1581 ;	quantum/action_layer.c:565: }
      007F77 22               [24] 1582 	ret
                                   1583 ;------------------------------------------------------------
                                   1584 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1585 ;------------------------------------------------------------
                                   1586 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1587 ;------------------------------------------------------------
                                   1588 ;	quantum/action_layer.c:567: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1589 ;	-----------------------------------------
                                   1590 	.area CSEG    (CODE)
                                   1591 	.area CONST   (CODE)
                                   1592 	.area XINIT   (CODE)
      00C5A3                       1593 __xinit__default_layer_state:
      00C5A3 00                    1594 	.db #0x00	; 0
      00C5A4                       1595 __xinit__layer_state:
      00C5A4 00                    1596 	.db #0x00	; 0
                                   1597 	.area CABS    (ABS,CODE)
                                   1598 
                                   1599 ; Experimental exact instruction outlining.
                                   1600 	.globl _ak820_outline_0006
                                   1601 	.globl _ak820_outline_0058
                                   1602 	.globl _ak820_outline_0064
                                   1603 	.globl _ak820_outline_0065
                                   1604 	.globl _ak820_outline_0066
                                   1605 	.globl _ak820_outline_0068
                                   1606 	.globl _ak820_outline_0077
                                   1607 	.globl _ak820_outline_0094
                                   1608 	.globl _ak820_outline_0108
                                   1609 	.globl _ak820_outline_0109
                                   1610 	.globl _ak820_outline_0119
                                   1611 	.globl _ak820_outline_0127
                                   1612 	.globl _ak820_outline_0133
                                   1613 	.globl _ak820_outline_0137
                                   1614 	.globl _ak820_outline_0138
                                   1615 	.globl _ak820_outline_0142
                                   1616 	.globl _ak820_outline_0152
                                   1617 	.globl _ak820_outline_0160
                                   1618 	.globl _ak820_outline_0162
                                   1619 	.globl _ak820_outline_0166
                                   1620 	.globl _ak820_outline_0174
                                   1621 	.globl _ak820_outline_0179
                                   1622 	.globl _ak820_outline_0186
                                   1623 
                                   1624 	.area CSEG (CODE)
                                   1625 ; function ak820_outline_0142
      007F78                       1626 _ak820_outline_0142:
      007F78 E0               [24] 1627 	movx	a,@dptr
      007F79 42 07            [12] 1628 	orl	ar7,a
      007F7B 8F 82            [24] 1629 	mov	dpl,r7
      007F7D 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0166
      007F7E                       1634 _ak820_outline_0166:
      007F7E F5 83            [12] 1635 	mov	dph,a
      007F80 E4               [12] 1636 	clr	a
      007F81 F0               [24] 1637 	movx	@dptr,a
      007F82 0F               [12] 1638 	inc	r7
      007F83 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0179
      007F84                       1643 _ak820_outline_0179:
      007F84 90 0A 48         [24] 1644 	mov	dptr,#_ak820_macro_change_PARM_2
      007F87 EF               [12] 1645 	mov	a,r7
      007F88 F0               [24] 1646 	movx	@dptr,a
      007F89 90 0A 49         [24] 1647 	mov	dptr,#_ak820_macro_change_PARM_3
      007F8C 22               [24] 1648 	ret
