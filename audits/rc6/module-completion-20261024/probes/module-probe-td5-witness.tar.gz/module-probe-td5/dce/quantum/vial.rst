                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_tap_dance
                                     17 	.globl _dynamic_keymap_get_tap_dance
                                     18 	.globl _dynamic_keymap_set_encoder
                                     19 	.globl _dynamic_keymap_get_encoder
                                     20 	.globl _repeat_key_cancel
                                     21 	.globl _ak820_combo_reload
                                     22 	.globl _clear_keyboard
                                     23 	.globl _ak820_action_exec
                                     24 	.globl _timer_elapsed32
                                     25 	.globl _timer_read32
                                     26 	.globl _timer_read
                                     27 	.globl ___memcpy
                                     28 	.globl _ADC_START
                                     29 	.globl _S0_R_FIFO
                                     30 	.globl _S0_T_FIFO
                                     31 	.globl _S0_FREE
                                     32 	.globl _S0_IF_BYTE
                                     33 	.globl _S0_IF_FIRST
                                     34 	.globl _S0_IF_OV
                                     35 	.globl _S0_FST_ACT
                                     36 	.globl _CP_RL2
                                     37 	.globl _C_T2
                                     38 	.globl _TR2
                                     39 	.globl _EXEN2
                                     40 	.globl _TCLK
                                     41 	.globl _RCLK
                                     42 	.globl _EXF2
                                     43 	.globl _CAP1F
                                     44 	.globl _TF2
                                     45 	.globl _RI
                                     46 	.globl _TI
                                     47 	.globl _RB8
                                     48 	.globl _TB8
                                     49 	.globl _REN
                                     50 	.globl _SM2
                                     51 	.globl _SM1
                                     52 	.globl _SM0
                                     53 	.globl _IT0
                                     54 	.globl _IE0
                                     55 	.globl _IT1
                                     56 	.globl _IE1
                                     57 	.globl _TR0
                                     58 	.globl _TF0
                                     59 	.globl _TR1
                                     60 	.globl _TF1
                                     61 	.globl _P4_0
                                     62 	.globl _P4_1
                                     63 	.globl _P4_2
                                     64 	.globl _P4_3
                                     65 	.globl _P4_4
                                     66 	.globl _P4_5
                                     67 	.globl _P4_6
                                     68 	.globl _RXD
                                     69 	.globl _TXD
                                     70 	.globl _INT0
                                     71 	.globl _INT1
                                     72 	.globl _T0
                                     73 	.globl _T1
                                     74 	.globl _MOSI1
                                     75 	.globl _MISO1
                                     76 	.globl _SCK1
                                     77 	.globl _P3_0
                                     78 	.globl _P3_1
                                     79 	.globl _P3_2
                                     80 	.globl _P3_3
                                     81 	.globl _P3_4
                                     82 	.globl _P3_5
                                     83 	.globl _P3_6
                                     84 	.globl _P3_7
                                     85 	.globl _CAP1_
                                     86 	.globl _T2_
                                     87 	.globl _CAP2_
                                     88 	.globl _T2EX_
                                     89 	.globl _RXD1
                                     90 	.globl _TXD1
                                     91 	.globl _P2_0
                                     92 	.globl _P2_1
                                     93 	.globl _P2_2
                                     94 	.globl _P2_3
                                     95 	.globl _P2_4
                                     96 	.globl _P2_5
                                     97 	.globl _P2_6
                                     98 	.globl _P2_7
                                     99 	.globl _AIN0
                                    100 	.globl _AIN1
                                    101 	.globl _AIN2
                                    102 	.globl _AIN3
                                    103 	.globl _AIN4
                                    104 	.globl _AIN5
                                    105 	.globl _AIN6
                                    106 	.globl _AIN7
                                    107 	.globl _CAP1
                                    108 	.globl _T2
                                    109 	.globl _CAP2
                                    110 	.globl _T2EX
                                    111 	.globl _INT0_
                                    112 	.globl _SCS
                                    113 	.globl _MOSI
                                    114 	.globl _MISO
                                    115 	.globl _SCK
                                    116 	.globl _RXD1_
                                    117 	.globl _TXD1_
                                    118 	.globl _P1_0
                                    119 	.globl _P1_1
                                    120 	.globl _P1_2
                                    121 	.globl _P1_3
                                    122 	.globl _P1_4
                                    123 	.globl _P1_5
                                    124 	.globl _P1_6
                                    125 	.globl _P1_7
                                    126 	.globl _AIN8
                                    127 	.globl _AIN9
                                    128 	.globl _AIN10
                                    129 	.globl _AIN11
                                    130 	.globl _AIN12
                                    131 	.globl _AIN13
                                    132 	.globl _RXD_
                                    133 	.globl _TXD_
                                    134 	.globl _SCL0
                                    135 	.globl _SDA0
                                    136 	.globl _P0_0
                                    137 	.globl _P0_1
                                    138 	.globl _P0_2
                                    139 	.globl _P0_3
                                    140 	.globl _P0_4
                                    141 	.globl _P0_5
                                    142 	.globl _P0_6
                                    143 	.globl _P0_7
                                    144 	.globl _IE_SPI0
                                    145 	.globl _IE_USB
                                    146 	.globl _IE_ADC
                                    147 	.globl _IE_UART1
                                    148 	.globl _IE_PWM_I2C
                                    149 	.globl _IE_GPIO
                                    150 	.globl _IE_WDOG
                                    151 	.globl _PX0
                                    152 	.globl _PT0
                                    153 	.globl _PX1
                                    154 	.globl _PT1
                                    155 	.globl _PS
                                    156 	.globl _PT2
                                    157 	.globl _PL_FLAG
                                    158 	.globl _PH_FLAG
                                    159 	.globl _EX0
                                    160 	.globl _ET0
                                    161 	.globl _EX1
                                    162 	.globl _ET1
                                    163 	.globl _ES
                                    164 	.globl _ET2
                                    165 	.globl _E_DIS
                                    166 	.globl _EA
                                    167 	.globl _P
                                    168 	.globl _F1
                                    169 	.globl _OV
                                    170 	.globl _RS0
                                    171 	.globl _RS1
                                    172 	.globl _F0
                                    173 	.globl _AC
                                    174 	.globl _CY
                                    175 	.globl _I2CS_INT_ST
                                    176 	.globl _I2CX_INT
                                    177 	.globl _LED_STATUS
                                    178 	.globl _LED_DMA_H
                                    179 	.globl _LED_DMA_L
                                    180 	.globl _LED_DMA
                                    181 	.globl _LED_PWM_OE
                                    182 	.globl _LED_COMMON
                                    183 	.globl _ADC_CHAN
                                    184 	.globl _ADC_DAT_H
                                    185 	.globl _ADC_DAT_L
                                    186 	.globl _ADC_DAT
                                    187 	.globl _ADC_CTRL
                                    188 	.globl _SPI1_CK_SE
                                    189 	.globl _SPI1_CTRL
                                    190 	.globl _SPI1_DATA
                                    191 	.globl _SPI1_STAT
                                    192 	.globl _SIF1
                                    193 	.globl _SBAUD1
                                    194 	.globl _SBUF1
                                    195 	.globl _SCON1
                                    196 	.globl _SPI0_SETUP
                                    197 	.globl _SPI0_CK_SE
                                    198 	.globl _SPI0_CTRL
                                    199 	.globl _SPI0_DATA
                                    200 	.globl _SPI0_STAT
                                    201 	.globl _T2CAP1H
                                    202 	.globl _T2CAP1L
                                    203 	.globl _T2CAP1
                                    204 	.globl _TH2
                                    205 	.globl _TL2
                                    206 	.globl _T2COUNT
                                    207 	.globl _RCAP2H
                                    208 	.globl _RCAP2L
                                    209 	.globl _RCAP2
                                    210 	.globl _T2MOD
                                    211 	.globl _T2CON
                                    212 	.globl _SBUF
                                    213 	.globl _SCON
                                    214 	.globl _TH1
                                    215 	.globl _TH0
                                    216 	.globl _TL1
                                    217 	.globl _TL0
                                    218 	.globl _TMOD
                                    219 	.globl _TCON
                                    220 	.globl _XBUS_AUX
                                    221 	.globl _P7
                                    222 	.globl _P6_DIR
                                    223 	.globl _P6_OUT_PU
                                    224 	.globl _P6_IN
                                    225 	.globl _P5_DIR
                                    226 	.globl _P5_OUT_PU
                                    227 	.globl _P5_IN
                                    228 	.globl _P4_LED_KEY
                                    229 	.globl _P4_DIR_PU
                                    230 	.globl _P4_MOD_OC
                                    231 	.globl _P4
                                    232 	.globl _P3_DIR_PU
                                    233 	.globl _P3_MOD_OC
                                    234 	.globl _P3
                                    235 	.globl _P2_DIR_PU
                                    236 	.globl _P2_MOD_OC
                                    237 	.globl _P2
                                    238 	.globl _P1_DIR_PU
                                    239 	.globl _P1_MOD_OC
                                    240 	.globl _P1
                                    241 	.globl _P0_DIR_PU
                                    242 	.globl _P0_MOD_OC
                                    243 	.globl _P0
                                    244 	.globl _ROM_CTRL
                                    245 	.globl _ROM_DATA_HH
                                    246 	.globl _ROM_DATA_HL
                                    247 	.globl _ROM_DATA_HI
                                    248 	.globl _ROM_ADDR_H
                                    249 	.globl _ROM_ADDR_L
                                    250 	.globl _ROM_ADDR
                                    251 	.globl _GPIO_IE
                                    252 	.globl _IP_EX
                                    253 	.globl _IE_EX
                                    254 	.globl _IP
                                    255 	.globl _IE
                                    256 	.globl _WDOG_COUNT
                                    257 	.globl _RESET_KEEP
                                    258 	.globl _WAKE_CTRL
                                    259 	.globl _CLOCK_CFG
                                    260 	.globl _POWER_CFG
                                    261 	.globl _PCON
                                    262 	.globl _GLOBAL_CFG
                                    263 	.globl _SAFE_MOD
                                    264 	.globl _DPH
                                    265 	.globl _DPL
                                    266 	.globl _SP
                                    267 	.globl _A_INV
                                    268 	.globl _B
                                    269 	.globl _ACC
                                    270 	.globl _PSW
                                    271 	.globl _vial_unlock_in_progress
                                    272 	.globl _vial_unlocked
                                    273 	.globl _g_vial_magic_keycode_override
                                    274 	.globl _vial_handle_cmd_PARM_2
                                    275 	.globl _vial_unlock_task
                                    276 	.globl _vial_init
                                    277 	.globl _vial_handle_cmd
                                    278 	.globl _vial_keycode_down
                                    279 	.globl _vial_keycode_up
                                    280 	.globl _vial_keycode_tap
                                    281 ;--------------------------------------------------------
                                    282 ; special function registers
                                    283 ;--------------------------------------------------------
                                    284 	.area RSEG    (ABS,DATA)
      000000                        285 	.org 0x0000
                           0000D0   286 _PSW	=	0x00d0
                           0000E0   287 _ACC	=	0x00e0
                           0000F0   288 _B	=	0x00f0
                           0000FD   289 _A_INV	=	0x00fd
                           000081   290 _SP	=	0x0081
                           000082   291 _DPL	=	0x0082
                           000083   292 _DPH	=	0x0083
                           0000A1   293 _SAFE_MOD	=	0x00a1
                           0000B1   294 _GLOBAL_CFG	=	0x00b1
                           000087   295 _PCON	=	0x0087
                           0000BA   296 _POWER_CFG	=	0x00ba
                           0000B9   297 _CLOCK_CFG	=	0x00b9
                           0000A9   298 _WAKE_CTRL	=	0x00a9
                           0000FE   299 _RESET_KEEP	=	0x00fe
                           0000FF   300 _WDOG_COUNT	=	0x00ff
                           0000A8   301 _IE	=	0x00a8
                           0000B8   302 _IP	=	0x00b8
                           0000E8   303 _IE_EX	=	0x00e8
                           0000E9   304 _IP_EX	=	0x00e9
                           0000B2   305 _GPIO_IE	=	0x00b2
                           008584   306 _ROM_ADDR	=	0x8584
                           000084   307 _ROM_ADDR_L	=	0x0084
                           000085   308 _ROM_ADDR_H	=	0x0085
                           008F8E   309 _ROM_DATA_HI	=	0x8f8e
                           00008E   310 _ROM_DATA_HL	=	0x008e
                           00008F   311 _ROM_DATA_HH	=	0x008f
                           000086   312 _ROM_CTRL	=	0x0086
                           000080   313 _P0	=	0x0080
                           0000C4   314 _P0_MOD_OC	=	0x00c4
                           0000C5   315 _P0_DIR_PU	=	0x00c5
                           000090   316 _P1	=	0x0090
                           000092   317 _P1_MOD_OC	=	0x0092
                           000093   318 _P1_DIR_PU	=	0x0093
                           0000A0   319 _P2	=	0x00a0
                           000094   320 _P2_MOD_OC	=	0x0094
                           000095   321 _P2_DIR_PU	=	0x0095
                           0000B0   322 _P3	=	0x00b0
                           000096   323 _P3_MOD_OC	=	0x0096
                           000097   324 _P3_DIR_PU	=	0x0097
                           0000C0   325 _P4	=	0x00c0
                           0000C2   326 _P4_MOD_OC	=	0x00c2
                           0000C3   327 _P4_DIR_PU	=	0x00c3
                           0000C1   328 _P4_LED_KEY	=	0x00c1
                           0000AA   329 _P5_IN	=	0x00aa
                           0000AB   330 _P5_OUT_PU	=	0x00ab
                           0000AC   331 _P5_DIR	=	0x00ac
                           0000AD   332 _P6_IN	=	0x00ad
                           0000AE   333 _P6_OUT_PU	=	0x00ae
                           0000AF   334 _P6_DIR	=	0x00af
                           0000F1   335 _P7	=	0x00f1
                           0000A2   336 _XBUS_AUX	=	0x00a2
                           000088   337 _TCON	=	0x0088
                           000089   338 _TMOD	=	0x0089
                           00008A   339 _TL0	=	0x008a
                           00008B   340 _TL1	=	0x008b
                           00008C   341 _TH0	=	0x008c
                           00008D   342 _TH1	=	0x008d
                           000098   343 _SCON	=	0x0098
                           000099   344 _SBUF	=	0x0099
                           0000C8   345 _T2CON	=	0x00c8
                           0000C9   346 _T2MOD	=	0x00c9
                           00CBCA   347 _RCAP2	=	0xcbca
                           0000CA   348 _RCAP2L	=	0x00ca
                           0000CB   349 _RCAP2H	=	0x00cb
                           00CDCC   350 _T2COUNT	=	0xcdcc
                           0000CC   351 _TL2	=	0x00cc
                           0000CD   352 _TH2	=	0x00cd
                           00CFCE   353 _T2CAP1	=	0xcfce
                           0000CE   354 _T2CAP1L	=	0x00ce
                           0000CF   355 _T2CAP1H	=	0x00cf
                           0000F8   356 _SPI0_STAT	=	0x00f8
                           0000F9   357 _SPI0_DATA	=	0x00f9
                           0000FA   358 _SPI0_CTRL	=	0x00fa
                           0000FB   359 _SPI0_CK_SE	=	0x00fb
                           0000FC   360 _SPI0_SETUP	=	0x00fc
                           0000BC   361 _SCON1	=	0x00bc
                           0000BD   362 _SBUF1	=	0x00bd
                           0000BE   363 _SBAUD1	=	0x00be
                           0000BF   364 _SIF1	=	0x00bf
                           0000B4   365 _SPI1_STAT	=	0x00b4
                           0000B5   366 _SPI1_DATA	=	0x00b5
                           0000B6   367 _SPI1_CTRL	=	0x00b6
                           0000B7   368 _SPI1_CK_SE	=	0x00b7
                           0000F3   369 _ADC_CTRL	=	0x00f3
                           00F5F4   370 _ADC_DAT	=	0xf5f4
                           0000F4   371 _ADC_DAT_L	=	0x00f4
                           0000F5   372 _ADC_DAT_H	=	0x00f5
                           0000F6   373 _ADC_CHAN	=	0x00f6
                           0000A6   374 _LED_COMMON	=	0x00a6
                           0000A7   375 _LED_PWM_OE	=	0x00a7
                           00C7C6   376 _LED_DMA	=	0xc7c6
                           0000C6   377 _LED_DMA_L	=	0x00c6
                           0000C7   378 _LED_DMA_H	=	0x00c7
                           0000F7   379 _LED_STATUS	=	0x00f7
                           0000B3   380 _I2CX_INT	=	0x00b3
                           0000BB   381 _I2CS_INT_ST	=	0x00bb
                                    382 ;--------------------------------------------------------
                                    383 ; special function bits
                                    384 ;--------------------------------------------------------
                                    385 	.area RSEG    (ABS,DATA)
      000000                        386 	.org 0x0000
                           0000D7   387 _CY	=	0x00d7
                           0000D6   388 _AC	=	0x00d6
                           0000D5   389 _F0	=	0x00d5
                           0000D4   390 _RS1	=	0x00d4
                           0000D3   391 _RS0	=	0x00d3
                           0000D2   392 _OV	=	0x00d2
                           0000D1   393 _F1	=	0x00d1
                           0000D0   394 _P	=	0x00d0
                           0000AF   395 _EA	=	0x00af
                           0000AE   396 _E_DIS	=	0x00ae
                           0000AD   397 _ET2	=	0x00ad
                           0000AC   398 _ES	=	0x00ac
                           0000AB   399 _ET1	=	0x00ab
                           0000AA   400 _EX1	=	0x00aa
                           0000A9   401 _ET0	=	0x00a9
                           0000A8   402 _EX0	=	0x00a8
                           0000BF   403 _PH_FLAG	=	0x00bf
                           0000BE   404 _PL_FLAG	=	0x00be
                           0000BD   405 _PT2	=	0x00bd
                           0000BC   406 _PS	=	0x00bc
                           0000BB   407 _PT1	=	0x00bb
                           0000BA   408 _PX1	=	0x00ba
                           0000B9   409 _PT0	=	0x00b9
                           0000B8   410 _PX0	=	0x00b8
                           0000EF   411 _IE_WDOG	=	0x00ef
                           0000EE   412 _IE_GPIO	=	0x00ee
                           0000ED   413 _IE_PWM_I2C	=	0x00ed
                           0000EC   414 _IE_UART1	=	0x00ec
                           0000EB   415 _IE_ADC	=	0x00eb
                           0000E9   416 _IE_USB	=	0x00e9
                           0000E8   417 _IE_SPI0	=	0x00e8
                           000087   418 _P0_7	=	0x0087
                           000086   419 _P0_6	=	0x0086
                           000085   420 _P0_5	=	0x0085
                           000084   421 _P0_4	=	0x0084
                           000083   422 _P0_3	=	0x0083
                           000082   423 _P0_2	=	0x0082
                           000081   424 _P0_1	=	0x0081
                           000080   425 _P0_0	=	0x0080
                           000081   426 _SDA0	=	0x0081
                           000080   427 _SCL0	=	0x0080
                           000083   428 _TXD_	=	0x0083
                           000082   429 _RXD_	=	0x0082
                           000085   430 _AIN13	=	0x0085
                           000084   431 _AIN12	=	0x0084
                           000083   432 _AIN11	=	0x0083
                           000082   433 _AIN10	=	0x0082
                           000081   434 _AIN9	=	0x0081
                           000080   435 _AIN8	=	0x0080
                           000097   436 _P1_7	=	0x0097
                           000096   437 _P1_6	=	0x0096
                           000095   438 _P1_5	=	0x0095
                           000094   439 _P1_4	=	0x0094
                           000093   440 _P1_3	=	0x0093
                           000092   441 _P1_2	=	0x0092
                           000091   442 _P1_1	=	0x0091
                           000090   443 _P1_0	=	0x0090
                           000097   444 _TXD1_	=	0x0097
                           000096   445 _RXD1_	=	0x0096
                           000097   446 _SCK	=	0x0097
                           000096   447 _MISO	=	0x0096
                           000095   448 _MOSI	=	0x0095
                           000094   449 _SCS	=	0x0094
                           000092   450 _INT0_	=	0x0092
                           000091   451 _T2EX	=	0x0091
                           000091   452 _CAP2	=	0x0091
                           000090   453 _T2	=	0x0090
                           000090   454 _CAP1	=	0x0090
                           000097   455 _AIN7	=	0x0097
                           000096   456 _AIN6	=	0x0096
                           000095   457 _AIN5	=	0x0095
                           000094   458 _AIN4	=	0x0094
                           000093   459 _AIN3	=	0x0093
                           000092   460 _AIN2	=	0x0092
                           000091   461 _AIN1	=	0x0091
                           000090   462 _AIN0	=	0x0090
                           0000A7   463 _P2_7	=	0x00a7
                           0000A6   464 _P2_6	=	0x00a6
                           0000A5   465 _P2_5	=	0x00a5
                           0000A4   466 _P2_4	=	0x00a4
                           0000A3   467 _P2_3	=	0x00a3
                           0000A2   468 _P2_2	=	0x00a2
                           0000A1   469 _P2_1	=	0x00a1
                           0000A0   470 _P2_0	=	0x00a0
                           0000A7   471 _TXD1	=	0x00a7
                           0000A6   472 _RXD1	=	0x00a6
                           0000A5   473 _T2EX_	=	0x00a5
                           0000A5   474 _CAP2_	=	0x00a5
                           0000A4   475 _T2_	=	0x00a4
                           0000A4   476 _CAP1_	=	0x00a4
                           0000B7   477 _P3_7	=	0x00b7
                           0000B6   478 _P3_6	=	0x00b6
                           0000B5   479 _P3_5	=	0x00b5
                           0000B4   480 _P3_4	=	0x00b4
                           0000B3   481 _P3_3	=	0x00b3
                           0000B2   482 _P3_2	=	0x00b2
                           0000B1   483 _P3_1	=	0x00b1
                           0000B0   484 _P3_0	=	0x00b0
                           0000B7   485 _SCK1	=	0x00b7
                           0000B6   486 _MISO1	=	0x00b6
                           0000B5   487 _MOSI1	=	0x00b5
                           0000B5   488 _T1	=	0x00b5
                           0000B4   489 _T0	=	0x00b4
                           0000B3   490 _INT1	=	0x00b3
                           0000B2   491 _INT0	=	0x00b2
                           0000B1   492 _TXD	=	0x00b1
                           0000B0   493 _RXD	=	0x00b0
                           0000C6   494 _P4_6	=	0x00c6
                           0000C5   495 _P4_5	=	0x00c5
                           0000C4   496 _P4_4	=	0x00c4
                           0000C3   497 _P4_3	=	0x00c3
                           0000C2   498 _P4_2	=	0x00c2
                           0000C1   499 _P4_1	=	0x00c1
                           0000C0   500 _P4_0	=	0x00c0
                           00008F   501 _TF1	=	0x008f
                           00008E   502 _TR1	=	0x008e
                           00008D   503 _TF0	=	0x008d
                           00008C   504 _TR0	=	0x008c
                           00008B   505 _IE1	=	0x008b
                           00008A   506 _IT1	=	0x008a
                           000089   507 _IE0	=	0x0089
                           000088   508 _IT0	=	0x0088
                           00009F   509 _SM0	=	0x009f
                           00009E   510 _SM1	=	0x009e
                           00009D   511 _SM2	=	0x009d
                           00009C   512 _REN	=	0x009c
                           00009B   513 _TB8	=	0x009b
                           00009A   514 _RB8	=	0x009a
                           000099   515 _TI	=	0x0099
                           000098   516 _RI	=	0x0098
                           0000CF   517 _TF2	=	0x00cf
                           0000CF   518 _CAP1F	=	0x00cf
                           0000CE   519 _EXF2	=	0x00ce
                           0000CD   520 _RCLK	=	0x00cd
                           0000CC   521 _TCLK	=	0x00cc
                           0000CB   522 _EXEN2	=	0x00cb
                           0000CA   523 _TR2	=	0x00ca
                           0000C9   524 _C_T2	=	0x00c9
                           0000C8   525 _CP_RL2	=	0x00c8
                           0000FF   526 _S0_FST_ACT	=	0x00ff
                           0000FE   527 _S0_IF_OV	=	0x00fe
                           0000FD   528 _S0_IF_FIRST	=	0x00fd
                           0000FC   529 _S0_IF_BYTE	=	0x00fc
                           0000FB   530 _S0_FREE	=	0x00fb
                           0000FA   531 _S0_T_FIFO	=	0x00fa
                           0000F8   532 _S0_R_FIFO	=	0x00f8
                           0000F7   533 _ADC_START	=	0x00f7
                                    534 ;--------------------------------------------------------
                                    535 ; overlayable register banks
                                    536 ;--------------------------------------------------------
                                    537 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        538 	.ds 8
                                    539 ;--------------------------------------------------------
                                    540 ; internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area DSEG    (DATA)
      000042                        543 _vial_handle_cmd_sloc0_1_0:
      000042                        544 	.ds 2
      000044                        545 _vial_handle_cmd_sloc1_1_0:
      000044                        546 	.ds 2
      000046                        547 _vial_handle_cmd_sloc2_1_0:
      000046                        548 	.ds 2
      000048                        549 _vial_handle_cmd_sloc3_1_0:
      000048                        550 	.ds 2
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 ;--------------------------------------------------------
                                    555 ; indirectly addressable internal ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area ISEG    (DATA)
                                    558 ;--------------------------------------------------------
                                    559 ; absolute internal ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area IABS    (ABS,DATA)
                                    562 	.area IABS    (ABS,DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; bit data
                                    565 ;--------------------------------------------------------
                                    566 	.area BSEG    (BIT)
                                    567 ;--------------------------------------------------------
                                    568 ; paged external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area PSEG    (PAG,XDATA)
                                    571 ;--------------------------------------------------------
                                    572 ; uninitialized external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area XSEG    (XDATA)
      000D09                        575 _vial_unlock_timer:
      000D09                        576 	.ds 4
      000D0D                        577 _vial_unlock_holding:
      000D0D                        578 	.ds 1
      000D0E                        579 _vial_keycode_firewall_in_10000_611:
      000D0E                        580 	.ds 2
      000D10                        581 _vial_fill_packet_PARM_2:
      000D10                        582 	.ds 1
      000D11                        583 _vial_fill_packet_msg_10000_614:
      000D11                        584 	.ds 2
      000D13                        585 _vial_handle_cmd_PARM_2:
      000D13                        586 	.ds 1
      000D14                        587 _vial_handle_cmd_data_10000_619:
      000D14                        588 	.ds 3
      000D17                        589 _vial_handle_cmd_td_70000_647:
      000D17                        590 	.ds 10
      000D21                        591 _vial_handle_cmd_td_70000_648:
      000D21                        592 	.ds 10
      000D2B                        593 _vial_handle_cmd_entry_70000_649:
      000D2B                        594 	.ds 10
      000D35                        595 _vial_handle_cmd_entry_70000_650:
      000D35                        596 	.ds 10
      000D3F                        597 _g_vial_magic_keycode_override::
      000D3F                        598 	.ds 2
      000D41                        599 _vial_keycode_down_keycode_10000_652:
      000D41                        600 	.ds 2
      000D43                        601 _vial_keycode_down_dummy_event_30000_659:
      000D43                        602 	.ds 6
      000D49                        603 _vial_keycode_up_keycode_10000_660:
      000D49                        604 	.ds 2
      000D4B                        605 _vial_keycode_up_dummy_event_30000_667:
      000D4B                        606 	.ds 6
      000D51                        607 _vial_keycode_tap_keycode_10000_668:
      000D51                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
      000EE7                        617 _vial_unlocked::
      000EE7                        618 	.ds 1
      000EE8                        619 _vial_unlock_in_progress::
      000EE8                        620 	.ds 1
      000EE9                        621 _vial_unlock_counter:
      000EE9                        622 	.ds 1
      000EEA                        623 _vial_unlock_combo_rows:
      000EEA                        624 	.ds 2
      000EEC                        625 _vial_unlock_combo_cols:
      000EEC                        626 	.ds 2
                                    627 	.area HOME    (CODE)
                                    628 	.area GSINIT0 (CODE)
                                    629 	.area GSINIT1 (CODE)
                                    630 	.area GSINIT2 (CODE)
                                    631 	.area GSINIT3 (CODE)
                                    632 	.area GSINIT4 (CODE)
                                    633 	.area GSINIT5 (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 	.area GSFINAL (CODE)
                                    636 	.area CSEG    (CODE)
                                    637 ;--------------------------------------------------------
                                    638 ; global & static initialisations
                                    639 ;--------------------------------------------------------
                                    640 	.area HOME    (CODE)
                                    641 	.area GSINIT  (CODE)
                                    642 	.area GSFINAL (CODE)
                                    643 	.area GSINIT  (CODE)
                                    644 ;--------------------------------------------------------
                                    645 ; Home
                                    646 ;--------------------------------------------------------
                                    647 	.area HOME    (CODE)
                                    648 	.area HOME    (CODE)
                                    649 ;--------------------------------------------------------
                                    650 ; code
                                    651 ;--------------------------------------------------------
                                    652 	.area CSEG    (CODE)
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    655 ;------------------------------------------------------------
                                    656 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    657 ;------------------------------------------------------------
                                    658 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    659 ;	-----------------------------------------
                           000007   660 	ar7 = 0x07
                           000006   661 	ar6 = 0x06
                           000005   662 	ar5 = 0x05
                           000004   663 	ar4 = 0x04
                           000003   664 	ar3 = 0x03
                           000002   665 	ar2 = 0x02
                           000001   666 	ar1 = 0x01
                           000000   667 	ar0 = 0x00
                                    668 ;	 function vial_unlock_task
                                    669 ;	-----------------------------------------
      00B0C0                        670 _vial_unlock_task:
                                    671 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B0C0 90 0E E8         [24]  672 	mov	dptr,#_vial_unlock_in_progress
      00B0C3 E0               [24]  673 	movx	a,@dptr
      00B0C4 70 01            [24]  674 	jnz	00131$
      00B0C6 22               [24]  675 	ret
                                    676 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B0C7                        677 00131$:
      00B0C7 7F 00            [12]  678 	mov	r7,#0x00
      00B0C9                        679 00115$:
      00B0C9 BF 02 00         [24]  680 	cjne	r7,#0x02,00184$
      00B0CC                        681 00184$:
      00B0CC 50 29            [24]  682 	jnc	00105$
                                    683 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B0CE EF               [12]  684 	mov	a,r7
      00B0CF 12 B7 31         [24]  685 	lcall	_ak820_outline_0131
      00B0D2 FE               [12]  686 	mov	r6,a
      00B0D3 EF               [12]  687 	mov	a,r7
      00B0D4 12 B7 26         [24]  688 	lcall	_ak820_outline_0130
      00B0D7 90 08 25         [24]  689 	mov	dptr,#_matrix_is_on_PARM_2
      00B0DA F0               [24]  690 	movx	@dptr,a
      00B0DB 8E 82            [24]  691 	mov	dpl, r6
      00B0DD C0 07            [24]  692 	push	ar7
      00B0DF 12 5E 11         [24]  693 	lcall	_matrix_is_on
      00B0E2 E5 82            [12]  694 	mov	a, dpl
      00B0E4 D0 07            [24]  695 	pop	ar7
      00B0E6 70 0C            [24]  696 	jnz	00116$
                                    697 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B0E8 90 0D 0D         [24]  698 	mov	dptr,#_vial_unlock_holding
      00B0EB E4               [12]  699 	clr	a
      00B0EC F0               [24]  700 	movx	@dptr,a
                                    701 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B0ED 90 0E E9         [24]  702 	mov	dptr,#_vial_unlock_counter
      00B0F0 74 1E            [12]  703 	mov	a,#0x1e
      00B0F2 F0               [24]  704 	movx	@dptr,a
                                    705 ;	quantum/vial.c:69: return;
      00B0F3 22               [24]  706 	ret
      00B0F4                        707 00116$:
                                    708 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B0F4 0F               [12]  709 	inc	r7
      00B0F5 80 D2            [24]  710 	sjmp	00115$
      00B0F7                        711 00105$:
                                    712 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B0F7 90 0D 0D         [24]  713 	mov	dptr,#_vial_unlock_holding
      00B0FA E0               [24]  714 	movx	a,@dptr
      00B0FB 70 12            [24]  715 	jnz	00107$
                                    716 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B0FD 90 0D 0D         [24]  717 	mov	dptr,#_vial_unlock_holding
      00B100 74 01            [12]  718 	mov	a,#0x01
      00B102 F0               [24]  719 	movx	@dptr,a
                                    720 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B103 12 4E 09         [24]  721 	lcall	_timer_read32
      00B106 12 54 1A         [24]  722 	lcall	_ak820_outline_0062
      00B109 90 0D 09         [24]  723 	mov	dptr,#_vial_unlock_timer
      00B10C 12 95 6B         [24]  724 	lcall	_ak820_outline_0009
      00B10F                        725 00107$:
                                    726 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B10F 90 0D 09         [24]  727 	mov	dptr,#_vial_unlock_timer
      00B112 12 54 09         [24]  728 	lcall	_ak820_outline_0061
      00B115 12 4E 62         [24]  729 	lcall	_timer_elapsed32
      00B118 12 54 1A         [24]  730 	lcall	_ak820_outline_0062
                                    731 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B11B 7B 1E            [12]  732 	mov	r3,#0x1e
      00B11D                        733 00109$:
      00B11D EB               [12]  734 	mov	a,r3
      00B11E 60 22            [24]  735 	jz	00111$
      00B120 C3               [12]  736 	clr	c
      00B121 EC               [12]  737 	mov	a,r4
      00B122 94 64            [12]  738 	subb	a,#0x64
      00B124 ED               [12]  739 	mov	a,r5
      00B125 94 00            [12]  740 	subb	a,#0x00
      00B127 EE               [12]  741 	mov	a,r6
      00B128 94 00            [12]  742 	subb	a,#0x00
      00B12A EF               [12]  743 	mov	a,r7
      00B12B 94 00            [12]  744 	subb	a,#0x00
      00B12D 40 13            [24]  745 	jc	00111$
                                    746 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B12F EC               [12]  747 	mov	a,r4
      00B130 24 9C            [12]  748 	add	a,#0x9c
      00B132 FC               [12]  749 	mov	r4,a
      00B133 ED               [12]  750 	mov	a,r5
      00B134 34 FF            [12]  751 	addc	a,#0xff
      00B136 FD               [12]  752 	mov	r5,a
      00B137 EE               [12]  753 	mov	a,r6
      00B138 34 FF            [12]  754 	addc	a,#0xff
      00B13A FE               [12]  755 	mov	r6,a
      00B13B EF               [12]  756 	mov	a,r7
      00B13C 34 FF            [12]  757 	addc	a,#0xff
      00B13E FF               [12]  758 	mov	r7,a
                                    759 ;	quantum/vial.c:82: --counter;
      00B13F 1B               [12]  760 	dec	r3
      00B140 80 DB            [24]  761 	sjmp	00109$
      00B142                        762 00111$:
                                    763 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B142 90 0E E9         [24]  764 	mov	dptr,#_vial_unlock_counter
      00B145 EB               [12]  765 	mov	a,r3
      00B146 F0               [24]  766 	movx	@dptr,a
                                    767 ;	quantum/vial.c:85: if (!counter) {
      00B147 EB               [12]  768 	mov	a,r3
      00B148 70 0A            [24]  769 	jnz	00117$
                                    770 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B14A 90 0E E8         [24]  771 	mov	dptr,#_vial_unlock_in_progress
      00B14D E4               [12]  772 	clr	a
      00B14E F0               [24]  773 	movx	@dptr,a
                                    774 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B14F 90 0E E7         [24]  775 	mov	dptr,#_vial_unlocked
      00B152 04               [12]  776 	inc	a
      00B153 F0               [24]  777 	movx	@dptr,a
      00B154                        778 00117$:
                                    779 ;	quantum/vial.c:90: }
      00B154 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'vial_init'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/vial.c:117: void vial_init(void) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function vial_init
                                    787 ;	-----------------------------------------
      00B155                        788 _vial_init:
                                    789 ;	quantum/vial.c:125: reload_combo();
                                    790 ;	quantum/vial.c:130: }
      00B155 02 35 39         [24]  791 	ljmp	_ak820_combo_reload
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    794 ;------------------------------------------------------------
                                    795 ;in            Allocated with name '_vial_keycode_firewall_in_10000_611'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function vial_keycode_firewall
                                    800 ;	-----------------------------------------
      00B158                        801 _vial_keycode_firewall:
      00B158 12 38 4E         [24]  802 	lcall	_ak820_outline_0109
      00B15B 90 0D 0E         [24]  803 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B15E 12 38 49         [24]  804 	lcall	_ak820_outline_0108
                                    805 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B161 90 0D 0E         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B164 12 37 C6         [24]  807 	lcall	_ak820_outline_0010
      00B167 BC 00 0D         [24]  808 	cjne	r4,#0x00,00102$
      00B16A BD 7C 0A         [24]  809 	cjne	r5,#0x7c,00102$
      00B16D 90 0E E7         [24]  810 	mov	dptr,#_vial_unlocked
      00B170 E0               [24]  811 	movx	a,@dptr
      00B171 70 04            [24]  812 	jnz	00102$
                                    813 ;	quantum/vial.c:134: return 0;
      00B173 90 00 00         [24]  814 	mov	dptr,#0x0000
      00B176 22               [24]  815 	ret
      00B177                        816 00102$:
                                    817 ;	quantum/vial.c:135: return in;
      00B177 12 43 17         [24]  818 	lcall	_ak820_outline_0119
                                    819 ;	quantum/vial.c:136: }
      00B17A 22               [24]  820 	ret
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'vial_fill_packet'
                                    823 ;------------------------------------------------------------
                                    824 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    825 ;msg           Allocated with name '_vial_fill_packet_msg_10000_614'
                                    826 ;i             Allocated with name '_vial_fill_packet_i_20000_616'
                                    827 ;------------------------------------------------------------
                                    828 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    829 ;	-----------------------------------------
                                    830 ;	 function vial_fill_packet
                                    831 ;	-----------------------------------------
      00B17B                        832 _vial_fill_packet:
      00B17B 12 38 4E         [24]  833 	lcall	_ak820_outline_0109
      00B17E 90 0D 11         [24]  834 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B181 12 38 49         [24]  835 	lcall	_ak820_outline_0108
                                    836 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B184 90 0D 11         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B187 12 37 FB         [24]  838 	lcall	_ak820_outline_0058
      00B18A 90 0D 10         [24]  839 	mov	dptr,#_vial_fill_packet_PARM_2
      00B18D E0               [24]  840 	movx	a,@dptr
      00B18E FD               [12]  841 	mov	r5,a
      00B18F 7C 00            [12]  842 	mov	r4,#0x00
      00B191                        843 00103$:
      00B191 BC 20 00         [24]  844 	cjne	r4,#0x20,00122$
      00B194                        845 00122$:
      00B194 50 09            [24]  846 	jnc	00105$
      00B196 EC               [12]  847 	mov	a,r4
      00B197 12 37 F3         [24]  848 	lcall	_ak820_outline_0036
      00B19A ED               [12]  849 	mov	a,r5
      00B19B F0               [24]  850 	movx	@dptr,a
      00B19C 0C               [12]  851 	inc	r4
      00B19D 80 F2            [24]  852 	sjmp	00103$
      00B19F                        853 00105$:
                                    854 ;	quantum/vial.c:141: }
      00B19F 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'vial_release_held_state'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function vial_release_held_state
                                    862 ;	-----------------------------------------
      00B1A0                        863 _vial_release_held_state:
                                    864 ;	quantum/vial.c:174: repeat_key_cancel();
      00B1A0 12 A5 B0         [24]  865 	lcall	_repeat_key_cancel
                                    866 ;	quantum/vial.c:176: clear_keyboard();
                                    867 ;	quantum/vial.c:177: }
      00B1A3 02 7A ED         [24]  868 	ljmp	_clear_keyboard
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    871 ;------------------------------------------------------------
                                    872 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    873 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    874 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    875 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    876 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    877 ;data          Allocated with name '_vial_handle_cmd_data_10000_619'
                                    878 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_620'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50000_625'
                                    880 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_626'
                                    881 ;page          Allocated with name '_vial_handle_cmd_page_40001_629'
                                    882 ;start         Allocated with name '_vial_handle_cmd_start_40002_631'
                                    883 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_631'
                                    884 ;count         Allocated with name '_vial_handle_cmd_count_40002_631'
                                    885 ;i             Allocated with name '_vial_handle_cmd_i_50002_632'
                                    886 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_633'
                                    887 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_633'
                                    888 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_633'
                                    889 ;i             Allocated with name '_vial_handle_cmd_i_50000_636'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    891 ;td            Allocated with name '_vial_handle_cmd_td_70000_647'
                                    892 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_648'
                                    893 ;td            Allocated with name '_vial_handle_cmd_td_70000_648'
                                    894 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_649'
                                    895 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_649'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_650'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_650'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function vial_handle_cmd
                                    902 ;	-----------------------------------------
      00B1A6                        903 _vial_handle_cmd:
      00B1A6 12 42 CE         [24]  904 	lcall	_ak820_outline_0042
      00B1A9 90 0D 14         [24]  905 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B1AC 12 37 E3         [24]  906 	lcall	_ak820_outline_0019
                                    907 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B1AF 90 0D 14         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B1B2 12 37 FB         [24]  909 	lcall	_ak820_outline_0058
                                    910 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B1B5 90 0D 13         [24]  911 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B1B8 E0               [24]  912 	movx	a,@dptr
      00B1B9 FD               [12]  913 	mov	r5,a
      00B1BA BD 20 02         [24]  914 	cjne	r5,#0x20,00246$
      00B1BD 80 01            [24]  915 	sjmp	00102$
      00B1BF                        916 00246$:
                                    917 ;	quantum/vial.c:190: return;
      00B1BF 22               [24]  918 	ret
      00B1C0                        919 00102$:
                                    920 ;	quantum/vial.c:193: switch (msg[1]) {
      00B1C0 74 01            [12]  921 	mov	a,#0x01
      00B1C2 12 93 83         [24]  922 	lcall	_ak820_outline_0053
      00B1C5 FB               [12]  923 	mov  r3,a
      00B1C6 24 F2            [12]  924 	add	a,#0xff - 0x0d
      00B1C8 50 01            [24]  925 	jnc	00247$
      00B1CA 22               [24]  926 	ret
      00B1CB                        927 00247$:
                                    928 ;	free result
      00B1CB EB               [12]  929 	mov	a,r3
      00B1CC 24 0A            [12]  930 	add	a,#(00248$-3-.)
      00B1CE 83               [24]  931 	movc	a,@a+pc
      00B1CF F5 82            [12]  932 	mov	dpl,a
      00B1D1 EB               [12]  933 	mov	a,r3
      00B1D2 24 12            [12]  934 	add	a,#(00249$-3-.)
      00B1D4 83               [24]  935 	movc	a,@a+pc
      00B1D5 F5 83            [12]  936 	mov	dph,a
      00B1D7 E4               [12]  937 	clr	a
      00B1D8 73               [24]  938 	jmp	@a+dptr
      00B1D9                        939 00248$:
      00B1D9 F5                     940 	.db	00103$
      00B1DA 3D                     941 	.db	00105$
      00B1DB 52                     942 	.db	00106$
      00B1DC DE                     943 	.db	00112$
      00B1DD 65                     944 	.db	00113$
      00B1DE AF                     945 	.db	00114$
      00B1DF 1E                     946 	.db	00116$
      00B1E0 39                     947 	.db	00119$
      00B1E1 58                     948 	.db	00120$
      00B1E2 66                     949 	.db	00121$
      00B1E3 14                     950 	.db	00141$
      00B1E4 14                     951 	.db	00141$
      00B1E5 14                     952 	.db	00141$
      00B1E6 71                     953 	.db	00122$
      00B1E7                        954 00249$:
      00B1E7 B1                     955 	.db	00103$>>8
      00B1E8 B2                     956 	.db	00105$>>8
      00B1E9 B2                     957 	.db	00106$>>8
      00B1EA B2                     958 	.db	00112$>>8
      00B1EB B3                     959 	.db	00113$>>8
      00B1EC B3                     960 	.db	00114$>>8
      00B1ED B4                     961 	.db	00116$>>8
      00B1EE B4                     962 	.db	00119$>>8
      00B1EF B4                     963 	.db	00120$>>8
      00B1F0 B4                     964 	.db	00121$>>8
      00B1F1 B6                     965 	.db	00141$>>8
      00B1F2 B6                     966 	.db	00141$>>8
      00B1F3 B6                     967 	.db	00141$>>8
      00B1F4 B4                     968 	.db	00122$>>8
                                    969 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B1F5                        970 00103$:
                                    971 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B1F5 90 0D 10         [24]  972 	mov	dptr,#_vial_fill_packet_PARM_2
      00B1F8 E4               [12]  973 	clr	a
      00B1F9 12 42 F2         [24]  974 	lcall	_ak820_outline_0066
      00B1FC C0 07            [24]  975 	push	ar7
      00B1FE C0 06            [24]  976 	push	ar6
      00B200 12 B1 7B         [24]  977 	lcall	_vial_fill_packet
      00B203 D0 06            [24]  978 	pop	ar6
      00B205 D0 07            [24]  979 	pop	ar7
                                    980 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B207 12 43 17         [24]  981 	lcall	_ak820_outline_0119
      00B20A 74 06            [12]  982 	mov	a,#0x06
      00B20C 12 42 F2         [24]  983 	lcall	_ak820_outline_0066
                                    984 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B20F A3               [24]  985 	inc	dptr
      00B210 E4               [12]  986 	clr	a
      00B211 12 42 C6         [24]  987 	lcall	_ak820_outline_0037
                                    988 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B214 12 42 C6         [24]  989 	lcall	_ak820_outline_0037
                                    990 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B217 A3               [24]  991 	inc	dptr
      00B218 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B219 FB               [12]  994 	mov	r3,a
      00B21A                        995 00133$:
      00B21A BB 08 00         [24]  996 	cjne	r3,#0x08,00250$
      00B21D                        997 00250$:
      00B21D 50 15            [24]  998 	jnc	00104$
      00B21F 8B 02            [24]  999 	mov	ar2,r3
      00B221 74 04            [12] 1000 	mov	a,#0x04
      00B223 2A               [12] 1001 	add	a, r2
      00B224 2E               [12] 1002 	add	a, r6
      00B225 F9               [12] 1003 	mov	r1,a
      00B226 E4               [12] 1004 	clr	a
      00B227 3F               [12] 1005 	addc	a,r7
      00B228 FA               [12] 1006 	mov	r2,a
      00B229 EB               [12] 1007 	mov	a,r3
      00B22A 90 C3 CC         [24] 1008 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_624
      00B22D 93               [24] 1009 	movc	a,@a+dptr
      00B22E 12 71 02         [24] 1010 	lcall	_ak820_outline_0140
      00B231 0B               [12] 1011 	inc	r3
      00B232 80 E6            [24] 1012 	sjmp	00133$
      00B234                       1013 00104$:
                                   1014 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B234 74 0C            [12] 1015 	mov	a,#0x0c
      00B236 12 37 F3         [24] 1016 	lcall	_ak820_outline_0036
      00B239 74 01            [12] 1017 	mov	a,#0x01
      00B23B F0               [24] 1018 	movx	@dptr,a
                                   1019 ;	quantum/vial.c:207: break;
      00B23C 22               [24] 1020 	ret
                                   1021 ;	quantum/vial.c:210: case vial_get_size: {
      00B23D                       1022 00105$:
                                   1023 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B23D 12 43 17         [24] 1024 	lcall	_ak820_outline_0119
      00B240 74 7C            [12] 1025 	mov	a,#0x7c
      00B242 F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B243 12 38 59         [24] 1028 	lcall	_ak820_outline_0127
      00B246 74 01            [12] 1029 	mov	a,#0x01
      00B248 12 42 C6         [24] 1030 	lcall	_ak820_outline_0037
                                   1031 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B24B E4               [12] 1032 	clr	a
      00B24C 12 42 C6         [24] 1033 	lcall	_ak820_outline_0037
                                   1034 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B24F A3               [24] 1035 	inc	dptr
      00B250 F0               [24] 1036 	movx	@dptr,a
                                   1037 ;	quantum/vial.c:216: break;
      00B251 22               [24] 1038 	ret
                                   1039 ;	quantum/vial.c:219: case vial_get_def: {
      00B252                       1040 00106$:
                                   1041 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B252 12 B0 84         [24] 1042 	lcall	_ak820_outline_0023
      00B255 E0               [24] 1043 	movx	a,@dptr
      00B256 FB               [12] 1044 	mov	r3,a
      00B257 12 42 BC         [24] 1045 	lcall	_ak820_outline_0012
      00B25A E0               [24] 1046 	movx	a,@dptr
      00B25B 4B               [12] 1047 	orl	a,r3
      00B25C 60 01            [24] 1048 	jz	00108$
      00B25E 22               [24] 1049 	ret
      00B25F                       1050 00108$:
                                   1051 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B25F 12 37 EB         [24] 1052 	lcall	_ak820_outline_0035
      00B262 FB               [12] 1053 	mov	r3,a
      00B263 7A 00            [12] 1054 	mov	r2,#0x00
      00B265 12 48 7B         [24] 1055 	lcall	_ak820_outline_0016
      00B268 F9               [12] 1056 	mov	r1,a
      00B269 E4               [12] 1057 	clr	a
      00B26A 42 03            [12] 1058 	orl	ar3,a
      00B26C E9               [12] 1059 	mov	a,r1
      00B26D 42 02            [12] 1060 	orl	ar2,a
                                   1061 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B26F C3               [12] 1062 	clr	c
      00B270 EB               [12] 1063 	mov	a,r3
      00B271 94 0C            [12] 1064 	subb	a,#0x0c
      00B273 EA               [12] 1065 	mov	a,r2
      00B274 94 00            [12] 1066 	subb	a,#0x00
      00B276 40 01            [24] 1067 	jc	00110$
      00B278 22               [24] 1068 	ret
      00B279                       1069 00110$:
                                   1070 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B279 EA               [12] 1071 	mov	a,r2
      00B27A C4               [12] 1072 	swap	a
      00B27B 23               [12] 1073 	rl	a
      00B27C 54 E0            [12] 1074 	anl	a,#0xe0
      00B27E CB               [12] 1075 	xch	a,r3
      00B27F C4               [12] 1076 	swap	a
      00B280 23               [12] 1077 	rl	a
      00B281 CB               [12] 1078 	xch	a,r3
      00B282 6B               [12] 1079 	xrl	a,r3
      00B283 CB               [12] 1080 	xch	a,r3
      00B284 54 E0            [12] 1081 	anl	a,#0xe0
      00B286 CB               [12] 1082 	xch	a,r3
      00B287 6B               [12] 1083 	xrl	a,r3
      00B288 FA               [12] 1084 	mov	r2,a
      00B289 8B 42            [24] 1085 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B28B 8A 43            [24] 1086 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1087 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B28D 74 7C            [12] 1088 	mov	a,#0x7c
      00B28F C3               [12] 1089 	clr	c
      00B290 95 42            [12] 1090 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B292 F8               [12] 1091 	mov	r0,a
      00B293 74 01            [12] 1092 	mov	a,#0x01
      00B295 95 43            [12] 1093 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B297 F9               [12] 1094 	mov	r1,a
                                   1095 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B298 C3               [12] 1096 	clr	c
      00B299 E8               [12] 1097 	mov	a,r0
      00B29A 94 20            [12] 1098 	subb	a,#0x20
      00B29C E9               [12] 1099 	mov	a,r1
      00B29D 94 00            [12] 1100 	subb	a,#0x00
      00B29F 40 02            [24] 1101 	jc	00144$
      00B2A1 78 20            [12] 1102 	mov	r0,#0x20
      00B2A3                       1103 00144$:
                                   1104 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B2A3 79 00            [12] 1105 	mov	r1,#0x00
      00B2A5                       1106 00136$:
      00B2A5 C3               [12] 1107 	clr	c
      00B2A6 E9               [12] 1108 	mov	a,r1
      00B2A7 98               [12] 1109 	subb	a,r0
      00B2A8 40 01            [24] 1110 	jc	00255$
      00B2AA 22               [24] 1111 	ret
      00B2AB                       1112 00255$:
      00B2AB C0 00            [24] 1113 	push	ar0
      00B2AD E9               [12] 1114 	mov	a,r1
      00B2AE 2E               [12] 1115 	add	a, r6
      00B2AF F5 44            [12] 1116 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B2B1 E4               [12] 1117 	clr	a
      00B2B2 3F               [12] 1118 	addc	a, r7
      00B2B3 F5 45            [12] 1119 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B2B5 89 46            [24] 1120 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B2B7 75 47 00         [24] 1121 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B2BA A8 42            [24] 1122 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B2BC AB 43            [24] 1123 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B2BE E5 46            [12] 1124 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B2C0 28               [12] 1125 	add	a, r0
      00B2C1 F8               [12] 1126 	mov	r0,a
      00B2C2 E5 47            [12] 1127 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B2C4 3B               [12] 1128 	addc	a, r3
      00B2C5 FB               [12] 1129 	mov	r3,a
      00B2C6 E8               [12] 1130 	mov	a,r0
      00B2C7 24 50            [12] 1131 	add	a, #_keyboard_definition
      00B2C9 F5 82            [12] 1132 	mov	dpl,a
      00B2CB EB               [12] 1133 	mov	a,r3
      00B2CC 34 C2            [12] 1134 	addc	a, #(_keyboard_definition >> 8)
      00B2CE F5 83            [12] 1135 	mov	dph,a
      00B2D0 E4               [12] 1136 	clr	a
      00B2D1 93               [24] 1137 	movc	a,@a+dptr
      00B2D2 85 44 82         [24] 1138 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B2D5 85 45 83         [24] 1139 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B2D8 F0               [24] 1140 	movx	@dptr,a
      00B2D9 09               [12] 1141 	inc	r1
      00B2DA D0 00            [24] 1142 	pop	ar0
                                   1143 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B2DC 80 C7            [24] 1144 	sjmp	00136$
      00B2DE                       1145 00112$:
                                   1146 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B2DE 74 02            [12] 1147 	mov	a,#0x02
      00B2E0 2E               [12] 1148 	add	a, r6
      00B2E1 12 48 9C         [24] 1149 	lcall	_ak820_outline_0034
      00B2E4 F5 46            [12] 1150 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1151 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B2E6 74 03            [12] 1152 	mov	a,#0x03
      00B2E8 2E               [12] 1153 	add	a, r6
      00B2E9 F5 44            [12] 1154 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B2EB E4               [12] 1155 	clr	a
      00B2EC 3F               [12] 1156 	addc	a, r7
      00B2ED F5 45            [12] 1157 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B2EF 85 44 82         [24] 1158 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B2F2 85 45 83         [24] 1159 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B2F5 E0               [24] 1160 	movx	a,@dptr
                                   1161 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B2F6 F5 42            [12] 1162 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B2F8 90 0B A5         [24] 1163 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B2FB F0               [24] 1164 	movx	@dptr,a
      00B2FC 90 0B A6         [24] 1165 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B2FF E4               [12] 1166 	clr	a
      00B300 F0               [24] 1167 	movx	@dptr,a
      00B301 85 46 82         [24] 1168 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B304 C0 07            [24] 1169 	push	ar7
      00B306 C0 06            [24] 1170 	push	ar6
      00B308 C0 05            [24] 1171 	push	ar5
      00B30A C0 04            [24] 1172 	push	ar4
      00B30C C0 03            [24] 1173 	push	ar3
      00B30E C0 02            [24] 1174 	push	ar2
      00B310 12 88 9A         [24] 1175 	lcall	_dynamic_keymap_get_encoder
      00B313 85 82 48         [24] 1176 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B316 85 83 49         [24] 1177 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B319 D0 02            [24] 1178 	pop	ar2
      00B31B D0 03            [24] 1179 	pop	ar3
      00B31D D0 04            [24] 1180 	pop	ar4
      00B31F D0 05            [24] 1181 	pop	ar5
      00B321 D0 06            [24] 1182 	pop	ar6
      00B323 D0 07            [24] 1183 	pop	ar7
                                   1184 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B325 A9 49            [24] 1185 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B327 12 43 17         [24] 1186 	lcall	_ak820_outline_0119
      00B32A E9               [12] 1187 	mov	a,r1
      00B32B F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B32C A8 48            [24] 1190 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B32E 12 38 59         [24] 1191 	lcall	_ak820_outline_0127
      00B331 E8               [12] 1192 	mov	a,r0
      00B332 F0               [24] 1193 	movx	@dptr,a
                                   1194 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B333 90 0B A5         [24] 1195 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B336 E5 42            [12] 1196 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B338 F0               [24] 1197 	movx	@dptr,a
      00B339 90 0B A6         [24] 1198 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B33C 74 01            [12] 1199 	mov	a,#0x01
      00B33E F0               [24] 1200 	movx	@dptr,a
      00B33F 85 46 82         [24] 1201 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B342 C0 03            [24] 1202 	push	ar3
      00B344 C0 02            [24] 1203 	push	ar2
      00B346 12 88 9A         [24] 1204 	lcall	_dynamic_keymap_get_encoder
      00B349 85 82 48         [24] 1205 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B34C 85 83 49         [24] 1206 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B34F D0 02            [24] 1207 	pop	ar2
      00B351 D0 03            [24] 1208 	pop	ar3
                                   1209 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B353 A9 49            [24] 1210 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B355 12 43 22         [24] 1211 	lcall	_ak820_outline_0136
      00B358 E9               [12] 1212 	mov	a,r1
      00B359 F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B35A A8 48            [24] 1215 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B35C 85 44 82         [24] 1216 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B35F 85 45 83         [24] 1217 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B362 E8               [12] 1218 	mov	a,r0
      00B363 F0               [24] 1219 	movx	@dptr,a
                                   1220 ;	quantum/vial.c:255: break;
      00B364 22               [24] 1221 	ret
                                   1222 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B365                       1223 00113$:
                                   1224 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B365 12 37 EB         [24] 1225 	lcall	_ak820_outline_0035
      00B368 F5 44            [12] 1226 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B36A 12 48 7B         [24] 1227 	lcall	_ak820_outline_0016
      00B36D F5 46            [12] 1228 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B36F 12 B0 84         [24] 1229 	lcall	_ak820_outline_0023
      00B372 E0               [24] 1230 	movx	a,@dptr
                                   1231 ;	assignBit
      00B373 24 FF            [12] 1232 	add	a,#0xff
      00B375 E4               [12] 1233 	clr	a
      00B376 33               [12] 1234 	rlc	a
      00B377 F5 48            [12] 1235 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B379 12 42 BC         [24] 1236 	lcall	_ak820_outline_0012
      00B37C E0               [24] 1237 	movx	a,@dptr
      00B37D F9               [12] 1238 	mov	r1,a
      00B37E 78 00            [12] 1239 	mov	r0,#0x00
      00B380 74 06            [12] 1240 	mov	a,#0x06
      00B382 12 37 DA         [24] 1241 	lcall	_ak820_outline_0018
      00B385 7B 00            [12] 1242 	mov	r3,#0x00
      00B387 42 00            [12] 1243 	orl	ar0,a
      00B389 EB               [12] 1244 	mov	a,r3
      00B38A 42 01            [12] 1245 	orl	ar1,a
      00B38C 12 38 6D         [24] 1246 	lcall	_ak820_outline_0159
      00B38F 12 B1 58         [24] 1247 	lcall	_vial_keycode_firewall
      00B392 AA 82            [24] 1248 	mov	r2, dpl
      00B394 AB 83            [24] 1249 	mov	r3, dph
      00B396 90 0B A8         [24] 1250 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B399 E5 46            [12] 1251 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B39B F0               [24] 1252 	movx	@dptr,a
      00B39C 90 0B A9         [24] 1253 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B39F E5 48            [12] 1254 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B3A1 F0               [24] 1255 	movx	@dptr,a
      00B3A2 90 0B AA         [24] 1256 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B3A5 EA               [12] 1257 	mov	a,r2
      00B3A6 12 48 ED         [24] 1258 	lcall	_ak820_outline_0189
      00B3A9 85 44 82         [24] 1259 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1260 ;	quantum/vial.c:259: break;
      00B3AC 02 89 01         [24] 1261 	ljmp	_dynamic_keymap_set_encoder
                                   1262 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B3AF                       1263 00114$:
                                   1264 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B3AF 90 0D 10         [24] 1265 	mov	dptr,#_vial_fill_packet_PARM_2
      00B3B2 74 FF            [12] 1266 	mov	a,#0xff
      00B3B4 12 42 F2         [24] 1267 	lcall	_ak820_outline_0066
      00B3B7 C0 07            [24] 1268 	push	ar7
      00B3B9 C0 06            [24] 1269 	push	ar6
      00B3BB 12 B1 7B         [24] 1270 	lcall	_vial_fill_packet
      00B3BE D0 06            [24] 1271 	pop	ar6
      00B3C0 D0 07            [24] 1272 	pop	ar7
                                   1273 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B3C2 90 0E E7         [24] 1274 	mov	dptr,#_vial_unlocked
      00B3C5 E0               [24] 1275 	movx	a,@dptr
      00B3C6 12 43 17         [24] 1276 	lcall	_ak820_outline_0119
      00B3C9 F0               [24] 1277 	movx	@dptr,a
                                   1278 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B3CA 74 01            [12] 1279 	mov	a,#0x01
      00B3CC 2E               [12] 1280 	add	a, r6
      00B3CD FA               [12] 1281 	mov	r2,a
      00B3CE E4               [12] 1282 	clr	a
      00B3CF 3F               [12] 1283 	addc	a, r7
      00B3D0 FB               [12] 1284 	mov	r3,a
      00B3D1 90 0E E8         [24] 1285 	mov	dptr,#_vial_unlock_in_progress
      00B3D4 E0               [24] 1286 	movx	a,@dptr
      00B3D5 12 43 22         [24] 1287 	lcall	_ak820_outline_0136
      00B3D8 F0               [24] 1288 	movx	@dptr,a
                                   1289 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B3D9 7B 00            [12] 1290 	mov	r3,#0x00
      00B3DB                       1291 00139$:
      00B3DB BB 02 00         [24] 1292 	cjne	r3,#0x02,00256$
      00B3DE                       1293 00256$:
      00B3DE 40 01            [24] 1294 	jc	00257$
      00B3E0 22               [24] 1295 	ret
      00B3E1                       1296 00257$:
                                   1297 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B3E1 8B 01            [24] 1298 	mov	ar1,r3
      00B3E3 7A 00            [12] 1299 	mov	r2,#0x00
      00B3E5 E9               [12] 1300 	mov	a,r1
      00B3E6 29               [12] 1301 	add	a,r1
      00B3E7 F5 48            [12] 1302 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B3E9 EA               [12] 1303 	mov	a,r2
      00B3EA 33               [12] 1304 	rlc	a
      00B3EB F5 49            [12] 1305 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B3ED 74 02            [12] 1306 	mov	a,#0x02
      00B3EF 25 48            [12] 1307 	add	a, _vial_handle_cmd_sloc3_1_0
      00B3F1 F8               [12] 1308 	mov	r0,a
      00B3F2 E4               [12] 1309 	clr	a
      00B3F3 35 49            [12] 1310 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B3F5 FA               [12] 1311 	mov	r2,a
      00B3F6 E8               [12] 1312 	mov	a,r0
      00B3F7 2E               [12] 1313 	add	a, r6
      00B3F8 F8               [12] 1314 	mov	r0,a
      00B3F9 EA               [12] 1315 	mov	a,r2
      00B3FA 3F               [12] 1316 	addc	a, r7
      00B3FB FA               [12] 1317 	mov	r2,a
      00B3FC EB               [12] 1318 	mov	a,r3
      00B3FD 12 B7 31         [24] 1319 	lcall	_ak820_outline_0131
      00B400 88 82            [24] 1320 	mov	dpl,r0
      00B402 8A 83            [24] 1321 	mov	dph,r2
      00B404 F0               [24] 1322 	movx	@dptr,a
                                   1323 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B405 74 03            [12] 1324 	mov	a,#0x03
      00B407 25 48            [12] 1325 	add	a, _vial_handle_cmd_sloc3_1_0
      00B409 F9               [12] 1326 	mov	r1,a
      00B40A E4               [12] 1327 	clr	a
      00B40B 35 49            [12] 1328 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B40D FA               [12] 1329 	mov	r2,a
      00B40E E9               [12] 1330 	mov	a,r1
      00B40F 2E               [12] 1331 	add	a, r6
      00B410 F9               [12] 1332 	mov	r1,a
      00B411 EA               [12] 1333 	mov	a,r2
      00B412 3F               [12] 1334 	addc	a, r7
      00B413 FA               [12] 1335 	mov	r2,a
      00B414 EB               [12] 1336 	mov	a,r3
      00B415 12 B7 26         [24] 1337 	lcall	_ak820_outline_0130
      00B418 12 71 02         [24] 1338 	lcall	_ak820_outline_0140
                                   1339 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B41B 0B               [12] 1340 	inc	r3
                                   1341 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B41C 80 BD            [24] 1342 	sjmp	00139$
      00B41E                       1343 00116$:
                                   1344 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B41E 90 0E E8         [24] 1345 	mov	dptr,#_vial_unlock_in_progress
      00B421 E0               [24] 1346 	movx	a,@dptr
      00B422 70 03            [24] 1347 	jnz	00118$
      00B424 12 B1 A0         [24] 1348 	lcall	_vial_release_held_state
      00B427                       1349 00118$:
                                   1350 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B427 90 0E E8         [24] 1351 	mov	dptr,#_vial_unlock_in_progress
      00B42A 74 01            [12] 1352 	mov	a,#0x01
      00B42C F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B42D 90 0E E9         [24] 1355 	mov	dptr,#_vial_unlock_counter
      00B430 74 1E            [12] 1356 	mov	a,#0x1e
      00B432 F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B433 90 0D 0D         [24] 1359 	mov	dptr,#_vial_unlock_holding
      00B436 E4               [12] 1360 	clr	a
      00B437 F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:287: break;
      00B438 22               [24] 1363 	ret
                                   1364 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B439                       1365 00119$:
                                   1366 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B439 90 0E E7         [24] 1367 	mov	dptr,#_vial_unlocked
      00B43C E0               [24] 1368 	movx	a,@dptr
      00B43D 12 43 17         [24] 1369 	lcall	_ak820_outline_0119
      00B440 F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B441 90 0E E8         [24] 1372 	mov	dptr,#_vial_unlock_in_progress
      00B444 E0               [24] 1373 	movx	a,@dptr
      00B445 12 43 1C         [24] 1374 	lcall	_ak820_outline_0125
                                   1375 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B448 74 02            [12] 1376 	mov	a,#0x02
      00B44A 2E               [12] 1377 	add	a, r6
      00B44B FA               [12] 1378 	mov	r2,a
      00B44C E4               [12] 1379 	clr	a
      00B44D 3F               [12] 1380 	addc	a, r7
      00B44E FB               [12] 1381 	mov	r3,a
      00B44F 90 0E E9         [24] 1382 	mov	dptr,#_vial_unlock_counter
      00B452 E0               [24] 1383 	movx	a,@dptr
      00B453 12 43 22         [24] 1384 	lcall	_ak820_outline_0136
      00B456 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:293: break;
      00B457 22               [24] 1387 	ret
                                   1388 ;	quantum/vial.c:295: case vial_lock: {
      00B458                       1389 00120$:
                                   1390 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B458 90 0E E7         [24] 1391 	mov	dptr,#_vial_unlocked
      00B45B E4               [12] 1392 	clr	a
      00B45C F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B45D 90 0E E8         [24] 1395 	mov	dptr,#_vial_unlock_in_progress
      00B460 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B461 90 0D 0D         [24] 1398 	mov	dptr,#_vial_unlock_holding
      00B464 F0               [24] 1399 	movx	@dptr,a
                                   1400 ;	quantum/vial.c:301: break;
      00B465 22               [24] 1401 	ret
                                   1402 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B466                       1403 00121$:
                                   1404 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B466 90 0D 10         [24] 1405 	mov	dptr,#_vial_fill_packet_PARM_2
      00B469 74 FF            [12] 1406 	mov	a,#0xff
      00B46B 12 42 F2         [24] 1407 	lcall	_ak820_outline_0066
                                   1408 ;	quantum/vial.c:314: break;
      00B46E 02 B1 7B         [24] 1409 	ljmp	_vial_fill_packet
                                   1410 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B471                       1411 00122$:
                                   1412 ;	quantum/vial.c:347: switch (msg[2]) {
      00B471 12 37 EB         [24] 1413 	lcall	_ak820_outline_0035
      00B474 FB               [12] 1414 	mov  r3,a
      00B475 24 FB            [12] 1415 	add	a,#0xff - 0x04
      00B477 50 01            [24] 1416 	jnc	00259$
      00B479 22               [24] 1417 	ret
      00B47A                       1418 00259$:
                                   1419 ;	free result
      00B47A EB               [12] 1420 	mov	a,r3
      00B47B 2B               [12] 1421 	add	a,r3
      00B47C 2B               [12] 1422 	add	a,r3
      00B47D 90 B4 81         [24] 1423 	mov	dptr,#00260$
      00B480 73               [24] 1424 	jmp	@a+dptr
      00B481                       1425 00260$:
      00B481 02 B4 90         [24] 1426 	ljmp	00123$
      00B484 02 B4 B9         [24] 1427 	ljmp	00124$
      00B487 02 B5 1B         [24] 1428 	ljmp	00125$
      00B48A 02 B5 5B         [24] 1429 	ljmp	00126$
      00B48D 02 B5 B9         [24] 1430 	ljmp	00127$
                                   1431 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B490                       1432 00123$:
                                   1433 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B490 90 0D 10         [24] 1434 	mov	dptr,#_vial_fill_packet_PARM_2
      00B493 E4               [12] 1435 	clr	a
      00B494 12 42 F2         [24] 1436 	lcall	_ak820_outline_0066
      00B497 C0 07            [24] 1437 	push	ar7
      00B499 C0 06            [24] 1438 	push	ar6
      00B49B 12 B1 7B         [24] 1439 	lcall	_vial_fill_packet
      00B49E D0 06            [24] 1440 	pop	ar6
      00B4A0 D0 07            [24] 1441 	pop	ar7
                                   1442 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B4A2 12 43 17         [24] 1443 	lcall	_ak820_outline_0119
      00B4A5 74 08            [12] 1444 	mov	a,#0x08
      00B4A7 12 42 F2         [24] 1445 	lcall	_ak820_outline_0066
                                   1446 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B4AA A3               [24] 1447 	inc	dptr
      00B4AB 12 42 C6         [24] 1448 	lcall	_ak820_outline_0037
                                   1449 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B4AE E4               [12] 1450 	clr	a
      00B4AF F0               [24] 1451 	movx	@dptr,a
                                   1452 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B4B0 74 1F            [12] 1453 	mov	a,#0x1f
      00B4B2 12 37 F3         [24] 1454 	lcall	_ak820_outline_0036
      00B4B5 74 01            [12] 1455 	mov	a,#0x01
      00B4B7 F0               [24] 1456 	movx	@dptr,a
                                   1457 ;	quantum/vial.c:356: break;
      00B4B8 22               [24] 1458 	ret
                                   1459 ;	quantum/vial.c:359: case dynamic_vial_tap_dance_get: {
      00B4B9                       1460 00124$:
                                   1461 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B4B9 12 48 7B         [24] 1462 	lcall	_ak820_outline_0016
      00B4BC FB               [12] 1463 	mov	r3,a
                                   1464 ;	quantum/vial.c:361: vial_tap_dance_entry_t td = { 0 };
      00B4BD 90 0D 17         [24] 1465 	mov	dptr,#_vial_handle_cmd_td_70000_647
      00B4C0 12 48 D3         [24] 1466 	lcall	_ak820_outline_0144
      00B4C3 90 0D 19         [24] 1467 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0002)
      00B4C6 F0               [24] 1468 	movx	@dptr,a
      00B4C7 A3               [24] 1469 	inc	dptr
      00B4C8 F0               [24] 1470 	movx	@dptr,a
      00B4C9 90 0D 1B         [24] 1471 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0004)
      00B4CC F0               [24] 1472 	movx	@dptr,a
      00B4CD A3               [24] 1473 	inc	dptr
      00B4CE F0               [24] 1474 	movx	@dptr,a
      00B4CF 90 0D 1D         [24] 1475 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0006)
      00B4D2 F0               [24] 1476 	movx	@dptr,a
      00B4D3 A3               [24] 1477 	inc	dptr
      00B4D4 F0               [24] 1478 	movx	@dptr,a
      00B4D5 90 0D 1F         [24] 1479 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0008)
      00B4D8 F0               [24] 1480 	movx	@dptr,a
      00B4D9 A3               [24] 1481 	inc	dptr
      00B4DA F0               [24] 1482 	movx	@dptr,a
                                   1483 ;	quantum/vial.c:362: msg[0] = dynamic_keymap_get_tap_dance(idx, &td);
      00B4DB 90 0B AD         [24] 1484 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      00B4DE 74 17            [12] 1485 	mov	a,#_vial_handle_cmd_td_70000_647
      00B4E0 F0               [24] 1486 	movx	@dptr,a
      00B4E1 74 0D            [12] 1487 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B4E3 12 38 18         [24] 1488 	lcall	_ak820_outline_0075
      00B4E6 8B 82            [24] 1489 	mov	dpl, r3
      00B4E8 C0 07            [24] 1490 	push	ar7
      00B4EA C0 06            [24] 1491 	push	ar6
      00B4EC C0 05            [24] 1492 	push	ar5
      00B4EE C0 04            [24] 1493 	push	ar4
      00B4F0 12 89 6D         [24] 1494 	lcall	_dynamic_keymap_get_tap_dance
      00B4F3 AA 82            [24] 1495 	mov	r2, dpl
      00B4F5 D0 04            [24] 1496 	pop	ar4
      00B4F7 D0 05            [24] 1497 	pop	ar5
      00B4F9 D0 06            [24] 1498 	pop	ar6
      00B4FB D0 07            [24] 1499 	pop	ar7
      00B4FD 12 43 17         [24] 1500 	lcall	_ak820_outline_0119
      00B500 EA               [12] 1501 	mov	a,r2
      00B501 F0               [24] 1502 	movx	@dptr,a
                                   1503 ;	quantum/vial.c:363: memcpy(&msg[1], &td, sizeof(td));
      00B502 8C 01            [24] 1504 	mov	ar1,r4
      00B504 8D 02            [24] 1505 	mov	ar2,r5
      00B506 7B 00            [12] 1506 	mov	r3,#0x00
      00B508 90 0E 67         [24] 1507 	mov	dptr,#___memcpy_PARM_2
      00B50B 74 17            [12] 1508 	mov	a,#_vial_handle_cmd_td_70000_647
      00B50D F0               [24] 1509 	movx	@dptr,a
      00B50E 74 0D            [12] 1510 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B510 12 B6 FE         [24] 1511 	lcall	_ak820_outline_0011
      00B513 12 43 32         [24] 1512 	lcall	_ak820_outline_0151
      00B516 8B F0            [24] 1513 	mov	b, r3
                                   1514 ;	quantum/vial.c:364: break;
      00B518 02 BC D2         [24] 1515 	ljmp	___memcpy
                                   1516 ;	quantum/vial.c:366: case dynamic_vial_tap_dance_set: {
      00B51B                       1517 00125$:
                                   1518 ;	quantum/vial.c:367: uint8_t idx = msg[3];
      00B51B 12 48 7B         [24] 1519 	lcall	_ak820_outline_0016
      00B51E FB               [12] 1520 	mov	r3,a
                                   1521 ;	quantum/vial.c:369: memcpy(&td, &msg[4], sizeof(td));
      00B51F 74 04            [12] 1522 	mov	a,#0x04
      00B521 2E               [12] 1523 	add	a, r6
      00B522 F9               [12] 1524 	mov	r1,a
      00B523 E4               [12] 1525 	clr	a
      00B524 3F               [12] 1526 	addc	a, r7
      00B525 FA               [12] 1527 	mov	r2,a
      00B526 90 0E 67         [24] 1528 	mov	dptr,#___memcpy_PARM_2
      00B529 E9               [12] 1529 	mov	a,r1
      00B52A F0               [24] 1530 	movx	@dptr,a
      00B52B EA               [12] 1531 	mov	a,r2
      00B52C 12 B6 FE         [24] 1532 	lcall	_ak820_outline_0011
      00B52F 90 0D 21         [24] 1533 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00B532 F5 F0            [12] 1534 	mov	b,a
      00B534 C0 07            [24] 1535 	push	ar7
      00B536 C0 06            [24] 1536 	push	ar6
      00B538 C0 03            [24] 1537 	push	ar3
      00B53A 12 BC D2         [24] 1538 	lcall	___memcpy
      00B53D D0 03            [24] 1539 	pop	ar3
                                   1540 ;	quantum/vial.c:376: msg[0] = dynamic_keymap_set_tap_dance(idx, &td);
      00B53F 90 0B B1         [24] 1541 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      00B542 74 21            [12] 1542 	mov	a,#_vial_handle_cmd_td_70000_648
      00B544 F0               [24] 1543 	movx	@dptr,a
      00B545 74 0D            [12] 1544 	mov	a,#(_vial_handle_cmd_td_70000_648 >> 8)
      00B547 12 38 18         [24] 1545 	lcall	_ak820_outline_0075
      00B54A 8B 82            [24] 1546 	mov	dpl, r3
      00B54C 12 89 EF         [24] 1547 	lcall	_dynamic_keymap_set_tap_dance
      00B54F AA 82            [24] 1548 	mov	r2, dpl
      00B551 D0 06            [24] 1549 	pop	ar6
      00B553 D0 07            [24] 1550 	pop	ar7
      00B555 12 43 17         [24] 1551 	lcall	_ak820_outline_0119
      00B558 EA               [12] 1552 	mov	a,r2
      00B559 F0               [24] 1553 	movx	@dptr,a
                                   1554 ;	quantum/vial.c:378: break;
      00B55A 22               [24] 1555 	ret
                                   1556 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B55B                       1557 00126$:
                                   1558 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B55B 12 48 7B         [24] 1559 	lcall	_ak820_outline_0016
      00B55E FB               [12] 1560 	mov	r3,a
                                   1561 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B55F 90 0D 2B         [24] 1562 	mov	dptr,#_vial_handle_cmd_entry_70000_649
      00B562 12 48 D3         [24] 1563 	lcall	_ak820_outline_0144
      00B565 90 0D 2D         [24] 1564 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0002)
      00B568 F0               [24] 1565 	movx	@dptr,a
      00B569 A3               [24] 1566 	inc	dptr
      00B56A F0               [24] 1567 	movx	@dptr,a
      00B56B 90 0D 2F         [24] 1568 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0004)
      00B56E F0               [24] 1569 	movx	@dptr,a
      00B56F A3               [24] 1570 	inc	dptr
      00B570 F0               [24] 1571 	movx	@dptr,a
      00B571 90 0D 31         [24] 1572 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0006)
      00B574 F0               [24] 1573 	movx	@dptr,a
      00B575 A3               [24] 1574 	inc	dptr
      00B576 F0               [24] 1575 	movx	@dptr,a
      00B577 90 0D 33         [24] 1576 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0008)
      00B57A F0               [24] 1577 	movx	@dptr,a
      00B57B A3               [24] 1578 	inc	dptr
      00B57C F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B57D 90 0B B5         [24] 1581 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B580 74 2B            [12] 1582 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B582 F0               [24] 1583 	movx	@dptr,a
      00B583 74 0D            [12] 1584 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B585 12 38 18         [24] 1585 	lcall	_ak820_outline_0075
      00B588 8B 82            [24] 1586 	mov	dpl, r3
      00B58A C0 07            [24] 1587 	push	ar7
      00B58C C0 06            [24] 1588 	push	ar6
      00B58E C0 05            [24] 1589 	push	ar5
      00B590 C0 04            [24] 1590 	push	ar4
      00B592 12 8A 8E         [24] 1591 	lcall	_dynamic_keymap_get_combo
      00B595 AA 82            [24] 1592 	mov	r2, dpl
      00B597 D0 04            [24] 1593 	pop	ar4
      00B599 D0 05            [24] 1594 	pop	ar5
      00B59B D0 06            [24] 1595 	pop	ar6
      00B59D D0 07            [24] 1596 	pop	ar7
      00B59F 12 43 17         [24] 1597 	lcall	_ak820_outline_0119
      00B5A2 EA               [12] 1598 	mov	a,r2
      00B5A3 F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B5A4 7B 00            [12] 1601 	mov	r3,#0x00
      00B5A6 90 0E 67         [24] 1602 	mov	dptr,#___memcpy_PARM_2
      00B5A9 74 2B            [12] 1603 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B5AB F0               [24] 1604 	movx	@dptr,a
      00B5AC 74 0D            [12] 1605 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B5AE 12 B6 FE         [24] 1606 	lcall	_ak820_outline_0011
      00B5B1 12 38 59         [24] 1607 	lcall	_ak820_outline_0127
      00B5B4 8B F0            [24] 1608 	mov	b, r3
                                   1609 ;	quantum/vial.c:387: break;
      00B5B6 02 BC D2         [24] 1610 	ljmp	___memcpy
                                   1611 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B5B9                       1612 00127$:
                                   1613 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B5B9 12 48 7B         [24] 1614 	lcall	_ak820_outline_0016
      00B5BC FD               [12] 1615 	mov	r5,a
                                   1616 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B5BD 74 04            [12] 1617 	mov	a,#0x04
      00B5BF 2E               [12] 1618 	add	a, r6
      00B5C0 FB               [12] 1619 	mov	r3,a
      00B5C1 E4               [12] 1620 	clr	a
      00B5C2 3F               [12] 1621 	addc	a, r7
      00B5C3 FC               [12] 1622 	mov	r4,a
      00B5C4 90 0E 67         [24] 1623 	mov	dptr,#___memcpy_PARM_2
      00B5C7 EB               [12] 1624 	mov	a,r3
      00B5C8 F0               [24] 1625 	movx	@dptr,a
      00B5C9 EC               [12] 1626 	mov	a,r4
      00B5CA 12 B6 FE         [24] 1627 	lcall	_ak820_outline_0011
      00B5CD 90 0D 35         [24] 1628 	mov	dptr,#_vial_handle_cmd_entry_70000_650
      00B5D0 F5 F0            [12] 1629 	mov	b,a
      00B5D2 C0 07            [24] 1630 	push	ar7
      00B5D4 C0 06            [24] 1631 	push	ar6
      00B5D6 C0 05            [24] 1632 	push	ar5
      00B5D8 12 BC D2         [24] 1633 	lcall	___memcpy
                                   1634 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B5DB 90 0D 3D         [24] 1635 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B5DE 12 38 43         [24] 1636 	lcall	_ak820_outline_0103
      00B5E1 12 33 FC         [24] 1637 	lcall	_ak820_outline_0123
      00B5E4 12 B1 58         [24] 1638 	lcall	_vial_keycode_firewall
      00B5E7 AB 82            [24] 1639 	mov	r3, dpl
      00B5E9 AC 83            [24] 1640 	mov	r4, dph
      00B5EB D0 05            [24] 1641 	pop	ar5
      00B5ED 90 0D 3D         [24] 1642 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B5F0 12 38 24         [24] 1643 	lcall	_ak820_outline_0080
                                   1644 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B5F3 90 0B B9         [24] 1645 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B5F6 74 35            [12] 1646 	mov	a,#_vial_handle_cmd_entry_70000_650
      00B5F8 F0               [24] 1647 	movx	@dptr,a
      00B5F9 74 0D            [12] 1648 	mov	a,#(_vial_handle_cmd_entry_70000_650 >> 8)
      00B5FB 12 38 18         [24] 1649 	lcall	_ak820_outline_0075
      00B5FE 8D 82            [24] 1650 	mov	dpl, r5
      00B600 12 8B 23         [24] 1651 	lcall	_dynamic_keymap_set_combo
      00B603 AC 82            [24] 1652 	mov	r4, dpl
      00B605 D0 06            [24] 1653 	pop	ar6
      00B607 D0 07            [24] 1654 	pop	ar7
      00B609 12 43 17         [24] 1655 	lcall	_ak820_outline_0119
      00B60C EC               [12] 1656 	mov	a,r4
      00B60D F0               [24] 1657 	movx	@dptr,a
                                   1658 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B60E EC               [12] 1659 	mov	a,r4
      00B60F 70 03            [24] 1660 	jnz	00141$
                                   1661 ;	quantum/vial.c:423: }
                                   1662 ;	quantum/vial.c:424: }
      00B611 02 35 39         [24] 1663 	ljmp	_ak820_combo_reload
      00B614                       1664 00141$:
      00B614 22               [24] 1665 	ret
                                   1666 ;------------------------------------------------------------
                                   1667 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1668 ;------------------------------------------------------------
                                   1669 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_652'
                                   1670 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_659'
                                   1671 ;------------------------------------------------------------
                                   1672 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1673 ;	-----------------------------------------
                                   1674 ;	 function vial_keycode_down
                                   1675 ;	-----------------------------------------
      00B615                       1676 _vial_keycode_down:
      00B615 12 38 4E         [24] 1677 	lcall	_ak820_outline_0109
      00B618 90 0D 41         [24] 1678 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B61B 12 38 49         [24] 1679 	lcall	_ak820_outline_0108
                                   1680 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B61E 90 0D 41         [24] 1681 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B621 12 37 C6         [24] 1682 	lcall	_ak820_outline_0010
      00B624 74 E0            [12] 1683 	mov	a,#0x100 - 0x20
      00B626 2D               [12] 1684 	add	a,r5
      00B627 50 19            [24] 1685 	jnc	00104$
      00B629 C3               [12] 1686 	clr	c
      00B62A 74 FF            [12] 1687 	mov	a,#0xff
      00B62C 9C               [12] 1688 	subb	a,r4
      00B62D 74 4F            [12] 1689 	mov	a,#0x4f
      00B62F 9D               [12] 1690 	subb	a,r5
      00B630 40 10            [24] 1691 	jc	00104$
                                   1692 ;	free result
                                   1693 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B632 90 0D 41         [24] 1694 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B635 EE               [12] 1695 	mov	a,r6
      00B636 12 38 5E         [24] 1696 	lcall	_ak820_outline_0128
                                   1697 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B639 90 0D 41         [24] 1698 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B63C E0               [24] 1699 	movx	a,@dptr
      00B63D 24 FE            [12] 1700 	add	a,#0xff - 0x01
      00B63F 40 01            [24] 1701 	jc	00104$
                                   1702 ;	free result
      00B641 22               [24] 1703 	ret
      00B642                       1704 00104$:
                                   1705 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B642 90 0D 41         [24] 1706 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B645 12 B7 0D         [24] 1707 	lcall	_ak820_outline_0025
                                   1708 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B648 40 06            [24] 1709 	jc	00107$
                                   1710 ;	free result
                                   1711 ;	quantum/vial.c:440: register_code16(keycode);
      00B64A 12 43 17         [24] 1712 	lcall	_ak820_outline_0119
      00B64D 02 A2 8B         [24] 1713 	ljmp	_register_code16
      00B650                       1714 00107$:
                                   1715 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B650 90 0D 47         [24] 1716 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0004)
      00B653 74 01            [12] 1717 	mov	a,#0x01
      00B655 F0               [24] 1718 	movx	@dptr,a
      00B656 90 0D 44         [24] 1719 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0001)
      00B659 74 F0            [12] 1720 	mov	a,#0xf0
      00B65B F0               [24] 1721 	movx	@dptr,a
      00B65C 90 0D 43         [24] 1722 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
      00B65F F0               [24] 1723 	movx	@dptr,a
      00B660 90 0D 48         [24] 1724 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0005)
      00B663 74 01            [12] 1725 	mov	a,#0x01
      00B665 F0               [24] 1726 	movx	@dptr,a
      00B666 12 4E 3A         [24] 1727 	lcall	_timer_read
      00B669 12 43 27         [24] 1728 	lcall	_ak820_outline_0137
      00B66C 43 06 01         [24] 1729 	orl	ar6,#0x01
      00B66F 90 0D 45         [24] 1730 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0002)
      00B672 12 48 C5         [24] 1731 	lcall	_ak820_outline_0065
                                   1732 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B675 90 0D 43         [24] 1733 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
                                   1734 ;	quantum/vial.c:448: }
      00B678 02 75 2F         [24] 1735 	ljmp	_ak820_action_exec
                                   1736 ;------------------------------------------------------------
                                   1737 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1738 ;------------------------------------------------------------
                                   1739 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_660'
                                   1740 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_667'
                                   1741 ;------------------------------------------------------------
                                   1742 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1743 ;	-----------------------------------------
                                   1744 ;	 function vial_keycode_up
                                   1745 ;	-----------------------------------------
      00B67B                       1746 _vial_keycode_up:
      00B67B 12 38 4E         [24] 1747 	lcall	_ak820_outline_0109
      00B67E 90 0D 49         [24] 1748 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B681 12 38 49         [24] 1749 	lcall	_ak820_outline_0108
                                   1750 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B684 90 0D 49         [24] 1751 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B687 12 37 C6         [24] 1752 	lcall	_ak820_outline_0010
      00B68A 74 E0            [12] 1753 	mov	a,#0x100 - 0x20
      00B68C 2D               [12] 1754 	add	a,r5
      00B68D 50 19            [24] 1755 	jnc	00104$
      00B68F C3               [12] 1756 	clr	c
      00B690 74 FF            [12] 1757 	mov	a,#0xff
      00B692 9C               [12] 1758 	subb	a,r4
      00B693 74 4F            [12] 1759 	mov	a,#0x4f
      00B695 9D               [12] 1760 	subb	a,r5
      00B696 40 10            [24] 1761 	jc	00104$
                                   1762 ;	free result
                                   1763 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B698 90 0D 49         [24] 1764 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B69B EE               [12] 1765 	mov	a,r6
      00B69C 12 38 5E         [24] 1766 	lcall	_ak820_outline_0128
                                   1767 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B69F 90 0D 49         [24] 1768 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B6A2 E0               [24] 1769 	movx	a,@dptr
      00B6A3 24 FE            [12] 1770 	add	a,#0xff - 0x01
      00B6A5 40 01            [24] 1771 	jc	00104$
                                   1772 ;	free result
      00B6A7 22               [24] 1773 	ret
      00B6A8                       1774 00104$:
                                   1775 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B6A8 90 0D 49         [24] 1776 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B6AB 12 B7 0D         [24] 1777 	lcall	_ak820_outline_0025
                                   1778 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B6AE 40 06            [24] 1779 	jc	00107$
                                   1780 ;	free result
                                   1781 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B6B0 12 43 17         [24] 1782 	lcall	_ak820_outline_0119
      00B6B3 02 A2 CF         [24] 1783 	ljmp	_unregister_code16
      00B6B6                       1784 00107$:
                                   1785 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B6B6 90 0D 4F         [24] 1786 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0004)
      00B6B9 74 01            [12] 1787 	mov	a,#0x01
      00B6BB F0               [24] 1788 	movx	@dptr,a
      00B6BC 90 0D 4C         [24] 1789 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0001)
      00B6BF 74 F0            [12] 1790 	mov	a,#0xf0
      00B6C1 F0               [24] 1791 	movx	@dptr,a
      00B6C2 90 0D 4B         [24] 1792 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
      00B6C5 F0               [24] 1793 	movx	@dptr,a
      00B6C6 90 0D 50         [24] 1794 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0005)
      00B6C9 E4               [12] 1795 	clr	a
      00B6CA F0               [24] 1796 	movx	@dptr,a
      00B6CB 12 4E 3A         [24] 1797 	lcall	_timer_read
      00B6CE 12 43 27         [24] 1798 	lcall	_ak820_outline_0137
      00B6D1 43 06 01         [24] 1799 	orl	ar6,#0x01
      00B6D4 90 0D 4D         [24] 1800 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0002)
      00B6D7 12 48 C5         [24] 1801 	lcall	_ak820_outline_0065
                                   1802 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B6DA 90 0D 4B         [24] 1803 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
                                   1804 ;	quantum/vial.c:470: }
      00B6DD 02 75 2F         [24] 1805 	ljmp	_ak820_action_exec
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1808 ;------------------------------------------------------------
                                   1809 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_668'
                                   1810 ;i             Allocated with name '_vial_keycode_tap_i_30000_671'
                                   1811 ;------------------------------------------------------------
                                   1812 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1813 ;	-----------------------------------------
                                   1814 ;	 function vial_keycode_tap
                                   1815 ;	-----------------------------------------
      00B6E0                       1816 _vial_keycode_tap:
      00B6E0 12 38 4E         [24] 1817 	lcall	_ak820_outline_0109
      00B6E3 90 0D 51         [24] 1818 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B6E6 12 38 49         [24] 1819 	lcall	_ak820_outline_0108
                                   1820 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B6E9 90 0D 51         [24] 1821 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B6EC 12 37 AC         [24] 1822 	lcall	_ak820_outline_0006
      00B6EF C0 07            [24] 1823 	push	ar7
      00B6F1 C0 06            [24] 1824 	push	ar6
      00B6F3 D1 15            [12] 1825 	acall	_vial_keycode_down
      00B6F5 D0 06            [24] 1826 	pop	ar6
      00B6F7 D0 07            [24] 1827 	pop	ar7
                                   1828 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B6F9 12 43 17         [24] 1829 	lcall	_ak820_outline_0119
                                   1830 ;	quantum/vial.c:476: }
      00B6FC C1 7B            [12] 1831 	ajmp	_vial_keycode_up
                                   1832 ;------------------------------------------------------------
                                   1833 ;Allocation info for local variables in function 'process_record_vial'
                                   1834 ;------------------------------------------------------------
                                   1835 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1836 ;keycode       Allocated with name '_process_record_vial_keycode_10000_673'
                                   1837 ;------------------------------------------------------------
                                   1838 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1839 ;	-----------------------------------------
                                   1840 	.area CSEG    (CODE)
                                   1841 	.area CONST   (CODE)
                                   1842 	.area CONST   (CODE)
      00C250                       1843 _keyboard_definition:
      00C250 FD                    1844 	.db #0xfd	; 253
      00C251 37                    1845 	.db #0x37	; 55	'7'
      00C252 7A                    1846 	.db #0x7a	; 122	'z'
      00C253 58                    1847 	.db #0x58	; 88	'X'
      00C254 5A                    1848 	.db #0x5a	; 90	'Z'
      00C255 00                    1849 	.db #0x00	; 0
      00C256 00                    1850 	.db #0x00	; 0
      00C257 04                    1851 	.db #0x04	; 4
      00C258 E6                    1852 	.db #0xe6	; 230
      00C259 D6                    1853 	.db #0xd6	; 214
      00C25A B4                    1854 	.db #0xb4	; 180
      00C25B 46                    1855 	.db #0x46	; 70	'F'
      00C25C 02                    1856 	.db #0x02	; 2
      00C25D 00                    1857 	.db #0x00	; 0
      00C25E 21                    1858 	.db #0x21	; 33
      00C25F 01                    1859 	.db #0x01	; 1
      00C260 00                    1860 	.db #0x00	; 0
      00C261 00                    1861 	.db #0x00	; 0
      00C262 00                    1862 	.db #0x00	; 0
      00C263 00                    1863 	.db #0x00	; 0
      00C264 37                    1864 	.db #0x37	; 55	'7'
      00C265 27                    1865 	.db #0x27	; 39
      00C266 97                    1866 	.db #0x97	; 151
      00C267 D6                    1867 	.db #0xd6	; 214
      00C268 E0                    1868 	.db #0xe0	; 224
      00C269 03                    1869 	.db #0x03	; 3
      00C26A CB                    1870 	.db #0xcb	; 203
      00C26B 01                    1871 	.db #0x01	; 1
      00C26C 3C                    1872 	.db #0x3c	; 60
      00C26D 00                    1873 	.db #0x00	; 0
      00C26E 00                    1874 	.db #0x00	; 0
      00C26F 3D                    1875 	.db #0x3d	; 61
      00C270 88                    1876 	.db #0x88	; 136
      00C271 CD                    1877 	.db #0xcd	; 205
      00C272 A5                    1878 	.db #0xa5	; 165
      00C273 AA                    1879 	.db #0xaa	; 170
      00C274 E5                    1880 	.db #0xe5	; 229
      00C275 A8                    1881 	.db #0xa8	; 168
      00C276 76                    1882 	.db #0x76	; 118	'v'
      00C277 F6                    1883 	.db #0xf6	; 246
      00C278 43                    1884 	.db #0x43	; 67	'C'
      00C279 0E                    1885 	.db #0x0e	; 14
      00C27A D2                    1886 	.db #0xd2	; 210
      00C27B 90                    1887 	.db #0x90	; 144
      00C27C 7D                    1888 	.db #0x7d	; 125
      00C27D 94                    1889 	.db #0x94	; 148
      00C27E 79                    1890 	.db #0x79	; 121	'y'
      00C27F 78                    1891 	.db #0x78	; 120	'x'
      00C280 EF                    1892 	.db #0xef	; 239
      00C281 49                    1893 	.db #0x49	; 73	'I'
      00C282 3E                    1894 	.db #0x3e	; 62
      00C283 EF                    1895 	.db #0xef	; 239
      00C284 FD                    1896 	.db #0xfd	; 253
      00C285 8F                    1897 	.db #0x8f	; 143
      00C286 EF                    1898 	.db #0xef	; 239
      00C287 00                    1899 	.db #0x00	; 0
      00C288 C6                    1900 	.db #0xc6	; 198
      00C289 D1                    1901 	.db #0xd1	; 209
      00C28A DB                    1902 	.db #0xdb	; 219
      00C28B FB                    1903 	.db #0xfb	; 251
      00C28C EB                    1904 	.db #0xeb	; 235
      00C28D DE                    1905 	.db #0xde	; 222
      00C28E 66                    1906 	.db #0x66	; 102	'f'
      00C28F 63                    1907 	.db #0x63	; 99	'c'
      00C290 0C                    1908 	.db #0x0c	; 12
      00C291 92                    1909 	.db #0x92	; 146
      00C292 7B                    1910 	.db #0x7b	; 123
      00C293 F9                    1911 	.db #0xf9	; 249
      00C294 D4                    1912 	.db #0xd4	; 212
      00C295 7A                    1913 	.db #0x7a	; 122	'z'
      00C296 4F                    1914 	.db #0x4f	; 79	'O'
      00C297 83                    1915 	.db #0x83	; 131
      00C298 4B                    1916 	.db #0x4b	; 75	'K'
      00C299 86                    1917 	.db #0x86	; 134
      00C29A 0E                    1918 	.db #0x0e	; 14
      00C29B 6A                    1919 	.db #0x6a	; 106	'j'
      00C29C F2                    1920 	.db #0xf2	; 242
      00C29D 22                    1921 	.db #0x22	; 34
      00C29E 22                    1922 	.db #0x22	; 34
      00C29F 0B                    1923 	.db #0x0b	; 11
      00C2A0 03                    1924 	.db #0x03	; 3
      00C2A1 BA                    1925 	.db #0xba	; 186
      00C2A2 67                    1926 	.db #0x67	; 103	'g'
      00C2A3 9B                    1927 	.db #0x9b	; 155
      00C2A4 7A                    1928 	.db #0x7a	; 122	'z'
      00C2A5 E1                    1929 	.db #0xe1	; 225
      00C2A6 BC                    1930 	.db #0xbc	; 188
      00C2A7 37                    1931 	.db #0x37	; 55	'7'
      00C2A8 26                    1932 	.db #0x26	; 38
      00C2A9 46                    1933 	.db #0x46	; 70	'F'
      00C2AA 78                    1934 	.db #0x78	; 120	'x'
      00C2AB 05                    1935 	.db #0x05	; 5
      00C2AC 0D                    1936 	.db #0x0d	; 13
      00C2AD 95                    1937 	.db #0x95	; 149
      00C2AE 02                    1938 	.db #0x02	; 2
      00C2AF E4                    1939 	.db #0xe4	; 228
      00C2B0 18                    1940 	.db #0x18	; 24
      00C2B1 CA                    1941 	.db #0xca	; 202
      00C2B2 33                    1942 	.db #0x33	; 51	'3'
      00C2B3 EA                    1943 	.db #0xea	; 234
      00C2B4 24                    1944 	.db #0x24	; 36
      00C2B5 C8                    1945 	.db #0xc8	; 200
      00C2B6 81                    1946 	.db #0x81	; 129
      00C2B7 4E                    1947 	.db #0x4e	; 78	'N'
      00C2B8 47                    1948 	.db #0x47	; 71	'G'
      00C2B9 A8                    1949 	.db #0xa8	; 168
      00C2BA 44                    1950 	.db #0x44	; 68	'D'
      00C2BB DD                    1951 	.db #0xdd	; 221
      00C2BC 91                    1952 	.db #0x91	; 145
      00C2BD 6D                    1953 	.db #0x6d	; 109	'm'
      00C2BE 69                    1954 	.db #0x69	; 105	'i'
      00C2BF DB                    1955 	.db #0xdb	; 219
      00C2C0 4F                    1956 	.db #0x4f	; 79	'O'
      00C2C1 3A                    1957 	.db #0x3a	; 58
      00C2C2 43                    1958 	.db #0x43	; 67	'C'
      00C2C3 9D                    1959 	.db #0x9d	; 157
      00C2C4 26                    1960 	.db #0x26	; 38
      00C2C5 49                    1961 	.db #0x49	; 73	'I'
      00C2C6 4C                    1962 	.db #0x4c	; 76	'L'
      00C2C7 EF                    1963 	.db #0xef	; 239
      00C2C8 2B                    1964 	.db #0x2b	; 43
      00C2C9 D8                    1965 	.db #0xd8	; 216
      00C2CA 55                    1966 	.db #0x55	; 85	'U'
      00C2CB 95                    1967 	.db #0x95	; 149
      00C2CC 70                    1968 	.db #0x70	; 112	'p'
      00C2CD B1                    1969 	.db #0xb1	; 177
      00C2CE CC                    1970 	.db #0xcc	; 204
      00C2CF CF                    1971 	.db #0xcf	; 207
      00C2D0 13                    1972 	.db #0x13	; 19
      00C2D1 32                    1973 	.db #0x32	; 50	'2'
      00C2D2 6A                    1974 	.db #0x6a	; 106	'j'
      00C2D3 A1                    1975 	.db #0xa1	; 161
      00C2D4 FF                    1976 	.db #0xff	; 255
      00C2D5 99                    1977 	.db #0x99	; 153
      00C2D6 61                    1978 	.db #0x61	; 97	'a'
      00C2D7 95                    1979 	.db #0x95	; 149
      00C2D8 B1                    1980 	.db #0xb1	; 177
      00C2D9 89                    1981 	.db #0x89	; 137
      00C2DA 9B                    1982 	.db #0x9b	; 155
      00C2DB 11                    1983 	.db #0x11	; 17
      00C2DC D9                    1984 	.db #0xd9	; 217
      00C2DD 35                    1985 	.db #0x35	; 53	'5'
      00C2DE 78                    1986 	.db #0x78	; 120	'x'
      00C2DF ED                    1987 	.db #0xed	; 237
      00C2E0 CD                    1988 	.db #0xcd	; 205
      00C2E1 94                    1989 	.db #0x94	; 148
      00C2E2 6E                    1990 	.db #0x6e	; 110	'n'
      00C2E3 60                    1991 	.db #0x60	; 96
      00C2E4 8E                    1992 	.db #0x8e	; 142
      00C2E5 63                    1993 	.db #0x63	; 99	'c'
      00C2E6 8B                    1994 	.db #0x8b	; 139
      00C2E7 FF                    1995 	.db #0xff	; 255
      00C2E8 4E                    1996 	.db #0x4e	; 78	'N'
      00C2E9 20                    1997 	.db #0x20	; 32
      00C2EA 7A                    1998 	.db #0x7a	; 122	'z'
      00C2EB B5                    1999 	.db #0xb5	; 181
      00C2EC 87                    2000 	.db #0x87	; 135
      00C2ED C2                    2001 	.db #0xc2	; 194
      00C2EE 35                    2002 	.db #0x35	; 53	'5'
      00C2EF A4                    2003 	.db #0xa4	; 164
      00C2F0 6D                    2004 	.db #0x6d	; 109	'm'
      00C2F1 18                    2005 	.db #0x18	; 24
      00C2F2 C1                    2006 	.db #0xc1	; 193
      00C2F3 A3                    2007 	.db #0xa3	; 163
      00C2F4 DB                    2008 	.db #0xdb	; 219
      00C2F5 53                    2009 	.db #0x53	; 83	'S'
      00C2F6 1D                    2010 	.db #0x1d	; 29
      00C2F7 EC                    2011 	.db #0xec	; 236
      00C2F8 F0                    2012 	.db #0xf0	; 240
      00C2F9 BF                    2013 	.db #0xbf	; 191
      00C2FA 4A                    2014 	.db #0x4a	; 74	'J'
      00C2FB 4C                    2015 	.db #0x4c	; 76	'L'
      00C2FC 4A                    2016 	.db #0x4a	; 74	'J'
      00C2FD C4                    2017 	.db #0xc4	; 196
      00C2FE AA                    2018 	.db #0xaa	; 170
      00C2FF 37                    2019 	.db #0x37	; 55	'7'
      00C300 19                    2020 	.db #0x19	; 25
      00C301 34                    2021 	.db #0x34	; 52	'4'
      00C302 3F                    2022 	.db #0x3f	; 63
      00C303 A1                    2023 	.db #0xa1	; 161
      00C304 D3                    2024 	.db #0xd3	; 211
      00C305 1A                    2025 	.db #0x1a	; 26
      00C306 5C                    2026 	.db #0x5c	; 92
      00C307 03                    2027 	.db #0x03	; 3
      00C308 4D                    2028 	.db #0x4d	; 77	'M'
      00C309 BC                    2029 	.db #0xbc	; 188
      00C30A 10                    2030 	.db #0x10	; 16
      00C30B 2E                    2031 	.db #0x2e	; 46
      00C30C 80                    2032 	.db #0x80	; 128
      00C30D F7                    2033 	.db #0xf7	; 247
      00C30E D6                    2034 	.db #0xd6	; 214
      00C30F 82                    2035 	.db #0x82	; 130
      00C310 24                    2036 	.db #0x24	; 36
      00C311 4C                    2037 	.db #0x4c	; 76	'L'
      00C312 87                    2038 	.db #0x87	; 135
      00C313 B9                    2039 	.db #0xb9	; 185
      00C314 F8                    2040 	.db #0xf8	; 248
      00C315 BE                    2041 	.db #0xbe	; 190
      00C316 67                    2042 	.db #0x67	; 103	'g'
      00C317 96                    2043 	.db #0x96	; 150
      00C318 89                    2044 	.db #0x89	; 137
      00C319 30                    2045 	.db #0x30	; 48	'0'
      00C31A C8                    2046 	.db #0xc8	; 200
      00C31B 8D                    2047 	.db #0x8d	; 141
      00C31C 2C                    2048 	.db #0x2c	; 44
      00C31D F5                    2049 	.db #0xf5	; 245
      00C31E 06                    2050 	.db #0x06	; 6
      00C31F 05                    2051 	.db #0x05	; 5
      00C320 7C                    2052 	.db #0x7c	; 124
      00C321 48                    2053 	.db #0x48	; 72	'H'
      00C322 1B                    2054 	.db #0x1b	; 27
      00C323 76                    2055 	.db #0x76	; 118	'v'
      00C324 AA                    2056 	.db #0xaa	; 170
      00C325 3D                    2057 	.db #0x3d	; 61
      00C326 28                    2058 	.db #0x28	; 40
      00C327 FC                    2059 	.db #0xfc	; 252
      00C328 80                    2060 	.db #0x80	; 128
      00C329 75                    2061 	.db #0x75	; 117	'u'
      00C32A EB                    2062 	.db #0xeb	; 235
      00C32B 78                    2063 	.db #0x78	; 120	'x'
      00C32C D0                    2064 	.db #0xd0	; 208
      00C32D 8A                    2065 	.db #0x8a	; 138
      00C32E 8F                    2066 	.db #0x8f	; 143
      00C32F 27                    2067 	.db #0x27	; 39
      00C330 F7                    2068 	.db #0xf7	; 247
      00C331 F2                    2069 	.db #0xf2	; 242
      00C332 EB                    2070 	.db #0xeb	; 235
      00C333 58                    2071 	.db #0x58	; 88	'X'
      00C334 37                    2072 	.db #0x37	; 55	'7'
      00C335 3C                    2073 	.db #0x3c	; 60
      00C336 2B                    2074 	.db #0x2b	; 43
      00C337 6F                    2075 	.db #0x6f	; 111	'o'
      00C338 0E                    2076 	.db #0x0e	; 14
      00C339 C7                    2077 	.db #0xc7	; 199
      00C33A E2                    2078 	.db #0xe2	; 226
      00C33B A0                    2079 	.db #0xa0	; 160
      00C33C 97                    2080 	.db #0x97	; 151
      00C33D EE                    2081 	.db #0xee	; 238
      00C33E FD                    2082 	.db #0xfd	; 253
      00C33F 9F                    2083 	.db #0x9f	; 159
      00C340 45                    2084 	.db #0x45	; 69	'E'
      00C341 17                    2085 	.db #0x17	; 23
      00C342 94                    2086 	.db #0x94	; 148
      00C343 E6                    2087 	.db #0xe6	; 230
      00C344 E7                    2088 	.db #0xe7	; 231
      00C345 FA                    2089 	.db #0xfa	; 250
      00C346 4C                    2090 	.db #0x4c	; 76	'L'
      00C347 7A                    2091 	.db #0x7a	; 122	'z'
      00C348 D6                    2092 	.db #0xd6	; 214
      00C349 7A                    2093 	.db #0x7a	; 122	'z'
      00C34A 7B                    2094 	.db #0x7b	; 123
      00C34B ED                    2095 	.db #0xed	; 237
      00C34C 10                    2096 	.db #0x10	; 16
      00C34D C5                    2097 	.db #0xc5	; 197
      00C34E BC                    2098 	.db #0xbc	; 188
      00C34F E3                    2099 	.db #0xe3	; 227
      00C350 A9                    2100 	.db #0xa9	; 169
      00C351 1F                    2101 	.db #0x1f	; 31
      00C352 CF                    2102 	.db #0xcf	; 207
      00C353 C4                    2103 	.db #0xc4	; 196
      00C354 9D                    2104 	.db #0x9d	; 157
      00C355 DC                    2105 	.db #0xdc	; 220
      00C356 45                    2106 	.db #0x45	; 69	'E'
      00C357 2A                    2107 	.db #0x2a	; 42
      00C358 69                    2108 	.db #0x69	; 105	'i'
      00C359 57                    2109 	.db #0x57	; 87	'W'
      00C35A 8F                    2110 	.db #0x8f	; 143
      00C35B EC                    2111 	.db #0xec	; 236
      00C35C 85                    2112 	.db #0x85	; 133
      00C35D 6C                    2113 	.db #0x6c	; 108	'l'
      00C35E 43                    2114 	.db #0x43	; 67	'C'
      00C35F 1C                    2115 	.db #0x1c	; 28
      00C360 BA                    2116 	.db #0xba	; 186
      00C361 89                    2117 	.db #0x89	; 137
      00C362 68                    2118 	.db #0x68	; 104	'h'
      00C363 4A                    2119 	.db #0x4a	; 74	'J'
      00C364 1C                    2120 	.db #0x1c	; 28
      00C365 91                    2121 	.db #0x91	; 145
      00C366 3F                    2122 	.db #0x3f	; 63
      00C367 D1                    2123 	.db #0xd1	; 209
      00C368 B3                    2124 	.db #0xb3	; 179
      00C369 96                    2125 	.db #0x96	; 150
      00C36A 1D                    2126 	.db #0x1d	; 29
      00C36B 7C                    2127 	.db #0x7c	; 124
      00C36C 14                    2128 	.db #0x14	; 20
      00C36D 77                    2129 	.db #0x77	; 119	'w'
      00C36E 9C                    2130 	.db #0x9c	; 156
      00C36F 74                    2131 	.db #0x74	; 116	't'
      00C370 36                    2132 	.db #0x36	; 54	'6'
      00C371 FF                    2133 	.db #0xff	; 255
      00C372 2C                    2134 	.db #0x2c	; 44
      00C373 66                    2135 	.db #0x66	; 102	'f'
      00C374 AF                    2136 	.db #0xaf	; 175
      00C375 0F                    2137 	.db #0x0f	; 15
      00C376 3C                    2138 	.db #0x3c	; 60
      00C377 A2                    2139 	.db #0xa2	; 162
      00C378 23                    2140 	.db #0x23	; 35
      00C379 85                    2141 	.db #0x85	; 133
      00C37A 05                    2142 	.db #0x05	; 5
      00C37B 87                    2143 	.db #0x87	; 135
      00C37C DA                    2144 	.db #0xda	; 218
      00C37D 61                    2145 	.db #0x61	; 97	'a'
      00C37E 5E                    2146 	.db #0x5e	; 94
      00C37F 42                    2147 	.db #0x42	; 66	'B'
      00C380 54                    2148 	.db #0x54	; 84	'T'
      00C381 60                    2149 	.db #0x60	; 96
      00C382 23                    2150 	.db #0x23	; 35
      00C383 CA                    2151 	.db #0xca	; 202
      00C384 BC                    2152 	.db #0xbc	; 188
      00C385 B3                    2153 	.db #0xb3	; 179
      00C386 18                    2154 	.db #0x18	; 24
      00C387 1D                    2155 	.db #0x1d	; 29
      00C388 F8                    2156 	.db #0xf8	; 248
      00C389 0A                    2157 	.db #0x0a	; 10
      00C38A 55                    2158 	.db #0x55	; 85	'U'
      00C38B CD                    2159 	.db #0xcd	; 205
      00C38C A3                    2160 	.db #0xa3	; 163
      00C38D DE                    2161 	.db #0xde	; 222
      00C38E FF                    2162 	.db #0xff	; 255
      00C38F B2                    2163 	.db #0xb2	; 178
      00C390 2A                    2164 	.db #0x2a	; 42
      00C391 35                    2165 	.db #0x35	; 53	'5'
      00C392 00                    2166 	.db #0x00	; 0
      00C393 D6                    2167 	.db #0xd6	; 214
      00C394 7B                    2168 	.db #0x7b	; 123
      00C395 E8                    2169 	.db #0xe8	; 232
      00C396 F2                    2170 	.db #0xf2	; 242
      00C397 1A                    2171 	.db #0x1a	; 26
      00C398 BC                    2172 	.db #0xbc	; 188
      00C399 F5                    2173 	.db #0xf5	; 245
      00C39A 7E                    2174 	.db #0x7e	; 126
      00C39B 48                    2175 	.db #0x48	; 72	'H'
      00C39C 72                    2176 	.db #0x72	; 114	'r'
      00C39D E0                    2177 	.db #0xe0	; 224
      00C39E E4                    2178 	.db #0xe4	; 228
      00C39F E0                    2179 	.db #0xe0	; 224
      00C3A0 27                    2180 	.db #0x27	; 39
      00C3A1 87                    2181 	.db #0x87	; 135
      00C3A2 9A                    2182 	.db #0x9a	; 154
      00C3A3 51                    2183 	.db #0x51	; 81	'Q'
      00C3A4 D4                    2184 	.db #0xd4	; 212
      00C3A5 DD                    2185 	.db #0xdd	; 221
      00C3A6 C3                    2186 	.db #0xc3	; 195
      00C3A7 AA                    2187 	.db #0xaa	; 170
      00C3A8 49                    2188 	.db #0x49	; 73	'I'
      00C3A9 5A                    2189 	.db #0x5a	; 90	'Z'
      00C3AA 2A                    2190 	.db #0x2a	; 42
      00C3AB 00                    2191 	.db #0x00	; 0
      00C3AC A0                    2192 	.db #0xa0	; 160
      00C3AD 8C                    2193 	.db #0x8c	; 140
      00C3AE FF                    2194 	.db #0xff	; 255
      00C3AF 74                    2195 	.db #0x74	; 116	't'
      00C3B0 BF                    2196 	.db #0xbf	; 191
      00C3B1 EC                    2197 	.db #0xec	; 236
      00C3B2 1D                    2198 	.db #0x1d	; 29
      00C3B3 F1                    2199 	.db #0xf1	; 241
      00C3B4 00                    2200 	.db #0x00	; 0
      00C3B5 01                    2201 	.db #0x01	; 1
      00C3B6 D8                    2202 	.db #0xd8	; 216
      00C3B7 02                    2203 	.db #0x02	; 2
      00C3B8 CC                    2204 	.db #0xcc	; 204
      00C3B9 07                    2205 	.db #0x07	; 7
      00C3BA 00                    2206 	.db #0x00	; 0
      00C3BB 00                    2207 	.db #0x00	; 0
      00C3BC C4                    2208 	.db #0xc4	; 196
      00C3BD 5E                    2209 	.db #0x5e	; 94
      00C3BE 2C                    2210 	.db #0x2c	; 44
      00C3BF 7E                    2211 	.db #0x7e	; 126
      00C3C0 B1                    2212 	.db #0xb1	; 177
      00C3C1 C4                    2213 	.db #0xc4	; 196
      00C3C2 67                    2214 	.db #0x67	; 103	'g'
      00C3C3 FB                    2215 	.db #0xfb	; 251
      00C3C4 02                    2216 	.db #0x02	; 2
      00C3C5 00                    2217 	.db #0x00	; 0
      00C3C6 00                    2218 	.db #0x00	; 0
      00C3C7 00                    2219 	.db #0x00	; 0
      00C3C8 00                    2220 	.db #0x00	; 0
      00C3C9 04                    2221 	.db #0x04	; 4
      00C3CA 59                    2222 	.db #0x59	; 89	'Y'
      00C3CB 5A                    2223 	.db #0x5a	; 90	'Z'
                                   2224 	.area CSEG    (CODE)
                                   2225 	.area CONST   (CODE)
      00C3CC                       2226 _vial_handle_cmd_keyboard_uid_40000_624:
      00C3CC 04                    2227 	.db #0x04	; 4
      00C3CD 70                    2228 	.db #0x70	; 112	'p'
      00C3CE FF                    2229 	.db #0xff	; 255
      00C3CF 90                    2230 	.db #0x90	; 144
      00C3D0 01                    2231 	.db #0x01	; 1
      00C3D1 B9                    2232 	.db #0xb9	; 185
      00C3D2 15                    2233 	.db #0x15	; 21
      00C3D3 D3                    2234 	.db #0xd3	; 211
                                   2235 	.area CSEG    (CODE)
                                   2236 	.area XINIT   (CODE)
      00C602                       2237 __xinit__vial_unlocked:
      00C602 00                    2238 	.db #0x00	;  0
      00C603                       2239 __xinit__vial_unlock_in_progress:
      00C603 00                    2240 	.db #0x00	;  0
      00C604                       2241 __xinit__vial_unlock_counter:
      00C604 00                    2242 	.db #0x00	; 0
      00C605                       2243 __xinit__vial_unlock_combo_rows:
      00C605 00                    2244 	.db #0x00	; 0
      00C606 00                    2245 	.db #0x00	; 0
      00C607                       2246 __xinit__vial_unlock_combo_cols:
      00C607 00                    2247 	.db #0x00	; 0
      00C608 05                    2248 	.db #0x05	; 5
                                   2249 	.area CABS    (ABS,CODE)
                                   2250 
                                   2251 ; Experimental exact instruction outlining.
                                   2252 	.globl _ak820_outline_0006
                                   2253 	.globl _ak820_outline_0009
                                   2254 	.globl _ak820_outline_0010
                                   2255 	.globl _ak820_outline_0011
                                   2256 	.globl _ak820_outline_0012
                                   2257 	.globl _ak820_outline_0016
                                   2258 	.globl _ak820_outline_0018
                                   2259 	.globl _ak820_outline_0019
                                   2260 	.globl _ak820_outline_0023
                                   2261 	.globl _ak820_outline_0025
                                   2262 	.globl _ak820_outline_0034
                                   2263 	.globl _ak820_outline_0035
                                   2264 	.globl _ak820_outline_0036
                                   2265 	.globl _ak820_outline_0037
                                   2266 	.globl _ak820_outline_0042
                                   2267 	.globl _ak820_outline_0053
                                   2268 	.globl _ak820_outline_0058
                                   2269 	.globl _ak820_outline_0061
                                   2270 	.globl _ak820_outline_0062
                                   2271 	.globl _ak820_outline_0065
                                   2272 	.globl _ak820_outline_0066
                                   2273 	.globl _ak820_outline_0075
                                   2274 	.globl _ak820_outline_0080
                                   2275 	.globl _ak820_outline_0103
                                   2276 	.globl _ak820_outline_0108
                                   2277 	.globl _ak820_outline_0109
                                   2278 	.globl _ak820_outline_0119
                                   2279 	.globl _ak820_outline_0123
                                   2280 	.globl _ak820_outline_0125
                                   2281 	.globl _ak820_outline_0127
                                   2282 	.globl _ak820_outline_0128
                                   2283 	.globl _ak820_outline_0130
                                   2284 	.globl _ak820_outline_0131
                                   2285 	.globl _ak820_outline_0136
                                   2286 	.globl _ak820_outline_0137
                                   2287 	.globl _ak820_outline_0140
                                   2288 	.globl _ak820_outline_0144
                                   2289 	.globl _ak820_outline_0151
                                   2290 	.globl _ak820_outline_0159
                                   2291 	.globl _ak820_outline_0189
                                   2292 
                                   2293 	.area CSEG (CODE)
                                   2294 ; function ak820_outline_0011
      00B6FE                       2295 _ak820_outline_0011:
      00B6FE A3               [24] 2296 	inc	dptr
      00B6FF F0               [24] 2297 	movx	@dptr,a
      00B700 E4               [12] 2298 	clr	a
      00B701 A3               [24] 2299 	inc	dptr
      00B702 F0               [24] 2300 	movx	@dptr,a
      00B703 90 0E 6A         [24] 2301 	mov	dptr,#___memcpy_PARM_3
      00B706 74 0A            [12] 2302 	mov	a,#0x0a
      00B708 F0               [24] 2303 	movx	@dptr,a
      00B709 E4               [12] 2304 	clr	a
      00B70A A3               [24] 2305 	inc	dptr
      00B70B F0               [24] 2306 	movx	@dptr,a
      00B70C 22               [24] 2307 	ret
                                   2308 
                                   2309 	.area CSEG (CODE)
                                   2310 ; function ak820_outline_0025
      00B70D                       2311 _ak820_outline_0025:
      00B70D E0               [24] 2312 	movx	a,@dptr
      00B70E FE               [12] 2313 	mov	r6,a
      00B70F A3               [24] 2314 	inc	dptr
      00B710 E0               [24] 2315 	movx	a,@dptr
      00B711 FF               [12] 2316 	mov	r7,a
      00B712 90 0D 3F         [24] 2317 	mov	dptr,#_g_vial_magic_keycode_override
      00B715 EE               [12] 2318 	mov	a,r6
      00B716 F0               [24] 2319 	movx	@dptr,a
      00B717 EF               [12] 2320 	mov	a,r7
      00B718 A3               [24] 2321 	inc	dptr
      00B719 F0               [24] 2322 	movx	@dptr,a
      00B71A 8E 04            [24] 2323 	mov	ar4,r6
      00B71C 8F 05            [24] 2324 	mov	ar5,r7
      00B71E C3               [12] 2325 	clr	c
      00B71F 74 FF            [12] 2326 	mov	a,#0xff
      00B721 9C               [12] 2327 	subb	a,r4
      00B722 74 1F            [12] 2328 	mov	a,#0x1f
      00B724 9D               [12] 2329 	subb	a,r5
      00B725 22               [24] 2330 	ret
                                   2331 
                                   2332 	.area CSEG (CODE)
                                   2333 ; function ak820_outline_0130
      00B726                       2334 _ak820_outline_0130:
      00B726 24 EC            [12] 2335 	add	a,#_vial_unlock_combo_cols
      00B728 F5 82            [12] 2336 	mov	dpl,a
      00B72A E4               [12] 2337 	clr	a
      00B72B 34 0E            [12] 2338 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B72D F5 83            [12] 2339 	mov	dph,a
      00B72F E0               [24] 2340 	movx	a,@dptr
      00B730 22               [24] 2341 	ret
                                   2342 
                                   2343 	.area CSEG (CODE)
                                   2344 ; function ak820_outline_0131
      00B731                       2345 _ak820_outline_0131:
      00B731 24 EA            [12] 2346 	add	a,#_vial_unlock_combo_rows
      00B733 F5 82            [12] 2347 	mov	dpl,a
      00B735 E4               [12] 2348 	clr	a
      00B736 34 0E            [12] 2349 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B738 F5 83            [12] 2350 	mov	dph,a
      00B73A E0               [24] 2351 	movx	a,@dptr
      00B73B 22               [24] 2352 	ret
