                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tap_dance
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_get_tap_dance
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_tap_dance_valid
                                    258 	.globl _ak820_tap_dance_task
                                    259 	.globl _ak820_tap_dance_before
                                    260 	.globl _ak820_tap_dance_process
                                    261 	.globl _ak820_tap_dance_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
      00000C                        540 _td_finish_sloc0_1_0:
      00000C                        541 	.ds 1
      00000D                        542 _ak820_tap_dance_before_sloc0_1_0:
      00000D                        543 	.ds 1
      00000E                        544 _ak820_tap_dance_process_sloc0_1_0:
      00000E                        545 	.ds 1
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      00059A                        554 _td_slots:
      00059A                        555 	.ds 32
      0005BA                        556 _td_wait:
      0005BA                        557 	.ds 2
      0005BC                        558 _td_work:
      0005BC                        559 	.ds 2
      0005BE                        560 _td_entry:
      0005BE                        561 	.ds 10
      0005C8                        562 _td_time:
      0005C8                        563 	.ds 2
      0005CA                        564 _td_map:
      0005CA                        565 	.ds 128
      00064A                        566 _td_record:
      00064A                        567 	.ds 9
      000653                        568 _td_step:
      000653                        569 	.ds 1
      000654                        570 _ak820_td_invoking:
      000654                        571 	.ds 1
      000655                        572 _ak820_tap_dance_valid_entry_10000_594:
      000655                        573 	.ds 2
      000657                        574 _ak820_tap_dance_valid_basic_30000_598:
      000657                        575 	.ds 1
      000658                        576 _td_finish_interrupted_10000_603:
      000658                        577 	.ds 1
      000659                        578 _td_finish_choice_10000_604:
      000659                        579 	.ds 1
      00065A                        580 _td_finish_state_10000_604:
      00065A                        581 	.ds 1
      00065B                        582 _td_finish_extra_10000_604:
      00065B                        583 	.ds 1
      00065C                        584 _ak820_tap_dance_task_now_10000_621:
      00065C                        585 	.ds 2
      00065E                        586 _ak820_tap_dance_task_term_10000_622:
      00065E                        587 	.ds 2
      000660                        588 _ak820_tap_dance_before_event_10000_625:
      000660                        589 	.ds 2
      000662                        590 _ak820_tap_dance_process_record_10000_641:
      000662                        591 	.ds 2
                                    592 ;--------------------------------------------------------
                                    593 ; absolute external ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area XABS    (ABS,XDATA)
                                    596 ;--------------------------------------------------------
                                    597 ; initialized external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area XISEG   (XDATA)
                                    600 	.area HOME    (CODE)
                                    601 	.area GSINIT0 (CODE)
                                    602 	.area GSINIT1 (CODE)
                                    603 	.area GSINIT2 (CODE)
                                    604 	.area GSINIT3 (CODE)
                                    605 	.area GSINIT4 (CODE)
                                    606 	.area GSINIT5 (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area CSEG    (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; global & static initialisations
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT  (CODE)
                                    615 	.area GSFINAL (CODE)
                                    616 	.area GSINIT  (CODE)
                                    617 ;--------------------------------------------------------
                                    618 ; Home
                                    619 ;--------------------------------------------------------
                                    620 	.area HOME    (CODE)
                                    621 	.area HOME    (CODE)
                                    622 ;--------------------------------------------------------
                                    623 ; code
                                    624 ;--------------------------------------------------------
                                    625 	.area CSEG    (CODE)
                                    626 ;------------------------------------------------------------
                                    627 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    628 ;------------------------------------------------------------
                                    629 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    630 ;------------------------------------------------------------
                                    631 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    632 ;	-----------------------------------------
                           000007   633 	ar7 = 0x07
                           000006   634 	ar6 = 0x06
                           000005   635 	ar5 = 0x05
                           000004   636 	ar4 = 0x04
                           000003   637 	ar3 = 0x03
                           000002   638 	ar2 = 0x02
                           000001   639 	ar1 = 0x01
                           000000   640 	ar0 = 0x00
                                    641 ;	 function ak820_tap_dance_valid
                                    642 ;	-----------------------------------------
      004352                        643 _ak820_tap_dance_valid:
      004352 12 38 4E         [24]  644 	lcall	_ak820_outline_0109
      004355 90 06 55         [24]  645 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      004358 12 38 49         [24]  646 	lcall	_ak820_outline_0108
                                    647 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)entry;
      00435B 90 06 55         [24]  648 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      00435E 12 37 FB         [24]  649 	lcall	_ak820_outline_0058
                                    650 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: if (bytes[9] & 128) return false;
      004361 74 09            [12]  651 	mov	a,#0x09
      004363 12 37 DA         [24]  652 	lcall	_ak820_outline_0018
      004366 30 E7 04         [24]  653 	jnb	acc.7,00130$
      004369 75 82 00         [24]  654 	mov	dpl, #0x00
                                    655 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      00436C 22               [24]  656 	ret
      00436D                        657 00130$:
      00436D 7D 00            [12]  658 	mov	r5,#0x00
      00436F                        659 00114$:
      00436F BD 04 00         [24]  660 	cjne	r5,#0x04,00167$
      004372                        661 00167$:
      004372 50 38            [24]  662 	jnc	00112$
                                    663 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: uint8_t basic = bytes[0], mods = bytes[1];
      004374 12 38 30         [24]  664 	lcall	_ak820_outline_0094
      004377 FC               [12]  665 	mov	r4,a
      004378 90 06 57         [24]  666 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      00437B 12 42 F2         [24]  667 	lcall	_ak820_outline_0066
      00437E A3               [24]  668 	inc	dptr
      00437F E0               [24]  669 	movx	a,@dptr
                                    670 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:30: if (!(basic | mods)) continue;
      004380 FB               [12]  671 	mov	r3,a
      004381 4C               [12]  672 	orl	a,r4
      004382 60 22            [24]  673 	jz	00111$
                                    674 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:31: if (mods >= 32 || !((basic >= KC_A && basic <= KC_EXSEL) ||
      004384 BB 20 00         [24]  675 	cjne	r3,#0x20,00170$
      004387                        676 00170$:
      004387 50 19            [24]  677 	jnc	00105$
      004389 BC 04 00         [24]  678 	cjne	r4,#0x04,00172$
      00438C                        679 00172$:
      00438C 40 05            [24]  680 	jc	00109$
      00438E EC               [12]  681 	mov	a,r4
      00438F 24 5B            [12]  682 	add	a,#0xff - 0xa4
      004391 50 13            [24]  683 	jnc	00111$
                                    684 ;	free result
      004393                        685 00109$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:32: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI))) return false;
      004393 90 06 57         [24]  687 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      004396 E0               [24]  688 	movx	a,@dptr
      004397 FC               [12]  689 	mov	r4,a
      004398 BC E0 00         [24]  690 	cjne	r4,#0xe0,00175$
      00439B                        691 00175$:
      00439B 40 05            [24]  692 	jc	00105$
      00439D EC               [12]  693 	mov	a,r4
      00439E 24 18            [12]  694 	add	a,#0xff - 0xe7
      0043A0 50 04            [24]  695 	jnc	00111$
                                    696 ;	free result
      0043A2                        697 00105$:
      0043A2 75 82 00         [24]  698 	mov	dpl, #0x00
      0043A5 22               [24]  699 	ret
      0043A6                        700 00111$:
                                    701 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      0043A6 0D               [12]  702 	inc	r5
      0043A7 12 48 CB         [24]  703 	lcall	_ak820_outline_0121
      0043AA 80 C3            [24]  704 	sjmp	00114$
      0043AC                        705 00112$:
                                    706 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:34: return true;
      0043AC 75 82 01         [24]  707 	mov	dpl, #0x01
                                    708 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:35: }
      0043AF 22               [24]  709 	ret
                                    710 ;------------------------------------------------------------
                                    711 ;Allocation info for local variables in function 'td_prepare'
                                    712 ;------------------------------------------------------------
                                    713 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: static void td_prepare(void) {
                                    714 ;	-----------------------------------------
                                    715 ;	 function td_prepare
                                    716 ;	-----------------------------------------
      0043B0                        717 _td_prepare:
                                    718 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: td_record.event.key.row = td_work->source / MATRIX_COLS;
      0043B0 90 05 BC         [24]  719 	mov	dptr,#_td_work
      0043B3 12 37 AC         [24]  720 	lcall	_ak820_outline_0006
      0043B6 A3               [24]  721 	inc	dptr
      0043B7 A3               [24]  722 	inc	dptr
      0043B8 E0               [24]  723 	movx	a,@dptr
      0043B9 75 F0 08         [24]  724 	mov	b,#0x08
      0043BC 84               [48]  725 	div	ab
      0043BD 90 06 4B         [24]  726 	mov	dptr,#(_td_record + 0x0001)
      0043C0 F0               [24]  727 	movx	@dptr,a
                                    728 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: td_record.event.key.col = td_work->source % MATRIX_COLS;
      0043C1 90 05 BC         [24]  729 	mov	dptr,#_td_work
      0043C4 12 37 AC         [24]  730 	lcall	_ak820_outline_0006
      0043C7 A3               [24]  731 	inc	dptr
      0043C8 A3               [24]  732 	inc	dptr
      0043C9 E0               [24]  733 	movx	a,@dptr
      0043CA FF               [12]  734 	mov	r7,a
      0043CB 53 07 07         [24]  735 	anl	ar7,#0x07
      0043CE 90 06 4A         [24]  736 	mov	dptr,#_td_record
      0043D1 EF               [12]  737 	mov	a,r7
      0043D2 F0               [24]  738 	movx	@dptr,a
                                    739 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: td_record.event.type = KEY_EVENT;
      0043D3 90 06 4E         [24]  740 	mov	dptr,#(_td_record + 0x0004)
      0043D6 74 01            [12]  741 	mov	a,#0x01
      0043D8 F0               [24]  742 	movx	@dptr,a
                                    743 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:42: td_record.event.time = td_time;
      0043D9 90 05 C8         [24]  744 	mov	dptr,#_td_time
      0043DC 12 37 FB         [24]  745 	lcall	_ak820_outline_0058
      0043DF 90 06 4C         [24]  746 	mov	dptr,#(_td_record + 0x0002)
      0043E2 12 48 C5         [24]  747 	lcall	_ak820_outline_0065
                                    748 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: td_record.tap.count = 1;
      0043E5 90 06 50         [24]  749 	mov	dptr,#(_td_record + 0x0006)
      0043E8 E0               [24]  750 	movx	a,@dptr
      0043E9 54 0F            [12]  751 	anl	a,#0x0f
      0043EB 44 10            [12]  752 	orl	a,#0x10
      0043ED F0               [24]  753 	movx	@dptr,a
                                    754 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: }
      0043EE 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'td_finish'
                                    758 ;------------------------------------------------------------
                                    759 ;interrupted   Allocated with name '_td_finish_interrupted_10000_603'
                                    760 ;choice        Allocated with name '_td_finish_choice_10000_604'
                                    761 ;state         Allocated with name '_td_finish_state_10000_604'
                                    762 ;extra         Allocated with name '_td_finish_extra_10000_604'
                                    763 ;------------------------------------------------------------
                                    764 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:45: static void td_finish(bool interrupted) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function td_finish
                                    767 ;	-----------------------------------------
      0043EF                        768 _td_finish:
      0043EF E5 82            [12]  769 	mov	a,dpl
      0043F1 90 06 58         [24]  770 	mov	dptr,#_td_finish_interrupted_10000_603
      0043F4 F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:46: uint8_t choice = 0, state;
      0043F5 90 06 59         [24]  773 	mov	dptr,#_td_finish_choice_10000_604
      0043F8 E4               [12]  774 	clr	a
      0043F9 F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: bool extra = false;
      0043FA 90 06 5B         [24]  777 	mov	dptr,#_td_finish_extra_10000_604
      0043FD F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: if (ak820_td_invoking) return;
      0043FE 90 06 54         [24]  780 	mov	dptr,#_ak820_td_invoking
      004401 E0               [24]  781 	movx	a,@dptr
      004402 60 01            [24]  782 	jz	00102$
      004404 22               [24]  783 	ret
      004405                        784 00102$:
                                    785 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: if (!td_wait) return;
      004405 90 05 BA         [24]  786 	mov	dptr,#_td_wait
      004408 12 37 FB         [24]  787 	lcall	_ak820_outline_0058
      00440B 90 05 BA         [24]  788 	mov	dptr,#_td_wait
      00440E 12 48 A6         [24]  789 	lcall	_ak820_outline_0038
      004411 70 01            [24]  790 	jnz	00104$
      004413 22               [24]  791 	ret
      004414                        792 00104$:
                                    793 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:50: ak820_td_invoking = true;
      004414 90 06 54         [24]  794 	mov	dptr,#_ak820_td_invoking
      004417 74 01            [12]  795 	mov	a,#0x01
      004419 F0               [24]  796 	movx	@dptr,a
                                    797 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: td_work = td_wait;
      00441A 90 05 BC         [24]  798 	mov	dptr,#_td_work
      00441D 12 48 C5         [24]  799 	lcall	_ak820_outline_0065
                                    800 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: td_wait = 0;
      004420 90 05 BA         [24]  801 	mov	dptr,#_td_wait
      004423 12 48 D3         [24]  802 	lcall	_ak820_outline_0144
                                    803 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: state = td_work->state;
      004426 12 48 54         [24]  804 	lcall	_ak820_outline_0007
      004429 FD               [12]  805 	mov	r5,a
      00442A 90 06 5A         [24]  806 	mov	dptr,#_td_finish_state_10000_604
      00442D F0               [24]  807 	movx	@dptr,a
                                    808 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: td_work->state = state | TD_DONE;
      00442E 43 05 08         [24]  809 	orl	ar5,#0x08
      004431 12 43 17         [24]  810 	lcall	_ak820_outline_0119
      004434 ED               [12]  811 	mov	a,r5
      004435 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: if ((state & 3) == 1) {
      004436 90 06 5A         [24]  814 	mov	dptr,#_td_finish_state_10000_604
      004439 E0               [24]  815 	movx	a,@dptr
      00443A FF               [12]  816 	mov	r7,a
      00443B FE               [12]  817 	mov	r6,a
      00443C 53 06 03         [24]  818 	anl	ar6,#0x03
      00443F BE 01 12         [24]  819 	cjne	r6,#0x01,00112$
                                    820 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: if ((state & TD_DOWN) && !interrupted) choice = 1;
      004442 EF               [12]  821 	mov	a,r7
      004443 30 E2 2B         [24]  822 	jnb	acc.2,00113$
      004446 90 06 58         [24]  823 	mov	dptr,#_td_finish_interrupted_10000_603
      004449 E0               [24]  824 	movx	a,@dptr
      00444A 70 25            [24]  825 	jnz	00113$
      00444C 90 06 59         [24]  826 	mov	dptr,#_td_finish_choice_10000_604
      00444F 74 01            [12]  827 	mov	a,#0x01
      004451 F0               [24]  828 	movx	@dptr,a
      004452 80 1D            [24]  829 	sjmp	00113$
      004454                        830 00112$:
                                    831 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: } else if (interrupted) extra = true;
      004454 90 06 58         [24]  832 	mov	dptr,#_td_finish_interrupted_10000_603
      004457 E0               [24]  833 	movx	a,@dptr
      004458 60 08            [24]  834 	jz	00109$
      00445A 90 06 5B         [24]  835 	mov	dptr,#_td_finish_extra_10000_604
      00445D 74 01            [12]  836 	mov	a,#0x01
      00445F F0               [24]  837 	movx	@dptr,a
      004460 80 0F            [24]  838 	sjmp	00113$
      004462                        839 00109$:
                                    840 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: else choice = (state & TD_DOWN) ? 3 : 2;
      004462 EF               [12]  841 	mov	a,r7
      004463 30 E2 04         [24]  842 	jnb	acc.2,00136$
      004466 7F 03            [12]  843 	mov	r7,#0x03
      004468 80 02            [24]  844 	sjmp	00137$
      00446A                        845 00136$:
      00446A 7F 02            [12]  846 	mov	r7,#0x02
      00446C                        847 00137$:
      00446C 90 06 59         [24]  848 	mov	dptr,#_td_finish_choice_10000_604
      00446F EF               [12]  849 	mov	a,r7
      004470 F0               [24]  850 	movx	@dptr,a
      004471                        851 00113$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: td_work->output = ((uint16_t AK820_STATE_MEM *)&td_entry)[choice];
      004471 90 05 BC         [24]  853 	mov	dptr,#_td_work
      004474 12 37 FB         [24]  854 	lcall	_ak820_outline_0058
      004477 90 06 59         [24]  855 	mov	dptr,#_td_finish_choice_10000_604
      00447A E0               [24]  856 	movx	a,@dptr
      00447B FD               [12]  857 	mov	r5,a
      00447C 75 F0 02         [24]  858 	mov	b,#0x02
      00447F A4               [48]  859 	mul	ab
      004480 24 BE            [12]  860 	add	a, #_td_entry
      004482 F5 82            [12]  861 	mov	dpl,a
      004484 74 05            [12]  862 	mov	a,#(_td_entry >> 8)
      004486 35 F0            [12]  863 	addc	a, b
      004488 F5 83            [12]  864 	mov	dph,a
      00448A 12 38 43         [24]  865 	lcall	_ak820_outline_0103
      00448D 12 43 17         [24]  866 	lcall	_ak820_outline_0119
      004490 12 38 24         [24]  867 	lcall	_ak820_outline_0080
                                    868 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:60: if (!td_work->output) {
      004493 90 05 BC         [24]  869 	mov	dptr,#_td_work
      004496 12 37 AC         [24]  870 	lcall	_ak820_outline_0006
      004499 12 48 E2         [24]  871 	lcall	_ak820_outline_0173
      00449C 70 28            [24]  872 	jnz	00117$
                                    873 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: if (choice >= 2) extra = true;
      00449E BD 02 00         [24]  874 	cjne	r5,#0x02,00286$
      0044A1                        875 00286$:
      0044A1 40 06            [24]  876 	jc	00115$
      0044A3 90 06 5B         [24]  877 	mov	dptr,#_td_finish_extra_10000_604
      0044A6 74 01            [12]  878 	mov	a,#0x01
      0044A8 F0               [24]  879 	movx	@dptr,a
      0044A9                        880 00115$:
                                    881 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:62: td_work->output = choice == 3 && td_entry.on_hold ? td_entry.on_hold : td_entry.on_tap;
      0044A9 90 06 59         [24]  882 	mov	dptr,#_td_finish_choice_10000_604
      0044AC E0               [24]  883 	movx	a,@dptr
      0044AD FD               [12]  884 	mov	r5,a
      0044AE BD 03 09         [24]  885 	cjne	r5,#0x03,00138$
      0044B1 90 05 C0         [24]  886 	mov	dptr,#(_td_entry + 0x0002)
      0044B4 12 38 12         [24]  887 	lcall	_ak820_outline_0064
      0044B7 4C               [12]  888 	orl	a,r4
      0044B8 70 06            [24]  889 	jnz	00139$
      0044BA                        890 00138$:
      0044BA 90 05 BE         [24]  891 	mov	dptr,#_td_entry
      0044BD 12 38 12         [24]  892 	lcall	_ak820_outline_0064
      0044C0                        893 00139$:
      0044C0 12 43 17         [24]  894 	lcall	_ak820_outline_0119
      0044C3 12 38 1E         [24]  895 	lcall	_ak820_outline_0077
      0044C6                        896 00117$:
                                    897 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:64: td_step = extra ? 0 : 2;
      0044C6 90 06 5B         [24]  898 	mov	dptr,#_td_finish_extra_10000_604
      0044C9 E0               [24]  899 	movx	a,@dptr
      0044CA 60 04            [24]  900 	jz	00143$
      0044CC 7F 00            [12]  901 	mov	r7,#0x00
      0044CE 80 02            [24]  902 	sjmp	00144$
      0044D0                        903 00143$:
      0044D0 7F 02            [12]  904 	mov	r7,#0x02
      0044D2                        905 00144$:
      0044D2 90 06 53         [24]  906 	mov	dptr,#_td_step
      0044D5 EF               [12]  907 	mov	a,r7
      0044D6 F0               [24]  908 	movx	@dptr,a
                                    909 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:65: td_record.keycode = td_entry.on_tap;
      0044D7 90 05 BE         [24]  910 	mov	dptr,#_td_entry
      0044DA 12 48 84         [24]  911 	lcall	_ak820_outline_0032
                                    912 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:66: td_prepare();
      0044DD 12 43 B0         [24]  913 	lcall	_td_prepare
      0044E0                        914 00132$:
                                    915 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: for (; td_step < 4; ++td_step) {
      0044E0 90 06 53         [24]  916 	mov	dptr,#_td_step
      0044E3 E0               [24]  917 	movx	a,@dptr
      0044E4 FF               [12]  918 	mov	r7,a
      0044E5 BF 04 00         [24]  919 	cjne	r7,#0x04,00292$
      0044E8                        920 00292$:
      0044E8 50 4B            [24]  921 	jnc	00127$
                                    922 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:70: if (td_step == 2) td_record.keycode = td_work->output;
      0044EA BF 02 09         [24]  923 	cjne	r7,#0x02,00119$
      0044ED 90 05 BC         [24]  924 	mov	dptr,#_td_work
      0044F0 12 37 AC         [24]  925 	lcall	_ak820_outline_0006
      0044F3 12 48 84         [24]  926 	lcall	_ak820_outline_0032
      0044F6                        927 00119$:
                                    928 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: if (td_step == 3 && (td_work->state & TD_DOWN)) break;
      0044F6 90 06 53         [24]  929 	mov	dptr,#_td_step
      0044F9 E0               [24]  930 	movx	a,@dptr
      0044FA FF               [12]  931 	mov	r7,a
      0044FB BF 03 0D         [24]  932 	cjne	r7,#0x03,00121$
      0044FE 90 05 BC         [24]  933 	mov	dptr,#_td_work
      004501 12 37 AC         [24]  934 	lcall	_ak820_outline_0006
      004504 A3               [24]  935 	inc	dptr
      004505 A3               [24]  936 	inc	dptr
      004506 A3               [24]  937 	inc	dptr
      004507 E0               [24]  938 	movx	a,@dptr
      004508 20 E2 2A         [24]  939 	jb	acc.2,00127$
      00450B                        940 00121$:
                                    941 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:72: td_record.event.pressed = !(td_step & 1);
      00450B 90 06 53         [24]  942 	mov	dptr,#_td_step
      00450E E0               [24]  943 	movx	a,@dptr
      00450F 54 01            [12]  944 	anl	a,#0x01
      004511 B4 01 00         [24]  945 	cjne	a,#0x01,00299$
      004514                        946 00299$:
      004514 92 0C            [24]  947 	mov	_td_finish_sloc0_1_0,c
      004516 90 06 4F         [24]  948 	mov	dptr,#(_td_record + 0x0005)
      004519 E4               [12]  949 	clr	a
      00451A 33               [12]  950 	rlc	a
      00451B 12 48 D8         [24]  951 	lcall	_ak820_outline_0147
                                    952 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: if (td_record.keycode) process_record(&td_record);
      00451E 60 06            [24]  953 	jz	00124$
      004520 90 06 4A         [24]  954 	mov	dptr,#_td_record
      004523 12 75 6D         [24]  955 	lcall	_process_record
      004526                        956 00124$:
                                    957 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: if (!td_work->state) goto done;
      004526 12 48 54         [24]  958 	lcall	_ak820_outline_0007
      004529 60 15            [24]  959 	jz	00130$
                                    960 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: for (; td_step < 4; ++td_step) {
      00452B 90 06 53         [24]  961 	mov	dptr,#_td_step
      00452E E0               [24]  962 	movx	a,@dptr
      00452F 24 01            [12]  963 	add	a, #0x01
      004531 F0               [24]  964 	movx	@dptr,a
      004532 02 44 E0         [24]  965 	ljmp	00132$
      004535                        966 00127$:
                                    967 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:76: if (!(td_work->state & TD_DOWN)) td_work->state = 0;
      004535 12 48 54         [24]  968 	lcall	_ak820_outline_0007
      004538 20 E2 05         [24]  969 	jb	acc.2,00130$
      00453B 12 43 17         [24]  970 	lcall	_ak820_outline_0119
      00453E E4               [12]  971 	clr	a
      00453F F0               [24]  972 	movx	@dptr,a
                                    973 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:77: done:
      004540                        974 00130$:
                                    975 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:78: ak820_td_invoking = false;
      004540 90 06 54         [24]  976 	mov	dptr,#_ak820_td_invoking
      004543 E4               [12]  977 	clr	a
      004544 F0               [24]  978 	movx	@dptr,a
                                    979 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: }
      004545 22               [24]  980 	ret
                                    981 ;------------------------------------------------------------
                                    982 ;Allocation info for local variables in function 'ak820_tap_dance_task'
                                    983 ;------------------------------------------------------------
                                    984 ;now           Allocated with name '_ak820_tap_dance_task_now_10000_621'
                                    985 ;term          Allocated with name '_ak820_tap_dance_task_term_10000_622'
                                    986 ;------------------------------------------------------------
                                    987 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: void ak820_tap_dance_task(uint16_t now) {
                                    988 ;	-----------------------------------------
                                    989 ;	 function ak820_tap_dance_task
                                    990 ;	-----------------------------------------
      004546                        991 _ak820_tap_dance_task:
      004546 12 38 4E         [24]  992 	lcall	_ak820_outline_0109
      004549 90 06 5C         [24]  993 	mov	dptr,#_ak820_tap_dance_task_now_10000_621
      00454C 12 38 49         [24]  994 	lcall	_ak820_outline_0108
                                    995 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:81: uint16_t term = td_entry.custom_tapping_term;
      00454F 90 05 C6         [24]  996 	mov	dptr,#(_td_entry + 0x0008)
      004552 12 37 FB         [24]  997 	lcall	_ak820_outline_0058
      004555 90 06 5E         [24]  998 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004558 12 48 C5         [24]  999 	lcall	_ak820_outline_0065
                                   1000 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:82: if (!term) term = 200;
      00455B EE               [12] 1001 	mov	a,r6
      00455C 4F               [12] 1002 	orl	a,r7
      00455D 70 08            [24] 1003 	jnz	00102$
      00455F 90 06 5E         [24] 1004 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004562 74 C8            [12] 1005 	mov	a,#0xc8
      004564 12 38 5E         [24] 1006 	lcall	_ak820_outline_0128
      004567                       1007 00102$:
                                   1008 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: if (td_wait && (uint16_t)(now - td_time) >= term) td_finish(false);
      004567 90 05 BA         [24] 1009 	mov	dptr,#_td_wait
      00456A 12 48 A6         [24] 1010 	lcall	_ak820_outline_0038
      00456D 60 26            [24] 1011 	jz	00106$
      00456F 90 05 C8         [24] 1012 	mov	dptr,#_td_time
      004572 12 37 FB         [24] 1013 	lcall	_ak820_outline_0058
      004575 90 06 5C         [24] 1014 	mov	dptr,#_ak820_tap_dance_task_now_10000_621
      004578 12 38 12         [24] 1015 	lcall	_ak820_outline_0064
      00457B EC               [12] 1016 	mov	a,r4
      00457C C3               [12] 1017 	clr	c
      00457D 9E               [12] 1018 	subb	a,r6
      00457E FE               [12] 1019 	mov	r6,a
      00457F ED               [12] 1020 	mov	a,r5
      004580 9F               [12] 1021 	subb	a,r7
      004581 FF               [12] 1022 	mov	r7,a
      004582 90 06 5E         [24] 1023 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004585 12 38 12         [24] 1024 	lcall	_ak820_outline_0064
      004588 C3               [12] 1025 	clr	c
      004589 EE               [12] 1026 	mov	a,r6
      00458A 9C               [12] 1027 	subb	a,r4
      00458B EF               [12] 1028 	mov	a,r7
      00458C 9D               [12] 1029 	subb	a,r5
      00458D 40 06            [24] 1030 	jc	00106$
      00458F 75 82 00         [24] 1031 	mov	dpl, #0x00
                                   1032 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:84: }
      004592 02 43 EF         [24] 1033 	ljmp	_td_finish
      004595                       1034 00106$:
      004595 22               [24] 1035 	ret
                                   1036 ;------------------------------------------------------------
                                   1037 ;Allocation info for local variables in function 'ak820_tap_dance_before'
                                   1038 ;------------------------------------------------------------
                                   1039 ;event         Allocated with name '_ak820_tap_dance_before_event_10000_625'
                                   1040 ;id            Allocated with name '_ak820_tap_dance_before_id_10000_626'
                                   1041 ;slot          Allocated with name '_ak820_tap_dance_before_slot_10000_626'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:85: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function ak820_tap_dance_before
                                   1046 ;	-----------------------------------------
      004596                       1047 _ak820_tap_dance_before:
      004596 12 38 4E         [24] 1048 	lcall	_ak820_outline_0109
      004599 90 06 60         [24] 1049 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      00459C 12 38 49         [24] 1050 	lcall	_ak820_outline_0108
                                   1051 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:88: if (IS_NOEVENT(*event)) return true;
      00459F 90 06 60         [24] 1052 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      0045A2 12 48 69         [24] 1053 	lcall	_ak820_outline_0013
      0045A5 70 04            [24] 1054 	jnz	00102$
      0045A7 75 82 01         [24] 1055 	mov	dpl, #0x01
      0045AA 22               [24] 1056 	ret
      0045AB                       1057 00102$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
      0045AB 12 38 36         [24] 1059 	lcall	_ak820_outline_0097
      0045AE FD               [12] 1060 	mov	r5,a
      0045AF BD 10 00         [24] 1061 	cjne	r5,#0x10,00220$
      0045B2                       1062 00220$:
      0045B2 50 09            [24] 1063 	jnc	00105$
      0045B4 12 38 30         [24] 1064 	lcall	_ak820_outline_0094
      0045B7 FC               [12] 1065 	mov	r4,a
      0045B8 BC 08 00         [24] 1066 	cjne	r4,#0x08,00222$
      0045BB                       1067 00222$:
      0045BB 40 1D            [24] 1068 	jc	00106$
      0045BD                       1069 00105$:
                                   1070 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: if (event->pressed) td_finish(true);
      0045BD 90 06 60         [24] 1071 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      0045C0 12 42 FF         [24] 1072 	lcall	_ak820_outline_0081
      0045C3 74 05            [12] 1073 	mov	a,#0x05
      0045C5 2A               [12] 1074 	add	a, r2
      0045C6 FA               [12] 1075 	mov	r2,a
      0045C7 E4               [12] 1076 	clr	a
      0045C8 3B               [12] 1077 	addc	a, r3
      0045C9 FB               [12] 1078 	mov	r3,a
      0045CA 12 43 22         [24] 1079 	lcall	_ak820_outline_0136
      0045CD E0               [24] 1080 	movx	a,@dptr
      0045CE 60 06            [24] 1081 	jz	00104$
      0045D0 75 82 01         [24] 1082 	mov	dpl, #0x01
      0045D3 12 43 EF         [24] 1083 	lcall	_td_finish
      0045D6                       1084 00104$:
                                   1085 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: return true;
      0045D6 75 82 01         [24] 1086 	mov	dpl, #0x01
      0045D9 22               [24] 1087 	ret
      0045DA                       1088 00106$:
                                   1089 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: id = event->key.row * MATRIX_COLS + event->key.col;
      0045DA ED               [12] 1090 	mov	a,r5
      0045DB 12 38 72         [24] 1091 	lcall	_ak820_outline_0162
                                   1092 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:94: if (td_map[id] == TD_NONE) {
      0045DE 2C               [12] 1093 	add	a,r4
      0045DF FD               [12] 1094 	mov	r5,a
      0045E0 24 CA            [12] 1095 	add	a, #_td_map
      0045E2 FB               [12] 1096 	mov	r3,a
      0045E3 E4               [12] 1097 	clr	a
      0045E4 34 05            [12] 1098 	addc	a, #(_td_map >> 8)
      0045E6 12 48 B6         [24] 1099 	lcall	_ak820_outline_0051
      0045E9 BA FF 11         [24] 1100 	cjne	r2,#0xff,00111$
                                   1101 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:95: if (!event->pressed) td_map[id] = 0;
      0045EC 74 05            [12] 1102 	mov	a,#0x05
      0045EE 2E               [12] 1103 	add	a, r6
      0045EF 12 37 D0         [24] 1104 	lcall	_ak820_outline_0017
      0045F2 70 05            [24] 1105 	jnz	00109$
      0045F4 12 33 FC         [24] 1106 	lcall	_ak820_outline_0123
      0045F7 E4               [12] 1107 	clr	a
      0045F8 F0               [24] 1108 	movx	@dptr,a
      0045F9                       1109 00109$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:96: return false;
      0045F9 75 82 00         [24] 1111 	mov	dpl, #0x00
      0045FC 22               [24] 1112 	ret
      0045FD                       1113 00111$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: if (event->pressed && td_wait && (td_wait->source != id || (td_wait->state & 3) == 2)) td_finish(true);
      0045FD 12 37 9F         [24] 1115 	lcall	_ak820_outline_0002
      004600 60 1F            [24] 1116 	jz	00113$
      004602 90 05 BA         [24] 1117 	mov	dptr,#_td_wait
      004605 12 37 FB         [24] 1118 	lcall	_ak820_outline_0058
      004608 4E               [12] 1119 	orl	a,r6
      004609 60 16            [24] 1120 	jz	00113$
      00460B 12 37 EB         [24] 1121 	lcall	_ak820_outline_0035
      00460E B5 05 0A         [24] 1122 	cjne	a,ar5,00112$
      004611 12 48 7B         [24] 1123 	lcall	_ak820_outline_0016
      004614 FF               [12] 1124 	mov	r7,a
      004615 53 07 03         [24] 1125 	anl	ar7,#0x03
      004618 BF 02 06         [24] 1126 	cjne	r7,#0x02,00113$
      00461B                       1127 00112$:
      00461B 75 82 01         [24] 1128 	mov	dpl, #0x01
      00461E 12 43 EF         [24] 1129 	lcall	_td_finish
      004621                       1130 00113$:
                                   1131 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:99: id = event->key.row * MATRIX_COLS + event->key.col;
      004621 90 06 60         [24] 1132 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      004624 12 37 AC         [24] 1133 	lcall	_ak820_outline_0006
      004627 A3               [24] 1134 	inc	dptr
      004628 E0               [24] 1135 	movx	a,@dptr
      004629 12 38 72         [24] 1136 	lcall	_ak820_outline_0162
      00462C FD               [12] 1137 	mov	r5,a
      00462D 12 38 30         [24] 1138 	lcall	_ak820_outline_0094
      004630 2D               [12] 1139 	add	a, r5
                                   1140 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: slot = td_slots + td_map[id];
      004631 FD               [12] 1141 	mov	r5,a
      004632 12 48 92         [24] 1142 	lcall	_ak820_outline_0033
      004635 E0               [24] 1143 	movx	a,@dptr
      004636 12 38 82         [24] 1144 	lcall	_ak820_outline_0191
      004639 24 9A            [12] 1145 	add	a, #_td_slots
      00463B FB               [12] 1146 	mov	r3,a
      00463C 74 05            [12] 1147 	mov	a,#(_td_slots >> 8)
      00463E 35 F0            [12] 1148 	addc	a, b
      004640 FC               [12] 1149 	mov	r4,a
                                   1150 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:101: if (slot->state && slot->source == id) {
      004641 74 03            [12] 1151 	mov	a,#0x03
      004643 2B               [12] 1152 	add	a, r3
      004644 F9               [12] 1153 	mov	r1,a
      004645 E4               [12] 1154 	clr	a
      004646 3C               [12] 1155 	addc	a, r4
      004647 FA               [12] 1156 	mov	r2,a
      004648 12 43 32         [24] 1157 	lcall	_ak820_outline_0151
      00464B E0               [24] 1158 	movx	a,@dptr
      00464C F8               [12] 1159 	mov	r0,a
      00464D 60 57            [24] 1160 	jz	00124$
      00464F C0 00            [24] 1161 	push	ar0
      004651 12 33 FC         [24] 1162 	lcall	_ak820_outline_0123
      004654 A3               [24] 1163 	inc	dptr
      004655 A3               [24] 1164 	inc	dptr
      004656 E0               [24] 1165 	movx	a,@dptr
      004657 B5 05 02         [24] 1166 	cjne	a,ar5,00235$
      00465A 80 04            [24] 1167 	sjmp	00236$
      00465C                       1168 00235$:
      00465C D0 00            [24] 1169 	pop	ar0
      00465E 80 46            [24] 1170 	sjmp	00124$
      004660                       1171 00236$:
      004660 D0 00            [24] 1172 	pop	ar0
                                   1173 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: if (event->pressed) return !(slot->state & TD_DONE);
      004662 12 37 9F         [24] 1174 	lcall	_ak820_outline_0002
      004665 60 0E            [24] 1175 	jz	00118$
      004667 E8               [12] 1176 	mov	a,r0
      004668 A2 E3            [12] 1177 	mov	c,acc.3
      00466A E4               [12] 1178 	clr	a
      00466B 33               [12] 1179 	rlc	a
      00466C B4 01 00         [24] 1180 	cjne	a,#0x01,00238$
      00466F                       1181 00238$:
      00466F 92 0D            [24] 1182 	mov  _ak820_tap_dance_before_sloc0_1_0,c
      004671 12 38 68         [24] 1183 	lcall	_ak820_outline_0150
      004674 22               [24] 1184 	ret
      004675                       1185 00118$:
                                   1186 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: slot->state &= ~TD_DOWN;
      004675 53 00 FB         [24] 1187 	anl	ar0,#0xfb
      004678 12 48 BE         [24] 1188 	lcall	_ak820_outline_0063
                                   1189 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: if (slot->state & TD_DONE) {
      00467B E8               [12] 1190 	mov	a,r0
      00467C 30 E3 23         [24] 1191 	jnb	acc.3,00122$
                                   1192 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:105: td_work = slot;
      00467F 90 05 BC         [24] 1193 	mov	dptr,#_td_work
      004682 12 38 24         [24] 1194 	lcall	_ak820_outline_0080
                                   1195 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:106: td_record.keycode = slot->output;
      004685 12 33 FC         [24] 1196 	lcall	_ak820_outline_0123
      004688 12 48 84         [24] 1197 	lcall	_ak820_outline_0032
                                   1198 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:107: slot->state = 0;
      00468B 12 43 32         [24] 1199 	lcall	_ak820_outline_0151
      00468E E4               [12] 1200 	clr	a
      00468F F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: td_prepare();
      004690 12 43 B0         [24] 1203 	lcall	_td_prepare
                                   1204 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:109: td_record.event.pressed = false;
      004693 90 06 4F         [24] 1205 	mov	dptr,#(_td_record + 0x0005)
      004696 E4               [12] 1206 	clr	a
      004697 12 48 D8         [24] 1207 	lcall	_ak820_outline_0147
                                   1208 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: if (td_record.keycode) process_record(&td_record);
      00469A 60 06            [24] 1209 	jz	00122$
      00469C 90 06 4A         [24] 1210 	mov	dptr,#_td_record
      00469F 12 75 6D         [24] 1211 	lcall	_process_record
      0046A2                       1212 00122$:
                                   1213 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:112: return false;
      0046A2 75 82 00         [24] 1214 	mov	dpl, #0x00
      0046A5 22               [24] 1215 	ret
      0046A6                       1216 00124$:
                                   1217 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: return true;
      0046A6 75 82 01         [24] 1218 	mov	dpl, #0x01
                                   1219 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:115: }
      0046A9 22               [24] 1220 	ret
                                   1221 ;------------------------------------------------------------
                                   1222 ;Allocation info for local variables in function 'ak820_tap_dance_process'
                                   1223 ;------------------------------------------------------------
                                   1224 ;record        Allocated with name '_ak820_tap_dance_process_record_10000_641'
                                   1225 ;index         Allocated with name '_ak820_tap_dance_process_index_10000_642'
                                   1226 ;id            Allocated with name '_ak820_tap_dance_process_id_10000_642'
                                   1227 ;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_642'
                                   1228 ;------------------------------------------------------------
                                   1229 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:116: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1230 ;	-----------------------------------------
                                   1231 ;	 function ak820_tap_dance_process
                                   1232 ;	-----------------------------------------
      0046AA                       1233 _ak820_tap_dance_process:
      0046AA 12 38 4E         [24] 1234 	lcall	_ak820_outline_0109
      0046AD 90 06 62         [24] 1235 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      0046B0 12 38 49         [24] 1236 	lcall	_ak820_outline_0108
                                   1237 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: if (get_repeat_key_count() || ak820_macro_primitive || record->event.type != KEY_EVENT ||
      0046B3 12 A6 44         [24] 1238 	lcall	_get_repeat_key_count
      0046B6 E5 82            [12] 1239 	mov	a, dpl
      0046B8 70 2F            [24] 1240 	jnz	00101$
      0046BA 90 0A 46         [24] 1241 	mov	dptr,#_ak820_macro_primitive
      0046BD E0               [24] 1242 	movx	a,@dptr
      0046BE 70 29            [24] 1243 	jnz	00101$
      0046C0 90 06 62         [24] 1244 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      0046C3 12 37 AC         [24] 1245 	lcall	_ak820_outline_0006
      0046C6 A3               [24] 1246 	inc	dptr
      0046C7 A3               [24] 1247 	inc	dptr
      0046C8 A3               [24] 1248 	inc	dptr
      0046C9 A3               [24] 1249 	inc	dptr
      0046CA E0               [24] 1250 	movx	a,@dptr
      0046CB FD               [12] 1251 	mov	r5,a
      0046CC BD 01 1A         [24] 1252 	cjne	r5,#0x01,00101$
                                   1253 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:120: record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS ||
      0046CF 12 38 36         [24] 1254 	lcall	_ak820_outline_0097
      0046D2 FD               [12] 1255 	mov	r5,a
      0046D3 BD 10 00         [24] 1256 	cjne	r5,#0x10,00228$
      0046D6                       1257 00228$:
      0046D6 50 11            [24] 1258 	jnc	00101$
      0046D8 12 38 30         [24] 1259 	lcall	_ak820_outline_0094
      0046DB FC               [12] 1260 	mov	r4,a
      0046DC BC 08 00         [24] 1261 	cjne	r4,#0x08,00230$
      0046DF                       1262 00230$:
      0046DF 50 08            [24] 1263 	jnc	00101$
                                   1264 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: !record->event.pressed) return (record->keycode >> 8) != (QK_TAP_DANCE >> 8);
      0046E1 74 05            [12] 1265 	mov	a,#0x05
      0046E3 2E               [12] 1266 	add	a, r6
      0046E4 12 48 9C         [24] 1267 	lcall	_ak820_outline_0034
      0046E7 70 26            [24] 1268 	jnz	00102$
      0046E9                       1269 00101$:
      0046E9 90 06 62         [24] 1270 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      0046EC 12 42 FF         [24] 1271 	lcall	_ak820_outline_0081
      0046EF 74 07            [12] 1272 	mov	a,#0x07
      0046F1 2A               [12] 1273 	add	a, r2
      0046F2 F5 82            [12] 1274 	mov	dpl,a
      0046F4 E4               [12] 1275 	clr	a
      0046F5 3B               [12] 1276 	addc	a, r3
      0046F6 F5 83            [12] 1277 	mov	dph,a
      0046F8 E0               [24] 1278 	movx	a,@dptr
      0046F9 A3               [24] 1279 	inc	dptr
      0046FA E0               [24] 1280 	movx	a,@dptr
      0046FB FA               [12] 1281 	mov	r2,a
      0046FC 7B 00            [12] 1282 	mov	r3,#0x00
      0046FE BA 57 06         [24] 1283 	cjne	r2,#0x57,00233$
      004701 BB 00 03         [24] 1284 	cjne	r3,#0x00,00233$
      004704 D3               [12] 1285 	setb	c
      004705 80 01            [24] 1286 	sjmp	00234$
      004707                       1287 00233$:
      004707 C3               [12] 1288 	clr	c
      004708                       1289 00234$:
      004708 B3               [12] 1290 	cpl	c
      004709 92 0E            [24] 1291 	mov	_ak820_tap_dance_process_sloc0_1_0,c
      00470B 12 38 68         [24] 1292 	lcall	_ak820_outline_0150
      00470E 22               [24] 1293 	ret
      00470F                       1294 00102$:
                                   1295 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:122: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      00470F ED               [12] 1296 	mov	a,r5
      004710 12 38 72         [24] 1297 	lcall	_ak820_outline_0162
      004713 2C               [12] 1298 	add	a,r4
      004714 FD               [12] 1299 	mov	r5,a
                                   1300 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:124: if (td_wait && !(td_wait->state & TD_DOWN) && td_wait->source == id &&
      004715 90 05 BA         [24] 1301 	mov	dptr,#_td_wait
      004718 12 38 43         [24] 1302 	lcall	_ak820_outline_0103
      00471B 4B               [12] 1303 	orl	a,r3
      00471C 60 3B            [24] 1304 	jz	00109$
      00471E 12 33 FC         [24] 1305 	lcall	_ak820_outline_0123
      004721 A3               [24] 1306 	inc	dptr
      004722 A3               [24] 1307 	inc	dptr
      004723 A3               [24] 1308 	inc	dptr
      004724 E0               [24] 1309 	movx	a,@dptr
      004725 20 E2 31         [24] 1310 	jb	acc.2,00109$
      004728 12 33 FC         [24] 1311 	lcall	_ak820_outline_0123
      00472B A3               [24] 1312 	inc	dptr
      00472C A3               [24] 1313 	inc	dptr
      00472D E0               [24] 1314 	movx	a,@dptr
      00472E B5 05 28         [24] 1315 	cjne	a,ar5,00109$
                                   1316 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: record->keycode != (QK_TAP_DANCE | td_map[id])) td_finish(true);
      004731 74 07            [12] 1317 	mov	a,#0x07
      004733 12 37 DA         [24] 1318 	lcall	_ak820_outline_0018
      004736 FE               [12] 1319 	mov	r6,a
      004737 A3               [24] 1320 	inc	dptr
      004738 E0               [24] 1321 	movx	a,@dptr
      004739 FF               [12] 1322 	mov	r7,a
      00473A ED               [12] 1323 	mov	a,r5
      00473B 12 48 92         [24] 1324 	lcall	_ak820_outline_0033
      00473E E0               [24] 1325 	movx	a,@dptr
      00473F FC               [12] 1326 	mov	r4,a
      004740 7B 00            [12] 1327 	mov	r3,#0x00
      004742 43 03 57         [24] 1328 	orl	ar3,#0x57
      004745 EE               [12] 1329 	mov	a,r6
      004746 B5 04 06         [24] 1330 	cjne	a,ar4,00239$
      004749 EF               [12] 1331 	mov	a,r7
      00474A B5 03 02         [24] 1332 	cjne	a,ar3,00239$
      00474D 80 0A            [24] 1333 	sjmp	00109$
      00474F                       1334 00239$:
      00474F 75 82 01         [24] 1335 	mov	dpl, #0x01
      004752 C0 05            [24] 1336 	push	ar5
      004754 12 43 EF         [24] 1337 	lcall	_td_finish
      004757 D0 05            [24] 1338 	pop	ar5
      004759                       1339 00109$:
                                   1340 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:126: if ((record->keycode >> 8) != (QK_TAP_DANCE >> 8)) return true;
      004759 90 06 62         [24] 1341 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      00475C 12 37 B6         [24] 1342 	lcall	_ak820_outline_0008
      00475F FE               [12] 1343 	mov	r6,a
      004760 A3               [24] 1344 	inc	dptr
      004761 E0               [24] 1345 	movx	a,@dptr
      004762 FB               [12] 1346 	mov	r3,a
      004763 7C 00            [12] 1347 	mov	r4,#0x00
      004765 BB 57 05         [24] 1348 	cjne	r3,#0x57,00240$
      004768 BC 00 02         [24] 1349 	cjne	r4,#0x00,00240$
      00476B 80 04            [24] 1350 	sjmp	00114$
      00476D                       1351 00240$:
      00476D 75 82 01         [24] 1352 	mov	dpl, #0x01
      004770 22               [24] 1353 	ret
      004771                       1354 00114$:
                                   1355 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:127: index = (uint8_t)record->keycode;
                                   1356 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:128: slot = td_slots + (index & 7);
      004771 8E 04            [24] 1357 	mov	ar4,r6
      004773 53 04 07         [24] 1358 	anl	ar4,#0x07
      004776 7F 00            [12] 1359 	mov	r7,#0x00
      004778 EC               [12] 1360 	mov	a,r4
      004779 2C               [12] 1361 	add	a,r4
      00477A FC               [12] 1362 	mov	r4,a
      00477B EF               [12] 1363 	mov	a,r7
      00477C 33               [12] 1364 	rlc	a
      00477D FF               [12] 1365 	mov	r7,a
      00477E EC               [12] 1366 	mov	a,r4
      00477F 2C               [12] 1367 	add	a,r4
      004780 FC               [12] 1368 	mov	r4,a
      004781 EF               [12] 1369 	mov	a,r7
      004782 33               [12] 1370 	rlc	a
      004783 FF               [12] 1371 	mov	r7,a
      004784 EC               [12] 1372 	mov	a,r4
      004785 24 9A            [12] 1373 	add	a, #_td_slots
      004787 FC               [12] 1374 	mov	r4,a
      004788 EF               [12] 1375 	mov	a,r7
      004789 34 05            [12] 1376 	addc	a, #(_td_slots >> 8)
      00478B FF               [12] 1377 	mov	r7,a
                                   1378 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: if (index >= VIAL_TAP_DANCE_ENTRIES || (slot->state && slot->source != id)) goto suppress;
      00478C BE 08 00         [24] 1379 	cjne	r6,#0x08,00241$
      00478F                       1380 00241$:
      00478F 40 03            [24] 1381 	jc	00242$
      004791 02 48 18         [24] 1382 	ljmp	00123$
      004794                       1383 00242$:
      004794 74 03            [12] 1384 	mov	a,#0x03
      004796 2C               [12] 1385 	add	a, r4
      004797 12 48 9C         [24] 1386 	lcall	_ak820_outline_0034
      00479A F9               [12] 1387 	mov	r1,a
      00479B 60 0E            [24] 1388 	jz	00116$
      00479D 12 48 E8         [24] 1389 	lcall	_ak820_outline_0186
      0047A0 A3               [24] 1390 	inc	dptr
      0047A1 A3               [24] 1391 	inc	dptr
      0047A2 E0               [24] 1392 	movx	a,@dptr
      0047A3 B5 05 02         [24] 1393 	cjne	a,ar5,00244$
      0047A6 80 03            [24] 1394 	sjmp	00245$
      0047A8                       1395 00244$:
      0047A8 02 48 18         [24] 1396 	ljmp	00123$
      0047AB                       1397 00245$:
      0047AB                       1398 00116$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: if (!slot->state) {
      0047AB E9               [12] 1400 	mov	a,r1
      0047AC 70 36            [24] 1401 	jnz	00122$
                                   1402 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: if (dynamic_keymap_get_tap_dance(index, &td_entry)) goto suppress;
      0047AE 90 0B AD         [24] 1403 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      0047B1 74 BE            [12] 1404 	mov	a,#_td_entry
      0047B3 F0               [24] 1405 	movx	@dptr,a
      0047B4 74 05            [12] 1406 	mov	a,#(_td_entry >> 8)
      0047B6 12 38 18         [24] 1407 	lcall	_ak820_outline_0075
      0047B9 8E 82            [24] 1408 	mov	dpl, r6
      0047BB C0 07            [24] 1409 	push	ar7
      0047BD C0 06            [24] 1410 	push	ar6
      0047BF C0 05            [24] 1411 	push	ar5
      0047C1 C0 04            [24] 1412 	push	ar4
      0047C3 C0 03            [24] 1413 	push	ar3
      0047C5 C0 02            [24] 1414 	push	ar2
      0047C7 12 89 6D         [24] 1415 	lcall	_dynamic_keymap_get_tap_dance
      0047CA 12 38 53         [24] 1416 	lcall	_ak820_outline_0124
      0047CD D0 02            [24] 1417 	pop	ar2
      0047CF D0 03            [24] 1418 	pop	ar3
      0047D1 D0 04            [24] 1419 	pop	ar4
      0047D3 D0 05            [24] 1420 	pop	ar5
      0047D5 D0 06            [24] 1421 	pop	ar6
      0047D7 D0 07            [24] 1422 	pop	ar7
      0047D9 45 F0            [12] 1423 	orl	a,b
      0047DB 70 3B            [24] 1424 	jnz	00123$
                                   1425 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:132: slot->source = id;
      0047DD 12 48 E8         [24] 1426 	lcall	_ak820_outline_0186
      0047E0 A3               [24] 1427 	inc	dptr
      0047E1 A3               [24] 1428 	inc	dptr
      0047E2 ED               [12] 1429 	mov	a,r5
      0047E3 F0               [24] 1430 	movx	@dptr,a
      0047E4                       1431 00122$:
                                   1432 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: slot->state = (slot->state & 3) + 1 + TD_DOWN;
      0047E4 12 43 22         [24] 1433 	lcall	_ak820_outline_0136
      0047E7 E0               [24] 1434 	movx	a,@dptr
      0047E8 F9               [12] 1435 	mov	r1,a
      0047E9 74 03            [12] 1436 	mov	a,#0x03
      0047EB 59               [12] 1437 	anl	a,r1
      0047EC 24 05            [12] 1438 	add	a, #0x05
      0047EE 12 43 22         [24] 1439 	lcall	_ak820_outline_0136
      0047F1 F0               [24] 1440 	movx	@dptr,a
                                   1441 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: td_time = record->event.time;
      0047F2 90 06 62         [24] 1442 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      0047F5 12 42 FF         [24] 1443 	lcall	_ak820_outline_0081
      0047F8 12 43 22         [24] 1444 	lcall	_ak820_outline_0136
      0047FB A3               [24] 1445 	inc	dptr
      0047FC A3               [24] 1446 	inc	dptr
      0047FD 12 42 FF         [24] 1447 	lcall	_ak820_outline_0081
      004800 90 05 C8         [24] 1448 	mov	dptr,#_td_time
      004803 EA               [12] 1449 	mov	a,r2
      004804 12 48 ED         [24] 1450 	lcall	_ak820_outline_0189
                                   1451 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: td_wait = slot;
      004807 90 05 BA         [24] 1452 	mov	dptr,#_td_wait
      00480A EC               [12] 1453 	mov	a,r4
      00480B 12 38 49         [24] 1454 	lcall	_ak820_outline_0108
                                   1455 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: td_map[id] = index;
      00480E ED               [12] 1456 	mov	a,r5
      00480F 12 48 92         [24] 1457 	lcall	_ak820_outline_0033
      004812 EE               [12] 1458 	mov	a,r6
      004813 F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:138: return false;
      004814 75 82 00         [24] 1461 	mov	dpl, #0x00
                                   1462 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: suppress:
      004817 22               [24] 1463 	ret
      004818                       1464 00123$:
                                   1465 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:140: td_map[id] = TD_NONE;
      004818 ED               [12] 1466 	mov	a,r5
      004819 12 48 92         [24] 1467 	lcall	_ak820_outline_0033
      00481C 74 FF            [12] 1468 	mov	a,#0xff
      00481E F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: return false;
      00481F 75 82 00         [24] 1471 	mov	dpl, #0x00
                                   1472 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:142: }
      004822 22               [24] 1473 	ret
                                   1474 ;------------------------------------------------------------
                                   1475 ;Allocation info for local variables in function 'ak820_tap_dance_cancel'
                                   1476 ;------------------------------------------------------------
                                   1477 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_652'
                                   1478 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_653'
                                   1479 ;------------------------------------------------------------
                                   1480 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:143: void ak820_tap_dance_cancel(void) {
                                   1481 ;	-----------------------------------------
                                   1482 ;	 function ak820_tap_dance_cancel
                                   1483 ;	-----------------------------------------
      004823                       1484 _ak820_tap_dance_cancel:
                                   1485 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:144: td_wait = 0;
      004823 90 05 BA         [24] 1486 	mov	dptr,#_td_wait
      004826 12 48 D3         [24] 1487 	lcall	_ak820_outline_0144
                                   1488 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:145: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_slots[i].state = 0;
      004829 FF               [12] 1489 	mov	r7,a
      00482A                       1490 00104$:
      00482A BF 08 00         [24] 1491 	cjne	r7,#0x08,00141$
      00482D                       1492 00141$:
      00482D 50 14            [24] 1493 	jnc	00101$
      00482F EF               [12] 1494 	mov	a,r7
      004830 12 38 82         [24] 1495 	lcall	_ak820_outline_0191
      004833 24 9A            [12] 1496 	add	a, #_td_slots
      004835 FD               [12] 1497 	mov	r5,a
      004836 74 05            [12] 1498 	mov	a,#(_td_slots >> 8)
      004838 35 F0            [12] 1499 	addc	a, b
      00483A FE               [12] 1500 	mov	r6,a
      00483B 12 48 AE         [24] 1501 	lcall	_ak820_outline_0041
      00483E E4               [12] 1502 	clr	a
      00483F F0               [24] 1503 	movx	@dptr,a
      004840 0F               [12] 1504 	inc	r7
      004841 80 E7            [24] 1505 	sjmp	00104$
      004843                       1506 00101$:
                                   1507 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:146: for (uint8_t i = 0; i < sizeof(td_map); ++i) td_map[i] = 0;
      004843 7F 00            [12] 1508 	mov	r7,#0x00
      004845                       1509 00107$:
      004845 BF 80 00         [24] 1510 	cjne	r7,#0x80,00143$
      004848                       1511 00143$:
      004848 50 09            [24] 1512 	jnc	00109$
      00484A EF               [12] 1513 	mov	a,r7
      00484B 12 48 92         [24] 1514 	lcall	_ak820_outline_0033
      00484E E4               [12] 1515 	clr	a
      00484F F0               [24] 1516 	movx	@dptr,a
      004850 0F               [12] 1517 	inc	r7
      004851 80 F2            [24] 1518 	sjmp	00107$
      004853                       1519 00109$:
                                   1520 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:147: }
      004853 22               [24] 1521 	ret
                                   1522 	.area CSEG    (CODE)
                                   1523 	.area CONST   (CODE)
                                   1524 	.area XINIT   (CODE)
                                   1525 	.area CABS    (ABS,CODE)
                                   1526 
                                   1527 ; Experimental exact instruction outlining.
                                   1528 	.globl _ak820_outline_0002
                                   1529 	.globl _ak820_outline_0006
                                   1530 	.globl _ak820_outline_0007
                                   1531 	.globl _ak820_outline_0008
                                   1532 	.globl _ak820_outline_0013
                                   1533 	.globl _ak820_outline_0016
                                   1534 	.globl _ak820_outline_0017
                                   1535 	.globl _ak820_outline_0018
                                   1536 	.globl _ak820_outline_0032
                                   1537 	.globl _ak820_outline_0033
                                   1538 	.globl _ak820_outline_0034
                                   1539 	.globl _ak820_outline_0035
                                   1540 	.globl _ak820_outline_0038
                                   1541 	.globl _ak820_outline_0041
                                   1542 	.globl _ak820_outline_0051
                                   1543 	.globl _ak820_outline_0058
                                   1544 	.globl _ak820_outline_0063
                                   1545 	.globl _ak820_outline_0064
                                   1546 	.globl _ak820_outline_0065
                                   1547 	.globl _ak820_outline_0066
                                   1548 	.globl _ak820_outline_0075
                                   1549 	.globl _ak820_outline_0077
                                   1550 	.globl _ak820_outline_0080
                                   1551 	.globl _ak820_outline_0081
                                   1552 	.globl _ak820_outline_0094
                                   1553 	.globl _ak820_outline_0097
                                   1554 	.globl _ak820_outline_0103
                                   1555 	.globl _ak820_outline_0108
                                   1556 	.globl _ak820_outline_0109
                                   1557 	.globl _ak820_outline_0119
                                   1558 	.globl _ak820_outline_0121
                                   1559 	.globl _ak820_outline_0123
                                   1560 	.globl _ak820_outline_0124
                                   1561 	.globl _ak820_outline_0128
                                   1562 	.globl _ak820_outline_0136
                                   1563 	.globl _ak820_outline_0144
                                   1564 	.globl _ak820_outline_0147
                                   1565 	.globl _ak820_outline_0150
                                   1566 	.globl _ak820_outline_0151
                                   1567 	.globl _ak820_outline_0162
                                   1568 	.globl _ak820_outline_0173
                                   1569 	.globl _ak820_outline_0186
                                   1570 	.globl _ak820_outline_0189
                                   1571 	.globl _ak820_outline_0191
                                   1572 
                                   1573 	.area CSEG (CODE)
                                   1574 ; function ak820_outline_0007
      004854                       1575 _ak820_outline_0007:
      004854 90 05 BC         [24] 1576 	mov	dptr,#_td_work
      004857 E0               [24] 1577 	movx	a,@dptr
      004858 FE               [12] 1578 	mov	r6,a
      004859 A3               [24] 1579 	inc	dptr
      00485A E0               [24] 1580 	movx	a,@dptr
      00485B FF               [12] 1581 	mov	r7,a
      00485C 74 03            [12] 1582 	mov	a,#0x03
      00485E 2E               [12] 1583 	add	a,r6
      00485F FE               [12] 1584 	mov	r6,a
      004860 E4               [12] 1585 	clr	a
      004861 3F               [12] 1586 	addc	a,r7
      004862 FF               [12] 1587 	mov	r7,a
      004863 8E 82            [24] 1588 	mov	dpl,r6
      004865 8F 83            [24] 1589 	mov	dph,r7
      004867 E0               [24] 1590 	movx	a,@dptr
      004868 22               [24] 1591 	ret
                                   1592 
                                   1593 	.area CSEG (CODE)
                                   1594 ; function ak820_outline_0013
      004869                       1595 _ak820_outline_0013:
      004869 E0               [24] 1596 	movx	a,@dptr
      00486A FE               [12] 1597 	mov	r6,a
      00486B A3               [24] 1598 	inc	dptr
      00486C E0               [24] 1599 	movx	a,@dptr
      00486D FF               [12] 1600 	mov	r7,a
      00486E 74 04            [12] 1601 	mov	a,#0x04
      004870 2E               [12] 1602 	add	a,r6
      004871 FC               [12] 1603 	mov	r4,a
      004872 E4               [12] 1604 	clr	a
      004873 3F               [12] 1605 	addc	a,r7
      004874 FD               [12] 1606 	mov	r5,a
      004875 8C 82            [24] 1607 	mov	dpl,r4
      004877 8D 83            [24] 1608 	mov	dph,r5
      004879 E0               [24] 1609 	movx	a,@dptr
      00487A 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0016
      00487B                       1614 _ak820_outline_0016:
      00487B 8E 82            [24] 1615 	mov	dpl,r6
      00487D 8F 83            [24] 1616 	mov	dph,r7
      00487F A3               [24] 1617 	inc	dptr
      004880 A3               [24] 1618 	inc	dptr
      004881 A3               [24] 1619 	inc	dptr
      004882 E0               [24] 1620 	movx	a,@dptr
      004883 22               [24] 1621 	ret
                                   1622 
                                   1623 	.area CSEG (CODE)
                                   1624 ; function ak820_outline_0032
      004884                       1625 _ak820_outline_0032:
      004884 E0               [24] 1626 	movx	a,@dptr
      004885 FE               [12] 1627 	mov	r6,a
      004886 A3               [24] 1628 	inc	dptr
      004887 E0               [24] 1629 	movx	a,@dptr
      004888 FF               [12] 1630 	mov	r7,a
      004889 90 06 51         [24] 1631 	mov	dptr,#(_td_record+0x0007)
      00488C EE               [12] 1632 	mov	a,r6
      00488D F0               [24] 1633 	movx	@dptr,a
      00488E EF               [12] 1634 	mov	a,r7
      00488F A3               [24] 1635 	inc	dptr
      004890 F0               [24] 1636 	movx	@dptr,a
      004891 22               [24] 1637 	ret
                                   1638 
                                   1639 	.area CSEG (CODE)
                                   1640 ; function ak820_outline_0033
      004892                       1641 _ak820_outline_0033:
      004892 24 CA            [12] 1642 	add	a,#_td_map
      004894 F5 82            [12] 1643 	mov	dpl,a
      004896 E4               [12] 1644 	clr	a
      004897 34 05            [12] 1645 	addc	a,#(_td_map>>8)
      004899 F5 83            [12] 1646 	mov	dph,a
      00489B 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0034
      00489C                       1651 _ak820_outline_0034:
      00489C FA               [12] 1652 	mov	r2,a
      00489D E4               [12] 1653 	clr	a
      00489E 3F               [12] 1654 	addc	a,r7
      00489F FB               [12] 1655 	mov	r3,a
      0048A0 8A 82            [24] 1656 	mov	dpl,r2
      0048A2 8B 83            [24] 1657 	mov	dph,r3
      0048A4 E0               [24] 1658 	movx	a,@dptr
      0048A5 22               [24] 1659 	ret
                                   1660 
                                   1661 	.area CSEG (CODE)
                                   1662 ; function ak820_outline_0038
      0048A6                       1663 _ak820_outline_0038:
      0048A6 E0               [24] 1664 	movx	a,@dptr
      0048A7 F5 F0            [12] 1665 	mov	b,a
      0048A9 A3               [24] 1666 	inc	dptr
      0048AA E0               [24] 1667 	movx	a,@dptr
      0048AB 45 F0            [12] 1668 	orl	a,b
      0048AD 22               [24] 1669 	ret
                                   1670 
                                   1671 	.area CSEG (CODE)
                                   1672 ; function ak820_outline_0041
      0048AE                       1673 _ak820_outline_0041:
      0048AE 8D 82            [24] 1674 	mov	dpl,r5
      0048B0 8E 83            [24] 1675 	mov	dph,r6
      0048B2 A3               [24] 1676 	inc	dptr
      0048B3 A3               [24] 1677 	inc	dptr
      0048B4 A3               [24] 1678 	inc	dptr
      0048B5 22               [24] 1679 	ret
                                   1680 
                                   1681 	.area CSEG (CODE)
                                   1682 ; function ak820_outline_0051
      0048B6                       1683 _ak820_outline_0051:
      0048B6 FC               [12] 1684 	mov	r4,a
      0048B7 8B 82            [24] 1685 	mov	dpl,r3
      0048B9 8C 83            [24] 1686 	mov	dph,r4
      0048BB E0               [24] 1687 	movx	a,@dptr
      0048BC FA               [12] 1688 	mov	r2,a
      0048BD 22               [24] 1689 	ret
                                   1690 
                                   1691 	.area CSEG (CODE)
                                   1692 ; function ak820_outline_0063
      0048BE                       1693 _ak820_outline_0063:
      0048BE 89 82            [24] 1694 	mov	dpl,r1
      0048C0 8A 83            [24] 1695 	mov	dph,r2
      0048C2 E8               [12] 1696 	mov	a,r0
      0048C3 F0               [24] 1697 	movx	@dptr,a
      0048C4 22               [24] 1698 	ret
                                   1699 
                                   1700 	.area CSEG (CODE)
                                   1701 ; function ak820_outline_0065
      0048C5                       1702 _ak820_outline_0065:
      0048C5 EE               [12] 1703 	mov	a,r6
      0048C6 F0               [24] 1704 	movx	@dptr,a
      0048C7 EF               [12] 1705 	mov	a,r7
      0048C8 A3               [24] 1706 	inc	dptr
      0048C9 F0               [24] 1707 	movx	@dptr,a
      0048CA 22               [24] 1708 	ret
                                   1709 
                                   1710 	.area CSEG (CODE)
                                   1711 ; function ak820_outline_0121
      0048CB                       1712 _ak820_outline_0121:
      0048CB 74 02            [12] 1713 	mov	a,#0x02
      0048CD 2E               [12] 1714 	add	a,r6
      0048CE FE               [12] 1715 	mov	r6,a
      0048CF E4               [12] 1716 	clr	a
      0048D0 3F               [12] 1717 	addc	a,r7
      0048D1 FF               [12] 1718 	mov	r7,a
      0048D2 22               [24] 1719 	ret
                                   1720 
                                   1721 	.area CSEG (CODE)
                                   1722 ; function ak820_outline_0144
      0048D3                       1723 _ak820_outline_0144:
      0048D3 E4               [12] 1724 	clr	a
      0048D4 F0               [24] 1725 	movx	@dptr,a
      0048D5 A3               [24] 1726 	inc	dptr
      0048D6 F0               [24] 1727 	movx	@dptr,a
      0048D7 22               [24] 1728 	ret
                                   1729 
                                   1730 	.area CSEG (CODE)
                                   1731 ; function ak820_outline_0147
      0048D8                       1732 _ak820_outline_0147:
      0048D8 F0               [24] 1733 	movx	@dptr,a
      0048D9 90 06 51         [24] 1734 	mov	dptr,#(_td_record+0x0007)
      0048DC E0               [24] 1735 	movx	a,@dptr
      0048DD FE               [12] 1736 	mov	r6,a
      0048DE A3               [24] 1737 	inc	dptr
      0048DF E0               [24] 1738 	movx	a,@dptr
      0048E0 4E               [12] 1739 	orl	a,r6
      0048E1 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0173
      0048E2                       1744 _ak820_outline_0173:
      0048E2 E0               [24] 1745 	movx	a,@dptr
      0048E3 FB               [12] 1746 	mov	r3,a
      0048E4 A3               [24] 1747 	inc	dptr
      0048E5 E0               [24] 1748 	movx	a,@dptr
      0048E6 4B               [12] 1749 	orl	a,r3
      0048E7 22               [24] 1750 	ret
                                   1751 
                                   1752 	.area CSEG (CODE)
                                   1753 ; function ak820_outline_0186
      0048E8                       1754 _ak820_outline_0186:
      0048E8 8C 82            [24] 1755 	mov	dpl,r4
      0048EA 8F 83            [24] 1756 	mov	dph,r7
      0048EC 22               [24] 1757 	ret
                                   1758 
                                   1759 	.area CSEG (CODE)
                                   1760 ; function ak820_outline_0189
      0048ED                       1761 _ak820_outline_0189:
      0048ED F0               [24] 1762 	movx	@dptr,a
      0048EE EB               [12] 1763 	mov	a,r3
      0048EF A3               [24] 1764 	inc	dptr
      0048F0 F0               [24] 1765 	movx	@dptr,a
      0048F1 22               [24] 1766 	ret
