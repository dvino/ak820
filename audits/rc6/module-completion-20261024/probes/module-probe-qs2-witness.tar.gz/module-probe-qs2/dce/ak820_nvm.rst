                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B84                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B84 E5 82            [12]  215 	mov	a,dpl
      003B86 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B89 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B8A 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003B8D 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B90 E0               [24]  221 	movx	a,@dptr
      003B91 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003B94 F0               [24]  223 	movx	@dptr,a
      003B95                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B95 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B97 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B98                        239 _ak820_nvm_diagnostic:
      003B98 12 38 8A         [24]  240 	lcall	_ak820_outline_0108
      003B9B 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B9E 12 38 8F         [24]  242 	lcall	_ak820_outline_0109
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BA1 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BA4 12 38 36         [24]  245 	lcall	_ak820_outline_0054
      003BA7 A2 0B            [12]  246 	mov	c,_storage_failed
      003BA9 E4               [12]  247 	clr	a
      003BAA 33               [12]  248 	rlc	a
      003BAB 12 38 94         [24]  249 	lcall	_ak820_outline_0123
      003BAE 12 43 35         [24]  250 	lcall	_ak820_outline_0062
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BB1 A3               [24]  252 	inc	dptr
      003BB2 A2 09            [12]  253 	mov	c,_page_valid
      003BB4 E4               [12]  254 	clr	a
      003BB5 33               [12]  255 	rlc	a
      003BB6 12 43 09         [24]  256 	lcall	_ak820_outline_0033
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BB9 A2 0A            [12]  258 	mov	c,_page_dirty
      003BBB E4               [12]  259 	clr	a
      003BBC 33               [12]  260 	rlc	a
      003BBD F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BBE 74 03            [12]  263 	mov	a,#0x03
      003BC0 12 43 7D         [24]  264 	lcall	_ak820_outline_0164
      003BC3 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003BC6 E0               [24]  266 	movx	a,@dptr
      003BC7 12 38 99         [24]  267 	lcall	_ak820_outline_0127
      003BCA F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BCB 74 04            [12]  270 	mov	a,#0x04
      003BCD 12 43 7D         [24]  271 	lcall	_ak820_outline_0164
      003BD0 90 05 5D         [24]  272 	mov	dptr,#_cached_page
      003BD3 E0               [24]  273 	movx	a,@dptr
      003BD4 12 38 99         [24]  274 	lcall	_ak820_outline_0127
      003BD7 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BD8 12 42 FF         [24]  277 	lcall	_ak820_outline_0009
      003BDB E4               [12]  278 	clr	a
      003BDC F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BDD 74 06            [12]  281 	mov	a,#0x06
      003BDF 12 43 66         [24]  282 	lcall	_ak820_outline_0139
      003BE2 90 05 5F         [24]  283 	mov	dptr,#_first_failure_stage
      003BE5 12 43 48         [24]  284 	lcall	_ak820_outline_0096
                                    285 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BE8 22               [24]  286 	ret
                                    287 ;------------------------------------------------------------
                                    288 ;Allocation info for local variables in function 'crc_byte'
                                    289 ;------------------------------------------------------------
                                    290 ;value         Allocated with name '_crc_byte_PARM_2'
                                    291 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    292 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    293 ;------------------------------------------------------------
                                    294 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    295 ;	-----------------------------------------
                                    296 ;	 function crc_byte
                                    297 ;	-----------------------------------------
      003BE9                        298 _crc_byte:
      003BE9 12 38 8A         [24]  299 	lcall	_ak820_outline_0108
      003BEC 90 05 64         [24]  300 	mov	dptr,#_crc_byte_crc_10000_25
      003BEF 12 38 8F         [24]  301 	lcall	_ak820_outline_0109
                                    302 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BF2 90 05 63         [24]  303 	mov	dptr,#_crc_byte_PARM_2
      003BF5 E0               [24]  304 	movx	a,@dptr
      003BF6 FF               [12]  305 	mov	r7,a
      003BF7 7E 00            [12]  306 	mov	r6,#0x00
      003BF9 90 05 64         [24]  307 	mov	dptr,#_crc_byte_crc_10000_25
      003BFC E0               [24]  308 	movx	a,@dptr
      003BFD 6E               [12]  309 	xrl	a,r6
      003BFE F0               [24]  310 	movx	@dptr,a
      003BFF A3               [24]  311 	inc	dptr
      003C00 E0               [24]  312 	movx	a,@dptr
      003C01 6F               [12]  313 	xrl	a,r7
      003C02 F0               [24]  314 	movx	@dptr,a
                                    315 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C03 7F 00            [12]  316 	mov	r7,#0x00
      003C05                        317 00102$:
                                    318 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C05 90 05 64         [24]  319 	mov	dptr,#_crc_byte_crc_10000_25
      003C08 12 38 59         [24]  320 	lcall	_ak820_outline_0079
      003C0B 30 E7 0E         [24]  321 	jnb	acc.7,00106$
      003C0E ED               [12]  322 	mov	a,r5
      003C0F 2D               [12]  323 	add	a,r5
      003C10 FB               [12]  324 	mov	r3,a
      003C11 EE               [12]  325 	mov	a,r6
      003C12 33               [12]  326 	rlc	a
      003C13 FC               [12]  327 	mov	r4,a
      003C14 63 03 21         [24]  328 	xrl	ar3,#0x21
      003C17 63 04 10         [24]  329 	xrl	ar4,#0x10
      003C1A 80 06            [24]  330 	sjmp	00107$
      003C1C                        331 00106$:
      003C1C ED               [12]  332 	mov	a,r5
      003C1D 2D               [12]  333 	add	a,r5
      003C1E FB               [12]  334 	mov	r3,a
      003C1F EE               [12]  335 	mov	a,r6
      003C20 33               [12]  336 	rlc	a
      003C21 FC               [12]  337 	mov	r4,a
      003C22                        338 00107$:
      003C22 90 05 64         [24]  339 	mov	dptr,#_crc_byte_crc_10000_25
      003C25 12 38 65         [24]  340 	lcall	_ak820_outline_0092
                                    341 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C28 0F               [12]  342 	inc	r7
      003C29 BF 08 D9         [24]  343 	cjne	r7,#0x08,00102$
                                    344 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C2C 12 33 FC         [24]  345 	lcall	_ak820_outline_0126
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C2F 22               [24]  347 	ret
                                    348 ;------------------------------------------------------------
                                    349 ;Allocation info for local variables in function 'page_crc'
                                    350 ;------------------------------------------------------------
                                    351 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    352 ;i             Allocated with name '_page_crc_i_10000_30'
                                    353 ;------------------------------------------------------------
                                    354 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    355 ;	-----------------------------------------
                                    356 ;	 function page_crc
                                    357 ;	-----------------------------------------
      003C30                        358 _page_crc:
                                    359 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C30 90 05 66         [24]  360 	mov	dptr,#_page_crc_crc_10000_30
      003C33 74 FF            [12]  361 	mov	a,#0xff
      003C35 F0               [24]  362 	movx	@dptr,a
      003C36 A3               [24]  363 	inc	dptr
      003C37 F0               [24]  364 	movx	@dptr,a
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C38 7F 00            [12]  366 	mov	r7,#0x00
      003C3A                        367 00102$:
      003C3A 90 05 66         [24]  368 	mov	dptr,#_page_crc_crc_10000_30
      003C3D 12 38 59         [24]  369 	lcall	_ak820_outline_0079
      003C40 12 43 55         [24]  370 	lcall	_ak820_outline_0112
      003C43 90 05 63         [24]  371 	mov	dptr,#_crc_byte_PARM_2
      003C46 F0               [24]  372 	movx	@dptr,a
      003C47 12 38 A3         [24]  373 	lcall	_ak820_outline_0137
      003C4A C0 07            [24]  374 	push	ar7
      003C4C 12 3B E9         [24]  375 	lcall	_crc_byte
      003C4F 12 43 8D         [24]  376 	lcall	_ak820_outline_0193
      003C52 D0 07            [24]  377 	pop	ar7
      003C54 90 05 66         [24]  378 	mov	dptr,#_page_crc_crc_10000_30
      003C57 12 43 6C         [24]  379 	lcall	_ak820_outline_0141
      003C5A 0F               [12]  380 	inc	r7
      003C5B BF 40 DC         [24]  381 	cjne	r7,#0x40,00102$
                                    382 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C5E 12 38 A3         [24]  383 	lcall	_ak820_outline_0137
                                    384 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C61 22               [24]  385 	ret
                                    386 ;------------------------------------------------------------
                                    387 ;Allocation info for local variables in function 'write_page'
                                    388 ;------------------------------------------------------------
                                    389 ;address       Allocated with name '_write_page_address_10000_32'
                                    390 ;i             Allocated with name '_write_page_i_10000_33'
                                    391 ;------------------------------------------------------------
                                    392 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    393 ;	-----------------------------------------
                                    394 ;	 function write_page
                                    395 ;	-----------------------------------------
      003C62                        396 _write_page:
      003C62 12 38 8A         [24]  397 	lcall	_ak820_outline_0108
      003C65 90 05 68         [24]  398 	mov	dptr,#_write_page_address_10000_32
      003C68 12 38 8F         [24]  399 	lcall	_ak820_outline_0109
                                    400 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C6B 90 05 68         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C6E 12 37 E9         [24]  402 	lcall	_ak820_outline_0005
      003C71 C0 07            [24]  403 	push	ar7
      003C73 C0 06            [24]  404 	push	ar6
      003C75 12 39 FD         [24]  405 	lcall	_ak820_flash_erase
      003C78 E5 82            [12]  406 	mov	a, dpl
      003C7A D0 06            [24]  407 	pop	ar6
      003C7C D0 07            [24]  408 	pop	ar7
      003C7E 70 03            [24]  409 	jnz	00102$
      003C80 F5 82            [12]  410 	mov	dpl,a
      003C82 22               [24]  411 	ret
      003C83                        412 00102$:
                                    413 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C83 90 04 F9         [24]  414 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C86 74 1D            [12]  415 	mov	a,#_page_data
      003C88 F0               [24]  416 	movx	@dptr,a
      003C89 74 05            [12]  417 	mov	a,#(_page_data >> 8)
      003C8B A3               [24]  418 	inc	dptr
      003C8C 12 43 35         [24]  419 	lcall	_ak820_outline_0062
      003C8F 12 3B 11         [24]  420 	lcall	_ak820_flash_program_page
      003C92 E5 82            [12]  421 	mov	a, dpl
      003C94 70 03            [24]  422 	jnz	00120$
      003C96 F5 82            [12]  423 	mov	dpl,a
                                    424 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C98 22               [24]  425 	ret
      003C99                        426 00120$:
      003C99 7F 00            [12]  427 	mov	r7,#0x00
      003C9B                        428 00108$:
                                    429 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C9B 8F 05            [24]  430 	mov	ar5,r7
      003C9D 7E 00            [12]  431 	mov	r6,#0x00
      003C9F 90 05 68         [24]  432 	mov	dptr,#_write_page_address_10000_32
      003CA2 12 38 72         [24]  433 	lcall	_ak820_outline_0102
      003CA5 ED               [12]  434 	mov	a,r5
      003CA6 2B               [12]  435 	add	a, r3
      003CA7 FB               [12]  436 	mov	r3,a
      003CA8 EE               [12]  437 	mov	a,r6
      003CA9 3C               [12]  438 	addc	a, r4
      003CAA FC               [12]  439 	mov	r4,a
      003CAB 12 33 FC         [24]  440 	lcall	_ak820_outline_0126
      003CAE 12 38 F0         [24]  441 	lcall	_ak820_flash_read
      003CB1 AE 82            [24]  442 	mov	r6, dpl
      003CB3 12 43 55         [24]  443 	lcall	_ak820_outline_0112
      003CB6 FD               [12]  444 	mov	r5,a
      003CB7 EE               [12]  445 	mov	a,r6
      003CB8 B5 05 02         [24]  446 	cjne	a,ar5,00149$
      003CBB 80 04            [24]  447 	sjmp	00109$
      003CBD                        448 00149$:
      003CBD 75 82 00         [24]  449 	mov	dpl, #0x00
      003CC0 22               [24]  450 	ret
      003CC1                        451 00109$:
                                    452 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CC1 0F               [12]  453 	inc	r7
      003CC2 BF 40 D6         [24]  454 	cjne	r7,#0x40,00108$
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CC5 75 82 01         [24]  456 	mov	dpl, #0x01
                                    457 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CC8 22               [24]  458 	ret
                                    459 ;------------------------------------------------------------
                                    460 ;Allocation info for local variables in function 'journal_header_valid'
                                    461 ;------------------------------------------------------------
                                    462 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    463 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    464 ;------------------------------------------------------------
                                    465 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    466 ;	-----------------------------------------
                                    467 ;	 function journal_header_valid
                                    468 ;	-----------------------------------------
      003CC9                        469 _journal_header_valid:
      003CC9 12 38 8A         [24]  470 	lcall	_ak820_outline_0108
      003CCC 90 05 6A         [24]  471 	mov	dptr,#_journal_header_valid_header_10000_39
      003CCF 12 38 8F         [24]  472 	lcall	_ak820_outline_0109
                                    473 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CD2 90 05 6A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003CD5 12 37 E9         [24]  475 	lcall	_ak820_outline_0005
      003CD8 E0               [24]  476 	movx	a,@dptr
      003CD9 FD               [12]  477 	mov	r5,a
      003CDA BD A5 02         [24]  478 	cjne	r5,#0xa5,00138$
      003CDD 80 04            [24]  479 	sjmp	00116$
      003CDF                        480 00138$:
      003CDF 75 82 00         [24]  481 	mov	dpl, #0x00
                                    482 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CE2 22               [24]  483 	ret
      003CE3                        484 00116$:
      003CE3 7D 01            [12]  485 	mov	r5,#0x01
      003CE5                        486 00106$:
                                    487 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CE5 ED               [12]  488 	mov	a,r5
      003CE6 12 38 26         [24]  489 	lcall	_ak820_outline_0020
      003CE9 E0               [24]  490 	movx	a,@dptr
      003CEA FC               [12]  491 	mov	r4,a
      003CEB 8D 02            [24]  492 	mov	ar2,r5
      003CED 7B 00            [12]  493 	mov	r3,#0x00
      003CEF 74 04            [12]  494 	mov	a,#0x04
      003CF1 2A               [12]  495 	add	a, r2
      003CF2 FA               [12]  496 	mov	r2,a
      003CF3 E4               [12]  497 	clr	a
      003CF4 3B               [12]  498 	addc	a, r3
      003CF5 FB               [12]  499 	mov	r3,a
      003CF6 EA               [12]  500 	mov	a,r2
      003CF7 2E               [12]  501 	add	a, r6
      003CF8 F5 82            [12]  502 	mov	dpl,a
      003CFA EB               [12]  503 	mov	a,r3
      003CFB 3F               [12]  504 	addc	a, r7
      003CFC F5 83            [12]  505 	mov	dph,a
      003CFE E0               [24]  506 	movx	a,@dptr
      003CFF 62 04            [12]  507 	xrl	ar4,a
      003D01 BC FF 02         [24]  508 	cjne	r4,#0xff,00139$
      003D04 80 04            [24]  509 	sjmp	00107$
      003D06                        510 00139$:
      003D06 75 82 00         [24]  511 	mov	dpl, #0x00
      003D09 22               [24]  512 	ret
      003D0A                        513 00107$:
                                    514 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D0A 0D               [12]  515 	inc	r5
      003D0B BD 05 D7         [24]  516 	cjne	r5,#0x05,00106$
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D0E 75 82 01         [24]  518 	mov	dpl, #0x01
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D11 22               [24]  520 	ret
                                    521 ;------------------------------------------------------------
                                    522 ;Allocation info for local variables in function 'recover_journal'
                                    523 ;------------------------------------------------------------
                                    524 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    525 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    526 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    527 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    528 ;------------------------------------------------------------
                                    529 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    530 ;	-----------------------------------------
                                    531 ;	 function recover_journal
                                    532 ;	-----------------------------------------
      003D12                        533 _recover_journal:
                                    534 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D12 7F 00            [12]  535 	mov	r7,#0x00
      003D14                        536 00115$:
      003D14 EF               [12]  537 	mov	a,r7
      003D15 24 6C            [12]  538 	add	a, #_recover_journal_header_10000_46
      003D17 FD               [12]  539 	mov	r5,a
      003D18 E4               [12]  540 	clr	a
      003D19 34 05            [12]  541 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D1B FE               [12]  542 	mov	r6,a
      003D1C 8F 04            [24]  543 	mov	ar4,r7
      003D1E 7B 00            [12]  544 	mov	r3,#0x00
      003D20 74 40            [12]  545 	mov	a,#0x40
      003D22 2C               [12]  546 	add	a, r4
      003D23 FC               [12]  547 	mov	r4,a
      003D24 74 EF            [12]  548 	mov	a,#0xef
      003D26 3B               [12]  549 	addc	a, r3
      003D27 FB               [12]  550 	mov	r3,a
      003D28 12 43 83         [24]  551 	lcall	_ak820_outline_0186
      003D2B 12 38 F0         [24]  552 	lcall	_ak820_flash_read
      003D2E AC 82            [24]  553 	mov	r4, dpl
      003D30 12 43 3B         [24]  554 	lcall	_ak820_outline_0067
      003D33 0F               [12]  555 	inc	r7
      003D34 BF 09 DD         [24]  556 	cjne	r7,#0x09,00115$
                                    557 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D37 90 05 6C         [24]  558 	mov	dptr,#_recover_journal_header_10000_46
      003D3A 12 3C C9         [24]  559 	lcall	_journal_header_valid
      003D3D E5 82            [12]  560 	mov	a, dpl
      003D3F 70 01            [24]  561 	jnz	00103$
      003D41 22               [24]  562 	ret
      003D42                        563 00103$:
                                    564 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D42 90 05 6D         [24]  565 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D45 E0               [24]  566 	movx	a,@dptr
      003D46 FF               [12]  567 	mov	r7,a
      003D47 7E 00            [12]  568 	mov	r6,#0x00
      003D49 90 05 6E         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D4C E0               [24]  570 	movx	a,@dptr
      003D4D FC               [12]  571 	mov	r4,a
      003D4E E4               [12]  572 	clr	a
      003D4F 42 07            [12]  573 	orl	ar7,a
      003D51 EC               [12]  574 	mov	a,r4
      003D52 42 06            [12]  575 	orl	ar6,a
                                    576 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D54 90 05 6F         [24]  577 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D57 E0               [24]  578 	movx	a,@dptr
      003D58 FD               [12]  579 	mov	r5,a
      003D59 7C 00            [12]  580 	mov	r4,#0x00
      003D5B 90 05 70         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D5E E0               [24]  582 	movx	a,@dptr
      003D5F FA               [12]  583 	mov	r2,a
      003D60 E4               [12]  584 	clr	a
      003D61 12 43 72         [24]  585 	lcall	_ak820_outline_0147
                                    586 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D64 C3               [12]  587 	clr	c
      003D65 EF               [12]  588 	mov	a,r7
      003D66 94 A0            [12]  589 	subb	a,#0xa0
      003D68 EE               [12]  590 	mov	a,r6
      003D69 94 00            [12]  591 	subb	a,#0x00
      003D6B 40 06            [24]  592 	jc	00134$
                                    593 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D6D 75 82 01         [24]  594 	mov	dpl, #0x01
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D70 02 3B 84         [24]  596 	ljmp	_nvm_fail
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D73                        598 00134$:
      003D73 7B 00            [12]  599 	mov	r3,#0x00
      003D75                        600 00117$:
      003D75 C0 05            [24]  601 	push	ar5
      003D77 C0 04            [24]  602 	push	ar4
      003D79 EB               [12]  603 	mov	a,r3
      003D7A 24 1D            [12]  604 	add	a, #_page_data
      003D7C F9               [12]  605 	mov	r1,a
      003D7D E4               [12]  606 	clr	a
      003D7E 34 05            [12]  607 	addc	a, #(_page_data >> 8)
      003D80 FA               [12]  608 	mov	r2,a
      003D81 8B 00            [24]  609 	mov	ar0,r3
      003D83 7D 00            [12]  610 	mov	r5,#0x00
      003D85 74 EF            [12]  611 	mov	a,#0xef
      003D87 2D               [12]  612 	add	a, r5
      003D88 FD               [12]  613 	mov	r5,a
      003D89 88 82            [24]  614 	mov	dpl, r0
      003D8B 8D 83            [24]  615 	mov	dph, r5
      003D8D 12 38 F0         [24]  616 	lcall	_ak820_flash_read
      003D90 AD 82            [24]  617 	mov	r5, dpl
      003D92 89 82            [24]  618 	mov	dpl,r1
      003D94 8A 83            [24]  619 	mov	dph,r2
      003D96 ED               [12]  620 	mov	a,r5
      003D97 F0               [24]  621 	movx	@dptr,a
      003D98 0B               [12]  622 	inc	r3
      003D99 BB 40 02         [24]  623 	cjne	r3,#0x40,00190$
      003D9C 80 06            [24]  624 	sjmp	00191$
      003D9E                        625 00190$:
      003D9E D0 04            [24]  626 	pop	ar4
      003DA0 D0 05            [24]  627 	pop	ar5
      003DA2 80 D1            [24]  628 	sjmp	00117$
      003DA4                        629 00191$:
      003DA4 D0 04            [24]  630 	pop	ar4
      003DA6 D0 05            [24]  631 	pop	ar5
                                    632 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DA8 C0 07            [24]  633 	push	ar7
      003DAA C0 06            [24]  634 	push	ar6
      003DAC C0 05            [24]  635 	push	ar5
      003DAE C0 04            [24]  636 	push	ar4
      003DB0 12 3C 30         [24]  637 	lcall	_page_crc
      003DB3 AA 82            [24]  638 	mov	r2, dpl
      003DB5 AB 83            [24]  639 	mov	r3, dph
      003DB7 D0 04            [24]  640 	pop	ar4
      003DB9 D0 05            [24]  641 	pop	ar5
      003DBB D0 06            [24]  642 	pop	ar6
      003DBD D0 07            [24]  643 	pop	ar7
      003DBF EA               [12]  644 	mov	a,r2
      003DC0 B5 05 06         [24]  645 	cjne	a,ar5,00192$
      003DC3 EB               [12]  646 	mov	a,r3
      003DC4 B5 04 02         [24]  647 	cjne	a,ar4,00192$
      003DC7 80 06            [24]  648 	sjmp	00113$
      003DC9                        649 00192$:
      003DC9 75 82 02         [24]  650 	mov	dpl, #0x02
      003DCC 02 3B 84         [24]  651 	ljmp	_nvm_fail
      003DCF                        652 00113$:
                                    653 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DCF EE               [12]  654 	mov	a,r6
      003DD0 54 03            [12]  655 	anl	a,#0x03
      003DD2 A2 E0            [12]  656 	mov	c,acc.0
      003DD4 CF               [12]  657 	xch	a,r7
      003DD5 13               [12]  658 	rrc	a
      003DD6 CF               [12]  659 	xch	a,r7
      003DD7 13               [12]  660 	rrc	a
      003DD8 A2 E0            [12]  661 	mov	c,acc.0
      003DDA CF               [12]  662 	xch	a,r7
      003DDB 13               [12]  663 	rrc	a
      003DDC CF               [12]  664 	xch	a,r7
      003DDD 13               [12]  665 	rrc	a
      003DDE CF               [12]  666 	xch	a,r7
      003DDF 24 C7            [12]  667 	add	a,#0xc7
      003DE1 FE               [12]  668 	mov	r6,a
      003DE2 12 43 78         [24]  669 	lcall	_ak820_outline_0161
      003DE5 12 3C 62         [24]  670 	lcall	_write_page
      003DE8 E5 82            [12]  671 	mov	a, dpl
      003DEA 70 06            [24]  672 	jnz	00110$
      003DEC 75 82 03         [24]  673 	mov	dpl, #0x03
      003DEF 02 3B 84         [24]  674 	ljmp	_nvm_fail
      003DF2                        675 00110$:
                                    676 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DF2 90 EF 40         [24]  677 	mov	dptr,#0xef40
      003DF5 12 39 FD         [24]  678 	lcall	_ak820_flash_erase
      003DF8 E5 82            [12]  679 	mov	a, dpl
      003DFA 70 06            [24]  680 	jnz	00119$
      003DFC 75 82 04         [24]  681 	mov	dpl, #0x04
                                    682 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DFF 02 3B 84         [24]  683 	ljmp	_nvm_fail
      003E02                        684 00119$:
      003E02 22               [24]  685 	ret
                                    686 ;------------------------------------------------------------
                                    687 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    688 ;------------------------------------------------------------
                                    689 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    690 ;	-----------------------------------------
                                    691 ;	 function eeprom_driver_init
                                    692 ;	-----------------------------------------
      003E03                        693 _eeprom_driver_init:
                                    694 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    695 ;	assignBit
      003E03 C2 0B            [12]  696 	clr	_storage_failed
                                    697 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E05 90 05 5F         [24]  698 	mov	dptr,#_first_failure_stage
      003E08 E4               [12]  699 	clr	a
      003E09 F0               [24]  700 	movx	@dptr,a
                                    701 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    702 ;	assignBit
      003E0A C2 0A            [12]  703 	clr	_page_dirty
                                    704 ;	assignBit
      003E0C C2 09            [12]  705 	clr	_page_valid
                                    706 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E0E 90 05 5E         [24]  707 	mov	dptr,#_batch_depth
      003E11 E4               [12]  708 	clr	a
      003E12 F0               [24]  709 	movx	@dptr,a
                                    710 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E13 12 3D 12         [24]  711 	lcall	_recover_journal
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E16 02 2A B7         [24]  714 	ljmp	_ak820_macro_init
                                    715 ;------------------------------------------------------------
                                    716 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    717 ;------------------------------------------------------------
                                    718 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    719 ;	-----------------------------------------
                                    720 ;	 function ak820_nvm_ok
                                    721 ;	-----------------------------------------
      003E19                        722 _ak820_nvm_ok:
      003E19 A2 0B            [12]  723 	mov	c,_storage_failed
      003E1B B3               [12]  724 	cpl	c
      003E1C 92 0C            [24]  725 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E1E 12 38 B2         [24]  726 	lcall	_ak820_outline_0154
      003E21 22               [24]  727 	ret
                                    728 ;------------------------------------------------------------
                                    729 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    730 ;------------------------------------------------------------
                                    731 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    732 ;	-----------------------------------------
                                    733 ;	 function ak820_nvm_schema_fault
                                    734 ;	-----------------------------------------
      003E22                        735 _ak820_nvm_schema_fault:
      003E22 75 82 10         [24]  736 	mov	dpl, #0x10
      003E25 02 3B 84         [24]  737 	ljmp	_nvm_fail
                                    738 ;------------------------------------------------------------
                                    739 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    740 ;------------------------------------------------------------
                                    741 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    742 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    743 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    744 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    745 ;------------------------------------------------------------
                                    746 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    747 ;	-----------------------------------------
                                    748 ;	 function ak820_nvm_flush
                                    749 ;	-----------------------------------------
      003E28                        750 _ak820_nvm_flush:
                                    751 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E28 30 0A 03         [24]  752 	jnb	_page_dirty,00101$
      003E2B 30 0B 01         [24]  753 	jnb	_storage_failed,00102$
      003E2E                        754 00101$:
      003E2E 22               [24]  755 	ret
      003E2F                        756 00102$:
                                    757 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E2F 12 3C 30         [24]  758 	lcall	_page_crc
      003E32 12 43 61         [24]  759 	lcall	_ak820_outline_0136
                                    760 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E35 90 05 75         [24]  761 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E38 74 A5            [12]  762 	mov	a,#0xa5
      003E3A F0               [24]  763 	movx	@dptr,a
                                    764 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E3B 90 05 5D         [24]  765 	mov	dptr,#_cached_page
      003E3E E0               [24]  766 	movx	a,@dptr
      003E3F 90 05 76         [24]  767 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E42 F0               [24]  768 	movx	@dptr,a
                                    769 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E43 90 05 77         [24]  770 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E46 E4               [12]  771 	clr	a
      003E47 F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E48 8E 05            [24]  774 	mov	ar5,r6
      003E4A 90 05 78         [24]  775 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E4D ED               [12]  776 	mov	a,r5
      003E4E F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E4F 8F 06            [24]  779 	mov	ar6,r7
      003E51 90 05 79         [24]  780 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E54 EE               [12]  781 	mov	a,r6
      003E55 F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E56 7F 01            [12]  784 	mov	r7,#0x01
      003E58                        785 00128$:
      003E58 8F 06            [24]  786 	mov	ar6,r7
      003E5A EE               [12]  787 	mov	a,r6
      003E5B 24 04            [12]  788 	add	a,#0x04
      003E5D FE               [12]  789 	mov	r6,a
      003E5E 33               [12]  790 	rlc	a
      003E5F 95 E0            [12]  791 	subb	a,acc
      003E61 FD               [12]  792 	mov	r5,a
      003E62 EE               [12]  793 	mov	a,r6
      003E63 24 75            [12]  794 	add	a, #_ak820_nvm_flush_header_10000_62
      003E65 FE               [12]  795 	mov	r6,a
      003E66 ED               [12]  796 	mov	a,r5
      003E67 34 05            [12]  797 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E69 FD               [12]  798 	mov	r5,a
      003E6A 12 43 18         [24]  799 	lcall	_ak820_outline_0044
      003E6D FC               [12]  800 	mov	r4,a
      003E6E 63 04 FF         [24]  801 	xrl	ar4,#0xff
      003E71 8E 82            [24]  802 	mov	dpl,r6
      003E73 8D 83            [24]  803 	mov	dph,r5
      003E75 EC               [12]  804 	mov	a,r4
      003E76 F0               [24]  805 	movx	@dptr,a
      003E77 0F               [12]  806 	inc	r7
      003E78 BF 05 DD         [24]  807 	cjne	r7,#0x05,00128$
                                    808 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E7B 90 05 7E         [24]  809 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E7E 74 05            [12]  810 	mov	a,#0x05
      003E80 F0               [24]  811 	movx	@dptr,a
                                    812 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E81 90 EF 40         [24]  813 	mov	dptr,#0xef40
      003E84 12 39 FD         [24]  814 	lcall	_ak820_flash_erase
      003E87 E5 82            [12]  815 	mov	a, dpl
      003E89 70 03            [24]  816 	jnz	00269$
      003E8B 02 3F 71         [24]  817 	ljmp	00127$
      003E8E                        818 00269$:
                                    819 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E8E 90 05 7E         [24]  820 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E91 74 06            [12]  821 	mov	a,#0x06
      003E93 F0               [24]  822 	movx	@dptr,a
                                    823 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E94 7F 00            [12]  824 	mov	r7,#0x00
      003E96                        825 00130$:
                                    826 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E96 12 43 24         [24]  827 	lcall	_ak820_outline_0055
      003E99 12 38 F0         [24]  828 	lcall	_ak820_flash_read
      003E9C E5 82            [12]  829 	mov	a, dpl
      003E9E 60 03            [24]  830 	jz	00270$
      003EA0 02 3F 71         [24]  831 	ljmp	00127$
      003EA3                        832 00270$:
                                    833 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EA3 0F               [12]  834 	inc	r7
      003EA4 BF 40 EF         [24]  835 	cjne	r7,#0x40,00130$
                                    836 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003EA7 90 05 7E         [24]  837 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EAA 74 07            [12]  838 	mov	a,#0x07
      003EAC F0               [24]  839 	movx	@dptr,a
                                    840 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EAD 90 EF 00         [24]  841 	mov	dptr,#0xef00
      003EB0 12 3C 62         [24]  842 	lcall	_write_page
      003EB3 E5 82            [12]  843 	mov	a, dpl
      003EB5 70 03            [24]  844 	jnz	00273$
      003EB7 02 3F 71         [24]  845 	ljmp	00127$
      003EBA                        846 00273$:
                                    847 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EBA 90 05 7E         [24]  848 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EBD 74 08            [12]  849 	mov	a,#0x08
      003EBF F0               [24]  850 	movx	@dptr,a
                                    851 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EC0 7F 01            [12]  852 	mov	r7,#0x01
      003EC2                        853 00132$:
                                    854 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EC2 12 43 18         [24]  855 	lcall	_ak820_outline_0044
      003EC5 FE               [12]  856 	mov	r6,a
      003EC6 60 22            [24]  857 	jz	00133$
      003EC8 8F 05            [24]  858 	mov	ar5,r7
      003ECA 7C 00            [12]  859 	mov	r4,#0x00
      003ECC 74 40            [12]  860 	mov	a,#0x40
      003ECE 2D               [12]  861 	add	a, r5
      003ECF FD               [12]  862 	mov	r5,a
      003ED0 74 EF            [12]  863 	mov	a,#0xef
      003ED2 3C               [12]  864 	addc	a, r4
      003ED3 FC               [12]  865 	mov	r4,a
      003ED4 90 04 F6         [24]  866 	mov	dptr,#_ak820_flash_program_PARM_2
      003ED7 EE               [12]  867 	mov	a,r6
      003ED8 F0               [24]  868 	movx	@dptr,a
      003ED9 12 43 88         [24]  869 	lcall	_ak820_outline_0187
      003EDC C0 07            [24]  870 	push	ar7
      003EDE 12 3A 5D         [24]  871 	lcall	_ak820_flash_program
      003EE1 E5 82            [12]  872 	mov	a, dpl
      003EE3 D0 07            [24]  873 	pop	ar7
      003EE5 70 03            [24]  874 	jnz	00275$
      003EE7 02 3F 71         [24]  875 	ljmp	00127$
      003EEA                        876 00275$:
      003EEA                        877 00133$:
                                    878 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EEA 0F               [12]  879 	inc	r7
      003EEB BF 09 D4         [24]  880 	cjne	r7,#0x09,00132$
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EEE 90 05 7E         [24]  882 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF1 74 09            [12]  883 	mov	a,#0x09
      003EF3 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EF4 7F 01            [12]  886 	mov	r7,#0x01
      003EF6                        887 00134$:
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EF6 12 43 24         [24]  889 	lcall	_ak820_outline_0055
      003EF9 12 38 F0         [24]  890 	lcall	_ak820_flash_read
      003EFC AE 82            [24]  891 	mov	r6, dpl
      003EFE 12 43 18         [24]  892 	lcall	_ak820_outline_0044
      003F01 FD               [12]  893 	mov	r5,a
      003F02 EE               [12]  894 	mov	a,r6
      003F03 B5 05 6B         [24]  895 	cjne	a,ar5,00127$
                                    896 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F06 0F               [12]  897 	inc	r7
      003F07 BF 09 EC         [24]  898 	cjne	r7,#0x09,00134$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F0A 90 05 7E         [24]  900 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F0D 74 0A            [12]  901 	mov	a,#0x0a
      003F0F F0               [24]  902 	movx	@dptr,a
                                    903 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F10 90 05 75         [24]  904 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F13 E0               [24]  905 	movx	a,@dptr
      003F14 90 04 F6         [24]  906 	mov	dptr,#_ak820_flash_program_PARM_2
      003F17 F0               [24]  907 	movx	@dptr,a
      003F18 90 EF 40         [24]  908 	mov	dptr,#0xef40
      003F1B 12 3A 5D         [24]  909 	lcall	_ak820_flash_program
      003F1E E5 82            [12]  910 	mov	a, dpl
      003F20 60 4F            [24]  911 	jz	00127$
                                    912 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F22 90 05 7E         [24]  913 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F25 74 0B            [12]  914 	mov	a,#0x0b
      003F27 F0               [24]  915 	movx	@dptr,a
                                    916 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F28 90 EF 40         [24]  917 	mov	dptr,#0xef40
      003F2B 12 38 F0         [24]  918 	lcall	_ak820_flash_read
      003F2E AF 82            [24]  919 	mov	r7, dpl
      003F30 90 05 75         [24]  920 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F33 E0               [24]  921 	movx	a,@dptr
      003F34 FE               [12]  922 	mov	r6,a
      003F35 EF               [12]  923 	mov	a,r7
      003F36 B5 06 38         [24]  924 	cjne	a,ar6,00127$
                                    925 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F39 90 05 7E         [24]  926 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F3C 74 0C            [12]  927 	mov	a,#0x0c
      003F3E F0               [24]  928 	movx	@dptr,a
                                    929 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F3F 90 05 5D         [24]  930 	mov	dptr,#_cached_page
      003F42 E0               [24]  931 	movx	a,@dptr
      003F43 FE               [12]  932 	mov	r6,a
      003F44 E4               [12]  933 	clr	a
      003F45 C3               [12]  934 	clr	c
      003F46 CE               [12]  935 	xch	a,r6
      003F47 13               [12]  936 	rrc	a
      003F48 CE               [12]  937 	xch	a,r6
      003F49 13               [12]  938 	rrc	a
      003F4A A2 E0            [12]  939 	mov	c,acc.0
      003F4C CE               [12]  940 	xch	a,r6
      003F4D 13               [12]  941 	rrc	a
      003F4E CE               [12]  942 	xch	a,r6
      003F4F 13               [12]  943 	rrc	a
      003F50 CE               [12]  944 	xch	a,r6
      003F51 24 C7            [12]  945 	add	a,#0xc7
      003F53 FF               [12]  946 	mov	r7,a
      003F54 12 38 94         [24]  947 	lcall	_ak820_outline_0123
      003F57 12 3C 62         [24]  948 	lcall	_write_page
      003F5A E5 82            [12]  949 	mov	a, dpl
      003F5C 60 13            [24]  950 	jz	00127$
                                    951 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F5E 90 05 7E         [24]  952 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F61 74 0D            [12]  953 	mov	a,#0x0d
      003F63 F0               [24]  954 	movx	@dptr,a
                                    955 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F64 90 EF 40         [24]  956 	mov	dptr,#0xef40
      003F67 12 39 FD         [24]  957 	lcall	_ak820_flash_erase
      003F6A E5 82            [12]  958 	mov	a, dpl
      003F6C 60 03            [24]  959 	jz	00127$
                                    960 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    961 ;	assignBit
      003F6E C2 0A            [12]  962 	clr	_page_dirty
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F70 22               [24]  965 	ret
      003F71                        966 00127$:
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F71 90 05 7E         [24]  968 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F74 E0               [24]  969 	movx	a,@dptr
      003F75 F5 82            [12]  970 	mov	dpl,a
                                    971 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F77 02 3B 84         [24]  972 	ljmp	_nvm_fail
                                    973 ;------------------------------------------------------------
                                    974 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    975 ;------------------------------------------------------------
                                    976 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    977 ;	-----------------------------------------
                                    978 ;	 function ak820_nvm_begin
                                    979 ;	-----------------------------------------
      003F7A                        980 _ak820_nvm_begin:
                                    981 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F7A 90 05 5E         [24]  982 	mov	dptr,#_batch_depth
      003F7D E0               [24]  983 	movx	a,@dptr
      003F7E FF               [12]  984 	mov	r7,a
      003F7F BF FF 06         [24]  985 	cjne	r7,#0xff,00102$
      003F82 75 82 0F         [24]  986 	mov	dpl, #0x0f
      003F85 02 3B 84         [24]  987 	ljmp	_nvm_fail
      003F88                        988 00102$:
                                    989 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F88 90 05 5E         [24]  990 	mov	dptr,#_batch_depth
      003F8B EF               [12]  991 	mov	a,r7
      003F8C 04               [12]  992 	inc	a
      003F8D F0               [24]  993 	movx	@dptr,a
                                    994 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F8E 22               [24]  995 	ret
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    998 ;------------------------------------------------------------
                                    999 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1000 ;	-----------------------------------------
                                   1001 ;	 function ak820_nvm_end
                                   1002 ;	-----------------------------------------
      003F8F                       1003 _ak820_nvm_end:
                                   1004 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F8F 90 05 5E         [24] 1005 	mov	dptr,#_batch_depth
      003F92 E0               [24] 1006 	movx	a,@dptr
      003F93 FF               [12] 1007 	mov	r7,a
      003F94 E0               [24] 1008 	movx	a,@dptr
      003F95 60 06            [24] 1009 	jz	00102$
      003F97 EF               [12] 1010 	mov	a,r7
      003F98 14               [12] 1011 	dec	a
      003F99 90 05 5E         [24] 1012 	mov	dptr,#_batch_depth
      003F9C F0               [24] 1013 	movx	@dptr,a
      003F9D                       1014 00102$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F9D 90 05 5E         [24] 1016 	mov	dptr,#_batch_depth
      003FA0 E0               [24] 1017 	movx	a,@dptr
      003FA1 70 03            [24] 1018 	jnz	00105$
                                   1019 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FA3 02 3E 28         [24] 1020 	ljmp	_ak820_nvm_flush
      003FA6                       1021 00105$:
      003FA6 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'load_page'
                                   1025 ;------------------------------------------------------------
                                   1026 ;page          Allocated with name '_load_page_page_10000_87'
                                   1027 ;i             Allocated with name '_load_page_i_10000_88'
                                   1028 ;------------------------------------------------------------
                                   1029 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1030 ;	-----------------------------------------
                                   1031 ;	 function load_page
                                   1032 ;	-----------------------------------------
      003FA7                       1033 _load_page:
      003FA7 E5 82            [12] 1034 	mov	a,dpl
      003FA9 90 05 7F         [24] 1035 	mov	dptr,#_load_page_page_10000_87
      003FAC F0               [24] 1036 	movx	@dptr,a
                                   1037 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FAD 30 09 17         [24] 1038 	jnb	_page_valid,00102$
      003FB0 90 05 5D         [24] 1039 	mov	dptr,#_cached_page
      003FB3 E0               [24] 1040 	movx	a,@dptr
      003FB4 FF               [12] 1041 	mov	r7,a
      003FB5 90 05 7F         [24] 1042 	mov	dptr,#_load_page_page_10000_87
      003FB8 E0               [24] 1043 	movx	a,@dptr
      003FB9 FE               [12] 1044 	mov	r6,a
      003FBA EF               [12] 1045 	mov	a,r7
      003FBB B5 06 09         [24] 1046 	cjne	a,ar6,00102$
      003FBE A2 0B            [12] 1047 	mov	c,_storage_failed
      003FC0 B3               [12] 1048 	cpl	c
      003FC1 92 0D            [24] 1049 	mov  _load_page_sloc0_1_0,c
      003FC3 12 38 B2         [24] 1050 	lcall	_ak820_outline_0154
      003FC6 22               [24] 1051 	ret
      003FC7                       1052 00102$:
                                   1053 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FC7 12 3E 28         [24] 1054 	lcall	_ak820_nvm_flush
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FCA 30 0B 04         [24] 1056 	jnb	_storage_failed,00119$
      003FCD 75 82 00         [24] 1057 	mov	dpl, #0x00
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FD0 22               [24] 1059 	ret
      003FD1                       1060 00119$:
      003FD1 7F 00            [12] 1061 	mov	r7,#0x00
      003FD3                       1062 00107$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FD3 EF               [12] 1064 	mov	a,r7
      003FD4 24 1D            [12] 1065 	add	a, #_page_data
      003FD6 FD               [12] 1066 	mov	r5,a
      003FD7 E4               [12] 1067 	clr	a
      003FD8 34 05            [12] 1068 	addc	a, #(_page_data >> 8)
      003FDA FE               [12] 1069 	mov	r6,a
      003FDB 90 05 7F         [24] 1070 	mov	dptr,#_load_page_page_10000_87
      003FDE E0               [24] 1071 	movx	a,@dptr
      003FDF FC               [12] 1072 	mov	r4,a
      003FE0 FA               [12] 1073 	mov	r2,a
      003FE1 E4               [12] 1074 	clr	a
      003FE2 C3               [12] 1075 	clr	c
      003FE3 CA               [12] 1076 	xch	a,r2
      003FE4 13               [12] 1077 	rrc	a
      003FE5 CA               [12] 1078 	xch	a,r2
      003FE6 13               [12] 1079 	rrc	a
      003FE7 A2 E0            [12] 1080 	mov	c,acc.0
      003FE9 CA               [12] 1081 	xch	a,r2
      003FEA 13               [12] 1082 	rrc	a
      003FEB CA               [12] 1083 	xch	a,r2
      003FEC 13               [12] 1084 	rrc	a
      003FED CA               [12] 1085 	xch	a,r2
      003FEE 24 C7            [12] 1086 	add	a,#0xc7
      003FF0 FB               [12] 1087 	mov	r3,a
      003FF1 8F 01            [24] 1088 	mov	ar1,r7
      003FF3 89 00            [24] 1089 	mov	ar0,r1
      003FF5 79 00            [12] 1090 	mov	r1,#0x00
      003FF7 E8               [12] 1091 	mov	a,r0
      003FF8 2A               [12] 1092 	add	a, r2
      003FF9 FA               [12] 1093 	mov	r2,a
      003FFA E9               [12] 1094 	mov	a,r1
      003FFB 3B               [12] 1095 	addc	a, r3
      003FFC FB               [12] 1096 	mov	r3,a
      003FFD 12 38 A8         [24] 1097 	lcall	_ak820_outline_0148
      004000 12 38 F0         [24] 1098 	lcall	_ak820_flash_read
      004003 AB 82            [24] 1099 	mov	r3, dpl
      004005 12 38 A3         [24] 1100 	lcall	_ak820_outline_0137
      004008 EB               [12] 1101 	mov	a,r3
      004009 F0               [24] 1102 	movx	@dptr,a
                                   1103 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00400A 0F               [12] 1104 	inc	r7
      00400B BF 40 C5         [24] 1105 	cjne	r7,#0x40,00107$
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00400E 90 05 5D         [24] 1107 	mov	dptr,#_cached_page
      004011 EC               [12] 1108 	mov	a,r4
      004012 F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1111 ;	assignBit
      004013 D2 09            [12] 1112 	setb	_page_valid
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004015 75 82 01         [24] 1114 	mov	dpl, #0x01
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004018 22               [24] 1116 	ret
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'read_offset'
                                   1119 ;------------------------------------------------------------
                                   1120 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function read_offset
                                   1125 ;	-----------------------------------------
      004019                       1126 _read_offset:
      004019 12 38 8A         [24] 1127 	lcall	_ak820_outline_0108
      00401C 90 05 80         [24] 1128 	mov	dptr,#_read_offset_offset_10000_93
      00401F 12 38 8F         [24] 1129 	lcall	_ak820_outline_0109
                                   1130 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004022 90 05 80         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      004025 12 38 36         [24] 1132 	lcall	_ak820_outline_0054
      004028 C3               [12] 1133 	clr	c
      004029 94 28            [12] 1134 	subb	a,#0x28
      00402B 40 04            [24] 1135 	jc	00102$
      00402D 75 82 00         [24] 1136 	mov	dpl, #0x00
      004030 22               [24] 1137 	ret
      004031                       1138 00102$:
                                   1139 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004031 30 09 34         [24] 1140 	jnb	_page_valid,00104$
      004034 8E 04            [24] 1141 	mov	ar4,r6
      004036 EF               [12] 1142 	mov	a,r7
      004037 A2 E7            [12] 1143 	mov	c,acc.7
      004039 CC               [12] 1144 	xch	a,r4
      00403A 33               [12] 1145 	rlc	a
      00403B CC               [12] 1146 	xch	a,r4
      00403C 33               [12] 1147 	rlc	a
      00403D A2 E7            [12] 1148 	mov	c,acc.7
      00403F CC               [12] 1149 	xch	a,r4
      004040 33               [12] 1150 	rlc	a
      004041 CC               [12] 1151 	xch	a,r4
      004042 33               [12] 1152 	rlc	a
      004043 CC               [12] 1153 	xch	a,r4
      004044 54 03            [12] 1154 	anl	a,#0x03
      004046 FD               [12] 1155 	mov	r5,a
      004047 90 05 5D         [24] 1156 	mov	dptr,#_cached_page
      00404A E0               [24] 1157 	movx	a,@dptr
      00404B FA               [12] 1158 	mov	r2,a
      00404C 7B 00            [12] 1159 	mov	r3,#0x00
      00404E EC               [12] 1160 	mov	a,r4
      00404F B5 02 16         [24] 1161 	cjne	a,ar2,00104$
      004052 ED               [12] 1162 	mov	a,r5
      004053 B5 03 12         [24] 1163 	cjne	a,ar3,00104$
                                   1164 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004056 74 3F            [12] 1165 	mov	a,#0x3f
      004058 5E               [12] 1166 	anl	a,r6
      004059 7D 00            [12] 1167 	mov	r5,#0x00
      00405B 24 1D            [12] 1168 	add	a, #_page_data
      00405D F5 82            [12] 1169 	mov	dpl,a
      00405F ED               [12] 1170 	mov	a,r5
      004060 34 05            [12] 1171 	addc	a, #(_page_data >> 8)
      004062 F5 83            [12] 1172 	mov	dph,a
      004064 E0               [24] 1173 	movx	a,@dptr
      004065 F5 82            [12] 1174 	mov	dpl,a
      004067 22               [24] 1175 	ret
      004068                       1176 00104$:
                                   1177 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004068 74 C7            [12] 1178 	mov	a,#0xc7
      00406A 2F               [12] 1179 	add	a, r7
      00406B FF               [12] 1180 	mov	r7,a
      00406C 12 38 94         [24] 1181 	lcall	_ak820_outline_0123
                                   1182 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00406F 02 38 F0         [24] 1183 	ljmp	_ak820_flash_read
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1186 ;------------------------------------------------------------
                                   1187 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function eeprom_read_byte
                                   1192 ;	-----------------------------------------
      004072                       1193 _eeprom_read_byte:
      004072 C0 07            [24] 1194 	push	ar7
      004074 C0 06            [24] 1195 	push	ar6
      004076 12 43 11         [24] 1196 	lcall	_ak820_outline_0037
      004079 90 05 82         [24] 1197 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00407C 12 38 1E         [24] 1198 	lcall	_ak820_outline_0017
                                   1199 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00407F 90 05 82         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004082 12 37 E9         [24] 1201 	lcall	_ak820_outline_0005
      004085 C0 06            [24] 1202 	push	ar6
      004087 C0 05            [24] 1203 	push	ar5
      004089 C0 04            [24] 1204 	push	ar4
      00408B C0 03            [24] 1205 	push	ar3
      00408D C0 02            [24] 1206 	push	ar2
      00408F C0 01            [24] 1207 	push	ar1
      004091 C0 00            [24] 1208 	push	ar0
      004093 12 40 19         [24] 1209 	lcall	_read_offset
      004096 AF 82            [24] 1210 	mov	r7, dpl
      004098 D0 00            [24] 1211 	pop	ar0
      00409A D0 01            [24] 1212 	pop	ar1
      00409C D0 02            [24] 1213 	pop	ar2
      00409E D0 03            [24] 1214 	pop	ar3
      0040A0 D0 04            [24] 1215 	pop	ar4
      0040A2 D0 05            [24] 1216 	pop	ar5
      0040A4 D0 06            [24] 1217 	pop	ar6
      0040A6 8F 82            [24] 1218 	mov	dpl, r7
                                   1219 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040A8 D0 06            [24] 1220 	pop	ar6
      0040AA D0 07            [24] 1221 	pop	ar7
      0040AC 22               [24] 1222 	ret
                                   1223 ;------------------------------------------------------------
                                   1224 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1225 ;------------------------------------------------------------
                                   1226 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1227 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1228 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1229 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1230 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function ak820_eeprom_read_block_xdata
                                   1235 ;	-----------------------------------------
      0040AD                       1236 _ak820_eeprom_read_block_xdata:
      0040AD 12 38 8A         [24] 1237 	lcall	_ak820_outline_0108
      0040B0 90 05 8A         [24] 1238 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040B3 12 38 8F         [24] 1239 	lcall	_ak820_outline_0109
                                   1240 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040B6 90 05 85         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040B9 12 38 36         [24] 1242 	lcall	_ak820_outline_0054
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040BC 90 05 8A         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040BF 12 38 4D         [24] 1245 	lcall	_ak820_outline_0060
      0040C2 90 05 8C         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040C5 12 38 53         [24] 1247 	lcall	_ak820_outline_0073
                                   1248 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040C8 90 05 88         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040CB 12 38 4D         [24] 1250 	lcall	_ak820_outline_0060
      0040CE                       1251 00103$:
      0040CE 8C 02            [24] 1252 	mov	ar2,r4
      0040D0 8D 03            [24] 1253 	mov	ar3,r5
      0040D2 1C               [12] 1254 	dec	r4
      0040D3 BC FF 01         [24] 1255 	cjne	r4,#0xff,00130$
      0040D6 1D               [12] 1256 	dec	r5
      0040D7                       1257 00130$:
      0040D7 EA               [12] 1258 	mov	a,r2
      0040D8 4B               [12] 1259 	orl	a,r3
      0040D9 60 5D            [24] 1260 	jz	00106$
                                   1261 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040DB 8E 02            [24] 1262 	mov	ar2,r6
      0040DD 8F 03            [24] 1263 	mov	ar3,r7
      0040DF 74 D8            [12] 1264 	mov	a,#0x100 - 0x28
      0040E1 2B               [12] 1265 	add	a,r3
      0040E2 50 17            [24] 1266 	jnc	00102$
      0040E4 90 05 8C         [24] 1267 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040E7 12 43 42         [24] 1268 	lcall	_ak820_outline_0086
      0040EA 12 38 A8         [24] 1269 	lcall	_ak820_outline_0148
      0040ED E4               [12] 1270 	clr	a
      0040EE F0               [24] 1271 	movx	@dptr,a
      0040EF 90 05 8C         [24] 1272 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F2 04               [12] 1273 	inc	a
      0040F3 2A               [12] 1274 	add	a, r2
      0040F4 F0               [24] 1275 	movx	@dptr,a
      0040F5 E4               [12] 1276 	clr	a
      0040F6 3B               [12] 1277 	addc	a, r3
      0040F7 A3               [24] 1278 	inc	dptr
      0040F8 F0               [24] 1279 	movx	@dptr,a
      0040F9 80 D3            [24] 1280 	sjmp	00103$
      0040FB                       1281 00102$:
                                   1282 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040FB 90 05 8C         [24] 1283 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040FE 12 43 42         [24] 1284 	lcall	_ak820_outline_0086
      004101 12 38 94         [24] 1285 	lcall	_ak820_outline_0123
      004104 C0 07            [24] 1286 	push	ar7
      004106 C0 06            [24] 1287 	push	ar6
      004108 C0 05            [24] 1288 	push	ar5
      00410A C0 04            [24] 1289 	push	ar4
      00410C C0 03            [24] 1290 	push	ar3
      00410E C0 02            [24] 1291 	push	ar2
      004110 12 40 19         [24] 1292 	lcall	_read_offset
      004113 A9 82            [24] 1293 	mov	r1, dpl
      004115 D0 02            [24] 1294 	pop	ar2
      004117 D0 03            [24] 1295 	pop	ar3
      004119 D0 04            [24] 1296 	pop	ar4
      00411B D0 05            [24] 1297 	pop	ar5
      00411D D0 06            [24] 1298 	pop	ar6
      00411F D0 07            [24] 1299 	pop	ar7
      004121 12 38 A8         [24] 1300 	lcall	_ak820_outline_0148
      004124 E9               [12] 1301 	mov	a,r1
      004125 F0               [24] 1302 	movx	@dptr,a
      004126 90 05 8C         [24] 1303 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004129 74 01            [12] 1304 	mov	a,#0x01
      00412B 2A               [12] 1305 	add	a, r2
      00412C F0               [24] 1306 	movx	@dptr,a
      00412D E4               [12] 1307 	clr	a
      00412E 3B               [12] 1308 	addc	a, r3
      00412F A3               [24] 1309 	inc	dptr
      004130 F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004131 0E               [12] 1312 	inc	r6
      004132 BE 00 99         [24] 1313 	cjne	r6,#0x00,00103$
      004135 0F               [12] 1314 	inc	r7
      004136 80 96            [24] 1315 	sjmp	00103$
      004138                       1316 00106$:
                                   1317 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004138 22               [24] 1318 	ret
                                   1319 ;------------------------------------------------------------
                                   1320 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1321 ;------------------------------------------------------------
                                   1322 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1323 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1324 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1325 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1326 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1327 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1328 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1329 ;------------------------------------------------------------
                                   1330 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1331 ;	-----------------------------------------
                                   1332 ;	 function ak820_eeprom_write_block_xdata
                                   1333 ;	-----------------------------------------
      004139                       1334 _ak820_eeprom_write_block_xdata:
      004139 12 38 8A         [24] 1335 	lcall	_ak820_outline_0108
      00413C 90 05 93         [24] 1336 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00413F 12 38 8F         [24] 1337 	lcall	_ak820_outline_0109
                                   1338 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004142 90 05 8E         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004145 12 38 36         [24] 1340 	lcall	_ak820_outline_0054
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004148 90 05 93         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00414B 12 38 4D         [24] 1343 	lcall	_ak820_outline_0060
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00414E 8E 02            [24] 1345 	mov	ar2,r6
      004150 8F 03            [24] 1346 	mov	ar3,r7
      004152 C3               [12] 1347 	clr	c
      004153 E4               [12] 1348 	clr	a
      004154 9A               [12] 1349 	subb	a,r2
      004155 74 28            [12] 1350 	mov	a,#0x28
      004157 9B               [12] 1351 	subb	a,r3
      004158 40 15            [24] 1352 	jc	00101$
                                   1353 ;	free result
      00415A E4               [12] 1354 	clr	a
      00415B C3               [12] 1355 	clr	c
      00415C 9E               [12] 1356 	subb	a,r6
      00415D FA               [12] 1357 	mov	r2,a
      00415E 74 28            [12] 1358 	mov	a,#0x28
      004160 9F               [12] 1359 	subb	a,r7
      004161 FB               [12] 1360 	mov	r3,a
      004162 90 05 91         [24] 1361 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004165 12 38 84         [24] 1362 	lcall	_ak820_outline_0107
      004168 C3               [12] 1363 	clr	c
      004169 EA               [12] 1364 	mov	a,r2
      00416A 98               [12] 1365 	subb	a,r0
      00416B EB               [12] 1366 	mov	a,r3
      00416C 99               [12] 1367 	subb	a,r1
      00416D 50 06            [24] 1368 	jnc	00125$
                                   1369 ;	free result
      00416F                       1370 00101$:
                                   1371 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00416F 75 82 0E         [24] 1372 	mov	dpl, #0x0e
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004172 02 3B 84         [24] 1374 	ljmp	_nvm_fail
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004175                       1376 00125$:
      004175 90 05 91         [24] 1377 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004178 12 43 42         [24] 1378 	lcall	_ak820_outline_0086
      00417B                       1379 00108$:
      00417B 8A 00            [24] 1380 	mov	ar0,r2
      00417D 8B 01            [24] 1381 	mov	ar1,r3
      00417F 1A               [12] 1382 	dec	r2
      004180 BA FF 01         [24] 1383 	cjne	r2,#0xff,00159$
      004183 1B               [12] 1384 	dec	r3
      004184                       1385 00159$:
      004184 E8               [12] 1386 	mov	a,r0
      004185 49               [12] 1387 	orl	a,r1
      004186 70 03            [24] 1388 	jnz	00160$
      004188 02 42 12         [24] 1389 	ljmp	00110$
      00418B                       1390 00160$:
                                   1391 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00418B C0 02            [24] 1392 	push	ar2
      00418D C0 03            [24] 1393 	push	ar3
      00418F 12 43 4F         [24] 1394 	lcall	_ak820_outline_0097
      004192 F9               [12] 1395 	mov	r1,a
      004193 A3               [24] 1396 	inc	dptr
      004194 12 38 AD         [24] 1397 	lcall	_ak820_outline_0149
                                   1398 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004197 8E 0C            [24] 1399 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004199 8F 0D            [24] 1400 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00419B A8 0C            [24] 1401 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00419D E5 0D            [12] 1402 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00419F A2 E7            [12] 1403 	mov	c,acc.7
      0041A1 C8               [12] 1404 	xch	a,r0
      0041A2 33               [12] 1405 	rlc	a
      0041A3 C8               [12] 1406 	xch	a,r0
      0041A4 33               [12] 1407 	rlc	a
      0041A5 A2 E7            [12] 1408 	mov	c,acc.7
      0041A7 C8               [12] 1409 	xch	a,r0
      0041A8 33               [12] 1410 	rlc	a
      0041A9 C8               [12] 1411 	xch	a,r0
      0041AA 33               [12] 1412 	rlc	a
      0041AB C8               [12] 1413 	xch	a,r0
      0041AC 54 03            [12] 1414 	anl	a,#0x03
      0041AE FB               [12] 1415 	mov	r3,a
      0041AF 88 82            [24] 1416 	mov	dpl, r0
      0041B1 C0 07            [24] 1417 	push	ar7
      0041B3 C0 06            [24] 1418 	push	ar6
      0041B5 C0 05            [24] 1419 	push	ar5
      0041B7 C0 04            [24] 1420 	push	ar4
      0041B9 C0 03            [24] 1421 	push	ar3
      0041BB C0 02            [24] 1422 	push	ar2
      0041BD C0 01            [24] 1423 	push	ar1
      0041BF 12 3F A7         [24] 1424 	lcall	_load_page
      0041C2 E5 82            [12] 1425 	mov	a, dpl
      0041C4 D0 01            [24] 1426 	pop	ar1
      0041C6 D0 02            [24] 1427 	pop	ar2
      0041C8 D0 03            [24] 1428 	pop	ar3
      0041CA D0 04            [24] 1429 	pop	ar4
      0041CC D0 05            [24] 1430 	pop	ar5
      0041CE D0 06            [24] 1431 	pop	ar6
      0041D0 D0 07            [24] 1432 	pop	ar7
      0041D2 D0 03            [24] 1433 	pop	ar3
      0041D4 D0 02            [24] 1434 	pop	ar2
      0041D6 70 01            [24] 1435 	jnz	00105$
      0041D8 22               [24] 1436 	ret
      0041D9                       1437 00105$:
                                   1438 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041D9 C0 06            [24] 1439 	push	ar6
      0041DB C0 07            [24] 1440 	push	ar7
      0041DD 74 3F            [12] 1441 	mov	a,#0x3f
      0041DF 55 0C            [12] 1442 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041E1 7F 00            [12] 1443 	mov	r7,#0x00
      0041E3 24 1D            [12] 1444 	add	a, #_page_data
      0041E5 F5 0C            [12] 1445 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041E7 EF               [12] 1446 	mov	a,r7
      0041E8 34 05            [12] 1447 	addc	a, #(_page_data >> 8)
      0041EA F5 0D            [12] 1448 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041EC 85 0C 82         [24] 1449 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041EF 85 0D 83         [24] 1450 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041F2 E0               [24] 1451 	movx	a,@dptr
      0041F3 B5 01 06         [24] 1452 	cjne	a,ar1,00162$
      0041F6 D0 07            [24] 1453 	pop	ar7
      0041F8 D0 06            [24] 1454 	pop	ar6
      0041FA 80 0E            [24] 1455 	sjmp	00107$
      0041FC                       1456 00162$:
      0041FC D0 07            [24] 1457 	pop	ar7
      0041FE D0 06            [24] 1458 	pop	ar6
                                   1459 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004200 85 0C 82         [24] 1460 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004203 85 0D 83         [24] 1461 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004206 E9               [12] 1462 	mov	a,r1
      004207 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1465 ;	assignBit
      004208 D2 0A            [12] 1466 	setb	_page_dirty
      00420A                       1467 00107$:
                                   1468 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00420A 0E               [12] 1469 	inc	r6
      00420B BE 00 01         [24] 1470 	cjne	r6,#0x00,00163$
      00420E 0F               [12] 1471 	inc	r7
      00420F                       1472 00163$:
      00420F 02 41 7B         [24] 1473 	ljmp	00108$
      004212                       1474 00110$:
                                   1475 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004212 90 05 5E         [24] 1476 	mov	dptr,#_batch_depth
      004215 E0               [24] 1477 	movx	a,@dptr
      004216 70 03            [24] 1478 	jnz	00113$
                                   1479 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004218 02 3E 28         [24] 1480 	ljmp	_ak820_nvm_flush
      00421B                       1481 00113$:
      00421B 22               [24] 1482 	ret
                                   1483 ;------------------------------------------------------------
                                   1484 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1485 ;------------------------------------------------------------
                                   1486 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1487 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1488 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1489 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1490 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1491 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1492 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1493 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1494 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1495 ;------------------------------------------------------------
                                   1496 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1497 ;	-----------------------------------------
                                   1498 ;	 function ak820_eeprom_update_block_xdata
                                   1499 ;	-----------------------------------------
      00421C                       1500 _ak820_eeprom_update_block_xdata:
      00421C 12 38 8A         [24] 1501 	lcall	_ak820_outline_0108
      00421F 90 05 9A         [24] 1502 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004222 12 38 8F         [24] 1503 	lcall	_ak820_outline_0109
                                   1504 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004225 90 05 9A         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004228 12 38 36         [24] 1506 	lcall	_ak820_outline_0054
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00422B 90 05 95         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00422E E0               [24] 1509 	movx	a,@dptr
      00422F F5 12            [12] 1510 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004231 A3               [24] 1511 	inc	dptr
      004232 E0               [24] 1512 	movx	a,@dptr
      004233 F5 13            [12] 1513 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004235 A3               [24] 1514 	inc	dptr
      004236 E0               [24] 1515 	movx	a,@dptr
      004237 F5 14            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004239 A9 12            [24] 1517 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00423B AA 13            [24] 1518 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1519 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00423D E4               [12] 1520 	clr	a
      00423E F5 0E            [12] 1521 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004240 F5 0F            [12] 1522 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004242                       1523 00105$:
      004242 90 05 98         [24] 1524 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004245 E0               [24] 1525 	movx	a,@dptr
      004246 F5 10            [12] 1526 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004248 A3               [24] 1527 	inc	dptr
      004249 E0               [24] 1528 	movx	a,@dptr
      00424A F5 11            [12] 1529 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00424C C3               [12] 1530 	clr	c
      00424D E5 0E            [12] 1531 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00424F 95 10            [12] 1532 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004251 E5 0F            [12] 1533 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004253 95 11            [12] 1534 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004255 50 68            [24] 1535 	jnc	00107$
                                   1536 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004257 89 00            [24] 1537 	mov	ar0,r1
      004259 8A 05            [24] 1538 	mov	ar5,r2
      00425B E5 0E            [12] 1539 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00425D 28               [12] 1540 	add	a, r0
      00425E F8               [12] 1541 	mov	r0,a
      00425F E5 0F            [12] 1542 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004261 3D               [12] 1543 	addc	a, r5
      004262 FD               [12] 1544 	mov	r5,a
      004263 88 82            [24] 1545 	mov	dpl, r0
      004265 8D 83            [24] 1546 	mov	dph, r5
      004267 C0 07            [24] 1547 	push	ar7
      004269 C0 06            [24] 1548 	push	ar6
      00426B C0 02            [24] 1549 	push	ar2
      00426D C0 01            [24] 1550 	push	ar1
      00426F 12 40 19         [24] 1551 	lcall	_read_offset
      004272 AD 82            [24] 1552 	mov	r5, dpl
      004274 D0 01            [24] 1553 	pop	ar1
      004276 D0 02            [24] 1554 	pop	ar2
      004278 D0 06            [24] 1555 	pop	ar6
      00427A D0 07            [24] 1556 	pop	ar7
      00427C E5 0E            [12] 1557 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00427E 2E               [12] 1558 	add	a, r6
      00427F F5 82            [12] 1559 	mov	dpl,a
      004281 E5 0F            [12] 1560 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004283 3F               [12] 1561 	addc	a, r7
      004284 F5 83            [12] 1562 	mov	dph,a
      004286 E0               [24] 1563 	movx	a,@dptr
      004287 FC               [12] 1564 	mov	r4,a
      004288 ED               [12] 1565 	mov	a,r5
      004289 B5 04 02         [24] 1566 	cjne	a,ar4,00131$
      00428C 80 27            [24] 1567 	sjmp	00106$
      00428E                       1568 00131$:
                                   1569 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00428E 90 05 9A         [24] 1570 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004291 E0               [24] 1571 	movx	a,@dptr
      004292 F8               [12] 1572 	mov	r0,a
      004293 A3               [24] 1573 	inc	dptr
      004294 E0               [24] 1574 	movx	a,@dptr
      004295 FD               [12] 1575 	mov	r5,a
      004296 90 05 8E         [24] 1576 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004299 E5 12            [12] 1577 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00429B F0               [24] 1578 	movx	@dptr,a
      00429C E5 13            [12] 1579 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00429E A3               [24] 1580 	inc	dptr
      00429F F0               [24] 1581 	movx	@dptr,a
      0042A0 E5 14            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042A2 A3               [24] 1583 	inc	dptr
      0042A3 F0               [24] 1584 	movx	@dptr,a
      0042A4 90 05 91         [24] 1585 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042A7 E5 10            [12] 1586 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042A9 F0               [24] 1587 	movx	@dptr,a
      0042AA E5 11            [12] 1588 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042AC A3               [24] 1589 	inc	dptr
      0042AD F0               [24] 1590 	movx	@dptr,a
      0042AE 88 82            [24] 1591 	mov	dpl, r0
      0042B0 8D 83            [24] 1592 	mov	dph, r5
                                   1593 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042B2 02 41 39         [24] 1594 	ljmp	_ak820_eeprom_write_block_xdata
      0042B5                       1595 00106$:
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042B5 05 0E            [12] 1597 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042B7 E4               [12] 1598 	clr	a
      0042B8 B5 0E 87         [24] 1599 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042BB 05 0F            [12] 1600 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042BD 80 83            [24] 1601 	sjmp	00105$
      0042BF                       1602 00107$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042BF 22               [24] 1604 	ret
                                   1605 ;------------------------------------------------------------
                                   1606 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1607 ;------------------------------------------------------------
                                   1608 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1609 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1610 ;------------------------------------------------------------
                                   1611 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1612 ;	-----------------------------------------
                                   1613 ;	 function eeprom_driver_erase
                                   1614 ;	-----------------------------------------
      0042C0                       1615 _eeprom_driver_erase:
                                   1616 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042C0 12 3E 28         [24] 1617 	lcall	_ak820_nvm_flush
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042C3 7F 00            [12] 1619 	mov	r7,#0x00
      0042C5                       1620 00111$:
      0042C5 BF A0 01         [24] 1621 	cjne	r7,#0xa0,00165$
      0042C8 22               [24] 1622 	ret
      0042C9                       1623 00165$:
      0042C9 20 0B 32         [24] 1624 	jb	_storage_failed,00113$
                                   1625 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042CC 8F 82            [24] 1626 	mov	dpl, r7
      0042CE C0 07            [24] 1627 	push	ar7
      0042D0 12 3F A7         [24] 1628 	lcall	_load_page
      0042D3 E5 82            [12] 1629 	mov	a, dpl
      0042D5 D0 07            [24] 1630 	pop	ar7
      0042D7 70 01            [24] 1631 	jnz	00126$
                                   1632 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042D9 22               [24] 1633 	ret
      0042DA                       1634 00126$:
      0042DA 7E 00            [12] 1635 	mov	r6,#0x00
      0042DC                       1636 00107$:
                                   1637 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042DC EE               [12] 1638 	mov	a,r6
      0042DD 24 1D            [12] 1639 	add	a, #_page_data
      0042DF FC               [12] 1640 	mov	r4,a
      0042E0 E4               [12] 1641 	clr	a
      0042E1 34 05            [12] 1642 	addc	a, #(_page_data >> 8)
      0042E3 FD               [12] 1643 	mov	r5,a
      0042E4 12 43 4F         [24] 1644 	lcall	_ak820_outline_0097
      0042E7 60 07            [24] 1645 	jz	00108$
      0042E9 12 38 99         [24] 1646 	lcall	_ak820_outline_0127
      0042EC E4               [12] 1647 	clr	a
      0042ED F0               [24] 1648 	movx	@dptr,a
                                   1649 ;	assignBit
      0042EE D2 0A            [12] 1650 	setb	_page_dirty
      0042F0                       1651 00108$:
                                   1652 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042F0 0E               [12] 1653 	inc	r6
      0042F1 BE 40 E8         [24] 1654 	cjne	r6,#0x40,00107$
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042F4 C0 07            [24] 1656 	push	ar7
      0042F6 12 3E 28         [24] 1657 	lcall	_ak820_nvm_flush
      0042F9 D0 07            [24] 1658 	pop	ar7
                                   1659 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042FB 0F               [12] 1660 	inc	r7
      0042FC 80 C7            [24] 1661 	sjmp	00111$
      0042FE                       1662 00113$:
                                   1663 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042FE 22               [24] 1664 	ret
                                   1665 	.area CSEG    (CODE)
                                   1666 	.area CONST   (CODE)
                                   1667 	.area XINIT   (CODE)
                                   1668 	.area CABS    (ABS,CODE)
                                   1669 
                                   1670 ; Experimental exact instruction outlining.
                                   1671 	.globl _ak820_outline_0005
                                   1672 	.globl _ak820_outline_0009
                                   1673 	.globl _ak820_outline_0017
                                   1674 	.globl _ak820_outline_0020
                                   1675 	.globl _ak820_outline_0033
                                   1676 	.globl _ak820_outline_0037
                                   1677 	.globl _ak820_outline_0044
                                   1678 	.globl _ak820_outline_0054
                                   1679 	.globl _ak820_outline_0055
                                   1680 	.globl _ak820_outline_0060
                                   1681 	.globl _ak820_outline_0062
                                   1682 	.globl _ak820_outline_0067
                                   1683 	.globl _ak820_outline_0073
                                   1684 	.globl _ak820_outline_0079
                                   1685 	.globl _ak820_outline_0086
                                   1686 	.globl _ak820_outline_0092
                                   1687 	.globl _ak820_outline_0096
                                   1688 	.globl _ak820_outline_0097
                                   1689 	.globl _ak820_outline_0102
                                   1690 	.globl _ak820_outline_0107
                                   1691 	.globl _ak820_outline_0108
                                   1692 	.globl _ak820_outline_0109
                                   1693 	.globl _ak820_outline_0112
                                   1694 	.globl _ak820_outline_0123
                                   1695 	.globl _ak820_outline_0126
                                   1696 	.globl _ak820_outline_0127
                                   1697 	.globl _ak820_outline_0136
                                   1698 	.globl _ak820_outline_0137
                                   1699 	.globl _ak820_outline_0139
                                   1700 	.globl _ak820_outline_0141
                                   1701 	.globl _ak820_outline_0147
                                   1702 	.globl _ak820_outline_0148
                                   1703 	.globl _ak820_outline_0149
                                   1704 	.globl _ak820_outline_0154
                                   1705 	.globl _ak820_outline_0161
                                   1706 	.globl _ak820_outline_0164
                                   1707 	.globl _ak820_outline_0186
                                   1708 	.globl _ak820_outline_0187
                                   1709 	.globl _ak820_outline_0193
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0009
      0042FF                       1713 _ak820_outline_0009:
      0042FF 8E 82            [24] 1714 	mov	dpl,r6
      004301 8F 83            [24] 1715 	mov	dph,r7
      004303 A3               [24] 1716 	inc	dptr
      004304 A3               [24] 1717 	inc	dptr
      004305 A3               [24] 1718 	inc	dptr
      004306 A3               [24] 1719 	inc	dptr
      004307 A3               [24] 1720 	inc	dptr
      004308 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0033
      004309                       1725 _ak820_outline_0033:
      004309 F0               [24] 1726 	movx	@dptr,a
      00430A 8E 82            [24] 1727 	mov	dpl,r6
      00430C 8F 83            [24] 1728 	mov	dph,r7
      00430E A3               [24] 1729 	inc	dptr
      00430F A3               [24] 1730 	inc	dptr
      004310 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0037
      004311                       1735 _ak820_outline_0037:
      004311 AF F0            [24] 1736 	mov	r7,b
      004313 AE 83            [24] 1737 	mov	r6,dph
      004315 E5 82            [12] 1738 	mov	a,dpl
      004317 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0044
      004318                       1743 _ak820_outline_0044:
      004318 EF               [12] 1744 	mov	a,r7
      004319 24 75            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      00431B F5 82            [12] 1746 	mov	dpl,a
      00431D E4               [12] 1747 	clr	a
      00431E 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004320 F5 83            [12] 1749 	mov	dph,a
      004322 E0               [24] 1750 	movx	a,@dptr
      004323 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0055
      004324                       1755 _ak820_outline_0055:
      004324 8F 06            [24] 1756 	mov	ar6,r7
      004326 7D 00            [12] 1757 	mov	r5,#0x00
      004328 74 40            [12] 1758 	mov	a,#0x40
      00432A 2E               [12] 1759 	add	a,r6
      00432B FE               [12] 1760 	mov	r6,a
      00432C 74 EF            [12] 1761 	mov	a,#0xef
      00432E 3D               [12] 1762 	addc	a,r5
      00432F FD               [12] 1763 	mov	r5,a
      004330 8E 82            [24] 1764 	mov	dpl,r6
      004332 8D 83            [24] 1765 	mov	dph,r5
      004334 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0062
      004335                       1770 _ak820_outline_0062:
      004335 F0               [24] 1771 	movx	@dptr,a
      004336 8E 82            [24] 1772 	mov	dpl,r6
      004338 8F 83            [24] 1773 	mov	dph,r7
      00433A 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0067
      00433B                       1778 _ak820_outline_0067:
      00433B 8D 82            [24] 1779 	mov	dpl,r5
      00433D 8E 83            [24] 1780 	mov	dph,r6
      00433F EC               [12] 1781 	mov	a,r4
      004340 F0               [24] 1782 	movx	@dptr,a
      004341 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0086
      004342                       1787 _ak820_outline_0086:
      004342 E0               [24] 1788 	movx	a,@dptr
      004343 FA               [12] 1789 	mov	r2,a
      004344 A3               [24] 1790 	inc	dptr
      004345 E0               [24] 1791 	movx	a,@dptr
      004346 FB               [12] 1792 	mov	r3,a
      004347 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0096
      004348                       1797 _ak820_outline_0096:
      004348 E0               [24] 1798 	movx	a,@dptr
      004349 8E 82            [24] 1799 	mov	dpl,r6
      00434B 8F 83            [24] 1800 	mov	dph,r7
      00434D F0               [24] 1801 	movx	@dptr,a
      00434E 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0097
      00434F                       1806 _ak820_outline_0097:
      00434F 8C 82            [24] 1807 	mov	dpl,r4
      004351 8D 83            [24] 1808 	mov	dph,r5
      004353 E0               [24] 1809 	movx	a,@dptr
      004354 22               [24] 1810 	ret
                                   1811 
                                   1812 	.area CSEG (CODE)
                                   1813 ; function ak820_outline_0112
      004355                       1814 _ak820_outline_0112:
      004355 EF               [12] 1815 	mov	a,r7
      004356 24 1D            [12] 1816 	add	a,#_page_data
      004358 F5 82            [12] 1817 	mov	dpl,a
      00435A E4               [12] 1818 	clr	a
      00435B 34 05            [12] 1819 	addc	a,#(_page_data>>8)
      00435D F5 83            [12] 1820 	mov	dph,a
      00435F E0               [24] 1821 	movx	a,@dptr
      004360 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0136
      004361                       1826 _ak820_outline_0136:
      004361 AE 82            [24] 1827 	mov	r6,dpl
      004363 AF 83            [24] 1828 	mov	r7,dph
      004365 22               [24] 1829 	ret
                                   1830 
                                   1831 	.area CSEG (CODE)
                                   1832 ; function ak820_outline_0139
      004366                       1833 _ak820_outline_0139:
      004366 2E               [12] 1834 	add	a,r6
      004367 FE               [12] 1835 	mov	r6,a
      004368 E4               [12] 1836 	clr	a
      004369 3F               [12] 1837 	addc	a,r7
      00436A FF               [12] 1838 	mov	r7,a
      00436B 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0141
      00436C                       1843 _ak820_outline_0141:
      00436C ED               [12] 1844 	mov	a,r5
      00436D F0               [24] 1845 	movx	@dptr,a
      00436E EE               [12] 1846 	mov	a,r6
      00436F A3               [24] 1847 	inc	dptr
      004370 F0               [24] 1848 	movx	@dptr,a
      004371 22               [24] 1849 	ret
                                   1850 
                                   1851 	.area CSEG (CODE)
                                   1852 ; function ak820_outline_0147
      004372                       1853 _ak820_outline_0147:
      004372 42 05            [12] 1854 	orl	ar5,a
      004374 EA               [12] 1855 	mov	a,r2
      004375 42 04            [12] 1856 	orl	ar4,a
      004377 22               [24] 1857 	ret
                                   1858 
                                   1859 	.area CSEG (CODE)
                                   1860 ; function ak820_outline_0161
      004378                       1861 _ak820_outline_0161:
      004378 8F 82            [24] 1862 	mov	dpl,r7
      00437A 8E 83            [24] 1863 	mov	dph,r6
      00437C 22               [24] 1864 	ret
                                   1865 
                                   1866 	.area CSEG (CODE)
                                   1867 ; function ak820_outline_0164
      00437D                       1868 _ak820_outline_0164:
      00437D 2E               [12] 1869 	add	a,r6
      00437E FC               [12] 1870 	mov	r4,a
      00437F E4               [12] 1871 	clr	a
      004380 3F               [12] 1872 	addc	a,r7
      004381 FD               [12] 1873 	mov	r5,a
      004382 22               [24] 1874 	ret
                                   1875 
                                   1876 	.area CSEG (CODE)
                                   1877 ; function ak820_outline_0186
      004383                       1878 _ak820_outline_0186:
      004383 8C 82            [24] 1879 	mov	dpl,r4
      004385 8B 83            [24] 1880 	mov	dph,r3
      004387 22               [24] 1881 	ret
                                   1882 
                                   1883 	.area CSEG (CODE)
                                   1884 ; function ak820_outline_0187
      004388                       1885 _ak820_outline_0187:
      004388 8D 82            [24] 1886 	mov	dpl,r5
      00438A 8C 83            [24] 1887 	mov	dph,r4
      00438C 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0193
      00438D                       1892 _ak820_outline_0193:
      00438D AD 82            [24] 1893 	mov	r5,dpl
      00438F AE 83            [24] 1894 	mov	r6,dph
      004391 22               [24] 1895 	ret
