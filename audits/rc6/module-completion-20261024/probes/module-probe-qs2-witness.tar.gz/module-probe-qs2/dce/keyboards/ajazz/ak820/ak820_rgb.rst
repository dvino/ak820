                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000012                        595 _suspended:
      000012                        596 	.ds 1
      000013                        597 _dirty:
      000013                        598 	.ds 1
      000014                        599 _rendering:
      000014                        600 	.ds 1
      000015                        601 _rgb_matrix_task_sloc0_1_0:
      000015                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006F7                        611 _rgb_matrix_config::
      0006F7                        612 	.ds 8
      0006FF                        613 _changed_at:
      0006FF                        614 	.ds 2
      000701                        615 _frame_at:
      000701                        616 	.ds 2
      000703                        617 _phase:
      000703                        618 	.ds 2
      000705                        619 _led_index:
      000705                        620 	.ds 1
      000706                        621 _frame_mode:
      000706                        622 	.ds 1
      000707                        623 _frame_hue:
      000707                        624 	.ds 1
      000708                        625 _frame_sat:
      000708                        626 	.ds 1
      000709                        627 _frame_val:
      000709                        628 	.ds 1
      00070A                        629 _frame_flags:
      00070A                        630 	.ds 1
      00070B                        631 _frame_phase:
      00070B                        632 	.ds 1
      00070C                        633 _reactive_age:
      00070C                        634 	.ds 82
      00075E                        635 _reactive_at:
      00075E                        636 	.ds 2
      000760                        637 _add_sat_PARM_2:
      000760                        638 	.ds 1
      000761                        639 _add_sat_x_10000_266:
      000761                        640 	.ds 1
      000762                        641 _sub_sat_PARM_2:
      000762                        642 	.ds 1
      000763                        643 _sub_sat_x_10000_268:
      000763                        644 	.ds 1
      000764                        645 _rgb_matrix_set_color_PARM_2:
      000764                        646 	.ds 1
      000765                        647 _rgb_matrix_set_color_PARM_3:
      000765                        648 	.ds 1
      000766                        649 _rgb_matrix_set_color_PARM_4:
      000766                        650 	.ds 1
      000767                        651 _rgb_matrix_set_color_index_10000_284:
      000767                        652 	.ds 2
      000769                        653 _rgb_matrix_set_color_all_PARM_2:
      000769                        654 	.ds 1
      00076A                        655 _rgb_matrix_set_color_all_PARM_3:
      00076A                        656 	.ds 1
      00076B                        657 _rgb_matrix_set_color_all_r_10000_287:
      00076B                        658 	.ds 1
      00076C                        659 _sine8_theta_10000_289:
      00076C                        660 	.ds 1
      00076D                        661 _sine8_offset_10000_290:
      00076D                        662 	.ds 1
      00076E                        663 _sine8_fraction_10000_290:
      00076E                        664 	.ds 1
      00076F                        665 _breathing_cie_value_10000_293:
      00076F                        666 	.ds 1
      000770                        667 _rgb_matrix_task_end_10000_298:
      000770                        668 	.ds 1
      000771                        669 _rgb_matrix_task_hsv_10000_298:
      000771                        670 	.ds 3
      000774                        671 _rgb_matrix_task_rgb_10000_298:
      000774                        672 	.ds 3
      000777                        673 _process_rgb_matrix_PARM_2:
      000777                        674 	.ds 1
      000778                        675 _process_rgb_matrix_PARM_3:
      000778                        676 	.ds 1
      000779                        677 _process_rgb_matrix_row_10000_319:
      000779                        678 	.ds 1
      00077A                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      00077A                        680 	.ds 1
      00077B                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      00077B                        682 	.ds 1
      00077C                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      00077C                        684 	.ds 1
      00077D                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      00077D                        686 	.ds 1
      00077E                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      00077E                        688 	.ds 2
      000780                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      000780                        690 	.ds 1
      000781                        691 _rgb_matrix_mode_mode_10000_411:
      000781                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      0053DA                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      0053DA 12 5B 9C         [24]  746 	lcall	_ak820_outline_0183
      0053DD 74 52            [12]  747 	mov	a,#0x52
      0053DF 12 38 9E         [24]  748 	lcall	_ak820_outline_0128
      0053E2 90 07 0C         [24]  749 	mov	dptr,#_reactive_age
      0053E5 F5 F0            [12]  750 	mov	b,a
      0053E7 12 BD 20         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      0053EA 12 4D D7         [24]  753 	lcall	_timer_read
      0053ED 12 38 78         [24]  754 	lcall	_ak820_outline_0103
      0053F0 90 07 5E         [24]  755 	mov	dptr,#_reactive_at
      0053F3 12 48 36         [24]  756 	lcall	_ak820_outline_0144
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      0053F6 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      0053F7                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      0053F7 90 07 5E         [24]  772 	mov	dptr,#_reactive_at
      0053FA 12 37 E9         [24]  773 	lcall	_ak820_outline_0005
      0053FD 12 4D DA         [24]  774 	lcall	_timer_elapsed
      005400 AE 82            [24]  775 	mov	r6, dpl
      005402 E5 83            [12]  776 	mov	a,dph
      005404 C4               [12]  777 	swap	a
      005405 CE               [12]  778 	xch	a,r6
      005406 C4               [12]  779 	swap	a
      005407 54 0F            [12]  780 	anl	a,#0x0f
      005409 6E               [12]  781 	xrl	a,r6
      00540A CE               [12]  782 	xch	a,r6
      00540B 54 0F            [12]  783 	anl	a,#0x0f
      00540D CE               [12]  784 	xch	a,r6
      00540E 6E               [12]  785 	xrl	a,r6
      00540F CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005410 FF               [12]  788 	mov	r7,a
      005411 4E               [12]  789 	orl	a,r6
      005412 70 01            [24]  790 	jnz	00102$
      005414 22               [24]  791 	ret
      005415                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      005415 8E 04            [24]  794 	mov	ar4,r6
      005417 EF               [12]  795 	mov	a,r7
      005418 C4               [12]  796 	swap	a
      005419 54 F0            [12]  797 	anl	a,#0xf0
      00541B CC               [12]  798 	xch	a,r4
      00541C C4               [12]  799 	swap	a
      00541D CC               [12]  800 	xch	a,r4
      00541E 6C               [12]  801 	xrl	a,r4
      00541F CC               [12]  802 	xch	a,r4
      005420 54 F0            [12]  803 	anl	a,#0xf0
      005422 CC               [12]  804 	xch	a,r4
      005423 6C               [12]  805 	xrl	a,r4
      005424 FD               [12]  806 	mov	r5,a
      005425 90 07 5E         [24]  807 	mov	dptr,#_reactive_at
      005428 12 43 42         [24]  808 	lcall	_ak820_outline_0086
      00542B 90 07 5E         [24]  809 	mov	dptr,#_reactive_at
      00542E EC               [12]  810 	mov	a,r4
      00542F 2A               [12]  811 	add	a, r2
      005430 F0               [24]  812 	movx	@dptr,a
      005431 ED               [12]  813 	mov	a,r5
      005432 3B               [12]  814 	addc	a, r3
      005433 A3               [24]  815 	inc	dptr
      005434 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      005435 8E 04            [24]  818 	mov	ar4,r6
      005437 8F 05            [24]  819 	mov	ar5,r7
      005439 12 48 2F         [24]  820 	lcall	_ak820_outline_0115
      00543C 50 04            [24]  821 	jnc	00108$
                                    822 ;	free result
      00543E 7D FF            [12]  823 	mov	r5,#0xff
      005440 80 02            [24]  824 	sjmp	00109$
      005442                        825 00108$:
      005442 8E 05            [24]  826 	mov	ar5,r6
      005444                        827 00109$:
                                    828 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005444 7F 00            [12]  829 	mov	r7,#0x00
      005446                        830 00104$:
                                    831 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      005446 EF               [12]  832 	mov	a,r7
      005447 24 0C            [12]  833 	add	a, #_reactive_age
      005449 FC               [12]  834 	mov	r4,a
      00544A E4               [12]  835 	clr	a
      00544B 34 07            [12]  836 	addc	a, #(_reactive_age >> 8)
      00544D FE               [12]  837 	mov	r6,a
      00544E 8C 82            [24]  838 	mov	dpl,r4
      005450 8E 83            [24]  839 	mov	dph,r6
      005452 E0               [24]  840 	movx	a,@dptr
      005453 FB               [12]  841 	mov	r3,a
      005454 C3               [12]  842 	clr	c
      005455 ED               [12]  843 	mov	a,r5
      005456 9B               [12]  844 	subb	a,r3
      005457 40 04            [24]  845 	jc	00110$
      005459 7B 00            [12]  846 	mov	r3,#0x00
      00545B 80 08            [24]  847 	sjmp	00111$
      00545D                        848 00110$:
      00545D 8C 82            [24]  849 	mov	dpl,r4
      00545F 8E 83            [24]  850 	mov	dph,r6
      005461 E0               [24]  851 	movx	a,@dptr
      005462 C3               [12]  852 	clr	c
      005463 9D               [12]  853 	subb	a,r5
      005464 FB               [12]  854 	mov	r3,a
      005465                        855 00111$:
      005465 8C 82            [24]  856 	mov	dpl,r4
      005467 8E 83            [24]  857 	mov	dph,r6
      005469 EB               [12]  858 	mov	a,r3
      00546A F0               [24]  859 	movx	@dptr,a
                                    860 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00546B 0F               [12]  861 	inc	r7
      00546C BF 52 00         [24]  862 	cjne	r7,#0x52,00144$
      00546F                        863 00144$:
      00546F 40 D5            [24]  864 	jc	00104$
                                    865 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      005471 22               [24]  866 	ret
                                    867 ;------------------------------------------------------------
                                    868 ;Allocation info for local variables in function 'add_sat'
                                    869 ;------------------------------------------------------------
                                    870 ;y             Allocated with name '_add_sat_PARM_2'
                                    871 ;x             Allocated with name '_add_sat_x_10000_266'
                                    872 ;------------------------------------------------------------
                                    873 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function add_sat
                                    876 ;	-----------------------------------------
      005472                        877 _add_sat:
      005472 E5 82            [12]  878 	mov	a,dpl
      005474 90 07 61         [24]  879 	mov	dptr,#_add_sat_x_10000_266
      005477 F0               [24]  880 	movx	@dptr,a
                                    881 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      005478 90 07 60         [24]  882 	mov	dptr,#_add_sat_PARM_2
      00547B E0               [24]  883 	movx	a,@dptr
      00547C FF               [12]  884 	mov	r7,a
      00547D FE               [12]  885 	mov	r6,a
      00547E 74 FF            [12]  886 	mov	a,#0xff
      005480 C3               [12]  887 	clr	c
      005481 9E               [12]  888 	subb	a,r6
      005482 FE               [12]  889 	mov	r6,a
      005483 90 07 61         [24]  890 	mov	dptr,#_add_sat_x_10000_266
      005486 E0               [24]  891 	movx	a,@dptr
      005487 FD               [12]  892 	mov	r5,a
      005488 C3               [12]  893 	clr	c
      005489 EE               [12]  894 	mov	a,r6
      00548A 9D               [12]  895 	subb	a,r5
      00548B 50 04            [24]  896 	jnc	00103$
                                    897 ;	free result
      00548D 7E FF            [12]  898 	mov	r6,#0xff
      00548F 80 03            [24]  899 	sjmp	00104$
      005491                        900 00103$:
      005491 EF               [12]  901 	mov	a,r7
      005492 2D               [12]  902 	add	a, r5
      005493 FE               [12]  903 	mov	r6,a
      005494                        904 00104$:
      005494 8E 82            [24]  905 	mov	dpl, r6
                                    906 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      005496 22               [24]  907 	ret
                                    908 ;------------------------------------------------------------
                                    909 ;Allocation info for local variables in function 'sub_sat'
                                    910 ;------------------------------------------------------------
                                    911 ;y             Allocated with name '_sub_sat_PARM_2'
                                    912 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    913 ;------------------------------------------------------------
                                    914 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    915 ;	-----------------------------------------
                                    916 ;	 function sub_sat
                                    917 ;	-----------------------------------------
      005497                        918 _sub_sat:
      005497 E5 82            [12]  919 	mov	a,dpl
      005499 90 07 63         [24]  920 	mov	dptr,#_sub_sat_x_10000_268
      00549C F0               [24]  921 	movx	@dptr,a
                                    922 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      00549D E0               [24]  923 	movx	a,@dptr
      00549E FF               [12]  924 	mov	r7,a
      00549F 90 07 62         [24]  925 	mov	dptr,#_sub_sat_PARM_2
      0054A2 E0               [24]  926 	movx	a,@dptr
      0054A3 FE               [12]  927 	mov	r6,a
      0054A4 C3               [12]  928 	clr	c
      0054A5 EF               [12]  929 	mov	a,r7
      0054A6 9E               [12]  930 	subb	a,r6
      0054A7 50 04            [24]  931 	jnc	00103$
      0054A9 7D 00            [12]  932 	mov	r5,#0x00
      0054AB 80 04            [24]  933 	sjmp	00104$
      0054AD                        934 00103$:
      0054AD EF               [12]  935 	mov	a,r7
      0054AE C3               [12]  936 	clr	c
      0054AF 9E               [12]  937 	subb	a,r6
      0054B0 FD               [12]  938 	mov	r5,a
      0054B1                        939 00104$:
      0054B1 8D 82            [24]  940 	mov	dpl, r5
                                    941 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      0054B3 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'mark_dirty'
                                    945 ;------------------------------------------------------------
                                    946 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function mark_dirty
                                    949 ;	-----------------------------------------
      0054B4                        950 _mark_dirty:
                                    951 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    952 ;	assignBit
      0054B4 D2 13            [12]  953 	setb	_dirty
                                    954 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      0054B6 12 4D D7         [24]  955 	lcall	_timer_read
      0054B9 12 38 78         [24]  956 	lcall	_ak820_outline_0103
      0054BC 90 06 FF         [24]  957 	mov	dptr,#_changed_at
      0054BF 12 48 36         [24]  958 	lcall	_ak820_outline_0144
                                    959 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      0054C2 22               [24]  960 	ret
                                    961 ;------------------------------------------------------------
                                    962 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    963 ;------------------------------------------------------------
                                    964 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function eeconfig_update_rgb_matrix
                                    969 ;	-----------------------------------------
      0054C3                        970 _eeconfig_update_rgb_matrix:
                                    971 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    972 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      0054C3 90 06 FE         [24]  973 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      0054C6 E4               [12]  974 	clr	a
      0054C7 F0               [24]  975 	movx	@dptr,a
      0054C8 90 06 FD         [24]  976 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      0054CB F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0054CC 90 05 95         [24]  979 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0054CF 12 48 16         [24]  980 	lcall	_ak820_outline_0064
      0054D2 A3               [24]  981 	inc	dptr
      0054D3 F0               [24]  982 	movx	@dptr,a
      0054D4 90 05 98         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0054D7 12 5B 61         [24]  984 	lcall	_ak820_outline_0072
      0054DA 12 42 1C         [24]  985 	lcall	_ak820_eeprom_update_block_xdata
                                    986 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    987 ;	assignBit
      0054DD C2 13            [12]  988 	clr	_dirty
                                    989 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      0054DF 22               [24]  990 	ret
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    993 ;------------------------------------------------------------
                                    994 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function eeconfig_update_rgb_matrix_default
                                    997 ;	-----------------------------------------
      0054E0                        998 _eeconfig_update_rgb_matrix_default:
                                    999 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      0054E0 12 5B 9C         [24] 1000 	lcall	_ak820_outline_0183
      0054E3 12 5B 61         [24] 1001 	lcall	_ak820_outline_0072
      0054E6 F5 F0            [12] 1002 	mov	b,a
      0054E8 12 BD 20         [24] 1003 	lcall	_memset
                                   1004 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      0054EB 12 5B 81         [24] 1005 	lcall	_ak820_outline_0120
      0054EE 44 01            [12] 1006 	orl	a,#0x01
      0054F0 F0               [24] 1007 	movx	@dptr,a
                                   1008 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      0054F1 12 5B 5A         [24] 1009 	lcall	_ak820_outline_0068
      0054F4 44 04            [12] 1010 	orl	a,#0x04
      0054F6 F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      0054F7 90 06 F8         [24] 1013 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0054FA E4               [12] 1014 	clr	a
      0054FB F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      0054FC 90 06 F9         [24] 1017 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0054FF 14               [12] 1018 	dec	a
      005500 F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005501 90 06 FA         [24] 1021 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005504 74 50            [12] 1022 	mov	a,#0x50
      005506 F0               [24] 1023 	movx	@dptr,a
                                   1024 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      005507 90 06 FB         [24] 1025 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00550A 74 60            [12] 1026 	mov	a,#0x60
      00550C F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      00550D 90 06 FC         [24] 1029 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005510 74 FF            [12] 1030 	mov	a,#0xff
      005512 F0               [24] 1031 	movx	@dptr,a
                                   1032 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1033 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      005513 81 C3            [12] 1034 	ajmp	_eeconfig_update_rgb_matrix
                                   1035 ;------------------------------------------------------------
                                   1036 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function rgb_matrix_reload_from_eeprom
                                   1041 ;	-----------------------------------------
      005515                       1042 _rgb_matrix_reload_from_eeprom:
                                   1043 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005515 90 05 85         [24] 1044 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005518 12 48 16         [24] 1045 	lcall	_ak820_outline_0064
      00551B A3               [24] 1046 	inc	dptr
      00551C F0               [24] 1047 	movx	@dptr,a
      00551D 90 05 88         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005520 12 5B 61         [24] 1049 	lcall	_ak820_outline_0072
      005523 12 40 AD         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      005526 12 5B 81         [24] 1052 	lcall	_ak820_outline_0120
      005529 60 11            [24] 1053 	jz	00101$
      00552B 12 5B 3B         [24] 1054 	lcall	_ak820_outline_0021
      00552E C3               [12] 1055 	clr	c
      00552F 64 80            [12] 1056 	xrl	a,#0x80
      005531 94 87            [12] 1057 	subb	a,#0x87
      005533 50 07            [24] 1058 	jnc	00101$
      005535 12 5B 5A         [24] 1059 	lcall	_ak820_outline_0068
      005538 24 FE            [12] 1060 	add	a,#0xff - 0x01
      00553A 50 02            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      00553C                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      00553C 91 E0            [24] 1065 	acall	_eeconfig_update_rgb_matrix_default
      00553E                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      00553E 90 06 FA         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005541 E0               [24] 1069 	movx	a,@dptr
      005542 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      005544 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      005546 90 06 FA         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005549 74 A0            [12] 1075 	mov	a,#0xa0
      00554B F0               [24] 1076 	movx	@dptr,a
      00554C                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      00554C C2 13            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      00554E C2 14            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005550 61 DA            [12] 1086 	ajmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      005552                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      005552 B1 15            [24] 1096 	acall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      005554 12 4D D7         [24] 1098 	lcall	_timer_read
      005557 12 43 61         [24] 1099 	lcall	_ak820_outline_0136
      00555A EE               [12] 1100 	mov	a,r6
      00555B 24 F0            [12] 1101 	add	a,#0xf0
      00555D FE               [12] 1102 	mov	r6,a
      00555E EF               [12] 1103 	mov	a,r7
      00555F 34 FF            [12] 1104 	addc	a,#0xff
      005561 FF               [12] 1105 	mov	r7,a
      005562 90 07 01         [24] 1106 	mov	dptr,#_frame_at
      005565 12 4D 34         [24] 1107 	lcall	_ak820_outline_0061
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      005568 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      005569                       1122 _rgb_matrix_set_color:
      005569 12 38 8A         [24] 1123 	lcall	_ak820_outline_0108
      00556C 90 07 67         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      00556F 12 38 8F         [24] 1125 	lcall	_ak820_outline_0109
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      005572 90 07 67         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005575 12 38 36         [24] 1128 	lcall	_ak820_outline_0054
      005578 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      00557B C3               [12] 1130 	clr	c
      00557C EE               [12] 1131 	mov	a,r6
      00557D 94 52            [12] 1132 	subb	a,#0x52
      00557F EF               [12] 1133 	mov	a,r7
      005580 64 80            [12] 1134 	xrl	a,#0x80
      005582 94 80            [12] 1135 	subb	a,#0x80
      005584 50 23            [24] 1136 	jnc	00104$
      005586 90 07 64         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005589 E0               [24] 1138 	movx	a,@dptr
      00558A FF               [12] 1139 	mov	r7,a
      00558B 90 07 65         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00558E E0               [24] 1141 	movx	a,@dptr
      00558F FD               [12] 1142 	mov	r5,a
      005590 90 07 66         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005593 E0               [24] 1144 	movx	a,@dptr
      005594 FC               [12] 1145 	mov	r4,a
      005595 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      005598 EF               [12] 1147 	mov	a,r7
      005599 F0               [24] 1148 	movx	@dptr,a
      00559A 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      00559D ED               [12] 1150 	mov	a,r5
      00559E F0               [24] 1151 	movx	@dptr,a
      00559F 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0055A2 EC               [12] 1153 	mov	a,r4
      0055A3 F0               [24] 1154 	movx	@dptr,a
      0055A4 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0055A6 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      0055A9                       1158 00104$:
      0055A9 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0055AA                       1171 _rgb_matrix_set_color_all:
      0055AA E5 82            [12] 1172 	mov	a,dpl
      0055AC 90 07 6B         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      0055AF F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      0055B0 E0               [24] 1176 	movx	a,@dptr
      0055B1 FF               [12] 1177 	mov	r7,a
      0055B2 90 07 69         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0055B5 E0               [24] 1179 	movx	a,@dptr
      0055B6 FE               [12] 1180 	mov	r6,a
      0055B7 90 07 6A         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0055BA E0               [24] 1182 	movx	a,@dptr
      0055BB FD               [12] 1183 	mov	r5,a
      0055BC 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      0055BF EE               [12] 1185 	mov	a,r6
      0055C0 F0               [24] 1186 	movx	@dptr,a
      0055C1 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      0055C4 ED               [12] 1188 	mov	a,r5
      0055C5 F0               [24] 1189 	movx	@dptr,a
      0055C6 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      0055C8 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      0055CB                       1206 _sine8:
      0055CB E5 82            [12] 1207 	mov	a,dpl
      0055CD 90 07 6C         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      0055D0 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      0055D1 E0               [24] 1211 	movx	a,@dptr
      0055D2 FF               [12] 1212 	mov	r7,a
      0055D3 90 07 6D         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      0055D6 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      0055D7 EF               [12] 1216 	mov	a,r7
      0055D8 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      0055DB 90 07 6D         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      0055DE 74 FF            [12] 1219 	mov	a,#0xff
      0055E0 C3               [12] 1220 	clr	c
      0055E1 9F               [12] 1221 	subb	a,r7
      0055E2 F0               [24] 1222 	movx	@dptr,a
      0055E3                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      0055E3 90 07 6D         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      0055E6 E0               [24] 1226 	movx	a,@dptr
      0055E7 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      0055EA F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      0055EB 90 07 6D         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      0055EE E0               [24] 1231 	movx	a,@dptr
      0055EF 54 0F            [12] 1232 	anl	a,#0x0f
      0055F1 FF               [12] 1233 	mov	r7,a
      0055F2 90 07 6E         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      0055F5 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      0055F6 90 07 6C         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      0055F9 E0               [24] 1238 	movx	a,@dptr
      0055FA 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      0055FD 90 07 6E         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      005600 EF               [12] 1241 	mov	a,r7
      005601 04               [12] 1242 	inc	a
      005602 F0               [24] 1243 	movx	@dptr,a
      005603                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      005603 90 07 6D         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      005606 E0               [24] 1247 	movx	a,@dptr
      005607 C4               [12] 1248 	swap	a
      005608 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      00560A 25 E0            [12] 1251 	add	a,acc
      00560C FF               [12] 1252 	mov	r7,a
      00560D 90 BF 11         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      005610 93               [24] 1254 	movc	a,@a+dptr
      005611 FE               [12] 1255 	mov	r6,a
      005612 0F               [12] 1256 	inc	r7
      005613 EF               [12] 1257 	mov	a,r7
      005614 90 BF 11         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      005617 93               [24] 1259 	movc	a,@a+dptr
      005618 FF               [12] 1260 	mov	r7,a
      005619 90 07 6E         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      00561C E0               [24] 1262 	movx	a,@dptr
      00561D 8F F0            [24] 1263 	mov	b,r7
      00561F A4               [48] 1264 	mul	ab
      005620 FF               [12] 1265 	mov	r7,a
      005621 E5 F0            [12] 1266 	mov	a,b
      005623 C4               [12] 1267 	swap	a
      005624 CF               [12] 1268 	xch	a,r7
      005625 C4               [12] 1269 	swap	a
      005626 54 0F            [12] 1270 	anl	a,#0x0f
      005628 6F               [12] 1271 	xrl	a,r7
      005629 CF               [12] 1272 	xch	a,r7
      00562A 54 0F            [12] 1273 	anl	a,#0x0f
      00562C CF               [12] 1274 	xch	a,r7
      00562D 6F               [12] 1275 	xrl	a,r7
      00562E CF               [12] 1276 	xch	a,r7
      00562F EF               [12] 1277 	mov	a,r7
      005630 2E               [12] 1278 	add	a, r6
      005631 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      005632 90 07 6C         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      005635 E0               [24] 1282 	movx	a,@dptr
      005636 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      005639 8F 06            [24] 1284 	mov	ar6,r7
      00563B 74 80            [12] 1285 	mov	a,#0x80
      00563D C3               [12] 1286 	clr	c
      00563E 9E               [12] 1287 	subb	a,r6
      00563F FE               [12] 1288 	mov	r6,a
      005640 80 04            [24] 1289 	sjmp	00108$
      005642                       1290 00107$:
      005642 74 80            [12] 1291 	mov	a,#0x80
      005644 2F               [12] 1292 	add	a, r7
      005645 FE               [12] 1293 	mov	r6,a
      005646                       1294 00108$:
      005646 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005648 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      005649                       1312 _breathing_cie:
      005649 E5 82            [12] 1313 	mov	a,dpl
      00564B 90 07 6F         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      00564E F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      00564F E0               [24] 1317 	movx	a,@dptr
      005650 FF               [12] 1318 	mov	r7,a
      005651 12 5B AA         [24] 1319 	lcall	_ak820_outline_0191
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      005654 FE               [12] 1321 	mov	r6,a
      005655 90 C2 1D         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      005658 93               [24] 1323 	movc	a,@a+dptr
      005659 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      00565A BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      00565D 8D 82            [24] 1327 	mov	dpl, r5
      00565F 22               [24] 1328 	ret
      005660                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      005660 EE               [12] 1331 	mov	a,r6
      005661 04               [12] 1332 	inc	a
      005662 90 C2 1D         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      005665 93               [24] 1334 	movc	a,@a+dptr
      005666 C3               [12] 1335 	clr	c
      005667 9D               [12] 1336 	subb	a,r5
      005668 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      005669 74 07            [12] 1339 	mov	a,#0x07
      00566B 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      00566C F5 F0            [12] 1342 	mov	b,a
      00566E EE               [12] 1343 	mov	a,r6
      00566F A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      005670 12 5B AA         [24] 1346 	lcall	_ak820_outline_0191
      005673 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      005674 F5 82            [12] 1349 	mov	dpl,a
      005676 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      005677                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      005677 71 F7            [12] 1367 	acall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005679 30 13 17         [24] 1369 	jnb	_dirty,00102$
      00567C 90 06 FF         [24] 1370 	mov	dptr,#_changed_at
      00567F 12 37 E9         [24] 1371 	lcall	_ak820_outline_0005
      005682 12 4D DA         [24] 1372 	lcall	_timer_elapsed
      005685 12 43 61         [24] 1373 	lcall	_ak820_outline_0136
      005688 C3               [12] 1374 	clr	c
      005689 EE               [12] 1375 	mov	a,r6
      00568A 94 E8            [12] 1376 	subb	a,#0xe8
      00568C EF               [12] 1377 	mov	a,r7
      00568D 94 03            [12] 1378 	subb	a,#0x03
      00568F 40 02            [24] 1379 	jc	00102$
      005691 91 C3            [12] 1380 	acall	_eeconfig_update_rgb_matrix
      005693                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      005693 30 14 02         [24] 1383 	jnb	_rendering,00254$
      005696 E1 4B            [12] 1384 	ajmp	00109$
      005698                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      005698 90 07 01         [24] 1387 	mov	dptr,#_frame_at
      00569B 12 37 E9         [24] 1388 	lcall	_ak820_outline_0005
      00569E 12 4D DA         [24] 1389 	lcall	_timer_elapsed
      0056A1 12 43 61         [24] 1390 	lcall	_ak820_outline_0136
      0056A4 C3               [12] 1391 	clr	c
      0056A5 EE               [12] 1392 	mov	a,r6
      0056A6 94 10            [12] 1393 	subb	a,#0x10
      0056A8 EF               [12] 1394 	mov	a,r7
      0056A9 94 00            [12] 1395 	subb	a,#0x00
      0056AB 50 01            [24] 1396 	jnc	00105$
      0056AD 22               [24] 1397 	ret
      0056AE                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0056AE 12 4D D7         [24] 1400 	lcall	_timer_read
      0056B1 12 38 78         [24] 1401 	lcall	_ak820_outline_0103
      0056B4 90 07 01         [24] 1402 	mov	dptr,#_frame_at
      0056B7 12 48 36         [24] 1403 	lcall	_ak820_outline_0144
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      0056BA 90 06 FB         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0056BD E0               [24] 1406 	movx	a,@dptr
      0056BE FF               [12] 1407 	mov	r7,a
      0056BF 7E 00            [12] 1408 	mov	r6,#0x00
      0056C1 74 20            [12] 1409 	mov	a,#0x20
      0056C3 2F               [12] 1410 	add	a, r7
      0056C4 FF               [12] 1411 	mov	r7,a
      0056C5 E4               [12] 1412 	clr	a
      0056C6 3E               [12] 1413 	addc	a, r6
      0056C7 FE               [12] 1414 	mov	r6,a
      0056C8 90 07 03         [24] 1415 	mov	dptr,#_phase
      0056CB 12 38 4D         [24] 1416 	lcall	_ak820_outline_0060
      0056CE EF               [12] 1417 	mov	a,r7
      0056CF 2C               [12] 1418 	add	a, r4
      0056D0 FF               [12] 1419 	mov	r7,a
      0056D1 EE               [12] 1420 	mov	a,r6
      0056D2 3D               [12] 1421 	addc	a, r5
      0056D3 FE               [12] 1422 	mov	r6,a
      0056D4 90 07 03         [24] 1423 	mov	dptr,#_phase
      0056D7 EF               [12] 1424 	mov	a,r7
      0056D8 F0               [24] 1425 	movx	@dptr,a
      0056D9 EE               [12] 1426 	mov	a,r6
      0056DA A3               [24] 1427 	inc	dptr
      0056DB F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      0056DC 90 07 03         [24] 1430 	mov	dptr,#_phase
      0056DF E0               [24] 1431 	movx	a,@dptr
      0056E0 A3               [24] 1432 	inc	dptr
      0056E1 E0               [24] 1433 	movx	a,@dptr
      0056E2 FF               [12] 1434 	mov	r7,a
      0056E3 90 07 0B         [24] 1435 	mov	dptr,#_frame_phase
      0056E6 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      0056E7 20 12 05         [24] 1438 	jb	_suspended,00135$
      0056EA 12 5B 5A         [24] 1439 	lcall	_ak820_outline_0068
      0056ED 70 04            [24] 1440 	jnz	00132$
      0056EF                       1441 00135$:
      0056EF 7E 00            [12] 1442 	mov	r6,#0x00
      0056F1 80 04            [24] 1443 	sjmp	00133$
      0056F3                       1444 00132$:
      0056F3 12 5B 3B         [24] 1445 	lcall	_ak820_outline_0021
      0056F6 FE               [12] 1446 	mov	r6,a
      0056F7                       1447 00133$:
      0056F7 90 07 06         [24] 1448 	mov	dptr,#_frame_mode
      0056FA EE               [12] 1449 	mov	a,r6
      0056FB F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      0056FC 90 06 F8         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0056FF E0               [24] 1453 	movx	a,@dptr
      005700 90 07 07         [24] 1454 	mov	dptr,#_frame_hue
      005703 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005704 90 06 F9         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005707 E0               [24] 1458 	movx	a,@dptr
      005708 90 07 08         [24] 1459 	mov	dptr,#_frame_sat
      00570B F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      00570C 90 06 FA         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00570F E0               [24] 1463 	movx	a,@dptr
      005710 FD               [12] 1464 	mov	r5,a
      005711 90 07 09         [24] 1465 	mov	dptr,#_frame_val
      005714 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005715 90 06 FC         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005718 E0               [24] 1469 	movx	a,@dptr
      005719 90 07 0A         [24] 1470 	mov	dptr,#_frame_flags
      00571C F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      00571D BE 02 24         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      005720 EF               [12] 1475 	mov	a,r7
      005721 24 C0            [12] 1476 	add	a,#0xc0
      005723 F5 82            [12] 1477 	mov	dpl,a
      005725 C0 05            [24] 1478 	push	ar5
      005727 B1 CB            [24] 1479 	acall	_sine8
      005729 AF 82            [24] 1480 	mov	r7, dpl
      00572B D0 05            [24] 1481 	pop	ar5
      00572D 8D F0            [24] 1482 	mov	b,r5
      00572F EF               [12] 1483 	mov	a,r7
      005730 A4               [48] 1484 	mul	ab
      005731 AE F0            [24] 1485 	mov	r6,b
      005733 8E 05            [24] 1486 	mov	ar5,r6
      005735 90 07 09         [24] 1487 	mov	dptr,#_frame_val
      005738 ED               [12] 1488 	mov	a,r5
      005739 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      00573A 8D 82            [24] 1491 	mov	dpl, r5
      00573C D1 49            [24] 1492 	acall	_breathing_cie
      00573E E5 82            [12] 1493 	mov	a, dpl
      005740 90 07 09         [24] 1494 	mov	dptr,#_frame_val
      005743 F0               [24] 1495 	movx	@dptr,a
      005744                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005744 90 07 05         [24] 1498 	mov	dptr,#_led_index
      005747 E4               [12] 1499 	clr	a
      005748 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      005749 D2 14            [12] 1503 	setb	_rendering
      00574B                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      00574B 12 5B A5         [24] 1506 	lcall	_ak820_outline_0189
      00574E 24 08            [12] 1507 	add	a,#0x08
      005750 FF               [12] 1508 	mov	r7,a
      005751 90 07 70         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005754 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005755 EF               [12] 1512 	mov	a,r7
      005756 24 AD            [12] 1513 	add	a,#0xff - 0x52
      005758 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      00575A 90 07 70         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00575D 74 52            [12] 1517 	mov	a,#0x52
      00575F F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      005760                       1520 00125$:
      005760 12 5B A5         [24] 1521 	lcall	_ak820_outline_0189
      005763 FF               [12] 1522 	mov	r7,a
      005764 90 07 70         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005767 E0               [24] 1524 	movx	a,@dptr
      005768 FE               [12] 1525 	mov	r6,a
      005769 C3               [12] 1526 	clr	c
      00576A EF               [12] 1527 	mov	a,r7
      00576B 9E               [12] 1528 	subb	a,r6
      00576C 40 03            [24] 1529 	jc	00261$
      00576E 02 58 D1         [24] 1530 	ljmp	00127$
      005771                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      005771 12 5B 88         [24] 1533 	lcall	_ak820_outline_0143
      005774 E0               [24] 1534 	movx	a,@dptr
      005775 60 07            [24] 1535 	jz	00121$
      005777 90 07 0A         [24] 1536 	mov	dptr,#_frame_flags
      00577A E0               [24] 1537 	movx	a,@dptr
      00577B 20 E2 1B         [24] 1538 	jb	acc.2,00122$
      00577E                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      00577E 12 5B A5         [24] 1541 	lcall	_ak820_outline_0189
      005781 FC               [12] 1542 	mov	r4,a
      005782 7D 00            [12] 1543 	mov	r5,#0x00
      005784 90 07 64         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005787 E4               [12] 1545 	clr	a
      005788 F0               [24] 1546 	movx	@dptr,a
      005789 90 07 65         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00578C F0               [24] 1548 	movx	@dptr,a
      00578D 90 07 66         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005790 F0               [24] 1550 	movx	@dptr,a
      005791 12 38 99         [24] 1551 	lcall	_ak820_outline_0127
      005794 B1 69            [24] 1552 	acall	_rgb_matrix_set_color
      005796 02 58 C8         [24] 1553 	ljmp	00123$
      005799                       1554 00122$:
                                   1555 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      005799 BE 05 21         [24] 1556 	cjne	r6,#0x05,00119$
                                   1557 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      00579C EF               [12] 1558 	mov	a,r7
      00579D 75 F0 03         [24] 1559 	mov	b,#0x03
      0057A0 A4               [48] 1560 	mul	ab
      0057A1 24 CE            [12] 1561 	add	a, #_g_direct_mode_colors
      0057A3 FD               [12] 1562 	mov	r5,a
      0057A4 74 0C            [12] 1563 	mov	a,#(_g_direct_mode_colors >> 8)
      0057A6 35 F0            [12] 1564 	addc	a, b
      0057A8 FE               [12] 1565 	mov	r6,a
      0057A9 90 0D E2         [24] 1566 	mov	dptr,#___memcpy_PARM_2
      0057AC ED               [12] 1567 	mov	a,r5
      0057AD F0               [24] 1568 	movx	@dptr,a
      0057AE EE               [12] 1569 	mov	a,r6
      0057AF 12 5B 6B         [24] 1570 	lcall	_ak820_outline_0074
      0057B2 90 07 71         [24] 1571 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057B5 F5 F0            [12] 1572 	mov	b,a
      0057B7 12 BC AA         [24] 1573 	lcall	___memcpy
      0057BA 02 58 6C         [24] 1574 	ljmp	00120$
      0057BD                       1575 00119$:
                                   1576 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      0057BD 90 07 07         [24] 1577 	mov	dptr,#_frame_hue
      0057C0 E0               [24] 1578 	movx	a,@dptr
      0057C1 90 07 71         [24] 1579 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057C4 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      0057C5 90 07 08         [24] 1582 	mov	dptr,#_frame_sat
      0057C8 E0               [24] 1583 	movx	a,@dptr
      0057C9 90 07 72         [24] 1584 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      0057CC F0               [24] 1585 	movx	@dptr,a
                                   1586 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      0057CD 90 07 09         [24] 1587 	mov	dptr,#_frame_val
      0057D0 E0               [24] 1588 	movx	a,@dptr
      0057D1 90 07 73         [24] 1589 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0057D4 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      0057D5 12 5B 88         [24] 1592 	lcall	_ak820_outline_0143
      0057D8 BE 03 0E         [24] 1593 	cjne	r6,#0x03,00113$
      0057DB 90 07 71         [24] 1594 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057DE E0               [24] 1595 	movx	a,@dptr
      0057DF FE               [12] 1596 	mov	r6,a
      0057E0 90 07 0B         [24] 1597 	mov	dptr,#_frame_phase
      0057E3 E0               [24] 1598 	movx	a,@dptr
      0057E4 2E               [12] 1599 	add	a, r6
      0057E5 90 07 71         [24] 1600 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057E8 F0               [24] 1601 	movx	@dptr,a
      0057E9                       1602 00113$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      0057E9 12 5B 88         [24] 1604 	lcall	_ak820_outline_0143
      0057EC BE 04 23         [24] 1605 	cjne	r6,#0x04,00115$
      0057EF 90 07 71         [24] 1606 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0057F2 E0               [24] 1607 	movx	a,@dptr
      0057F3 FE               [12] 1608 	mov	r6,a
      0057F4 12 5B A5         [24] 1609 	lcall	_ak820_outline_0189
      0057F7 75 F0 02         [24] 1610 	mov	b,#0x02
      0057FA A4               [48] 1611 	mul	ab
      0057FB 24 79            [12] 1612 	add	a, #_ak820_led_points
      0057FD F5 82            [12] 1613 	mov	dpl,a
      0057FF 74 C1            [12] 1614 	mov	a,#(_ak820_led_points >> 8)
      005801 12 5B 7A         [24] 1615 	lcall	_ak820_outline_0114
      005804 FD               [12] 1616 	mov	r5,a
      005805 90 07 0B         [24] 1617 	mov	dptr,#_frame_phase
      005808 E0               [24] 1618 	movx	a,@dptr
      005809 FC               [12] 1619 	mov	r4,a
      00580A ED               [12] 1620 	mov	a,r5
      00580B C3               [12] 1621 	clr	c
      00580C 9C               [12] 1622 	subb	a,r4
      00580D 2E               [12] 1623 	add	a, r6
      00580E 90 07 71         [24] 1624 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005811 F0               [24] 1625 	movx	@dptr,a
      005812                       1626 00115$:
                                   1627 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      005812 12 5B 88         [24] 1628 	lcall	_ak820_outline_0143
      005815 BE 06 54         [24] 1629 	cjne	r6,#0x06,00120$
                                   1630 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005818 12 5B 93         [24] 1631 	lcall	_ak820_outline_0177
      00581B FE               [12] 1632 	mov	r6,a
      00581C 74 07            [12] 1633 	mov	a,#0x07
      00581E C3               [12] 1634 	clr	c
      00581F 9E               [12] 1635 	subb	a,r6
      005820 FE               [12] 1636 	mov	r6,a
                                   1637 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      005821 8E F0            [24] 1638 	mov	b,r6
      005823 05 F0            [12] 1639 	inc	b
      005825 74 01            [12] 1640 	mov	a,#0x01
      005827 80 02            [24] 1641 	sjmp	00273$
      005829                       1642 00272$:
      005829 25 E0            [12] 1643 	add	a,acc
      00582B                       1644 00273$:
      00582B D5 F0 FB         [24] 1645 	djnz	b,00272$
      00582E FD               [12] 1646 	mov	r5,a
                                   1647 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      00582F 12 5B A5         [24] 1648 	lcall	_ak820_outline_0189
      005832 24 0C            [12] 1649 	add	a, #_reactive_age
      005834 F5 82            [12] 1650 	mov	dpl,a
      005836 E4               [12] 1651 	clr	a
      005837 34 07            [12] 1652 	addc	a, #(_reactive_age >> 8)
      005839 F5 83            [12] 1653 	mov	dph,a
      00583B E0               [24] 1654 	movx	a,@dptr
                                   1655 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      00583C FC               [12] 1656 	mov	r4,a
      00583D C3               [12] 1657 	clr	c
      00583E 9D               [12] 1658 	subb	a,r5
      00583F 40 07            [24] 1659 	jc	00137$
      005841 90 07 09         [24] 1660 	mov	dptr,#_frame_val
      005844 E0               [24] 1661 	movx	a,@dptr
      005845 FB               [12] 1662 	mov	r3,a
      005846 80 1F            [24] 1663 	sjmp	00138$
      005848                       1664 00137$:
      005848 90 07 09         [24] 1665 	mov	dptr,#_frame_val
      00584B E0               [24] 1666 	movx	a,@dptr
      00584C F5 F0            [12] 1667 	mov	b, a
      00584E EC               [12] 1668 	mov	a,r4
      00584F A4               [48] 1669 	mul	ab
      005850 FC               [12] 1670 	mov	r4,a
      005851 AA F0            [24] 1671 	mov	r2,b
      005853 8E F0            [24] 1672 	mov	b,r6
      005855 05 F0            [12] 1673 	inc	b
      005857 AB 04            [24] 1674 	mov	r3,ar4
      005859 AD 02            [24] 1675 	mov	r5,ar2
      00585B 80 07            [24] 1676 	sjmp	00276$
      00585D                       1677 00275$:
      00585D C3               [12] 1678 	clr	c
      00585E ED               [12] 1679 	mov	a,r5
      00585F 13               [12] 1680 	rrc	a
      005860 FD               [12] 1681 	mov	r5,a
      005861 EB               [12] 1682 	mov	a,r3
      005862 13               [12] 1683 	rrc	a
      005863 FB               [12] 1684 	mov	r3,a
      005864                       1685 00276$:
      005864 D5 F0 F6         [24] 1686 	djnz	b,00275$
      005867                       1687 00138$:
      005867 90 07 73         [24] 1688 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      00586A EB               [12] 1689 	mov	a,r3
      00586B F0               [24] 1690 	movx	@dptr,a
      00586C                       1691 00120$:
                                   1692 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      00586C 12 5B 88         [24] 1693 	lcall	_ak820_outline_0143
      00586F BE 02 03         [24] 1694 	cjne	r6,#0x02,00277$
      005872 D3               [12] 1695 	setb	c
      005873 80 01            [24] 1696 	sjmp	00278$
      005875                       1697 00277$:
      005875 C3               [12] 1698 	clr	c
      005876                       1699 00278$:
      005876 B3               [12] 1700 	cpl	c
      005877 92 15            [24] 1701 	mov	_rgb_matrix_task_sloc0_1_0,c
      005879 90 0D E2         [24] 1702 	mov	dptr,#___memcpy_PARM_2
      00587C 74 71            [12] 1703 	mov	a,#_rgb_matrix_task_hsv_10000_298
      00587E F0               [24] 1704 	movx	@dptr,a
      00587F 74 07            [12] 1705 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      005881 12 5B 6B         [24] 1706 	lcall	_ak820_outline_0074
      005884 90 0B 09         [24] 1707 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      005887 F5 F0            [12] 1708 	mov	b,a
      005889 12 BC AA         [24] 1709 	lcall	___memcpy
      00588C 90 0B 0C         [24] 1710 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      00588F 74 74            [12] 1711 	mov	a,#_rgb_matrix_task_rgb_10000_298
      005891 F0               [24] 1712 	movx	@dptr,a
      005892 74 07            [12] 1713 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005894 A3               [24] 1714 	inc	dptr
      005895 F0               [24] 1715 	movx	@dptr,a
      005896 A2 15            [12] 1716 	mov	c,_rgb_matrix_task_sloc0_1_0
      005898 12 38 B2         [24] 1717 	lcall	_ak820_outline_0154
      00589B 12 85 20         [24] 1718 	lcall	_hsv_to_rgb_into
                                   1719 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      00589E 12 5B A5         [24] 1720 	lcall	_ak820_outline_0189
      0058A1 FD               [12] 1721 	mov	r5,a
      0058A2 7E 00            [12] 1722 	mov	r6,#0x00
      0058A4 90 07 75         [24] 1723 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      0058A7 E0               [24] 1724 	movx	a,@dptr
      0058A8 FC               [12] 1725 	mov	r4,a
      0058A9 90 07 74         [24] 1726 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      0058AC E0               [24] 1727 	movx	a,@dptr
      0058AD FB               [12] 1728 	mov	r3,a
      0058AE 90 07 76         [24] 1729 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      0058B1 E0               [24] 1730 	movx	a,@dptr
      0058B2 FA               [12] 1731 	mov	r2,a
      0058B3 90 07 64         [24] 1732 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0058B6 EC               [12] 1733 	mov	a,r4
      0058B7 F0               [24] 1734 	movx	@dptr,a
      0058B8 90 07 65         [24] 1735 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0058BB EB               [12] 1736 	mov	a,r3
      0058BC F0               [24] 1737 	movx	@dptr,a
      0058BD 90 07 66         [24] 1738 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0058C0 EA               [12] 1739 	mov	a,r2
      0058C1 F0               [24] 1740 	movx	@dptr,a
      0058C2 12 38 A3         [24] 1741 	lcall	_ak820_outline_0137
      0058C5 12 55 69         [24] 1742 	lcall	_rgb_matrix_set_color
      0058C8                       1743 00123$:
                                   1744 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      0058C8 12 5B A5         [24] 1745 	lcall	_ak820_outline_0189
      0058CB 24 01            [12] 1746 	add	a, #0x01
      0058CD F0               [24] 1747 	movx	@dptr,a
      0058CE 02 57 60         [24] 1748 	ljmp	00125$
      0058D1                       1749 00127$:
                                   1750 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      0058D1 BF 52 02         [24] 1751 	cjne	r7,#0x52,00130$
                                   1752 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1753 ;	assignBit
      0058D4 C2 14            [12] 1754 	clr	_rendering
      0058D6                       1755 00130$:
                                   1756 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      0058D6 22               [24] 1757 	ret
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1760 ;------------------------------------------------------------
                                   1761 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1762 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1763 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1764 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1765 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1766 ;------------------------------------------------------------
                                   1767 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1768 ;	-----------------------------------------
                                   1769 ;	 function process_rgb_matrix
                                   1770 ;	-----------------------------------------
      0058D7                       1771 _process_rgb_matrix:
      0058D7 E5 82            [12] 1772 	mov	a,dpl
      0058D9 90 07 79         [24] 1773 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0058DC F0               [24] 1774 	movx	@dptr,a
                                   1775 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      0058DD 90 07 78         [24] 1776 	mov	dptr,#_process_rgb_matrix_PARM_3
      0058E0 E0               [24] 1777 	movx	a,@dptr
      0058E1 60 23            [24] 1778 	jz	00101$
      0058E3 20 12 20         [24] 1779 	jb	_suspended,00101$
      0058E6 12 5B 5A         [24] 1780 	lcall	_ak820_outline_0068
      0058E9 60 1B            [24] 1781 	jz	00101$
                                   1782 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      0058EB 12 5B 3B         [24] 1783 	lcall	_ak820_outline_0021
      0058EE FF               [12] 1784 	mov	r7,a
      0058EF BF 06 14         [24] 1785 	cjne	r7,#0x06,00101$
      0058F2 90 07 79         [24] 1786 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0058F5 E0               [24] 1787 	movx	a,@dptr
      0058F6 FF               [12] 1788 	mov	r7,a
      0058F7 BF 10 00         [24] 1789 	cjne	r7,#0x10,00169$
      0058FA                       1790 00169$:
      0058FA 50 0A            [24] 1791 	jnc	00101$
      0058FC 90 07 77         [24] 1792 	mov	dptr,#_process_rgb_matrix_PARM_2
      0058FF E0               [24] 1793 	movx	a,@dptr
      005900 FE               [12] 1794 	mov	r6,a
      005901 BE 08 00         [24] 1795 	cjne	r6,#0x08,00171$
      005904                       1796 00171$:
      005904 40 01            [24] 1797 	jc	00102$
      005906                       1798 00101$:
      005906 22               [24] 1799 	ret
      005907                       1800 00102$:
                                   1801 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005907 C0 07            [24] 1802 	push	ar7
      005909 C0 06            [24] 1803 	push	ar6
      00590B 12 53 F7         [24] 1804 	lcall	_age_reactive
      00590E D0 06            [24] 1805 	pop	ar6
      005910 D0 07            [24] 1806 	pop	ar7
                                   1807 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005912 EF               [12] 1808 	mov	a,r7
      005913 12 38 C7         [24] 1809 	lcall	_ak820_outline_0195
      005916 2E               [12] 1810 	add	a,r6
      005917 FF               [12] 1811 	mov	r7,a
                                   1812 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005918 7E 00            [12] 1813 	mov	r6,#0x00
      00591A                       1814 00111$:
                                   1815 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      00591A EE               [12] 1816 	mov	a,r6
      00591B 90 BE 9D         [24] 1817 	mov	dptr,#_ak820_rgb_slots
      00591E 93               [24] 1818 	movc	a,@a+dptr
      00591F B5 07 29         [24] 1819 	cjne	a,ar7,00112$
                                   1820 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005922 EE               [12] 1821 	mov	a,r6
      005923 24 0C            [12] 1822 	add	a, #_reactive_age
      005925 FC               [12] 1823 	mov	r4,a
      005926 E4               [12] 1824 	clr	a
      005927 34 07            [12] 1825 	addc	a, #(_reactive_age >> 8)
      005929 FD               [12] 1826 	mov	r5,a
      00592A 12 5B 93         [24] 1827 	lcall	_ak820_outline_0177
      00592D F5 F0            [12] 1828 	mov	b, a
      00592F 05 F0            [12] 1829 	inc	b
      005931 7B 80            [12] 1830 	mov	r3,#0x80
      005933 E4               [12] 1831 	clr	a
      005934 FA               [12] 1832 	mov	r2,a
      005935 33               [12] 1833 	rlc	a
      005936 92 D2            [24] 1834 	mov	ov,c
      005938 80 08            [24] 1835 	sjmp	00176$
      00593A                       1836 00175$:
      00593A A2 D2            [12] 1837 	mov	c,ov
      00593C EA               [12] 1838 	mov	a,r2
      00593D 13               [12] 1839 	rrc	a
      00593E FA               [12] 1840 	mov	r2,a
      00593F EB               [12] 1841 	mov	a,r3
      005940 13               [12] 1842 	rrc	a
      005941 FB               [12] 1843 	mov	r3,a
      005942                       1844 00176$:
      005942 D5 F0 F5         [24] 1845 	djnz	b,00175$
      005945 12 38 99         [24] 1846 	lcall	_ak820_outline_0127
      005948 EB               [12] 1847 	mov	a,r3
      005949 F0               [24] 1848 	movx	@dptr,a
                                   1849 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      00594A 22               [24] 1850 	ret
      00594B                       1851 00112$:
                                   1852 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00594B 0E               [12] 1853 	inc	r6
      00594C BE 52 00         [24] 1854 	cjne	r6,#0x52,00177$
      00594F                       1855 00177$:
      00594F 40 C9            [24] 1856 	jc	00111$
                                   1857 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      005951 22               [24] 1858 	ret
                                   1859 ;------------------------------------------------------------
                                   1860 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1861 ;------------------------------------------------------------
                                   1862 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1863 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1864 ;------------------------------------------------------------
                                   1865 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1866 ;	-----------------------------------------
                                   1867 ;	 function rgb_matrix_set_suspend_state
                                   1868 ;	-----------------------------------------
      005952                       1869 _rgb_matrix_set_suspend_state:
      005952 E5 82            [12] 1870 	mov	a,dpl
      005954 90 07 7A         [24] 1871 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      005957 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      005958 E0               [24] 1874 	movx	a,@dptr
                                   1875 ;	assignBit
      005959 F5 15            [12] 1876 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      00595B 13               [12] 1877 	rrc	a
      00595C 92 12            [24] 1878 	mov	_suspended,c
                                   1879 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1880 ;	assignBit
      00595E C2 14            [12] 1881 	clr	_rendering
                                   1882 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      005960 12 53 DA         [24] 1883 	lcall	_clear_reactive
                                   1884 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005963 E5 15            [12] 1885 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      005965 60 0F            [24] 1886 	jz	00103$
                                   1887 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      005967 90 07 69         [24] 1888 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      00596A E4               [12] 1889 	clr	a
      00596B F0               [24] 1890 	movx	@dptr,a
      00596C 90 07 6A         [24] 1891 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      00596F F0               [24] 1892 	movx	@dptr,a
      005970 75 82 00         [24] 1893 	mov	dpl, #0x00
                                   1894 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      005973 02 55 AA         [24] 1895 	ljmp	_rgb_matrix_set_color_all
      005976                       1896 00103$:
      005976 22               [24] 1897 	ret
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function rgb_matrix_is_enabled
                                   1904 ;	-----------------------------------------
      005977                       1905 _rgb_matrix_is_enabled:
      005977 12 5B 5A         [24] 1906 	lcall	_ak820_outline_0068
      00597A F5 82            [12] 1907 	mov	dpl,a
      00597C 22               [24] 1908 	ret
                                   1909 ;------------------------------------------------------------
                                   1910 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1911 ;------------------------------------------------------------
                                   1912 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1913 ;	-----------------------------------------
                                   1914 ;	 function rgb_matrix_get_mode
                                   1915 ;	-----------------------------------------
      00597D                       1916 _rgb_matrix_get_mode:
      00597D 12 5B 3B         [24] 1917 	lcall	_ak820_outline_0021
      005980 F5 82            [12] 1918 	mov	dpl,a
      005982 22               [24] 1919 	ret
                                   1920 ;------------------------------------------------------------
                                   1921 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1922 ;------------------------------------------------------------
                                   1923 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1924 ;	-----------------------------------------
                                   1925 ;	 function rgb_matrix_get_hue
                                   1926 ;	-----------------------------------------
      005983                       1927 _rgb_matrix_get_hue:
      005983 90 06 F8         [24] 1928 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005986 E0               [24] 1929 	movx	a,@dptr
      005987 F5 82            [12] 1930 	mov	dpl,a
      005989 22               [24] 1931 	ret
                                   1932 ;------------------------------------------------------------
                                   1933 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1934 ;------------------------------------------------------------
                                   1935 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1936 ;	-----------------------------------------
                                   1937 ;	 function rgb_matrix_get_sat
                                   1938 ;	-----------------------------------------
      00598A                       1939 _rgb_matrix_get_sat:
      00598A 90 06 F9         [24] 1940 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00598D E0               [24] 1941 	movx	a,@dptr
      00598E F5 82            [12] 1942 	mov	dpl,a
      005990 22               [24] 1943 	ret
                                   1944 ;------------------------------------------------------------
                                   1945 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function rgb_matrix_get_val
                                   1950 ;	-----------------------------------------
      005991                       1951 _rgb_matrix_get_val:
      005991 90 06 FA         [24] 1952 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005994 E0               [24] 1953 	movx	a,@dptr
      005995 F5 82            [12] 1954 	mov	dpl,a
      005997 22               [24] 1955 	ret
                                   1956 ;------------------------------------------------------------
                                   1957 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1958 ;------------------------------------------------------------
                                   1959 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1960 ;	-----------------------------------------
                                   1961 ;	 function rgb_matrix_get_speed
                                   1962 ;	-----------------------------------------
      005998                       1963 _rgb_matrix_get_speed:
      005998 90 06 FB         [24] 1964 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00599B E0               [24] 1965 	movx	a,@dptr
      00599C F5 82            [12] 1966 	mov	dpl,a
      00599E 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1970 ;------------------------------------------------------------
                                   1971 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1972 ;	-----------------------------------------
                                   1973 ;	 function rgb_matrix_toggle_noeeprom
                                   1974 ;	-----------------------------------------
      00599F                       1975 _rgb_matrix_toggle_noeeprom:
      00599F 12 5B 5A         [24] 1976 	lcall	_ak820_outline_0068
      0059A2 FF               [12] 1977 	mov	r7,a
      0059A3 63 07 01         [24] 1978 	xrl	ar7,#0x01
      0059A6 90 06 F7         [24] 1979 	mov	dptr,#_rgb_matrix_config
      0059A9 EF               [12] 1980 	mov	a,r7
      0059AA 54 03            [12] 1981 	anl	a,#0x03
      0059AC F5 F0            [12] 1982 	mov	b,a
      0059AE E0               [24] 1983 	movx	a,@dptr
      0059AF 54 FC            [12] 1984 	anl	a,#0xfc
      0059B1 45 F0            [12] 1985 	orl	a,b
      0059B3 F0               [24] 1986 	movx	@dptr,a
                                   1987 ;	assignBit
      0059B4 C2 14            [12] 1988 	clr	_rendering
      0059B6 02 53 DA         [24] 1989 	ljmp	_clear_reactive
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1992 ;------------------------------------------------------------
                                   1993 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1994 ;	-----------------------------------------
                                   1995 ;	 function rgb_matrix_enable_noeeprom
                                   1996 ;	-----------------------------------------
      0059B9                       1997 _rgb_matrix_enable_noeeprom:
      0059B9 12 5B 5A         [24] 1998 	lcall	_ak820_outline_0068
      0059BC 70 03            [24] 1999 	jnz	00102$
      0059BE 12 53 DA         [24] 2000 	lcall	_clear_reactive
      0059C1                       2001 00102$:
      0059C1 12 5B 81         [24] 2002 	lcall	_ak820_outline_0120
      0059C4 44 01            [12] 2003 	orl	a,#0x01
      0059C6 F0               [24] 2004 	movx	@dptr,a
                                   2005 ;	assignBit
      0059C7 C2 14            [12] 2006 	clr	_rendering
      0059C9 22               [24] 2007 	ret
                                   2008 ;------------------------------------------------------------
                                   2009 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2010 ;------------------------------------------------------------
                                   2011 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2012 ;	-----------------------------------------
                                   2013 ;	 function rgb_matrix_disable_noeeprom
                                   2014 ;	-----------------------------------------
      0059CA                       2015 _rgb_matrix_disable_noeeprom:
      0059CA 12 5B 81         [24] 2016 	lcall	_ak820_outline_0120
      0059CD F0               [24] 2017 	movx	@dptr,a
                                   2018 ;	assignBit
      0059CE C2 14            [12] 2019 	clr	_rendering
      0059D0 02 53 DA         [24] 2020 	ljmp	_clear_reactive
                                   2021 ;------------------------------------------------------------
                                   2022 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2023 ;------------------------------------------------------------
                                   2024 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2025 ;------------------------------------------------------------
                                   2026 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2027 ;	-----------------------------------------
                                   2028 ;	 function rgb_matrix_mode_noeeprom
                                   2029 ;	-----------------------------------------
      0059D3                       2030 _rgb_matrix_mode_noeeprom:
      0059D3 E5 82            [12] 2031 	mov	a,dpl
      0059D5 90 07 7B         [24] 2032 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0059D8 F0               [24] 2033 	movx	@dptr,a
                                   2034 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      0059D9 E0               [24] 2035 	movx	a,@dptr
      0059DA FF               [12] 2036 	mov	r7,a
      0059DB 60 05            [24] 2037 	jz	00101$
      0059DD BF 07 00         [24] 2038 	cjne	r7,#0x07,00123$
      0059E0                       2039 00123$:
      0059E0 40 01            [24] 2040 	jc	00102$
      0059E2                       2041 00101$:
      0059E2 22               [24] 2042 	ret
      0059E3                       2043 00102$:
                                   2044 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      0059E3 12 5B 3B         [24] 2045 	lcall	_ak820_outline_0021
      0059E6 FE               [12] 2046 	mov	r6,a
      0059E7 EF               [12] 2047 	mov	a,r7
      0059E8 B5 06 02         [24] 2048 	cjne	a,ar6,00125$
      0059EB 80 03            [24] 2049 	sjmp	00105$
      0059ED                       2050 00125$:
      0059ED 12 53 DA         [24] 2051 	lcall	_clear_reactive
      0059F0                       2052 00105$:
                                   2053 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      0059F0 90 07 7B         [24] 2054 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0059F3 E0               [24] 2055 	movx	a,@dptr
      0059F4 90 06 F7         [24] 2056 	mov	dptr,#_rgb_matrix_config
      0059F7 25 E0            [12] 2057 	add	a,acc
      0059F9 25 E0            [12] 2058 	add	a,acc
      0059FB 54 FC            [12] 2059 	anl	a,#0xfc
      0059FD F5 F0            [12] 2060 	mov	b,a
      0059FF E0               [24] 2061 	movx	a,@dptr
      005A00 54 03            [12] 2062 	anl	a,#0x03
      005A02 45 F0            [12] 2063 	orl	a,b
      005A04 F0               [24] 2064 	movx	@dptr,a
                                   2065 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2066 ;	assignBit
      005A05 C2 14            [12] 2067 	clr	_rendering
                                   2068 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005A07 22               [24] 2069 	ret
                                   2070 ;------------------------------------------------------------
                                   2071 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2072 ;------------------------------------------------------------
                                   2073 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2074 ;	-----------------------------------------
                                   2075 ;	 function rgb_matrix_step_noeeprom
                                   2076 ;	-----------------------------------------
      005A08                       2077 _rgb_matrix_step_noeeprom:
                                   2078 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005A08 12 5B 3B         [24] 2079 	lcall	_ak820_outline_0021
      005A0B FF               [12] 2080 	mov	r7,a
      005A0C 0F               [12] 2081 	inc	r7
      005A0D BF 07 00         [24] 2082 	cjne	r7,#0x07,00112$
      005A10                       2083 00112$:
      005A10 40 04            [24] 2084 	jc	00103$
      005A12 7F 01            [12] 2085 	mov	r7,#0x01
      005A14 80 07            [24] 2086 	sjmp	00104$
      005A16                       2087 00103$:
      005A16 12 5B 3B         [24] 2088 	lcall	_ak820_outline_0021
      005A19 FE               [12] 2089 	mov	r6,a
      005A1A 0E               [12] 2090 	inc	r6
      005A1B 8E 07            [24] 2091 	mov	ar7,r6
      005A1D                       2092 00104$:
      005A1D 8F 82            [24] 2093 	mov	dpl, r7
                                   2094 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005A1F 21 D3            [12] 2095 	ajmp	_rgb_matrix_mode_noeeprom
                                   2096 ;------------------------------------------------------------
                                   2097 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2098 ;------------------------------------------------------------
                                   2099 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2100 ;	-----------------------------------------
                                   2101 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2102 ;	-----------------------------------------
      005A21                       2103 _rgb_matrix_step_reverse_noeeprom:
                                   2104 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005A21 12 5B 3B         [24] 2105 	lcall	_ak820_outline_0021
      005A24 24 FE            [12] 2106 	add	a,#0xff - 0x01
      005A26 40 04            [24] 2107 	jc	00103$
                                   2108 ;	free result
      005A28 7F 06            [12] 2109 	mov	r7,#0x06
      005A2A 80 05            [24] 2110 	sjmp	00104$
      005A2C                       2111 00103$:
      005A2C 12 5B 3B         [24] 2112 	lcall	_ak820_outline_0021
      005A2F 14               [12] 2113 	dec	a
      005A30 FF               [12] 2114 	mov	r7,a
      005A31                       2115 00104$:
      005A31 8F 82            [24] 2116 	mov	dpl, r7
                                   2117 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005A33 21 D3            [12] 2118 	ajmp	_rgb_matrix_mode_noeeprom
                                   2119 ;------------------------------------------------------------
                                   2120 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2121 ;------------------------------------------------------------
                                   2122 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2123 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2124 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2125 ;------------------------------------------------------------
                                   2126 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2127 ;	-----------------------------------------
                                   2128 ;	 function rgb_matrix_sethsv_noeeprom
                                   2129 ;	-----------------------------------------
      005A35                       2130 _rgb_matrix_sethsv_noeeprom:
      005A35 12 38 8A         [24] 2131 	lcall	_ak820_outline_0108
      005A38 90 07 7E         [24] 2132 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005A3B 12 38 8F         [24] 2133 	lcall	_ak820_outline_0109
                                   2134 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005A3E 90 07 7E         [24] 2135 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005A41 E0               [24] 2136 	movx	a,@dptr
      005A42 90 06 F8         [24] 2137 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A45 F0               [24] 2138 	movx	@dptr,a
                                   2139 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005A46 90 07 7C         [24] 2140 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005A49 E0               [24] 2141 	movx	a,@dptr
      005A4A FF               [12] 2142 	mov	r7,a
      005A4B 90 06 F9         [24] 2143 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A4E F0               [24] 2144 	movx	@dptr,a
                                   2145 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005A4F 90 07 7D         [24] 2146 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005A52 E0               [24] 2147 	movx	a,@dptr
      005A53 FF               [12] 2148 	mov  r7,a
      005A54 24 5F            [12] 2149 	add	a,#0xff - 0xa0
      005A56 50 04            [24] 2150 	jnc	00103$
                                   2151 ;	free result
      005A58 7E A0            [12] 2152 	mov	r6,#0xa0
      005A5A 80 02            [24] 2153 	sjmp	00104$
      005A5C                       2154 00103$:
      005A5C 8F 06            [24] 2155 	mov	ar6,r7
      005A5E                       2156 00104$:
      005A5E 90 06 FA         [24] 2157 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005A61 EE               [12] 2158 	mov	a,r6
      005A62 F0               [24] 2159 	movx	@dptr,a
                                   2160 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005A63 22               [24] 2161 	ret
                                   2162 ;------------------------------------------------------------
                                   2163 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2164 ;------------------------------------------------------------
                                   2165 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2166 ;------------------------------------------------------------
                                   2167 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2168 ;	-----------------------------------------
                                   2169 ;	 function rgb_matrix_set_speed_noeeprom
                                   2170 ;	-----------------------------------------
      005A64                       2171 _rgb_matrix_set_speed_noeeprom:
      005A64 E5 82            [12] 2172 	mov	a,dpl
      005A66 90 07 80         [24] 2173 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005A69 F0               [24] 2174 	movx	@dptr,a
      005A6A E0               [24] 2175 	movx	a,@dptr
      005A6B 90 06 FB         [24] 2176 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005A6E F0               [24] 2177 	movx	@dptr,a
      005A6F 22               [24] 2178 	ret
                                   2179 ;------------------------------------------------------------
                                   2180 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2181 ;------------------------------------------------------------
                                   2182 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2183 ;------------------------------------------------------------
                                   2184 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2185 ;	-----------------------------------------
                                   2186 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2187 ;	-----------------------------------------
      005A70                       2188 _rgb_matrix_increase_hue_noeeprom:
      005A70 90 06 F8         [24] 2189 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A73 E0               [24] 2190 	movx	a,@dptr
      005A74 24 08            [12] 2191 	add	a,#0x08
      005A76 90 06 F8         [24] 2192 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A79 F0               [24] 2193 	movx	@dptr,a
      005A7A 22               [24] 2194 	ret
                                   2195 ;------------------------------------------------------------
                                   2196 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2197 ;------------------------------------------------------------
                                   2198 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2199 ;	-----------------------------------------
                                   2200 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2201 ;	-----------------------------------------
      005A7B                       2202 _rgb_matrix_decrease_hue_noeeprom:
      005A7B 90 06 F8         [24] 2203 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A7E E0               [24] 2204 	movx	a,@dptr
      005A7F 24 F8            [12] 2205 	add	a,#0xf8
      005A81 90 06 F8         [24] 2206 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A84 F0               [24] 2207 	movx	@dptr,a
      005A85 22               [24] 2208 	ret
                                   2209 ;------------------------------------------------------------
                                   2210 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2211 ;------------------------------------------------------------
                                   2212 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2213 ;	-----------------------------------------
                                   2214 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2215 ;	-----------------------------------------
      005A86                       2216 _rgb_matrix_increase_sat_noeeprom:
      005A86 90 06 F9         [24] 2217 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A89 12 5B 44         [24] 2218 	lcall	_ak820_outline_0050
      005A8C 12 54 72         [24] 2219 	lcall	_add_sat
      005A8F AF 82            [24] 2220 	mov	r7, dpl
      005A91 90 06 F9         [24] 2221 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A94 EF               [12] 2222 	mov	a,r7
      005A95 F0               [24] 2223 	movx	@dptr,a
      005A96 22               [24] 2224 	ret
                                   2225 ;------------------------------------------------------------
                                   2226 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2227 ;------------------------------------------------------------
                                   2228 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2229 ;	-----------------------------------------
                                   2230 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2231 ;	-----------------------------------------
      005A97                       2232 _rgb_matrix_decrease_sat_noeeprom:
      005A97 90 06 F9         [24] 2233 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A9A 12 5B 4F         [24] 2234 	lcall	_ak820_outline_0051
      005A9D 12 54 97         [24] 2235 	lcall	_sub_sat
      005AA0 AF 82            [24] 2236 	mov	r7, dpl
      005AA2 90 06 F9         [24] 2237 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AA5 EF               [12] 2238 	mov	a,r7
      005AA6 F0               [24] 2239 	movx	@dptr,a
      005AA7 22               [24] 2240 	ret
                                   2241 ;------------------------------------------------------------
                                   2242 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2243 ;------------------------------------------------------------
                                   2244 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2245 ;------------------------------------------------------------
                                   2246 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2247 ;	-----------------------------------------
                                   2248 ;	 function rgb_matrix_increase_val_noeeprom
                                   2249 ;	-----------------------------------------
      005AA8                       2250 _rgb_matrix_increase_val_noeeprom:
                                   2251 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005AA8 90 06 FA         [24] 2252 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AAB 12 5B 44         [24] 2253 	lcall	_ak820_outline_0050
      005AAE 12 54 72         [24] 2254 	lcall	_add_sat
                                   2255 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005AB1 E5 82            [12] 2256 	mov	a,dpl
      005AB3 FF               [12] 2257 	mov	r7,a
      005AB4 24 5F            [12] 2258 	add	a,#0xff - 0xa0
      005AB6 50 04            [24] 2259 	jnc	00103$
                                   2260 ;	free result
      005AB8 7E A0            [12] 2261 	mov	r6,#0xa0
      005ABA 80 02            [24] 2262 	sjmp	00104$
      005ABC                       2263 00103$:
      005ABC 8F 06            [24] 2264 	mov	ar6,r7
      005ABE                       2265 00104$:
      005ABE 90 06 FA         [24] 2266 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AC1 EE               [12] 2267 	mov	a,r6
      005AC2 F0               [24] 2268 	movx	@dptr,a
                                   2269 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005AC3 22               [24] 2270 	ret
                                   2271 ;------------------------------------------------------------
                                   2272 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2273 ;------------------------------------------------------------
                                   2274 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2275 ;	-----------------------------------------
                                   2276 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2277 ;	-----------------------------------------
      005AC4                       2278 _rgb_matrix_decrease_val_noeeprom:
      005AC4 90 06 FA         [24] 2279 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AC7 12 5B 4F         [24] 2280 	lcall	_ak820_outline_0051
      005ACA 12 54 97         [24] 2281 	lcall	_sub_sat
      005ACD AF 82            [24] 2282 	mov	r7, dpl
      005ACF 90 06 FA         [24] 2283 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AD2 EF               [12] 2284 	mov	a,r7
      005AD3 F0               [24] 2285 	movx	@dptr,a
      005AD4 22               [24] 2286 	ret
                                   2287 ;------------------------------------------------------------
                                   2288 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2289 ;------------------------------------------------------------
                                   2290 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2291 ;	-----------------------------------------
                                   2292 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2293 ;	-----------------------------------------
      005AD5                       2294 _rgb_matrix_increase_speed_noeeprom:
      005AD5 90 06 FB         [24] 2295 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AD8 12 5B 44         [24] 2296 	lcall	_ak820_outline_0050
      005ADB 12 54 72         [24] 2297 	lcall	_add_sat
      005ADE AF 82            [24] 2298 	mov	r7, dpl
      005AE0 90 06 FB         [24] 2299 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AE3 EF               [12] 2300 	mov	a,r7
      005AE4 F0               [24] 2301 	movx	@dptr,a
      005AE5 22               [24] 2302 	ret
                                   2303 ;------------------------------------------------------------
                                   2304 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2305 ;------------------------------------------------------------
                                   2306 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2307 ;	-----------------------------------------
                                   2308 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2309 ;	-----------------------------------------
      005AE6                       2310 _rgb_matrix_decrease_speed_noeeprom:
      005AE6 90 06 FB         [24] 2311 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AE9 12 5B 4F         [24] 2312 	lcall	_ak820_outline_0051
      005AEC 12 54 97         [24] 2313 	lcall	_sub_sat
      005AEF AF 82            [24] 2314 	mov	r7, dpl
      005AF1 90 06 FB         [24] 2315 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AF4 EF               [12] 2316 	mov	a,r7
      005AF5 F0               [24] 2317 	movx	@dptr,a
      005AF6 22               [24] 2318 	ret
                                   2319 ;------------------------------------------------------------
                                   2320 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2321 ;------------------------------------------------------------
                                   2322 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2323 ;	-----------------------------------------
                                   2324 ;	 function rgb_matrix_toggle
                                   2325 ;	-----------------------------------------
      005AF7                       2326 _rgb_matrix_toggle:
      005AF7 31 9F            [12] 2327 	acall	_rgb_matrix_toggle_noeeprom
      005AF9 02 54 B4         [24] 2328 	ljmp	_mark_dirty
                                   2329 ;------------------------------------------------------------
                                   2330 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2331 ;------------------------------------------------------------
                                   2332 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2333 ;	-----------------------------------------
                                   2334 ;	 function rgb_matrix_step
                                   2335 ;	-----------------------------------------
      005AFC                       2336 _rgb_matrix_step:
      005AFC 51 08            [12] 2337 	acall	_rgb_matrix_step_noeeprom
      005AFE 02 54 B4         [24] 2338 	ljmp	_mark_dirty
                                   2339 ;------------------------------------------------------------
                                   2340 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2341 ;------------------------------------------------------------
                                   2342 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2343 ;	-----------------------------------------
                                   2344 ;	 function rgb_matrix_step_reverse
                                   2345 ;	-----------------------------------------
      005B01                       2346 _rgb_matrix_step_reverse:
      005B01 51 21            [12] 2347 	acall	_rgb_matrix_step_reverse_noeeprom
      005B03 02 54 B4         [24] 2348 	ljmp	_mark_dirty
                                   2349 ;------------------------------------------------------------
                                   2350 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2351 ;------------------------------------------------------------
                                   2352 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2353 ;	-----------------------------------------
                                   2354 ;	 function rgb_matrix_increase_hue
                                   2355 ;	-----------------------------------------
      005B06                       2356 _rgb_matrix_increase_hue:
      005B06 51 70            [12] 2357 	acall	_rgb_matrix_increase_hue_noeeprom
      005B08 02 54 B4         [24] 2358 	ljmp	_mark_dirty
                                   2359 ;------------------------------------------------------------
                                   2360 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2361 ;------------------------------------------------------------
                                   2362 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2363 ;	-----------------------------------------
                                   2364 ;	 function rgb_matrix_decrease_hue
                                   2365 ;	-----------------------------------------
      005B0B                       2366 _rgb_matrix_decrease_hue:
      005B0B 51 7B            [12] 2367 	acall	_rgb_matrix_decrease_hue_noeeprom
      005B0D 02 54 B4         [24] 2368 	ljmp	_mark_dirty
                                   2369 ;------------------------------------------------------------
                                   2370 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2371 ;------------------------------------------------------------
                                   2372 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2373 ;	-----------------------------------------
                                   2374 ;	 function rgb_matrix_increase_sat
                                   2375 ;	-----------------------------------------
      005B10                       2376 _rgb_matrix_increase_sat:
      005B10 51 86            [12] 2377 	acall	_rgb_matrix_increase_sat_noeeprom
      005B12 02 54 B4         [24] 2378 	ljmp	_mark_dirty
                                   2379 ;------------------------------------------------------------
                                   2380 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2381 ;------------------------------------------------------------
                                   2382 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2383 ;	-----------------------------------------
                                   2384 ;	 function rgb_matrix_decrease_sat
                                   2385 ;	-----------------------------------------
      005B15                       2386 _rgb_matrix_decrease_sat:
      005B15 51 97            [12] 2387 	acall	_rgb_matrix_decrease_sat_noeeprom
      005B17 02 54 B4         [24] 2388 	ljmp	_mark_dirty
                                   2389 ;------------------------------------------------------------
                                   2390 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2391 ;------------------------------------------------------------
                                   2392 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2393 ;	-----------------------------------------
                                   2394 ;	 function rgb_matrix_increase_val
                                   2395 ;	-----------------------------------------
      005B1A                       2396 _rgb_matrix_increase_val:
      005B1A 51 A8            [12] 2397 	acall	_rgb_matrix_increase_val_noeeprom
      005B1C 02 54 B4         [24] 2398 	ljmp	_mark_dirty
                                   2399 ;------------------------------------------------------------
                                   2400 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2401 ;------------------------------------------------------------
                                   2402 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2403 ;	-----------------------------------------
                                   2404 ;	 function rgb_matrix_decrease_val
                                   2405 ;	-----------------------------------------
      005B1F                       2406 _rgb_matrix_decrease_val:
      005B1F 51 C4            [12] 2407 	acall	_rgb_matrix_decrease_val_noeeprom
      005B21 02 54 B4         [24] 2408 	ljmp	_mark_dirty
                                   2409 ;------------------------------------------------------------
                                   2410 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function rgb_matrix_increase_speed
                                   2415 ;	-----------------------------------------
      005B24                       2416 _rgb_matrix_increase_speed:
      005B24 51 D5            [12] 2417 	acall	_rgb_matrix_increase_speed_noeeprom
      005B26 02 54 B4         [24] 2418 	ljmp	_mark_dirty
                                   2419 ;------------------------------------------------------------
                                   2420 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function rgb_matrix_decrease_speed
                                   2425 ;	-----------------------------------------
      005B29                       2426 _rgb_matrix_decrease_speed:
      005B29 51 E6            [12] 2427 	acall	_rgb_matrix_decrease_speed_noeeprom
      005B2B 02 54 B4         [24] 2428 	ljmp	_mark_dirty
                                   2429 ;------------------------------------------------------------
                                   2430 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2431 ;------------------------------------------------------------
                                   2432 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2433 ;------------------------------------------------------------
                                   2434 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2435 ;	-----------------------------------------
                                   2436 ;	 function rgb_matrix_mode
                                   2437 ;	-----------------------------------------
      005B2E                       2438 _rgb_matrix_mode:
      005B2E E5 82            [12] 2439 	mov	a,dpl
      005B30 90 07 81         [24] 2440 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005B33 12 5B 8E         [24] 2441 	lcall	_ak820_outline_0174
      005B36 31 D3            [12] 2442 	acall	_rgb_matrix_mode_noeeprom
      005B38 02 54 B4         [24] 2443 	ljmp	_mark_dirty
                                   2444 ;------------------------------------------------------------
                                   2445 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2446 ;------------------------------------------------------------
                                   2447 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2448 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2449 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2450 ;------------------------------------------------------------
                                   2451 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2452 ;	-----------------------------------------
                                   2453 	.area CSEG    (CODE)
                                   2454 	.area CONST   (CODE)
                                   2455 	.area CONST   (CODE)
      00BF11                       2456 _sine8_coefficients_10000_290:
      00BF11 00                    2457 	.db #0x00	; 0
      00BF12 31                    2458 	.db #0x31	; 49	'1'
      00BF13 31                    2459 	.db #0x31	; 49	'1'
      00BF14 29                    2460 	.db #0x29	; 41
      00BF15 5A                    2461 	.db #0x5a	; 90	'Z'
      00BF16 1B                    2462 	.db #0x1b	; 27
      00BF17 75                    2463 	.db #0x75	; 117	'u'
      00BF18 0A                    2464 	.db #0x0a	; 10
                                   2465 	.area CSEG    (CODE)
                                   2466 	.area XINIT   (CODE)
                                   2467 	.area CABS    (ABS,CODE)
                                   2468 
                                   2469 ; Experimental exact instruction outlining.
                                   2470 	.globl _ak820_outline_0005
                                   2471 	.globl _ak820_outline_0021
                                   2472 	.globl _ak820_outline_0050
                                   2473 	.globl _ak820_outline_0051
                                   2474 	.globl _ak820_outline_0054
                                   2475 	.globl _ak820_outline_0060
                                   2476 	.globl _ak820_outline_0061
                                   2477 	.globl _ak820_outline_0064
                                   2478 	.globl _ak820_outline_0068
                                   2479 	.globl _ak820_outline_0072
                                   2480 	.globl _ak820_outline_0074
                                   2481 	.globl _ak820_outline_0086
                                   2482 	.globl _ak820_outline_0103
                                   2483 	.globl _ak820_outline_0108
                                   2484 	.globl _ak820_outline_0109
                                   2485 	.globl _ak820_outline_0114
                                   2486 	.globl _ak820_outline_0115
                                   2487 	.globl _ak820_outline_0120
                                   2488 	.globl _ak820_outline_0127
                                   2489 	.globl _ak820_outline_0128
                                   2490 	.globl _ak820_outline_0136
                                   2491 	.globl _ak820_outline_0137
                                   2492 	.globl _ak820_outline_0143
                                   2493 	.globl _ak820_outline_0144
                                   2494 	.globl _ak820_outline_0154
                                   2495 	.globl _ak820_outline_0174
                                   2496 	.globl _ak820_outline_0177
                                   2497 	.globl _ak820_outline_0183
                                   2498 	.globl _ak820_outline_0189
                                   2499 	.globl _ak820_outline_0191
                                   2500 	.globl _ak820_outline_0195
                                   2501 
                                   2502 	.area CSEG (CODE)
                                   2503 ; function ak820_outline_0021
      005B3B                       2504 _ak820_outline_0021:
      005B3B 90 06 F7         [24] 2505 	mov	dptr,#_rgb_matrix_config
      005B3E E0               [24] 2506 	movx	a,@dptr
      005B3F 03               [12] 2507 	rr	a
      005B40 03               [12] 2508 	rr	a
      005B41 54 3F            [12] 2509 	anl	a,#0x3f
      005B43 22               [24] 2510 	ret
                                   2511 
                                   2512 	.area CSEG (CODE)
                                   2513 ; function ak820_outline_0050
      005B44                       2514 _ak820_outline_0050:
      005B44 E0               [24] 2515 	movx	a,@dptr
      005B45 FF               [12] 2516 	mov	r7,a
      005B46 90 07 60         [24] 2517 	mov	dptr,#_add_sat_PARM_2
      005B49 74 10            [12] 2518 	mov	a,#0x10
      005B4B F0               [24] 2519 	movx	@dptr,a
      005B4C 8F 82            [24] 2520 	mov	dpl,r7
      005B4E 22               [24] 2521 	ret
                                   2522 
                                   2523 	.area CSEG (CODE)
                                   2524 ; function ak820_outline_0051
      005B4F                       2525 _ak820_outline_0051:
      005B4F E0               [24] 2526 	movx	a,@dptr
      005B50 FF               [12] 2527 	mov	r7,a
      005B51 90 07 62         [24] 2528 	mov	dptr,#_sub_sat_PARM_2
      005B54 74 10            [12] 2529 	mov	a,#0x10
      005B56 F0               [24] 2530 	movx	@dptr,a
      005B57 8F 82            [24] 2531 	mov	dpl,r7
      005B59 22               [24] 2532 	ret
                                   2533 
                                   2534 	.area CSEG (CODE)
                                   2535 ; function ak820_outline_0068
      005B5A                       2536 _ak820_outline_0068:
      005B5A 90 06 F7         [24] 2537 	mov	dptr,#_rgb_matrix_config
      005B5D E0               [24] 2538 	movx	a,@dptr
      005B5E 54 03            [12] 2539 	anl	a,#0x03
      005B60 22               [24] 2540 	ret
                                   2541 
                                   2542 	.area CSEG (CODE)
                                   2543 ; function ak820_outline_0072
      005B61                       2544 _ak820_outline_0072:
      005B61 74 08            [12] 2545 	mov	a,#0x08
      005B63 F0               [24] 2546 	movx	@dptr,a
      005B64 E4               [12] 2547 	clr	a
      005B65 A3               [24] 2548 	inc	dptr
      005B66 F0               [24] 2549 	movx	@dptr,a
      005B67 90 06 F7         [24] 2550 	mov	dptr,#_rgb_matrix_config
      005B6A 22               [24] 2551 	ret
                                   2552 
                                   2553 	.area CSEG (CODE)
                                   2554 ; function ak820_outline_0074
      005B6B                       2555 _ak820_outline_0074:
      005B6B A3               [24] 2556 	inc	dptr
      005B6C F0               [24] 2557 	movx	@dptr,a
      005B6D E4               [12] 2558 	clr	a
      005B6E A3               [24] 2559 	inc	dptr
      005B6F F0               [24] 2560 	movx	@dptr,a
      005B70 90 0D E5         [24] 2561 	mov	dptr,#___memcpy_PARM_3
      005B73 74 03            [12] 2562 	mov	a,#0x03
      005B75 F0               [24] 2563 	movx	@dptr,a
      005B76 E4               [12] 2564 	clr	a
      005B77 A3               [24] 2565 	inc	dptr
      005B78 F0               [24] 2566 	movx	@dptr,a
      005B79 22               [24] 2567 	ret
                                   2568 
                                   2569 	.area CSEG (CODE)
                                   2570 ; function ak820_outline_0114
      005B7A                       2571 _ak820_outline_0114:
      005B7A 35 F0            [12] 2572 	addc	a,b
      005B7C F5 83            [12] 2573 	mov	dph,a
      005B7E E4               [12] 2574 	clr	a
      005B7F 93               [24] 2575 	movc	a,@a+dptr
      005B80 22               [24] 2576 	ret
                                   2577 
                                   2578 	.area CSEG (CODE)
                                   2579 ; function ak820_outline_0120
      005B81                       2580 _ak820_outline_0120:
      005B81 90 06 F7         [24] 2581 	mov	dptr,#_rgb_matrix_config
      005B84 E0               [24] 2582 	movx	a,@dptr
      005B85 54 FC            [12] 2583 	anl	a,#0xfc
      005B87 22               [24] 2584 	ret
                                   2585 
                                   2586 	.area CSEG (CODE)
                                   2587 ; function ak820_outline_0143
      005B88                       2588 _ak820_outline_0143:
      005B88 90 07 06         [24] 2589 	mov	dptr,#_frame_mode
      005B8B E0               [24] 2590 	movx	a,@dptr
      005B8C FE               [12] 2591 	mov	r6,a
      005B8D 22               [24] 2592 	ret
                                   2593 
                                   2594 	.area CSEG (CODE)
                                   2595 ; function ak820_outline_0174
      005B8E                       2596 _ak820_outline_0174:
      005B8E F0               [24] 2597 	movx	@dptr,a
      005B8F E0               [24] 2598 	movx	a,@dptr
      005B90 F5 82            [12] 2599 	mov	dpl,a
      005B92 22               [24] 2600 	ret
                                   2601 
                                   2602 	.area CSEG (CODE)
                                   2603 ; function ak820_outline_0177
      005B93                       2604 _ak820_outline_0177:
      005B93 90 06 FB         [24] 2605 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005B96 E0               [24] 2606 	movx	a,@dptr
      005B97 23               [12] 2607 	rl	a
      005B98 23               [12] 2608 	rl	a
      005B99 54 03            [12] 2609 	anl	a,#0x03
      005B9B 22               [24] 2610 	ret
                                   2611 
                                   2612 	.area CSEG (CODE)
                                   2613 ; function ak820_outline_0183
      005B9C                       2614 _ak820_outline_0183:
      005B9C 90 0D EA         [24] 2615 	mov	dptr,#_memset_PARM_2
      005B9F E4               [12] 2616 	clr	a
      005BA0 F0               [24] 2617 	movx	@dptr,a
      005BA1 90 0D EB         [24] 2618 	mov	dptr,#_memset_PARM_3
      005BA4 22               [24] 2619 	ret
                                   2620 
                                   2621 	.area CSEG (CODE)
                                   2622 ; function ak820_outline_0189
      005BA5                       2623 _ak820_outline_0189:
      005BA5 90 07 05         [24] 2624 	mov	dptr,#_led_index
      005BA8 E0               [24] 2625 	movx	a,@dptr
      005BA9 22               [24] 2626 	ret
                                   2627 
                                   2628 	.area CSEG (CODE)
                                   2629 ; function ak820_outline_0191
      005BAA                       2630 _ak820_outline_0191:
      005BAA C4               [12] 2631 	swap	a
      005BAB 23               [12] 2632 	rl	a
      005BAC 54 1F            [12] 2633 	anl	a,#0x1f
      005BAE 22               [24] 2634 	ret
