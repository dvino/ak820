                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_tapping_term
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_mods
                                     14 	.globl _add_owned_mods
                                     15 	.globl _send_keyboard_report
                                     16 	.globl _layer_hold_off
                                     17 	.globl _layer_hold_on
                                     18 	.globl _unregister_mods
                                     19 	.globl _register_mods
                                     20 	.globl _process_record
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_oneshot_target
                                    265 	.globl _ak820_oneshot_process_PARM_3
                                    266 	.globl _ak820_oneshot_process_PARM_2
                                    267 	.globl _ak820_oneshot_consumed
                                    268 	.globl _ak820_oneshot_mods
                                    269 	.globl _ak820_tapping_source_PARM_1
                                    270 	.globl _ak820_tapping_source
                                    271 	.globl _ak820_tapping_before
                                    272 	.globl _ak820_tapping_process
                                    273 	.globl _ak820_tapping_cancel
                                    274 	.globl _ak820_oneshot_process
                                    275 ;--------------------------------------------------------
                                    276 ; special function registers
                                    277 ;--------------------------------------------------------
                                    278 	.area RSEG    (ABS,DATA)
      000000                        279 	.org 0x0000
                           0000D0   280 _PSW	=	0x00d0
                           0000E0   281 _ACC	=	0x00e0
                           0000F0   282 _B	=	0x00f0
                           0000FD   283 _A_INV	=	0x00fd
                           000081   284 _SP	=	0x0081
                           000082   285 _DPL	=	0x0082
                           000083   286 _DPH	=	0x0083
                           0000A1   287 _SAFE_MOD	=	0x00a1
                           0000B1   288 _GLOBAL_CFG	=	0x00b1
                           000087   289 _PCON	=	0x0087
                           0000BA   290 _POWER_CFG	=	0x00ba
                           0000B9   291 _CLOCK_CFG	=	0x00b9
                           0000A9   292 _WAKE_CTRL	=	0x00a9
                           0000FE   293 _RESET_KEEP	=	0x00fe
                           0000FF   294 _WDOG_COUNT	=	0x00ff
                           0000A8   295 _IE	=	0x00a8
                           0000B8   296 _IP	=	0x00b8
                           0000E8   297 _IE_EX	=	0x00e8
                           0000E9   298 _IP_EX	=	0x00e9
                           0000B2   299 _GPIO_IE	=	0x00b2
                           008584   300 _ROM_ADDR	=	0x8584
                           000084   301 _ROM_ADDR_L	=	0x0084
                           000085   302 _ROM_ADDR_H	=	0x0085
                           008F8E   303 _ROM_DATA_HI	=	0x8f8e
                           00008E   304 _ROM_DATA_HL	=	0x008e
                           00008F   305 _ROM_DATA_HH	=	0x008f
                           000086   306 _ROM_CTRL	=	0x0086
                           000080   307 _P0	=	0x0080
                           0000C4   308 _P0_MOD_OC	=	0x00c4
                           0000C5   309 _P0_DIR_PU	=	0x00c5
                           000090   310 _P1	=	0x0090
                           000092   311 _P1_MOD_OC	=	0x0092
                           000093   312 _P1_DIR_PU	=	0x0093
                           0000A0   313 _P2	=	0x00a0
                           000094   314 _P2_MOD_OC	=	0x0094
                           000095   315 _P2_DIR_PU	=	0x0095
                           0000B0   316 _P3	=	0x00b0
                           000096   317 _P3_MOD_OC	=	0x0096
                           000097   318 _P3_DIR_PU	=	0x0097
                           0000C0   319 _P4	=	0x00c0
                           0000C2   320 _P4_MOD_OC	=	0x00c2
                           0000C3   321 _P4_DIR_PU	=	0x00c3
                           0000C1   322 _P4_LED_KEY	=	0x00c1
                           0000AA   323 _P5_IN	=	0x00aa
                           0000AB   324 _P5_OUT_PU	=	0x00ab
                           0000AC   325 _P5_DIR	=	0x00ac
                           0000AD   326 _P6_IN	=	0x00ad
                           0000AE   327 _P6_OUT_PU	=	0x00ae
                           0000AF   328 _P6_DIR	=	0x00af
                           0000F1   329 _P7	=	0x00f1
                           0000A2   330 _XBUS_AUX	=	0x00a2
                           000088   331 _TCON	=	0x0088
                           000089   332 _TMOD	=	0x0089
                           00008A   333 _TL0	=	0x008a
                           00008B   334 _TL1	=	0x008b
                           00008C   335 _TH0	=	0x008c
                           00008D   336 _TH1	=	0x008d
                           000098   337 _SCON	=	0x0098
                           000099   338 _SBUF	=	0x0099
                           0000C8   339 _T2CON	=	0x00c8
                           0000C9   340 _T2MOD	=	0x00c9
                           00CBCA   341 _RCAP2	=	0xcbca
                           0000CA   342 _RCAP2L	=	0x00ca
                           0000CB   343 _RCAP2H	=	0x00cb
                           00CDCC   344 _T2COUNT	=	0xcdcc
                           0000CC   345 _TL2	=	0x00cc
                           0000CD   346 _TH2	=	0x00cd
                           00CFCE   347 _T2CAP1	=	0xcfce
                           0000CE   348 _T2CAP1L	=	0x00ce
                           0000CF   349 _T2CAP1H	=	0x00cf
                           0000F8   350 _SPI0_STAT	=	0x00f8
                           0000F9   351 _SPI0_DATA	=	0x00f9
                           0000FA   352 _SPI0_CTRL	=	0x00fa
                           0000FB   353 _SPI0_CK_SE	=	0x00fb
                           0000FC   354 _SPI0_SETUP	=	0x00fc
                           0000BC   355 _SCON1	=	0x00bc
                           0000BD   356 _SBUF1	=	0x00bd
                           0000BE   357 _SBAUD1	=	0x00be
                           0000BF   358 _SIF1	=	0x00bf
                           0000B4   359 _SPI1_STAT	=	0x00b4
                           0000B5   360 _SPI1_DATA	=	0x00b5
                           0000B6   361 _SPI1_CTRL	=	0x00b6
                           0000B7   362 _SPI1_CK_SE	=	0x00b7
                           0000F3   363 _ADC_CTRL	=	0x00f3
                           00F5F4   364 _ADC_DAT	=	0xf5f4
                           0000F4   365 _ADC_DAT_L	=	0x00f4
                           0000F5   366 _ADC_DAT_H	=	0x00f5
                           0000F6   367 _ADC_CHAN	=	0x00f6
                           0000A6   368 _LED_COMMON	=	0x00a6
                           0000A7   369 _LED_PWM_OE	=	0x00a7
                           00C7C6   370 _LED_DMA	=	0xc7c6
                           0000C6   371 _LED_DMA_L	=	0x00c6
                           0000C7   372 _LED_DMA_H	=	0x00c7
                           0000F7   373 _LED_STATUS	=	0x00f7
                           0000B3   374 _I2CX_INT	=	0x00b3
                           0000BB   375 _I2CS_INT_ST	=	0x00bb
                                    376 ;--------------------------------------------------------
                                    377 ; special function bits
                                    378 ;--------------------------------------------------------
                                    379 	.area RSEG    (ABS,DATA)
      000000                        380 	.org 0x0000
                           0000D7   381 _CY	=	0x00d7
                           0000D6   382 _AC	=	0x00d6
                           0000D5   383 _F0	=	0x00d5
                           0000D4   384 _RS1	=	0x00d4
                           0000D3   385 _RS0	=	0x00d3
                           0000D2   386 _OV	=	0x00d2
                           0000D1   387 _F1	=	0x00d1
                           0000D0   388 _P	=	0x00d0
                           0000AF   389 _EA	=	0x00af
                           0000AE   390 _E_DIS	=	0x00ae
                           0000AD   391 _ET2	=	0x00ad
                           0000AC   392 _ES	=	0x00ac
                           0000AB   393 _ET1	=	0x00ab
                           0000AA   394 _EX1	=	0x00aa
                           0000A9   395 _ET0	=	0x00a9
                           0000A8   396 _EX0	=	0x00a8
                           0000BF   397 _PH_FLAG	=	0x00bf
                           0000BE   398 _PL_FLAG	=	0x00be
                           0000BD   399 _PT2	=	0x00bd
                           0000BC   400 _PS	=	0x00bc
                           0000BB   401 _PT1	=	0x00bb
                           0000BA   402 _PX1	=	0x00ba
                           0000B9   403 _PT0	=	0x00b9
                           0000B8   404 _PX0	=	0x00b8
                           0000EF   405 _IE_WDOG	=	0x00ef
                           0000EE   406 _IE_GPIO	=	0x00ee
                           0000ED   407 _IE_PWM_I2C	=	0x00ed
                           0000EC   408 _IE_UART1	=	0x00ec
                           0000EB   409 _IE_ADC	=	0x00eb
                           0000E9   410 _IE_USB	=	0x00e9
                           0000E8   411 _IE_SPI0	=	0x00e8
                           000087   412 _P0_7	=	0x0087
                           000086   413 _P0_6	=	0x0086
                           000085   414 _P0_5	=	0x0085
                           000084   415 _P0_4	=	0x0084
                           000083   416 _P0_3	=	0x0083
                           000082   417 _P0_2	=	0x0082
                           000081   418 _P0_1	=	0x0081
                           000080   419 _P0_0	=	0x0080
                           000081   420 _SDA0	=	0x0081
                           000080   421 _SCL0	=	0x0080
                           000083   422 _TXD_	=	0x0083
                           000082   423 _RXD_	=	0x0082
                           000085   424 _AIN13	=	0x0085
                           000084   425 _AIN12	=	0x0084
                           000083   426 _AIN11	=	0x0083
                           000082   427 _AIN10	=	0x0082
                           000081   428 _AIN9	=	0x0081
                           000080   429 _AIN8	=	0x0080
                           000097   430 _P1_7	=	0x0097
                           000096   431 _P1_6	=	0x0096
                           000095   432 _P1_5	=	0x0095
                           000094   433 _P1_4	=	0x0094
                           000093   434 _P1_3	=	0x0093
                           000092   435 _P1_2	=	0x0092
                           000091   436 _P1_1	=	0x0091
                           000090   437 _P1_0	=	0x0090
                           000097   438 _TXD1_	=	0x0097
                           000096   439 _RXD1_	=	0x0096
                           000097   440 _SCK	=	0x0097
                           000096   441 _MISO	=	0x0096
                           000095   442 _MOSI	=	0x0095
                           000094   443 _SCS	=	0x0094
                           000092   444 _INT0_	=	0x0092
                           000091   445 _T2EX	=	0x0091
                           000091   446 _CAP2	=	0x0091
                           000090   447 _T2	=	0x0090
                           000090   448 _CAP1	=	0x0090
                           000097   449 _AIN7	=	0x0097
                           000096   450 _AIN6	=	0x0096
                           000095   451 _AIN5	=	0x0095
                           000094   452 _AIN4	=	0x0094
                           000093   453 _AIN3	=	0x0093
                           000092   454 _AIN2	=	0x0092
                           000091   455 _AIN1	=	0x0091
                           000090   456 _AIN0	=	0x0090
                           0000A7   457 _P2_7	=	0x00a7
                           0000A6   458 _P2_6	=	0x00a6
                           0000A5   459 _P2_5	=	0x00a5
                           0000A4   460 _P2_4	=	0x00a4
                           0000A3   461 _P2_3	=	0x00a3
                           0000A2   462 _P2_2	=	0x00a2
                           0000A1   463 _P2_1	=	0x00a1
                           0000A0   464 _P2_0	=	0x00a0
                           0000A7   465 _TXD1	=	0x00a7
                           0000A6   466 _RXD1	=	0x00a6
                           0000A5   467 _T2EX_	=	0x00a5
                           0000A5   468 _CAP2_	=	0x00a5
                           0000A4   469 _T2_	=	0x00a4
                           0000A4   470 _CAP1_	=	0x00a4
                           0000B7   471 _P3_7	=	0x00b7
                           0000B6   472 _P3_6	=	0x00b6
                           0000B5   473 _P3_5	=	0x00b5
                           0000B4   474 _P3_4	=	0x00b4
                           0000B3   475 _P3_3	=	0x00b3
                           0000B2   476 _P3_2	=	0x00b2
                           0000B1   477 _P3_1	=	0x00b1
                           0000B0   478 _P3_0	=	0x00b0
                           0000B7   479 _SCK1	=	0x00b7
                           0000B6   480 _MISO1	=	0x00b6
                           0000B5   481 _MOSI1	=	0x00b5
                           0000B5   482 _T1	=	0x00b5
                           0000B4   483 _T0	=	0x00b4
                           0000B3   484 _INT1	=	0x00b3
                           0000B2   485 _INT0	=	0x00b2
                           0000B1   486 _TXD	=	0x00b1
                           0000B0   487 _RXD	=	0x00b0
                           0000C6   488 _P4_6	=	0x00c6
                           0000C5   489 _P4_5	=	0x00c5
                           0000C4   490 _P4_4	=	0x00c4
                           0000C3   491 _P4_3	=	0x00c3
                           0000C2   492 _P4_2	=	0x00c2
                           0000C1   493 _P4_1	=	0x00c1
                           0000C0   494 _P4_0	=	0x00c0
                           00008F   495 _TF1	=	0x008f
                           00008E   496 _TR1	=	0x008e
                           00008D   497 _TF0	=	0x008d
                           00008C   498 _TR0	=	0x008c
                           00008B   499 _IE1	=	0x008b
                           00008A   500 _IT1	=	0x008a
                           000089   501 _IE0	=	0x0089
                           000088   502 _IT0	=	0x0088
                           00009F   503 _SM0	=	0x009f
                           00009E   504 _SM1	=	0x009e
                           00009D   505 _SM2	=	0x009d
                           00009C   506 _REN	=	0x009c
                           00009B   507 _TB8	=	0x009b
                           00009A   508 _RB8	=	0x009a
                           000099   509 _TI	=	0x0099
                           000098   510 _RI	=	0x0098
                           0000CF   511 _TF2	=	0x00cf
                           0000CF   512 _CAP1F	=	0x00cf
                           0000CE   513 _EXF2	=	0x00ce
                           0000CD   514 _RCLK	=	0x00cd
                           0000CC   515 _TCLK	=	0x00cc
                           0000CB   516 _EXEN2	=	0x00cb
                           0000CA   517 _TR2	=	0x00ca
                           0000C9   518 _C_T2	=	0x00c9
                           0000C8   519 _CP_RL2	=	0x00c8
                           0000FF   520 _S0_FST_ACT	=	0x00ff
                           0000FE   521 _S0_IF_OV	=	0x00fe
                           0000FD   522 _S0_IF_FIRST	=	0x00fd
                           0000FC   523 _S0_IF_BYTE	=	0x00fc
                           0000FB   524 _S0_FREE	=	0x00fb
                           0000FA   525 _S0_T_FIFO	=	0x00fa
                           0000F8   526 _S0_R_FIFO	=	0x00f8
                           0000F7   527 _ADC_START	=	0x00f7
                                    528 ;--------------------------------------------------------
                                    529 ; overlayable register banks
                                    530 ;--------------------------------------------------------
                                    531 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        532 	.ds 8
                                    533 ;--------------------------------------------------------
                                    534 ; internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area DSEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; overlayable items in internal ram
                                    539 ;--------------------------------------------------------
                                    540 ;--------------------------------------------------------
                                    541 ; indirectly addressable internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area ISEG    (DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; absolute internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area IABS    (ABS,DATA)
                                    548 	.area IABS    (ABS,DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; bit data
                                    551 ;--------------------------------------------------------
                                    552 	.area BSEG    (BIT)
      00000F                        553 _ak820_tapping_before_sloc0_1_0:
      00000F                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; paged external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area PSEG    (PAG,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; uninitialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XSEG    (XDATA)
      0005EA                        563 _source_state:
      0005EA                        564 	.ds 130
      00066C                        565 _pending_time:
      00066C                        566 	.ds 2
      00066E                        567 _pending_code:
      00066E                        568 	.ds 2
      000670                        569 _ak820_tapping_source_PARM_1:
      000670                        570 	.ds 2
      000672                        571 _hold_PARM_2:
      000672                        572 	.ds 1
      000673                        573 _hold_code_10000_625:
      000673                        574 	.ds 2
      000675                        575 _hold_mods_30000_628:
      000675                        576 	.ds 1
      000676                        577 _commit_pending_id_10000_634:
      000676                        578 	.ds 1
      000677                        579 _ak820_tapping_before_event_10000_635:
      000677                        580 	.ds 2
      000679                        581 _ak820_tapping_process_record_10000_646:
      000679                        582 	.ds 2
      00067B                        583 _ak820_tapping_process_code_10000_647:
      00067B                        584 	.ds 2
      00067D                        585 _ak820_tapping_process_sc_mods_10000_647:
      00067D                        586 	.ds 1
      00067E                        587 _ak820_oneshot_mods::
      00067E                        588 	.ds 1
      00067F                        589 _ak820_oneshot_consumed::
      00067F                        590 	.ds 1
      000680                        591 _ak820_oneshot_process_PARM_2:
      000680                        592 	.ds 1
      000681                        593 _ak820_oneshot_process_PARM_3:
      000681                        594 	.ds 1
      000682                        595 _ak820_oneshot_process_code_10000_672:
      000682                        596 	.ds 2
      000684                        597 _ak820_oneshot_process_mods_10000_673:
      000684                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; absolute external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XABS    (ABS,XDATA)
                                    603 ;--------------------------------------------------------
                                    604 ; initialized external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XISEG   (XDATA)
      000DFA                        607 _pending:
      000DFA                        608 	.ds 1
      000DFB                        609 _ak820_oneshot_target::
      000DFB                        610 	.ds 1
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function ak820_tapping_source
                                    653 ;	-----------------------------------------
      004841                        654 _ak820_tapping_source:
                                    655 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004841 90 06 71         [24]  656 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004844 E0               [24]  657 	movx	a,@dptr
      004845 FF               [12]  658 	mov	r7,a
      004846 BF 10 00         [24]  659 	cjne	r7,#0x10,00147$
      004849                        660 00147$:
      004849 50 14            [24]  661 	jnc	00102$
      00484B 90 06 70         [24]  662 	mov	dptr,#_ak820_tapping_source_PARM_1
      00484E E0               [24]  663 	movx	a,@dptr
      00484F FE               [12]  664 	mov	r6,a
      004850 BE 08 00         [24]  665 	cjne	r6,#0x08,00149$
      004853                        666 00149$:
      004853 50 0A            [24]  667 	jnc	00102$
      004855 8F 05            [24]  668 	mov	ar5,r7
      004857 ED               [12]  669 	mov	a,r5
      004858 12 38 C7         [24]  670 	lcall	_ak820_outline_0195
      00485B 2E               [12]  671 	add	a,r6
      00485C F5 82            [12]  672 	mov	dpl,a
      00485E 22               [24]  673 	ret
      00485F                        674 00102$:
                                    675 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      00485F 90 06 70         [24]  676 	mov	dptr,#_ak820_tapping_source_PARM_1
      004862 E0               [24]  677 	movx	a,@dptr
      004863 FE               [12]  678 	mov	r6,a
      004864 BE 01 00         [24]  679 	cjne	r6,#0x01,00151$
      004867                        680 00151$:
      004867 50 0E            [24]  681 	jnc	00109$
                                    682 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004869 BF FD 04         [24]  683 	cjne	r7,#0xfd,00105$
      00486C 75 82 80         [24]  684 	mov	dpl, #0x80
      00486F 22               [24]  685 	ret
      004870                        686 00105$:
                                    687 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004870 BF FC 04         [24]  688 	cjne	r7,#0xfc,00109$
      004873 75 82 81         [24]  689 	mov	dpl, #0x81
      004876 22               [24]  690 	ret
      004877                        691 00109$:
                                    692 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004877 75 82 FF         [24]  693 	mov	dpl, #0xff
                                    694 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00487A 22               [24]  695 	ret
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'hold'
                                    698 ;------------------------------------------------------------
                                    699 ;pressed       Allocated with name '_hold_PARM_2'
                                    700 ;code          Allocated with name '_hold_code_10000_625'
                                    701 ;mods          Allocated with name '_hold_mods_30000_628'
                                    702 ;layer         Allocated with name '_hold_layer_30000_631'
                                    703 ;------------------------------------------------------------
                                    704 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    705 ;	-----------------------------------------
                                    706 ;	 function hold
                                    707 ;	-----------------------------------------
      00487B                        708 _hold:
      00487B 12 38 8A         [24]  709 	lcall	_ak820_outline_0108
      00487E 90 06 73         [24]  710 	mov	dptr,#_hold_code_10000_625
      004881 12 38 8F         [24]  711 	lcall	_ak820_outline_0109
                                    712 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004884 90 06 73         [24]  713 	mov	dptr,#_hold_code_10000_625
      004887 12 4C E3         [24]  714 	lcall	_ak820_outline_0010
      00488A 74 C0            [12]  715 	mov	a,#0x100 - 0x40
      00488C 2D               [12]  716 	add	a,r5
      00488D 40 2E            [24]  717 	jc	00110$
                                    718 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      00488F 8F 05            [24]  719 	mov	ar5,r7
      004891 53 05 1F         [24]  720 	anl	ar5,#0x1f
      004894 90 06 75         [24]  721 	mov	dptr,#_hold_mods_30000_628
      004897 ED               [12]  722 	mov	a,r5
      004898 F0               [24]  723 	movx	@dptr,a
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004899 ED               [12]  725 	mov	a,r5
      00489A 30 E4 08         [24]  726 	jnb	acc.4,00102$
      00489D ED               [12]  727 	mov	a,r5
      00489E C4               [12]  728 	swap	a
      00489F 54 F0            [12]  729 	anl	a,#0xf0
      0048A1 90 06 75         [24]  730 	mov	dptr,#_hold_mods_30000_628
      0048A4 F0               [24]  731 	movx	@dptr,a
      0048A5                        732 00102$:
                                    733 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0048A5 90 06 72         [24]  734 	mov	dptr,#_hold_PARM_2
      0048A8 E0               [24]  735 	movx	a,@dptr
      0048A9 60 09            [24]  736 	jz	00104$
      0048AB 90 06 75         [24]  737 	mov	dptr,#_hold_mods_30000_628
      0048AE E0               [24]  738 	movx	a,@dptr
      0048AF F5 82            [12]  739 	mov	dpl,a
      0048B1 02 7A 48         [24]  740 	ljmp	_register_mods
      0048B4                        741 00104$:
                                    742 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0048B4 90 06 75         [24]  743 	mov	dptr,#_hold_mods_30000_628
      0048B7 E0               [24]  744 	movx	a,@dptr
      0048B8 F5 82            [12]  745 	mov	dpl,a
      0048BA 02 7A 5C         [24]  746 	ljmp	_unregister_mods
      0048BD                        747 00110$:
                                    748 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      0048BD 8F 06            [24]  749 	mov	ar6,r7
      0048BF 74 0F            [12]  750 	mov	a,#0x0f
      0048C1 5E               [12]  751 	anl	a,r6
      0048C2 FF               [12]  752 	mov	r7,a
                                    753 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      0048C3 90 06 72         [24]  754 	mov	dptr,#_hold_PARM_2
      0048C6 E0               [24]  755 	movx	a,@dptr
      0048C7 60 05            [24]  756 	jz	00107$
      0048C9 8F 82            [24]  757 	mov	dpl, r7
      0048CB 02 7C 01         [24]  758 	ljmp	_layer_hold_on
      0048CE                        759 00107$:
                                    760 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0048CE 8F 82            [24]  761 	mov	dpl, r7
                                    762 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0048D0 02 7C 37         [24]  763 	ljmp	_layer_hold_off
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'commit_pending'
                                    766 ;------------------------------------------------------------
                                    767 ;id            Allocated with name '_commit_pending_id_10000_634'
                                    768 ;------------------------------------------------------------
                                    769 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function commit_pending
                                    772 ;	-----------------------------------------
      0048D3                        773 _commit_pending:
                                    774 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0048D3 90 0D FA         [24]  775 	mov	dptr,#_pending
      0048D6 E0               [24]  776 	movx	a,@dptr
      0048D7 90 06 76         [24]  777 	mov	dptr,#_commit_pending_id_10000_634
      0048DA F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0048DB 12 4D 55         [24]  780 	lcall	_ak820_outline_0160
                                    781 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0048DE 90 06 76         [24]  782 	mov	dptr,#_commit_pending_id_10000_634
      0048E1 E0               [24]  783 	movx	a,@dptr
      0048E2 24 EA            [12]  784 	add	a,#_source_state
      0048E4 FF               [12]  785 	mov	r7,a
      0048E5 E4               [12]  786 	clr	a
      0048E6 34 05            [12]  787 	addc	a, #(_source_state >> 8)
      0048E8 FE               [12]  788 	mov	r6,a
      0048E9 12 43 78         [24]  789 	lcall	_ak820_outline_0161
      0048EC E0               [24]  790 	movx	a,@dptr
      0048ED FD               [12]  791 	mov	r5,a
      0048EE 43 05 04         [24]  792 	orl	ar5,#0x04
      0048F1 12 43 78         [24]  793 	lcall	_ak820_outline_0161
      0048F4 ED               [12]  794 	mov	a,r5
      0048F5 F0               [24]  795 	movx	@dptr,a
                                    796 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      0048F6 90 06 6E         [24]  797 	mov	dptr,#_pending_code
      0048F9 12 38 36         [24]  798 	lcall	_ak820_outline_0054
      0048FC 90 06 72         [24]  799 	mov	dptr,#_hold_PARM_2
      0048FF 74 01            [12]  800 	mov	a,#0x01
      004901 12 43 35         [24]  801 	lcall	_ak820_outline_0062
                                    802 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004904 01 7B            [12]  803 	ajmp	_hold
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    806 ;------------------------------------------------------------
                                    807 ;event         Allocated with name '_ak820_tapping_before_event_10000_635'
                                    808 ;id            Allocated with name '_ak820_tapping_before_id_10000_636'
                                    809 ;------------------------------------------------------------
                                    810 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function ak820_tapping_before
                                    813 ;	-----------------------------------------
      004906                        814 _ak820_tapping_before:
      004906 12 38 8A         [24]  815 	lcall	_ak820_outline_0108
      004909 90 06 77         [24]  816 	mov	dptr,#_ak820_tapping_before_event_10000_635
      00490C 12 38 8F         [24]  817 	lcall	_ak820_outline_0109
                                    818 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      00490F 90 06 77         [24]  819 	mov	dptr,#_ak820_tapping_before_event_10000_635
      004912 12 4C E3         [24]  820 	lcall	_ak820_outline_0010
      004915 12 4D 12         [24]  821 	lcall	_ak820_outline_0025
      004918 C0 07            [24]  822 	push	ar7
      00491A C0 06            [24]  823 	push	ar6
      00491C 12 BC AA         [24]  824 	lcall	___memcpy
      00491F 11 41            [12]  825 	acall	_ak820_tapping_source
      004921 AD 82            [24]  826 	mov	r5, dpl
      004923 D0 06            [24]  827 	pop	ar6
      004925 D0 07            [24]  828 	pop	ar7
                                    829 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004927 90 0E 6B         [24]  830 	mov	dptr,#_vial_unlock_in_progress
      00492A E0               [24]  831 	movx	a,@dptr
      00492B 60 29            [24]  832 	jz	00106$
                                    833 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00492D 74 04            [12]  834 	mov	a,#0x04
      00492F 12 4C ED         [24]  835 	lcall	_ak820_outline_0012
      004932 60 1E            [24]  836 	jz	00102$
      004934 BD FF 02         [24]  837 	cjne	r5,#0xff,00218$
      004937 80 19            [24]  838 	sjmp	00102$
      004939                        839 00218$:
      004939 74 05            [12]  840 	mov	a,#0x05
      00493B 12 4C ED         [24]  841 	lcall	_ak820_outline_0012
      00493E 70 12            [24]  842 	jnz	00102$
      004940 ED               [12]  843 	mov	a,r5
      004941 24 EA            [12]  844 	add	a, #_source_state
      004943 FB               [12]  845 	mov	r3,a
      004944 E4               [12]  846 	clr	a
      004945 34 05            [12]  847 	addc	a, #(_source_state >> 8)
      004947 12 4D 2C         [24]  848 	lcall	_ak820_outline_0058
      00494A 53 02 FD         [24]  849 	anl	ar2,#0xfd
      00494D 12 33 FC         [24]  850 	lcall	_ak820_outline_0126
      004950 EA               [12]  851 	mov	a,r2
      004951 F0               [24]  852 	movx	@dptr,a
      004952                        853 00102$:
                                    854 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004952 75 82 00         [24]  855 	mov	dpl, #0x00
      004955 22               [24]  856 	ret
      004956                        857 00106$:
                                    858 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004956 90 0D FA         [24]  859 	mov	dptr,#_pending
      004959 E0               [24]  860 	movx	a,@dptr
      00495A FC               [12]  861 	mov	r4,a
      00495B BC FF 02         [24]  862 	cjne	r4,#0xff,00220$
      00495E 80 59            [24]  863 	sjmp	00108$
      004960                        864 00220$:
      004960 12 38 2E         [24]  865 	lcall	_ak820_outline_0036
      004963 FB               [12]  866 	mov	r3,a
      004964 A3               [24]  867 	inc	dptr
      004965 E0               [24]  868 	movx	a,@dptr
      004966 FC               [12]  869 	mov	r4,a
      004967 90 06 6C         [24]  870 	mov	dptr,#_pending_time
      00496A E0               [24]  871 	movx	a,@dptr
      00496B F9               [12]  872 	mov	r1,a
      00496C A3               [24]  873 	inc	dptr
      00496D E0               [24]  874 	movx	a,@dptr
      00496E FA               [12]  875 	mov	r2,a
      00496F EB               [12]  876 	mov	a,r3
      004970 C3               [12]  877 	clr	c
      004971 99               [12]  878 	subb	a,r1
      004972 FB               [12]  879 	mov	r3,a
      004973 EC               [12]  880 	mov	a,r4
      004974 9A               [12]  881 	subb	a,r2
      004975 FC               [12]  882 	mov	r4,a
      004976 C0 07            [24]  883 	push	ar7
      004978 C0 06            [24]  884 	push	ar6
      00497A C0 05            [24]  885 	push	ar5
      00497C C0 04            [24]  886 	push	ar4
      00497E C0 03            [24]  887 	push	ar3
      004980 12 47 DC         [24]  888 	lcall	_ak820_settings_tapping_term
      004983 12 4D 5C         [24]  889 	lcall	_ak820_outline_0190
      004986 D0 03            [24]  890 	pop	ar3
      004988 D0 04            [24]  891 	pop	ar4
      00498A D0 05            [24]  892 	pop	ar5
      00498C D0 06            [24]  893 	pop	ar6
      00498E D0 07            [24]  894 	pop	ar7
      004990 C3               [12]  895 	clr	c
      004991 EB               [12]  896 	mov	a,r3
      004992 99               [12]  897 	subb	a,r1
      004993 EC               [12]  898 	mov	a,r4
      004994 9A               [12]  899 	subb	a,r2
      004995 50 1C            [24]  900 	jnc	00107$
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004997 74 04            [12]  902 	mov	a,#0x04
      004999 12 4C ED         [24]  903 	lcall	_ak820_outline_0012
      00499C 60 1B            [24]  904 	jz	00108$
      00499E 12 38 07         [24]  905 	lcall	_ak820_outline_0011
      0049A1 60 16            [24]  906 	jz	00108$
      0049A3 BD FF 02         [24]  907 	cjne	r5,#0xff,00224$
      0049A6 80 0B            [24]  908 	sjmp	00107$
      0049A8                        909 00224$:
      0049A8 90 0D FA         [24]  910 	mov	dptr,#_pending
      0049AB E0               [24]  911 	movx	a,@dptr
      0049AC FF               [12]  912 	mov	r7,a
      0049AD ED               [12]  913 	mov	a,r5
      0049AE B5 07 02         [24]  914 	cjne	a,ar7,00225$
      0049B1 80 06            [24]  915 	sjmp	00108$
      0049B3                        916 00225$:
      0049B3                        917 00107$:
      0049B3 C0 05            [24]  918 	push	ar5
      0049B5 11 D3            [12]  919 	acall	_commit_pending
      0049B7 D0 05            [24]  920 	pop	ar5
      0049B9                        921 00108$:
                                    922 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0049B9 90 06 77         [24]  923 	mov	dptr,#_ak820_tapping_before_event_10000_635
      0049BC 12 38 36         [24]  924 	lcall	_ak820_outline_0054
      0049BF 74 04            [12]  925 	mov	a,#0x04
      0049C1 12 4C ED         [24]  926 	lcall	_ak820_outline_0012
      0049C4 60 03            [24]  927 	jz	00114$
      0049C6 BD FF 04         [24]  928 	cjne	r5,#0xff,00115$
      0049C9                        929 00114$:
      0049C9 75 82 01         [24]  930 	mov	dpl, #0x01
      0049CC 22               [24]  931 	ret
      0049CD                        932 00115$:
                                    933 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0049CD ED               [12]  934 	mov	a,r5
      0049CE 12 4D 41         [24]  935 	lcall	_ak820_outline_0080
      0049D1 30 E1 13         [24]  936 	jnb	acc.1,00120$
                                    937 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0049D4 74 05            [12]  938 	mov	a,#0x05
      0049D6 2E               [12]  939 	add	a, r6
      0049D7 12 38 14         [24]  940 	lcall	_ak820_outline_0015
      0049DA 70 07            [24]  941 	jnz	00118$
      0049DC 74 FD            [12]  942 	mov	a,#0xfd
      0049DE 5B               [12]  943 	anl	a,r3
      0049DF 12 38 99         [24]  944 	lcall	_ak820_outline_0127
      0049E2 F0               [24]  945 	movx	@dptr,a
      0049E3                        946 00118$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      0049E3 75 82 00         [24]  948 	mov	dpl, #0x00
      0049E6 22               [24]  949 	ret
      0049E7                        950 00120$:
                                    951 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      0049E7 12 42 FF         [24]  952 	lcall	_ak820_outline_0009
      0049EA E0               [24]  953 	movx	a,@dptr
      0049EB FF               [12]  954 	mov	r7,a
      0049EC 8B 06            [24]  955 	mov	ar6,r3
      0049EE 53 06 01         [24]  956 	anl	ar6,#0x01
      0049F1 EE               [12]  957 	mov	a,r6
      0049F2 B4 01 00         [24]  958 	cjne	a,#0x01,00231$
      0049F5                        959 00231$:
      0049F5 B3               [12]  960 	cpl	c
      0049F6 92 0F            [24]  961 	mov	_ak820_tapping_before_sloc0_1_0,c
      0049F8 8F F0            [24]  962 	mov	b,r7
      0049FA E4               [12]  963 	clr	a
      0049FB 33               [12]  964 	rlc	a
      0049FC B5 F0 04         [24]  965 	cjne	a,b,00122$
      0049FF 75 82 00         [24]  966 	mov	dpl, #0x00
      004A02 22               [24]  967 	ret
      004A03                        968 00122$:
                                    969 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004A03 63 03 01         [24]  970 	xrl	ar3,#0x01
      004A06 12 38 99         [24]  971 	lcall	_ak820_outline_0127
      004A09 EB               [12]  972 	mov	a,r3
      004A0A F0               [24]  973 	movx	@dptr,a
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004A0B 75 82 01         [24]  975 	mov	dpl, #0x01
                                    976 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004A0E 22               [24]  977 	ret
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    980 ;------------------------------------------------------------
                                    981 ;record        Allocated with name '_ak820_tapping_process_record_10000_646'
                                    982 ;id            Allocated with name '_ak820_tapping_process_id_10000_647'
                                    983 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_647'
                                    984 ;code          Allocated with name '_ak820_tapping_process_code_10000_647'
                                    985 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_647'
                                    986 ;------------------------------------------------------------
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    988 ;	-----------------------------------------
                                    989 ;	 function ak820_tapping_process
                                    990 ;	-----------------------------------------
      004A0F                        991 _ak820_tapping_process:
      004A0F 12 38 8A         [24]  992 	lcall	_ak820_outline_0108
      004A12 90 06 79         [24]  993 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004A15 12 38 8F         [24]  994 	lcall	_ak820_outline_0109
                                    995 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004A18 90 06 7D         [24]  996 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004A1B E4               [12]  997 	clr	a
      004A1C F0               [24]  998 	movx	@dptr,a
                                    999 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004A1D 90 06 79         [24] 1000 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004A20 12 38 36         [24] 1001 	lcall	_ak820_outline_0054
      004A23 74 04            [12] 1002 	mov	a,#0x04
      004A25 12 4C F8         [24] 1003 	lcall	_ak820_outline_0018
      004A28 70 04            [24] 1004 	jnz	00102$
      004A2A 75 82 01         [24] 1005 	mov	dpl, #0x01
      004A2D 22               [24] 1006 	ret
      004A2E                       1007 00102$:
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004A2E 8E 04            [24] 1009 	mov	ar4,r6
      004A30 8F 05            [24] 1010 	mov	ar5,r7
      004A32 12 4D 12         [24] 1011 	lcall	_ak820_outline_0025
      004A35 C0 07            [24] 1012 	push	ar7
      004A37 C0 06            [24] 1013 	push	ar6
      004A39 12 BC AA         [24] 1014 	lcall	___memcpy
      004A3C 11 41            [12] 1015 	acall	_ak820_tapping_source
      004A3E AD 82            [24] 1016 	mov	r5, dpl
      004A40 D0 06            [24] 1017 	pop	ar6
      004A42 D0 07            [24] 1018 	pop	ar7
                                   1019 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004A44 BD FF 04         [24] 1020 	cjne	r5,#0xff,00104$
      004A47 75 82 01         [24] 1021 	mov	dpl, #0x01
      004A4A 22               [24] 1022 	ret
      004A4B                       1023 00104$:
                                   1024 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004A4B 74 07            [12] 1025 	mov	a,#0x07
      004A4D 12 38 26         [24] 1026 	lcall	_ak820_outline_0020
      004A50 12 38 36         [24] 1027 	lcall	_ak820_outline_0054
      004A53 90 06 7B         [24] 1028 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A56 12 4D 34         [24] 1029 	lcall	_ak820_outline_0061
                                   1030 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004A59 BE 1A 15         [24] 1031 	cjne	r6,#0x1a,00111$
      004A5C BF 7C 12         [24] 1032 	cjne	r7,#0x7c,00111$
      004A5F 90 06 7B         [24] 1033 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A62 74 26            [12] 1034 	mov	a,#0x26
      004A64 F0               [24] 1035 	movx	@dptr,a
      004A65 74 22            [12] 1036 	mov	a,#0x22
      004A67 A3               [24] 1037 	inc	dptr
      004A68 F0               [24] 1038 	movx	@dptr,a
      004A69 90 06 7D         [24] 1039 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004A6C 74 02            [12] 1040 	mov	a,#0x02
      004A6E F0               [24] 1041 	movx	@dptr,a
      004A6F 80 28            [24] 1042 	sjmp	00112$
      004A71                       1043 00111$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004A71 BE 1B 15         [24] 1045 	cjne	r6,#0x1b,00108$
      004A74 BF 7C 12         [24] 1046 	cjne	r7,#0x7c,00108$
      004A77 90 06 7B         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A7A 74 27            [12] 1048 	mov	a,#0x27
      004A7C F0               [24] 1049 	movx	@dptr,a
      004A7D 74 32            [12] 1050 	mov	a,#0x32
      004A7F A3               [24] 1051 	inc	dptr
      004A80 F0               [24] 1052 	movx	@dptr,a
      004A81 90 06 7D         [24] 1053 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004A84 74 20            [12] 1054 	mov	a,#0x20
      004A86 F0               [24] 1055 	movx	@dptr,a
      004A87 80 10            [24] 1056 	sjmp	00112$
      004A89                       1057 00108$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004A89 BE 1E 0D         [24] 1059 	cjne	r6,#0x1e,00112$
      004A8C BF 7C 0A         [24] 1060 	cjne	r7,#0x7c,00112$
      004A8F 90 06 7B         [24] 1061 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A92 74 28            [12] 1062 	mov	a,#0x28
      004A94 F0               [24] 1063 	movx	@dptr,a
      004A95 74 32            [12] 1064 	mov	a,#0x32
      004A97 A3               [24] 1065 	inc	dptr
      004A98 F0               [24] 1066 	movx	@dptr,a
      004A99                       1067 00112$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004A99 90 06 7B         [24] 1069 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A9C E0               [24] 1070 	movx	a,@dptr
      004A9D A3               [24] 1071 	inc	dptr
      004A9E E0               [24] 1072 	movx	a,@dptr
      004A9F FF               [12] 1073 	mov	r7,a
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004AA0 BF 20 00         [24] 1075 	cjne	r7,#0x20,00242$
      004AA3                       1076 00242$:
      004AA3 40 05            [24] 1077 	jc	00113$
      004AA5 BF 50 00         [24] 1078 	cjne	r7,#0x50,00244$
      004AA8                       1079 00244$:
      004AA8 40 04            [24] 1080 	jc	00114$
      004AAA                       1081 00113$:
      004AAA 75 82 01         [24] 1082 	mov	dpl, #0x01
      004AAD 22               [24] 1083 	ret
      004AAE                       1084 00114$:
                                   1085 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004AAE BF 40 00         [24] 1086 	cjne	r7,#0x40,00246$
      004AB1                       1087 00246$:
      004AB1 40 0C            [24] 1088 	jc	00117$
      004AB3 53 07 0F         [24] 1089 	anl	ar7,#0x0f
      004AB6 BF 06 00         [24] 1090 	cjne	r7,#0x06,00248$
      004AB9                       1091 00248$:
      004AB9 40 04            [24] 1092 	jc	00117$
      004ABB 75 82 00         [24] 1093 	mov	dpl, #0x00
      004ABE 22               [24] 1094 	ret
      004ABF                       1095 00117$:
                                   1096 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004ABF 90 06 79         [24] 1097 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004AC2 12 38 36         [24] 1098 	lcall	_ak820_outline_0054
      004AC5 74 05            [12] 1099 	mov	a,#0x05
      004AC7 12 4C ED         [24] 1100 	lcall	_ak820_outline_0012
      004ACA 60 1E            [24] 1101 	jz	00131$
                                   1102 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004ACC 90 0D FA         [24] 1103 	mov	dptr,#_pending
      004ACF ED               [12] 1104 	mov	a,r5
      004AD0 12 43 09         [24] 1105 	lcall	_ak820_outline_0033
                                   1106 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004AD3 12 38 36         [24] 1107 	lcall	_ak820_outline_0054
      004AD6 90 06 6C         [24] 1108 	mov	dptr,#_pending_time
      004AD9 12 4D 34         [24] 1109 	lcall	_ak820_outline_0061
                                   1110 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004ADC 90 06 7B         [24] 1111 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004ADF 12 38 36         [24] 1112 	lcall	_ak820_outline_0054
      004AE2 90 06 6E         [24] 1113 	mov	dptr,#_pending_code
      004AE5 12 4D 34         [24] 1114 	lcall	_ak820_outline_0061
      004AE8 61 86            [12] 1115 	ajmp	00132$
      004AEA                       1116 00131$:
                                   1117 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004AEA 90 0D FA         [24] 1118 	mov	dptr,#_pending
      004AED E0               [24] 1119 	movx	a,@dptr
      004AEE FF               [12] 1120 	mov	r7,a
      004AEF ED               [12] 1121 	mov	a,r5
      004AF0 B5 07 02         [24] 1122 	cjne	a,ar7,00251$
      004AF3 80 02            [24] 1123 	sjmp	00252$
      004AF5                       1124 00251$:
      004AF5 61 60            [12] 1125 	ajmp	00128$
      004AF7                       1126 00252$:
                                   1127 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004AF7 12 4D 55         [24] 1128 	lcall	_ak820_outline_0160
                                   1129 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004AFA 90 06 7D         [24] 1130 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004AFD E0               [24] 1131 	movx	a,@dptr
      004AFE FF               [12] 1132 	mov	r7,a
      004AFF E0               [24] 1133 	movx	a,@dptr
      004B00 60 05            [24] 1134 	jz	00120$
      004B02 8F 82            [24] 1135 	mov	dpl, r7
      004B04 12 80 71         [24] 1136 	lcall	_add_owned_mods
      004B07                       1137 00120$:
                                   1138 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004B07 90 06 79         [24] 1139 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004B0A 12 38 36         [24] 1140 	lcall	_ak820_outline_0054
      004B0D 74 07            [12] 1141 	mov	a,#0x07
      004B0F 2E               [12] 1142 	add	a, r6
      004B10 FB               [12] 1143 	mov	r3,a
      004B11 E4               [12] 1144 	clr	a
      004B12 3F               [12] 1145 	addc	a, r7
      004B13 FC               [12] 1146 	mov	r4,a
      004B14 90 06 7B         [24] 1147 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004B17 E0               [24] 1148 	movx	a,@dptr
      004B18 F9               [12] 1149 	mov	r1,a
      004B19 7A 00            [12] 1150 	mov	r2,#0x00
      004B1B 12 33 FC         [24] 1151 	lcall	_ak820_outline_0126
      004B1E 12 4D 4F         [24] 1152 	lcall	_ak820_outline_0140
                                   1153 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004B21 C3               [12] 1154 	clr	c
      004B22 04               [12] 1155 	inc	a
      004B23 99               [12] 1156 	subb	a,r1
      004B24 50 28            [24] 1157 	jnc	00122$
                                   1158 ;	free result
                                   1159 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004B26 74 06            [12] 1160 	mov	a,#0x06
      004B28 12 38 26         [24] 1161 	lcall	_ak820_outline_0020
      004B2B E0               [24] 1162 	movx	a,@dptr
      004B2C 54 0F            [12] 1163 	anl	a,#0x0f
      004B2E 44 10            [12] 1164 	orl	a,#0x10
      004B30 F0               [24] 1165 	movx	@dptr,a
                                   1166 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004B31 12 42 FF         [24] 1167 	lcall	_ak820_outline_0009
      004B34 74 01            [12] 1168 	mov	a,#0x01
      004B36 12 43 35         [24] 1169 	lcall	_ak820_outline_0062
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004B39 12 74 F6         [24] 1171 	lcall	_process_record
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004B3C 90 06 79         [24] 1173 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004B3F 12 37 E9         [24] 1174 	lcall	_ak820_outline_0005
      004B42 A3               [24] 1175 	inc	dptr
      004B43 A3               [24] 1176 	inc	dptr
      004B44 A3               [24] 1177 	inc	dptr
      004B45 A3               [24] 1178 	inc	dptr
      004B46 A3               [24] 1179 	inc	dptr
      004B47 E4               [12] 1180 	clr	a
      004B48 12 43 35         [24] 1181 	lcall	_ak820_outline_0062
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004B4B 12 74 F6         [24] 1183 	lcall	_process_record
      004B4E                       1184 00122$:
                                   1185 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004B4E 90 06 7D         [24] 1186 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004B51 E0               [24] 1187 	movx	a,@dptr
      004B52 FF               [12] 1188 	mov	r7,a
      004B53 E0               [24] 1189 	movx	a,@dptr
      004B54 60 30            [24] 1190 	jz	00132$
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004B56 8F 82            [24] 1192 	mov	dpl, r7
      004B58 12 80 81         [24] 1193 	lcall	_del_owned_mods
                                   1194 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004B5B 12 83 AA         [24] 1195 	lcall	_send_keyboard_report
      004B5E 80 26            [24] 1196 	sjmp	00132$
      004B60                       1197 00128$:
                                   1198 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004B60 ED               [12] 1199 	mov	a,r5
      004B61 24 EA            [12] 1200 	add	a, #_source_state
      004B63 FE               [12] 1201 	mov	r6,a
      004B64 E4               [12] 1202 	clr	a
      004B65 34 05            [12] 1203 	addc	a, #(_source_state >> 8)
      004B67 FF               [12] 1204 	mov	r7,a
      004B68 12 38 7E         [24] 1205 	lcall	_ak820_outline_0105
      004B6B FD               [12] 1206 	mov	r5,a
      004B6C 30 E2 17         [24] 1207 	jnb	acc.2,00132$
                                   1208 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004B6F 53 05 FB         [24] 1209 	anl	ar5,#0xfb
      004B72 12 38 94         [24] 1210 	lcall	_ak820_outline_0123
      004B75 ED               [12] 1211 	mov	a,r5
      004B76 F0               [24] 1212 	movx	@dptr,a
                                   1213 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004B77 90 06 7B         [24] 1214 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004B7A 12 38 36         [24] 1215 	lcall	_ak820_outline_0054
      004B7D 90 06 72         [24] 1216 	mov	dptr,#_hold_PARM_2
      004B80 E4               [12] 1217 	clr	a
      004B81 12 43 35         [24] 1218 	lcall	_ak820_outline_0062
      004B84 11 7B            [12] 1219 	acall	_hold
      004B86                       1220 00132$:
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004B86 75 82 00         [24] 1222 	mov	dpl, #0x00
                                   1223 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004B89 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1227 ;------------------------------------------------------------
                                   1228 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_670'
                                   1229 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_671'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function ak820_tapping_cancel
                                   1234 ;	-----------------------------------------
      004B8A                       1235 _ak820_tapping_cancel:
                                   1236 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004B8A 12 4D 55         [24] 1237 	lcall	_ak820_outline_0160
                                   1238 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004B8D 7F 00            [12] 1239 	mov	r7,#0x00
      004B8F                       1240 00103$:
      004B8F BF 82 00         [24] 1241 	cjne	r7,#0x82,00122$
      004B92                       1242 00122$:
      004B92 50 16            [24] 1243 	jnc	00105$
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004B94 12 4D 03         [24] 1245 	lcall	_ak820_outline_0022
                                   1246 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004B97 74 02            [12] 1247 	mov	a,#0x02
      004B99 5C               [12] 1248 	anl	a,r4
      004B9A FB               [12] 1249 	mov	r3,a
      004B9B 53 04 01         [24] 1250 	anl	ar4,#0x01
      004B9E EC               [12] 1251 	mov	a,r4
      004B9F 2C               [12] 1252 	add	a,r4
      004BA0 42 03            [12] 1253 	orl	ar3,a
      004BA2 12 38 A3         [24] 1254 	lcall	_ak820_outline_0137
      004BA5 EB               [12] 1255 	mov	a,r3
      004BA6 F0               [24] 1256 	movx	@dptr,a
                                   1257 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004BA7 0F               [12] 1258 	inc	r7
      004BA8 80 E5            [24] 1259 	sjmp	00103$
      004BAA                       1260 00105$:
                                   1261 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004BAA 22               [24] 1262 	ret
                                   1263 ;------------------------------------------------------------
                                   1264 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1265 ;------------------------------------------------------------
                                   1266 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1267 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1268 ;code          Allocated with name '_ak820_oneshot_process_code_10000_672'
                                   1269 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_673'
                                   1270 ;i             Allocated with name '_ak820_oneshot_process_i_40000_687'
                                   1271 ;------------------------------------------------------------
                                   1272 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1273 ;	-----------------------------------------
                                   1274 ;	 function ak820_oneshot_process
                                   1275 ;	-----------------------------------------
      004BAB                       1276 _ak820_oneshot_process:
      004BAB 12 38 8A         [24] 1277 	lcall	_ak820_outline_0108
      004BAE 90 06 82         [24] 1278 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004BB1 12 38 8F         [24] 1279 	lcall	_ak820_outline_0109
                                   1280 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004BB4 90 06 80         [24] 1281 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004BB7 E0               [24] 1282 	movx	a,@dptr
      004BB8 FF               [12] 1283 	mov	r7,a
      004BB9 BF FF 02         [24] 1284 	cjne	r7,#0xff,00248$
      004BBC 80 0B            [24] 1285 	sjmp	00101$
      004BBE                       1286 00248$:
      004BBE C0 07            [24] 1287 	push	ar7
      004BC0 12 A5 E0         [24] 1288 	lcall	_get_repeat_key_count
      004BC3 E5 82            [12] 1289 	mov	a, dpl
      004BC5 D0 07            [24] 1290 	pop	ar7
      004BC7 60 04            [24] 1291 	jz	00102$
      004BC9                       1292 00101$:
      004BC9 75 82 01         [24] 1293 	mov	dpl, #0x01
      004BCC 22               [24] 1294 	ret
      004BCD                       1295 00102$:
                                   1296 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004BCD 90 06 82         [24] 1297 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004BD0 E0               [24] 1298 	movx	a,@dptr
      004BD1 FD               [12] 1299 	mov	r5,a
      004BD2 A3               [24] 1300 	inc	dptr
      004BD3 E0               [24] 1301 	movx	a,@dptr
      004BD4 FB               [12] 1302 	mov	r3,a
      004BD5 BB 52 02         [24] 1303 	cjne	r3,#0x52,00250$
      004BD8 80 02            [24] 1304 	sjmp	00251$
      004BDA                       1305 00250$:
      004BDA 81 7D            [12] 1306 	ajmp	00116$
      004BDC                       1307 00251$:
      004BDC 8D 04            [24] 1308 	mov	ar4,r5
      004BDE 53 04 E0         [24] 1309 	anl	ar4,#0xe0
      004BE1 BC A0 02         [24] 1310 	cjne	r4,#0xa0,00252$
      004BE4 80 02            [24] 1311 	sjmp	00253$
      004BE6                       1312 00252$:
      004BE6 81 7D            [12] 1313 	ajmp	00116$
      004BE8                       1314 00253$:
                                   1315 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004BE8 8D 04            [24] 1316 	mov	ar4,r5
      004BEA 53 04 0F         [24] 1317 	anl	ar4,#0x0f
      004BED 90 06 84         [24] 1318 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004BF0 EC               [12] 1319 	mov	a,r4
      004BF1 F0               [24] 1320 	movx	@dptr,a
                                   1321 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004BF2 ED               [12] 1322 	mov	a,r5
      004BF3 30 E4 08         [24] 1323 	jnb	acc.4,00105$
      004BF6 EC               [12] 1324 	mov	a,r4
      004BF7 C4               [12] 1325 	swap	a
      004BF8 54 F0            [12] 1326 	anl	a,#0xf0
      004BFA 90 06 84         [24] 1327 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004BFD F0               [24] 1328 	movx	@dptr,a
      004BFE                       1329 00105$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004BFE 90 06 81         [24] 1331 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004C01 E0               [24] 1332 	movx	a,@dptr
      004C02 60 2D            [24] 1333 	jz	00113$
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004C04 12 4D 03         [24] 1335 	lcall	_ak820_outline_0022
      004C07 43 04 08         [24] 1336 	orl	ar4,#0x08
      004C0A 12 43 3B         [24] 1337 	lcall	_ak820_outline_0067
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004C0D 53 04 EF         [24] 1339 	anl	ar4,#0xef
      004C10 12 43 3B         [24] 1340 	lcall	_ak820_outline_0067
                                   1341 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004C13 90 0D FB         [24] 1342 	mov	dptr,#_ak820_oneshot_target
      004C16 E0               [24] 1343 	movx	a,@dptr
      004C17 FC               [12] 1344 	mov	r4,a
      004C18 BC FF 02         [24] 1345 	cjne	r4,#0xff,00256$
      004C1B 80 09            [24] 1346 	sjmp	00107$
      004C1D                       1347 00256$:
      004C1D 12 4D 3A         [24] 1348 	lcall	_ak820_outline_0077
      004C20 43 04 10         [24] 1349 	orl	ar4,#0x10
      004C23 12 43 3B         [24] 1350 	lcall	_ak820_outline_0067
      004C26                       1351 00107$:
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004C26 90 06 84         [24] 1353 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C29 E0               [24] 1354 	movx	a,@dptr
      004C2A F5 82            [12] 1355 	mov	dpl,a
      004C2C 12 7A 48         [24] 1356 	lcall	_register_mods
      004C2F 80 48            [24] 1357 	sjmp	00114$
      004C31                       1358 00113$:
                                   1359 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004C31 12 4D 03         [24] 1360 	lcall	_ak820_outline_0022
      004C34 30 E3 42         [24] 1361 	jnb	acc.3,00114$
                                   1362 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004C37 EC               [12] 1363 	mov	a,r4
      004C38 20 E4 24         [24] 1364 	jb	acc.4,00109$
                                   1365 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004C3B 90 06 7E         [24] 1366 	mov	dptr,#_ak820_oneshot_mods
      004C3E E0               [24] 1367 	movx	a,@dptr
      004C3F F4               [12] 1368 	cpl	a
      004C40 FC               [12] 1369 	mov	r4,a
      004C41 90 06 84         [24] 1370 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C44 E0               [24] 1371 	movx	a,@dptr
      004C45 FB               [12] 1372 	mov	r3,a
      004C46 52 04            [12] 1373 	anl	ar4,a
      004C48 8C 82            [24] 1374 	mov	dpl, r4
      004C4A C0 06            [24] 1375 	push	ar6
      004C4C C0 05            [24] 1376 	push	ar5
      004C4E C0 03            [24] 1377 	push	ar3
      004C50 12 80 71         [24] 1378 	lcall	_add_owned_mods
      004C53 D0 03            [24] 1379 	pop	ar3
      004C55 D0 05            [24] 1380 	pop	ar5
      004C57 D0 06            [24] 1381 	pop	ar6
                                   1382 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004C59 90 06 7E         [24] 1383 	mov	dptr,#_ak820_oneshot_mods
      004C5C E0               [24] 1384 	movx	a,@dptr
      004C5D 4B               [12] 1385 	orl	a,r3
      004C5E F0               [24] 1386 	movx	@dptr,a
      004C5F                       1387 00109$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004C5F 90 06 84         [24] 1389 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C62 E0               [24] 1390 	movx	a,@dptr
      004C63 F5 82            [12] 1391 	mov	dpl,a
      004C65 C0 06            [24] 1392 	push	ar6
      004C67 C0 05            [24] 1393 	push	ar5
      004C69 12 7A 5C         [24] 1394 	lcall	_unregister_mods
      004C6C D0 05            [24] 1395 	pop	ar5
      004C6E D0 06            [24] 1396 	pop	ar6
                                   1397 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004C70 12 4D 3A         [24] 1398 	lcall	_ak820_outline_0077
      004C73 53 04 E7         [24] 1399 	anl	ar4,#0xe7
      004C76 12 43 3B         [24] 1400 	lcall	_ak820_outline_0067
      004C79                       1401 00114$:
                                   1402 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004C79 75 82 00         [24] 1403 	mov	dpl, #0x00
      004C7C 22               [24] 1404 	ret
      004C7D                       1405 00116$:
                                   1406 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004C7D 90 06 81         [24] 1407 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004C80 E0               [24] 1408 	movx	a,@dptr
      004C81 60 5C            [24] 1409 	jz	00124$
      004C83 90 06 82         [24] 1410 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004C86 12 38 59         [24] 1411 	lcall	_ak820_outline_0079
      004C89 C3               [12] 1412 	clr	c
      004C8A 74 01            [12] 1413 	mov	a,#0x01
      004C8C 9D               [12] 1414 	subb	a,r5
      004C8D E4               [12] 1415 	clr	a
      004C8E 9E               [12] 1416 	subb	a,r6
      004C8F 50 4E            [24] 1417 	jnc	00124$
                                   1418 ;	free result
                                   1419 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004C91 C3               [12] 1420 	clr	c
      004C92 ED               [12] 1421 	mov	a,r5
      004C93 94 E0            [12] 1422 	subb	a,#0xe0
      004C95 EE               [12] 1423 	mov	a,r6
      004C96 94 00            [12] 1424 	subb	a,#0x00
      004C98 40 07            [24] 1425 	jc	00129$
      004C9A 74 E7            [12] 1426 	mov	a,#0xe7
      004C9C 9D               [12] 1427 	subb	a,r5
      004C9D E4               [12] 1428 	clr	a
      004C9E 9E               [12] 1429 	subb	a,r6
      004C9F 50 3E            [24] 1430 	jnc	00124$
                                   1431 ;	free result
      004CA1                       1432 00129$:
                                   1433 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004CA1 74 AE            [12] 1434 	mov	a,#0x100 - 0x52
      004CA3 2E               [12] 1435 	add	a,r6
      004CA4 50 09            [24] 1436 	jnc	00165$
      004CA6 C3               [12] 1437 	clr	c
      004CA7 74 DF            [12] 1438 	mov	a,#0xdf
      004CA9 9D               [12] 1439 	subb	a,r5
      004CAA 74 52            [12] 1440 	mov	a,#0x52
      004CAC 9E               [12] 1441 	subb	a,r6
      004CAD 50 30            [24] 1442 	jnc	00124$
                                   1443 ;	free result
                                   1444 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004CAF                       1445 00165$:
      004CAF 7E 00            [12] 1446 	mov	r6,#0x00
      004CB1                       1447 00131$:
      004CB1 BE 82 00         [24] 1448 	cjne	r6,#0x82,00265$
      004CB4                       1449 00265$:
      004CB4 50 12            [24] 1450 	jnc	00120$
                                   1451 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004CB6 EE               [12] 1452 	mov	a,r6
      004CB7 12 4D 41         [24] 1453 	lcall	_ak820_outline_0080
      004CBA 30 E3 08         [24] 1454 	jnb	acc.3,00132$
      004CBD 43 03 10         [24] 1455 	orl	ar3,#0x10
      004CC0 12 38 99         [24] 1456 	lcall	_ak820_outline_0127
      004CC3 EB               [12] 1457 	mov	a,r3
      004CC4 F0               [24] 1458 	movx	@dptr,a
      004CC5                       1459 00132$:
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004CC5 0E               [12] 1461 	inc	r6
      004CC6 80 E9            [24] 1462 	sjmp	00131$
      004CC8                       1463 00120$:
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004CC8 90 06 7E         [24] 1465 	mov	dptr,#_ak820_oneshot_mods
      004CCB E0               [24] 1466 	movx	a,@dptr
      004CCC FE               [12] 1467 	mov	r6,a
      004CCD E0               [24] 1468 	movx	a,@dptr
      004CCE 60 0F            [24] 1469 	jz	00124$
                                   1470 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004CD0 90 06 7F         [24] 1471 	mov	dptr,#_ak820_oneshot_consumed
      004CD3 EE               [12] 1472 	mov	a,r6
      004CD4 F0               [24] 1473 	movx	@dptr,a
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004CD5 90 0D FB         [24] 1475 	mov	dptr,#_ak820_oneshot_target
      004CD8 EF               [12] 1476 	mov	a,r7
      004CD9 F0               [24] 1477 	movx	@dptr,a
                                   1478 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004CDA 90 06 7E         [24] 1479 	mov	dptr,#_ak820_oneshot_mods
      004CDD E4               [12] 1480 	clr	a
      004CDE F0               [24] 1481 	movx	@dptr,a
      004CDF                       1482 00124$:
                                   1483 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004CDF 75 82 01         [24] 1484 	mov	dpl, #0x01
                                   1485 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004CE2 22               [24] 1486 	ret
                                   1487 	.area CSEG    (CODE)
                                   1488 	.area CONST   (CODE)
                                   1489 	.area XINIT   (CODE)
      00C676                       1490 __xinit__pending:
      00C676 FF                    1491 	.db #0xff	; 255
      00C677                       1492 __xinit__ak820_oneshot_target:
      00C677 FF                    1493 	.db #0xff	; 255
                                   1494 	.area CABS    (ABS,CODE)
                                   1495 
                                   1496 ; Experimental exact instruction outlining.
                                   1497 	.globl _ak820_outline_0005
                                   1498 	.globl _ak820_outline_0009
                                   1499 	.globl _ak820_outline_0010
                                   1500 	.globl _ak820_outline_0011
                                   1501 	.globl _ak820_outline_0012
                                   1502 	.globl _ak820_outline_0015
                                   1503 	.globl _ak820_outline_0018
                                   1504 	.globl _ak820_outline_0020
                                   1505 	.globl _ak820_outline_0022
                                   1506 	.globl _ak820_outline_0025
                                   1507 	.globl _ak820_outline_0033
                                   1508 	.globl _ak820_outline_0036
                                   1509 	.globl _ak820_outline_0054
                                   1510 	.globl _ak820_outline_0058
                                   1511 	.globl _ak820_outline_0061
                                   1512 	.globl _ak820_outline_0062
                                   1513 	.globl _ak820_outline_0067
                                   1514 	.globl _ak820_outline_0077
                                   1515 	.globl _ak820_outline_0079
                                   1516 	.globl _ak820_outline_0080
                                   1517 	.globl _ak820_outline_0105
                                   1518 	.globl _ak820_outline_0108
                                   1519 	.globl _ak820_outline_0109
                                   1520 	.globl _ak820_outline_0123
                                   1521 	.globl _ak820_outline_0126
                                   1522 	.globl _ak820_outline_0127
                                   1523 	.globl _ak820_outline_0137
                                   1524 	.globl _ak820_outline_0140
                                   1525 	.globl _ak820_outline_0160
                                   1526 	.globl _ak820_outline_0161
                                   1527 	.globl _ak820_outline_0190
                                   1528 	.globl _ak820_outline_0195
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0010
      004CE3                       1532 _ak820_outline_0010:
      004CE3 E0               [24] 1533 	movx	a,@dptr
      004CE4 FE               [12] 1534 	mov	r6,a
      004CE5 A3               [24] 1535 	inc	dptr
      004CE6 E0               [24] 1536 	movx	a,@dptr
      004CE7 FF               [12] 1537 	mov	r7,a
      004CE8 8E 04            [24] 1538 	mov	ar4,r6
      004CEA 8F 05            [24] 1539 	mov	ar5,r7
      004CEC 22               [24] 1540 	ret
                                   1541 
                                   1542 	.area CSEG (CODE)
                                   1543 ; function ak820_outline_0012
      004CED                       1544 _ak820_outline_0012:
      004CED 2E               [12] 1545 	add	a,r6
      004CEE FB               [12] 1546 	mov	r3,a
      004CEF E4               [12] 1547 	clr	a
      004CF0 3F               [12] 1548 	addc	a,r7
      004CF1 FC               [12] 1549 	mov	r4,a
      004CF2 8B 82            [24] 1550 	mov	dpl,r3
      004CF4 8C 83            [24] 1551 	mov	dph,r4
      004CF6 E0               [24] 1552 	movx	a,@dptr
      004CF7 22               [24] 1553 	ret
                                   1554 
                                   1555 	.area CSEG (CODE)
                                   1556 ; function ak820_outline_0018
      004CF8                       1557 _ak820_outline_0018:
      004CF8 2E               [12] 1558 	add	a,r6
      004CF9 FC               [12] 1559 	mov	r4,a
      004CFA E4               [12] 1560 	clr	a
      004CFB 3F               [12] 1561 	addc	a,r7
      004CFC FD               [12] 1562 	mov	r5,a
      004CFD 8C 82            [24] 1563 	mov	dpl,r4
      004CFF 8D 83            [24] 1564 	mov	dph,r5
      004D01 E0               [24] 1565 	movx	a,@dptr
      004D02 22               [24] 1566 	ret
                                   1567 
                                   1568 	.area CSEG (CODE)
                                   1569 ; function ak820_outline_0022
      004D03                       1570 _ak820_outline_0022:
      004D03 EF               [12] 1571 	mov	a,r7
      004D04 24 EA            [12] 1572 	add	a,#_source_state
      004D06 FD               [12] 1573 	mov	r5,a
      004D07 E4               [12] 1574 	clr	a
      004D08 34 05            [12] 1575 	addc	a,#(_source_state>>8)
      004D0A FE               [12] 1576 	mov	r6,a
      004D0B 8D 82            [24] 1577 	mov	dpl,r5
      004D0D 8E 83            [24] 1578 	mov	dph,r6
      004D0F E0               [24] 1579 	movx	a,@dptr
      004D10 FC               [12] 1580 	mov	r4,a
      004D11 22               [24] 1581 	ret
                                   1582 
                                   1583 	.area CSEG (CODE)
                                   1584 ; function ak820_outline_0025
      004D12                       1585 _ak820_outline_0025:
      004D12 90 0D E2         [24] 1586 	mov	dptr,#___memcpy_PARM_2
      004D15 EC               [12] 1587 	mov	a,r4
      004D16 F0               [24] 1588 	movx	@dptr,a
      004D17 ED               [12] 1589 	mov	a,r5
      004D18 A3               [24] 1590 	inc	dptr
      004D19 F0               [24] 1591 	movx	@dptr,a
      004D1A E4               [12] 1592 	clr	a
      004D1B A3               [24] 1593 	inc	dptr
      004D1C F0               [24] 1594 	movx	@dptr,a
      004D1D 90 0D E5         [24] 1595 	mov	dptr,#___memcpy_PARM_3
      004D20 74 02            [12] 1596 	mov	a,#0x02
      004D22 F0               [24] 1597 	movx	@dptr,a
      004D23 E4               [12] 1598 	clr	a
      004D24 A3               [24] 1599 	inc	dptr
      004D25 F0               [24] 1600 	movx	@dptr,a
      004D26 90 06 70         [24] 1601 	mov	dptr,#_ak820_tapping_source_PARM_1
      004D29 F5 F0            [12] 1602 	mov	b,a
      004D2B 22               [24] 1603 	ret
                                   1604 
                                   1605 	.area CSEG (CODE)
                                   1606 ; function ak820_outline_0058
      004D2C                       1607 _ak820_outline_0058:
      004D2C FC               [12] 1608 	mov	r4,a
      004D2D 8B 82            [24] 1609 	mov	dpl,r3
      004D2F 8C 83            [24] 1610 	mov	dph,r4
      004D31 E0               [24] 1611 	movx	a,@dptr
      004D32 FA               [12] 1612 	mov	r2,a
      004D33 22               [24] 1613 	ret
                                   1614 
                                   1615 	.area CSEG (CODE)
                                   1616 ; function ak820_outline_0061
      004D34                       1617 _ak820_outline_0061:
      004D34 EE               [12] 1618 	mov	a,r6
      004D35 F0               [24] 1619 	movx	@dptr,a
      004D36 EF               [12] 1620 	mov	a,r7
      004D37 A3               [24] 1621 	inc	dptr
      004D38 F0               [24] 1622 	movx	@dptr,a
      004D39 22               [24] 1623 	ret
                                   1624 
                                   1625 	.area CSEG (CODE)
                                   1626 ; function ak820_outline_0077
      004D3A                       1627 _ak820_outline_0077:
      004D3A 8D 82            [24] 1628 	mov	dpl,r5
      004D3C 8E 83            [24] 1629 	mov	dph,r6
      004D3E E0               [24] 1630 	movx	a,@dptr
      004D3F FC               [12] 1631 	mov	r4,a
      004D40 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0080
      004D41                       1636 _ak820_outline_0080:
      004D41 24 EA            [12] 1637 	add	a,#_source_state
      004D43 FC               [12] 1638 	mov	r4,a
      004D44 E4               [12] 1639 	clr	a
      004D45 34 05            [12] 1640 	addc	a,#(_source_state>>8)
      004D47 FD               [12] 1641 	mov	r5,a
      004D48 8C 82            [24] 1642 	mov	dpl,r4
      004D4A 8D 83            [24] 1643 	mov	dph,r5
      004D4C E0               [24] 1644 	movx	a,@dptr
      004D4D FB               [12] 1645 	mov	r3,a
      004D4E 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0140
      004D4F                       1650 _ak820_outline_0140:
      004D4F E9               [12] 1651 	mov	a,r1
      004D50 F0               [24] 1652 	movx	@dptr,a
      004D51 EA               [12] 1653 	mov	a,r2
      004D52 A3               [24] 1654 	inc	dptr
      004D53 F0               [24] 1655 	movx	@dptr,a
      004D54 22               [24] 1656 	ret
                                   1657 
                                   1658 	.area CSEG (CODE)
                                   1659 ; function ak820_outline_0160
      004D55                       1660 _ak820_outline_0160:
      004D55 90 0D FA         [24] 1661 	mov	dptr,#_pending
      004D58 74 FF            [12] 1662 	mov	a,#0xff
      004D5A F0               [24] 1663 	movx	@dptr,a
      004D5B 22               [24] 1664 	ret
                                   1665 
                                   1666 	.area CSEG (CODE)
                                   1667 ; function ak820_outline_0190
      004D5C                       1668 _ak820_outline_0190:
      004D5C A9 82            [24] 1669 	mov	r1,dpl
      004D5E AA 83            [24] 1670 	mov	r2,dph
      004D60 22               [24] 1671 	ret
