                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006CB                         85 _eeprom_read_word_addr_10000_91:
      0006CB                         86 	.ds 3
      0006CE                         87 _eeprom_read_word_ret_10000_92:
      0006CE                         88 	.ds 2
      0006D0                         89 _eeprom_read_dword_addr_10000_93:
      0006D0                         90 	.ds 3
      0006D3                         91 _eeprom_read_dword_ret_10000_94:
      0006D3                         92 	.ds 4
      0006D7                         93 _eeprom_write_byte_PARM_2:
      0006D7                         94 	.ds 1
      0006D8                         95 _eeprom_write_byte_addr_10000_95:
      0006D8                         96 	.ds 3
      0006DB                         97 _eeprom_write_word_PARM_2:
      0006DB                         98 	.ds 2
      0006DD                         99 _eeprom_write_word_addr_10000_97:
      0006DD                        100 	.ds 3
      0006E0                        101 _eeprom_write_dword_PARM_2:
      0006E0                        102 	.ds 4
      0006E4                        103 _eeprom_write_dword_addr_10000_99:
      0006E4                        104 	.ds 3
      0006E7                        105 _eeprom_update_byte_PARM_2:
      0006E7                        106 	.ds 1
      0006E8                        107 _eeprom_update_byte_addr_10000_107:
      0006E8                        108 	.ds 3
      0006EB                        109 _eeprom_update_word_PARM_2:
      0006EB                        110 	.ds 2
      0006ED                        111 _eeprom_update_word_addr_10000_111:
      0006ED                        112 	.ds 3
      0006F0                        113 _eeprom_update_dword_PARM_2:
      0006F0                        114 	.ds 4
      0006F4                        115 _eeprom_update_dword_addr_10000_115:
      0006F4                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0051D2                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0051D2 12 43 11         [24]  170 	lcall	_ak820_outline_0037
      0051D5 90 06 CB         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0051D8 12 38 1E         [24]  172 	lcall	_ak820_outline_0017
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0051DB 90 06 CE         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0051DE 12 53 D5         [24]  175 	lcall	_ak820_outline_0173
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0051E1 90 06 CB         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0051E4 12 53 8D         [24]  178 	lcall	_ak820_outline_0013
      0051E7 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0051EA ED               [12]  180 	mov	a,r5
      0051EB 12 38 1E         [24]  181 	lcall	_ak820_outline_0017
      0051EE 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0051F1 12 53 C8         [24]  183 	lcall	_ak820_outline_0116
      0051F4 90 06 CE         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0051F7 12 40 AD         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0051FA 90 06 CE         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0051FD 12 53 BF         [24]  188 	lcall	_ak820_outline_0091
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      005200 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      005201                        201 _eeprom_read_dword:
      005201 12 43 11         [24]  202 	lcall	_ak820_outline_0037
      005204 90 06 D0         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005207 12 38 1E         [24]  204 	lcall	_ak820_outline_0017
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      00520A 90 06 D3         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00520D 12 53 9D         [24]  207 	lcall	_ak820_outline_0052
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      005210 90 06 D0         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005213 12 53 8D         [24]  210 	lcall	_ak820_outline_0013
      005216 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005219 ED               [12]  212 	mov	a,r5
      00521A 12 38 1E         [24]  213 	lcall	_ak820_outline_0017
      00521D 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005220 74 04            [12]  215 	mov	a,#0x04
      005222 12 38 9E         [24]  216 	lcall	_ak820_outline_0128
      005225 90 06 D3         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005228 12 40 AD         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      00522B 90 06 D3         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00522E 12 53 A6         [24]  221 	lcall	_ak820_outline_0057
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      005231 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      005232                        234 _eeprom_write_byte:
      005232 12 43 11         [24]  235 	lcall	_ak820_outline_0037
      005235 90 06 D8         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005238 12 38 1E         [24]  237 	lcall	_ak820_outline_0017
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      00523B 90 06 D8         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      00523E 12 53 76         [24]  240 	lcall	_ak820_outline_0004
      005241 74 01            [12]  241 	mov	a,#0x01
      005243 12 38 9E         [24]  242 	lcall	_ak820_outline_0128
      005246 90 06 D7         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005249 02 41 39         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      00524C                        256 _eeprom_write_word:
      00524C 12 43 11         [24]  257 	lcall	_ak820_outline_0037
      00524F 90 06 DD         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005252 12 38 1E         [24]  259 	lcall	_ak820_outline_0017
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005255 90 06 DD         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005258 12 53 76         [24]  262 	lcall	_ak820_outline_0004
      00525B 12 53 C8         [24]  263 	lcall	_ak820_outline_0116
      00525E 90 06 DB         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      005261 02 41 39         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005264                        277 _eeprom_write_dword:
      005264 12 43 11         [24]  278 	lcall	_ak820_outline_0037
      005267 90 06 E4         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00526A 12 38 1E         [24]  280 	lcall	_ak820_outline_0017
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      00526D 90 06 E4         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005270 12 53 76         [24]  283 	lcall	_ak820_outline_0004
      005273 74 04            [12]  284 	mov	a,#0x04
      005275 12 38 9E         [24]  285 	lcall	_ak820_outline_0128
      005278 90 06 E0         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      00527B 02 41 39         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00527E                        307 _eeprom_update_byte:
      00527E C0 07            [24]  308 	push	ar7
      005280 C0 06            [24]  309 	push	ar6
      005282 C0 05            [24]  310 	push	ar5
      005284 C0 04            [24]  311 	push	ar4
      005286 12 43 11         [24]  312 	lcall	_ak820_outline_0037
      005289 90 06 E8         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00528C 12 38 1E         [24]  314 	lcall	_ak820_outline_0017
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00528F 90 06 E8         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005292 12 53 67         [24]  317 	lcall	_ak820_outline_0002
      005295 12 40 72         [24]  318 	lcall	_eeprom_read_byte
      005298 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      00529A 90 06 E7         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      00529D E0               [24]  322 	movx	a,@dptr
      00529E FE               [12]  323 	mov	r6,a
      00529F EF               [12]  324 	mov	a,r7
      0052A0 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      0052A3 80 36            [24]  326 	sjmp	00103$
      0052A5                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      0052A5 90 06 E8         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0052A8 12 38 4D         [24]  330 	lcall	_ak820_outline_0060
      0052AB A3               [24]  331 	inc	dptr
      0052AC E0               [24]  332 	movx	a,@dptr
      0052AD FF               [12]  333 	mov	r7,a
      0052AE 90 06 D7         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      0052B1 EE               [12]  335 	mov	a,r6
      0052B2 F0               [24]  336 	movx	@dptr,a
      0052B3 12 38 99         [24]  337 	lcall	_ak820_outline_0127
      0052B6 8F F0            [24]  338 	mov	b, r7
      0052B8 C0 07            [24]  339 	push	ar7
      0052BA C0 06            [24]  340 	push	ar6
      0052BC C0 05            [24]  341 	push	ar5
      0052BE C0 04            [24]  342 	push	ar4
      0052C0 C0 03            [24]  343 	push	ar3
      0052C2 C0 02            [24]  344 	push	ar2
      0052C4 C0 01            [24]  345 	push	ar1
      0052C6 C0 00            [24]  346 	push	ar0
      0052C8 12 52 32         [24]  347 	lcall	_eeprom_write_byte
      0052CB D0 00            [24]  348 	pop	ar0
      0052CD D0 01            [24]  349 	pop	ar1
      0052CF D0 02            [24]  350 	pop	ar2
      0052D1 D0 03            [24]  351 	pop	ar3
      0052D3 D0 04            [24]  352 	pop	ar4
      0052D5 D0 05            [24]  353 	pop	ar5
      0052D7 D0 06            [24]  354 	pop	ar6
      0052D9 D0 07            [24]  355 	pop	ar7
      0052DB                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      0052DB D0 04            [24]  358 	pop	ar4
      0052DD D0 05            [24]  359 	pop	ar5
      0052DF D0 06            [24]  360 	pop	ar6
      0052E1 D0 07            [24]  361 	pop	ar7
      0052E3 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      0052E4                        374 _eeprom_update_word:
      0052E4 12 43 11         [24]  375 	lcall	_ak820_outline_0037
      0052E7 90 06 ED         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0052EA 12 38 1E         [24]  377 	lcall	_ak820_outline_0017
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0052ED 90 06 ED         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0052F0 12 53 67         [24]  380 	lcall	_ak820_outline_0002
      0052F3 12 51 D2         [24]  381 	lcall	_eeprom_read_word
      0052F6 12 43 61         [24]  382 	lcall	_ak820_outline_0136
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0052F9 90 06 EB         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      0052FC 12 38 4D         [24]  385 	lcall	_ak820_outline_0060
      0052FF EE               [12]  386 	mov	a,r6
      005300 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      005303 EF               [12]  388 	mov	a,r7
      005304 B5 05 01         [24]  389 	cjne	a,ar5,00112$
      005307 22               [24]  390 	ret
      005308                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005308 90 06 ED         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00530B E0               [24]  394 	movx	a,@dptr
      00530C FB               [12]  395 	mov	r3,a
      00530D A3               [24]  396 	inc	dptr
      00530E 12 38 36         [24]  397 	lcall	_ak820_outline_0054
      005311 90 06 DB         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      005314 12 38 53         [24]  399 	lcall	_ak820_outline_0073
      005317 8B 82            [24]  400 	mov	dpl, r3
      005319 8E 83            [24]  401 	mov	dph, r6
      00531B 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      00531D 02 52 4C         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      005320                        416 _eeprom_update_dword:
      005320 12 43 11         [24]  417 	lcall	_ak820_outline_0037
      005323 90 06 F4         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005326 12 38 1E         [24]  419 	lcall	_ak820_outline_0017
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005329 90 06 F4         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00532C 12 53 67         [24]  422 	lcall	_ak820_outline_0002
      00532F 12 52 01         [24]  423 	lcall	_eeprom_read_dword
      005332 12 53 B7         [24]  424 	lcall	_ak820_outline_0059
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      005335 90 06 F0         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      005338 12 38 84         [24]  427 	lcall	_ak820_outline_0107
      00533B A3               [24]  428 	inc	dptr
      00533C 12 43 42         [24]  429 	lcall	_ak820_outline_0086
      00533F EC               [12]  430 	mov	a,r4
      005340 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      005343 ED               [12]  432 	mov	a,r5
      005344 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      005347 EE               [12]  434 	mov	a,r6
      005348 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      00534B EF               [12]  436 	mov	a,r7
      00534C B5 03 01         [24]  437 	cjne	a,ar3,00112$
      00534F 22               [24]  438 	ret
      005350                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005350 90 06 F4         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005353 12 53 8D         [24]  442 	lcall	_ak820_outline_0013
      005356 90 06 E0         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005359 12 53 CF         [24]  444 	lcall	_ak820_outline_0165
      00535C EA               [12]  445 	mov	a,r2
      00535D A3               [24]  446 	inc	dptr
      00535E 12 48 3C         [24]  447 	lcall	_ak820_outline_0194
      005361 12 53 96         [24]  448 	lcall	_ak820_outline_0048
                                    449 ;	drivers/eeprom/eeprom_driver.c:101: }
      005364 02 52 64         [24]  450 	ljmp	_eeprom_write_dword
                                    451 	.area CSEG    (CODE)
                                    452 	.area CONST   (CODE)
                                    453 	.area XINIT   (CODE)
                                    454 	.area CABS    (ABS,CODE)
                                    455 
                                    456 ; Experimental exact instruction outlining.
                                    457 	.globl _ak820_outline_0002
                                    458 	.globl _ak820_outline_0004
                                    459 	.globl _ak820_outline_0013
                                    460 	.globl _ak820_outline_0017
                                    461 	.globl _ak820_outline_0037
                                    462 	.globl _ak820_outline_0048
                                    463 	.globl _ak820_outline_0052
                                    464 	.globl _ak820_outline_0054
                                    465 	.globl _ak820_outline_0057
                                    466 	.globl _ak820_outline_0059
                                    467 	.globl _ak820_outline_0060
                                    468 	.globl _ak820_outline_0073
                                    469 	.globl _ak820_outline_0086
                                    470 	.globl _ak820_outline_0091
                                    471 	.globl _ak820_outline_0107
                                    472 	.globl _ak820_outline_0116
                                    473 	.globl _ak820_outline_0127
                                    474 	.globl _ak820_outline_0128
                                    475 	.globl _ak820_outline_0136
                                    476 	.globl _ak820_outline_0165
                                    477 	.globl _ak820_outline_0173
                                    478 	.globl _ak820_outline_0194
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      005367                        482 _ak820_outline_0002:
      005367 E0               [24]  483 	movx	a,@dptr
      005368 FD               [12]  484 	mov	r5,a
      005369 A3               [24]  485 	inc	dptr
      00536A E0               [24]  486 	movx	a,@dptr
      00536B FE               [12]  487 	mov	r6,a
      00536C A3               [24]  488 	inc	dptr
      00536D E0               [24]  489 	movx	a,@dptr
      00536E FF               [12]  490 	mov	r7,a
      00536F 8D 82            [24]  491 	mov	dpl,r5
      005371 8E 83            [24]  492 	mov	dph,r6
      005373 8F F0            [24]  493 	mov	b,r7
      005375 22               [24]  494 	ret
                                    495 
                                    496 	.area CSEG (CODE)
                                    497 ; function ak820_outline_0004
      005376                        498 _ak820_outline_0004:
      005376 E0               [24]  499 	movx	a,@dptr
      005377 FD               [12]  500 	mov	r5,a
      005378 A3               [24]  501 	inc	dptr
      005379 E0               [24]  502 	movx	a,@dptr
      00537A FE               [12]  503 	mov	r6,a
      00537B A3               [24]  504 	inc	dptr
      00537C E0               [24]  505 	movx	a,@dptr
      00537D FF               [12]  506 	mov	r7,a
      00537E 90 05 8E         [24]  507 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005381 ED               [12]  508 	mov	a,r5
      005382 F0               [24]  509 	movx	@dptr,a
      005383 EE               [12]  510 	mov	a,r6
      005384 A3               [24]  511 	inc	dptr
      005385 F0               [24]  512 	movx	@dptr,a
      005386 EF               [12]  513 	mov	a,r7
      005387 A3               [24]  514 	inc	dptr
      005388 F0               [24]  515 	movx	@dptr,a
      005389 90 05 91         [24]  516 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00538C 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0013
      00538D                        521 _ak820_outline_0013:
      00538D E0               [24]  522 	movx	a,@dptr
      00538E FD               [12]  523 	mov	r5,a
      00538F A3               [24]  524 	inc	dptr
      005390 E0               [24]  525 	movx	a,@dptr
      005391 FE               [12]  526 	mov	r6,a
      005392 A3               [24]  527 	inc	dptr
      005393 E0               [24]  528 	movx	a,@dptr
      005394 FF               [12]  529 	mov	r7,a
      005395 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0048
      005396                        534 _ak820_outline_0048:
      005396 8D 82            [24]  535 	mov	dpl,r5
      005398 8E 83            [24]  536 	mov	dph,r6
      00539A 8F F0            [24]  537 	mov	b,r7
      00539C 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0052
      00539D                        542 _ak820_outline_0052:
      00539D E4               [12]  543 	clr	a
      00539E F0               [24]  544 	movx	@dptr,a
      00539F A3               [24]  545 	inc	dptr
      0053A0 F0               [24]  546 	movx	@dptr,a
      0053A1 A3               [24]  547 	inc	dptr
      0053A2 F0               [24]  548 	movx	@dptr,a
      0053A3 A3               [24]  549 	inc	dptr
      0053A4 F0               [24]  550 	movx	@dptr,a
      0053A5 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0057
      0053A6                        555 _ak820_outline_0057:
      0053A6 E0               [24]  556 	movx	a,@dptr
      0053A7 FC               [12]  557 	mov	r4,a
      0053A8 A3               [24]  558 	inc	dptr
      0053A9 E0               [24]  559 	movx	a,@dptr
      0053AA FD               [12]  560 	mov	r5,a
      0053AB A3               [24]  561 	inc	dptr
      0053AC E0               [24]  562 	movx	a,@dptr
      0053AD FE               [12]  563 	mov	r6,a
      0053AE A3               [24]  564 	inc	dptr
      0053AF E0               [24]  565 	movx	a,@dptr
      0053B0 8C 82            [24]  566 	mov	dpl,r4
      0053B2 8D 83            [24]  567 	mov	dph,r5
      0053B4 8E F0            [24]  568 	mov	b,r6
      0053B6 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0059
      0053B7                        573 _ak820_outline_0059:
      0053B7 AC 82            [24]  574 	mov	r4,dpl
      0053B9 AD 83            [24]  575 	mov	r5,dph
      0053BB AE F0            [24]  576 	mov	r6,b
      0053BD FF               [12]  577 	mov	r7,a
      0053BE 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0091
      0053BF                        582 _ak820_outline_0091:
      0053BF E0               [24]  583 	movx	a,@dptr
      0053C0 FE               [12]  584 	mov	r6,a
      0053C1 A3               [24]  585 	inc	dptr
      0053C2 E0               [24]  586 	movx	a,@dptr
      0053C3 8E 82            [24]  587 	mov	dpl,r6
      0053C5 F5 83            [12]  588 	mov	dph,a
      0053C7 22               [24]  589 	ret
                                    590 
                                    591 	.area CSEG (CODE)
                                    592 ; function ak820_outline_0116
      0053C8                        593 _ak820_outline_0116:
      0053C8 74 02            [12]  594 	mov	a,#0x02
      0053CA F0               [24]  595 	movx	@dptr,a
      0053CB E4               [12]  596 	clr	a
      0053CC A3               [24]  597 	inc	dptr
      0053CD F0               [24]  598 	movx	@dptr,a
      0053CE 22               [24]  599 	ret
                                    600 
                                    601 	.area CSEG (CODE)
                                    602 ; function ak820_outline_0165
      0053CF                        603 _ak820_outline_0165:
      0053CF E8               [12]  604 	mov	a,r0
      0053D0 F0               [24]  605 	movx	@dptr,a
      0053D1 E9               [12]  606 	mov	a,r1
      0053D2 A3               [24]  607 	inc	dptr
      0053D3 F0               [24]  608 	movx	@dptr,a
      0053D4 22               [24]  609 	ret
                                    610 
                                    611 	.area CSEG (CODE)
                                    612 ; function ak820_outline_0173
      0053D5                        613 _ak820_outline_0173:
      0053D5 E4               [12]  614 	clr	a
      0053D6 F0               [24]  615 	movx	@dptr,a
      0053D7 A3               [24]  616 	inc	dptr
      0053D8 F0               [24]  617 	movx	@dptr,a
      0053D9 22               [24]  618 	ret
