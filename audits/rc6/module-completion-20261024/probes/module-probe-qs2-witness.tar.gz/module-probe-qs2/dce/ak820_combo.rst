                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_combo_term
                                     12 	.globl _dynamic_keymap_get_combo
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_combo_valid
                                    258 	.globl _ak820_combo_cancel
                                    259 	.globl _ak820_combo_reload
                                    260 	.globl _ak820_combo_tick
                                    261 	.globl _ak820_combo_process
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
      000000                        540 _input_sloc0_1_0:
      000000                        541 	.ds 1
      000001                        542 _output_sloc0_1_0:
      000001                        543 	.ds 1
      000002                        544 _ak820_combo_valid_sloc0_1_0:
      000002                        545 	.ds 1
      000003                        546 _ak820_combo_process_sloc0_1_0:
      000003                        547 	.ds 1
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      000422                        556 _input_code_10000_616:
      000422                        557 	.ds 2
      000424                        558 _output_code_10000_618:
      000424                        559 	.ds 2
      000426                        560 _combos:
      000426                        561 	.ds 32
      000446                        562 _saved:
      000446                        563 	.ds 9
      00044F                        564 _active:
      00044F                        565 	.ds 1
      000450                        566 _ak820_combo_valid_entry_10000_620:
      000450                        567 	.ds 2
      000452                        568 _ak820_combo_reload_entry_30000_632:
      000452                        569 	.ds 10
      00045C                        570 _ak820_combo_tick_now_10000_637:
      00045C                        571 	.ds 2
      00045E                        572 _ak820_combo_process_record_10000_640:
      00045E                        573 	.ds 2
      000460                        574 _ak820_combo_process_eligible_10001_655:
      000460                        575 	.ds 1
      000461                        576 _ak820_combo_process_i_40001_658:
      000461                        577 	.ds 1
      000462                        578 _ak820_combo_process_a_50001_659:
      000462                        579 	.ds 1
      000463                        580 _ak820_combo_process_b_50001_659:
      000463                        581 	.ds 1
                                    582 ;--------------------------------------------------------
                                    583 ; absolute external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XABS    (ABS,XDATA)
                                    586 ;--------------------------------------------------------
                                    587 ; initialized external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area XISEG   (XDATA)
      000DF8                        590 _first:
      000DF8                        591 	.ds 1
      000DF9                        592 _second:
      000DF9                        593 	.ds 1
                                    594 	.area HOME    (CODE)
                                    595 	.area GSINIT0 (CODE)
                                    596 	.area GSINIT1 (CODE)
                                    597 	.area GSINIT2 (CODE)
                                    598 	.area GSINIT3 (CODE)
                                    599 	.area GSINIT4 (CODE)
                                    600 	.area GSINIT5 (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area CSEG    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; global & static initialisations
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 	.area GSFINAL (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; Home
                                    613 ;--------------------------------------------------------
                                    614 	.area HOME    (CODE)
                                    615 	.area HOME    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; code
                                    618 ;--------------------------------------------------------
                                    619 	.area CSEG    (CODE)
                                    620 ;------------------------------------------------------------
                                    621 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    622 ;------------------------------------------------------------
                                    623 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    624 ;------------------------------------------------------------
                                    625 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    626 ;	-----------------------------------------
                           000007   627 	ar7 = 0x07
                           000006   628 	ar6 = 0x06
                           000005   629 	ar5 = 0x05
                           000004   630 	ar4 = 0x04
                           000003   631 	ar3 = 0x03
                           000002   632 	ar2 = 0x02
                           000001   633 	ar1 = 0x01
                           000000   634 	ar0 = 0x00
                                    635 ;	 function input
                                    636 ;	-----------------------------------------
      003468                        637 _input:
      003468 12 38 8A         [24]  638 	lcall	_ak820_outline_0108
      00346B 90 04 22         [24]  639 	mov	dptr,#_input_code_10000_616
      00346E 12 38 8F         [24]  640 	lcall	_ak820_outline_0109
      003471 90 04 22         [24]  641 	mov	dptr,#_input_code_10000_616
      003474 12 38 36         [24]  642 	lcall	_ak820_outline_0054
      003477 C3               [12]  643 	clr	c
      003478 EE               [12]  644 	mov	a,r6
      003479 94 04            [12]  645 	subb	a,#0x04
      00347B EF               [12]  646 	mov	a,r7
      00347C 94 00            [12]  647 	subb	a,#0x00
      00347E 40 07            [24]  648 	jc	00103$
      003480 74 A4            [12]  649 	mov	a,#0xa4
      003482 9E               [12]  650 	subb	a,r6
      003483 E4               [12]  651 	clr	a
      003484 9F               [12]  652 	subb	a,r7
      003485 50 04            [24]  653 	jnc	00104$
                                    654 ;	free result
      003487                        655 00103$:
                                    656 ;	assignBit
      003487 C2 00            [12]  657 	clr	_input_sloc0_1_0
      003489 80 02            [24]  658 	sjmp	00105$
      00348B                        659 00104$:
                                    660 ;	assignBit
      00348B D2 00            [12]  661 	setb	_input_sloc0_1_0
      00348D                        662 00105$:
      00348D A2 00            [12]  663 	mov	c,_input_sloc0_1_0
      00348F 12 38 B2         [24]  664 	lcall	_ak820_outline_0154
      003492 22               [24]  665 	ret
                                    666 ;------------------------------------------------------------
                                    667 ;Allocation info for local variables in function 'output'
                                    668 ;------------------------------------------------------------
                                    669 ;code          Allocated with name '_output_code_10000_618'
                                    670 ;basic         Allocated with name '_output_basic_10000_619'
                                    671 ;------------------------------------------------------------
                                    672 ;	keyboards/ajazz/ak820/ak820_combo.c:16: static bool output(uint16_t code) {
                                    673 ;	-----------------------------------------
                                    674 ;	 function output
                                    675 ;	-----------------------------------------
      003493                        676 _output:
      003493 12 38 8A         [24]  677 	lcall	_ak820_outline_0108
      003496 90 04 24         [24]  678 	mov	dptr,#_output_code_10000_618
      003499 12 38 8F         [24]  679 	lcall	_ak820_outline_0109
                                    680 ;	keyboards/ajazz/ak820/ak820_combo.c:17: uint8_t basic = code;
      00349C 90 04 24         [24]  681 	mov	dptr,#_output_code_10000_618
      00349F 12 38 36         [24]  682 	lcall	_ak820_outline_0054
      0034A2 8E 05            [24]  683 	mov	ar5,r6
                                    684 ;	keyboards/ajazz/ak820/ak820_combo.c:18: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      0034A4 74 E0            [12]  685 	mov	a,#0x100 - 0x20
      0034A6 2F               [12]  686 	add	a,r7
      0034A7 40 1B            [24]  687 	jc	00103$
      0034A9 8D 06            [24]  688 	mov	ar6,r5
      0034AB 7F 00            [12]  689 	mov	r7,#0x00
      0034AD 12 38 94         [24]  690 	lcall	_ak820_outline_0123
      0034B0 C0 05            [24]  691 	push	ar5
      0034B2 91 68            [12]  692 	acall	_input
      0034B4 E5 82            [12]  693 	mov	a, dpl
      0034B6 D0 05            [24]  694 	pop	ar5
      0034B8 70 0E            [24]  695 	jnz	00104$
      0034BA BD E0 00         [24]  696 	cjne	r5,#0xe0,00135$
      0034BD                        697 00135$:
      0034BD 40 05            [24]  698 	jc	00103$
      0034BF ED               [12]  699 	mov	a,r5
      0034C0 24 18            [12]  700 	add	a,#0xff - 0xe7
      0034C2 50 04            [24]  701 	jnc	00104$
                                    702 ;	free result
      0034C4                        703 00103$:
                                    704 ;	assignBit
      0034C4 C2 01            [12]  705 	clr	_output_sloc0_1_0
      0034C6 80 02            [24]  706 	sjmp	00105$
      0034C8                        707 00104$:
                                    708 ;	assignBit
      0034C8 D2 01            [12]  709 	setb	_output_sloc0_1_0
      0034CA                        710 00105$:
      0034CA A2 01            [12]  711 	mov	c,_output_sloc0_1_0
      0034CC 12 38 B2         [24]  712 	lcall	_ak820_outline_0154
                                    713 ;	keyboards/ajazz/ak820/ak820_combo.c:19: }
      0034CF 22               [24]  714 	ret
                                    715 ;------------------------------------------------------------
                                    716 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    717 ;------------------------------------------------------------
                                    718 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_620'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_combo.c:25: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_combo_valid
                                    723 ;	-----------------------------------------
      0034D0                        724 _ak820_combo_valid:
      0034D0 12 38 8A         [24]  725 	lcall	_ak820_outline_0108
      0034D3 90 04 50         [24]  726 	mov	dptr,#_ak820_combo_valid_entry_10000_620
      0034D6 12 38 8F         [24]  727 	lcall	_ak820_outline_0109
                                    728 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[2] || entry->input[3]) return false;
      0034D9 90 04 50         [24]  729 	mov	dptr,#_ak820_combo_valid_entry_10000_620
      0034DC 12 37 E9         [24]  730 	lcall	_ak820_outline_0005
      0034DF A3               [24]  731 	inc	dptr
      0034E0 A3               [24]  732 	inc	dptr
      0034E1 A3               [24]  733 	inc	dptr
      0034E2 A3               [24]  734 	inc	dptr
      0034E3 E0               [24]  735 	movx	a,@dptr
      0034E4 FC               [12]  736 	mov	r4,a
      0034E5 A3               [24]  737 	inc	dptr
      0034E6 E0               [24]  738 	movx	a,@dptr
      0034E7 4C               [12]  739 	orl	a,r4
      0034E8 70 0C            [24]  740 	jnz	00101$
      0034EA 74 06            [12]  741 	mov	a,#0x06
      0034EC 12 38 26         [24]  742 	lcall	_ak820_outline_0020
      0034EF E0               [24]  743 	movx	a,@dptr
      0034F0 FC               [12]  744 	mov	r4,a
      0034F1 A3               [24]  745 	inc	dptr
      0034F2 E0               [24]  746 	movx	a,@dptr
      0034F3 4C               [12]  747 	orl	a,r4
      0034F4 60 04            [24]  748 	jz	00102$
      0034F6                        749 00101$:
      0034F6 75 82 00         [24]  750 	mov	dpl, #0x00
      0034F9 22               [24]  751 	ret
      0034FA                        752 00102$:
                                    753 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      0034FA 8E 04            [24]  754 	mov	ar4,r6
      0034FC 8F 05            [24]  755 	mov	ar5,r7
      0034FE 12 38 2E         [24]  756 	lcall	_ak820_outline_0036
      003501 FA               [12]  757 	mov	r2,a
      003502 A3               [24]  758 	inc	dptr
      003503 E0               [24]  759 	movx	a,@dptr
      003504 FB               [12]  760 	mov	r3,a
      003505 12 38 99         [24]  761 	lcall	_ak820_outline_0127
      003508 12 38 4D         [24]  762 	lcall	_ak820_outline_0060
      00350B EA               [12]  763 	mov	a,r2
      00350C 4C               [12]  764 	orl	a,r4
      00350D F8               [12]  765 	mov	r0,a
      00350E EB               [12]  766 	mov	a,r3
      00350F 4D               [12]  767 	orl	a,r5
      003510 48               [12]  768 	orl	a,r0
      003511 70 13            [24]  769 	jnz	00105$
      003513 74 08            [12]  770 	mov	a,#0x08
      003515 12 38 26         [24]  771 	lcall	_ak820_outline_0020
      003518 E0               [24]  772 	movx	a,@dptr
      003519 F8               [12]  773 	mov	r0,a
      00351A A3               [24]  774 	inc	dptr
      00351B E0               [24]  775 	movx	a,@dptr
      00351C 48               [12]  776 	orl	a,r0
      00351D B4 01 00         [24]  777 	cjne	a,#0x01,00152$
      003520                        778 00152$:
      003520 92 02            [24]  779 	mov  _ak820_combo_valid_sloc0_1_0,c
      003522 12 38 B2         [24]  780 	lcall	_ak820_outline_0154
      003525 22               [24]  781 	ret
      003526                        782 00105$:
                                    783 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (entry->input[0] == entry->input[1]) return false;
      003526 EC               [12]  784 	mov	a,r4
      003527 B5 02 08         [24]  785 	cjne	a,ar2,00107$
      00352A ED               [12]  786 	mov	a,r5
      00352B B5 03 04         [24]  787 	cjne	a,ar3,00107$
      00352E 75 82 00         [24]  788 	mov	dpl, #0x00
      003531 22               [24]  789 	ret
      003532                        790 00107$:
                                    791 ;	keyboards/ajazz/ak820/ak820_combo.c:29: if (!input(entry->input[0])) return false;
      003532 12 38 99         [24]  792 	lcall	_ak820_outline_0127
      003535 C0 07            [24]  793 	push	ar7
      003537 C0 06            [24]  794 	push	ar6
      003539 C0 03            [24]  795 	push	ar3
      00353B C0 02            [24]  796 	push	ar2
      00353D 91 68            [12]  797 	acall	_input
      00353F E5 82            [12]  798 	mov	a, dpl
      003541 D0 02            [24]  799 	pop	ar2
      003543 D0 03            [24]  800 	pop	ar3
      003545 D0 06            [24]  801 	pop	ar6
      003547 D0 07            [24]  802 	pop	ar7
      003549 70 03            [24]  803 	jnz	00109$
      00354B F5 82            [12]  804 	mov	dpl,a
      00354D 22               [24]  805 	ret
      00354E                        806 00109$:
                                    807 ;	keyboards/ajazz/ak820/ak820_combo.c:30: if (!input(entry->input[1])) return false;
      00354E 12 38 A8         [24]  808 	lcall	_ak820_outline_0148
      003551 C0 07            [24]  809 	push	ar7
      003553 C0 06            [24]  810 	push	ar6
      003555 91 68            [12]  811 	acall	_input
      003557 E5 82            [12]  812 	mov	a, dpl
      003559 D0 06            [24]  813 	pop	ar6
      00355B D0 07            [24]  814 	pop	ar7
      00355D 70 03            [24]  815 	jnz	00111$
      00355F F5 82            [12]  816 	mov	dpl,a
      003561 22               [24]  817 	ret
      003562                        818 00111$:
                                    819 ;	keyboards/ajazz/ak820/ak820_combo.c:31: return output(entry->output);
      003562 74 08            [12]  820 	mov	a,#0x08
      003564 12 38 26         [24]  821 	lcall	_ak820_outline_0020
      003567 12 37 E9         [24]  822 	lcall	_ak820_outline_0005
                                    823 ;	keyboards/ajazz/ak820/ak820_combo.c:32: }
      00356A 81 93            [12]  824 	ajmp	_output
                                    825 ;------------------------------------------------------------
                                    826 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    827 ;------------------------------------------------------------
                                    828 ;	keyboards/ajazz/ak820/ak820_combo.c:35: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    829 ;	-----------------------------------------
                                    830 ;	 function ak820_combo_cancel
                                    831 ;	-----------------------------------------
      00356C                        832 _ak820_combo_cancel:
      00356C 90 0D F9         [24]  833 	mov	dptr,#_second
      00356F 74 FF            [12]  834 	mov	a,#0xff
      003571 F0               [24]  835 	movx	@dptr,a
      003572 90 0D F8         [24]  836 	mov	dptr,#_first
      003575 F0               [24]  837 	movx	@dptr,a
      003576 90 04 4F         [24]  838 	mov	dptr,#_active
      003579 E4               [12]  839 	clr	a
      00357A F0               [24]  840 	movx	@dptr,a
      00357B 22               [24]  841 	ret
                                    842 ;------------------------------------------------------------
                                    843 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    844 ;------------------------------------------------------------
                                    845 ;i             Allocated with name '_ak820_combo_reload_i_20000_631'
                                    846 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_632'
                                    847 ;------------------------------------------------------------
                                    848 ;	keyboards/ajazz/ak820/ak820_combo.c:36: void ak820_combo_reload(void) {
                                    849 ;	-----------------------------------------
                                    850 ;	 function ak820_combo_reload
                                    851 ;	-----------------------------------------
      00357C                        852 _ak820_combo_reload:
                                    853 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00357C 7F 00            [12]  854 	mov	r7,#0x00
      00357E                        855 00105$:
      00357E BF 08 00         [24]  856 	cjne	r7,#0x08,00131$
      003581                        857 00131$:
      003581 40 01            [24]  858 	jc	00132$
      003583 22               [24]  859 	ret
      003584                        860 00132$:
                                    861 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = 0;
      003584 EF               [12]  862 	mov	a,r7
      003585 75 F0 04         [24]  863 	mov	b,#0x04
      003588 A4               [48]  864 	mul	ab
      003589 24 26            [12]  865 	add	a, #_combos
      00358B FD               [12]  866 	mov	r5,a
      00358C 74 04            [12]  867 	mov	a,#(_combos >> 8)
      00358E 35 F0            [12]  868 	addc	a, b
      003590 FE               [12]  869 	mov	r6,a
      003591 8D 03            [24]  870 	mov	ar3,r5
      003593 8E 04            [24]  871 	mov	ar4,r6
      003595 12 33 FC         [24]  872 	lcall	_ak820_outline_0126
      003598 E4               [12]  873 	clr	a
      003599 F0               [24]  874 	movx	@dptr,a
                                    875 ;	keyboards/ajazz/ak820/ak820_combo.c:40: if (!dynamic_keymap_get_combo(i, &entry)) {
      00359A 90 0B 33         [24]  876 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00359D 74 52            [12]  877 	mov	a,#_ak820_combo_reload_entry_30000_632
      00359F F0               [24]  878 	movx	@dptr,a
      0035A0 74 04            [12]  879 	mov	a,#(_ak820_combo_reload_entry_30000_632 >> 8)
      0035A2 12 38 5F         [24]  880 	lcall	_ak820_outline_0085
      0035A5 8F 82            [24]  881 	mov	dpl, r7
      0035A7 C0 07            [24]  882 	push	ar7
      0035A9 C0 06            [24]  883 	push	ar6
      0035AB C0 05            [24]  884 	push	ar5
      0035AD C0 04            [24]  885 	push	ar4
      0035AF C0 03            [24]  886 	push	ar3
      0035B1 12 89 17         [24]  887 	lcall	_dynamic_keymap_get_combo
      0035B4 12 38 78         [24]  888 	lcall	_ak820_outline_0103
      0035B7 D0 03            [24]  889 	pop	ar3
      0035B9 D0 04            [24]  890 	pop	ar4
      0035BB D0 05            [24]  891 	pop	ar5
      0035BD D0 06            [24]  892 	pop	ar6
      0035BF D0 07            [24]  893 	pop	ar7
      0035C1 45 F0            [12]  894 	orl	a,b
      0035C3 70 28            [24]  895 	jnz	00106$
                                    896 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].a = entry.input[0];
      0035C5 90 04 52         [24]  897 	mov	dptr,#_ak820_combo_reload_entry_30000_632
      0035C8 E0               [24]  898 	movx	a,@dptr
      0035C9 12 33 FC         [24]  899 	lcall	_ak820_outline_0126
      0035CC F0               [24]  900 	movx	@dptr,a
                                    901 ;	keyboards/ajazz/ak820/ak820_combo.c:42: combos[i].b = entry.input[1];
      0035CD 74 01            [12]  902 	mov	a,#0x01
      0035CF 2D               [12]  903 	add	a, r5
      0035D0 FB               [12]  904 	mov	r3,a
      0035D1 E4               [12]  905 	clr	a
      0035D2 3E               [12]  906 	addc	a, r6
      0035D3 FC               [12]  907 	mov	r4,a
      0035D4 90 04 54         [24]  908 	mov	dptr,#(_ak820_combo_reload_entry_30000_632 + 0x0002)
      0035D7 E0               [24]  909 	movx	a,@dptr
      0035D8 12 33 FC         [24]  910 	lcall	_ak820_outline_0126
      0035DB F0               [24]  911 	movx	@dptr,a
                                    912 ;	keyboards/ajazz/ak820/ak820_combo.c:43: combos[i].output = entry.output;
      0035DC 74 02            [12]  913 	mov	a,#0x02
      0035DE 12 38 BC         [24]  914 	lcall	_ak820_outline_0163
      0035E1 90 04 5A         [24]  915 	mov	dptr,#(_ak820_combo_reload_entry_30000_632 + 0x0008)
      0035E4 12 38 72         [24]  916 	lcall	_ak820_outline_0102
      0035E7 12 38 A3         [24]  917 	lcall	_ak820_outline_0137
      0035EA 12 38 65         [24]  918 	lcall	_ak820_outline_0092
      0035ED                        919 00106$:
                                    920 ;	keyboards/ajazz/ak820/ak820_combo.c:37: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035ED 0F               [12]  921 	inc	r7
                                    922 ;	keyboards/ajazz/ak820/ak820_combo.c:46: }
      0035EE A1 7E            [24]  923 	ajmp	00105$
                                    924 ;------------------------------------------------------------
                                    925 ;Allocation info for local variables in function 'flush'
                                    926 ;------------------------------------------------------------
                                    927 ;	keyboards/ajazz/ak820/ak820_combo.c:47: static void flush(void) {
                                    928 ;	-----------------------------------------
                                    929 ;	 function flush
                                    930 ;	-----------------------------------------
      0035F0                        931 _flush:
                                    932 ;	keyboards/ajazz/ak820/ak820_combo.c:48: first = NONE;
      0035F0 90 0D F8         [24]  933 	mov	dptr,#_first
      0035F3 74 FF            [12]  934 	mov	a,#0xff
      0035F5 F0               [24]  935 	movx	@dptr,a
                                    936 ;	keyboards/ajazz/ak820/ak820_combo.c:49: process_record(&saved);
      0035F6 90 04 46         [24]  937 	mov	dptr,#_saved
                                    938 ;	keyboards/ajazz/ak820/ak820_combo.c:50: }
      0035F9 02 74 F6         [24]  939 	ljmp	_process_record
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    942 ;------------------------------------------------------------
                                    943 ;now           Allocated with name '_ak820_combo_tick_now_10000_637'
                                    944 ;------------------------------------------------------------
                                    945 ;	keyboards/ajazz/ak820/ak820_combo.c:51: void ak820_combo_tick(uint16_t now) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function ak820_combo_tick
                                    948 ;	-----------------------------------------
      0035FC                        949 _ak820_combo_tick:
      0035FC 12 38 8A         [24]  950 	lcall	_ak820_outline_0108
      0035FF 90 04 5C         [24]  951 	mov	dptr,#_ak820_combo_tick_now_10000_637
      003602 12 38 8F         [24]  952 	lcall	_ak820_outline_0109
                                    953 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      003605 12 38 C2         [24]  954 	lcall	_ak820_outline_0188
      003608 FF               [12]  955 	mov	r7,a
      003609 BF FF 01         [24]  956 	cjne	r7,#0xff,00128$
      00360C 22               [24]  957 	ret
      00360D                        958 00128$:
      00360D 90 04 4F         [24]  959 	mov	dptr,#_active
      003610 E0               [24]  960 	movx	a,@dptr
      003611 70 2A            [24]  961 	jnz	00105$
      003613 90 04 48         [24]  962 	mov	dptr,#(_saved + 0x0002)
      003616 12 38 36         [24]  963 	lcall	_ak820_outline_0054
      003619 90 04 5C         [24]  964 	mov	dptr,#_ak820_combo_tick_now_10000_637
      00361C 12 38 4D         [24]  965 	lcall	_ak820_outline_0060
      00361F EC               [12]  966 	mov	a,r4
      003620 C3               [12]  967 	clr	c
      003621 9E               [12]  968 	subb	a,r6
      003622 FE               [12]  969 	mov	r6,a
      003623 ED               [12]  970 	mov	a,r5
      003624 9F               [12]  971 	subb	a,r7
      003625 FF               [12]  972 	mov	r7,a
      003626 C0 07            [24]  973 	push	ar7
      003628 C0 06            [24]  974 	push	ar6
      00362A 12 47 D6         [24]  975 	lcall	_ak820_settings_combo_term
      00362D 12 38 AD         [24]  976 	lcall	_ak820_outline_0149
      003630 D0 06            [24]  977 	pop	ar6
      003632 D0 07            [24]  978 	pop	ar7
      003634 C3               [12]  979 	clr	c
      003635 EE               [12]  980 	mov	a,r6
      003636 9C               [12]  981 	subb	a,r4
      003637 EF               [12]  982 	mov	a,r7
      003638 9D               [12]  983 	subb	a,r5
      003639 40 02            [24]  984 	jc	00105$
                                    985 ;	keyboards/ajazz/ak820/ak820_combo.c:53: }
      00363B A1 F0            [24]  986 	ajmp	_flush
      00363D                        987 00105$:
      00363D 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'ak820_combo_process'
                                    991 ;------------------------------------------------------------
                                    992 ;record        Allocated with name '_ak820_combo_process_record_10000_640'
                                    993 ;id            Allocated with name '_ak820_combo_process_id_10000_641'
                                    994 ;code          Allocated with name '_ak820_combo_process_code_10000_641'
                                    995 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_655'
                                    996 ;previous      Allocated with name '_ak820_combo_process_previous_30001_657'
                                    997 ;i             Allocated with name '_ak820_combo_process_i_40001_658'
                                    998 ;a             Allocated with name '_ak820_combo_process_a_50001_659'
                                    999 ;b             Allocated with name '_ak820_combo_process_b_50001_659'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_combo.c:54: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_combo_process
                                   1004 ;	-----------------------------------------
      00363E                       1005 _ak820_combo_process:
      00363E 12 38 8A         [24] 1006 	lcall	_ak820_outline_0108
      003641 90 04 5E         [24] 1007 	mov	dptr,#_ak820_combo_process_record_10000_640
      003644 12 38 8F         [24] 1008 	lcall	_ak820_outline_0109
                                   1009 ;	keyboards/ajazz/ak820/ak820_combo.c:55: uint8_t id, code = record->keycode;
      003647 90 04 5E         [24] 1010 	mov	dptr,#_ak820_combo_process_record_10000_640
      00364A 12 37 F3         [24] 1011 	lcall	_ak820_outline_0008
      00364D 8C 03            [24] 1012 	mov	ar3,r4
                                   1013 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (IS_NOEVENT(record->event)) return true;
      00364F 74 04            [12] 1014 	mov	a,#0x04
      003651 2E               [12] 1015 	add	a, r6
      003652 12 38 14         [24] 1016 	lcall	_ak820_outline_0015
      003655 70 04            [24] 1017 	jnz	00102$
      003657 75 82 01         [24] 1018 	mov	dpl, #0x01
      00365A 22               [24] 1019 	ret
      00365B                       1020 00102$:
                                   1021 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00365B 12 38 6B         [24] 1022 	lcall	_ak820_outline_0095
      00365E FA               [12] 1023 	mov	r2,a
      00365F BA 10 00         [24] 1024 	cjne	r2,#0x10,00300$
      003662                       1025 00300$:
      003662 50 09            [24] 1026 	jnc	00106$
      003664 12 38 7E         [24] 1027 	lcall	_ak820_outline_0105
      003667 F9               [12] 1028 	mov	r1,a
      003668 B9 08 00         [24] 1029 	cjne	r1,#0x08,00302$
      00366B                       1030 00302$:
      00366B 40 15            [24] 1031 	jc	00107$
      00366D                       1032 00106$:
                                   1033 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (first != NONE && !active) flush();
      00366D 12 38 C2         [24] 1034 	lcall	_ak820_outline_0188
      003670 F8               [12] 1035 	mov	r0,a
      003671 B8 FF 02         [24] 1036 	cjne	r0,#0xff,00304$
      003674 80 08            [24] 1037 	sjmp	00104$
      003676                       1038 00304$:
      003676 90 04 4F         [24] 1039 	mov	dptr,#_active
      003679 E0               [24] 1040 	movx	a,@dptr
      00367A 70 02            [24] 1041 	jnz	00104$
      00367C B1 F0            [24] 1042 	acall	_flush
      00367E                       1043 00104$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_combo.c:60: return true;
      00367E 75 82 01         [24] 1045 	mov	dpl, #0x01
      003681 22               [24] 1046 	ret
      003682                       1047 00107$:
                                   1048 ;	keyboards/ajazz/ak820/ak820_combo.c:62: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003682 EA               [12] 1049 	mov	a,r2
      003683 12 38 C7         [24] 1050 	lcall	_ak820_outline_0195
      003686 29               [12] 1051 	add	a,r1
      003687 FA               [12] 1052 	mov	r2,a
                                   1053 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (active) {
      003688 90 04 4F         [24] 1054 	mov	dptr,#_active
      00368B E0               [24] 1055 	movx	a,@dptr
      00368C 60 6F            [24] 1056 	jz	00123$
                                   1057 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id != first && id != second) return true;
      00368E 12 38 C2         [24] 1058 	lcall	_ak820_outline_0188
      003691 F9               [12] 1059 	mov	r1,a
      003692 EA               [12] 1060 	mov	a,r2
      003693 B5 01 02         [24] 1061 	cjne	a,ar1,00307$
      003696 80 0F            [24] 1062 	sjmp	00110$
      003698                       1063 00307$:
      003698 90 0D F9         [24] 1064 	mov	dptr,#_second
      00369B E0               [24] 1065 	movx	a,@dptr
      00369C F9               [12] 1066 	mov	r1,a
      00369D EA               [12] 1067 	mov	a,r2
      00369E B5 01 02         [24] 1068 	cjne	a,ar1,00308$
      0036A1 80 04            [24] 1069 	sjmp	00110$
      0036A3                       1070 00308$:
      0036A3 75 82 01         [24] 1071 	mov	dpl, #0x01
      0036A6 22               [24] 1072 	ret
      0036A7                       1073 00110$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_combo.c:65: if (!record->event.pressed) {
      0036A7 90 04 5E         [24] 1075 	mov	dptr,#_ak820_combo_process_record_10000_640
      0036AA 12 38 84         [24] 1076 	lcall	_ak820_outline_0107
      0036AD 74 05            [12] 1077 	mov	a,#0x05
      0036AF 28               [12] 1078 	add	a, r0
      0036B0 F8               [12] 1079 	mov	r0,a
      0036B1 E4               [12] 1080 	clr	a
      0036B2 39               [12] 1081 	addc	a, r1
      0036B3 F9               [12] 1082 	mov	r1,a
      0036B4 12 38 B7         [24] 1083 	lcall	_ak820_outline_0155
      0036B7 E0               [24] 1084 	movx	a,@dptr
      0036B8 70 3F            [24] 1085 	jnz	00121$
                                   1086 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (saved.event.pressed) {
      0036BA 90 04 4B         [24] 1087 	mov	dptr,#(_saved + 0x0005)
      0036BD E0               [24] 1088 	movx	a,@dptr
      0036BE 60 0F            [24] 1089 	jz	00113$
                                   1090 ;	keyboards/ajazz/ak820/ak820_combo.c:67: saved.event.pressed = false;
      0036C0 90 04 4B         [24] 1091 	mov	dptr,#(_saved + 0x0005)
      0036C3 E4               [12] 1092 	clr	a
      0036C4 F0               [24] 1093 	movx	@dptr,a
                                   1094 ;	keyboards/ajazz/ak820/ak820_combo.c:68: process_record(&saved);
      0036C5 90 04 46         [24] 1095 	mov	dptr,#_saved
      0036C8 C0 02            [24] 1096 	push	ar2
      0036CA 12 74 F6         [24] 1097 	lcall	_process_record
      0036CD D0 02            [24] 1098 	pop	ar2
      0036CF                       1099 00113$:
                                   1100 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (id == first) first = NONE;
      0036CF 12 38 C2         [24] 1101 	lcall	_ak820_outline_0188
      0036D2 F9               [12] 1102 	mov	r1,a
      0036D3 EA               [12] 1103 	mov	a,r2
      0036D4 B5 01 08         [24] 1104 	cjne	a,ar1,00115$
      0036D7 90 0D F8         [24] 1105 	mov	dptr,#_first
      0036DA 74 FF            [12] 1106 	mov	a,#0xff
      0036DC F0               [24] 1107 	movx	@dptr,a
      0036DD 80 06            [24] 1108 	sjmp	00116$
      0036DF                       1109 00115$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_combo.c:71: else second = NONE;
      0036DF 90 0D F9         [24] 1111 	mov	dptr,#_second
      0036E2 74 FF            [12] 1112 	mov	a,#0xff
      0036E4 F0               [24] 1113 	movx	@dptr,a
      0036E5                       1114 00116$:
                                   1115 ;	keyboards/ajazz/ak820/ak820_combo.c:72: if (first == NONE && second == NONE) active = false;
      0036E5 12 38 C2         [24] 1116 	lcall	_ak820_outline_0188
      0036E8 F9               [12] 1117 	mov	r1,a
      0036E9 B9 FF 0D         [24] 1118 	cjne	r1,#0xff,00121$
      0036EC 90 0D F9         [24] 1119 	mov	dptr,#_second
      0036EF E0               [24] 1120 	movx	a,@dptr
      0036F0 F9               [12] 1121 	mov	r1,a
      0036F1 B9 FF 05         [24] 1122 	cjne	r1,#0xff,00121$
      0036F4 90 04 4F         [24] 1123 	mov	dptr,#_active
      0036F7 E4               [12] 1124 	clr	a
      0036F8 F0               [24] 1125 	movx	@dptr,a
      0036F9                       1126 00121$:
                                   1127 ;	keyboards/ajazz/ak820/ak820_combo.c:74: return false;
      0036F9 75 82 00         [24] 1128 	mov	dpl, #0x00
      0036FC 22               [24] 1129 	ret
      0036FD                       1130 00123$:
                                   1131 ;	keyboards/ajazz/ak820/ak820_combo.c:76: bool eligible = false;
      0036FD 90 04 60         [24] 1132 	mov	dptr,#_ak820_combo_process_eligible_10001_655
      003700 E4               [12] 1133 	clr	a
      003701 F0               [24] 1134 	movx	@dptr,a
                                   1135 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (record->event.pressed && input(record->keycode)) {
      003702 12 38 07         [24] 1136 	lcall	_ak820_outline_0011
      003705 70 02            [24] 1137 	jnz	00317$
      003707 E1 A8            [12] 1138 	ajmp	00134$
      003709                       1139 00317$:
      003709 12 38 99         [24] 1140 	lcall	_ak820_outline_0127
      00370C C0 03            [24] 1141 	push	ar3
      00370E C0 02            [24] 1142 	push	ar2
      003710 91 68            [12] 1143 	acall	_input
      003712 E5 82            [12] 1144 	mov	a, dpl
      003714 D0 02            [24] 1145 	pop	ar2
      003716 D0 03            [24] 1146 	pop	ar3
      003718 70 02            [24] 1147 	jnz	00318$
      00371A E1 A8            [12] 1148 	ajmp	00134$
      00371C                       1149 00318$:
                                   1150 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t previous = saved.keycode;
      00371C 90 04 4D         [24] 1151 	mov	dptr,#(_saved + 0x0007)
      00371F E0               [24] 1152 	movx	a,@dptr
      003720 FF               [12] 1153 	mov	r7,a
                                   1154 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003721 90 04 61         [24] 1155 	mov	dptr,#_ak820_combo_process_i_40001_658
      003724 E4               [12] 1156 	clr	a
      003725 F0               [24] 1157 	movx	@dptr,a
      003726 EB               [12] 1158 	mov	a,r3
      003727 B5 07 03         [24] 1159 	cjne	a,ar7,00319$
      00372A D3               [12] 1160 	setb	c
      00372B 80 01            [24] 1161 	sjmp	00320$
      00372D                       1162 00319$:
      00372D C3               [12] 1163 	clr	c
      00372E                       1164 00320$:
      00372E 92 03            [24] 1165 	mov	_ak820_combo_process_sloc0_1_0,c
      003730 7E 00            [12] 1166 	mov	r6,#0x00
      003732                       1167 00141$:
      003732 BE 08 00         [24] 1168 	cjne	r6,#0x08,00321$
      003735                       1169 00321$:
      003735 40 02            [24] 1170 	jc	00322$
      003737 E1 A8            [12] 1171 	ajmp	00134$
      003739                       1172 00322$:
                                   1173 ;	keyboards/ajazz/ak820/ak820_combo.c:80: uint8_t a = combos[i].a, b = combos[i].b;
      003739 EE               [12] 1174 	mov	a,r6
      00373A 12 38 3C         [24] 1175 	lcall	_ak820_outline_0056
      00373D E0               [24] 1176 	movx	a,@dptr
      00373E F9               [12] 1177 	mov	r1,a
      00373F 90 04 62         [24] 1178 	mov	dptr,#_ak820_combo_process_a_50001_659
      003742 F0               [24] 1179 	movx	@dptr,a
      003743 12 38 99         [24] 1180 	lcall	_ak820_outline_0127
      003746 A3               [24] 1181 	inc	dptr
      003747 E0               [24] 1182 	movx	a,@dptr
      003748 FD               [12] 1183 	mov	r5,a
      003749 90 04 63         [24] 1184 	mov	dptr,#_ak820_combo_process_b_50001_659
      00374C F0               [24] 1185 	movx	@dptr,a
                                   1186 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (a == code || b == code) {
      00374D E9               [12] 1187 	mov	a,r1
      00374E B5 03 02         [24] 1188 	cjne	a,ar3,00323$
      003751 80 04            [24] 1189 	sjmp	00129$
      003753                       1190 00323$:
      003753 ED               [12] 1191 	mov	a,r5
      003754 B5 03 49         [24] 1192 	cjne	a,ar3,00142$
      003757                       1193 00129$:
                                   1194 ;	keyboards/ajazz/ak820/ak820_combo.c:82: eligible = true;
      003757 90 04 60         [24] 1195 	mov	dptr,#_ak820_combo_process_eligible_10001_655
      00375A 74 01            [12] 1196 	mov	a,#0x01
      00375C F0               [24] 1197 	movx	@dptr,a
                                   1198 ;	keyboards/ajazz/ak820/ak820_combo.c:83: if (first != NONE && code != previous && (a == previous || b == previous)) {
      00375D 12 38 C2         [24] 1199 	lcall	_ak820_outline_0188
      003760 FD               [12] 1200 	mov	r5,a
      003761 BD FF 02         [24] 1201 	cjne	r5,#0xff,00326$
      003764 80 3A            [24] 1202 	sjmp	00142$
      003766                       1203 00326$:
      003766 20 03 37         [24] 1204 	jb	_ak820_combo_process_sloc0_1_0,00142$
      003769 90 04 62         [24] 1205 	mov	dptr,#_ak820_combo_process_a_50001_659
      00376C E0               [24] 1206 	movx	a,@dptr
      00376D B5 07 02         [24] 1207 	cjne	a,ar7,00328$
      003770 80 07            [24] 1208 	sjmp	00124$
      003772                       1209 00328$:
      003772 90 04 63         [24] 1210 	mov	dptr,#_ak820_combo_process_b_50001_659
      003775 E0               [24] 1211 	movx	a,@dptr
      003776 B5 07 27         [24] 1212 	cjne	a,ar7,00142$
      003779                       1213 00124$:
                                   1214 ;	keyboards/ajazz/ak820/ak820_combo.c:84: second = id;
      003779 90 0D F9         [24] 1215 	mov	dptr,#_second
      00377C EA               [12] 1216 	mov	a,r2
      00377D F0               [24] 1217 	movx	@dptr,a
                                   1218 ;	keyboards/ajazz/ak820/ak820_combo.c:85: active = true;
      00377E 90 04 4F         [24] 1219 	mov	dptr,#_active
      003781 74 01            [12] 1220 	mov	a,#0x01
      003783 F0               [24] 1221 	movx	@dptr,a
                                   1222 ;	keyboards/ajazz/ak820/ak820_combo.c:86: saved.keycode = combos[i].output;
      003784 90 04 61         [24] 1223 	mov	dptr,#_ak820_combo_process_i_40001_658
      003787 E0               [24] 1224 	movx	a,@dptr
      003788 12 38 3C         [24] 1225 	lcall	_ak820_outline_0056
      00378B A3               [24] 1226 	inc	dptr
      00378C A3               [24] 1227 	inc	dptr
      00378D 12 38 4D         [24] 1228 	lcall	_ak820_outline_0060
      003790 90 04 4D         [24] 1229 	mov	dptr,#(_saved + 0x0007)
      003793 12 38 53         [24] 1230 	lcall	_ak820_outline_0073
                                   1231 ;	keyboards/ajazz/ak820/ak820_combo.c:87: process_record(&saved);
      003796 90 04 46         [24] 1232 	mov	dptr,#_saved
      003799 12 74 F6         [24] 1233 	lcall	_process_record
                                   1234 ;	keyboards/ajazz/ak820/ak820_combo.c:88: return false;
      00379C 75 82 00         [24] 1235 	mov	dpl, #0x00
      00379F 22               [24] 1236 	ret
      0037A0                       1237 00142$:
                                   1238 ;	keyboards/ajazz/ak820/ak820_combo.c:79: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0037A0 0E               [12] 1239 	inc	r6
      0037A1 90 04 61         [24] 1240 	mov	dptr,#_ak820_combo_process_i_40001_658
      0037A4 EE               [12] 1241 	mov	a,r6
      0037A5 F0               [24] 1242 	movx	@dptr,a
      0037A6 E1 32            [24] 1243 	ajmp	00141$
      0037A8                       1244 00134$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_combo.c:93: if (first != NONE) flush();
      0037A8 12 38 C2         [24] 1246 	lcall	_ak820_outline_0188
      0037AB FF               [12] 1247 	mov	r7,a
      0037AC BF FF 02         [24] 1248 	cjne	r7,#0xff,00331$
      0037AF 80 06            [24] 1249 	sjmp	00137$
      0037B1                       1250 00331$:
      0037B1 C0 02            [24] 1251 	push	ar2
      0037B3 B1 F0            [24] 1252 	acall	_flush
      0037B5 D0 02            [24] 1253 	pop	ar2
      0037B7                       1254 00137$:
                                   1255 ;	keyboards/ajazz/ak820/ak820_combo.c:94: if (eligible) {
      0037B7 90 04 60         [24] 1256 	mov	dptr,#_ak820_combo_process_eligible_10001_655
      0037BA E0               [24] 1257 	movx	a,@dptr
      0037BB 60 28            [24] 1258 	jz	00139$
                                   1259 ;	keyboards/ajazz/ak820/ak820_combo.c:95: first = id;
      0037BD 90 0D F8         [24] 1260 	mov	dptr,#_first
      0037C0 EA               [12] 1261 	mov	a,r2
      0037C1 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	keyboards/ajazz/ak820/ak820_combo.c:96: saved = *record;
      0037C2 90 04 5E         [24] 1264 	mov	dptr,#_ak820_combo_process_record_10000_640
      0037C5 12 38 59         [24] 1265 	lcall	_ak820_outline_0079
      0037C8 7F 00            [12] 1266 	mov	r7,#0x00
      0037CA 90 0D E2         [24] 1267 	mov	dptr,#___memcpy_PARM_2
      0037CD ED               [12] 1268 	mov	a,r5
      0037CE 12 38 1E         [24] 1269 	lcall	_ak820_outline_0017
      0037D1 90 0D E5         [24] 1270 	mov	dptr,#___memcpy_PARM_3
      0037D4 74 09            [12] 1271 	mov	a,#0x09
      0037D6 12 38 9E         [24] 1272 	lcall	_ak820_outline_0128
      0037D9 90 04 46         [24] 1273 	mov	dptr,#_saved
      0037DC F5 F0            [12] 1274 	mov	b,a
      0037DE 12 BC AA         [24] 1275 	lcall	___memcpy
                                   1276 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return false;
      0037E1 75 82 00         [24] 1277 	mov	dpl, #0x00
      0037E4 22               [24] 1278 	ret
      0037E5                       1279 00139$:
                                   1280 ;	keyboards/ajazz/ak820/ak820_combo.c:99: return true;
      0037E5 75 82 01         [24] 1281 	mov	dpl, #0x01
                                   1282 ;	keyboards/ajazz/ak820/ak820_combo.c:100: }
      0037E8 22               [24] 1283 	ret
                                   1284 	.area CSEG    (CODE)
                                   1285 	.area CONST   (CODE)
                                   1286 	.area XINIT   (CODE)
      00C674                       1287 __xinit__first:
      00C674 FF                    1288 	.db #0xff	; 255
      00C675                       1289 __xinit__second:
      00C675 FF                    1290 	.db #0xff	; 255
                                   1291 	.area CABS    (ABS,CODE)
                                   1292 
                                   1293 ; Experimental exact instruction outlining.
                                   1294 	.globl _ak820_outline_0005
                                   1295 	.globl _ak820_outline_0008
                                   1296 	.globl _ak820_outline_0011
                                   1297 	.globl _ak820_outline_0015
                                   1298 	.globl _ak820_outline_0017
                                   1299 	.globl _ak820_outline_0020
                                   1300 	.globl _ak820_outline_0036
                                   1301 	.globl _ak820_outline_0054
                                   1302 	.globl _ak820_outline_0056
                                   1303 	.globl _ak820_outline_0060
                                   1304 	.globl _ak820_outline_0073
                                   1305 	.globl _ak820_outline_0079
                                   1306 	.globl _ak820_outline_0085
                                   1307 	.globl _ak820_outline_0092
                                   1308 	.globl _ak820_outline_0095
                                   1309 	.globl _ak820_outline_0102
                                   1310 	.globl _ak820_outline_0103
                                   1311 	.globl _ak820_outline_0105
                                   1312 	.globl _ak820_outline_0107
                                   1313 	.globl _ak820_outline_0108
                                   1314 	.globl _ak820_outline_0109
                                   1315 	.globl _ak820_outline_0123
                                   1316 	.globl _ak820_outline_0126
                                   1317 	.globl _ak820_outline_0127
                                   1318 	.globl _ak820_outline_0128
                                   1319 	.globl _ak820_outline_0137
                                   1320 	.globl _ak820_outline_0148
                                   1321 	.globl _ak820_outline_0149
                                   1322 	.globl _ak820_outline_0154
                                   1323 	.globl _ak820_outline_0155
                                   1324 	.globl _ak820_outline_0163
                                   1325 	.globl _ak820_outline_0188
                                   1326 	.globl _ak820_outline_0195
                                   1327 
                                   1328 	.area CSEG (CODE)
                                   1329 ; function ak820_outline_0005
      0037E9                       1330 _ak820_outline_0005:
      0037E9 E0               [24] 1331 	movx	a,@dptr
      0037EA FE               [12] 1332 	mov	r6,a
      0037EB A3               [24] 1333 	inc	dptr
      0037EC E0               [24] 1334 	movx	a,@dptr
      0037ED FF               [12] 1335 	mov	r7,a
      0037EE 8E 82            [24] 1336 	mov	dpl,r6
      0037F0 8F 83            [24] 1337 	mov	dph,r7
      0037F2 22               [24] 1338 	ret
                                   1339 
                                   1340 	.area CSEG (CODE)
                                   1341 ; function ak820_outline_0008
      0037F3                       1342 _ak820_outline_0008:
      0037F3 E0               [24] 1343 	movx	a,@dptr
      0037F4 FE               [12] 1344 	mov	r6,a
      0037F5 A3               [24] 1345 	inc	dptr
      0037F6 E0               [24] 1346 	movx	a,@dptr
      0037F7 FF               [12] 1347 	mov	r7,a
      0037F8 74 07            [12] 1348 	mov	a,#0x07
      0037FA 2E               [12] 1349 	add	a,r6
      0037FB F5 82            [12] 1350 	mov	dpl,a
      0037FD E4               [12] 1351 	clr	a
      0037FE 3F               [12] 1352 	addc	a,r7
      0037FF F5 83            [12] 1353 	mov	dph,a
      003801 E0               [24] 1354 	movx	a,@dptr
      003802 FC               [12] 1355 	mov	r4,a
      003803 A3               [24] 1356 	inc	dptr
      003804 E0               [24] 1357 	movx	a,@dptr
      003805 FD               [12] 1358 	mov	r5,a
      003806 22               [24] 1359 	ret
                                   1360 
                                   1361 	.area CSEG (CODE)
                                   1362 ; function ak820_outline_0011
      003807                       1363 _ak820_outline_0011:
      003807 74 05            [12] 1364 	mov	a,#0x05
      003809 2E               [12] 1365 	add	a,r6
      00380A FE               [12] 1366 	mov	r6,a
      00380B E4               [12] 1367 	clr	a
      00380C 3F               [12] 1368 	addc	a,r7
      00380D FF               [12] 1369 	mov	r7,a
      00380E 8E 82            [24] 1370 	mov	dpl,r6
      003810 8F 83            [24] 1371 	mov	dph,r7
      003812 E0               [24] 1372 	movx	a,@dptr
      003813 22               [24] 1373 	ret
                                   1374 
                                   1375 	.area CSEG (CODE)
                                   1376 ; function ak820_outline_0015
      003814                       1377 _ak820_outline_0015:
      003814 F9               [12] 1378 	mov	r1,a
      003815 E4               [12] 1379 	clr	a
      003816 3F               [12] 1380 	addc	a,r7
      003817 FA               [12] 1381 	mov	r2,a
      003818 89 82            [24] 1382 	mov	dpl,r1
      00381A 8A 83            [24] 1383 	mov	dph,r2
      00381C E0               [24] 1384 	movx	a,@dptr
      00381D 22               [24] 1385 	ret
                                   1386 
                                   1387 	.area CSEG (CODE)
                                   1388 ; function ak820_outline_0017
      00381E                       1389 _ak820_outline_0017:
      00381E F0               [24] 1390 	movx	@dptr,a
      00381F EE               [12] 1391 	mov	a,r6
      003820 A3               [24] 1392 	inc	dptr
      003821 F0               [24] 1393 	movx	@dptr,a
      003822 EF               [12] 1394 	mov	a,r7
      003823 A3               [24] 1395 	inc	dptr
      003824 F0               [24] 1396 	movx	@dptr,a
      003825 22               [24] 1397 	ret
                                   1398 
                                   1399 	.area CSEG (CODE)
                                   1400 ; function ak820_outline_0020
      003826                       1401 _ak820_outline_0020:
      003826 2E               [12] 1402 	add	a,r6
      003827 F5 82            [12] 1403 	mov	dpl,a
      003829 E4               [12] 1404 	clr	a
      00382A 3F               [12] 1405 	addc	a,r7
      00382B F5 83            [12] 1406 	mov	dph,a
      00382D 22               [24] 1407 	ret
                                   1408 
                                   1409 	.area CSEG (CODE)
                                   1410 ; function ak820_outline_0036
      00382E                       1411 _ak820_outline_0036:
      00382E 8E 82            [24] 1412 	mov	dpl,r6
      003830 8F 83            [24] 1413 	mov	dph,r7
      003832 A3               [24] 1414 	inc	dptr
      003833 A3               [24] 1415 	inc	dptr
      003834 E0               [24] 1416 	movx	a,@dptr
      003835 22               [24] 1417 	ret
                                   1418 
                                   1419 	.area CSEG (CODE)
                                   1420 ; function ak820_outline_0054
      003836                       1421 _ak820_outline_0054:
      003836 E0               [24] 1422 	movx	a,@dptr
      003837 FE               [12] 1423 	mov	r6,a
      003838 A3               [24] 1424 	inc	dptr
      003839 E0               [24] 1425 	movx	a,@dptr
      00383A FF               [12] 1426 	mov	r7,a
      00383B 22               [24] 1427 	ret
                                   1428 
                                   1429 	.area CSEG (CODE)
                                   1430 ; function ak820_outline_0056
      00383C                       1431 _ak820_outline_0056:
      00383C 75 F0 04         [24] 1432 	mov	b,#0x04
      00383F A4               [48] 1433 	mul	ab
      003840 24 26            [12] 1434 	add	a,#_combos
      003842 FC               [12] 1435 	mov	r4,a
      003843 74 04            [12] 1436 	mov	a,#(_combos>>8)
      003845 35 F0            [12] 1437 	addc	a,b
      003847 FD               [12] 1438 	mov	r5,a
      003848 8C 82            [24] 1439 	mov	dpl,r4
      00384A 8D 83            [24] 1440 	mov	dph,r5
      00384C 22               [24] 1441 	ret
                                   1442 
                                   1443 	.area CSEG (CODE)
                                   1444 ; function ak820_outline_0060
      00384D                       1445 _ak820_outline_0060:
      00384D E0               [24] 1446 	movx	a,@dptr
      00384E FC               [12] 1447 	mov	r4,a
      00384F A3               [24] 1448 	inc	dptr
      003850 E0               [24] 1449 	movx	a,@dptr
      003851 FD               [12] 1450 	mov	r5,a
      003852 22               [24] 1451 	ret
                                   1452 
                                   1453 	.area CSEG (CODE)
                                   1454 ; function ak820_outline_0073
      003853                       1455 _ak820_outline_0073:
      003853 EC               [12] 1456 	mov	a,r4
      003854 F0               [24] 1457 	movx	@dptr,a
      003855 ED               [12] 1458 	mov	a,r5
      003856 A3               [24] 1459 	inc	dptr
      003857 F0               [24] 1460 	movx	@dptr,a
      003858 22               [24] 1461 	ret
                                   1462 
                                   1463 	.area CSEG (CODE)
                                   1464 ; function ak820_outline_0079
      003859                       1465 _ak820_outline_0079:
      003859 E0               [24] 1466 	movx	a,@dptr
      00385A FD               [12] 1467 	mov	r5,a
      00385B A3               [24] 1468 	inc	dptr
      00385C E0               [24] 1469 	movx	a,@dptr
      00385D FE               [12] 1470 	mov	r6,a
      00385E 22               [24] 1471 	ret
                                   1472 
                                   1473 	.area CSEG (CODE)
                                   1474 ; function ak820_outline_0085
      00385F                       1475 _ak820_outline_0085:
      00385F A3               [24] 1476 	inc	dptr
      003860 F0               [24] 1477 	movx	@dptr,a
      003861 E4               [12] 1478 	clr	a
      003862 A3               [24] 1479 	inc	dptr
      003863 F0               [24] 1480 	movx	@dptr,a
      003864 22               [24] 1481 	ret
                                   1482 
                                   1483 	.area CSEG (CODE)
                                   1484 ; function ak820_outline_0092
      003865                       1485 _ak820_outline_0092:
      003865 EB               [12] 1486 	mov	a,r3
      003866 F0               [24] 1487 	movx	@dptr,a
      003867 EC               [12] 1488 	mov	a,r4
      003868 A3               [24] 1489 	inc	dptr
      003869 F0               [24] 1490 	movx	@dptr,a
      00386A 22               [24] 1491 	ret
                                   1492 
                                   1493 	.area CSEG (CODE)
                                   1494 ; function ak820_outline_0095
      00386B                       1495 _ak820_outline_0095:
      00386B 8E 82            [24] 1496 	mov	dpl,r6
      00386D 8F 83            [24] 1497 	mov	dph,r7
      00386F A3               [24] 1498 	inc	dptr
      003870 E0               [24] 1499 	movx	a,@dptr
      003871 22               [24] 1500 	ret
                                   1501 
                                   1502 	.area CSEG (CODE)
                                   1503 ; function ak820_outline_0102
      003872                       1504 _ak820_outline_0102:
      003872 E0               [24] 1505 	movx	a,@dptr
      003873 FB               [12] 1506 	mov	r3,a
      003874 A3               [24] 1507 	inc	dptr
      003875 E0               [24] 1508 	movx	a,@dptr
      003876 FC               [12] 1509 	mov	r4,a
      003877 22               [24] 1510 	ret
                                   1511 
                                   1512 	.area CSEG (CODE)
                                   1513 ; function ak820_outline_0103
      003878                       1514 _ak820_outline_0103:
      003878 E5 82            [12] 1515 	mov	a,dpl
      00387A 85 83 F0         [24] 1516 	mov	b,dph
      00387D 22               [24] 1517 	ret
                                   1518 
                                   1519 	.area CSEG (CODE)
                                   1520 ; function ak820_outline_0105
      00387E                       1521 _ak820_outline_0105:
      00387E 8E 82            [24] 1522 	mov	dpl,r6
      003880 8F 83            [24] 1523 	mov	dph,r7
      003882 E0               [24] 1524 	movx	a,@dptr
      003883 22               [24] 1525 	ret
                                   1526 
                                   1527 	.area CSEG (CODE)
                                   1528 ; function ak820_outline_0107
      003884                       1529 _ak820_outline_0107:
      003884 E0               [24] 1530 	movx	a,@dptr
      003885 F8               [12] 1531 	mov	r0,a
      003886 A3               [24] 1532 	inc	dptr
      003887 E0               [24] 1533 	movx	a,@dptr
      003888 F9               [12] 1534 	mov	r1,a
      003889 22               [24] 1535 	ret
                                   1536 
                                   1537 	.area CSEG (CODE)
                                   1538 ; function ak820_outline_0108
      00388A                       1539 _ak820_outline_0108:
      00388A AF 83            [24] 1540 	mov	r7,dph
      00388C E5 82            [12] 1541 	mov	a,dpl
      00388E 22               [24] 1542 	ret
                                   1543 
                                   1544 	.area CSEG (CODE)
                                   1545 ; function ak820_outline_0109
      00388F                       1546 _ak820_outline_0109:
      00388F F0               [24] 1547 	movx	@dptr,a
      003890 EF               [12] 1548 	mov	a,r7
      003891 A3               [24] 1549 	inc	dptr
      003892 F0               [24] 1550 	movx	@dptr,a
      003893 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0123
      003894                       1555 _ak820_outline_0123:
      003894 8E 82            [24] 1556 	mov	dpl,r6
      003896 8F 83            [24] 1557 	mov	dph,r7
      003898 22               [24] 1558 	ret
                                   1559 
                                   1560 	.area CSEG (CODE)
                                   1561 ; function ak820_outline_0127
      003899                       1562 _ak820_outline_0127:
      003899 8C 82            [24] 1563 	mov	dpl,r4
      00389B 8D 83            [24] 1564 	mov	dph,r5
      00389D 22               [24] 1565 	ret
                                   1566 
                                   1567 	.area CSEG (CODE)
                                   1568 ; function ak820_outline_0128
      00389E                       1569 _ak820_outline_0128:
      00389E F0               [24] 1570 	movx	@dptr,a
      00389F E4               [12] 1571 	clr	a
      0038A0 A3               [24] 1572 	inc	dptr
      0038A1 F0               [24] 1573 	movx	@dptr,a
      0038A2 22               [24] 1574 	ret
                                   1575 
                                   1576 	.area CSEG (CODE)
                                   1577 ; function ak820_outline_0137
      0038A3                       1578 _ak820_outline_0137:
      0038A3 8D 82            [24] 1579 	mov	dpl,r5
      0038A5 8E 83            [24] 1580 	mov	dph,r6
      0038A7 22               [24] 1581 	ret
                                   1582 
                                   1583 	.area CSEG (CODE)
                                   1584 ; function ak820_outline_0148
      0038A8                       1585 _ak820_outline_0148:
      0038A8 8A 82            [24] 1586 	mov	dpl,r2
      0038AA 8B 83            [24] 1587 	mov	dph,r3
      0038AC 22               [24] 1588 	ret
                                   1589 
                                   1590 	.area CSEG (CODE)
                                   1591 ; function ak820_outline_0149
      0038AD                       1592 _ak820_outline_0149:
      0038AD AC 82            [24] 1593 	mov	r4,dpl
      0038AF AD 83            [24] 1594 	mov	r5,dph
      0038B1 22               [24] 1595 	ret
                                   1596 
                                   1597 	.area CSEG (CODE)
                                   1598 ; function ak820_outline_0154
      0038B2                       1599 _ak820_outline_0154:
      0038B2 E4               [12] 1600 	clr	a
      0038B3 33               [12] 1601 	rlc	a
      0038B4 F5 82            [12] 1602 	mov	dpl,a
      0038B6 22               [24] 1603 	ret
                                   1604 
                                   1605 	.area CSEG (CODE)
                                   1606 ; function ak820_outline_0155
      0038B7                       1607 _ak820_outline_0155:
      0038B7 88 82            [24] 1608 	mov	dpl,r0
      0038B9 89 83            [24] 1609 	mov	dph,r1
      0038BB 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0163
      0038BC                       1614 _ak820_outline_0163:
      0038BC 2D               [12] 1615 	add	a,r5
      0038BD FD               [12] 1616 	mov	r5,a
      0038BE E4               [12] 1617 	clr	a
      0038BF 3E               [12] 1618 	addc	a,r6
      0038C0 FE               [12] 1619 	mov	r6,a
      0038C1 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0188
      0038C2                       1624 _ak820_outline_0188:
      0038C2 90 0D F8         [24] 1625 	mov	dptr,#_first
      0038C5 E0               [24] 1626 	movx	a,@dptr
      0038C6 22               [24] 1627 	ret
                                   1628 
                                   1629 	.area CSEG (CODE)
                                   1630 ; function ak820_outline_0195
      0038C7                       1631 _ak820_outline_0195:
      0038C7 C4               [12] 1632 	swap	a
      0038C8 03               [12] 1633 	rr	a
      0038C9 54 F8            [12] 1634 	anl	a,#0xf8
      0038CB 22               [24] 1635 	ret
