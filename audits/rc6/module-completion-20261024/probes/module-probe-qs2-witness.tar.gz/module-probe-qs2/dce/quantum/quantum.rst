                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_settings_caps_delay
                                     17 	.globl _ak820_settings_tap_code_delay
                                     18 	.globl _ak820_combo_process
                                     19 	.globl _process_repeat_key
                                     20 	.globl _process_last_key
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _mcu_reset
                                     24 	.globl _bootloader_jump
                                     25 	.globl _ak820_resolve_key
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _rgb_matrix_set_suspend_state
                                     36 	.globl _rgb_matrix_task
                                     37 	.globl _mDelaymS
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _process_record_quantum_helper_PARM_2
                                    282 	.globl _get_record_keycode_PARM_2
                                    283 	.globl _post_process_record_user_PARM_2
                                    284 	.globl _post_process_record_kb_PARM_2
                                    285 	.globl _process_record_user_PARM_2
                                    286 	.globl _process_record_kb_PARM_2
                                    287 	.globl _pre_process_record_user_PARM_2
                                    288 	.globl _pre_process_record_kb_PARM_2
                                    289 	.globl _register_code16
                                    290 	.globl _unregister_code16
                                    291 	.globl _pre_process_record_kb
                                    292 	.globl _pre_process_record_user
                                    293 	.globl _process_action_kb
                                    294 	.globl _process_record_kb
                                    295 	.globl _process_record_user
                                    296 	.globl _post_process_record_kb
                                    297 	.globl _post_process_record_user
                                    298 	.globl _reset_keyboard
                                    299 	.globl _soft_reset_keyboard
                                    300 	.globl _get_record_keycode
                                    301 	.globl _pre_process_record_quantum
                                    302 	.globl _post_process_record_quantum
                                    303 	.globl _process_record_quantum
                                    304 	.globl _process_record_quantum_helper
                                    305 	.globl _shutdown_user
                                    306 ;--------------------------------------------------------
                                    307 ; special function registers
                                    308 ;--------------------------------------------------------
                                    309 	.area RSEG    (ABS,DATA)
      000000                        310 	.org 0x0000
                           0000D0   311 _PSW	=	0x00d0
                           0000E0   312 _ACC	=	0x00e0
                           0000F0   313 _B	=	0x00f0
                           0000FD   314 _A_INV	=	0x00fd
                           000081   315 _SP	=	0x0081
                           000082   316 _DPL	=	0x0082
                           000083   317 _DPH	=	0x0083
                           0000A1   318 _SAFE_MOD	=	0x00a1
                           0000B1   319 _GLOBAL_CFG	=	0x00b1
                           000087   320 _PCON	=	0x0087
                           0000BA   321 _POWER_CFG	=	0x00ba
                           0000B9   322 _CLOCK_CFG	=	0x00b9
                           0000A9   323 _WAKE_CTRL	=	0x00a9
                           0000FE   324 _RESET_KEEP	=	0x00fe
                           0000FF   325 _WDOG_COUNT	=	0x00ff
                           0000A8   326 _IE	=	0x00a8
                           0000B8   327 _IP	=	0x00b8
                           0000E8   328 _IE_EX	=	0x00e8
                           0000E9   329 _IP_EX	=	0x00e9
                           0000B2   330 _GPIO_IE	=	0x00b2
                           008584   331 _ROM_ADDR	=	0x8584
                           000084   332 _ROM_ADDR_L	=	0x0084
                           000085   333 _ROM_ADDR_H	=	0x0085
                           008F8E   334 _ROM_DATA_HI	=	0x8f8e
                           00008E   335 _ROM_DATA_HL	=	0x008e
                           00008F   336 _ROM_DATA_HH	=	0x008f
                           000086   337 _ROM_CTRL	=	0x0086
                           000080   338 _P0	=	0x0080
                           0000C4   339 _P0_MOD_OC	=	0x00c4
                           0000C5   340 _P0_DIR_PU	=	0x00c5
                           000090   341 _P1	=	0x0090
                           000092   342 _P1_MOD_OC	=	0x0092
                           000093   343 _P1_DIR_PU	=	0x0093
                           0000A0   344 _P2	=	0x00a0
                           000094   345 _P2_MOD_OC	=	0x0094
                           000095   346 _P2_DIR_PU	=	0x0095
                           0000B0   347 _P3	=	0x00b0
                           000096   348 _P3_MOD_OC	=	0x0096
                           000097   349 _P3_DIR_PU	=	0x0097
                           0000C0   350 _P4	=	0x00c0
                           0000C2   351 _P4_MOD_OC	=	0x00c2
                           0000C3   352 _P4_DIR_PU	=	0x00c3
                           0000C1   353 _P4_LED_KEY	=	0x00c1
                           0000AA   354 _P5_IN	=	0x00aa
                           0000AB   355 _P5_OUT_PU	=	0x00ab
                           0000AC   356 _P5_DIR	=	0x00ac
                           0000AD   357 _P6_IN	=	0x00ad
                           0000AE   358 _P6_OUT_PU	=	0x00ae
                           0000AF   359 _P6_DIR	=	0x00af
                           0000F1   360 _P7	=	0x00f1
                           0000A2   361 _XBUS_AUX	=	0x00a2
                           000088   362 _TCON	=	0x0088
                           000089   363 _TMOD	=	0x0089
                           00008A   364 _TL0	=	0x008a
                           00008B   365 _TL1	=	0x008b
                           00008C   366 _TH0	=	0x008c
                           00008D   367 _TH1	=	0x008d
                           000098   368 _SCON	=	0x0098
                           000099   369 _SBUF	=	0x0099
                           0000C8   370 _T2CON	=	0x00c8
                           0000C9   371 _T2MOD	=	0x00c9
                           00CBCA   372 _RCAP2	=	0xcbca
                           0000CA   373 _RCAP2L	=	0x00ca
                           0000CB   374 _RCAP2H	=	0x00cb
                           00CDCC   375 _T2COUNT	=	0xcdcc
                           0000CC   376 _TL2	=	0x00cc
                           0000CD   377 _TH2	=	0x00cd
                           00CFCE   378 _T2CAP1	=	0xcfce
                           0000CE   379 _T2CAP1L	=	0x00ce
                           0000CF   380 _T2CAP1H	=	0x00cf
                           0000F8   381 _SPI0_STAT	=	0x00f8
                           0000F9   382 _SPI0_DATA	=	0x00f9
                           0000FA   383 _SPI0_CTRL	=	0x00fa
                           0000FB   384 _SPI0_CK_SE	=	0x00fb
                           0000FC   385 _SPI0_SETUP	=	0x00fc
                           0000BC   386 _SCON1	=	0x00bc
                           0000BD   387 _SBUF1	=	0x00bd
                           0000BE   388 _SBAUD1	=	0x00be
                           0000BF   389 _SIF1	=	0x00bf
                           0000B4   390 _SPI1_STAT	=	0x00b4
                           0000B5   391 _SPI1_DATA	=	0x00b5
                           0000B6   392 _SPI1_CTRL	=	0x00b6
                           0000B7   393 _SPI1_CK_SE	=	0x00b7
                           0000F3   394 _ADC_CTRL	=	0x00f3
                           00F5F4   395 _ADC_DAT	=	0xf5f4
                           0000F4   396 _ADC_DAT_L	=	0x00f4
                           0000F5   397 _ADC_DAT_H	=	0x00f5
                           0000F6   398 _ADC_CHAN	=	0x00f6
                           0000A6   399 _LED_COMMON	=	0x00a6
                           0000A7   400 _LED_PWM_OE	=	0x00a7
                           00C7C6   401 _LED_DMA	=	0xc7c6
                           0000C6   402 _LED_DMA_L	=	0x00c6
                           0000C7   403 _LED_DMA_H	=	0x00c7
                           0000F7   404 _LED_STATUS	=	0x00f7
                           0000B3   405 _I2CX_INT	=	0x00b3
                           0000BB   406 _I2CS_INT_ST	=	0x00bb
                                    407 ;--------------------------------------------------------
                                    408 ; special function bits
                                    409 ;--------------------------------------------------------
                                    410 	.area RSEG    (ABS,DATA)
      000000                        411 	.org 0x0000
                           0000D7   412 _CY	=	0x00d7
                           0000D6   413 _AC	=	0x00d6
                           0000D5   414 _F0	=	0x00d5
                           0000D4   415 _RS1	=	0x00d4
                           0000D3   416 _RS0	=	0x00d3
                           0000D2   417 _OV	=	0x00d2
                           0000D1   418 _F1	=	0x00d1
                           0000D0   419 _P	=	0x00d0
                           0000AF   420 _EA	=	0x00af
                           0000AE   421 _E_DIS	=	0x00ae
                           0000AD   422 _ET2	=	0x00ad
                           0000AC   423 _ES	=	0x00ac
                           0000AB   424 _ET1	=	0x00ab
                           0000AA   425 _EX1	=	0x00aa
                           0000A9   426 _ET0	=	0x00a9
                           0000A8   427 _EX0	=	0x00a8
                           0000BF   428 _PH_FLAG	=	0x00bf
                           0000BE   429 _PL_FLAG	=	0x00be
                           0000BD   430 _PT2	=	0x00bd
                           0000BC   431 _PS	=	0x00bc
                           0000BB   432 _PT1	=	0x00bb
                           0000BA   433 _PX1	=	0x00ba
                           0000B9   434 _PT0	=	0x00b9
                           0000B8   435 _PX0	=	0x00b8
                           0000EF   436 _IE_WDOG	=	0x00ef
                           0000EE   437 _IE_GPIO	=	0x00ee
                           0000ED   438 _IE_PWM_I2C	=	0x00ed
                           0000EC   439 _IE_UART1	=	0x00ec
                           0000EB   440 _IE_ADC	=	0x00eb
                           0000E9   441 _IE_USB	=	0x00e9
                           0000E8   442 _IE_SPI0	=	0x00e8
                           000087   443 _P0_7	=	0x0087
                           000086   444 _P0_6	=	0x0086
                           000085   445 _P0_5	=	0x0085
                           000084   446 _P0_4	=	0x0084
                           000083   447 _P0_3	=	0x0083
                           000082   448 _P0_2	=	0x0082
                           000081   449 _P0_1	=	0x0081
                           000080   450 _P0_0	=	0x0080
                           000081   451 _SDA0	=	0x0081
                           000080   452 _SCL0	=	0x0080
                           000083   453 _TXD_	=	0x0083
                           000082   454 _RXD_	=	0x0082
                           000085   455 _AIN13	=	0x0085
                           000084   456 _AIN12	=	0x0084
                           000083   457 _AIN11	=	0x0083
                           000082   458 _AIN10	=	0x0082
                           000081   459 _AIN9	=	0x0081
                           000080   460 _AIN8	=	0x0080
                           000097   461 _P1_7	=	0x0097
                           000096   462 _P1_6	=	0x0096
                           000095   463 _P1_5	=	0x0095
                           000094   464 _P1_4	=	0x0094
                           000093   465 _P1_3	=	0x0093
                           000092   466 _P1_2	=	0x0092
                           000091   467 _P1_1	=	0x0091
                           000090   468 _P1_0	=	0x0090
                           000097   469 _TXD1_	=	0x0097
                           000096   470 _RXD1_	=	0x0096
                           000097   471 _SCK	=	0x0097
                           000096   472 _MISO	=	0x0096
                           000095   473 _MOSI	=	0x0095
                           000094   474 _SCS	=	0x0094
                           000092   475 _INT0_	=	0x0092
                           000091   476 _T2EX	=	0x0091
                           000091   477 _CAP2	=	0x0091
                           000090   478 _T2	=	0x0090
                           000090   479 _CAP1	=	0x0090
                           000097   480 _AIN7	=	0x0097
                           000096   481 _AIN6	=	0x0096
                           000095   482 _AIN5	=	0x0095
                           000094   483 _AIN4	=	0x0094
                           000093   484 _AIN3	=	0x0093
                           000092   485 _AIN2	=	0x0092
                           000091   486 _AIN1	=	0x0091
                           000090   487 _AIN0	=	0x0090
                           0000A7   488 _P2_7	=	0x00a7
                           0000A6   489 _P2_6	=	0x00a6
                           0000A5   490 _P2_5	=	0x00a5
                           0000A4   491 _P2_4	=	0x00a4
                           0000A3   492 _P2_3	=	0x00a3
                           0000A2   493 _P2_2	=	0x00a2
                           0000A1   494 _P2_1	=	0x00a1
                           0000A0   495 _P2_0	=	0x00a0
                           0000A7   496 _TXD1	=	0x00a7
                           0000A6   497 _RXD1	=	0x00a6
                           0000A5   498 _T2EX_	=	0x00a5
                           0000A5   499 _CAP2_	=	0x00a5
                           0000A4   500 _T2_	=	0x00a4
                           0000A4   501 _CAP1_	=	0x00a4
                           0000B7   502 _P3_7	=	0x00b7
                           0000B6   503 _P3_6	=	0x00b6
                           0000B5   504 _P3_5	=	0x00b5
                           0000B4   505 _P3_4	=	0x00b4
                           0000B3   506 _P3_3	=	0x00b3
                           0000B2   507 _P3_2	=	0x00b2
                           0000B1   508 _P3_1	=	0x00b1
                           0000B0   509 _P3_0	=	0x00b0
                           0000B7   510 _SCK1	=	0x00b7
                           0000B6   511 _MISO1	=	0x00b6
                           0000B5   512 _MOSI1	=	0x00b5
                           0000B5   513 _T1	=	0x00b5
                           0000B4   514 _T0	=	0x00b4
                           0000B3   515 _INT1	=	0x00b3
                           0000B2   516 _INT0	=	0x00b2
                           0000B1   517 _TXD	=	0x00b1
                           0000B0   518 _RXD	=	0x00b0
                           0000C6   519 _P4_6	=	0x00c6
                           0000C5   520 _P4_5	=	0x00c5
                           0000C4   521 _P4_4	=	0x00c4
                           0000C3   522 _P4_3	=	0x00c3
                           0000C2   523 _P4_2	=	0x00c2
                           0000C1   524 _P4_1	=	0x00c1
                           0000C0   525 _P4_0	=	0x00c0
                           00008F   526 _TF1	=	0x008f
                           00008E   527 _TR1	=	0x008e
                           00008D   528 _TF0	=	0x008d
                           00008C   529 _TR0	=	0x008c
                           00008B   530 _IE1	=	0x008b
                           00008A   531 _IT1	=	0x008a
                           000089   532 _IE0	=	0x0089
                           000088   533 _IT0	=	0x0088
                           00009F   534 _SM0	=	0x009f
                           00009E   535 _SM1	=	0x009e
                           00009D   536 _SM2	=	0x009d
                           00009C   537 _REN	=	0x009c
                           00009B   538 _TB8	=	0x009b
                           00009A   539 _RB8	=	0x009a
                           000099   540 _TI	=	0x0099
                           000098   541 _RI	=	0x0098
                           0000CF   542 _TF2	=	0x00cf
                           0000CF   543 _CAP1F	=	0x00cf
                           0000CE   544 _EXF2	=	0x00ce
                           0000CD   545 _RCLK	=	0x00cd
                           0000CC   546 _TCLK	=	0x00cc
                           0000CB   547 _EXEN2	=	0x00cb
                           0000CA   548 _TR2	=	0x00ca
                           0000C9   549 _C_T2	=	0x00c9
                           0000C8   550 _CP_RL2	=	0x00c8
                           0000FF   551 _S0_FST_ACT	=	0x00ff
                           0000FE   552 _S0_IF_OV	=	0x00fe
                           0000FD   553 _S0_IF_FIRST	=	0x00fd
                           0000FC   554 _S0_IF_BYTE	=	0x00fc
                           0000FB   555 _S0_FREE	=	0x00fb
                           0000FA   556 _S0_T_FIFO	=	0x00fa
                           0000F8   557 _S0_R_FIFO	=	0x00f8
                           0000F7   558 _ADC_START	=	0x00f7
                                    559 ;--------------------------------------------------------
                                    560 ; overlayable register banks
                                    561 ;--------------------------------------------------------
                                    562 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        563 	.ds 8
                                    564 ;--------------------------------------------------------
                                    565 ; internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area DSEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable items in internal ram
                                    570 ;--------------------------------------------------------
                                    571 ;--------------------------------------------------------
                                    572 ; indirectly addressable internal ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area ISEG    (DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; absolute internal ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area IABS    (ABS,DATA)
                                    579 	.area IABS    (ABS,DATA)
                                    580 ;--------------------------------------------------------
                                    581 ; bit data
                                    582 ;--------------------------------------------------------
                                    583 	.area BSEG    (BIT)
      000026                        584 _get_record_keycode_sloc0_1_0:
      000026                        585 	.ds 1
      000027                        586 _pre_process_record_quantum_sloc0_1_0:
      000027                        587 	.ds 1
      000028                        588 _process_ak820_nkro_sloc0_1_0:
      000028                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; paged external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area PSEG    (PAG,XDATA)
                                    594 ;--------------------------------------------------------
                                    595 ; uninitialized external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XSEG    (XDATA)
      000C20                        598 _extract_mod_bits_code_10000_623:
      000C20                        599 	.ds 2
      000C22                        600 _register_code16_code_10000_629:
      000C22                        601 	.ds 2
      000C24                        602 _unregister_code16_code_10000_634:
      000C24                        603 	.ds 2
      000C26                        604 _pre_process_record_kb_PARM_2:
      000C26                        605 	.ds 3
      000C29                        606 _pre_process_record_kb_keycode_10000_648:
      000C29                        607 	.ds 2
      000C2B                        608 _pre_process_record_user_PARM_2:
      000C2B                        609 	.ds 3
      000C2E                        610 _process_record_kb_PARM_2:
      000C2E                        611 	.ds 3
      000C31                        612 _process_record_kb_keycode_10000_654:
      000C31                        613 	.ds 2
      000C33                        614 _process_record_user_PARM_2:
      000C33                        615 	.ds 3
      000C36                        616 _post_process_record_kb_PARM_2:
      000C36                        617 	.ds 3
      000C39                        618 _post_process_record_kb_keycode_10000_658:
      000C39                        619 	.ds 2
      000C3B                        620 _post_process_record_user_PARM_2:
      000C3B                        621 	.ds 3
      000C3E                        622 _get_record_keycode_PARM_2:
      000C3E                        623 	.ds 1
      000C3F                        624 _get_record_keycode_record_argument_10000_672:
      000C3F                        625 	.ds 2
      000C41                        626 _pre_process_record_quantum_record_argument_10000_678:
      000C41                        627 	.ds 2
      000C43                        628 _post_process_record_quantum_record_10000_680:
      000C43                        629 	.ds 2
      000C45                        630 _process_record_quantum_record_10000_682:
      000C45                        631 	.ds 2
      000C47                        632 _process_ak820_nkro_PARM_2:
      000C47                        633 	.ds 3
      000C4A                        634 _process_ak820_nkro_keycode_10000_684:
      000C4A                        635 	.ds 2
      000C4C                        636 _process_record_quantum_helper_PARM_2:
      000C4C                        637 	.ds 2
      000C4E                        638 _process_record_quantum_helper_keycode_10000_689:
      000C4E                        639 	.ds 2
      000C50                        640 _get_u8_str_last_num_10000_715:
      000C50                        641 	.ds 1
      000C51                        642 _get_u16_str_last_num_10000_719:
      000C51                        643 	.ds 2
                                    644 ;--------------------------------------------------------
                                    645 ; absolute external ram data
                                    646 ;--------------------------------------------------------
                                    647 	.area XABS    (ABS,XDATA)
                                    648 ;--------------------------------------------------------
                                    649 ; initialized external ram data
                                    650 ;--------------------------------------------------------
                                    651 	.area XISEG   (XDATA)
                                    652 	.area HOME    (CODE)
                                    653 	.area GSINIT0 (CODE)
                                    654 	.area GSINIT1 (CODE)
                                    655 	.area GSINIT2 (CODE)
                                    656 	.area GSINIT3 (CODE)
                                    657 	.area GSINIT4 (CODE)
                                    658 	.area GSINIT5 (CODE)
                                    659 	.area GSINIT  (CODE)
                                    660 	.area GSFINAL (CODE)
                                    661 	.area CSEG    (CODE)
                                    662 ;--------------------------------------------------------
                                    663 ; global & static initialisations
                                    664 ;--------------------------------------------------------
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT  (CODE)
                                    667 	.area GSFINAL (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 ;------------------------------------------------------------
                                    670 ;Allocation info for local variables in function 'get_u8_str'
                                    671 ;------------------------------------------------------------
                                    672 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    673 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_714'
                                    674 ;buf           Allocated with name '_get_u8_str_buf_10000_715'
                                    675 ;last_num      Allocated with name '_get_u8_str_last_num_10000_715'
                                    676 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_715'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/quantum.c:778: static uint8_t last_num = 0xFF;
      0030F3 90 0C 50         [24]  679 	mov	dptr,#_get_u8_str_last_num_10000_715
      0030F6 74 FF            [12]  680 	mov	a,#0xff
      0030F8 F0               [24]  681 	movx	@dptr,a
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'get_u16_str'
                                    684 ;------------------------------------------------------------
                                    685 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    686 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_718'
                                    687 ;buf           Allocated with name '_get_u16_str_buf_10000_719'
                                    688 ;last_num      Allocated with name '_get_u16_str_last_num_10000_719'
                                    689 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_719'
                                    690 ;------------------------------------------------------------
                                    691 ;	quantum/quantum.c:798: static uint16_t last_num = 0xFF;
      0030F9 90 0C 51         [24]  692 	mov	dptr,#_get_u16_str_last_num_10000_719
      0030FC 74 FF            [12]  693 	mov	a,#0xff
      0030FE F0               [24]  694 	movx	@dptr,a
      0030FF E4               [12]  695 	clr	a
      003100 A3               [24]  696 	inc	dptr
      003101 F0               [24]  697 	movx	@dptr,a
                                    698 ;--------------------------------------------------------
                                    699 ; Home
                                    700 ;--------------------------------------------------------
                                    701 	.area HOME    (CODE)
                                    702 	.area HOME    (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; code
                                    705 ;--------------------------------------------------------
                                    706 	.area CSEG    (CODE)
                                    707 ;------------------------------------------------------------
                                    708 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    709 ;------------------------------------------------------------
                                    710 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    711 ;------------------------------------------------------------
                                    712 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    713 ;	-----------------------------------------
                           000007   714 	ar7 = 0x07
                           000006   715 	ar6 = 0x06
                           000005   716 	ar5 = 0x05
                           000004   717 	ar4 = 0x04
                           000003   718 	ar3 = 0x03
                           000002   719 	ar2 = 0x02
                           000001   720 	ar1 = 0x01
                           000000   721 	ar0 = 0x00
                                    722 ;	 function extract_mod_bits
                                    723 ;	-----------------------------------------
      00A142                        724 _extract_mod_bits:
      00A142 12 38 8A         [24]  725 	lcall	_ak820_outline_0108
      00A145 90 0C 20         [24]  726 	mov	dptr,#_extract_mod_bits_code_10000_623
      00A148 12 38 8F         [24]  727 	lcall	_ak820_outline_0109
                                    728 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A14B 90 0C 20         [24]  729 	mov	dptr,#_extract_mod_bits_code_10000_623
      00A14E E0               [24]  730 	movx	a,@dptr
      00A14F A3               [24]  731 	inc	dptr
      00A150 E0               [24]  732 	movx	a,@dptr
                                    733 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A151 FF               [12]  734 	mov	r7,a
      00A152 60 05            [24]  735 	jz	00101$
      00A154 EF               [12]  736 	mov	a,r7
      00A155 24 E0            [12]  737 	add	a,#0xff - 0x1f
      00A157 50 04            [24]  738 	jnc	00102$
                                    739 ;	free result
      00A159                        740 00101$:
      00A159 75 82 00         [24]  741 	mov	dpl, #0x00
      00A15C 22               [24]  742 	ret
      00A15D                        743 00102$:
                                    744 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A15D EF               [12]  745 	mov	a,r7
      00A15E 30 E4 07         [24]  746 	jnb	acc.4,00106$
      00A161 EF               [12]  747 	mov	a,r7
      00A162 C4               [12]  748 	swap	a
      00A163 54 F0            [12]  749 	anl	a,#0xf0
      00A165 FE               [12]  750 	mov	r6,a
      00A166 80 02            [24]  751 	sjmp	00107$
      00A168                        752 00106$:
      00A168 8F 06            [24]  753 	mov	ar6,r7
      00A16A                        754 00107$:
      00A16A 8E 82            [24]  755 	mov	dpl, r6
                                    756 ;	quantum/quantum.c:143: }
      00A16C 22               [24]  757 	ret
                                    758 ;------------------------------------------------------------
                                    759 ;Allocation info for local variables in function 'do_code16'
                                    760 ;------------------------------------------------------------
                                    761 ;f             Allocated with name '_do_code16_PARM_2'
                                    762 ;code          Allocated with name '_do_code16_code_10000_626'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function register_code16
                                    767 ;	-----------------------------------------
      00A16D                        768 _register_code16:
      00A16D 12 38 8A         [24]  769 	lcall	_ak820_outline_0108
      00A170 90 0C 22         [24]  770 	mov	dptr,#_register_code16_code_10000_629
      00A173 12 38 8F         [24]  771 	lcall	_ak820_outline_0109
                                    772 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A176 90 0C 22         [24]  773 	mov	dptr,#_register_code16_code_10000_629
      00A179 12 37 E9         [24]  774 	lcall	_ak820_outline_0005
      00A17C C0 07            [24]  775 	push	ar7
      00A17E C0 06            [24]  776 	push	ar6
      00A180 31 42            [12]  777 	acall	_extract_mod_bits
      00A182 AD 82            [24]  778 	mov	r5, dpl
      00A184 D0 06            [24]  779 	pop	ar6
      00A186 D0 07            [24]  780 	pop	ar7
                                    781 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A188 12 9F 7B         [24]  782 	lcall	_ak820_outline_0124
      00A18B 40 07            [24]  783 	jc	00105$
      00A18D 74 E7            [12]  784 	mov	a,#0xe7
      00A18F 9E               [12]  785 	subb	a,r6
      00A190 E4               [12]  786 	clr	a
      00A191 9F               [12]  787 	subb	a,r7
      00A192 50 08            [24]  788 	jnc	00101$
                                    789 ;	free result
      00A194                        790 00105$:
      00A194 90 0C 22         [24]  791 	mov	dptr,#_register_code16_code_10000_629
      00A197 12 71 C3         [24]  792 	lcall	_ak820_outline_0039
      00A19A 70 07            [24]  793 	jnz	00102$
      00A19C                        794 00101$:
                                    795 ;	quantum/quantum.c:153: register_mods(mods);
      00A19C 8D 82            [24]  796 	mov	dpl, r5
      00A19E 12 7A 48         [24]  797 	lcall	_register_mods
      00A1A1 80 05            [24]  798 	sjmp	00103$
      00A1A3                        799 00102$:
                                    800 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A1A3 8D 82            [24]  801 	mov	dpl, r5
      00A1A5 12 7A 70         [24]  802 	lcall	_register_weak_mods
      00A1A8                        803 00103$:
                                    804 ;	quantum/quantum.c:157: register_code(code);
      00A1A8 90 0C 22         [24]  805 	mov	dptr,#_register_code16_code_10000_629
      00A1AB E0               [24]  806 	movx	a,@dptr
      00A1AC F5 82            [12]  807 	mov	dpl,a
                                    808 ;	quantum/quantum.c:167: }
      00A1AE 02 79 19         [24]  809 	ljmp	_register_code
                                    810 ;------------------------------------------------------------
                                    811 ;Allocation info for local variables in function 'unregister_code16'
                                    812 ;------------------------------------------------------------
                                    813 ;code          Allocated with name '_unregister_code16_code_10000_634'
                                    814 ;mods          Allocated with name '_unregister_code16_mods_10000_635'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    817 ;	-----------------------------------------
                                    818 ;	 function unregister_code16
                                    819 ;	-----------------------------------------
      00A1B1                        820 _unregister_code16:
      00A1B1 12 38 8A         [24]  821 	lcall	_ak820_outline_0108
      00A1B4 90 0C 24         [24]  822 	mov	dptr,#_unregister_code16_code_10000_634
      00A1B7 12 38 8F         [24]  823 	lcall	_ak820_outline_0109
                                    824 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A1BA 90 0C 24         [24]  825 	mov	dptr,#_unregister_code16_code_10000_634
      00A1BD 12 37 E9         [24]  826 	lcall	_ak820_outline_0005
      00A1C0 C0 07            [24]  827 	push	ar7
      00A1C2 C0 06            [24]  828 	push	ar6
      00A1C4 31 42            [12]  829 	acall	_extract_mod_bits
      00A1C6 AD 82            [24]  830 	mov	r5, dpl
      00A1C8 D0 06            [24]  831 	pop	ar6
                                    832 ;	quantum/quantum.c:172: unregister_code(code);
      00A1CA 8E 04            [24]  833 	mov	ar4,r6
      00A1CC 8C 82            [24]  834 	mov	dpl, r4
      00A1CE C0 06            [24]  835 	push	ar6
      00A1D0 C0 05            [24]  836 	push	ar5
      00A1D2 12 79 86         [24]  837 	lcall	_unregister_code
      00A1D5 D0 05            [24]  838 	pop	ar5
      00A1D7 D0 06            [24]  839 	pop	ar6
      00A1D9 D0 07            [24]  840 	pop	ar7
                                    841 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A1DB 12 9F 7B         [24]  842 	lcall	_ak820_outline_0124
      00A1DE 40 07            [24]  843 	jc	00105$
      00A1E0 74 E7            [12]  844 	mov	a,#0xe7
      00A1E2 9E               [12]  845 	subb	a,r6
      00A1E3 E4               [12]  846 	clr	a
      00A1E4 9F               [12]  847 	subb	a,r7
      00A1E5 50 08            [24]  848 	jnc	00101$
                                    849 ;	free result
      00A1E7                        850 00105$:
      00A1E7 90 0C 24         [24]  851 	mov	dptr,#_unregister_code16_code_10000_634
      00A1EA 12 71 C3         [24]  852 	lcall	_ak820_outline_0039
      00A1ED 70 05            [24]  853 	jnz	00102$
      00A1EF                        854 00101$:
                                    855 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A1EF 8D 82            [24]  856 	mov	dpl, r5
      00A1F1 02 7A 5C         [24]  857 	ljmp	_unregister_mods
      00A1F4                        858 00102$:
                                    859 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A1F4 8D 82            [24]  860 	mov	dpl, r5
                                    861 ;	quantum/quantum.c:187: }
      00A1F6 02 7A 84         [24]  862 	ljmp	_unregister_weak_mods
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'tap_code16_delay'
                                    865 ;------------------------------------------------------------
                                    866 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    867 ;code          Allocated with name '_tap_code16_delay_code_10000_639'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_20000_641'
                                    869 ;i             Allocated with name '_tap_code16_delay_i_50000_644'
                                    870 ;------------------------------------------------------------
                                    871 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function pre_process_record_kb
                                    874 ;	-----------------------------------------
      00A1F9                        875 _pre_process_record_kb:
      00A1F9 12 38 8A         [24]  876 	lcall	_ak820_outline_0108
      00A1FC 90 0C 29         [24]  877 	mov	dptr,#_pre_process_record_kb_keycode_10000_648
      00A1FF 12 38 8F         [24]  878 	lcall	_ak820_outline_0109
                                    879 ;	quantum/quantum.c:211: return pre_process_record_user(keycode, record);
      00A202 90 0C 29         [24]  880 	mov	dptr,#_pre_process_record_kb_keycode_10000_648
      00A205 12 38 36         [24]  881 	lcall	_ak820_outline_0054
      00A208 90 0C 26         [24]  882 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A20B 12 9F 72         [24]  883 	lcall	_ak820_outline_0042
      00A20E 90 0C 2B         [24]  884 	mov	dptr,#_pre_process_record_user_PARM_2
      00A211 12 A5 3F         [24]  885 	lcall	_ak820_outline_0014
                                    886 ;	quantum/quantum.c:212: }
      00A214 41 16            [12]  887 	ajmp	_pre_process_record_user
                                    888 ;------------------------------------------------------------
                                    889 ;Allocation info for local variables in function 'pre_process_record_user'
                                    890 ;------------------------------------------------------------
                                    891 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    892 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_650'
                                    893 ;------------------------------------------------------------
                                    894 ;	quantum/quantum.c:214: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    895 ;	-----------------------------------------
                                    896 ;	 function pre_process_record_user
                                    897 ;	-----------------------------------------
      00A216                        898 _pre_process_record_user:
                                    899 ;	quantum/quantum.c:215: return true;
      00A216 75 82 01         [24]  900 	mov	dpl, #0x01
                                    901 ;	quantum/quantum.c:216: }
      00A219 22               [24]  902 	ret
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'process_action_kb'
                                    905 ;------------------------------------------------------------
                                    906 ;record        Allocated with name '_process_action_kb_record_10000_652'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/quantum.c:218: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function process_action_kb
                                    911 ;	-----------------------------------------
      00A21A                        912 _process_action_kb:
                                    913 ;	quantum/quantum.c:219: return true;
      00A21A 75 82 01         [24]  914 	mov	dpl, #0x01
                                    915 ;	quantum/quantum.c:220: }
      00A21D 22               [24]  916 	ret
                                    917 ;------------------------------------------------------------
                                    918 ;Allocation info for local variables in function 'process_record_kb'
                                    919 ;------------------------------------------------------------
                                    920 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    921 ;keycode       Allocated with name '_process_record_kb_keycode_10000_654'
                                    922 ;------------------------------------------------------------
                                    923 ;	quantum/quantum.c:222: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function process_record_kb
                                    926 ;	-----------------------------------------
      00A21E                        927 _process_record_kb:
      00A21E 12 38 8A         [24]  928 	lcall	_ak820_outline_0108
      00A221 90 0C 31         [24]  929 	mov	dptr,#_process_record_kb_keycode_10000_654
      00A224 12 38 8F         [24]  930 	lcall	_ak820_outline_0109
                                    931 ;	quantum/quantum.c:223: return process_record_user(keycode, record);
      00A227 90 0C 31         [24]  932 	mov	dptr,#_process_record_kb_keycode_10000_654
      00A22A 12 38 36         [24]  933 	lcall	_ak820_outline_0054
      00A22D 90 0C 2E         [24]  934 	mov	dptr,#_process_record_kb_PARM_2
      00A230 12 9F 72         [24]  935 	lcall	_ak820_outline_0042
      00A233 90 0C 33         [24]  936 	mov	dptr,#_process_record_user_PARM_2
      00A236 12 A5 3F         [24]  937 	lcall	_ak820_outline_0014
                                    938 ;	quantum/quantum.c:224: }
      00A239 41 3B            [12]  939 	ajmp	_process_record_user
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'process_record_user'
                                    942 ;------------------------------------------------------------
                                    943 ;record        Allocated with name '_process_record_user_PARM_2'
                                    944 ;keycode       Allocated with name '_process_record_user_keycode_10000_656'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/quantum.c:226: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function process_record_user
                                    949 ;	-----------------------------------------
      00A23B                        950 _process_record_user:
                                    951 ;	quantum/quantum.c:227: return true;
      00A23B 75 82 01         [24]  952 	mov	dpl, #0x01
                                    953 ;	quantum/quantum.c:228: }
      00A23E 22               [24]  954 	ret
                                    955 ;------------------------------------------------------------
                                    956 ;Allocation info for local variables in function 'post_process_record_kb'
                                    957 ;------------------------------------------------------------
                                    958 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    959 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_658'
                                    960 ;------------------------------------------------------------
                                    961 ;	quantum/quantum.c:230: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    962 ;	-----------------------------------------
                                    963 ;	 function post_process_record_kb
                                    964 ;	-----------------------------------------
      00A23F                        965 _post_process_record_kb:
      00A23F 12 38 8A         [24]  966 	lcall	_ak820_outline_0108
      00A242 90 0C 39         [24]  967 	mov	dptr,#_post_process_record_kb_keycode_10000_658
      00A245 12 38 8F         [24]  968 	lcall	_ak820_outline_0109
                                    969 ;	quantum/quantum.c:231: post_process_record_user(keycode, record);
      00A248 90 0C 39         [24]  970 	mov	dptr,#_post_process_record_kb_keycode_10000_658
      00A24B 12 38 36         [24]  971 	lcall	_ak820_outline_0054
      00A24E 90 0C 36         [24]  972 	mov	dptr,#_post_process_record_kb_PARM_2
      00A251 12 9F 72         [24]  973 	lcall	_ak820_outline_0042
      00A254 90 0C 3B         [24]  974 	mov	dptr,#_post_process_record_user_PARM_2
      00A257 12 A5 3F         [24]  975 	lcall	_ak820_outline_0014
                                    976 ;	quantum/quantum.c:232: }
      00A25A 41 5C            [24]  977 	ajmp	_post_process_record_user
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'post_process_record_user'
                                    980 ;------------------------------------------------------------
                                    981 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    982 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_660'
                                    983 ;------------------------------------------------------------
                                    984 ;	quantum/quantum.c:234: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    985 ;	-----------------------------------------
                                    986 ;	 function post_process_record_user
                                    987 ;	-----------------------------------------
      00A25C                        988 _post_process_record_user:
      00A25C 22               [24]  989 	ret
                                    990 ;------------------------------------------------------------
                                    991 ;Allocation info for local variables in function 'shutdown_quantum'
                                    992 ;------------------------------------------------------------
                                    993 ;i             Allocated with name '_shutdown_quantum_i_30000_666'
                                    994 ;------------------------------------------------------------
                                    995 ;	quantum/quantum.c:236: void shutdown_quantum(void) {
                                    996 ;	-----------------------------------------
                                    997 ;	 function shutdown_quantum
                                    998 ;	-----------------------------------------
      00A25D                        999 _shutdown_quantum:
                                   1000 ;	quantum/quantum.c:237: clear_keyboard();
      00A25D 12 7A 98         [24] 1001 	lcall	_clear_keyboard
                                   1002 ;	quantum/quantum.c:252: shutdown_user();
      00A260 B1 31            [12] 1003 	acall	_shutdown_user
                                   1004 ;	quantum/quantum.c:253: wait_ms(250);
      00A262 7F FA            [12] 1005 	mov	r7,#0xfa
      00A264                       1006 00106$:
      00A264 EF               [12] 1007 	mov	a,r7
      00A265 60 09            [24] 1008 	jz	00108$
      00A267 90 00 01         [24] 1009 	mov	dptr,#0x0001
      00A26A 12 5D 31         [24] 1010 	lcall	_mDelaymS
      00A26D 1F               [12] 1011 	dec	r7
      00A26E 80 F4            [24] 1012 	sjmp	00106$
      00A270                       1013 00108$:
                                   1014 ;	quantum/quantum.c:258: }
      00A270 22               [24] 1015 	ret
                                   1016 ;------------------------------------------------------------
                                   1017 ;Allocation info for local variables in function 'reset_keyboard'
                                   1018 ;------------------------------------------------------------
                                   1019 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                   1020 ;	-----------------------------------------
                                   1021 ;	 function reset_keyboard
                                   1022 ;	-----------------------------------------
      00A271                       1023 _reset_keyboard:
                                   1024 ;	quantum/quantum.c:261: shutdown_quantum();
      00A271 51 5D            [24] 1025 	acall	_shutdown_quantum
                                   1026 ;	quantum/quantum.c:262: bootloader_jump();
                                   1027 ;	quantum/quantum.c:263: }
      00A273 02 34 0E         [24] 1028 	ljmp	_bootloader_jump
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function soft_reset_keyboard
                                   1035 ;	-----------------------------------------
      00A276                       1036 _soft_reset_keyboard:
                                   1037 ;	quantum/quantum.c:266: shutdown_quantum();
      00A276 51 5D            [24] 1038 	acall	_shutdown_quantum
                                   1039 ;	quantum/quantum.c:267: mcu_reset();
                                   1040 ;	quantum/quantum.c:268: }
      00A278 02 34 01         [24] 1041 	ljmp	_mcu_reset
                                   1042 ;------------------------------------------------------------
                                   1043 ;Allocation info for local variables in function 'get_record_keycode'
                                   1044 ;------------------------------------------------------------
                                   1045 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1046 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_672'
                                   1047 ;record        Allocated with name '_get_record_keycode_record_10000_673'
                                   1048 ;------------------------------------------------------------
                                   1049 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                   1050 ;	-----------------------------------------
                                   1051 ;	 function get_record_keycode
                                   1052 ;	-----------------------------------------
      00A27B                       1053 _get_record_keycode:
      00A27B 12 38 8A         [24] 1054 	lcall	_ak820_outline_0108
      00A27E 90 0C 3F         [24] 1055 	mov	dptr,#_get_record_keycode_record_argument_10000_672
      00A281 12 38 8F         [24] 1056 	lcall	_ak820_outline_0109
                                   1057 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A284 90 0C 3F         [24] 1058 	mov	dptr,#_get_record_keycode_record_argument_10000_672
      00A287 12 37 F3         [24] 1059 	lcall	_ak820_outline_0008
                                   1060 ;	quantum/quantum.c:278: if (record->keycode) {
      00A28A 4C               [12] 1061 	orl	a,r4
      00A28B 60 04            [24] 1062 	jz	00102$
                                   1063 ;	quantum/quantum.c:279: return record->keycode;
      00A28D 12 38 99         [24] 1064 	lcall	_ak820_outline_0127
      00A290 22               [24] 1065 	ret
      00A291                       1066 00102$:
                                   1067 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A291 12 7A D7         [24] 1068 	lcall	_ak820_outline_0023
      00A294 7A 00            [12] 1069 	mov	r2,#0x00
      00A296 12 43 72         [24] 1070 	lcall	_ak820_outline_0147
      00A299 12 38 07         [24] 1071 	lcall	_ak820_outline_0011
      00A29C 60 06            [24] 1072 	jz	00105$
      00A29E 90 0C 3E         [24] 1073 	mov	dptr,#_get_record_keycode_PARM_2
      00A2A1 E0               [24] 1074 	movx	a,@dptr
      00A2A2 70 04            [24] 1075 	jnz	00106$
      00A2A4                       1076 00105$:
                                   1077 ;	assignBit
      00A2A4 C2 26            [12] 1078 	clr	_get_record_keycode_sloc0_1_0
      00A2A6 80 02            [24] 1079 	sjmp	00107$
      00A2A8                       1080 00106$:
                                   1081 ;	assignBit
      00A2A8 D2 26            [12] 1082 	setb	_get_record_keycode_sloc0_1_0
      00A2AA                       1083 00107$:
      00A2AA 90 09 B2         [24] 1084 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A2AD A2 26            [12] 1085 	mov	c,_get_record_keycode_sloc0_1_0
      00A2AF E4               [12] 1086 	clr	a
      00A2B0 33               [12] 1087 	rlc	a
      00A2B1 F0               [24] 1088 	movx	@dptr,a
      00A2B2 12 43 88         [24] 1089 	lcall	_ak820_outline_0187
                                   1090 ;	quantum/quantum.c:287: }
      00A2B5 02 7E 5B         [24] 1091 	ljmp	_ak820_resolve_key
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'get_event_keycode'
                                   1094 ;------------------------------------------------------------
                                   1095 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1096 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_676'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function pre_process_record_quantum
                                   1101 ;	-----------------------------------------
      00A2B8                       1102 _pre_process_record_quantum:
      00A2B8 12 38 8A         [24] 1103 	lcall	_ak820_outline_0108
      00A2BB 90 0C 41         [24] 1104 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_678
      00A2BE 12 38 8F         [24] 1105 	lcall	_ak820_outline_0109
                                   1106 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A2C1 90 0C 41         [24] 1107 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_678
      00A2C4 12 38 36         [24] 1108 	lcall	_ak820_outline_0054
                                   1109 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A2C7 90 0C 3E         [24] 1110 	mov	dptr,#_get_record_keycode_PARM_2
      00A2CA 74 01            [12] 1111 	mov	a,#0x01
      00A2CC 12 43 35         [24] 1112 	lcall	_ak820_outline_0062
      00A2CF C0 07            [24] 1113 	push	ar7
      00A2D1 C0 06            [24] 1114 	push	ar6
      00A2D3 51 7B            [24] 1115 	acall	_get_record_keycode
      00A2D5 12 38 AD         [24] 1116 	lcall	_ak820_outline_0149
      00A2D8 D0 06            [24] 1117 	pop	ar6
      00A2DA D0 07            [24] 1118 	pop	ar7
                                   1119 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A2DC 74 07            [12] 1120 	mov	a,#0x07
      00A2DE 12 38 26         [24] 1121 	lcall	_ak820_outline_0020
      00A2E1 12 38 53         [24] 1122 	lcall	_ak820_outline_0073
                                   1123 ;	quantum/quantum.c:353: return pre_process_record_kb(keycode, record) &&
      00A2E4 90 0C 26         [24] 1124 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A2E7 12 A5 32         [24] 1125 	lcall	_ak820_outline_0001
      00A2EA C0 07            [24] 1126 	push	ar7
      00A2EC C0 06            [24] 1127 	push	ar6
      00A2EE 31 F9            [12] 1128 	acall	_pre_process_record_kb
      00A2F0 E5 82            [12] 1129 	mov	a, dpl
      00A2F2 D0 06            [24] 1130 	pop	ar6
      00A2F4 D0 07            [24] 1131 	pop	ar7
      00A2F6 60 0A            [24] 1132 	jz	00103$
                                   1133 ;	quantum/quantum.c:356: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A2F8 12 38 94         [24] 1134 	lcall	_ak820_outline_0123
      00A2FB 12 36 3E         [24] 1135 	lcall	_ak820_combo_process
      00A2FE E5 82            [12] 1136 	mov	a, dpl
      00A300 70 04            [24] 1137 	jnz	00104$
                                   1138 ;	quantum/quantum.c:361: true;
      00A302                       1139 00103$:
                                   1140 ;	assignBit
      00A302 C2 27            [12] 1141 	clr	_pre_process_record_quantum_sloc0_1_0
      00A304 80 02            [24] 1142 	sjmp	00105$
      00A306                       1143 00104$:
                                   1144 ;	assignBit
      00A306 D2 27            [12] 1145 	setb	_pre_process_record_quantum_sloc0_1_0
      00A308                       1146 00105$:
      00A308 A2 27            [12] 1147 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A30A 12 38 B2         [24] 1148 	lcall	_ak820_outline_0154
                                   1149 ;	quantum/quantum.c:362: }
      00A30D 22               [24] 1150 	ret
                                   1151 ;------------------------------------------------------------
                                   1152 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1153 ;------------------------------------------------------------
                                   1154 ;record        Allocated with name '_post_process_record_quantum_record_10000_680'
                                   1155 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_681'
                                   1156 ;------------------------------------------------------------
                                   1157 ;	quantum/quantum.c:365: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1158 ;	-----------------------------------------
                                   1159 ;	 function post_process_record_quantum
                                   1160 ;	-----------------------------------------
      00A30E                       1161 _post_process_record_quantum:
      00A30E 12 38 8A         [24] 1162 	lcall	_ak820_outline_0108
      00A311 90 0C 43         [24] 1163 	mov	dptr,#_post_process_record_quantum_record_10000_680
      00A314 12 38 8F         [24] 1164 	lcall	_ak820_outline_0109
                                   1165 ;	quantum/quantum.c:366: uint16_t keycode = get_record_keycode(record, false);
      00A317 90 0C 43         [24] 1166 	mov	dptr,#_post_process_record_quantum_record_10000_680
      00A31A 12 38 36         [24] 1167 	lcall	_ak820_outline_0054
      00A31D 90 0C 3E         [24] 1168 	mov	dptr,#_get_record_keycode_PARM_2
      00A320 E4               [12] 1169 	clr	a
      00A321 12 43 35         [24] 1170 	lcall	_ak820_outline_0062
      00A324 51 7B            [24] 1171 	acall	_get_record_keycode
      00A326 12 43 61         [24] 1172 	lcall	_ak820_outline_0136
                                   1173 ;	quantum/quantum.c:367: post_process_record_kb(keycode, record);
      00A329 90 0C 43         [24] 1174 	mov	dptr,#_post_process_record_quantum_record_10000_680
      00A32C 12 38 72         [24] 1175 	lcall	_ak820_outline_0102
      00A32F 7D 00            [12] 1176 	mov	r5,#0x00
      00A331 90 0C 36         [24] 1177 	mov	dptr,#_post_process_record_kb_PARM_2
      00A334 12 A5 3F         [24] 1178 	lcall	_ak820_outline_0014
                                   1179 ;	quantum/quantum.c:368: }
      00A337 41 3F            [12] 1180 	ajmp	_post_process_record_kb
                                   1181 ;------------------------------------------------------------
                                   1182 ;Allocation info for local variables in function 'process_record_quantum'
                                   1183 ;------------------------------------------------------------
                                   1184 ;record        Allocated with name '_process_record_quantum_record_10000_682'
                                   1185 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_683'
                                   1186 ;------------------------------------------------------------
                                   1187 ;	quantum/quantum.c:370: bool process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1188 ;	-----------------------------------------
                                   1189 ;	 function process_record_quantum
                                   1190 ;	-----------------------------------------
      00A339                       1191 _process_record_quantum:
      00A339 12 38 8A         [24] 1192 	lcall	_ak820_outline_0108
      00A33C 90 0C 45         [24] 1193 	mov	dptr,#_process_record_quantum_record_10000_682
      00A33F 12 38 8F         [24] 1194 	lcall	_ak820_outline_0109
                                   1195 ;	quantum/quantum.c:372: uint16_t keycode = get_record_keycode(record, false);
      00A342 90 0C 45         [24] 1196 	mov	dptr,#_process_record_quantum_record_10000_682
      00A345 12 38 36         [24] 1197 	lcall	_ak820_outline_0054
      00A348 90 0C 3E         [24] 1198 	mov	dptr,#_get_record_keycode_PARM_2
      00A34B E4               [12] 1199 	clr	a
      00A34C 12 43 35         [24] 1200 	lcall	_ak820_outline_0062
      00A34F 51 7B            [24] 1201 	acall	_get_record_keycode
      00A351 12 43 61         [24] 1202 	lcall	_ak820_outline_0136
                                   1203 ;	quantum/quantum.c:376: return process_record_quantum_helper(keycode, record);
      00A354 90 0C 45         [24] 1204 	mov	dptr,#_process_record_quantum_record_10000_682
      00A357 12 38 4D         [24] 1205 	lcall	_ak820_outline_0060
      00A35A 90 0C 4C         [24] 1206 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A35D EC               [12] 1207 	mov	a,r4
      00A35E F0               [24] 1208 	movx	@dptr,a
      00A35F ED               [12] 1209 	mov	a,r5
      00A360 A3               [24] 1210 	inc	dptr
      00A361 12 43 35         [24] 1211 	lcall	_ak820_outline_0062
                                   1212 ;	quantum/quantum.c:377: }
      00A364 61 D1            [24] 1213 	ajmp	_process_record_quantum_helper
                                   1214 ;------------------------------------------------------------
                                   1215 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1216 ;------------------------------------------------------------
                                   1217 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1218 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_684'
                                   1219 ;record        Allocated with name '_process_ak820_nkro_record_10000_685'
                                   1220 ;------------------------------------------------------------
                                   1221 ;	quantum/quantum.c:394: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1222 ;	-----------------------------------------
                                   1223 ;	 function process_ak820_nkro
                                   1224 ;	-----------------------------------------
      00A366                       1225 _process_ak820_nkro:
      00A366 12 38 8A         [24] 1226 	lcall	_ak820_outline_0108
      00A369 90 0C 4A         [24] 1227 	mov	dptr,#_process_ak820_nkro_keycode_10000_684
      00A36C 12 38 8F         [24] 1228 	lcall	_ak820_outline_0109
                                   1229 ;	quantum/quantum.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A36F 90 0C 47         [24] 1230 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A372 12 38 36         [24] 1231 	lcall	_ak820_outline_0054
                                   1232 ;	quantum/quantum.c:400: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A375 90 0C 4A         [24] 1233 	mov	dptr,#_process_ak820_nkro_keycode_10000_684
      00A378 12 38 4D         [24] 1234 	lcall	_ak820_outline_0060
      00A37B C3               [12] 1235 	clr	c
      00A37C EC               [12] 1236 	mov	a,r4
      00A37D 94 11            [12] 1237 	subb	a,#0x11
      00A37F ED               [12] 1238 	mov	a,r5
      00A380 94 70            [12] 1239 	subb	a,#0x70
      00A382 40 08            [24] 1240 	jc	00101$
      00A384 74 13            [12] 1241 	mov	a,#0x13
      00A386 9C               [12] 1242 	subb	a,r4
      00A387 74 70            [12] 1243 	mov	a,#0x70
      00A389 9D               [12] 1244 	subb	a,r5
      00A38A 50 04            [24] 1245 	jnc	00102$
                                   1246 ;	free result
      00A38C                       1247 00101$:
      00A38C 75 82 01         [24] 1248 	mov	dpl, #0x01
      00A38F 22               [24] 1249 	ret
      00A390                       1250 00102$:
                                   1251 ;	quantum/quantum.c:401: if (record->event.pressed) {
      00A390 12 38 07         [24] 1252 	lcall	_ak820_outline_0011
      00A393 60 38            [24] 1253 	jz	00105$
                                   1254 ;	quantum/quantum.c:402: clear_keyboard();
      00A395 C0 05            [24] 1255 	push	ar5
      00A397 C0 04            [24] 1256 	push	ar4
      00A399 12 7A 98         [24] 1257 	lcall	_clear_keyboard
      00A39C D0 04            [24] 1258 	pop	ar4
      00A39E D0 05            [24] 1259 	pop	ar5
                                   1260 ;	quantum/quantum.c:403: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A3A0 BC 13 14         [24] 1261 	cjne	r4,#0x13,00108$
      00A3A3 BD 70 11         [24] 1262 	cjne	r5,#0x70,00108$
      00A3A6 90 0B 04         [24] 1263 	mov	dptr,#_keymap_config
      00A3A9 E0               [24] 1264 	movx	a,@dptr
      00A3AA 23               [12] 1265 	rl	a
      00A3AB 54 01            [12] 1266 	anl	a,#0x01
      00A3AD B4 01 00         [24] 1267 	cjne	a,#0x01,00136$
      00A3B0                       1268 00136$:
      00A3B0 92 28            [24] 1269 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A3B2 E4               [12] 1270 	clr	a
      00A3B3 33               [12] 1271 	rlc	a
      00A3B4 FF               [12] 1272 	mov	r7,a
      00A3B5 80 09            [24] 1273 	sjmp	00109$
      00A3B7                       1274 00108$:
      00A3B7 E4               [12] 1275 	clr	a
      00A3B8 BC 11 04         [24] 1276 	cjne	r4,#0x11,00137$
      00A3BB BD 70 01         [24] 1277 	cjne	r5,#0x70,00137$
      00A3BE 04               [12] 1278 	inc	a
      00A3BF                       1279 00137$:
      00A3BF FF               [12] 1280 	mov	r7,a
      00A3C0                       1281 00109$:
                                   1282 ;	assignBit
      00A3C0 EF               [12] 1283 	mov	a,r7
      00A3C1 24 FF            [12] 1284 	add	a,#0xff
      00A3C3 E4               [12] 1285 	clr	a
      00A3C4 33               [12] 1286 	rlc	a
      00A3C5 90 0B 04         [24] 1287 	mov	dptr,#_keymap_config
      00A3C8 13               [12] 1288 	rrc	a
      00A3C9 E0               [24] 1289 	movx	a,@dptr
      00A3CA 92 E7            [24] 1290 	mov	acc.7,c
      00A3CC F0               [24] 1291 	movx	@dptr,a
      00A3CD                       1292 00105$:
                                   1293 ;	quantum/quantum.c:405: return false;
      00A3CD 75 82 00         [24] 1294 	mov	dpl, #0x00
                                   1295 ;	quantum/quantum.c:406: }
      00A3D0 22               [24] 1296 	ret
                                   1297 ;------------------------------------------------------------
                                   1298 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1299 ;------------------------------------------------------------
                                   1300 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1301 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_689'
                                   1302 ;record        Allocated with name '_process_record_quantum_helper_record_10000_690'
                                   1303 ;------------------------------------------------------------
                                   1304 ;	quantum/quantum.c:409: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1305 ;	-----------------------------------------
                                   1306 ;	 function process_record_quantum_helper
                                   1307 ;	-----------------------------------------
      00A3D1                       1308 _process_record_quantum_helper:
      00A3D1 12 38 8A         [24] 1309 	lcall	_ak820_outline_0108
      00A3D4 90 0C 4E         [24] 1310 	mov	dptr,#_process_record_quantum_helper_keycode_10000_689
      00A3D7 12 38 8F         [24] 1311 	lcall	_ak820_outline_0109
                                   1312 ;	quantum/quantum.c:411: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A3DA 90 0C 4C         [24] 1313 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A3DD 12 38 36         [24] 1314 	lcall	_ak820_outline_0054
                                   1315 ;	quantum/quantum.c:454: process_ak820_nkro(keycode, record) &&
      00A3E0 90 0C 4E         [24] 1316 	mov	dptr,#_process_record_quantum_helper_keycode_10000_689
      00A3E3 12 38 4D         [24] 1317 	lcall	_ak820_outline_0060
      00A3E6 90 0C 47         [24] 1318 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A3E9 12 A5 32         [24] 1319 	lcall	_ak820_outline_0001
      00A3EC C0 07            [24] 1320 	push	ar7
      00A3EE C0 06            [24] 1321 	push	ar6
      00A3F0 C0 05            [24] 1322 	push	ar5
      00A3F2 C0 04            [24] 1323 	push	ar4
      00A3F4 71 66            [24] 1324 	acall	_process_ak820_nkro
      00A3F6 E5 82            [12] 1325 	mov	a, dpl
      00A3F8 D0 04            [24] 1326 	pop	ar4
      00A3FA D0 05            [24] 1327 	pop	ar5
      00A3FC D0 06            [24] 1328 	pop	ar6
      00A3FE D0 07            [24] 1329 	pop	ar7
      00A400 70 02            [24] 1330 	jnz	00204$
      00A402 81 F2            [12] 1331 	ajmp	00101$
      00A404                       1332 00204$:
                                   1333 ;	quantum/quantum.c:465: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A404 90 0C 09         [24] 1334 	mov	dptr,#_process_last_key_PARM_2
      00A407 12 A5 32         [24] 1335 	lcall	_ak820_outline_0001
      00A40A C0 07            [24] 1336 	push	ar7
      00A40C C0 06            [24] 1337 	push	ar6
      00A40E C0 05            [24] 1338 	push	ar5
      00A410 C0 04            [24] 1339 	push	ar4
      00A412 12 9E 9E         [24] 1340 	lcall	_process_last_key
      00A415 E5 82            [12] 1341 	mov	a, dpl
      00A417 D0 04            [24] 1342 	pop	ar4
      00A419 D0 05            [24] 1343 	pop	ar5
      00A41B D0 06            [24] 1344 	pop	ar6
      00A41D D0 07            [24] 1345 	pop	ar7
      00A41F 70 02            [24] 1346 	jnz	00205$
      00A421 81 F2            [12] 1347 	ajmp	00101$
      00A423                       1348 00205$:
      00A423 90 0C 0F         [24] 1349 	mov	dptr,#_process_repeat_key_PARM_2
      00A426 12 A5 32         [24] 1350 	lcall	_ak820_outline_0001
      00A429 C0 07            [24] 1351 	push	ar7
      00A42B C0 06            [24] 1352 	push	ar6
      00A42D C0 05            [24] 1353 	push	ar5
      00A42F C0 04            [24] 1354 	push	ar4
      00A431 12 9F 1B         [24] 1355 	lcall	_process_repeat_key
      00A434 E5 82            [12] 1356 	mov	a, dpl
      00A436 D0 04            [24] 1357 	pop	ar4
      00A438 D0 05            [24] 1358 	pop	ar5
      00A43A D0 06            [24] 1359 	pop	ar6
      00A43C D0 07            [24] 1360 	pop	ar7
      00A43E 70 02            [24] 1361 	jnz	00206$
      00A440 81 F2            [12] 1362 	ajmp	00101$
      00A442                       1363 00206$:
                                   1364 ;	quantum/quantum.c:474: process_record_via(keycode, record) &&
      00A442 90 0C 8B         [24] 1365 	mov	dptr,#_process_record_via_PARM_2
      00A445 12 A5 32         [24] 1366 	lcall	_ak820_outline_0001
      00A448 C0 07            [24] 1367 	push	ar7
      00A44A C0 06            [24] 1368 	push	ar6
      00A44C C0 05            [24] 1369 	push	ar5
      00A44E C0 04            [24] 1370 	push	ar4
      00A450 12 AA 34         [24] 1371 	lcall	_process_record_via
      00A453 E5 82            [12] 1372 	mov	a, dpl
      00A455 D0 04            [24] 1373 	pop	ar4
      00A457 D0 05            [24] 1374 	pop	ar5
      00A459 D0 06            [24] 1375 	pop	ar6
      00A45B D0 07            [24] 1376 	pop	ar7
      00A45D 70 02            [24] 1377 	jnz	00207$
      00A45F 81 F2            [12] 1378 	ajmp	00101$
      00A461                       1379 00207$:
                                   1380 ;	quantum/quantum.c:484: process_record_kb(keycode, record) &&
      00A461 90 0C 2E         [24] 1381 	mov	dptr,#_process_record_kb_PARM_2
      00A464 12 A5 32         [24] 1382 	lcall	_ak820_outline_0001
      00A467 C0 07            [24] 1383 	push	ar7
      00A469 C0 06            [24] 1384 	push	ar6
      00A46B C0 05            [24] 1385 	push	ar5
      00A46D C0 04            [24] 1386 	push	ar4
      00A46F 51 1E            [12] 1387 	acall	_process_record_kb
      00A471 E5 82            [12] 1388 	mov	a, dpl
      00A473 D0 04            [24] 1389 	pop	ar4
      00A475 D0 05            [24] 1390 	pop	ar5
      00A477 D0 06            [24] 1391 	pop	ar6
      00A479 D0 07            [24] 1392 	pop	ar7
      00A47B 70 02            [24] 1393 	jnz	00208$
      00A47D 81 F2            [12] 1394 	ajmp	00101$
      00A47F                       1395 00208$:
                                   1396 ;	quantum/quantum.c:507: process_caps_word(keycode, record) &&
      00A47F 90 0B F0         [24] 1397 	mov	dptr,#_process_caps_word_PARM_2
      00A482 12 A5 32         [24] 1398 	lcall	_ak820_outline_0001
      00A485 C0 07            [24] 1399 	push	ar7
      00A487 C0 06            [24] 1400 	push	ar6
      00A489 C0 05            [24] 1401 	push	ar5
      00A48B C0 04            [24] 1402 	push	ar4
      00A48D 12 9B A6         [24] 1403 	lcall	_process_caps_word
      00A490 E5 82            [12] 1404 	mov	a, dpl
      00A492 D0 04            [24] 1405 	pop	ar4
      00A494 D0 05            [24] 1406 	pop	ar5
      00A496 D0 06            [24] 1407 	pop	ar6
      00A498 D0 07            [24] 1408 	pop	ar7
      00A49A 60 56            [24] 1409 	jz	00101$
                                   1410 ;	quantum/quantum.c:537: process_grave_esc(keycode, record) &&
      00A49C 90 0B F5         [24] 1411 	mov	dptr,#_process_grave_esc_PARM_2
      00A49F 12 A5 32         [24] 1412 	lcall	_ak820_outline_0001
      00A4A2 C0 07            [24] 1413 	push	ar7
      00A4A4 C0 06            [24] 1414 	push	ar6
      00A4A6 C0 05            [24] 1415 	push	ar5
      00A4A8 C0 04            [24] 1416 	push	ar4
      00A4AA 12 9C C3         [24] 1417 	lcall	_process_grave_esc
      00A4AD E5 82            [12] 1418 	mov	a, dpl
      00A4AF D0 04            [24] 1419 	pop	ar4
      00A4B1 D0 05            [24] 1420 	pop	ar5
      00A4B3 D0 06            [24] 1421 	pop	ar6
      00A4B5 D0 07            [24] 1422 	pop	ar7
      00A4B7 60 39            [24] 1423 	jz	00101$
                                   1424 ;	quantum/quantum.c:540: process_rgb(keycode, record) &&
      00A4B9 90 0C 14         [24] 1425 	mov	dptr,#_process_rgb_PARM_2
      00A4BC 12 A5 32         [24] 1426 	lcall	_ak820_outline_0001
      00A4BF C0 07            [24] 1427 	push	ar7
      00A4C1 C0 06            [24] 1428 	push	ar6
      00A4C3 C0 05            [24] 1429 	push	ar5
      00A4C5 C0 04            [24] 1430 	push	ar4
      00A4C7 12 9F 83         [24] 1431 	lcall	_process_rgb
      00A4CA E5 82            [12] 1432 	mov	a, dpl
      00A4CC D0 04            [24] 1433 	pop	ar4
      00A4CE D0 05            [24] 1434 	pop	ar5
      00A4D0 D0 06            [24] 1435 	pop	ar6
      00A4D2 D0 07            [24] 1436 	pop	ar7
      00A4D4 60 1C            [24] 1437 	jz	00101$
                                   1438 ;	quantum/quantum.c:552: process_tri_layer(keycode, record) &&
      00A4D6 90 0C 1A         [24] 1439 	mov	dptr,#_process_tri_layer_PARM_2
      00A4D9 12 A5 32         [24] 1440 	lcall	_ak820_outline_0001
      00A4DC C0 07            [24] 1441 	push	ar7
      00A4DE C0 06            [24] 1442 	push	ar6
      00A4E0 C0 05            [24] 1443 	push	ar5
      00A4E2 C0 04            [24] 1444 	push	ar4
      00A4E4 11 34            [12] 1445 	acall	_process_tri_layer
      00A4E6 E5 82            [12] 1446 	mov	a, dpl
      00A4E8 D0 04            [24] 1447 	pop	ar4
      00A4EA D0 05            [24] 1448 	pop	ar5
      00A4EC D0 06            [24] 1449 	pop	ar6
      00A4EE D0 07            [24] 1450 	pop	ar7
      00A4F0 70 04            [24] 1451 	jnz	00102$
                                   1452 ;	quantum/quantum.c:554: true)) {
      00A4F2                       1453 00101$:
                                   1454 ;	quantum/quantum.c:555: return false;
      00A4F2 75 82 00         [24] 1455 	mov	dpl, #0x00
      00A4F5 22               [24] 1456 	ret
      00A4F6                       1457 00102$:
                                   1458 ;	quantum/quantum.c:558: if (record->event.pressed) {
      00A4F6 12 9C B6         [24] 1459 	lcall	_ak820_outline_0099
      00A4F9 60 2D            [24] 1460 	jz	00117$
                                   1461 ;	quantum/quantum.c:559: switch (keycode) {
      00A4FB BC 00 05         [24] 1462 	cjne	r4,#0x00,00214$
      00A4FE BD 7C 02         [24] 1463 	cjne	r5,#0x7c,00214$
      00A501 80 10            [24] 1464 	sjmp	00112$
      00A503                       1465 00214$:
      00A503 BC 01 05         [24] 1466 	cjne	r4,#0x01,00215$
      00A506 BD 7C 02         [24] 1467 	cjne	r5,#0x7c,00215$
      00A509 80 0E            [24] 1468 	sjmp	00113$
      00A50B                       1469 00215$:
                                   1470 ;	quantum/quantum.c:561: case QK_BOOTLOADER:
      00A50B BC 03 1A         [24] 1471 	cjne	r4,#0x03,00117$
      00A50E BD 7C 17         [24] 1472 	cjne	r5,#0x7c,00117$
      00A511 80 0C            [24] 1473 	sjmp	00114$
      00A513                       1474 00112$:
                                   1475 ;	quantum/quantum.c:562: reset_keyboard();
      00A513 51 71            [24] 1476 	acall	_reset_keyboard
                                   1477 ;	quantum/quantum.c:563: return false;
      00A515 75 82 00         [24] 1478 	mov	dpl, #0x00
                                   1479 ;	quantum/quantum.c:564: case QK_REBOOT:
      00A518 22               [24] 1480 	ret
      00A519                       1481 00113$:
                                   1482 ;	quantum/quantum.c:565: soft_reset_keyboard();
      00A519 51 76            [24] 1483 	acall	_soft_reset_keyboard
                                   1484 ;	quantum/quantum.c:566: return false;
      00A51B 75 82 00         [24] 1485 	mov	dpl, #0x00
                                   1486 ;	quantum/quantum.c:578: case QK_CLEAR_EEPROM:
      00A51E 22               [24] 1487 	ret
      00A51F                       1488 00114$:
                                   1489 ;	quantum/quantum.c:585: eeconfig_disable();
      00A51F 12 93 26         [24] 1490 	lcall	_eeconfig_disable
                                   1491 ;	quantum/quantum.c:586: soft_reset_keyboard();
      00A522 51 76            [24] 1492 	acall	_soft_reset_keyboard
                                   1493 ;	quantum/quantum.c:588: return false;
      00A524 75 82 00         [24] 1494 	mov	dpl, #0x00
                                   1495 ;	quantum/quantum.c:643: }
      00A527 22               [24] 1496 	ret
      00A528                       1497 00117$:
                                   1498 ;	quantum/quantum.c:646: return process_action_kb(record);
      00A528 7D 00            [12] 1499 	mov	r5,#0x00
      00A52A 12 38 94         [24] 1500 	lcall	_ak820_outline_0123
      00A52D 8D F0            [24] 1501 	mov	b, r5
                                   1502 ;	quantum/quantum.c:647: }
      00A52F 41 1A            [12] 1503 	ajmp	_process_action_kb
                                   1504 ;------------------------------------------------------------
                                   1505 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1506 ;------------------------------------------------------------
                                   1507 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_697'
                                   1508 ;------------------------------------------------------------
                                   1509 ;	quantum/quantum.c:649: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1510 ;	-----------------------------------------
                                   1511 ;	 function shutdown_user
                                   1512 ;	-----------------------------------------
      00A531                       1513 _shutdown_user:
      00A531 22               [24] 1514 	ret
                                   1515 ;------------------------------------------------------------
                                   1516 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1517 ;------------------------------------------------------------
                                   1518 ;	quantum/quantum.c:665: void suspend_power_down_quantum(void) {
                                   1519 ;	-----------------------------------------
                                   1520 	.area CSEG    (CODE)
                                   1521 	.area CONST   (CODE)
                                   1522 	.area XINIT   (CODE)
                                   1523 	.area CABS    (ABS,CODE)
                                   1524 
                                   1525 ; Experimental exact instruction outlining.
                                   1526 	.globl _ak820_outline_0001
                                   1527 	.globl _ak820_outline_0005
                                   1528 	.globl _ak820_outline_0008
                                   1529 	.globl _ak820_outline_0011
                                   1530 	.globl _ak820_outline_0014
                                   1531 	.globl _ak820_outline_0020
                                   1532 	.globl _ak820_outline_0023
                                   1533 	.globl _ak820_outline_0039
                                   1534 	.globl _ak820_outline_0042
                                   1535 	.globl _ak820_outline_0054
                                   1536 	.globl _ak820_outline_0060
                                   1537 	.globl _ak820_outline_0062
                                   1538 	.globl _ak820_outline_0073
                                   1539 	.globl _ak820_outline_0099
                                   1540 	.globl _ak820_outline_0102
                                   1541 	.globl _ak820_outline_0108
                                   1542 	.globl _ak820_outline_0109
                                   1543 	.globl _ak820_outline_0123
                                   1544 	.globl _ak820_outline_0124
                                   1545 	.globl _ak820_outline_0127
                                   1546 	.globl _ak820_outline_0136
                                   1547 	.globl _ak820_outline_0147
                                   1548 	.globl _ak820_outline_0149
                                   1549 	.globl _ak820_outline_0154
                                   1550 	.globl _ak820_outline_0187
                                   1551 
                                   1552 	.area CSEG (CODE)
                                   1553 ; function ak820_outline_0001
      00A532                       1554 _ak820_outline_0001:
      00A532 EE               [12] 1555 	mov	a,r6
      00A533 F0               [24] 1556 	movx	@dptr,a
      00A534 EF               [12] 1557 	mov	a,r7
      00A535 A3               [24] 1558 	inc	dptr
      00A536 F0               [24] 1559 	movx	@dptr,a
      00A537 E4               [12] 1560 	clr	a
      00A538 A3               [24] 1561 	inc	dptr
      00A539 F0               [24] 1562 	movx	@dptr,a
      00A53A 8C 82            [24] 1563 	mov	dpl,r4
      00A53C 8D 83            [24] 1564 	mov	dph,r5
      00A53E 22               [24] 1565 	ret
                                   1566 
                                   1567 	.area CSEG (CODE)
                                   1568 ; function ak820_outline_0014
      00A53F                       1569 _ak820_outline_0014:
      00A53F EB               [12] 1570 	mov	a,r3
      00A540 F0               [24] 1571 	movx	@dptr,a
      00A541 EC               [12] 1572 	mov	a,r4
      00A542 A3               [24] 1573 	inc	dptr
      00A543 F0               [24] 1574 	movx	@dptr,a
      00A544 ED               [12] 1575 	mov	a,r5
      00A545 A3               [24] 1576 	inc	dptr
      00A546 F0               [24] 1577 	movx	@dptr,a
      00A547 8E 82            [24] 1578 	mov	dpl,r6
      00A549 8F 83            [24] 1579 	mov	dph,r7
      00A54B 22               [24] 1580 	ret
