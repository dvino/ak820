                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002A                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002A                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C86                        589 _via_eeprom_set_valid_valid_10000_609:
      000C86                        590 	.ds 1
      000C87                        591 _via_set_layout_options_value_10000_625:
      000C87                        592 	.ds 4
      000C8B                        593 _process_record_via_PARM_2:
      000C8B                        594 	.ds 3
      000C8E                        595 _process_record_via_keycode_10000_627:
      000C8E                        596 	.ds 2
      000C90                        597 _raw_hid_receive_kb_PARM_2:
      000C90                        598 	.ds 1
      000C91                        599 _raw_hid_receive_kb_data_10000_633:
      000C91                        600 	.ds 3
      000C94                        601 _raw_hid_receive_PARM_2:
      000C94                        602 	.ds 1
      000C95                        603 _raw_hid_receive_packet_10000_635:
      000C95                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A955                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A955 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A958 75 F0 00         [24]  659 	mov	b, #0x00
      00A95B 12 40 72         [24]  660 	lcall	_eeprom_read_byte
      00A95E AF 82            [24]  661 	mov	r7, dpl
      00A960 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00A963 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A966 75 F0 00         [24]  664 	mov	b, #0x00
      00A969 12 40 72         [24]  665 	lcall	_eeprom_read_byte
      00A96C AF 82            [24]  666 	mov	r7, dpl
      00A96E BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A971 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A974 75 F0 00         [24]  669 	mov	b, #0x00
      00A977 12 40 72         [24]  670 	lcall	_eeprom_read_byte
      00A97A AF 82            [24]  671 	mov	r7, dpl
      00A97C BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A97F 80 04            [24]  673 	sjmp	00104$
      00A981                        674 00126$:
      00A981                        675 00103$:
                                    676 ;	assignBit
      00A981 C2 2A            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A983 80 02            [24]  678 	sjmp	00105$
      00A985                        679 00104$:
                                    680 ;	assignBit
      00A985 D2 2A            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A987                        682 00105$:
      00A987 A2 2A            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A989 12 38 B2         [24]  684 	lcall	_ak820_outline_0154
                                    685 ;	quantum/via.c:104: }
      00A98C 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A98D                        699 _via_eeprom_set_valid:
      00A98D E5 82            [12]  700 	mov	a,dpl
      00A98F 90 0C 86         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A992 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A993 E0               [24]  704 	movx	a,@dptr
      00A994 60 04            [24]  705 	jz	00103$
      00A996 7F 03            [12]  706 	mov	r7,#0x03
      00A998 80 02            [24]  707 	sjmp	00104$
      00A99A                        708 00103$:
      00A99A 7F FF            [12]  709 	mov	r7,#0xff
      00A99C                        710 00104$:
      00A99C 90 06 E7         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A99F EF               [12]  712 	mov	a,r7
      00A9A0 F0               [24]  713 	movx	@dptr,a
      00A9A1 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A9A4 75 F0 00         [24]  715 	mov	b, #0x00
      00A9A7 12 52 7E         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A9AA 90 0C 86         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A9AD E0               [24]  719 	movx	a,@dptr
      00A9AE 60 04            [24]  720 	jz	00105$
      00A9B0 7F 20            [12]  721 	mov	r7,#0x20
      00A9B2 80 02            [24]  722 	sjmp	00106$
      00A9B4                        723 00105$:
      00A9B4 7F FF            [12]  724 	mov	r7,#0xff
      00A9B6                        725 00106$:
      00A9B6 90 06 E7         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A9B9 EF               [12]  727 	mov	a,r7
      00A9BA F0               [24]  728 	movx	@dptr,a
      00A9BB 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A9BE 75 F0 00         [24]  730 	mov	b, #0x00
      00A9C1 12 52 7E         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A9C4 90 0C 86         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A9C7 E0               [24]  734 	movx	a,@dptr
      00A9C8 60 04            [24]  735 	jz	00107$
      00A9CA 7F 08            [12]  736 	mov	r7,#0x08
      00A9CC 80 02            [24]  737 	sjmp	00108$
      00A9CE                        738 00107$:
      00A9CE 7F FF            [12]  739 	mov	r7,#0xff
      00A9D0                        740 00108$:
      00A9D0 90 06 E7         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A9D3 EF               [12]  742 	mov	a,r7
      00A9D4 F0               [24]  743 	movx	@dptr,a
      00A9D5 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A9D8 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A9DB 02 52 7E         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A9DE                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A9DE 51 01            [12]  757 	acall	_via_get_layout_options
      00A9E0 51 19            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A9E2 31 55            [12]  760 	acall	_via_eeprom_is_valid
      00A9E4 E5 82            [12]  761 	mov	a, dpl
      00A9E6 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A9E8 02 3E 22         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A9EB                        766 00103$:
      00A9EB 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A9EC                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A9EC 75 82 00         [24]  777 	mov	dpl, #0x00
      00A9EF 31 8D            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A9F1 12 93 E5         [24]  780 	lcall	_ak820_outline_0158
      00A9F4 51 1A            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A9F6 12 8A 63         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A9F9 12 8E D7         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A9FC 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A9FF 21 8D            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00AA01                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00AA01 90 00 28         [24]  799 	mov	dptr,#0x0028
      00AA04 75 F0 00         [24]  800 	mov	b, #0x00
      00AA07 12 40 72         [24]  801 	lcall	_eeprom_read_byte
      00AA0A AF 82            [24]  802 	mov	r7, dpl
      00AA0C 7E 00            [12]  803 	mov	r6,#0x00
      00AA0E 7D 00            [12]  804 	mov	r5,#0x00
      00AA10 7C 00            [12]  805 	mov	r4,#0x00
      00AA12 12 43 78         [24]  806 	lcall	_ak820_outline_0161
      00AA15 8D F0            [24]  807 	mov	b, r5
      00AA17 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00AA18 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00AA19                        820 _via_set_layout_options_kb:
      00AA19 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00AA1A                        831 _via_set_layout_options:
      00AA1A 12 93 DD         [24]  832 	lcall	_ak820_outline_0125
      00AA1D 90 0C 87         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00AA20 12 93 CB         [24]  834 	lcall	_ak820_outline_0045
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00AA23 90 0C 87         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00AA26 E0               [24]  837 	movx	a,@dptr
      00AA27 90 06 E7         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AA2A F0               [24]  839 	movx	@dptr,a
      00AA2B 90 00 28         [24]  840 	mov	dptr,#0x0028
      00AA2E 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00AA31 02 52 7E         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00AA34                        855 _process_record_via:
      00AA34 12 38 8A         [24]  856 	lcall	_ak820_outline_0108
      00AA37 90 0C 8E         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00AA3A 12 38 8F         [24]  858 	lcall	_ak820_outline_0109
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00AA3D 90 0C 8B         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00AA40 12 53 8D         [24]  861 	lcall	_ak820_outline_0013
      00AA43 74 05            [12]  862 	mov	a,#0x05
      00AA45 12 38 BC         [24]  863 	lcall	_ak820_outline_0163
      00AA48 12 53 96         [24]  864 	lcall	_ak820_outline_0048
      00AA4B 12 BE 6D         [24]  865 	lcall	__gptrget
      00AA4E 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00AA50 90 0C 8E         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00AA53 12 4C E3         [24]  869 	lcall	_ak820_outline_0010
      00AA56 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00AA58 2D               [12]  871 	add	a,r5
      00AA59 50 12            [24]  872 	jnc	00105$
      00AA5B C3               [12]  873 	clr	c
      00AA5C 74 7F            [12]  874 	mov	a,#0x7f
      00AA5E 9C               [12]  875 	subb	a,r4
      00AA5F 74 77            [12]  876 	mov	a,#0x77
      00AA61 9D               [12]  877 	subb	a,r5
      00AA62 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AA64 8E 82            [24]  882 	mov	dpl, r6
      00AA66 12 8E FD         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AA69 75 82 00         [24]  885 	mov	dpl, #0x00
      00AA6C 22               [24]  886 	ret
      00AA6D                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AA6D 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AA70 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AA71                        903 _raw_hid_receive_kb:
      00AA71 12 43 11         [24]  904 	lcall	_ak820_outline_0037
      00AA74 90 0C 91         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00AA77 12 38 1E         [24]  906 	lcall	_ak820_outline_0017
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AA7A 90 0C 91         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00AA7D 12 53 67         [24]  909 	lcall	_ak820_outline_0002
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AA80 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AA82 02 BD 48         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AA85                        950 _raw_hid_receive:
      00AA85 12 43 11         [24]  951 	lcall	_ak820_outline_0037
      00AA88 90 0C 95         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00AA8B 12 38 1E         [24]  953 	lcall	_ak820_outline_0017
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AA8E 90 0C 95         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00AA91 12 38 36         [24]  956 	lcall	_ak820_outline_0054
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AA94 74 01            [12]  958 	mov	a,#0x01
      00AA96 12 43 7D         [24]  959 	lcall	_ak820_outline_0164
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AA99 90 0C 94         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AA9C E0               [24]  962 	movx	a,@dptr
      00AA9D FB               [12]  963 	mov	r3,a
      00AA9E BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AAA1 80 01            [24]  965 	sjmp	00102$
      00AAA3                        966 00520$:
      00AAA3 22               [24]  967 	ret
      00AAA4                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AAA4 90 0E 6B         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AAA7 E0               [24]  971 	movx	a,@dptr
      00AAA8 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AAAA 12 38 7E         [24]  974 	lcall	_ak820_outline_0105
      00AAAD FA               [12]  975 	mov	r2,a
      00AAAE BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00AAB1 80 01            [24]  977 	sjmp	00104$
      00AAB3                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00AAB3 22               [24]  980 	ret
      00AAB4                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AAB4 12 43 4F         [24]  983 	lcall	_ak820_outline_0097
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AAB7 FA               [12]  985 	mov	r2,a
      00AAB8 60 21            [24]  986 	jz	00114$
      00AABA BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00AABD 80 1C            [24]  988 	sjmp	00114$
      00AABF                        989 00524$:
      00AABF BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00AAC2 80 17            [24]  991 	sjmp	00114$
      00AAC4                        992 00525$:
      00AAC4 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00AAC7 80 12            [24]  994 	sjmp	00114$
      00AAC9                        995 00526$:
      00AAC9 BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00AACC 80 0D            [24]  997 	sjmp	00114$
      00AACE                        998 00527$:
      00AACE BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00AAD1 80 08            [24] 1000 	sjmp	00114$
      00AAD3                       1001 00528$:
      00AAD3 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00AAD6 80 03            [24] 1003 	sjmp	00530$
      00AAD8                       1004 00529$:
      00AAD8 02 AF F4         [24] 1005 	ljmp	00171$
      00AADB                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00AADB                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00AADB 12 38 7E         [24] 1010 	lcall	_ak820_outline_0105
      00AADE FA               [12] 1011 	mov	r2,a
      00AADF BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00AAE2 80 5F            [24] 1013 	sjmp	00115$
      00AAE4                       1014 00531$:
      00AAE4 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00AAE7 80 67            [24] 1016 	sjmp	00116$
      00AAE9                       1017 00532$:
      00AAE9 BA 03 02         [24] 1018 	cjne	r2,#0x03,00533$
      00AAEC 81 0E            [24] 1019 	ajmp	00125$
      00AAEE                       1020 00533$:
      00AAEE BA 04 02         [24] 1021 	cjne	r2,#0x04,00534$
      00AAF1 81 A2            [12] 1022 	ajmp	00129$
      00AAF3                       1023 00534$:
      00AAF3 BA 05 02         [24] 1024 	cjne	r2,#0x05,00535$
      00AAF6 81 DB            [12] 1025 	ajmp	00130$
      00AAF8                       1026 00535$:
      00AAF8 BA 06 02         [24] 1027 	cjne	r2,#0x06,00536$
      00AAFB A1 47            [12] 1028 	ajmp	00135$
      00AAFD                       1029 00536$:
      00AAFD BA 07 02         [24] 1030 	cjne	r2,#0x07,00537$
      00AB00 A1 59            [12] 1031 	ajmp	00136$
      00AB02                       1032 00537$:
      00AB02 BA 08 02         [24] 1033 	cjne	r2,#0x08,00538$
      00AB05 A1 74            [12] 1034 	ajmp	00137$
      00AB07                       1035 00538$:
      00AB07 BA 09 02         [24] 1036 	cjne	r2,#0x09,00539$
      00AB0A A1 8F            [12] 1037 	ajmp	00138$
      00AB0C                       1038 00539$:
      00AB0C BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00AB0F 02 AF 83         [24] 1040 	ljmp	00161$
      00AB12                       1041 00540$:
      00AB12 BA 0C 02         [24] 1042 	cjne	r2,#0x0c,00541$
      00AB15 A1 AA            [12] 1043 	ajmp	00139$
      00AB17                       1044 00541$:
      00AB17 BA 0D 02         [24] 1045 	cjne	r2,#0x0d,00542$
      00AB1A A1 CB            [12] 1046 	ajmp	00140$
      00AB1C                       1047 00542$:
      00AB1C BA 0E 02         [24] 1048 	cjne	r2,#0x0e,00543$
      00AB1F A1 F3            [12] 1049 	ajmp	00141$
      00AB21                       1050 00543$:
      00AB21 BA 0F 02         [24] 1051 	cjne	r2,#0x0f,00544$
      00AB24 C1 3B            [12] 1052 	ajmp	00144$
      00AB26                       1053 00544$:
      00AB26 BA 10 02         [24] 1054 	cjne	r2,#0x10,00545$
      00AB29 C1 AA            [12] 1055 	ajmp	00151$
      00AB2B                       1056 00545$:
      00AB2B BA 11 02         [24] 1057 	cjne	r2,#0x11,00546$
      00AB2E C1 C3            [12] 1058 	ajmp	00154$
      00AB30                       1059 00546$:
      00AB30 BA 12 02         [24] 1060 	cjne	r2,#0x12,00547$
      00AB33 C1 E4            [12] 1061 	ajmp	00155$
      00AB35                       1062 00547$:
      00AB35 BA 13 02         [24] 1063 	cjne	r2,#0x13,00548$
      00AB38 E1 2C            [12] 1064 	ajmp	00158$
      00AB3A                       1065 00548$:
      00AB3A BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00AB3D 02 AF C2         [24] 1067 	ljmp	00168$
      00AB40                       1068 00549$:
      00AB40 02 AF DC         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00AB43                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00AB43 12 38 99         [24] 1073 	lcall	_ak820_outline_0127
      00AB46 E4               [12] 1074 	clr	a
      00AB47 12 43 09         [24] 1075 	lcall	_ak820_outline_0033
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00AB4A 74 09            [12] 1077 	mov	a,#0x09
      00AB4C F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00AB4D 02 AF F4         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00AB50                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00AB50 12 43 4F         [24] 1084 	lcall	_ak820_outline_0097
      00AB53 FA               [12] 1085 	mov	r2,a
      00AB54 BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00AB57 80 0C            [24] 1087 	sjmp	00117$
      00AB59                       1088 00550$:
      00AB59 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00AB5C 80 32            [24] 1090 	sjmp	00118$
      00AB5E                       1091 00551$:
      00AB5E BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00AB61 61 CA            [24] 1093 	ajmp	00119$
      00AB63                       1094 00552$:
      00AB63 61 F4            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00AB65                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AB65 12 4D A6         [24] 1099 	lcall	_timer_read32
      00AB68 85 82 38         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AB6B 85 83 39         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AB6E 85 F0 3A         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AB71 F5 3B            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AB73 12 38 94         [24] 1105 	lcall	_ak820_outline_0123
      00AB76 A3               [24] 1106 	inc	dptr
      00AB77 A3               [24] 1107 	inc	dptr
      00AB78 E5 3B            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AB7A 12 43 09         [24] 1109 	lcall	_ak820_outline_0033
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AB7D A3               [24] 1111 	inc	dptr
      00AB7E E5 3A            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AB80 F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AB81 12 B0 22         [24] 1115 	lcall	_ak820_outline_0024
      00AB84 E5 39            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AB86 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AB87 12 42 FF         [24] 1119 	lcall	_ak820_outline_0009
      00AB8A E5 38            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00AB8C F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00AB8D 02 AF F4         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00AB90                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AB90 C0 03            [24] 1127 	push	ar3
      00AB92 C0 07            [24] 1128 	push	ar7
      00AB94 C0 06            [24] 1129 	push	ar6
      00AB96 C0 03            [24] 1130 	push	ar3
      00AB98 51 01            [12] 1131 	acall	_via_get_layout_options
      00AB9A 85 82 38         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AB9D 85 83 39         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00ABA0 85 F0 3A         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00ABA3 F5 3B            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ABA5 D0 03            [24] 1136 	pop	ar3
      00ABA7 D0 06            [24] 1137 	pop	ar6
      00ABA9 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00ABAB 12 38 94         [24] 1140 	lcall	_ak820_outline_0123
      00ABAE A3               [24] 1141 	inc	dptr
      00ABAF A3               [24] 1142 	inc	dptr
      00ABB0 E5 3B            [12] 1143 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ABB2 12 43 09         [24] 1144 	lcall	_ak820_outline_0033
                                   1145 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00ABB5 A3               [24] 1146 	inc	dptr
      00ABB6 E5 3A            [12] 1147 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ABB8 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00ABB9 12 B0 22         [24] 1150 	lcall	_ak820_outline_0024
      00ABBC E5 39            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ABBE F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00ABBF 12 42 FF         [24] 1154 	lcall	_ak820_outline_0009
      00ABC2 E5 38            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00ABC4 F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00ABC5 D0 03            [24] 1158 	pop	ar3
      00ABC7 02 AF F4         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00ABCA                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00ABCA 90 0E 6A         [24] 1163 	mov	dptr,#_vial_unlocked
      00ABCD E0               [24] 1164 	movx	a,@dptr
      00ABCE 70 03            [24] 1165 	jnz	00553$
      00ABD0 02 AF F4         [24] 1166 	ljmp	00171$
      00ABD3                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00ABD3 7A 01            [12] 1169 	mov	r2,#0x01
      00ABD5 79 00            [12] 1170 	mov	r1,#0x00
      00ABD7                       1171 00173$:
      00ABD7 B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00ABDA                       1173 00554$:
      00ABDA 40 03            [24] 1174 	jc	00555$
      00ABDC 02 AF F4         [24] 1175 	ljmp	00171$
      00ABDF                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00ABDF 89 82            [24] 1178 	mov	dpl, r1
      00ABE1 12 5D F2         [24] 1179 	lcall	_matrix_get_row
      00ABE4 A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00ABE6 EA               [12] 1182 	mov	a,r2
      00ABE7 2C               [12] 1183 	add	a, r4
      00ABE8 F5 82            [12] 1184 	mov	dpl,a
      00ABEA E4               [12] 1185 	clr	a
      00ABEB 3D               [12] 1186 	addc	a, r5
      00ABEC F5 83            [12] 1187 	mov	dph,a
      00ABEE 0A               [12] 1188 	inc	r2
      00ABEF E8               [12] 1189 	mov	a,r0
      00ABF0 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00ABF1 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00ABF2 80 E3            [24] 1194 	sjmp	00173$
      00ABF4                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00ABF4 12 B0 50         [24] 1197 	lcall	_ak820_outline_0094
      00ABF7 90 0C 90         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ABFA 12 B0 2B         [24] 1199 	lcall	_ak820_outline_0040
      00ABFD C0 07            [24] 1200 	push	ar7
      00ABFF C0 06            [24] 1201 	push	ar6
      00AC01 C0 03            [24] 1202 	push	ar3
      00AC03 51 71            [24] 1203 	acall	_raw_hid_receive_kb
      00AC05 D0 03            [24] 1204 	pop	ar3
      00AC07 D0 06            [24] 1205 	pop	ar6
      00AC09 D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00AC0B 02 AF F4         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AC0E                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00AC0E 12 43 4F         [24] 1212 	lcall	_ak820_outline_0097
      00AC11 FA               [12] 1213 	mov	r2,a
      00AC12 BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00AC15 80 02            [24] 1215 	sjmp	00557$
      00AC17                       1216 00556$:
      00AC17 81 88            [12] 1217 	ajmp	00127$
      00AC19                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AC19 C0 03            [24] 1220 	push	ar3
      00AC1B 12 38 2E         [24] 1221 	lcall	_ak820_outline_0036
      00AC1E F8               [12] 1222 	mov	r0,a
      00AC1F 79 00            [12] 1223 	mov	r1,#0x00
      00AC21 7B 00            [12] 1224 	mov	r3,#0x00
      00AC23 88 3B            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AC25 8B 38            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AC27 8B 39            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AC29 8B 3A            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AC2B 12 B0 19         [24] 1229 	lcall	_ak820_outline_0016
      00AC2E F8               [12] 1230 	mov	r0,a
      00AC2F 89 03            [24] 1231 	mov	ar3,r1
      00AC31 88 02            [24] 1232 	mov	ar2,r0
      00AC33 E4               [12] 1233 	clr	a
      00AC34 42 38            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00AC36 E9               [12] 1235 	mov	a,r1
      00AC37 42 39            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AC39 EA               [12] 1237 	mov	a,r2
      00AC3A 42 3A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AC3C EB               [12] 1239 	mov	a,r3
      00AC3D 42 3B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AC3F 12 B0 22         [24] 1241 	lcall	_ak820_outline_0024
      00AC42 E0               [24] 1242 	movx	a,@dptr
      00AC43 F8               [12] 1243 	mov	r0,a
      00AC44 79 00            [12] 1244 	mov	r1,#0x00
      00AC46 7A 00            [12] 1245 	mov	r2,#0x00
      00AC48 8A 03            [24] 1246 	mov	ar3,r2
      00AC4A 89 02            [24] 1247 	mov	ar2,r1
      00AC4C 88 01            [24] 1248 	mov	ar1,r0
      00AC4E E4               [12] 1249 	clr	a
      00AC4F 42 38            [12] 1250 	orl	_raw_hid_receive_sloc0_1_0,a
      00AC51 E9               [12] 1251 	mov	a,r1
      00AC52 42 39            [12] 1252 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AC54 EA               [12] 1253 	mov	a,r2
      00AC55 42 3A            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AC57 EB               [12] 1255 	mov	a,r3
      00AC58 42 3B            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AC5A 12 42 FF         [24] 1257 	lcall	_ak820_outline_0009
      00AC5D E0               [24] 1258 	movx	a,@dptr
      00AC5E F8               [12] 1259 	mov	r0,a
      00AC5F E4               [12] 1260 	clr	a
      00AC60 F9               [12] 1261 	mov	r1,a
      00AC61 FA               [12] 1262 	mov	r2,a
      00AC62 FB               [12] 1263 	mov	r3,a
      00AC63 E5 39            [12] 1264 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AC65 42 01            [12] 1265 	orl	ar1,a
      00AC67 E5 3A            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AC69 42 02            [12] 1267 	orl	ar2,a
      00AC6B E5 3B            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AC6D 42 03            [12] 1269 	orl	ar3,a
                                   1270 ;	quantum/via.c:323: via_set_layout_options(value);
      00AC6F 12 38 B7         [24] 1271 	lcall	_ak820_outline_0155
      00AC72 8A F0            [24] 1272 	mov	b, r2
      00AC74 EB               [12] 1273 	mov	a, r3
      00AC75 C0 07            [24] 1274 	push	ar7
      00AC77 C0 06            [24] 1275 	push	ar6
      00AC79 C0 03            [24] 1276 	push	ar3
      00AC7B 51 1A            [12] 1277 	acall	_via_set_layout_options
      00AC7D D0 03            [24] 1278 	pop	ar3
      00AC7F D0 06            [24] 1279 	pop	ar6
      00AC81 D0 07            [24] 1280 	pop	ar7
                                   1281 ;	quantum/via.c:324: break;
      00AC83 D0 03            [24] 1282 	pop	ar3
      00AC85 02 AF F4         [24] 1283 	ljmp	00171$
                                   1284 ;	quantum/via.c:326: default: {
      00AC88                       1285 00127$:
                                   1286 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AC88 12 B0 50         [24] 1287 	lcall	_ak820_outline_0094
      00AC8B 90 0C 90         [24] 1288 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AC8E 12 B0 2B         [24] 1289 	lcall	_ak820_outline_0040
      00AC91 C0 07            [24] 1290 	push	ar7
      00AC93 C0 06            [24] 1291 	push	ar6
      00AC95 C0 03            [24] 1292 	push	ar3
      00AC97 51 71            [24] 1293 	acall	_raw_hid_receive_kb
      00AC99 D0 03            [24] 1294 	pop	ar3
      00AC9B D0 06            [24] 1295 	pop	ar6
      00AC9D D0 07            [24] 1296 	pop	ar7
                                   1297 ;	quantum/via.c:331: break;
      00AC9F 02 AF F4         [24] 1298 	ljmp	00171$
                                   1299 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00ACA2                       1300 00129$:
                                   1301 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00ACA2 12 43 4F         [24] 1302 	lcall	_ak820_outline_0097
      00ACA5 FA               [12] 1303 	mov	r2,a
      00ACA6 12 38 2E         [24] 1304 	lcall	_ak820_outline_0036
      00ACA9 F9               [12] 1305 	mov	r1,a
      00ACAA 12 B0 19         [24] 1306 	lcall	_ak820_outline_0016
      00ACAD F8               [12] 1307 	mov	r0,a
      00ACAE 90 0B 21         [24] 1308 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00ACB1 E9               [12] 1309 	mov	a,r1
      00ACB2 F0               [24] 1310 	movx	@dptr,a
      00ACB3 90 0B 22         [24] 1311 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00ACB6 E8               [12] 1312 	mov	a,r0
      00ACB7 F0               [24] 1313 	movx	@dptr,a
      00ACB8 8A 82            [24] 1314 	mov	dpl, r2
      00ACBA C0 07            [24] 1315 	push	ar7
      00ACBC C0 06            [24] 1316 	push	ar6
      00ACBE C0 03            [24] 1317 	push	ar3
      00ACC0 12 87 84         [24] 1318 	lcall	_dynamic_keymap_get_keycode
      00ACC3 12 4D 5C         [24] 1319 	lcall	_ak820_outline_0190
      00ACC6 D0 03            [24] 1320 	pop	ar3
      00ACC8 D0 06            [24] 1321 	pop	ar6
      00ACCA D0 07            [24] 1322 	pop	ar7
                                   1323 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00ACCC 12 B0 22         [24] 1324 	lcall	_ak820_outline_0024
      00ACCF 8A 00            [24] 1325 	mov	ar0,r2
      00ACD1 E8               [12] 1326 	mov	a,r0
      00ACD2 F0               [24] 1327 	movx	@dptr,a
                                   1328 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00ACD3 12 42 FF         [24] 1329 	lcall	_ak820_outline_0009
      00ACD6 E9               [12] 1330 	mov	a,r1
      00ACD7 F0               [24] 1331 	movx	@dptr,a
                                   1332 ;	quantum/via.c:337: break;
      00ACD8 02 AF F4         [24] 1333 	ljmp	00171$
                                   1334 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00ACDB                       1335 00130$:
                                   1336 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00ACDB 90 0E 6A         [24] 1337 	mov	dptr,#_vial_unlocked
      00ACDE E0               [24] 1338 	movx	a,@dptr
      00ACDF 70 19            [24] 1339 	jnz	00132$
      00ACE1 12 B0 22         [24] 1340 	lcall	_ak820_outline_0024
      00ACE4 E0               [24] 1341 	movx	a,@dptr
      00ACE5 FA               [12] 1342 	mov	r2,a
      00ACE6 BA 7C 11         [24] 1343 	cjne	r2,#0x7c,00132$
      00ACE9 74 05            [12] 1344 	mov	a,#0x05
      00ACEB 2E               [12] 1345 	add	a, r6
      00ACEC 12 38 14         [24] 1346 	lcall	_ak820_outline_0015
      00ACEF 70 09            [24] 1347 	jnz	00132$
                                   1348 ;	quantum/via.c:344: *command_id = id_unhandled;
      00ACF1 12 38 94         [24] 1349 	lcall	_ak820_outline_0123
      00ACF4 74 FF            [12] 1350 	mov	a,#0xff
      00ACF6 F0               [24] 1351 	movx	@dptr,a
                                   1352 ;	quantum/via.c:345: break;
      00ACF7 02 AF F4         [24] 1353 	ljmp	00171$
      00ACFA                       1354 00132$:
                                   1355 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00ACFA C0 03            [24] 1356 	push	ar3
      00ACFC 12 43 4F         [24] 1357 	lcall	_ak820_outline_0097
      00ACFF F5 3D            [12] 1358 	mov	_raw_hid_receive_sloc2_1_0,a
      00AD01 12 38 2E         [24] 1359 	lcall	_ak820_outline_0036
      00AD04 F5 3C            [12] 1360 	mov	_raw_hid_receive_sloc1_1_0,a
      00AD06 12 B0 19         [24] 1361 	lcall	_ak820_outline_0016
      00AD09 F5 38            [12] 1362 	mov	_raw_hid_receive_sloc0_1_0,a
      00AD0B 12 B0 22         [24] 1363 	lcall	_ak820_outline_0024
      00AD0E E0               [24] 1364 	movx	a,@dptr
      00AD0F FB               [12] 1365 	mov	r3,a
      00AD10 78 00            [12] 1366 	mov	r0,#0x00
      00AD12 12 42 FF         [24] 1367 	lcall	_ak820_outline_0009
      00AD15 E0               [24] 1368 	movx	a,@dptr
      00AD16 7A 00            [12] 1369 	mov	r2,#0x00
      00AD18 42 00            [12] 1370 	orl	ar0,a
      00AD1A EA               [12] 1371 	mov	a,r2
      00AD1B 42 03            [12] 1372 	orl	ar3,a
      00AD1D 90 0B 24         [24] 1373 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00AD20 E5 3C            [12] 1374 	mov	a,_raw_hid_receive_sloc1_1_0
      00AD22 F0               [24] 1375 	movx	@dptr,a
      00AD23 90 0B 25         [24] 1376 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00AD26 E5 38            [12] 1377 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD28 F0               [24] 1378 	movx	@dptr,a
      00AD29 90 0B 26         [24] 1379 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00AD2C E8               [12] 1380 	mov	a,r0
      00AD2D 12 48 3C         [24] 1381 	lcall	_ak820_outline_0194
      00AD30 85 3D 82         [24] 1382 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00AD33 C0 07            [24] 1383 	push	ar7
      00AD35 C0 06            [24] 1384 	push	ar6
      00AD37 C0 03            [24] 1385 	push	ar3
      00AD39 12 87 D2         [24] 1386 	lcall	_dynamic_keymap_set_keycode
      00AD3C D0 03            [24] 1387 	pop	ar3
      00AD3E D0 06            [24] 1388 	pop	ar6
      00AD40 D0 07            [24] 1389 	pop	ar7
                                   1390 ;	quantum/via.c:349: break;
      00AD42 D0 03            [24] 1391 	pop	ar3
      00AD44 02 AF F4         [24] 1392 	ljmp	00171$
                                   1393 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00AD47                       1394 00135$:
                                   1395 ;	quantum/via.c:352: dynamic_keymap_reset();
      00AD47 C0 07            [24] 1396 	push	ar7
      00AD49 C0 06            [24] 1397 	push	ar6
      00AD4B C0 03            [24] 1398 	push	ar3
      00AD4D 12 8A 63         [24] 1399 	lcall	_dynamic_keymap_reset
      00AD50 D0 03            [24] 1400 	pop	ar3
      00AD52 D0 06            [24] 1401 	pop	ar6
      00AD54 D0 07            [24] 1402 	pop	ar7
                                   1403 ;	quantum/via.c:353: break;
      00AD56 02 AF F4         [24] 1404 	ljmp	00171$
                                   1405 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AD59                       1406 00136$:
                                   1407 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AD59 12 B0 50         [24] 1408 	lcall	_ak820_outline_0094
      00AD5C 90 0D DB         [24] 1409 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AD5F 12 B0 2B         [24] 1410 	lcall	_ak820_outline_0040
      00AD62 C0 07            [24] 1411 	push	ar7
      00AD64 C0 06            [24] 1412 	push	ar6
      00AD66 C0 03            [24] 1413 	push	ar3
      00AD68 12 BB 1F         [24] 1414 	lcall	_vialrgb_set_value
      00AD6B D0 03            [24] 1415 	pop	ar3
      00AD6D D0 06            [24] 1416 	pop	ar6
      00AD6F D0 07            [24] 1417 	pop	ar7
                                   1418 ;	quantum/via.c:375: break;
      00AD71 02 AF F4         [24] 1419 	ljmp	00171$
                                   1420 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AD74                       1421 00137$:
                                   1422 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AD74 12 B0 50         [24] 1423 	lcall	_ak820_outline_0094
      00AD77 90 0D D7         [24] 1424 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AD7A 12 B0 2B         [24] 1425 	lcall	_ak820_outline_0040
      00AD7D C0 07            [24] 1426 	push	ar7
      00AD7F C0 06            [24] 1427 	push	ar6
      00AD81 C0 03            [24] 1428 	push	ar3
      00AD83 12 B9 B8         [24] 1429 	lcall	_vialrgb_get_value
      00AD86 D0 03            [24] 1430 	pop	ar3
      00AD88 D0 06            [24] 1431 	pop	ar6
      00AD8A D0 07            [24] 1432 	pop	ar7
                                   1433 ;	quantum/via.c:397: break;
      00AD8C 02 AF F4         [24] 1434 	ljmp	00171$
                                   1435 ;	quantum/via.c:399: case id_lighting_save: {
      00AD8F                       1436 00138$:
                                   1437 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AD8F 12 B0 50         [24] 1438 	lcall	_ak820_outline_0094
      00AD92 90 0D DF         [24] 1439 	mov	dptr,#_vialrgb_save_PARM_2
      00AD95 12 B0 2B         [24] 1440 	lcall	_ak820_outline_0040
      00AD98 C0 07            [24] 1441 	push	ar7
      00AD9A C0 06            [24] 1442 	push	ar6
      00AD9C C0 03            [24] 1443 	push	ar3
      00AD9E 12 BB AC         [24] 1444 	lcall	_vialrgb_save
      00ADA1 D0 03            [24] 1445 	pop	ar3
      00ADA3 D0 06            [24] 1446 	pop	ar6
      00ADA5 D0 07            [24] 1447 	pop	ar7
                                   1448 ;	quantum/via.c:419: break;
      00ADA7 02 AF F4         [24] 1449 	ljmp	00171$
                                   1450 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00ADAA                       1451 00139$:
                                   1452 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00ADAA C0 07            [24] 1453 	push	ar7
      00ADAC C0 06            [24] 1454 	push	ar6
      00ADAE C0 05            [24] 1455 	push	ar5
      00ADB0 C0 04            [24] 1456 	push	ar4
      00ADB2 C0 03            [24] 1457 	push	ar3
      00ADB4 12 8E 51         [24] 1458 	lcall	_dynamic_keymap_macro_get_count
      00ADB7 AA 82            [24] 1459 	mov	r2, dpl
      00ADB9 D0 03            [24] 1460 	pop	ar3
      00ADBB D0 04            [24] 1461 	pop	ar4
      00ADBD D0 05            [24] 1462 	pop	ar5
      00ADBF D0 06            [24] 1463 	pop	ar6
      00ADC1 D0 07            [24] 1464 	pop	ar7
      00ADC3 12 38 99         [24] 1465 	lcall	_ak820_outline_0127
      00ADC6 EA               [12] 1466 	mov	a,r2
      00ADC7 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	quantum/via.c:430: break;
      00ADC8 02 AF F4         [24] 1469 	ljmp	00171$
                                   1470 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00ADCB                       1471 00140$:
                                   1472 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00ADCB C0 07            [24] 1473 	push	ar7
      00ADCD C0 06            [24] 1474 	push	ar6
      00ADCF C0 05            [24] 1475 	push	ar5
      00ADD1 C0 04            [24] 1476 	push	ar4
      00ADD3 C0 03            [24] 1477 	push	ar3
      00ADD5 12 8E 55         [24] 1478 	lcall	_dynamic_keymap_macro_get_buffer_size
      00ADD8 12 4D 5C         [24] 1479 	lcall	_ak820_outline_0190
      00ADDB D0 03            [24] 1480 	pop	ar3
      00ADDD D0 04            [24] 1481 	pop	ar4
      00ADDF D0 05            [24] 1482 	pop	ar5
      00ADE1 D0 06            [24] 1483 	pop	ar6
      00ADE3 D0 07            [24] 1484 	pop	ar7
                                   1485 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00ADE5 8A 00            [24] 1486 	mov	ar0,r2
      00ADE7 12 38 99         [24] 1487 	lcall	_ak820_outline_0127
      00ADEA E8               [12] 1488 	mov	a,r0
      00ADEB 12 43 09         [24] 1489 	lcall	_ak820_outline_0033
                                   1490 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00ADEE E9               [12] 1491 	mov	a,r1
      00ADEF F0               [24] 1492 	movx	@dptr,a
                                   1493 ;	quantum/via.c:436: break;
      00ADF0 02 AF F4         [24] 1494 	ljmp	00171$
                                   1495 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00ADF3                       1496 00141$:
                                   1497 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ADF3 C0 03            [24] 1498 	push	ar3
      00ADF5 12 B0 02         [24] 1499 	lcall	_ak820_outline_0003
      00ADF8 89 38            [24] 1500 	mov	_raw_hid_receive_sloc0_1_0,r1
      00ADFA 8A 39            [24] 1501 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1502 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00ADFC 12 B0 19         [24] 1503 	lcall	_ak820_outline_0016
      00ADFF FB               [12] 1504 	mov	r3,a
                                   1505 ;	quantum/via.c:441: if (size <= 28)
      00AE00 8B 3E            [24] 1506 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AE02 75 3F 00         [24] 1507 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AE05 C3               [12] 1508 	clr	c
      00AE06 74 1C            [12] 1509 	mov	a,#0x1c
      00AE08 9B               [12] 1510 	subb	a,r3
      00AE09 D0 03            [24] 1511 	pop	ar3
      00AE0B 50 03            [24] 1512 	jnc	00562$
      00AE0D 02 AF F4         [24] 1513 	ljmp	00171$
      00AE10                       1514 00562$:
                                   1515 ;	free result
                                   1516 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AE10 12 B0 34         [24] 1517 	lcall	_ak820_outline_0071
      00AE13 90 0B 73         [24] 1518 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AE16 E5 3E            [12] 1519 	mov	a,_raw_hid_receive_sloc3_1_0
      00AE18 F0               [24] 1520 	movx	@dptr,a
      00AE19 E5 3F            [12] 1521 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AE1B A3               [24] 1522 	inc	dptr
      00AE1C F0               [24] 1523 	movx	@dptr,a
      00AE1D 90 0B 75         [24] 1524 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AE20 12 B0 3E         [24] 1525 	lcall	_ak820_outline_0087
      00AE23 85 38 82         [24] 1526 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AE26 85 39 83         [24] 1527 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AE29 C0 07            [24] 1528 	push	ar7
      00AE2B C0 06            [24] 1529 	push	ar6
      00AE2D C0 03            [24] 1530 	push	ar3
      00AE2F 12 8E 59         [24] 1531 	lcall	_dynamic_keymap_macro_get_buffer
      00AE32 D0 03            [24] 1532 	pop	ar3
      00AE34 D0 06            [24] 1533 	pop	ar6
      00AE36 D0 07            [24] 1534 	pop	ar7
                                   1535 ;	quantum/via.c:443: break;
      00AE38 02 AF F4         [24] 1536 	ljmp	00171$
                                   1537 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AE3B                       1538 00144$:
                                   1539 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AE3B 90 0E 6A         [24] 1540 	mov	dptr,#_vial_unlocked
      00AE3E E0               [24] 1541 	movx	a,@dptr
      00AE3F 70 01            [24] 1542 	jnz	00146$
                                   1543 ;	quantum/via.c:450: return;
      00AE41 22               [24] 1544 	ret
      00AE42                       1545 00146$:
                                   1546 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AE42 C0 03            [24] 1547 	push	ar3
      00AE44 12 B0 02         [24] 1548 	lcall	_ak820_outline_0003
      00AE47 89 3E            [24] 1549 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AE49 8A 3F            [24] 1550 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1551 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AE4B 12 B0 19         [24] 1552 	lcall	_ak820_outline_0016
      00AE4E F5 38            [12] 1553 	mov	_raw_hid_receive_sloc0_1_0, a
      00AE50 75 39 00         [24] 1554 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1555 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AE53 85 38 40         [24] 1556 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AE56 85 39 41         [24] 1557 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00AE59 C3               [12] 1558 	clr	c
      00AE5A 74 1C            [12] 1559 	mov	a,#0x1c
      00AE5C 95 40            [12] 1560 	subb	a,_raw_hid_receive_sloc4_1_0
      00AE5E E4               [12] 1561 	clr	a
      00AE5F 95 41            [12] 1562 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AE61 D0 03            [24] 1563 	pop	ar3
      00AE63 40 44            [24] 1564 	jc	00147$
                                   1565 ;	free result
      00AE65 8B 01            [24] 1566 	mov	ar1,r3
      00AE67 7A 00            [12] 1567 	mov	r2,#0x00
      00AE69 E9               [12] 1568 	mov	a,r1
      00AE6A 24 FC            [12] 1569 	add	a,#0xfc
      00AE6C F9               [12] 1570 	mov	r1,a
      00AE6D EA               [12] 1571 	mov	a,r2
      00AE6E 34 FF            [12] 1572 	addc	a,#0xff
      00AE70 FA               [12] 1573 	mov	r2,a
      00AE71 C3               [12] 1574 	clr	c
      00AE72 E9               [12] 1575 	mov	a,r1
      00AE73 95 40            [12] 1576 	subb	a,_raw_hid_receive_sloc4_1_0
      00AE75 EA               [12] 1577 	mov	a,r2
      00AE76 95 41            [12] 1578 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AE78 40 2F            [24] 1579 	jc	00147$
                                   1580 ;	free result
      00AE7A 12 B0 34         [24] 1581 	lcall	_ak820_outline_0071
      00AE7D 90 0B 7A         [24] 1582 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AE80 E5 38            [12] 1583 	mov	a,_raw_hid_receive_sloc0_1_0
      00AE82 F0               [24] 1584 	movx	@dptr,a
      00AE83 E5 39            [12] 1585 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AE85 A3               [24] 1586 	inc	dptr
      00AE86 F0               [24] 1587 	movx	@dptr,a
      00AE87 90 0B 7C         [24] 1588 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AE8A 12 B0 3E         [24] 1589 	lcall	_ak820_outline_0087
      00AE8D 85 3E 82         [24] 1590 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AE90 85 3F 83         [24] 1591 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AE93 C0 07            [24] 1592 	push	ar7
      00AE95 C0 06            [24] 1593 	push	ar6
      00AE97 C0 03            [24] 1594 	push	ar3
      00AE99 12 8E A5         [24] 1595 	lcall	_dynamic_keymap_macro_set_buffer
      00AE9C E5 82            [12] 1596 	mov	a, dpl
      00AE9E D0 03            [24] 1597 	pop	ar3
      00AEA0 D0 06            [24] 1598 	pop	ar6
      00AEA2 D0 07            [24] 1599 	pop	ar7
      00AEA4 60 03            [24] 1600 	jz	00566$
      00AEA6 02 AF F4         [24] 1601 	ljmp	00171$
      00AEA9                       1602 00566$:
      00AEA9                       1603 00147$:
      00AEA9 22               [24] 1604 	ret
                                   1605 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AEAA                       1606 00151$:
                                   1607 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AEAA 90 0E 6A         [24] 1608 	mov	dptr,#_vial_unlocked
      00AEAD E0               [24] 1609 	movx	a,@dptr
      00AEAE 70 01            [24] 1610 	jnz	00153$
      00AEB0 22               [24] 1611 	ret
      00AEB1                       1612 00153$:
                                   1613 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AEB1 C0 07            [24] 1614 	push	ar7
      00AEB3 C0 06            [24] 1615 	push	ar6
      00AEB5 C0 03            [24] 1616 	push	ar3
      00AEB7 12 8E D7         [24] 1617 	lcall	_dynamic_keymap_macro_reset
      00AEBA D0 03            [24] 1618 	pop	ar3
      00AEBC D0 06            [24] 1619 	pop	ar6
      00AEBE D0 07            [24] 1620 	pop	ar7
                                   1621 ;	quantum/via.c:473: break;
      00AEC0 02 AF F4         [24] 1622 	ljmp	00171$
                                   1623 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AEC3                       1624 00154$:
                                   1625 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AEC3 C0 07            [24] 1626 	push	ar7
      00AEC5 C0 06            [24] 1627 	push	ar6
      00AEC7 C0 05            [24] 1628 	push	ar5
      00AEC9 C0 04            [24] 1629 	push	ar4
      00AECB C0 03            [24] 1630 	push	ar3
      00AECD 12 87 49         [24] 1631 	lcall	_dynamic_keymap_get_layer_count
      00AED0 AA 82            [24] 1632 	mov	r2, dpl
      00AED2 D0 03            [24] 1633 	pop	ar3
      00AED4 D0 04            [24] 1634 	pop	ar4
      00AED6 D0 05            [24] 1635 	pop	ar5
      00AED8 D0 06            [24] 1636 	pop	ar6
      00AEDA D0 07            [24] 1637 	pop	ar7
      00AEDC 12 38 99         [24] 1638 	lcall	_ak820_outline_0127
      00AEDF EA               [12] 1639 	mov	a,r2
      00AEE0 F0               [24] 1640 	movx	@dptr,a
                                   1641 ;	quantum/via.c:477: break;
      00AEE1 02 AF F4         [24] 1642 	ljmp	00171$
                                   1643 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AEE4                       1644 00155$:
                                   1645 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AEE4 C0 03            [24] 1646 	push	ar3
      00AEE6 12 B0 02         [24] 1647 	lcall	_ak820_outline_0003
      00AEE9 89 40            [24] 1648 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AEEB 8A 41            [24] 1649 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1650 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00AEED 12 B0 19         [24] 1651 	lcall	_ak820_outline_0016
      00AEF0 FB               [12] 1652 	mov	r3,a
                                   1653 ;	quantum/via.c:482: if (size <= 28)
      00AEF1 8B 3E            [24] 1654 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AEF3 75 3F 00         [24] 1655 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AEF6 C3               [12] 1656 	clr	c
      00AEF7 74 1C            [12] 1657 	mov	a,#0x1c
      00AEF9 9B               [12] 1658 	subb	a,r3
      00AEFA D0 03            [24] 1659 	pop	ar3
      00AEFC 50 03            [24] 1660 	jnc	00568$
      00AEFE 02 AF F4         [24] 1661 	ljmp	00171$
      00AF01                       1662 00568$:
                                   1663 ;	free result
                                   1664 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AF01 12 B0 34         [24] 1665 	lcall	_ak820_outline_0071
      00AF04 90 0B 5C         [24] 1666 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AF07 E5 3E            [12] 1667 	mov	a,_raw_hid_receive_sloc3_1_0
      00AF09 F0               [24] 1668 	movx	@dptr,a
      00AF0A E5 3F            [12] 1669 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AF0C A3               [24] 1670 	inc	dptr
      00AF0D F0               [24] 1671 	movx	@dptr,a
      00AF0E 90 0B 5E         [24] 1672 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AF11 12 B0 3E         [24] 1673 	lcall	_ak820_outline_0087
      00AF14 85 40 82         [24] 1674 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AF17 85 41 83         [24] 1675 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AF1A C0 07            [24] 1676 	push	ar7
      00AF1C C0 06            [24] 1677 	push	ar6
      00AF1E C0 03            [24] 1678 	push	ar3
      00AF20 12 8C 1E         [24] 1679 	lcall	_dynamic_keymap_get_buffer
      00AF23 D0 03            [24] 1680 	pop	ar3
      00AF25 D0 06            [24] 1681 	pop	ar6
      00AF27 D0 07            [24] 1682 	pop	ar7
                                   1683 ;	quantum/via.c:484: break;
      00AF29 02 AF F4         [24] 1684 	ljmp	00171$
                                   1685 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00AF2C                       1686 00158$:
                                   1687 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AF2C 12 43 4F         [24] 1688 	lcall	_ak820_outline_0097
      00AF2F FD               [12] 1689 	mov	r5,a
      00AF30 7C 00            [12] 1690 	mov	r4,#0x00
      00AF32 12 38 2E         [24] 1691 	lcall	_ak820_outline_0036
      00AF35 7A 00            [12] 1692 	mov	r2,#0x00
      00AF37 42 04            [12] 1693 	orl	ar4,a
      00AF39 EA               [12] 1694 	mov	a,r2
      00AF3A 42 05            [12] 1695 	orl	ar5,a
      00AF3C 8C 40            [24] 1696 	mov	_raw_hid_receive_sloc4_1_0,r4
      00AF3E 8D 41            [24] 1697 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1698 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00AF40 12 B0 19         [24] 1699 	lcall	_ak820_outline_0016
      00AF43 F9               [12] 1700 	mov	r1,a
      00AF44 7A 00            [12] 1701 	mov	r2,#0x00
                                   1702 ;	quantum/via.c:489: if (size <= 28)
      00AF46 89 00            [24] 1703 	mov	ar0,r1
      00AF48 E8               [12] 1704 	mov	a,r0
      00AF49 24 E3            [12] 1705 	add	a,#0xff - 0x1c
      00AF4B 50 02            [24] 1706 	jnc	00569$
      00AF4D E1 F4            [12] 1707 	ajmp	00171$
      00AF4F                       1708 00569$:
                                   1709 ;	free result
                                   1710 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00AF4F C0 03            [24] 1711 	push	ar3
      00AF51 74 04            [12] 1712 	mov	a,#0x04
      00AF53 2E               [12] 1713 	add	a, r6
      00AF54 F8               [12] 1714 	mov	r0,a
      00AF55 E4               [12] 1715 	clr	a
      00AF56 3F               [12] 1716 	addc	a, r7
      00AF57 FB               [12] 1717 	mov	r3,a
      00AF58 7D 00            [12] 1718 	mov	r5,#0x00
      00AF5A 90 0B 63         [24] 1719 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00AF5D 12 4D 4F         [24] 1720 	lcall	_ak820_outline_0140
      00AF60 90 0B 65         [24] 1721 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00AF63 E8               [12] 1722 	mov	a,r0
      00AF64 12 48 3C         [24] 1723 	lcall	_ak820_outline_0194
      00AF67 ED               [12] 1724 	mov	a,r5
      00AF68 A3               [24] 1725 	inc	dptr
      00AF69 F0               [24] 1726 	movx	@dptr,a
      00AF6A 85 40 82         [24] 1727 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AF6D 85 41 83         [24] 1728 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AF70 C0 07            [24] 1729 	push	ar7
      00AF72 C0 06            [24] 1730 	push	ar6
      00AF74 C0 03            [24] 1731 	push	ar3
      00AF76 12 8C 5F         [24] 1732 	lcall	_dynamic_keymap_set_buffer
      00AF79 D0 03            [24] 1733 	pop	ar3
      00AF7B D0 06            [24] 1734 	pop	ar6
      00AF7D D0 07            [24] 1735 	pop	ar7
                                   1736 ;	quantum/via.c:491: break;
      00AF7F D0 03            [24] 1737 	pop	ar3
      00AF81 E1 F4            [12] 1738 	ajmp	00171$
                                   1739 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AF83                       1740 00161$:
                                   1741 ;	quantum/via.c:497: if (!vial_unlocked)
      00AF83 90 0E 6A         [24] 1742 	mov	dptr,#_vial_unlocked
      00AF86 E0               [24] 1743 	movx	a,@dptr
      00AF87 70 02            [24] 1744 	jnz	00570$
      00AF89 E1 F4            [12] 1745 	ajmp	00171$
      00AF8B                       1746 00570$:
                                   1747 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AF8B 12 B0 57         [24] 1748 	lcall	_ak820_outline_0156
      00AF8E 90 06 C1         [24] 1749 	mov	dptr,#_raw_hid_send_PARM_2
      00AF91 12 B0 47         [24] 1750 	lcall	_ak820_outline_0088
      00AF94 C0 07            [24] 1751 	push	ar7
      00AF96 C0 06            [24] 1752 	push	ar6
      00AF98 C0 03            [24] 1753 	push	ar3
      00AF9A 12 4F 92         [24] 1754 	lcall	_raw_hid_send
      00AF9D D0 03            [24] 1755 	pop	ar3
      00AF9F D0 06            [24] 1756 	pop	ar6
      00AFA1 D0 07            [24] 1757 	pop	ar7
                                   1758 ;	quantum/via.c:503: wait_ms(100);
      00AFA3 7D 64            [12] 1759 	mov	r5,#0x64
      00AFA5                       1760 00176$:
      00AFA5 ED               [12] 1761 	mov	a,r5
      00AFA6 60 09            [24] 1762 	jz	00166$
      00AFA8 90 00 01         [24] 1763 	mov	dptr,#0x0001
      00AFAB 12 5D 31         [24] 1764 	lcall	_mDelaymS
      00AFAE 1D               [12] 1765 	dec	r5
      00AFAF 80 F4            [24] 1766 	sjmp	00176$
      00AFB1                       1767 00166$:
                                   1768 ;	quantum/via.c:504: bootloader_jump();
      00AFB1 C0 07            [24] 1769 	push	ar7
      00AFB3 C0 06            [24] 1770 	push	ar6
      00AFB5 C0 03            [24] 1771 	push	ar3
      00AFB7 12 34 0E         [24] 1772 	lcall	_bootloader_jump
      00AFBA D0 03            [24] 1773 	pop	ar3
      00AFBC D0 06            [24] 1774 	pop	ar6
      00AFBE D0 07            [24] 1775 	pop	ar7
                                   1776 ;	quantum/via.c:505: break;
                                   1777 ;	quantum/via.c:509: case id_vial_prefix: {
      00AFC0 80 32            [24] 1778 	sjmp	00171$
      00AFC2                       1779 00168$:
                                   1780 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00AFC2 12 B0 57         [24] 1781 	lcall	_ak820_outline_0156
      00AFC5 90 0C A2         [24] 1782 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AFC8 12 B0 47         [24] 1783 	lcall	_ak820_outline_0088
      00AFCB C0 07            [24] 1784 	push	ar7
      00AFCD C0 06            [24] 1785 	push	ar6
      00AFCF C0 03            [24] 1786 	push	ar3
      00AFD1 12 B1 47         [24] 1787 	lcall	_vial_handle_cmd
      00AFD4 D0 03            [24] 1788 	pop	ar3
      00AFD6 D0 06            [24] 1789 	pop	ar6
      00AFD8 D0 07            [24] 1790 	pop	ar7
                                   1791 ;	quantum/via.c:511: break;
                                   1792 ;	quantum/via.c:514: default: {
      00AFDA 80 18            [24] 1793 	sjmp	00171$
      00AFDC                       1794 00169$:
                                   1795 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00AFDC 12 B0 57         [24] 1796 	lcall	_ak820_outline_0156
      00AFDF 90 0C 90         [24] 1797 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AFE2 12 B0 47         [24] 1798 	lcall	_ak820_outline_0088
      00AFE5 C0 07            [24] 1799 	push	ar7
      00AFE7 C0 06            [24] 1800 	push	ar6
      00AFE9 C0 03            [24] 1801 	push	ar3
      00AFEB 12 AA 71         [24] 1802 	lcall	_raw_hid_receive_kb
      00AFEE D0 03            [24] 1803 	pop	ar3
      00AFF0 D0 06            [24] 1804 	pop	ar6
      00AFF2 D0 07            [24] 1805 	pop	ar7
                                   1806 ;	quantum/via.c:521: skip:
      00AFF4                       1807 00171$:
                                   1808 ;	quantum/via.c:525: raw_hid_send(data, length);
      00AFF4 7D 00            [12] 1809 	mov	r5,#0x00
      00AFF6 90 06 C1         [24] 1810 	mov	dptr,#_raw_hid_send_PARM_2
      00AFF9 EB               [12] 1811 	mov	a,r3
      00AFFA 12 43 35         [24] 1812 	lcall	_ak820_outline_0062
      00AFFD 8D F0            [24] 1813 	mov	b, r5
                                   1814 ;	quantum/via.c:526: }
      00AFFF 02 4F 92         [24] 1815 	ljmp	_raw_hid_send
                                   1816 	.area CSEG    (CODE)
                                   1817 	.area CONST   (CODE)
                                   1818 	.area XINIT   (CODE)
                                   1819 	.area CABS    (ABS,CODE)
                                   1820 
                                   1821 ; Experimental exact instruction outlining.
                                   1822 	.globl _ak820_outline_0002
                                   1823 	.globl _ak820_outline_0003
                                   1824 	.globl _ak820_outline_0009
                                   1825 	.globl _ak820_outline_0010
                                   1826 	.globl _ak820_outline_0013
                                   1827 	.globl _ak820_outline_0015
                                   1828 	.globl _ak820_outline_0016
                                   1829 	.globl _ak820_outline_0017
                                   1830 	.globl _ak820_outline_0024
                                   1831 	.globl _ak820_outline_0033
                                   1832 	.globl _ak820_outline_0036
                                   1833 	.globl _ak820_outline_0037
                                   1834 	.globl _ak820_outline_0040
                                   1835 	.globl _ak820_outline_0045
                                   1836 	.globl _ak820_outline_0048
                                   1837 	.globl _ak820_outline_0054
                                   1838 	.globl _ak820_outline_0062
                                   1839 	.globl _ak820_outline_0071
                                   1840 	.globl _ak820_outline_0087
                                   1841 	.globl _ak820_outline_0088
                                   1842 	.globl _ak820_outline_0094
                                   1843 	.globl _ak820_outline_0097
                                   1844 	.globl _ak820_outline_0105
                                   1845 	.globl _ak820_outline_0108
                                   1846 	.globl _ak820_outline_0109
                                   1847 	.globl _ak820_outline_0123
                                   1848 	.globl _ak820_outline_0125
                                   1849 	.globl _ak820_outline_0127
                                   1850 	.globl _ak820_outline_0140
                                   1851 	.globl _ak820_outline_0154
                                   1852 	.globl _ak820_outline_0155
                                   1853 	.globl _ak820_outline_0156
                                   1854 	.globl _ak820_outline_0158
                                   1855 	.globl _ak820_outline_0161
                                   1856 	.globl _ak820_outline_0163
                                   1857 	.globl _ak820_outline_0164
                                   1858 	.globl _ak820_outline_0190
                                   1859 	.globl _ak820_outline_0194
                                   1860 
                                   1861 	.area CSEG (CODE)
                                   1862 ; function ak820_outline_0003
      00B002                       1863 _ak820_outline_0003:
      00B002 8C 82            [24] 1864 	mov	dpl,r4
      00B004 8D 83            [24] 1865 	mov	dph,r5
      00B006 E0               [24] 1866 	movx	a,@dptr
      00B007 FA               [12] 1867 	mov	r2,a
      00B008 79 00            [12] 1868 	mov	r1,#0x00
      00B00A 8E 82            [24] 1869 	mov	dpl,r6
      00B00C 8F 83            [24] 1870 	mov	dph,r7
      00B00E A3               [24] 1871 	inc	dptr
      00B00F A3               [24] 1872 	inc	dptr
      00B010 E0               [24] 1873 	movx	a,@dptr
      00B011 7B 00            [12] 1874 	mov	r3,#0x00
      00B013 42 01            [12] 1875 	orl	ar1,a
      00B015 EB               [12] 1876 	mov	a,r3
      00B016 42 02            [12] 1877 	orl	ar2,a
      00B018 22               [24] 1878 	ret
                                   1879 
                                   1880 	.area CSEG (CODE)
                                   1881 ; function ak820_outline_0016
      00B019                       1882 _ak820_outline_0016:
      00B019 8E 82            [24] 1883 	mov	dpl,r6
      00B01B 8F 83            [24] 1884 	mov	dph,r7
      00B01D A3               [24] 1885 	inc	dptr
      00B01E A3               [24] 1886 	inc	dptr
      00B01F A3               [24] 1887 	inc	dptr
      00B020 E0               [24] 1888 	movx	a,@dptr
      00B021 22               [24] 1889 	ret
                                   1890 
                                   1891 	.area CSEG (CODE)
                                   1892 ; function ak820_outline_0024
      00B022                       1893 _ak820_outline_0024:
      00B022 8E 82            [24] 1894 	mov	dpl,r6
      00B024 8F 83            [24] 1895 	mov	dph,r7
      00B026 A3               [24] 1896 	inc	dptr
      00B027 A3               [24] 1897 	inc	dptr
      00B028 A3               [24] 1898 	inc	dptr
      00B029 A3               [24] 1899 	inc	dptr
      00B02A 22               [24] 1900 	ret
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0040
      00B02B                       1904 _ak820_outline_0040:
      00B02B EB               [12] 1905 	mov	a,r3
      00B02C F0               [24] 1906 	movx	@dptr,a
      00B02D 88 82            [24] 1907 	mov	dpl,r0
      00B02F 89 83            [24] 1908 	mov	dph,r1
      00B031 8A F0            [24] 1909 	mov	b,r2
      00B033 22               [24] 1910 	ret
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0071
      00B034                       1914 _ak820_outline_0071:
      00B034 74 04            [12] 1915 	mov	a,#0x04
      00B036 2E               [12] 1916 	add	a,r6
      00B037 F9               [12] 1917 	mov	r1,a
      00B038 E4               [12] 1918 	clr	a
      00B039 3F               [12] 1919 	addc	a,r7
      00B03A F8               [12] 1920 	mov	r0,a
      00B03B 7A 00            [12] 1921 	mov	r2,#0x00
      00B03D 22               [24] 1922 	ret
                                   1923 
                                   1924 	.area CSEG (CODE)
                                   1925 ; function ak820_outline_0087
      00B03E                       1926 _ak820_outline_0087:
      00B03E E9               [12] 1927 	mov	a,r1
      00B03F F0               [24] 1928 	movx	@dptr,a
      00B040 E8               [12] 1929 	mov	a,r0
      00B041 A3               [24] 1930 	inc	dptr
      00B042 F0               [24] 1931 	movx	@dptr,a
      00B043 EA               [12] 1932 	mov	a,r2
      00B044 A3               [24] 1933 	inc	dptr
      00B045 F0               [24] 1934 	movx	@dptr,a
      00B046 22               [24] 1935 	ret
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0088
      00B047                       1939 _ak820_outline_0088:
      00B047 EB               [12] 1940 	mov	a,r3
      00B048 F0               [24] 1941 	movx	@dptr,a
      00B049 8A 82            [24] 1942 	mov	dpl,r2
      00B04B 8C 83            [24] 1943 	mov	dph,r4
      00B04D 8D F0            [24] 1944 	mov	b,r5
      00B04F 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0094
      00B050                       1949 _ak820_outline_0094:
      00B050 8E 00            [24] 1950 	mov	ar0,r6
      00B052 8F 01            [24] 1951 	mov	ar1,r7
      00B054 7A 00            [12] 1952 	mov	r2,#0x00
      00B056 22               [24] 1953 	ret
                                   1954 
                                   1955 	.area CSEG (CODE)
                                   1956 ; function ak820_outline_0156
      00B057                       1957 _ak820_outline_0156:
      00B057 8E 02            [24] 1958 	mov	ar2,r6
      00B059 8F 04            [24] 1959 	mov	ar4,r7
      00B05B 7D 00            [12] 1960 	mov	r5,#0x00
      00B05D 22               [24] 1961 	ret
