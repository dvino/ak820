                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _ak820_settings_caps_delay
                                     24 	.globl _ak820_settings_tap_code_delay
                                     25 	.globl _clear_owned_usages
                                     26 	.globl _owned_usage_key
                                     27 	.globl _clear_owned_keys
                                     28 	.globl _del_owned_key
                                     29 	.globl _add_owned_key
                                     30 	.globl _clear_owned_mods
                                     31 	.globl _del_owned_weak_mods
                                     32 	.globl _add_owned_weak_mods
                                     33 	.globl _del_owned_mods
                                     34 	.globl _add_owned_mods
                                     35 	.globl _clear_weak_mods
                                     36 	.globl _clear_mods
                                     37 	.globl _send_keyboard_report
                                     38 	.globl _layer_hold_clear
                                     39 	.globl _layer_hold_off
                                     40 	.globl _layer_hold_on
                                     41 	.globl _ak820_resolve_key
                                     42 	.globl _layer_xor
                                     43 	.globl _layer_and
                                     44 	.globl _layer_or
                                     45 	.globl _layer_off
                                     46 	.globl _layer_on
                                     47 	.globl _layer_move
                                     48 	.globl _layer_clear
                                     49 	.globl _layer_state_set
                                     50 	.globl _default_layer_xor
                                     51 	.globl _default_layer_and
                                     52 	.globl _default_layer_or
                                     53 	.globl _default_layer_set
                                     54 	.globl _post_process_record_quantum
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      000027                        590 _process_action_sloc0_1_0:
      000027                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      000020                        608 _process_action_sloc1_1_0:
      000020                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      00085A                        618 _tp_buttons::
      00085A                        619 	.ds 2
      00085C                        620 _action_exec_PARM_1:
      00085C                        621 	.ds 6
      000862                        622 _action_exec_record_10001_648:
      000862                        623 	.ds 9
      00086B                        624 _ak820_action_exec_event_10000_652:
      00086B                        625 	.ds 2
      00086D                        626 _ak820_action_exec_snapshot_10000_653:
      00086D                        627 	.ds 6
      000873                        628 _process_record_record_argument_10000_656:
      000873                        629 	.ds 2
      000875                        630 _process_record_handler_record_argument_10000_664:
      000875                        631 	.ds 2
      000877                        632 _process_record_handler_action_10000_665:
      000877                        633 	.ds 2
      000879                        634 _process_action_PARM_2:
      000879                        635 	.ds 2
      00087B                        636 _process_action_record_argument_10000_676:
      00087B                        637 	.ds 2
      00087D                        638 _process_action_on_40000_699:
      00087D                        639 	.ds 1
      00087E                        640 _register_code_code_10000_733:
      00087E                        641 	.ds 1
      00087F                        642 _unregister_code_code_10000_747:
      00087F                        643 	.ds 1
      000880                        644 _tap_code_delay_PARM_2:
      000880                        645 	.ds 2
      000882                        646 _tap_code_delay_code_10000_760:
      000882                        647 	.ds 1
      000883                        648 _tap_code_code_10000_767:
      000883                        649 	.ds 1
      000884                        650 _register_mods_mods_10000_769:
      000884                        651 	.ds 1
      000885                        652 _unregister_mods_mods_10000_773:
      000885                        653 	.ds 1
      000886                        654 _register_weak_mods_mods_10000_777:
      000886                        655 	.ds 1
      000887                        656 _unregister_weak_mods_mods_10000_781:
      000887                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000E0A                        666 _disable_action_cache::
      000E0A                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      007457                        711 _action_exec:
                                    712 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007457 90 08 5E         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00745A 12 37 E9         [24]  714 	lcall	_ak820_outline_0005
      00745D 12 35 FC         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007460 90 08 5C         [24]  717 	mov	dptr,#_action_exec_PARM_1
      007463 12 49 06         [24]  718 	lcall	_ak820_tapping_before
      007466 E5 82            [12]  719 	mov	a, dpl
      007468 70 01            [24]  720 	jnz	00102$
      00746A 22               [24]  721 	ret
      00746B                        722 00102$:
                                    723 ;	quantum/action.c:126: if (event.pressed) {
      00746B 90 08 61         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00746E E0               [24]  725 	movx	a,@dptr
      00746F 60 03            [24]  726 	jz	00104$
                                    727 ;	quantum/action.c:128: clear_weak_mods();
      007471 12 84 5A         [24]  728 	lcall	_clear_weak_mods
      007474                        729 00104$:
                                    730 ;	quantum/action.c:140: record.event = event;
      007474 90 0D E2         [24]  731 	mov	dptr,#___memcpy_PARM_2
      007477 74 5C            [12]  732 	mov	a,#_action_exec_PARM_1
      007479 F0               [24]  733 	movx	@dptr,a
      00747A 74 08            [12]  734 	mov	a,#(_action_exec_PARM_1 >> 8)
      00747C 12 7A EF         [24]  735 	lcall	_ak820_outline_0053
      00747F 12 7B 0F         [24]  736 	lcall	_ak820_outline_0117
      007482 90 08 62         [24]  737 	mov	dptr,#_action_exec_record_10001_648
      007485 F5 F0            [12]  738 	mov	b,a
      007487 12 BC AA         [24]  739 	lcall	___memcpy
                                    740 ;	quantum/action.c:142: record.tap.count = 0;
      00748A 90 08 68         [24]  741 	mov	dptr,#(_action_exec_record_10001_648 + 0x0006)
      00748D E0               [24]  742 	movx	a,@dptr
      00748E 54 0F            [12]  743 	anl	a,#0x0f
      007490 F0               [24]  744 	movx	@dptr,a
                                    745 ;	quantum/action.c:147: record.keycode = 0;
      007491 90 08 69         [24]  746 	mov	dptr,#(_action_exec_record_10001_648 + 0x0007)
      007494 12 53 D5         [24]  747 	lcall	_ak820_outline_0173
                                    748 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007497 90 08 66         [24]  749 	mov	dptr,#(_action_exec_record_10001_648 + 0x0004)
      00749A E0               [24]  750 	movx	a,@dptr
      00749B 60 0A            [24]  751 	jz	00107$
      00749D 90 08 62         [24]  752 	mov	dptr,#_action_exec_record_10001_648
      0074A0 12 A2 B8         [24]  753 	lcall	_pre_process_record_quantum
      0074A3 E5 82            [12]  754 	mov	a, dpl
      0074A5 60 10            [24]  755 	jz	00110$
      0074A7                        756 00107$:
                                    757 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      0074A7 90 08 62         [24]  758 	mov	dptr,#_action_exec_record_10001_648
      0074AA 12 4A 0F         [24]  759 	lcall	_ak820_tapping_process
      0074AD E5 82            [12]  760 	mov	a, dpl
      0074AF 70 01            [24]  761 	jnz	00106$
      0074B1 22               [24]  762 	ret
      0074B2                        763 00106$:
                                    764 ;	quantum/action.c:185: process_record(&record);
      0074B2 90 08 62         [24]  765 	mov	dptr,#_action_exec_record_10001_648
                                    766 ;	quantum/action.c:200: }
      0074B5 81 F6            [12]  767 	ajmp	_process_record
      0074B7                        768 00110$:
      0074B7 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_652'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_653'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      0074B8                        780 _ak820_action_exec:
      0074B8 12 38 8A         [24]  781 	lcall	_ak820_outline_0108
      0074BB 90 08 6B         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_652
      0074BE 12 38 8F         [24]  783 	lcall	_ak820_outline_0109
                                    784 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      0074C1 90 08 6B         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_652
      0074C4 12 38 59         [24]  786 	lcall	_ak820_outline_0079
      0074C7 7F 00            [12]  787 	mov	r7,#0x00
      0074C9 90 0D E2         [24]  788 	mov	dptr,#___memcpy_PARM_2
      0074CC ED               [12]  789 	mov	a,r5
      0074CD 12 38 1E         [24]  790 	lcall	_ak820_outline_0017
      0074D0 90 0D E5         [24]  791 	mov	dptr,#___memcpy_PARM_3
      0074D3 12 7B 0F         [24]  792 	lcall	_ak820_outline_0117
      0074D6 90 08 6D         [24]  793 	mov	dptr,#_ak820_action_exec_snapshot_10000_653
      0074D9 F5 F0            [12]  794 	mov	b,a
      0074DB 12 BC AA         [24]  795 	lcall	___memcpy
                                    796 ;	quantum/action.c:207: action_exec(snapshot);
      0074DE 90 0D E2         [24]  797 	mov	dptr,#___memcpy_PARM_2
      0074E1 74 6D            [12]  798 	mov	a,#_ak820_action_exec_snapshot_10000_653
      0074E3 F0               [24]  799 	movx	@dptr,a
      0074E4 74 08            [12]  800 	mov	a,#(_ak820_action_exec_snapshot_10000_653 >> 8)
      0074E6 12 7A EF         [24]  801 	lcall	_ak820_outline_0053
      0074E9 12 7B 0F         [24]  802 	lcall	_ak820_outline_0117
      0074EC 90 08 5C         [24]  803 	mov	dptr,#_action_exec_PARM_1
      0074EF F5 F0            [12]  804 	mov	b,a
      0074F1 12 BC AA         [24]  805 	lcall	___memcpy
                                    806 ;	quantum/action.c:208: }
      0074F4 81 57            [12]  807 	ajmp	_action_exec
                                    808 ;------------------------------------------------------------
                                    809 ;Allocation info for local variables in function 'process_record_nocache'
                                    810 ;------------------------------------------------------------
                                    811 ;record        Allocated with name '_process_record_nocache_record_10000_654'
                                    812 ;------------------------------------------------------------
                                    813 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    814 ;	-----------------------------------------
                                    815 ;	 function process_record
                                    816 ;	-----------------------------------------
      0074F6                        817 _process_record:
      0074F6 12 38 8A         [24]  818 	lcall	_ak820_outline_0108
      0074F9 90 08 73         [24]  819 	mov	dptr,#_process_record_record_argument_10000_656
      0074FC 12 38 8F         [24]  820 	lcall	_ak820_outline_0109
                                    821 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0074FF 90 08 73         [24]  822 	mov	dptr,#_process_record_record_argument_10000_656
      007502 12 38 36         [24]  823 	lcall	_ak820_outline_0054
                                    824 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      007505 74 04            [12]  825 	mov	a,#0x04
      007507 12 4C F8         [24]  826 	lcall	_ak820_outline_0018
      00750A 70 01            [24]  827 	jnz	00102$
                                    828 ;	quantum/action.c:354: return;
      00750C 22               [24]  829 	ret
      00750D                        830 00102$:
                                    831 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00750D 8E 04            [24]  832 	mov	ar4,r6
      00750F 8F 05            [24]  833 	mov	ar5,r7
      007511 90 0D E2         [24]  834 	mov	dptr,#___memcpy_PARM_2
      007514 EC               [12]  835 	mov	a,r4
      007515 F0               [24]  836 	movx	@dptr,a
      007516 ED               [12]  837 	mov	a,r5
      007517 12 7A EF         [24]  838 	lcall	_ak820_outline_0053
      00751A 12 53 C8         [24]  839 	lcall	_ak820_outline_0116
      00751D 90 06 70         [24]  840 	mov	dptr,#_ak820_tapping_source_PARM_1
      007520 F5 F0            [12]  841 	mov	b,a
      007522 C0 07            [24]  842 	push	ar7
      007524 C0 06            [24]  843 	push	ar6
      007526 12 BC AA         [24]  844 	lcall	___memcpy
      007529 12 48 41         [24]  845 	lcall	_ak820_tapping_source
      00752C AD 82            [24]  846 	mov	r5, dpl
      00752E D0 06            [24]  847 	pop	ar6
      007530 D0 07            [24]  848 	pop	ar7
                                    849 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007532 12 42 FF         [24]  850 	lcall	_ak820_outline_0009
      007535 E0               [24]  851 	movx	a,@dptr
      007536 FC               [12]  852 	mov	r4,a
                                    853 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      007537 74 07            [12]  854 	mov	a,#0x07
      007539 2E               [12]  855 	add	a, r6
      00753A FA               [12]  856 	mov	r2,a
      00753B E4               [12]  857 	clr	a
      00753C 3F               [12]  858 	addc	a, r7
      00753D FB               [12]  859 	mov	r3,a
      00753E 90 0C 3E         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      007541 74 01            [12]  861 	mov	a,#0x01
      007543 12 43 35         [24]  862 	lcall	_ak820_outline_0062
      007546 C0 07            [24]  863 	push	ar7
      007548 C0 06            [24]  864 	push	ar6
      00754A C0 05            [24]  865 	push	ar5
      00754C C0 04            [24]  866 	push	ar4
      00754E C0 03            [24]  867 	push	ar3
      007550 C0 02            [24]  868 	push	ar2
      007552 12 A2 7B         [24]  869 	lcall	_get_record_keycode
      007555 A8 82            [24]  870 	mov	r0, dpl
      007557 A9 83            [24]  871 	mov	r1, dph
      007559 D0 02            [24]  872 	pop	ar2
      00755B D0 03            [24]  873 	pop	ar3
      00755D D0 04            [24]  874 	pop	ar4
      00755F D0 05            [24]  875 	pop	ar5
      007561 D0 06            [24]  876 	pop	ar6
      007563 D0 07            [24]  877 	pop	ar7
      007565 12 38 A8         [24]  878 	lcall	_ak820_outline_0148
      007568 12 53 CF         [24]  879 	lcall	_ak820_outline_0165
                                    880 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00756B 74 07            [12]  881 	mov	a,#0x07
      00756D 12 38 26         [24]  882 	lcall	_ak820_outline_0020
      007570 12 43 42         [24]  883 	lcall	_ak820_outline_0086
      007573 90 06 80         [24]  884 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007576 ED               [12]  885 	mov	a,r5
      007577 F0               [24]  886 	movx	@dptr,a
      007578 90 06 81         [24]  887 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00757B EC               [12]  888 	mov	a,r4
      00757C F0               [24]  889 	movx	@dptr,a
      00757D 12 38 A8         [24]  890 	lcall	_ak820_outline_0148
      007580 C0 07            [24]  891 	push	ar7
      007582 C0 06            [24]  892 	push	ar6
      007584 C0 05            [24]  893 	push	ar5
      007586 C0 04            [24]  894 	push	ar4
      007588 12 4B AB         [24]  895 	lcall	_ak820_oneshot_process
      00758B E5 82            [12]  896 	mov	a, dpl
      00758D D0 04            [24]  897 	pop	ar4
      00758F D0 05            [24]  898 	pop	ar5
      007591 D0 06            [24]  899 	pop	ar6
      007593 D0 07            [24]  900 	pop	ar7
      007595 70 01            [24]  901 	jnz	00104$
      007597 22               [24]  902 	ret
      007598                        903 00104$:
                                    904 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      007598 12 38 94         [24]  905 	lcall	_ak820_outline_0123
      00759B C0 07            [24]  906 	push	ar7
      00759D C0 06            [24]  907 	push	ar6
      00759F C0 05            [24]  908 	push	ar5
      0075A1 C0 04            [24]  909 	push	ar4
      0075A3 12 A3 39         [24]  910 	lcall	_process_record_quantum
      0075A6 E5 82            [12]  911 	mov	a, dpl
      0075A8 D0 04            [24]  912 	pop	ar4
      0075AA D0 05            [24]  913 	pop	ar5
      0075AC D0 06            [24]  914 	pop	ar6
      0075AE D0 07            [24]  915 	pop	ar7
      0075B0 70 0A            [24]  916 	jnz	00106$
                                    917 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0075B2 90 05 9C         [24]  918 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0075B5 EC               [12]  919 	mov	a,r4
      0075B6 F0               [24]  920 	movx	@dptr,a
      0075B7 8D 82            [24]  921 	mov	dpl, r5
                                    922 ;	quantum/action.c:376: return;
      0075B9 02 2E BB         [24]  923 	ljmp	_ak820_oneshot_post
      0075BC                        924 00106$:
                                    925 ;	quantum/action.c:382: process_record_handler(record);
      0075BC 12 38 94         [24]  926 	lcall	_ak820_outline_0123
      0075BF C0 07            [24]  927 	push	ar7
      0075C1 C0 06            [24]  928 	push	ar6
      0075C3 C0 05            [24]  929 	push	ar5
      0075C5 C0 04            [24]  930 	push	ar4
      0075C7 B1 E9            [24]  931 	acall	_process_record_handler
      0075C9 D0 04            [24]  932 	pop	ar4
      0075CB D0 05            [24]  933 	pop	ar5
      0075CD D0 06            [24]  934 	pop	ar6
      0075CF D0 07            [24]  935 	pop	ar7
                                    936 ;	quantum/action.c:386: post_process_record_quantum(record);
      0075D1 12 38 94         [24]  937 	lcall	_ak820_outline_0123
      0075D4 C0 05            [24]  938 	push	ar5
      0075D6 C0 04            [24]  939 	push	ar4
      0075D8 12 A3 0E         [24]  940 	lcall	_post_process_record_quantum
      0075DB D0 04            [24]  941 	pop	ar4
      0075DD D0 05            [24]  942 	pop	ar5
                                    943 ;	quantum/action.c:388: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0075DF 90 05 9C         [24]  944 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0075E2 EC               [12]  945 	mov	a,r4
      0075E3 F0               [24]  946 	movx	@dptr,a
      0075E4 8D 82            [24]  947 	mov	dpl, r5
                                    948 ;	quantum/action.c:390: }
      0075E6 02 2E BB         [24]  949 	ljmp	_ak820_oneshot_post
                                    950 ;------------------------------------------------------------
                                    951 ;Allocation info for local variables in function 'process_record_handler'
                                    952 ;------------------------------------------------------------
                                    953 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_664'
                                    954 ;record        Allocated with name '_process_record_handler_record_10000_665'
                                    955 ;action        Allocated with name '_process_record_handler_action_10000_665'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/action.c:392: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function process_record_handler
                                    960 ;	-----------------------------------------
      0075E9                        961 _process_record_handler:
      0075E9 12 38 8A         [24]  962 	lcall	_ak820_outline_0108
      0075EC 90 08 75         [24]  963 	mov	dptr,#_process_record_handler_record_argument_10000_664
      0075EF 12 38 8F         [24]  964 	lcall	_ak820_outline_0109
                                    965 ;	quantum/action.c:396: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0075F2 90 08 75         [24]  966 	mov	dptr,#_process_record_handler_record_argument_10000_664
      0075F5 12 37 F3         [24]  967 	lcall	_ak820_outline_0008
                                    968 ;	quantum/action.c:403: if (record->keycode) {
      0075F8 4C               [12]  969 	orl	a,r4
      0075F9 60 19            [24]  970 	jz	00102$
                                    971 ;	quantum/action.c:404: action.code = action_for_keycode(record->keycode);
      0075FB 12 38 99         [24]  972 	lcall	_ak820_outline_0127
      0075FE C0 07            [24]  973 	push	ar7
      007600 C0 06            [24]  974 	push	ar6
      007602 12 98 39         [24]  975 	lcall	_action_for_keycode
      007605 12 38 AD         [24]  976 	lcall	_ak820_outline_0149
      007608 D0 06            [24]  977 	pop	ar6
      00760A D0 07            [24]  978 	pop	ar7
      00760C 90 08 77         [24]  979 	mov	dptr,#_process_record_handler_action_10000_665
      00760F 12 38 53         [24]  980 	lcall	_ak820_outline_0073
      007612 80 2A            [24]  981 	sjmp	00104$
      007614                        982 00102$:
                                    983 ;	quantum/action.c:407: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007614 12 7A D7         [24]  984 	lcall	_ak820_outline_0023
      007617 7A 00            [12]  985 	mov	r2,#0x00
      007619 12 43 72         [24]  986 	lcall	_ak820_outline_0147
      00761C 12 42 FF         [24]  987 	lcall	_ak820_outline_0009
      00761F E0               [24]  988 	movx	a,@dptr
      007620 90 09 B2         [24]  989 	mov	dptr,#_ak820_resolve_key_PARM_2
      007623 F0               [24]  990 	movx	@dptr,a
      007624 12 43 88         [24]  991 	lcall	_ak820_outline_0187
      007627 C0 07            [24]  992 	push	ar7
      007629 C0 06            [24]  993 	push	ar6
      00762B 12 7E 5B         [24]  994 	lcall	_ak820_resolve_key
      00762E 12 98 39         [24]  995 	lcall	_action_for_keycode
      007631 12 38 AD         [24]  996 	lcall	_ak820_outline_0149
      007634 D0 06            [24]  997 	pop	ar6
      007636 D0 07            [24]  998 	pop	ar7
      007638 90 08 77         [24]  999 	mov	dptr,#_process_record_handler_action_10000_665
      00763B 12 38 53         [24] 1000 	lcall	_ak820_outline_0073
                                   1001 ;	quantum/action.c:416: ac_dprintf("ACTION: ");
      00763E                       1002 00104$:
                                   1003 ;	quantum/action.c:427: process_action(record, action);
      00763E 90 0D E2         [24] 1004 	mov	dptr,#___memcpy_PARM_2
      007641 74 77            [12] 1005 	mov	a,#_process_record_handler_action_10000_665
      007643 F0               [24] 1006 	movx	@dptr,a
      007644 74 08            [12] 1007 	mov	a,#(_process_record_handler_action_10000_665 >> 8)
      007646 12 7A EF         [24] 1008 	lcall	_ak820_outline_0053
      007649 12 53 C8         [24] 1009 	lcall	_ak820_outline_0116
      00764C 90 08 79         [24] 1010 	mov	dptr,#_process_action_PARM_2
      00764F F5 F0            [12] 1011 	mov	b,a
      007651 C0 07            [24] 1012 	push	ar7
      007653 C0 06            [24] 1013 	push	ar6
      007655 12 BC AA         [24] 1014 	lcall	___memcpy
      007658 D0 06            [24] 1015 	pop	ar6
      00765A D0 07            [24] 1016 	pop	ar7
      00765C 12 38 94         [24] 1017 	lcall	_ak820_outline_0123
                                   1018 ;	quantum/action.c:428: }
      00765F C1 61            [24] 1019 	ajmp	_process_action
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'register_mouse'
                                   1022 ;------------------------------------------------------------
                                   1023 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1024 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_673'
                                   1025 ;------------------------------------------------------------
                                   1026 ;	quantum/action.c:440: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1027 ;	-----------------------------------------
                                   1028 ;	 function process_action
                                   1029 ;	-----------------------------------------
      007661                       1030 _process_action:
      007661 12 38 8A         [24] 1031 	lcall	_ak820_outline_0108
      007664 90 08 7B         [24] 1032 	mov	dptr,#_process_action_record_argument_10000_676
      007667 12 38 8F         [24] 1033 	lcall	_ak820_outline_0109
                                   1034 ;	quantum/action.c:493: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00766A 90 08 7B         [24] 1035 	mov	dptr,#_process_action_record_argument_10000_676
      00766D 12 37 E9         [24] 1036 	lcall	_ak820_outline_0005
                                   1037 ;	quantum/action.c:499: pressed = record->event.pressed;
      007670 A3               [24] 1038 	inc	dptr
      007671 A3               [24] 1039 	inc	dptr
      007672 A3               [24] 1040 	inc	dptr
      007673 A3               [24] 1041 	inc	dptr
      007674 A3               [24] 1042 	inc	dptr
      007675 E0               [24] 1043 	movx	a,@dptr
      007676 F5 27            [12] 1044 	mov	_process_action_sloc0_1_0,a
                                   1045 ;	quantum/action.c:523: switch (action.kind.id) {
      007678 90 08 7A         [24] 1046 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00767B E0               [24] 1047 	movx	a,@dptr
      00767C C4               [12] 1048 	swap	a
      00767D 54 0F            [12] 1049 	anl	a,#0x0f
      00767F FD               [12] 1050 	mov  r5,a
      007680 24 F4            [12] 1051 	add	a,#0xff - 0x0b
      007682 50 03            [24] 1052 	jnc	00434$
      007684 02 79 02         [24] 1053 	ljmp	00181$
      007687                       1054 00434$:
                                   1055 ;	free result
      007687 ED               [12] 1056 	mov	a,r5
      007688 24 0A            [12] 1057 	add	a,#(00435$-3-.)
      00768A 83               [24] 1058 	movc	a,@a+pc
      00768B F5 82            [12] 1059 	mov	dpl,a
      00768D ED               [12] 1060 	mov	a,r5
      00768E 24 10            [12] 1061 	add	a,#(00436$-3-.)
      007690 83               [24] 1062 	movc	a,@a+pc
      007691 F5 83            [12] 1063 	mov	dph,a
      007693 E4               [12] 1064 	clr	a
      007694 73               [24] 1065 	jmp	@a+dptr
      007695                       1066 00435$:
      007695 AD                    1067 	.db	00102$
      007696 AD                    1068 	.db	00102$
      007697 02                    1069 	.db	00181$
      007698 02                    1070 	.db	00181$
      007699 37                    1071 	.db	00123$
      00769A 02                    1072 	.db	00181$
      00769B 02                    1073 	.db	00181$
      00769C 02                    1074 	.db	00181$
      00769D 97                    1075 	.db	00131$
      00769E 69                    1076 	.db	00147$
      00769F 8F                    1077 	.db	00152$
      0076A0 8F                    1078 	.db	00152$
      0076A1                       1079 00436$:
      0076A1 76                    1080 	.db	00102$>>8
      0076A2 76                    1081 	.db	00102$>>8
      0076A3 79                    1082 	.db	00181$>>8
      0076A4 79                    1083 	.db	00181$>>8
      0076A5 77                    1084 	.db	00123$>>8
      0076A6 79                    1085 	.db	00181$>>8
      0076A7 79                    1086 	.db	00181$>>8
      0076A8 79                    1087 	.db	00181$>>8
      0076A9 77                    1088 	.db	00131$>>8
      0076AA 78                    1089 	.db	00147$>>8
      0076AB 78                    1090 	.db	00152$>>8
      0076AC 78                    1091 	.db	00152$>>8
                                   1092 ;	quantum/action.c:526: case ACT_RMODS: {
      0076AD                       1093 00102$:
                                   1094 ;	quantum/action.c:527: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0076AD 90 08 7A         [24] 1095 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076B0 E0               [24] 1096 	movx	a,@dptr
      0076B1 54 F0            [12] 1097 	anl	a,#0xf0
      0076B3 70 06            [24] 1098 	jnz	00194$
      0076B5 12 7B 16         [24] 1099 	lcall	_ak820_outline_0118
      0076B8 FD               [12] 1100 	mov	r5,a
      0076B9 80 07            [24] 1101 	sjmp	00195$
      0076BB                       1102 00194$:
      0076BB 12 7B 16         [24] 1103 	lcall	_ak820_outline_0118
      0076BE C4               [12] 1104 	swap	a
      0076BF 54 F0            [12] 1105 	anl	a,#0xf0
      0076C1 FD               [12] 1106 	mov	r5,a
      0076C2                       1107 00195$:
                                   1108 ;	quantum/action.c:529: if (pressed) {
      0076C2 E5 27            [12] 1109 	mov	a,_process_action_sloc0_1_0
      0076C4 60 35            [24] 1110 	jz	00119$
                                   1111 ;	quantum/action.c:530: if (mods) {
      0076C6 ED               [12] 1112 	mov	a,r5
      0076C7 60 29            [24] 1113 	jz	00110$
                                   1114 ;	quantum/action.c:531: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0076C9 12 7B 28         [24] 1115 	lcall	_ak820_outline_0162
      0076CC FC               [12] 1116 	mov	r4,a
      0076CD BC E0 00         [24] 1117 	cjne	r4,#0xe0,00440$
      0076D0                       1118 00440$:
      0076D0 40 07            [24] 1119 	jc	00108$
      0076D2 12 7B 28         [24] 1120 	lcall	_ak820_outline_0162
      0076D5 24 18            [12] 1121 	add	a,#0xff - 0xe7
      0076D7 50 0A            [24] 1122 	jnc	00104$
                                   1123 ;	free result
      0076D9                       1124 00108$:
      0076D9 7B 79            [12] 1125 	mov	r3,#_process_action_PARM_2
      0076DB 7C 08            [12] 1126 	mov	r4,#(_process_action_PARM_2 >> 8)
      0076DD 12 33 FC         [24] 1127 	lcall	_ak820_outline_0126
      0076E0 E0               [24] 1128 	movx	a,@dptr
      0076E1 70 07            [24] 1129 	jnz	00105$
      0076E3                       1130 00104$:
                                   1131 ;	quantum/action.c:535: add_owned_mods(mods);
      0076E3 8D 82            [24] 1132 	mov	dpl, r5
      0076E5 12 80 71         [24] 1133 	lcall	_add_owned_mods
      0076E8 80 05            [24] 1134 	sjmp	00106$
      0076EA                       1135 00105$:
                                   1136 ;	quantum/action.c:537: add_owned_weak_mods(mods);
      0076EA 8D 82            [24] 1137 	mov	dpl, r5
      0076EC 12 80 90         [24] 1138 	lcall	_add_owned_weak_mods
      0076EF                       1139 00106$:
                                   1140 ;	quantum/action.c:539: send_keyboard_report();
      0076EF 12 83 AA         [24] 1141 	lcall	_send_keyboard_report
      0076F2                       1142 00110$:
                                   1143 ;	quantum/action.c:541: register_code(action.key.code);
      0076F2 12 7A FF         [24] 1144 	lcall	_ak820_outline_0078
      0076F5 12 79 19         [24] 1145 	lcall	_register_code
      0076F8 02 79 02         [24] 1146 	ljmp	00181$
      0076FB                       1147 00119$:
                                   1148 ;	quantum/action.c:543: unregister_code(action.key.code);
      0076FB 12 7A FF         [24] 1149 	lcall	_ak820_outline_0078
      0076FE C0 05            [24] 1150 	push	ar5
      007700 12 79 86         [24] 1151 	lcall	_unregister_code
      007703 D0 05            [24] 1152 	pop	ar5
                                   1153 ;	quantum/action.c:544: if (mods) {
      007705 ED               [12] 1154 	mov	a,r5
      007706 70 03            [24] 1155 	jnz	00444$
      007708 02 79 02         [24] 1156 	ljmp	00181$
      00770B                       1157 00444$:
                                   1158 ;	quantum/action.c:545: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00770B 12 7B 28         [24] 1159 	lcall	_ak820_outline_0162
      00770E FC               [12] 1160 	mov	r4,a
      00770F BC E0 00         [24] 1161 	cjne	r4,#0xe0,00445$
      007712                       1162 00445$:
      007712 40 07            [24] 1163 	jc	00115$
      007714 12 7B 28         [24] 1164 	lcall	_ak820_outline_0162
      007717 24 18            [12] 1165 	add	a,#0xff - 0xe7
      007719 50 0A            [24] 1166 	jnc	00111$
                                   1167 ;	free result
      00771B                       1168 00115$:
      00771B 7B 79            [12] 1169 	mov	r3,#_process_action_PARM_2
      00771D 7C 08            [12] 1170 	mov	r4,#(_process_action_PARM_2 >> 8)
      00771F 12 33 FC         [24] 1171 	lcall	_ak820_outline_0126
      007722 E0               [24] 1172 	movx	a,@dptr
      007723 70 07            [24] 1173 	jnz	00112$
      007725                       1174 00111$:
                                   1175 ;	quantum/action.c:546: del_owned_mods(mods);
      007725 8D 82            [24] 1176 	mov	dpl, r5
      007727 12 80 81         [24] 1177 	lcall	_del_owned_mods
      00772A 80 05            [24] 1178 	sjmp	00113$
      00772C                       1179 00112$:
                                   1180 ;	quantum/action.c:548: del_owned_weak_mods(mods);
      00772C 8D 82            [24] 1181 	mov	dpl, r5
      00772E 12 80 A0         [24] 1182 	lcall	_del_owned_weak_mods
      007731                       1183 00113$:
                                   1184 ;	quantum/action.c:550: send_keyboard_report();
      007731 12 83 AA         [24] 1185 	lcall	_send_keyboard_report
                                   1186 ;	quantum/action.c:553: } break;
      007734 02 79 02         [24] 1187 	ljmp	00181$
                                   1188 ;	quantum/action.c:630: case ACT_USAGE:
      007737                       1189 00123$:
                                   1190 ;	quantum/action.c:636: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007737 74 07            [12] 1191 	mov	a,#0x07
      007739 12 38 26         [24] 1192 	lcall	_ak820_outline_0020
      00773C 12 4C E3         [24] 1193 	lcall	_ak820_outline_0010
      00773F C3               [12] 1194 	clr	c
      007740 EC               [12] 1195 	mov	a,r4
      007741 94 A5            [12] 1196 	subb	a,#0xa5
      007743 ED               [12] 1197 	mov	a,r5
      007744 94 00            [12] 1198 	subb	a,#0x00
      007746 40 15            [24] 1199 	jc	00125$
      007748 74 C2            [12] 1200 	mov	a,#0xc2
      00774A 9C               [12] 1201 	subb	a,r4
      00774B E4               [12] 1202 	clr	a
      00774C 9D               [12] 1203 	subb	a,r5
      00774D 40 0E            [24] 1204 	jc	00125$
                                   1205 ;	free result
                                   1206 ;	quantum/action.c:637: owned_usage_key((uint8_t)record->keycode, pressed);
      00774F 90 0A D9         [24] 1207 	mov	dptr,#_owned_usage_key_PARM_2
      007752 E5 27            [12] 1208 	mov	a,_process_action_sloc0_1_0
      007754 F0               [24] 1209 	movx	@dptr,a
      007755 8E 82            [24] 1210 	mov	dpl, r6
      007757 12 82 56         [24] 1211 	lcall	_owned_usage_key
                                   1212 ;	quantum/action.c:638: break;
      00775A 02 79 02         [24] 1213 	ljmp	00181$
      00775D                       1214 00125$:
                                   1215 ;	quantum/action.c:641: switch (action.usage.page) {
      00775D 12 7B 06         [24] 1216 	lcall	_ak820_outline_0089
      007760 FF               [12] 1217 	mov	r7,a
      007761 60 08            [24] 1218 	jz	00127$
      007763 BF 01 02         [24] 1219 	cjne	r7,#0x01,00452$
      007766 80 19            [24] 1220 	sjmp	00128$
      007768                       1221 00452$:
      007768 02 79 02         [24] 1222 	ljmp	00181$
                                   1223 ;	quantum/action.c:642: case PAGE_SYSTEM:
      00776B                       1224 00127$:
                                   1225 ;	quantum/action.c:643: host_system_send(pressed ? action.usage.code : 0);
      00776B E5 27            [12] 1226 	mov	a,_process_action_sloc0_1_0
      00776D 60 05            [24] 1227 	jz	00196$
      00776F 12 7B 1D         [24] 1228 	lcall	_ak820_outline_0134
      007772 80 04            [24] 1229 	sjmp	00197$
      007774                       1230 00196$:
      007774 7E 00            [12] 1231 	mov	r6,#0x00
      007776 7F 00            [12] 1232 	mov	r7,#0x00
      007778                       1233 00197$:
      007778 12 38 94         [24] 1234 	lcall	_ak820_outline_0123
      00777B 12 71 57         [24] 1235 	lcall	_host_system_send
                                   1236 ;	quantum/action.c:644: break;
      00777E 02 79 02         [24] 1237 	ljmp	00181$
                                   1238 ;	quantum/action.c:645: case PAGE_CONSUMER:
      007781                       1239 00128$:
                                   1240 ;	quantum/action.c:646: host_consumer_send(pressed ? action.usage.code : 0);
      007781 E5 27            [12] 1241 	mov	a,_process_action_sloc0_1_0
      007783 60 05            [24] 1242 	jz	00198$
      007785 12 7B 1D         [24] 1243 	lcall	_ak820_outline_0134
      007788 80 04            [24] 1244 	sjmp	00199$
      00778A                       1245 00198$:
      00778A 7E 00            [12] 1246 	mov	r6,#0x00
      00778C 7F 00            [12] 1247 	mov	r7,#0x00
      00778E                       1248 00199$:
      00778E 12 38 94         [24] 1249 	lcall	_ak820_outline_0123
      007791 12 71 86         [24] 1250 	lcall	_host_consumer_send
                                   1251 ;	quantum/action.c:649: break;
      007794 02 79 02         [24] 1252 	ljmp	00181$
                                   1253 ;	quantum/action.c:656: case ACT_LAYER: {
      007797                       1254 00131$:
                                   1255 ;	quantum/action.c:657: uint8_t on = action.layer_bitop.on;
      007797 90 08 7A         [24] 1256 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00779A E0               [24] 1257 	movx	a,@dptr
      00779B 54 03            [12] 1258 	anl	a,#0x03
      00779D 90 08 7D         [24] 1259 	mov	dptr,#_process_action_on_40000_699
      0077A0 F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/action.c:660: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0077A1 E0               [24] 1262 	movx	a,@dptr
      0077A2 FF               [12] 1263 	mov	r7,a
      0077A3 60 11            [24] 1264 	jz	00200$
      0077A5 E5 27            [12] 1265 	mov	a,_process_action_sloc0_1_0
      0077A7 60 07            [24] 1266 	jz	00202$
      0077A9 8F 06            [24] 1267 	mov	ar6,r7
      0077AB 53 06 01         [24] 1268 	anl	ar6,#0x01
      0077AE 80 10            [24] 1269 	sjmp	00201$
      0077B0                       1270 00202$:
      0077B0 74 02            [12] 1271 	mov	a,#0x02
      0077B2 5F               [12] 1272 	anl	a,r7
      0077B3 FE               [12] 1273 	mov	r6,a
      0077B4 80 0A            [24] 1274 	sjmp	00201$
      0077B6                       1275 00200$:
      0077B6 E5 27            [12] 1276 	mov	a,_process_action_sloc0_1_0
      0077B8 B4 01 00         [24] 1277 	cjne	a,#0x01,00457$
      0077BB                       1278 00457$:
      0077BB 92 20            [24] 1279 	mov  _process_action_sloc1_1_0,c
      0077BD E4               [12] 1280 	clr	a
      0077BE 33               [12] 1281 	rlc	a
      0077BF FE               [12] 1282 	mov	r6,a
      0077C0                       1283 00201$:
      0077C0 EE               [12] 1284 	mov	a,r6
      0077C1 70 03            [24] 1285 	jnz	00458$
      0077C3 02 79 02         [24] 1286 	ljmp	00181$
      0077C6                       1287 00458$:
                                   1288 ;	quantum/action.c:661: uint8_t shift = action.layer_bitop.part * 4;
      0077C6 12 7B 28         [24] 1289 	lcall	_ak820_outline_0162
      0077C9 C4               [12] 1290 	swap	a
      0077CA 03               [12] 1291 	rr	a
      0077CB 54 07            [12] 1292 	anl	a,#0x07
      0077CD 25 E0            [12] 1293 	add	a,acc
      0077CF 25 E0            [12] 1294 	add	a,acc
      0077D1 FF               [12] 1295 	mov	r7,a
                                   1296 ;	quantum/action.c:662: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0077D2 12 7B 28         [24] 1297 	lcall	_ak820_outline_0162
      0077D5 54 0F            [12] 1298 	anl	a,#0x0f
      0077D7 FE               [12] 1299 	mov	r6,a
      0077D8 8F F0            [24] 1300 	mov	b,r7
      0077DA 05 F0            [12] 1301 	inc	b
      0077DC EE               [12] 1302 	mov	a,r6
      0077DD 80 02            [24] 1303 	sjmp	00460$
      0077DF                       1304 00459$:
      0077DF 25 E0            [12] 1305 	add	a,acc
      0077E1                       1306 00460$:
      0077E1 D5 F0 FB         [24] 1307 	djnz	b,00459$
      0077E4 FE               [12] 1308 	mov	r6,a
                                   1309 ;	quantum/action.c:663: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0077E5 12 7B 28         [24] 1310 	lcall	_ak820_outline_0162
      0077E8 30 E4 11         [24] 1311 	jnb	acc.4,00204$
      0077EB 8F F0            [24] 1312 	mov	b,r7
      0077ED 05 F0            [12] 1313 	inc	b
      0077EF 74 0F            [12] 1314 	mov	a,#0x0f
      0077F1 80 02            [24] 1315 	sjmp	00463$
      0077F3                       1316 00462$:
      0077F3 25 E0            [12] 1317 	add	a,acc
      0077F5                       1318 00463$:
      0077F5 D5 F0 FB         [24] 1319 	djnz	b,00462$
      0077F8 F4               [12] 1320 	cpl	a
      0077F9 FF               [12] 1321 	mov	r7,a
      0077FA 80 02            [24] 1322 	sjmp	00205$
      0077FC                       1323 00204$:
      0077FC 7F 00            [12] 1324 	mov	r7,#0x00
      0077FE                       1325 00205$:
                                   1326 ;	quantum/action.c:664: bits |= mask;
      0077FE EE               [12] 1327 	mov	a,r6
      0077FF 42 07            [12] 1328 	orl	ar7,a
                                   1329 ;	quantum/action.c:665: if (!on) {
      007801 90 08 7D         [24] 1330 	mov	dptr,#_process_action_on_40000_699
      007804 E0               [24] 1331 	movx	a,@dptr
      007805 70 31            [24] 1332 	jnz	00143$
                                   1333 ;	quantum/action.c:666: switch (action.layer_bitop.op) {
      007807 12 7B 06         [24] 1334 	lcall	_ak820_outline_0089
      00780A FE               [12] 1335 	mov	r6,a
      00780B 2E               [12] 1336 	add	a,r6
                                   1337 ;	quantum/action.c:667: case OP_BIT_AND: default_layer_and(bits); break;
      00780C 90 78 10         [24] 1338 	mov	dptr,#00465$
      00780F 73               [24] 1339 	jmp	@a+dptr
      007810                       1340 00465$:
      007810 80 06            [24] 1341 	sjmp	00132$
      007812 80 0C            [24] 1342 	sjmp	00133$
      007814 80 12            [24] 1343 	sjmp	00134$
      007816 80 18            [24] 1344 	sjmp	00135$
      007818                       1345 00132$:
      007818 8F 82            [24] 1346 	mov	dpl, r7
      00781A 12 7B 7E         [24] 1347 	lcall	_default_layer_and
      00781D 02 79 02         [24] 1348 	ljmp	00181$
                                   1349 ;	quantum/action.c:668: case OP_BIT_OR: default_layer_or(bits); break;
      007820                       1350 00133$:
      007820 8F 82            [24] 1351 	mov	dpl, r7
      007822 12 7B 6E         [24] 1352 	lcall	_default_layer_or
      007825 02 79 02         [24] 1353 	ljmp	00181$
                                   1354 ;	quantum/action.c:669: case OP_BIT_XOR: default_layer_xor(bits); break;
      007828                       1355 00134$:
      007828 8F 82            [24] 1356 	mov	dpl, r7
      00782A 12 7B 93         [24] 1357 	lcall	_default_layer_xor
      00782D 02 79 02         [24] 1358 	ljmp	00181$
                                   1359 ;	quantum/action.c:670: case OP_BIT_SET: default_layer_set(bits); break;
      007830                       1360 00135$:
      007830 8F 82            [24] 1361 	mov	dpl, r7
      007832 12 7B 64         [24] 1362 	lcall	_default_layer_set
                                   1363 ;	quantum/action.c:671: }
      007835 02 79 02         [24] 1364 	ljmp	00181$
      007838                       1365 00143$:
                                   1366 ;	quantum/action.c:673: switch (action.layer_bitop.op) {
      007838 12 7B 06         [24] 1367 	lcall	_ak820_outline_0089
      00783B FE               [12] 1368 	mov	r6,a
      00783C 2E               [12] 1369 	add	a,r6
                                   1370 ;	quantum/action.c:674: case OP_BIT_AND: layer_and(bits); break;
      00783D 90 78 41         [24] 1371 	mov	dptr,#00466$
      007840 73               [24] 1372 	jmp	@a+dptr
      007841                       1373 00466$:
      007841 80 06            [24] 1374 	sjmp	00137$
      007843 80 0C            [24] 1375 	sjmp	00138$
      007845 80 12            [24] 1376 	sjmp	00139$
      007847 80 18            [24] 1377 	sjmp	00140$
      007849                       1378 00137$:
      007849 8F 82            [24] 1379 	mov	dpl, r7
      00784B 12 7D 08         [24] 1380 	lcall	_layer_and
      00784E 02 79 02         [24] 1381 	ljmp	00181$
                                   1382 ;	quantum/action.c:675: case OP_BIT_OR: layer_or(bits); break;
      007851                       1383 00138$:
      007851 8F 82            [24] 1384 	mov	dpl, r7
      007853 12 7C F8         [24] 1385 	lcall	_layer_or
      007856 02 79 02         [24] 1386 	ljmp	00181$
                                   1387 ;	quantum/action.c:676: case OP_BIT_XOR: layer_xor(bits); break;
      007859                       1388 00139$:
      007859 8F 82            [24] 1389 	mov	dpl, r7
      00785B 12 7D 1D         [24] 1390 	lcall	_layer_xor
      00785E 02 79 02         [24] 1391 	ljmp	00181$
                                   1392 ;	quantum/action.c:677: case OP_BIT_SET: layer_state_set(bits); break;
      007861                       1393 00140$:
      007861 8F 82            [24] 1394 	mov	dpl, r7
      007863 12 7C 9A         [24] 1395 	lcall	_layer_state_set
                                   1396 ;	quantum/action.c:681: break;
      007866 02 79 02         [24] 1397 	ljmp	00181$
                                   1398 ;	quantum/action.c:683: case ACT_LAYER_MODS:
      007869                       1399 00147$:
                                   1400 ;	quantum/action.c:684: if (pressed) {
      007869 E5 27            [12] 1401 	mov	a,_process_action_sloc0_1_0
      00786B 60 11            [24] 1402 	jz	00149$
                                   1403 ;	quantum/action.c:685: layer_hold_on(action.layer_mods.layer);
      00786D 12 7B 16         [24] 1404 	lcall	_ak820_outline_0118
      007870 F5 82            [12] 1405 	mov	dpl,a
      007872 12 7C 01         [24] 1406 	lcall	_layer_hold_on
                                   1407 ;	quantum/action.c:686: register_mods(action.layer_mods.mods);
      007875 12 7A FF         [24] 1408 	lcall	_ak820_outline_0078
      007878 12 7A 48         [24] 1409 	lcall	_register_mods
      00787B 02 79 02         [24] 1410 	ljmp	00181$
      00787E                       1411 00149$:
                                   1412 ;	quantum/action.c:688: unregister_mods(action.layer_mods.mods);
      00787E 12 7A FF         [24] 1413 	lcall	_ak820_outline_0078
      007881 12 7A 5C         [24] 1414 	lcall	_unregister_mods
                                   1415 ;	quantum/action.c:689: layer_hold_off(action.layer_mods.layer);
      007884 12 7B 16         [24] 1416 	lcall	_ak820_outline_0118
      007887 F5 82            [12] 1417 	mov	dpl,a
      007889 12 7C 37         [24] 1418 	lcall	_layer_hold_off
                                   1419 ;	quantum/action.c:691: break;
      00788C 02 79 02         [24] 1420 	ljmp	00181$
                                   1421 ;	quantum/action.c:693: case ACT_LAYER_TAP_EXT:
      00788F                       1422 00152$:
                                   1423 ;	quantum/action.c:694: switch (action.layer_tap.code) {
      00788F 12 7B 28         [24] 1424 	lcall	_ak820_outline_0162
      007892 FF               [12] 1425 	mov	r7,a
      007893 BF F1 02         [24] 1426 	cjne	r7,#0xf1,00468$
      007896 80 0A            [24] 1427 	sjmp	00154$
      007898                       1428 00468$:
      007898 BF F2 02         [24] 1429 	cjne	r7,#0xf2,00469$
      00789B 80 19            [24] 1430 	sjmp	00155$
      00789D                       1431 00469$:
                                   1432 ;	quantum/action.c:710: momentary_layer_action:
      00789D BF F3 3B         [24] 1433 	cjne	r7,#0xf3,00160$
      0078A0 80 28            [24] 1434 	sjmp	00156$
      0078A2                       1435 00154$:
                                   1436 ;	quantum/action.c:711: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0078A2 E5 27            [12] 1437 	mov	a,_process_action_sloc0_1_0
      0078A4 60 08            [24] 1438 	jz	00206$
      0078A6 12 7A E6         [24] 1439 	lcall	_ak820_outline_0041
      0078A9 12 7C 01         [24] 1440 	lcall	_layer_hold_on
      0078AC 80 54            [24] 1441 	sjmp	00181$
      0078AE                       1442 00206$:
      0078AE 12 7A E6         [24] 1443 	lcall	_ak820_outline_0041
      0078B1 12 7C 37         [24] 1444 	lcall	_layer_hold_off
                                   1445 ;	quantum/action.c:712: break;
                                   1446 ;	quantum/action.c:713: case OP_OFF_ON:
      0078B4 80 4C            [24] 1447 	sjmp	00181$
      0078B6                       1448 00155$:
                                   1449 ;	quantum/action.c:714: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0078B6 E5 27            [12] 1450 	mov	a,_process_action_sloc0_1_0
      0078B8 60 08            [24] 1451 	jz	00208$
      0078BA 12 7A E6         [24] 1452 	lcall	_ak820_outline_0041
      0078BD 12 7C DB         [24] 1453 	lcall	_layer_off
      0078C0 80 40            [24] 1454 	sjmp	00181$
      0078C2                       1455 00208$:
      0078C2 12 7A E6         [24] 1456 	lcall	_ak820_outline_0041
      0078C5 12 7C C1         [24] 1457 	lcall	_layer_on
                                   1458 ;	quantum/action.c:715: break;
                                   1459 ;	quantum/action.c:716: case OP_SET_CLEAR:
      0078C8 80 38            [24] 1460 	sjmp	00181$
      0078CA                       1461 00156$:
                                   1462 ;	quantum/action.c:717: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0078CA E5 27            [12] 1463 	mov	a,_process_action_sloc0_1_0
      0078CC 60 08            [24] 1464 	jz	00210$
      0078CE 12 7A E6         [24] 1465 	lcall	_ak820_outline_0041
      0078D1 12 7C AC         [24] 1466 	lcall	_layer_move
      0078D4 80 2C            [24] 1467 	sjmp	00181$
      0078D6                       1468 00210$:
      0078D6 12 7C A7         [24] 1469 	lcall	_layer_clear
                                   1470 ;	quantum/action.c:718: break;
                                   1471 ;	quantum/action.c:764: default:
      0078D9 80 27            [24] 1472 	sjmp	00181$
      0078DB                       1473 00160$:
                                   1474 ;	quantum/action.c:771: if (pressed) {
      0078DB E5 27            [12] 1475 	mov	a,_process_action_sloc0_1_0
      0078DD 60 08            [24] 1476 	jz	00163$
                                   1477 ;	quantum/action.c:773: register_code(action.layer_tap.code);
      0078DF 12 7A FF         [24] 1478 	lcall	_ak820_outline_0078
      0078E2 12 79 19         [24] 1479 	lcall	_register_code
                                   1480 ;	quantum/action.c:775: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0078E5 80 1B            [24] 1481 	sjmp	00181$
      0078E7                       1482 00163$:
                                   1483 ;	quantum/action.c:776: if (action.layer_tap.code == KC_CAPS) {
      0078E7 12 7B 28         [24] 1484 	lcall	_ak820_outline_0162
      0078EA FF               [12] 1485 	mov	r7,a
      0078EB BF 39 0E         [24] 1486 	cjne	r7,#0x39,00175$
                                   1487 ;	quantum/action.c:777: wait_ms(TAP_HOLD_CAPS_DELAY);
      0078EE 7F 50            [12] 1488 	mov	r7,#0x50
      0078F0                       1489 00187$:
      0078F0 EF               [12] 1490 	mov	a,r7
      0078F1 60 09            [24] 1491 	jz	00175$
      0078F3 90 00 01         [24] 1492 	mov	dptr,#0x0001
      0078F6 12 5D 31         [24] 1493 	lcall	_mDelaymS
      0078F9 1F               [12] 1494 	dec	r7
                                   1495 ;	quantum/action.c:779: wait_ms(TAP_CODE_DELAY);
      0078FA 80 F4            [24] 1496 	sjmp	00187$
      0078FC                       1497 00175$:
                                   1498 ;	quantum/action.c:781: unregister_code(action.layer_tap.code);
      0078FC 12 7A FF         [24] 1499 	lcall	_ak820_outline_0078
      0078FF 12 79 86         [24] 1500 	lcall	_unregister_code
                                   1501 ;	quantum/action.c:864: }
      007902                       1502 00181$:
                                   1503 ;	quantum/action.c:885: switch (action.kind.id) {
      007902 90 08 7A         [24] 1504 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007905 E0               [24] 1505 	movx	a,@dptr
      007906 C4               [12] 1506 	swap	a
      007907 54 0F            [12] 1507 	anl	a,#0x0f
      007909 FF               [12] 1508 	mov	r7,a
      00790A BF 08 02         [24] 1509 	cjne	r7,#0x08,00478$
      00790D 80 03            [24] 1510 	sjmp	00183$
      00790F                       1511 00478$:
      00790F BF 09 06         [24] 1512 	cjne	r7,#0x09,00192$
                                   1513 ;	quantum/action.c:887: case ACT_LAYER_MODS:
      007912                       1514 00183$:
                                   1515 ;	quantum/action.c:892: led_set(host_keyboard_leds());
      007912 12 70 BC         [24] 1516 	lcall	_host_keyboard_leds
                                   1517 ;	quantum/action.c:896: }
                                   1518 ;	quantum/action.c:949: }
      007915 02 9A EC         [24] 1519 	ljmp	_led_set
      007918                       1520 00192$:
      007918 22               [24] 1521 	ret
                                   1522 ;------------------------------------------------------------
                                   1523 ;Allocation info for local variables in function 'register_code'
                                   1524 ;------------------------------------------------------------
                                   1525 ;code          Allocated with name '_register_code_code_10000_733'
                                   1526 ;------------------------------------------------------------
                                   1527 ;	quantum/action.c:955: __attribute__((weak)) void register_code(uint8_t code) {
                                   1528 ;	-----------------------------------------
                                   1529 ;	 function register_code
                                   1530 ;	-----------------------------------------
      007919                       1531 _register_code:
      007919 E5 82            [12] 1532 	mov	a,dpl
      00791B 90 08 7E         [24] 1533 	mov	dptr,#_register_code_code_10000_733
      00791E F0               [24] 1534 	movx	@dptr,a
                                   1535 ;	quantum/action.c:956: if (code == KC_NO) {
      00791F E0               [24] 1536 	movx	a,@dptr
      007920 FF               [12] 1537 	mov	r7,a
      007921 70 01            [24] 1538 	jnz	00123$
                                   1539 ;	quantum/action.c:957: return;
      007923 22               [24] 1540 	ret
      007924                       1541 00123$:
                                   1542 ;	quantum/action.c:992: } else if (IS_BASIC_KEYCODE(code)) {
      007924 BF 04 00         [24] 1543 	cjne	r7,#0x04,00186$
      007927                       1544 00186$:
      007927 40 12            [24] 1545 	jc	00119$
      007929 EF               [12] 1546 	mov	a,r7
      00792A 24 5B            [12] 1547 	add	a,#0xff - 0xa4
      00792C 40 0D            [24] 1548 	jc	00119$
                                   1549 ;	free result
                                   1550 ;	quantum/action.c:997: if (!add_owned_key(code)) return;
      00792E 8F 82            [24] 1551 	mov	dpl, r7
      007930 12 81 15         [24] 1552 	lcall	_add_owned_key
      007933 E5 82            [12] 1553 	mov	a, dpl
      007935 70 01            [24] 1554 	jnz	00104$
      007937 22               [24] 1555 	ret
      007938                       1556 00104$:
                                   1557 ;	quantum/action.c:1011: send_keyboard_report();
      007938 02 83 AA         [24] 1558 	ljmp	_send_keyboard_report
      00793B                       1559 00119$:
                                   1560 ;	quantum/action.c:1012: } else if (IS_MODIFIER_KEYCODE(code)) {
      00793B 12 7B 2D         [24] 1561 	lcall	_ak820_outline_0171
      00793E BF E0 00         [24] 1562 	cjne	r7,#0xe0,00190$
      007941                       1563 00190$:
      007941 40 1A            [24] 1564 	jc	00115$
      007943 EF               [12] 1565 	mov	a,r7
      007944 24 18            [12] 1566 	add	a,#0xff - 0xe7
      007946 40 15            [24] 1567 	jc	00115$
                                   1568 ;	free result
                                   1569 ;	quantum/action.c:1013: add_owned_mods(MOD_BIT(code));
      007948 74 07            [12] 1570 	mov	a,#0x07
      00794A 5F               [12] 1571 	anl	a,r7
      00794B 12 7A F8         [24] 1572 	lcall	_ak820_outline_0065
      00794E 80 02            [24] 1573 	sjmp	00194$
      007950                       1574 00193$:
      007950 25 E0            [12] 1575 	add	a,acc
      007952                       1576 00194$:
      007952 D5 F0 FB         [24] 1577 	djnz	b,00193$
      007955 F5 82            [12] 1578 	mov	dpl,a
      007957 12 80 71         [24] 1579 	lcall	_add_owned_mods
                                   1580 ;	quantum/action.c:1014: send_keyboard_report();
      00795A 02 83 AA         [24] 1581 	ljmp	_send_keyboard_report
      00795D                       1582 00115$:
                                   1583 ;	quantum/action.c:1017: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00795D 12 7B 2D         [24] 1584 	lcall	_ak820_outline_0171
      007960 BF A5 00         [24] 1585 	cjne	r7,#0xa5,00195$
      007963                       1586 00195$:
      007963 40 05            [24] 1587 	jc	00113$
      007965 EF               [12] 1588 	mov	a,r7
      007966 24 58            [12] 1589 	add	a,#0xff - 0xa7
      007968 50 0D            [24] 1590 	jnc	00108$
                                   1591 ;	free result
      00796A                       1592 00113$:
      00796A 12 7B 2D         [24] 1593 	lcall	_ak820_outline_0171
      00796D BF A8 00         [24] 1594 	cjne	r7,#0xa8,00198$
      007970                       1595 00198$:
      007970 40 13            [24] 1596 	jc	00125$
      007972 EF               [12] 1597 	mov	a,r7
      007973 24 3D            [12] 1598 	add	a,#0xff - 0xc2
      007975 40 0E            [24] 1599 	jc	00125$
                                   1600 ;	free result
      007977                       1601 00108$:
                                   1602 ;	quantum/action.c:1019: owned_usage_key(code, true);
      007977 12 7B 2D         [24] 1603 	lcall	_ak820_outline_0171
      00797A 90 0A D9         [24] 1604 	mov	dptr,#_owned_usage_key_PARM_2
      00797D 74 01            [12] 1605 	mov	a,#0x01
      00797F F0               [24] 1606 	movx	@dptr,a
      007980 8F 82            [24] 1607 	mov	dpl, r7
                                   1608 ;	quantum/action.c:1027: register_mouse(code, true);
                                   1609 ;	quantum/action.c:1029: }
      007982 02 82 56         [24] 1610 	ljmp	_owned_usage_key
      007985                       1611 00125$:
      007985 22               [24] 1612 	ret
                                   1613 ;------------------------------------------------------------
                                   1614 ;Allocation info for local variables in function 'unregister_code'
                                   1615 ;------------------------------------------------------------
                                   1616 ;code          Allocated with name '_unregister_code_code_10000_747'
                                   1617 ;------------------------------------------------------------
                                   1618 ;	quantum/action.c:1035: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1619 ;	-----------------------------------------
                                   1620 ;	 function unregister_code
                                   1621 ;	-----------------------------------------
      007986                       1622 _unregister_code:
      007986 E5 82            [12] 1623 	mov	a,dpl
      007988 90 08 7F         [24] 1624 	mov	dptr,#_unregister_code_code_10000_747
      00798B F0               [24] 1625 	movx	@dptr,a
                                   1626 ;	quantum/action.c:1036: if (code == KC_NO) {
      00798C E0               [24] 1627 	movx	a,@dptr
      00798D FF               [12] 1628 	mov	r7,a
      00798E 70 01            [24] 1629 	jnz	00121$
                                   1630 ;	quantum/action.c:1037: return;
      007990 22               [24] 1631 	ret
      007991                       1632 00121$:
                                   1633 ;	quantum/action.c:1069: } else if (IS_BASIC_KEYCODE(code)) {
      007991 BF 04 00         [24] 1634 	cjne	r7,#0x04,00184$
      007994                       1635 00184$:
      007994 40 12            [24] 1636 	jc	00117$
      007996 EF               [12] 1637 	mov	a,r7
      007997 24 5B            [12] 1638 	add	a,#0xff - 0xa4
      007999 40 0D            [24] 1639 	jc	00117$
                                   1640 ;	free result
                                   1641 ;	quantum/action.c:1071: if (!del_owned_key(code)) return;
      00799B 8F 82            [24] 1642 	mov	dpl, r7
      00799D 12 81 8F         [24] 1643 	lcall	_del_owned_key
      0079A0 E5 82            [12] 1644 	mov	a, dpl
      0079A2 70 01            [24] 1645 	jnz	00102$
      0079A4 22               [24] 1646 	ret
      0079A5                       1647 00102$:
                                   1648 ;	quantum/action.c:1078: send_keyboard_report();
      0079A5 02 83 AA         [24] 1649 	ljmp	_send_keyboard_report
      0079A8                       1650 00117$:
                                   1651 ;	quantum/action.c:1079: } else if (IS_MODIFIER_KEYCODE(code)) {
      0079A8 12 7B 33         [24] 1652 	lcall	_ak820_outline_0172
      0079AB BF E0 00         [24] 1653 	cjne	r7,#0xe0,00188$
      0079AE                       1654 00188$:
      0079AE 40 1A            [24] 1655 	jc	00113$
      0079B0 EF               [12] 1656 	mov	a,r7
      0079B1 24 18            [12] 1657 	add	a,#0xff - 0xe7
      0079B3 40 15            [24] 1658 	jc	00113$
                                   1659 ;	free result
                                   1660 ;	quantum/action.c:1080: del_owned_mods(MOD_BIT(code));
      0079B5 74 07            [12] 1661 	mov	a,#0x07
      0079B7 5F               [12] 1662 	anl	a,r7
      0079B8 12 7A F8         [24] 1663 	lcall	_ak820_outline_0065
      0079BB 80 02            [24] 1664 	sjmp	00192$
      0079BD                       1665 00191$:
      0079BD 25 E0            [12] 1666 	add	a,acc
      0079BF                       1667 00192$:
      0079BF D5 F0 FB         [24] 1668 	djnz	b,00191$
      0079C2 F5 82            [12] 1669 	mov	dpl,a
      0079C4 12 80 81         [24] 1670 	lcall	_del_owned_mods
                                   1671 ;	quantum/action.c:1081: send_keyboard_report();
      0079C7 02 83 AA         [24] 1672 	ljmp	_send_keyboard_report
      0079CA                       1673 00113$:
                                   1674 ;	quantum/action.c:1084: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0079CA 12 7B 33         [24] 1675 	lcall	_ak820_outline_0172
      0079CD BF A5 00         [24] 1676 	cjne	r7,#0xa5,00193$
      0079D0                       1677 00193$:
      0079D0 40 05            [24] 1678 	jc	00111$
      0079D2 EF               [12] 1679 	mov	a,r7
      0079D3 24 58            [12] 1680 	add	a,#0xff - 0xa7
      0079D5 50 0D            [24] 1681 	jnc	00106$
                                   1682 ;	free result
      0079D7                       1683 00111$:
      0079D7 12 7B 33         [24] 1684 	lcall	_ak820_outline_0172
      0079DA BF A8 00         [24] 1685 	cjne	r7,#0xa8,00196$
      0079DD                       1686 00196$:
      0079DD 40 12            [24] 1687 	jc	00123$
      0079DF EF               [12] 1688 	mov	a,r7
      0079E0 24 3D            [12] 1689 	add	a,#0xff - 0xc2
      0079E2 40 0D            [24] 1690 	jc	00123$
                                   1691 ;	free result
      0079E4                       1692 00106$:
                                   1693 ;	quantum/action.c:1086: owned_usage_key(code, false);
      0079E4 12 7B 33         [24] 1694 	lcall	_ak820_outline_0172
      0079E7 90 0A D9         [24] 1695 	mov	dptr,#_owned_usage_key_PARM_2
      0079EA E4               [12] 1696 	clr	a
      0079EB F0               [24] 1697 	movx	@dptr,a
      0079EC 8F 82            [24] 1698 	mov	dpl, r7
                                   1699 ;	quantum/action.c:1094: register_mouse(code, false);
                                   1700 ;	quantum/action.c:1096: }
      0079EE 02 82 56         [24] 1701 	ljmp	_owned_usage_key
      0079F1                       1702 00123$:
      0079F1 22               [24] 1703 	ret
                                   1704 ;------------------------------------------------------------
                                   1705 ;Allocation info for local variables in function 'tap_code_delay'
                                   1706 ;------------------------------------------------------------
                                   1707 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1708 ;code          Allocated with name '_tap_code_delay_code_10000_760'
                                   1709 ;i             Allocated with name '_tap_code_delay_i_20000_762'
                                   1710 ;i             Allocated with name '_tap_code_delay_i_50000_765'
                                   1711 ;------------------------------------------------------------
                                   1712 ;	quantum/action.c:1103: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1713 ;	-----------------------------------------
                                   1714 ;	 function tap_code_delay
                                   1715 ;	-----------------------------------------
      0079F2                       1716 _tap_code_delay:
      0079F2 E5 82            [12] 1717 	mov	a,dpl
      0079F4 90 08 82         [24] 1718 	mov	dptr,#_tap_code_delay_code_10000_760
      0079F7 F0               [24] 1719 	movx	@dptr,a
                                   1720 ;	quantum/action.c:1104: register_code(code);
      0079F8 E0               [24] 1721 	movx	a,@dptr
      0079F9 FF               [12] 1722 	mov	r7,a
      0079FA F5 82            [12] 1723 	mov	dpl,a
      0079FC C0 07            [24] 1724 	push	ar7
      0079FE 31 19            [12] 1725 	acall	_register_code
      007A00 D0 07            [24] 1726 	pop	ar7
                                   1727 ;	quantum/action.c:1105: for (uint16_t i = delay; i > 0; i--) {
      007A02 90 08 80         [24] 1728 	mov	dptr,#_tap_code_delay_PARM_2
      007A05 12 38 59         [24] 1729 	lcall	_ak820_outline_0079
      007A08                       1730 00110$:
      007A08 ED               [12] 1731 	mov	a,r5
      007A09 4E               [12] 1732 	orl	a,r6
      007A0A 60 0D            [24] 1733 	jz	00105$
                                   1734 ;	quantum/action.c:1106: wait_ms(1);
      007A0C 90 00 01         [24] 1735 	mov	dptr,#0x0001
      007A0F 12 5D 31         [24] 1736 	lcall	_mDelaymS
                                   1737 ;	quantum/action.c:1105: for (uint16_t i = delay; i > 0; i--) {
      007A12 1D               [12] 1738 	dec	r5
      007A13 BD FF 01         [24] 1739 	cjne	r5,#0xff,00141$
      007A16 1E               [12] 1740 	dec	r6
      007A17                       1741 00141$:
      007A17 80 EF            [24] 1742 	sjmp	00110$
      007A19                       1743 00105$:
                                   1744 ;	quantum/action.c:1108: unregister_code(code);
      007A19 8F 82            [24] 1745 	mov	dpl, r7
                                   1746 ;	quantum/action.c:1109: }
      007A1B 21 86            [12] 1747 	ajmp	_unregister_code
                                   1748 ;------------------------------------------------------------
                                   1749 ;Allocation info for local variables in function 'tap_code'
                                   1750 ;------------------------------------------------------------
                                   1751 ;code          Allocated with name '_tap_code_code_10000_767'
                                   1752 ;------------------------------------------------------------
                                   1753 ;	quantum/action.c:1115: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1754 ;	-----------------------------------------
                                   1755 ;	 function tap_code
                                   1756 ;	-----------------------------------------
      007A1D                       1757 _tap_code:
      007A1D E5 82            [12] 1758 	mov	a,dpl
      007A1F 90 08 83         [24] 1759 	mov	dptr,#_tap_code_code_10000_767
      007A22 F0               [24] 1760 	movx	@dptr,a
                                   1761 ;	quantum/action.c:1116: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A23 E0               [24] 1762 	movx	a,@dptr
      007A24 FF               [12] 1763 	mov	r7,a
      007A25 BF 39 0C         [24] 1764 	cjne	r7,#0x39,00103$
      007A28 C0 07            [24] 1765 	push	ar7
      007A2A 12 47 E8         [24] 1766 	lcall	_ak820_settings_caps_delay
      007A2D 12 43 8D         [24] 1767 	lcall	_ak820_outline_0193
      007A30 D0 07            [24] 1768 	pop	ar7
      007A32 80 0A            [24] 1769 	sjmp	00104$
      007A34                       1770 00103$:
      007A34 C0 07            [24] 1771 	push	ar7
      007A36 12 47 E2         [24] 1772 	lcall	_ak820_settings_tap_code_delay
      007A39 12 43 8D         [24] 1773 	lcall	_ak820_outline_0193
      007A3C D0 07            [24] 1774 	pop	ar7
      007A3E                       1775 00104$:
      007A3E 90 08 80         [24] 1776 	mov	dptr,#_tap_code_delay_PARM_2
      007A41 12 43 6C         [24] 1777 	lcall	_ak820_outline_0141
      007A44 8F 82            [24] 1778 	mov	dpl, r7
                                   1779 ;	quantum/action.c:1117: }
      007A46 21 F2            [12] 1780 	ajmp	_tap_code_delay
                                   1781 ;------------------------------------------------------------
                                   1782 ;Allocation info for local variables in function 'register_mods'
                                   1783 ;------------------------------------------------------------
                                   1784 ;mods          Allocated with name '_register_mods_mods_10000_769'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/action.c:1123: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function register_mods
                                   1789 ;	-----------------------------------------
      007A48                       1790 _register_mods:
      007A48 E5 82            [12] 1791 	mov	a,dpl
      007A4A 90 08 84         [24] 1792 	mov	dptr,#_register_mods_mods_10000_769
      007A4D F0               [24] 1793 	movx	@dptr,a
                                   1794 ;	quantum/action.c:1124: if (mods) {
      007A4E E0               [24] 1795 	movx	a,@dptr
      007A4F FF               [12] 1796 	mov	r7,a
      007A50 E0               [24] 1797 	movx	a,@dptr
      007A51 60 08            [24] 1798 	jz	00103$
                                   1799 ;	quantum/action.c:1125: add_owned_mods(mods);
      007A53 8F 82            [24] 1800 	mov	dpl, r7
      007A55 12 80 71         [24] 1801 	lcall	_add_owned_mods
                                   1802 ;	quantum/action.c:1126: send_keyboard_report();
                                   1803 ;	quantum/action.c:1128: }
      007A58 02 83 AA         [24] 1804 	ljmp	_send_keyboard_report
      007A5B                       1805 00103$:
      007A5B 22               [24] 1806 	ret
                                   1807 ;------------------------------------------------------------
                                   1808 ;Allocation info for local variables in function 'unregister_mods'
                                   1809 ;------------------------------------------------------------
                                   1810 ;mods          Allocated with name '_unregister_mods_mods_10000_773'
                                   1811 ;------------------------------------------------------------
                                   1812 ;	quantum/action.c:1134: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1813 ;	-----------------------------------------
                                   1814 ;	 function unregister_mods
                                   1815 ;	-----------------------------------------
      007A5C                       1816 _unregister_mods:
      007A5C E5 82            [12] 1817 	mov	a,dpl
      007A5E 90 08 85         [24] 1818 	mov	dptr,#_unregister_mods_mods_10000_773
      007A61 F0               [24] 1819 	movx	@dptr,a
                                   1820 ;	quantum/action.c:1135: if (mods) {
      007A62 E0               [24] 1821 	movx	a,@dptr
      007A63 FF               [12] 1822 	mov	r7,a
      007A64 E0               [24] 1823 	movx	a,@dptr
      007A65 60 08            [24] 1824 	jz	00103$
                                   1825 ;	quantum/action.c:1136: del_owned_mods(mods);
      007A67 8F 82            [24] 1826 	mov	dpl, r7
      007A69 12 80 81         [24] 1827 	lcall	_del_owned_mods
                                   1828 ;	quantum/action.c:1137: send_keyboard_report();
                                   1829 ;	quantum/action.c:1139: }
      007A6C 02 83 AA         [24] 1830 	ljmp	_send_keyboard_report
      007A6F                       1831 00103$:
      007A6F 22               [24] 1832 	ret
                                   1833 ;------------------------------------------------------------
                                   1834 ;Allocation info for local variables in function 'register_weak_mods'
                                   1835 ;------------------------------------------------------------
                                   1836 ;mods          Allocated with name '_register_weak_mods_mods_10000_777'
                                   1837 ;------------------------------------------------------------
                                   1838 ;	quantum/action.c:1145: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1839 ;	-----------------------------------------
                                   1840 ;	 function register_weak_mods
                                   1841 ;	-----------------------------------------
      007A70                       1842 _register_weak_mods:
      007A70 E5 82            [12] 1843 	mov	a,dpl
      007A72 90 08 86         [24] 1844 	mov	dptr,#_register_weak_mods_mods_10000_777
      007A75 F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	quantum/action.c:1146: if (mods) {
      007A76 E0               [24] 1847 	movx	a,@dptr
      007A77 FF               [12] 1848 	mov	r7,a
      007A78 E0               [24] 1849 	movx	a,@dptr
      007A79 60 08            [24] 1850 	jz	00103$
                                   1851 ;	quantum/action.c:1147: add_owned_weak_mods(mods);
      007A7B 8F 82            [24] 1852 	mov	dpl, r7
      007A7D 12 80 90         [24] 1853 	lcall	_add_owned_weak_mods
                                   1854 ;	quantum/action.c:1148: send_keyboard_report();
                                   1855 ;	quantum/action.c:1150: }
      007A80 02 83 AA         [24] 1856 	ljmp	_send_keyboard_report
      007A83                       1857 00103$:
      007A83 22               [24] 1858 	ret
                                   1859 ;------------------------------------------------------------
                                   1860 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1861 ;------------------------------------------------------------
                                   1862 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_781'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	quantum/action.c:1156: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function unregister_weak_mods
                                   1867 ;	-----------------------------------------
      007A84                       1868 _unregister_weak_mods:
      007A84 E5 82            [12] 1869 	mov	a,dpl
      007A86 90 08 87         [24] 1870 	mov	dptr,#_unregister_weak_mods_mods_10000_781
      007A89 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	quantum/action.c:1157: if (mods) {
      007A8A E0               [24] 1873 	movx	a,@dptr
      007A8B FF               [12] 1874 	mov	r7,a
      007A8C E0               [24] 1875 	movx	a,@dptr
      007A8D 60 08            [24] 1876 	jz	00103$
                                   1877 ;	quantum/action.c:1158: del_owned_weak_mods(mods);
      007A8F 8F 82            [24] 1878 	mov	dpl, r7
      007A91 12 80 A0         [24] 1879 	lcall	_del_owned_weak_mods
                                   1880 ;	quantum/action.c:1159: send_keyboard_report();
                                   1881 ;	quantum/action.c:1161: }
      007A94 02 83 AA         [24] 1882 	ljmp	_send_keyboard_report
      007A97                       1883 00103$:
      007A97 22               [24] 1884 	ret
                                   1885 ;------------------------------------------------------------
                                   1886 ;Allocation info for local variables in function 'clear_keyboard'
                                   1887 ;------------------------------------------------------------
                                   1888 ;	quantum/action.c:1167: void clear_keyboard(void) {
                                   1889 ;	-----------------------------------------
                                   1890 ;	 function clear_keyboard
                                   1891 ;	-----------------------------------------
      007A98                       1892 _clear_keyboard:
                                   1893 ;	quantum/action.c:1168: clear_mods();
      007A98 12 84 25         [24] 1894 	lcall	_clear_mods
                                   1895 ;	quantum/action.c:1169: clear_keyboard_but_mods();
                                   1896 ;	quantum/action.c:1170: }
      007A9B 41 9D            [12] 1897 	ajmp	_clear_keyboard_but_mods
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	quantum/action.c:1176: void clear_keyboard_but_mods(void) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function clear_keyboard_but_mods
                                   1904 ;	-----------------------------------------
      007A9D                       1905 _clear_keyboard_but_mods:
                                   1906 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007A9D 90 0E 0F         [24] 1907 	mov	dptr,#_actual_keyboard_report
      007AA0 12 73 75         [24] 1908 	lcall	_clear_keys_from_report
                                   1909 ;	quantum/action.c:1178: clear_keyboard_but_mods_and_keys();
                                   1910 ;	quantum/action.c:1179: }
      007AA3 41 A5            [12] 1911 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1912 ;------------------------------------------------------------
                                   1913 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1914 ;------------------------------------------------------------
                                   1915 ;	quantum/action.c:1185: void clear_keyboard_but_mods_and_keys(void) {
                                   1916 ;	-----------------------------------------
                                   1917 ;	 function clear_keyboard_but_mods_and_keys
                                   1918 ;	-----------------------------------------
      007AA5                       1919 _clear_keyboard_but_mods_and_keys:
                                   1920 ;	quantum/action.c:1187: ak820_tapping_cancel();
      007AA5 12 4B 8A         [24] 1921 	lcall	_ak820_tapping_cancel
                                   1922 ;	quantum/action.c:1204: ak820_oneshot_cancel();
      007AA8 12 2E F0         [24] 1923 	lcall	_ak820_oneshot_cancel
                                   1924 ;	quantum/action.c:1207: ak820_combo_cancel();
      007AAB 12 35 6C         [24] 1925 	lcall	_ak820_combo_cancel
                                   1926 ;	quantum/action.c:1210: repeat_key_cancel();
      007AAE 12 A5 4C         [24] 1927 	lcall	_repeat_key_cancel
                                   1928 ;	quantum/action.c:1212: clear_owned_mods();
      007AB1 12 80 B0         [24] 1929 	lcall	_clear_owned_mods
                                   1930 ;	quantum/action.c:1213: clear_owned_keys();
      007AB4 12 80 E8         [24] 1931 	lcall	_clear_owned_keys
                                   1932 ;	quantum/action.c:1214: clear_owned_usages();
      007AB7 12 82 1E         [24] 1933 	lcall	_clear_owned_usages
                                   1934 ;	quantum/action.c:1215: layer_hold_clear();
      007ABA 91 6D            [12] 1935 	acall	_layer_hold_clear
                                   1936 ;	quantum/action.c:1217: clear_macro_tri_layer();
      007ABC 12 A0 29         [24] 1937 	lcall	_clear_macro_tri_layer
                                   1938 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007ABF 90 0E 0F         [24] 1939 	mov	dptr,#_actual_keyboard_report
      007AC2 12 73 75         [24] 1940 	lcall	_clear_keys_from_report
                                   1941 ;	quantum/action.c:1222: host_system_send(0);
      007AC5 90 00 00         [24] 1942 	mov	dptr,#0x0000
      007AC8 12 71 57         [24] 1943 	lcall	_host_system_send
                                   1944 ;	quantum/action.c:1223: host_consumer_send(0);
      007ACB 90 00 00         [24] 1945 	mov	dptr,#0x0000
      007ACE 12 71 86         [24] 1946 	lcall	_host_consumer_send
                                   1947 ;	quantum/action.c:1225: clear_weak_mods();
      007AD1 12 84 5A         [24] 1948 	lcall	_clear_weak_mods
                                   1949 ;	quantum/action.c:1226: send_keyboard_report();
                                   1950 ;	quantum/action.c:1234: }
      007AD4 02 83 AA         [24] 1951 	ljmp	_send_keyboard_report
                                   1952 ;------------------------------------------------------------
                                   1953 ;Allocation info for local variables in function 'is_tap_record'
                                   1954 ;------------------------------------------------------------
                                   1955 ;record        Allocated with name '_is_tap_record_record_10000_797'
                                   1956 ;action        Allocated with name '_is_tap_record_action_10001_801'
                                   1957 ;------------------------------------------------------------
                                   1958 ;	quantum/action.c:1240: bool is_tap_record(keyrecord_t *record) {
                                   1959 ;	-----------------------------------------
                                   1960 	.area CSEG    (CODE)
                                   1961 	.area CONST   (CODE)
                                   1962 	.area XINIT   (CODE)
      00C686                       1963 __xinit__disable_action_cache:
      00C686 00                    1964 	.db #0x00	;  0
                                   1965 	.area CABS    (ABS,CODE)
                                   1966 
                                   1967 ; Experimental exact instruction outlining.
                                   1968 	.globl _ak820_outline_0005
                                   1969 	.globl _ak820_outline_0008
                                   1970 	.globl _ak820_outline_0009
                                   1971 	.globl _ak820_outline_0010
                                   1972 	.globl _ak820_outline_0017
                                   1973 	.globl _ak820_outline_0018
                                   1974 	.globl _ak820_outline_0020
                                   1975 	.globl _ak820_outline_0023
                                   1976 	.globl _ak820_outline_0041
                                   1977 	.globl _ak820_outline_0053
                                   1978 	.globl _ak820_outline_0054
                                   1979 	.globl _ak820_outline_0062
                                   1980 	.globl _ak820_outline_0065
                                   1981 	.globl _ak820_outline_0073
                                   1982 	.globl _ak820_outline_0078
                                   1983 	.globl _ak820_outline_0079
                                   1984 	.globl _ak820_outline_0086
                                   1985 	.globl _ak820_outline_0089
                                   1986 	.globl _ak820_outline_0108
                                   1987 	.globl _ak820_outline_0109
                                   1988 	.globl _ak820_outline_0116
                                   1989 	.globl _ak820_outline_0117
                                   1990 	.globl _ak820_outline_0118
                                   1991 	.globl _ak820_outline_0123
                                   1992 	.globl _ak820_outline_0126
                                   1993 	.globl _ak820_outline_0127
                                   1994 	.globl _ak820_outline_0134
                                   1995 	.globl _ak820_outline_0141
                                   1996 	.globl _ak820_outline_0147
                                   1997 	.globl _ak820_outline_0148
                                   1998 	.globl _ak820_outline_0149
                                   1999 	.globl _ak820_outline_0162
                                   2000 	.globl _ak820_outline_0165
                                   2001 	.globl _ak820_outline_0171
                                   2002 	.globl _ak820_outline_0172
                                   2003 	.globl _ak820_outline_0173
                                   2004 	.globl _ak820_outline_0187
                                   2005 	.globl _ak820_outline_0193
                                   2006 
                                   2007 	.area CSEG (CODE)
                                   2008 ; function ak820_outline_0023
      007AD7                       2009 _ak820_outline_0023:
      007AD7 8E 82            [24] 2010 	mov	dpl,r6
      007AD9 8F 83            [24] 2011 	mov	dph,r7
      007ADB A3               [24] 2012 	inc	dptr
      007ADC E0               [24] 2013 	movx	a,@dptr
      007ADD FC               [12] 2014 	mov	r4,a
      007ADE 7D 00            [12] 2015 	mov	r5,#0x00
      007AE0 8E 82            [24] 2016 	mov	dpl,r6
      007AE2 8F 83            [24] 2017 	mov	dph,r7
      007AE4 E0               [24] 2018 	movx	a,@dptr
      007AE5 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0041
      007AE6                       2023 _ak820_outline_0041:
      007AE6 90 08 7A         [24] 2024 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007AE9 E0               [24] 2025 	movx	a,@dptr
      007AEA 54 1F            [12] 2026 	anl	a,#0x1f
      007AEC F5 82            [12] 2027 	mov	dpl,a
      007AEE 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0053
      007AEF                       2032 _ak820_outline_0053:
      007AEF A3               [24] 2033 	inc	dptr
      007AF0 F0               [24] 2034 	movx	@dptr,a
      007AF1 E4               [12] 2035 	clr	a
      007AF2 A3               [24] 2036 	inc	dptr
      007AF3 F0               [24] 2037 	movx	@dptr,a
      007AF4 90 0D E5         [24] 2038 	mov	dptr,#___memcpy_PARM_3
      007AF7 22               [24] 2039 	ret
                                   2040 
                                   2041 	.area CSEG (CODE)
                                   2042 ; function ak820_outline_0065
      007AF8                       2043 _ak820_outline_0065:
      007AF8 F5 F0            [12] 2044 	mov	b,a
      007AFA 05 F0            [12] 2045 	inc	b
      007AFC 74 01            [12] 2046 	mov	a,#0x01
      007AFE 22               [24] 2047 	ret
                                   2048 
                                   2049 	.area CSEG (CODE)
                                   2050 ; function ak820_outline_0078
      007AFF                       2051 _ak820_outline_0078:
      007AFF 90 08 79         [24] 2052 	mov	dptr,#_process_action_PARM_2
      007B02 E0               [24] 2053 	movx	a,@dptr
      007B03 F5 82            [12] 2054 	mov	dpl,a
      007B05 22               [24] 2055 	ret
                                   2056 
                                   2057 	.area CSEG (CODE)
                                   2058 ; function ak820_outline_0089
      007B06                       2059 _ak820_outline_0089:
      007B06 90 08 7A         [24] 2060 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B09 E0               [24] 2061 	movx	a,@dptr
      007B0A 03               [12] 2062 	rr	a
      007B0B 03               [12] 2063 	rr	a
      007B0C 54 03            [12] 2064 	anl	a,#0x03
      007B0E 22               [24] 2065 	ret
                                   2066 
                                   2067 	.area CSEG (CODE)
                                   2068 ; function ak820_outline_0117
      007B0F                       2069 _ak820_outline_0117:
      007B0F 74 06            [12] 2070 	mov	a,#0x06
      007B11 F0               [24] 2071 	movx	@dptr,a
      007B12 E4               [12] 2072 	clr	a
      007B13 A3               [24] 2073 	inc	dptr
      007B14 F0               [24] 2074 	movx	@dptr,a
      007B15 22               [24] 2075 	ret
                                   2076 
                                   2077 	.area CSEG (CODE)
                                   2078 ; function ak820_outline_0118
      007B16                       2079 _ak820_outline_0118:
      007B16 90 08 7A         [24] 2080 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B19 E0               [24] 2081 	movx	a,@dptr
      007B1A 54 0F            [12] 2082 	anl	a,#0x0f
      007B1C 22               [24] 2083 	ret
                                   2084 
                                   2085 	.area CSEG (CODE)
                                   2086 ; function ak820_outline_0134
      007B1D                       2087 _ak820_outline_0134:
      007B1D 90 08 79         [24] 2088 	mov	dptr,#_process_action_PARM_2
      007B20 E0               [24] 2089 	movx	a,@dptr
      007B21 FE               [12] 2090 	mov	r6,a
      007B22 A3               [24] 2091 	inc	dptr
      007B23 E0               [24] 2092 	movx	a,@dptr
      007B24 54 03            [12] 2093 	anl	a,#0x03
      007B26 FF               [12] 2094 	mov	r7,a
      007B27 22               [24] 2095 	ret
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0162
      007B28                       2099 _ak820_outline_0162:
      007B28 90 08 79         [24] 2100 	mov	dptr,#_process_action_PARM_2
      007B2B E0               [24] 2101 	movx	a,@dptr
      007B2C 22               [24] 2102 	ret
                                   2103 
                                   2104 	.area CSEG (CODE)
                                   2105 ; function ak820_outline_0171
      007B2D                       2106 _ak820_outline_0171:
      007B2D 90 08 7E         [24] 2107 	mov	dptr,#_register_code_code_10000_733
      007B30 E0               [24] 2108 	movx	a,@dptr
      007B31 FF               [12] 2109 	mov	r7,a
      007B32 22               [24] 2110 	ret
                                   2111 
                                   2112 	.area CSEG (CODE)
                                   2113 ; function ak820_outline_0172
      007B33                       2114 _ak820_outline_0172:
      007B33 90 08 7F         [24] 2115 	mov	dptr,#_unregister_code_code_10000_747
      007B36 E0               [24] 2116 	movx	a,@dptr
      007B37 FF               [12] 2117 	mov	r7,a
      007B38 22               [24] 2118 	ret
