                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000C53                        554 _last_record:
      000C53                        555 	.ds 9
      000C5C                        556 _ak820_repeat_invoking:
      000C5C                        557 	.ds 1
      000C5D                        558 _registered_record:
      000C5D                        559 	.ds 9
      000C66                        560 _registered_repeat_count:
      000C66                        561 	.ds 1
      000C67                        562 _registered_mods:
      000C67                        563 	.ds 1
      000C68                        564 _set_last_mods_mods_10000_170:
      000C68                        565 	.ds 1
      000C69                        566 _set_last_record_PARM_2:
      000C69                        567 	.ds 3
      000C6C                        568 _set_last_record_keycode_10000_172:
      000C6C                        569 	.ds 2
      000C6E                        570 _update_last_repeat_count_dir_10000_174:
      000C6E                        571 	.ds 1
      000C6F                        572 _repeat_invoke_PARM_2:
      000C6F                        573 	.ds 1
      000C70                        574 _repeat_invoke_event_10000_182:
      000C70                        575 	.ds 3
      000C73                        576 _repeat_key_invoke_event_10000_197:
      000C73                        577 	.ds 3
      000C76                        578 _find_alt_keycode_PARM_2:
      000C76                        579 	.ds 1
      000C77                        580 _find_alt_keycode_PARM_3:
      000C77                        581 	.ds 1
      000C78                        582 _find_alt_keycode_table_10000_199:
      000C78                        583 	.ds 3
      000C7B                        584 _get_alt_repeat_key_keycode_keycode_10000_206:
      000C7B                        585 	.ds 2
      000C7D                        586 _get_alt_repeat_key_keycode_mods_10000_206:
      000C7D                        587 	.ds 1
      000C7E                        588 _get_alt_repeat_key_keycode_alt_keycode_10000_206:
      000C7E                        589 	.ds 2
      000C80                        590 _alt_repeat_key_invoke_event_10000_220:
      000C80                        591 	.ds 3
      000C83                        592 _get_alt_repeat_key_keycode_user_PARM_2:
      000C83                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000E62                        602 _last_mods:
      000E62                        603 	.ds 1
      000E63                        604 _last_repeat_count:
      000E63                        605 	.ds 1
      000E64                        606 _processing_repeat_count:
      000E64                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function repeat_key_cancel
                                    640 ;	-----------------------------------------
      00A54C                        641 _repeat_key_cancel:
                           000007   642 	ar7 = 0x07
                           000006   643 	ar6 = 0x06
                           000005   644 	ar5 = 0x05
                           000004   645 	ar4 = 0x04
                           000003   646 	ar3 = 0x03
                           000002   647 	ar2 = 0x02
                           000001   648 	ar1 = 0x01
                           000000   649 	ar0 = 0x00
                                    650 ;	quantum/repeat_key.c:45: registered_record.keycode = 0;
      00A54C 90 0C 64         [24]  651 	mov	dptr,#(_registered_record + 0x0007)
      00A54F 12 53 D5         [24]  652 	lcall	_ak820_outline_0173
                                    653 ;	quantum/repeat_key.c:46: }
      00A552 22               [24]  654 	ret
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'get_last_keycode'
                                    657 ;------------------------------------------------------------
                                    658 ;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
                                    659 ;	-----------------------------------------
                                    660 ;	 function set_last_mods
                                    661 ;	-----------------------------------------
      00A553                        662 _set_last_mods:
      00A553 E5 82            [12]  663 	mov	a,dpl
      00A555 90 0C 68         [24]  664 	mov	dptr,#_set_last_mods_mods_10000_170
      00A558 F0               [24]  665 	movx	@dptr,a
                                    666 ;	quantum/repeat_key.c:66: last_mods = mods;
      00A559 E0               [24]  667 	movx	a,@dptr
      00A55A 90 0E 62         [24]  668 	mov	dptr,#_last_mods
      00A55D F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/repeat_key.c:67: }
      00A55E 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'set_last_record'
                                    674 ;------------------------------------------------------------
                                    675 ;record        Allocated with name '_set_last_record_PARM_2'
                                    676 ;keycode       Allocated with name '_set_last_record_keycode_10000_172'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t* record) {
                                    679 ;	-----------------------------------------
                                    680 ;	 function set_last_record
                                    681 ;	-----------------------------------------
      00A55F                        682 _set_last_record:
      00A55F 12 38 8A         [24]  683 	lcall	_ak820_outline_0108
      00A562 90 0C 6C         [24]  684 	mov	dptr,#_set_last_record_keycode_10000_172
      00A565 12 38 8F         [24]  685 	lcall	_ak820_outline_0109
                                    686 ;	quantum/repeat_key.c:70: last_record         = *record;
      00A568 90 0C 69         [24]  687 	mov	dptr,#_set_last_record_PARM_2
      00A56B 12 53 8D         [24]  688 	lcall	_ak820_outline_0013
      00A56E 90 0D E2         [24]  689 	mov	dptr,#___memcpy_PARM_2
      00A571 ED               [12]  690 	mov	a,r5
      00A572 12 38 1E         [24]  691 	lcall	_ak820_outline_0017
      00A575 90 0D E5         [24]  692 	mov	dptr,#___memcpy_PARM_3
      00A578 74 09            [12]  693 	mov	a,#0x09
      00A57A 12 38 9E         [24]  694 	lcall	_ak820_outline_0128
      00A57D 90 0C 53         [24]  695 	mov	dptr,#_last_record
      00A580 F5 F0            [12]  696 	mov	b,a
      00A582 12 BC AA         [24]  697 	lcall	___memcpy
                                    698 ;	quantum/repeat_key.c:71: last_record.keycode = keycode;
      00A585 90 0C 6C         [24]  699 	mov	dptr,#_set_last_record_keycode_10000_172
      00A588 12 38 36         [24]  700 	lcall	_ak820_outline_0054
      00A58B 90 0C 5A         [24]  701 	mov	dptr,#(_last_record + 0x0007)
      00A58E 12 4D 34         [24]  702 	lcall	_ak820_outline_0061
                                    703 ;	quantum/repeat_key.c:72: last_repeat_count   = 0;
      00A591 90 0E 63         [24]  704 	mov	dptr,#_last_repeat_count
      00A594 E4               [12]  705 	clr	a
      00A595 F0               [24]  706 	movx	@dptr,a
                                    707 ;	quantum/repeat_key.c:73: }
      00A596 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    711 ;------------------------------------------------------------
                                    712 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function update_last_repeat_count
                                    717 ;	-----------------------------------------
      00A597                        718 _update_last_repeat_count:
      00A597 E5 82            [12]  719 	mov	a,dpl
      00A599 90 0C 6E         [24]  720 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A59C F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
      00A59D E0               [24]  723 	movx	a,@dptr
      00A59E FF               [12]  724 	mov	r7,a
      00A59F 33               [12]  725 	rlc	a
      00A5A0 E4               [12]  726 	clr	a
      00A5A1 33               [12]  727 	rlc	a
      00A5A2 FE               [12]  728 	mov	r6,a
      00A5A3 90 0E 63         [24]  729 	mov	dptr,#_last_repeat_count
      00A5A6 E0               [24]  730 	movx	a,@dptr
      00A5A7 FD               [12]  731 	mov	r5,a
      00A5A8 33               [12]  732 	rlc	a
      00A5A9 E4               [12]  733 	clr	a
      00A5AA 33               [12]  734 	rlc	a
      00A5AB FC               [12]  735 	mov	r4,a
      00A5AC EE               [12]  736 	mov	a,r6
      00A5AD B5 04 02         [24]  737 	cjne	a,ar4,00131$
      00A5B0 80 06            [24]  738 	sjmp	00104$
      00A5B2                        739 00131$:
                                    740 ;	quantum/repeat_key.c:78: last_repeat_count = dir;
      00A5B2 90 0E 63         [24]  741 	mov	dptr,#_last_repeat_count
      00A5B5 EF               [12]  742 	mov	a,r7
      00A5B6 F0               [24]  743 	movx	@dptr,a
      00A5B7 22               [24]  744 	ret
      00A5B8                        745 00104$:
                                    746 ;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      00A5B8 EE               [12]  747 	mov	a,r6
      00A5B9 60 0F            [24]  748 	jz	00108$
      00A5BB C3               [12]  749 	clr	c
      00A5BC 74 01            [12]  750 	mov	a,#(0x81 ^ 0x80)
      00A5BE 8D F0            [24]  751 	mov	b,r5
      00A5C0 63 F0 80         [24]  752 	xrl	b,#0x80
      00A5C3 95 F0            [12]  753 	subb	a,b
      00A5C5 E4               [12]  754 	clr	a
      00A5C6 33               [12]  755 	rlc	a
      00A5C7 FF               [12]  756 	mov	r7,a
                                    757 ;	free result
      00A5C8 80 09            [24]  758 	sjmp	00109$
      00A5CA                        759 00108$:
      00A5CA C3               [12]  760 	clr	c
      00A5CB ED               [12]  761 	mov	a,r5
      00A5CC 64 80            [12]  762 	xrl	a,#0x80
      00A5CE 94 FF            [12]  763 	subb	a,#0xff
      00A5D0 E4               [12]  764 	clr	a
      00A5D1 33               [12]  765 	rlc	a
      00A5D2 FF               [12]  766 	mov	r7,a
      00A5D3                        767 00109$:
      00A5D3 EF               [12]  768 	mov	a,r7
      00A5D4 60 09            [24]  769 	jz	00106$
                                    770 ;	quantum/repeat_key.c:80: last_repeat_count += dir;
      00A5D6 90 0C 6E         [24]  771 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A5D9 E0               [24]  772 	movx	a,@dptr
      00A5DA 90 0E 63         [24]  773 	mov	dptr,#_last_repeat_count
      00A5DD 2D               [12]  774 	add	a, r5
      00A5DE F0               [24]  775 	movx	@dptr,a
      00A5DF                        776 00106$:
                                    777 ;	quantum/repeat_key.c:82: }
      00A5DF 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function get_repeat_key_count
                                    785 ;	-----------------------------------------
      00A5E0                        786 _get_repeat_key_count:
                                    787 ;	quantum/repeat_key.c:85: return processing_repeat_count;
      00A5E0 90 0E 64         [24]  788 	mov	dptr,#_processing_repeat_count
      00A5E3 E0               [24]  789 	movx	a,@dptr
                                    790 ;	quantum/repeat_key.c:86: }
      00A5E4 F5 82            [12]  791 	mov	dpl,a
      00A5E6 22               [24]  792 	ret
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'repeat_invoke'
                                    795 ;------------------------------------------------------------
                                    796 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    797 ;event         Allocated with name '_repeat_invoke_event_10000_182'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t* event, bool alternate) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function repeat_invoke
                                    802 ;	-----------------------------------------
      00A5E7                        803 _repeat_invoke:
      00A5E7 12 43 11         [24]  804 	lcall	_ak820_outline_0037
      00A5EA 90 0C 70         [24]  805 	mov	dptr,#_repeat_invoke_event_10000_182
      00A5ED 12 38 1E         [24]  806 	lcall	_ak820_outline_0017
                                    807 ;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
      00A5F0 90 0C 5C         [24]  808 	mov	dptr,#_ak820_repeat_invoking
      00A5F3 E0               [24]  809 	movx	a,@dptr
      00A5F4 60 01            [24]  810 	jz	00102$
      00A5F6 22               [24]  811 	ret
      00A5F7                        812 00102$:
                                    813 ;	quantum/repeat_key.c:99: if (processing_repeat_count) {
      00A5F7 90 0E 64         [24]  814 	mov	dptr,#_processing_repeat_count
      00A5FA E0               [24]  815 	movx	a,@dptr
      00A5FB 60 01            [24]  816 	jz	00104$
                                    817 ;	quantum/repeat_key.c:100: return;
      00A5FD 22               [24]  818 	ret
      00A5FE                        819 00104$:
                                    820 ;	quantum/repeat_key.c:103: if (event->pressed) {
      00A5FE 90 0C 70         [24]  821 	mov	dptr,#_repeat_invoke_event_10000_182
      00A601 12 53 8D         [24]  822 	lcall	_ak820_outline_0013
      00A604 74 05            [12]  823 	mov	a,#0x05
      00A606 12 9F 64         [24]  824 	lcall	_ak820_outline_0028
      00A609 12 BE 6D         [24]  825 	lcall	__gptrget
      00A60C 70 02            [24]  826 	jnz	00197$
      00A60E C1 86            [24]  827 	ajmp	00117$
      00A610                        828 00197$:
                                    829 ;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
      00A610 12 A8 89         [24]  830 	lcall	_ak820_outline_0176
      00A613 70 0A            [24]  831 	jnz	00105$
      00A615 90 0C 5A         [24]  832 	mov	dptr,#(_last_record + 0x0007)
      00A618 E0               [24]  833 	movx	a,@dptr
      00A619 FB               [12]  834 	mov	r3,a
      00A61A A3               [24]  835 	inc	dptr
      00A61B E0               [24]  836 	movx	a,@dptr
      00A61C 4B               [12]  837 	orl	a,r3
      00A61D 70 01            [24]  838 	jnz	00106$
      00A61F                        839 00105$:
      00A61F 22               [24]  840 	ret
      00A620                        841 00106$:
                                    842 ;	quantum/repeat_key.c:107: registered_record = last_record;
      00A620 90 0D E2         [24]  843 	mov	dptr,#___memcpy_PARM_2
      00A623 74 53            [12]  844 	mov	a,#_last_record
      00A625 F0               [24]  845 	movx	@dptr,a
      00A626 74 0C            [12]  846 	mov	a,#(_last_record >> 8)
      00A628 12 38 5F         [24]  847 	lcall	_ak820_outline_0085
      00A62B 90 0D E5         [24]  848 	mov	dptr,#___memcpy_PARM_3
      00A62E 74 09            [12]  849 	mov	a,#0x09
      00A630 12 38 9E         [24]  850 	lcall	_ak820_outline_0128
      00A633 90 0C 5D         [24]  851 	mov	dptr,#_registered_record
      00A636 F5 F0            [12]  852 	mov	b,a
      00A638 12 BC AA         [24]  853 	lcall	___memcpy
                                    854 ;	quantum/repeat_key.c:108: registered_mods = last_mods;
      00A63B 90 0E 62         [24]  855 	mov	dptr,#_last_mods
      00A63E E0               [24]  856 	movx	a,@dptr
      00A63F 90 0C 67         [24]  857 	mov	dptr,#_registered_mods
      00A642 F0               [24]  858 	movx	@dptr,a
                                    859 ;	quantum/repeat_key.c:110: if (alternate) {
      00A643 90 0C 6F         [24]  860 	mov	dptr,#_repeat_invoke_PARM_2
      00A646 E0               [24]  861 	movx	a,@dptr
      00A647 FC               [12]  862 	mov	r4,a
      00A648 E0               [24]  863 	movx	a,@dptr
      00A649 60 1B            [24]  864 	jz	00111$
                                    865 ;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
      00A64B C0 04            [24]  866 	push	ar4
      00A64D F1 54            [24]  867 	acall	_get_alt_repeat_key_keycode
      00A64F AA 82            [24]  868 	mov	r2, dpl
      00A651 AB 83            [24]  869 	mov	r3, dph
      00A653 D0 04            [24]  870 	pop	ar4
      00A655 90 0C 64         [24]  871 	mov	dptr,#(_registered_record + 0x0007)
      00A658 EA               [12]  872 	mov	a,r2
      00A659 12 48 3C         [24]  873 	lcall	_ak820_outline_0194
                                    874 ;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
      00A65C EA               [12]  875 	mov	a,r2
      00A65D 4B               [12]  876 	orl	a,r3
      00A65E 70 01            [24]  877 	jnz	00109$
      00A660 22               [24]  878 	ret
      00A661                        879 00109$:
                                    880 ;	quantum/repeat_key.c:114: registered_mods = 0;
      00A661 90 0C 67         [24]  881 	mov	dptr,#_registered_mods
      00A664 E4               [12]  882 	clr	a
      00A665 F0               [24]  883 	movx	@dptr,a
      00A666                        884 00111$:
                                    885 ;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
      00A666 EC               [12]  886 	mov	a,r4
      00A667 60 04            [24]  887 	jz	00123$
      00A669 7C FF            [12]  888 	mov	r4,#0xff
      00A66B 80 02            [24]  889 	sjmp	00124$
      00A66D                        890 00123$:
      00A66D 7C 01            [12]  891 	mov	r4,#0x01
      00A66F                        892 00124$:
      00A66F 8C 82            [24]  893 	mov	dpl, r4
      00A671 B1 97            [12]  894 	acall	_update_last_repeat_count
                                    895 ;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
      00A673 90 0C 67         [24]  896 	mov	dptr,#_registered_mods
      00A676 E0               [24]  897 	movx	a,@dptr
      00A677 F5 82            [12]  898 	mov	dpl,a
      00A679 12 7A 70         [24]  899 	lcall	_register_weak_mods
                                    900 ;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
      00A67C 90 0E 63         [24]  901 	mov	dptr,#_last_repeat_count
      00A67F E0               [24]  902 	movx	a,@dptr
      00A680 90 0C 66         [24]  903 	mov	dptr,#_registered_repeat_count
      00A683 F0               [24]  904 	movx	@dptr,a
      00A684 80 2A            [24]  905 	sjmp	00118$
      00A686                        906 00117$:
                                    907 ;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      00A686 12 A8 89         [24]  908 	lcall	_ak820_outline_0176
      00A689 60 24            [24]  909 	jz	00112$
      00A68B 74 01            [12]  910 	mov	a,#0x01
      00A68D 12 9F 64         [24]  911 	lcall	_ak820_outline_0028
      00A690 12 BE 6D         [24]  912 	lcall	__gptrget
      00A693 FA               [12]  913 	mov	r2,a
      00A694 90 0C 5E         [24]  914 	mov	dptr,#(_registered_record + 0x0001)
      00A697 E0               [24]  915 	movx	a,@dptr
      00A698 FC               [12]  916 	mov	r4,a
      00A699 EA               [12]  917 	mov	a,r2
      00A69A B5 04 12         [24]  918 	cjne	a,ar4,00112$
                                    919 ;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
      00A69D 12 53 96         [24]  920 	lcall	_ak820_outline_0048
      00A6A0 12 BE 6D         [24]  921 	lcall	__gptrget
      00A6A3 FD               [12]  922 	mov	r5,a
      00A6A4 90 0C 5D         [24]  923 	mov	dptr,#_registered_record
      00A6A7 E0               [24]  924 	movx	a,@dptr
      00A6A8 FF               [12]  925 	mov	r7,a
      00A6A9 ED               [12]  926 	mov	a,r5
      00A6AA B5 07 02         [24]  927 	cjne	a,ar7,00206$
      00A6AD 80 01            [24]  928 	sjmp	00118$
      00A6AF                        929 00206$:
      00A6AF                        930 00112$:
      00A6AF 22               [24]  931 	ret
      00A6B0                        932 00118$:
                                    933 ;	quantum/repeat_key.c:127: registered_record.event = *event;
      00A6B0 90 0C 70         [24]  934 	mov	dptr,#_repeat_invoke_event_10000_182
      00A6B3 12 53 8D         [24]  935 	lcall	_ak820_outline_0013
      00A6B6 90 0D E2         [24]  936 	mov	dptr,#___memcpy_PARM_2
      00A6B9 ED               [12]  937 	mov	a,r5
      00A6BA 12 38 1E         [24]  938 	lcall	_ak820_outline_0017
      00A6BD 90 0D E5         [24]  939 	mov	dptr,#___memcpy_PARM_3
      00A6C0 12 7B 0F         [24]  940 	lcall	_ak820_outline_0117
      00A6C3 90 0C 5D         [24]  941 	mov	dptr,#_registered_record
      00A6C6 F5 F0            [12]  942 	mov	b,a
      00A6C8 12 BC AA         [24]  943 	lcall	___memcpy
                                    944 ;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
      00A6CB 90 0C 66         [24]  945 	mov	dptr,#_registered_repeat_count
      00A6CE E0               [24]  946 	movx	a,@dptr
      00A6CF 90 0E 64         [24]  947 	mov	dptr,#_processing_repeat_count
      00A6D2 F0               [24]  948 	movx	@dptr,a
                                    949 ;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
      00A6D3 90 0C 5C         [24]  950 	mov	dptr,#_ak820_repeat_invoking
      00A6D6 74 01            [12]  951 	mov	a,#0x01
      00A6D8 F0               [24]  952 	movx	@dptr,a
                                    953 ;	quantum/repeat_key.c:132: process_record(&registered_record);
      00A6D9 90 0C 5D         [24]  954 	mov	dptr,#_registered_record
      00A6DC 12 74 F6         [24]  955 	lcall	_process_record
                                    956 ;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
      00A6DF 90 0C 5C         [24]  957 	mov	dptr,#_ak820_repeat_invoking
      00A6E2 E4               [12]  958 	clr	a
      00A6E3 F0               [24]  959 	movx	@dptr,a
                                    960 ;	quantum/repeat_key.c:136: processing_repeat_count = 0;
      00A6E4 90 0E 64         [24]  961 	mov	dptr,#_processing_repeat_count
      00A6E7 F0               [24]  962 	movx	@dptr,a
                                    963 ;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
      00A6E8 90 0C 62         [24]  964 	mov	dptr,#(_registered_record + 0x0005)
      00A6EB E0               [24]  965 	movx	a,@dptr
      00A6EC 70 0F            [24]  966 	jnz	00121$
                                    967 ;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
      00A6EE 90 0C 67         [24]  968 	mov	dptr,#_registered_mods
      00A6F1 E0               [24]  969 	movx	a,@dptr
      00A6F2 F5 82            [12]  970 	mov	dpl,a
      00A6F4 12 7A 84         [24]  971 	lcall	_unregister_weak_mods
                                    972 ;	quantum/repeat_key.c:144: registered_record.keycode = 0;
      00A6F7 90 0C 64         [24]  973 	mov	dptr,#(_registered_record + 0x0007)
      00A6FA 12 53 D5         [24]  974 	lcall	_ak820_outline_0173
      00A6FD                        975 00121$:
                                    976 ;	quantum/repeat_key.c:146: }
      00A6FD 22               [24]  977 	ret
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    980 ;------------------------------------------------------------
                                    981 ;event         Allocated with name '_repeat_key_invoke_event_10000_197'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t* event) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function repeat_key_invoke
                                    986 ;	-----------------------------------------
      00A6FE                        987 _repeat_key_invoke:
      00A6FE 12 43 11         [24]  988 	lcall	_ak820_outline_0037
      00A701 90 0C 73         [24]  989 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A704 12 38 1E         [24]  990 	lcall	_ak820_outline_0017
                                    991 ;	quantum/repeat_key.c:149: repeat_invoke(event, false);
      00A707 90 0C 73         [24]  992 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A70A 12 53 8D         [24]  993 	lcall	_ak820_outline_0013
      00A70D 90 0C 6F         [24]  994 	mov	dptr,#_repeat_invoke_PARM_2
      00A710 E4               [12]  995 	clr	a
      00A711 F0               [24]  996 	movx	@dptr,a
      00A712 12 53 96         [24]  997 	lcall	_ak820_outline_0048
                                    998 ;	quantum/repeat_key.c:150: }
      00A715 A1 E7            [12]  999 	ajmp	_repeat_invoke
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'find_alt_keycode'
                                   1002 ;------------------------------------------------------------
                                   1003 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                   1004 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                   1005 ;table         Allocated with name '_find_alt_keycode_table_10000_199'
                                   1006 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
                                   1007 ;i             Allocated with name '_find_alt_keycode_i_20000_201'
                                   1008 ;------------------------------------------------------------
                                   1009 ;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1010 ;	-----------------------------------------
                                   1011 ;	 function find_alt_keycode
                                   1012 ;	-----------------------------------------
      00A717                       1013 _find_alt_keycode:
      00A717 12 43 11         [24] 1014 	lcall	_ak820_outline_0037
      00A71A 90 0C 78         [24] 1015 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A71D 12 38 1E         [24] 1016 	lcall	_ak820_outline_0017
                                   1017 ;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
      00A720 90 0C 78         [24] 1018 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A723 12 53 8D         [24] 1019 	lcall	_ak820_outline_0013
                                   1020 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A726 7C 00            [12] 1021 	mov	r4,#0x00
      00A728                       1022 00105$:
      00A728 90 0C 76         [24] 1023 	mov	dptr,#_find_alt_keycode_PARM_2
      00A72B E0               [24] 1024 	movx	a,@dptr
      00A72C FB               [12] 1025 	mov	r3,a
      00A72D C3               [12] 1026 	clr	c
      00A72E EC               [12] 1027 	mov	a,r4
      00A72F 9B               [12] 1028 	subb	a,r3
      00A730 50 1E            [24] 1029 	jnc	00103$
                                   1030 ;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
      00A732 EC               [12] 1031 	mov	a,r4
      00A733 12 91 D3         [24] 1032 	lcall	_ak820_outline_0027
      00A736 12 BE 6D         [24] 1033 	lcall	__gptrget
      00A739 F9               [12] 1034 	mov	r1,a
      00A73A 90 0C 77         [24] 1035 	mov	dptr,#_find_alt_keycode_PARM_3
      00A73D E0               [24] 1036 	movx	a,@dptr
      00A73E B5 01 0C         [24] 1037 	cjne	a,ar1,00106$
                                   1038 ;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
      00A741 74 01            [12] 1039 	mov	a,#0x01
      00A743 6C               [12] 1040 	xrl	a,r4
      00A744 12 91 D3         [24] 1041 	lcall	_ak820_outline_0027
      00A747 12 BE 6D         [24] 1042 	lcall	__gptrget
      00A74A F5 82            [12] 1043 	mov	dpl,a
      00A74C 22               [24] 1044 	ret
      00A74D                       1045 00106$:
                                   1046 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A74D 0C               [12] 1047 	inc	r4
      00A74E 80 D8            [24] 1048 	sjmp	00105$
      00A750                       1049 00103$:
                                   1050 ;	quantum/repeat_key.c:174: return KC_NO;
      00A750 75 82 00         [24] 1051 	mov	dpl, #0x00
                                   1052 ;	quantum/repeat_key.c:175: }
      00A753 22               [24] 1053 	ret
                                   1054 ;------------------------------------------------------------
                                   1055 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1056 ;------------------------------------------------------------
                                   1057 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
                                   1058 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
                                   1059 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
                                   1060 ;------------------------------------------------------------
                                   1061 ;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
                                   1062 ;	-----------------------------------------
                                   1063 ;	 function get_alt_repeat_key_keycode
                                   1064 ;	-----------------------------------------
      00A754                       1065 _get_alt_repeat_key_keycode:
                                   1066 ;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
      00A754 90 0C 5A         [24] 1067 	mov	dptr,#(_last_record + 0x0007)
      00A757 12 38 36         [24] 1068 	lcall	_ak820_outline_0054
      00A75A 90 0C 7B         [24] 1069 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A75D 12 4D 34         [24] 1070 	lcall	_ak820_outline_0061
                                   1071 ;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
      00A760 90 0E 62         [24] 1072 	mov	dptr,#_last_mods
      00A763 E0               [24] 1073 	movx	a,@dptr
      00A764 FD               [12] 1074 	mov	r5,a
      00A765 90 0C 7D         [24] 1075 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A768 F0               [24] 1076 	movx	@dptr,a
                                   1077 ;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      00A769 90 0C 83         [24] 1078 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      00A76C ED               [12] 1079 	mov	a,r5
      00A76D 12 43 35         [24] 1080 	lcall	_ak820_outline_0062
      00A770 C0 07            [24] 1081 	push	ar7
      00A772 C0 06            [24] 1082 	push	ar6
      00A774 12 A8 85         [24] 1083 	lcall	_get_alt_repeat_key_keycode_user
      00A777 12 38 AD         [24] 1084 	lcall	_ak820_outline_0149
      00A77A D0 06            [24] 1085 	pop	ar6
      00A77C D0 07            [24] 1086 	pop	ar7
                                   1087 ;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
      00A77E 8C 02            [24] 1088 	mov	ar2,r4
      00A780 8D 03            [24] 1089 	mov	ar3,r5
      00A782 BA 01 05         [24] 1090 	cjne	r2,#0x01,00176$
      00A785 BB 00 02         [24] 1091 	cjne	r3,#0x00,00176$
      00A788 80 04            [24] 1092 	sjmp	00102$
      00A78A                       1093 00176$:
                                   1094 ;	quantum/repeat_key.c:186: return alt_keycode;
      00A78A 12 38 99         [24] 1095 	lcall	_ak820_outline_0127
      00A78D 22               [24] 1096 	ret
      00A78E                       1097 00102$:
                                   1098 ;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      00A78E 90 0C 7D         [24] 1099 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A791 E0               [24] 1100 	movx	a,@dptr
      00A792 54 F0            [12] 1101 	anl	a,#0xf0
      00A794 60 02            [24] 1102 	jz	00118$
      00A796 74 10            [12] 1103 	mov	a,#0x10
      00A798                       1104 00118$:
      00A798 FD               [12] 1105 	mov	r5,a
                                   1106 ;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
      00A799 90 0C 7D         [24] 1107 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A79C E0               [24] 1108 	movx	a,@dptr
      00A79D FC               [12] 1109 	mov	r4,a
      00A79E C4               [12] 1110 	swap	a
      00A79F 54 0F            [12] 1111 	anl	a,#0x0f
      00A7A1 4C               [12] 1112 	orl	a,r4
      00A7A2 54 0F            [12] 1113 	anl	a,#0x0f
      00A7A4 4D               [12] 1114 	orl	a,r5
      00A7A5 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      00A7A6 8E 04            [24] 1117 	mov	ar4,r6
      00A7A8 8F 05            [24] 1118 	mov	ar5,r7
      00A7AA 74 FF            [12] 1119 	mov	a,#0x100 - 0x01
      00A7AC 2D               [12] 1120 	add	a,r5
      00A7AD 50 1C            [24] 1121 	jnc	00115$
      00A7AF C3               [12] 1122 	clr	c
      00A7B0 74 FF            [12] 1123 	mov	a,#0xff
      00A7B2 9C               [12] 1124 	subb	a,r4
      00A7B3 74 1F            [12] 1125 	mov	a,#0x1f
      00A7B5 9D               [12] 1126 	subb	a,r5
      00A7B6 40 13            [24] 1127 	jc	00115$
                                   1128 ;	free result
                                   1129 ;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
      00A7B8 8F 06            [24] 1130 	mov	ar6,r7
      00A7BA 53 06 1F         [24] 1131 	anl	ar6,#0x1f
      00A7BD 90 0C 7D         [24] 1132 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A7C0 E0               [24] 1133 	movx	a,@dptr
      00A7C1 4E               [12] 1134 	orl	a,r6
      00A7C2 F0               [24] 1135 	movx	@dptr,a
                                   1136 ;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      00A7C3 7D 00            [12] 1137 	mov	r5,#0x00
      00A7C5 90 0C 7B         [24] 1138 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A7C8 12 38 53         [24] 1139 	lcall	_ak820_outline_0073
                                   1140 ;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
      00A7CB                       1141 00115$:
      00A7CB 90 0C 7B         [24] 1142 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A7CE 12 4C E3         [24] 1143 	lcall	_ak820_outline_0010
      00A7D1 12 48 2F         [24] 1144 	lcall	_ak820_outline_0115
      00A7D4 50 03            [24] 1145 	jnc	00180$
      00A7D6 02 A8 66         [24] 1146 	ljmp	00114$
      00A7D9                       1147 00180$:
                                   1148 ;	free result
                                   1149 ;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      00A7D9 90 0C 7D         [24] 1150 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A7DC E0               [24] 1151 	movx	a,@dptr
      00A7DD 54 0D            [12] 1152 	anl	a,#0x0d
      00A7DF 60 21            [24] 1153 	jz	00107$
                                   1154 ;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A7E1 8E 05            [24] 1155 	mov	ar5,r6
      00A7E3 90 0C 76         [24] 1156 	mov	dptr,#_find_alt_keycode_PARM_2
      00A7E6 74 0A            [12] 1157 	mov	a,#0x0a
      00A7E8 F0               [24] 1158 	movx	@dptr,a
      00A7E9 90 0C 77         [24] 1159 	mov	dptr,#_find_alt_keycode_PARM_3
      00A7EC ED               [12] 1160 	mov	a,r5
      00A7ED F0               [24] 1161 	movx	@dptr,a
      00A7EE 90 C2 54         [24] 1162 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
      00A7F1 75 F0 80         [24] 1163 	mov	b, #0x80
      00A7F4 12 A7 17         [24] 1164 	lcall	_find_alt_keycode
      00A7F7 AD 82            [24] 1165 	mov	r5, dpl
      00A7F9 90 0C 7E         [24] 1166 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A7FC ED               [12] 1167 	mov	a,r5
      00A7FD 12 38 9E         [24] 1168 	lcall	_ak820_outline_0128
      00A800 80 1D            [24] 1169 	sjmp	00108$
      00A802                       1170 00107$:
                                   1171 ;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A802 90 0C 76         [24] 1172 	mov	dptr,#_find_alt_keycode_PARM_2
      00A805 74 08            [12] 1173 	mov	a,#0x08
      00A807 F0               [24] 1174 	movx	@dptr,a
      00A808 90 0C 77         [24] 1175 	mov	dptr,#_find_alt_keycode_PARM_3
      00A80B EE               [12] 1176 	mov	a,r6
      00A80C F0               [24] 1177 	movx	@dptr,a
      00A80D 90 C2 5E         [24] 1178 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      00A810 75 F0 80         [24] 1179 	mov	b, #0x80
      00A813 12 A7 17         [24] 1180 	lcall	_find_alt_keycode
      00A816 AF 82            [24] 1181 	mov	r7, dpl
      00A818 90 0C 7E         [24] 1182 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A81B EF               [12] 1183 	mov	a,r7
      00A81C 12 38 9E         [24] 1184 	lcall	_ak820_outline_0128
      00A81F                       1185 00108$:
                                   1186 ;	quantum/repeat_key.c:246: if (!alt_keycode) {
      00A81F 90 0C 7E         [24] 1187 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A822 12 71 C3         [24] 1188 	lcall	_ak820_outline_0039
      00A825 70 22            [24] 1189 	jnz	00110$
                                   1190 ;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A827 90 0C 7B         [24] 1191 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A82A E0               [24] 1192 	movx	a,@dptr
      00A82B FF               [12] 1193 	mov	r7,a
      00A82C 90 0C 76         [24] 1194 	mov	dptr,#_find_alt_keycode_PARM_2
      00A82F 74 16            [12] 1195 	mov	a,#0x16
      00A831 F0               [24] 1196 	movx	@dptr,a
      00A832 90 0C 77         [24] 1197 	mov	dptr,#_find_alt_keycode_PARM_3
      00A835 EF               [12] 1198 	mov	a,r7
      00A836 F0               [24] 1199 	movx	@dptr,a
      00A837 90 C2 66         [24] 1200 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
      00A83A 75 F0 80         [24] 1201 	mov	b, #0x80
      00A83D 12 A7 17         [24] 1202 	lcall	_find_alt_keycode
      00A840 AF 82            [24] 1203 	mov	r7, dpl
      00A842 90 0C 7E         [24] 1204 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A845 EF               [12] 1205 	mov	a,r7
      00A846 12 38 9E         [24] 1206 	lcall	_ak820_outline_0128
      00A849                       1207 00110$:
                                   1208 ;	quantum/repeat_key.c:274: if (alt_keycode) {
      00A849 90 0C 7E         [24] 1209 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A84C 12 38 36         [24] 1210 	lcall	_ak820_outline_0054
      00A84F 90 0C 7E         [24] 1211 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A852 12 71 C3         [24] 1212 	lcall	_ak820_outline_0039
      00A855 60 0F            [24] 1213 	jz	00114$
                                   1214 ;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
      00A857 90 0C 7D         [24] 1215 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A85A E0               [24] 1216 	movx	a,@dptr
      00A85B FD               [12] 1217 	mov	r5,a
      00A85C E4               [12] 1218 	clr	a
      00A85D 42 06            [12] 1219 	orl	ar6,a
      00A85F ED               [12] 1220 	mov	a,r5
      00A860 42 07            [12] 1221 	orl	ar7,a
      00A862 12 38 94         [24] 1222 	lcall	_ak820_outline_0123
      00A865 22               [24] 1223 	ret
      00A866                       1224 00114$:
                                   1225 ;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
      00A866 90 00 00         [24] 1226 	mov	dptr,#0x0000
                                   1227 ;	quantum/repeat_key.c:281: }
      00A869 22               [24] 1228 	ret
                                   1229 ;------------------------------------------------------------
                                   1230 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1231 ;------------------------------------------------------------
                                   1232 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t* event) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function alt_repeat_key_invoke
                                   1237 ;	-----------------------------------------
      00A86A                       1238 _alt_repeat_key_invoke:
      00A86A 12 43 11         [24] 1239 	lcall	_ak820_outline_0037
      00A86D 90 0C 80         [24] 1240 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A870 12 38 1E         [24] 1241 	lcall	_ak820_outline_0017
                                   1242 ;	quantum/repeat_key.c:285: repeat_invoke(event, true);
      00A873 90 0C 80         [24] 1243 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A876 12 53 8D         [24] 1244 	lcall	_ak820_outline_0013
      00A879 90 0C 6F         [24] 1245 	mov	dptr,#_repeat_invoke_PARM_2
      00A87C 74 01            [12] 1246 	mov	a,#0x01
      00A87E F0               [24] 1247 	movx	@dptr,a
      00A87F 12 53 96         [24] 1248 	lcall	_ak820_outline_0048
                                   1249 ;	quantum/repeat_key.c:286: }
      00A882 02 A5 E7         [24] 1250 	ljmp	_repeat_invoke
                                   1251 ;------------------------------------------------------------
                                   1252 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1253 ;------------------------------------------------------------
                                   1254 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1255 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
                                   1256 ;------------------------------------------------------------
                                   1257 ;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1258 ;	-----------------------------------------
                                   1259 ;	 function get_alt_repeat_key_keycode_user
                                   1260 ;	-----------------------------------------
      00A885                       1261 _get_alt_repeat_key_keycode_user:
                                   1262 ;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
      00A885 90 00 01         [24] 1263 	mov	dptr,#0x0001
                                   1264 ;	quantum/repeat_key.c:291: }
      00A888 22               [24] 1265 	ret
                                   1266 	.area CSEG    (CODE)
                                   1267 	.area CONST   (CODE)
                                   1268 	.area CONST   (CODE)
      00C254                       1269 _get_alt_repeat_key_keycode_pairs_50000_214:
      00C254 09                    1270 	.db #0x09	; 9
      00C255 05                    1271 	.db #0x05	; 5
      00C256 07                    1272 	.db #0x07	; 7
      00C257 18                    1273 	.db #0x18	; 24
      00C258 11                    1274 	.db #0x11	; 17
      00C259 13                    1275 	.db #0x13	; 19
      00C25A 04                    1276 	.db #0x04	; 4
      00C25B 08                    1277 	.db #0x08	; 8
      00C25C 12                    1278 	.db #0x12	; 18
      00C25D 0C                    1279 	.db #0x0c	; 12
                                   1280 	.area CSEG    (CODE)
                                   1281 	.area CONST   (CODE)
      00C25E                       1282 _get_alt_repeat_key_keycode_pairs_50000_215:
      00C25E 0D                    1283 	.db #0x0d	; 13
      00C25F 0E                    1284 	.db #0x0e	; 14
      00C260 0B                    1285 	.db #0x0b	; 11
      00C261 0F                    1286 	.db #0x0f	; 15
      00C262 1A                    1287 	.db #0x1a	; 26
      00C263 05                    1288 	.db #0x05	; 5
      00C264 08                    1289 	.db #0x08	; 8
      00C265 05                    1290 	.db #0x05	; 5
                                   1291 	.area CSEG    (CODE)
                                   1292 	.area CONST   (CODE)
      00C266                       1293 _get_alt_repeat_key_keycode_pairs_50000_217:
      00C266 50                    1294 	.db #0x50	; 80	'P'
      00C267 4F                    1295 	.db #0x4f	; 79	'O'
      00C268 52                    1296 	.db #0x52	; 82	'R'
      00C269 51                    1297 	.db #0x51	; 81	'Q'
      00C26A 4A                    1298 	.db #0x4a	; 74	'J'
      00C26B 4D                    1299 	.db #0x4d	; 77	'M'
      00C26C 4B                    1300 	.db #0x4b	; 75	'K'
      00C26D 4E                    1301 	.db #0x4e	; 78	'N'
      00C26E 2A                    1302 	.db #0x2a	; 42
      00C26F 4C                    1303 	.db #0x4c	; 76	'L'
      00C270 2F                    1304 	.db #0x2f	; 47
      00C271 30                    1305 	.db #0x30	; 48	'0'
      00C272 B6                    1306 	.db #0xb6	; 182
      00C273 B7                    1307 	.db #0xb7	; 183
      00C274 AB                    1308 	.db #0xab	; 171
      00C275 AC                    1309 	.db #0xac	; 172
      00C276 BB                    1310 	.db #0xbb	; 187
      00C277 BC                    1311 	.db #0xbc	; 188
      00C278 A9                    1312 	.db #0xa9	; 169
      00C279 AA                    1313 	.db #0xaa	; 170
      00C27A BD                    1314 	.db #0xbd	; 189
      00C27B BE                    1315 	.db #0xbe	; 190
                                   1316 	.area CSEG    (CODE)
                                   1317 	.area XINIT   (CODE)
      00C6DE                       1318 __xinit__last_mods:
      00C6DE 00                    1319 	.db #0x00	; 0
      00C6DF                       1320 __xinit__last_repeat_count:
      00C6DF 00                    1321 	.db #0x00	;  0
      00C6E0                       1322 __xinit__processing_repeat_count:
      00C6E0 00                    1323 	.db #0x00	;  0
                                   1324 	.area CABS    (ABS,CODE)
                                   1325 
                                   1326 ; Experimental exact instruction outlining.
                                   1327 	.globl _ak820_outline_0010
                                   1328 	.globl _ak820_outline_0013
                                   1329 	.globl _ak820_outline_0017
                                   1330 	.globl _ak820_outline_0027
                                   1331 	.globl _ak820_outline_0028
                                   1332 	.globl _ak820_outline_0037
                                   1333 	.globl _ak820_outline_0039
                                   1334 	.globl _ak820_outline_0048
                                   1335 	.globl _ak820_outline_0054
                                   1336 	.globl _ak820_outline_0061
                                   1337 	.globl _ak820_outline_0062
                                   1338 	.globl _ak820_outline_0073
                                   1339 	.globl _ak820_outline_0085
                                   1340 	.globl _ak820_outline_0108
                                   1341 	.globl _ak820_outline_0109
                                   1342 	.globl _ak820_outline_0115
                                   1343 	.globl _ak820_outline_0117
                                   1344 	.globl _ak820_outline_0123
                                   1345 	.globl _ak820_outline_0127
                                   1346 	.globl _ak820_outline_0128
                                   1347 	.globl _ak820_outline_0149
                                   1348 	.globl _ak820_outline_0173
                                   1349 	.globl _ak820_outline_0176
                                   1350 	.globl _ak820_outline_0194
                                   1351 
                                   1352 	.area CSEG (CODE)
                                   1353 ; function ak820_outline_0176
      00A889                       1354 _ak820_outline_0176:
      00A889 90 0C 64         [24] 1355 	mov	dptr,#(_registered_record+0x0007)
      00A88C E0               [24] 1356 	movx	a,@dptr
      00A88D FB               [12] 1357 	mov	r3,a
      00A88E A3               [24] 1358 	inc	dptr
      00A88F E0               [24] 1359 	movx	a,@dptr
      00A890 4B               [12] 1360 	orl	a,r3
      00A891 22               [24] 1361 	ret
