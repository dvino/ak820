                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_tap_code_delay
                                     12 	.globl _ak820_settings_reset
                                     13 	.globl _ak820_settings_set
                                     14 	.globl _ak820_settings_get
                                     15 	.globl _ak820_settings_query
                                     16 	.globl _ak820_settings_init
                                     17 	.globl _unregister_code16
                                     18 	.globl _register_code16
                                     19 	.globl _matrix_is_on
                                     20 	.globl _dynamic_keymap_set_combo
                                     21 	.globl _dynamic_keymap_get_combo
                                     22 	.globl _dynamic_keymap_set_encoder
                                     23 	.globl _dynamic_keymap_get_encoder
                                     24 	.globl _repeat_key_cancel
                                     25 	.globl _ak820_combo_reload
                                     26 	.globl _clear_keyboard
                                     27 	.globl _ak820_action_exec
                                     28 	.globl _timer_elapsed32
                                     29 	.globl _timer_read32
                                     30 	.globl _timer_read
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _ADC_START
                                     34 	.globl _S0_R_FIFO
                                     35 	.globl _S0_T_FIFO
                                     36 	.globl _S0_FREE
                                     37 	.globl _S0_IF_BYTE
                                     38 	.globl _S0_IF_FIRST
                                     39 	.globl _S0_IF_OV
                                     40 	.globl _S0_FST_ACT
                                     41 	.globl _CP_RL2
                                     42 	.globl _C_T2
                                     43 	.globl _TR2
                                     44 	.globl _EXEN2
                                     45 	.globl _TCLK
                                     46 	.globl _RCLK
                                     47 	.globl _EXF2
                                     48 	.globl _CAP1F
                                     49 	.globl _TF2
                                     50 	.globl _RI
                                     51 	.globl _TI
                                     52 	.globl _RB8
                                     53 	.globl _TB8
                                     54 	.globl _REN
                                     55 	.globl _SM2
                                     56 	.globl _SM1
                                     57 	.globl _SM0
                                     58 	.globl _IT0
                                     59 	.globl _IE0
                                     60 	.globl _IT1
                                     61 	.globl _IE1
                                     62 	.globl _TR0
                                     63 	.globl _TF0
                                     64 	.globl _TR1
                                     65 	.globl _TF1
                                     66 	.globl _P4_0
                                     67 	.globl _P4_1
                                     68 	.globl _P4_2
                                     69 	.globl _P4_3
                                     70 	.globl _P4_4
                                     71 	.globl _P4_5
                                     72 	.globl _P4_6
                                     73 	.globl _RXD
                                     74 	.globl _TXD
                                     75 	.globl _INT0
                                     76 	.globl _INT1
                                     77 	.globl _T0
                                     78 	.globl _T1
                                     79 	.globl _MOSI1
                                     80 	.globl _MISO1
                                     81 	.globl _SCK1
                                     82 	.globl _P3_0
                                     83 	.globl _P3_1
                                     84 	.globl _P3_2
                                     85 	.globl _P3_3
                                     86 	.globl _P3_4
                                     87 	.globl _P3_5
                                     88 	.globl _P3_6
                                     89 	.globl _P3_7
                                     90 	.globl _CAP1_
                                     91 	.globl _T2_
                                     92 	.globl _CAP2_
                                     93 	.globl _T2EX_
                                     94 	.globl _RXD1
                                     95 	.globl _TXD1
                                     96 	.globl _P2_0
                                     97 	.globl _P2_1
                                     98 	.globl _P2_2
                                     99 	.globl _P2_3
                                    100 	.globl _P2_4
                                    101 	.globl _P2_5
                                    102 	.globl _P2_6
                                    103 	.globl _P2_7
                                    104 	.globl _AIN0
                                    105 	.globl _AIN1
                                    106 	.globl _AIN2
                                    107 	.globl _AIN3
                                    108 	.globl _AIN4
                                    109 	.globl _AIN5
                                    110 	.globl _AIN6
                                    111 	.globl _AIN7
                                    112 	.globl _CAP1
                                    113 	.globl _T2
                                    114 	.globl _CAP2
                                    115 	.globl _T2EX
                                    116 	.globl _INT0_
                                    117 	.globl _SCS
                                    118 	.globl _MOSI
                                    119 	.globl _MISO
                                    120 	.globl _SCK
                                    121 	.globl _RXD1_
                                    122 	.globl _TXD1_
                                    123 	.globl _P1_0
                                    124 	.globl _P1_1
                                    125 	.globl _P1_2
                                    126 	.globl _P1_3
                                    127 	.globl _P1_4
                                    128 	.globl _P1_5
                                    129 	.globl _P1_6
                                    130 	.globl _P1_7
                                    131 	.globl _AIN8
                                    132 	.globl _AIN9
                                    133 	.globl _AIN10
                                    134 	.globl _AIN11
                                    135 	.globl _AIN12
                                    136 	.globl _AIN13
                                    137 	.globl _RXD_
                                    138 	.globl _TXD_
                                    139 	.globl _SCL0
                                    140 	.globl _SDA0
                                    141 	.globl _P0_0
                                    142 	.globl _P0_1
                                    143 	.globl _P0_2
                                    144 	.globl _P0_3
                                    145 	.globl _P0_4
                                    146 	.globl _P0_5
                                    147 	.globl _P0_6
                                    148 	.globl _P0_7
                                    149 	.globl _IE_SPI0
                                    150 	.globl _IE_USB
                                    151 	.globl _IE_ADC
                                    152 	.globl _IE_UART1
                                    153 	.globl _IE_PWM_I2C
                                    154 	.globl _IE_GPIO
                                    155 	.globl _IE_WDOG
                                    156 	.globl _PX0
                                    157 	.globl _PT0
                                    158 	.globl _PX1
                                    159 	.globl _PT1
                                    160 	.globl _PS
                                    161 	.globl _PT2
                                    162 	.globl _PL_FLAG
                                    163 	.globl _PH_FLAG
                                    164 	.globl _EX0
                                    165 	.globl _ET0
                                    166 	.globl _EX1
                                    167 	.globl _ET1
                                    168 	.globl _ES
                                    169 	.globl _ET2
                                    170 	.globl _E_DIS
                                    171 	.globl _EA
                                    172 	.globl _P
                                    173 	.globl _F1
                                    174 	.globl _OV
                                    175 	.globl _RS0
                                    176 	.globl _RS1
                                    177 	.globl _F0
                                    178 	.globl _AC
                                    179 	.globl _CY
                                    180 	.globl _I2CS_INT_ST
                                    181 	.globl _I2CX_INT
                                    182 	.globl _LED_STATUS
                                    183 	.globl _LED_DMA_H
                                    184 	.globl _LED_DMA_L
                                    185 	.globl _LED_DMA
                                    186 	.globl _LED_PWM_OE
                                    187 	.globl _LED_COMMON
                                    188 	.globl _ADC_CHAN
                                    189 	.globl _ADC_DAT_H
                                    190 	.globl _ADC_DAT_L
                                    191 	.globl _ADC_DAT
                                    192 	.globl _ADC_CTRL
                                    193 	.globl _SPI1_CK_SE
                                    194 	.globl _SPI1_CTRL
                                    195 	.globl _SPI1_DATA
                                    196 	.globl _SPI1_STAT
                                    197 	.globl _SIF1
                                    198 	.globl _SBAUD1
                                    199 	.globl _SBUF1
                                    200 	.globl _SCON1
                                    201 	.globl _SPI0_SETUP
                                    202 	.globl _SPI0_CK_SE
                                    203 	.globl _SPI0_CTRL
                                    204 	.globl _SPI0_DATA
                                    205 	.globl _SPI0_STAT
                                    206 	.globl _T2CAP1H
                                    207 	.globl _T2CAP1L
                                    208 	.globl _T2CAP1
                                    209 	.globl _TH2
                                    210 	.globl _TL2
                                    211 	.globl _T2COUNT
                                    212 	.globl _RCAP2H
                                    213 	.globl _RCAP2L
                                    214 	.globl _RCAP2
                                    215 	.globl _T2MOD
                                    216 	.globl _T2CON
                                    217 	.globl _SBUF
                                    218 	.globl _SCON
                                    219 	.globl _TH1
                                    220 	.globl _TH0
                                    221 	.globl _TL1
                                    222 	.globl _TL0
                                    223 	.globl _TMOD
                                    224 	.globl _TCON
                                    225 	.globl _XBUS_AUX
                                    226 	.globl _P7
                                    227 	.globl _P6_DIR
                                    228 	.globl _P6_OUT_PU
                                    229 	.globl _P6_IN
                                    230 	.globl _P5_DIR
                                    231 	.globl _P5_OUT_PU
                                    232 	.globl _P5_IN
                                    233 	.globl _P4_LED_KEY
                                    234 	.globl _P4_DIR_PU
                                    235 	.globl _P4_MOD_OC
                                    236 	.globl _P4
                                    237 	.globl _P3_DIR_PU
                                    238 	.globl _P3_MOD_OC
                                    239 	.globl _P3
                                    240 	.globl _P2_DIR_PU
                                    241 	.globl _P2_MOD_OC
                                    242 	.globl _P2
                                    243 	.globl _P1_DIR_PU
                                    244 	.globl _P1_MOD_OC
                                    245 	.globl _P1
                                    246 	.globl _P0_DIR_PU
                                    247 	.globl _P0_MOD_OC
                                    248 	.globl _P0
                                    249 	.globl _ROM_CTRL
                                    250 	.globl _ROM_DATA_HH
                                    251 	.globl _ROM_DATA_HL
                                    252 	.globl _ROM_DATA_HI
                                    253 	.globl _ROM_ADDR_H
                                    254 	.globl _ROM_ADDR_L
                                    255 	.globl _ROM_ADDR
                                    256 	.globl _GPIO_IE
                                    257 	.globl _IP_EX
                                    258 	.globl _IE_EX
                                    259 	.globl _IP
                                    260 	.globl _IE
                                    261 	.globl _WDOG_COUNT
                                    262 	.globl _RESET_KEEP
                                    263 	.globl _WAKE_CTRL
                                    264 	.globl _CLOCK_CFG
                                    265 	.globl _POWER_CFG
                                    266 	.globl _PCON
                                    267 	.globl _GLOBAL_CFG
                                    268 	.globl _SAFE_MOD
                                    269 	.globl _DPH
                                    270 	.globl _DPL
                                    271 	.globl _SP
                                    272 	.globl _A_INV
                                    273 	.globl _B
                                    274 	.globl _ACC
                                    275 	.globl _PSW
                                    276 	.globl _vial_unlock_in_progress
                                    277 	.globl _vial_unlocked
                                    278 	.globl _g_vial_magic_keycode_override
                                    279 	.globl _vial_handle_cmd_PARM_2
                                    280 	.globl _vial_unlock_task
                                    281 	.globl _vial_init
                                    282 	.globl _vial_handle_cmd
                                    283 	.globl _vial_keycode_down
                                    284 	.globl _vial_keycode_up
                                    285 	.globl _vial_keycode_tap
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000042                        548 _vial_handle_cmd_sloc0_1_0:
      000042                        549 	.ds 2
      000044                        550 _vial_handle_cmd_sloc1_1_0:
      000044                        551 	.ds 2
      000046                        552 _vial_handle_cmd_sloc2_1_0:
      000046                        553 	.ds 2
      000048                        554 _vial_handle_cmd_sloc3_1_0:
      000048                        555 	.ds 2
                                    556 ;--------------------------------------------------------
                                    557 ; overlayable items in internal ram
                                    558 ;--------------------------------------------------------
                                    559 ;--------------------------------------------------------
                                    560 ; indirectly addressable internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area ISEG    (DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; absolute internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area IABS    (ABS,DATA)
                                    567 	.area IABS    (ABS,DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; bit data
                                    570 ;--------------------------------------------------------
                                    571 	.area BSEG    (BIT)
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000C98                        580 _vial_unlock_timer:
      000C98                        581 	.ds 4
      000C9C                        582 _vial_unlock_holding:
      000C9C                        583 	.ds 1
      000C9D                        584 _vial_keycode_firewall_in_10000_633:
      000C9D                        585 	.ds 2
      000C9F                        586 _vial_fill_packet_PARM_2:
      000C9F                        587 	.ds 1
      000CA0                        588 _vial_fill_packet_msg_10000_636:
      000CA0                        589 	.ds 2
      000CA2                        590 _vial_handle_cmd_PARM_2:
      000CA2                        591 	.ds 1
      000CA3                        592 _vial_handle_cmd_data_10000_641:
      000CA3                        593 	.ds 3
      000CA6                        594 _vial_handle_cmd_entry_70000_672:
      000CA6                        595 	.ds 10
      000CB0                        596 _vial_handle_cmd_entry_70000_673:
      000CB0                        597 	.ds 10
      000CBA                        598 _g_vial_magic_keycode_override::
      000CBA                        599 	.ds 2
      000CBC                        600 _vial_keycode_down_keycode_10000_675:
      000CBC                        601 	.ds 2
      000CBE                        602 _vial_keycode_down_dummy_event_30000_682:
      000CBE                        603 	.ds 6
      000CC4                        604 _vial_keycode_up_keycode_10000_683:
      000CC4                        605 	.ds 2
      000CC6                        606 _vial_keycode_up_dummy_event_30000_690:
      000CC6                        607 	.ds 6
      000CCC                        608 _vial_keycode_tap_keycode_10000_691:
      000CCC                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
      000E6A                        618 _vial_unlocked::
      000E6A                        619 	.ds 1
      000E6B                        620 _vial_unlock_in_progress::
      000E6B                        621 	.ds 1
      000E6C                        622 _vial_unlock_counter:
      000E6C                        623 	.ds 1
      000E6D                        624 _vial_unlock_combo_rows:
      000E6D                        625 	.ds 2
      000E6F                        626 _vial_unlock_combo_cols:
      000E6F                        627 	.ds 2
                                    628 	.area HOME    (CODE)
                                    629 	.area GSINIT0 (CODE)
                                    630 	.area GSINIT1 (CODE)
                                    631 	.area GSINIT2 (CODE)
                                    632 	.area GSINIT3 (CODE)
                                    633 	.area GSINIT4 (CODE)
                                    634 	.area GSINIT5 (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area CSEG    (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; global & static initialisations
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area GSINIT  (CODE)
                                    643 	.area GSFINAL (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 ;--------------------------------------------------------
                                    646 ; Home
                                    647 ;--------------------------------------------------------
                                    648 	.area HOME    (CODE)
                                    649 	.area HOME    (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; code
                                    652 ;--------------------------------------------------------
                                    653 	.area CSEG    (CODE)
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    656 ;------------------------------------------------------------
                                    657 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    658 ;------------------------------------------------------------
                                    659 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    660 ;	-----------------------------------------
                           000007   661 	ar7 = 0x07
                           000006   662 	ar6 = 0x06
                           000005   663 	ar5 = 0x05
                           000004   664 	ar4 = 0x04
                           000003   665 	ar3 = 0x03
                           000002   666 	ar2 = 0x02
                           000001   667 	ar1 = 0x01
                           000000   668 	ar0 = 0x00
                                    669 ;	 function vial_unlock_task
                                    670 ;	-----------------------------------------
      00B05E                        671 _vial_unlock_task:
                                    672 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B05E 90 0E 6B         [24]  673 	mov	dptr,#_vial_unlock_in_progress
      00B061 E0               [24]  674 	movx	a,@dptr
      00B062 70 01            [24]  675 	jnz	00131$
      00B064 22               [24]  676 	ret
                                    677 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B065                        678 00131$:
      00B065 7F 00            [12]  679 	mov	r7,#0x00
      00B067                        680 00115$:
      00B067 BF 02 00         [24]  681 	cjne	r7,#0x02,00184$
      00B06A                        682 00184$:
      00B06A 50 29            [24]  683 	jnc	00105$
                                    684 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B06C EF               [12]  685 	mov	a,r7
      00B06D 12 B7 01         [24]  686 	lcall	_ak820_outline_0131
      00B070 FE               [12]  687 	mov	r6,a
      00B071 EF               [12]  688 	mov	a,r7
      00B072 12 B6 F6         [24]  689 	lcall	_ak820_outline_0130
      00B075 90 07 AB         [24]  690 	mov	dptr,#_matrix_is_on_PARM_2
      00B078 F0               [24]  691 	movx	@dptr,a
      00B079 8E 82            [24]  692 	mov	dpl, r6
      00B07B C0 07            [24]  693 	push	ar7
      00B07D 12 5D A3         [24]  694 	lcall	_matrix_is_on
      00B080 E5 82            [12]  695 	mov	a, dpl
      00B082 D0 07            [24]  696 	pop	ar7
      00B084 70 0C            [24]  697 	jnz	00116$
                                    698 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B086 90 0C 9C         [24]  699 	mov	dptr,#_vial_unlock_holding
      00B089 E4               [12]  700 	clr	a
      00B08A F0               [24]  701 	movx	@dptr,a
                                    702 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B08B 90 0E 6C         [24]  703 	mov	dptr,#_vial_unlock_counter
      00B08E 74 1E            [12]  704 	mov	a,#0x1e
      00B090 F0               [24]  705 	movx	@dptr,a
                                    706 ;	quantum/vial.c:69: return;
      00B091 22               [24]  707 	ret
      00B092                        708 00116$:
                                    709 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B092 0F               [12]  710 	inc	r7
      00B093 80 D2            [24]  711 	sjmp	00115$
      00B095                        712 00105$:
                                    713 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B095 90 0C 9C         [24]  714 	mov	dptr,#_vial_unlock_holding
      00B098 E0               [24]  715 	movx	a,@dptr
      00B099 70 12            [24]  716 	jnz	00107$
                                    717 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B09B 90 0C 9C         [24]  718 	mov	dptr,#_vial_unlock_holding
      00B09E 74 01            [12]  719 	mov	a,#0x01
      00B0A0 F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B0A1 12 4D A6         [24]  722 	lcall	_timer_read32
      00B0A4 12 53 B7         [24]  723 	lcall	_ak820_outline_0059
      00B0A7 90 0C 98         [24]  724 	mov	dptr,#_vial_unlock_timer
      00B0AA 12 93 BF         [24]  725 	lcall	_ak820_outline_0006
      00B0AD                        726 00107$:
                                    727 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B0AD 90 0C 98         [24]  728 	mov	dptr,#_vial_unlock_timer
      00B0B0 12 53 A6         [24]  729 	lcall	_ak820_outline_0057
      00B0B3 12 4D FF         [24]  730 	lcall	_timer_elapsed32
      00B0B6 12 53 B7         [24]  731 	lcall	_ak820_outline_0059
                                    732 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B0B9 7B 1E            [12]  733 	mov	r3,#0x1e
      00B0BB                        734 00109$:
      00B0BB EB               [12]  735 	mov	a,r3
      00B0BC 60 22            [24]  736 	jz	00111$
      00B0BE C3               [12]  737 	clr	c
      00B0BF EC               [12]  738 	mov	a,r4
      00B0C0 94 64            [12]  739 	subb	a,#0x64
      00B0C2 ED               [12]  740 	mov	a,r5
      00B0C3 94 00            [12]  741 	subb	a,#0x00
      00B0C5 EE               [12]  742 	mov	a,r6
      00B0C6 94 00            [12]  743 	subb	a,#0x00
      00B0C8 EF               [12]  744 	mov	a,r7
      00B0C9 94 00            [12]  745 	subb	a,#0x00
      00B0CB 40 13            [24]  746 	jc	00111$
                                    747 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B0CD EC               [12]  748 	mov	a,r4
      00B0CE 24 9C            [12]  749 	add	a,#0x9c
      00B0D0 FC               [12]  750 	mov	r4,a
      00B0D1 ED               [12]  751 	mov	a,r5
      00B0D2 34 FF            [12]  752 	addc	a,#0xff
      00B0D4 FD               [12]  753 	mov	r5,a
      00B0D5 EE               [12]  754 	mov	a,r6
      00B0D6 34 FF            [12]  755 	addc	a,#0xff
      00B0D8 FE               [12]  756 	mov	r6,a
      00B0D9 EF               [12]  757 	mov	a,r7
      00B0DA 34 FF            [12]  758 	addc	a,#0xff
      00B0DC FF               [12]  759 	mov	r7,a
                                    760 ;	quantum/vial.c:82: --counter;
      00B0DD 1B               [12]  761 	dec	r3
      00B0DE 80 DB            [24]  762 	sjmp	00109$
      00B0E0                        763 00111$:
                                    764 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B0E0 90 0E 6C         [24]  765 	mov	dptr,#_vial_unlock_counter
      00B0E3 EB               [12]  766 	mov	a,r3
      00B0E4 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:85: if (!counter) {
      00B0E5 EB               [12]  769 	mov	a,r3
      00B0E6 70 0A            [24]  770 	jnz	00117$
                                    771 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B0E8 90 0E 6B         [24]  772 	mov	dptr,#_vial_unlock_in_progress
      00B0EB E4               [12]  773 	clr	a
      00B0EC F0               [24]  774 	movx	@dptr,a
                                    775 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B0ED 90 0E 6A         [24]  776 	mov	dptr,#_vial_unlocked
      00B0F0 04               [12]  777 	inc	a
      00B0F1 F0               [24]  778 	movx	@dptr,a
      00B0F2                        779 00117$:
                                    780 ;	quantum/vial.c:90: }
      00B0F2 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'vial_init'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/vial.c:117: void vial_init(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function vial_init
                                    788 ;	-----------------------------------------
      00B0F3                        789 _vial_init:
                                    790 ;	quantum/vial.c:119: ak820_settings_init();
      00B0F3 12 45 77         [24]  791 	lcall	_ak820_settings_init
                                    792 ;	quantum/vial.c:125: reload_combo();
                                    793 ;	quantum/vial.c:130: }
      00B0F6 02 35 7C         [24]  794 	ljmp	_ak820_combo_reload
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    797 ;------------------------------------------------------------
                                    798 ;in            Allocated with name '_vial_keycode_firewall_in_10000_633'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function vial_keycode_firewall
                                    803 ;	-----------------------------------------
      00B0F9                        804 _vial_keycode_firewall:
      00B0F9 12 38 8A         [24]  805 	lcall	_ak820_outline_0108
      00B0FC 90 0C 9D         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_633
      00B0FF 12 38 8F         [24]  807 	lcall	_ak820_outline_0109
                                    808 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B102 90 0C 9D         [24]  809 	mov	dptr,#_vial_keycode_firewall_in_10000_633
      00B105 12 4C E3         [24]  810 	lcall	_ak820_outline_0010
      00B108 BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00B10B BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00B10E 90 0E 6A         [24]  813 	mov	dptr,#_vial_unlocked
      00B111 E0               [24]  814 	movx	a,@dptr
      00B112 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:134: return 0;
      00B114 90 00 00         [24]  817 	mov	dptr,#0x0000
      00B117 22               [24]  818 	ret
      00B118                        819 00102$:
                                    820 ;	quantum/vial.c:135: return in;
      00B118 12 38 94         [24]  821 	lcall	_ak820_outline_0123
                                    822 ;	quantum/vial.c:136: }
      00B11B 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_636'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_638'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00B11C                        835 _vial_fill_packet:
      00B11C 12 38 8A         [24]  836 	lcall	_ak820_outline_0108
      00B11F 90 0C A0         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_636
      00B122 12 38 8F         [24]  838 	lcall	_ak820_outline_0109
                                    839 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B125 90 0C A0         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_636
      00B128 12 38 36         [24]  841 	lcall	_ak820_outline_0054
      00B12B 90 0C 9F         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00B12E E0               [24]  843 	movx	a,@dptr
      00B12F FD               [12]  844 	mov	r5,a
      00B130 7C 00            [12]  845 	mov	r4,#0x00
      00B132                        846 00103$:
      00B132 BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00B135                        848 00122$:
      00B135 50 09            [24]  849 	jnc	00105$
      00B137 EC               [12]  850 	mov	a,r4
      00B138 12 38 26         [24]  851 	lcall	_ak820_outline_0020
      00B13B ED               [12]  852 	mov	a,r5
      00B13C F0               [24]  853 	movx	@dptr,a
      00B13D 0C               [12]  854 	inc	r4
      00B13E 80 F2            [24]  855 	sjmp	00103$
      00B140                        856 00105$:
                                    857 ;	quantum/vial.c:141: }
      00B140 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00B141                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:174: repeat_key_cancel();
      00B141 12 A5 4C         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:176: clear_keyboard();
                                    870 ;	quantum/vial.c:177: }
      00B144 02 7A 98         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_641'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_642'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_647'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_648'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_651'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_653'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_653'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_653'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_654'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_655'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_655'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_655'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_658'
                                    893 ;qsid_greater_than Allocated with name '_vial_handle_cmd_qsid_greater_than_40000_664'
                                    894 ;qsid          Allocated with name '_vial_handle_cmd_qsid_40000_665'
                                    895 ;qsid          Allocated with name '_vial_handle_cmd_qsid_40000_666'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_672'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_672'
                                    898 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_673'
                                    899 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_673'
                                    900 ;------------------------------------------------------------
                                    901 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    902 ;	-----------------------------------------
                                    903 ;	 function vial_handle_cmd
                                    904 ;	-----------------------------------------
      00B147                        905 _vial_handle_cmd:
      00B147 12 43 11         [24]  906 	lcall	_ak820_outline_0037
      00B14A 90 0C A3         [24]  907 	mov	dptr,#_vial_handle_cmd_data_10000_641
      00B14D 12 38 1E         [24]  908 	lcall	_ak820_outline_0017
                                    909 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B150 90 0C A3         [24]  910 	mov	dptr,#_vial_handle_cmd_data_10000_641
      00B153 12 38 36         [24]  911 	lcall	_ak820_outline_0054
                                    912 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B156 90 0C A2         [24]  913 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B159 E0               [24]  914 	movx	a,@dptr
      00B15A FD               [12]  915 	mov	r5,a
      00B15B BD 20 02         [24]  916 	cjne	r5,#0x20,00261$
      00B15E 80 01            [24]  917 	sjmp	00102$
      00B160                        918 00261$:
                                    919 ;	quantum/vial.c:190: return;
      00B160 22               [24]  920 	ret
      00B161                        921 00102$:
                                    922 ;	quantum/vial.c:193: switch (msg[1]) {
      00B161 74 01            [12]  923 	mov	a,#0x01
      00B163 12 4C ED         [24]  924 	lcall	_ak820_outline_0012
      00B166 FA               [12]  925 	mov  r2,a
      00B167 24 F2            [12]  926 	add	a,#0xff - 0x0d
      00B169 50 01            [24]  927 	jnc	00262$
      00B16B 22               [24]  928 	ret
      00B16C                        929 00262$:
                                    930 ;	free result
      00B16C EA               [12]  931 	mov	a,r2
      00B16D 24 0A            [12]  932 	add	a,#(00263$-3-.)
      00B16F 83               [24]  933 	movc	a,@a+pc
      00B170 F5 82            [12]  934 	mov	dpl,a
      00B172 EA               [12]  935 	mov	a,r2
      00B173 24 12            [12]  936 	add	a,#(00264$-3-.)
      00B175 83               [24]  937 	movc	a,@a+pc
      00B176 F5 83            [12]  938 	mov	dph,a
      00B178 E4               [12]  939 	clr	a
      00B179 73               [24]  940 	jmp	@a+dptr
      00B17A                        941 00263$:
      00B17A 96                     942 	.db	00103$
      00B17B DF                     943 	.db	00105$
      00B17C F4                     944 	.db	00106$
      00B17D AB                     945 	.db	00112$
      00B17E 25                     946 	.db	00113$
      00B17F 73                     947 	.db	00114$
      00B180 E4                     948 	.db	00116$
      00B181 FF                     949 	.db	00119$
      00B182 1C                     950 	.db	00120$
      00B183 2A                     951 	.db	00121$
      00B184 49                     952 	.db	00122$
      00B185 7B                     953 	.db	00123$
      00B186 B1                     954 	.db	00124$
      00B187 C4                     955 	.db	00125$
      00B188                        956 00264$:
      00B188 B1                     957 	.db	00103$>>8
      00B189 B1                     958 	.db	00105$>>8
      00B18A B1                     959 	.db	00106$>>8
      00B18B B2                     960 	.db	00112$>>8
      00B18C B3                     961 	.db	00113$>>8
      00B18D B3                     962 	.db	00114$>>8
      00B18E B3                     963 	.db	00116$>>8
      00B18F B3                     964 	.db	00119$>>8
      00B190 B4                     965 	.db	00120$>>8
      00B191 B4                     966 	.db	00121$>>8
      00B192 B4                     967 	.db	00122$>>8
      00B193 B4                     968 	.db	00123$>>8
      00B194 B4                     969 	.db	00124$>>8
      00B195 B4                     970 	.db	00125$>>8
                                    971 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B196                        972 00103$:
                                    973 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B196 90 0C 9F         [24]  974 	mov	dptr,#_vial_fill_packet_PARM_2
      00B199 E4               [12]  975 	clr	a
      00B19A 12 43 35         [24]  976 	lcall	_ak820_outline_0062
      00B19D C0 07            [24]  977 	push	ar7
      00B19F C0 06            [24]  978 	push	ar6
      00B1A1 12 B1 1C         [24]  979 	lcall	_vial_fill_packet
      00B1A4 D0 06            [24]  980 	pop	ar6
      00B1A6 D0 07            [24]  981 	pop	ar7
                                    982 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B1A8 12 38 94         [24]  983 	lcall	_ak820_outline_0123
      00B1AB 74 06            [12]  984 	mov	a,#0x06
      00B1AD 12 43 35         [24]  985 	lcall	_ak820_outline_0062
                                    986 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B1B0 A3               [24]  987 	inc	dptr
      00B1B1 E4               [12]  988 	clr	a
      00B1B2 12 43 09         [24]  989 	lcall	_ak820_outline_0033
                                    990 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B1B5 12 43 09         [24]  991 	lcall	_ak820_outline_0033
                                    992 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B1B8 A3               [24]  993 	inc	dptr
      00B1B9 F0               [24]  994 	movx	@dptr,a
                                    995 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B1BA FA               [12]  996 	mov	r2,a
      00B1BB                        997 00134$:
      00B1BB BA 08 00         [24]  998 	cjne	r2,#0x08,00265$
      00B1BE                        999 00265$:
      00B1BE 50 16            [24] 1000 	jnc	00104$
      00B1C0 8A 01            [24] 1001 	mov	ar1,r2
      00B1C2 74 04            [12] 1002 	mov	a,#0x04
      00B1C4 29               [12] 1003 	add	a, r1
      00B1C5 2E               [12] 1004 	add	a, r6
      00B1C6 F8               [12] 1005 	mov	r0,a
      00B1C7 E4               [12] 1006 	clr	a
      00B1C8 3F               [12] 1007 	addc	a,r7
      00B1C9 F9               [12] 1008 	mov	r1,a
      00B1CA EA               [12] 1009 	mov	a,r2
      00B1CB 90 C4 B0         [24] 1010 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_646
      00B1CE 93               [24] 1011 	movc	a,@a+dptr
      00B1CF 12 38 B7         [24] 1012 	lcall	_ak820_outline_0155
      00B1D2 F0               [24] 1013 	movx	@dptr,a
      00B1D3 0A               [12] 1014 	inc	r2
      00B1D4 80 E5            [24] 1015 	sjmp	00134$
      00B1D6                       1016 00104$:
                                   1017 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B1D6 74 0C            [12] 1018 	mov	a,#0x0c
      00B1D8 12 38 26         [24] 1019 	lcall	_ak820_outline_0020
      00B1DB 74 01            [12] 1020 	mov	a,#0x01
      00B1DD F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	quantum/vial.c:207: break;
      00B1DE 22               [24] 1023 	ret
                                   1024 ;	quantum/vial.c:210: case vial_get_size: {
      00B1DF                       1025 00105$:
                                   1026 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B1DF 12 38 94         [24] 1027 	lcall	_ak820_outline_0123
      00B1E2 74 7C            [12] 1028 	mov	a,#0x7c
      00B1E4 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B1E5 12 33 FC         [24] 1031 	lcall	_ak820_outline_0126
      00B1E8 74 01            [12] 1032 	mov	a,#0x01
      00B1EA 12 43 09         [24] 1033 	lcall	_ak820_outline_0033
                                   1034 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B1ED E4               [12] 1035 	clr	a
      00B1EE 12 43 09         [24] 1036 	lcall	_ak820_outline_0033
                                   1037 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B1F1 A3               [24] 1038 	inc	dptr
      00B1F2 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	quantum/vial.c:216: break;
      00B1F3 22               [24] 1041 	ret
                                   1042 ;	quantum/vial.c:219: case vial_get_def: {
      00B1F4                       1043 00106$:
                                   1044 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B1F4 12 B0 22         [24] 1045 	lcall	_ak820_outline_0024
      00B1F7 E0               [24] 1046 	movx	a,@dptr
      00B1F8 FA               [12] 1047 	mov	r2,a
      00B1F9 12 42 FF         [24] 1048 	lcall	_ak820_outline_0009
      00B1FC E0               [24] 1049 	movx	a,@dptr
      00B1FD 4A               [12] 1050 	orl	a,r2
      00B1FE 60 01            [24] 1051 	jz	00108$
      00B200 22               [24] 1052 	ret
      00B201                       1053 00108$:
                                   1054 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B201 12 38 2E         [24] 1055 	lcall	_ak820_outline_0036
      00B204 F9               [12] 1056 	mov	r1,a
      00B205 7A 00            [12] 1057 	mov	r2,#0x00
      00B207 12 B0 19         [24] 1058 	lcall	_ak820_outline_0016
      00B20A F8               [12] 1059 	mov	r0,a
      00B20B C0 06            [24] 1060 	push	ar6
      00B20D C0 07            [24] 1061 	push	ar7
      00B20F 88 07            [24] 1062 	mov	ar7,r0
      00B211 E4               [12] 1063 	clr	a
      00B212 49               [12] 1064 	orl	a,r1
      00B213 F5 42            [12] 1065 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B215 EF               [12] 1066 	mov	a,r7
      00B216 4A               [12] 1067 	orl	a,r2
      00B217 F5 43            [12] 1068 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),a
                                   1069 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B219 C3               [12] 1070 	clr	c
      00B21A E5 42            [12] 1071 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B21C 94 0C            [12] 1072 	subb	a,#0x0c
      00B21E E5 43            [12] 1073 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B220 94 00            [12] 1074 	subb	a,#0x00
      00B222 D0 07            [24] 1075 	pop	ar7
      00B224 D0 06            [24] 1076 	pop	ar6
      00B226 40 01            [24] 1077 	jc	00110$
      00B228 22               [24] 1078 	ret
      00B229                       1079 00110$:
                                   1080 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B229 C0 06            [24] 1081 	push	ar6
      00B22B C0 07            [24] 1082 	push	ar7
      00B22D A9 42            [24] 1083 	mov	r1,_vial_handle_cmd_sloc0_1_0
      00B22F E5 43            [12] 1084 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B231 C4               [12] 1085 	swap	a
      00B232 23               [12] 1086 	rl	a
      00B233 54 E0            [12] 1087 	anl	a,#0xe0
      00B235 C9               [12] 1088 	xch	a,r1
      00B236 C4               [12] 1089 	swap	a
      00B237 23               [12] 1090 	rl	a
      00B238 C9               [12] 1091 	xch	a,r1
      00B239 69               [12] 1092 	xrl	a,r1
      00B23A C9               [12] 1093 	xch	a,r1
      00B23B 54 E0            [12] 1094 	anl	a,#0xe0
      00B23D C9               [12] 1095 	xch	a,r1
      00B23E 69               [12] 1096 	xrl	a,r1
      00B23F FA               [12] 1097 	mov	r2,a
      00B240 89 44            [24] 1098 	mov	_vial_handle_cmd_sloc1_1_0,r1
      00B242 8A 45            [24] 1099 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),r2
                                   1100 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B244 74 7C            [12] 1101 	mov	a,#0x7c
      00B246 C3               [12] 1102 	clr	c
      00B247 95 44            [12] 1103 	subb	a,_vial_handle_cmd_sloc1_1_0
      00B249 F8               [12] 1104 	mov	r0,a
      00B24A 74 01            [12] 1105 	mov	a,#0x01
      00B24C 95 45            [12] 1106 	subb	a,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B24E FF               [12] 1107 	mov	r7,a
                                   1108 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B24F 88 42            [24] 1109 	mov	_vial_handle_cmd_sloc0_1_0,r0
      00B251 8F 43            [24] 1110 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r7
      00B253 C3               [12] 1111 	clr	c
      00B254 E5 42            [12] 1112 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B256 94 20            [12] 1113 	subb	a,#0x20
      00B258 E5 43            [12] 1114 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B25A 94 00            [12] 1115 	subb	a,#0x00
      00B25C D0 07            [24] 1116 	pop	ar7
      00B25E D0 06            [24] 1117 	pop	ar6
      00B260 50 04            [24] 1118 	jnc	00144$
      00B262 A8 42            [24] 1119 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B264 80 02            [24] 1120 	sjmp	00145$
      00B266                       1121 00144$:
      00B266 78 20            [12] 1122 	mov	r0,#0x20
      00B268                       1123 00145$:
                                   1124 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B268 75 42 00         [24] 1125 	mov	_vial_handle_cmd_sloc0_1_0,#0x00
      00B26B                       1126 00137$:
      00B26B C3               [12] 1127 	clr	c
      00B26C E5 42            [12] 1128 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B26E 98               [12] 1129 	subb	a,r0
      00B26F 40 01            [24] 1130 	jc	00270$
      00B271 22               [24] 1131 	ret
      00B272                       1132 00270$:
      00B272 C0 00            [24] 1133 	push	ar0
      00B274 E5 42            [12] 1134 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B276 2E               [12] 1135 	add	a, r6
      00B277 F5 46            [12] 1136 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B279 E4               [12] 1137 	clr	a
      00B27A 3F               [12] 1138 	addc	a, r7
      00B27B F5 47            [12] 1139 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B27D 85 42 48         [24] 1140 	mov	_vial_handle_cmd_sloc3_1_0,_vial_handle_cmd_sloc0_1_0
      00B280 75 49 00         [24] 1141 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),#0x00
      00B283 A8 44            [24] 1142 	mov	r0,_vial_handle_cmd_sloc1_1_0
      00B285 AA 45            [24] 1143 	mov	r2,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B287 E5 48            [12] 1144 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B289 28               [12] 1145 	add	a, r0
      00B28A F8               [12] 1146 	mov	r0,a
      00B28B E5 49            [12] 1147 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B28D 3A               [12] 1148 	addc	a, r2
      00B28E FA               [12] 1149 	mov	r2,a
      00B28F E8               [12] 1150 	mov	a,r0
      00B290 24 34            [12] 1151 	add	a, #_keyboard_definition
      00B292 F5 82            [12] 1152 	mov	dpl,a
      00B294 EA               [12] 1153 	mov	a,r2
      00B295 34 C3            [12] 1154 	addc	a, #(_keyboard_definition >> 8)
      00B297 F5 83            [12] 1155 	mov	dph,a
      00B299 E4               [12] 1156 	clr	a
      00B29A 93               [24] 1157 	movc	a,@a+dptr
      00B29B 85 46 82         [24] 1158 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B29E 85 47 83         [24] 1159 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B2A1 F0               [24] 1160 	movx	@dptr,a
      00B2A2 E5 42            [12] 1161 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B2A4 04               [12] 1162 	inc	a
      00B2A5 F5 42            [12] 1163 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B2A7 D0 00            [24] 1164 	pop	ar0
                                   1165 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B2A9 80 C0            [24] 1166 	sjmp	00137$
      00B2AB                       1167 00112$:
                                   1168 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B2AB 74 02            [12] 1169 	mov	a,#0x02
      00B2AD 2E               [12] 1170 	add	a, r6
      00B2AE F5 46            [12] 1171 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B2B0 E4               [12] 1172 	clr	a
      00B2B1 3F               [12] 1173 	addc	a, r7
      00B2B2 F5 47            [12] 1174 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B2B4 85 46 82         [24] 1175 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B2B7 85 47 83         [24] 1176 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B2BA E0               [24] 1177 	movx	a,@dptr
      00B2BB F5 48            [12] 1178 	mov	_vial_handle_cmd_sloc3_1_0,a
                                   1179 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B2BD 74 03            [12] 1180 	mov	a,#0x03
      00B2BF 2E               [12] 1181 	add	a, r6
      00B2C0 F5 42            [12] 1182 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B2C2 E4               [12] 1183 	clr	a
      00B2C3 3F               [12] 1184 	addc	a, r7
      00B2C4 F5 43            [12] 1185 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),a
      00B2C6 85 42 82         [24] 1186 	mov	dpl,_vial_handle_cmd_sloc0_1_0
      00B2C9 85 43 83         [24] 1187 	mov	dph,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B2CC E0               [24] 1188 	movx	a,@dptr
                                   1189 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B2CD F5 44            [12] 1190 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B2CF 90 0B 2B         [24] 1191 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B2D2 F0               [24] 1192 	movx	@dptr,a
      00B2D3 90 0B 2C         [24] 1193 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B2D6 E4               [12] 1194 	clr	a
      00B2D7 F0               [24] 1195 	movx	@dptr,a
      00B2D8 85 48 82         [24] 1196 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B2DB C0 07            [24] 1197 	push	ar7
      00B2DD C0 06            [24] 1198 	push	ar6
      00B2DF C0 04            [24] 1199 	push	ar4
      00B2E1 C0 03            [24] 1200 	push	ar3
      00B2E3 12 88 45         [24] 1201 	lcall	_dynamic_keymap_get_encoder
      00B2E6 12 4D 5C         [24] 1202 	lcall	_ak820_outline_0190
      00B2E9 D0 03            [24] 1203 	pop	ar3
      00B2EB D0 04            [24] 1204 	pop	ar4
      00B2ED D0 06            [24] 1205 	pop	ar6
      00B2EF D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B2F1 8A 00            [24] 1208 	mov	ar0,r2
      00B2F3 12 38 94         [24] 1209 	lcall	_ak820_outline_0123
      00B2F6 E8               [12] 1210 	mov	a,r0
      00B2F7 F0               [24] 1211 	movx	@dptr,a
                                   1212 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B2F8 12 33 FC         [24] 1213 	lcall	_ak820_outline_0126
      00B2FB E9               [12] 1214 	mov	a,r1
      00B2FC F0               [24] 1215 	movx	@dptr,a
                                   1216 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B2FD 90 0B 2B         [24] 1217 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B300 E5 44            [12] 1218 	mov	a,_vial_handle_cmd_sloc1_1_0
      00B302 F0               [24] 1219 	movx	@dptr,a
      00B303 90 0B 2C         [24] 1220 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B306 74 01            [12] 1221 	mov	a,#0x01
      00B308 F0               [24] 1222 	movx	@dptr,a
      00B309 85 48 82         [24] 1223 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B30C 12 88 45         [24] 1224 	lcall	_dynamic_keymap_get_encoder
      00B30F 12 4D 5C         [24] 1225 	lcall	_ak820_outline_0190
                                   1226 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B312 8A 00            [24] 1227 	mov	ar0,r2
      00B314 85 46 82         [24] 1228 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B317 85 47 83         [24] 1229 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B31A E8               [12] 1230 	mov	a,r0
      00B31B F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B31C 85 42 82         [24] 1233 	mov	dpl,_vial_handle_cmd_sloc0_1_0
      00B31F 85 43 83         [24] 1234 	mov	dph,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B322 E9               [12] 1235 	mov	a,r1
      00B323 F0               [24] 1236 	movx	@dptr,a
                                   1237 ;	quantum/vial.c:255: break;
      00B324 22               [24] 1238 	ret
                                   1239 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B325                       1240 00113$:
                                   1241 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B325 12 38 2E         [24] 1242 	lcall	_ak820_outline_0036
      00B328 F5 44            [12] 1243 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B32A 12 B0 19         [24] 1244 	lcall	_ak820_outline_0016
      00B32D F5 46            [12] 1245 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B32F 12 B0 22         [24] 1246 	lcall	_ak820_outline_0024
      00B332 E0               [24] 1247 	movx	a,@dptr
                                   1248 ;	assignBit
      00B333 24 FF            [12] 1249 	add	a,#0xff
      00B335 E4               [12] 1250 	clr	a
      00B336 33               [12] 1251 	rlc	a
      00B337 F5 48            [12] 1252 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B339 12 42 FF         [24] 1253 	lcall	_ak820_outline_0009
      00B33C E0               [24] 1254 	movx	a,@dptr
      00B33D F8               [12] 1255 	mov	r0,a
      00B33E 79 00            [12] 1256 	mov	r1,#0x00
      00B340 88 43            [24] 1257 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r0
      00B342 89 42            [24] 1258 	mov	_vial_handle_cmd_sloc0_1_0,r1
      00B344 74 06            [12] 1259 	mov	a,#0x06
      00B346 12 38 26         [24] 1260 	lcall	_ak820_outline_0020
      00B349 E0               [24] 1261 	movx	a,@dptr
      00B34A F9               [12] 1262 	mov	r1,a
      00B34B 7A 00            [12] 1263 	mov	r2,#0x00
      00B34D E5 43            [12] 1264 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B34F 42 02            [12] 1265 	orl	ar2,a
      00B351 89 82            [24] 1266 	mov	dpl, r1
      00B353 8A 83            [24] 1267 	mov	dph, r2
      00B355 12 B0 F9         [24] 1268 	lcall	_vial_keycode_firewall
      00B358 12 4D 5C         [24] 1269 	lcall	_ak820_outline_0190
      00B35B 90 0B 2E         [24] 1270 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B35E E5 46            [12] 1271 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B360 F0               [24] 1272 	movx	@dptr,a
      00B361 90 0B 2F         [24] 1273 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B364 E5 48            [12] 1274 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B366 F0               [24] 1275 	movx	@dptr,a
      00B367 90 0B 30         [24] 1276 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B36A 12 4D 4F         [24] 1277 	lcall	_ak820_outline_0140
      00B36D 85 44 82         [24] 1278 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1279 ;	quantum/vial.c:259: break;
      00B370 02 88 AC         [24] 1280 	ljmp	_dynamic_keymap_set_encoder
                                   1281 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B373                       1282 00114$:
                                   1283 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B373 90 0C 9F         [24] 1284 	mov	dptr,#_vial_fill_packet_PARM_2
      00B376 74 FF            [12] 1285 	mov	a,#0xff
      00B378 12 43 35         [24] 1286 	lcall	_ak820_outline_0062
      00B37B C0 07            [24] 1287 	push	ar7
      00B37D C0 06            [24] 1288 	push	ar6
      00B37F 12 B1 1C         [24] 1289 	lcall	_vial_fill_packet
      00B382 D0 06            [24] 1290 	pop	ar6
      00B384 D0 07            [24] 1291 	pop	ar7
                                   1292 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B386 90 0E 6A         [24] 1293 	mov	dptr,#_vial_unlocked
      00B389 12 43 48         [24] 1294 	lcall	_ak820_outline_0096
                                   1295 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B38C 74 01            [12] 1296 	mov	a,#0x01
      00B38E 2E               [12] 1297 	add	a, r6
      00B38F F9               [12] 1298 	mov	r1,a
      00B390 E4               [12] 1299 	clr	a
      00B391 3F               [12] 1300 	addc	a, r7
      00B392 FA               [12] 1301 	mov	r2,a
      00B393 90 0E 6B         [24] 1302 	mov	dptr,#_vial_unlock_in_progress
      00B396 E0               [24] 1303 	movx	a,@dptr
      00B397 12 70 94         [24] 1304 	lcall	_ak820_outline_0142
                                   1305 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B39A 7A 00            [12] 1306 	mov	r2,#0x00
      00B39C                       1307 00140$:
      00B39C BA 02 00         [24] 1308 	cjne	r2,#0x02,00271$
      00B39F                       1309 00271$:
      00B39F 40 01            [24] 1310 	jc	00272$
      00B3A1 22               [24] 1311 	ret
      00B3A2                       1312 00272$:
                                   1313 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B3A2 8A 00            [24] 1314 	mov	ar0,r2
      00B3A4 79 00            [12] 1315 	mov	r1,#0x00
      00B3A6 E8               [12] 1316 	mov	a,r0
      00B3A7 28               [12] 1317 	add	a,r0
      00B3A8 F5 48            [12] 1318 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B3AA E9               [12] 1319 	mov	a,r1
      00B3AB 33               [12] 1320 	rlc	a
      00B3AC F5 49            [12] 1321 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B3AE 74 02            [12] 1322 	mov	a,#0x02
      00B3B0 25 48            [12] 1323 	add	a, _vial_handle_cmd_sloc3_1_0
      00B3B2 F8               [12] 1324 	mov	r0,a
      00B3B3 E4               [12] 1325 	clr	a
      00B3B4 35 49            [12] 1326 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B3B6 F9               [12] 1327 	mov	r1,a
      00B3B7 E8               [12] 1328 	mov	a,r0
      00B3B8 2E               [12] 1329 	add	a, r6
      00B3B9 F5 46            [12] 1330 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B3BB E9               [12] 1331 	mov	a,r1
      00B3BC 3F               [12] 1332 	addc	a, r7
      00B3BD F5 47            [12] 1333 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B3BF EA               [12] 1334 	mov	a,r2
      00B3C0 12 B7 01         [24] 1335 	lcall	_ak820_outline_0131
      00B3C3 85 46 82         [24] 1336 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B3C6 85 47 83         [24] 1337 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B3C9 F0               [24] 1338 	movx	@dptr,a
                                   1339 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B3CA 74 03            [12] 1340 	mov	a,#0x03
      00B3CC 25 48            [12] 1341 	add	a, _vial_handle_cmd_sloc3_1_0
      00B3CE F8               [12] 1342 	mov	r0,a
      00B3CF E4               [12] 1343 	clr	a
      00B3D0 35 49            [12] 1344 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B3D2 F9               [12] 1345 	mov	r1,a
      00B3D3 E8               [12] 1346 	mov	a,r0
      00B3D4 2E               [12] 1347 	add	a, r6
      00B3D5 F8               [12] 1348 	mov	r0,a
      00B3D6 E9               [12] 1349 	mov	a,r1
      00B3D7 3F               [12] 1350 	addc	a, r7
      00B3D8 F9               [12] 1351 	mov	r1,a
      00B3D9 EA               [12] 1352 	mov	a,r2
      00B3DA 12 B6 F6         [24] 1353 	lcall	_ak820_outline_0130
      00B3DD 12 38 B7         [24] 1354 	lcall	_ak820_outline_0155
      00B3E0 F0               [24] 1355 	movx	@dptr,a
                                   1356 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B3E1 0A               [12] 1357 	inc	r2
                                   1358 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B3E2 80 B8            [24] 1359 	sjmp	00140$
      00B3E4                       1360 00116$:
                                   1361 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B3E4 90 0E 6B         [24] 1362 	mov	dptr,#_vial_unlock_in_progress
      00B3E7 E0               [24] 1363 	movx	a,@dptr
      00B3E8 70 03            [24] 1364 	jnz	00118$
      00B3EA 12 B1 41         [24] 1365 	lcall	_vial_release_held_state
      00B3ED                       1366 00118$:
                                   1367 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B3ED 90 0E 6B         [24] 1368 	mov	dptr,#_vial_unlock_in_progress
      00B3F0 74 01            [12] 1369 	mov	a,#0x01
      00B3F2 F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B3F3 90 0E 6C         [24] 1372 	mov	dptr,#_vial_unlock_counter
      00B3F6 74 1E            [12] 1373 	mov	a,#0x1e
      00B3F8 F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B3F9 90 0C 9C         [24] 1376 	mov	dptr,#_vial_unlock_holding
      00B3FC E4               [12] 1377 	clr	a
      00B3FD F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	quantum/vial.c:287: break;
      00B3FE 22               [24] 1380 	ret
                                   1381 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B3FF                       1382 00119$:
                                   1383 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B3FF 90 0E 6A         [24] 1384 	mov	dptr,#_vial_unlocked
      00B402 12 43 48         [24] 1385 	lcall	_ak820_outline_0096
                                   1386 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B405 90 0E 6B         [24] 1387 	mov	dptr,#_vial_unlock_in_progress
      00B408 E0               [24] 1388 	movx	a,@dptr
      00B409 12 33 FC         [24] 1389 	lcall	_ak820_outline_0126
      00B40C F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B40D 74 02            [12] 1392 	mov	a,#0x02
      00B40F 2E               [12] 1393 	add	a, r6
      00B410 F9               [12] 1394 	mov	r1,a
      00B411 E4               [12] 1395 	clr	a
      00B412 3F               [12] 1396 	addc	a, r7
      00B413 FA               [12] 1397 	mov	r2,a
      00B414 90 0E 6C         [24] 1398 	mov	dptr,#_vial_unlock_counter
      00B417 E0               [24] 1399 	movx	a,@dptr
      00B418 12 70 94         [24] 1400 	lcall	_ak820_outline_0142
                                   1401 ;	quantum/vial.c:293: break;
      00B41B 22               [24] 1402 	ret
                                   1403 ;	quantum/vial.c:295: case vial_lock: {
      00B41C                       1404 00120$:
                                   1405 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B41C 90 0E 6A         [24] 1406 	mov	dptr,#_vial_unlocked
      00B41F E4               [12] 1407 	clr	a
      00B420 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B421 90 0E 6B         [24] 1410 	mov	dptr,#_vial_unlock_in_progress
      00B424 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B425 90 0C 9C         [24] 1413 	mov	dptr,#_vial_unlock_holding
      00B428 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vial.c:301: break;
      00B429 22               [24] 1416 	ret
                                   1417 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B42A                       1418 00121$:
                                   1419 ;	quantum/vial.c:305: uint16_t qsid_greater_than = msg[2] | (msg[3] << 8);
      00B42A 12 B6 BA         [24] 1420 	lcall	_ak820_outline_0007
      00B42D 88 49            [24] 1421 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B42F 89 48            [24] 1422 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B431 8A 01            [24] 1423 	mov	ar1,r2
      00B433 7A 00            [12] 1424 	mov	r2,#0x00
      00B435 E5 49            [12] 1425 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B437 42 02            [12] 1426 	orl	ar2,a
                                   1427 ;	quantum/vial.c:307: ak820_settings_query(qsid_greater_than, msg, length);
      00B439 90 05 DA         [24] 1428 	mov	dptr,#_ak820_settings_query_PARM_2
      00B43C 12 4D 34         [24] 1429 	lcall	_ak820_outline_0061
      00B43F 90 05 DC         [24] 1430 	mov	dptr,#_ak820_settings_query_PARM_3
      00B442 ED               [12] 1431 	mov	a,r5
      00B443 12 92 1A         [24] 1432 	lcall	_ak820_outline_0145
                                   1433 ;	quantum/vial.c:314: break;
      00B446 02 45 FE         [24] 1434 	ljmp	_ak820_settings_query
                                   1435 ;	quantum/vial.c:317: case vial_qmk_settings_get: {
      00B449                       1436 00122$:
                                   1437 ;	quantum/vial.c:318: uint16_t qsid = msg[2] | (msg[3] << 8);
      00B449 12 B6 BA         [24] 1438 	lcall	_ak820_outline_0007
      00B44C 88 49            [24] 1439 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B44E 89 48            [24] 1440 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B450 8A 01            [24] 1441 	mov	ar1,r2
      00B452 7A 00            [12] 1442 	mov	r2,#0x00
      00B454 E5 49            [12] 1443 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B456 42 02            [12] 1444 	orl	ar2,a
                                   1445 ;	quantum/vial.c:320: msg[0] = ak820_settings_get(qsid, &msg[1], length - 1);
      00B458 8D 00            [24] 1446 	mov	ar0,r5
      00B45A 18               [12] 1447 	dec	r0
      00B45B 90 05 E0         [24] 1448 	mov	dptr,#_ak820_settings_get_PARM_2
      00B45E 12 38 65         [24] 1449 	lcall	_ak820_outline_0092
      00B461 90 05 E2         [24] 1450 	mov	dptr,#_ak820_settings_get_PARM_3
      00B464 E8               [12] 1451 	mov	a,r0
      00B465 12 92 1A         [24] 1452 	lcall	_ak820_outline_0145
      00B468 C0 07            [24] 1453 	push	ar7
      00B46A C0 06            [24] 1454 	push	ar6
      00B46C 12 46 94         [24] 1455 	lcall	_ak820_settings_get
      00B46F A9 82            [24] 1456 	mov	r1, dpl
      00B471 D0 06            [24] 1457 	pop	ar6
      00B473 D0 07            [24] 1458 	pop	ar7
      00B475 12 38 94         [24] 1459 	lcall	_ak820_outline_0123
      00B478 E9               [12] 1460 	mov	a,r1
      00B479 F0               [24] 1461 	movx	@dptr,a
                                   1462 ;	quantum/vial.c:325: break;
      00B47A 22               [24] 1463 	ret
                                   1464 ;	quantum/vial.c:327: case vial_qmk_settings_set: {
      00B47B                       1465 00123$:
                                   1466 ;	quantum/vial.c:328: uint16_t qsid = msg[2] | (msg[3] << 8);
      00B47B 12 B6 BA         [24] 1467 	lcall	_ak820_outline_0007
      00B47E 88 49            [24] 1468 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B480 89 48            [24] 1469 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B482 8A 01            [24] 1470 	mov	ar1,r2
      00B484 7A 00            [12] 1471 	mov	r2,#0x00
      00B486 E5 49            [12] 1472 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B488 42 02            [12] 1473 	orl	ar2,a
                                   1474 ;	quantum/vial.c:330: msg[0] = ak820_settings_set(qsid, &msg[4], length - 4);
      00B48A 90 05 E5         [24] 1475 	mov	dptr,#_ak820_settings_set_PARM_2
      00B48D 74 04            [12] 1476 	mov	a,#0x04
      00B48F 2E               [12] 1477 	add	a, r6
      00B490 F0               [24] 1478 	movx	@dptr,a
      00B491 E4               [12] 1479 	clr	a
      00B492 3F               [12] 1480 	addc	a, r7
      00B493 A3               [24] 1481 	inc	dptr
      00B494 F0               [24] 1482 	movx	@dptr,a
      00B495 ED               [12] 1483 	mov	a,r5
      00B496 24 FC            [12] 1484 	add	a,#0xfc
      00B498 90 05 E7         [24] 1485 	mov	dptr,#_ak820_settings_set_PARM_3
      00B49B 12 92 1A         [24] 1486 	lcall	_ak820_outline_0145
      00B49E C0 07            [24] 1487 	push	ar7
      00B4A0 C0 06            [24] 1488 	push	ar6
      00B4A2 12 47 10         [24] 1489 	lcall	_ak820_settings_set
      00B4A5 AA 82            [24] 1490 	mov	r2, dpl
      00B4A7 D0 06            [24] 1491 	pop	ar6
      00B4A9 D0 07            [24] 1492 	pop	ar7
      00B4AB 12 38 94         [24] 1493 	lcall	_ak820_outline_0123
      00B4AE EA               [12] 1494 	mov	a,r2
      00B4AF F0               [24] 1495 	movx	@dptr,a
                                   1496 ;	quantum/vial.c:335: break;
      00B4B0 22               [24] 1497 	ret
                                   1498 ;	quantum/vial.c:337: case vial_qmk_settings_reset: {
      00B4B1                       1499 00124$:
                                   1500 ;	quantum/vial.c:339: msg[0] = ak820_settings_reset();
      00B4B1 C0 07            [24] 1501 	push	ar7
      00B4B3 C0 06            [24] 1502 	push	ar6
      00B4B5 12 47 C9         [24] 1503 	lcall	_ak820_settings_reset
      00B4B8 AA 82            [24] 1504 	mov	r2, dpl
      00B4BA D0 06            [24] 1505 	pop	ar6
      00B4BC D0 07            [24] 1506 	pop	ar7
      00B4BE 12 38 94         [24] 1507 	lcall	_ak820_outline_0123
      00B4C1 EA               [12] 1508 	mov	a,r2
      00B4C2 F0               [24] 1509 	movx	@dptr,a
                                   1510 ;	quantum/vial.c:343: break;
      00B4C3 22               [24] 1511 	ret
                                   1512 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B4C4                       1513 00125$:
                                   1514 ;	quantum/vial.c:347: switch (msg[2]) {
      00B4C4 12 38 2E         [24] 1515 	lcall	_ak820_outline_0036
      00B4C7 FD               [12] 1516 	mov	r5,a
      00B4C8 60 0C            [24] 1517 	jz	00126$
      00B4CA BD 03 02         [24] 1518 	cjne	r5,#0x03,00275$
      00B4CD 80 31            [24] 1519 	sjmp	00127$
      00B4CF                       1520 00275$:
      00B4CF BD 04 03         [24] 1521 	cjne	r5,#0x04,00276$
      00B4D2 02 B5 5E         [24] 1522 	ljmp	00128$
      00B4D5                       1523 00276$:
      00B4D5 22               [24] 1524 	ret
                                   1525 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B4D6                       1526 00126$:
                                   1527 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B4D6 90 0C 9F         [24] 1528 	mov	dptr,#_vial_fill_packet_PARM_2
      00B4D9 E4               [12] 1529 	clr	a
      00B4DA 12 43 35         [24] 1530 	lcall	_ak820_outline_0062
      00B4DD C0 07            [24] 1531 	push	ar7
      00B4DF C0 06            [24] 1532 	push	ar6
      00B4E1 12 B1 1C         [24] 1533 	lcall	_vial_fill_packet
      00B4E4 D0 06            [24] 1534 	pop	ar6
      00B4E6 D0 07            [24] 1535 	pop	ar7
                                   1536 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B4E8 12 38 94         [24] 1537 	lcall	_ak820_outline_0123
      00B4EB E4               [12] 1538 	clr	a
      00B4EC 12 43 35         [24] 1539 	lcall	_ak820_outline_0062
                                   1540 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B4EF A3               [24] 1541 	inc	dptr
      00B4F0 74 08            [12] 1542 	mov	a,#0x08
      00B4F2 12 43 09         [24] 1543 	lcall	_ak820_outline_0033
                                   1544 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B4F5 E4               [12] 1545 	clr	a
      00B4F6 F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B4F7 74 1F            [12] 1548 	mov	a,#0x1f
      00B4F9 12 38 26         [24] 1549 	lcall	_ak820_outline_0020
      00B4FC 74 01            [12] 1550 	mov	a,#0x01
      00B4FE F0               [24] 1551 	movx	@dptr,a
                                   1552 ;	quantum/vial.c:356: break;
      00B4FF 22               [24] 1553 	ret
                                   1554 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B500                       1555 00127$:
                                   1556 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B500 12 B0 19         [24] 1557 	lcall	_ak820_outline_0016
      00B503 FD               [12] 1558 	mov	r5,a
                                   1559 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B504 90 0C A6         [24] 1560 	mov	dptr,#_vial_handle_cmd_entry_70000_672
      00B507 12 53 D5         [24] 1561 	lcall	_ak820_outline_0173
      00B50A 90 0C A8         [24] 1562 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0002)
      00B50D F0               [24] 1563 	movx	@dptr,a
      00B50E A3               [24] 1564 	inc	dptr
      00B50F F0               [24] 1565 	movx	@dptr,a
      00B510 90 0C AA         [24] 1566 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0004)
      00B513 F0               [24] 1567 	movx	@dptr,a
      00B514 A3               [24] 1568 	inc	dptr
      00B515 F0               [24] 1569 	movx	@dptr,a
      00B516 90 0C AC         [24] 1570 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0006)
      00B519 F0               [24] 1571 	movx	@dptr,a
      00B51A A3               [24] 1572 	inc	dptr
      00B51B F0               [24] 1573 	movx	@dptr,a
      00B51C 90 0C AE         [24] 1574 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0008)
      00B51F F0               [24] 1575 	movx	@dptr,a
      00B520 A3               [24] 1576 	inc	dptr
      00B521 F0               [24] 1577 	movx	@dptr,a
                                   1578 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B522 90 0B 33         [24] 1579 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B525 74 A6            [12] 1580 	mov	a,#_vial_handle_cmd_entry_70000_672
      00B527 F0               [24] 1581 	movx	@dptr,a
      00B528 74 0C            [12] 1582 	mov	a,#(_vial_handle_cmd_entry_70000_672 >> 8)
      00B52A 12 38 5F         [24] 1583 	lcall	_ak820_outline_0085
      00B52D 8D 82            [24] 1584 	mov	dpl, r5
      00B52F C0 07            [24] 1585 	push	ar7
      00B531 C0 06            [24] 1586 	push	ar6
      00B533 C0 04            [24] 1587 	push	ar4
      00B535 C0 03            [24] 1588 	push	ar3
      00B537 12 89 17         [24] 1589 	lcall	_dynamic_keymap_get_combo
      00B53A AA 82            [24] 1590 	mov	r2, dpl
      00B53C D0 03            [24] 1591 	pop	ar3
      00B53E D0 04            [24] 1592 	pop	ar4
      00B540 D0 06            [24] 1593 	pop	ar6
      00B542 D0 07            [24] 1594 	pop	ar7
      00B544 12 38 94         [24] 1595 	lcall	_ak820_outline_0123
      00B547 EA               [12] 1596 	mov	a,r2
      00B548 F0               [24] 1597 	movx	@dptr,a
                                   1598 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B549 7D 00            [12] 1599 	mov	r5,#0x00
      00B54B 90 0D E2         [24] 1600 	mov	dptr,#___memcpy_PARM_2
      00B54E 74 A6            [12] 1601 	mov	a,#_vial_handle_cmd_entry_70000_672
      00B550 F0               [24] 1602 	movx	@dptr,a
      00B551 74 0C            [12] 1603 	mov	a,#(_vial_handle_cmd_entry_70000_672 >> 8)
      00B553 12 B6 E7         [24] 1604 	lcall	_ak820_outline_0075
      00B556 12 33 FC         [24] 1605 	lcall	_ak820_outline_0126
      00B559 8D F0            [24] 1606 	mov	b, r5
                                   1607 ;	quantum/vial.c:387: break;
      00B55B 02 BC AA         [24] 1608 	ljmp	___memcpy
                                   1609 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B55E                       1610 00128$:
                                   1611 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B55E 12 B0 19         [24] 1612 	lcall	_ak820_outline_0016
      00B561 FD               [12] 1613 	mov	r5,a
                                   1614 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B562 74 04            [12] 1615 	mov	a,#0x04
      00B564 2E               [12] 1616 	add	a, r6
      00B565 FB               [12] 1617 	mov	r3,a
      00B566 E4               [12] 1618 	clr	a
      00B567 3F               [12] 1619 	addc	a, r7
      00B568 FC               [12] 1620 	mov	r4,a
      00B569 90 0D E2         [24] 1621 	mov	dptr,#___memcpy_PARM_2
      00B56C EB               [12] 1622 	mov	a,r3
      00B56D F0               [24] 1623 	movx	@dptr,a
      00B56E EC               [12] 1624 	mov	a,r4
      00B56F 12 B6 E7         [24] 1625 	lcall	_ak820_outline_0075
      00B572 90 0C B0         [24] 1626 	mov	dptr,#_vial_handle_cmd_entry_70000_673
      00B575 F5 F0            [12] 1627 	mov	b,a
      00B577 C0 07            [24] 1628 	push	ar7
      00B579 C0 06            [24] 1629 	push	ar6
      00B57B C0 05            [24] 1630 	push	ar5
      00B57D 12 BC AA         [24] 1631 	lcall	___memcpy
                                   1632 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B580 90 0C B8         [24] 1633 	mov	dptr,#(_vial_handle_cmd_entry_70000_673 + 0x0008)
      00B583 12 38 72         [24] 1634 	lcall	_ak820_outline_0102
      00B586 12 33 FC         [24] 1635 	lcall	_ak820_outline_0126
      00B589 12 B0 F9         [24] 1636 	lcall	_vial_keycode_firewall
      00B58C AB 82            [24] 1637 	mov	r3, dpl
      00B58E AC 83            [24] 1638 	mov	r4, dph
      00B590 D0 05            [24] 1639 	pop	ar5
      00B592 90 0C B8         [24] 1640 	mov	dptr,#(_vial_handle_cmd_entry_70000_673 + 0x0008)
      00B595 12 38 65         [24] 1641 	lcall	_ak820_outline_0092
                                   1642 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B598 90 0B 37         [24] 1643 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B59B 74 B0            [12] 1644 	mov	a,#_vial_handle_cmd_entry_70000_673
      00B59D F0               [24] 1645 	movx	@dptr,a
      00B59E 74 0C            [12] 1646 	mov	a,#(_vial_handle_cmd_entry_70000_673 >> 8)
      00B5A0 12 38 5F         [24] 1647 	lcall	_ak820_outline_0085
      00B5A3 8D 82            [24] 1648 	mov	dpl, r5
      00B5A5 12 89 BD         [24] 1649 	lcall	_dynamic_keymap_set_combo
      00B5A8 AC 82            [24] 1650 	mov	r4, dpl
      00B5AA D0 06            [24] 1651 	pop	ar6
      00B5AC D0 07            [24] 1652 	pop	ar7
      00B5AE 12 38 94         [24] 1653 	lcall	_ak820_outline_0123
      00B5B1 EC               [12] 1654 	mov	a,r4
      00B5B2 F0               [24] 1655 	movx	@dptr,a
                                   1656 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B5B3 EC               [12] 1657 	mov	a,r4
      00B5B4 70 03            [24] 1658 	jnz	00142$
                                   1659 ;	quantum/vial.c:423: }
                                   1660 ;	quantum/vial.c:424: }
      00B5B6 02 35 7C         [24] 1661 	ljmp	_ak820_combo_reload
      00B5B9                       1662 00142$:
      00B5B9 22               [24] 1663 	ret
                                   1664 ;------------------------------------------------------------
                                   1665 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1666 ;------------------------------------------------------------
                                   1667 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_675'
                                   1668 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_682'
                                   1669 ;------------------------------------------------------------
                                   1670 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1671 ;	-----------------------------------------
                                   1672 ;	 function vial_keycode_down
                                   1673 ;	-----------------------------------------
      00B5BA                       1674 _vial_keycode_down:
      00B5BA 12 38 8A         [24] 1675 	lcall	_ak820_outline_0108
      00B5BD 90 0C BC         [24] 1676 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B5C0 12 38 8F         [24] 1677 	lcall	_ak820_outline_0109
                                   1678 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B5C3 90 0C BC         [24] 1679 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B5C6 12 4C E3         [24] 1680 	lcall	_ak820_outline_0010
      00B5C9 74 E0            [12] 1681 	mov	a,#0x100 - 0x20
      00B5CB 2D               [12] 1682 	add	a,r5
      00B5CC 50 19            [24] 1683 	jnc	00104$
      00B5CE C3               [12] 1684 	clr	c
      00B5CF 74 FF            [12] 1685 	mov	a,#0xff
      00B5D1 9C               [12] 1686 	subb	a,r4
      00B5D2 74 4F            [12] 1687 	mov	a,#0x4f
      00B5D4 9D               [12] 1688 	subb	a,r5
      00B5D5 40 10            [24] 1689 	jc	00104$
                                   1690 ;	free result
                                   1691 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B5D7 90 0C BC         [24] 1692 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B5DA EE               [12] 1693 	mov	a,r6
      00B5DB 12 38 9E         [24] 1694 	lcall	_ak820_outline_0128
                                   1695 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B5DE 90 0C BC         [24] 1696 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B5E1 E0               [24] 1697 	movx	a,@dptr
      00B5E2 24 FE            [12] 1698 	add	a,#0xff - 0x01
      00B5E4 40 01            [24] 1699 	jc	00104$
                                   1700 ;	free result
      00B5E6 22               [24] 1701 	ret
      00B5E7                       1702 00104$:
                                   1703 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B5E7 90 0C BC         [24] 1704 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B5EA 12 B6 CE         [24] 1705 	lcall	_ak820_outline_0026
                                   1706 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B5ED 40 06            [24] 1707 	jc	00107$
                                   1708 ;	free result
                                   1709 ;	quantum/vial.c:440: register_code16(keycode);
      00B5EF 12 38 94         [24] 1710 	lcall	_ak820_outline_0123
      00B5F2 02 A1 6D         [24] 1711 	ljmp	_register_code16
      00B5F5                       1712 00107$:
                                   1713 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B5F5 90 0C C2         [24] 1714 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0004)
      00B5F8 74 01            [12] 1715 	mov	a,#0x01
      00B5FA F0               [24] 1716 	movx	@dptr,a
      00B5FB 90 0C BF         [24] 1717 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0001)
      00B5FE 74 F0            [12] 1718 	mov	a,#0xf0
      00B600 F0               [24] 1719 	movx	@dptr,a
      00B601 90 0C BE         [24] 1720 	mov	dptr,#_vial_keycode_down_dummy_event_30000_682
      00B604 F0               [24] 1721 	movx	@dptr,a
      00B605 90 0C C3         [24] 1722 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0005)
      00B608 74 01            [12] 1723 	mov	a,#0x01
      00B60A F0               [24] 1724 	movx	@dptr,a
      00B60B 12 4D D7         [24] 1725 	lcall	_timer_read
      00B60E 12 43 61         [24] 1726 	lcall	_ak820_outline_0136
      00B611 43 06 01         [24] 1727 	orl	ar6,#0x01
      00B614 90 0C C0         [24] 1728 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0002)
      00B617 12 4D 34         [24] 1729 	lcall	_ak820_outline_0061
                                   1730 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B61A 90 0C BE         [24] 1731 	mov	dptr,#_vial_keycode_down_dummy_event_30000_682
                                   1732 ;	quantum/vial.c:448: }
      00B61D 02 74 B8         [24] 1733 	ljmp	_ak820_action_exec
                                   1734 ;------------------------------------------------------------
                                   1735 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1736 ;------------------------------------------------------------
                                   1737 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_683'
                                   1738 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_690'
                                   1739 ;------------------------------------------------------------
                                   1740 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1741 ;	-----------------------------------------
                                   1742 ;	 function vial_keycode_up
                                   1743 ;	-----------------------------------------
      00B620                       1744 _vial_keycode_up:
      00B620 12 38 8A         [24] 1745 	lcall	_ak820_outline_0108
      00B623 90 0C C4         [24] 1746 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B626 12 38 8F         [24] 1747 	lcall	_ak820_outline_0109
                                   1748 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B629 90 0C C4         [24] 1749 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B62C 12 4C E3         [24] 1750 	lcall	_ak820_outline_0010
      00B62F 74 E0            [12] 1751 	mov	a,#0x100 - 0x20
      00B631 2D               [12] 1752 	add	a,r5
      00B632 50 19            [24] 1753 	jnc	00104$
      00B634 C3               [12] 1754 	clr	c
      00B635 74 FF            [12] 1755 	mov	a,#0xff
      00B637 9C               [12] 1756 	subb	a,r4
      00B638 74 4F            [12] 1757 	mov	a,#0x4f
      00B63A 9D               [12] 1758 	subb	a,r5
      00B63B 40 10            [24] 1759 	jc	00104$
                                   1760 ;	free result
                                   1761 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B63D 90 0C C4         [24] 1762 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B640 EE               [12] 1763 	mov	a,r6
      00B641 12 38 9E         [24] 1764 	lcall	_ak820_outline_0128
                                   1765 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B644 90 0C C4         [24] 1766 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B647 E0               [24] 1767 	movx	a,@dptr
      00B648 24 FE            [12] 1768 	add	a,#0xff - 0x01
      00B64A 40 01            [24] 1769 	jc	00104$
                                   1770 ;	free result
      00B64C 22               [24] 1771 	ret
      00B64D                       1772 00104$:
                                   1773 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B64D 90 0C C4         [24] 1774 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B650 12 B6 CE         [24] 1775 	lcall	_ak820_outline_0026
                                   1776 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B653 40 06            [24] 1777 	jc	00107$
                                   1778 ;	free result
                                   1779 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B655 12 38 94         [24] 1780 	lcall	_ak820_outline_0123
      00B658 02 A1 B1         [24] 1781 	ljmp	_unregister_code16
      00B65B                       1782 00107$:
                                   1783 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B65B 90 0C CA         [24] 1784 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0004)
      00B65E 74 01            [12] 1785 	mov	a,#0x01
      00B660 F0               [24] 1786 	movx	@dptr,a
      00B661 90 0C C7         [24] 1787 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0001)
      00B664 74 F0            [12] 1788 	mov	a,#0xf0
      00B666 F0               [24] 1789 	movx	@dptr,a
      00B667 90 0C C6         [24] 1790 	mov	dptr,#_vial_keycode_up_dummy_event_30000_690
      00B66A F0               [24] 1791 	movx	@dptr,a
      00B66B 90 0C CB         [24] 1792 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0005)
      00B66E E4               [12] 1793 	clr	a
      00B66F F0               [24] 1794 	movx	@dptr,a
      00B670 12 4D D7         [24] 1795 	lcall	_timer_read
      00B673 12 43 61         [24] 1796 	lcall	_ak820_outline_0136
      00B676 43 06 01         [24] 1797 	orl	ar6,#0x01
      00B679 90 0C C8         [24] 1798 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0002)
      00B67C 12 4D 34         [24] 1799 	lcall	_ak820_outline_0061
                                   1800 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B67F 90 0C C6         [24] 1801 	mov	dptr,#_vial_keycode_up_dummy_event_30000_690
                                   1802 ;	quantum/vial.c:470: }
      00B682 02 74 B8         [24] 1803 	ljmp	_ak820_action_exec
                                   1804 ;------------------------------------------------------------
                                   1805 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1806 ;------------------------------------------------------------
                                   1807 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_691'
                                   1808 ;i             Allocated with name '_vial_keycode_tap_i_30000_694'
                                   1809 ;------------------------------------------------------------
                                   1810 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1811 ;	-----------------------------------------
                                   1812 ;	 function vial_keycode_tap
                                   1813 ;	-----------------------------------------
      00B685                       1814 _vial_keycode_tap:
      00B685 12 38 8A         [24] 1815 	lcall	_ak820_outline_0108
      00B688 90 0C CC         [24] 1816 	mov	dptr,#_vial_keycode_tap_keycode_10000_691
      00B68B 12 38 8F         [24] 1817 	lcall	_ak820_outline_0109
                                   1818 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B68E 90 0C CC         [24] 1819 	mov	dptr,#_vial_keycode_tap_keycode_10000_691
      00B691 12 37 E9         [24] 1820 	lcall	_ak820_outline_0005
      00B694 C0 07            [24] 1821 	push	ar7
      00B696 C0 06            [24] 1822 	push	ar6
      00B698 B1 BA            [12] 1823 	acall	_vial_keycode_down
                                   1824 ;	quantum/vial.c:474: qs_wait_ms(QS_tap_code_delay);
      00B69A 12 47 E2         [24] 1825 	lcall	_ak820_settings_tap_code_delay
      00B69D 12 38 AD         [24] 1826 	lcall	_ak820_outline_0149
      00B6A0 D0 06            [24] 1827 	pop	ar6
      00B6A2 D0 07            [24] 1828 	pop	ar7
      00B6A4                       1829 00106$:
      00B6A4 EC               [12] 1830 	mov	a,r4
      00B6A5 4D               [12] 1831 	orl	a,r5
      00B6A6 60 0D            [24] 1832 	jz	00103$
      00B6A8 90 00 01         [24] 1833 	mov	dptr,#0x0001
      00B6AB 12 5D 31         [24] 1834 	lcall	_mDelaymS
      00B6AE 1C               [12] 1835 	dec	r4
      00B6AF BC FF 01         [24] 1836 	cjne	r4,#0xff,00128$
      00B6B2 1D               [12] 1837 	dec	r5
      00B6B3                       1838 00128$:
      00B6B3 80 EF            [24] 1839 	sjmp	00106$
      00B6B5                       1840 00103$:
                                   1841 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B6B5 12 38 94         [24] 1842 	lcall	_ak820_outline_0123
                                   1843 ;	quantum/vial.c:476: }
      00B6B8 C1 20            [12] 1844 	ajmp	_vial_keycode_up
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'process_record_vial'
                                   1847 ;------------------------------------------------------------
                                   1848 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1849 ;keycode       Allocated with name '_process_record_vial_keycode_10000_696'
                                   1850 ;------------------------------------------------------------
                                   1851 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1852 ;	-----------------------------------------
                                   1853 	.area CSEG    (CODE)
                                   1854 	.area CONST   (CODE)
                                   1855 	.area CONST   (CODE)
      00C334                       1856 _keyboard_definition:
      00C334 FD                    1857 	.db #0xfd	; 253
      00C335 37                    1858 	.db #0x37	; 55	'7'
      00C336 7A                    1859 	.db #0x7a	; 122	'z'
      00C337 58                    1860 	.db #0x58	; 88	'X'
      00C338 5A                    1861 	.db #0x5a	; 90	'Z'
      00C339 00                    1862 	.db #0x00	; 0
      00C33A 00                    1863 	.db #0x00	; 0
      00C33B 04                    1864 	.db #0x04	; 4
      00C33C E6                    1865 	.db #0xe6	; 230
      00C33D D6                    1866 	.db #0xd6	; 214
      00C33E B4                    1867 	.db #0xb4	; 180
      00C33F 46                    1868 	.db #0x46	; 70	'F'
      00C340 02                    1869 	.db #0x02	; 2
      00C341 00                    1870 	.db #0x00	; 0
      00C342 21                    1871 	.db #0x21	; 33
      00C343 01                    1872 	.db #0x01	; 1
      00C344 00                    1873 	.db #0x00	; 0
      00C345 00                    1874 	.db #0x00	; 0
      00C346 00                    1875 	.db #0x00	; 0
      00C347 00                    1876 	.db #0x00	; 0
      00C348 37                    1877 	.db #0x37	; 55	'7'
      00C349 27                    1878 	.db #0x27	; 39
      00C34A 97                    1879 	.db #0x97	; 151
      00C34B D6                    1880 	.db #0xd6	; 214
      00C34C E0                    1881 	.db #0xe0	; 224
      00C34D 03                    1882 	.db #0x03	; 3
      00C34E CB                    1883 	.db #0xcb	; 203
      00C34F 01                    1884 	.db #0x01	; 1
      00C350 3C                    1885 	.db #0x3c	; 60
      00C351 00                    1886 	.db #0x00	; 0
      00C352 00                    1887 	.db #0x00	; 0
      00C353 3D                    1888 	.db #0x3d	; 61
      00C354 88                    1889 	.db #0x88	; 136
      00C355 CD                    1890 	.db #0xcd	; 205
      00C356 A5                    1891 	.db #0xa5	; 165
      00C357 AA                    1892 	.db #0xaa	; 170
      00C358 E5                    1893 	.db #0xe5	; 229
      00C359 A8                    1894 	.db #0xa8	; 168
      00C35A 76                    1895 	.db #0x76	; 118	'v'
      00C35B F6                    1896 	.db #0xf6	; 246
      00C35C 43                    1897 	.db #0x43	; 67	'C'
      00C35D 0E                    1898 	.db #0x0e	; 14
      00C35E D2                    1899 	.db #0xd2	; 210
      00C35F 90                    1900 	.db #0x90	; 144
      00C360 7D                    1901 	.db #0x7d	; 125
      00C361 94                    1902 	.db #0x94	; 148
      00C362 79                    1903 	.db #0x79	; 121	'y'
      00C363 78                    1904 	.db #0x78	; 120	'x'
      00C364 EF                    1905 	.db #0xef	; 239
      00C365 49                    1906 	.db #0x49	; 73	'I'
      00C366 3E                    1907 	.db #0x3e	; 62
      00C367 EF                    1908 	.db #0xef	; 239
      00C368 FD                    1909 	.db #0xfd	; 253
      00C369 8F                    1910 	.db #0x8f	; 143
      00C36A EF                    1911 	.db #0xef	; 239
      00C36B 00                    1912 	.db #0x00	; 0
      00C36C C6                    1913 	.db #0xc6	; 198
      00C36D D1                    1914 	.db #0xd1	; 209
      00C36E DB                    1915 	.db #0xdb	; 219
      00C36F FB                    1916 	.db #0xfb	; 251
      00C370 EB                    1917 	.db #0xeb	; 235
      00C371 DE                    1918 	.db #0xde	; 222
      00C372 66                    1919 	.db #0x66	; 102	'f'
      00C373 63                    1920 	.db #0x63	; 99	'c'
      00C374 0C                    1921 	.db #0x0c	; 12
      00C375 92                    1922 	.db #0x92	; 146
      00C376 7B                    1923 	.db #0x7b	; 123
      00C377 F9                    1924 	.db #0xf9	; 249
      00C378 D4                    1925 	.db #0xd4	; 212
      00C379 7A                    1926 	.db #0x7a	; 122	'z'
      00C37A 4F                    1927 	.db #0x4f	; 79	'O'
      00C37B 83                    1928 	.db #0x83	; 131
      00C37C 4B                    1929 	.db #0x4b	; 75	'K'
      00C37D 86                    1930 	.db #0x86	; 134
      00C37E 0E                    1931 	.db #0x0e	; 14
      00C37F 6A                    1932 	.db #0x6a	; 106	'j'
      00C380 F2                    1933 	.db #0xf2	; 242
      00C381 22                    1934 	.db #0x22	; 34
      00C382 22                    1935 	.db #0x22	; 34
      00C383 0B                    1936 	.db #0x0b	; 11
      00C384 03                    1937 	.db #0x03	; 3
      00C385 BA                    1938 	.db #0xba	; 186
      00C386 67                    1939 	.db #0x67	; 103	'g'
      00C387 9B                    1940 	.db #0x9b	; 155
      00C388 7A                    1941 	.db #0x7a	; 122	'z'
      00C389 E1                    1942 	.db #0xe1	; 225
      00C38A BC                    1943 	.db #0xbc	; 188
      00C38B 37                    1944 	.db #0x37	; 55	'7'
      00C38C 26                    1945 	.db #0x26	; 38
      00C38D 46                    1946 	.db #0x46	; 70	'F'
      00C38E 78                    1947 	.db #0x78	; 120	'x'
      00C38F 05                    1948 	.db #0x05	; 5
      00C390 0D                    1949 	.db #0x0d	; 13
      00C391 95                    1950 	.db #0x95	; 149
      00C392 02                    1951 	.db #0x02	; 2
      00C393 E4                    1952 	.db #0xe4	; 228
      00C394 18                    1953 	.db #0x18	; 24
      00C395 CA                    1954 	.db #0xca	; 202
      00C396 33                    1955 	.db #0x33	; 51	'3'
      00C397 EA                    1956 	.db #0xea	; 234
      00C398 24                    1957 	.db #0x24	; 36
      00C399 C8                    1958 	.db #0xc8	; 200
      00C39A 81                    1959 	.db #0x81	; 129
      00C39B 4E                    1960 	.db #0x4e	; 78	'N'
      00C39C 47                    1961 	.db #0x47	; 71	'G'
      00C39D A8                    1962 	.db #0xa8	; 168
      00C39E 44                    1963 	.db #0x44	; 68	'D'
      00C39F DD                    1964 	.db #0xdd	; 221
      00C3A0 91                    1965 	.db #0x91	; 145
      00C3A1 6D                    1966 	.db #0x6d	; 109	'm'
      00C3A2 69                    1967 	.db #0x69	; 105	'i'
      00C3A3 DB                    1968 	.db #0xdb	; 219
      00C3A4 4F                    1969 	.db #0x4f	; 79	'O'
      00C3A5 3A                    1970 	.db #0x3a	; 58
      00C3A6 43                    1971 	.db #0x43	; 67	'C'
      00C3A7 9D                    1972 	.db #0x9d	; 157
      00C3A8 26                    1973 	.db #0x26	; 38
      00C3A9 49                    1974 	.db #0x49	; 73	'I'
      00C3AA 4C                    1975 	.db #0x4c	; 76	'L'
      00C3AB EF                    1976 	.db #0xef	; 239
      00C3AC 2B                    1977 	.db #0x2b	; 43
      00C3AD D8                    1978 	.db #0xd8	; 216
      00C3AE 55                    1979 	.db #0x55	; 85	'U'
      00C3AF 95                    1980 	.db #0x95	; 149
      00C3B0 70                    1981 	.db #0x70	; 112	'p'
      00C3B1 B1                    1982 	.db #0xb1	; 177
      00C3B2 CC                    1983 	.db #0xcc	; 204
      00C3B3 CF                    1984 	.db #0xcf	; 207
      00C3B4 13                    1985 	.db #0x13	; 19
      00C3B5 32                    1986 	.db #0x32	; 50	'2'
      00C3B6 6A                    1987 	.db #0x6a	; 106	'j'
      00C3B7 A1                    1988 	.db #0xa1	; 161
      00C3B8 FF                    1989 	.db #0xff	; 255
      00C3B9 99                    1990 	.db #0x99	; 153
      00C3BA 61                    1991 	.db #0x61	; 97	'a'
      00C3BB 95                    1992 	.db #0x95	; 149
      00C3BC B1                    1993 	.db #0xb1	; 177
      00C3BD 89                    1994 	.db #0x89	; 137
      00C3BE 9B                    1995 	.db #0x9b	; 155
      00C3BF 11                    1996 	.db #0x11	; 17
      00C3C0 D9                    1997 	.db #0xd9	; 217
      00C3C1 35                    1998 	.db #0x35	; 53	'5'
      00C3C2 78                    1999 	.db #0x78	; 120	'x'
      00C3C3 ED                    2000 	.db #0xed	; 237
      00C3C4 CD                    2001 	.db #0xcd	; 205
      00C3C5 94                    2002 	.db #0x94	; 148
      00C3C6 6E                    2003 	.db #0x6e	; 110	'n'
      00C3C7 60                    2004 	.db #0x60	; 96
      00C3C8 8E                    2005 	.db #0x8e	; 142
      00C3C9 63                    2006 	.db #0x63	; 99	'c'
      00C3CA 8B                    2007 	.db #0x8b	; 139
      00C3CB FF                    2008 	.db #0xff	; 255
      00C3CC 4E                    2009 	.db #0x4e	; 78	'N'
      00C3CD 20                    2010 	.db #0x20	; 32
      00C3CE 7A                    2011 	.db #0x7a	; 122	'z'
      00C3CF B5                    2012 	.db #0xb5	; 181
      00C3D0 87                    2013 	.db #0x87	; 135
      00C3D1 C2                    2014 	.db #0xc2	; 194
      00C3D2 35                    2015 	.db #0x35	; 53	'5'
      00C3D3 A4                    2016 	.db #0xa4	; 164
      00C3D4 6D                    2017 	.db #0x6d	; 109	'm'
      00C3D5 18                    2018 	.db #0x18	; 24
      00C3D6 C1                    2019 	.db #0xc1	; 193
      00C3D7 A3                    2020 	.db #0xa3	; 163
      00C3D8 DB                    2021 	.db #0xdb	; 219
      00C3D9 53                    2022 	.db #0x53	; 83	'S'
      00C3DA 1D                    2023 	.db #0x1d	; 29
      00C3DB EC                    2024 	.db #0xec	; 236
      00C3DC F0                    2025 	.db #0xf0	; 240
      00C3DD BF                    2026 	.db #0xbf	; 191
      00C3DE 4A                    2027 	.db #0x4a	; 74	'J'
      00C3DF 4C                    2028 	.db #0x4c	; 76	'L'
      00C3E0 4A                    2029 	.db #0x4a	; 74	'J'
      00C3E1 C4                    2030 	.db #0xc4	; 196
      00C3E2 AA                    2031 	.db #0xaa	; 170
      00C3E3 37                    2032 	.db #0x37	; 55	'7'
      00C3E4 19                    2033 	.db #0x19	; 25
      00C3E5 34                    2034 	.db #0x34	; 52	'4'
      00C3E6 3F                    2035 	.db #0x3f	; 63
      00C3E7 A1                    2036 	.db #0xa1	; 161
      00C3E8 D3                    2037 	.db #0xd3	; 211
      00C3E9 1A                    2038 	.db #0x1a	; 26
      00C3EA 5C                    2039 	.db #0x5c	; 92
      00C3EB 03                    2040 	.db #0x03	; 3
      00C3EC 4D                    2041 	.db #0x4d	; 77	'M'
      00C3ED BC                    2042 	.db #0xbc	; 188
      00C3EE 10                    2043 	.db #0x10	; 16
      00C3EF 2E                    2044 	.db #0x2e	; 46
      00C3F0 80                    2045 	.db #0x80	; 128
      00C3F1 F7                    2046 	.db #0xf7	; 247
      00C3F2 D6                    2047 	.db #0xd6	; 214
      00C3F3 82                    2048 	.db #0x82	; 130
      00C3F4 24                    2049 	.db #0x24	; 36
      00C3F5 4C                    2050 	.db #0x4c	; 76	'L'
      00C3F6 87                    2051 	.db #0x87	; 135
      00C3F7 B9                    2052 	.db #0xb9	; 185
      00C3F8 F8                    2053 	.db #0xf8	; 248
      00C3F9 BE                    2054 	.db #0xbe	; 190
      00C3FA 67                    2055 	.db #0x67	; 103	'g'
      00C3FB 96                    2056 	.db #0x96	; 150
      00C3FC 89                    2057 	.db #0x89	; 137
      00C3FD 30                    2058 	.db #0x30	; 48	'0'
      00C3FE C8                    2059 	.db #0xc8	; 200
      00C3FF 8D                    2060 	.db #0x8d	; 141
      00C400 2C                    2061 	.db #0x2c	; 44
      00C401 F5                    2062 	.db #0xf5	; 245
      00C402 06                    2063 	.db #0x06	; 6
      00C403 05                    2064 	.db #0x05	; 5
      00C404 7C                    2065 	.db #0x7c	; 124
      00C405 48                    2066 	.db #0x48	; 72	'H'
      00C406 1B                    2067 	.db #0x1b	; 27
      00C407 76                    2068 	.db #0x76	; 118	'v'
      00C408 AA                    2069 	.db #0xaa	; 170
      00C409 3D                    2070 	.db #0x3d	; 61
      00C40A 28                    2071 	.db #0x28	; 40
      00C40B FC                    2072 	.db #0xfc	; 252
      00C40C 80                    2073 	.db #0x80	; 128
      00C40D 75                    2074 	.db #0x75	; 117	'u'
      00C40E EB                    2075 	.db #0xeb	; 235
      00C40F 78                    2076 	.db #0x78	; 120	'x'
      00C410 D0                    2077 	.db #0xd0	; 208
      00C411 8A                    2078 	.db #0x8a	; 138
      00C412 8F                    2079 	.db #0x8f	; 143
      00C413 27                    2080 	.db #0x27	; 39
      00C414 F7                    2081 	.db #0xf7	; 247
      00C415 F2                    2082 	.db #0xf2	; 242
      00C416 EB                    2083 	.db #0xeb	; 235
      00C417 58                    2084 	.db #0x58	; 88	'X'
      00C418 37                    2085 	.db #0x37	; 55	'7'
      00C419 3C                    2086 	.db #0x3c	; 60
      00C41A 2B                    2087 	.db #0x2b	; 43
      00C41B 6F                    2088 	.db #0x6f	; 111	'o'
      00C41C 0E                    2089 	.db #0x0e	; 14
      00C41D C7                    2090 	.db #0xc7	; 199
      00C41E E2                    2091 	.db #0xe2	; 226
      00C41F A0                    2092 	.db #0xa0	; 160
      00C420 97                    2093 	.db #0x97	; 151
      00C421 EE                    2094 	.db #0xee	; 238
      00C422 FD                    2095 	.db #0xfd	; 253
      00C423 9F                    2096 	.db #0x9f	; 159
      00C424 45                    2097 	.db #0x45	; 69	'E'
      00C425 17                    2098 	.db #0x17	; 23
      00C426 94                    2099 	.db #0x94	; 148
      00C427 E6                    2100 	.db #0xe6	; 230
      00C428 E7                    2101 	.db #0xe7	; 231
      00C429 FA                    2102 	.db #0xfa	; 250
      00C42A 4C                    2103 	.db #0x4c	; 76	'L'
      00C42B 7A                    2104 	.db #0x7a	; 122	'z'
      00C42C D6                    2105 	.db #0xd6	; 214
      00C42D 7A                    2106 	.db #0x7a	; 122	'z'
      00C42E 7B                    2107 	.db #0x7b	; 123
      00C42F ED                    2108 	.db #0xed	; 237
      00C430 10                    2109 	.db #0x10	; 16
      00C431 C5                    2110 	.db #0xc5	; 197
      00C432 BC                    2111 	.db #0xbc	; 188
      00C433 E3                    2112 	.db #0xe3	; 227
      00C434 A9                    2113 	.db #0xa9	; 169
      00C435 1F                    2114 	.db #0x1f	; 31
      00C436 CF                    2115 	.db #0xcf	; 207
      00C437 C4                    2116 	.db #0xc4	; 196
      00C438 9D                    2117 	.db #0x9d	; 157
      00C439 DC                    2118 	.db #0xdc	; 220
      00C43A 45                    2119 	.db #0x45	; 69	'E'
      00C43B 2A                    2120 	.db #0x2a	; 42
      00C43C 69                    2121 	.db #0x69	; 105	'i'
      00C43D 57                    2122 	.db #0x57	; 87	'W'
      00C43E 8F                    2123 	.db #0x8f	; 143
      00C43F EC                    2124 	.db #0xec	; 236
      00C440 85                    2125 	.db #0x85	; 133
      00C441 6C                    2126 	.db #0x6c	; 108	'l'
      00C442 43                    2127 	.db #0x43	; 67	'C'
      00C443 1C                    2128 	.db #0x1c	; 28
      00C444 BA                    2129 	.db #0xba	; 186
      00C445 89                    2130 	.db #0x89	; 137
      00C446 68                    2131 	.db #0x68	; 104	'h'
      00C447 4A                    2132 	.db #0x4a	; 74	'J'
      00C448 1C                    2133 	.db #0x1c	; 28
      00C449 91                    2134 	.db #0x91	; 145
      00C44A 3F                    2135 	.db #0x3f	; 63
      00C44B D1                    2136 	.db #0xd1	; 209
      00C44C B3                    2137 	.db #0xb3	; 179
      00C44D 96                    2138 	.db #0x96	; 150
      00C44E 1D                    2139 	.db #0x1d	; 29
      00C44F 7C                    2140 	.db #0x7c	; 124
      00C450 14                    2141 	.db #0x14	; 20
      00C451 77                    2142 	.db #0x77	; 119	'w'
      00C452 9C                    2143 	.db #0x9c	; 156
      00C453 74                    2144 	.db #0x74	; 116	't'
      00C454 36                    2145 	.db #0x36	; 54	'6'
      00C455 FF                    2146 	.db #0xff	; 255
      00C456 2C                    2147 	.db #0x2c	; 44
      00C457 66                    2148 	.db #0x66	; 102	'f'
      00C458 AF                    2149 	.db #0xaf	; 175
      00C459 0F                    2150 	.db #0x0f	; 15
      00C45A 3C                    2151 	.db #0x3c	; 60
      00C45B A2                    2152 	.db #0xa2	; 162
      00C45C 23                    2153 	.db #0x23	; 35
      00C45D 85                    2154 	.db #0x85	; 133
      00C45E 05                    2155 	.db #0x05	; 5
      00C45F 87                    2156 	.db #0x87	; 135
      00C460 DA                    2157 	.db #0xda	; 218
      00C461 61                    2158 	.db #0x61	; 97	'a'
      00C462 5E                    2159 	.db #0x5e	; 94
      00C463 42                    2160 	.db #0x42	; 66	'B'
      00C464 54                    2161 	.db #0x54	; 84	'T'
      00C465 60                    2162 	.db #0x60	; 96
      00C466 23                    2163 	.db #0x23	; 35
      00C467 CA                    2164 	.db #0xca	; 202
      00C468 BC                    2165 	.db #0xbc	; 188
      00C469 B3                    2166 	.db #0xb3	; 179
      00C46A 18                    2167 	.db #0x18	; 24
      00C46B 1D                    2168 	.db #0x1d	; 29
      00C46C F8                    2169 	.db #0xf8	; 248
      00C46D 0A                    2170 	.db #0x0a	; 10
      00C46E 55                    2171 	.db #0x55	; 85	'U'
      00C46F CD                    2172 	.db #0xcd	; 205
      00C470 A3                    2173 	.db #0xa3	; 163
      00C471 DE                    2174 	.db #0xde	; 222
      00C472 FF                    2175 	.db #0xff	; 255
      00C473 B2                    2176 	.db #0xb2	; 178
      00C474 2A                    2177 	.db #0x2a	; 42
      00C475 35                    2178 	.db #0x35	; 53	'5'
      00C476 00                    2179 	.db #0x00	; 0
      00C477 D6                    2180 	.db #0xd6	; 214
      00C478 7B                    2181 	.db #0x7b	; 123
      00C479 E8                    2182 	.db #0xe8	; 232
      00C47A F2                    2183 	.db #0xf2	; 242
      00C47B 1A                    2184 	.db #0x1a	; 26
      00C47C BC                    2185 	.db #0xbc	; 188
      00C47D F5                    2186 	.db #0xf5	; 245
      00C47E 7E                    2187 	.db #0x7e	; 126
      00C47F 48                    2188 	.db #0x48	; 72	'H'
      00C480 72                    2189 	.db #0x72	; 114	'r'
      00C481 E0                    2190 	.db #0xe0	; 224
      00C482 E4                    2191 	.db #0xe4	; 228
      00C483 E0                    2192 	.db #0xe0	; 224
      00C484 27                    2193 	.db #0x27	; 39
      00C485 87                    2194 	.db #0x87	; 135
      00C486 9A                    2195 	.db #0x9a	; 154
      00C487 51                    2196 	.db #0x51	; 81	'Q'
      00C488 D4                    2197 	.db #0xd4	; 212
      00C489 DD                    2198 	.db #0xdd	; 221
      00C48A C3                    2199 	.db #0xc3	; 195
      00C48B AA                    2200 	.db #0xaa	; 170
      00C48C 49                    2201 	.db #0x49	; 73	'I'
      00C48D 5A                    2202 	.db #0x5a	; 90	'Z'
      00C48E 2A                    2203 	.db #0x2a	; 42
      00C48F 00                    2204 	.db #0x00	; 0
      00C490 A0                    2205 	.db #0xa0	; 160
      00C491 8C                    2206 	.db #0x8c	; 140
      00C492 FF                    2207 	.db #0xff	; 255
      00C493 74                    2208 	.db #0x74	; 116	't'
      00C494 BF                    2209 	.db #0xbf	; 191
      00C495 EC                    2210 	.db #0xec	; 236
      00C496 1D                    2211 	.db #0x1d	; 29
      00C497 F1                    2212 	.db #0xf1	; 241
      00C498 00                    2213 	.db #0x00	; 0
      00C499 01                    2214 	.db #0x01	; 1
      00C49A D8                    2215 	.db #0xd8	; 216
      00C49B 02                    2216 	.db #0x02	; 2
      00C49C CC                    2217 	.db #0xcc	; 204
      00C49D 07                    2218 	.db #0x07	; 7
      00C49E 00                    2219 	.db #0x00	; 0
      00C49F 00                    2220 	.db #0x00	; 0
      00C4A0 C4                    2221 	.db #0xc4	; 196
      00C4A1 5E                    2222 	.db #0x5e	; 94
      00C4A2 2C                    2223 	.db #0x2c	; 44
      00C4A3 7E                    2224 	.db #0x7e	; 126
      00C4A4 B1                    2225 	.db #0xb1	; 177
      00C4A5 C4                    2226 	.db #0xc4	; 196
      00C4A6 67                    2227 	.db #0x67	; 103	'g'
      00C4A7 FB                    2228 	.db #0xfb	; 251
      00C4A8 02                    2229 	.db #0x02	; 2
      00C4A9 00                    2230 	.db #0x00	; 0
      00C4AA 00                    2231 	.db #0x00	; 0
      00C4AB 00                    2232 	.db #0x00	; 0
      00C4AC 00                    2233 	.db #0x00	; 0
      00C4AD 04                    2234 	.db #0x04	; 4
      00C4AE 59                    2235 	.db #0x59	; 89	'Y'
      00C4AF 5A                    2236 	.db #0x5a	; 90	'Z'
                                   2237 	.area CSEG    (CODE)
                                   2238 	.area CONST   (CODE)
      00C4B0                       2239 _vial_handle_cmd_keyboard_uid_40000_646:
      00C4B0 04                    2240 	.db #0x04	; 4
      00C4B1 70                    2241 	.db #0x70	; 112	'p'
      00C4B2 FF                    2242 	.db #0xff	; 255
      00C4B3 90                    2243 	.db #0x90	; 144
      00C4B4 01                    2244 	.db #0x01	; 1
      00C4B5 B9                    2245 	.db #0xb9	; 185
      00C4B6 15                    2246 	.db #0x15	; 21
      00C4B7 D3                    2247 	.db #0xd3	; 211
                                   2248 	.area CSEG    (CODE)
                                   2249 	.area XINIT   (CODE)
      00C6E6                       2250 __xinit__vial_unlocked:
      00C6E6 00                    2251 	.db #0x00	;  0
      00C6E7                       2252 __xinit__vial_unlock_in_progress:
      00C6E7 00                    2253 	.db #0x00	;  0
      00C6E8                       2254 __xinit__vial_unlock_counter:
      00C6E8 00                    2255 	.db #0x00	; 0
      00C6E9                       2256 __xinit__vial_unlock_combo_rows:
      00C6E9 00                    2257 	.db #0x00	; 0
      00C6EA 00                    2258 	.db #0x00	; 0
      00C6EB                       2259 __xinit__vial_unlock_combo_cols:
      00C6EB 00                    2260 	.db #0x00	; 0
      00C6EC 05                    2261 	.db #0x05	; 5
                                   2262 	.area CABS    (ABS,CODE)
                                   2263 
                                   2264 ; Experimental exact instruction outlining.
                                   2265 	.globl _ak820_outline_0005
                                   2266 	.globl _ak820_outline_0006
                                   2267 	.globl _ak820_outline_0007
                                   2268 	.globl _ak820_outline_0009
                                   2269 	.globl _ak820_outline_0010
                                   2270 	.globl _ak820_outline_0012
                                   2271 	.globl _ak820_outline_0016
                                   2272 	.globl _ak820_outline_0017
                                   2273 	.globl _ak820_outline_0020
                                   2274 	.globl _ak820_outline_0024
                                   2275 	.globl _ak820_outline_0026
                                   2276 	.globl _ak820_outline_0033
                                   2277 	.globl _ak820_outline_0036
                                   2278 	.globl _ak820_outline_0037
                                   2279 	.globl _ak820_outline_0054
                                   2280 	.globl _ak820_outline_0057
                                   2281 	.globl _ak820_outline_0059
                                   2282 	.globl _ak820_outline_0061
                                   2283 	.globl _ak820_outline_0062
                                   2284 	.globl _ak820_outline_0075
                                   2285 	.globl _ak820_outline_0085
                                   2286 	.globl _ak820_outline_0092
                                   2287 	.globl _ak820_outline_0096
                                   2288 	.globl _ak820_outline_0102
                                   2289 	.globl _ak820_outline_0108
                                   2290 	.globl _ak820_outline_0109
                                   2291 	.globl _ak820_outline_0123
                                   2292 	.globl _ak820_outline_0126
                                   2293 	.globl _ak820_outline_0128
                                   2294 	.globl _ak820_outline_0130
                                   2295 	.globl _ak820_outline_0131
                                   2296 	.globl _ak820_outline_0136
                                   2297 	.globl _ak820_outline_0140
                                   2298 	.globl _ak820_outline_0142
                                   2299 	.globl _ak820_outline_0145
                                   2300 	.globl _ak820_outline_0149
                                   2301 	.globl _ak820_outline_0155
                                   2302 	.globl _ak820_outline_0173
                                   2303 	.globl _ak820_outline_0190
                                   2304 
                                   2305 	.area CSEG (CODE)
                                   2306 ; function ak820_outline_0007
      00B6BA                       2307 _ak820_outline_0007:
      00B6BA 8E 82            [24] 2308 	mov	dpl,r6
      00B6BC 8F 83            [24] 2309 	mov	dph,r7
      00B6BE A3               [24] 2310 	inc	dptr
      00B6BF A3               [24] 2311 	inc	dptr
      00B6C0 E0               [24] 2312 	movx	a,@dptr
      00B6C1 FA               [12] 2313 	mov	r2,a
      00B6C2 8E 82            [24] 2314 	mov	dpl,r6
      00B6C4 8F 83            [24] 2315 	mov	dph,r7
      00B6C6 A3               [24] 2316 	inc	dptr
      00B6C7 A3               [24] 2317 	inc	dptr
      00B6C8 A3               [24] 2318 	inc	dptr
      00B6C9 E0               [24] 2319 	movx	a,@dptr
      00B6CA F8               [12] 2320 	mov	r0,a
      00B6CB 79 00            [12] 2321 	mov	r1,#0x00
      00B6CD 22               [24] 2322 	ret
                                   2323 
                                   2324 	.area CSEG (CODE)
                                   2325 ; function ak820_outline_0026
      00B6CE                       2326 _ak820_outline_0026:
      00B6CE E0               [24] 2327 	movx	a,@dptr
      00B6CF FE               [12] 2328 	mov	r6,a
      00B6D0 A3               [24] 2329 	inc	dptr
      00B6D1 E0               [24] 2330 	movx	a,@dptr
      00B6D2 FF               [12] 2331 	mov	r7,a
      00B6D3 90 0C BA         [24] 2332 	mov	dptr,#_g_vial_magic_keycode_override
      00B6D6 EE               [12] 2333 	mov	a,r6
      00B6D7 F0               [24] 2334 	movx	@dptr,a
      00B6D8 EF               [12] 2335 	mov	a,r7
      00B6D9 A3               [24] 2336 	inc	dptr
      00B6DA F0               [24] 2337 	movx	@dptr,a
      00B6DB 8E 04            [24] 2338 	mov	ar4,r6
      00B6DD 8F 05            [24] 2339 	mov	ar5,r7
      00B6DF C3               [12] 2340 	clr	c
      00B6E0 74 FF            [12] 2341 	mov	a,#0xff
      00B6E2 9C               [12] 2342 	subb	a,r4
      00B6E3 74 1F            [12] 2343 	mov	a,#0x1f
      00B6E5 9D               [12] 2344 	subb	a,r5
      00B6E6 22               [24] 2345 	ret
                                   2346 
                                   2347 	.area CSEG (CODE)
                                   2348 ; function ak820_outline_0075
      00B6E7                       2349 _ak820_outline_0075:
      00B6E7 A3               [24] 2350 	inc	dptr
      00B6E8 F0               [24] 2351 	movx	@dptr,a
      00B6E9 E4               [12] 2352 	clr	a
      00B6EA A3               [24] 2353 	inc	dptr
      00B6EB F0               [24] 2354 	movx	@dptr,a
      00B6EC 90 0D E5         [24] 2355 	mov	dptr,#___memcpy_PARM_3
      00B6EF 74 0A            [12] 2356 	mov	a,#0x0a
      00B6F1 F0               [24] 2357 	movx	@dptr,a
      00B6F2 E4               [12] 2358 	clr	a
      00B6F3 A3               [24] 2359 	inc	dptr
      00B6F4 F0               [24] 2360 	movx	@dptr,a
      00B6F5 22               [24] 2361 	ret
                                   2362 
                                   2363 	.area CSEG (CODE)
                                   2364 ; function ak820_outline_0130
      00B6F6                       2365 _ak820_outline_0130:
      00B6F6 24 6F            [12] 2366 	add	a,#_vial_unlock_combo_cols
      00B6F8 F5 82            [12] 2367 	mov	dpl,a
      00B6FA E4               [12] 2368 	clr	a
      00B6FB 34 0E            [12] 2369 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B6FD F5 83            [12] 2370 	mov	dph,a
      00B6FF E0               [24] 2371 	movx	a,@dptr
      00B700 22               [24] 2372 	ret
                                   2373 
                                   2374 	.area CSEG (CODE)
                                   2375 ; function ak820_outline_0131
      00B701                       2376 _ak820_outline_0131:
      00B701 24 6D            [12] 2377 	add	a,#_vial_unlock_combo_rows
      00B703 F5 82            [12] 2378 	mov	dpl,a
      00B705 E4               [12] 2379 	clr	a
      00B706 34 0E            [12] 2380 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B708 F5 83            [12] 2381 	mov	dph,a
      00B70A E0               [24] 2382 	movx	a,@dptr
      00B70B 22               [24] 2383 	ret
