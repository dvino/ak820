                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_settings
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _clear_keyboard
                                     12 	.globl ___memcpy
                                     13 	.globl _memcmp
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_read_block_xdata
                                     16 	.globl _ak820_nvm_end
                                     17 	.globl _ak820_nvm_begin
                                     18 	.globl _ak820_nvm_schema_fault
                                     19 	.globl _ak820_nvm_ok
                                     20 	.globl _ak820_settings_set_PARM_3
                                     21 	.globl _ak820_settings_set_PARM_2
                                     22 	.globl _ak820_settings_get_PARM_3
                                     23 	.globl _ak820_settings_get_PARM_2
                                     24 	.globl _ak820_settings_query_PARM_3
                                     25 	.globl _ak820_settings_query_PARM_2
                                     26 	.globl _ak820_settings_init
                                     27 	.globl _ak820_settings_query
                                     28 	.globl _ak820_settings_get
                                     29 	.globl _ak820_settings_set
                                     30 	.globl _ak820_settings_reset
                                     31 	.globl _ak820_settings_grave_esc
                                     32 	.globl _ak820_settings_combo_term
                                     33 	.globl _ak820_settings_tapping_term
                                     34 	.globl _ak820_settings_tap_code_delay
                                     35 	.globl _ak820_settings_caps_delay
                                     36 ;--------------------------------------------------------
                                     37 ; special function registers
                                     38 ;--------------------------------------------------------
                                     39 	.area RSEG    (ABS,DATA)
      000000                         40 	.org 0x0000
                                     41 ;--------------------------------------------------------
                                     42 ; special function bits
                                     43 ;--------------------------------------------------------
                                     44 	.area RSEG    (ABS,DATA)
      000000                         45 	.org 0x0000
                                     46 ;--------------------------------------------------------
                                     47 ; overlayable register banks
                                     48 ;--------------------------------------------------------
                                     49 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         50 	.ds 8
                                     51 ;--------------------------------------------------------
                                     52 ; internal ram data
                                     53 ;--------------------------------------------------------
                                     54 	.area DSEG    (DATA)
                                     55 ;--------------------------------------------------------
                                     56 ; overlayable items in internal ram
                                     57 ;--------------------------------------------------------
                                     58 ;--------------------------------------------------------
                                     59 ; indirectly addressable internal ram data
                                     60 ;--------------------------------------------------------
                                     61 	.area ISEG    (DATA)
                                     62 ;--------------------------------------------------------
                                     63 ; absolute internal ram data
                                     64 ;--------------------------------------------------------
                                     65 	.area IABS    (ABS,DATA)
                                     66 	.area IABS    (ABS,DATA)
                                     67 ;--------------------------------------------------------
                                     68 ; bit data
                                     69 ;--------------------------------------------------------
                                     70 	.area BSEG    (BIT)
      00000E                         71 _valid_sloc0_1_0:
      00000E                         72 	.ds 1
                                     73 ;--------------------------------------------------------
                                     74 ; paged external ram data
                                     75 ;--------------------------------------------------------
                                     76 	.area PSEG    (PAG,XDATA)
                                     77 ;--------------------------------------------------------
                                     78 ; uninitialized external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area XSEG    (XDATA)
      00059E                         81 _current:
      00059E                         82 	.ds 24
      0005B6                         83 _candidate:
      0005B6                         84 	.ds 24
      0005CE                         85 _word_p_10000_54:
      0005CE                         86 	.ds 2
      0005D0                         87 _put_word_PARM_2:
      0005D0                         88 	.ds 2
      0005D2                         89 _put_word_p_10000_56:
      0005D2                         90 	.ds 2
      0005D4                         91 _checksum_crc_10000_59:
      0005D4                         92 	.ds 2
      0005D6                         93 _valid_i_10000_69:
      0005D6                         94 	.ds 1
      0005D7                         95 _ak820_settings_init_blank_zero_10000_86:
      0005D7                         96 	.ds 1
      0005D8                         97 _ak820_settings_init_blank_erased_10000_86:
      0005D8                         98 	.ds 1
      0005D9                         99 _offset_id_10000_94:
      0005D9                        100 	.ds 1
      0005DA                        101 _ak820_settings_query_PARM_2:
      0005DA                        102 	.ds 2
      0005DC                        103 _ak820_settings_query_PARM_3:
      0005DC                        104 	.ds 1
      0005DD                        105 _ak820_settings_query_greater_than_10000_98:
      0005DD                        106 	.ds 2
      0005DF                        107 _ak820_settings_query_used_10000_99:
      0005DF                        108 	.ds 1
      0005E0                        109 _ak820_settings_get_PARM_2:
      0005E0                        110 	.ds 2
      0005E2                        111 _ak820_settings_get_PARM_3:
      0005E2                        112 	.ds 1
      0005E3                        113 _ak820_settings_get_id_10000_106:
      0005E3                        114 	.ds 2
      0005E5                        115 _ak820_settings_set_PARM_2:
      0005E5                        116 	.ds 2
      0005E7                        117 _ak820_settings_set_PARM_3:
      0005E7                        118 	.ds 1
      0005E8                        119 _ak820_settings_set_id_10000_111:
      0005E8                        120 	.ds 2
                                    121 ;--------------------------------------------------------
                                    122 ; absolute external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XABS    (ABS,XDATA)
                                    125 ;--------------------------------------------------------
                                    126 ; initialized external ram data
                                    127 ;--------------------------------------------------------
                                    128 	.area XISEG   (XDATA)
                                    129 	.area HOME    (CODE)
                                    130 	.area GSINIT0 (CODE)
                                    131 	.area GSINIT1 (CODE)
                                    132 	.area GSINIT2 (CODE)
                                    133 	.area GSINIT3 (CODE)
                                    134 	.area GSINIT4 (CODE)
                                    135 	.area GSINIT5 (CODE)
                                    136 	.area GSINIT  (CODE)
                                    137 	.area GSFINAL (CODE)
                                    138 	.area CSEG    (CODE)
                                    139 ;--------------------------------------------------------
                                    140 ; global & static initialisations
                                    141 ;--------------------------------------------------------
                                    142 	.area HOME    (CODE)
                                    143 	.area GSINIT  (CODE)
                                    144 	.area GSFINAL (CODE)
                                    145 	.area GSINIT  (CODE)
                                    146 ;--------------------------------------------------------
                                    147 ; Home
                                    148 ;--------------------------------------------------------
                                    149 	.area HOME    (CODE)
                                    150 	.area HOME    (CODE)
                                    151 ;--------------------------------------------------------
                                    152 ; code
                                    153 ;--------------------------------------------------------
                                    154 	.area CSEG    (CODE)
                                    155 ;------------------------------------------------------------
                                    156 ;Allocation info for local variables in function 'word'
                                    157 ;------------------------------------------------------------
                                    158 ;p             Allocated with name '_word_p_10000_54'
                                    159 ;------------------------------------------------------------
                                    160 ;	keyboards/ajazz/ak820/ak820_settings.c:13: static uint16_t word(const uint8_t AK820_XDATA *p) {
                                    161 ;	-----------------------------------------
                                    162 ;	 function word
                                    163 ;	-----------------------------------------
      004392                        164 _word:
                           000007   165 	ar7 = 0x07
                           000006   166 	ar6 = 0x06
                           000005   167 	ar5 = 0x05
                           000004   168 	ar4 = 0x04
                           000003   169 	ar3 = 0x03
                           000002   170 	ar2 = 0x02
                           000001   171 	ar1 = 0x01
                           000000   172 	ar0 = 0x00
      004392 12 38 8A         [24]  173 	lcall	_ak820_outline_0108
      004395 90 05 CE         [24]  174 	mov	dptr,#_word_p_10000_54
      004398 12 38 8F         [24]  175 	lcall	_ak820_outline_0109
                                    176 ;	keyboards/ajazz/ak820/ak820_settings.c:14: return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
      00439B 90 05 CE         [24]  177 	mov	dptr,#_word_p_10000_54
      00439E 12 37 E9         [24]  178 	lcall	_ak820_outline_0005
      0043A1 E0               [24]  179 	movx	a,@dptr
      0043A2 FD               [12]  180 	mov	r5,a
      0043A3 7C 00            [12]  181 	mov	r4,#0x00
      0043A5 12 38 6B         [24]  182 	lcall	_ak820_outline_0095
      0043A8 FE               [12]  183 	mov	r6,a
      0043A9 E4               [12]  184 	clr	a
      0043AA 42 05            [12]  185 	orl	ar5,a
      0043AC EE               [12]  186 	mov	a,r6
      0043AD 42 04            [12]  187 	orl	ar4,a
      0043AF 12 43 88         [24]  188 	lcall	_ak820_outline_0187
                                    189 ;	keyboards/ajazz/ak820/ak820_settings.c:15: }
      0043B2 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'put_word'
                                    193 ;------------------------------------------------------------
                                    194 ;v             Allocated with name '_put_word_PARM_2'
                                    195 ;p             Allocated with name '_put_word_p_10000_56'
                                    196 ;------------------------------------------------------------
                                    197 ;	keyboards/ajazz/ak820/ak820_settings.c:16: static void put_word(uint8_t AK820_XDATA *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
                                    198 ;	-----------------------------------------
                                    199 ;	 function put_word
                                    200 ;	-----------------------------------------
      0043B3                        201 _put_word:
      0043B3 12 38 8A         [24]  202 	lcall	_ak820_outline_0108
      0043B6 90 05 D2         [24]  203 	mov	dptr,#_put_word_p_10000_56
      0043B9 12 38 8F         [24]  204 	lcall	_ak820_outline_0109
      0043BC 90 05 D2         [24]  205 	mov	dptr,#_put_word_p_10000_56
      0043BF 12 38 36         [24]  206 	lcall	_ak820_outline_0054
      0043C2 90 05 D0         [24]  207 	mov	dptr,#_put_word_PARM_2
      0043C5 12 38 4D         [24]  208 	lcall	_ak820_outline_0060
      0043C8 8C 03            [24]  209 	mov	ar3,r4
      0043CA 12 38 94         [24]  210 	lcall	_ak820_outline_0123
      0043CD EB               [12]  211 	mov	a,r3
      0043CE 12 43 35         [24]  212 	lcall	_ak820_outline_0062
      0043D1 A3               [24]  213 	inc	dptr
      0043D2 8D 04            [24]  214 	mov	ar4,r5
      0043D4 EC               [12]  215 	mov	a,r4
      0043D5 F0               [24]  216 	movx	@dptr,a
      0043D6 22               [24]  217 	ret
                                    218 ;------------------------------------------------------------
                                    219 ;Allocation info for local variables in function 'checksum'
                                    220 ;------------------------------------------------------------
                                    221 ;crc           Allocated with name '_checksum_crc_10000_59'
                                    222 ;i             Allocated with name '_checksum_i_10000_59'
                                    223 ;bit           Allocated with name '_checksum_bit_10000_59'
                                    224 ;------------------------------------------------------------
                                    225 ;	keyboards/ajazz/ak820/ak820_settings.c:17: static uint16_t checksum(void) {
                                    226 ;	-----------------------------------------
                                    227 ;	 function checksum
                                    228 ;	-----------------------------------------
      0043D7                        229 _checksum:
                                    230 ;	keyboards/ajazz/ak820/ak820_settings.c:18: uint16_t crc = 0xFFFFu;
      0043D7 90 05 D4         [24]  231 	mov	dptr,#_checksum_crc_10000_59
      0043DA 74 FF            [12]  232 	mov	a,#0xff
      0043DC F0               [24]  233 	movx	@dptr,a
      0043DD A3               [24]  234 	inc	dptr
      0043DE F0               [24]  235 	movx	@dptr,a
                                    236 ;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
      0043DF 7F 00            [12]  237 	mov	r7,#0x00
      0043E1                        238 00106$:
                                    239 ;	keyboards/ajazz/ak820/ak820_settings.c:21: crc ^= (uint16_t)candidate[i] << 8;
      0043E1 12 48 23         [24]  240 	lcall	_ak820_outline_0111
      0043E4 FD               [12]  241 	mov	r5,a
      0043E5 7E 00            [12]  242 	mov	r6,#0x00
      0043E7 90 05 D4         [24]  243 	mov	dptr,#_checksum_crc_10000_59
      0043EA E0               [24]  244 	movx	a,@dptr
      0043EB 6E               [12]  245 	xrl	a,r6
      0043EC F0               [24]  246 	movx	@dptr,a
      0043ED A3               [24]  247 	inc	dptr
      0043EE E0               [24]  248 	movx	a,@dptr
      0043EF 6D               [12]  249 	xrl	a,r5
      0043F0 F0               [24]  250 	movx	@dptr,a
                                    251 ;	keyboards/ajazz/ak820/ak820_settings.c:22: for (bit = 0; bit < 8; ++bit) crc = (crc & 0x8000u) ? (crc << 1) ^ 0x1021u : (uint16_t)(crc << 1);
      0043F1 7E 08            [12]  252 	mov	r6,#0x08
      0043F3                        253 00105$:
      0043F3 90 05 D4         [24]  254 	mov	dptr,#_checksum_crc_10000_59
      0043F6 12 38 4D         [24]  255 	lcall	_ak820_outline_0060
      0043F9 30 E7 0E         [24]  256 	jnb	acc.7,00110$
      0043FC EC               [12]  257 	mov	a,r4
      0043FD 2C               [12]  258 	add	a,r4
      0043FE FA               [12]  259 	mov	r2,a
      0043FF ED               [12]  260 	mov	a,r5
      004400 33               [12]  261 	rlc	a
      004401 FB               [12]  262 	mov	r3,a
      004402 63 02 21         [24]  263 	xrl	ar2,#0x21
      004405 63 03 10         [24]  264 	xrl	ar3,#0x10
      004408 80 06            [24]  265 	sjmp	00111$
      00440A                        266 00110$:
      00440A EC               [12]  267 	mov	a,r4
      00440B 2C               [12]  268 	add	a,r4
      00440C FA               [12]  269 	mov	r2,a
      00440D ED               [12]  270 	mov	a,r5
      00440E 33               [12]  271 	rlc	a
      00440F FB               [12]  272 	mov	r3,a
      004410                        273 00111$:
      004410 90 05 D4         [24]  274 	mov	dptr,#_checksum_crc_10000_59
      004413 EA               [12]  275 	mov	a,r2
      004414 12 48 3C         [24]  276 	lcall	_ak820_outline_0194
      004417 DE DA            [24]  277 	djnz	r6,00105$
                                    278 ;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
      004419 0F               [12]  279 	inc	r7
      00441A BF 16 00         [24]  280 	cjne	r7,#0x16,00151$
      00441D                        281 00151$:
      00441D 40 C2            [24]  282 	jc	00106$
                                    283 ;	keyboards/ajazz/ak820/ak820_settings.c:24: return crc;
      00441F 12 38 A8         [24]  284 	lcall	_ak820_outline_0148
                                    285 ;	keyboards/ajazz/ak820/ak820_settings.c:25: }
      004422 22               [24]  286 	ret
                                    287 ;------------------------------------------------------------
                                    288 ;Allocation info for local variables in function 'seal'
                                    289 ;------------------------------------------------------------
                                    290 ;	keyboards/ajazz/ak820/ak820_settings.c:26: static void seal(void) { put_word(candidate + 22, checksum()); }
                                    291 ;	-----------------------------------------
                                    292 ;	 function seal
                                    293 ;	-----------------------------------------
      004423                        294 _seal:
      004423 12 43 D7         [24]  295 	lcall	_checksum
      004426 12 38 78         [24]  296 	lcall	_ak820_outline_0103
      004429 90 05 D0         [24]  297 	mov	dptr,#_put_word_PARM_2
      00442C 12 48 36         [24]  298 	lcall	_ak820_outline_0144
      00442F 90 05 CC         [24]  299 	mov	dptr,#(_candidate + 0x0016)
      004432 02 43 B3         [24]  300 	ljmp	_put_word
                                    301 ;------------------------------------------------------------
                                    302 ;Allocation info for local variables in function 'defaults'
                                    303 ;------------------------------------------------------------
                                    304 ;i             Allocated with name '_defaults_i_20000_67'
                                    305 ;------------------------------------------------------------
                                    306 ;	keyboards/ajazz/ak820/ak820_settings.c:34: static void defaults(void) {
                                    307 ;	-----------------------------------------
                                    308 ;	 function defaults
                                    309 ;	-----------------------------------------
      004435                        310 _defaults:
                                    311 ;	keyboards/ajazz/ak820/ak820_settings.c:35: for (uint8_t i = 0; i < AK820_SETTINGS_SIZE; ++i) candidate[i] = default_record[i];
      004435 7F 00            [12]  312 	mov	r7,#0x00
      004437                        313 00103$:
      004437 BF 18 00         [24]  314 	cjne	r7,#0x18,00122$
      00443A                        315 00122$:
      00443A 50 13            [24]  316 	jnc	00105$
      00443C EF               [12]  317 	mov	a,r7
      00443D 24 B6            [12]  318 	add	a, #_candidate
      00443F FD               [12]  319 	mov	r5,a
      004440 E4               [12]  320 	clr	a
      004441 34 05            [12]  321 	addc	a, #(_candidate >> 8)
      004443 FE               [12]  322 	mov	r6,a
      004444 EF               [12]  323 	mov	a,r7
      004445 90 BE EF         [24]  324 	mov	dptr,#_default_record
      004448 93               [24]  325 	movc	a,@a+dptr
      004449 12 48 1D         [24]  326 	lcall	_ak820_outline_0104
      00444C 0F               [12]  327 	inc	r7
      00444D 80 E8            [24]  328 	sjmp	00103$
      00444F                        329 00105$:
                                    330 ;	keyboards/ajazz/ak820/ak820_settings.c:36: }
      00444F 22               [24]  331 	ret
                                    332 ;------------------------------------------------------------
                                    333 ;Allocation info for local variables in function 'valid'
                                    334 ;------------------------------------------------------------
                                    335 ;i             Allocated with name '_valid_i_10000_69'
                                    336 ;value         Allocated with name '_valid_value_10000_69'
                                    337 ;------------------------------------------------------------
                                    338 ;	keyboards/ajazz/ak820/ak820_settings.c:37: static bool valid(void) {
                                    339 ;	-----------------------------------------
                                    340 ;	 function valid
                                    341 ;	-----------------------------------------
      004450                        342 _valid:
                                    343 ;	keyboards/ajazz/ak820/ak820_settings.c:40: if (candidate[0] != 'Q' || candidate[1] != 'S' || candidate[2] != AK820_SETTINGS_VERSION || candidate[3] != 11 || candidate[4] != AK820_SETTINGS_CAPABILITIES) return false;
      004450 90 05 B6         [24]  344 	mov	dptr,#_candidate
      004453 E0               [24]  345 	movx	a,@dptr
      004454 FF               [12]  346 	mov	r7,a
      004455 BF 51 22         [24]  347 	cjne	r7,#0x51,00101$
      004458 90 05 B7         [24]  348 	mov	dptr,#(_candidate + 0x0001)
      00445B E0               [24]  349 	movx	a,@dptr
      00445C FF               [12]  350 	mov	r7,a
      00445D BF 53 1A         [24]  351 	cjne	r7,#0x53,00101$
      004460 90 05 B8         [24]  352 	mov	dptr,#(_candidate + 0x0002)
      004463 E0               [24]  353 	movx	a,@dptr
      004464 FF               [12]  354 	mov	r7,a
      004465 BF 01 12         [24]  355 	cjne	r7,#0x01,00101$
      004468 90 05 B9         [24]  356 	mov	dptr,#(_candidate + 0x0003)
      00446B E0               [24]  357 	movx	a,@dptr
      00446C FF               [12]  358 	mov	r7,a
      00446D BF 0B 0A         [24]  359 	cjne	r7,#0x0b,00101$
      004470 90 05 BA         [24]  360 	mov	dptr,#(_candidate + 0x0004)
      004473 E0               [24]  361 	movx	a,@dptr
      004474 FF               [12]  362 	mov	r7,a
      004475 BF 3F 02         [24]  363 	cjne	r7,#0x3f,00227$
      004478 80 04            [24]  364 	sjmp	00102$
      00447A                        365 00227$:
      00447A                        366 00101$:
      00447A 75 82 00         [24]  367 	mov	dpl, #0x00
      00447D 22               [24]  368 	ret
      00447E                        369 00102$:
                                    370 ;	keyboards/ajazz/ak820/ak820_settings.c:41: if (candidate[5] & 0xF0u) return false;
      00447E 90 05 BB         [24]  371 	mov	dptr,#(_candidate + 0x0005)
      004481 E0               [24]  372 	movx	a,@dptr
      004482 54 F0            [12]  373 	anl	a,#0xf0
      004484 60 04            [24]  374 	jz	00108$
      004486 75 82 00         [24]  375 	mov	dpl, #0x00
      004489 22               [24]  376 	ret
      00448A                        377 00108$:
                                    378 ;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 6; i <= 14; i += 2) {
      00448A 90 05 D6         [24]  379 	mov	dptr,#_valid_i_10000_69
      00448D 74 06            [12]  380 	mov	a,#0x06
      00448F F0               [24]  381 	movx	@dptr,a
      004490                        382 00122$:
                                    383 ;	keyboards/ajazz/ak820/ak820_settings.c:43: value = word(candidate + i);
      004490 90 05 D6         [24]  384 	mov	dptr,#_valid_i_10000_69
      004493 E0               [24]  385 	movx	a,@dptr
      004494 FF               [12]  386 	mov	r7,a
      004495 12 48 0A         [24]  387 	lcall	_ak820_outline_0043
      004498 C0 07            [24]  388 	push	ar7
      00449A 12 43 92         [24]  389 	lcall	_word
      00449D 12 43 8D         [24]  390 	lcall	_ak820_outline_0193
      0044A0 D0 07            [24]  391 	pop	ar7
                                    392 ;	keyboards/ajazz/ak820/ak820_settings.c:44: if (i == 10 || i == 12) { if (value > 100) return false; }
      0044A2 BF 0A 02         [24]  393 	cjne	r7,#0x0a,00229$
      0044A5 80 03            [24]  394 	sjmp	00114$
      0044A7                        395 00229$:
      0044A7 BF 0C 10         [24]  396 	cjne	r7,#0x0c,00115$
      0044AA                        397 00114$:
      0044AA 8D 04            [24]  398 	mov	ar4,r5
      0044AC 8E 07            [24]  399 	mov	ar7,r6
      0044AE C3               [12]  400 	clr	c
      0044AF 74 64            [12]  401 	mov	a,#0x64
      0044B1 9C               [12]  402 	subb	a,r4
      0044B2 E4               [12]  403 	clr	a
      0044B3 9F               [12]  404 	subb	a,r7
      0044B4 50 15            [24]  405 	jnc	00123$
                                    406 ;	free result
      0044B6 75 82 00         [24]  407 	mov	dpl, #0x00
      0044B9 22               [24]  408 	ret
      0044BA                        409 00115$:
                                    410 ;	keyboards/ajazz/ak820/ak820_settings.c:45: else if (!value || value > 1000) return false;
      0044BA ED               [12]  411 	mov	a,r5
      0044BB 4E               [12]  412 	orl	a,r6
      0044BC 60 09            [24]  413 	jz	00111$
      0044BE C3               [12]  414 	clr	c
      0044BF 74 E8            [12]  415 	mov	a,#0xe8
      0044C1 9D               [12]  416 	subb	a,r5
      0044C2 74 03            [12]  417 	mov	a,#0x03
      0044C4 9E               [12]  418 	subb	a,r6
      0044C5 50 04            [24]  419 	jnc	00123$
                                    420 ;	free result
      0044C7                        421 00111$:
      0044C7 75 82 00         [24]  422 	mov	dpl, #0x00
      0044CA 22               [24]  423 	ret
      0044CB                        424 00123$:
                                    425 ;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 6; i <= 14; i += 2) {
      0044CB 90 05 D6         [24]  426 	mov	dptr,#_valid_i_10000_69
      0044CE E0               [24]  427 	movx	a,@dptr
      0044CF 24 02            [12]  428 	add	a,#0x02
      0044D1 F0               [24]  429 	movx	@dptr,a
      0044D2 E0               [24]  430 	movx	a,@dptr
      0044D3 24 F1            [12]  431 	add	a,#0xff - 0x0e
      0044D5 50 B9            [24]  432 	jnc	00122$
                                    433 ;	free result
                                    434 ;	keyboards/ajazz/ak820/ak820_settings.c:47: for (i = 16; i < 22; ++i) if (candidate[i]) return false;
      0044D7 7F 10            [12]  435 	mov	r7,#0x10
      0044D9                        436 00124$:
      0044D9 EF               [12]  437 	mov	a,r7
      0044DA 12 48 0A         [24]  438 	lcall	_ak820_outline_0043
      0044DD E0               [24]  439 	movx	a,@dptr
      0044DE 60 04            [24]  440 	jz	00125$
      0044E0 75 82 00         [24]  441 	mov	dpl, #0x00
      0044E3 22               [24]  442 	ret
      0044E4                        443 00125$:
      0044E4 0F               [12]  444 	inc	r7
      0044E5 BF 16 00         [24]  445 	cjne	r7,#0x16,00237$
      0044E8                        446 00237$:
      0044E8 40 EF            [24]  447 	jc	00124$
                                    448 ;	keyboards/ajazz/ak820/ak820_settings.c:48: return word(candidate + 22) == checksum();
      0044EA 90 05 CC         [24]  449 	mov	dptr,#(_candidate + 0x0016)
      0044ED 12 43 92         [24]  450 	lcall	_word
      0044F0 12 43 61         [24]  451 	lcall	_ak820_outline_0136
      0044F3 C0 07            [24]  452 	push	ar7
      0044F5 C0 06            [24]  453 	push	ar6
      0044F7 12 43 D7         [24]  454 	lcall	_checksum
      0044FA 12 38 AD         [24]  455 	lcall	_ak820_outline_0149
      0044FD D0 06            [24]  456 	pop	ar6
      0044FF D0 07            [24]  457 	pop	ar7
      004501 EE               [12]  458 	mov	a,r6
      004502 B5 04 07         [24]  459 	cjne	a,ar4,00239$
      004505 EF               [12]  460 	mov	a,r7
      004506 B5 05 03         [24]  461 	cjne	a,ar5,00239$
      004509 D3               [12]  462 	setb	c
      00450A 80 01            [24]  463 	sjmp	00240$
      00450C                        464 00239$:
      00450C C3               [12]  465 	clr	c
      00450D                        466 00240$:
      00450D 92 0E            [24]  467 	mov  _valid_sloc0_1_0,c
      00450F 12 38 B2         [24]  468 	lcall	_ak820_outline_0154
                                    469 ;	keyboards/ajazz/ak820/ak820_settings.c:49: }
      004512 22               [24]  470 	ret
                                    471 ;------------------------------------------------------------
                                    472 ;Allocation info for local variables in function 'commit'
                                    473 ;------------------------------------------------------------
                                    474 ;	keyboards/ajazz/ak820/ak820_settings.c:53: static int commit(void) {
                                    475 ;	-----------------------------------------
                                    476 ;	 function commit
                                    477 ;	-----------------------------------------
      004513                        478 _commit:
                                    479 ;	keyboards/ajazz/ak820/ak820_settings.c:54: if (!ak820_nvm_ok()) return -1;
      004513 12 3E 19         [24]  480 	lcall	_ak820_nvm_ok
      004516 E5 82            [12]  481 	mov	a, dpl
      004518 70 04            [24]  482 	jnz	00102$
      00451A 90 FF FF         [24]  483 	mov	dptr,#0xffff
      00451D 22               [24]  484 	ret
      00451E                        485 00102$:
                                    486 ;	keyboards/ajazz/ak820/ak820_settings.c:55: if (!memcmp(current, candidate, sizeof(current))) return 0;
      00451E 90 0D F0         [24]  487 	mov	dptr,#_memcmp_PARM_2
      004521 74 B6            [12]  488 	mov	a,#_candidate
      004523 F0               [24]  489 	movx	@dptr,a
      004524 74 05            [12]  490 	mov	a,#(_candidate >> 8)
      004526 12 38 5F         [24]  491 	lcall	_ak820_outline_0085
      004529 90 0D F3         [24]  492 	mov	dptr,#_memcmp_PARM_3
      00452C 12 48 16         [24]  493 	lcall	_ak820_outline_0064
      00452F 90 05 9E         [24]  494 	mov	dptr,#_current
      004532 F5 F0            [12]  495 	mov	b,a
      004534 12 BD 83         [24]  496 	lcall	_memcmp
      004537 12 38 78         [24]  497 	lcall	_ak820_outline_0103
      00453A 45 F0            [12]  498 	orl	a,b
      00453C 70 04            [24]  499 	jnz	00104$
      00453E 90 00 00         [24]  500 	mov	dptr,#0x0000
      004541 22               [24]  501 	ret
      004542                        502 00104$:
                                    503 ;	keyboards/ajazz/ak820/ak820_settings.c:56: clear_keyboard();
      004542 12 7A 98         [24]  504 	lcall	_clear_keyboard
                                    505 ;	keyboards/ajazz/ak820/ak820_settings.c:57: ak820_nvm_begin();
      004545 12 3F 7A         [24]  506 	lcall	_ak820_nvm_begin
                                    507 ;	keyboards/ajazz/ak820/ak820_settings.c:58: ak820_eeprom_update_block_xdata(candidate, (void *)AK820_SETTINGS_ADDR, sizeof(candidate));
      004548 90 05 95         [24]  508 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00454B 74 A8            [12]  509 	mov	a,#0xa8
      00454D F0               [24]  510 	movx	@dptr,a
      00454E 74 06            [12]  511 	mov	a,#0x06
      004550 12 38 5F         [24]  512 	lcall	_ak820_outline_0085
      004553 90 05 98         [24]  513 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004556 12 48 16         [24]  514 	lcall	_ak820_outline_0064
      004559 90 05 B6         [24]  515 	mov	dptr,#_candidate
      00455C 12 42 1C         [24]  516 	lcall	_ak820_eeprom_update_block_xdata
                                    517 ;	keyboards/ajazz/ak820/ak820_settings.c:59: ak820_nvm_end();
      00455F 12 3F 8F         [24]  518 	lcall	_ak820_nvm_end
                                    519 ;	keyboards/ajazz/ak820/ak820_settings.c:60: if (!ak820_nvm_ok()) return -1;
      004562 12 3E 19         [24]  520 	lcall	_ak820_nvm_ok
      004565 E5 82            [12]  521 	mov	a, dpl
      004567 70 04            [24]  522 	jnz	00106$
      004569 90 FF FF         [24]  523 	mov	dptr,#0xffff
      00456C 22               [24]  524 	ret
      00456D                        525 00106$:
                                    526 ;	keyboards/ajazz/ak820/ak820_settings.c:61: memcpy(current, candidate, sizeof(current));
      00456D 12 47 EE         [24]  527 	lcall	_ak820_outline_0019
      004570 12 BC AA         [24]  528 	lcall	___memcpy
                                    529 ;	keyboards/ajazz/ak820/ak820_settings.c:62: return 0;
      004573 90 00 00         [24]  530 	mov	dptr,#0x0000
                                    531 ;	keyboards/ajazz/ak820/ak820_settings.c:63: }
      004576 22               [24]  532 	ret
                                    533 ;------------------------------------------------------------
                                    534 ;Allocation info for local variables in function 'ak820_settings_init'
                                    535 ;------------------------------------------------------------
                                    536 ;i             Allocated with name '_ak820_settings_init_i_10000_86'
                                    537 ;blank_zero    Allocated with name '_ak820_settings_init_blank_zero_10000_86'
                                    538 ;blank_erased  Allocated with name '_ak820_settings_init_blank_erased_10000_86'
                                    539 ;------------------------------------------------------------
                                    540 ;	keyboards/ajazz/ak820/ak820_settings.c:64: void ak820_settings_init(void) {
                                    541 ;	-----------------------------------------
                                    542 ;	 function ak820_settings_init
                                    543 ;	-----------------------------------------
      004577                        544 _ak820_settings_init:
                                    545 ;	keyboards/ajazz/ak820/ak820_settings.c:66: bool blank_zero = true, blank_erased = true;
      004577 90 05 D7         [24]  546 	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
      00457A 74 01            [12]  547 	mov	a,#0x01
      00457C F0               [24]  548 	movx	@dptr,a
      00457D 90 05 D8         [24]  549 	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
      004580 F0               [24]  550 	movx	@dptr,a
                                    551 ;	keyboards/ajazz/ak820/ak820_settings.c:67: ak820_eeprom_read_block_xdata(candidate, (const void *)AK820_SETTINGS_ADDR, sizeof(candidate));
      004581 90 05 85         [24]  552 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004584 74 A8            [12]  553 	mov	a,#0xa8
      004586 F0               [24]  554 	movx	@dptr,a
      004587 74 06            [12]  555 	mov	a,#0x06
      004589 12 38 5F         [24]  556 	lcall	_ak820_outline_0085
      00458C 90 05 88         [24]  557 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00458F 12 48 16         [24]  558 	lcall	_ak820_outline_0064
      004592 90 05 B6         [24]  559 	mov	dptr,#_candidate
      004595 12 40 AD         [24]  560 	lcall	_ak820_eeprom_read_block_xdata
                                    561 ;	keyboards/ajazz/ak820/ak820_settings.c:68: if (!valid()) {
      004598 12 44 50         [24]  562 	lcall	_valid
      00459B E5 82            [12]  563 	mov	a, dpl
                                    564 ;	keyboards/ajazz/ak820/ak820_settings.c:71: for (i = 0; i < sizeof(candidate); ++i) {
      00459D 70 33            [24]  565 	jnz	00110$
      00459F FF               [12]  566 	mov	r7,a
      0045A0                        567 00111$:
                                    568 ;	keyboards/ajazz/ak820/ak820_settings.c:72: if (candidate[i]) blank_zero = false;
      0045A0 EF               [12]  569 	mov	a,r7
      0045A1 12 48 0A         [24]  570 	lcall	_ak820_outline_0043
      0045A4 E0               [24]  571 	movx	a,@dptr
      0045A5 60 05            [24]  572 	jz	00102$
      0045A7 90 05 D7         [24]  573 	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
      0045AA E4               [12]  574 	clr	a
      0045AB F0               [24]  575 	movx	@dptr,a
      0045AC                        576 00102$:
                                    577 ;	keyboards/ajazz/ak820/ak820_settings.c:73: if (candidate[i] != 0xFF) blank_erased = false;
      0045AC 12 48 23         [24]  578 	lcall	_ak820_outline_0111
      0045AF FE               [12]  579 	mov	r6,a
      0045B0 BE FF 02         [24]  580 	cjne	r6,#0xff,00167$
      0045B3 80 05            [24]  581 	sjmp	00112$
      0045B5                        582 00167$:
      0045B5 90 05 D8         [24]  583 	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
      0045B8 E4               [12]  584 	clr	a
      0045B9 F0               [24]  585 	movx	@dptr,a
      0045BA                        586 00112$:
                                    587 ;	keyboards/ajazz/ak820/ak820_settings.c:71: for (i = 0; i < sizeof(candidate); ++i) {
      0045BA 0F               [12]  588 	inc	r7
      0045BB BF 18 00         [24]  589 	cjne	r7,#0x18,00168$
      0045BE                        590 00168$:
      0045BE 40 E0            [24]  591 	jc	00111$
                                    592 ;	keyboards/ajazz/ak820/ak820_settings.c:75: if (!blank_zero && !blank_erased) ak820_nvm_schema_fault();
      0045C0 90 05 D7         [24]  593 	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
      0045C3 E0               [24]  594 	movx	a,@dptr
      0045C4 70 09            [24]  595 	jnz	00107$
      0045C6 90 05 D8         [24]  596 	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
      0045C9 E0               [24]  597 	movx	a,@dptr
      0045CA 70 03            [24]  598 	jnz	00107$
      0045CC 12 3E 22         [24]  599 	lcall	_ak820_nvm_schema_fault
      0045CF                        600 00107$:
                                    601 ;	keyboards/ajazz/ak820/ak820_settings.c:76: defaults();
      0045CF 12 44 35         [24]  602 	lcall	_defaults
      0045D2                        603 00110$:
                                    604 ;	keyboards/ajazz/ak820/ak820_settings.c:78: memcpy(current, candidate, sizeof(current));
      0045D2 12 47 EE         [24]  605 	lcall	_ak820_outline_0019
                                    606 ;	keyboards/ajazz/ak820/ak820_settings.c:79: }
      0045D5 02 BC AA         [24]  607 	ljmp	___memcpy
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'offset'
                                    610 ;------------------------------------------------------------
                                    611 ;id            Allocated with name '_offset_id_10000_94'
                                    612 ;i             Allocated with name '_offset_i_20000_96'
                                    613 ;------------------------------------------------------------
                                    614 ;	keyboards/ajazz/ak820/ak820_settings.c:95: static uint8_t offset(uint8_t id) {
                                    615 ;	-----------------------------------------
                                    616 ;	 function offset
                                    617 ;	-----------------------------------------
      0045D8                        618 _offset:
      0045D8 E5 82            [12]  619 	mov	a,dpl
      0045DA 90 05 D9         [24]  620 	mov	dptr,#_offset_id_10000_94
      0045DD F0               [24]  621 	movx	@dptr,a
                                    622 ;	keyboards/ajazz/ak820/ak820_settings.c:96: for (uint8_t i = 0; i < sizeof(ids); ++i) if (ids[i] == id) return positions[i];
      0045DE E0               [24]  623 	movx	a,@dptr
      0045DF FF               [12]  624 	mov	r7,a
      0045E0 7E 00            [12]  625 	mov	r6,#0x00
      0045E2                        626 00105$:
      0045E2 BE 05 00         [24]  627 	cjne	r6,#0x05,00130$
      0045E5                        628 00130$:
      0045E5 50 13            [24]  629 	jnc	00103$
      0045E7 EE               [12]  630 	mov	a,r6
      0045E8 90 BF 07         [24]  631 	mov	dptr,#_ids
      0045EB 93               [24]  632 	movc	a,@a+dptr
      0045EC B5 07 08         [24]  633 	cjne	a,ar7,00106$
      0045EF EE               [12]  634 	mov	a,r6
      0045F0 90 BF 0C         [24]  635 	mov	dptr,#_positions
      0045F3 93               [24]  636 	movc	a,@a+dptr
      0045F4 F5 82            [12]  637 	mov	dpl,a
      0045F6 22               [24]  638 	ret
      0045F7                        639 00106$:
      0045F7 0E               [12]  640 	inc	r6
      0045F8 80 E8            [24]  641 	sjmp	00105$
      0045FA                        642 00103$:
                                    643 ;	keyboards/ajazz/ak820/ak820_settings.c:97: return 0;
      0045FA 75 82 00         [24]  644 	mov	dpl, #0x00
                                    645 ;	keyboards/ajazz/ak820/ak820_settings.c:98: }
      0045FD 22               [24]  646 	ret
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'ak820_settings_query'
                                    649 ;------------------------------------------------------------
                                    650 ;buffer        Allocated with name '_ak820_settings_query_PARM_2'
                                    651 ;size          Allocated with name '_ak820_settings_query_PARM_3'
                                    652 ;greater_than  Allocated with name '_ak820_settings_query_greater_than_10000_98'
                                    653 ;i             Allocated with name '_ak820_settings_query_i_10000_99'
                                    654 ;used          Allocated with name '_ak820_settings_query_used_10000_99'
                                    655 ;------------------------------------------------------------
                                    656 ;	keyboards/ajazz/ak820/ak820_settings.c:99: void ak820_settings_query(uint16_t greater_than, uint8_t AK820_XDATA *buffer, uint8_t size) {
                                    657 ;	-----------------------------------------
                                    658 ;	 function ak820_settings_query
                                    659 ;	-----------------------------------------
      0045FE                        660 _ak820_settings_query:
      0045FE 12 38 8A         [24]  661 	lcall	_ak820_outline_0108
      004601 90 05 DD         [24]  662 	mov	dptr,#_ak820_settings_query_greater_than_10000_98
      004604 12 38 8F         [24]  663 	lcall	_ak820_outline_0109
                                    664 ;	keyboards/ajazz/ak820/ak820_settings.c:100: uint8_t i, used = 0;
      004607 90 05 DF         [24]  665 	mov	dptr,#_ak820_settings_query_used_10000_99
      00460A E4               [12]  666 	clr	a
      00460B F0               [24]  667 	movx	@dptr,a
                                    668 ;	keyboards/ajazz/ak820/ak820_settings.c:101: for (i = 0; i < size; ++i) buffer[i] = 0xFF;
      00460C 90 05 DA         [24]  669 	mov	dptr,#_ak820_settings_query_PARM_2
      00460F 12 38 36         [24]  670 	lcall	_ak820_outline_0054
      004612 90 05 DC         [24]  671 	mov	dptr,#_ak820_settings_query_PARM_3
      004615 E0               [24]  672 	movx	a,@dptr
      004616 FD               [12]  673 	mov	r5,a
      004617 7C 00            [12]  674 	mov	r4,#0x00
      004619                        675 00108$:
      004619 C3               [12]  676 	clr	c
      00461A EC               [12]  677 	mov	a,r4
      00461B 9D               [12]  678 	subb	a,r5
      00461C 50 0A            [24]  679 	jnc	00101$
      00461E EC               [12]  680 	mov	a,r4
      00461F 12 38 26         [24]  681 	lcall	_ak820_outline_0020
      004622 74 FF            [12]  682 	mov	a,#0xff
      004624 F0               [24]  683 	movx	@dptr,a
      004625 0C               [12]  684 	inc	r4
      004626 80 F1            [24]  685 	sjmp	00108$
      004628                        686 00101$:
                                    687 ;	keyboards/ajazz/ak820/ak820_settings.c:102: if (greater_than >= 19) return;
      004628 90 05 DD         [24]  688 	mov	dptr,#_ak820_settings_query_greater_than_10000_98
      00462B 12 38 72         [24]  689 	lcall	_ak820_outline_0102
      00462E C3               [12]  690 	clr	c
      00462F EB               [12]  691 	mov	a,r3
      004630 94 13            [12]  692 	subb	a,#0x13
      004632 EC               [12]  693 	mov	a,r4
      004633 94 00            [12]  694 	subb	a,#0x00
      004635 40 01            [24]  695 	jc	00129$
                                    696 ;	keyboards/ajazz/ak820/ak820_settings.c:103: for (i = 0; i < sizeof(ids) && used + 2 <= size; ++i) {
      004637 22               [24]  697 	ret
      004638                        698 00129$:
      004638 7C 00            [12]  699 	mov	r4,#0x00
      00463A                        700 00112$:
      00463A BC 05 00         [24]  701 	cjne	r4,#0x05,00169$
      00463D                        702 00169$:
      00463D 50 54            [24]  703 	jnc	00114$
      00463F C0 06            [24]  704 	push	ar6
      004641 C0 07            [24]  705 	push	ar7
      004643 90 05 DF         [24]  706 	mov	dptr,#_ak820_settings_query_used_10000_99
      004646 E0               [24]  707 	movx	a,@dptr
      004647 FB               [12]  708 	mov	r3,a
      004648 F9               [12]  709 	mov	r1,a
      004649 7A 00            [12]  710 	mov	r2,#0x00
      00464B 74 02            [12]  711 	mov	a,#0x02
      00464D 29               [12]  712 	add	a, r1
      00464E F9               [12]  713 	mov	r1,a
      00464F E4               [12]  714 	clr	a
      004650 3A               [12]  715 	addc	a, r2
      004651 FA               [12]  716 	mov	r2,a
      004652 8D 00            [24]  717 	mov	ar0,r5
      004654 7F 00            [12]  718 	mov	r7,#0x00
      004656 C3               [12]  719 	clr	c
      004657 E8               [12]  720 	mov	a,r0
      004658 99               [12]  721 	subb	a,r1
      004659 EF               [12]  722 	mov	a,r7
      00465A 64 80            [12]  723 	xrl	a,#0x80
      00465C 8A F0            [24]  724 	mov	b,r2
      00465E 63 F0 80         [24]  725 	xrl	b,#0x80
      004661 95 F0            [12]  726 	subb	a,b
      004663 D0 07            [24]  727 	pop	ar7
      004665 D0 06            [24]  728 	pop	ar6
      004667 40 2A            [24]  729 	jc	00114$
                                    730 ;	free result
                                    731 ;	keyboards/ajazz/ak820/ak820_settings.c:104: if (ids[i] > (uint8_t)greater_than) { buffer[used++] = ids[i]; buffer[used++] = 0; }
      004669 EC               [12]  732 	mov	a,r4
      00466A 90 BF 07         [24]  733 	mov	dptr,#_ids
      00466D 93               [24]  734 	movc	a,@a+dptr
      00466E FA               [12]  735 	mov	r2,a
      00466F 90 05 DD         [24]  736 	mov	dptr,#_ak820_settings_query_greater_than_10000_98
      004672 E0               [24]  737 	movx	a,@dptr
      004673 C3               [12]  738 	clr	c
      004674 9A               [12]  739 	subb	a,r2
      004675 50 19            [24]  740 	jnc	00113$
                                    741 ;	free result
      004677 90 05 DF         [24]  742 	mov	dptr,#_ak820_settings_query_used_10000_99
      00467A EB               [12]  743 	mov	a,r3
      00467B 04               [12]  744 	inc	a
      00467C F0               [24]  745 	movx	@dptr,a
      00467D EB               [12]  746 	mov	a,r3
      00467E 12 38 26         [24]  747 	lcall	_ak820_outline_0020
      004681 EA               [12]  748 	mov	a,r2
      004682 F0               [24]  749 	movx	@dptr,a
      004683 90 05 DF         [24]  750 	mov	dptr,#_ak820_settings_query_used_10000_99
      004686 E0               [24]  751 	movx	a,@dptr
      004687 FB               [12]  752 	mov	r3,a
      004688 04               [12]  753 	inc	a
      004689 F0               [24]  754 	movx	@dptr,a
      00468A EB               [12]  755 	mov	a,r3
      00468B 12 38 26         [24]  756 	lcall	_ak820_outline_0020
      00468E E4               [12]  757 	clr	a
      00468F F0               [24]  758 	movx	@dptr,a
      004690                        759 00113$:
                                    760 ;	keyboards/ajazz/ak820/ak820_settings.c:103: for (i = 0; i < sizeof(ids) && used + 2 <= size; ++i) {
      004690 0C               [12]  761 	inc	r4
      004691 80 A7            [24]  762 	sjmp	00112$
      004693                        763 00114$:
                                    764 ;	keyboards/ajazz/ak820/ak820_settings.c:106: }
      004693 22               [24]  765 	ret
                                    766 ;------------------------------------------------------------
                                    767 ;Allocation info for local variables in function 'ak820_settings_get'
                                    768 ;------------------------------------------------------------
                                    769 ;buffer        Allocated with name '_ak820_settings_get_PARM_2'
                                    770 ;capacity      Allocated with name '_ak820_settings_get_PARM_3'
                                    771 ;id            Allocated with name '_ak820_settings_get_id_10000_106'
                                    772 ;out           Allocated with name '_ak820_settings_get_out_10000_107'
                                    773 ;pos           Allocated with name '_ak820_settings_get_pos_10000_107'
                                    774 ;width         Allocated with name '_ak820_settings_get_width_10000_107'
                                    775 ;------------------------------------------------------------
                                    776 ;	keyboards/ajazz/ak820/ak820_settings.c:107: int ak820_settings_get(uint16_t id, uint8_t AK820_XDATA *buffer, uint8_t capacity) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_settings_get
                                    779 ;	-----------------------------------------
      004694                        780 _ak820_settings_get:
      004694 12 38 8A         [24]  781 	lcall	_ak820_outline_0108
      004697 90 05 E3         [24]  782 	mov	dptr,#_ak820_settings_get_id_10000_106
      00469A 12 38 8F         [24]  783 	lcall	_ak820_outline_0109
                                    784 ;	keyboards/ajazz/ak820/ak820_settings.c:108: uint8_t AK820_XDATA *out = buffer;
      00469D 90 05 E0         [24]  785 	mov	dptr,#_ak820_settings_get_PARM_2
      0046A0 12 38 36         [24]  786 	lcall	_ak820_outline_0054
                                    787 ;	keyboards/ajazz/ak820/ak820_settings.c:109: uint8_t pos, width = id == 1 ? 1 : 2;
      0046A3 90 05 E3         [24]  788 	mov	dptr,#_ak820_settings_get_id_10000_106
      0046A6 12 38 4D         [24]  789 	lcall	_ak820_outline_0060
      0046A9 BC 01 07         [24]  790 	cjne	r4,#0x01,00110$
      0046AC BD 00 04         [24]  791 	cjne	r5,#0x00,00110$
      0046AF 7B 01            [12]  792 	mov	r3,#0x01
      0046B1 80 02            [24]  793 	sjmp	00111$
      0046B3                        794 00110$:
      0046B3 7B 02            [12]  795 	mov	r3,#0x02
      0046B5                        796 00111$:
                                    797 ;	keyboards/ajazz/ak820/ak820_settings.c:110: if (id > 255) return -1;
      0046B5 12 48 2F         [24]  798 	lcall	_ak820_outline_0115
      0046B8 50 04            [24]  799 	jnc	00102$
                                    800 ;	free result
      0046BA 90 FF FF         [24]  801 	mov	dptr,#0xffff
      0046BD 22               [24]  802 	ret
      0046BE                        803 00102$:
                                    804 ;	keyboards/ajazz/ak820/ak820_settings.c:111: pos = offset((uint8_t)id);
      0046BE 90 05 E3         [24]  805 	mov	dptr,#_ak820_settings_get_id_10000_106
      0046C1 E0               [24]  806 	movx	a,@dptr
      0046C2 F5 82            [12]  807 	mov	dpl,a
      0046C4 C0 07            [24]  808 	push	ar7
      0046C6 C0 06            [24]  809 	push	ar6
      0046C8 C0 03            [24]  810 	push	ar3
      0046CA 12 45 D8         [24]  811 	lcall	_offset
      0046CD AD 82            [24]  812 	mov	r5, dpl
      0046CF D0 03            [24]  813 	pop	ar3
      0046D1 D0 06            [24]  814 	pop	ar6
      0046D3 D0 07            [24]  815 	pop	ar7
                                    816 ;	keyboards/ajazz/ak820/ak820_settings.c:112: if (!pos || capacity < width) return -1;
      0046D5 ED               [12]  817 	mov	a,r5
      0046D6 60 08            [24]  818 	jz	00103$
      0046D8 90 05 E2         [24]  819 	mov	dptr,#_ak820_settings_get_PARM_3
      0046DB E0               [24]  820 	movx	a,@dptr
      0046DC C3               [12]  821 	clr	c
      0046DD 9B               [12]  822 	subb	a,r3
      0046DE 50 04            [24]  823 	jnc	00104$
      0046E0                        824 00103$:
      0046E0 90 FF FF         [24]  825 	mov	dptr,#0xffff
      0046E3 22               [24]  826 	ret
      0046E4                        827 00104$:
                                    828 ;	keyboards/ajazz/ak820/ak820_settings.c:113: out[0] = current[pos];
      0046E4 ED               [12]  829 	mov	a,r5
      0046E5 24 9E            [12]  830 	add	a, #_current
      0046E7 F5 82            [12]  831 	mov	dpl,a
      0046E9 E4               [12]  832 	clr	a
      0046EA 34 05            [12]  833 	addc	a, #(_current >> 8)
      0046EC F5 83            [12]  834 	mov	dph,a
      0046EE 12 43 48         [24]  835 	lcall	_ak820_outline_0096
                                    836 ;	keyboards/ajazz/ak820/ak820_settings.c:114: if (width == 2) out[1] = current[pos + 1];
      0046F1 BB 02 18         [24]  837 	cjne	r3,#0x02,00107$
      0046F4 0E               [12]  838 	inc	r6
      0046F5 BE 00 01         [24]  839 	cjne	r6,#0x00,00147$
      0046F8 0F               [12]  840 	inc	r7
      0046F9                        841 00147$:
      0046F9 0D               [12]  842 	inc	r5
      0046FA ED               [12]  843 	mov	a,r5
      0046FB 33               [12]  844 	rlc	a
      0046FC 95 E0            [12]  845 	subb	a,acc
      0046FE FC               [12]  846 	mov	r4,a
      0046FF ED               [12]  847 	mov	a,r5
      004700 24 9E            [12]  848 	add	a, #_current
      004702 F5 82            [12]  849 	mov	dpl,a
      004704 EC               [12]  850 	mov	a,r4
      004705 34 05            [12]  851 	addc	a, #(_current >> 8)
      004707 F5 83            [12]  852 	mov	dph,a
      004709 12 43 48         [24]  853 	lcall	_ak820_outline_0096
      00470C                        854 00107$:
                                    855 ;	keyboards/ajazz/ak820/ak820_settings.c:115: return 0;
      00470C 90 00 00         [24]  856 	mov	dptr,#0x0000
                                    857 ;	keyboards/ajazz/ak820/ak820_settings.c:116: }
      00470F 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'ak820_settings_set'
                                    861 ;------------------------------------------------------------
                                    862 ;buffer        Allocated with name '_ak820_settings_set_PARM_2'
                                    863 ;capacity      Allocated with name '_ak820_settings_set_PARM_3'
                                    864 ;id            Allocated with name '_ak820_settings_set_id_10000_111'
                                    865 ;in            Allocated with name '_ak820_settings_set_in_10000_112'
                                    866 ;pos           Allocated with name '_ak820_settings_set_pos_10000_112'
                                    867 ;width         Allocated with name '_ak820_settings_set_width_10000_112'
                                    868 ;------------------------------------------------------------
                                    869 ;	keyboards/ajazz/ak820/ak820_settings.c:117: int ak820_settings_set(uint16_t id, const uint8_t AK820_XDATA *buffer, uint8_t capacity) {
                                    870 ;	-----------------------------------------
                                    871 ;	 function ak820_settings_set
                                    872 ;	-----------------------------------------
      004710                        873 _ak820_settings_set:
      004710 12 38 8A         [24]  874 	lcall	_ak820_outline_0108
      004713 90 05 E8         [24]  875 	mov	dptr,#_ak820_settings_set_id_10000_111
      004716 12 38 8F         [24]  876 	lcall	_ak820_outline_0109
                                    877 ;	keyboards/ajazz/ak820/ak820_settings.c:118: const uint8_t AK820_XDATA *in = buffer;
      004719 90 05 E5         [24]  878 	mov	dptr,#_ak820_settings_set_PARM_2
      00471C 12 38 36         [24]  879 	lcall	_ak820_outline_0054
                                    880 ;	keyboards/ajazz/ak820/ak820_settings.c:119: uint8_t pos, width = id == 1 ? 1 : 2;
      00471F 90 05 E8         [24]  881 	mov	dptr,#_ak820_settings_set_id_10000_111
      004722 12 38 4D         [24]  882 	lcall	_ak820_outline_0060
      004725 BC 01 07         [24]  883 	cjne	r4,#0x01,00113$
      004728 BD 00 04         [24]  884 	cjne	r5,#0x00,00113$
      00472B 7B 01            [12]  885 	mov	r3,#0x01
      00472D 80 02            [24]  886 	sjmp	00114$
      00472F                        887 00113$:
      00472F 7B 02            [12]  888 	mov	r3,#0x02
      004731                        889 00114$:
                                    890 ;	keyboards/ajazz/ak820/ak820_settings.c:120: if (id > 255) return -1;
      004731 12 48 2F         [24]  891 	lcall	_ak820_outline_0115
      004734 50 04            [24]  892 	jnc	00102$
                                    893 ;	free result
      004736 90 FF FF         [24]  894 	mov	dptr,#0xffff
      004739 22               [24]  895 	ret
      00473A                        896 00102$:
                                    897 ;	keyboards/ajazz/ak820/ak820_settings.c:121: pos = offset((uint8_t)id);
      00473A 90 05 E8         [24]  898 	mov	dptr,#_ak820_settings_set_id_10000_111
      00473D E0               [24]  899 	movx	a,@dptr
      00473E F5 82            [12]  900 	mov	dpl,a
      004740 C0 07            [24]  901 	push	ar7
      004742 C0 06            [24]  902 	push	ar6
      004744 C0 03            [24]  903 	push	ar3
      004746 12 45 D8         [24]  904 	lcall	_offset
      004749 AD 82            [24]  905 	mov	r5, dpl
      00474B D0 03            [24]  906 	pop	ar3
      00474D D0 06            [24]  907 	pop	ar6
      00474F D0 07            [24]  908 	pop	ar7
                                    909 ;	keyboards/ajazz/ak820/ak820_settings.c:122: if (!pos || capacity < width || !ak820_nvm_ok()) return -1;
      004751 ED               [12]  910 	mov	a,r5
      004752 60 0F            [24]  911 	jz	00103$
      004754 90 05 E7         [24]  912 	mov	dptr,#_ak820_settings_set_PARM_3
      004757 E0               [24]  913 	movx	a,@dptr
      004758 C3               [12]  914 	clr	c
      004759 9B               [12]  915 	subb	a,r3
      00475A 40 07            [24]  916 	jc	00103$
      00475C 12 3E 19         [24]  917 	lcall	_ak820_nvm_ok
      00475F E5 82            [12]  918 	mov	a, dpl
      004761 70 04            [24]  919 	jnz	00104$
      004763                        920 00103$:
      004763 90 FF FF         [24]  921 	mov	dptr,#0xffff
      004766 22               [24]  922 	ret
      004767                        923 00104$:
                                    924 ;	keyboards/ajazz/ak820/ak820_settings.c:123: memcpy(candidate, current, sizeof(candidate));
      004767 90 0D E2         [24]  925 	mov	dptr,#___memcpy_PARM_2
      00476A 74 9E            [12]  926 	mov	a,#_current
      00476C F0               [24]  927 	movx	@dptr,a
      00476D 74 05            [12]  928 	mov	a,#(_current >> 8)
      00476F 12 38 5F         [24]  929 	lcall	_ak820_outline_0085
      004772 90 0D E5         [24]  930 	mov	dptr,#___memcpy_PARM_3
      004775 12 48 16         [24]  931 	lcall	_ak820_outline_0064
      004778 90 05 B6         [24]  932 	mov	dptr,#_candidate
      00477B F5 F0            [12]  933 	mov	b,a
      00477D C0 07            [24]  934 	push	ar7
      00477F C0 06            [24]  935 	push	ar6
      004781 C0 05            [24]  936 	push	ar5
      004783 C0 03            [24]  937 	push	ar3
      004785 12 BC AA         [24]  938 	lcall	___memcpy
      004788 D0 03            [24]  939 	pop	ar3
      00478A D0 05            [24]  940 	pop	ar5
      00478C D0 06            [24]  941 	pop	ar6
      00478E D0 07            [24]  942 	pop	ar7
                                    943 ;	keyboards/ajazz/ak820/ak820_settings.c:124: candidate[pos] = in[0];
      004790 ED               [12]  944 	mov	a,r5
      004791 24 B6            [12]  945 	add	a, #_candidate
      004793 FA               [12]  946 	mov	r2,a
      004794 E4               [12]  947 	clr	a
      004795 34 05            [12]  948 	addc	a, #(_candidate >> 8)
      004797 FC               [12]  949 	mov	r4,a
      004798 12 38 7E         [24]  950 	lcall	_ak820_outline_0105
      00479B 8A 82            [24]  951 	mov	dpl,r2
      00479D 8C 83            [24]  952 	mov	dph,r4
      00479F F0               [24]  953 	movx	@dptr,a
                                    954 ;	keyboards/ajazz/ak820/ak820_settings.c:125: if (width == 2) candidate[pos + 1] = in[1];
      0047A0 BB 02 15         [24]  955 	cjne	r3,#0x02,00108$
      0047A3 0D               [12]  956 	inc	r5
      0047A4 ED               [12]  957 	mov	a,r5
      0047A5 33               [12]  958 	rlc	a
      0047A6 95 E0            [12]  959 	subb	a,acc
      0047A8 FC               [12]  960 	mov	r4,a
      0047A9 ED               [12]  961 	mov	a,r5
      0047AA 24 B6            [12]  962 	add	a, #_candidate
      0047AC FD               [12]  963 	mov	r5,a
      0047AD EC               [12]  964 	mov	a,r4
      0047AE 34 05            [12]  965 	addc	a, #(_candidate >> 8)
      0047B0 FC               [12]  966 	mov	r4,a
      0047B1 12 38 6B         [24]  967 	lcall	_ak820_outline_0095
      0047B4 12 43 88         [24]  968 	lcall	_ak820_outline_0187
      0047B7 F0               [24]  969 	movx	@dptr,a
      0047B8                        970 00108$:
                                    971 ;	keyboards/ajazz/ak820/ak820_settings.c:126: seal();
      0047B8 12 44 23         [24]  972 	lcall	_seal
                                    973 ;	keyboards/ajazz/ak820/ak820_settings.c:127: if (!valid()) return -1;
      0047BB 12 44 50         [24]  974 	lcall	_valid
      0047BE E5 82            [12]  975 	mov	a, dpl
      0047C0 70 04            [24]  976 	jnz	00110$
      0047C2 90 FF FF         [24]  977 	mov	dptr,#0xffff
      0047C5 22               [24]  978 	ret
      0047C6                        979 00110$:
                                    980 ;	keyboards/ajazz/ak820/ak820_settings.c:128: return commit();
                                    981 ;	keyboards/ajazz/ak820/ak820_settings.c:129: }
      0047C6 02 45 13         [24]  982 	ljmp	_commit
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'ak820_settings_reset'
                                    985 ;------------------------------------------------------------
                                    986 ;	keyboards/ajazz/ak820/ak820_settings.c:130: int ak820_settings_reset(void) { defaults(); return commit(); }
                                    987 ;	-----------------------------------------
                                    988 ;	 function ak820_settings_reset
                                    989 ;	-----------------------------------------
      0047C9                        990 _ak820_settings_reset:
      0047C9 12 44 35         [24]  991 	lcall	_defaults
      0047CC 02 45 13         [24]  992 	ljmp	_commit
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'ak820_settings_grave_esc'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_settings.c:131: uint8_t ak820_settings_grave_esc(void) { return current[5]; }
                                    997 ;	-----------------------------------------
                                    998 ;	 function ak820_settings_grave_esc
                                    999 ;	-----------------------------------------
      0047CF                       1000 _ak820_settings_grave_esc:
      0047CF 90 05 A3         [24] 1001 	mov	dptr,#(_current + 0x0005)
      0047D2 E0               [24] 1002 	movx	a,@dptr
      0047D3 F5 82            [12] 1003 	mov	dpl,a
      0047D5 22               [24] 1004 	ret
                                   1005 ;------------------------------------------------------------
                                   1006 ;Allocation info for local variables in function 'ak820_settings_combo_term'
                                   1007 ;------------------------------------------------------------
                                   1008 ;	keyboards/ajazz/ak820/ak820_settings.c:132: uint16_t ak820_settings_combo_term(void) { return word(current + 6); }
                                   1009 ;	-----------------------------------------
                                   1010 ;	 function ak820_settings_combo_term
                                   1011 ;	-----------------------------------------
      0047D6                       1012 _ak820_settings_combo_term:
      0047D6 90 05 A4         [24] 1013 	mov	dptr,#(_current + 0x0006)
      0047D9 02 43 92         [24] 1014 	ljmp	_word
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'ak820_settings_tapping_term'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	keyboards/ajazz/ak820/ak820_settings.c:133: uint16_t ak820_settings_tapping_term(void) { return word(current + 8); }
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function ak820_settings_tapping_term
                                   1021 ;	-----------------------------------------
      0047DC                       1022 _ak820_settings_tapping_term:
      0047DC 90 05 A6         [24] 1023 	mov	dptr,#(_current + 0x0008)
      0047DF 02 43 92         [24] 1024 	ljmp	_word
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'ak820_settings_tap_code_delay'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	keyboards/ajazz/ak820/ak820_settings.c:134: uint16_t ak820_settings_tap_code_delay(void) { return word(current + 10); }
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function ak820_settings_tap_code_delay
                                   1031 ;	-----------------------------------------
      0047E2                       1032 _ak820_settings_tap_code_delay:
      0047E2 90 05 A8         [24] 1033 	mov	dptr,#(_current + 0x000a)
      0047E5 02 43 92         [24] 1034 	ljmp	_word
                                   1035 ;------------------------------------------------------------
                                   1036 ;Allocation info for local variables in function 'ak820_settings_caps_delay'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	keyboards/ajazz/ak820/ak820_settings.c:135: uint16_t ak820_settings_caps_delay(void) { return word(current + 12); }
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function ak820_settings_caps_delay
                                   1041 ;	-----------------------------------------
      0047E8                       1042 _ak820_settings_caps_delay:
      0047E8 90 05 AA         [24] 1043 	mov	dptr,#(_current + 0x000c)
      0047EB 02 43 92         [24] 1044 	ljmp	_word
                                   1045 ;------------------------------------------------------------
                                   1046 ;Allocation info for local variables in function 'ak820_settings_autoshift_timeout'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	keyboards/ajazz/ak820/ak820_settings.c:136: uint16_t ak820_settings_autoshift_timeout(void) { return word(current + 14); }
                                   1049 ;	-----------------------------------------
                                   1050 	.area CSEG    (CODE)
                                   1051 	.area CONST   (CODE)
                                   1052 	.area CONST   (CODE)
      00BEEF                       1053 _default_record:
      00BEEF 51                    1054 	.db #0x51	; 81	'Q'
      00BEF0 53                    1055 	.db #0x53	; 83	'S'
      00BEF1 01                    1056 	.db #0x01	; 1
      00BEF2 0B                    1057 	.db #0x0b	; 11
      00BEF3 3F                    1058 	.db #0x3f	; 63
      00BEF4 00                    1059 	.db #0x00	; 0
      00BEF5 28                    1060 	.db #0x28	; 40
      00BEF6 00                    1061 	.db #0x00	; 0
      00BEF7 C8                    1062 	.db #0xc8	; 200
      00BEF8 00                    1063 	.db #0x00	; 0
      00BEF9 00                    1064 	.db #0x00	; 0
      00BEFA 00                    1065 	.db #0x00	; 0
      00BEFB 50                    1066 	.db #0x50	; 80	'P'
      00BEFC 00                    1067 	.db #0x00	; 0
      00BEFD AF                    1068 	.db #0xaf	; 175
      00BEFE 00                    1069 	.db #0x00	; 0
      00BEFF 00                    1070 	.db #0x00	; 0
      00BF00 00                    1071 	.db #0x00	; 0
      00BF01 00                    1072 	.db #0x00	; 0
      00BF02 00                    1073 	.db #0x00	; 0
      00BF03 00                    1074 	.db #0x00	; 0
      00BF04 00                    1075 	.db #0x00	; 0
      00BF05 7B                    1076 	.db #0x7b	; 123
      00BF06 C9                    1077 	.db #0xc9	; 201
                                   1078 	.area CSEG    (CODE)
                                   1079 	.area CONST   (CODE)
      00BF07                       1080 _ids:
      00BF07 01                    1081 	.db #0x01	; 1
      00BF08 02                    1082 	.db #0x02	; 2
      00BF09 07                    1083 	.db #0x07	; 7
      00BF0A 12                    1084 	.db #0x12	; 18
      00BF0B 13                    1085 	.db #0x13	; 19
                                   1086 	.area CSEG    (CODE)
                                   1087 	.area CONST   (CODE)
      00BF0C                       1088 _positions:
      00BF0C 05                    1089 	.db #0x05	; 5
      00BF0D 06                    1090 	.db #0x06	; 6
      00BF0E 08                    1091 	.db #0x08	; 8
      00BF0F 0A                    1092 	.db #0x0a	; 10
      00BF10 0C                    1093 	.db #0x0c	; 12
                                   1094 	.area CSEG    (CODE)
                                   1095 	.area XINIT   (CODE)
                                   1096 	.area CABS    (ABS,CODE)
                                   1097 
                                   1098 ; Experimental exact instruction outlining.
                                   1099 	.globl _ak820_outline_0005
                                   1100 	.globl _ak820_outline_0019
                                   1101 	.globl _ak820_outline_0020
                                   1102 	.globl _ak820_outline_0043
                                   1103 	.globl _ak820_outline_0054
                                   1104 	.globl _ak820_outline_0060
                                   1105 	.globl _ak820_outline_0062
                                   1106 	.globl _ak820_outline_0064
                                   1107 	.globl _ak820_outline_0085
                                   1108 	.globl _ak820_outline_0095
                                   1109 	.globl _ak820_outline_0096
                                   1110 	.globl _ak820_outline_0102
                                   1111 	.globl _ak820_outline_0103
                                   1112 	.globl _ak820_outline_0104
                                   1113 	.globl _ak820_outline_0105
                                   1114 	.globl _ak820_outline_0108
                                   1115 	.globl _ak820_outline_0109
                                   1116 	.globl _ak820_outline_0111
                                   1117 	.globl _ak820_outline_0115
                                   1118 	.globl _ak820_outline_0123
                                   1119 	.globl _ak820_outline_0136
                                   1120 	.globl _ak820_outline_0144
                                   1121 	.globl _ak820_outline_0148
                                   1122 	.globl _ak820_outline_0149
                                   1123 	.globl _ak820_outline_0154
                                   1124 	.globl _ak820_outline_0187
                                   1125 	.globl _ak820_outline_0193
                                   1126 	.globl _ak820_outline_0194
                                   1127 
                                   1128 	.area CSEG (CODE)
                                   1129 ; function ak820_outline_0019
      0047EE                       1130 _ak820_outline_0019:
      0047EE 90 0D E2         [24] 1131 	mov	dptr,#___memcpy_PARM_2
      0047F1 74 B6            [12] 1132 	mov	a,#_candidate
      0047F3 F0               [24] 1133 	movx	@dptr,a
      0047F4 74 05            [12] 1134 	mov	a,#(_candidate>>8)
      0047F6 A3               [24] 1135 	inc	dptr
      0047F7 F0               [24] 1136 	movx	@dptr,a
      0047F8 E4               [12] 1137 	clr	a
      0047F9 A3               [24] 1138 	inc	dptr
      0047FA F0               [24] 1139 	movx	@dptr,a
      0047FB 90 0D E5         [24] 1140 	mov	dptr,#___memcpy_PARM_3
      0047FE 74 18            [12] 1141 	mov	a,#0x18
      004800 F0               [24] 1142 	movx	@dptr,a
      004801 E4               [12] 1143 	clr	a
      004802 A3               [24] 1144 	inc	dptr
      004803 F0               [24] 1145 	movx	@dptr,a
      004804 90 05 9E         [24] 1146 	mov	dptr,#_current
      004807 F5 F0            [12] 1147 	mov	b,a
      004809 22               [24] 1148 	ret
                                   1149 
                                   1150 	.area CSEG (CODE)
                                   1151 ; function ak820_outline_0043
      00480A                       1152 _ak820_outline_0043:
      00480A 24 B6            [12] 1153 	add	a,#_candidate
      00480C FD               [12] 1154 	mov	r5,a
      00480D E4               [12] 1155 	clr	a
      00480E 34 05            [12] 1156 	addc	a,#(_candidate>>8)
      004810 FE               [12] 1157 	mov	r6,a
      004811 8D 82            [24] 1158 	mov	dpl,r5
      004813 8E 83            [24] 1159 	mov	dph,r6
      004815 22               [24] 1160 	ret
                                   1161 
                                   1162 	.area CSEG (CODE)
                                   1163 ; function ak820_outline_0064
      004816                       1164 _ak820_outline_0064:
      004816 74 18            [12] 1165 	mov	a,#0x18
      004818 F0               [24] 1166 	movx	@dptr,a
      004819 E4               [12] 1167 	clr	a
      00481A A3               [24] 1168 	inc	dptr
      00481B F0               [24] 1169 	movx	@dptr,a
      00481C 22               [24] 1170 	ret
                                   1171 
                                   1172 	.area CSEG (CODE)
                                   1173 ; function ak820_outline_0104
      00481D                       1174 _ak820_outline_0104:
      00481D 8D 82            [24] 1175 	mov	dpl,r5
      00481F 8E 83            [24] 1176 	mov	dph,r6
      004821 F0               [24] 1177 	movx	@dptr,a
      004822 22               [24] 1178 	ret
                                   1179 
                                   1180 	.area CSEG (CODE)
                                   1181 ; function ak820_outline_0111
      004823                       1182 _ak820_outline_0111:
      004823 EF               [12] 1183 	mov	a,r7
      004824 24 B6            [12] 1184 	add	a,#_candidate
      004826 F5 82            [12] 1185 	mov	dpl,a
      004828 E4               [12] 1186 	clr	a
      004829 34 05            [12] 1187 	addc	a,#(_candidate>>8)
      00482B F5 83            [12] 1188 	mov	dph,a
      00482D E0               [24] 1189 	movx	a,@dptr
      00482E 22               [24] 1190 	ret
                                   1191 
                                   1192 	.area CSEG (CODE)
                                   1193 ; function ak820_outline_0115
      00482F                       1194 _ak820_outline_0115:
      00482F C3               [12] 1195 	clr	c
      004830 74 FF            [12] 1196 	mov	a,#0xff
      004832 9C               [12] 1197 	subb	a,r4
      004833 E4               [12] 1198 	clr	a
      004834 9D               [12] 1199 	subb	a,r5
      004835 22               [24] 1200 	ret
                                   1201 
                                   1202 	.area CSEG (CODE)
                                   1203 ; function ak820_outline_0144
      004836                       1204 _ak820_outline_0144:
      004836 F0               [24] 1205 	movx	@dptr,a
      004837 E5 F0            [12] 1206 	mov	a,b
      004839 A3               [24] 1207 	inc	dptr
      00483A F0               [24] 1208 	movx	@dptr,a
      00483B 22               [24] 1209 	ret
                                   1210 
                                   1211 	.area CSEG (CODE)
                                   1212 ; function ak820_outline_0194
      00483C                       1213 _ak820_outline_0194:
      00483C F0               [24] 1214 	movx	@dptr,a
      00483D EB               [12] 1215 	mov	a,r3
      00483E A3               [24] 1216 	inc	dptr
      00483F F0               [24] 1217 	movx	@dptr,a
      004840 22               [24] 1218 	ret
