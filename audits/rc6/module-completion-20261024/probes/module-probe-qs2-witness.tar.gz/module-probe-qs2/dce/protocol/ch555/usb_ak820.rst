                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000017                        576 _control_setup_valid_interface_10000_286:
      000017                        577 	.ds 1
      000018                        578 _control_setup_zero_index_10000_286:
      000018                        579 	.ds 1
      000019                        580 _control_setup_zero_value_10000_286:
      000019                        581 	.ds 1
      00001A                        582 _control_setup_zero_length_10000_286:
      00001A                        583 	.ds 1
      00001B                        584 _control_setup_sloc0_1_0:
      00001B                        585 	.ds 1
      00001C                        586 _control_setup_sloc2_1_0:
      00001C                        587 	.ds 1
      00001D                        588 _ak820_usb_try_send_sloc0_1_0:
      00001D                        589 	.ds 1
      00001E                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        591 	.ds 1
      00001F                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001F                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      0007B1                        602 _D0SetupReqCode::
      0007B1                        603 	.ds 1
      0007B2                        604 _D0SetupLen::
      0007B2                        605 	.ds 2
      0007B4                        606 _pD0Descr::
      0007B4                        607 	.ds 3
      0007B7                        608 _D0UsbConfig::
      0007B7                        609 	.ds 1
      0007B8                        610 _USB_EnumStatus::
      0007B8                        611 	.ds 1
      0007B9                        612 _USB_SleepStatus::
      0007B9                        613 	.ds 1
      0007BA                        614 _MCU_Sleep_Operate::
      0007BA                        615 	.ds 1
      0007BB                        616 _KB_USB_UpStatus::
      0007BB                        617 	.ds 1
      0007BC                        618 _KB_USB_SetReport::
      0007BC                        619 	.ds 1
      0007BD                        620 _ak820_boot_stage::
      0007BD                        621 	.ds 1
      0007BE                        622 _ak820_main_heartbeat::
      0007BE                        623 	.ds 1
      0007BF                        624 _raw_state:
      0007BF                        625 	.ds 1
      0007C0                        626 _raw_buffer:
      0007C0                        627 	.ds 32
      0007E0                        628 _raw_reply_without_nvm:
      0007E0                        629 	.ds 1
      0007E1                        630 _keyboard_reset:
      0007E1                        631 	.ds 1
      0007E2                        632 _input_snapshot:
      0007E2                        633 	.ds 46
      000810                        634 _control_phase:
      000810                        635 	.ds 1
      000811                        636 _output_kind:
      000811                        637 	.ds 1
      000812                        638 _output_report_id:
      000812                        639 	.ds 1
      000813                        640 _control_zlp:
      000813                        641 	.ds 1
      000814                        642 _control_pointer:
      000814                        643 	.ds 2
      000816                        644 _descriptor_select_PARM_2:
      000816                        645 	.ds 1
      000817                        646 _descriptor_select_PARM_3:
      000817                        647 	.ds 2
      000819                        648 _descriptor_select_type_10000_268:
      000819                        649 	.ds 1
      00081A                        650 _control_setup_length_10000_286:
      00081A                        651 	.ds 2
      00081C                        652 _control_setup_offset_10000_286:
      00081C                        653 	.ds 1
      00081D                        654 _ak820_usb_send_PARM_2:
      00081D                        655 	.ds 2
      00081F                        656 _ak820_usb_send_PARM_3:
      00081F                        657 	.ds 1
      000820                        658 _ak820_usb_send_endpoint_10000_422:
      000820                        659 	.ds 1
      000821                        660 _ak820_usb_send_offset_10000_423:
      000821                        661 	.ds 1
      000822                        662 _ak820_usb_try_send_PARM_2:
      000822                        663 	.ds 2
      000824                        664 _ak820_usb_try_send_PARM_3:
      000824                        665 	.ds 1
      000825                        666 _ak820_usb_try_send_endpoint_10000_443:
      000825                        667 	.ds 1
      000826                        668 _ak820_usb_try_send_sent_10000_444:
      000826                        669 	.ds 1
      000827                        670 _ak820_usb_raw_send_PARM_2:
      000827                        671 	.ds 1
      000828                        672 _ak820_usb_raw_send_report_10000_459:
      000828                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005E94                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005E94 90 07 BF         [24]  727 	mov	dptr,#_raw_state
      005E97 E0               [24]  728 	movx	a,@dptr
      005E98 FF               [12]  729 	mov	r7,a
      005E99 BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005E9C 80 1C            [24]  731 	sjmp	00101$
      005E9E                        732 00130$:
      005E9E 90 07 BF         [24]  733 	mov	dptr,#_raw_state
      005EA1 E0               [24]  734 	movx	a,@dptr
      005EA2 FF               [12]  735 	mov	r7,a
      005EA3 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005EA6 80 12            [24]  737 	sjmp	00101$
      005EA8                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005EA8 90 07 BF         [24]  740 	mov	dptr,#_raw_state
      005EAB E0               [24]  741 	movx	a,@dptr
      005EAC FF               [12]  742 	mov	r7,a
      005EAD BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005EB0 80 08            [24]  744 	sjmp	00101$
      005EB2                        745 00132$:
      005EB2 90 07 BF         [24]  746 	mov	dptr,#_raw_state
      005EB5 E0               [24]  747 	movx	a,@dptr
      005EB6 FF               [12]  748 	mov	r7,a
      005EB7 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005EBA                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005EBA 90 07 BF         [24]  752 	mov	dptr,#_raw_state
      005EBD 74 07            [12]  753 	mov	a,#0x07
      005EBF F0               [24]  754 	movx	@dptr,a
      005EC0 80 05            [24]  755 	sjmp	00103$
      005EC2                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005EC2 90 07 BF         [24]  758 	mov	dptr,#_raw_state
      005EC5 E4               [12]  759 	clr	a
      005EC6 F0               [24]  760 	movx	@dptr,a
      005EC7                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005EC7 90 08 11         [24]  763 	mov	dptr,#_output_kind
      005ECA E4               [12]  764 	clr	a
      005ECB F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005ECC 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005ECD                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005ECD 90 07 BF         [24]  777 	mov	dptr,#_raw_state
      005ED0 E0               [24]  778 	movx	a,@dptr
      005ED1 FF               [12]  779 	mov	r7,a
      005ED2 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005ED5 90 07 BF         [24]  781 	mov	dptr,#_raw_state
      005ED8 74 06            [12]  782 	mov	a,#0x06
      005EDA F0               [24]  783 	movx	@dptr,a
      005EDB 22               [24]  784 	ret
      005EDC                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005EDC 90 07 BF         [24]  787 	mov	dptr,#_raw_state
      005EDF E0               [24]  788 	movx	a,@dptr
      005EE0 FF               [12]  789 	mov	r7,a
      005EE1 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005EE4 90 07 BF         [24]  791 	mov	dptr,#_raw_state
      005EE7 E4               [12]  792 	clr	a
      005EE8 F0               [24]  793 	movx	@dptr,a
      005EE9                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005EE9 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005EEA                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005EEA 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005EED 74 01            [12]  809 	mov	a,#0x01
      005EEF F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005EF0 F5 82            [12]  812 	mov	dpl,a
      005EF2 74 12            [12]  813 	mov	a,#0x12
      005EF4 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005EF5 A3               [24]  816 	inc	dptr
      005EF6 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005EF7 A3               [24]  819 	inc	dptr
      005EF8 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005EF9 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005EFC E4               [12]  823 	clr	a
      005EFD F0               [24]  824 	movx	@dptr,a
      005EFE 15 82            [12]  825 	dec	dpl
      005F00 F0               [24]  826 	movx	@dptr,a
      005F01 15 82            [12]  827 	dec	dpl
      005F03 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005F04 FF               [12]  830 	mov	r7,a
      005F05                        831 00103$:
      005F05 EF               [12]  832 	mov	a,r7
      005F06 24 E2            [12]  833 	add	a, #_input_snapshot
      005F08 F5 82            [12]  834 	mov	dpl,a
      005F0A E4               [12]  835 	clr	a
      005F0B 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005F0D F5 83            [12]  837 	mov	dph,a
      005F0F E4               [12]  838 	clr	a
      005F10 F0               [24]  839 	movx	@dptr,a
      005F11 0F               [12]  840 	inc	r7
      005F12 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005F15                        842 00139$:
      005F15 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005F17 90 07 EA         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005F1A 74 06            [12]  846 	mov	a,#0x06
      005F1C F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005F1D 90 08 0A         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005F20 03               [12]  850 	rr	a
      005F21 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005F22 90 08 0D         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005F25 04               [12]  854 	inc	a
      005F26 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005F27 7F 00            [12]  857 	mov	r7,#0x00
      005F29                        858 00105$:
      005F29 8F 06            [24]  859 	mov	ar6,r7
      005F2B 74 C0            [12]  860 	mov	a,#0xc0
      005F2D 2E               [12]  861 	add	a, r6
      005F2E F5 82            [12]  862 	mov	dpl,a
      005F30 74 10            [12]  863 	mov	a,#0x10
      005F32 24 00            [12]  864 	add	a, #0x00
      005F34 F5 83            [12]  865 	mov	dph,a
      005F36 E4               [12]  866 	clr	a
      005F37 F0               [24]  867 	movx	@dptr,a
      005F38 0F               [12]  868 	inc	r7
      005F39 BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005F3C                        870 00141$:
      005F3C 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005F3E 02 5E 94         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005F41                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005F41 90 07 BF         [24]  884 	mov	dptr,#_raw_state
      005F44 E0               [24]  885 	movx	a,@dptr
      005F45 FF               [12]  886 	mov	r7,a
      005F46 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005F49 90 07 BF         [24]  888 	mov	dptr,#_raw_state
      005F4C E4               [12]  889 	clr	a
      005F4D F0               [24]  890 	movx	@dptr,a
      005F4E                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005F4E 90 08 11         [24]  893 	mov	dptr,#_output_kind
      005F51 E4               [12]  894 	clr	a
      005F52 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005F53 90 08 10         [24]  897 	mov	dptr,#_control_phase
      005F56 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005F57 90 07 B1         [24]  900 	mov	dptr,#_D0SetupReqCode
      005F5A 14               [12]  901 	dec	a
      005F5B F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005F5C 90 22 00         [24]  904 	mov	dptr,#0x2200
      005F5F 74 CF            [12]  905 	mov	a,#0xcf
      005F61 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005F62 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005F63                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005F63 90 07 B2         [24]  921 	mov	dptr,#_D0SetupLen
      005F66 E0               [24]  922 	movx	a,@dptr
      005F67 FE               [12]  923 	mov	r6,a
      005F68 A3               [24]  924 	inc	dptr
      005F69 E0               [24]  925 	movx	a,@dptr
      005F6A FF               [12]  926 	mov	r7,a
      005F6B C3               [12]  927 	clr	c
      005F6C 74 40            [12]  928 	mov	a,#0x40
      005F6E 9E               [12]  929 	subb	a,r6
      005F6F E4               [12]  930 	clr	a
      005F70 9F               [12]  931 	subb	a,r7
      005F71 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005F73 7E 40            [12]  934 	mov	r6,#0x40
      005F75 80 07            [24]  935 	sjmp	00110$
      005F77                        936 00109$:
      005F77 90 07 B2         [24]  937 	mov	dptr,#_D0SetupLen
      005F7A E0               [24]  938 	movx	a,@dptr
      005F7B FE               [12]  939 	mov	r6,a
      005F7C A3               [24]  940 	inc	dptr
      005F7D E0               [24]  941 	movx	a,@dptr
      005F7E                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005F7E 7F 00            [12]  944 	mov	r7,#0x00
      005F80                        945 00105$:
      005F80 C3               [12]  946 	clr	c
      005F81 EF               [12]  947 	mov	a,r7
      005F82 9E               [12]  948 	subb	a,r6
      005F83 50 2A            [24]  949 	jnc	00101$
      005F85 8F 04            [24]  950 	mov	ar4,r7
      005F87 74 10            [12]  951 	mov	a,#0x10
      005F89 24 00            [12]  952 	add	a, #0x00
      005F8B FD               [12]  953 	mov	r5,a
      005F8C 90 08 14         [24]  954 	mov	dptr,#_control_pointer
      005F8F E0               [24]  955 	movx	a,@dptr
      005F90 FA               [12]  956 	mov	r2,a
      005F91 A3               [24]  957 	inc	dptr
      005F92 E0               [24]  958 	movx	a,@dptr
      005F93 FB               [12]  959 	mov	r3,a
      005F94 8A 82            [24]  960 	mov	dpl,r2
      005F96 8B 83            [24]  961 	mov	dph,r3
      005F98 E4               [12]  962 	clr	a
      005F99 93               [24]  963 	movc	a,@a+dptr
      005F9A F9               [12]  964 	mov	r1,a
      005F9B 90 08 14         [24]  965 	mov	dptr,#_control_pointer
      005F9E 74 01            [12]  966 	mov	a,#0x01
      005FA0 2A               [12]  967 	add	a, r2
      005FA1 F0               [24]  968 	movx	@dptr,a
      005FA2 E4               [12]  969 	clr	a
      005FA3 3B               [12]  970 	addc	a, r3
      005FA4 A3               [24]  971 	inc	dptr
      005FA5 F0               [24]  972 	movx	@dptr,a
      005FA6 8C 82            [24]  973 	mov	dpl,r4
      005FA8 8D 83            [24]  974 	mov	dph,r5
      005FAA E9               [12]  975 	mov	a,r1
      005FAB F0               [24]  976 	movx	@dptr,a
      005FAC 0F               [12]  977 	inc	r7
      005FAD 80 D1            [24]  978 	sjmp	00105$
      005FAF                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005FAF 8E 05            [24]  981 	mov	ar5,r6
      005FB1 7F 00            [12]  982 	mov	r7,#0x00
      005FB3 90 07 B2         [24]  983 	mov	dptr,#_D0SetupLen
      005FB6 E0               [24]  984 	movx	a,@dptr
      005FB7 FB               [12]  985 	mov	r3,a
      005FB8 A3               [24]  986 	inc	dptr
      005FB9 E0               [24]  987 	movx	a,@dptr
      005FBA FC               [12]  988 	mov	r4,a
      005FBB EB               [12]  989 	mov	a,r3
      005FBC C3               [12]  990 	clr	c
      005FBD 9D               [12]  991 	subb	a,r5
      005FBE FB               [12]  992 	mov	r3,a
      005FBF EC               [12]  993 	mov	a,r4
      005FC0 9F               [12]  994 	subb	a,r7
      005FC1 FC               [12]  995 	mov	r4,a
      005FC2 90 07 B2         [24]  996 	mov	dptr,#_D0SetupLen
      005FC5 EB               [12]  997 	mov	a,r3
      005FC6 F0               [24]  998 	movx	@dptr,a
      005FC7 EC               [12]  999 	mov	a,r4
      005FC8 A3               [24] 1000 	inc	dptr
      005FC9 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005FCA EE               [12] 1003 	mov	a,r6
      005FCB 70 05            [24] 1004 	jnz	00103$
      005FCD 90 08 13         [24] 1005 	mov	dptr,#_control_zlp
      005FD0 E4               [12] 1006 	clr	a
      005FD1 F0               [24] 1007 	movx	@dptr,a
      005FD2                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005FD2 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005FD5 EE               [12] 1011 	mov	a,r6
      005FD6 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005FD7 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005FDA E0               [24] 1015 	movx	a,@dptr
      005FDB 54 C0            [12] 1016 	anl	a,#0xc0
      005FDD F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005FDE 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005FDF                       1032 _descriptor_select:
      005FDF E5 82            [12] 1033 	mov	a,dpl
      005FE1 90 08 19         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      005FE4 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005FE5 E0               [24] 1037 	movx	a,@dptr
      005FE6 FF               [12] 1038 	mov	r7,a
      005FE7 BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005FEA 90 08 16         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005FED E0               [24] 1041 	movx	a,@dptr
      005FEE 70 1A            [24] 1042 	jnz	00102$
      005FF0 90 08 17         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005FF3 E0               [24] 1044 	movx	a,@dptr
      005FF4 F5 F0            [12] 1045 	mov	b,a
      005FF6 A3               [24] 1046 	inc	dptr
      005FF7 E0               [24] 1047 	movx	a,@dptr
      005FF8 45 F0            [12] 1048 	orl	a,b
      005FFA 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005FFC 90 08 14         [24] 1051 	mov	dptr,#_control_pointer
      005FFF 74 A6            [12] 1052 	mov	a,#_DeviceDescriptor
      006001 F0               [24] 1053 	movx	@dptr,a
      006002 74 C5            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      006004 A3               [24] 1055 	inc	dptr
      006005 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      006006 90 00 12         [24] 1058 	mov	dptr,#0x0012
      006009 22               [24] 1059 	ret
      00600A                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      00600A 90 08 19         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      00600D E0               [24] 1063 	movx	a,@dptr
      00600E FF               [12] 1064 	mov	r7,a
      00600F BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      006012 90 08 16         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      006015 E0               [24] 1067 	movx	a,@dptr
      006016 70 1A            [24] 1068 	jnz	00106$
      006018 90 08 17         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      00601B E0               [24] 1070 	movx	a,@dptr
      00601C F5 F0            [12] 1071 	mov	b,a
      00601E A3               [24] 1072 	inc	dptr
      00601F E0               [24] 1073 	movx	a,@dptr
      006020 45 F0            [12] 1074 	orl	a,b
      006022 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      006024 90 08 14         [24] 1077 	mov	dptr,#_control_pointer
      006027 74 B8            [12] 1078 	mov	a,#_ConfigurationDescriptor
      006029 F0               [24] 1079 	movx	@dptr,a
      00602A 74 C5            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      00602C A3               [24] 1081 	inc	dptr
      00602D F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      00602E 90 00 54         [24] 1084 	mov	dptr,#0x0054
      006031 22               [24] 1085 	ret
      006032                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      006032 90 08 19         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      006035 E0               [24] 1089 	movx	a,@dptr
      006036 FF               [12] 1090 	mov	r7,a
      006037 BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      00603A 80 03            [24] 1092 	sjmp	00239$
      00603C                       1093 00238$:
      00603C 02 60 D6         [24] 1094 	ljmp	00119$
      00603F                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      00603F 90 08 17         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      006042 E0               [24] 1098 	movx	a,@dptr
      006043 FD               [12] 1099 	mov	r5,a
      006044 A3               [24] 1100 	inc	dptr
      006045 E0               [24] 1101 	movx	a,@dptr
      006046 FE               [12] 1102 	mov	r6,a
      006047 90 08 17         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      00604A E0               [24] 1104 	movx	a,@dptr
      00604B F5 F0            [12] 1105 	mov	b,a
      00604D A3               [24] 1106 	inc	dptr
      00604E E0               [24] 1107 	movx	a,@dptr
      00604F 45 F0            [12] 1108 	orl	a,b
      006051 60 0C            [24] 1109 	jz	00110$
      006053 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      006056 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      006059 80 04            [24] 1112 	sjmp	00110$
      00605B                       1113 00241$:
      00605B 90 00 00         [24] 1114 	mov	dptr,#0x0000
      00605E 22               [24] 1115 	ret
      00605F                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      00605F 90 08 16         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      006062 E0               [24] 1119 	movx	a,@dptr
      006063 FE               [12] 1120 	mov  r6,a
      006064 24 FC            [12] 1121 	add	a,#0xff - 0x03
      006066 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      006068 EE               [12] 1124 	mov	a,r6
      006069 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      00606A 90 60 6E         [24] 1127 	mov	dptr,#00243$
      00606D 73               [24] 1128 	jmp	@a+dptr
      00606E                       1129 00243$:
      00606E 80 06            [24] 1130 	sjmp	00112$
      006070 80 1B            [24] 1131 	sjmp	00113$
      006072 80 30            [24] 1132 	sjmp	00114$
      006074 80 45            [24] 1133 	sjmp	00115$
      006076                       1134 00112$:
      006076 90 08 14         [24] 1135 	mov	dptr,#_control_pointer
      006079 74 0C            [12] 1136 	mov	a,#_LanguageString
      00607B F0               [24] 1137 	movx	@dptr,a
      00607C 74 C6            [12] 1138 	mov	a,#(_LanguageString >> 8)
      00607E A3               [24] 1139 	inc	dptr
      00607F F0               [24] 1140 	movx	@dptr,a
      006080 90 C6 0C         [24] 1141 	mov	dptr,#_LanguageString
      006083 E4               [12] 1142 	clr	a
      006084 93               [24] 1143 	movc	a,@a+dptr
      006085 FE               [12] 1144 	mov	r6,a
      006086 7D 00            [12] 1145 	mov	r5,#0x00
      006088 8E 82            [24] 1146 	mov	dpl, r6
      00608A 8D 83            [24] 1147 	mov	dph, r5
      00608C 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      00608D                       1150 00113$:
      00608D 90 08 14         [24] 1151 	mov	dptr,#_control_pointer
      006090 74 10            [12] 1152 	mov	a,#_ManufacturerString
      006092 F0               [24] 1153 	movx	@dptr,a
      006093 74 C6            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      006095 A3               [24] 1155 	inc	dptr
      006096 F0               [24] 1156 	movx	@dptr,a
      006097 90 C6 10         [24] 1157 	mov	dptr,#_ManufacturerString
      00609A E4               [12] 1158 	clr	a
      00609B 93               [24] 1159 	movc	a,@a+dptr
      00609C FE               [12] 1160 	mov	r6,a
      00609D 7D 00            [12] 1161 	mov	r5,#0x00
      00609F 8E 82            [24] 1162 	mov	dpl, r6
      0060A1 8D 83            [24] 1163 	mov	dph, r5
      0060A3 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      0060A4                       1166 00114$:
      0060A4 90 08 14         [24] 1167 	mov	dptr,#_control_pointer
      0060A7 74 1E            [12] 1168 	mov	a,#_ProductString
      0060A9 F0               [24] 1169 	movx	@dptr,a
      0060AA 74 C6            [12] 1170 	mov	a,#(_ProductString >> 8)
      0060AC A3               [24] 1171 	inc	dptr
      0060AD F0               [24] 1172 	movx	@dptr,a
      0060AE 90 C6 1E         [24] 1173 	mov	dptr,#_ProductString
      0060B1 E4               [12] 1174 	clr	a
      0060B2 93               [24] 1175 	movc	a,@a+dptr
      0060B3 FE               [12] 1176 	mov	r6,a
      0060B4 7D 00            [12] 1177 	mov	r5,#0x00
      0060B6 8E 82            [24] 1178 	mov	dpl, r6
      0060B8 8D 83            [24] 1179 	mov	dph, r5
      0060BA 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      0060BB                       1182 00115$:
      0060BB 90 08 14         [24] 1183 	mov	dptr,#_control_pointer
      0060BE 74 56            [12] 1184 	mov	a,#_SerialNumberString
      0060C0 F0               [24] 1185 	movx	@dptr,a
      0060C1 74 C6            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      0060C3 A3               [24] 1187 	inc	dptr
      0060C4 F0               [24] 1188 	movx	@dptr,a
      0060C5 90 C6 56         [24] 1189 	mov	dptr,#_SerialNumberString
      0060C8 E4               [12] 1190 	clr	a
      0060C9 93               [24] 1191 	movc	a,@a+dptr
      0060CA FE               [12] 1192 	mov	r6,a
      0060CB 7D 00            [12] 1193 	mov	r5,#0x00
      0060CD 8E 82            [24] 1194 	mov	dpl, r6
      0060CF 8D 83            [24] 1195 	mov	dph, r5
      0060D1 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      0060D2                       1198 00116$:
      0060D2 90 00 00         [24] 1199 	mov	dptr,#0x0000
      0060D5 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      0060D6                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      0060D6 90 08 16         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      0060D9 E0               [24] 1205 	movx	a,@dptr
      0060DA 70 11            [24] 1206 	jnz	00120$
      0060DC 90 08 17         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      0060DF E0               [24] 1208 	movx	a,@dptr
      0060E0 FD               [12] 1209 	mov	r5,a
      0060E1 A3               [24] 1210 	inc	dptr
      0060E2 E0               [24] 1211 	movx	a,@dptr
      0060E3 FE               [12] 1212 	mov	r6,a
      0060E4 C3               [12] 1213 	clr	c
      0060E5 ED               [12] 1214 	mov	a,r5
      0060E6 94 03            [12] 1215 	subb	a,#0x03
      0060E8 EE               [12] 1216 	mov	a,r6
      0060E9 94 00            [12] 1217 	subb	a,#0x00
      0060EB 40 04            [24] 1218 	jc	00121$
      0060ED                       1219 00120$:
      0060ED 90 00 00         [24] 1220 	mov	dptr,#0x0000
      0060F0 22               [24] 1221 	ret
      0060F1                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      0060F1 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      0060F4 80 03            [24] 1225 	sjmp	00127$
      0060F6                       1226 00246$:
      0060F6 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      0060F9                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      0060F9 ED               [12] 1230 	mov	a,r5
      0060FA 75 F0 04         [24] 1231 	mov	b,#0x04
      0060FD A4               [48] 1232 	mul	ab
      0060FE 24 2F            [12] 1233 	add	a, #_interface_descriptors
      006100 FE               [12] 1234 	mov	r6,a
      006101 74 BF            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      006103 35 F0            [12] 1236 	addc	a, b
      006105 FF               [12] 1237 	mov	r7,a
      006106 8E 82            [24] 1238 	mov	dpl,r6
      006108 8F 83            [24] 1239 	mov	dph,r7
      00610A A3               [24] 1240 	inc	dptr
      00610B A3               [24] 1241 	inc	dptr
      00610C E4               [12] 1242 	clr	a
      00610D 93               [24] 1243 	movc	a,@a+dptr
      00610E FC               [12] 1244 	mov	r4,a
      00610F A3               [24] 1245 	inc	dptr
      006110 E4               [12] 1246 	clr	a
      006111 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      006112 FD               [12] 1249 	mov	r5,a
      006113 4C               [12] 1250 	orl	a,r4
      006114 70 04            [24] 1251 	jnz	00124$
      006116 90 00 00         [24] 1252 	mov	dptr,#0x0000
      006119 22               [24] 1253 	ret
      00611A                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      00611A 90 08 19         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      00611D E0               [24] 1257 	movx	a,@dptr
      00611E FB               [12] 1258 	mov	r3,a
      00611F BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      006122 8E 82            [24] 1261 	mov	dpl,r6
      006124 8F 83            [24] 1262 	mov	dph,r7
      006126 E4               [12] 1263 	clr	a
      006127 93               [24] 1264 	movc	a,@a+dptr
      006128 FE               [12] 1265 	mov	r6,a
      006129 A3               [24] 1266 	inc	dptr
      00612A E4               [12] 1267 	clr	a
      00612B 93               [24] 1268 	movc	a,@a+dptr
      00612C FF               [12] 1269 	mov	r7,a
      00612D 90 08 14         [24] 1270 	mov	dptr,#_control_pointer
      006130 EE               [12] 1271 	mov	a,r6
      006131 F0               [24] 1272 	movx	@dptr,a
      006132 EF               [12] 1273 	mov	a,r7
      006133 A3               [24] 1274 	inc	dptr
      006134 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      006135 74 07            [12] 1277 	mov	a,#0x07
      006137 2C               [12] 1278 	add	a, r4
      006138 F5 82            [12] 1279 	mov	dpl,a
      00613A E4               [12] 1280 	clr	a
      00613B 3D               [12] 1281 	addc	a, r5
      00613C F5 83            [12] 1282 	mov	dph,a
      00613E E4               [12] 1283 	clr	a
      00613F 93               [24] 1284 	movc	a,@a+dptr
      006140 FE               [12] 1285 	mov	r6,a
      006141 A3               [24] 1286 	inc	dptr
      006142 E4               [12] 1287 	clr	a
      006143 93               [24] 1288 	movc	a,@a+dptr
      006144 FF               [12] 1289 	mov	r7,a
      006145 8E 82            [24] 1290 	mov	dpl, r6
      006147 8F 83            [24] 1291 	mov	dph, r7
      006149 22               [24] 1292 	ret
      00614A                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      00614A 90 08 14         [24] 1295 	mov	dptr,#_control_pointer
      00614D EC               [12] 1296 	mov	a,r4
      00614E F0               [24] 1297 	movx	@dptr,a
      00614F ED               [12] 1298 	mov	a,r5
      006150 A3               [24] 1299 	inc	dptr
      006151 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      006152 90 00 09         [24] 1302 	mov	dptr,#0x0009
      006155 22               [24] 1303 	ret
      006156                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      006156 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      006159 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      00615A                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      00615A 90 10 00         [24] 1330 	mov	dptr,#0x1000
      00615D E0               [24] 1331 	movx	a,@dptr
      00615E FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      00615F A3               [24] 1334 	inc	dptr
      006160 A3               [24] 1335 	inc	dptr
      006161 E0               [24] 1336 	movx	a,@dptr
      006162 FE               [12] 1337 	mov	r6,a
      006163 A3               [24] 1338 	inc	dptr
      006164 E0               [24] 1339 	movx	a,@dptr
      006165 FC               [12] 1340 	mov	r4,a
      006166 7D 00            [12] 1341 	mov	r5,#0x00
      006168 8E 03            [24] 1342 	mov	ar3,r6
      00616A 7E 00            [12] 1343 	mov	r6,#0x00
      00616C ED               [12] 1344 	mov	a,r5
      00616D 4B               [12] 1345 	orl	a,r3
      00616E FD               [12] 1346 	mov	r5,a
      00616F EC               [12] 1347 	mov	a,r4
      006170 4E               [12] 1348 	orl	a,r6
      006171 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      006172 A3               [24] 1351 	inc	dptr
      006173 E0               [24] 1352 	movx	a,@dptr
      006174 FC               [12] 1353 	mov	r4,a
      006175 A3               [24] 1354 	inc	dptr
      006176 E0               [24] 1355 	movx	a,@dptr
      006177 FA               [12] 1356 	mov	r2,a
      006178 7B 00            [12] 1357 	mov	r3,#0x00
      00617A 8C 01            [24] 1358 	mov	ar1,r4
      00617C 7C 00            [12] 1359 	mov	r4,#0x00
      00617E EB               [12] 1360 	mov	a,r3
      00617F 49               [12] 1361 	orl	a,r1
      006180 FB               [12] 1362 	mov	r3,a
      006181 EA               [12] 1363 	mov	a,r2
      006182 4C               [12] 1364 	orl	a,r4
      006183 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      006184 C3               [12] 1367 	clr	c
      006185 EB               [12] 1368 	mov	a,r3
      006186 94 03            [12] 1369 	subb	a,#0x03
      006188 EC               [12] 1370 	mov	a,r4
      006189 94 00            [12] 1371 	subb	a,#0x00
      00618B 92 17            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      00618D EB               [12] 1374 	mov	a,r3
      00618E 4C               [12] 1375 	orl	a,r4
      00618F B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      006192                       1377 01201$:
      006192 92 18            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      006194 ED               [12] 1380 	mov	a,r5
      006195 4E               [12] 1381 	orl	a,r6
      006196 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      006199                       1383 01202$:
                                   1384 ;	assignBit
      006199 92 1B            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      00619B 92 19            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      00619D 90 08 1C         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      0061A0 E4               [12] 1389 	clr	a
      0061A1 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0061A2 90 07 BF         [24] 1392 	mov	dptr,#_raw_state
      0061A5 E0               [24] 1393 	movx	a,@dptr
      0061A6 FA               [12] 1394 	mov	r2,a
      0061A7 BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      0061AA 90 07 BF         [24] 1396 	mov	dptr,#_raw_state
      0061AD E4               [12] 1397 	clr	a
      0061AE F0               [24] 1398 	movx	@dptr,a
      0061AF                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      0061AF C0 07            [24] 1401 	push	ar7
      0061B1 90 08 11         [24] 1402 	mov	dptr,#_output_kind
      0061B4 E4               [12] 1403 	clr	a
      0061B5 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      0061B6 90 08 10         [24] 1406 	mov	dptr,#_control_phase
      0061B9 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      0061BA 90 08 13         [24] 1409 	mov	dptr,#_control_zlp
      0061BD F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0061BE 90 10 01         [24] 1412 	mov	dptr,#0x1001
      0061C1 E0               [24] 1413 	movx	a,@dptr
      0061C2 90 07 B1         [24] 1414 	mov	dptr,#_D0SetupReqCode
      0061C5 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0061C6 90 10 06         [24] 1417 	mov	dptr,#0x1006
      0061C9 E0               [24] 1418 	movx	a,@dptr
      0061CA FA               [12] 1419 	mov	r2,a
      0061CB A3               [24] 1420 	inc	dptr
      0061CC E0               [24] 1421 	movx	a,@dptr
      0061CD F9               [12] 1422 	mov	r1,a
      0061CE 78 00            [12] 1423 	mov	r0,#0x00
      0061D0 7F 00            [12] 1424 	mov	r7,#0x00
      0061D2 90 07 B2         [24] 1425 	mov	dptr,#_D0SetupLen
      0061D5 E8               [12] 1426 	mov	a,r0
      0061D6 4A               [12] 1427 	orl	a,r2
      0061D7 F0               [24] 1428 	movx	@dptr,a
      0061D8 E9               [12] 1429 	mov	a,r1
      0061D9 4F               [12] 1430 	orl	a,r7
      0061DA A3               [24] 1431 	inc	dptr
      0061DB F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      0061DC 90 07 B2         [24] 1434 	mov	dptr,#_D0SetupLen
      0061DF E0               [24] 1435 	movx	a,@dptr
      0061E0 FA               [12] 1436 	mov	r2,a
      0061E1 A3               [24] 1437 	inc	dptr
      0061E2 E0               [24] 1438 	movx	a,@dptr
      0061E3 4A               [12] 1439 	orl	a,r2
      0061E4 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      0061E7                       1441 01205$:
      0061E7 92 1A            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0061E9 90 22 00         [24] 1444 	mov	dptr,#0x2200
      0061EC 74 C2            [12] 1445 	mov	a,#0xc2
      0061EE F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      0061EF 90 22 08         [24] 1448 	mov	dptr,#0x2208
      0061F2 E4               [12] 1449 	clr	a
      0061F3 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      0061F4 90 07 B1         [24] 1452 	mov	dptr,#_D0SetupReqCode
      0061F7 E0               [24] 1453 	movx	a,@dptr
      0061F8 F5 16            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      0061FA C3               [12] 1455 	clr	c
      0061FB 74 0B            [12] 1456 	mov	a,#0x0b
      0061FD 95 16            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      0061FF D0 07            [24] 1458 	pop	ar7
      006201 50 03            [24] 1459 	jnc	01206$
      006203 02 5F 41         [24] 1460 	ljmp	_control_stall
      006206                       1461 01206$:
                                   1462 ;	free result
      006206 E5 16            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      006208 F5 F0            [12] 1464 	mov	b,a
      00620A 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      00620C 83               [24] 1466 	movc	a,@a+pc
      00620D F5 82            [12] 1467 	mov	dpl,a
      00620F E5 F0            [12] 1468 	mov	a,b
      006211 24 10            [12] 1469 	add	a,#(01208$-3-.)
      006213 83               [24] 1470 	movc	a,@a+pc
      006214 F5 83            [12] 1471 	mov	dph,a
      006216 E4               [12] 1472 	clr	a
      006217 73               [24] 1473 	jmp	@a+dptr
      006218                       1474 01207$:
      006218 C0                    1475 	.db	00188$
      006219 66                    1476 	.db	00205$
      00621A A9                    1477 	.db	00282$
      00621B 66                    1478 	.db	00205$
      00621C ED                    1479 	.db	00290$
      00621D EA                    1480 	.db	00116$
      00621E 30                    1481 	.db	00103$
      00621F ED                    1482 	.db	00290$
      006220 EF                    1483 	.db	00150$
      006221 13                    1484 	.db	00123$
      006222 1F                    1485 	.db	00157$
      006223 72                    1486 	.db	00173$
      006224                       1487 01208$:
      006224 64                    1488 	.db	00188$>>8
      006225 65                    1489 	.db	00205$>>8
      006226 68                    1490 	.db	00282$>>8
      006227 65                    1491 	.db	00205$>>8
      006228 68                    1492 	.db	00290$>>8
      006229 62                    1493 	.db	00116$>>8
      00622A 62                    1494 	.db	00103$>>8
      00622B 68                    1495 	.db	00290$>>8
      00622C 63                    1496 	.db	00150$>>8
      00622D 63                    1497 	.db	00123$>>8
      00622E 64                    1498 	.db	00157$>>8
      00622F 64                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006230                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006230 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      006233 80 08            [24] 1504 	sjmp	00112$
      006235                       1505 01209$:
      006235 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      006238 80 03            [24] 1507 	sjmp	01211$
      00623A                       1508 01210$:
      00623A 02 5F 41         [24] 1509 	ljmp	_control_stall
      00623D                       1510 01211$:
      00623D                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      00623D 8E 01            [24] 1513 	mov	ar1,r6
      00623F B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      006242 80 09            [24] 1515 	sjmp	00301$
      006244                       1516 01212$:
      006244 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      006247 80 04            [24] 1518 	sjmp	00301$
      006249                       1519 01213$:
                                   1520 ;	assignBit
      006249 C2 1C            [12] 1521 	clr	_control_setup_sloc2_1_0
      00624B 80 02            [24] 1522 	sjmp	00302$
      00624D                       1523 00301$:
                                   1524 ;	assignBit
      00624D D2 1C            [12] 1525 	setb	_control_setup_sloc2_1_0
      00624F                       1526 00302$:
      00624F E4               [12] 1527 	clr	a
      006250 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      006253 04               [12] 1529 	inc	a
      006254                       1530 01214$:
      006254 FA               [12] 1531 	mov	r2,a
      006255 A2 1C            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      006257 E4               [12] 1533 	clr	a
      006258 33               [12] 1534 	rlc	a
      006259 B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      00625C 80 03            [24] 1536 	sjmp	00105$
      00625E                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      00625E 02 5F 41         [24] 1539 	ljmp	_control_stall
      006261                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      006261 8E 02            [24] 1542 	mov	ar2,r6
      006263 90 08 16         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      006266 ED               [12] 1544 	mov	a,r5
      006267 F0               [24] 1545 	movx	@dptr,a
      006268 90 08 17         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      00626B EB               [12] 1547 	mov	a,r3
      00626C F0               [24] 1548 	movx	@dptr,a
      00626D EC               [12] 1549 	mov	a,r4
      00626E A3               [24] 1550 	inc	dptr
      00626F F0               [24] 1551 	movx	@dptr,a
      006270 8A 82            [24] 1552 	mov	dpl, r2
      006272 12 5F DF         [24] 1553 	lcall	_descriptor_select
      006275 85 82 17         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      006278 85 83 18         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      00627B E5 17            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      00627D 45 18            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      00627F 70 03            [24] 1559 	jnz	00107$
      006281 02 5F 41         [24] 1560 	ljmp	_control_stall
      006284                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      006284 90 07 B2         [24] 1563 	mov	dptr,#_D0SetupLen
      006287 E0               [24] 1564 	movx	a,@dptr
      006288 F8               [12] 1565 	mov	r0,a
      006289 A3               [24] 1566 	inc	dptr
      00628A E0               [24] 1567 	movx	a,@dptr
      00628B FA               [12] 1568 	mov	r2,a
      00628C C3               [12] 1569 	clr	c
      00628D E5 17            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      00628F 98               [12] 1571 	subb	a,r0
      006290 E5 18            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006292 9A               [12] 1573 	subb	a,r2
      006293 50 06            [24] 1574 	jnc	00303$
      006295 E5 17            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      006297 54 3F            [12] 1576 	anl	a,#0x3f
      006299 60 04            [24] 1577 	jz	00304$
      00629B                       1578 00303$:
                                   1579 ;	assignBit
      00629B C2 1C            [12] 1580 	clr	_control_setup_sloc2_1_0
      00629D 80 02            [24] 1581 	sjmp	00305$
      00629F                       1582 00304$:
                                   1583 ;	assignBit
      00629F D2 1C            [12] 1584 	setb	_control_setup_sloc2_1_0
      0062A1                       1585 00305$:
      0062A1 90 08 13         [24] 1586 	mov	dptr,#_control_zlp
      0062A4 A2 1C            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      0062A6 E4               [12] 1588 	clr	a
      0062A7 33               [12] 1589 	rlc	a
      0062A8 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      0062A9 90 07 B2         [24] 1592 	mov	dptr,#_D0SetupLen
      0062AC E0               [24] 1593 	movx	a,@dptr
      0062AD F9               [12] 1594 	mov	r1,a
      0062AE A3               [24] 1595 	inc	dptr
      0062AF E0               [24] 1596 	movx	a,@dptr
      0062B0 FA               [12] 1597 	mov	r2,a
      0062B1 C3               [12] 1598 	clr	c
      0062B2 E5 17            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      0062B4 99               [12] 1600 	subb	a,r1
      0062B5 E5 18            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0062B7 9A               [12] 1602 	subb	a,r2
      0062B8 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      0062BA 90 07 B2         [24] 1605 	mov	dptr,#_D0SetupLen
      0062BD E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      0062BF F0               [24] 1607 	movx	@dptr,a
      0062C0 E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0062C2 A3               [24] 1609 	inc	dptr
      0062C3 F0               [24] 1610 	movx	@dptr,a
      0062C4                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0062C4 90 07 B2         [24] 1613 	mov	dptr,#_D0SetupLen
      0062C7 E0               [24] 1614 	movx	a,@dptr
      0062C8 F9               [12] 1615 	mov	r1,a
      0062C9 A3               [24] 1616 	inc	dptr
      0062CA E0               [24] 1617 	movx	a,@dptr
      0062CB 49               [12] 1618 	orl	a,r1
      0062CC 60 04            [24] 1619 	jz	00306$
      0062CE 7A 01            [12] 1620 	mov	r2,#0x01
      0062D0 80 02            [24] 1621 	sjmp	00307$
      0062D2                       1622 00306$:
      0062D2 7A 02            [12] 1623 	mov	r2,#0x02
      0062D4                       1624 00307$:
      0062D4 90 08 10         [24] 1625 	mov	dptr,#_control_phase
      0062D7 EA               [12] 1626 	mov	a,r2
      0062D8 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      0062D9 90 07 B2         [24] 1629 	mov	dptr,#_D0SetupLen
      0062DC E0               [24] 1630 	movx	a,@dptr
      0062DD F9               [12] 1631 	mov	r1,a
      0062DE A3               [24] 1632 	inc	dptr
      0062DF E0               [24] 1633 	movx	a,@dptr
      0062E0 49               [12] 1634 	orl	a,r1
      0062E1 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      0062E3 02 5F 63         [24] 1637 	ljmp	_control_next
      0062E6                       1638 00111$:
      0062E6 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      0062E7 02 5F 41         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      0062EA                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      0062EA EF               [12] 1645 	mov	a,r7
      0062EB 70 23            [24] 1646 	jnz	00118$
      0062ED 30 18 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      0062F0 30 1A 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      0062F3 8D 01            [24] 1649 	mov	ar1,r5
      0062F5 8E 02            [24] 1650 	mov	ar2,r6
      0062F7 C3               [12] 1651 	clr	c
      0062F8 74 7F            [12] 1652 	mov	a,#0x7f
      0062FA 99               [12] 1653 	subb	a,r1
      0062FB E4               [12] 1654 	clr	a
      0062FC 9A               [12] 1655 	subb	a,r2
      0062FD 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0062FF 90 07 B2         [24] 1659 	mov	dptr,#_D0SetupLen
      006302 ED               [12] 1660 	mov	a,r5
      006303 F0               [24] 1661 	movx	@dptr,a
      006304 EE               [12] 1662 	mov	a,r6
      006305 A3               [24] 1663 	inc	dptr
      006306 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      006307 90 08 10         [24] 1666 	mov	dptr,#_control_phase
      00630A 74 03            [12] 1667 	mov	a,#0x03
      00630C F0               [24] 1668 	movx	@dptr,a
      00630D 02 68 F0         [24] 1669 	ljmp	00291$
      006310                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      006310 02 5F 41         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      006313                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      006313 EF               [12] 1676 	mov	a,r7
      006314 70 3C            [24] 1677 	jnz	00145$
      006316 30 18 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      006319 30 1A 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      00631C 8D 01            [24] 1680 	mov	ar1,r5
      00631E 8E 02            [24] 1681 	mov	ar2,r6
      006320 C3               [12] 1682 	clr	c
      006321 74 01            [12] 1683 	mov	a,#0x01
      006323 99               [12] 1684 	subb	a,r1
      006324 E4               [12] 1685 	clr	a
      006325 9A               [12] 1686 	subb	a,r2
      006326 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      006328 C0 06            [24] 1690 	push	ar6
      00632A C0 05            [24] 1691 	push	ar5
      00632C 12 5E EA         [24] 1692 	lcall	_endpoints_reset
      00632F D0 05            [24] 1693 	pop	ar5
      006331 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      006333 90 07 B7         [24] 1696 	mov	dptr,#_D0UsbConfig
      006336 ED               [12] 1697 	mov	a,r5
      006337 F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      006338 A2 1B            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      00633A B3               [12] 1701 	cpl	c
      00633B 92 1C            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      00633D 90 07 B8         [24] 1703 	mov	dptr,#_USB_EnumStatus
      006340 E4               [12] 1704 	clr	a
      006341 33               [12] 1705 	rlc	a
      006342 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      006343 90 07 E1         [24] 1708 	mov	dptr,#_keyboard_reset
      006346 74 01            [12] 1709 	mov	a,#0x01
      006348 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      006349 90 08 10         [24] 1712 	mov	dptr,#_control_phase
      00634C 74 03            [12] 1713 	mov	a,#0x03
      00634E F0               [24] 1714 	movx	@dptr,a
      00634F 02 68 F0         [24] 1715 	ljmp	00291$
      006352                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      006352 BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      006355 80 03            [24] 1719 	sjmp	01232$
      006357                       1720 01231$:
      006357 02 5F 41         [24] 1721 	ljmp	_control_stall
      00635A                       1722 01232$:
      00635A 90 07 B7         [24] 1723 	mov	dptr,#_D0UsbConfig
      00635D E0               [24] 1724 	movx	a,@dptr
      00635E 70 03            [24] 1725 	jnz	01233$
      006360 02 5F 41         [24] 1726 	ljmp	_control_stall
      006363                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006363 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      006366 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      006369 8D 01            [24] 1731 	mov	ar1,r5
      00636B 8E 02            [24] 1732 	mov	ar2,r6
      00636D B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      006370 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      006373 90 07 B2         [24] 1735 	mov	dptr,#_D0SetupLen
      006376 E0               [24] 1736 	movx	a,@dptr
      006377 F9               [12] 1737 	mov	r1,a
      006378 A3               [24] 1738 	inc	dptr
      006379 E0               [24] 1739 	movx	a,@dptr
      00637A FA               [12] 1740 	mov	r2,a
      00637B B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      00637E BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      006381 90 07 BF         [24] 1743 	mov	dptr,#_raw_state
      006384 E0               [24] 1744 	movx	a,@dptr
      006385 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      006387 90 07 BF         [24] 1747 	mov	dptr,#_raw_state
      00638A 74 01            [12] 1748 	mov	a,#0x01
      00638C F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      00638D 90 08 11         [24] 1751 	mov	dptr,#_output_kind
      006390 F0               [24] 1752 	movx	@dptr,a
      006391 80 52            [24] 1753 	sjmp	00136$
      006393                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006393 EB               [12] 1756 	mov	a,r3
      006394 4C               [12] 1757 	orl	a,r4
      006395 70 20            [24] 1758 	jnz	00130$
      006397 8D 01            [24] 1759 	mov	ar1,r5
      006399 8E 02            [24] 1760 	mov	ar2,r6
      00639B B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      00639E BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      0063A1 90 07 B2         [24] 1763 	mov	dptr,#_D0SetupLen
      0063A4 E0               [24] 1764 	movx	a,@dptr
      0063A5 F9               [12] 1765 	mov	r1,a
      0063A6 A3               [24] 1766 	inc	dptr
      0063A7 E0               [24] 1767 	movx	a,@dptr
      0063A8 FA               [12] 1768 	mov	r2,a
      0063A9 B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      0063AC BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      0063AF 90 08 11         [24] 1772 	mov	dptr,#_output_kind
      0063B2 74 02            [12] 1773 	mov	a,#0x02
      0063B4 F0               [24] 1774 	movx	@dptr,a
      0063B5 80 2E            [24] 1775 	sjmp	00136$
      0063B7                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0063B7 BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      0063BA BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      0063BD 8D 01            [24] 1780 	mov	ar1,r5
      0063BF 8E 02            [24] 1781 	mov	ar2,r6
      0063C1 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      0063C4 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      0063C7 90 07 B2         [24] 1784 	mov	dptr,#_D0SetupLen
      0063CA E0               [24] 1785 	movx	a,@dptr
      0063CB F9               [12] 1786 	mov	r1,a
      0063CC A3               [24] 1787 	inc	dptr
      0063CD E0               [24] 1788 	movx	a,@dptr
      0063CE FA               [12] 1789 	mov	r2,a
      0063CF B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      0063D2 BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      0063D5 90 08 11         [24] 1793 	mov	dptr,#_output_kind
      0063D8 74 03            [12] 1794 	mov	a,#0x03
      0063DA F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      0063DB 90 08 12         [24] 1797 	mov	dptr,#_output_report_id
      0063DE 23               [12] 1798 	rl	a
      0063DF F0               [24] 1799 	movx	@dptr,a
      0063E0 80 03            [24] 1800 	sjmp	00136$
      0063E2                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      0063E2 02 5F 41         [24] 1803 	ljmp	_control_stall
      0063E5                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      0063E5 90 08 10         [24] 1806 	mov	dptr,#_control_phase
      0063E8 74 04            [12] 1807 	mov	a,#0x04
      0063EA F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      0063EB 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      0063EC 02 5F 41         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      0063EF                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0063EF BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      0063F2 30 18 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      0063F5 30 19 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      0063F8 90 07 B2         [24] 1819 	mov	dptr,#_D0SetupLen
      0063FB E0               [24] 1820 	movx	a,@dptr
      0063FC F9               [12] 1821 	mov	r1,a
      0063FD A3               [24] 1822 	inc	dptr
      0063FE E0               [24] 1823 	movx	a,@dptr
      0063FF FA               [12] 1824 	mov	r2,a
      006400 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      006403 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      006406 90 07 B7         [24] 1828 	mov	dptr,#_D0UsbConfig
      006409 E0               [24] 1829 	movx	a,@dptr
      00640A 90 10 00         [24] 1830 	mov	dptr,#0x1000
      00640D F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      00640E 90 22 08         [24] 1833 	mov	dptr,#0x2208
      006411 74 01            [12] 1834 	mov	a,#0x01
      006413 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      006414 90 08 10         [24] 1837 	mov	dptr,#_control_phase
      006417 04               [12] 1838 	inc	a
      006418 F0               [24] 1839 	movx	@dptr,a
      006419 02 68 F0         [24] 1840 	ljmp	00291$
      00641C                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      00641C 02 5F 41         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      00641F                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      00641F BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      006422 30 17 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      006425 30 19 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      006428 90 07 B2         [24] 1850 	mov	dptr,#_D0SetupLen
      00642B E0               [24] 1851 	movx	a,@dptr
      00642C F9               [12] 1852 	mov	r1,a
      00642D A3               [24] 1853 	inc	dptr
      00642E E0               [24] 1854 	movx	a,@dptr
      00642F FA               [12] 1855 	mov	r2,a
      006430 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      006433 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      006436 90 07 B7         [24] 1858 	mov	dptr,#_D0UsbConfig
      006439 E0               [24] 1859 	movx	a,@dptr
      00643A 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      00643C 90 10 00         [24] 1862 	mov	dptr,#0x1000
      00643F E4               [12] 1863 	clr	a
      006440 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006441 90 22 08         [24] 1866 	mov	dptr,#0x2208
      006444 04               [12] 1867 	inc	a
      006445 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      006446 90 08 10         [24] 1870 	mov	dptr,#_control_phase
      006449 04               [12] 1871 	inc	a
      00644A F0               [24] 1872 	movx	@dptr,a
      00644B 02 68 F0         [24] 1873 	ljmp	00291$
      00644E                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      00644E 30 17 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      006451 90 07 B7         [24] 1877 	mov	dptr,#_D0UsbConfig
      006454 E0               [24] 1878 	movx	a,@dptr
      006455 60 18            [24] 1879 	jz	00161$
      006457 BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      00645A 30 1A 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      00645D EB               [12] 1883 	mov	a,r3
      00645E 4C               [12] 1884 	orl	a,r4
      00645F 70 05            [24] 1885 	jnz	00159$
      006461 90 06 8F         [24] 1886 	mov	dptr,#_keyboard_idle
      006464 EE               [12] 1887 	mov	a,r6
      006465 F0               [24] 1888 	movx	@dptr,a
      006466                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      006466 90 08 10         [24] 1891 	mov	dptr,#_control_phase
      006469 74 03            [12] 1892 	mov	a,#0x03
      00646B F0               [24] 1893 	movx	@dptr,a
      00646C 02 68 F0         [24] 1894 	ljmp	00291$
      00646F                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      00646F 02 5F 41         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006472                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006472 BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      006475 30 17 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      006478 30 19 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      00647B 30 1A 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      00647E 90 07 B7         [24] 1905 	mov	dptr,#_D0UsbConfig
      006481 E0               [24] 1906 	movx	a,@dptr
      006482 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      006484 90 08 10         [24] 1909 	mov	dptr,#_control_phase
      006487 74 03            [12] 1910 	mov	a,#0x03
      006489 F0               [24] 1911 	movx	@dptr,a
      00648A 02 68 F0         [24] 1912 	ljmp	00291$
      00648D                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      00648D EB               [12] 1915 	mov	a,r3
      00648E 4C               [12] 1916 	orl	a,r4
      00648F 70 2C            [24] 1917 	jnz	00175$
      006491 90 07 B7         [24] 1918 	mov	dptr,#_D0UsbConfig
      006494 E0               [24] 1919 	movx	a,@dptr
      006495 60 26            [24] 1920 	jz	00175$
      006497 BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      00649A 30 1A 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      00649D 8D 01            [24] 1923 	mov	ar1,r5
      00649F 8E 02            [24] 1924 	mov	ar2,r6
      0064A1 C3               [12] 1925 	clr	c
      0064A2 74 01            [12] 1926 	mov	a,#0x01
      0064A4 99               [12] 1927 	subb	a,r1
      0064A5 E4               [12] 1928 	clr	a
      0064A6 9A               [12] 1929 	subb	a,r2
      0064A7 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      0064A9 90 0D FC         [24] 1933 	mov	dptr,#_keyboard_protocol
      0064AC ED               [12] 1934 	mov	a,r5
      0064AD F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      0064AE 90 07 E1         [24] 1937 	mov	dptr,#_keyboard_reset
      0064B1 74 01            [12] 1938 	mov	a,#0x01
      0064B3 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      0064B4 90 08 10         [24] 1941 	mov	dptr,#_control_phase
      0064B7 74 03            [12] 1942 	mov	a,#0x03
      0064B9 F0               [24] 1943 	movx	@dptr,a
      0064BA 02 68 F0         [24] 1944 	ljmp	00291$
      0064BD                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      0064BD 02 5F 41         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      0064C0                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      0064C0 20 19 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      0064C3 02 5F 41         [24] 1952 	ljmp	_control_stall
      0064C6                       1953 01283$:
      0064C6 90 07 B2         [24] 1954 	mov	dptr,#_D0SetupLen
      0064C9 E0               [24] 1955 	movx	a,@dptr
      0064CA F9               [12] 1956 	mov	r1,a
      0064CB A3               [24] 1957 	inc	dptr
      0064CC E0               [24] 1958 	movx	a,@dptr
      0064CD FA               [12] 1959 	mov	r2,a
      0064CE B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      0064D1 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      0064D4 80 03            [24] 1962 	sjmp	01285$
      0064D6                       1963 01284$:
      0064D6 02 5F 41         [24] 1964 	ljmp	_control_stall
      0064D9                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0064D9 E4               [12] 1967 	clr	a
      0064DA BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      0064DD 04               [12] 1969 	inc	a
      0064DE                       1970 01286$:
      0064DE FA               [12] 1971 	mov	r2,a
      0064DF 60 03            [24] 1972 	jz	00196$
      0064E1 20 18 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      0064E4                       1974 00196$:
      0064E4 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      0064E7 30 17 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      0064EA 90 07 B7         [24] 1977 	mov	dptr,#_D0UsbConfig
      0064ED E0               [24] 1978 	movx	a,@dptr
      0064EE 70 29            [24] 1979 	jnz	00189$
      0064F0                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0064F0 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      0064F3 90 07 B7         [24] 1983 	mov	dptr,#_D0UsbConfig
      0064F6 E0               [24] 1984 	movx	a,@dptr
      0064F7 60 6A            [24] 1985 	jz	00190$
      0064F9 EB               [12] 1986 	mov	a,r3
      0064FA 4C               [12] 1987 	orl	a,r4
      0064FB 60 1C            [24] 1988 	jz	00189$
      0064FD 8B 00            [24] 1989 	mov	ar0,r3
      0064FF 8C 01            [24] 1990 	mov	ar1,r4
      006501 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      006504 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      006507 80 10            [24] 1993 	sjmp	00189$
      006509                       1994 01298$:
      006509 C3               [12] 1995 	clr	c
      00650A E8               [12] 1996 	mov	a,r0
      00650B 94 81            [12] 1997 	subb	a,#0x81
      00650D E9               [12] 1998 	mov	a,r1
      00650E 94 00            [12] 1999 	subb	a,#0x00
      006510 40 51            [24] 2000 	jc	00190$
      006512 74 83            [12] 2001 	mov	a,#0x83
      006514 98               [12] 2002 	subb	a,r0
      006515 E4               [12] 2003 	clr	a
      006516 99               [12] 2004 	subb	a,r1
      006517 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      006519                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      006519 8B 01            [24] 2009 	mov	ar1,r3
      00651B 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      00651E EA               [12] 2012 	mov	a,r2
      00651F 60 0B            [24] 2013 	jz	00308$
      006521 90 07 B9         [24] 2014 	mov	dptr,#_USB_SleepStatus
      006524 E0               [24] 2015 	movx	a,@dptr
      006525 54 01            [12] 2016 	anl	a,#0x01
      006527 25 E0            [12] 2017 	add	a,acc
      006529 FA               [12] 2018 	mov	r2,a
      00652A 80 22            [24] 2019 	sjmp	00309$
      00652C                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      00652C BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      00652F E9               [12] 2023 	mov	a,r1
      006530 60 18            [24] 2024 	jz	00310$
      006532 89 00            [24] 2025 	mov	ar0,r1
      006534 79 00            [12] 2026 	mov	r1,#0x00
      006536 74 22            [12] 2027 	mov	a,#0x22
      006538 29               [12] 2028 	add	a, r1
      006539 F9               [12] 2029 	mov	r1,a
      00653A 88 82            [24] 2030 	mov	dpl,r0
      00653C 89 83            [24] 2031 	mov	dph,r1
      00653E E0               [24] 2032 	movx	a,@dptr
      00653F F9               [12] 2033 	mov	r1,a
      006540 53 01 03         [24] 2034 	anl	ar1,#0x03
      006543 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      006546 79 01            [12] 2036 	mov	r1,#0x01
      006548 80 02            [24] 2037 	sjmp	00311$
      00654A                       2038 00310$:
      00654A 79 00            [12] 2039 	mov	r1,#0x00
      00654C                       2040 00311$:
      00654C 89 02            [24] 2041 	mov	ar2,r1
      00654E                       2042 00309$:
      00654E 90 10 00         [24] 2043 	mov	dptr,#0x1000
      006551 EA               [12] 2044 	mov	a,r2
      006552 F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      006553 A3               [24] 2047 	inc	dptr
      006554 E4               [12] 2048 	clr	a
      006555 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      006556 90 22 08         [24] 2051 	mov	dptr,#0x2208
      006559 74 02            [12] 2052 	mov	a,#0x02
      00655B F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      00655C 90 08 10         [24] 2055 	mov	dptr,#_control_phase
      00655F F0               [24] 2056 	movx	@dptr,a
      006560 02 68 F0         [24] 2057 	ljmp	00291$
      006563                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006563 02 5F 41         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006566                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      006566 20 1A 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      006569 02 65 F9         [24] 2065 	ljmp	00279$
      00656C                       2066 01307$:
      00656C 90 07 B7         [24] 2067 	mov	dptr,#_D0UsbConfig
      00656F E0               [24] 2068 	movx	a,@dptr
      006570 70 03            [24] 2069 	jnz	01308$
      006572 02 65 F9         [24] 2070 	ljmp	00279$
      006575                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      006575 EF               [12] 2073 	mov	a,r7
      006576 70 29            [24] 2074 	jnz	00218$
      006578 8D 01            [24] 2075 	mov	ar1,r5
      00657A 8E 02            [24] 2076 	mov	ar2,r6
      00657C B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      00657F BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      006582 30 18 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006585 90 07 B1         [24] 2081 	mov	dptr,#_D0SetupReqCode
      006588 E0               [24] 2082 	movx	a,@dptr
      006589 FA               [12] 2083 	mov	r2,a
      00658A BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      00658D 90 07 B9         [24] 2085 	mov	dptr,#_USB_SleepStatus
      006590 E0               [24] 2086 	movx	a,@dptr
      006591 43 E0 01         [24] 2087 	orl	acc,#0x01
      006594 F0               [24] 2088 	movx	@dptr,a
      006595 80 59            [24] 2089 	sjmp	00219$
      006597                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006597 90 07 B9         [24] 2092 	mov	dptr,#_USB_SleepStatus
      00659A E0               [24] 2093 	movx	a,@dptr
      00659B 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      00659E F0               [24] 2095 	movx	@dptr,a
      00659F 80 4F            [24] 2096 	sjmp	00219$
      0065A1                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0065A1 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      0065A4 30 19 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      0065A7 8B 01            [24] 2101 	mov	ar1,r3
      0065A9 8C 02            [24] 2102 	mov	ar2,r4
      0065AB C3               [12] 2103 	clr	c
      0065AC E9               [12] 2104 	mov	a,r1
      0065AD 94 81            [12] 2105 	subb	a,#0x81
      0065AF EA               [12] 2106 	mov	a,r2
      0065B0 94 00            [12] 2107 	subb	a,#0x00
      0065B2 40 39            [24] 2108 	jc	00212$
      0065B4 74 83            [12] 2109 	mov	a,#0x83
      0065B6 99               [12] 2110 	subb	a,r1
      0065B7 E4               [12] 2111 	clr	a
      0065B8 9A               [12] 2112 	subb	a,r2
      0065B9 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      0065BB 8B 02            [24] 2116 	mov	ar2,r3
      0065BD 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0065C0 8A 00            [24] 2119 	mov	ar0,r2
      0065C2 79 00            [12] 2120 	mov	r1,#0x00
      0065C4 74 22            [12] 2121 	mov	a,#0x22
      0065C6 29               [12] 2122 	add	a, r1
      0065C7 F9               [12] 2123 	mov	r1,a
      0065C8 88 17            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      0065CA 89 18            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0065CC 90 07 B1         [24] 2126 	mov	dptr,#_D0SetupReqCode
      0065CF E0               [24] 2127 	movx	a,@dptr
      0065D0 F9               [12] 2128 	mov	r1,a
      0065D1 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      0065D4 79 03            [12] 2130 	mov	r1,#0x03
      0065D6 80 02            [24] 2131 	sjmp	00319$
      0065D8                       2132 00318$:
      0065D8 79 02            [12] 2133 	mov	r1,#0x02
      0065DA                       2134 00319$:
      0065DA 43 01 10         [24] 2135 	orl	ar1,#0x10
      0065DD 85 17 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      0065E0 85 18 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0065E3 E9               [12] 2138 	mov	a,r1
      0065E4 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0065E5 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      0065E8 12 5E CD         [24] 2142 	lcall	_raw_complete
      0065EB 80 03            [24] 2143 	sjmp	00219$
      0065ED                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      0065ED 02 5F 41         [24] 2146 	ljmp	_control_stall
      0065F0                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      0065F0 90 08 10         [24] 2149 	mov	dptr,#_control_phase
      0065F3 74 03            [12] 2150 	mov	a,#0x03
      0065F5 F0               [24] 2151 	movx	@dptr,a
      0065F6 02 68 F0         [24] 2152 	ljmp	00291$
      0065F9                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0065F9 E4               [12] 2155 	clr	a
      0065FA BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      0065FD 04               [12] 2157 	inc	a
      0065FE                       2158 01324$:
      0065FE FA               [12] 2159 	mov	r2,a
      0065FF 70 03            [24] 2160 	jnz	01326$
      006601 02 68 6B         [24] 2161 	ljmp	00273$
      006604                       2162 01326$:
      006604 90 07 B1         [24] 2163 	mov	dptr,#_D0SetupReqCode
      006607 E0               [24] 2164 	movx	a,@dptr
      006608 F9               [12] 2165 	mov	r1,a
      006609 B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      00660C 80 03            [24] 2167 	sjmp	01328$
      00660E                       2168 01327$:
      00660E 02 68 6B         [24] 2169 	ljmp	00273$
      006611                       2170 01328$:
      006611 90 07 B7         [24] 2171 	mov	dptr,#_D0UsbConfig
      006614 E0               [24] 2172 	movx	a,@dptr
      006615 70 03            [24] 2173 	jnz	01329$
      006617 02 68 6B         [24] 2174 	ljmp	00273$
      00661A                       2175 01329$:
      00661A 90 07 B2         [24] 2176 	mov	dptr,#_D0SetupLen
      00661D E0               [24] 2177 	movx	a,@dptr
      00661E F8               [12] 2178 	mov	r0,a
      00661F A3               [24] 2179 	inc	dptr
      006620 E0               [24] 2180 	movx	a,@dptr
      006621 48               [12] 2181 	orl	a,r0
      006622 70 03            [24] 2182 	jnz	01330$
      006624 02 68 6B         [24] 2183 	ljmp	00273$
      006627                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      006627 C0 03            [24] 2186 	push	ar3
      006629 C0 04            [24] 2187 	push	ar4
      00662B 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      00662D 8E 00            [24] 2190 	mov	ar0,r6
      00662F B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      006632 E8               [12] 2192 	mov	a,r0
      006633 80 01            [24] 2193 	sjmp	01332$
      006635                       2194 01331$:
      006635 E4               [12] 2195 	clr	a
      006636                       2196 01332$:
      006636 F5 17            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      006638 D0 04            [24] 2198 	pop	ar4
      00663A D0 03            [24] 2199 	pop	ar3
      00663C E5 17            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      00663E 60 17            [24] 2201 	jz	00251$
      006640 EB               [12] 2202 	mov	a,r3
      006641 4C               [12] 2203 	orl	a,r4
      006642 70 13            [24] 2204 	jnz	00251$
      006644 E9               [12] 2205 	mov	a,r1
      006645 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      006647 90 08 1A         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      00664A 74 08            [12] 2209 	mov	a,#0x08
      00664C F0               [24] 2210 	movx	@dptr,a
      00664D E4               [12] 2211 	clr	a
      00664E A3               [24] 2212 	inc	dptr
      00664F F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006650 90 08 1C         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      006653 F0               [24] 2216 	movx	@dptr,a
      006654 02 67 DB         [24] 2217 	ljmp	00252$
      006657                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006657 E5 17            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      006659 60 27            [24] 2221 	jz	00245$
      00665B BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      00665E BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006661 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      006664                       2226 01339$:
      006664 50 1C            [24] 2227 	jnc	00245$
      006666 E9               [12] 2228 	mov	a,r1
      006667 90 BF 28         [24] 2229 	mov	dptr,#_shared_lengths
      00666A 93               [24] 2230 	movc	a,@a+dptr
      00666B F8               [12] 2231 	mov	r0,a
      00666C 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      00666E 90 08 1A         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      006671 E8               [12] 2235 	mov	a,r0
      006672 F0               [24] 2236 	movx	@dptr,a
      006673 E4               [12] 2237 	clr	a
      006674 A3               [24] 2238 	inc	dptr
      006675 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      006676 E9               [12] 2241 	mov	a,r1
      006677 90 BF 21         [24] 2242 	mov	dptr,#_shared_offsets
      00667A 93               [24] 2243 	movc	a,@a+dptr
      00667B 90 08 1C         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      00667E F0               [24] 2245 	movx	@dptr,a
      00667F 02 67 DB         [24] 2246 	ljmp	00252$
      006682                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006682 E5 17            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      006684 60 7A            [24] 2250 	jz	00240$
      006686 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      006689 BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      00668C E9               [12] 2253 	mov	a,r1
      00668D 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00668F 90 07 B2         [24] 2256 	mov	dptr,#_D0SetupLen
      006692 E0               [24] 2257 	movx	a,@dptr
      006693 F8               [12] 2258 	mov	r0,a
      006694 A3               [24] 2259 	inc	dptr
      006695 E0               [24] 2260 	movx	a,@dptr
      006696 F9               [12] 2261 	mov	r1,a
      006697 C3               [12] 2262 	clr	c
      006698 E8               [12] 2263 	mov	a,r0
      006699 94 20            [12] 2264 	subb	a,#0x20
      00669B E9               [12] 2265 	mov	a,r1
      00669C 94 00            [12] 2266 	subb	a,#0x00
      00669E 50 0A            [24] 2267 	jnc	00320$
      0066A0 90 07 B2         [24] 2268 	mov	dptr,#_D0SetupLen
      0066A3 E0               [24] 2269 	movx	a,@dptr
      0066A4 F8               [12] 2270 	mov	r0,a
      0066A5 A3               [24] 2271 	inc	dptr
      0066A6 E0               [24] 2272 	movx	a,@dptr
      0066A7 F9               [12] 2273 	mov	r1,a
      0066A8 80 04            [24] 2274 	sjmp	00321$
      0066AA                       2275 00320$:
      0066AA 78 20            [12] 2276 	mov	r0,#0x20
      0066AC 79 00            [12] 2277 	mov	r1,#0x00
      0066AE                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0066AE 75 17 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      0066B1                       2281 00293$:
      0066B1 C0 03            [24] 2282 	push	ar3
      0066B3 C0 04            [24] 2283 	push	ar4
      0066B5 AB 17            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      0066B7 7C 00            [12] 2285 	mov	r4,#0x00
      0066B9 C3               [12] 2286 	clr	c
      0066BA EB               [12] 2287 	mov	a,r3
      0066BB 98               [12] 2288 	subb	a,r0
      0066BC EC               [12] 2289 	mov	a,r4
      0066BD 99               [12] 2290 	subb	a,r1
      0066BE D0 04            [24] 2291 	pop	ar4
      0066C0 D0 03            [24] 2292 	pop	ar3
      0066C2 50 32            [24] 2293 	jnc	00222$
      0066C4 C0 00            [24] 2294 	push	ar0
      0066C6 C0 01            [24] 2295 	push	ar1
      0066C8 85 17 19         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0066CB 74 10            [12] 2297 	mov	a,#0x10
      0066CD 24 00            [12] 2298 	add	a, #0x00
      0066CF F5 1A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      0066D1 A8 17            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      0066D3 79 00            [12] 2301 	mov	r1,#0x00
      0066D5 74 C0            [12] 2302 	mov	a,#0xc0
      0066D7 28               [12] 2303 	add	a, r0
      0066D8 F8               [12] 2304 	mov	r0,a
      0066D9 E4               [12] 2305 	clr	a
      0066DA 39               [12] 2306 	addc	a, r1
      0066DB F9               [12] 2307 	mov	r1,a
      0066DC 88 82            [24] 2308 	mov	dpl,r0
      0066DE 74 10            [12] 2309 	mov	a,#0x10
      0066E0 29               [12] 2310 	add	a, r1
      0066E1 F5 83            [12] 2311 	mov	dph,a
      0066E3 E0               [24] 2312 	movx	a,@dptr
      0066E4 85 19 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      0066E7 85 1A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0066EA F0               [24] 2315 	movx	@dptr,a
      0066EB E5 17            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      0066ED 04               [12] 2317 	inc	a
      0066EE F5 17            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      0066F0 D0 01            [24] 2319 	pop	ar1
      0066F2 D0 00            [24] 2320 	pop	ar0
      0066F4 80 BB            [24] 2321 	sjmp	00293$
      0066F6                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      0066F6 90 08 1A         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      0066F9 E4               [12] 2325 	clr	a
      0066FA F0               [24] 2326 	movx	@dptr,a
      0066FB A3               [24] 2327 	inc	dptr
      0066FC F0               [24] 2328 	movx	@dptr,a
      0066FD 02 67 DB         [24] 2329 	ljmp	00252$
      006700                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006700 8D 00            [24] 2332 	mov	ar0,r5
      006702 8E 01            [24] 2333 	mov	ar1,r6
      006704 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      006707 B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      00670A EB               [12] 2336 	mov	a,r3
      00670B 4C               [12] 2337 	orl	a,r4
      00670C 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      00670E 90 07 BC         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      006711 E0               [24] 2341 	movx	a,@dptr
      006712 90 10 00         [24] 2342 	mov	dptr,#0x1000
      006715 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      006716 90 08 1A         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      006719 E4               [12] 2346 	clr	a
      00671A F0               [24] 2347 	movx	@dptr,a
      00671B A3               [24] 2348 	inc	dptr
      00671C F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      00671D 90 07 B2         [24] 2351 	mov	dptr,#_D0SetupLen
      006720 04               [12] 2352 	inc	a
      006721 F0               [24] 2353 	movx	@dptr,a
      006722 E4               [12] 2354 	clr	a
      006723 A3               [24] 2355 	inc	dptr
      006724 F0               [24] 2356 	movx	@dptr,a
      006725 02 67 DB         [24] 2357 	ljmp	00252$
      006728                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006728 B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      00672B B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      00672E BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      006731 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006734 C0 03            [24] 2365 	push	ar3
      006736 C0 04            [24] 2366 	push	ar4
      006738 90 10 00         [24] 2367 	mov	dptr,#0x1000
      00673B 74 06            [12] 2368 	mov	a,#0x06
      00673D F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      00673E 90 07 BC         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      006741 E0               [24] 2372 	movx	a,@dptr
      006742 90 10 01         [24] 2373 	mov	dptr,#0x1001
      006745 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      006746 90 08 1A         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      006749 E4               [12] 2377 	clr	a
      00674A F0               [24] 2378 	movx	@dptr,a
      00674B A3               [24] 2379 	inc	dptr
      00674C F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      00674D 90 07 B2         [24] 2382 	mov	dptr,#_D0SetupLen
      006750 E0               [24] 2383 	movx	a,@dptr
      006751 FB               [12] 2384 	mov	r3,a
      006752 A3               [24] 2385 	inc	dptr
      006753 E0               [24] 2386 	movx	a,@dptr
      006754 FC               [12] 2387 	mov	r4,a
      006755 C3               [12] 2388 	clr	c
      006756 74 02            [12] 2389 	mov	a,#0x02
      006758 9B               [12] 2390 	subb	a,r3
      006759 E4               [12] 2391 	clr	a
      00675A 9C               [12] 2392 	subb	a,r4
      00675B D0 04            [24] 2393 	pop	ar4
      00675D D0 03            [24] 2394 	pop	ar3
      00675F 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      006761 90 07 B2         [24] 2397 	mov	dptr,#_D0SetupLen
      006764 74 02            [12] 2398 	mov	a,#0x02
      006766 F0               [24] 2399 	movx	@dptr,a
      006767 E4               [12] 2400 	clr	a
      006768 A3               [24] 2401 	inc	dptr
      006769 F0               [24] 2402 	movx	@dptr,a
      00676A 80 6F            [24] 2403 	sjmp	00252$
      00676C                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00676C B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      00676F B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      006772 BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      006775 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006778 90 10 00         [24] 2411 	mov	dptr,#0x1000
      00677B 74 41            [12] 2412 	mov	a,#0x41
      00677D F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      00677E A3               [24] 2415 	inc	dptr
      00677F 74 4B            [12] 2416 	mov	a,#0x4b
      006781 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      006782 A3               [24] 2419 	inc	dptr
      006783 74 42            [12] 2420 	mov	a,#0x42
      006785 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      006786 A3               [24] 2423 	inc	dptr
      006787 74 54            [12] 2424 	mov	a,#0x54
      006789 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      00678A A3               [24] 2427 	inc	dptr
      00678B 74 01            [12] 2428 	mov	a,#0x01
      00678D F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      00678E 90 07 BD         [24] 2431 	mov	dptr,#_ak820_boot_stage
      006791 E0               [24] 2432 	movx	a,@dptr
      006792 90 10 05         [24] 2433 	mov	dptr,#0x1005
      006795 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006796 90 07 BE         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      006799 E0               [24] 2437 	movx	a,@dptr
      00679A 90 10 06         [24] 2438 	mov	dptr,#0x1006
      00679D F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00679E 90 07 B8         [24] 2441 	mov	dptr,#_USB_EnumStatus
      0067A1 E0               [24] 2442 	movx	a,@dptr
      0067A2 60 02            [24] 2443 	jz	00322$
      0067A4 74 01            [12] 2444 	mov	a,#0x01
      0067A6                       2445 00322$:
      0067A6 F9               [12] 2446 	mov	r1,a
      0067A7 90 07 B9         [24] 2447 	mov	dptr,#_USB_SleepStatus
      0067AA E0               [24] 2448 	movx	a,@dptr
      0067AB 54 02            [12] 2449 	anl	a,#0x02
      0067AD F8               [12] 2450 	mov	r0,a
      0067AE E9               [12] 2451 	mov	a,r1
      0067AF 42 00            [12] 2452 	orl	ar0,a
      0067B1 90 10 07         [24] 2453 	mov	dptr,#0x1007
      0067B4 E8               [12] 2454 	mov	a,r0
      0067B5 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      0067B6 90 08 1A         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      0067B9 E4               [12] 2458 	clr	a
      0067BA F0               [24] 2459 	movx	@dptr,a
      0067BB A3               [24] 2460 	inc	dptr
      0067BC F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      0067BD 90 07 B2         [24] 2463 	mov	dptr,#_D0SetupLen
      0067C0 E0               [24] 2464 	movx	a,@dptr
      0067C1 F8               [12] 2465 	mov	r0,a
      0067C2 A3               [24] 2466 	inc	dptr
      0067C3 E0               [24] 2467 	movx	a,@dptr
      0067C4 F9               [12] 2468 	mov	r1,a
      0067C5 C3               [12] 2469 	clr	c
      0067C6 74 08            [12] 2470 	mov	a,#0x08
      0067C8 98               [12] 2471 	subb	a,r0
      0067C9 E4               [12] 2472 	clr	a
      0067CA 99               [12] 2473 	subb	a,r1
      0067CB 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      0067CD 90 07 B2         [24] 2476 	mov	dptr,#_D0SetupLen
      0067D0 74 08            [12] 2477 	mov	a,#0x08
      0067D2 F0               [24] 2478 	movx	@dptr,a
      0067D3 E4               [12] 2479 	clr	a
      0067D4 A3               [24] 2480 	inc	dptr
      0067D5 F0               [24] 2481 	movx	@dptr,a
      0067D6 80 03            [24] 2482 	sjmp	00252$
      0067D8                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      0067D8 02 5F 41         [24] 2485 	ljmp	_control_stall
      0067DB                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      0067DB 90 08 1A         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      0067DE E0               [24] 2489 	movx	a,@dptr
      0067DF F5 19            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      0067E1 A3               [24] 2491 	inc	dptr
      0067E2 E0               [24] 2492 	movx	a,@dptr
      0067E3 F5 1A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      0067E5 E5 19            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      0067E7 45 1A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0067E9 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      0067EB 90 07 B2         [24] 2498 	mov	dptr,#_D0SetupLen
      0067EE E0               [24] 2499 	movx	a,@dptr
      0067EF F8               [12] 2500 	mov	r0,a
      0067F0 A3               [24] 2501 	inc	dptr
      0067F1 E0               [24] 2502 	movx	a,@dptr
      0067F2 F9               [12] 2503 	mov	r1,a
      0067F3 C3               [12] 2504 	clr	c
      0067F4 E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      0067F6 98               [12] 2506 	subb	a,r0
      0067F7 E5 1A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0067F9 99               [12] 2508 	subb	a,r1
      0067FA 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      0067FC 90 07 B2         [24] 2511 	mov	dptr,#_D0SetupLen
      0067FF E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      006801 F0               [24] 2513 	movx	@dptr,a
      006802 E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006804 A3               [24] 2515 	inc	dptr
      006805 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006806                       2518 00559$:
      006806 75 19 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      006809                       2520 00296$:
      006809 90 07 B2         [24] 2521 	mov	dptr,#_D0SetupLen
      00680C E0               [24] 2522 	movx	a,@dptr
      00680D F8               [12] 2523 	mov	r0,a
      00680E C3               [12] 2524 	clr	c
      00680F E5 19            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      006811 98               [12] 2526 	subb	a,r0
      006812 50 46            [24] 2527 	jnc	00263$
      006814 85 19 17         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006817 74 10            [12] 2529 	mov	a,#0x10
      006819 24 00            [12] 2530 	add	a, #0x00
      00681B F5 18            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      00681D 90 08 1C         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      006820 E0               [24] 2533 	movx	a,@dptr
      006821 25 19            [12] 2534 	add	a, _control_setup_sloc4_1_0
      006823 24 E2            [12] 2535 	add	a, #_input_snapshot
      006825 F5 82            [12] 2536 	mov	dpl,a
      006827 E4               [12] 2537 	clr	a
      006828 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      00682A F5 83            [12] 2539 	mov	dph,a
      00682C E0               [24] 2540 	movx	a,@dptr
      00682D 85 17 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      006830 85 18 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006833 F0               [24] 2543 	movx	@dptr,a
      006834 E5 19            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      006836 04               [12] 2545 	inc	a
      006837 F5 19            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      006839 80 CE            [24] 2547 	sjmp	00296$
      00683B                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      00683B BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      00683E BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      006841 90 07 B2         [24] 2552 	mov	dptr,#_D0SetupLen
      006844 E0               [24] 2553 	movx	a,@dptr
      006845 F8               [12] 2554 	mov	r0,a
      006846 A3               [24] 2555 	inc	dptr
      006847 E0               [24] 2556 	movx	a,@dptr
      006848 F9               [12] 2557 	mov	r1,a
      006849 C3               [12] 2558 	clr	c
      00684A 74 20            [12] 2559 	mov	a,#0x20
      00684C 98               [12] 2560 	subb	a,r0
      00684D E4               [12] 2561 	clr	a
      00684E 99               [12] 2562 	subb	a,r1
      00684F 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      006851 90 07 B2         [24] 2565 	mov	dptr,#_D0SetupLen
      006854 74 20            [12] 2566 	mov	a,#0x20
      006856 F0               [24] 2567 	movx	@dptr,a
      006857 E4               [12] 2568 	clr	a
      006858 A3               [24] 2569 	inc	dptr
      006859 F0               [24] 2570 	movx	@dptr,a
      00685A                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      00685A 90 07 B2         [24] 2573 	mov	dptr,#_D0SetupLen
      00685D E0               [24] 2574 	movx	a,@dptr
      00685E 90 22 08         [24] 2575 	mov	dptr,#0x2208
      006861 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006862 90 08 10         [24] 2578 	mov	dptr,#_control_phase
      006865 74 02            [12] 2579 	mov	a,#0x02
      006867 F0               [24] 2580 	movx	@dptr,a
      006868 02 68 F0         [24] 2581 	ljmp	00291$
      00686B                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      00686B EB               [12] 2584 	mov	a,r3
      00686C 4C               [12] 2585 	orl	a,r4
      00686D 70 37            [24] 2586 	jnz	00265$
      00686F 90 07 B7         [24] 2587 	mov	dptr,#_D0UsbConfig
      006872 E0               [24] 2588 	movx	a,@dptr
      006873 60 31            [24] 2589 	jz	00265$
      006875 EA               [12] 2590 	mov	a,r2
      006876 60 2E            [24] 2591 	jz	00265$
      006878 90 07 B1         [24] 2592 	mov	dptr,#_D0SetupReqCode
      00687B E0               [24] 2593 	movx	a,@dptr
      00687C FA               [12] 2594 	mov	r2,a
      00687D BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      006880 30 19 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      006883 90 07 B2         [24] 2597 	mov	dptr,#_D0SetupLen
      006886 E0               [24] 2598 	movx	a,@dptr
      006887 F9               [12] 2599 	mov	r1,a
      006888 A3               [24] 2600 	inc	dptr
      006889 E0               [24] 2601 	movx	a,@dptr
      00688A FA               [12] 2602 	mov	r2,a
      00688B B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      00688E BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      006891 90 0D FC         [24] 2606 	mov	dptr,#_keyboard_protocol
      006894 E0               [24] 2607 	movx	a,@dptr
      006895 90 10 00         [24] 2608 	mov	dptr,#0x1000
      006898 F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006899 90 22 08         [24] 2611 	mov	dptr,#0x2208
      00689C 74 01            [12] 2612 	mov	a,#0x01
      00689E F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      00689F 90 08 10         [24] 2615 	mov	dptr,#_control_phase
      0068A2 04               [12] 2616 	inc	a
      0068A3 F0               [24] 2617 	movx	@dptr,a
      0068A4 80 4A            [24] 2618 	sjmp	00291$
      0068A6                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      0068A6 02 5F 41         [24] 2622 	ljmp	_control_stall
      0068A9                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0068A9 30 17 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      0068AC 90 07 B7         [24] 2626 	mov	dptr,#_D0UsbConfig
      0068AF E0               [24] 2627 	movx	a,@dptr
      0068B0 60 38            [24] 2628 	jz	00284$
      0068B2 BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      0068B5 8E 05            [24] 2630 	mov	ar5,r6
      0068B7 7E 00            [12] 2631 	mov	r6,#0x00
      0068B9 ED               [12] 2632 	mov	a,r5
      0068BA 4E               [12] 2633 	orl	a,r6
      0068BB 70 2D            [24] 2634 	jnz	00284$
      0068BD 90 07 B2         [24] 2635 	mov	dptr,#_D0SetupLen
      0068C0 E0               [24] 2636 	movx	a,@dptr
      0068C1 FE               [12] 2637 	mov	r6,a
      0068C2 A3               [24] 2638 	inc	dptr
      0068C3 E0               [24] 2639 	movx	a,@dptr
      0068C4 FF               [12] 2640 	mov	r7,a
      0068C5 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      0068C8 BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0068CB EB               [12] 2644 	mov	a,r3
      0068CC 4C               [12] 2645 	orl	a,r4
      0068CD 70 07            [24] 2646 	jnz	00324$
      0068CF 90 06 8F         [24] 2647 	mov	dptr,#_keyboard_idle
      0068D2 E0               [24] 2648 	movx	a,@dptr
      0068D3 FF               [12] 2649 	mov	r7,a
      0068D4 80 02            [24] 2650 	sjmp	00325$
      0068D6                       2651 00324$:
      0068D6 7F 00            [12] 2652 	mov	r7,#0x00
      0068D8                       2653 00325$:
      0068D8 90 10 00         [24] 2654 	mov	dptr,#0x1000
      0068DB EF               [12] 2655 	mov	a,r7
      0068DC F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      0068DD 90 22 08         [24] 2658 	mov	dptr,#0x2208
      0068E0 74 01            [12] 2659 	mov	a,#0x01
      0068E2 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      0068E3 90 08 10         [24] 2662 	mov	dptr,#_control_phase
      0068E6 04               [12] 2663 	inc	a
      0068E7 F0               [24] 2664 	movx	@dptr,a
      0068E8 80 06            [24] 2665 	sjmp	00291$
      0068EA                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      0068EA 02 5F 41         [24] 2669 	ljmp	_control_stall
      0068ED                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      0068ED 02 5F 41         [24] 2672 	ljmp	_control_stall
      0068F0                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0068F0 90 22 00         [24] 2675 	mov	dptr,#0x2200
      0068F3 74 C0            [12] 2676 	mov	a,#0xc0
      0068F5 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      0068F6 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      0068F7                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0068F7 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      0068FA E0               [24] 2692 	movx	a,@dptr
      0068FB 20 E6 01         [24] 2693 	jb	acc.6,00102$
      0068FE 22               [24] 2694 	ret
      0068FF                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0068FF 90 08 10         [24] 2697 	mov	dptr,#_control_phase
      006902 E0               [24] 2698 	movx	a,@dptr
      006903 FF               [12] 2699 	mov	r7,a
      006904 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      006907 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      00690A E0               [24] 2702 	movx	a,@dptr
      00690B 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      00690D 90 08 10         [24] 2705 	mov	dptr,#_control_phase
      006910 E4               [12] 2706 	clr	a
      006911 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006912 90 22 00         [24] 2709 	mov	dptr,#0x2200
      006915 74 02            [12] 2710 	mov	a,#0x02
      006917 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006918 22               [24] 2713 	ret
      006919                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006919 BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      00691C 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      00691F E0               [24] 2718 	movx	a,@dptr
      006920 FF               [12] 2719 	mov	r7,a
      006921 90 07 B2         [24] 2720 	mov	dptr,#_D0SetupLen
      006924 E0               [24] 2721 	movx	a,@dptr
      006925 FD               [12] 2722 	mov	r5,a
      006926 A3               [24] 2723 	inc	dptr
      006927 E0               [24] 2724 	movx	a,@dptr
      006928 FE               [12] 2725 	mov	r6,a
      006929 7C 00            [12] 2726 	mov	r4,#0x00
      00692B EF               [12] 2727 	mov	a,r7
      00692C B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      00692F EC               [12] 2729 	mov	a,r4
      006930 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      006933 80 03            [24] 2731 	sjmp	00107$
      006935                       2732 00209$:
      006935                       2733 00106$:
      006935 02 5F 41         [24] 2734 	ljmp	_control_stall
      006938                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006938 90 08 11         [24] 2737 	mov	dptr,#_output_kind
      00693B E0               [24] 2738 	movx	a,@dptr
      00693C FF               [12] 2739 	mov	r7,a
      00693D BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      006940 90 07 BF         [24] 2741 	mov	dptr,#_raw_state
      006943 E0               [24] 2742 	movx	a,@dptr
      006944 FE               [12] 2743 	mov	r6,a
      006945 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006948 7E 00            [12] 2746 	mov	r6,#0x00
      00694A                       2747 00121$:
      00694A EE               [12] 2748 	mov	a,r6
      00694B 24 C0            [12] 2749 	add	a, #_raw_buffer
      00694D FC               [12] 2750 	mov	r4,a
      00694E E4               [12] 2751 	clr	a
      00694F 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      006951 FD               [12] 2753 	mov	r5,a
      006952 8E 82            [24] 2754 	mov	dpl,r6
      006954 74 10            [12] 2755 	mov	a,#0x10
      006956 24 00            [12] 2756 	add	a, #0x00
      006958 F5 83            [12] 2757 	mov	dph,a
      00695A E0               [24] 2758 	movx	a,@dptr
      00695B 8C 82            [24] 2759 	mov	dpl,r4
      00695D 8D 83            [24] 2760 	mov	dph,r5
      00695F F0               [24] 2761 	movx	@dptr,a
      006960 0E               [12] 2762 	inc	r6
      006961 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      006964                       2764 00214$:
      006964 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006966 90 07 BF         [24] 2767 	mov	dptr,#_raw_state
      006969 74 02            [12] 2768 	mov	a,#0x02
      00696B F0               [24] 2769 	movx	@dptr,a
      00696C 80 2B            [24] 2770 	sjmp	00119$
      00696E                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      00696E BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006971 90 10 00         [24] 2775 	mov	dptr,#0x1000
      006974 E0               [24] 2776 	movx	a,@dptr
      006975 90 07 BC         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      006978 F0               [24] 2778 	movx	@dptr,a
      006979 80 1E            [24] 2779 	sjmp	00119$
      00697B                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      00697B BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      00697E 90 10 00         [24] 2783 	mov	dptr,#0x1000
      006981 E0               [24] 2784 	movx	a,@dptr
      006982 FF               [12] 2785 	mov	r7,a
      006983 90 08 12         [24] 2786 	mov	dptr,#_output_report_id
      006986 E0               [24] 2787 	movx	a,@dptr
      006987 FE               [12] 2788 	mov	r6,a
      006988 EF               [12] 2789 	mov	a,r7
      006989 B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      00698C 90 10 01         [24] 2792 	mov	dptr,#0x1001
      00698F E0               [24] 2793 	movx	a,@dptr
      006990 90 07 BC         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      006993 F0               [24] 2795 	movx	@dptr,a
      006994 80 03            [24] 2796 	sjmp	00119$
      006996                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006996 02 5F 41         [24] 2799 	ljmp	_control_stall
      006999                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006999 90 08 11         [24] 2802 	mov	dptr,#_output_kind
      00699C E4               [12] 2803 	clr	a
      00699D F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      00699E 90 07 B2         [24] 2806 	mov	dptr,#_D0SetupLen
      0069A1 F0               [24] 2807 	movx	@dptr,a
      0069A2 A3               [24] 2808 	inc	dptr
      0069A3 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      0069A4 90 08 10         [24] 2811 	mov	dptr,#_control_phase
      0069A7 74 03            [12] 2812 	mov	a,#0x03
      0069A9 F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      0069AA 90 22 08         [24] 2815 	mov	dptr,#0x2208
      0069AD E4               [12] 2816 	clr	a
      0069AE F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      0069AF F5 82            [12] 2819 	mov	dpl,a
      0069B1 74 48            [12] 2820 	mov	a,#0x48
      0069B3 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      0069B4 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      0069B5                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      0069B5 90 08 10         [24] 2833 	mov	dptr,#_control_phase
      0069B8 E0               [24] 2834 	movx	a,@dptr
      0069B9 FF               [12] 2835 	mov	r7,a
      0069BA BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      0069BD 90 07 B2         [24] 2838 	mov	dptr,#_D0SetupLen
      0069C0 E0               [24] 2839 	movx	a,@dptr
      0069C1 FD               [12] 2840 	mov	r5,a
      0069C2 A3               [24] 2841 	inc	dptr
      0069C3 E0               [24] 2842 	movx	a,@dptr
      0069C4 4D               [12] 2843 	orl	a,r5
      0069C5 70 06            [24] 2844 	jnz	00101$
      0069C7 90 08 13         [24] 2845 	mov	dptr,#_control_zlp
      0069CA E0               [24] 2846 	movx	a,@dptr
      0069CB 60 0A            [24] 2847 	jz	00102$
      0069CD                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      0069CD 90 22 00         [24] 2850 	mov	dptr,#0x2200
      0069D0 E0               [24] 2851 	movx	a,@dptr
      0069D1 64 40            [12] 2852 	xrl	a,#0x40
      0069D3 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      0069D4 02 5F 63         [24] 2856 	ljmp	_control_next
      0069D7                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      0069D7 90 08 10         [24] 2859 	mov	dptr,#_control_phase
      0069DA 74 02            [12] 2860 	mov	a,#0x02
      0069DC F0               [24] 2861 	movx	@dptr,a
      0069DD 80 18            [24] 2862 	sjmp	00110$
      0069DF                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      0069DF BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      0069E2 90 07 B1         [24] 2867 	mov	dptr,#_D0SetupReqCode
      0069E5 E0               [24] 2868 	movx	a,@dptr
      0069E6 FF               [12] 2869 	mov	r7,a
      0069E7 BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      0069EA 90 07 B2         [24] 2871 	mov	dptr,#_D0SetupLen
      0069ED E0               [24] 2872 	movx	a,@dptr
      0069EE 90 22 07         [24] 2873 	mov	dptr,#0x2207
      0069F1 F0               [24] 2874 	movx	@dptr,a
      0069F2                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      0069F2 90 08 10         [24] 2877 	mov	dptr,#_control_phase
      0069F5 E4               [12] 2878 	clr	a
      0069F6 F0               [24] 2879 	movx	@dptr,a
      0069F7                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0069F7 90 22 00         [24] 2882 	mov	dptr,#0x2200
      0069FA 74 82            [12] 2883 	mov	a,#0x82
      0069FC F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      0069FD 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      0069FE                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      0069FE                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      0069FE 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      006A01 E0               [24] 2902 	movx	a,@dptr
      006A02 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006A05 12 5E EA         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006A08 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006A0B E4               [12] 2908 	clr	a
      006A0C F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006A0D 90 07 B9         [24] 2911 	mov	dptr,#_USB_SleepStatus
      006A10 F0               [24] 2912 	movx	@dptr,a
      006A11 90 07 B8         [24] 2913 	mov	dptr,#_USB_EnumStatus
      006A14 F0               [24] 2914 	movx	@dptr,a
      006A15 90 07 B7         [24] 2915 	mov	dptr,#_D0UsbConfig
      006A18 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006A19 90 07 BC         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      006A1C F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006A1D 90 0D FC         [24] 2921 	mov	dptr,#_keyboard_protocol
      006A20 04               [12] 2922 	inc	a
      006A21 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006A22 90 06 8F         [24] 2925 	mov	dptr,#_keyboard_idle
      006A25 E4               [12] 2926 	clr	a
      006A26 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006A27 90 07 E1         [24] 2929 	mov	dptr,#_keyboard_reset
      006A2A 04               [12] 2930 	inc	a
      006A2B F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006A2C 90 07 B1         [24] 2933 	mov	dptr,#_D0SetupReqCode
      006A2F 74 FF            [12] 2934 	mov	a,#0xff
      006A31 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006A32 90 07 B2         [24] 2937 	mov	dptr,#_D0SetupLen
      006A35 E4               [12] 2938 	clr	a
      006A36 F0               [24] 2939 	movx	@dptr,a
      006A37 A3               [24] 2940 	inc	dptr
      006A38 F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006A39 90 08 10         [24] 2943 	mov	dptr,#_control_phase
      006A3C F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A3D 90 22 00         [24] 2946 	mov	dptr,#0x2200
      006A40 74 02            [12] 2947 	mov	a,#0x02
      006A42 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006A43 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      006A46 E4               [12] 2951 	clr	a
      006A47 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006A48 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      006A4B 04               [12] 2955 	inc	a
      006A4C F0               [24] 2956 	movx	@dptr,a
      006A4D 02 6A E3         [24] 2957 	ljmp	00130$
      006A50                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006A50 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      006A53 E0               [24] 2961 	movx	a,@dptr
      006A54 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006A57 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      006A5A E0               [24] 2965 	movx	a,@dptr
      006A5B FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006A5C 74 07            [12] 2968 	mov	a,#0x07
      006A5E 5F               [12] 2969 	anl	a,r7
      006A5F FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006A60 EF               [12] 2972 	mov	a,r7
      006A61 54 18            [12] 2973 	anl	a,#0x18
      006A63 70 08            [24] 2974 	jnz	00115$
      006A65 EE               [12] 2975 	mov	a,r6
      006A66 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006A68 12 68 F7         [24] 2978 	lcall	_control_out
      006A6B 80 43            [24] 2979 	sjmp	00116$
      006A6D                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006A6D 8F 05            [24] 2982 	mov	ar5,r7
      006A6F 74 18            [12] 2983 	mov	a,#0x18
      006A71 5D               [12] 2984 	anl	a,r5
      006A72 FC               [12] 2985 	mov	r4,a
      006A73 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006A76 EE               [12] 2988 	mov	a,r6
      006A77 70 05            [24] 2989 	jnz	00106$
      006A79 12 69 B5         [24] 2990 	lcall	_control_in
      006A7C 80 32            [24] 2991 	sjmp	00116$
      006A7E                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006A7E EE               [12] 2994 	mov	a,r6
      006A7F 24 FC            [12] 2995 	add	a,#0xff - 0x03
      006A81 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006A83 8E 04            [24] 2999 	mov	ar4,r6
      006A85 7B 00            [12] 3000 	mov	r3,#0x00
      006A87 74 22            [12] 3001 	mov	a,#0x22
      006A89 2B               [12] 3002 	add	a, r3
      006A8A FB               [12] 3003 	mov	r3,a
      006A8B 8C 82            [24] 3004 	mov	dpl,r4
      006A8D 8B 83            [24] 3005 	mov	dph,r3
      006A8F E0               [24] 3006 	movx	a,@dptr
      006A90 FA               [12] 3007 	mov	r2,a
      006A91 74 FC            [12] 3008 	mov	a,#0xfc
      006A93 5A               [12] 3009 	anl	a,r2
      006A94 44 02            [12] 3010 	orl	a,#0x02
      006A96 8C 82            [24] 3011 	mov	dpl,r4
      006A98 8B 83            [24] 3012 	mov	dph,r3
      006A9A F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006A9B BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      006A9E 12 5E CD         [24] 3016 	lcall	_raw_complete
      006AA1 80 0D            [24] 3017 	sjmp	00116$
      006AA3                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006AA3 53 05 18         [24] 3020 	anl	ar5,#0x18
      006AA6 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      006AA9 EF               [12] 3022 	mov	a,r7
      006AAA 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006AAD 12 61 5A         [24] 3025 	lcall	_control_setup
      006AB0                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006AB0 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      006AB3 E4               [12] 3029 	clr	a
      006AB4 F0               [24] 3030 	movx	@dptr,a
      006AB5 80 2C            [24] 3031 	sjmp	00130$
      006AB7                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006AB7 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      006ABA E0               [24] 3035 	movx	a,@dptr
      006ABB 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006ABE 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006AC1 E0               [24] 3039 	movx	a,@dptr
      006AC2 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006AC5 90 07 B9         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006AC8 E0               [24] 3042 	movx	a,@dptr
      006AC9 43 E0 02         [24] 3043 	orl	acc,#0x02
      006ACC F0               [24] 3044 	movx	@dptr,a
      006ACD 80 0E            [24] 3045 	sjmp	00120$
      006ACF                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006ACF 90 07 B9         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006AD2 E0               [24] 3049 	movx	a,@dptr
      006AD3 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006AD6 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006AD7 90 07 E1         [24] 3053 	mov	dptr,#_keyboard_reset
      006ADA 74 01            [12] 3054 	mov	a,#0x01
      006ADC F0               [24] 3055 	movx	@dptr,a
      006ADD                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006ADD 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006AE0 74 04            [12] 3059 	mov	a,#0x04
      006AE2 F0               [24] 3060 	movx	@dptr,a
      006AE3                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006AE3 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006AE6 E0               [24] 3064 	movx	a,@dptr
      006AE7 54 25            [12] 3065 	anl	a,#0x25
      006AE9 60 03            [24] 3066 	jz	00242$
      006AEB 02 69 FE         [24] 3067 	ljmp	00129$
      006AEE                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006AEE 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006AEF                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3080 ;	assignBit
      006AEF C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006AF1 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006AF4 E4               [12] 3084 	clr	a
      006AF5 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006AF6 90 07 BF         [24] 3087 	mov	dptr,#_raw_state
      006AF9 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006AFA 12 5E EA         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006AFD 90 07 B9         [24] 3092 	mov	dptr,#_USB_SleepStatus
      006B00 E4               [12] 3093 	clr	a
      006B01 F0               [24] 3094 	movx	@dptr,a
      006B02 90 07 B8         [24] 3095 	mov	dptr,#_USB_EnumStatus
      006B05 F0               [24] 3096 	movx	@dptr,a
      006B06 90 07 B7         [24] 3097 	mov	dptr,#_D0UsbConfig
      006B09 F0               [24] 3098 	movx	@dptr,a
      006B0A 90 22 07         [24] 3099 	mov	dptr,#0x2207
      006B0D F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006B0E 90 07 BA         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      006B11 F0               [24] 3103 	movx	@dptr,a
      006B12 90 07 BB         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      006B15 F0               [24] 3105 	movx	@dptr,a
      006B16 90 07 BC         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      006B19 F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006B1A 90 0D FC         [24] 3109 	mov	dptr,#_keyboard_protocol
      006B1D 04               [12] 3110 	inc	a
      006B1E F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006B1F 90 06 8F         [24] 3113 	mov	dptr,#_keyboard_idle
      006B22 E4               [12] 3114 	clr	a
      006B23 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006B24 90 07 E1         [24] 3117 	mov	dptr,#_keyboard_reset
      006B27 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006B28 90 08 10         [24] 3120 	mov	dptr,#_control_phase
      006B2B F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006B2C 90 07 B1         [24] 3123 	mov	dptr,#_D0SetupReqCode
      006B2F 14               [12] 3124 	dec	a
      006B30 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006B31 90 07 B2         [24] 3127 	mov	dptr,#_D0SetupLen
      006B34 E4               [12] 3128 	clr	a
      006B35 F0               [24] 3129 	movx	@dptr,a
      006B36 A3               [24] 3130 	inc	dptr
      006B37 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B38 90 22 00         [24] 3133 	mov	dptr,#0x2200
      006B3B 74 02            [12] 3134 	mov	a,#0x02
      006B3D F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006B3E 90 22 37         [24] 3137 	mov	dptr,#0x2237
      006B41 74 7F            [12] 3138 	mov	a,#0x7f
      006B43 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006B44 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      006B47 74 FF            [12] 3142 	mov	a,#0xff
      006B49 F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006B4A 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      006B4D 74 07            [12] 3146 	mov	a,#0x07
      006B4F F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006B50 A3               [24] 3149 	inc	dptr
      006B51 74 80            [12] 3150 	mov	a,#0x80
      006B53 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3153 ;	assignBit
      006B54 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006B56 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      006B57                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006B57 90 07 B9         [24] 3169 	mov	dptr,#_USB_SleepStatus
      006B5A E0               [24] 3170 	movx	a,@dptr
      006B5B FF               [12] 3171 	mov	r7,a
      006B5C BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006B5F 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      006B62 E0               [24] 3175 	movx	a,@dptr
      006B63 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006B64 E0               [24] 3178 	movx	a,@dptr
      006B65 FE               [12] 3179 	mov	r6,a
      006B66 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      006B69 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      006B6C EE               [12] 3182 	mov	a,r6
      006B6D F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006B6E 7E 0A            [12] 3185 	mov	r6,#0x0a
      006B70                       3186 00108$:
      006B70 EE               [12] 3187 	mov	a,r6
      006B71 60 09            [24] 3188 	jz	00105$
      006B73 90 00 01         [24] 3189 	mov	dptr,#0x0001
      006B76 12 5D 31         [24] 3190 	lcall	_mDelaymS
      006B79 1E               [12] 3191 	dec	r6
      006B7A 80 F4            [24] 3192 	sjmp	00108$
      006B7C                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006B7C 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      006B7F EF               [12] 3196 	mov	a,r7
      006B80 F0               [24] 3197 	movx	@dptr,a
      006B81                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006B81 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      006B82                       3220 _ak820_usb_send:
      006B82 E5 82            [12] 3221 	mov	a,dpl
      006B84 90 08 20         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006B87 F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006B88 90 08 21         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006B8B 74 2E            [12] 3226 	mov	a,#0x2e
      006B8D F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006B8E 90 08 20         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006B91 E0               [24] 3230 	movx	a,@dptr
      006B92 FF               [12] 3231 	mov	r7,a
      006B93 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      006B96                       3233 00306$:
      006B96 40 14            [24] 3234 	jc	00101$
      006B98 EF               [12] 3235 	mov	a,r7
      006B99 24 FC            [12] 3236 	add	a,#0xff - 0x03
      006B9B 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      006B9D 90 08 1F         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      006BA0 E0               [24] 3240 	movx	a,@dptr
      006BA1 FE               [12] 3241 	mov  r6,a
      006BA2 24 BF            [12] 3242 	add	a,#0xff - 0x40
      006BA4 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      006BA6 90 07 B8         [24] 3245 	mov	dptr,#_USB_EnumStatus
      006BA9 E0               [24] 3246 	movx	a,@dptr
      006BAA 70 04            [24] 3247 	jnz	00102$
      006BAC                       3248 00101$:
      006BAC 75 82 00         [24] 3249 	mov	dpl, #0x00
      006BAF 22               [24] 3250 	ret
      006BB0                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006BB0 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006BB3 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      006BB6 80 04            [24] 3256 	sjmp	00107$
      006BB8                       3257 00313$:
      006BB8 75 82 00         [24] 3258 	mov	dpl, #0x00
      006BBB 22               [24] 3259 	ret
      006BBC                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006BBC 90 08 21         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006BBF E4               [12] 3263 	clr	a
      006BC0 F0               [24] 3264 	movx	@dptr,a
      006BC1 80 3C            [24] 3265 	sjmp	00119$
      006BC3                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006BC3 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006BC6 90 08 1D         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      006BC9 E0               [24] 3271 	movx	a,@dptr
      006BCA FD               [12] 3272 	mov	r5,a
      006BCB A3               [24] 3273 	inc	dptr
      006BCC E0               [24] 3274 	movx	a,@dptr
      006BCD FF               [12] 3275 	mov	r7,a
      006BCE 8D 82            [24] 3276 	mov	dpl,r5
      006BD0 8F 83            [24] 3277 	mov	dph,r7
      006BD2 E0               [24] 3278 	movx	a,@dptr
      006BD3 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006BD4 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      006BD7                       3282 00316$:
      006BD7 50 0E            [24] 3283 	jnc	00108$
      006BD9 EF               [12] 3284 	mov	a,r7
      006BDA 90 BF 28         [24] 3285 	mov	dptr,#_shared_lengths
      006BDD 93               [24] 3286 	movc	a,@a+dptr
      006BDE FD               [12] 3287 	mov	r5,a
      006BDF 60 06            [24] 3288 	jz	00108$
      006BE1 EE               [12] 3289 	mov	a,r6
      006BE2 B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      006BE5 80 04            [24] 3291 	sjmp	00109$
      006BE7                       3292 00319$:
      006BE7                       3293 00108$:
      006BE7 75 82 00         [24] 3294 	mov	dpl, #0x00
      006BEA 22               [24] 3295 	ret
      006BEB                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006BEB EF               [12] 3298 	mov	a,r7
      006BEC 90 BF 21         [24] 3299 	mov	dptr,#_shared_offsets
      006BEF 93               [24] 3300 	movc	a,@a+dptr
      006BF0 90 08 21         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006BF3 F0               [24] 3302 	movx	@dptr,a
      006BF4 80 09            [24] 3303 	sjmp	00119$
      006BF6                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006BF6 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      006BF9 80 04            [24] 3307 	sjmp	00119$
      006BFB                       3308 00320$:
      006BFB 75 82 00         [24] 3309 	mov	dpl, #0x00
      006BFE 22               [24] 3310 	ret
      006BFF                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006BFF 90 07 B9         [24] 3313 	mov	dptr,#_USB_SleepStatus
      006C02 E0               [24] 3314 	movx	a,@dptr
      006C03 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      006C06 12 6B 57         [24] 3316 	lcall	_USB_WakeUp_PC
      006C09 75 82 00         [24] 3317 	mov	dpl, #0x00
      006C0C 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006C0D                       3320 00184$:
      006C0D 7F FA            [12] 3321 	mov	r7,#0xfa
      006C0F                       3322 00127$:
      006C0F 90 08 20         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006C12 E0               [24] 3324 	movx	a,@dptr
      006C13 FC               [12] 3325 	mov	r4,a
      006C14 7D 00            [12] 3326 	mov	r5,#0x00
      006C16 8C 02            [24] 3327 	mov	ar2,r4
      006C18 74 22            [12] 3328 	mov	a,#0x22
      006C1A 2D               [12] 3329 	add	a, r5
      006C1B FB               [12] 3330 	mov	r3,a
      006C1C 8A 82            [24] 3331 	mov	dpl,r2
      006C1E 8B 83            [24] 3332 	mov	dph,r3
      006C20 E0               [24] 3333 	movx	a,@dptr
      006C21 54 03            [12] 3334 	anl	a,#0x03
      006C23 70 14            [24] 3335 	jnz	00129$
      006C25 8F 03            [24] 3336 	mov	ar3,r7
      006C27 1F               [12] 3337 	dec	r7
      006C28 EB               [12] 3338 	mov	a,r3
      006C29 60 0E            [24] 3339 	jz	00129$
      006C2B 7B 28            [12] 3340 	mov	r3,#0x28
      006C2D                       3341 00141$:
      006C2D EB               [12] 3342 	mov	a,r3
      006C2E 60 DF            [24] 3343 	jz	00127$
      006C30 90 00 01         [24] 3344 	mov	dptr,#0x0001
      006C33 12 5C ED         [24] 3345 	lcall	_mDelayuS
      006C36 1B               [12] 3346 	dec	r3
      006C37 80 F4            [24] 3347 	sjmp	00141$
      006C39                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006C39 A2 AF            [12] 3350 	mov	c,_EA
      006C3B E4               [12] 3351 	clr	a
      006C3C 33               [12] 3352 	rlc	a
      006C3D FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3355 ;	assignBit
      006C3E C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006C40 90 07 B8         [24] 3358 	mov	dptr,#_USB_EnumStatus
      006C43 E0               [24] 3359 	movx	a,@dptr
      006C44 60 25            [24] 3360 	jz	00130$
      006C46 90 08 20         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006C49 E0               [24] 3362 	movx	a,@dptr
      006C4A FB               [12] 3363 	mov	r3,a
      006C4B F9               [12] 3364 	mov	r1,a
      006C4C 7A 00            [12] 3365 	mov	r2,#0x00
      006C4E 74 22            [12] 3366 	mov	a,#0x22
      006C50 2A               [12] 3367 	add	a, r2
      006C51 FA               [12] 3368 	mov	r2,a
      006C52 89 82            [24] 3369 	mov	dpl,r1
      006C54 8A 83            [24] 3370 	mov	dph,r2
      006C56 E0               [24] 3371 	movx	a,@dptr
      006C57 FA               [12] 3372 	mov	r2,a
      006C58 53 02 03         [24] 3373 	anl	ar2,#0x03
      006C5B BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006C5E BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      006C61 90 07 BF         [24] 3377 	mov	dptr,#_raw_state
      006C64 E0               [24] 3378 	movx	a,@dptr
      006C65 FB               [12] 3379 	mov	r3,a
      006C66 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      006C69 80 09            [24] 3381 	sjmp	00192$
      006C6B                       3382 00331$:
      006C6B                       3383 00130$:
                                   3384 ;	assignBit
      006C6B EF               [12] 3385 	mov	a,r7
      006C6C 24 FF            [12] 3386 	add	a,#0xff
      006C6E 92 AF            [24] 3387 	mov	_EA,c
      006C70 75 82 00         [24] 3388 	mov	dpl, #0x00
      006C73 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006C74                       3391 00192$:
      006C74 7B 00            [12] 3392 	mov	r3,#0x00
      006C76                       3393 00144$:
      006C76 C3               [12] 3394 	clr	c
      006C77 EB               [12] 3395 	mov	a,r3
      006C78 9E               [12] 3396 	subb	a,r6
      006C79 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006C7B C0 07            [24] 3399 	push	ar7
      006C7D 90 08 20         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006C80 E0               [24] 3401 	movx	a,@dptr
      006C81 F9               [12] 3402 	mov	r1,a
      006C82 E4               [12] 3403 	clr	a
      006C83 C3               [12] 3404 	clr	c
      006C84 C9               [12] 3405 	xch	a,r1
      006C85 13               [12] 3406 	rrc	a
      006C86 C9               [12] 3407 	xch	a,r1
      006C87 13               [12] 3408 	rrc	a
      006C88 A2 E0            [12] 3409 	mov	c,acc.0
      006C8A C9               [12] 3410 	xch	a,r1
      006C8B 13               [12] 3411 	rrc	a
      006C8C C9               [12] 3412 	xch	a,r1
      006C8D 13               [12] 3413 	rrc	a
      006C8E C9               [12] 3414 	xch	a,r1
      006C8F FA               [12] 3415 	mov	r2,a
      006C90 8B 00            [24] 3416 	mov	ar0,r3
      006C92 7F 00            [12] 3417 	mov	r7,#0x00
      006C94 E8               [12] 3418 	mov	a,r0
      006C95 29               [12] 3419 	add	a, r1
      006C96 F9               [12] 3420 	mov	r1,a
      006C97 EF               [12] 3421 	mov	a,r7
      006C98 3A               [12] 3422 	addc	a, r2
      006C99 24 10            [12] 3423 	add	a,#0x10
      006C9B FA               [12] 3424 	mov	r2,a
      006C9C 90 08 1D         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      006C9F E0               [24] 3426 	movx	a,@dptr
      006CA0 F8               [12] 3427 	mov	r0,a
      006CA1 A3               [24] 3428 	inc	dptr
      006CA2 E0               [24] 3429 	movx	a,@dptr
      006CA3 FF               [12] 3430 	mov	r7,a
      006CA4 EB               [12] 3431 	mov	a,r3
      006CA5 28               [12] 3432 	add	a, r0
      006CA6 F5 1B            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      006CA8 E4               [12] 3434 	clr	a
      006CA9 3F               [12] 3435 	addc	a, r7
      006CAA F5 1C            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006CAC 85 1B 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006CAF 85 1C 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006CB2 E0               [24] 3439 	movx	a,@dptr
      006CB3 89 82            [24] 3440 	mov	dpl,r1
      006CB5 8A 83            [24] 3441 	mov	dph,r2
      006CB7 F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006CB8 90 08 21         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006CBB E0               [24] 3445 	movx	a,@dptr
      006CBC F5 1D            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      006CBE 74 2E            [12] 3447 	mov	a,#0x2e
      006CC0 B5 1D 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006CC3 D0 07            [24] 3449 	pop	ar7
      006CC5 80 18            [24] 3450 	sjmp	00145$
      006CC7                       3451 00333$:
      006CC7 D0 07            [24] 3452 	pop	ar7
      006CC9 EB               [12] 3453 	mov	a,r3
      006CCA 25 1D            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      006CCC 24 E2            [12] 3455 	add	a, #_input_snapshot
      006CCE F9               [12] 3456 	mov	r1,a
      006CCF E4               [12] 3457 	clr	a
      006CD0 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      006CD2 FA               [12] 3459 	mov	r2,a
      006CD3 85 1B 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006CD6 85 1C 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006CD9 E0               [24] 3462 	movx	a,@dptr
      006CDA 89 82            [24] 3463 	mov	dpl,r1
      006CDC 8A 83            [24] 3464 	mov	dph,r2
      006CDE F0               [24] 3465 	movx	@dptr,a
      006CDF                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006CDF 0B               [12] 3468 	inc	r3
      006CE0 80 94            [24] 3469 	sjmp	00144$
      006CE2                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006CE2 90 08 20         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006CE5 E0               [24] 3473 	movx	a,@dptr
      006CE6 FB               [12] 3474 	mov	r3,a
      006CE7 F9               [12] 3475 	mov	r1,a
      006CE8 7A 00            [12] 3476 	mov	r2,#0x00
      006CEA 74 08            [12] 3477 	mov	a,#0x08
      006CEC 29               [12] 3478 	add	a, r1
      006CED F9               [12] 3479 	mov	r1,a
      006CEE 74 22            [12] 3480 	mov	a,#0x22
      006CF0 3A               [12] 3481 	addc	a, r2
      006CF1 FA               [12] 3482 	mov	r2,a
      006CF2 89 82            [24] 3483 	mov	dpl,r1
      006CF4 8A 83            [24] 3484 	mov	dph,r2
      006CF6 EE               [12] 3485 	mov	a,r6
      006CF7 F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006CF8 BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      006CFB 90 07 BF         [24] 3489 	mov	dptr,#_raw_state
      006CFE 74 04            [12] 3490 	mov	a,#0x04
      006D00 F0               [24] 3491 	movx	@dptr,a
      006D01                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006D01 74 22            [12] 3494 	mov	a,#0x22
      006D03 2D               [12] 3495 	add	a, r5
      006D04 FD               [12] 3496 	mov	r5,a
      006D05 8C 82            [24] 3497 	mov	dpl,r4
      006D07 8D 83            [24] 3498 	mov	dph,r5
      006D09 E0               [24] 3499 	movx	a,@dptr
      006D0A FE               [12] 3500 	mov	r6,a
      006D0B 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      006D0E 8C 82            [24] 3502 	mov	dpl,r4
      006D10 8D 83            [24] 3503 	mov	dph,r5
      006D12 EE               [12] 3504 	mov	a,r6
      006D13 F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3507 ;	assignBit
      006D14 EF               [12] 3508 	mov	a,r7
      006D15 24 FF            [12] 3509 	add	a,#0xff
      006D17 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006D19 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006D1C 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      006D1D                       3528 _ak820_usb_try_send:
      006D1D E5 82            [12] 3529 	mov	a,dpl
      006D1F 90 08 25         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006D22 F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      006D23 A2 AF            [12] 3534 	mov	c,_EA
      006D25 92 1D            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006D27 90 08 26         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006D2A E4               [12] 3538 	clr	a
      006D2B F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3541 ;	assignBit
      006D2C C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006D2E 90 08 25         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006D31 E0               [24] 3545 	movx	a,@dptr
      006D32 FF               [12] 3546 	mov	r7,a
      006D33 BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      006D36                       3548 00152$:
      006D36 40 4E            [24] 3549 	jc	00102$
      006D38 EF               [12] 3550 	mov	a,r7
      006D39 24 FD            [12] 3551 	add	a,#0xff - 0x02
      006D3B 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      006D3D 90 07 B8         [24] 3554 	mov	dptr,#_USB_EnumStatus
      006D40 E0               [24] 3555 	movx	a,@dptr
      006D41 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006D43 90 07 B9         [24] 3558 	mov	dptr,#_USB_SleepStatus
      006D46 E0               [24] 3559 	movx	a,@dptr
      006D47 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      006D4A 90 07 E1         [24] 3561 	mov	dptr,#_keyboard_reset
      006D4D E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006D4E 70 36            [24] 3564 	jnz	00102$
      006D50 8F 06            [24] 3565 	mov	ar6,r7
      006D52 24 22            [12] 3566 	add	a,#0x22
      006D54 FD               [12] 3567 	mov	r5,a
      006D55 8E 82            [24] 3568 	mov	dpl,r6
      006D57 8D 83            [24] 3569 	mov	dph,r5
      006D59 E0               [24] 3570 	movx	a,@dptr
      006D5A FE               [12] 3571 	mov	r6,a
      006D5B 53 06 03         [24] 3572 	anl	ar6,#0x03
      006D5E BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006D61 90 08 22         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006D64 E0               [24] 3576 	movx	a,@dptr
      006D65 FD               [12] 3577 	mov	r5,a
      006D66 A3               [24] 3578 	inc	dptr
      006D67 E0               [24] 3579 	movx	a,@dptr
      006D68 FE               [12] 3580 	mov	r6,a
      006D69 90 08 24         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006D6C E0               [24] 3582 	movx	a,@dptr
      006D6D FC               [12] 3583 	mov	r4,a
      006D6E 90 08 1D         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      006D71 ED               [12] 3585 	mov	a,r5
      006D72 F0               [24] 3586 	movx	@dptr,a
      006D73 EE               [12] 3587 	mov	a,r6
      006D74 A3               [24] 3588 	inc	dptr
      006D75 F0               [24] 3589 	movx	@dptr,a
      006D76 90 08 1F         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      006D79 EC               [12] 3591 	mov	a,r4
      006D7A F0               [24] 3592 	movx	@dptr,a
      006D7B 8F 82            [24] 3593 	mov	dpl, r7
      006D7D 12 6B 82         [24] 3594 	lcall	_ak820_usb_send
      006D80 E5 82            [12] 3595 	mov	a, dpl
      006D82 90 08 26         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006D85 F0               [24] 3597 	movx	@dptr,a
      006D86                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3600 ;	assignBit
      006D86 A2 1D            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006D88 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006D8A 90 08 26         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006D8D E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006D8E F5 82            [12] 3607 	mov	dpl,a
      006D90 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      006D91                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006D91 90 07 C0         [24] 3618 	mov	dptr,#_raw_buffer
      006D94 E0               [24] 3619 	movx	a,@dptr
      006D95 FF               [12] 3620 	mov	r7,a
      006D96 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      006D99 80 35            [24] 3622 	sjmp	00108$
      006D9B                       3623 00302$:
      006D9B BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      006D9E 80 34            [24] 3625 	sjmp	00109$
      006DA0                       3626 00303$:
      006DA0 BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      006DA3 80 2B            [24] 3628 	sjmp	00108$
      006DA5                       3629 00304$:
      006DA5 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      006DA8 80 47            [24] 3631 	sjmp	00116$
      006DAA                       3632 00305$:
      006DAA BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      006DAD 80 21            [24] 3634 	sjmp	00108$
      006DAF                       3635 00306$:
      006DAF BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      006DB2 80 1C            [24] 3637 	sjmp	00108$
      006DB4                       3638 00307$:
      006DB4 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      006DB7 80 17            [24] 3640 	sjmp	00108$
      006DB9                       3641 00308$:
      006DB9 BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      006DBC 80 12            [24] 3643 	sjmp	00108$
      006DBE                       3644 00309$:
      006DBE BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      006DC1 80 0D            [24] 3646 	sjmp	00108$
      006DC3                       3647 00310$:
      006DC3 BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      006DC6 80 08            [24] 3649 	sjmp	00108$
      006DC8                       3650 00311$:
      006DC8 BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      006DCB 80 46            [24] 3652 	sjmp	00124$
      006DCD                       3653 00312$:
      006DCD 02 6E 68         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006DD0                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006DD0 75 82 01         [24] 3658 	mov	dpl, #0x01
      006DD3 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006DD4                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006DD4 12 70 9A         [24] 3663 	lcall	_ak820_outline_0167
      006DD7 BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      006DDA 80 0D            [24] 3665 	sjmp	00113$
      006DDC                       3666 00313$:
      006DDC BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      006DDF 80 08            [24] 3668 	sjmp	00113$
      006DE1                       3669 00314$:
      006DE1 BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      006DE4 80 03            [24] 3671 	sjmp	00113$
      006DE6                       3672 00315$:
      006DE6 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006DE9                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006DE9 75 82 01         [24] 3677 	mov	dpl, #0x01
      006DEC 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006DED                       3680 00114$:
      006DED 75 82 00         [24] 3681 	mov	dpl, #0x00
      006DF0 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006DF1                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006DF1 12 70 9A         [24] 3686 	lcall	_ak820_outline_0167
      006DF4 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      006DF7 80 12            [24] 3688 	sjmp	00121$
      006DF9                       3689 00318$:
      006DF9 BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      006DFC 80 0D            [24] 3691 	sjmp	00121$
      006DFE                       3692 00319$:
      006DFE BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      006E01 80 08            [24] 3694 	sjmp	00121$
      006E03                       3695 00320$:
      006E03 BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      006E06 80 03            [24] 3697 	sjmp	00121$
      006E08                       3698 00321$:
      006E08 BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006E0B                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006E0B 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006E0E 22               [24] 3705 	ret
      006E0F                       3706 00122$:
      006E0F 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006E12 22               [24] 3709 	ret
      006E13                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006E13 12 70 9A         [24] 3712 	lcall	_ak820_outline_0167
      006E16 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      006E18 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      006E1A EF               [12] 3716 	mov	a,r7
      006E1B 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      006E1D 83               [24] 3718 	movc	a,@a+pc
      006E1E F5 82            [12] 3719 	mov	dpl,a
      006E20 EF               [12] 3720 	mov	a,r7
      006E21 24 12            [12] 3721 	add	a,#(00326$-3-.)
      006E23 83               [24] 3722 	movc	a,@a+pc
      006E24 F5 83            [12] 3723 	mov	dph,a
      006E26 E4               [12] 3724 	clr	a
      006E27 73               [24] 3725 	jmp	@a+dptr
      006E28                       3726 00325$:
      006E28 44                    3727 	.db	00134$
      006E29 44                    3728 	.db	00134$
      006E2A 44                    3729 	.db	00134$
      006E2B 44                    3730 	.db	00134$
      006E2C 64                    3731 	.db	00142$
      006E2D 44                    3732 	.db	00134$
      006E2E 44                    3733 	.db	00134$
      006E2F 44                    3734 	.db	00134$
      006E30 44                    3735 	.db	00134$
      006E31 44                    3736 	.db	00134$
      006E32 44                    3737 	.db	00134$
      006E33 64                    3738 	.db	00142$
      006E34 64                    3739 	.db	00142$
      006E35 48                    3740 	.db	00135$
      006E36                       3741 00326$:
      006E36 6E                    3742 	.db	00134$>>8
      006E37 6E                    3743 	.db	00134$>>8
      006E38 6E                    3744 	.db	00134$>>8
      006E39 6E                    3745 	.db	00134$>>8
      006E3A 6E                    3746 	.db	00142$>>8
      006E3B 6E                    3747 	.db	00134$>>8
      006E3C 6E                    3748 	.db	00134$>>8
      006E3D 6E                    3749 	.db	00134$>>8
      006E3E 6E                    3750 	.db	00134$>>8
      006E3F 6E                    3751 	.db	00134$>>8
      006E40 6E                    3752 	.db	00134$>>8
      006E41 6E                    3753 	.db	00142$>>8
      006E42 6E                    3754 	.db	00142$>>8
      006E43 6E                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006E44                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006E44 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006E47 22               [24] 3761 	ret
      006E48                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006E48 90 07 C2         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      006E4B E0               [24] 3765 	movx	a,@dptr
      006E4C FF               [12] 3766 	mov	r7,a
      006E4D 60 0D            [24] 3767 	jz	00139$
      006E4F BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      006E52 80 08            [24] 3769 	sjmp	00139$
      006E54                       3770 00328$:
      006E54 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      006E57 80 03            [24] 3772 	sjmp	00139$
      006E59                       3773 00329$:
      006E59 BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006E5C                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006E5C 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006E5F 22               [24] 3780 	ret
      006E60                       3781 00140$:
      006E60 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006E63 22               [24] 3784 	ret
      006E64                       3785 00142$:
      006E64 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006E67 22               [24] 3788 	ret
      006E68                       3789 00144$:
      006E68 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006E6B 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      006E6C                       3804 _ak820_usb_raw_send:
      006E6C 12 43 11         [24] 3805 	lcall	_ak820_outline_0037
      006E6F 90 08 28         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006E72 12 38 1E         [24] 3807 	lcall	_ak820_outline_0017
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006E75 90 08 27         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006E78 E0               [24] 3810 	movx	a,@dptr
      006E79 FF               [12] 3811 	mov	r7,a
      006E7A BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006E7D C0 07            [24] 3814 	push	ar7
      006E7F 12 3E 28         [24] 3815 	lcall	_ak820_nvm_flush
      006E82 D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006E84 90 07 E0         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      006E87 E0               [24] 3819 	movx	a,@dptr
      006E88 70 07            [24] 3820 	jnz	00103$
      006E8A 12 3E 19         [24] 3821 	lcall	_ak820_nvm_ok
      006E8D E5 82            [12] 3822 	mov	a, dpl
      006E8F 60 17            [24] 3823 	jz	00106$
      006E91                       3824 00103$:
      006E91 90 08 28         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006E94 12 38 59         [24] 3826 	lcall	_ak820_outline_0079
      006E97 90 08 1D         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      006E9A 12 43 6C         [24] 3828 	lcall	_ak820_outline_0141
      006E9D 90 08 1F         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      006EA0 EF               [12] 3830 	mov	a,r7
      006EA1 F0               [24] 3831 	movx	@dptr,a
      006EA2 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006EA5 02 6B 82         [24] 3834 	ljmp	_ak820_usb_send
      006EA8                       3835 00106$:
      006EA8 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      006EA9                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006EA9 A2 AF            [12] 3852 	mov	c,_EA
      006EAB E4               [12] 3853 	clr	a
      006EAC 33               [12] 3854 	rlc	a
      006EAD FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3857 ;	assignBit
      006EAE C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006EB0 90 07 B8         [24] 3860 	mov	dptr,#_USB_EnumStatus
      006EB3 E0               [24] 3861 	movx	a,@dptr
      006EB4 60 0A            [24] 3862 	jz	00101$
      006EB6 90 07 BF         [24] 3863 	mov	dptr,#_raw_state
      006EB9 E0               [24] 3864 	movx	a,@dptr
      006EBA FE               [12] 3865 	mov	r6,a
      006EBB BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      006EBE 80 06            [24] 3867 	sjmp	00102$
      006EC0                       3868 00270$:
      006EC0                       3869 00101$:
                                   3870 ;	assignBit
      006EC0 EF               [12] 3871 	mov	a,r7
      006EC1 24 FF            [12] 3872 	add	a,#0xff
      006EC3 92 AF            [24] 3873 	mov	_EA,c
      006EC5 22               [24] 3874 	ret
      006EC6                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006EC6 90 07 BF         [24] 3877 	mov	dptr,#_raw_state
      006EC9 74 03            [12] 3878 	mov	a,#0x03
      006ECB F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3881 ;	assignBit
      006ECC EF               [12] 3882 	mov	a,r7
      006ECD 24 FF            [12] 3883 	add	a,#0xff
      006ECF 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006ED1 90 07 C0         [24] 3886 	mov	dptr,#_raw_buffer
      006ED4 E0               [24] 3887 	movx	a,@dptr
      006ED5 FF               [12] 3888 	mov	r7,a
      006ED6 E4               [12] 3889 	clr	a
      006ED7 BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      006EDA 04               [12] 3891 	inc	a
      006EDB                       3892 00271$:
      006EDB FF               [12] 3893 	mov	r7,a
      006EDC 70 03            [24] 3894 	jnz	00273$
      006EDE 02 6F 7E         [24] 3895 	ljmp	00118$
      006EE1                       3896 00273$:
      006EE1 90 07 C1         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      006EE4 E0               [24] 3898 	movx	a,@dptr
      006EE5 60 03            [24] 3899 	jz	00274$
      006EE7 02 6F 7E         [24] 3900 	ljmp	00118$
      006EEA                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006EEA 90 07 C2         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      006EED E0               [24] 3904 	movx	a,@dptr
      006EEE FD               [12] 3905 	mov	r5,a
      006EEF 7E 00            [12] 3906 	mov	r6,#0x00
      006EF1 90 07 C3         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      006EF4 E0               [24] 3908 	movx	a,@dptr
      006EF5 7B 00            [12] 3909 	mov	r3,#0x00
      006EF7 42 06            [12] 3910 	orl	ar6,a
      006EF9 EB               [12] 3911 	mov	a,r3
      006EFA 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006EFC 90 07 C4         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      006EFF E0               [24] 3915 	movx	a,@dptr
      006F00 FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F01 7B 05            [12] 3918 	mov	r3,#0x05
      006F03                       3919 00128$:
      006F03 EB               [12] 3920 	mov	a,r3
      006F04 12 70 88         [24] 3921 	lcall	_ak820_outline_0110
      006F07 0B               [12] 3922 	inc	r3
      006F08 BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      006F0B                       3924 00275$:
      006F0B 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006F0D EC               [12] 3927 	mov	a,r4
      006F0E 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      006F10 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      006F12 EC               [12] 3931 	mov	a,r4
      006F13 60 26            [24] 3932 	jz	00165$
      006F15 8C 03            [24] 3933 	mov	ar3,r4
      006F17 1B               [12] 3934 	dec	r3
      006F18 7A 00            [12] 3935 	mov	r2,#0x00
      006F1A 74 FF            [12] 3936 	mov	a,#0xff
      006F1C C3               [12] 3937 	clr	c
      006F1D 9B               [12] 3938 	subb	a,r3
      006F1E FB               [12] 3939 	mov	r3,a
      006F1F 74 FF            [12] 3940 	mov	a,#0xff
      006F21 9A               [12] 3941 	subb	a,r2
      006F22 FA               [12] 3942 	mov	r2,a
      006F23 8E 00            [24] 3943 	mov	ar0,r6
      006F25 8D 01            [24] 3944 	mov	ar1,r5
      006F27 C3               [12] 3945 	clr	c
      006F28 EB               [12] 3946 	mov	a,r3
      006F29 98               [12] 3947 	subb	a,r0
      006F2A EA               [12] 3948 	mov	a,r2
      006F2B 99               [12] 3949 	subb	a,r1
      006F2C 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      006F2E                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006F2E 90 07 C1         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      006F31 74 FF            [12] 3955 	mov	a,#0xff
      006F33 F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006F34 90 07 C4         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      006F37 E4               [12] 3959 	clr	a
      006F38 F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006F39 80 3A            [24] 3962 	sjmp	00108$
      006F3B                       3963 00165$:
      006F3B 7B 00            [12] 3964 	mov	r3,#0x00
      006F3D                       3965 00131$:
      006F3D C3               [12] 3966 	clr	c
      006F3E EB               [12] 3967 	mov	a,r3
      006F3F 9C               [12] 3968 	subb	a,r4
      006F40 50 33            [24] 3969 	jnc	00108$
      006F42 C0 04            [24] 3970 	push	ar4
      006F44 8B 02            [24] 3971 	mov	ar2,r3
      006F46 74 05            [12] 3972 	mov	a,#0x05
      006F48 2A               [12] 3973 	add	a, r2
      006F49 F9               [12] 3974 	mov	r1,a
      006F4A 33               [12] 3975 	rlc	a
      006F4B 95 E0            [12] 3976 	subb	a,acc
      006F4D FA               [12] 3977 	mov	r2,a
      006F4E E9               [12] 3978 	mov	a,r1
      006F4F 24 C0            [12] 3979 	add	a, #_raw_buffer
      006F51 F9               [12] 3980 	mov	r1,a
      006F52 EA               [12] 3981 	mov	a,r2
      006F53 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      006F55 FA               [12] 3983 	mov	r2,a
      006F56 8B 1E            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006F58 75 1F 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006F5B 8E 00            [24] 3986 	mov	ar0,r6
      006F5D 8D 04            [24] 3987 	mov	ar4,r5
      006F5F E5 1E            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006F61 28               [12] 3989 	add	a, r0
      006F62 F8               [12] 3990 	mov	r0,a
      006F63 E5 1F            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006F65 3C               [12] 3992 	addc	a, r4
      006F66 FC               [12] 3993 	mov	r4,a
      006F67 88 82            [24] 3994 	mov	dpl,r0
      006F69 8C 83            [24] 3995 	mov	dph,r4
      006F6B E4               [12] 3996 	clr	a
      006F6C 93               [24] 3997 	movc	a,@a+dptr
      006F6D 12 70 94         [24] 3998 	lcall	_ak820_outline_0142
      006F70 0B               [12] 3999 	inc	r3
      006F71 D0 04            [24] 4000 	pop	ar4
      006F73 80 C8            [24] 4001 	sjmp	00131$
      006F75                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006F75 12 70 74         [24] 4004 	lcall	_ak820_outline_0046
      006F78 12 6B 82         [24] 4005 	lcall	_ak820_usb_send
      006F7B 02 70 24         [24] 4006 	ljmp	00119$
      006F7E                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006F7E EF               [12] 4009 	mov	a,r7
      006F7F 70 03            [24] 4010 	jnz	00281$
      006F81 02 70 01         [24] 4011 	ljmp	00114$
      006F84                       4012 00281$:
      006F84 12 70 9A         [24] 4013 	lcall	_ak820_outline_0167
      006F87 BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      006F8A 80 03            [24] 4015 	sjmp	00283$
      006F8C                       4016 00282$:
      006F8C 02 70 01         [24] 4017 	ljmp	00114$
      006F8F                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F8F 7F 02            [12] 4020 	mov	r7,#0x02
      006F91                       4021 00133$:
      006F91 EF               [12] 4022 	mov	a,r7
      006F92 12 70 88         [24] 4023 	lcall	_ak820_outline_0110
      006F95 0F               [12] 4024 	inc	r7
      006F96 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      006F99                       4026 00284$:
      006F99 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006F9B 90 07 C2         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      006F9E 74 01            [12] 4030 	mov	a,#0x01
      006FA0 F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006FA1 90 07 C3         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      006FA4 74 A8            [12] 4034 	mov	a,#0xa8
      006FA6 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006FA7 90 07 C4         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      006FAA 12 3B 98         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006FAD 7F 00            [12] 4040 	mov	r7,#0x00
      006FAF                       4041 00135$:
      006FAF 8F 06            [24] 4042 	mov	ar6,r7
      006FB1 74 0B            [12] 4043 	mov	a,#0x0b
      006FB3 2E               [12] 4044 	add	a, r6
      006FB4 24 C0            [12] 4045 	add	a,#_raw_buffer
      006FB6 FE               [12] 4046 	mov	r6,a
      006FB7 E4               [12] 4047 	clr	a
      006FB8 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      006FBA FD               [12] 4049 	mov	r5,a
      006FBB EF               [12] 4050 	mov	a,r7
      006FBC 24 64            [12] 4051 	add	a, #_ak820_flash_diagnostic
      006FBE F5 82            [12] 4052 	mov	dpl,a
      006FC0 E4               [12] 4053 	clr	a
      006FC1 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006FC3 F5 83            [12] 4055 	mov	dph,a
      006FC5 E0               [24] 4056 	movx	a,@dptr
      006FC6 8E 82            [24] 4057 	mov	dpl,r6
      006FC8 8D 83            [24] 4058 	mov	dph,r5
      006FCA F0               [24] 4059 	movx	@dptr,a
      006FCB 0F               [12] 4060 	inc	r7
      006FCC BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      006FCF                       4062 00286$:
      006FCF 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006FD1 90 0E 6A         [24] 4065 	mov	dptr,#_vial_unlocked
      006FD4 E0               [24] 4066 	movx	a,@dptr
      006FD5 90 07 D1         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      006FD8 F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006FD9 90 0E 6B         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      006FDC E0               [24] 4071 	movx	a,@dptr
      006FDD 90 07 D2         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      006FE0 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006FE1 90 07 B8         [24] 4075 	mov	dptr,#_USB_EnumStatus
      006FE4 E0               [24] 4076 	movx	a,@dptr
      006FE5 90 07 D3         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      006FE8 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006FE9 90 07 B9         [24] 4080 	mov	dptr,#_USB_SleepStatus
      006FEC E0               [24] 4081 	movx	a,@dptr
      006FED 90 07 D4         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      006FF0 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006FF1 90 07 BF         [24] 4085 	mov	dptr,#_raw_state
      006FF4 E0               [24] 4086 	movx	a,@dptr
      006FF5 90 07 D5         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      006FF8 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006FF9 12 70 74         [24] 4090 	lcall	_ak820_outline_0046
      006FFC 12 6B 82         [24] 4091 	lcall	_ak820_usb_send
      006FFF 80 23            [24] 4092 	sjmp	00119$
      007001                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      007001 12 6D 91         [24] 4095 	lcall	_raw_request_is_nonpersistent
      007004 E5 82            [12] 4096 	mov	a, dpl
      007006 90 07 E0         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      007009 F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      00700A 12 3F 7A         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      00700D 90 0C 94         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      007010 74 20            [12] 4103 	mov	a,#0x20
      007012 F0               [24] 4104 	movx	@dptr,a
      007013 90 07 C0         [24] 4105 	mov	dptr,#_raw_buffer
      007016 75 F0 00         [24] 4106 	mov	b, #0x00
      007019 12 AA 85         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      00701C 12 3F 8F         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      00701F 90 07 E0         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      007022 E4               [12] 4112 	clr	a
      007023 F0               [24] 4113 	movx	@dptr,a
      007024                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4116 ;	assignBit
      007024 A2 AF            [12] 4117 	mov	c,_EA
      007026 92 1E            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4120 ;	assignBit
      007028 C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      00702A 12 70 A0         [24] 4123 	lcall	_ak820_outline_0170
      00702D BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      007030 90 07 BF         [24] 4125 	mov	dptr,#_raw_state
      007033 74 05            [12] 4126 	mov	a,#0x05
      007035 F0               [24] 4127 	movx	@dptr,a
      007036 80 1B            [24] 4128 	sjmp	00127$
      007038                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      007038 12 70 A0         [24] 4131 	lcall	_ak820_outline_0170
      00703B BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      00703E 80 0E            [24] 4133 	sjmp	00121$
      007040                       4134 00290$:
      007040 12 70 A0         [24] 4135 	lcall	_ak820_outline_0170
      007043 BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      007046 80 06            [24] 4137 	sjmp	00121$
      007048                       4138 00291$:
      007048 12 70 A0         [24] 4139 	lcall	_ak820_outline_0170
      00704B BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      00704E                       4141 00121$:
      00704E 90 07 BF         [24] 4142 	mov	dptr,#_raw_state
      007051 E4               [12] 4143 	clr	a
      007052 F0               [24] 4144 	movx	@dptr,a
      007053                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4147 ;	assignBit
      007053 A2 1E            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      007055 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      007057 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      007058                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      007058 A2 AF            [12] 4165 	mov	c,_EA
      00705A 92 1F            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4168 ;	assignBit
      00705C C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      00705E 90 07 E1         [24] 4171 	mov	dptr,#_keyboard_reset
      007061 E0               [24] 4172 	movx	a,@dptr
      007062 FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      007063 E4               [12] 4175 	clr	a
      007064 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4178 ;	assignBit
      007065 A2 1F            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      007067 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      007069 EF               [12] 4182 	mov	a,r7
      00706A B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      00706D                       4184 00103$:
      00706D B3               [12] 4185 	cpl	c
      00706E 92 1F            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      007070 12 38 B2         [24] 4187 	lcall	_ak820_outline_0154
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      007073 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00BF21                       4193 _shared_offsets:
      00BF21 00                    4194 	.db #0x00	; 0
      00BF22 00                    4195 	.db #0x00	; 0
      00BF23 28                    4196 	.db #0x28	; 40
      00BF24 28                    4197 	.db #0x28	; 40
      00BF25 2B                    4198 	.db #0x2b	; 43
      00BF26 00                    4199 	.db #0x00	; 0
      00BF27 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00BF28                       4203 _shared_lengths:
      00BF28 00                    4204 	.db #0x00	; 0
      00BF29 00                    4205 	.db #0x00	; 0
      00BF2A 00                    4206 	.db #0x00	; 0
      00BF2B 03                    4207 	.db #0x03	; 3
      00BF2C 03                    4208 	.db #0x03	; 3
      00BF2D 00                    4209 	.db #0x00	; 0
      00BF2E 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00BF2F                       4213 _interface_descriptors:
      00BF2F CA C4                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BF31 CA C5                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BF33 7D C5                 4216 	.byte _RawReport, (_RawReport >> 8)
      00BF35 E3 C5                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BF37 0F C5                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00BF39 FC C5                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0017
                                   4226 	.globl _ak820_outline_0037
                                   4227 	.globl _ak820_outline_0046
                                   4228 	.globl _ak820_outline_0079
                                   4229 	.globl _ak820_outline_0110
                                   4230 	.globl _ak820_outline_0141
                                   4231 	.globl _ak820_outline_0142
                                   4232 	.globl _ak820_outline_0154
                                   4233 	.globl _ak820_outline_0167
                                   4234 	.globl _ak820_outline_0170
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0046
      007074                       4238 _ak820_outline_0046:
      007074 90 08 1D         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      007077 74 C0            [12] 4240 	mov	a,#_raw_buffer
      007079 F0               [24] 4241 	movx	@dptr,a
      00707A 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      00707C A3               [24] 4243 	inc	dptr
      00707D F0               [24] 4244 	movx	@dptr,a
      00707E 90 08 1F         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      007081 74 20            [12] 4246 	mov	a,#0x20
      007083 F0               [24] 4247 	movx	@dptr,a
      007084 75 82 03         [24] 4248 	mov	dpl,#0x03
      007087 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0110
      007088                       4253 _ak820_outline_0110:
      007088 24 C0            [12] 4254 	add	a,#_raw_buffer
      00708A F5 82            [12] 4255 	mov	dpl,a
      00708C E4               [12] 4256 	clr	a
      00708D 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      00708F F5 83            [12] 4258 	mov	dph,a
      007091 E4               [12] 4259 	clr	a
      007092 F0               [24] 4260 	movx	@dptr,a
      007093 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0142
      007094                       4265 _ak820_outline_0142:
      007094 89 82            [24] 4266 	mov	dpl,r1
      007096 8A 83            [24] 4267 	mov	dph,r2
      007098 F0               [24] 4268 	movx	@dptr,a
      007099 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0167
      00709A                       4273 _ak820_outline_0167:
      00709A 90 07 C1         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      00709D E0               [24] 4275 	movx	a,@dptr
      00709E FF               [12] 4276 	mov	r7,a
      00709F 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0170
      0070A0                       4281 _ak820_outline_0170:
      0070A0 90 07 BF         [24] 4282 	mov	dptr,#_raw_state
      0070A3 E0               [24] 4283 	movx	a,@dptr
      0070A4 FF               [12] 4284 	mov	r7,a
      0070A5 22               [24] 4285 	ret
